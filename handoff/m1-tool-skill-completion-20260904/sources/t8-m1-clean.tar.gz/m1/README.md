# M1 生产文档智能解析

M1 的 canonical Compose 同时启动 API、MinerU、一次性知识迁移、PostgreSQL Wiki、
Neo4j Graph 及受治理的增强服务。运行目标为带 NVIDIA GPU 的 x86_64/AMD64 主机；
PaddlePaddle 当前锁定版本没有 Linux ARM64 wheel。
上传 XLSX/XLS/CSV、PDF、DOCX、图片、DXF 或归档，自动抽取
`m1.document.v2`、建立字段索引，并将低置信项或冲突送入人工审核。

MinerU + Instructor 是所有受支持文档的唯一事实权威。型号、数量、金额、日期和编号
必须具有源证据；名称归一化、产品分类和属性拆解是可关闭的结果字段。MinerU、
Instructor 或其必需模型不可用时失败关闭并进入审核，不回退到已删除的旧解析器。

> 运行镜像保留原有 React 控制台和全部 M1 API；前端静态资源已预编译，因此部署
> 不需要 Node.js。知识库能力以增量方式接入，不替换原审核 UI、报告、下载或 CAD/VLM
> 链路。

---

## 前置条件

目标机器需要 Docker Engine、Compose v2、NVIDIA 驱动与 NVIDIA Container Toolkit。
不需要本机 Python 或 Node.js，但必须预先准备固定版本的离线模型目录和发布目录中的
完整镜像集合。

确认:

```bash
docker --version          # >= 20
docker compose version    # v2
```

---

## 本地生产同形启动

**1. 准备非密钥配置和进程环境密钥**

不要把真实密钥提交到仓库。复制模板后，填写镜像引用、离线模型根目录、数据库口令、
MinerU mapper 和 drawing-VLM 的独立 endpoint/model；密钥通过进程环境或本机
root-owned 配置注入：

```powershell
Copy-Item .env.example .env
$env:M1_MINERU_MAPPER_API_KEY="<mapper-key>"
$env:M1_MINERU_DRAWING_REGION_VLM_API_KEY="<drawing-vlm-key>"
```

Linux/macOS 使用 `cp .env.example .env`，再按相同变量名执行 `export`。

模板同时声明归档限额、模型清单、路由、知识库和生命周期配置。任务库保持 SQLite；
权威知识使用独立 PostgreSQL，图投影使用 Neo4j。

**2. 构建并启动**

```bash
docker compose -f docker-compose.yml config --quiet
docker compose -f docker-compose.yml up -d --build
```

`.env.example` 中的数据库口令只是本机开发占位值，部署前必须由密钥管理系统覆盖。
`docker-compose.yml` 只是 canonical `runtime + build + dev` 三个 fragment 的兼容入口；
它包含 MinerU sidecar 和 one-shot migration，不再维护另一套服务定义。

full-GPU 构建安装固定版本 Paddle、Docling 和 Instructor；之后依赖未变化时可复用
Docker 层缓存。

存活检查: <http://localhost:8080/health>。OCR/VLM 依赖就绪检查:
<http://localhost:8080/ready>；只有后者返回 HTTP 200 才开始接收生产流量。运行时
模型下载被禁止，缓存或模型摘要缺失会保持未就绪。

---

## 验证一下（用自带的样例）

包里带了 `samples/test_cable.pdf`（一份真实的工程图）。

```bash
curl -X POST http://localhost:8080/ingest -F "file=@samples/test_cable.pdf"
# 返回 {"task_id":"...","status":"queued"} 之类

# 用返回的 task_id 查结果（把 <id> 换掉）
curl http://localhost:8080/tasks/<id>
```

几秒到几十秒后（取决于 VLM 响应速度），任务会变成 `done`, 字段、置信度、明细表都出来了。

## 文档与检索 API

```text
POST /ingest                         异步上传
POST /ingest/sync                    同步上传；支持类型/子类型提示与语义开关
GET  /tasks/{id}/document            完整 m1.document.v2
GET  /documents/search               全文、类型和任意字段路径检索
GET  /orders/search                  订单号、型号、名称、类别和日期检索
GET  /tasks/{id}/exports/order.xlsx  四 Sheet 标准订单表
POST /review/{id}                    页眉、行字段和校验问题审核
POST /ingest/archive                 ZIP/TAR/RAR/7Z 异步归档任务
```

标准订单 Excel 包含“订单头、产品明细、校验问题、原始证据”。归档默认限制为
512 MiB 压缩/解压总量、100 MiB 单文件、5000 条目、100:1 压缩比和 2 层递归。

## 客户资料盘点（任务 2）

在正式解析前先运行只读目录调研 CLI。它递归识别普通文件和嵌套归档、按魔数/扩展名
统计类型、流式计算 SHA-256、标记重复文件，并稳定选出每种类型的真实样本。该命令
不修改源文件、不解压到客户目录，也不调用 OCR、LLM 或 VLM：

```powershell
uv run --frozen python -m m1.onboarding "C:\客户资料" `
  --json .\data\catalog.json `
  --csv .\data\catalog.csv `
  --sample-per-type 5 `
  --fail-on-errors
```

快速预盘可加 `--metadata-only` 跳过哈希；最终入库前应去掉该参数，以 SHA-256 作为
幂等和去重依据。归档限制可通过 `--max-archive-size`、`--max-total-uncompressed`、
`--max-single-file`、`--max-entries`、`--max-compression-ratio` 和
`--max-recursion-depth` 调整。

## Governed Wiki + Graph（任务 4/5）

每次 M1 生成 `m1.document.v2` 后，KnowledgeRuntime 会将原始证据、字段事实、标准实体、
版本、审核状态、知识切片和检索投影写入 Wiki，再通过 outbox 投影到 Graph。确定性高
置信事实可激活；推断、冲突和低置信内容保持 `candidate/under_review`，普通检索默认不可见。
图投影失败不会破坏原始 M1 任务，管理员可安全重放 outbox。

开发/单租户兼容模式可使用以下头部；未传租户头时使用 `default`：

```text
X-Tenant-ID: customer-a
X-Actor-ID: user-or-service-id
X-Actor-Roles: reader                 # 多角色逗号分隔
```

`reviewer` 可查看/处理待审核知识，`admin` 可创建租户、回填和重放 outbox。多客户生产
环境必须配置 `TENANT_API_KEY_HASHES`：服务端按请求 key 的 SHA-256 绑定
`tenant_id/actor_id/roles`，并忽略客户端试图抬高租户或角色的头部。只配置
`API_AUTH_KEY` 的全局 key 模式仅用于单租户旧客户端，不应直接暴露到公网。

```text
GET  /knowledge/health                       Wiki/Graph 健康状态
POST /knowledge/tenants                      创建租户（admin）
POST /knowledge/tasks/{task_id}/sync         单任务幂等同步，不重新调用 OCR/VLM
POST /knowledge/backfill                     有界回填历史 M1 结果（admin/reviewer）
GET  /knowledge/search                       已激活知识检索；候选需显式权限
GET  /knowledge/entities                     标准实体列表
GET  /knowledge/entities/{entity_id}         标准实体详情
GET  /knowledge/reviews                      审核队列（admin/reviewer）
POST /knowledge/reviews/reassess             无模型重评历史误报；默认 dry-run（admin）
POST /knowledge/reviews/bulk                 批量文档审核并级联派生任务；默认 dry-run（admin）
POST /knowledge/reviews/{review_task_id}     知识审核决定（admin/reviewer）
GET  /knowledge/graph/{source_record_id}     指定文档版本的图投影
GET  /knowledge/stats                        字段事实和投影覆盖统计
POST /knowledge/outbox/drain                 重放图/检索投影（admin）
```

`GET /knowledge/stats` 同时返回 `inventory`、`claims` 和 `projections`：前者用于核对
来源、文档版本、task/version 绑定、标准实体和全量 outbox；后两者用于核对事实/关系
审核状态以及切片、检索索引和 Graph 快照。统计只返回租户内聚合值，不返回文件名、
文档内容或 ACL 明细。

对已经解析完的历史任务做回填不会产生模型费用：

```bash
curl -X POST http://localhost:8080/knowledge/backfill \
  -H "Content-Type: application/json" \
  -H "X-Tenant-ID: customer-a" \
  -H "X-Actor-ID: migration-job" \
  -H "X-Actor-Roles: admin" \
  -d '{"limit":100,"offset":0,"force":false}'
```

Orchestrator 在原有 12 个 M1 工具之外新增五个只读知识工具：知识检索、实体列表、实体
详情、图查询和统计。租户/调用者身份由可信运行环境注入请求头，不进入模型可见的
query/body Schema；创建租户、回填、审核和 outbox 重放仍只保留为管理 API。

KnowledgeStore 启动时会在 PostgreSQL 上获取 advisory lock，并通过 Alembic 自动升级到
最新 schema；启动只有在表和列完整校验后才会 ready。维护窗口也可显式执行：

```powershell
uv run python -m m1.knowledge.migrations.runner `
  --database-url "postgresql+asyncpg://user:password@host:5432/m1"
```

删除旧 M1 task 会先事务性 tombstone 其 Wiki、检索切片、来源断言和关系，再通过 outbox
以更高 generation 删除或恢复 Neo4j 投影。同一文档/实体仍被其他任务或来源引用时采用
引用计数，不会误删共享知识；旧的并发 Graph writer 也不能复活已删除投影。

任务 2、4、5、6 的逐项交付边界、真实语料统计和复验命令见
[`docs/base-data-delivery.md`](docs/base-data-delivery.md)；机器可读的脱敏验收快照位于
[`docs/evidence/base-data-acceptance-20260717.json`](docs/evidence/base-data-acceptance-20260717.json)。
完成后的模块依赖、事务/权限、真实 Neo4j 和容量检查见
[`docs/architecture-audit-20260717.md`](docs/architecture-audit-20260717.md)。

## 发布前验收

本地先运行固定权威工作流、MinerU 文档解析与表格布局路由测试：

```powershell
uv run --frozen --extra dev --extra ocr --extra knowledge --extra document-parsers `
  pytest -q tests/test_full_authority_workflow.py `
  tests/test_mineru_document_parsing.py tests/test_mineru_tabular_layout.py
```

真实 GPU、模型端点和离线缓存必须通过候选 release 的
`deploy/source-runtime/m1-full-canary.sh` 验收。密钥只放在服务器 root-owned
`deploy.env.next` 中，不写入仓库或测试命令。

当前生产链路固定使用 MinerU + Instructor 作为文档事实权威，不提供
`legacy/shadow/guarded` 权威模式切换。MinerU、文本映射和绘图区域 VLM 任一必需
能力未就绪时，解析失败关闭，不回退到已删除的 Verifier、Tabular Schema
Interpreter、legacy OCR 或订单语义增强链路。

PP-StructureV3、PaddleOCR-VL 和 Docling 继续作为受治理的格式与区域能力，由
独立开关和离线模型清单控制；它们不会取代 MinerU/Instructor 的最终事实权威。
生产使用模块自有的 `deploy/compose.runtime.yml`，不再使用 CPU rollback 或旧
full-GPU overlay。

---

## 常用命令

```bash
docker compose -f docker-compose.yml up -d --build
docker compose -f docker-compose.yml config --quiet
docker compose -f docker-compose.yml logs -f
docker compose -f docker-compose.yml ps
docker compose -f docker-compose.yml down
```

并行验收时使用独立项目名、端口和数据目录，避免碰到已运行的 M1：

```powershell
$env:COMPOSE_PROJECT_NAME="m1-acceptance"
$env:API_PORT="18081"
$env:POSTGRES_PORT="15432"
$env:NEO4J_HTTP_PORT="17474"
$env:NEO4J_BOLT_PORT="17687"
$env:M1_DATA_DIR="./data-acceptance"
docker compose config --quiet
# 确认配置后才执行：docker compose up -d --build
```

---

## 数据存在哪

- M1 本地兼容数据库: `./data/m1.db` (仅 SQLite 模式)
- Wiki/Postgres: Compose 命名卷 `m1-postgres`
- Graph/Neo4j: Compose 命名卷 `m1-neo4j-data`、`m1-neo4j-logs`
- 上传的文件: `./data/uploads/`
- PaddleX OCR 模型缓存: `./data/paddlex/`

`./data` 是宿主机目录，命名卷由 Docker 管理；普通 `docker compose down` 不删除这些数据。
只有明确执行 `docker compose down -v` 才会删除 Wiki/Graph 卷，生产环境不要误用。
Docker 验收可临时设置 `M1_DATA_DIR` 指向独立目录（例如 `./data-test`），避免与正在运行
的 M1 共用 SQLite、上传文件或 OCR 缓存。

---

## PaddleOCR / PaddleX

生产镜像保留 PaddleOCR、PP-StructureV3 和 PaddleOCR-VL 依赖。生产发布前应把
模型清单要求的 `PP-OCRv5_mobile_det/rec` 及结构化解析模型放入持久化缓存并完成
校验。Compose 将 `PADDLE_PDX_CACHE_HOME` 固定为 `/app/data/paddlex`；是否启用
结构化能力分别由 `PP_STRUCTURE_ENABLED` 和 `PADDLEOCR_VL_ENABLED` 控制，不再有
独立的 `OCR_ENABLED` 或启动期 legacy OCR warmup 开关。

本地开发（非 Docker）应从 M1 目录按锁文件安装开发和 OCR 依赖：

```bash
uv sync --frozen --extra dev --extra ocr-gpu --extra knowledge --extra document-parsers
```

运行前必须将模型清单中的 PaddleX 模型放入离线目录，并将
`PADDLE_PDX_CACHE_HOME` 指向该目录；运行时不会下载模型。

---

## 可选: 加鉴权

`.env` 里把 `API_AUTH_KEY=随便填一个` 设上, 重启后除 `/health` 和 `/ready` 外所有接口都要带请求头:

```
X-API-Key: 随便填一个
```

---

## 目录里有什么

```
m1/
├── Dockerfile            # 纯 Python 单阶段镜像
├── docker-compose.yml    # canonical runtime/build/dev 的兼容入口
├── .env                  # 非密钥运行配置
├── .env.example          # 配置模板参考
├── .dockerignore         # 构建时排除项
├── pyproject.toml        # Python 依赖
├── src/                  # Python API 与处理流水线源码
└── samples/
    └── test_cable.pdf    # 开箱即测的样例
```

---

## 常见问题

**Q: 启动后 `/ready` 不通?**
看日志 `docker compose -f docker-compose.yml logs m1 m1-mineru`。检查固定模型目录、
mapper/drawing-VLM endpoint、数据库迁移及 GPU。任何必需权威能力不可用都会失败关闭。

**Q: 上传后任务一直 queued?**
VLM 在调用。看日志确认是不是 API Key 无额度 / 网络不通。

**Q: 想换端口?**
改 `.env` 里 `API_PORT=8080` 为别的, 重启。

**Q: 构建太慢?**
Dockerfile 已配清华 pip 源。也可 `docker build --build-arg PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/ -t m1 .` 换阿里源。
