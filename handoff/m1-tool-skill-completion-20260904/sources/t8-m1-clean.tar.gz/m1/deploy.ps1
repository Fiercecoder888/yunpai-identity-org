$ErrorActionPreference = "Stop"

docker compose config --quiet
docker compose up -d --build
docker compose ps
