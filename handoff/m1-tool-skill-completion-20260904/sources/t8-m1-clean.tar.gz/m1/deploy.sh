#!/usr/bin/env sh
set -eu

docker compose config --quiet
docker compose up -d --build
docker compose ps
