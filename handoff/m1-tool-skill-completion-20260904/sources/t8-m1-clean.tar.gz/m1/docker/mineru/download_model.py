"""Download one immutable MinerU model revision and emit a file manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_expected_sha256(values: list[str]) -> dict[str, str]:
    expected: dict[str, str] = {}
    for value in values:
        name, separator, digest = value.partition("=")
        candidate = Path(name)
        if (
            not separator
            or candidate.is_absolute()
            or ".." in candidate.parts
            or not re.fullmatch(r"[0-9a-f]{64}", digest)
        ):
            raise SystemExit(f"Invalid --expected-sha256 value: {value!r}")
        normalized = candidate.as_posix()
        if normalized in expected:
            raise SystemExit(f"Duplicate expected model file: {normalized}")
        expected[normalized] = digest
    return expected


def main() -> None:
    from huggingface_hub import snapshot_download

    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--expected-sha256", action="append", default=[])
    args = parser.parse_args()

    if not re.fullmatch(r"[0-9a-f]{40}", args.revision):
        raise SystemExit("Model revision must be an immutable 40-character commit")
    expected = parse_expected_sha256(args.expected_sha256)
    if not expected:
        raise SystemExit("At least one pinned model file hash is required")

    args.output.mkdir(parents=True, exist_ok=True)
    if any(args.output.iterdir()):
        raise SystemExit(f"Model output directory is not empty: {args.output}")
    snapshot_download(
        repo_id=args.repository,
        revision=args.revision,
        local_dir=args.output,
        token=False,
    )
    readme = args.output / "README.md"
    if not readme.is_file() or not re.search(
        r"(?im)^\s*license:\s*apache-2\.0\s*$",
        readme.read_text(encoding="utf-8"),
    ):
        raise SystemExit("Pinned MinerU model card is missing apache-2.0 metadata")
    for required_name in ("config.json", "model.safetensors", "tokenizer.json"):
        if not (args.output / required_name).is_file():
            raise SystemExit(f"Pinned model is missing {required_name}")

    files = []
    for path in sorted(args.output.rglob("*")):
        if ".cache" in path.relative_to(args.output).parts:
            continue
        if path.is_symlink():
            raise SystemExit(f"Model snapshot contains a symlink: {path}")
        if not path.is_file():
            continue
        files.append(
            {
                "path": path.relative_to(args.output).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    actual = {item["path"]: item["sha256"] for item in files}
    for name, digest in expected.items():
        if actual.get(name) != digest:
            raise SystemExit(
                f"Pinned model hash mismatch for {name}: "
                f"expected {digest}, got {actual.get(name)}"
            )
    if not files:
        raise SystemExit("Pinned model snapshot is empty")

    files_payload = json.dumps(
        files,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    payload = {
        "schema_version": 1,
        "repository": args.repository,
        "revision": args.revision,
        "files_sha256": hashlib.sha256(files_payload).hexdigest(),
        "files": files,
    }
    args.manifest.write_text(
        json.dumps(payload, ensure_ascii=True, indent=2) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
