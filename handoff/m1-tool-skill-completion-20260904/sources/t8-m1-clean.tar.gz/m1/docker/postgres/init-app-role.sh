#!/usr/bin/env bash
set -Eeuo pipefail

# Run once for a new data volume as the bootstrap administrator. The M1 role
# owns its objects for Alembic, but cannot bypass forced row-level security.
app_user="${M1_POSTGRES_APP_USER:?M1_POSTGRES_APP_USER is required}"
app_password="${M1_POSTGRES_APP_PASSWORD:?M1_POSTGRES_APP_PASSWORD is required}"
app_database="${POSTGRES_DB:?POSTGRES_DB is required}"

role_exists="$(
  psql --username "$POSTGRES_USER" --dbname "$app_database" \
    --set=app_user="$app_user" --tuples-only --no-align <<'SQL' \
    | tr -d '[:space:]'
SELECT 1 FROM pg_roles WHERE rolname = :'app_user';
SQL
)"

if [[ "$role_exists" == "1" ]]; then
  psql --username "$POSTGRES_USER" --dbname "$app_database" \
    --set=app_user="$app_user" --set=app_password="$app_password" <<'SQL'
ALTER ROLE :"app_user" WITH LOGIN PASSWORD :'app_password' NOSUPERUSER NOBYPASSRLS;
SQL
else
  psql --username "$POSTGRES_USER" --dbname "$app_database" \
    --set=app_user="$app_user" --set=app_password="$app_password" <<'SQL'
CREATE ROLE :"app_user" WITH LOGIN PASSWORD :'app_password' NOSUPERUSER NOBYPASSRLS;
SQL
fi

psql --username "$POSTGRES_USER" --dbname "$app_database" \
  --set=app_user="$app_user" --set=app_database="$app_database" <<'SQL'
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS vector;
ALTER DATABASE :"app_database" OWNER TO :"app_user";
ALTER SCHEMA public OWNER TO :"app_user";
GRANT ALL ON SCHEMA public TO :"app_user";
SQL
