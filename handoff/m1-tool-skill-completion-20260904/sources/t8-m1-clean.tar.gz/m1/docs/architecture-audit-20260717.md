# M1 基础资料架构复核（2026-07-17）

## 结论

任务 2、4、5、6 的功能交付、真实语料和兼容门禁仍然成立。架构复核期间发现并修复了
一个真实 Neo4j 删除一致性缺陷和一个包级反向依赖。修复后全套测试、真实 Neo4j 集成、
PostgreSQL/Neo4j 运行态与最终 Docker 镜像均通过。

当前状态可作为基础数据库第一阶段交付，但在接入百万级资料前，检索后端扩容和数据库
RLS 是明确的下一阶段架构项，不能把当前 304 文档验收外推为百万级容量证明。

```mermaid
flowchart LR
    A["文件与归档"] --> B["确定性 DocumentAdapter"]
    B --> C["m1.document.v2"]
    C --> D["TaskStore 与兼容 API"]
    C --> E["KnowledgeRuntime"]
    E --> F["PostgreSQL Wiki / 版本 / 证据 / ACL"]
    F --> G["切片与候选检索"]
    F --> H["事务性 Outbox"]
    H --> I["Neo4j 活动 Graph"]
    J["审核"] --> F
    J --> H
```

## 完成性复核

- 五份外部验收报告的 SHA-256 与脱敏证据清单全部匹配。
- 17 个 M1 Agent 工具与 Orchestrator 镜像声明逐 JSON 字段一致。
- 旧版 17 个 API method/path、React 控制台、旧响应字段、审核、报告、下载及图片/CAD
  VLM 链路由回归门禁保护。
- 304/304 份生产文档具有 `m1.document.v2`、SHA-256、适配器和终态；无解析异常。
- `.env` 被 Git 忽略，M1/Orchestrator 范围未发现硬编码 `sk-*` 密钥。

## 本次发现并修复

### 1. Neo4j 同代 tombstone 未生效

真实 Neo4j 测试复现：source-A/source-B 共用实体时，以相同 generation 删除 source-A，
旧锁条件拒绝 active→tombstoned 转换，导致声明/关系和 `source_record_ids` 可能残留。

修复后的顺序语义与内存 Graph 一致：

- 更高 generation 总是获胜；
- 相同 generation 的 delete 可覆盖 active；
- 相同 generation 的 replace 不可复活 tombstone。

真实 Neo4j 并发替换、共享实体删除和清理测试已通过，且测试租户无残留节点、关系或锁。

### 2. `api ↔ ingest` 包级依赖环

批次层原先在函数内反向导入 API 的 `_task_registry`。它不造成启动错误，但破坏层次边界。
现改为由 API 构造 `BatchOrchestrator` 时注入只读 task registry；批次层始终以持久化子任务
状态为事实源，内存 registry 仅为等待优化。AST 包依赖图复测为 0 个环。

## 数据库与投影架构结果

- PostgreSQL：25 张知识业务表、47 个外键、25 个唯一约束、161 个索引。
- Alembic：代码 head 与真实库均为 `0002_legacy_knowledge_upgrade`。
- Outbox：6,901 条全部 delivered，pending/processing/failed 均为 0。
- Neo4j：3 个唯一约束、5 个 ONLINE 索引；候选资料未进入活动图。
- 活动 task/version 绑定 304；切片 3,110；检索文档 3,110；Graph 快照 304。
- 候选检索 `W-H94` 命中 19，普通活动检索命中 0，候选权限隔离正确。

## 测试结果

- M1：226 passed，8 skipped；整体语句覆盖率 75%。
- Orchestrator：76 passed。
- 架构重点测试：58 passed（权限、版本、tombstone、迁移、并发、归档、批次）。
- 真实 Neo4j 集成：1 passed。
- 批次依赖注入、权限 API 和旧 UI/路由：21 passed。
- Docker：`m1-knowledge-test:20260717-final` ready，PostgreSQL/Neo4j 健康，运行统计与数据库一致。
- 镜像内版本：PaddlePaddle 3.3.1、PaddleOCR 3.7.0、PyMuPDF 1.28.0、OpenPyXL 3.1.5、
  SQLAlchemy 2.0.51。

8 个默认跳过项是显式开关的真实 VLM/OCR/外部 Neo4j 测试；本次真实 Neo4j 已单独执行，
真实 VLM/OCR 结果由已校验哈希的验收报告提供，未重复消耗模型 API。

## 剩余架构风险

### 高优先级：百万级检索后端

当前知识检索从 PostgreSQL 选取最多 5,000 个候选，再在 M1 进程内执行 BM25 风格排序；
vector/graph 分数是可注入接口，尚无生产向量库实现。最终镜像在 3,110 个候选索引上的
10 次热查询为 p50 534.14 ms、p95 630.03 ms、最大 714.75 ms。

这足以支撑当前基础语料，但不应直接承接百万级资料。扩容前应落地 PostgreSQL FTS/pg_trgm
或 OpenSearch，并使用 pgvector/专用向量库生成服务端候选；M1 只负责融合和 ACL 后过滤。

### 中优先级：数据库纵深租户隔离

当前 25 张知识表均通过 `tenant_id`、API key 身份绑定和应用层 ACL 隔离，跨租户测试通过；
真实 PostgreSQL 尚未启用 Row Level Security。生产多租户建议增加 RLS policy 和最小权限
数据库角色，避免应用查询缺陷成为单点隔离失效。

### 中优先级：大模块拆分

`knowledge/persistence.py` 约 4,563 行、`api/main.py` 约 2,223 行。功能边界清晰但物理文件
过大，后续建议按 source/version、entity/claim、projection/outbox、review 和 API router 拆分，
保持公开接口不变。

### 低优先级：覆盖率结构

知识持久化/投影/Schema 和订单解析覆盖率约 81%–99%，但旧 Streamlit UI、复制报告和部分
付费 VLM 路径主要依赖静态资源测试或显式在线验收，使总体覆盖率为 75%。后续可为报告与
旧 UI 边界增加无模型单测；在线模型测试继续保持 opt-in。
