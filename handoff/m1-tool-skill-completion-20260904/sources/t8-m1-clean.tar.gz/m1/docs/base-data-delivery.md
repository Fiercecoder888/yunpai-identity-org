# M1 基础资料任务 2、4、5、6 交付与验收

本文是基于现有 M1 的交付边界和复验入口。生产文件保持在客户本地只读目录；仓库只保存
实现、合成测试和不含文件名/正文的聚合验收快照。所有新增能力都是 M1 的增量能力，原有
上传、任务、审核、报告、下载、React 控制台、图片/PDF/CAD VLM 和置信度链路继续保留。

## 任务 2：数据来源、数据类型和真实样本调研

只读盘点入口为 `python -m m1.onboarding`。它按魔数识别类型、递归审计归档、流式计算
SHA-256、标记重复项，并按文件大小分层稳定选样；不修改源文件，不把正文写入清单，
也不调用 OCR/LLM/VLM。

本轮真实资料盘点结果：

- 8 个物理入口，共 248,644,088 字节；包含 3 个归档入口和 2 个嵌套归档容器。
- 341 条审计记录、330 个归档成员、31 个重复内容、0 个失败、1 个被安全跳过的系统元数据。
- 去重后 304 份入库候选：130 XLSX、6 XLS、152 PDF、16 DOCX。
- 每种有效类型分层选择 3 份，共 12 份真实样本；样本清单只记录相对定位、大小和 SHA-256。
- 304 份文档的业务分布为：269 订单、19 技术文档、9 模具、3 设备、3 采购台账和 1 库存。
- 识别出的主要模板包括供应商采购单、客户采购单、备货单、采购申请/收货/订单台账、
  库存快照、设备台账、模具映射、承认书/规格书和流程文档。

复验命令：

```powershell
uv run --frozen python -m m1.onboarding "C:\客户资料" `
  --json .\data\catalog.json --csv .\data\catalog.csv `
  --sample-per-type 3 --fail-on-errors
```

## 任务 4：清洗、Schema、元数据和权限治理

清洗与事实边界：

- 文件类型以魔数为主；乱码文件名保留原名并另存显示名；文本同时保留原文和 NFKC 值。
- 表格只传播显式合并单元格，隐藏列参与取证但降低主字段优先级，未映射列进入
  `custom_fields/raw_columns`。
- 型号、数量、金额、公式缓存和订单号来自确定性解析；VLM 只能补充名称、类别和属性，
  越权修改事实会被拒绝并生成校验问题。
- 每个字段可携带 Sheet/Page/Cell/Range 证据、置信度、合并继承和推断标记；冲突不会被
  静默覆盖。

统一文档契约为 `m1.document.v2`：`source`、`document_type/subtype`、`header`、`lines`、
`totals`、`field_meta`、`validation_issues` 是事实主结构；原 `extraction`、`scored_result`、
`fields`、`bom` 继续作为兼容字段。

Wiki 使用 PostgreSQL/Alembic 的受治理 Schema，保存来源资产、出现位置、文档与双时态版本、
证据锚点、字段事实、标准实体、外部身份、别名、冲突、审核决定和 outbox。所有业务表按
`tenant_id` 隔离；ACL 支持 private/tenant/restricted/public、owner、读写 principal 和
security labels。候选数据只有 reviewer/admin 显式请求才能看到；生产多租户身份由
`TENANT_API_KEY_HASHES` 把 key 的 SHA-256 绑定到 tenant/actor/roles，客户端头部不能提权。

## 任务 5：结构化入库、知识切片和检索配置

`KnowledgeRuntime` 在 M1 持久化 `m1.document.v2` 后执行幂等投影：

1. Wiki 保存来源、文档版本、事实、实体、别名、关系与审核任务。
2. 文档按 header、line、page/evidence 生成稳定切片，并仅将允许字段写入检索投影。
3. 检索基线为中文/标识符 BM25 风格排序，同时预留 vector score 和 graph context 加权。
4. 逻辑关系先落 SQL Graph staging；只有已审核的活动快照才经 outbox 投影到 Neo4j。
5. 删除 task 采用引用计数和 tombstone；新版本替换旧版本，删除当前版本可恢复最近仍被
   引用的版本，旧 writer 不能复活过期图。
6. `/knowledge/backfill` 支持精确 task ID 差集续跑、有界并发和幂等重试，且不会重新调用
   OCR/LLM/VLM。
7. `/knowledge/reviews/reassess` 可在不重跑模型的前提下重建历史审核标记，修复旧兼容字段
   为空导致的假阳性；默认只预览。`/knowledge/reviews/bulk` 以文档为审核原子，接受文档后
   在同一事务内收敛其字段、实体和关系审核，再由 outbox 更新活动检索与 Graph。

304 份真实文档的干净库回灌结果：304 个活动 task/version 绑定、3,110 个候选切片、
3,110 个候选检索文档、304 个候选图快照、4,225 条候选关系。共 6,901 个投影事件已交付，
无 pending/processing/failed。候选检索可命中 `W-H94` 19 条，活动检索为 0；Neo4j 只有
投影锁节点、无业务节点或关系，证明审核隔离生效。

## 任务 6：真实数据测试、单测和质量验收

验收分四层，避免把单元测试冒充真实语料验收：

- 确定性全量 HTTP 回归：304/304 份终态成功，全部为 `m1.document.v2`，SHA-256 和 adapter
  完整，0 个解析异常；共形成 2,533 条结构化行。
- 真实 SiliconFlow：`Qwen/Qwen3.6-27B` 对 268 份可语义增强文档执行 277 次请求，0 次
  Schema 重试、0 次降级；随后按额度要求只对目标备货单做一次端到端复测，仍为 12 行、
  总数量 7,400、确定性事实未改变。
- 真实 PaddleOCR/Docker：扫描订单识别出 `DP-101/HDMI-202`、数量 `12/8`、合计 20；
  OCR 1 页成功、0 页失败，重启后文档、订单检索和四 Sheet Excel 导出均可恢复。
- 自动化回归：M1 全套测试、Orchestrator M1 工具测试、Compose 配置、PostgreSQL 迁移、
  Neo4j 投影、候选审核、租户隔离、归档攻击和旧能力兼容均作为发布门禁。

在线测试默认跳过，只有显式设置 `M1_RUN_LIVE_TESTS=1` 才会产生费用。OCR 真实测试清空
模型 key 并拦截语义入口。当前验收快照及外部报告 SHA-256 见 `docs/evidence`；外部报告可
被独立校验，但生产文件和正文不进入 Git。

## M1 原能力保留门禁

- 当前 API 路由集合包含旧版全部 17 个 method/path 组合，新增路由不覆盖旧路径。
- `DocumentRecord` 保留旧四组响应字段；图片、DXF、DWG 的成功、低置信审核和 VLM 故障
  降级均有回归测试。
- 原 React 首页和静态 JS/CSS 仍由最后一个 StaticFiles mount 提供，新增 `/knowledge/*`
  路由不会被静态站点截获。
- 原报告、复制报告、下载、批次、审核和任务删除入口仍在；删除同时安全退役知识投影。
- OCR 和语义增强生产默认开启，但每次上传仍可显式关闭语义增强以控制费用。

发布时应运行：

```powershell
uv run --frozen --no-dev --extra dev pytest -q
docker compose config --quiet
```

Orchestrator 在其目录执行 `uv run --frozen pytest -q`。8 个默认跳过项是显式启用的在线模型/
外部 Neo4j 验收，不代表缺失；其对应的真实运行结果记录在脱敏验收快照中。
