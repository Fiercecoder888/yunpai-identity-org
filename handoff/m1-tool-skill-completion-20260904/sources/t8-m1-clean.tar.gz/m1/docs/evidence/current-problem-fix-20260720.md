# M1 当前问题修复验收记录

日期：2026-07-20

分支：`dev_lwz_m1_current_problem_followup_20260720`

## 实现覆盖

- Document Verifier 默认使用 `order_mold_unknown` 范围、PromptedOutput、45 秒总超时、单次校验纠正重试、3 次失败/300 秒熔断，并限制为 20 行和 8000 字符。
- 模型结果仅能生成受证据约束的分类、主体角色、标识符、问题行建议；确定性数值和受保护字段不会被覆盖。
- 知识检索默认 `precise`，默认最低分 0.30，同一来源最多 2 条，并返回 `match_reason`。
- outbox worker 默认启用，每 5 秒最多处理 200 个事件，最多尝试 10 次。新事件不再额外等待 75 秒，确保正常负载下最老 pending 年龄可保持在 60 秒以内。
- LightRAG 的异步删除状态按可重试状态处理，鉴权和契约错误进入终止失败；旁路异常只降级健康状态，不影响权威 PostgreSQL/Neo4j readiness。
- M1 与 Orchestrator 的工具声明均为 17 个工具，名称唯一且文件内容一致。

## 本地验证

| 检查 | 结果 |
| --- | --- |
| M1 全量 pytest（修改前基线） | 416 passed, 9 skipped |
| Verifier/检索/LightRAG/outbox/readiness 定向测试 | 55 passed |
| follow-up 默认值/outbox/LightRAG/readiness 定向测试 | 15 passed |
| Orchestrator 声明和注册器测试 | 15 passed |
| `ruff check src tests` | passed |
| `deploy/source-runtime/compose.yml` 配置解析 | passed |
| `compose.m1-full-gpu.yml` 配置解析 | passed |
| 两份 M1 `tool.json` | 17/17，字节级一致 |

最终全量 pytest 结果以本提交完成前最后一次运行结果为准。

## 未执行项

- 本轮未连接或修改生产服务，未安装 deb，未重启容器，未写入生产任务或知识库。
- 当前开发机没有在本轮启动可用于验收的 Qwen2.5-VL 服务，因此未重新执行真实文件的 95% Verifier 成功率和模型耗时门槛。该项必须在具有本地模型服务的隔离环境中保留原始文件名执行。
- CI 配置未修改；CI 继续只负责打包。
