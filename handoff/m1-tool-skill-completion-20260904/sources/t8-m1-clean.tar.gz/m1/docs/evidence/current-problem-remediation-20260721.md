# M1 current-problem remediation evidence (2026-07-21)

## Scope

- Branch: `dev_lwz_m1_current_problem_remediation_20260721`.
- Base: GitLab `origin/main` at `f0e59e6` after a conflict-free rebase.
- No push, merge request, main merge, production deployment, production access, service restart, or production configuration change was performed.
- `.gitlab-ci.yml` is unchanged; CI remains packaging-only.

## Implemented

- Document Verifier defaults to `order_mold_unknown`; clean equipment and inventory documents do not call the model.
- Classification, party, identifier, and line checks use separate compact PromptedOutput schemas. Each prompt is at most 8,000 characters and each line batch contains at most 20 rows.
- A document has a hard budget of four real model requests, including schema-correction retries, and a 90-second end-to-end deadline including queue wait. Transport timeout remains 45 seconds and is never retried.
- Verifier calls are single-flight. Success/failure metrics and a locked closed/open/half-open circuit breaker operate per document; three consecutive failures open the breaker for 300 seconds.
- Optional Verifier failures add an informational `DOCUMENT_VERIFIER_DEGRADED` issue and preserve deterministic facts. Explicit type/subtype hints remain locked, and model output cannot overwrite deterministic names, models, codes, specifications, quantities, or dates.
- Guarded Verifier application only fills an empty buyer/seller/supplier field from cited coordinate evidence. Existing party roles are immutable, and non-item line verdicts are review suggestions only: they never delete, reorder, rebuild or revalidate deterministic rows.
- Contract/header extraction stops at the next label. An order date cannot become a delivery date without independent delivery evidence. Same-line `VLM_NAME_FACT_CONFLICT` entries collapse into one multi-path issue.
- Precise knowledge search rejects graph-only and low-confidence matches, requires exact identifier boundaries, ranks exact structured identifiers first, and returns at most two hits per source. An unreliable query returns an empty hit list.
- LightRAG delete is an asynchronous lifecycle after the authoritative tombstone. `delete_in_progress` remains pending without consuming the independent ten-attempt ordinary failure budget; authentication and contract errors terminate immediately.
- Background outbox delivery has a durable, normalized tenant registry populated from configured tenants, API-key tenants, historical tasks, and every new task save.
- Every five-second worker tick uses at most 200 leases globally with at most eight concurrent tenant drains. Sparse tenants are processed in fair waves, unused successful quota is reused, and exception/timeout quota is conservatively retained.
- A timed-out tenant keeps its quota across ticks. Retained pressure is anonymous in health output, degrades after 60 seconds, and is cancelled after 310 seconds so all eight slots cannot remain silently occupied forever.
- Synchronous projection fast paths and the worker use the same lease fencing and durable retry policy. PostgreSQL and Neo4j remain authoritative; LightRAG can only degrade readiness.
- Relationship notifications now treat a missing graph snapshot as a bounded materialization wait only while the same governed version is still pre-projection and no versioned graph event exists. `relationship.claimed` and `relationship.accepted` share this rule; a completed graph event without its atomic snapshot remains a terminal integrity failure.
- Graph delivery rereads the snapshot after the materialization-state query, closing the commit-boundary TOCTOU. Graph materialization waits terminate after 120 seconds, while the existing generic/LightRAG lifecycle deadline remains 1,800 seconds; both values are reported by health endpoints.
- Tombstone retires pending or leased relationship events for every exact relationship ID belonging to the deleted source/version. Superseded historical events are included, unrelated versions are left untouched, and graph generation fencing prevents an in-flight stale replacement from resurrecting the deleted projection.
- A durable task lifecycle epoch fences every source-derived write. Tombstone, sync, review, graph generation, document versions, source bindings and projections use one lock order; a retired/rejected content-addressed version cannot be rebound by another task.
- Entity, identity and alias creation plus source binding are atomic. Review decisions bind to the exact review task, preserve safe replay after migration, and fail closed for cross-task or ambiguous idempotency reuse.
- LightRAG events are FIFO per tenant/source across processes. PostgreSQL advisory locks permit one owner, the lease is capped at 120 seconds, and a crashed upsert is recovered before a queued authoritative delete.
- `/health` and `/ready` expose Verifier metrics, aggregate projection backlog/age/terminal failures, retained worker pressure, and LightRAG sync/delete timestamps. Authoritative health has a five-second deadline, probes at most eight tenants per round with cursor rotation, and repeated timed-out Neo4j probes reuse one in-flight task.
- `scripts/verify_knowledge_lifecycle.py` performs a local-safe black-box ingest/search/Neo4j/delete proof. Remote mutation requires two explicit acknowledgements and reports never contain credentials.

## Automated verification

- M1 pytest with the disposable PostgreSQL application-role database enabled: `574 passed, 9 skipped`.
- Orchestrator excluding the unrelated M5 declaration drift: `77 passed, 1 deselected`. The full latest-main run is `77 passed, 1 failed`; the failure is the pre-existing M5 module/orchestrator manifest mismatch and this branch has no M5 diff.
- Focused outbox/review/task-fence/LightRAG/migration regression: `59 passed, 3 skipped`; skipped cases were separately exercised against PostgreSQL.
- PostgreSQL RLS, LightRAG dual-engine leasing, shared-version double tombstone, same-document double approve, and retired-version replay integration: `18 passed` in the combined PostgreSQL run.
- Ruff: all M1 and Orchestrator source/tests passed.
- M1 and Orchestrator manifests: byte-identical, semantic-identical, 17 unique tools.
- The new platform plus M1 runtime Compose, and M1 runtime plus build plus dev Compose, passed `docker compose config --quiet` with non-pullable placeholder images and credentials.
- This branch does not change `m1/Dockerfile`, `m1/pyproject.toml` or `m1/uv.lock`; M1 source is mounted from the Deb release. The server-66 runtime fingerprint should therefore reuse the GPU/OpenCV image already accepted on the `f0e59e6` main baseline, rather than build a branch-specific image.
- A local GPU dependency build started before the final rebase was intentionally terminated after `origin/main` added the single-OpenCV-provider fix. That obsolete image is not acceptance evidence. Final dependency identity, GPU assignment and real-model inference remain production-host canary gates.
- `git diff --check` passed.

## Local PostgreSQL, Neo4j and LightRAG lifecycle proof

The generated one-line inventory fixture was visible through precise PostgreSQL search, direct read-only Neo4j query, and LightRAG query before deletion. The authoritative graph contained five nodes and three edges; five Neo4j nodes were found and three contained the opaque marker.

- Visibility: `5.843s`.
- Tombstone convergence: `60.765s` (within the hard 120-second gate).
- Total: `66.765s`.
- Final PostgreSQL search, authoritative graph, direct Neo4j, and LightRAG state: absent.
- Final outbox: `pending=0`, oldest age `0.0s`, `terminal_failures=0`, complete fresh health snapshot.

The previously observed terminal relationship event was reproduced and traced by timestamps: the relationship event committed about 12 ms before its versioned graph snapshot/event transaction. The zero-freshness worker leased it in that interval. This was a graph materialization ordering race, not a failed tombstone delete.

## Real-file deterministic regression

All uploads preserved the original filenames.

| File | Classification | Lines | Notes |
| --- | --- | ---: | --- |
| 广西桐曦一楼押出生产设备 一览表.xls | equipment/equipment_register | 15 | No validation issue; Verifier skipped |
| 广西桐曦二楼生产设备一览表.xls | equipment/equipment_register | 17 | No validation issue; Verifier skipped |
| 库存.xls | inventory/inventory_snapshot | 416 | No validation issue; Verifier skipped |
| 模号-外模类型明细.xlsx | mold/mold_mapping | 37 | Preserved `MOLD_IDENTIFIER_CONFLICT` and `MOLD_IDENTIFIER_AMBIGUOUS` |
| 测试设备一览表.xls | equipment/equipment_register | 19 | No validation issue; Verifier skipped |
| 白宝机器模具设备一览表.xlsx | equipment/equipment_register | 25 | No validation issue; Verifier skipped |
| DP桐曦备货单TX2607150002.xlsx | order/stocking_order | 12 | Order `TX2607150002`; the source physically contains 12 non-empty material rows and has no independent delivery date |
| test_cable.pdf | technical_document/approval_drawing | 10 | Preserved `DRAWING_BOM_DESCRIPTION_MISSING` review issue |
| 采购函.pdf | order/purchase_contract | 0 deterministic-only | Native PDF text has no table rows; live OCR/VLM was not available in this local environment |

The eight archived production-contract samples that previously copied signing dates into `contract_number` were rechecked: 8/8 now return a null contract number while preserving the signing date.

## External gates and residual risk

- The required >=95% live Verifier structured-output rate still needs a non-production Qwen2.5-VL endpoint and a fresh corpus run. It has not been inferred from mocks.
- The local Docker host has one RTX 4070 Ti SUPER with 16 GiB VRAM, below the 20 GiB parser acceptance threshold. It can prove CUDA/Paddle initialization but cannot replace the required model-bundle canary on a qualifying GPU host.
- Authenticated model API connectivity and `/enhanced/preflight?require_all=true` were not run because this local environment has neither the approved offline model bundle nor an M1 VLM credential. No production credential or endpoint was accessed.
- Production backlog age, terminal failure count, and ten-minute observation require an authorized deployment and are intentionally not claimed here.
- An upgrade cannot discover a historical tenant whose task was already deleted before the registry existed. Such tenants must be listed in `KNOWLEDGE_OUTBOX_TENANT_IDS` before first start.
- Governed task reactivation and review corrections remain intentionally rejected until a complete versioned restoration/revision workflow exists; the implementation does not perform partial recovery.
- A synchronous call already executing inside Python `to_thread` cannot be force-killed. Single-flight limits this to one Neo4j health probe; deployment should retain explicit Neo4j driver/network timeouts.
- Previously observed nested-archive isolation, PP-Structure shadow row duplication, and concurrent PostgreSQL ingest conflicts remain separate follow-up work.
- Latest `origin/main` currently has an unrelated M5 `tool.json` drift that makes one Orchestrator declaration-sync test fail. It must be fixed by the M5 owner; this M1 branch does not modify M5.
