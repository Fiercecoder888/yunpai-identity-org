# M1 历史知识回灌

`POST /knowledge/backfill` 只重放已持久化的 `m1.document.v2`，不会调用 OCR、LLM 或 VLM。

```json
{
  "limit": 1000,
  "offset": 0,
  "force": false,
  "task_ids": [],
  "max_concurrent": 2,
  "retry_attempts": 3
}
```

- `force=false`：跳过当前 M1 任务中已标记为 `knowledge_sync_status=synced` 的记录。
- `task_ids`：按精确任务 ID 续跑差集；最多 1000 个。它适合中断恢复，避免重放整个历史库。
- `max_concurrent`：文档级并发，范围 1–16，默认 1。PostgreSQL 生产回灌建议从 2 开始压测。
- `retry_attempts`：单文档幂等重试次数，范围 1–5，默认 3。

请求需要 `admin` 或 `reviewer` 角色。候选文档只进入 Wiki、搜索候选区和 SQL Graph staging；审核通过前不会投影到活动 Neo4j 图。

回灌后应反复调用 `POST /knowledge/outbox/drain`，直到返回 `leased=0`。发布验收要求 `retried=0`、`terminal_failures=0`，并用 `GET /knowledge/stats` 核对 task/version 绑定、切片、索引和 Graph 快照。
