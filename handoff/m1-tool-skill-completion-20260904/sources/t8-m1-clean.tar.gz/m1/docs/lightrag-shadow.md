# LightRAG shadow index POC

LightRAG is an optional, non-authoritative comparison index. It is disabled by
default, has no public M1 route, and never replaces M1 PostgreSQL, governed
Neo4j, lifecycle, audit, tombstone, or outbox behavior. LightRAG is accessed
through `httpx`; the `lightrag-hku` Python package is not an M1 dependency.

## Fixed runtime and REST contract

The optional Compose overlay pins the official server image to:

```text
ghcr.io/hkuds/lightrag:v1.4.16
sha256:67ccf8d9f74eb29da872bf8b3e6513605f5ac601fb0509c5b0ca16d98d2d307d
```

The multi-architecture digest was checked with:

```bash
docker buildx imagetools inspect ghcr.io/hkuds/lightrag:v1.4.16
```

The adapter uses the v1.4.16 official API contract:

- `POST /documents/text` with `text` and an opaque hashed `file_source`.
- `POST /documents/paginated` to resolve the LightRAG document IDs belonging
  to one M1 source hash.
- `DELETE /documents/delete_document` with `doc_ids`,
  `delete_file=false`, and `delete_llm_cache=false`.
- `POST /query` with `only_need_context=true` for offline comparison.

It accepts both v1.4.16's `200 / status=duplicated` replay response and newer
servers' HTTP 409 replay response. No real source filename or host path is sent
as `file_source`. Physical file deletion is always disabled. Deletion is
asynchronous in LightRAG, so the M1 outbox event remains retryable until the
document disappears from `/documents/paginated`.

## Offline BAAI/bge-m3 cache

The embedding sidecar is also disabled with the overlay. It pins the Ada/4090
TEI image and mounts a local model snapshot read-only:

```text
BAAI/bge-m3 revision 5617a9f61b028005a4858fdac845db406aefb181
ghcr.io/huggingface/text-embeddings-inference:89-1.9.3
sha256:e47e625ced2385d3dbfdee79ba0380204578e0b27ef1a926783f9b3486aaf109
```

The exact files, sizes, SHA-256 values and MIT license are recorded in
`models/lightrag-shadow.lock.json`. Provision this snapshot while network
access is explicitly allowed, then verify it before starting the profile:

```bash
huggingface-cli download BAAI/bge-m3 \
  --revision 5617a9f61b028005a4858fdac845db406aefb181 \
  --local-dir /data/models/BAAI-bge-m3
python scripts/verify_lightrag_model.py --root /data/models/BAAI-bge-m3
export LIGHTRAG_BGE_M3_MODEL_DIR=/data/models/BAAI-bge-m3
```

The required Compose variable has no default. The TEI service receives the
local directory as `/models/bge-m3:ro`, uses that path as its model ID, and
sets `HF_HUB_OFFLINE=1` and `TRANSFORMERS_OFFLINE=1`; it cannot download a
model at runtime. GPU device 1 is the default and can be changed with
`LIGHTRAG_EMBEDDING_GPU_ID`.

## Starting the isolated profile

Set local-only credentials and the compatible LLM address, then explicitly
include the overlay and profile:

```bash
docker compose -f docker-compose.yml \
  -f docker-compose.lightrag-shadow.yml \
  --profile lightrag-shadow up -d
```

This creates separate LightRAG PostgreSQL and Neo4j services and volumes. It
does not write M1's authoritative tables, graph nodes, or volumes. Do not add
this overlay to the production package until a separate deployment approval.

## Offline comparison report

Copy `benchmarks/lightrag-cases.example.json`, supply governed source record
IDs, and run:

```bash
python -m m1.benchmarks.lightrag_shadow \
  --cases benchmarks/lightrag-cases.private.json \
  --output benchmarks/results/lightrag-comparison.json \
  --m1-api-key "$M1_API_KEY" \
  --lightrag-api-key "$LIGHTRAG_API_KEY" \
  --top-k 5 \
  --lifecycle-probe
```

The command writes JSON and HTML. Per query it reports authoritative and
LightRAG Recall@5, citation correctness, and latency. The lifecycle probe uses
one synthetic opaque document to measure duplicate-write idempotency, confirms
that the probe was retrievable, deletes it, and verifies both document-status
and query-level deletion consistency. It does not modify M1's authoritative
store.

Promotion remains forbidden until the corpus gates pass and every tombstoned
probe/document is absent from both status and retrieval results.
