# M1 模块瘦身与解析能力升级阶段报告

日期：2026-07-19

验收代码：`abca41d805a8`

实施分支：`dev_lwz_m1_20260717`

结论：新解析架构、PydanticAI 结构化调用、模块拆分和 LightRAG 隔离旁路已经在本地落地并通过兼容性回归；当前不具备删除 legacy 解析器或切换生产默认值的条件。阻断项是缺少 20 份脱敏人工标注真值、相对旧解析器的 p95 性能未达到 1.5 倍门槛，以及生产源码净行数尚未减少。

## 1. 目标与完成范围

本阶段按以下链路改造 M1：

`PP-StructureV3 / PaddleOCR-VL → PydanticAI → 现有业务校验 → PostgreSQL / Neo4j`

已完成：

- 保留 `DocumentRecord`、业务分类、字段校验、坐标证据、人工审核、tombstone、outbox 和权威知识治理。
- 新增统一 `DocumentEvidence`，实现 PP-StructureV3、PaddleOCR-VL 和 Docling 后端以及 `legacy / shadow / structured` 三种模式。
- XLSX/XLS/CSV 继续使用确定性解析；PDF/图片使用 PP-StructureV3；DOCX/PPTX/HTML 使用可选 Docling。
- PaddleOCR-VL 仅补充低置信度或缺失页级证据，不覆盖确定性事实和显式 subtype 提示；没有渲染页时禁止把整份 PDF 交给 VLM。
- 使用 PydanticAI `PromptedOutput`、Pydantic 模型、二进制图片输入和两次校验重试收拢订单语义与通用 VLM 调用。
- API、工作流、知识持久化、PDF、订单、语义增强、归档和批处理入口完成职责拆分。
- LightRAG 以禁用默认值的 Compose profile 独立运行，使用隔离 PostgreSQL、Neo4j、TEI/BGE-M3；不写 M1 权威表和权威图。
- 17 个 Orchestrator 工具、HTTP 路由和 `m1.document.v2` 契约保持兼容。

未执行：推送分支、创建 MR、合并 main、连接或部署生产。

## 2. 技术栈

- API/模型：FastAPI、Pydantic v2、PydanticAI、OpenAI 兼容 vLLM。
- 文档解析：PaddleOCR 3.7.0、PaddleX 3.7.2、PP-StructureV3、PaddleOCR-VL 1.6、Docling 2.113.0。
- 存储：PostgreSQL/pgvector、Neo4j；SQLite 任务库兼容保留。
- 旁路检索：LightRAG 1.4.16、BAAI/bge-m3、Text Embeddings Inference 1.9.3。
- 工程验证：pytest、ruff、Docker、Docker Compose。

Docling 只在 `document-parsers` optional extra 中；LightRAG 通过 HTTP 访问，不是 M1 Python 依赖。该阶段报告形成时，默认 Compose 使用 `DOCUMENT_PARSER_MODE=legacy` 并关闭模型增强；随后按 2026-07-19 的启用决策，OCR、VLM 语义增强和 shadow LLM 复核改为默认开启。PP-StructureV3、PaddleOCR-VL、Docling 和 LightRAG 仍保持显式启用。

## 3. 真实输入、处理与输出

私有本地语料共 148 份：122 份 PDF、16 份 DOCX、3 份 XLS、7 份 XLSX。20 份开发对比集由 10 份 PDF、5 份 DOCX、3 份 XLS、2 份 XLSX 组成。原文件、逐文档结果和模型缓存均由 Git ignore 排除，Git 跟踪数量为 0。

对比流程：

1. 旧解析器生成代理基线。
2. 10 份 PDF 在离线 GPU 容器中运行 PP-StructureV3。
3. 5 份 DOCX 在离线 Docling optional extra 中运行。
4. 5 份表格继续使用确定性解析。
5. 候选结果进入现有业务构建和验证，统一生成 `DocumentRecord`。
6. 比较分类、关键头字段、表格行数、非空明细字段、坐标证据和耗时。

聚合输出：

| 指标 | 结果 | 状态 |
|---|---:|---|
| 成功解析 | 20/20 | 通过 |
| 文档分类与旧代理一致 | 20/20 | 通过 |
| 关键头字段与旧代理一致 | 73/73 | 通过 |
| 表格行数一致 | 20/20 | 通过 |
| 非空明细字段与旧代理一致 | 10,783/10,815，99.704% | 通过代理门槛 |
| 关键字段有效坐标证据 | 10,887/10,887，100% | 通过 |
| 候选 p95 | 20.916 秒 | 低于 180 秒 |
| 最大单文档耗时 | 34.271 秒 | 低于 180 秒 |
| 相对旧代理 p95 | 66.699 倍 | 未通过 1.5 倍门槛 |

这些一致率只表示相对旧结果，不能替代人工标注准确率。当前 20 份语料状态为 `unreviewed`，不得据此删除 legacy 实现。

冷启动不是性能差距的唯一来源。每类排除最慢的首次加载样本后，PDF p95 为 1.262 秒，旧解析器为 0.134 秒，约 9.4 倍；Docling p95 为 0.145 秒，旧解析器为 0.043 秒，约 3.4 倍；确定性表格为 0.357 秒，旧解析器为 0.342 秒，约 1.04 倍。因此启动预热只能消除 20.9 秒和 34.3 秒的冷加载，不能单独满足 1.5 倍门槛。原生 PDF 快速路径必须先用人工真值证明不会牺牲准确率。

## 4. GPU、模型与旁路实测

| 项目 | 实测结果 |
|---|---|
| PP-StructureV3 单页离线 GPU | 20.815 秒；Paddle CUDA 可用；峰值分配 2,359,510,272 字节 |
| 10 份 PDF 连续 GPU | p95 20.916 秒；峰值分配 2,869,638,400 字节 |
| PaddleOCR-VL 合成页 | 冷加载 19.654 秒；推理 1.248 秒；峰值 6,363,503,616 字节 |
| PaddleOCR-VL 实际渲染页 | 33.192 秒；33/33 坐标证据；峰值 6,363,503,616 字节 |
| 解析模型缓存 | 96 个制品逐文件大小和 SHA-256 通过；两个流水线 complete |
| BGE-M3 缓存 | 固定 revision 的 6 个文件逐文件大小和 SHA-256 通过 |
| TEI sidecar | 固定摘要镜像健康；1024 维；全有限值；L2=1.0；单请求 536.702 ms |
| LightRAG 生命周期 | 重复写入保持 1 个文档；可检索；删除后状态和查询均不可见；28.281 秒 |

LightRAG 实测同时发现并修复两项问题：v1.4.16 必须使用 `LIGHTRAG_*_STORAGE` 环境变量；官方镜像不含 `curl`，健康检查改为 Python 标准库。生命周期探针增加查询索引最终一致性的有界轮询。测试结束后隔离 workspace 文档数为 0，全部旁路容器已停止，卷保留。

仓库内 `document-parsers.lock.json` 描述依赖与“仓库不携带可移植模型二进制”的事实；`document-parser-artifacts.lock.json` 描述本机外置缓存的 96 个已验证制品。二者用途不同，运行时 readiness 仍要求外置缓存清单完整。

## 5. 模块拆分与代码量

以下数据以 PydanticAI 迁移完成后的 `3b1dcb8` 为入口拆分基线：

| 入口模块 | 拆分前 | 当前 |
|---|---:|---:|
| API | 1,995 | 782 |
| 工作流 | 1,547 | 108 |
| 知识持久化 facade | 4,186 | 145 |
| PDF adapter facade | 1,817 | 593 |
| 订单构建 | 1,489 | 977 |
| 订单语义 | 1,351 | 772 |
| 归档 adapter | 1,236 | 987 |
| 批处理 | 1,117 | 795 |

当前 `m1/src/m1` 有 132 个 Python 文件，最大文件 987 行，没有生产 Python 文件超过 1,000 行。

但以采购合同 hotfix 提交 `af44eab` 为计划基线，生产 Python 代码由 32,407 行增至 39,302 行，净增 6,895 行。新增行来自统一证据层、三类解析后端、PydanticAI、旁路 adapter、benchmark、兼容 facade 和测试支撑；旧 OCR/布局实现尚未删除。因此只能判定“模块职责已瘦身”，不能判定“源码总量已减少 1,000 行”。

## 6. 测试与兼容性

- M1：`298 passed, 9 skipped`；唯一 warning 为本机未安装 ccache，不影响结果。
- Orchestrator：`56 passed`。
- ruff lint：通过。
- `git diff --check`：通过。
- 基础、GPU parser 和 LightRAG 三套 Compose：`config --quiet` 通过。
- 最终 GPU 镜像：4,864,300,514 字节；离线 `/health=ok`、`/ready=ready`；包含 VLM 页级保护。
- 两份 M1 工具声明逐字节一致；M1 17 个工具；全局 77 个工具名唯一；`base_url=http://m1:8080`；两个上传工具 `timeout_s=240`。

回归覆盖四类已知真实缺陷：空标签不能成为合同号/日期、显式 `purchase_contract` 提示优先、甲乙方角色不互相污染、带角色前缀的同一企业合并为一个实体并合并角色。

## 7. 门禁结论

| 门禁 | 结果 |
|---|---|
| 新架构、影子模式和兼容 facade | 通过 |
| 生产单文件不超过 1,000 行 | 通过 |
| 20 份私有样本执行完成 | 通过 |
| 分类、关键字段、行数、坐标证据相对旧代理 | 通过 |
| 绝对 p95 不超过 180 秒 | 通过 |
| GPU 显存不超过 20 GiB | 通过 |
| LightRAG 幂等、检索和删除一致性 | 通过 |
| 20 份脱敏人工标注 golden corpus | 未提供 |
| p95 不超过旧实现 1.5 倍 | 未通过 |
| 删除至少 1,000 行旧 OCR/布局/JSON 修复代码 | 未执行，受前两项门禁阻断 |

下一步应先补齐 20 份脱敏人工标注，并明确标注文档类型、显式 subtype、合同/订单号、日期、甲乙方和每个关键单元格；随后针对原生 PDF 的性能差距设计可证明不降低准确率的快速路径。只有人工准确率、证据、性能和显存门禁全部通过后，才允许把默认模式切到 `structured`，并以独立提交删除 legacy OCR/布局代码。当前禁止推送、合并或部署生产。
