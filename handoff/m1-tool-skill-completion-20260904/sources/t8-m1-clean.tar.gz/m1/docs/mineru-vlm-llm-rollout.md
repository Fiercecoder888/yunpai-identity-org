# MinerU + Instructor Full-Authority Runtime

Status: full-authority application contract implemented; full regression and
real GPU canary are required before production activation.

## Decision

M1 has one document-fact authority:

```text
uploaded document
  -> lossless format normalization
  -> MinerU 3.4.4 evidence
  -> Instructor domain extraction
  -> citation and table replay validation
  -> DocumentRecord
  -> PostgreSQL / Neo4j
```

The runtime no longer exposes `MINERU_AUTHORITY_MODE`. Shadow and guarded
authority selection, Document Verifier, the old Tabular Schema Interpreter,
legacy OCR verification, and order semantic enrichment are not fallback paths.
The historical `mineru_shadow_*` names remain only where changing persisted
artifact/state keys would break compatibility; they do not make authority
selectable.

## Runtime Contract

- `m1-mineru` is a required internal service in
  `m1/deploy/compose.runtime.yml`; it has no public port.
- MinerU and the M1 parser use the host-selected parser GPU through
  `M1_PARSER_GPU_ID`.
- The sidecar image is supplied by the release catalog through
  `M1_MINERU_IMAGE`; server 190 never builds it or downloads models.
- MinerU version, model revision, protocol, concurrency, timeouts and offline
  model mounts are fixed by the module runtime contract.
- Instructor text mapping uses the dedicated `M1_MINERU_MAPPER_*` endpoint
  contract. The server-190/test-host example targets the shared
  `qwen3.6-35b-a3b-fp8-gpu0-200k` service at
  `http://host.docker.internal:18085/v1` with a 60-second request timeout.
- Drawing-region image analysis uses the independent
  `M1_MINERU_DRAWING_REGION_VLM_*` endpoint contract and remains on
  `Qwen/Qwen2.5-VL-7B-Instruct` at
  `http://host.docker.internal:18086/v1`; region requests use 30 seconds and
  the complete asset budget is 180 seconds.
- The general image extractor's `VLM_*` contract uses that same 7B endpoint;
  its timeout is declared independently as `VLM_TIMEOUT_SECONDS=300`. It does
  not inherit the drawing-region credential and is never used for text-only
  MinerU mapping.
- Do not point the text Mapper back at the drawing-region VLM merely because
  both expose an OpenAI-compatible API; their model capabilities and GPU
  ownership are intentionally separate.
- Real credentials remain only in server 190's root-owned `deploy.env`.

The production Compose assembly is the platform fragment plus the module-owned
runtime fragment. The removed CPU rollback and legacy full-GPU overlays are not
valid deployment alternatives. Rollback means switching to a previously
verified immutable release, not activating a second parser implementation.

## Evidence Contract

The adapter consumes MinerU's ZIP-only `content_list_v2` contract plus
`middle_json`. It rejects an unexpected MinerU version or protocol.

Coordinates are normalized from MinerU's `0..1000` space to `0..1`, while page
dimensions and rotation remain attached to source evidence. A table-level box
is never represented as an invented cell box. Every accepted critical field
must cite an existing block, table, cell or visual region.

Instructor selects canonical domains, fields and table axes. M1 then copies
values from cited evidence and deterministically replays every source row. The
model does not generate an arbitrary number of business records from memory.
Explicit upload hints remain authoritative, and validation issues continue to
drive human review.

## Format Routing

- PDF and images use MinerU evidence directly.
- DOCX and PPTX use lossless normalization before MinerU.
- XLSX preserves native cells, formulas and images while MinerU/Instructor
  resolves layout semantics.
- CSV, legacy XLS and HTML use controlled normalization without restoring the
  deleted Tabular Schema Interpreter.
- Archives and CAD retain their existing secure entry points, then route the
  extracted document through the same authority.
- PP-StructureV3, PaddleOCR-VL and Docling remain governed regional or format
  capabilities. They may add evidence but cannot replace the final authority.
- Tabular Layout Router remains available and attaches governed layout profiles
  to MinerU Instructor.

## Failure Behavior

- MinerU `202` is polled without uploading the file again.
- A lost task/result may be resubmitted only within the bounded retry contract.
- Invalid input is a task-local failure with stable validation evidence.
- Sidecar, Instructor, timeout, version, protocol or citation failures fail the
  authoritative parse closed. M1 does not return facts from a deleted legacy
  pipeline.
- Private artifacts stay mode `0600`, remain bounded by retention and size
  limits, and are removed by the normal lifecycle.
- `/health`, `/ready` and authenticated enhanced preflight report the required
  MinerU/Instructor capabilities and must not describe a missing authority as
  merely optional degradation.

## Release Gates

Before activation, run all of the following against the exact candidate:

1. Full M1 pytest and Ruff.
2. MinerU full-authority, format matrix, citation and tabular-layout tests.
3. Module runtime/build/dev Compose rendering and source-runtime assembly.
4. Offline image dependency smoke, including the selected OpenCV provider,
   PaddleOCR, Docling and Instructor imports.
5. Authenticated mapper, drawing-region VLM and router endpoint probes.
6. Real MinerU inference on the assigned GPU with the verified offline model
   bundle.
7. `/ready` and enhanced preflight, including PostgreSQL, Neo4j, embedding and
   LightRAG lifecycle checks.

Compose rendering or a green CPU build alone is not production acceptance.

## License Boundary

The sidecar uses MinerU VLM-only and the pinned MinerU2.5-Pro weights. It does
not enable pipeline or hybrid backends. Keep `THIRD_PARTY_NOTICES.txt`, model
license evidence and the legal review required for external online service use.
