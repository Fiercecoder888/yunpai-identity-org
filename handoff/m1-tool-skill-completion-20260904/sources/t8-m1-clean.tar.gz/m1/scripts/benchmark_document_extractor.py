"""Read-only 20-sample benchmark for external document extractors.

It discovers local production files plus named M1 regression samples, runs an
optional candidate CLI once per file, and writes a privacy-preserving JSON
report. Candidate templates receive ``{input}``, ``{output}``, ``{case_id}``,
and ``{original_filename}``; output can be an m1.document.v2 record directly
or an object containing ``record``/``document``.

Gold is optional. Legacy labels use ``expected.fields`` and table specs.
Provisional semantic gold additionally supports intent/subtype, record counts,
key/header fields, expected rows, field names, process sequences, and contract
clause counts. ``--strict-gold`` fails closed when that gold cannot be loaded,
SHA-matched, scored, fully consumed, or matched in full by every completed
candidate. The report never includes raw candidate values or absolute input
paths.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shlex
import subprocess
import sys  # noqa: F401 - CLI tests monkeypatch this module-level namespace.
import tempfile
import time
import unicodedata
from collections import Counter, defaultdict, deque
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
M1_DIR = SCRIPT_DIR.parent
USER_HOME = Path.home()
DEFAULT_PRODUCTION = USER_HOME / "Downloads" / "\u751f\u4ea7\u6570\u636e"
DEFAULT_EXPANDED = M1_DIR / "benchmarks" / "private" / "production-expanded-20260719"
DEFAULT_SAMPLES = (
    M1_DIR / "samples" / "test_cable.pdf",
    USER_HOME / "Desktop" / "M1-TestData" / "input" / "\u91c7\u8d2d\u51fd.pdf",
    USER_HOME / "Downloads" / "DP\u6850\u66e6\u5907\u8d27\u5355TX2607150002.xlsx",
)
DEFAULT_REPORT = M1_DIR / "benchmarks" / "private" / "extractor-benchmark.json"
SUPPORTED = frozenset(
    {
        ".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".xls", ".csv", ".tsv",
        ".html", ".htm", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp",
    }
)
SKIP_PARTS = frozenset(
    {"__macosx", ".git", ".m1_assets", ".pytest_cache", "__pycache__"}
)
LINE_SKIP = frozenset(
    {
        "line_id", "image_refs", "name_normalized", "full_product_name",
        "product_category", "name_attributes", "custom_fields", "raw_columns",
    }
)
TOKEN = re.compile(
    r"\.([A-Za-z_][A-Za-z0-9_-]*)|\[(\d+)\]|\[\"([^\"]+)\"\]"
)


@dataclass(frozen=True, slots=True)
class Case:
    id: str
    path: Path
    sha256: str
    category: str
    source_kind: str
    size_bytes: int


@dataclass(frozen=True, slots=True)
class CandidateOutput:
    """Candidate record plus private, in-memory scoring context."""

    record: dict[str, Any]
    payload: dict[str, Any]


@dataclass(frozen=True, slots=True)
class _SemanticOccurrence:
    name: str
    value: Any
    path: str
    scope: str
    source_refs: tuple[dict[str, Any], ...] = ()


_PROVISIONAL_SCORING_KEYS = frozenset(
    {
        "intent_family",
        "document_subtype",
        "record_count",
        "key_values",
        "header_fields",
        "detail_columns",
        "field_names",
        "records",
        "line_items",
        "process_sequence",
        "purchase_contract_clause_count",
    }
)
_DESCRIPTIVE_GOLD_KEYS = frozenset({"record_count_semantics"})
_LEGACY_GOLD_KEYS = frozenset(
    {"fields", "tables", "parameter_tables", "continuations"}
)


def _present(value: Any) -> bool:
    return value not in (None, "", [], {})


def _norm(value: Any) -> Any:
    if isinstance(value, bool) or value is None:
        return value
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        try:
            parsed = Decimal(str(value))
            if parsed.is_finite():
                return parsed.normalize()
        except (InvalidOperation, ValueError):
            pass
    return "".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def _equal(expected: Any, actual: Any) -> bool:
    if isinstance(expected, dict) and set(expected) <= {"value", "present"}:
        if expected.get("present") is False:
            return not _present(actual)
        expected = expected.get("value", {"present": True})
        if expected == {"present": True}:
            return _present(actual)
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(
            key in actual and _equal(value, actual[key]) for key, value in expected.items()
        )
    if isinstance(expected, list):
        return isinstance(actual, list) and len(expected) == len(actual) and all(
            _equal(left, right) for left, right in zip(expected, actual)
        )
    numeric_expected = isinstance(expected, (int, float, Decimal)) and not isinstance(
        expected,
        bool,
    )
    numeric_actual = isinstance(actual, (int, float, Decimal)) and not isinstance(
        actual,
        bool,
    )
    if numeric_expected or numeric_actual:
        try:
            left = Decimal(str(expected).replace(",", "").strip())
            right = Decimal(str(actual).replace(",", "").strip())
            return left.is_finite() and right.is_finite() and left == right
        except (InvalidOperation, ValueError):
            return False
    return _norm(expected) == _norm(actual)


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _content_digest(value: str | bytes | None) -> str:
    if isinstance(value, str):
        value = value.encode("utf-8", errors="replace")
    return hashlib.sha256(value or b"").hexdigest()


def _quote(value: str) -> str:
    return subprocess.list2cmdline([value]) if os.name == "nt" else shlex.quote(value)


def _category(path: Path) -> str:
    suffix = path.suffix.casefold()
    if suffix == ".pdf":
        return "pdf"
    if suffix in {".xlsx", ".xlsm", ".xls", ".csv", ".tsv"}:
        return "spreadsheet"
    if suffix in {".docx", ".pptx"}:
        return "office"
    if suffix in {".html", ".htm"}:
        return "html"
    return "image"


def _files(root: Path) -> Iterator[Path]:
    if root.is_file():
        if root.suffix.casefold() in SUPPORTED:
            yield root
        return
    if not root.is_dir():
        return
    try:
        candidates = sorted(root.rglob("*"), key=lambda item: item.as_posix().casefold())
    except OSError:
        return
    for path in candidates:
        if not path.is_file() or path.suffix.casefold() not in SUPPORTED:
            continue
        if any(part.casefold() in SKIP_PARTS for part in path.parts):
            continue
        yield path


def _discover(args: argparse.Namespace) -> tuple[list[Case], list[dict[str, str]], int]:
    roots = args.production_root or [DEFAULT_PRODUCTION]
    expanded = args.expanded_root
    if expanded is None:
        expanded = [DEFAULT_EXPANDED] if DEFAULT_EXPANDED.is_dir() else []
    entries: list[tuple[Path, str, bool]] = []
    issues: list[dict[str, str]] = []
    seen_paths: set[Path] = set()

    def add(path: Path, kind: str, priority: bool) -> None:
        try:
            path = path.resolve()
            if path in seen_paths or not path.is_file() or path.suffix.casefold() not in SUPPORTED:
                return
            if path.stat().st_size > args.max_file_mib * 1024 * 1024:
                issues.append({"kind": "skipped_too_large", "file": path.name})
                return
        except OSError as exc:
            issues.append({"kind": "stat_error", "file": path.name, "error_type": type(exc).__name__})
            return
        seen_paths.add(path)
        entries.append((path, kind, priority))

    default_samples = () if args.no_default_samples else DEFAULT_SAMPLES
    for sample in [*default_samples, *(args.sample or [])]:
        if sample.is_file():
            add(sample, "named", True)
        else:
            issues.append({"kind": "missing_named_sample", "file": sample.name})
    for kind, source_roots in (("production", roots), ("expanded", expanded)):
        for root in source_roots:
            if not root.exists():
                issues.append({"kind": f"missing_{kind}_root", "file": root.name})
            for path in _files(root):
                # Expanded archives may contain images embedded by DOCX/PDF
                # source documents. They are not independent production inputs.
                if kind == "expanded" and _category(path) == "image":
                    continue
                add(path, kind, False)

    entries.sort(key=lambda item: (not item[2], _category(item[0]), item[1], item[0].name.casefold()))
    selected: list[Case] = []
    seen_hashes: set[str] = set()
    id_counts: Counter[str] = Counter()

    def select(entry: tuple[Path, str, bool]) -> bool:
        if len(selected) >= args.limit:
            return False
        path, kind, _priority = entry
        try:
            sha256 = _digest(path)
        except OSError as exc:
            issues.append({"kind": "hash_error", "file": path.name, "error_type": type(exc).__name__})
            return False
        if sha256 in seen_hashes:
            return False
        seen_hashes.add(sha256)
        category = _category(path)
        prefix = f"{category}-{sha256[:12]}"
        id_counts[prefix] += 1
        case_id = prefix if id_counts[prefix] == 1 else f"{prefix}-{id_counts[prefix]}"
        selected.append(Case(case_id, path, sha256, category, kind, path.stat().st_size))
        return True

    for entry in entries:
        if entry[2]:
            select(entry)
    buckets: dict[str, deque[tuple[Path, str, bool]]] = defaultdict(deque)
    for entry in entries:
        if not entry[2]:
            buckets[_category(entry[0])].append(entry)
    while len(selected) < args.limit and any(buckets.values()):
        for category in sorted(buckets):
            if buckets[category] and len(selected) < args.limit:
                select(buckets[category].popleft())
    return selected, issues, len(entries)


def _path_value(payload: Any, path: str) -> Any:
    if path == "$":
        return payload
    if not path.startswith("$"):
        return None
    current, position = payload, 1
    while position < len(path):
        match = TOKEN.match(path, position)
        if match is None:
            return None
        key, index, quoted = match.groups()
        if index is not None:
            if not isinstance(current, list) or int(index) >= len(current):
                return None
            current = current[int(index)]
        else:
            key = key if key is not None else quoted
            if not isinstance(current, dict) or key not in current:
                return None
            current = current[key]
        position = match.end()
    return current


def _child_path(prefix: str, key: str, *, quoted: bool) -> str:
    if quoted or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
        return f"{prefix}[{json.dumps(key, ensure_ascii=False)}]"
    return f"{prefix}.{key}"


def _walk(value: Any, prefix: str, *, quoted: bool = False, depth: int = 0) -> Iterator[tuple[str, Any]]:
    if not _present(value):
        return
    if isinstance(value, dict) and depth < 3:
        for key in sorted(value, key=str):
            yield from _walk(value[key], _child_path(prefix, str(key), quoted=quoted), quoted=quoted, depth=depth + 1)
    elif not isinstance(value, list):
        yield prefix, value


def _facts(record: dict[str, Any]) -> list[tuple[str, Any, str]]:
    values: list[tuple[str, Any, str]] = []
    for field in ("document_type", "document_subtype"):
        if _present(record.get(field)):
            values.append((f"$.{field}", record[field], "classification"))
    for section in ("header", "totals"):
        if isinstance(record.get(section), dict):
            values.extend((path, value, "key_value") for path, value in _walk(record[section], f"$.{section}"))
    for index, line in enumerate(record.get("lines") or []):
        if not isinstance(line, dict):
            continue
        prefix = f"$.lines[{index}]"
        for field, value in line.items():
            if field not in LINE_SKIP and _present(value):
                values.extend((path, item, "table_cell") for path, item in _walk(value, f"{prefix}.{field}"))
        for field in ("custom_fields", "raw_columns"):
            if isinstance(line.get(field), dict):
                values.extend(
                    (path, item, "parameter")
                    for path, item in _walk(
                        line[field],
                        f"{prefix}.{field}",
                        quoted=True,
                    )
                )
    return values


def _locatable(ref: Any) -> tuple[bool, bool]:
    if not isinstance(ref, dict):
        return False, False
    if ref.get("sheet") and (ref.get("cell") or ref.get("range")):
        return True, True
    try:
        page = int(ref.get("page") or 0)
    except (TypeError, ValueError):
        page = 0
    if page <= 0:
        return bool(ref), False
    bbox = ref.get("bbox")
    valid_bbox = False
    if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
        try:
            valid_bbox = all(math.isfinite(float(item)) for item in bbox)
        except (TypeError, ValueError):
            valid_bbox = False
    return True, valid_bbox or bool(str(ref.get("part") or "").strip())


def _coverage(record: dict[str, Any]) -> dict[str, Any]:
    metadata = record.get("field_meta") if isinstance(record.get("field_meta"), dict) else {}
    counts, scopes = Counter(), defaultdict(Counter)
    for path, _value, scope in _facts(record):
        counts["facts"] += 1
        scopes[scope]["facts"] += 1
        refs = metadata.get(path, {}).get("source_refs") if isinstance(metadata.get(path), dict) else []
        present = located = False
        for ref in refs if isinstance(refs, list) else []:
            has_ref, has_locator = _locatable(ref)
            present, located = present or has_ref, located or has_locator
        if present:
            counts["metadata_present"] += 1
            scopes[scope]["metadata_present"] += 1
        if located:
            counts["locatable"] += 1
            scopes[scope]["locatable"] += 1
    denominator = counts["facts"]
    return {
        **dict(counts),
        "metadata_ratio": counts["metadata_present"] / denominator if denominator else 1.0,
        "locatable_ratio": counts["locatable"] / denominator if denominator else 1.0,
        "by_scope": {
            name: {**dict(values), "locatable_ratio": values["locatable"] / values["facts"] if values["facts"] else 1.0}
            for name, values in sorted(scopes.items())
        },
    }


_SEMANTIC_COMPLETION_COUNT_KEYS = (
    "evidence_total",
    "source_evidence_total",
    "supplemental_evidence_total",
    "evidence_accounted",
    "evidence_structured",
    "evidence_schema",
    "evidence_redundant",
    "evidence_non_semantic",
    "evidence_ambiguous",
    "evidence_needs_review",
    "evidence_verified",
    "evidence_advisory",
    "source_evidence_structured",
    "source_evidence_schema",
    "source_evidence_redundant",
    "source_evidence_non_semantic",
    "source_evidence_ambiguous",
    "source_evidence_needs_review",
    "source_evidence_verified",
    "source_evidence_advisory",
    "supplemental_evidence_structured",
    "supplemental_evidence_schema",
    "supplemental_evidence_redundant",
    "supplemental_evidence_non_semantic",
    "supplemental_evidence_ambiguous",
    "supplemental_evidence_needs_review",
    "supplemental_evidence_verified",
    "supplemental_evidence_advisory",
    "facts_total",
    "facts_verified",
    "facts_ambiguous",
    "facts_advisory",
    "source_facts_verified",
    "source_facts_ambiguous",
    "source_facts_advisory",
    "supplemental_facts_verified",
    "supplemental_facts_ambiguous",
    "supplemental_facts_advisory",
)
_SEMANTIC_COMPLETION_RATIO_KEYS = (
    "audit_completeness",
    "source_semantically_verified",
    "source_structured",
    "source_requiring_review",
    "evidence_accounting",
    "audited_structured",
    "audited_requiring_review",
)

_SEMANTIC_COMPLETION_DEPRECATED_COMPATIBILITY_FIELDS = {
    "evidence_accounting_ratio": "audit_completeness_ratio",
    "evidence_structured_ratio": "source_structured_ratio",
    "evidence_requiring_review_ratio": "source_requiring_review_ratio",
    "fact_verified_ratio": "fact_status_verified_ratio",
}


def _nonnegative_int(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        return None
    return value


def _unit_ratio(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    result = float(value)
    return result if math.isfinite(result) and 0.0 <= result <= 1.0 else None


def _semantic_completion_overview(raw: Any) -> dict[str, Any]:
    audit = (
        raw.get("semantic_completeness_audit")
        if isinstance(raw, dict)
        else None
    )
    counts = audit.get("counts") if isinstance(audit, dict) else None
    ratios = audit.get("ratios") if isinstance(audit, dict) else None
    available = isinstance(counts, dict) and isinstance(ratios, dict)
    result: dict[str, Any] = {
        "semantic_completion_available": available,
        "semantic_completion_schema_version": (
            audit.get("schema_version") if isinstance(audit, dict) else None
        ),
        "semantic_completion_review_required": (
            audit.get("review_required")
            if isinstance(audit, dict)
            and isinstance(audit.get("review_required"), bool)
            else None
        ),
    }
    for key in _SEMANTIC_COMPLETION_COUNT_KEYS:
        result[f"semantic_completion_{key}"] = _nonnegative_int(
            counts.get(key) if isinstance(counts, dict) else None
        )
    for key in _SEMANTIC_COMPLETION_RATIO_KEYS:
        result[f"semantic_completion_{key}_ratio"] = _unit_ratio(
            ratios.get(key) if isinstance(ratios, dict) else None
        )
    return result


def _overview(record: dict[str, Any]) -> dict[str, Any]:
    raw = record.get("extraction", {}).get("raw_content", {}) if isinstance(record.get("extraction"), dict) else {}
    extraction_metadata = (
        record.get("extraction", {}).get("metadata", {})
        if isinstance(record.get("extraction"), dict)
        and isinstance(record.get("extraction", {}).get("metadata"), dict)
        else {}
    )
    pages = raw.get("pages") if isinstance(raw, dict) else []
    table_count = sum(
        len(page.get(key) or [])
        for page in pages if isinstance(page, dict)
        for key in ("tables", "ocr_tables")
        if isinstance(page.get(key), list)
    )
    issues = sorted(
        {
            str(item.get("code"))
            for item in record.get("validation_issues") or []
            if isinstance(item, dict) and item.get("code")
        }
    )
    facts = _facts(record)
    return {
        "document_type": record.get("document_type"),
        "document_subtype": record.get("document_subtype"),
        "line_count": len(record.get("lines") or []),
        "nonempty_record_field_count": len(facts),
        "parameter_value_count": sum(1 for _path, _value, scope in facts if scope == "parameter"),
        "evidence_table_count": table_count,
        "validation_issue_codes": issues,
        "document_intent": extraction_metadata.get("document_intent"),
        "evidence_complete": extraction_metadata.get("evidence_complete"),
        "semantic_complete": extraction_metadata.get("semantic_complete"),
        "accounted_complete": extraction_metadata.get("accounted_complete"),
        "retained_complete": extraction_metadata.get("retained_complete"),
        "evidence_coverage_ratio": extraction_metadata.get(
            "evidence_coverage_ratio"
        ),
        "semantic_accounting_ratio": extraction_metadata.get(
            "semantic_accounting_ratio"
        ),
        "evidence_accounting_ratio": extraction_metadata.get(
            "evidence_accounting_ratio"
        ),
        "retained_evidence_ratio": extraction_metadata.get(
            "retained_evidence_ratio"
        ),
        "evidence_total_count": extraction_metadata.get("evidence_total_count"),
        "evidence_mapped_count": extraction_metadata.get("evidence_mapped_count"),
        "evidence_schema_count": extraction_metadata.get(
            "evidence_schema_count"
        ),
        "evidence_redundant_count": extraction_metadata.get(
            "evidence_redundant_count"
        ),
        "evidence_raw_content_count": extraction_metadata.get(
            "evidence_raw_content_count"
        ),
        "evidence_unresolved_count": extraction_metadata.get(
            "evidence_unresolved_count"
        ),
        "evidence_retained_count": extraction_metadata.get(
            "evidence_retained_count"
        ),
        "evidence_unmapped_count": extraction_metadata.get(
            "evidence_unmapped_count"
        ),
        "content_evidence_count": extraction_metadata.get(
            "content_evidence_count"
        ),
        "content_unit_count": extraction_metadata.get("content_unit_count"),
        "content_model_bound_count": extraction_metadata.get(
            "content_model_bound_count"
        ),
        "content_local_fallback_count": extraction_metadata.get(
            "content_local_fallback_count"
        ),
        "content_accounted_complete": extraction_metadata.get(
            "content_accounted_complete"
        ),
        "content_semantic_coverage_ratio": extraction_metadata.get(
            "content_semantic_coverage_ratio"
        ),
        "content_accounting_ratio": extraction_metadata.get(
            "content_accounting_ratio"
        ),
        "spreadsheet_continuation_group_count": len(
            extraction_metadata.get("spreadsheet_continuation_groups") or []
        ),
        "source_asset_inventory_status": extraction_metadata.get(
            "source_asset_inventory_status"
        ),
        "source_asset_count": extraction_metadata.get("source_asset_count"),
        "source_asset_media_part_count": extraction_metadata.get(
            "source_asset_media_part_count"
        ),
        "source_asset_occurrence_count": extraction_metadata.get(
            "source_asset_occurrence_count"
        ),
        "source_asset_requirement_count": extraction_metadata.get(
            "source_asset_requirement_count"
        ),
        "source_asset_analyzed_count": extraction_metadata.get(
            "source_asset_analyzed_count"
        ),
        "source_asset_analyzed_asset_count": extraction_metadata.get(
            "source_asset_analyzed_asset_count"
        ),
        "source_asset_fulfilled_requirement_count": extraction_metadata.get(
            "source_asset_fulfilled_requirement_count"
        ),
        "source_asset_inventory_ratio": extraction_metadata.get(
            "source_asset_inventory_ratio"
        ),
        "source_asset_analysis_ratio": extraction_metadata.get(
            "source_asset_analysis_ratio"
        ),
        **_semantic_completion_overview(raw),
    }


def _record(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("candidate JSON must be an object")  # noqa: TRY004
    options = [payload.get("record"), payload.get("document"), payload]
    if isinstance(payload.get("result"), dict):
        options.extend([payload["result"].get("record"), payload["result"].get("document")])
    for value in options:
        if isinstance(value, dict) and any(
            key in value
            for key in ("header", "lines", "field_meta", "document_type", "extraction")
        ):
            return value
    raise ValueError("candidate JSON has no record/document")


def _load_candidate_json(value: str) -> Any:
    try:
        return json.loads(value.strip())
    except json.JSONDecodeError:
        for line in reversed(value.splitlines()):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                pass
    raise ValueError("candidate output is not JSON")


def _validated_candidate_output(
    payload: Any,
    *,
    case: Case,
) -> CandidateOutput:
    record = _record(payload)
    source = record.get("source")
    source_sha256 = (
        str(source.get("sha256") or "").casefold()
        if isinstance(source, dict)
        else ""
    )
    if source_sha256 != case.sha256.casefold():
        raise ValueError("candidate record source SHA-256 does not match case")
    return CandidateOutput(
        record=record,
        payload=payload if isinstance(payload, dict) else {},
    )


def _candidate_reported_elapsed(payload: Any) -> float:
    timing = payload.get("timing") if isinstance(payload, dict) else None
    value = timing.get("total_ms") if isinstance(timing, dict) else None
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(float(value))
        or float(value) < 0
    ):
        raise ValueError("replayed candidate has no valid total_ms timing")
    return round(float(value), 3)


def _run_candidate(
    case: Case,
    args: argparse.Namespace,
    temporary_dir: Path,
) -> tuple[CandidateOutput | None, dict[str, Any]]:
    replay_dir = getattr(args, "candidate_replay_dir", None)
    if replay_dir is not None:
        replay_root = Path(replay_dir).resolve()
        replay_path = (replay_root / f"{case.id}.json").resolve()
        if replay_path.parent != replay_root:
            return None, {
                "status": "error",
                "error_type": "CandidateReplayPathInvalid",
            }
        try:
            payload = _load_candidate_json(replay_path.read_text(encoding="utf-8"))
            candidate_output = _validated_candidate_output(payload, case=case)
            elapsed = _candidate_reported_elapsed(payload)
        except FileNotFoundError:
            return None, {
                "status": "error",
                "error_type": "CandidateReplayMissing",
            }
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
            return None, {
                "status": "error",
                "error_type": f"CandidateReplayInvalid:{exc.__class__.__name__}",
            }
        return candidate_output, {
            "status": "completed",
            "output_source": "replay",
            "elapsed_ms": elapsed,
        }

    output = temporary_dir / f"{case.id}.json"
    replacements = {
        "{input}": _quote(str(case.path)), "{output}": _quote(str(output)),
        "{case_id}": _quote(case.id), "{original_filename}": _quote(case.path.name),
    }
    command = args.candidate_command
    for token, replacement in replacements.items():
        command = command.replace(token, replacement)
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            shell=True,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=args.timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        return None, {
            "status": "error",
            "error_type": "TimeoutExpired",
            "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
            "stdout_sha256": _content_digest(exc.stdout),
            "stderr_sha256": _content_digest(exc.stderr),
        }
    elapsed = round((time.perf_counter() - started) * 1000, 3)
    if completed.returncode:
        return None, {
            "status": "error",
            "error_type": "CandidateProcessError",
            "returncode": completed.returncode,
            "elapsed_ms": elapsed,
            "stdout_sha256": _content_digest(completed.stdout),
            "stderr_sha256": _content_digest(completed.stderr),
        }
    sources: list[tuple[str, str]] = []
    if args.candidate_output_mode in {"auto", "file"} and output.is_file():
        sources.append(("file", output.read_text(encoding="utf-8")))
    if args.candidate_output_mode in {"auto", "stdout"}:
        sources.append(("stdout", completed.stdout))
    for source, raw in sources:
        try:
            payload = _load_candidate_json(raw)
            candidate_output = _validated_candidate_output(payload, case=case)
            return candidate_output, {
                "status": "completed",
                "output_source": source,
                "elapsed_ms": elapsed,
            }
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
    return None, {
        "status": "error",
        "error_type": "CandidateOutputInvalid",
        "elapsed_ms": elapsed,
        "stdout_sha256": _content_digest(completed.stdout),
    }


def _gold_case(case: Case, gold: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(gold, dict):
        return None
    for item in gold.get("cases") or []:
        if not isinstance(item, dict):
            continue
        if item.get("id") == case.id or str(item.get("sha256") or "").casefold() == case.sha256.casefold():
            return item
    by_name = [
        item
        for item in gold.get("cases") or []
        if isinstance(item, dict)
        and str(item.get("original_filename") or item.get("filename") or "").casefold()
        == case.path.name.casefold()
    ]
    return by_name[0] if len(by_name) == 1 else None


def _gold_match_kind(case: Case, gold_case: dict[str, Any] | None) -> str | None:
    if gold_case is None:
        return None
    if str(gold_case.get("sha256") or "").casefold() == case.sha256.casefold():
        return "sha256"
    if gold_case.get("id") == case.id:
        return "id"
    return "filename"


def _expected(case: dict[str, Any]) -> dict[str, Any]:
    for key in ("expected", "gold"):
        if isinstance(case.get(key), dict):
            return case[key]
    keys = ("fields", "key_values", "tables", "parameter_tables", "continuations")
    return case if any(key in case for key in keys) else {}


def _semantic_name(value: object) -> str:
    normalized = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return re.sub(r"[\s_\-:：]+", "", normalized)


def _semantic_occurrences(
    record: dict[str, Any],
    payload: dict[str, Any] | None,
) -> list[_SemanticOccurrence]:
    projection = (
        payload.get("projection", {})
        if isinstance(payload, dict) and isinstance(payload.get("projection"), dict)
        else {}
    )
    field_names = (
        projection.get("field_names", {})
        if isinstance(projection.get("field_names"), dict)
        else {}
    )
    metadata = (
        record.get("field_meta", {})
        if isinstance(record.get("field_meta"), dict)
        else {}
    )
    occurrences: list[_SemanticOccurrence] = []

    def add(section: str, values: Any, prefix: str) -> None:
        if not isinstance(values, dict):
            return
        for key, value in values.items():
            path = _child_path(prefix, str(key), quoted=False)
            semantic = str(field_names.get(path) or key)
            meta = metadata.get(path)
            refs = (
                meta.get("source_refs", [])
                if isinstance(meta, dict) and isinstance(meta.get("source_refs"), list)
                else []
            )
            occurrences.append(
                _SemanticOccurrence(
                    name=semantic,
                    value=value,
                    path=path,
                    scope=section,
                    source_refs=tuple(ref for ref in refs if isinstance(ref, dict)),
                )
            )

    add("header", record.get("header"), "$.header")
    for index, line in enumerate(record.get("lines") or []):
        add("line", line, f"$.lines[{index}]")
    return occurrences


def _semantic_values(
    occurrences: list[_SemanticOccurrence],
    name: str,
    *,
    scope: str | None = None,
) -> list[_SemanticOccurrence]:
    wanted = _semantic_name(name)
    return [
        occurrence
        for occurrence in occurrences
        if _semantic_name(occurrence.name) == wanted
        and (scope is None or occurrence.scope == scope)
    ]


def _occurrence_is_locatable(occurrence: _SemanticOccurrence) -> bool:
    for reference in occurrence.source_refs:
        if reference.get("sheet") and (reference.get("cell") or reference.get("range")):
            return True
        if str(reference.get("part") or "").strip():
            return True
        try:
            if int(reference.get("page") or 0) > 0:
                return True
        except (TypeError, ValueError):
            pass
        bbox = reference.get("bbox")
        if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
            try:
                if all(math.isfinite(float(item)) for item in bbox):
                    return True
            except (TypeError, ValueError):
                pass
    return False


def _unique_semantic_value_matches(
    candidates: list[_SemanticOccurrence],
    expected: Any,
    *,
    require_locatable: bool,
) -> bool:
    present = [candidate for candidate in candidates if _present(candidate.value)]
    if expected is None:
        return not present
    if not present:
        return False

    representatives: list[_SemanticOccurrence] = []
    for candidate in present:
        if not any(
            _equal(representative.value, candidate.value)
            for representative in representatives
        ):
            representatives.append(candidate)
    if len(representatives) != 1 or not _equal(expected, representatives[0].value):
        return False

    matching = [candidate for candidate in present if _equal(expected, candidate.value)]
    return not require_locatable or any(
        _occurrence_is_locatable(candidate) for candidate in matching
    )


def _candidate_intent(record: dict[str, Any], payload: dict[str, Any] | None) -> str:
    result = (
        payload.get("result", {})
        if isinstance(payload, dict) and isinstance(payload.get("result"), dict)
        else {}
    )
    extraction = (
        record.get("extraction", {})
        if isinstance(record.get("extraction"), dict)
        else {}
    )
    metadata = (
        extraction.get("metadata", {})
        if isinstance(extraction.get("metadata"), dict)
        else {}
    )
    return str(
        result.get("document_intent")
        or metadata.get("document_intent")
        or record.get("document_type")
        or ""
    )


def _intent_family(intent: str) -> str:
    intent = intent.strip().casefold()
    return {
        "purchase_contract": "purchase_order",
        "supplier_purchase_order": "purchase_order",
        "stocking_order": "purchase_order",
        "engineering_drawing": "technical_document",
        "product_specification": "technical_document",
    }.get(intent, intent)


def _candidate_subtype(
    record: dict[str, Any],
    payload: dict[str, Any] | None,
    *,
    intent: str,
) -> str:
    result = (
        payload.get("result", {})
        if isinstance(payload, dict) and isinstance(payload.get("result"), dict)
        else {}
    )
    explicit = record.get("document_subtype") or result.get("document_subtype")
    if explicit:
        return str(explicit)
    return intent if _intent_family(intent) != intent else ""


def _model_content_units(
    record: dict[str, Any], payload: dict[str, Any] | None
) -> list[dict[str, Any]]:
    result = (
        payload.get("result", {})
        if isinstance(payload, dict) and isinstance(payload.get("result"), dict)
        else {}
    )
    candidates = result.get("content_units")
    if not isinstance(candidates, list):
        extraction = (
            record.get("extraction", {})
            if isinstance(record.get("extraction"), dict)
            else {}
        )
        raw = (
            extraction.get("raw_content", {})
            if isinstance(extraction.get("raw_content"), dict)
            else {}
        )
        dispositions = (
            raw.get("evidence_dispositions", {})
            if isinstance(raw.get("evidence_dispositions"), dict)
            else {}
        )
        candidates = dispositions.get("content_model_bound")
    units: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for item in candidates if isinstance(candidates, list) else []:
        if not isinstance(item, dict):
            continue
        if item.get("binding_source", "model") not in {
            "model",
            "deterministic",
        }:
            continue
        marker = (
            str(item.get("evidence_id") or ""),
            str(item.get("content_kind") or ""),
            str(item.get("label") or ""),
            str(item.get("exact_text") or ""),
        )
        if marker in seen:
            continue
        seen.add(marker)
        units.append(item)
    return units


def _content_semantics(item: dict[str, Any]) -> str:
    values = [str(item.get("content_kind") or ""), str(item.get("label") or "")]
    for alternate in item.get("alternate_semantics") or []:
        if isinstance(alternate, dict):
            values.extend(
                [
                    str(alternate.get("content_kind") or ""),
                    str(alternate.get("label") or ""),
                ]
            )
    return _semantic_name(" ".join(values))


def _is_contract_clause_unit(item: dict[str, Any]) -> bool:
    text = _semantic_name(item.get("exact_text"))
    if text in {"合同条款", "contractterms", "contractclauses"}:
        return False
    kind = _semantic_name(item.get("content_kind"))
    label = _semantic_name(item.get("label"))
    return kind == "contractclause" or bool(
        re.fullmatch(r"(?:clause|合同条款)\d+", label)
    )


def _ordered_contains(text: str, expected: list[Any]) -> tuple[bool, int]:
    normalized = _semantic_name(text)
    cursor = 0
    matched = 0
    for item in expected:
        token = _semantic_name(item)
        position = normalized.find(token, cursor)
        if not token or position < 0:
            return False, matched
        matched += 1
        cursor = position + len(token)
    return True, matched


def _line_source_position(occurrence: _SemanticOccurrence) -> tuple[Any, ...] | None:
    positions: list[tuple[Any, ...]] = []
    for reference in occurrence.source_refs:
        cell = str(reference.get("cell") or "")
        if match := re.fullmatch(r"([A-Za-z]+)(\d+)", cell):
            column = 0
            for character in match.group(1).upper():
                column = column * 26 + ord(character) - ord("A") + 1
            positions.append((0, int(match.group(2)), column))
        part = str(reference.get("part") or "")
        if match := re.search(r"(?:/|:)r(\d+)(?:/|:)c(\d+)(?:\b|/|:)", part):
            positions.append((1, int(match.group(1)), int(match.group(2))))
        bbox = reference.get("bbox")
        if isinstance(bbox, list) and len(bbox) >= 2:
            try:
                positions.append(
                    (
                        2,
                        int(reference.get("page") or 0),
                        float(bbox[1]),
                        float(bbox[0]),
                    )
                )
            except (TypeError, ValueError):
                pass
    return min(positions) if positions else None


def _line_semantic_names(
    occurrences: list[_SemanticOccurrence],
    record: dict[str, Any],
) -> list[str]:
    actual: list[str] = []
    actual_seen: set[str] = set()
    for occurrence in occurrences:
        if occurrence.scope != "line":
            continue
        marker = _semantic_name(occurrence.name)
        if not marker or marker in actual_seen:
            continue
        actual_seen.add(marker)
        actual.append(occurrence.name)

    extraction = (
        record.get("extraction", {})
        if isinstance(record.get("extraction"), dict)
        else {}
    )
    declared: list[str] = []
    line_field_order = extraction.get("line_field_order")
    explicit_order = isinstance(line_field_order, list)
    if explicit_order:
        declared.extend(str(name) for name in line_field_order)
    if not declared:
        record_sets = extraction.get("record_sets")
        for record_set in record_sets if isinstance(record_sets, list) else []:
            if not isinstance(record_set, dict) or record_set.get("role") != (
                "primary_business_records"
            ):
                continue
            records = record_set.get("records")
            if not isinstance(records, list):
                continue
            for semantic_record in records:
                fields = (
                    semantic_record.get("fields")
                    if isinstance(semantic_record, dict)
                    else None
                )
                for field in fields if isinstance(fields, list) else []:
                    if not isinstance(field, dict):
                        continue
                    name = field.get("canonical_name") or field.get("name")
                    if name:
                        declared.append(str(name))
            if declared:
                break

    if not declared:
        first_line = [
            occurrence
            for occurrence in occurrences
            if occurrence.scope == "line"
            and occurrence.path.startswith("$.lines[0].")
        ]
        positioned = [
            (position, occurrence)
            for occurrence in first_line
            if (position := _line_source_position(occurrence)) is not None
        ]
        if positioned and len(positioned) == len(first_line):
            declared.extend(
                occurrence.name
                for _position, occurrence in sorted(
                    positioned,
                    key=lambda item: item[0],
                )
            )

    schema_seen: set[str] = set()
    if explicit_order:
        raw_content = extraction.get("raw_content")
        dispositions = (
            raw_content.get("evidence_dispositions")
            if isinstance(raw_content, dict)
            else None
        )
        schema_labels = (
            dispositions.get("schema_label")
            if isinstance(dispositions, dict)
            else None
        )
        for item in schema_labels if isinstance(schema_labels, list) else []:
            if not isinstance(item, dict):
                continue
            marker = _semantic_name(item.get("quote"))
            if marker:
                schema_seen.add(marker)

    names: list[str] = []
    seen: set[str] = set()
    for name in [*declared, *actual]:
        marker = _semantic_name(name)
        if (
            not marker
            or marker in seen
            or (
                marker not in actual_seen
                and not (explicit_order and marker in schema_seen)
            )
        ):
            continue
        seen.add(marker)
        names.append(name)
    return names


def _line_semantic_rows(
    record: dict[str, Any], occurrences: list[_SemanticOccurrence]
) -> list[dict[str, list[_SemanticOccurrence]]]:
    rows: list[dict[str, list[_SemanticOccurrence]]] = [
        {} for _line in (record.get("lines") or [])
    ]
    for occurrence in occurrences:
        match = re.match(r"^\$\.lines\[(\d+)\]", occurrence.path)
        if occurrence.scope != "line" or match is None:
            continue
        index = int(match.group(1))
        if index >= len(rows):
            continue
        rows[index].setdefault(_semantic_name(occurrence.name), []).append(occurrence)
    return rows


def _source_cell_matches(refs: tuple[dict[str, Any], ...], locator: str) -> bool:
    if "!" not in locator:
        return False
    sheet, cell = locator.rsplit("!", 1)
    return any(
        _semantic_name(ref.get("sheet")) == _semantic_name(sheet)
        and str(ref.get("cell") or "").casefold() == cell.casefold()
        for ref in refs
    )


def _score_provisional_semantics(
    record: dict[str, Any],
    expected: dict[str, Any],
    *,
    payload: dict[str, Any] | None,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    errors: list[str] = []
    consumed = set(expected) & (
        _PROVISIONAL_SCORING_KEYS | _DESCRIPTIVE_GOLD_KEYS | _LEGACY_GOLD_KEYS
    )
    unconsumed = sorted(set(expected) - consumed)
    occurrences = _semantic_occurrences(record, payload)
    line_names = _line_semantic_names(occurrences, record)
    line_rows = _line_semantic_rows(record, occurrences)
    intent = _candidate_intent(record, payload)

    def check(annotation: str, matched: bool, **details: Any) -> None:
        checks.append({"annotation": annotation, "matched": bool(matched), **details})

    if "intent_family" in expected:
        check(
            "intent_family",
            _equal(expected["intent_family"], _intent_family(intent)),
        )
    if "document_subtype" in expected:
        check(
            "document_subtype",
            _equal(
                expected["document_subtype"],
                _candidate_subtype(record, payload, intent=intent),
            ),
        )
    if "record_count" in expected:
        if not isinstance(expected["record_count"], int):
            errors.append("record_count must be an integer")
        check(
            "record_count",
            isinstance(expected["record_count"], int)
            and expected["record_count"] == len(record.get("lines") or []),
        )

    key_values = expected.get("key_values")
    if "key_values" in expected and not isinstance(key_values, dict):
        errors.append("key_values must be an object")
    for name, value in key_values.items() if isinstance(key_values, dict) else []:
        if str(name).startswith("$"):
            continue
        candidates = _semantic_values(
            occurrences,
            str(name),
            scope="header",
        )
        check(
            f"key_values.{name}",
            _unique_semantic_value_matches(
                candidates,
                value,
                require_locatable=True,
            ),
        )

    header_fields = expected.get("header_fields")
    if "header_fields" in expected and not isinstance(header_fields, dict):
        errors.append("header_fields must be an object")
    for name, specification in (
        header_fields.items() if isinstance(header_fields, dict) else []
    ):
        if isinstance(specification, dict):
            unknown = sorted(set(specification) - {"value", "source_cell"})
            unconsumed.extend(f"header_fields.{name}.{key}" for key in unknown)
            if "value" not in specification:
                errors.append(f"header_fields.{name}.value is required")
            wanted = specification.get("value")
            source_cell = specification.get("source_cell")
        else:
            wanted = specification
            source_cell = None
        candidates = _semantic_values(occurrences, str(name), scope="header")
        matching = [item for item in candidates if _equal(wanted, item.value)]
        matched = _unique_semantic_value_matches(
            candidates,
            wanted,
            require_locatable=True,
        )
        if source_cell is not None:
            matched = matched and any(
                _source_cell_matches(item.source_refs, str(source_cell))
                for item in matching
            )
        check(f"header_fields.{name}", matched)

    for key in ("detail_columns", "field_names"):
        if key not in expected:
            continue
        values = expected[key]
        if not isinstance(values, list):
            errors.append(f"{key} must be an array")
            check(key, False)
            continue
        available = {_semantic_name(name) for name in line_names}
        for index, name in enumerate(values):
            check(f"{key}[{index}]", _semantic_name(name) in available)
        ordered, matched_count = _ordered_contains("\n".join(line_names), values)
        check(
            f"{key}.__order__",
            ordered,
            matched_items=matched_count,
            total_items=len(values),
        )

    for key in ("records", "line_items"):
        if key not in expected:
            continue
        rows = expected[key]
        if not isinstance(rows, list):
            errors.append(f"{key} must be an array")
            check(key, False)
            continue
        for row_index, wanted_row in enumerate(rows):
            if not isinstance(wanted_row, dict):
                errors.append(f"{key}[{row_index}] must be an object")
                check(f"{key}[{row_index}]", False)
                continue
            actual_row = line_rows[row_index] if row_index < len(line_rows) else {}
            for name, value in wanted_row.items():
                candidates = actual_row.get(_semantic_name(name), [])
                matched = _unique_semantic_value_matches(
                    candidates,
                    value,
                    require_locatable=False,
                )
                check(f"{key}[{row_index}].{name}", matched)

    content_units = _model_content_units(record, payload)
    if "process_sequence" in expected:
        sequence = expected["process_sequence"]
        if not isinstance(sequence, list):
            errors.append("process_sequence must be an array")
            check("process_sequence", False)
        else:
            process_text = "\n".join(
                str(item.get("exact_text") or "")
                for item in content_units
                if any(
                    marker in _content_semantics(item)
                    for marker in ("process", "workflow", "step", "工艺", "步骤")
                )
            )
            ordered, matched_count = _ordered_contains(process_text, sequence)
            check(
                "process_sequence",
                ordered,
                matched_items=matched_count,
                total_items=len(sequence),
            )

    if "purchase_contract_clause_count" in expected:
        expected_count = expected["purchase_contract_clause_count"]
        if not isinstance(expected_count, int):
            errors.append("purchase_contract_clause_count must be an integer")
        clause_ids = {
            str(item.get("evidence_id") or f"index:{index}")
            for index, item in enumerate(content_units)
            if _is_contract_clause_unit(item)
        }
        check(
            "purchase_contract_clause_count",
            isinstance(expected_count, int) and len(clause_ids) == expected_count,
            actual_count=len(clause_ids),
        )

    matched = sum(int(item["matched"]) for item in checks)
    return {
        "status": "scored" if checks else "no_semantic_annotations",
        "matched": matched,
        "total": len(checks),
        "accuracy": matched / len(checks) if checks else None,
        "checks": checks,
        "unmatched_annotations": [
            item["annotation"] for item in checks if not item["matched"]
        ],
        "consumed_annotation_keys": sorted(consumed),
        "descriptive_annotation_keys": sorted(
            set(expected) & _DESCRIPTIVE_GOLD_KEYS
        ),
        "unconsumed_annotation_keys": sorted(set(unconsumed)),
        "annotation_errors": errors,
    }


def _field_specs(expected: dict[str, Any]) -> Iterator[tuple[str, Any]]:
    for key in ("fields", "key_values"):
        values = expected.get(key)
        if isinstance(values, dict):
            yield from (
                (str(path), value)
                for path, value in values.items()
                if key == "fields" or str(path).startswith("$")
            )
        elif isinstance(values, list):
            for item in values:
                if isinstance(item, dict) and item.get("path"):
                    yield str(item["path"]), item.get("value", {"present": True})


def _table_specs(expected: dict[str, Any]) -> Iterator[tuple[str, dict[str, Any]]]:
    for kind, key in (("table", "tables"), ("parameter_table", "parameter_tables"), ("continuation", "continuations")):
        for item in expected.get(key) or []:
            if isinstance(item, dict):
                yield kind, item


def _table_metric(record: dict[str, Any], kind: str, spec: dict[str, Any]) -> dict[str, Any]:
    path = str(spec.get("record_path") or "$.lines")
    actual = _path_value(record, path)
    actual = actual if isinstance(actual, list) else []
    expected_rows = spec.get("rows") if isinstance(spec.get("rows"), list) else []
    expected_count = (
        spec.get("row_count")
        if isinstance(spec.get("row_count"), int)
        else (len(expected_rows) if expected_rows else None)
    )
    keys = [str(key) for key in spec.get("key_fields") or []]
    used: set[int] = set()
    matched_rows = matched_cells = total_cells = missing_rows = 0
    for index, wanted in enumerate(expected_rows):
        if not isinstance(wanted, dict):
            continue
        match = next(
            (
                item_index
                for item_index, row in enumerate(actual)
                if item_index not in used
                and isinstance(row, dict)
                and (
                    (not keys and item_index == index)
                    or (
                        keys
                        and all(
                            key in wanted and _equal(wanted[key], row.get(key))
                            for key in keys
                        )
                    )
                )
            ),
            None,
        )
        if match is None:
            missing_rows += 1
            total_cells += sum(1 for value in wanted.values() if _present(value))
            continue
        used.add(match)
        row = actual[match]
        checks = [(key, value) for key, value in wanted.items() if key != "line_id" and _present(value)]
        total_cells += len(checks)
        row_matches = sum(1 for key, value in checks if _equal(value, row.get(key)))
        matched_cells += row_matches
        matched_rows += int(row_matches == len(checks))
    return {
        "id": str(spec.get("id") or kind), "kind": kind, "continuation_group": spec.get("continuation_group"),
        "record_path": path, "expected_row_count": expected_count, "actual_row_count": len(actual),
        "row_count_match": expected_count is None or expected_count == len(actual), "expected_rows": len(expected_rows),
        "matched_rows": matched_rows,
        "missing_rows": missing_rows,
        "matched_cells": matched_cells,
        "compared_cells": total_cells,
    }


def _score_gold(
    record: dict[str, Any] | None,
    gold_case: dict[str, Any] | None,
    *,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if gold_case is None:
        return {
            "status": "no_matching_gold",
            "fields": None,
            "tables": [],
            "semantic_gold": None,
        }
    expected = _expected(gold_case)
    candidate_record = record or {}
    checks = [
        {
            "path": path,
            "matched": _equal(value, _path_value(candidate_record, path)),
        }
        for path, value in _field_specs(expected)
    ]
    tables = [
        _table_metric(candidate_record, kind, spec)
        for kind, spec in _table_specs(expected)
    ]
    fields = sum(int(item["matched"]) for item in checks), len(checks)
    cells = sum(int(table["matched_cells"]) for table in tables), sum(int(table["compared_cells"]) for table in tables)
    semantic_gold = _score_provisional_semantics(
        candidate_record,
        expected,
        payload=payload,
    )
    return {
        "status": (
            "candidate_not_scored"
            if record is None
            else (
                "labeled"
                if checks or tables or semantic_gold["total"]
                else "gold_case_without_labels"
            )
        ),
        "fields": {
            "matched": fields[0],
            "total": fields[1],
            "accuracy": fields[0] / fields[1] if fields[1] else None,
            "unmatched_paths": [item["path"] for item in checks if not item["matched"]],
        },
        "tables": tables,
        "table_cells": {"matched": cells[0], "total": cells[1], "accuracy": cells[0] / cells[1] if cells[1] else None},
        "continuation_groups": sorted(
            {
                str(table["continuation_group"])
                for table in tables
                if table.get("continuation_group")
            }
        ),
        "semantic_gold": semantic_gold,
    }


def _key_gold_evaluation(score: Any) -> dict[str, Any]:
    if not isinstance(score, dict) or score.get("status") in {
        "no_matching_gold",
        "candidate_not_scored",
    }:
        return {
            "status": "not_scored",
            "passed": None,
            "assertion_count": 0,
            "failures": ["gold_not_scored"],
        }

    failures: list[str] = []
    fields = score.get("fields") if isinstance(score.get("fields"), dict) else {}
    field_matched = int(fields.get("matched") or 0)
    field_total = int(fields.get("total") or 0)
    if field_matched != field_total:
        failures.append("legacy_fields_mismatch")

    table_assertions = 0
    for table in score.get("tables") or []:
        if not isinstance(table, dict):
            continue
        if table.get("expected_row_count") is not None:
            table_assertions += 1
            if table.get("row_count_match") is not True:
                failures.append("table_row_count_mismatch")
        compared = int(table.get("compared_cells") or 0)
        table_assertions += compared
        if int(table.get("matched_cells") or 0) != compared:
            failures.append("table_cells_mismatch")

    semantic = (
        score.get("semantic_gold")
        if isinstance(score.get("semantic_gold"), dict)
        else {}
    )
    semantic_matched = int(semantic.get("matched") or 0)
    semantic_total = int(semantic.get("total") or 0)
    if semantic_matched != semantic_total:
        failures.append("semantic_gold_mismatch")
    if semantic.get("annotation_errors"):
        failures.append("gold_annotation_invalid")
    if semantic.get("unconsumed_annotation_keys"):
        failures.append("gold_annotations_unconsumed")

    assertion_count = field_total + table_assertions + semantic_total
    if assertion_count == 0:
        failures.append("no_effective_assertions")
    unique_failures = list(dict.fromkeys(failures))
    return {
        "status": "passed" if not unique_failures else "failed",
        "passed": not unique_failures,
        "assertion_count": assertion_count,
        "failures": unique_failures,
    }


def _full_evidence_evaluation(overview: Any) -> dict[str, Any]:
    if not isinstance(overview, dict) or not overview:
        return {
            "status": "not_available",
            "passed": None,
            "failures": ["candidate_overview_not_available"],
        }

    checks = {
        "evidence_not_accounted": overview.get("accounted_complete") is True,
        "evidence_not_retained": overview.get("retained_complete") is True,
        "content_not_accounted": overview.get("content_accounted_complete") is True,
        "terminal_unresolved_evidence": overview.get("evidence_unresolved_count") == 0,
        "source_asset_inventory_incomplete": (
            overview.get("source_asset_inventory_status") == "complete"
        ),
    }
    evidence_counts = {
        key: overview.get(key)
        for key in (
            "evidence_total_count",
            "evidence_mapped_count",
            "evidence_schema_count",
            "evidence_redundant_count",
            "evidence_raw_content_count",
            "evidence_retained_count",
            "content_evidence_count",
            "content_unit_count",
        )
    }
    if all(isinstance(value, int) for value in evidence_counts.values()):
        total = evidence_counts["evidence_total_count"]
        checks["evidence_accounting_counts_not_closed"] = (
            evidence_counts["evidence_mapped_count"]
            + evidence_counts["evidence_schema_count"]
            + evidence_counts["evidence_redundant_count"]
            + evidence_counts["evidence_raw_content_count"]
            >= total
        )
        checks["evidence_retention_counts_not_closed"] = (
            evidence_counts["evidence_retained_count"] >= total
        )
        checks["content_accounting_counts_not_closed"] = (
            evidence_counts["content_unit_count"]
            >= evidence_counts["content_evidence_count"]
        )
    else:
        checks["evidence_counts_unavailable"] = False
    source_counts = {
        key: overview.get(key)
        for key in (
            "source_asset_count",
            "source_asset_requirement_count",
            "source_asset_analyzed_count",
            "source_asset_analyzed_asset_count",
            "source_asset_fulfilled_requirement_count",
        )
    }
    if all(isinstance(value, int) for value in source_counts.values()):
        checks["source_assets_not_analyzed"] = (
            source_counts["source_asset_analyzed_count"]
            >= source_counts["source_asset_count"]
            + source_counts["source_asset_requirement_count"]
            and source_counts["source_asset_analyzed_asset_count"]
            >= source_counts["source_asset_count"]
            and source_counts["source_asset_fulfilled_requirement_count"]
            >= source_counts["source_asset_requirement_count"]
        )
    else:
        checks["source_asset_counts_unavailable"] = False

    failures = [name for name, passed in checks.items() if not passed]
    return {
        "status": "passed" if not failures else "failed",
        "passed": not failures,
        "failures": failures,
    }


def _aggregate(cases: list[dict[str, Any]]) -> dict[str, Any]:
    status = Counter()
    categories = Counter()
    coverage = Counter()
    fields = Counter()
    cells = Counter()
    tables = Counter()
    elapsed: list[float] = []
    raw_evidence = Counter()
    content_semantics = Counter()
    semantic_completion = Counter()
    source_assets = Counter()
    gold_semantics = Counter()
    gold_status = Counter()
    unconsumed_gold = Counter()
    for case in cases:
        categories[case["category"]] += 1
        candidate = case.get("candidate") or {}
        status[str(candidate.get("status"))] += 1
        if isinstance(candidate.get("elapsed_ms"), (int, float)):
            elapsed.append(float(candidate["elapsed_ms"]))
        for key in ("facts", "metadata_present", "locatable"):
            coverage[key] += int((case.get("source_coverage") or {}).get(key) or 0)
        overview = case.get("candidate_overview") or {}
        raw_evidence["total"] += int(overview.get("evidence_total_count") or 0)
        raw_evidence["mapped"] += int(overview.get("evidence_mapped_count") or 0)
        raw_evidence["schema"] += int(overview.get("evidence_schema_count") or 0)
        raw_evidence["redundant"] += int(
            overview.get("evidence_redundant_count") or 0
        )
        raw_evidence["raw_content"] += int(
            overview.get("evidence_raw_content_count") or 0
        )
        raw_evidence["unresolved"] += int(
            overview.get("evidence_unresolved_count") or 0
        )
        raw_evidence["retained"] += int(
            overview.get("evidence_retained_count") or 0
        )
        raw_evidence["unmapped"] += int(overview.get("evidence_unmapped_count") or 0)
        raw_evidence["complete_cases"] += int(
            overview.get("evidence_complete") is True
        )
        content_semantics["evidence"] += int(
            overview.get("content_evidence_count") or 0
        )
        content_semantics["units"] += int(
            overview.get("content_unit_count") or 0
        )
        content_semantics["model_bound"] += int(
            overview.get("content_model_bound_count") or 0
        )
        content_semantics["local_fallback"] += int(
            overview.get("content_local_fallback_count") or 0
        )
        content_semantics["accounted_complete_cases"] += int(
            overview.get("content_accounted_complete") is True
        )
        if overview.get("semantic_completion_available") is True:
            semantic_completion["available_cases"] += 1
            semantic_completion["review_required_cases"] += int(
                overview.get("semantic_completion_review_required") is True
            )
            for key in _SEMANTIC_COMPLETION_COUNT_KEYS:
                semantic_completion[key] += int(
                    overview.get(f"semantic_completion_{key}") or 0
                )
            completion_total = overview.get("semantic_completion_evidence_total")
            completion_accounted = overview.get(
                "semantic_completion_evidence_accounted"
            )
            semantic_completion["accounted_complete_cases"] += int(
                isinstance(completion_total, int)
                and isinstance(completion_accounted, int)
                and completion_total == completion_accounted
            )
        source_assets["assets"] += int(overview.get("source_asset_count") or 0)
        source_assets["media_parts"] += int(
            overview.get("source_asset_media_part_count") or 0
        )
        source_assets["occurrences"] += int(
            overview.get("source_asset_occurrence_count") or 0
        )
        source_assets["requirements"] += int(
            overview.get("source_asset_requirement_count") or 0
        )
        source_assets["analyzed"] += int(
            overview.get("source_asset_analyzed_count") or 0
        )
        source_assets["analyzed_assets"] += int(
            overview.get("source_asset_analyzed_asset_count") or 0
        )
        source_assets["fulfilled_requirements"] += int(
            overview.get("source_asset_fulfilled_requirement_count") or 0
        )
        source_assets["complete_inventories"] += int(
            overview.get("source_asset_inventory_status") == "complete"
        )
        gold = case.get("gold") or {}
        gold_status[str(gold.get("status") or "missing")] += 1
        for key in ("matched", "total"):
            fields[key] += int((gold.get("fields") or {}).get(key) or 0)
            cells[key] += int((gold.get("table_cells") or {}).get(key) or 0)
        for table in gold.get("tables") or []:
            if isinstance(table, dict):
                tables["total"] += 1
                tables["row_count_matches"] += int(bool(table.get("row_count_match")))
                tables[table.get("kind") or "table"] += 1
        semantic_gold = gold.get("semantic_gold")
        if isinstance(semantic_gold, dict):
            gold_semantics["matched"] += int(semantic_gold.get("matched") or 0)
            gold_semantics["total"] += int(semantic_gold.get("total") or 0)
            gold_semantics["scored_cases"] += int(
                semantic_gold.get("status") == "scored"
            )
            gold_semantics["annotation_errors"] += len(
                semantic_gold.get("annotation_errors") or []
            )
            for key in semantic_gold.get("unconsumed_annotation_keys") or []:
                unconsumed_gold[str(key)] += 1
    elapsed.sort()
    p95 = elapsed[max(0, math.ceil(len(elapsed) * 0.95) - 1)] if elapsed else None
    completion_available = semantic_completion["available_cases"]
    completion_evidence_total = semantic_completion["evidence_total"]
    completion_source_evidence_total = semantic_completion[
        "source_evidence_total"
    ]
    completion_facts_total = semantic_completion["facts_total"]
    audit_completeness_ratio = (
        semantic_completion["evidence_accounted"] / completion_evidence_total
        if completion_evidence_total
        else (1.0 if completion_available else None)
    )
    source_structured_ratio = (
        semantic_completion["source_evidence_verified"]
        / completion_source_evidence_total
        if completion_source_evidence_total
        else (1.0 if completion_available else None)
    )
    source_requiring_review_ratio = (
        (
            semantic_completion["source_evidence_ambiguous"]
            + semantic_completion["source_evidence_needs_review"]
        )
        / completion_source_evidence_total
        if completion_source_evidence_total
        else (0.0 if completion_available else None)
    )
    fact_status_verified_ratio = (
        semantic_completion["facts_verified"] / completion_facts_total
        if completion_facts_total
        else None
    )
    return {
        "case_status": dict(status), "categories": dict(categories),
        "source_coverage": {
            **dict(coverage),
            "metadata_ratio": (
                coverage["metadata_present"] / coverage["facts"]
                if coverage["facts"]
                else None
            ),
            "locatable_ratio": (
                coverage["locatable"] / coverage["facts"]
                if coverage["facts"]
                else None
            ),
        },
        "gold_fields": {**dict(fields), "accuracy": fields["matched"] / fields["total"] if fields["total"] else None},
        "gold_table_cells": {**dict(cells), "accuracy": cells["matched"] / cells["total"] if cells["total"] else None},
        "gold_tables": dict(tables),
        "gold_semantic": {
            **dict(gold_semantics),
            "accuracy": (
                gold_semantics["matched"] / gold_semantics["total"]
                if gold_semantics["total"]
                else None
            ),
            "case_status": dict(gold_status),
            "unconsumed_annotation_keys": dict(sorted(unconsumed_gold.items())),
        },
        "raw_evidence": {
            **dict(raw_evidence),
            "semantic_mapping_ratio": (
                raw_evidence["mapped"] / raw_evidence["total"]
                if raw_evidence["total"]
                else None
            ),
            "semantic_accounting_ratio": (
                (
                    raw_evidence["mapped"]
                    + raw_evidence["schema"]
                    + raw_evidence["redundant"]
                )
                / raw_evidence["total"]
                if raw_evidence["total"]
                else None
            ),
            "evidence_accounting_ratio": (
                (
                    raw_evidence["mapped"]
                    + raw_evidence["schema"]
                    + raw_evidence["redundant"]
                    + raw_evidence["raw_content"]
                )
                / raw_evidence["total"]
                if raw_evidence["total"]
                else None
            ),
            "retained_evidence_ratio": (
                raw_evidence["retained"] / raw_evidence["total"]
                if raw_evidence["total"]
                else None
            ),
            "coverage_ratio": (
                raw_evidence["mapped"] / raw_evidence["total"]
                if raw_evidence["total"]
                else None
            ),
        },
        "content_semantics": {
            **dict(content_semantics),
            "semantic_coverage_ratio": (
                content_semantics["model_bound"]
                / content_semantics["evidence"]
                if content_semantics["evidence"]
                else 1.0
            ),
            "accounting_ratio": (
                content_semantics["units"] / content_semantics["evidence"]
                if content_semantics["evidence"]
                else 1.0
            ),
        },
        "semantic_completion": {
            **dict(semantic_completion),
            "unavailable_cases": len(cases) - completion_available,
            "audit_completeness_ratio": audit_completeness_ratio,
            "source_semantically_verified_ratio": source_structured_ratio,
            "source_structured_ratio": source_structured_ratio,
            "source_requiring_review_ratio": source_requiring_review_ratio,
            "fact_status_verified_ratio": fact_status_verified_ratio,
            "semantic_fact_accuracy_evaluated": False,
            "semantic_fact_accuracy": None,
            "semantic_fact_accuracy_evaluation_reason": (
                "semantic_facts_not_annotated_in_gold"
            ),
            "deprecated_compatibility_fields": dict(
                _SEMANTIC_COMPLETION_DEPRECATED_COMPATIBILITY_FIELDS
            ),
            # Compatibility aliases. Structured/review coverage now has the
            # same source-only denominator as the explicit replacement fields.
            "evidence_accounting_ratio": audit_completeness_ratio,
            "evidence_structured_ratio": source_structured_ratio,
            "evidence_requiring_review_ratio": source_requiring_review_ratio,
            "fact_verified_ratio": fact_status_verified_ratio,
        },
        "source_assets": {
            **dict(source_assets),
            "inventory_ratio": (
                source_assets["complete_inventories"] / len(cases)
                if cases
                else None
            ),
            "analysis_ratio": (
                source_assets["analyzed"]
                / (source_assets["assets"] + source_assets["requirements"])
                if source_assets["assets"] + source_assets["requirements"]
                else 1.0
            ),
        },
        "performance": {
            "completed_case_count": len(elapsed),
            "p95_elapsed_ms": p95,
            "max_elapsed_ms": max(elapsed) if elapsed else None,
        },
    }


def _write(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _manifest(cases: list[Case]) -> dict[str, Any]:
    return {
        "schema_version": "m1.extractor-discovery.v1", "case_count": len(cases),
        "cases": [
            {
                "id": case.id,
                "sha256": case.sha256,
                "original_filename": case.path.name,
                "category": case.category,
                "size_bytes": case.size_bytes,
                "hints": {},
            }
            for case in cases
        ],
    }


def _strict_gold_summary(
    *,
    enabled: bool,
    configured: bool,
    gold: dict[str, Any] | None,
    cases: list[dict[str, Any]],
) -> dict[str, Any]:
    if not enabled:
        return {
            "enabled": False,
            "passed": None,
            "failure_count": 0,
            "failures": [],
        }

    failures: list[dict[str, Any]] = []

    def fail(code: str, **details: Any) -> None:
        failures.append({"code": code, **details})

    if not configured:
        fail("GOLD_NOT_CONFIGURED")
    if configured and gold is None:
        fail("GOLD_NOT_LOADED")
    if isinstance(gold, dict):
        gold_cases = [item for item in gold.get("cases") or [] if isinstance(item, dict)]
        if not gold_cases:
            fail("GOLD_CASES_EMPTY")
        if not cases:
            fail("SELECTED_CASES_EMPTY")
        declared_count = gold.get("case_count")
        if isinstance(declared_count, int) and declared_count != len(gold_cases):
            fail(
                "GOLD_CASE_COUNT_MISMATCH",
                declared=declared_count,
                actual=len(gold_cases),
            )
        gold_hashes = [str(item.get("sha256") or "").casefold() for item in gold_cases]
        missing_hash_ids = [
            str(item.get("id") or "unknown")
            for item, sha256 in zip(gold_cases, gold_hashes, strict=True)
            if not re.fullmatch(r"[0-9a-f]{64}", sha256)
        ]
        if missing_hash_ids:
            fail("GOLD_CASE_SHA256_MISSING_OR_INVALID", case_ids=missing_hash_ids)
        duplicate_hashes = sorted(
            sha256
            for sha256, count in Counter(gold_hashes).items()
            if sha256 and count > 1
        )
        if duplicate_hashes:
            fail("GOLD_CASE_SHA256_DUPLICATE", sha256=duplicate_hashes)
        selected_hashes = {str(item.get("sha256") or "").casefold() for item in cases}
        unselected = sorted(set(gold_hashes) - selected_hashes - {""})
        if unselected:
            fail("GOLD_CASE_NOT_SELECTED", sha256=unselected)

        for item in cases:
            case_id = str(item.get("id") or "unknown")
            candidate = item.get("candidate")
            candidate_status = (
                candidate.get("status") if isinstance(candidate, dict) else None
            )
            if candidate_status != "completed":
                failure = {
                    "case_id": case_id,
                    "candidate_status": candidate_status,
                }
                if isinstance(candidate, dict) and candidate.get("error_type"):
                    failure["error_type"] = str(candidate["error_type"])
                fail("CANDIDATE_NOT_COMPLETED", **failure)
            score = item.get("gold")
            if not isinstance(score, dict) or score.get("status") == "no_matching_gold":
                fail("SELECTED_CASE_MISSING_GOLD", case_id=case_id)
                continue
            if score.get("matched_by") != "sha256":
                fail(
                    "GOLD_CASE_NOT_SHA256_MATCHED",
                    case_id=case_id,
                    matched_by=score.get("matched_by"),
                )
            if score.get("status") == "candidate_not_scored":
                fail("GOLD_CASE_NOT_SCORED", case_id=case_id)
            fields = score.get("fields") or {}
            field_matched = int(fields.get("matched") or 0)
            field_total = int(fields.get("total") or 0)
            if field_matched != field_total:
                fail(
                    "LEGACY_GOLD_FIELD_MISMATCH",
                    case_id=case_id,
                    matched=field_matched,
                    total=field_total,
                    unmatched_paths=[
                        str(path) for path in fields.get("unmatched_paths") or []
                    ],
                )
            table_assertions = 0
            for table in score.get("tables") or []:
                if not isinstance(table, dict):
                    continue
                table_id = str(table.get("id") or "table")
                if table.get("expected_row_count") is not None:
                    table_assertions += 1
                    if table.get("row_count_match") is not True:
                        fail(
                            "GOLD_TABLE_ROW_COUNT_MISMATCH",
                            case_id=case_id,
                            table_id=table_id,
                            expected=table.get("expected_row_count"),
                            actual=table.get("actual_row_count"),
                        )
                compared_cells = int(table.get("compared_cells") or 0)
                table_assertions += compared_cells
                matched_cells = int(table.get("matched_cells") or 0)
                if matched_cells != compared_cells:
                    fail(
                        "GOLD_TABLE_CELL_MISMATCH",
                        case_id=case_id,
                        table_id=table_id,
                        matched=matched_cells,
                        total=compared_cells,
                    )
            semantic = score.get("semantic_gold")
            if not isinstance(semantic, dict):
                fail("SEMANTIC_GOLD_SCORE_MISSING", case_id=case_id)
                continue
            unconsumed = semantic.get("unconsumed_annotation_keys") or []
            if unconsumed:
                fail(
                    "GOLD_ANNOTATION_KEYS_UNCONSUMED",
                    case_id=case_id,
                    keys=sorted(str(key) for key in unconsumed),
                )
            annotation_errors = semantic.get("annotation_errors") or []
            if annotation_errors:
                fail(
                    "GOLD_ANNOTATION_INVALID",
                    case_id=case_id,
                    errors=[str(error) for error in annotation_errors],
                )
            matched = int(semantic.get("matched") or 0)
            total = int(semantic.get("total") or 0)
            if field_total + table_assertions + total == 0:
                fail("GOLD_CASE_WITHOUT_ASSERTIONS", case_id=case_id)
            if matched != total:
                fail(
                    "SEMANTIC_GOLD_MISMATCH",
                    case_id=case_id,
                    matched=matched,
                    total=total,
                    unmatched_annotations=[
                        str(annotation)
                        for annotation in semantic.get("unmatched_annotations") or []
                    ],
                )

    return {
        "enabled": True,
        "passed": not failures,
        "failure_count": len(failures),
        "failures": failures,
    }


def _run(args: argparse.Namespace) -> dict[str, Any]:
    cases, issues, discovered = _discover(args)
    candidate_replay_dir = getattr(args, "candidate_replay_dir", None)
    strict_requested = bool(getattr(args, "strict_gold", False))
    gold = None
    gold_error = None
    if args.gold:
        try:
            gold = json.loads(args.gold.read_text(encoding="utf-8"))
            if not isinstance(gold, dict):
                raise ValueError("gold root is not an object")  # noqa: TRY004
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            gold_error = type(exc).__name__
    strict_gold_unavailable = strict_requested and gold is None
    output_cases: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="m1-extractor-benchmark-") as temporary:
        for case in cases:
            gold_case = _gold_case(case, gold)
            item: dict[str, Any] = {
                "id": case.id,
                "sha256": case.sha256,
                "original_filename": case.path.name,
                "category": case.category,
                "source_kind": case.source_kind,
                "size_bytes": case.size_bytes,
            }
            if (
                not args.candidate_command
                and not candidate_replay_dir
                or args.dry_run
                or strict_gold_unavailable
            ):
                item["candidate"] = {
                    "status": "not_run",
                    **(
                        {"reason": "strict_gold_unavailable"}
                        if strict_gold_unavailable
                        else {}
                    ),
                }
                item["gold"] = _score_gold(None, gold_case)
            else:
                candidate_output, candidate = _run_candidate(
                    case,
                    args,
                    Path(temporary),
                )
                item["candidate"] = candidate
                if candidate_output is not None:
                    record = candidate_output.record
                    item["candidate_overview"] = _overview(record)
                    item["source_coverage"] = _coverage(record)
                    item["gold"] = _score_gold(
                        record,
                        gold_case,
                        payload=candidate_output.payload,
                    )
                else:
                    item["gold"] = _score_gold(None, gold_case)
            item["gold"]["matched_by"] = _gold_match_kind(case, gold_case)
            key_gold = _key_gold_evaluation(item["gold"])
            item["key_gold_status"] = key_gold["status"]
            item["key_gold_passed"] = key_gold["passed"]
            item["key_gold_evaluation"] = key_gold
            full_evidence = _full_evidence_evaluation(
                item.get("candidate_overview")
            )
            item["full_evidence_status"] = full_evidence["status"]
            item["full_evidence_passed"] = full_evidence["passed"]
            item["full_evidence_evaluation"] = full_evidence
            output_cases.append(item)
    strict_gold = _strict_gold_summary(
        enabled=strict_requested,
        configured=bool(args.gold),
        gold=gold,
        cases=output_cases,
    )
    key_gold_values = [item["key_gold_passed"] for item in output_cases]
    full_evidence_values = [item["full_evidence_passed"] for item in output_cases]

    def gate_summary(values: list[bool | None]) -> dict[str, Any]:
        if any(value is False for value in values):
            status = "failed"
            passed = False
        elif not values or any(value is None for value in values):
            status = "not_available"
            passed = None
        else:
            passed = True
            status = "passed"
        return {
            "status": status,
            "passed": passed,
            "passed_cases": sum(value is True for value in values),
            "failed_cases": sum(value is False for value in values),
            "not_available_cases": sum(value is None for value in values),
        }

    report = {
        "schema_version": "m1.extractor-benchmark.v1", "generated_at_utc": datetime.now(UTC).isoformat(),
        "privacy": {"raw_candidate_values_in_report": False, "absolute_source_paths_in_report": False},
        "discovery": {
            "target_case_count": args.limit,
            "discovered_supported_file_count": discovered,
            "selected_case_count": len(cases),
            "issues": issues,
        },
        "candidate": {
            "configured": bool(
                args.candidate_command or candidate_replay_dir
            ),
            "dry_run": bool(args.dry_run),
            "output_mode": (
                "replay"
                if candidate_replay_dir
                else args.candidate_output_mode
                if args.candidate_command
                else None
            ),
            "timeout_seconds": (
                args.timeout_seconds if args.candidate_command else None
            ),
        },
        "gold": {
            "configured": bool(args.gold),
            "loaded": gold is not None,
            "schema_version": gold.get("schema_version") if gold else None,
            "load_error": gold_error,
            "strict": strict_gold,
        },
        "quality_gates": {
            "key_gold": gate_summary(key_gold_values),
            "full_evidence": gate_summary(full_evidence_values),
        },
        "aggregate": _aggregate(output_cases), "cases": output_cases,
    }
    if args.manifest_out:
        _write(args.manifest_out, _manifest(cases))
        report["discovery_manifest"] = args.manifest_out.name
    return report


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read-only 20-sample extractor benchmark.")
    parser.add_argument("--production-root", action="append", type=Path, help="Production source root; repeatable.")
    parser.add_argument(
        "--expanded-root",
        action="append",
        type=Path,
        help="Optional expanded corpus root; repeatable.",
    )
    parser.add_argument("--sample", action="append", type=Path, help="Extra named sample; repeatable.")
    parser.add_argument(
        "--no-default-samples",
        action="store_true",
        help="Exclude built-in named regression samples; use only explicit --sample values and roots.",
    )
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--max-file-mib", type=float, default=64.0)
    parser.add_argument("--candidate-command", help="Shell template containing {input}; may use {output}.")
    parser.add_argument(
        "--candidate-replay-dir",
        type=Path,
        help=(
            "Read precomputed <case-id>.json outputs after validating each "
            "record source SHA-256; candidate timing comes from timing.total_ms."
        ),
    )
    parser.add_argument("--candidate-output-mode", choices=("auto", "stdout", "file"), default="auto")
    parser.add_argument("--timeout-seconds", type=float, default=240.0)
    parser.add_argument("--gold", type=Path, help="Optional sidecar gold JSON.")
    parser.add_argument(
        "--strict-gold",
        action="store_true",
        help=(
            "Fail after writing the report when gold is unavailable, a selected "
            "case is not completed/SHA-matched/scored, an annotation key is "
            "unconsumed, or any semantic assertion is unmatched."
        ),
    )
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    parser.add_argument("--manifest-out", type=Path, help="Write selected-sample annotation skeleton.")
    parser.add_argument("--dry-run", action="store_true", help="Do not invoke a configured candidate command.")
    return parser


def main() -> None:
    args = _parser().parse_args()
    if args.limit <= 0 or args.max_file_mib <= 0 or args.timeout_seconds <= 0:
        raise SystemExit("--limit, --max-file-mib, and --timeout-seconds must be positive")
    if args.candidate_command and "{input}" not in args.candidate_command:
        raise SystemExit("--candidate-command must contain {input}")
    if args.candidate_command and args.candidate_replay_dir:
        raise SystemExit(
            "--candidate-command and --candidate-replay-dir are mutually exclusive"
        )
    if args.candidate_replay_dir and not args.candidate_replay_dir.is_dir():
        raise SystemExit("--candidate-replay-dir must be an existing directory")
    if (
        args.candidate_output_mode == "file"
        and args.candidate_command
        and "{output}" not in args.candidate_command
    ):
        raise SystemExit("file output mode requires {output} in --candidate-command")
    report = _run(args)
    _write(args.report, report)
    print(
        json.dumps(
            {
                "report": str(args.report),
                "selected_case_count": report["discovery"]["selected_case_count"],
                "candidate_configured": report["candidate"]["configured"],
                "strict_gold_passed": report["gold"]["strict"]["passed"],
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    strict = report["gold"]["strict"]
    if strict["enabled"] and not strict["passed"]:
        codes = sorted({failure["code"] for failure in strict["failures"]})
        raise SystemExit(
            "strict gold validation failed: "
            f"{strict['failure_count']} failure(s); codes={','.join(codes)}; "
            f"report={args.report}"
        )


if __name__ == "__main__":
    main()
