#!/usr/bin/env python3
"""Create and verify an offline M1 model asset bundle.

The bundle is intentionally external to Git, Docker images, and the source
DEB.  Every regular file (including license evidence) is recorded by size and
SHA-256.  Symlinks are rejected so the read-only production mount cannot
escape the verified bundle root.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import tarfile
from pathlib import Path, PurePosixPath
from typing import Any


MANIFEST_NAME = "model-assets.manifest.json"
SPEC_SCHEMA = "m1.model-asset-spec.v1"
MANIFEST_SCHEMA = "m1.model-asset-manifest.v1"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class BundleError(ValueError):
    """Raised when a bundle or its specification violates the contract."""


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BundleError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise BundleError(f"JSON root must be an object: {path}")
    return value


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _canonical_json(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def _relative_path(raw: object, *, label: str) -> PurePosixPath:
    if not isinstance(raw, str) or not raw.strip():
        raise BundleError(f"{label} must be a non-empty relative path")
    path = PurePosixPath(raw)
    if path.is_absolute() or ".." in path.parts or "." in path.parts:
        raise BundleError(f"unsafe {label}: {raw!r}")
    return path


def validate_spec(spec: dict[str, Any]) -> None:
    if spec.get("schema_version") != SPEC_SCHEMA:
        raise BundleError(f"unsupported spec schema: {spec.get('schema_version')!r}")
    if spec.get("runtime_downloads_allowed") is not False:
        raise BundleError("full runtime bundle must forbid runtime downloads")
    bundle_id = spec.get("bundle_id")
    if not isinstance(bundle_id, str) or not re.fullmatch(r"[A-Za-z0-9._-]+", bundle_id):
        raise BundleError("bundle_id must contain only letters, digits, dot, underscore, hyphen")
    components = spec.get("components")
    if not isinstance(components, list) or not components:
        raise BundleError("spec must declare at least one component")
    required_manifests = spec.get("required_manifests")
    if not isinstance(required_manifests, list) or not required_manifests:
        raise BundleError("spec must declare at least one required model manifest")
    for index, required_manifest in enumerate(required_manifests):
        if not isinstance(required_manifest, dict):
            raise BundleError(f"required_manifests[{index}] must be an object")
        _relative_path(
            required_manifest.get("path"),
            label=f"required_manifests[{index}].path",
        )
        if not isinstance(required_manifest.get("schema_version"), str):
            raise BundleError(f"required_manifests[{index}].schema_version is required")
        if required_manifest.get("complete") is not True:
            raise BundleError(f"required_manifests[{index}] must require complete=true")
        if not isinstance(required_manifest.get("artifact_list_key"), str):
            raise BundleError(f"required_manifests[{index}].artifact_list_key is required")
    seen: set[str] = set()
    for index, component in enumerate(components):
        if not isinstance(component, dict):
            raise BundleError(f"components[{index}] must be an object")
        component_id = component.get("id")
        if not isinstance(component_id, str) or not component_id:
            raise BundleError(f"components[{index}].id is required")
        if component_id in seen:
            raise BundleError(f"duplicate component id: {component_id}")
        seen.add(component_id)
        if not isinstance(component.get("name"), str) or not component["name"]:
            raise BundleError(f"component {component_id} name is required")
        if not isinstance(component.get("version"), str) or not component["version"]:
            raise BundleError(f"component {component_id} version is required")
        roots = component.get("asset_roots")
        if not isinstance(roots, list) or not roots:
            raise BundleError(f"component {component_id} must declare asset_roots")
        for root in roots:
            _relative_path(root, label=f"component {component_id} asset root")
        license_info = component.get("license")
        if not isinstance(license_info, dict):
            raise BundleError(f"component {component_id} license is required")
        spdx_id = license_info.get("spdx_id")
        source = license_info.get("source")
        if not isinstance(spdx_id, str) or not spdx_id:
            raise BundleError(f"component {component_id} SPDX id is required")
        if not isinstance(source, str) or not source.startswith("https://"):
            raise BundleError(f"component {component_id} license source must be HTTPS")
        _relative_path(
            license_info.get("evidence_file"),
            label=f"component {component_id} license evidence",
        )


def _resolve(root: Path, relative: PurePosixPath) -> Path:
    candidate = root.joinpath(*relative.parts)
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise BundleError(f"path escapes bundle root: {relative}") from exc
    return candidate


def _regular_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for directory, directory_names, file_names in os.walk(root, followlinks=False):
        current = Path(directory)
        for name in tuple(directory_names):
            path = current / name
            if path.is_symlink():
                raise BundleError(f"symlinked directories are forbidden: {path}")
        for name in file_names:
            path = current / name
            if path.name == MANIFEST_NAME and path.parent == root:
                continue
            if path.is_symlink() or not path.is_file():
                raise BundleError(f"only regular files are allowed: {path}")
            files.append(path)
    return sorted(files, key=lambda value: value.relative_to(root).as_posix())


def _copy_regular_tree(source: Path, destination: Path) -> tuple[int, int]:
    """Materialize one model tree, preferring hardlinks without keeping links."""

    if not source.is_dir() or source.is_symlink():
        raise BundleError(f"model source must be a real directory: {source}")
    copied = 0
    linked = 0
    for path in source.rglob("*"):
        relative = path.relative_to(source)
        target = destination / relative
        if path.is_symlink():
            raise BundleError(f"model source symlink is forbidden: {path}")
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        if not path.is_file():
            raise BundleError(f"model source contains a non-regular file: {path}")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if target.stat().st_size != path.stat().st_size or _sha256_file(target) != _sha256_file(path):
                raise BundleError(f"conflicting staged model artifact: {target}")
            continue
        try:
            os.link(path, target)
            linked += 1
        except OSError:
            shutil.copy2(path, target)
            copied += 1
    return linked, copied


def stage_bundle(
    destination: Path,
    parser_cache: Path,
    embedding_cache: Path,
    parser_manifest: Path,
    bge_license: Path,
    spec_path: Path,
) -> dict[str, Any]:
    """Build the canonical layout from the existing private cache locations."""

    destination = destination.resolve()
    parser_cache = parser_cache.resolve()
    embedding_cache = embedding_cache.resolve()
    parser_manifest = parser_manifest.resolve()
    bge_license = bge_license.resolve()
    spec_path = spec_path.resolve()
    spec = _load_json(spec_path)
    validate_spec(spec)
    if destination.exists() and any(destination.iterdir()):
        raise BundleError(f"stage destination must be empty: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    linked = 0
    copied = 0
    staged_roots: set[str] = set()
    for component in spec["components"]:
        for raw_root in component["asset_roots"]:
            relative = _relative_path(raw_root, label="asset root")
            relative_text = relative.as_posix()
            if relative_text in staged_roots:
                continue
            staged_roots.add(relative_text)
            if relative.parts[0] == "paddlex":
                source = parser_cache.joinpath(*relative.parts[1:])
            elif relative_text == "embedding/BAAI-bge-m3":
                source = embedding_cache
            else:
                raise BundleError(f"stage has no source mapping for: {relative_text}")
            target = destination.joinpath(*relative.parts)
            target.mkdir(parents=True, exist_ok=True)
            root_linked, root_copied = _copy_regular_tree(source, target)
            linked += root_linked
            copied += root_copied
    nested_target = destination / "paddlex" / "document-parser-models.json"
    nested_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(parser_manifest, nested_target)
    license_target = destination / "licenses" / "BAAI-bge-m3-MIT.txt"
    license_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(bge_license, license_target)
    manifest_path = write_manifest(destination, spec_path)
    verification = verify_manifest(destination, spec_path)
    return {
        **verification,
        "manifest": str(manifest_path),
        "hardlinked_files": linked,
        "copied_files": copied + 2,
    }


def _validate_bundle_layout(root: Path, spec: dict[str, Any]) -> None:
    if not root.is_dir() or root.is_symlink():
        raise BundleError(f"bundle root must be a real directory: {root}")
    for component in spec["components"]:
        component_id = component["id"]
        for raw_root in component["asset_roots"]:
            relative = _relative_path(raw_root, label=f"component {component_id} asset root")
            asset_root = _resolve(root, relative)
            if not asset_root.is_dir() or asset_root.is_symlink():
                raise BundleError(f"missing asset root for {component_id}: {relative}")
            if not any(path.is_file() for path in asset_root.rglob("*")):
                raise BundleError(f"empty asset root for {component_id}: {relative}")
        evidence_relative = _relative_path(
            component["license"]["evidence_file"],
            label=f"component {component_id} license evidence",
        )
        evidence = _resolve(root, evidence_relative)
        if not evidence.is_file() or evidence.is_symlink() or evidence.stat().st_size == 0:
            raise BundleError(f"missing license evidence for {component_id}: {evidence_relative}")
    _validate_required_manifests(root, spec)


def _validate_required_manifests(root: Path, spec: dict[str, Any]) -> None:
    """Verify parser cache metadata and every artifact recorded inside it."""

    for requirement in spec["required_manifests"]:
        relative = _relative_path(requirement["path"], label="required model manifest")
        manifest_path = _resolve(root, relative)
        if not manifest_path.is_file() or manifest_path.is_symlink():
            raise BundleError(f"missing required model manifest: {relative}")
        nested = _load_json(manifest_path)
        if nested.get("schema_version") != requirement["schema_version"]:
            raise BundleError(f"nested model manifest schema mismatch: {relative}")
        if nested.get("complete") is not True:
            raise BundleError(f"nested model manifest is incomplete: {relative}")
        pipelines = nested.get("pipelines")
        if not isinstance(pipelines, dict) or not pipelines:
            raise BundleError(f"nested model manifest has no pipelines: {relative}")
        for pipeline_name, pipeline in pipelines.items():
            if not isinstance(pipeline, dict) or pipeline.get("complete") is not True:
                raise BundleError(f"incomplete nested pipeline {pipeline_name}: {relative}")
            missing = pipeline.get("missing_models", [])
            if missing:
                raise BundleError(f"nested pipeline {pipeline_name} has missing models: {missing}")
        artifact_key = requirement["artifact_list_key"]
        artifacts = nested.get(artifact_key)
        if not isinstance(artifacts, list) or not artifacts:
            raise BundleError(f"nested model manifest has no {artifact_key}: {relative}")
        nested_root = manifest_path.parent
        seen: set[str] = set()
        for index, artifact in enumerate(artifacts):
            if not isinstance(artifact, dict):
                raise BundleError(f"nested {artifact_key}[{index}] must be an object")
            artifact_relative = _relative_path(
                artifact.get("path"),
                label=f"nested {artifact_key}[{index}].path",
            )
            artifact_text = artifact_relative.as_posix()
            if artifact_text in seen:
                raise BundleError(f"duplicate nested model artifact: {artifact_text}")
            seen.add(artifact_text)
            path = _resolve(nested_root, artifact_relative)
            if not path.is_file() or path.is_symlink():
                raise BundleError(f"missing nested model artifact: {artifact_text}")
            size = artifact.get("size_bytes")
            digest = artifact.get("sha256")
            if not isinstance(size, int) or path.stat().st_size != size:
                raise BundleError(f"nested model artifact size mismatch: {artifact_text}")
            if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
                raise BundleError(f"invalid nested model artifact SHA-256: {artifact_text}")
            if _sha256_file(path) != digest:
                raise BundleError(f"nested model artifact SHA-256 mismatch: {artifact_text}")


def create_manifest(root: Path, spec_path: Path) -> dict[str, Any]:
    root = root.resolve()
    spec_path = spec_path.resolve()
    spec = _load_json(spec_path)
    validate_spec(spec)
    _validate_bundle_layout(root, spec)
    files = _regular_files(root)
    artifacts = []
    total_size = 0
    for path in files:
        relative = path.relative_to(root).as_posix()
        size = path.stat().st_size
        artifacts.append({"path": relative, "size_bytes": size, "sha256": _sha256_file(path)})
        total_size += size
    spec_digest = _sha256_bytes(_canonical_json(spec))
    manifest: dict[str, Any] = {
        "schema_version": MANIFEST_SCHEMA,
        "bundle_id": spec["bundle_id"],
        "complete": True,
        "runtime_downloads_allowed": False,
        "created_at": dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z"),
        "spec_sha256": spec_digest,
        "components": spec["components"],
        "artifact_count": len(artifacts),
        "total_size_bytes": total_size,
        "artifacts": artifacts,
    }
    manifest["manifest_payload_sha256"] = _sha256_bytes(_canonical_json(manifest))
    return manifest


def write_manifest(root: Path, spec_path: Path) -> Path:
    manifest = create_manifest(root, spec_path)
    destination = root.resolve() / MANIFEST_NAME
    destination.write_bytes(_canonical_json(manifest))
    return destination


def verify_manifest(root: Path, spec_path: Path, *, strict: bool = True) -> dict[str, Any]:
    root = root.resolve()
    spec = _load_json(spec_path.resolve())
    validate_spec(spec)
    _validate_bundle_layout(root, spec)
    manifest_path = root / MANIFEST_NAME
    manifest = _load_json(manifest_path)
    if manifest.get("schema_version") != MANIFEST_SCHEMA or manifest.get("complete") is not True:
        raise BundleError("asset manifest is incomplete or uses an unsupported schema")
    if manifest.get("runtime_downloads_allowed") is not False:
        raise BundleError("asset manifest must forbid runtime downloads")
    if manifest.get("bundle_id") != spec["bundle_id"]:
        raise BundleError("bundle_id does not match the checked-in specification")
    expected_spec_hash = _sha256_bytes(_canonical_json(spec))
    if manifest.get("spec_sha256") != expected_spec_hash:
        raise BundleError("asset manifest was generated from a different specification")
    manifest_copy = dict(manifest)
    payload_hash = manifest_copy.pop("manifest_payload_sha256", None)
    if not isinstance(payload_hash, str) or not SHA256_RE.fullmatch(payload_hash):
        raise BundleError("manifest payload SHA-256 is missing or malformed")
    if _sha256_bytes(_canonical_json(manifest_copy)) != payload_hash:
        raise BundleError("manifest payload SHA-256 mismatch")
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or not artifacts:
        raise BundleError("manifest contains no artifacts")
    expected_paths: set[str] = set()
    total_size = 0
    for index, artifact in enumerate(artifacts):
        if not isinstance(artifact, dict):
            raise BundleError(f"artifacts[{index}] must be an object")
        relative = _relative_path(artifact.get("path"), label=f"artifacts[{index}].path")
        relative_text = relative.as_posix()
        if relative_text in expected_paths:
            raise BundleError(f"duplicate artifact path: {relative_text}")
        expected_paths.add(relative_text)
        path = _resolve(root, relative)
        if not path.is_file() or path.is_symlink():
            raise BundleError(f"missing regular artifact: {relative_text}")
        size = artifact.get("size_bytes")
        digest = artifact.get("sha256")
        if not isinstance(size, int) or size < 0 or path.stat().st_size != size:
            raise BundleError(f"artifact size mismatch: {relative_text}")
        if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
            raise BundleError(f"invalid artifact SHA-256: {relative_text}")
        if _sha256_file(path) != digest:
            raise BundleError(f"artifact SHA-256 mismatch: {relative_text}")
        total_size += size
    if manifest.get("artifact_count") != len(artifacts):
        raise BundleError("artifact_count does not match manifest entries")
    if manifest.get("total_size_bytes") != total_size:
        raise BundleError("total_size_bytes does not match manifest entries")
    if manifest.get("components") != spec["components"]:
        raise BundleError("component or license metadata differs from the specification")
    if strict:
        actual_paths = {
            path.relative_to(root).as_posix()
            for path in _regular_files(root)
        }
        if actual_paths != expected_paths:
            missing = sorted(expected_paths - actual_paths)
            extra = sorted(actual_paths - expected_paths)
            raise BundleError(f"bundle file set mismatch: missing={missing}, extra={extra}")
    return {
        "status": "verified",
        "bundle_id": manifest["bundle_id"],
        "artifact_count": len(artifacts),
        "total_size_bytes": total_size,
        "strict": strict,
    }


def create_archive(root: Path, archive: Path) -> Path:
    root = root.resolve()
    if not (root / MANIFEST_NAME).is_file():
        raise BundleError(f"create and verify {MANIFEST_NAME} before archiving")
    archive = archive.resolve()
    archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, mode="w:gz", compresslevel=1, format=tarfile.PAX_FORMAT) as output:
        for path in [root / MANIFEST_NAME, *_regular_files(root)]:
            relative = path.relative_to(root).as_posix()
            info = output.gettarinfo(str(path), arcname=relative)
            info.uid = 0
            info.gid = 0
            info.uname = "root"
            info.gname = "root"
            info.mtime = 0
            with path.open("rb") as stream:
                output.addfile(info, stream)
    checksum_path = archive.with_name(archive.name + ".sha256")
    checksum_path.write_text(f"{_sha256_file(archive)}  {archive.name}\n", encoding="ascii")
    return archive


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    spec_parser = subparsers.add_parser("verify-spec", help="validate the checked-in bundle specification")
    spec_parser.add_argument("--spec", type=Path, required=True)
    create_parser = subparsers.add_parser("create", help="hash a curated model root and write its manifest")
    create_parser.add_argument("--root", type=Path, required=True)
    create_parser.add_argument("--spec", type=Path, required=True)
    create_parser.add_argument("--archive", type=Path)
    stage_parser = subparsers.add_parser(
        "stage",
        help="materialize the canonical bundle layout from existing private caches",
    )
    stage_parser.add_argument("--destination", type=Path, required=True)
    stage_parser.add_argument("--parser-cache", type=Path, required=True)
    stage_parser.add_argument("--embedding-cache", type=Path, required=True)
    stage_parser.add_argument("--parser-manifest", type=Path, required=True)
    stage_parser.add_argument("--spec", type=Path, required=True)
    stage_parser.add_argument(
        "--bge-license",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "models"
        / "licenses"
        / "BAAI-bge-m3-MIT.txt",
    )
    stage_parser.add_argument("--archive", type=Path)
    verify_parser = subparsers.add_parser("verify", help="verify every artifact, license, and manifest field")
    verify_parser.add_argument("--root", type=Path, required=True)
    verify_parser.add_argument("--spec", type=Path, required=True)
    verify_parser.add_argument("--no-strict", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    try:
        if args.command == "verify-spec":
            spec = _load_json(args.spec.resolve())
            validate_spec(spec)
            result: dict[str, Any] = {
                "status": "valid",
                "bundle_id": spec["bundle_id"],
                "component_count": len(spec["components"]),
            }
        elif args.command == "create":
            manifest_path = write_manifest(args.root, args.spec)
            result = verify_manifest(args.root, args.spec)
            result["manifest"] = str(manifest_path)
            if args.archive:
                result["archive"] = str(create_archive(args.root, args.archive))
        elif args.command == "stage":
            result = stage_bundle(
                args.destination,
                args.parser_cache,
                args.embedding_cache,
                args.parser_manifest,
                args.bge_license,
                args.spec,
            )
            if args.archive:
                result["archive"] = str(create_archive(args.destination, args.archive))
        else:
            result = verify_manifest(args.root, args.spec, strict=not args.no_strict)
    except BundleError as exc:
        raise SystemExit(f"model asset verification failed: {exc}") from exc
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
