"""Run a read-only MinerU full-authority candidate probe.

This command intentionally avoids FastAPI, TaskStore, knowledge persistence,
and outbox delivery. It is for an isolated GPU canary only.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
from pathlib import Path
from typing import Any

from m1.core.config import Settings
from m1.documents.magic import sniff_file_type
from m1.documents.parsing.mineru_authority import (
    authority_document_digest,
    evaluate_mineru_authority,
)
from m1.documents.parsing.mineru_shadow import build_mineru_shadow_runner

_SUMMARY_FIELDS = (
    "mineru_elapsed_ms",
    "mapper_elapsed_ms",
    "total_elapsed_ms",
    "mapper_requests",
    "mapper_repaired_mappings",
    "mapper_initial_dropped_mappings",
    "mapper_initial_dropped_tables",
    "mapper_unresolved_dropped_mappings",
    "mapper_unresolved_dropped_tables",
    "mapper_dropped_facts",
    "mapper_invalid_facts",
    "rejected_citations",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _source_seed(path: Path, file_type: str, sha256: str) -> dict[str, Any]:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": path.name,
            "sha256": sha256,
        },
        "document_type": "unknown",
        "document_subtype": "unknown",
        "header": {},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
        "extraction": {
            "metadata": {
                "adapter": "mineru_canary_source_seed",
                "authority_mode": "full",
                "file_type": file_type,
            }
        },
    }


def _safe_summary(summary: dict[str, Any]) -> dict[str, Any]:
    safe = {
        key: summary[key]
        for key in _SUMMARY_FIELDS
        if key in summary and isinstance(summary[key], (str, int, float, bool))
    }
    regions = summary.get("record_region_assessment")
    if isinstance(regions, dict):
        safe["record_regions"] = {
            "status": regions.get("status"),
            "record_region_count": len(regions.get("record_regions") or []),
            "no_record_table_count": len(regions.get("no_record_table_ids") or []),
            "inconclusive_table_count": len(
                regions.get("inconclusive_table_ids") or []
            ),
            "mapped_region_count": len(regions.get("mapped_region_ids") or []),
            "unmapped_region_count": len(regions.get("unmapped_region_ids") or []),
            "fabricated_region_count": len(regions.get("fabricated_region_ids") or []),
            "cross_region_count": len(regions.get("cross_region_ids") or []),
            "overlapping_region_count": len(
                regions.get("overlapping_region_ids") or []
            ),
            "assessment_reasons": list(regions.get("reasons") or []),
        }
    return safe


async def _run(paths: list[Path]) -> dict[str, Any]:
    settings = Settings()
    runner = build_mineru_shadow_runner(settings)
    if runner is None:
        raise RuntimeError("MinerU candidate runner is disabled")

    try:
        probe = await runner.probe()
        cases: list[dict[str, Any]] = []
        for path in paths:
            file_type = sniff_file_type(path).kind
            source_sha256 = _sha256(path)
            seed = _source_seed(path, file_type, source_sha256)
            try:
                result = await runner.run_candidate(
                    task_id=f"canary-{source_sha256[:24]}",
                    path=path,
                    original_filename=path.name,
                    file_type=file_type,
                    authoritative=seed,
                )
                decision = evaluate_mineru_authority(
                    result.document,
                    result.summary,
                    baseline=seed,
                    authority_mode="full",
                )
                document = result.document.model_dump(mode="json")
                cases.append(
                    {
                        "source_sha256": source_sha256,
                        "file_type": file_type,
                        "document_type": document.get("document_type"),
                        "document_subtype": document.get("document_subtype"),
                        "line_count": len(document.get("lines") or []),
                        "header_fields": sorted(
                            key
                            for key, value in (document.get("header") or {}).items()
                            if value not in (None, "", [], {})
                        ),
                        "validation_issue_codes": sorted(
                            {
                                str(issue.get("code"))
                                for issue in document.get("validation_issues") or []
                                if isinstance(issue, dict) and issue.get("code")
                            }
                        ),
                        "authority_gate": decision.summary(),
                        "timing": _safe_summary(result.summary),
                        "document_sha256": authority_document_digest(document),
                    }
                )
            except Exception as exc:  # noqa: BLE001 - preserve every case outcome
                cases.append(
                    {
                        "source_sha256": source_sha256,
                        "file_type": file_type,
                        "error_type": exc.__class__.__name__,
                    }
                )
        return {
            "schema_version": "m1.mineru-canary.v1",
            "probe_ready": bool(probe.get("ready", False)),
            "case_count": len(cases),
            "cases": cases,
        }
    finally:
        await runner.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    args = parser.parse_args()
    paths = [path.resolve() for path in args.inputs]
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        raise SystemExit(f"canary inputs must be files: {', '.join(missing)}")
    print(json.dumps(asyncio.run(_run(paths)), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
