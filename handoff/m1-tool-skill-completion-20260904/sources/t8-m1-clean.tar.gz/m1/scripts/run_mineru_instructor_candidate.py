"""CLI wrapper for the production MinerU Instructor candidate service."""

from __future__ import annotations

from m1.documents.parsing.mineru_instructor_service import main, run_candidate

__all__ = ["main", "run_candidate"]


if __name__ == "__main__":
    raise SystemExit(main())
