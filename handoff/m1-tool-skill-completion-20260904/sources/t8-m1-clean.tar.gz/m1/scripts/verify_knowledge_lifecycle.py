"""Black-box verification of M1 knowledge and projection deletion lifecycle.

The script mutates data only through public HTTP contracts. It creates one
synthetic inventory CSV containing an opaque marker, uses a direct read-only
Neo4j query to prove the authoritative projection, deletes the M1 task, and
proves that authoritative and optional shadow projections converge before a
hard deadline.

Remote targets are rejected unless ``--allow-remote`` is explicitly supplied.
This makes an accidental production invocation fail before any HTTP request is
sent.
"""

from __future__ import annotations

import argparse
import asyncio
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from typing import Any
from urllib.parse import urlsplit
from uuid import uuid4

import httpx


SCHEMA_VERSION = "m1.knowledge-lifecycle-verification.v1"
DEFAULT_BASE_URL = "http://127.0.0.1:8080"
LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1"})
NEO4J_SCHEMES = frozenset(
    {"bolt", "bolt+s", "bolt+ssc", "neo4j", "neo4j+s", "neo4j+ssc"}
)
TERMINAL_TASK_STATUSES = frozenset({"done", "failed", "needs_review"})


class UnsafeTargetError(ValueError):
    """Raised before I/O when a target does not satisfy the local-only policy."""


class LifecycleVerificationError(RuntimeError):
    """Safe, structured lifecycle failure that never carries credentials."""

    def __init__(
        self,
        code: str,
        phase: str,
        *,
        marker: str = "",
        task_id: str = "",
        detail: str = "",
        observed: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(code)
        self.code = code
        self.phase = phase
        self.marker = marker
        self.task_id = task_id
        self.detail = detail
        self.observed = dict(observed or {})

    def report(self) -> dict[str, Any]:
        error: dict[str, str] = {"code": self.code, "phase": self.phase}
        if self.detail:
            error["detail"] = self.detail
        report = {
            "schema_version": SCHEMA_VERSION,
            "status": "failed",
            "marker": self.marker or None,
            "task_id": self.task_id or None,
            "error": error,
        }
        if self.observed:
            report["observed"] = self.observed
        return report


@dataclass(frozen=True, slots=True)
class VerificationConfig:
    base_url: str = DEFAULT_BASE_URL
    api_key: str = ""
    tenant_id: str = "default"
    allow_remote: bool = False
    confirm_destructive_target: str = ""
    visibility_timeout_seconds: float = 120.0
    deletion_timeout_seconds: float = 120.0
    poll_interval_seconds: float = 2.0
    request_timeout_seconds: float = 30.0
    outbox_oldest_max_seconds: float = 60.0
    lightrag_base_url: str = ""
    lightrag_api_key: str = ""
    lightrag_workspace: str = "m1-shadow"
    neo4j_uri: str = ""
    neo4j_username: str = "neo4j"
    neo4j_password: str = ""
    neo4j_database: str = "neo4j"

    def __post_init__(self) -> None:
        if not self.tenant_id.strip():
            raise ValueError("tenant_id must not be empty")
        for name in (
            "visibility_timeout_seconds",
            "deletion_timeout_seconds",
            "poll_interval_seconds",
            "request_timeout_seconds",
            "outbox_oldest_max_seconds",
        ):
            if float(getattr(self, name)) <= 0:
                raise ValueError(f"{name} must be greater than zero")


def validate_target_url(value: str, *, allow_remote: bool) -> str:
    """Normalize a target and enforce the default local-only safety boundary."""

    candidate = value.strip()
    parsed = urlsplit(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise UnsafeTargetError("target must be an absolute http(s) URL")
    if parsed.username is not None or parsed.password is not None:
        raise UnsafeTargetError("credentials are not allowed in target URLs")
    if parsed.query or parsed.fragment:
        raise UnsafeTargetError("target URLs must not contain query or fragment data")
    host = parsed.hostname.casefold()
    if not allow_remote and host not in LOOPBACK_HOSTS:
        raise UnsafeTargetError(
            "remote target refused; pass --allow-remote only for an intentional run"
        )
    return candidate.rstrip("/") + "/"


def validate_destructive_target(
    value: str, *, allow_remote: bool, confirmation: str
) -> str:
    """Require an exact second acknowledgement before remote mutation."""

    normalized = validate_target_url(value, allow_remote=allow_remote)
    if urlsplit(normalized).hostname.casefold() not in LOOPBACK_HOSTS:
        confirmed = confirmation.strip().rstrip("/") + "/"
        if confirmed != normalized:
            raise UnsafeTargetError(
                "remote mutation requires --confirm-destructive-target equal to base URL"
            )
    return normalized


def validate_neo4j_uri(value: str, *, allow_remote: bool) -> str:
    candidate = value.strip()
    parsed = urlsplit(candidate)
    if parsed.scheme not in NEO4J_SCHEMES or not parsed.hostname:
        raise UnsafeTargetError("Neo4j URI must be an absolute bolt/neo4j URI")
    if parsed.username is not None or parsed.password is not None:
        raise UnsafeTargetError("credentials are not allowed in Neo4j URI")
    if parsed.query or parsed.fragment:
        raise UnsafeTargetError("Neo4j URI must not contain query or fragment data")
    if not allow_remote and parsed.hostname.casefold() not in LOOPBACK_HOSTS:
        raise UnsafeTargetError("remote Neo4j target refused")
    return candidate


def _response_object(response: httpx.Response, *, operation: str) -> dict[str, Any]:
    if response.status_code < 200 or response.status_code >= 300:
        raise LifecycleVerificationError(
            "HTTP_REQUEST_FAILED",
            operation,
            detail=f"HTTP_{response.status_code}",
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise LifecycleVerificationError(
            "INVALID_JSON_RESPONSE", operation
        ) from exc
    if not isinstance(payload, dict):
        raise LifecycleVerificationError("INVALID_RESPONSE_SHAPE", operation)
    return payload


def _synthetic_csv(marker: str) -> bytes:
    # The inventory shape is deterministic and avoids invoking the order/VLM
    # verifier while still exercising a structured line, search, and graph.
    text = (
        "\ufeff\u4ed3\u5e93\u540d\u79f0,\u7269\u6599\u4ee3\u7801,\u7269\u6599\u540d\u79f0,"
        "\u5355\u4f4d,\u5373\u65f6\u5e93\u5b58\u6570\u91cf\n"
        f"M1-LIFECYCLE,{marker},{marker},PCS,1\n"
    )
    return text.encode("utf-8")


def _marker_in_payload(payload: Mapping[str, Any], marker: str) -> bool:
    return marker in json.dumps(payload, ensure_ascii=False, sort_keys=True)


def _search_has_source(
    payload: Mapping[str, Any], *, marker: str, source_record_id: str
) -> bool:
    hits = payload.get("hits")
    if not isinstance(hits, list):
        return False
    for hit in hits:
        if not isinstance(hit, Mapping):
            continue
        document = hit.get("document")
        if not isinstance(document, Mapping):
            continue
        if str(document.get("source_record_id") or "") != source_record_id:
            continue
        if str(hit.get("match_reason") or "") != "exact_identifier":
            continue
        if _marker_in_payload(document, marker):
            return True
    return False


def _outbox_snapshot(
    payload: Mapping[str, Any], *, minimum_refreshed_at: datetime | None = None
) -> dict[str, Any]:
    knowledge = payload.get("knowledge")
    if not isinstance(knowledge, Mapping):
        raise LifecycleVerificationError("OUTBOX_STATUS_MISSING", "deletion")
    outbox = knowledge.get("outbox")
    if not isinstance(outbox, Mapping):
        raise LifecycleVerificationError("OUTBOX_STATUS_MISSING", "deletion")
    required = {
        "pending",
        "oldest_pending_age_seconds",
        "terminal_failures",
        "status_error_count",
        "health_complete",
        "refreshed_at",
        "enabled",
        "running",
    }
    if not required.issubset(outbox):
        raise LifecycleVerificationError("OUTBOX_STATUS_INCOMPLETE", "deletion")
    try:
        if any(
            isinstance(outbox[name], bool)
            for name in (
                "pending",
                "oldest_pending_age_seconds",
                "terminal_failures",
                "status_error_count",
            )
        ):
            raise TypeError("boolean outbox counter")
        pending = int(outbox["pending"])
        oldest = float(outbox["oldest_pending_age_seconds"])
        terminal = int(outbox["terminal_failures"])
        status_errors = int(outbox["status_error_count"])
        refreshed_at = datetime.fromisoformat(str(outbox["refreshed_at"]))
        if refreshed_at.tzinfo is None:
            raise ValueError("outbox refreshed_at must be timezone-aware")
    except (TypeError, ValueError) as exc:
        raise LifecycleVerificationError(
            "OUTBOX_STATUS_INVALID", "deletion"
        ) from exc
    return {
        "pending": pending,
        "oldest_pending_age_seconds": oldest,
        "terminal_failures": terminal,
        "status_error_count": status_errors,
        "health_complete": outbox.get("health_complete") is True,
        "worker_enabled": outbox.get("enabled") is True,
        "worker_running": outbox.get("running") is True,
        "refreshed_at": refreshed_at.isoformat(),
        "refreshed_after_delete": bool(
            minimum_refreshed_at is None or refreshed_at > minimum_refreshed_at
        ),
    }


def _validate_preflight(
    payload: Mapping[str, Any], *, lightrag_query_configured: bool
) -> dict[str, Any]:
    knowledge = payload.get("knowledge")
    if not isinstance(knowledge, Mapping):
        raise LifecycleVerificationError("KNOWLEDGE_STATUS_MISSING", "preflight")
    backend = knowledge.get("backend")
    if not isinstance(backend, Mapping):
        raise LifecycleVerificationError("KNOWLEDGE_BACKEND_MISSING", "preflight")
    wiki = backend.get("wiki")
    graph = backend.get("graph")
    shadow = backend.get("lightrag_shadow")
    if not isinstance(wiki, Mapping) or not isinstance(graph, Mapping):
        raise LifecycleVerificationError("AUTHORITATIVE_BACKEND_MISSING", "preflight")
    if str(wiki.get("backend") or "") != "postgresql" or wiki.get("status") != "ok":
        raise LifecycleVerificationError(
            "POSTGRESQL_BACKEND_NOT_READY", "preflight"
        )
    if (
        str(graph.get("backend") or "") != "neo4j"
        or graph.get("status") != "ok"
        or graph.get("schema_initialized") is not True
    ):
        raise LifecycleVerificationError("NEO4J_BACKEND_NOT_READY", "preflight")
    outbox = knowledge.get("outbox")
    if not isinstance(outbox, Mapping):
        raise LifecycleVerificationError("OUTBOX_STATUS_MISSING", "preflight")
    if (
        outbox.get("enabled") is not True
        or outbox.get("running") is not True
        or outbox.get("health_complete") is not True
    ):
        raise LifecycleVerificationError("OUTBOX_WORKER_NOT_READY", "preflight")
    shadow_enabled = bool(isinstance(shadow, Mapping) and shadow.get("enabled"))
    if shadow_enabled and not lightrag_query_configured:
        raise LifecycleVerificationError(
            "LIGHTRAG_QUERY_NOT_CONFIGURED", "preflight"
        )
    if lightrag_query_configured and not shadow_enabled:
        raise LifecycleVerificationError("LIGHTRAG_SHADOW_NOT_ENABLED", "preflight")
    return {
        "postgresql": "ready",
        "neo4j": "ready",
        "neo4j_schema_initialized": True,
        "outbox_worker": "ready",
        "lightrag_shadow_enabled": shadow_enabled,
    }


class M1HttpClient:
    """Typed facade over the small set of public M1 routes used by the probe."""

    def __init__(
        self,
        config: VerificationConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        base_url = validate_target_url(
            config.base_url, allow_remote=config.allow_remote
        )
        headers = {
            "Accept": "application/json",
            "X-Tenant-ID": config.tenant_id,
        }
        if config.api_key.strip():
            headers["X-API-Key"] = config.api_key.strip()
        self._tenant_id = config.tenant_id
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=httpx.Timeout(config.request_timeout_seconds),
            follow_redirects=False,
            trust_env=False,
            transport=transport,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def upload(self, marker: str) -> dict[str, Any]:
        response = await self._client.post(
            "ingest",
            files={
                "file": (
                    "m1-knowledge-lifecycle.csv",
                    _synthetic_csv(marker),
                    "text/csv; charset=utf-8",
                )
            },
            data={
                "tenant_id": self._tenant_id,
                "doc_type_hint": "inventory",
                "document_subtype_hint": "inventory_snapshot",
                "semantic_enrichment": "false",
            },
        )
        return _response_object(response, operation="upload")

    async def task(self, task_id: str) -> dict[str, Any]:
        response = await self._client.get(f"tasks/{task_id}")
        return _response_object(response, operation="task")

    async def search(self, marker: str) -> dict[str, Any]:
        response = await self._client.get(
            "knowledge/search",
            params={"q": marker, "mode": "precise", "limit": 10},
        )
        return _response_object(response, operation="search")

    async def graph(self, source_record_id: str) -> tuple[bool, dict[str, Any] | None]:
        response = await self._client.get(
            f"knowledge/graph/{source_record_id}"
        )
        if response.status_code == 404:
            return False, None
        return True, _response_object(response, operation="graph")

    async def delete_task(self, task_id: str) -> dict[str, Any]:
        response = await self._client.delete(f"tasks/{task_id}")
        return _response_object(response, operation="delete")

    async def health(self) -> dict[str, Any]:
        response = await self._client.get("health")
        return _response_object(response, operation="health")

    async def ready(self) -> dict[str, Any]:
        response = await self._client.get("ready")
        return _response_object(response, operation="ready")


class LightRAGQueryClient:
    """Read-only LightRAG query facade used only when explicitly configured."""

    def __init__(
        self,
        config: VerificationConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        base_url = validate_target_url(
            config.lightrag_base_url, allow_remote=config.allow_remote
        )
        workspace = "".join(
            character if character.isalnum() or character == "_" else "_"
            for character in config.lightrag_workspace.strip()
        ).strip("_")
        if not workspace:
            raise ValueError("lightrag_workspace must not be empty")
        headers = {
            "Accept": "application/json",
            "LIGHTRAG-WORKSPACE": workspace,
        }
        if config.lightrag_api_key.strip():
            headers["X-API-Key"] = config.lightrag_api_key.strip()
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=httpx.Timeout(config.request_timeout_seconds),
            follow_redirects=False,
            trust_env=False,
            transport=transport,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def contains(self, marker: str) -> bool:
        response = await self._client.post(
            "query",
            json={
                "query": marker,
                "mode": "naive",
                "top_k": 5,
                "chunk_top_k": 5,
                "only_need_context": True,
            },
        )
        payload = _response_object(response, operation="lightrag_query")
        searchable = {
            key: payload[key]
            for key in ("response", "context", "data")
            if key in payload
        }
        return _marker_in_payload(searchable, marker)


class Neo4jProjectionProbe:
    """Read-only proof that the authoritative Neo4j sink contains a source."""

    _QUERY = """
        MATCH (node:M1NodeDeclaration {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id
        })
        WHERE node.status = 'active'
        RETURN count(node) AS node_count,
               sum(CASE
                   WHEN coalesce(node.properties_json, '') CONTAINS $marker
                   THEN 1 ELSE 0 END) AS marker_count
    """

    def __init__(self, config: VerificationConfig) -> None:
        uri = validate_neo4j_uri(config.neo4j_uri, allow_remote=config.allow_remote)
        if not config.neo4j_password:
            raise ValueError("neo4j_password must not be empty")
        try:
            from neo4j import GraphDatabase
        except ImportError as exc:
            raise ValueError("Neo4j driver requires the M1 knowledge extra") from exc
        self._database = config.neo4j_database
        self._driver = GraphDatabase.driver(
            uri,
            auth=(config.neo4j_username, config.neo4j_password),
        )

    async def close(self) -> None:
        await asyncio.to_thread(self._driver.close)

    async def inspect(
        self, *, tenant_id: str, source_record_id: str, marker: str
    ) -> dict[str, int]:
        def query() -> dict[str, int]:
            with self._driver.session(database=self._database) as session:
                record = session.run(
                    self._QUERY,
                    tenant_id=tenant_id,
                    source_record_id=source_record_id,
                    marker=marker,
                ).single()
                if record is None:
                    return {"node_count": 0, "marker_count": 0}
                return {
                    "node_count": int(record.get("node_count") or 0),
                    "marker_count": int(record.get("marker_count") or 0),
                }

        return await asyncio.to_thread(query)


@dataclass(frozen=True, slots=True)
class _DeletionObservation:
    search_absent: bool
    graph_inactive: bool
    neo4j_absent: bool
    lightrag_absent: bool | None
    outbox: dict[str, Any]

    def report(self) -> dict[str, Any]:
        return {
            "authoritative_search_absent": self.search_absent,
            "graph_active_projection_absent": self.graph_inactive,
            "neo4j_projection_absent": self.neo4j_absent,
            "lightrag_absent": self.lightrag_absent,
            "outbox": self.outbox,
        }

    def converged(self, *, oldest_max_seconds: float) -> bool:
        return bool(
            self.search_absent
            and self.graph_inactive
            and self.neo4j_absent
            and self.lightrag_absent is not False
            and self.outbox["pending"] == 0
            and self.outbox["oldest_pending_age_seconds"] < oldest_max_seconds
            and self.outbox["terminal_failures"] == 0
            and self.outbox["status_error_count"] == 0
            and self.outbox["health_complete"] is True
            and self.outbox["worker_enabled"] is True
            and self.outbox["worker_running"] is True
            and self.outbox["refreshed_after_delete"] is True
        )


async def _wait_for_task(
    client: M1HttpClient,
    *,
    task_id: str,
    marker: str,
    deadline: float,
    poll_interval: float,
    monotonic: Callable[[], float],
    sleep: Callable[[float], Awaitable[None]],
) -> dict[str, Any]:
    while True:
        payload = await client.task(task_id)
        status = str(payload.get("status") or "").casefold()
        sync_status = str(payload.get("knowledge_sync_status") or "").casefold()
        if status == "failed" or sync_status == "failed":
            raise LifecycleVerificationError(
                "INGEST_OR_KNOWLEDGE_SYNC_FAILED",
                "ingest",
                marker=marker,
                task_id=task_id,
                observed={
                    "task_status": status,
                    "knowledge_sync_status": sync_status,
                },
            )
        if status == "needs_review":
            raise LifecycleVerificationError(
                "SYNTHETIC_DOCUMENT_NEEDS_REVIEW",
                "ingest",
                marker=marker,
                task_id=task_id,
                observed={
                    "task_status": status,
                    "knowledge_sync_status": sync_status,
                },
            )
        if (
            status in TERMINAL_TASK_STATUSES
            and sync_status == "synced"
            and str(payload.get("knowledge_document_id") or "")
        ):
            return payload
        if monotonic() >= deadline:
            raise LifecycleVerificationError(
                "INGEST_VISIBILITY_TIMEOUT",
                "ingest",
                marker=marker,
                task_id=task_id,
                observed={
                    "task_status": status,
                    "knowledge_sync_status": sync_status,
                },
            )
        await sleep(poll_interval)


async def _wait_for_visibility(
    client: M1HttpClient,
    lightrag: LightRAGQueryClient | None,
    neo4j: Any,
    *,
    tenant_id: str,
    source_record_id: str,
    marker: str,
    task_id: str,
    deadline: float,
    poll_interval: float,
    monotonic: Callable[[], float],
    sleep: Callable[[float], Awaitable[None]],
) -> dict[str, Any]:
    while True:
        search = await client.search(marker)
        graph_visible, graph = await client.graph(source_record_id)
        search_visible = _search_has_source(
            search, marker=marker, source_record_id=source_record_id
        )
        graph_nodes = graph.get("nodes") if isinstance(graph, Mapping) else None
        active_graph_nodes = (
            [
                node
                for node in graph_nodes
                if isinstance(node, Mapping)
                and node.get("status") == "active"
                and str(node.get("source_record_id") or "") == source_record_id
            ]
            if isinstance(graph_nodes, list)
            else []
        )
        graph_matches = bool(
            graph_visible
            and isinstance(graph, Mapping)
            and str(graph.get("source_record_id") or "") == source_record_id
            and active_graph_nodes
            and _marker_in_payload({"nodes": active_graph_nodes}, marker)
        )
        neo4j_status = await neo4j.inspect(
            tenant_id=tenant_id,
            source_record_id=source_record_id,
            marker=marker,
        )
        neo4j_visible = bool(
            int(neo4j_status.get("node_count") or 0) > 0
            and int(neo4j_status.get("marker_count") or 0) > 0
        )
        lightrag_visible = await lightrag.contains(marker) if lightrag else None
        if (
            search_visible
            and graph_matches
            and neo4j_visible
            and lightrag_visible is not False
        ):
            nodes = graph.get("nodes") if isinstance(graph, Mapping) else []
            edges = graph.get("edges") if isinstance(graph, Mapping) else []
            return {
                "authoritative_search_visible": True,
                "graph_visible": True,
                "graph_node_count": len(nodes) if isinstance(nodes, list) else None,
                "graph_edge_count": len(edges) if isinstance(edges, list) else None,
                "neo4j_visible": True,
                "neo4j_node_count": int(neo4j_status["node_count"]),
                "neo4j_marker_node_count": int(neo4j_status["marker_count"]),
                "lightrag_visible": lightrag_visible,
            }
        if monotonic() >= deadline:
            raise LifecycleVerificationError(
                "PROJECTION_VISIBILITY_TIMEOUT",
                "visibility",
                marker=marker,
                task_id=task_id,
                observed={
                    "authoritative_search_visible": search_visible,
                    "graph_visible": graph_matches,
                    "neo4j_visible": neo4j_visible,
                    "lightrag_visible": lightrag_visible,
                },
            )
        await sleep(poll_interval)


async def _deletion_observation(
    client: M1HttpClient,
    lightrag: LightRAGQueryClient | None,
    neo4j: Any,
    *,
    tenant_id: str,
    marker: str,
    source_record_id: str,
    deleted_at: datetime,
) -> _DeletionObservation:
    search = await client.search(marker)
    graph_visible, _graph = await client.graph(source_record_id)
    health = await client.health()
    neo4j_status = await neo4j.inspect(
        tenant_id=tenant_id,
        source_record_id=source_record_id,
        marker=marker,
    )
    lightrag_absent = not await lightrag.contains(marker) if lightrag else None
    return _DeletionObservation(
        search_absent=not bool(search.get("hits")),
        graph_inactive=not graph_visible,
        neo4j_absent=int(neo4j_status.get("node_count") or 0) == 0,
        lightrag_absent=lightrag_absent,
        outbox=_outbox_snapshot(health, minimum_refreshed_at=deleted_at),
    )


async def _wait_for_deletion(
    client: M1HttpClient,
    lightrag: LightRAGQueryClient | None,
    neo4j: Any,
    *,
    tenant_id: str,
    marker: str,
    task_id: str,
    source_record_id: str,
    deleted_at: datetime,
    deadline: float,
    poll_interval: float,
    oldest_max_seconds: float,
    monotonic: Callable[[], float],
    sleep: Callable[[float], Awaitable[None]],
) -> _DeletionObservation:
    while True:
        observation = await _deletion_observation(
            client,
            lightrag,
            neo4j,
            tenant_id=tenant_id,
            marker=marker,
            source_record_id=source_record_id,
            deleted_at=deleted_at,
        )
        if observation.converged(oldest_max_seconds=oldest_max_seconds):
            return observation
        if monotonic() >= deadline:
            raise LifecycleVerificationError(
                "DELETION_CONVERGENCE_TIMEOUT",
                "deletion",
                marker=marker,
                task_id=task_id,
                observed=observation.report(),
            )
        await sleep(poll_interval)


async def verify_knowledge_lifecycle(
    config: VerificationConfig,
    *,
    marker: str | None = None,
    m1_transport: httpx.AsyncBaseTransport | None = None,
    lightrag_transport: httpx.AsyncBaseTransport | None = None,
    neo4j_probe: Any | None = None,
    monotonic: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> dict[str, Any]:
    """Run the black-box lifecycle probe and return a credential-free report."""

    # Validate every configured target before constructing either client. This
    # guarantees an unsafe target cannot receive even a health request.
    validate_destructive_target(
        config.base_url,
        allow_remote=config.allow_remote,
        confirmation=config.confirm_destructive_target,
    )
    if config.lightrag_base_url.strip():
        validate_target_url(
            config.lightrag_base_url, allow_remote=config.allow_remote
        )
    if config.neo4j_uri.strip():
        validate_neo4j_uri(config.neo4j_uri, allow_remote=config.allow_remote)

    token = marker or f"M1_KNOWLEDGE_LIFECYCLE_{uuid4().hex.upper()}"
    if not token.strip():
        raise ValueError("marker must not be empty")
    started_at = datetime.now(timezone.utc)
    started = monotonic()
    client = M1HttpClient(config, transport=m1_transport)
    lightrag = (
        LightRAGQueryClient(config, transport=lightrag_transport)
        if config.lightrag_base_url.strip()
        else None
    )
    neo4j = neo4j_probe
    task_id = ""
    delete_requested = False
    try:
        if neo4j is None:
            if not config.neo4j_uri.strip():
                raise LifecycleVerificationError(
                    "NEO4J_QUERY_NOT_CONFIGURED", "preflight", marker=token
                )
            neo4j = Neo4jProjectionProbe(config)
        preflight = _validate_preflight(
            await client.ready(),
            lightrag_query_configured=lightrag is not None,
        )
        upload = await client.upload(token)
        task_id = str(upload.get("task_id") or "").strip()
        if not task_id:
            raise LifecycleVerificationError(
                "UPLOAD_TASK_ID_MISSING", "upload", marker=token
            )

        visibility_deadline = monotonic() + config.visibility_timeout_seconds
        try:
            async with asyncio.timeout(config.visibility_timeout_seconds):
                task = await _wait_for_task(
                    client,
                    task_id=task_id,
                    marker=token,
                    deadline=visibility_deadline,
                    poll_interval=config.poll_interval_seconds,
                    monotonic=monotonic,
                    sleep=sleep,
                )
                source_record_id = str(task["knowledge_document_id"])
                visibility = await _wait_for_visibility(
                    client,
                    lightrag,
                    neo4j,
                    tenant_id=config.tenant_id,
                    source_record_id=source_record_id,
                    marker=token,
                    task_id=task_id,
                    deadline=visibility_deadline,
                    poll_interval=config.poll_interval_seconds,
                    monotonic=monotonic,
                    sleep=sleep,
                )
        except TimeoutError as exc:
            raise LifecycleVerificationError(
                "PROJECTION_VISIBILITY_TIMEOUT",
                "visibility",
                marker=token,
                task_id=task_id,
            ) from exc
        visibility_elapsed = monotonic() - started

        deleted = await client.delete_task(task_id)
        if not bool(deleted.get("deleted")):
            raise LifecycleVerificationError(
                "TASK_DELETE_NOT_CONFIRMED",
                "delete",
                marker=token,
                task_id=task_id,
            )
        delete_requested = True
        deleted_at = datetime.now(timezone.utc)
        deletion_started = monotonic()
        try:
            # The outer timeout is independent of per-request timeouts. It is
            # the hard post-DELETE deadline and cancels an in-flight probe when
            # the remaining lifecycle budget is exhausted.
            async with asyncio.timeout(config.deletion_timeout_seconds):
                observation = await _wait_for_deletion(
                    client,
                    lightrag,
                    neo4j,
                    tenant_id=config.tenant_id,
                    marker=token,
                    task_id=task_id,
                    source_record_id=source_record_id,
                    deleted_at=deleted_at,
                    deadline=deletion_started + config.deletion_timeout_seconds,
                    poll_interval=config.poll_interval_seconds,
                    oldest_max_seconds=config.outbox_oldest_max_seconds,
                    monotonic=monotonic,
                    sleep=sleep,
                )
        except TimeoutError as exc:
            raise LifecycleVerificationError(
                "DELETION_CONVERGENCE_TIMEOUT",
                "deletion",
                marker=token,
                task_id=task_id,
            ) from exc
        finished_at = datetime.now(timezone.utc)
        return {
            "schema_version": SCHEMA_VERSION,
            "status": "passed",
            "started_at": started_at.isoformat(),
            "finished_at": finished_at.isoformat(),
            "tenant_id": config.tenant_id,
            "marker": token,
            "task_id": task_id,
            "source_record_id": source_record_id,
            "preflight": preflight,
            "visibility": visibility,
            "deletion": {
                "task_deleted": True,
                **observation.report(),
            },
            "timings_seconds": {
                "visibility": round(visibility_elapsed, 3),
                "deletion_convergence": round(monotonic() - deletion_started, 3),
                "total": round(monotonic() - started, 3),
            },
            "limits": {
                "deletion_hard_deadline_seconds": config.deletion_timeout_seconds,
                "outbox_oldest_max_seconds": config.outbox_oldest_max_seconds,
            },
        }
    except LifecycleVerificationError as exc:
        if not exc.marker:
            exc.marker = token
        if not exc.task_id:
            exc.task_id = task_id
        raise
    except (httpx.HTTPError, asyncio.TimeoutError) as exc:
        raise LifecycleVerificationError(
            "HTTP_TRANSPORT_ERROR",
            "request",
            marker=token,
            task_id=task_id,
            detail=exc.__class__.__name__,
        ) from exc
    finally:
        if task_id and not delete_requested:
            try:
                await client.delete_task(task_id)
            except Exception:  # noqa: BLE001 - best-effort failed-probe cleanup
                pass
        close_operations = [client.close()]
        if lightrag is not None:
            close_operations.append(lightrag.close())
        if neo4j is not None:
            close_operations.append(neo4j.close())
        await asyncio.gather(*close_operations, return_exceptions=True)


def _redact_secrets(value: Any, secrets: tuple[str, ...]) -> Any:
    """Defense-in-depth redaction before a report reaches stdout or disk."""

    if isinstance(value, str):
        redacted = value
        for secret in secrets:
            if secret:
                redacted = redacted.replace(secret, "[REDACTED]")
        return redacted
    if isinstance(value, list):
        return [_redact_secrets(item, secrets) for item in value]
    if isinstance(value, dict):
        return {
            str(key): _redact_secrets(item, secrets)
            for key, item in value.items()
        }
    return value


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Verify M1 knowledge/search/graph/LightRAG deletion convergence."
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("M1_BASE_URL", DEFAULT_BASE_URL),
        help="M1 base URL (default: M1_BASE_URL or local port 8080)",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("M1_API_KEY", ""),
        help="M1 API key (prefer M1_API_KEY; never written to the report)",
    )
    parser.add_argument(
        "--tenant-id", default=os.getenv("M1_TENANT_ID", "default")
    )
    parser.add_argument("--allow-remote", action="store_true")
    parser.add_argument(
        "--confirm-destructive-target",
        default=os.getenv("M1_CONFIRM_DESTRUCTIVE_TARGET", ""),
        help="Exact remote M1 base URL acknowledgement; never needed for loopback",
    )
    parser.add_argument("--visibility-timeout-seconds", type=float, default=120.0)
    parser.add_argument("--deletion-timeout-seconds", type=float, default=120.0)
    parser.add_argument("--poll-interval-seconds", type=float, default=2.0)
    parser.add_argument("--request-timeout-seconds", type=float, default=30.0)
    parser.add_argument("--outbox-oldest-max-seconds", type=float, default=60.0)
    parser.add_argument(
        "--lightrag-base-url", default=os.getenv("LIGHTRAG_BASE_URL", "")
    )
    parser.add_argument(
        "--lightrag-api-key",
        default=os.getenv("LIGHTRAG_API_KEY", ""),
        help="LightRAG API key (prefer LIGHTRAG_API_KEY; never reported)",
    )
    parser.add_argument(
        "--lightrag-workspace",
        default=os.getenv("LIGHTRAG_WORKSPACE", "m1-shadow"),
    )
    parser.add_argument("--neo4j-uri", default=os.getenv("M1_NEO4J_URI", ""))
    parser.add_argument(
        "--neo4j-username", default=os.getenv("M1_NEO4J_USERNAME", "neo4j")
    )
    parser.add_argument(
        "--neo4j-password",
        default=os.getenv("M1_NEO4J_PASSWORD", ""),
        help="Neo4j password (prefer M1_NEO4J_PASSWORD; never reported)",
    )
    parser.add_argument(
        "--neo4j-database", default=os.getenv("M1_NEO4J_DATABASE", "neo4j")
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional JSON report path; stdout is always emitted",
    )
    return parser


async def _main_async(args: argparse.Namespace) -> tuple[int, dict[str, Any]]:
    try:
        config = VerificationConfig(
            base_url=args.base_url,
            api_key=args.api_key,
            tenant_id=args.tenant_id,
            allow_remote=args.allow_remote,
            confirm_destructive_target=args.confirm_destructive_target,
            visibility_timeout_seconds=args.visibility_timeout_seconds,
            deletion_timeout_seconds=args.deletion_timeout_seconds,
            poll_interval_seconds=args.poll_interval_seconds,
            request_timeout_seconds=args.request_timeout_seconds,
            outbox_oldest_max_seconds=args.outbox_oldest_max_seconds,
            lightrag_base_url=args.lightrag_base_url,
            lightrag_api_key=args.lightrag_api_key,
            lightrag_workspace=args.lightrag_workspace,
            neo4j_uri=args.neo4j_uri,
            neo4j_username=args.neo4j_username,
            neo4j_password=args.neo4j_password,
            neo4j_database=args.neo4j_database,
        )
        report = await verify_knowledge_lifecycle(config)
        return 0, report
    except UnsafeTargetError:
        return 2, {
            "schema_version": SCHEMA_VERSION,
            "status": "refused",
            "error": {"code": "REMOTE_TARGET_REFUSED", "phase": "safety"},
        }
    except LifecycleVerificationError as exc:
        return 1, exc.report()
    except (TypeError, ValueError):
        return 2, {
            "schema_version": SCHEMA_VERSION,
            "status": "failed",
            "error": {"code": "INVALID_CONFIGURATION", "phase": "configuration"},
        }
    except Exception as exc:  # noqa: BLE001 - never leak request context or keys
        return 1, {
            "schema_version": SCHEMA_VERSION,
            "status": "failed",
            "error": {
                "code": "UNEXPECTED_ERROR",
                "phase": "runtime",
                "detail": exc.__class__.__name__,
            },
        }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    exit_code, report = asyncio.run(_main_async(args))
    safe_report = _redact_secrets(
        report,
        (
            str(args.api_key or ""),
            str(args.lightrag_api_key or ""),
            str(args.neo4j_password or ""),
        ),
    )
    rendered = json.dumps(safe_report, ensure_ascii=False, indent=2, sort_keys=True)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
