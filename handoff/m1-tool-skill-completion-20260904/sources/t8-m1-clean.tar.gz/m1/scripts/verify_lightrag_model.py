"""Verify the exact offline BAAI/bge-m3 snapshot used by the shadow profile."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from m1.knowledge.lightrag_model_cache import verify_lightrag_model


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument(
        "--lock",
        type=Path,
        default=project_root / "models" / "lightrag-shadow.lock.json",
    )
    args = parser.parse_args()
    print(
        json.dumps(
            verify_lightrag_model(args.root, args.lock),
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
