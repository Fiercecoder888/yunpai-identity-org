"""Container-local governance CLI for capability and content-region routes."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import sys
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from .core.config import settings
from .documents.parsing.content_region_contracts import (
    ContentRegionExecutionObservation,
    registered_content_region_routes,
)
from .documents.parsing.region_capability_contracts import (
    ParsingCapability,
    RegionCapabilityExecutionObservation,
)
from .knowledge.persistence import KnowledgeStore
from .state import TaskStatus
from .workflow.persistence import TaskStore

RouteKind = Literal["capability", "content"]
_SCHEMA_VERSION = "m1.adaptive-region-route-operation.v1"
_PREHASHED_REFERENCE = re.compile(
    r"(?:(?:md5|sha-?(?:1|224|256|384|512)|blake2[bs]?|hash|digest)[:=])?"
    r"(?:[0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{56}|[0-9a-f]{64}|"
    r"[0-9a-f]{96}|[0-9a-f]{128})",
    flags=re.IGNORECASE,
)


def _nonempty(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must not be empty")
    return normalized


def _raw_task_reference(value: str) -> str:
    normalized = _nonempty(value)
    if _PREHASHED_REFERENCE.fullmatch(normalized):
        raise argparse.ArgumentTypeError(
            "task reference must be the original task identifier, not a digest"
        )
    return normalized


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.adaptive_region_routes",
        description="Govern reviewed RegionCapability and ContentRegion profiles.",
    )
    parser.add_argument(
        "--route-kind", required=True, choices=("capability", "content")
    )
    commands = parser.add_subparsers(dest="command", required=True)

    list_command = commands.add_parser("list")
    list_command.add_argument("--tenant-id", required=True, type=_nonempty)
    list_command.add_argument(
        "--status", choices=("candidate", "active", "deprecated", "rejected")
    )
    list_command.add_argument("--limit", type=int, default=100)

    get_command = commands.add_parser("get")
    get_command.add_argument("--tenant-id", required=True, type=_nonempty)
    get_command.add_argument("--profile-id", required=True, type=_nonempty)

    observe = commands.add_parser("record-observation")
    observe.add_argument("--tenant-id", required=True, type=_nonempty)
    observe.add_argument("--profile-id", required=True, type=_nonempty)
    observe.add_argument("--task-id", required=True, type=_raw_task_reference)
    observe.add_argument("--outcome", required=True, choices=("success", "failure"))
    observe.add_argument("--reviewed-by", required=True, type=_nonempty)
    observe.add_argument("--review-note", required=True, type=_nonempty)
    observe.add_argument("--error-code", type=_nonempty)
    observe.add_argument("--latency-ms", type=int, default=0)

    activate = commands.add_parser("activate")
    activate.add_argument("--tenant-id", required=True, type=_nonempty)
    activate.add_argument("--profile-id", required=True, type=_nonempty)
    activate.add_argument("--approved-by", required=True, type=_nonempty)
    activate.add_argument("--reviewed-by", required=True, type=_nonempty)
    activate.add_argument("--review-note", required=True, type=_nonempty)

    for command in ("reject", "deprecate"):
        mutation = commands.add_parser(command)
        mutation.add_argument("--tenant-id", required=True, type=_nonempty)
        mutation.add_argument("--profile-id", required=True, type=_nonempty)
        mutation.add_argument("--reviewed-by", required=True, type=_nonempty)
        mutation.add_argument("--review-note", required=True, type=_nonempty)
    return parser


def _enum(value: object) -> str | None:
    if value is None:
        return None
    return str(getattr(value, "value", value))


def _profile_payload(kind: RouteKind, profile: Any) -> dict[str, Any]:
    signature = profile.signature
    payload = {
        "profile_id": profile.profile_id,
        "tenant_id": profile.tenant_id,
        "profile_key": profile.profile_key,
        "version": profile.version,
        "supersedes_profile_id": profile.supersedes_profile_id,
        "status": _enum(profile.status),
        "exact_fingerprint": profile.exact_fingerprint,
        "embedding_model": profile.embedding_model,
        "embedding_dimensions": profile.embedding_dimensions,
        "observation_count": profile.observation_count,
        "success_count": profile.success_count,
        "failure_count": profile.failure_count,
        "reviewed_by": profile.reviewed_by,
        "reviewed_at": profile.reviewed_at.isoformat() if profile.reviewed_at else None,
        "approved_by": profile.approved_by,
        "approved_at": profile.approved_at.isoformat() if profile.approved_at else None,
    }
    if kind == "capability":
        payload.update(
            capability=_enum(profile.capability),
            source_kind=_enum(signature.source_kind),
            scope=_enum(signature.scope),
            region_kind=_enum(signature.region_kind),
            contract_revision=signature.contract_revision,
            producer_revision=signature.producer_revision,
        )
    else:
        payload.update(
            role=_enum(profile.role),
            strategy_id=_enum(profile.strategy_id),
            source_family=_enum(signature.source_family),
            region_kind=_enum(signature.region_kind),
            contract_revision=signature.contract_revision,
            embedding_space=profile.embedding_space,
        )
    return payload


def _candidate_audit_path(
    value: object, profile_id: str, path: str = "$"
) -> str | None:
    """Return a value-free path only when the final audit names the candidate."""

    if isinstance(value, Mapping):
        if value.get("candidate_profile_id") == profile_id:
            return path
        for key, item in value.items():
            found = _candidate_audit_path(item, profile_id, f"{path}.{key}")
            if found is not None:
                return found
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for index, item in enumerate(value):
            found = _candidate_audit_path(item, profile_id, f"{path}[{index}]")
            if found is not None:
                return found
    return None


def _route_audit(document: Mapping[str, Any], kind: RouteKind) -> object:
    extraction = document.get("extraction")
    if not isinstance(extraction, Mapping):
        return None
    metadata = extraction.get("metadata")
    if not isinstance(metadata, Mapping):
        return None
    if kind == "content":
        return metadata.get("content_region_routing")
    evidence = metadata.get("structured_evidence")
    raw = evidence.get("raw") if isinstance(evidence, Mapping) else None
    if isinstance(raw, Mapping):
        return raw.get("region_capability_routing")
    return None


def _task_hash(tenant_id: str, task_id: str) -> str:
    return hashlib.sha256(f"{tenant_id}\0{task_id}".encode()).hexdigest()


async def _open_store() -> KnowledgeStore:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    await store.init(migrate_schema=False)
    return store


async def _list(args: argparse.Namespace) -> dict[str, Any]:
    kind: RouteKind = args.route_kind
    store = await _open_store()
    try:
        method = getattr(
            store,
            f"list_{'region_capability' if kind == 'capability' else 'content_region'}_profiles",
        )
        profiles = await method(
            args.tenant_id,
            status=args.status,
            limit=max(1, min(int(args.limit), 1000)),
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "list",
            "route_kind": kind,
            "tenant_id": args.tenant_id,
            "profiles": [_profile_payload(kind, profile) for profile in profiles],
        }
    finally:
        await store.close()


async def _get(args: argparse.Namespace) -> dict[str, Any]:
    kind: RouteKind = args.route_kind
    store = await _open_store()
    try:
        method = getattr(
            store,
            f"get_{'region_capability' if kind == 'capability' else 'content_region'}_profile",
        )
        profile = await method(args.tenant_id, args.profile_id)
        if profile is None:
            raise LookupError("adaptive region profile not found")
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "get",
            "route_kind": kind,
            "profile": _profile_payload(kind, profile),
        }
    finally:
        await store.close()


async def _record_observation(args: argparse.Namespace) -> dict[str, Any]:
    kind: RouteKind = args.route_kind
    store = await _open_store()
    task_store = TaskStore(settings.database_url)
    try:
        get_method = getattr(
            store,
            f"get_{'region_capability' if kind == 'capability' else 'content_region'}_profile",
        )
        profile = await get_method(args.tenant_id, args.profile_id)
        if profile is None:
            raise LookupError("adaptive region profile not found")
        task = await task_store.load(args.task_id)
        if task is None:
            raise LookupError("route validation task not found")
        if str(task.tenant_id).strip() != args.tenant_id:
            raise ValueError("route validation task belongs to another tenant")
        if task.status is not TaskStatus.DONE or not isinstance(task.document, Mapping):
            raise ValueError("route validation requires a completed final task")
        audit_path = _candidate_audit_path(
            _route_audit(task.document, kind),
            args.profile_id,
        )
        if audit_path is None:
            raise ValueError("final task does not reference the candidate profile")
        success = args.outcome == "success"
        if not success and not args.error_code:
            raise ValueError("failed route validation requires an error code")
        task_reference_hash = _task_hash(args.tenant_id, args.task_id)
        common = {
            "tenant_id": args.tenant_id,
            "profile_id": args.profile_id,
            "exact_fingerprint": profile.exact_fingerprint,
            "task_reference_hash": task_reference_hash,
            "outcome": args.outcome,
            "validation_passed": success,
            "reviewed_by": args.reviewed_by,
            "review_note_sha256": hashlib.sha256(args.review_note.encode()).hexdigest(),
            "latency_ms": max(0, int(args.latency_ms)),
            "error_code": "" if success else args.error_code,
        }
        if kind == "capability":
            observation = RegionCapabilityExecutionObservation(
                **common,
                region_reference_hash=hashlib.sha256(audit_path.encode()).hexdigest(),
            )
            persisted = await store.record_region_capability_execution_observation(
                observation
            )
        else:
            observation = ContentRegionExecutionObservation(**common)
            persisted = await store.record_content_region_execution_observation(
                observation
            )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "record-observation",
            "route_kind": kind,
            "profile_id": args.profile_id,
            "observation_id": persisted.observation_id,
            "task_reference_hash": task_reference_hash,
            "outcome": args.outcome,
        }
    finally:
        await task_store.close()
        await store.close()


async def _activate(args: argparse.Namespace) -> dict[str, Any]:
    kind: RouteKind = args.route_kind
    store = await _open_store()
    try:
        get_method = getattr(
            store,
            f"get_{'region_capability' if kind == 'capability' else 'content_region'}_profile",
        )
        profile = await get_method(args.tenant_id, args.profile_id)
        if profile is None:
            raise LookupError("adaptive region profile not found")
        common = {
            "approved_by": args.approved_by,
            "reviewed_by": args.reviewed_by,
            "review_note": args.review_note,
            "expected_observation_count": profile.observation_count,
        }
        if kind == "capability":
            if profile.capability is not ParsingCapability.PADDLEOCR_VL:
                raise ValueError(
                    "only the currently executable paddleocr_vl capability may activate"
                )
            activated = await store.activate_region_capability_profile(
                args.tenant_id,
                args.profile_id,
                allowed_capabilities=(ParsingCapability.PADDLEOCR_VL,),
                **common,
            )
        else:
            allowed = registered_content_region_routes().pairs(
                profile.signature.region_kind
            )
            activated = await store.activate_content_region_profile(
                args.tenant_id,
                args.profile_id,
                allowed_routes=allowed,
                **common,
            )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "activate",
            "route_kind": kind,
            "profile": _profile_payload(kind, activated),
        }
    finally:
        await store.close()


async def _review_mutation(args: argparse.Namespace) -> dict[str, Any]:
    kind: RouteKind = args.route_kind
    prefix = "region_capability" if kind == "capability" else "content_region"
    store = await _open_store()
    try:
        method = getattr(store, f"{args.command}_{prefix}_profile")
        profile = await method(
            args.tenant_id,
            args.profile_id,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": args.command,
            "route_kind": kind,
            "profile": _profile_payload(kind, profile),
        }
    finally:
        await store.close()


async def _run(args: argparse.Namespace) -> dict[str, Any]:
    if args.command == "list":
        return await _list(args)
    if args.command == "get":
        return await _get(args)
    if args.command == "record-observation":
        return await _record_observation(args)
    if args.command == "activate":
        return await _activate(args)
    if args.command in {"reject", "deprecate"}:
        return await _review_mutation(args)
    raise ValueError(f"unsupported adaptive region operation: {args.command}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = asyncio.run(_run(args))
    except Exception as error:  # noqa: BLE001 - emit only the bounded type
        print(
            json.dumps(
                {
                    "schema_version": _SCHEMA_VERSION,
                    "operation": str(getattr(args, "command", "unknown")),
                    "status": "failed",
                    "error_type": error.__class__.__name__,
                },
                ensure_ascii=True,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["main"]
