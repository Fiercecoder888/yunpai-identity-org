"""Lifecycle manager for M1's governed adaptive routing extensions."""

from __future__ import annotations

import inspect
from typing import Any

from loguru import logger


def _initial_status(
    *,
    enabled: bool = False,
    required: bool = False,
    mode: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "enabled": enabled,
        "required": required,
        "ready": not enabled,
        "degraded": False,
        "error_type": None,
    }
    if mode is not None:
        payload["mode"] = mode
    return payload


async def _close_client(client: Any | None) -> None:
    if client is None:
        return
    close = getattr(client, "close", None)
    if not callable(close):
        return
    result = close()
    if inspect.isawaitable(result):
        await result


class AdaptiveRouteRuntimeManager:
    """Own model clients and runtime state outside the FastAPI entry module."""

    def __init__(self) -> None:
        self.field_runtime: Any | None = None
        self.field_client: Any | None = None
        self.field_status = _initial_status(mode="shadow")
        self.visual_runtime: Any | None = None
        self.visual_client: Any | None = None
        self.visual_status = _initial_status(mode="shadow")
        self.region_runtime: Any | None = None
        self.region_client: Any | None = None
        self.region_status = _initial_status()
        self.content_runtime: Any | None = None
        self.content_client: Any | None = None
        self.content_status = _initial_status()

    @staticmethod
    def _reset_status(
        status: dict[str, Any],
        *,
        enabled: bool,
        required: bool,
        mode: str | None = None,
    ) -> None:
        status.clear()
        status.update(_initial_status(enabled=enabled, required=required, mode=mode))

    @staticmethod
    def _model_client(settings: Any, prefix: str) -> Any:
        from ..structured_llm import StructuredModelClient

        base_url = str(getattr(settings, f"resolved_{prefix}_base_url"))
        model = str(getattr(settings, f"resolved_{prefix}_model"))
        if not base_url or not model:
            raise ValueError(
                f"{prefix.replace('_', ' ')} endpoint and model are required"
            )
        return StructuredModelClient(
            api_key=str(getattr(settings, f"resolved_{prefix}_api_key")),
            base_url=base_url,
            model=model,
            temperature=0.0,
            max_tokens=1024,
            enable_thinking=False,
            timeout=float(getattr(settings, f"{prefix}_timeout_seconds")),
            retries=1,
            output_mode="prompted",
            validation_retry_timeout_per_attempt=True,
        )

    @staticmethod
    async def _probe(client: Any, label: str) -> None:
        result = await client.probe()
        if isinstance(result, dict) and result.get("ready") is False:
            raise RuntimeError(f"{label} model probe failed")

    @staticmethod
    async def _record_init_failure(
        *,
        status: dict[str, Any],
        client: Any | None,
        label: str,
        error: Exception,
    ) -> None:
        status.update(
            ready=False,
            degraded=True,
            error_type=error.__class__.__name__,
        )
        logger.warning(
            "{} initialization degraded error_type={}",
            label,
            error.__class__.__name__,
        )
        try:
            await _close_client(client)
        except Exception as cleanup_error:  # noqa: BLE001 - retain probe error
            logger.warning(
                "{} cleanup degraded error_type={}",
                label,
                cleanup_error.__class__.__name__,
            )

    def snapshot(self, name: str) -> dict[str, Any]:
        payload = dict(getattr(self, f"{name}_status"))
        runtime = getattr(self, f"{name}_runtime")
        snapshot = getattr(runtime, "status_snapshot", None)
        if callable(snapshot):
            runtime_payload = snapshot()
            if isinstance(runtime_payload, dict):
                payload.update(runtime_payload)
        return payload

    def wire_field_consumers(
        self,
        *,
        mineru_shadow_runner: Any | None,
    ) -> tuple[str, ...]:
        runtime = self.field_runtime
        if runtime is None:
            return ()
        registry = getattr(runtime, "registry", None)
        if registry is None:
            raise RuntimeError("field semantic runtime has no canonical registry")
        # Every document workflow consumes the runtime in adaptive post-build,
        # independently of the MinerU integration.
        consumers: list[str] = ["workflow_postbuild"]
        instructor = getattr(mineru_shadow_runner, "instructor_service", None)
        if instructor is not None:
            instructor.field_semantic_router = runtime
            instructor.field_semantic_registry = registry
            consumers.append("mineru_instructor")
        return tuple(consumers)

    def wire_region_consumer(self, document_parser: Any | None) -> tuple[str, ...]:
        if self.region_runtime is None:
            return ()
        if document_parser is None or not hasattr(
            document_parser, "page_capability_router"
        ):
            return ()
        document_parser.page_capability_router = self.region_runtime
        return ("document_parser",)

    @staticmethod
    def _record_consumers(
        *,
        settings: Any,
        prefix: str,
        status: dict[str, Any],
        consumers: tuple[str, ...],
        label: str,
    ) -> None:
        if not bool(getattr(settings, f"{prefix}_enabled", False)):
            return
        status["consumers"] = list(consumers)
        if consumers or status.get("ready") is False:
            return
        status.update(ready=False, degraded=True, error_type="NoConsumers")
        if bool(getattr(settings, f"{prefix}_required", False)):
            raise RuntimeError(f"required {label} has no active consumers")

    def record_field_consumers(self, settings: Any, consumers: tuple[str, ...]) -> None:
        self._record_consumers(
            settings=settings,
            prefix="field_semantic_router",
            status=self.field_status,
            consumers=consumers,
            label="field semantic router",
        )

    def record_region_consumers(
        self, settings: Any, consumers: tuple[str, ...]
    ) -> None:
        self._record_consumers(
            settings=settings,
            prefix="region_capability_router",
            status=self.region_status,
            consumers=consumers,
            label="region capability router",
        )

    def record_content_consumers(
        self, settings: Any, consumers: tuple[str, ...]
    ) -> None:
        self._record_consumers(
            settings=settings,
            prefix="content_region_router",
            status=self.content_status,
            consumers=consumers,
            label="content region router",
        )

    async def init_field(self, settings: Any, knowledge: Any | None) -> None:
        enabled = bool(getattr(settings, "field_semantic_router_enabled", False))
        required = bool(getattr(settings, "field_semantic_router_required", False))
        mode = str(getattr(settings, "field_semantic_router_mode", "shadow"))
        self.field_runtime = self.field_client = None
        self._reset_status(
            self.field_status,
            enabled=enabled,
            required=required,
            mode=mode,
        )
        if not enabled:
            return
        client = None
        try:
            if knowledge is None:
                raise RuntimeError(
                    "field semantic routing requires the knowledge runtime"
                )
            provider = knowledge.embedding_provider
            if provider is None:
                raise RuntimeError(
                    "field semantic routing requires knowledge embeddings"
                )
            from ..documents.parsing.field_semantic_model_client import (
                PydanticFieldSemanticSelector,
            )
            from ..documents.parsing.field_semantic_registry import (
                build_document_canonical_field_registry,
            )
            from ..documents.parsing.field_semantic_routing import (
                FieldSemanticRoutingRuntime,
            )

            client = self._model_client(settings, "field_semantic_router")
            runtime = FieldSemanticRoutingRuntime(
                store=knowledge.store,
                registry=build_document_canonical_field_registry(),
                embedding_provider=provider,
                selector=PydanticFieldSemanticSelector(client),
                mode=mode,
                max_fields_per_document=int(
                    settings.field_semantic_router_max_fields_per_document
                ),
                required=required,
            )
            await self._probe(client, "field semantic router")
            self.field_client, self.field_runtime = client, runtime
            self.field_status.update(ready=True, degraded=False, error_type=None)
            logger.info("Field semantic routing runtime initialized mode={}", mode)
        except Exception as error:
            self.field_runtime = self.field_client = None
            await self._record_init_failure(
                status=self.field_status,
                client=client,
                label="Field semantic routing",
                error=error,
            )
            if required:
                raise

    async def init_visual(self, settings: Any, knowledge: Any | None) -> None:
        enabled = bool(getattr(settings, "visual_region_router_enabled", False))
        required = bool(getattr(settings, "visual_region_router_required", False))
        mode = str(getattr(settings, "visual_region_router_mode", "shadow"))
        self.visual_runtime = self.visual_client = None
        self._reset_status(
            self.visual_status,
            enabled=enabled,
            required=required,
            mode=mode,
        )
        if not enabled:
            return
        client = None
        try:
            if knowledge is None:
                raise RuntimeError(
                    "visual region routing requires the knowledge runtime"
                )
            provider = knowledge.embedding_provider
            if provider is None:
                raise RuntimeError(
                    "visual region routing requires knowledge embeddings"
                )
            from ..documents.parsing.visual_region_model_client import (
                PydanticVisualRegionSelectorFactory,
                TextVisualRegionEmbeddingAdapter,
            )
            from ..documents.parsing.visual_region_routing import (
                GovernedVisualRegionRoutingRuntime,
            )

            client = self._model_client(settings, "visual_region_router")
            runtime = GovernedVisualRegionRoutingRuntime(
                store=knowledge.store,
                embedding_provider=TextVisualRegionEmbeddingAdapter(provider),
                selector_factory=PydanticVisualRegionSelectorFactory(client),
                mode=mode,
                max_regions_per_document=int(
                    settings.visual_region_router_max_regions_per_document
                ),
                required=required,
            )
            await self._probe(client, "visual region router")
            self.visual_client, self.visual_runtime = client, runtime
            self.visual_status.update(ready=True, degraded=False, error_type=None)
            logger.info("Visual region routing runtime initialized mode={}", mode)
        except Exception as error:
            self.visual_runtime = self.visual_client = None
            await self._record_init_failure(
                status=self.visual_status,
                client=client,
                label="Visual region routing",
                error=error,
            )
            if required:
                raise

    async def init_region(self, settings: Any, knowledge: Any | None) -> None:
        enabled = bool(getattr(settings, "region_capability_router_enabled", False))
        required = bool(getattr(settings, "region_capability_router_required", False))
        self.region_runtime = self.region_client = None
        self._reset_status(
            self.region_status,
            enabled=enabled,
            required=required,
        )
        if not enabled:
            return
        client = None
        try:
            if knowledge is None:
                raise RuntimeError(
                    "region capability routing requires the knowledge runtime"
                )
            provider = knowledge.embedding_provider
            if provider is None:
                raise RuntimeError(
                    "region capability routing requires knowledge embeddings"
                )
            if not bool(getattr(settings, "pp_structure_enabled", False)):
                raise RuntimeError("region capability routing requires PP-Structure")
            if not bool(getattr(settings, "paddleocr_vl_enabled", False)):
                raise RuntimeError("region capability routing requires PaddleOCR-VL")
            from ..documents.parsing.region_capability_contracts import (
                ParsingCapability,
            )
            from ..documents.parsing.region_capability_routing import (
                PydanticRegionCapabilitySelector,
                RegionCapabilityRoutingRuntime,
            )

            client = self._model_client(settings, "region_capability_router")
            runtime = RegionCapabilityRoutingRuntime(
                store=knowledge.store,
                embedding_provider=provider,
                selector=PydanticRegionCapabilitySelector(client),
                available_capabilities=(ParsingCapability.PADDLEOCR_VL,),
                required=required,
                circuit_failures=int(
                    settings.region_capability_router_circuit_failures
                ),
                circuit_seconds=float(
                    settings.region_capability_router_circuit_seconds
                ),
            )
            await self._probe(client, "region capability router")
            self.region_client, self.region_runtime = client, runtime
            self.region_status.update(ready=True, degraded=False, error_type=None)
            logger.info("Region capability routing runtime initialized")
        except Exception as error:
            self.region_runtime = self.region_client = None
            await self._record_init_failure(
                status=self.region_status,
                client=client,
                label="Region capability routing",
                error=error,
            )
            if required:
                raise

    async def init_content(self, settings: Any, knowledge: Any | None) -> None:
        enabled = bool(getattr(settings, "content_region_router_enabled", False))
        required = bool(getattr(settings, "content_region_router_required", False))
        self.content_runtime = self.content_client = None
        self._reset_status(
            self.content_status,
            enabled=enabled,
            required=required,
        )
        if not enabled:
            return
        client = None
        try:
            if knowledge is None:
                raise RuntimeError(
                    "content region routing requires the knowledge runtime"
                )
            provider = knowledge.embedding_provider
            if provider is None:
                raise RuntimeError(
                    "content region routing requires knowledge embeddings"
                )
            from ..documents.parsing.content_region_model_client import (
                ContentRegionEmbeddingAdapter,
                PydanticContentRegionSelector,
            )
            from ..documents.parsing.content_region_routing import (
                ContentRegionRoutingRuntime,
            )

            client = self._model_client(settings, "content_region_router")
            runtime = ContentRegionRoutingRuntime(
                store=knowledge.store,
                embedding_provider=ContentRegionEmbeddingAdapter(provider),
                selector=PydanticContentRegionSelector(client),
                required=required,
                circuit_failures=int(settings.content_region_router_circuit_failures),
                circuit_seconds=float(settings.content_region_router_circuit_seconds),
            )
            await self._probe(client, "content region router")
            self.content_client, self.content_runtime = client, runtime
            self.content_status.update(ready=True, degraded=False, error_type=None)
            logger.info("Content region routing runtime initialized")
        except Exception as error:
            self.content_runtime = self.content_client = None
            await self._record_init_failure(
                status=self.content_status,
                client=client,
                label="Content region routing",
                error=error,
            )
            if required:
                raise

    async def _close_one(self, name: str) -> None:
        client = getattr(self, f"{name}_client")
        setattr(self, f"{name}_client", None)
        setattr(self, f"{name}_runtime", None)
        await _close_client(client)
        status = getattr(self, f"{name}_status")
        status["ready"] = not bool(status.get("enabled"))

    async def close_field(self) -> None:
        await self._close_one("field")

    async def close_visual(self) -> None:
        await self._close_one("visual")

    async def close_region(self) -> None:
        await self._close_one("region")

    async def close_content(self) -> None:
        await self._close_one("content")


__all__ = ["AdaptiveRouteRuntimeManager"]
