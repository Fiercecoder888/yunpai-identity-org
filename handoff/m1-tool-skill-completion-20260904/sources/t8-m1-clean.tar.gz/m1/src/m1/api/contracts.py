"""HTTP request contracts shared by the M1 route modules.

Keeping these models independent from the application factory avoids circular
imports while ``m1.api.main`` continues to re-export the historical names.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ReportRequest(BaseModel):
    """综合报告生成请求。"""

    note: str = ""
    force: bool = False


class ReviewRequest(BaseModel):
    """人工审核载荷；旧 query 参数仍由路由兼容。"""

    model_config = ConfigDict(extra="allow")

    approve: bool = True
    reviewer: str = "anonymous"
    comment: str = ""
    corrections: dict | None = None
    header_corrections: dict | None = None
    line_corrections: list[dict] | dict | None = None
    issue_resolutions: list[dict] | dict | None = None

    @model_validator(mode="before")
    @classmethod
    def capture_legacy_flat_corrections(cls, value):
        """Accept the legacy UI body ``{"lines.1.quantity": "9"}``."""

        if not isinstance(value, dict):
            return value
        known = {
            "approve",
            "reviewer",
            "comment",
            "corrections",
            "header_corrections",
            "line_corrections",
            "issue_resolutions",
        }
        extras = {key: item for key, item in value.items() if key not in known}
        if not extras:
            return value
        normalized = {key: item for key, item in value.items() if key in known}
        normalized["corrections"] = {
            **(normalized.get("corrections") or {}),
            **extras,
        }
        return normalized


class BatchIngestAccepted(BaseModel):
    """Immediate acknowledgement for asynchronously expanded batch uploads."""

    model_config = ConfigDict(populate_by_name=True)

    task_id: str
    parent_id: str
    status: str
    processing_stage: str
    child_count: int = Field(ge=0)
    child_ids: list[str] = Field(default_factory=list)
    accepted_file_count: int = Field(ge=1)
    async_: bool = Field(default=True, alias="async")
    poll_url: str


class KnowledgeTenantRequest(BaseModel):
    tenant_id: str
    display_name: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class KnowledgeBackfillRequest(BaseModel):
    limit: int = Field(default=100, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)
    force: bool = False
    task_ids: list[str] = Field(default_factory=list, max_length=1000)
    max_concurrent: int = Field(default=1, ge=1, le=16)
    retry_attempts: int = Field(default=3, ge=1, le=5)


class KnowledgeReviewRequest(BaseModel):
    decision: str
    reviewer_id: str | None = None
    reason: str = ""
    corrections: dict[str, Any] = Field(default_factory=dict)
    evidence_anchor_ids: list[str] = Field(default_factory=list)
    idempotency_key: str | None = None


class KnowledgeReassessRequest(BaseModel):
    """Bounded, model-free repair for historical false review flags."""

    dry_run: bool = True
    limit: int = Field(default=100, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)
    task_ids: list[str] = Field(default_factory=list, max_length=1000)
    max_concurrent: int = Field(default=4, ge=1, le=16)


class KnowledgeBulkReviewRequest(BaseModel):
    """Audited document-level bulk decision; derived tasks cascade atomically."""

    decision: str = "accept"
    reason: str = ""
    dry_run: bool = True
    review_task_ids: list[str] = Field(default_factory=list, max_length=1000)
    limit: int = Field(default=100, ge=1, le=1000)
    max_concurrent: int = Field(default=4, ge=1, le=16)


class KnowledgeOutboxRequest(BaseModel):
    limit: int = Field(default=100, ge=1, le=1000)
