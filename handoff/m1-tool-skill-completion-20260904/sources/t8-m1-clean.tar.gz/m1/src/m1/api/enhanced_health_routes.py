"""Optional enhanced-capability diagnostics routes.

Integration is intentionally separate from ``m1.api.main``.  Register this
module after the normal routes with::

    register_enhanced_health_routes(app, runtime)

The probe is created lazily on the first request, after the application lifespan
has initialized the real workflow and knowledge dependencies.  Ordinary
``/ready`` remains unchanged and never performs model inference.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from collections.abc import Callable
from types import ModuleType

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict

from ..core.config import settings
from ..enhanced_probe import (
    PREFLIGHT_CAPABILITIES,
    EnhancedCapabilityProbe,
    build_enhanced_probe_from_runtime,
)

_CONFIGURATION_FINGERPRINT_CONTEXT = b"m1-enhanced-configuration-fingerprint-v1\0"


class EnhancedPreflightRequest(BaseModel):
    """Explicit deploy-gate options; lifecycle writes require confirmation."""

    model_config = ConfigDict(extra="forbid")

    require_all: bool = False
    include_lightrag_lifecycle: bool = False
    confirm_lightrag_lifecycle_side_effects: bool = False


def enhanced_configuration_fingerprint(settings_obj: object) -> str | None:
    """Authenticate effective M1 settings without exposing a secret verifier."""

    model_dump = getattr(settings_obj, "model_dump", None)
    if callable(model_dump):
        payload = model_dump(mode="json")
    else:
        payload = {
            key: value
            for key, value in vars(settings_obj).items()
            if not key.startswith("_")
        }
    fingerprint_key = str(payload.pop("enhanced_preflight_api_key", "") or "")
    if not fingerprint_key:
        return None
    encoded = _CONFIGURATION_FINGERPRINT_CONTEXT + json.dumps(
        payload,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hmac.new(
        fingerprint_key.encode("utf-8"),
        encoded,
        hashlib.sha256,
    ).hexdigest()


def register_enhanced_health_routes(
    app: FastAPI,
    runtime: ModuleType,
    *,
    settings_obj=settings,
    probe_factory: Callable[[], EnhancedCapabilityProbe] | None = None,
) -> None:
    """Register lazy, authenticated diagnostics without changing core readiness."""

    probe: EnhancedCapabilityProbe | None = None
    runtime_identity: tuple[int, int] | None = None

    def current_probe() -> EnhancedCapabilityProbe:
        nonlocal probe, runtime_identity
        if probe_factory is not None:
            if probe is None:
                probe = probe_factory()
            return probe
        engine = getattr(runtime, "engine", None)
        if engine is None:
            raise HTTPException(503, "M1 runtime is not initialized")
        identity = (id(engine), id(getattr(runtime, "knowledge_runtime", None)))
        if probe is None or runtime_identity != identity:
            probe = build_enhanced_probe_from_runtime(runtime, settings_obj)
            runtime_identity = identity
        return probe

    @app.get("/enhanced/ready")
    async def enhanced_ready():
        """Configuration/cache snapshot only: no inference and no network I/O."""

        report = current_probe().readiness()
        payload = report.model_dump(mode="json")
        payload["configuration_fingerprint"] = enhanced_configuration_fingerprint(
            settings_obj
        )
        if not report.ready:
            return JSONResponse(status_code=503, content=payload)
        return payload

    @app.post("/enhanced/preflight")
    async def enhanced_preflight(
        request: EnhancedPreflightRequest,
        x_m1_preflight_key: str | None = Header(
            default=None,
            alias="X-M1-Preflight-Key",
        ),
    ):
        """Run real inference/network checks only after an explicit POST."""

        configured_key = str(
            getattr(settings_obj, "enhanced_preflight_api_key", "") or ""
        )
        if not configured_key:
            raise HTTPException(503, "enhanced preflight is disabled")
        if x_m1_preflight_key is None:
            raise HTTPException(401, "enhanced preflight key is required")
        if not hmac.compare_digest(
            x_m1_preflight_key.encode("utf-8"),
            configured_key.encode("utf-8"),
        ):
            raise HTTPException(403, "enhanced preflight key is invalid")
        if (
            request.include_lightrag_lifecycle
            and not request.confirm_lightrag_lifecycle_side_effects
        ):
            raise HTTPException(
                422,
                "LightRAG lifecycle probe requires explicit side-effect confirmation",
            )
        current = current_probe()
        if current.preflight_running:
            raise HTTPException(409, "enhanced preflight is already running")
        required = PREFLIGHT_CAPABILITIES if request.require_all else ()
        report = await current.preflight(
            include_lightrag_lifecycle=request.include_lightrag_lifecycle,
            required_capabilities=required,
        )
        payload = report.model_dump(mode="json")
        payload["configuration_fingerprint"] = enhanced_configuration_fingerprint(
            settings_obj
        )
        if not report.ready:
            return JSONResponse(status_code=503, content=payload)
        return payload


__all__ = [
    "EnhancedPreflightRequest",
    "enhanced_configuration_fingerprint",
    "register_enhanced_health_routes",
]
