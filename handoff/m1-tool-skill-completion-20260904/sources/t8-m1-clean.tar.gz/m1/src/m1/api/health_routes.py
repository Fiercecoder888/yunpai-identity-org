"""Liveness and readiness route registration."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from types import ModuleType
from typing import Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from ..core.config import settings
from ..knowledge.outbox_delivery import (
    GRAPH_MATERIALIZATION_WAIT_DEADLINE_SECONDS,
    LIFECYCLE_WAIT_DEADLINE_SECONDS,
)


def register_health_routes(app: FastAPI, runtime: ModuleType) -> None:
    """Register health routes against the mutable ``m1.api.main`` runtime.

    Tests and embedded callers historically monkeypatch globals in
    ``m1.api.main``. Looking them up through the module object at request time
    preserves that contract after the route split.
    """

    def current_parser_status() -> dict:
        parser = getattr(getattr(runtime.engine, "deps", None), "document_parser", None)
        if parser is None:
            return {
                "mode": settings.document_parser_mode,
                "ready": settings.document_parser_mode == "legacy",
                "backends": {},
            }
        status_fn = getattr(parser, "readiness", None)
        if not callable(status_fn):
            return {
                "mode": settings.document_parser_mode,
                "ready": False,
                "backends": {},
            }
        return status_fn()

    def current_document_router_status() -> dict[str, Any]:
        configured = bool(settings.document_router_enabled)
        required = bool(settings.document_router_required)
        router = getattr(runtime, "document_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "mode": settings.document_router_mode,
            "model": settings.document_router_model,
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        initialization: dict[str, Any] = {}
        provider = getattr(runtime, "_document_routing_status_snapshot", None)
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                initialization = snapshot
                payload.update(snapshot)

        runtime_snapshot: dict[str, Any] = {}
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                runtime_snapshot = snapshot
                payload.update(snapshot)
        initialization_degraded = bool(
            configured
            and initialization
            and (initialization.get("degraded") or initialization.get("ready") is False)
            and not runtime_snapshot.get("last_success_at")
        )
        degraded = bool(
            configured
            and (
                not initialized
                or initialization_degraded
                or payload.get("degraded")
                or payload.get("circuit_open")
                or payload.get("ready") is False
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_entity_router_status() -> dict[str, Any]:
        configured = bool(settings.entity_router_enabled)
        required = bool(settings.entity_router_required)
        router = getattr(runtime, "entity_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "model": settings.entity_router_model,
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        initialization = getattr(runtime, "_entity_routing_status_snapshot", None)
        if callable(initialization):
            snapshot = initialization()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_tabular_layout_router_status() -> dict[str, Any]:
        configured = bool(getattr(settings, "tabular_layout_router_enabled", False))
        required = bool(getattr(settings, "tabular_layout_router_required", False))
        router = getattr(runtime, "tabular_layout_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        provider = getattr(runtime, "_tabular_layout_routing_status_snapshot", None)
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_field_semantic_router_status() -> dict[str, Any]:
        configured = bool(getattr(settings, "field_semantic_router_enabled", False))
        required = bool(getattr(settings, "field_semantic_router_required", False))
        router = getattr(runtime, "field_semantic_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "mode": getattr(settings, "field_semantic_router_mode", "shadow"),
            "model": getattr(
                settings,
                "resolved_field_semantic_router_model",
                "",
            ),
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        provider = getattr(runtime, "_field_semantic_routing_status_snapshot", None)
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_visual_region_router_status() -> dict[str, Any]:
        configured = bool(getattr(settings, "visual_region_router_enabled", False))
        required = bool(getattr(settings, "visual_region_router_required", False))
        router = getattr(runtime, "visual_region_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "mode": getattr(settings, "visual_region_router_mode", "shadow"),
            "model": getattr(settings, "resolved_visual_region_router_model", ""),
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        provider = getattr(runtime, "_visual_region_routing_status_snapshot", None)
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_region_capability_router_status() -> dict[str, Any]:
        configured = bool(getattr(settings, "region_capability_router_enabled", False))
        required = bool(getattr(settings, "region_capability_router_required", False))
        router = getattr(runtime, "region_capability_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "model": getattr(
                settings,
                "resolved_region_capability_router_model",
                "",
            ),
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        provider = getattr(
            runtime,
            "_region_capability_routing_status_snapshot",
            None,
        )
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_content_region_router_status() -> dict[str, Any]:
        configured = bool(getattr(settings, "content_region_router_enabled", False))
        required = bool(getattr(settings, "content_region_router_required", False))
        router = getattr(runtime, "content_region_routing_runtime", None)
        initialized = router is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            "required": required,
            "ready": (not configured) or initialized,
            "initialized": initialized,
            "model": getattr(settings, "resolved_content_region_router_model", ""),
            "error_type": "NotInitialized" if configured and not initialized else None,
        }
        provider = getattr(runtime, "_content_region_routing_status_snapshot", None)
        if callable(provider):
            snapshot = provider()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        snapshot_fn = getattr(router, "status_snapshot", None)
        if callable(snapshot_fn):
            snapshot = snapshot_fn()
            if isinstance(snapshot, dict):
                payload.update(snapshot)
        degraded = bool(
            configured
            and (
                not initialized
                or payload.get("degraded")
                or payload.get("ready") is False
                or payload.get("circuit_open")
            )
        )
        payload["degraded"] = degraded
        payload["ready"] = bool((not configured) or (initialized and not degraded))
        payload["status"] = "degraded" if degraded else "ready"
        if not degraded:
            payload["error_type"] = None
        return payload

    def current_mineru_shadow_status() -> dict[str, Any]:
        configured = bool(settings.mineru_shadow_enabled)
        runner = getattr(
            getattr(runtime.engine, "deps", None),
            "mineru_shadow_runner",
            None,
        )
        initialized = runner is not None
        payload: dict[str, Any] = {
            "enabled": configured,
            # MinerU + Instructor is the sole document authority. The retained
            # optional setting name cannot make this dependency optional.
            "required": True,
            "configured_required": bool(settings.mineru_shadow_required),
            "ready": False,
            "initialized": initialized,
            "backend": settings.mineru_backend,
            "version": settings.mineru_version,
            "model_revision": settings.mineru_model_revision,
            "mapper_model": settings.mineru_mapper_model,
            "error": "not_initialized" if not initialized else None,
        }
        status_fn = getattr(runner, "status", None)
        if callable(status_fn):
            payload.update(status_fn())
        authority_mode = str(
            getattr(runner, "authority_mode", payload.get("authority_mode") or "")
            or ""
        ).strip().casefold()
        candidate_pipeline = str(payload.get("candidate_pipeline") or "").strip()
        authority_contract_ready = bool(
            configured
            and initialized
            and authority_mode == "full"
            and candidate_pipeline == "mineru_instructor"
        )
        runtime_ready = bool(payload.get("ready"))
        ready = bool(authority_contract_ready and runtime_ready)
        degraded = bool(not ready or payload.get("degraded"))
        payload["enabled"] = configured
        payload["required"] = True
        payload["configured_required"] = bool(settings.mineru_shadow_required)
        payload["authority_mode"] = authority_mode or None
        payload["candidate_pipeline"] = candidate_pipeline or None
        payload["authority_contract_ready"] = authority_contract_ready
        payload["ready"] = ready
        payload["degraded"] = degraded
        payload["status"] = "degraded" if degraded else "ready"
        if not configured:
            payload["error"] = "not_enabled"
        elif not initialized:
            payload["error"] = "not_initialized"
        elif not authority_contract_ready:
            payload["error"] = "authority_contract_mismatch"
        elif ready:
            payload["error"] = None
        return payload

    def cached_outbox_health_is_stale(payload: dict[str, Any]) -> bool:
        refreshed_at = payload.get("refreshed_at")
        if not isinstance(refreshed_at, str) or not refreshed_at:
            return True
        try:
            refreshed = datetime.fromisoformat(refreshed_at)
        except ValueError:
            return True
        if refreshed.tzinfo is None:
            return True
        max_age = max(
            60.0,
            float(settings.knowledge_outbox_interval_seconds) * 3.0,
        )
        return (datetime.now(UTC) - refreshed).total_seconds() > max_age

    async def current_outbox_status() -> dict[str, Any]:
        knowledge = runtime.knowledge_runtime
        payload = dict(getattr(runtime, "_outbox_worker_status", {}))
        cached_health = payload.pop("health", None)
        if knowledge is None:
            payload.setdefault("enabled", settings.knowledge_outbox_worker_enabled)
            payload["running"] = False
        elif isinstance(cached_health, dict) and "tenant_count" in cached_health:
            cached_health = dict(cached_health)
            if cached_outbox_health_is_stale(cached_health):
                cached_health["health_complete"] = False
                cached_health["health_stale"] = True
                cached_health.setdefault("status_error", "StaleHealthSnapshot")
            payload.update(cached_health)
        else:
            # Startup can race the worker's first snapshot. Keep this path
            # bounded to one default-tenant query; normal health calls only
            # read the anonymous aggregate periodically refreshed by worker.
            default_tenant = (
                str(settings.knowledge_default_tenant_id).strip().casefold()
                or "default"
            )
            fallback: dict[str, Any] = {
                "pending": 0,
                "oldest_pending_age_seconds": 0.0,
                "terminal_failures": 0,
                "max_attempts": 0,
                "by_projection": {},
                "tenant_count": max(1, int(payload.get("tenant_count") or 0)),
                "status_error_count": 0,
                "health_complete": False,
            }
            try:
                tenant_health = await asyncio.wait_for(
                    knowledge.store.projection_outbox_health(default_tenant),
                    timeout=float(
                        getattr(
                            runtime,
                            "_OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS",
                            2.0,
                        )
                    ),
                )
                fallback.update(tenant_health)
                fallback["tenant_count"] = max(1, int(payload.get("tenant_count") or 0))
                fallback["health_complete"] = False
            except Exception as exc:  # noqa: BLE001 - health reports type only
                fallback["status_error_count"] = 1
                fallback["status_error"] = exc.__class__.__name__
            payload.update(fallback)
        if (
            knowledge is not None
            and settings.knowledge_outbox_worker_enabled
            and payload.get("running") is not True
        ):
            payload["health_complete"] = False
            payload["worker_stalled"] = True
            payload.setdefault("status_error", "OutboxWorkerNotRunning")
        if payload.get("retained_stalled") is True:
            payload["health_complete"] = False
            payload["worker_stalled"] = True
            payload.setdefault("status_error", "OutboxWorkerRetainedTaskStalled")
        last_result = payload.get("last_result")
        last_result = last_result if isinstance(last_result, dict) else {}
        lifecycle_waits = int(last_result.get("lifecycle_waits") or 0)
        terminal_failures = int(payload.get("terminal_failures") or 0)
        payload["lifecycle"] = {
            "waiting_last_drain": lifecycle_waits,
            "deadline_seconds": LIFECYCLE_WAIT_DEADLINE_SECONDS,
            "graph_materialization_deadline_seconds": (
                GRAPH_MATERIALIZATION_WAIT_DEADLINE_SECONDS
            ),
        }
        payload["terminal"] = {
            "count": terminal_failures,
            "present": terminal_failures > 0,
        }
        return payload

    @app.get("/health")
    async def health() -> dict:
        parser_status = current_parser_status()
        router_status = current_document_router_status()
        entity_router_status = current_entity_router_status()
        tabular_layout_router_status = current_tabular_layout_router_status()
        field_semantic_router_status = current_field_semantic_router_status()
        visual_region_router_status = current_visual_region_router_status()
        region_capability_router_status = current_region_capability_router_status()
        content_region_router_status = current_content_region_router_status()
        mineru_status = current_mineru_shadow_status()
        outbox_status = await current_outbox_status()
        knowledge = runtime.knowledge_runtime
        lightrag_status = {
            "enabled": settings.lightrag_shadow_enabled,
            "configured": (
                knowledge is not None
                and getattr(knowledge, "lightrag_shadow", None) is not None
            ),
            "workspace": (
                settings.lightrag_workspace if settings.lightrag_shadow_enabled else ""
            ),
            "last_success_sync_at": None,
            "last_success_delete_at": None,
        }
        snapshot_fn = getattr(knowledge, "lightrag_status_snapshot", None)
        if callable(snapshot_fn):
            lightrag_status.update(snapshot_fn())
        outbox_incomplete = outbox_status.get("health_complete") is False
        outbox_terminal = bool(outbox_status.get("terminal", {}).get("present"))
        degraded_reasons: list[str] = []
        if bool(router_status.get("degraded")):
            degraded_reasons.append("document_router_degraded")
        if bool(entity_router_status.get("degraded")):
            degraded_reasons.append("entity_router_degraded")
        if bool(tabular_layout_router_status.get("degraded")):
            degraded_reasons.append("tabular_layout_router_degraded")
        if bool(field_semantic_router_status.get("degraded")):
            degraded_reasons.append("field_semantic_router_degraded")
        if bool(visual_region_router_status.get("degraded")):
            degraded_reasons.append("visual_region_router_degraded")
        if bool(region_capability_router_status.get("degraded")):
            degraded_reasons.append("region_capability_router_degraded")
        if bool(content_region_router_status.get("degraded")):
            degraded_reasons.append("content_region_router_degraded")
        if bool(mineru_status.get("degraded")):
            degraded_reasons.append("mineru_shadow_degraded")
        if outbox_incomplete:
            degraded_reasons.append("projection_status_incomplete")
        if outbox_terminal:
            degraded_reasons.append("projection_terminal_failures")
        return {
            "status": "degraded" if degraded_reasons else "ok",
            "degraded": bool(degraded_reasons),
            "degraded_reasons": degraded_reasons,
            "module": "m1",
            "model": settings.vlm_model,
            "vlm_configured": bool(settings.vlm_api_key),
            "document_parser": parser_status,
            "document_router": router_status,
            "entity_router": entity_router_status,
            "tabular_layout_router": tabular_layout_router_status,
            "field_semantic_router": field_semantic_router_status,
            "visual_region_router": visual_region_router_status,
            "region_capability_router": region_capability_router_status,
            "content_region_router": content_region_router_status,
            "mineru_shadow": mineru_status,
            "knowledge": {
                "enabled": settings.knowledge_enabled,
                "required": settings.knowledge_required,
                "ready": knowledge is not None,
                "graph_backend": settings.graph_backend,
                "lightrag_shadow": lightrag_status,
                "error": runtime.knowledge_init_error or None,
                "outbox": outbox_status,
            },
        }

    @app.get("/ready")
    async def ready():
        """Readiness gate used by Docker and upstream orchestrators."""

        parser_status = current_parser_status()
        router_status = current_document_router_status()
        entity_router_status = current_entity_router_status()
        tabular_layout_router_status = current_tabular_layout_router_status()
        field_semantic_router_status = current_field_semantic_router_status()
        visual_region_router_status = current_visual_region_router_status()
        region_capability_router_status = current_region_capability_router_status()
        content_region_router_status = current_content_region_router_status()
        mineru_status = current_mineru_shadow_status()
        outbox_status = await current_outbox_status()
        knowledge = runtime.knowledge_runtime
        knowledge_status: dict[str, Any] = {
            "enabled": settings.knowledge_enabled,
            "required": settings.knowledge_required,
            "ready": knowledge is not None,
            "graph_backend": settings.graph_backend,
            "error": runtime.knowledge_init_error or None,
            "outbox": outbox_status,
        }
        if knowledge is not None:
            try:
                backend_health = await asyncio.wait_for(
                    knowledge.health(),
                    timeout=float(
                        getattr(
                            runtime,
                            "_KNOWLEDGE_HEALTH_TIMEOUT_SECONDS",
                            5.0,
                        )
                    ),
                )
                knowledge_status["backend"] = backend_health
                knowledge_status["ready"] = backend_health.get("status") == "ok"
            except Exception as exc:  # noqa: BLE001 - readiness reports type only
                knowledge_status["ready"] = False
                knowledge_status["error"] = exc.__class__.__name__
        backend_health = knowledge_status.get("backend")
        backend_health = backend_health if isinstance(backend_health, dict) else {}
        shadow_health = backend_health.get("lightrag_shadow")
        shadow_health = shadow_health if isinstance(shadow_health, dict) else {}
        degraded_reasons: list[str] = []
        if bool(shadow_health.get("enabled")) and not bool(shadow_health.get("ready")):
            degraded_reasons.append("lightrag_shadow_unavailable")
        if bool(outbox_status.get("terminal", {}).get("present")):
            degraded_reasons.append("projection_terminal_failures")
        if outbox_status.get("health_complete") is False:
            degraded_reasons.append("projection_status_incomplete")
        knowledge_degraded_reasons = list(degraded_reasons)
        if bool(router_status.get("degraded")):
            degraded_reasons.append("document_router_degraded")
        if bool(entity_router_status.get("degraded")):
            degraded_reasons.append("entity_router_degraded")
        if bool(tabular_layout_router_status.get("degraded")):
            degraded_reasons.append("tabular_layout_router_degraded")
        if bool(field_semantic_router_status.get("degraded")):
            degraded_reasons.append("field_semantic_router_degraded")
        if bool(visual_region_router_status.get("degraded")):
            degraded_reasons.append("visual_region_router_degraded")
        if bool(region_capability_router_status.get("degraded")):
            degraded_reasons.append("region_capability_router_degraded")
        if bool(content_region_router_status.get("degraded")):
            degraded_reasons.append("content_region_router_degraded")
        if bool(mineru_status.get("degraded")):
            degraded_reasons.append("mineru_shadow_degraded")
        knowledge_status["degraded"] = bool(knowledge_degraded_reasons)
        knowledge_status["degraded_reasons"] = knowledge_degraded_reasons
        knowledge_ready = not settings.knowledge_required or bool(
            knowledge_status["ready"]
        )
        router_ready = not bool(router_status.get("required")) or bool(
            router_status.get("ready")
        )
        entity_router_ready = not bool(entity_router_status.get("required")) or bool(
            entity_router_status.get("ready")
        )
        tabular_layout_router_ready = not bool(
            tabular_layout_router_status.get("required")
        ) or bool(tabular_layout_router_status.get("ready"))
        field_semantic_router_ready = not bool(
            field_semantic_router_status.get("required")
        ) or bool(field_semantic_router_status.get("ready"))
        visual_region_router_ready = not bool(
            visual_region_router_status.get("required")
        ) or bool(visual_region_router_status.get("ready"))
        region_capability_router_ready = not bool(
            region_capability_router_status.get("required")
        ) or bool(region_capability_router_status.get("ready"))
        content_region_router_ready = not bool(
            content_region_router_status.get("required")
        ) or bool(content_region_router_status.get("ready"))
        mineru_ready = bool(mineru_status.get("ready"))
        is_ready = (
            router_ready
            and entity_router_ready
            and tabular_layout_router_ready
            and field_semantic_router_ready
            and visual_region_router_ready
            and region_capability_router_ready
            and content_region_router_ready
            and mineru_ready
            and knowledge_ready
        )
        readiness_status = (
            "not_ready" if not is_ready else "degraded" if degraded_reasons else "ready"
        )
        payload = {
            "status": readiness_status,
            "module": "m1",
            "model": settings.vlm_model,
            "vlm_configured": bool(settings.vlm_api_key),
            "document_parser": parser_status,
            "document_router": router_status,
            "entity_router": entity_router_status,
            "tabular_layout_router": tabular_layout_router_status,
            "field_semantic_router": field_semantic_router_status,
            "visual_region_router": visual_region_router_status,
            "region_capability_router": region_capability_router_status,
            "content_region_router": content_region_router_status,
            "mineru_shadow": mineru_status,
            "knowledge": knowledge_status,
            "degraded": bool(degraded_reasons),
            "degraded_reasons": degraded_reasons,
        }
        if not is_ready:
            return JSONResponse(status_code=503, content=payload)
        return payload
