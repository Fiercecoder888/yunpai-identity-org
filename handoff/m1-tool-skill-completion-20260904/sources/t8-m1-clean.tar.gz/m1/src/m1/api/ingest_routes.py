"""Single-file, batch, and archive ingestion routes."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import JSONResponse
from loguru import logger

from ..core.config import settings
from ..state import TaskState, TaskStatus
from .contracts import BatchIngestAccepted
from .route_support import (
    classify_staged_upload,
    save_upload_streaming,
    state_detail,
    state_summary,
)

_SYNC_TERMINAL_STATUSES = frozenset(
    {TaskStatus.DONE, TaskStatus.FAILED, TaskStatus.NEEDS_REVIEW}
)
_SYNC_WAIT_SECONDS = 45.0


def _accepted_sync_response(state: TaskState, *, poll_url: str) -> JSONResponse:
    return JSONResponse(
        status_code=202,
        headers={"Retry-After": "5"},
        content={
            "code": "M1_INGEST_ACCEPTED",
            "message": "Document processing continues asynchronously.",
            "task_id": state.task_id,
            "status": state.status.value,
            "processing_stage": state.processing_stage,
            "sync_complete": False,
            "poll_url": poll_url,
        },
    )


def _require_sync_terminal(
    state: TaskState,
    *,
    poll_url: str,
    timed_out: bool,
) -> None:
    """Reject a synchronous response unless persistence proves completion."""

    if state.status in _SYNC_TERMINAL_STATUSES:
        return
    code = "M1_INGEST_SYNC_TIMEOUT" if timed_out else "M1_INGEST_SYNC_INCOMPLETE"
    raise HTTPException(
        status_code=504 if timed_out else 409,
        detail={
            "code": code,
            "message": "Document processing has not reached a terminal state.",
            "task_id": state.task_id,
            "status": state.status.value,
            "processing_stage": state.processing_stage,
            "sync_complete": False,
            "poll_url": poll_url,
        },
        headers={"Retry-After": "5"},
    )


def register_ingest_routes(app: FastAPI, runtime: ModuleType) -> None:
    @app.post("/ingest")
    async def ingest(
        request: Request,
        file: UploadFile = File(...),  # noqa: B008 - FastAPI dependency marker
        doc_type_hint: str = Form(""),
        document_subtype_hint: str = Form(""),
        semantic_enrichment: bool = Form(True),
        tenant_id: str = Form(""),
    ) -> dict:
        if runtime.engine is None:
            raise HTTPException(500, "engine 未初始化")
        resolved_tenant = runtime._form_tenant(request, tenant_id)

        task_id = uuid.uuid4().hex[:12]
        extension = Path(file.filename or "").suffix or ".bin"
        save_path = settings.upload_path / f"{task_id}{extension}"
        await save_upload_streaming(file, save_path, settings.max_archive_size)
        kind = await classify_staged_upload(save_path)
        if kind == "archive":
            from ..ingest.batch import BatchOrchestrator

            orchestrator = BatchOrchestrator(
                runtime.store,
                runtime._spawn,
                semaphore=runtime._processing_semaphore,
                task_registry=runtime._task_registry,
            )
            parent = await orchestrator.ingest_archive_path(
                save_path,
                parent_filename=file.filename or save_path.name,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
                semantic_enrichment=semantic_enrichment,
                tenant_id=resolved_tenant,
            )
            if orchestrator.last_finalize_task is not None:
                runtime._register_background_task(
                    parent.task_id, orchestrator.last_finalize_task
                )
            return {
                "task_id": parent.task_id,
                "status": parent.status.value,
                "file_type": "batch",
                "processing_stage": parent.processing_stage,
                "child_count": 0,
                "child_ids": [],
                "needs_review": False,
                "overall_confidence": None,
                "poll_url": f"/batch/{parent.task_id}",
            }

        state = TaskState(
            task_id=task_id,
            tenant_id=resolved_tenant,
            file_path=str(save_path),
            original_filename=file.filename or save_path.name,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            created_at=datetime.now(UTC).isoformat(),
        )
        logger.info("接收到文件 task={} suffix={}", task_id, extension[:16])
        await runtime.store.save(state)
        runtime._spawn(state)
        return {
            "task_id": task_id,
            "status": state.status.value,
            "needs_review": state.is_paused(),
            "overall_confidence": None,
        }

    @app.post("/ingest/sync")
    async def ingest_sync(
        request: Request,
        file: UploadFile = File(...),  # noqa: B008 - FastAPI dependency marker
        doc_type_hint: str = Form(""),
        document_subtype_hint: str = Form(""),
        semantic_enrichment: bool = Form(True),
        tenant_id: str = Form(""),
    ) -> dict:
        """同步版 ingest: 上传 → 后台推进 → 等到 done/failed/needs_review → 返回 detail。

        与 /ingest 的区别: 阻塞等待终态。供中央 Agent 当工具调用 (避免轮询)。
        超时 220s (大文档/慢 VLM 时返回当前状态, 客户端可再查 /tasks/{id})。
        """

        if runtime.engine is None:
            raise HTTPException(500, "engine 未初始化")
        resolved_tenant = runtime._form_tenant(request, tenant_id)

        task_id = uuid.uuid4().hex[:12]
        extension = Path(file.filename or "").suffix or ".bin"
        save_path = settings.upload_path / f"{task_id}{extension}"
        await save_upload_streaming(file, save_path, settings.max_archive_size)
        kind = await classify_staged_upload(save_path)
        if kind == "archive":
            from ..ingest.batch import BatchOrchestrator

            orchestrator = BatchOrchestrator(
                runtime.store,
                runtime._spawn,
                semaphore=runtime._processing_semaphore,
                task_registry=runtime._task_registry,
            )
            parent = await orchestrator.ingest_archive_path(
                save_path,
                parent_filename=file.filename or save_path.name,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
                semantic_enrichment=semantic_enrichment,
                tenant_id=resolved_tenant,
            )
            if orchestrator.last_finalize_task is not None:
                runtime._register_background_task(
                    parent.task_id, orchestrator.last_finalize_task
                )
            timed_out = False
            try:
                await runtime.wait_for_task(parent.task_id, timeout=_SYNC_WAIT_SECONDS)
            except TimeoutError:
                timed_out = True
                logger.warning(
                    "[sync] archive task={} exceeded 45s; returning accepted poll contract",
                    parent.task_id,
                )
            final_parent = await runtime.store.load(parent.task_id)
            if final_parent is None:
                raise HTTPException(500, f"Archive task lost: {parent.task_id}")
            children = await runtime.store.list_by_parent(parent.task_id)
            poll_url = f"/batch/{parent.task_id}"
            if timed_out and final_parent.status not in _SYNC_TERMINAL_STATUSES:
                return _accepted_sync_response(final_parent, poll_url=poll_url)
            _require_sync_terminal(
                final_parent,
                poll_url=poll_url,
                timed_out=timed_out,
            )
            detail = state_detail(final_parent)
            detail.update(
                {
                    "sync_complete": True,
                    "poll_url": poll_url,
                    "child_count": len(children),
                    "child_ids": [child.task_id for child in children],
                    "children": [state_summary(child) for child in children],
                }
            )
            return detail

        state = TaskState(
            task_id=task_id,
            tenant_id=resolved_tenant,
            file_path=str(save_path),
            original_filename=file.filename or save_path.name,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            created_at=datetime.now(UTC).isoformat(),
        )
        logger.info("[sync] 接收到文件 task={} suffix={}", task_id, extension[:16])
        await runtime.store.save(state)
        runtime._spawn(state)

        timed_out = False
        try:
            await runtime.wait_for_task(task_id, timeout=_SYNC_WAIT_SECONDS)
        except TimeoutError:
            timed_out = True
            logger.warning("[sync] task={} 45s 未完成, 返回 202 轮询契约", task_id)
        final = await runtime.store.load(task_id)
        if final is None:
            raise HTTPException(500, f"任务丢失: {task_id}")
        poll_url = f"/tasks/{task_id}"
        if timed_out and final.status not in _SYNC_TERMINAL_STATUSES:
            return _accepted_sync_response(final, poll_url=poll_url)
        _require_sync_terminal(final, poll_url=poll_url, timed_out=timed_out)
        detail = state_detail(final)
        detail["sync_complete"] = True
        detail["poll_url"] = poll_url
        return detail

    @app.post(
        "/ingest/batch",
        status_code=202,
        response_model=BatchIngestAccepted,
    )
    async def ingest_batch(
        request: Request,
        files: list[UploadFile] = File(...),  # noqa: B008 - FastAPI dependency marker
        doc_type_hint: str = Form(""),
        document_subtype_hint: str = Form(""),
        semantic_enrichment: bool = Form(True),
        tenant_id: str = Form(""),
    ) -> BatchIngestAccepted:
        """多文件批量上传。每个文件建子任务, 返回父任务 id。

        支持混合: 普通文件直接处理, 压缩包自动解压后内部文件各建子任务。
        """

        if runtime.engine is None or runtime.store is None:
            raise HTTPException(500, "engine/store 未初始化")
        resolved_tenant = runtime._form_tenant(request, tenant_id)
        if not files:
            raise HTTPException(400, "未提供任何文件")

        from ..ingest.batch import BatchOrchestrator

        incoming = settings.upload_path / "incoming" / uuid.uuid4().hex[:12]
        incoming.mkdir(parents=True, exist_ok=True)
        disk_files: list[tuple[str, Path]] = []
        for index, upload in enumerate(files):
            original = upload.filename or f"file_{index}.bin"
            suffix = Path(original).suffix or ".bin"
            save_path = incoming / f"{index:04d}_{uuid.uuid4().hex[:12]}{suffix}"
            await save_upload_streaming(upload, save_path, settings.max_archive_size)
            disk_files.append((original, save_path))
        orchestrator = BatchOrchestrator(
            runtime.store,
            runtime._spawn,
            semaphore=runtime._processing_semaphore,
            task_registry=runtime._task_registry,
        )
        parent = await orchestrator.ingest_paths(
            disk_files,
            parent_filename="batch_upload",
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            tenant_id=resolved_tenant,
        )
        if orchestrator.last_finalize_task is not None:
            runtime._register_background_task(
                parent.task_id, orchestrator.last_finalize_task
            )
        return BatchIngestAccepted(
            task_id=parent.task_id,
            parent_id=parent.task_id,
            status=parent.status.value,
            processing_stage=parent.processing_stage,
            child_count=len(parent.child_ids),
            child_ids=parent.child_ids,
            accepted_file_count=len(disk_files),
            async_=True,
            poll_url=f"/batch/{parent.task_id}",
        )

    @app.post("/ingest/archive")
    async def ingest_archive(
        request: Request,
        file: UploadFile = File(...),  # noqa: B008 - FastAPI dependency marker
        doc_type_hint: str = Form(""),
        document_subtype_hint: str = Form(""),
        semantic_enrichment: bool = Form(True),
        tenant_id: str = Form(""),
    ) -> dict:
        """单个压缩包上传, 自动解压, 内部文件各建子任务。"""

        if runtime.engine is None or runtime.store is None:
            raise HTTPException(500, "engine/store 未初始化")
        resolved_tenant = runtime._form_tenant(request, tenant_id)

        from ..ingest.batch import BatchOrchestrator

        name = file.filename or ""
        incoming = settings.upload_path / "incoming"
        incoming.mkdir(parents=True, exist_ok=True)
        suffixes = "".join(Path(name).suffixes[-2:]) or ".archive"
        archive_path = incoming / f"{uuid.uuid4().hex[:12]}{suffixes}"
        await save_upload_streaming(file, archive_path, settings.max_archive_size)
        kind = await classify_staged_upload(archive_path)
        if kind != "archive":
            archive_path.unlink(missing_ok=True)
            raise HTTPException(400, "文件内容不是受支持的 ZIP/TAR/RAR/7Z 归档")
        orchestrator = BatchOrchestrator(
            runtime.store,
            runtime._spawn,
            semaphore=runtime._processing_semaphore,
            task_registry=runtime._task_registry,
        )
        parent = await orchestrator.ingest_archive_path(
            archive_path,
            parent_filename=name,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            tenant_id=resolved_tenant,
        )
        if orchestrator.last_finalize_task is not None:
            runtime._register_background_task(
                parent.task_id, orchestrator.last_finalize_task
            )
        return {
            "task_id": parent.task_id,
            "status": parent.status.value,
            "child_count": len(parent.child_ids),
            "child_ids": parent.child_ids,
            "processing_stage": parent.processing_stage,
            "async": True,
        }

    @app.get("/batch/{parent_id}")
    async def get_batch(parent_id: str) -> dict:
        """查询父任务批次: 父状态 + 所有子任务状态。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        parent = await runtime.store.load(parent_id)
        if parent is None:
            raise HTTPException(404, f"父任务不存在: {parent_id}")
        children = await runtime.store.list_by_parent(parent_id)
        terminal = {TaskStatus.DONE, TaskStatus.FAILED, TaskStatus.NEEDS_REVIEW}
        return {
            "parent": state_detail(parent),
            "children": [state_summary(child) for child in children],
            "child_count": len(children),
            "done_count": sum(1 for child in children if child.status in terminal),
            "failed_count": sum(
                1 for child in children if child.status == TaskStatus.FAILED
            ),
            "review_count": sum(
                1 for child in children if child.status == TaskStatus.NEEDS_REVIEW
            ),
            "pending_count": sum(
                1 for child in children if child.status not in terminal
            ),
        }
