"""Governed knowledge, review, search, and graph HTTP routes."""
from __future__ import annotations

import asyncio
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, Request

from ..core.config import settings
from . import main as api_main
from .main import (
    KnowledgeBackfillRequest,
    KnowledgeBulkReviewRequest,
    KnowledgeOutboxRequest,
    KnowledgeReassessRequest,
    KnowledgeReviewRequest,
    KnowledgeTenantRequest,
    TaskState,
    TaskStatus,
    _actor_context,
    _normalize_tenant_id,
    _request_tenant,
    _require_knowledge_role,
    _require_knowledge_runtime,
    _safe_exception_message,
    _update_knowledge_task_status,
)


def register_knowledge_routes(app: FastAPI) -> None:
    @app.get("/knowledge/health")
    async def knowledge_health() -> dict:
        runtime = _require_knowledge_runtime()
        try:
            return await runtime.health()
        except Exception as exc:
            raise HTTPException(
                503, f"知识库健康检查失败: {exc.__class__.__name__}"
            ) from exc

    @app.post("/knowledge/tenants")
    async def create_knowledge_tenant(
        request: Request, payload: KnowledgeTenantRequest
    ) -> dict:
        _require_knowledge_role(request, "admin")
        runtime = _require_knowledge_runtime()
        tenant_id = _normalize_tenant_id(payload.tenant_id)
        tenant = await runtime.create_tenant(
            tenant_id,
            payload.display_name.strip() or tenant_id,
            metadata=payload.metadata,
        )
        return tenant.model_dump(mode="json")

    @app.post("/knowledge/tasks/{task_id}/sync")
    async def sync_knowledge_task(task_id: str, request: Request) -> dict:
        runtime = _require_knowledge_runtime()
        if api_main.store is None:
            raise HTTPException(500, "store 未初始化")
        tenant_id = _request_tenant(request)
        state = await api_main.store.load(task_id)
        if state is None or state.tenant_id != tenant_id:
            raise HTTPException(404, "任务不存在")
        document = await api_main.store.get_document(task_id) or state.document
        if document is None:
            raise HTTPException(409, "任务尚无 m1.document.v2 结果")
        from ..knowledge.eligibility import knowledge_sync_eligibility

        eligible, reason = knowledge_sync_eligibility(document)
        if not eligible:
            await _update_knowledge_task_status(
                task_id,
                status="skipped",
                error=reason,
            )
            raise HTTPException(
                409,
                "document is not eligible for governed knowledge projection",
            )
        try:
            outcome = await runtime.sync_document(
                tenant_id=tenant_id,
                task_id=task_id,
                document=document,
            )
        except Exception as exc:
            await _update_knowledge_task_status(
                task_id, status="failed", error=exc.__class__.__name__
            )
            raise HTTPException(
                502, f"知识入库失败: {exc.__class__.__name__}"
            ) from exc
        await _update_knowledge_task_status(
            task_id,
            status=outcome.status,
            document_id=outcome.document.document_id,
            version_id=outcome.document.version_id,
            error=outcome.graph_error or outcome.embedding_error,
        )
        return outcome.model_dump(mode="json")

    @app.post("/knowledge/backfill")
    async def backfill_knowledge(
        request: Request, payload: KnowledgeBackfillRequest
    ) -> dict:
        """Replay already parsed M1 documents without invoking OCR, VLM or LLM."""

        runtime = _require_knowledge_runtime()
        _require_knowledge_role(request, "admin", "reviewer")
        if api_main.store is None:
            raise HTTPException(500, "store 未初始化")
        tenant_id = _request_tenant(request)
        states = await api_main.store.list_all(tenant_id=tenant_id)
        if payload.task_ids:
            selected_ids = {str(task_id).strip() for task_id in payload.task_ids}
            states = [state for state in states if state.task_id in selected_ids]
        states = states[payload.offset : payload.offset + payload.limit]
        counters = {
            "selected": len(states),
            "synced": 0,
            "skipped": 0,
            "missing_document": 0,
            "failed": 0,
        }
        failures: list[dict[str, str]] = []

        semaphore = asyncio.Semaphore(payload.max_concurrent)

        async def sync_state(state: TaskState) -> tuple[str, dict[str, str] | None]:
            if state.file_type == "batch" or state.child_ids:
                return "skipped", None
            document = await api_main.store.get_document(state.task_id) or state.document
            if document is None:
                return "missing_document", None
            from ..knowledge.eligibility import knowledge_sync_eligibility

            eligible, reason = knowledge_sync_eligibility(document)
            if not eligible:
                await _update_knowledge_task_status(
                    state.task_id,
                    status="skipped",
                    error=reason,
                )
                return "skipped", None
            if not payload.force and state.knowledge_sync_status == "synced":
                return "skipped", None
            async with semaphore:
                for attempt in range(1, payload.retry_attempts + 1):
                    try:
                        outcome = await runtime.sync_document(
                            tenant_id=tenant_id,
                            task_id=state.task_id,
                            document=document,
                        )
                        await _update_knowledge_task_status(
                            state.task_id,
                            status=outcome.status,
                            document_id=outcome.document.document_id,
                            version_id=outcome.document.version_id,
                            error=outcome.graph_error or outcome.embedding_error,
                        )
                        return "synced", None
                    except Exception as exc:  # noqa: BLE001 - bounded replay
                        error_type = exc.__class__.__name__
                        if attempt < payload.retry_attempts:
                            await asyncio.sleep(0.05 * (2 ** (attempt - 1)))
                            continue
                        await _update_knowledge_task_status(
                            state.task_id, status="failed", error=error_type
                        )
                        return "failed", {
                            "task_id": state.task_id,
                            "error": error_type,
                        }
            raise AssertionError("unreachable backfill result")

        results = await asyncio.gather(*(sync_state(state) for state in states))
        for status, failure in results:
            counters[status] += 1
            if failure is not None:
                failures.append(failure)
        return {
            "tenant_id": tenant_id,
            **counters,
            "failures": failures[:50],
            "next_offset": payload.offset + len(states),
        }

    @app.get("/knowledge/search")
    async def search_knowledge(
        request: Request,
        q: str = Query(..., min_length=1),
        document_type: str = Query(""),
        document_subtype: str = Query(""),
        include_candidate: bool = Query(False),
        limit: int = Query(20, ge=1, le=200),
        mode: Literal["precise", "broad"] = Query("precise"),
        min_score: float | None = Query(None, ge=0.0, le=1.0),
    ) -> dict:
        runtime = _require_knowledge_runtime()
        tenant_id = _request_tenant(request)
        actor_id, roles = _actor_context(request)
        if include_candidate:
            _require_knowledge_role(request, "admin", "reviewer")
        filters = {
            key: value
            for key, value in {
                "document_type": document_type,
                "document_subtype": document_subtype,
            }.items()
            if value
        }
        statuses = {"active", "candidate"} if include_candidate else {"active"}
        hits = await runtime.search_index(
            tenant_id,
            q,
            filters=filters,
            statuses=statuses,
            include_candidate=include_candidate,
            actor_id=actor_id,
            actor_roles=roles,
            limit=limit,
            mode=mode,
            min_score=(
                settings.knowledge_search_default_min_score
                if min_score is None and mode == "precise"
                else min_score
            ),
            max_hits_per_source=settings.knowledge_search_max_hits_per_source,
        )
        return {
            "tenant_id": tenant_id,
            "query": q,
            "include_candidate": include_candidate,
            "mode": mode,
            "min_score": (
                settings.knowledge_search_default_min_score
                if min_score is None and mode == "precise"
                else (min_score or 0.0)
            ),
            "hits": [hit.model_dump(mode="json") for hit in hits],
        }

    @app.get("/knowledge/entities")
    async def list_knowledge_entities(
        request: Request,
        entity_type: str = Query(""),
        lifecycle_status: str = Query(""),
        include_candidate: bool = Query(False),
        limit: int = Query(100, ge=1, le=1000),
        offset: int = Query(0, ge=0),
    ) -> list[dict]:
        runtime = _require_knowledge_runtime()
        public_statuses = {"active", "approved"}
        requested_status = lifecycle_status.strip().casefold()
        if include_candidate:
            _require_knowledge_role(request, "admin", "reviewer")
            allowed_statuses = {requested_status} if requested_status else None
        elif requested_status and requested_status not in public_statuses:
            raise HTTPException(
                403, "candidate entities require reviewer/admin access"
            )
        else:
            allowed_statuses = (
                {requested_status} if requested_status else public_statuses
            )
        records = await runtime.store.list_entities(
            _request_tenant(request),
            entity_type=entity_type or None,
            lifecycle_statuses=allowed_statuses,
            limit=limit,
            offset=offset,
        )
        actor_id, roles = _actor_context(request)
        return [
            record.model_dump(mode="json")
            for record in records
            if runtime.store.acl_allows(record.acl, actor_id=actor_id, actor_roles=roles)
        ]

    @app.get("/knowledge/entities/{entity_id}")
    async def get_knowledge_entity(
        entity_id: str,
        request: Request,
        include_candidate: bool = Query(False),
    ) -> dict:
        runtime = _require_knowledge_runtime()
        tenant_id = _request_tenant(request)
        record = await runtime.store.get_entity(tenant_id, entity_id)
        if record is None:
            raise HTTPException(404, "实体不存在")
        if str(record.lifecycle_status) not in {"active", "approved"}:
            if not include_candidate:
                raise HTTPException(404, "entity not found")
            _require_knowledge_role(request, "admin", "reviewer")
        actor_id, roles = _actor_context(request)
        if not runtime.store.acl_allows(
            record.acl, actor_id=actor_id, actor_roles=roles
        ):
            raise HTTPException(404, "实体不存在")
        return record.model_dump(mode="json")

    @app.get("/knowledge/reviews")
    async def list_knowledge_reviews(
        request: Request,
        status: str = Query("open"),
        limit: int = Query(100, ge=1, le=1000),
    ) -> list[dict]:
        _require_knowledge_role(request, "admin", "reviewer")
        runtime = _require_knowledge_runtime()
        records = await runtime.store.list_review_tasks(
            _request_tenant(request), status=status, limit=limit
        )
        return [record.model_dump(mode="json") for record in records]

    @app.post("/knowledge/reviews/reassess")
    async def reassess_knowledge_reviews(
        request: Request,
        payload: KnowledgeReassessRequest,
    ) -> dict:
        """Preview/apply deterministic repair of legacy false-positive reviews."""

        _require_knowledge_role(request, "admin")
        if api_main.engine is None or api_main.store is None:
            raise HTTPException(503, "M1 工作流未初始化")
        tenant_id = _request_tenant(request)
        selected: list[TaskState] = []
        if payload.task_ids:
            for task_id in dict.fromkeys(payload.task_ids):
                state = await api_main.store.load(task_id)
                if state is None or state.tenant_id != tenant_id:
                    raise HTTPException(404, f"任务不存在: {task_id}")
                selected.append(state)
        else:
            states = await api_main.store.list_by_status(
                TaskStatus.NEEDS_REVIEW.value,
                tenant_id=tenant_id,
            )
            selected = states[payload.offset : payload.offset + payload.limit]
        if payload.task_ids:
            selected = selected[payload.offset : payload.offset + payload.limit]

        semaphore = asyncio.Semaphore(payload.max_concurrent)

        async def reassess(state: TaskState) -> dict[str, object]:
            async with semaphore:
                try:
                    return await api_main.engine.reassess_document_review(
                        state.task_id,
                        dry_run=payload.dry_run,
                    )
                except ValueError as exc:
                    return {
                        "task_id": state.task_id,
                        "skipped": True,
                        "error": _safe_exception_message(exc),
                    }

        results = await asyncio.gather(*(reassess(state) for state in selected))
        auto_approvable = sum(
            1 for result in results if result.get("after_needs_review") is False
        )
        still_blocked = sum(
            1 for result in results if result.get("after_needs_review") is True
        )
        skipped = sum(1 for result in results if result.get("skipped"))
        return {
            "tenant_id": tenant_id,
            "dry_run": payload.dry_run,
            "selected": len(selected),
            "auto_approvable": auto_approvable,
            "still_blocked": still_blocked,
            "skipped": skipped,
            "next_offset": payload.offset + len(selected),
            "results": results,
        }

    @app.post("/knowledge/reviews/bulk")
    async def bulk_decide_knowledge_reviews(
        request: Request,
        payload: KnowledgeBulkReviewRequest,
    ) -> dict:
        """Preview/apply document decisions without one-clicking derived claims."""

        actor_id, _roles = _require_knowledge_role(request, "admin")
        if not actor_id:
            raise HTTPException(403, "bulk review requires a trusted actor_id")
        decision = payload.decision.strip().casefold()
        if decision not in {"accept", "reject"}:
            raise HTTPException(422, "bulk review only supports accept or reject")
        runtime = _require_knowledge_runtime()
        tenant_id = _request_tenant(request)
        open_reviews = await runtime.store.list_review_tasks(
            tenant_id,
            status="open",
            limit=1000,
        )
        requested_ids = set(payload.review_task_ids)
        selected = [
            review
            for review in open_reviews
            if review.target_type == "document_version"
            and (not requested_ids or review.review_task_id in requested_ids)
        ][: payload.limit]
        if requested_ids:
            found = {review.review_task_id for review in selected}
            missing = sorted(requested_ids - found)
            if missing:
                raise HTTPException(
                    404,
                    f"document review tasks not found or not open: {missing[:20]}",
                )
        if payload.dry_run:
            return {
                "tenant_id": tenant_id,
                "dry_run": True,
                "decision": decision,
                "selected": len(selected),
                "review_task_ids": [review.review_task_id for review in selected],
            }

        semaphore = asyncio.Semaphore(payload.max_concurrent)

        async def decide(review) -> dict[str, object]:
            async with semaphore:
                try:
                    result = await runtime.store.decide_review(
                        tenant_id=tenant_id,
                        review_task_id=review.review_task_id,
                        decision=decision,
                        reviewer_id=actor_id,
                        reason=payload.reason,
                        idempotency_key=(
                            f"bulk:{review.review_task_id}:{decision}:{actor_id}"
                        ),
                    )
                    return {
                        "review_task_id": review.review_task_id,
                        "decision_id": result.decision_id,
                        "status": "decided",
                    }
                except Exception as exc:  # noqa: BLE001 - report per-item failure
                    return {
                        "review_task_id": review.review_task_id,
                        "status": "failed",
                        "error": _safe_exception_message(exc),
                    }

        results = await asyncio.gather(*(decide(review) for review in selected))
        return {
            "tenant_id": tenant_id,
            "dry_run": False,
            "decision": decision,
            "selected": len(selected),
            "decided": sum(1 for item in results if item["status"] == "decided"),
            "failed": sum(1 for item in results if item["status"] == "failed"),
            "outbox": {"queued": True, "worker_managed": True},
            "results": results,
        }

    @app.post("/knowledge/reviews/{review_task_id}")
    async def decide_knowledge_review(
        review_task_id: str,
        request: Request,
        payload: KnowledgeReviewRequest,
    ) -> dict:
        actor_id, _roles = _require_knowledge_role(request, "admin", "reviewer")
        if not actor_id:
            raise HTTPException(403, "review decisions require a trusted actor_id")
        runtime = _require_knowledge_runtime()
        try:
            decision = await runtime.store.decide_review(
                tenant_id=_request_tenant(request),
                review_task_id=review_task_id,
                decision=payload.decision,
                reviewer_id=actor_id,
                reason=payload.reason,
                corrections=payload.corrections,
                evidence_anchor_ids=payload.evidence_anchor_ids,
                idempotency_key=payload.idempotency_key,
            )
        except Exception as exc:
            from ..knowledge.persistence import (
                IdempotencyConflictError,
                RecordNotFoundError,
                ReviewConflictError,
                TenantBoundaryError,
            )

            if isinstance(exc, (RecordNotFoundError, TenantBoundaryError)):
                raise HTTPException(404, "审核任务不存在") from exc
            if isinstance(exc, (IdempotencyConflictError, ReviewConflictError)):
                raise HTTPException(409, str(exc)) from exc
            if isinstance(exc, ValueError):
                raise HTTPException(422, str(exc)) from exc
            raise
        return decision.model_dump(mode="json")

    @app.get("/knowledge/graph/{source_record_id}")
    async def get_knowledge_graph(
        source_record_id: str,
        request: Request,
        version: str = Query(""),
        include_candidate: bool = Query(False),
    ) -> dict:
        runtime = _require_knowledge_runtime()
        if include_candidate:
            _require_knowledge_role(request, "admin", "reviewer")
        actor_id, roles = _actor_context(request)
        graph = await runtime.store.get_graph_projection(
            _request_tenant(request),
            source_record_id,
            version or None,
            include_candidate=include_candidate,
            actor_id=actor_id,
            actor_roles=roles,
        )
        if graph is None:
            raise HTTPException(404, "图投影不存在")
        return graph.model_dump(mode="json")

    @app.get("/knowledge/stats")
    async def knowledge_stats(request: Request) -> dict:
        runtime = _require_knowledge_runtime()
        tenant_id = _request_tenant(request)
        return {
            "tenant_id": tenant_id,
            "inventory": await runtime.store.inventory_stats(tenant_id),
            "claims": await runtime.store.claim_stats(tenant_id),
            "projections": await runtime.store.projection_stats(tenant_id),
        }

    @app.post("/knowledge/outbox/drain")
    async def drain_knowledge_outbox(
        request: Request, payload: KnowledgeOutboxRequest
    ) -> dict:
        _require_knowledge_role(request, "admin")
        runtime = _require_knowledge_runtime()
        result = await runtime.drain_outbox(
            tenant_id=_request_tenant(request), limit=payload.limit
        )
        return result.model_dump(mode="json")
