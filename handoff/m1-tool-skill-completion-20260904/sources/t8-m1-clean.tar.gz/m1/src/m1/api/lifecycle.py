"""FastAPI lifespan orchestration for the mutable M1 application runtime."""

from __future__ import annotations

from contextlib import asynccontextmanager
from types import ModuleType

from fastapi import FastAPI


def create_lifespan(runtime: ModuleType):
    """Bind startup/shutdown to ``m1.api.main`` without copying global state."""

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        try:
            await runtime.init_app()
            yield
        finally:
            await runtime._drain_tasks()
            await runtime._close_dependency_clients()
            await runtime._close_knowledge_runtime()
            if runtime.store is not None:
                await runtime.store.close()

    return lifespan
