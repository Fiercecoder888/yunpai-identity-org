"""FastAPI 应用入口。

端点:
  POST /ingest          上传文件, 触发处理
  GET  /tasks           列出任务 (可按状态过滤)
  GET  /tasks/{id}      查看任务详情
  GET  /review/queue    取待审核队列
  POST /review/{id}     提交人工审核结果
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import inspect
import json
import re
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from loguru import logger
from starlette.middleware.base import BaseHTTPMiddleware

from ..core.config import settings
from ..deps import WorkflowDeps, get_deps, init_deps
from ..state import TaskState, TaskStatus
from ..workflow import TaskStore, WorkflowEngine
from . import route_support as _route_support
from .adaptive_route_runtime import AdaptiveRouteRuntimeManager
from .contracts import (
    KnowledgeBackfillRequest,
    KnowledgeBulkReviewRequest,
    KnowledgeOutboxRequest,
    KnowledgeReassessRequest,
    KnowledgeReviewRequest,
    KnowledgeTenantRequest,
    ReportRequest,
    ReviewRequest,
)
from .lifecycle import create_lifespan

# Compatibility aliases retained for callers that imported the former private
# helpers from ``m1.api.main`` before the route split.
_attachment_headers = _route_support.attachment_headers
_build_batch_zip = _route_support.build_batch_zip
_classify_staged_upload = _route_support.classify_staged_upload
_media_type_for_path = _route_support.media_type_for_path
_safe_archive_name = _route_support.safe_archive_name
_safe_download_stem = _route_support.safe_download_stem
_save_upload_streaming = _route_support.save_upload_streaming
_state_detail = _route_support.state_detail
_state_summary = _route_support.state_summary

__all__ = [
    "KnowledgeBackfillRequest",
    "KnowledgeBulkReviewRequest",
    "KnowledgeOutboxRequest",
    "KnowledgeReassessRequest",
    "KnowledgeReviewRequest",
    "KnowledgeTenantRequest",
    "ReportRequest",
    "ReviewRequest",
    "app",
    "create_app",
]

# ----------------------------------------------------------------------
# 全局单例
# ----------------------------------------------------------------------
store: TaskStore | None = None
engine: WorkflowEngine | None = None
knowledge_runtime: Any | None = None
knowledge_init_error: str = ""
document_routing_runtime: Any | None = None
document_routing_status: dict[str, Any] = {
    "enabled": False,
    "mode": "shadow",
    "ready": True,
    "degraded": False,
    "error_type": None,
}
entity_routing_runtime: Any | None = None
entity_routing_status: dict[str, Any] = {
    "enabled": False,
    "ready": True,
    "degraded": False,
    "error_type": None,
}
tabular_layout_routing_runtime: Any | None = None
tabular_layout_routing_client: Any | None = None
tabular_layout_routing_status: dict[str, Any] = {
    "enabled": False,
    "ready": True,
    "degraded": False,
    "error_type": None,
}
_adaptive_route_manager = AdaptiveRouteRuntimeManager()
field_semantic_routing_runtime: Any | None = None
field_semantic_routing_client: Any | None = None
field_semantic_routing_status = _adaptive_route_manager.field_status
visual_region_routing_runtime: Any | None = None
visual_region_routing_client: Any | None = None
visual_region_routing_status = _adaptive_route_manager.visual_status
region_capability_routing_runtime: Any | None = None
region_capability_routing_client: Any | None = None
region_capability_routing_status = _adaptive_route_manager.region_status
content_region_routing_runtime: Any | None = None
content_region_routing_client: Any | None = None
content_region_routing_status = _adaptive_route_manager.content_status
_outbox_worker_task: asyncio.Task | None = None
_outbox_health_task: asyncio.Task | None = None
_outbox_health_by_tenant: dict[str, tuple[dict[str, Any] | None, str | None]] = {}
_outbox_tenant_tasks: dict[str, asyncio.Task] = {}
_outbox_tenant_reservations: dict[str, int] = {}
_outbox_tenant_started_at: dict[str, float] = {}
_outbox_worker_status: dict[str, Any] = {
    "enabled": False,
    "running": False,
    "last_started_at": None,
    "last_completed_at": None,
    "last_error_type": None,
    "registry_error_type": None,
    "tenant_count": 0,
    "health": None,
    "last_result": None,
}
_outbox_tenant_cursor = 0
_outbox_health_cursor = 0
_OUTBOX_HEALTH_PROBE_CONCURRENCY = 8
_OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS = 2.0
_OUTBOX_HEALTH_CYCLE_TIMEOUT_SECONDS = 5.0
_OUTBOX_REGISTRY_TIMEOUT_SECONDS = 2.0
_OUTBOX_TENANT_DRAIN_TIMEOUT_SECONDS = 60.0
_OUTBOX_TENANT_DRAIN_CONCURRENCY = 8
_OUTBOX_RETAINED_STALL_SECONDS = 60.0
# External projection leases last 300 seconds. Do not release a timed-out
# worker slot until that lease window has elapsed, then rely on attempt fencing
# to reject any stale completion.
_OUTBOX_RETAINED_MAX_SECONDS = 310.0
_KNOWLEDGE_HEALTH_TIMEOUT_SECONDS = 5.0
_processing_semaphore: asyncio.Semaphore | None = None

# 后台任务注册表: task_id -> asyncio.Task
# 持有引用避免被 GC (asyncio 对 task 是弱引用); task 完成后自动移除
_task_registry: dict[str, asyncio.Task] = {}

# 健康检查等不受鉴权保护的路径
OPEN_PATHS = {"/health", "/ready"}
_TENANT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")


def _normalize_tenant_id(value: str | None) -> str:
    """Return the stable tenant key used by task and knowledge persistence.

    Existing callers do not send a tenant and remain in ``default``.  Keeping
    the accepted alphabet deliberately small prevents ambiguous path/log keys
    and makes the same identifier safe for Postgres, Neo4j and object storage.
    """

    tenant_id = str(value or "default").strip().casefold()
    if not _TENANT_ID_RE.fullmatch(tenant_id):
        raise HTTPException(
            422,
            "tenant_id 只能包含小写字母、数字、点、下划线或连字符，且最长 64 位",
        )
    return tenant_id


@lru_cache(maxsize=8)
def _parse_tenant_credentials(raw: str) -> dict[str, dict[str, Any]]:
    """Parse a hash-only API credential map without ever storing plaintext keys."""

    if not raw.strip():
        return {}
    payload = json.loads(raw)
    if not isinstance(payload, dict):
        raise ValueError(  # noqa: TRY004 - configuration contract uses ValueError
            "TENANT_API_KEY_HASHES must be a JSON object"
        )
    result: dict[str, dict[str, Any]] = {}
    for digest, identity in payload.items():
        normalized_digest = str(digest).strip().casefold()
        if not re.fullmatch(r"[0-9a-f]{64}", normalized_digest):
            raise ValueError("tenant API key map contains a non-SHA256 key")
        if not isinstance(identity, dict):
            raise ValueError(  # noqa: TRY004 - configuration contract uses ValueError
                "tenant API key identity must be an object"
            )
        tenant_id = str(identity.get("tenant_id") or "").strip()
        if not tenant_id:
            raise ValueError("tenant API key identity is missing tenant_id")
        roles = identity.get("roles") or []
        if not isinstance(roles, list) or not all(
            isinstance(role, str) for role in roles
        ):
            raise ValueError("tenant API key roles must be a string list")
        result[normalized_digest] = {
            "tenant_id": tenant_id,
            "actor_id": str(identity.get("actor_id") or "api-key"),
            "roles": roles,
        }
    return result


def _safe_exception_message(exc: BaseException) -> str:
    """Return a bounded exception label without response bodies or credentials."""

    status = getattr(exc, "status_code", None)
    suffix = f" status={status}" if isinstance(status, int) else ""
    if exc.__class__.__name__ == "OperationalError":
        origin = str(getattr(exc, "orig", "")).lower()
        if "locked" in origin or "busy" in origin:
            suffix += " category=database_locked"
        elif "disk i/o" in origin:
            suffix += " category=storage_io"
        elif "unable to open" in origin:
            suffix += " category=database_unavailable"
    return f"{exc.__class__.__name__}{suffix}"


def _actor_context(request: Request) -> tuple[str, set[str]]:
    if getattr(request.state, "identity_bound", False):
        return (
            str(getattr(request.state, "actor_id", "")),
            {
                str(item).strip().casefold()
                for item in getattr(request.state, "actor_roles", ())
                if str(item).strip()
            },
        )
    actor_id = request.headers.get("X-Actor-ID", "").strip()
    roles = {
        item.strip().casefold()
        for item in request.headers.get("X-Actor-Roles", "").split(",")
        if item.strip()
    }
    return actor_id, roles


def _require_knowledge_role(request: Request, *allowed: str) -> tuple[str, set[str]]:
    actor_id, roles = _actor_context(request)
    accepted = {role.casefold() for role in allowed}
    if not roles.intersection(accepted):
        raise HTTPException(403, f"需要以下角色之一: {', '.join(sorted(accepted))}")
    return actor_id, roles


def _request_tenant(request: Request) -> str:
    return _normalize_tenant_id(getattr(request.state, "tenant_id", None))


def _form_tenant(request: Request, tenant_id: str) -> str:
    header_tenant = _request_tenant(request)
    if not tenant_id.strip():
        return header_tenant
    resolved = _normalize_tenant_id(tenant_id)
    if resolved != header_tenant:
        raise HTTPException(403, "表单 tenant_id 必须与 X-Tenant-ID 一致")
    return resolved


def _require_knowledge_runtime():
    if knowledge_runtime is None:
        raise HTTPException(
            503,
            f"知识库运行时未就绪: {knowledge_init_error or 'disabled'}",
        )
    return knowledge_runtime


class ApiKeyMiddleware(BaseHTTPMiddleware):
    """静态 API Key 鉴权。

    - settings.api_auth_key 为空 → 不启用 (开发态默认)
    - 非空 → 除 OPEN_PATHS 外的所有请求需带 X-API-Key 头且匹配
    """

    async def dispatch(self, request: Request, call_next):
        auth_key = settings.api_auth_key
        tenant_credentials_enabled = bool(settings.tenant_api_key_hashes.strip())
        if (
            auth_key
            and not tenant_credentials_enabled
            and request.url.path not in OPEN_PATHS
        ):
            provided = request.headers.get("X-API-Key", "")
            if provided != auth_key:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "无效或缺失的 API Key (需 X-API-Key 头)"},
                )
        return await call_next(request)


class TenantBoundaryMiddleware(BaseHTTPMiddleware):
    """Hide task-scoped resources that belong to another tenant.

    The header is additive: legacy clients remain in ``default``.  Returning
    404 instead of 403 avoids disclosing whether another customer's task ID
    exists.
    """

    _RESOURCE_PATH = re.compile(r"^/(?:tasks|batch|review|files)/([^/]+)")

    async def dispatch(self, request: Request, call_next):
        if request.url.path in OPEN_PATHS:
            request.state.tenant_id = "default"
            request.state.actor_id = ""
            request.state.actor_roles = ()
            request.state.identity_bound = False
            return await call_next(request)

        raw_credentials = settings.tenant_api_key_hashes
        try:
            credentials = _parse_tenant_credentials(raw_credentials)
        except (TypeError, ValueError, json.JSONDecodeError):
            return JSONResponse(
                status_code=500,
                content={"detail": "tenant credential configuration is invalid"},
            )
        if credentials:
            provided_key = request.headers.get("X-API-Key", "")
            if not provided_key:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "缺少租户 API Key"},
                )
            provided_hash = hashlib.sha256(provided_key.encode("utf-8")).hexdigest()
            identity = next(
                (
                    value
                    for digest, value in credentials.items()
                    if hmac.compare_digest(digest, provided_hash)
                ),
                None,
            )
            if identity is None:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "无效的租户 API Key"},
                )
            try:
                tenant_id = _normalize_tenant_id(str(identity["tenant_id"]))
                requested_tenant = request.headers.get("X-Tenant-ID", "").strip()
                if (
                    requested_tenant
                    and _normalize_tenant_id(requested_tenant) != tenant_id
                ):
                    return JSONResponse(
                        status_code=404, content={"detail": "资源不存在"}
                    )
            except HTTPException as exc:
                return JSONResponse(
                    status_code=exc.status_code, content={"detail": exc.detail}
                )
            request.state.actor_id = str(identity.get("actor_id") or "api-key")
            request.state.actor_roles = tuple(identity.get("roles") or ())
            request.state.identity_bound = True
        else:
            try:
                tenant_id = _normalize_tenant_id(request.headers.get("X-Tenant-ID"))
            except HTTPException as exc:
                return JSONResponse(
                    status_code=exc.status_code, content={"detail": exc.detail}
                )
            request.state.actor_id = request.headers.get("X-Actor-ID", "").strip()
            request.state.actor_roles = tuple(
                item.strip()
                for item in request.headers.get("X-Actor-Roles", "").split(",")
                if item.strip()
            )
            request.state.identity_bound = False
        match = self._RESOURCE_PATH.match(request.url.path)
        if match is not None and store is not None:
            resource_id = match.group(1)
            if resource_id not in {"queue"}:
                state = await store.load(resource_id)
                if state is not None and state.tenant_id != tenant_id:
                    return JSONResponse(
                        status_code=404, content={"detail": "资源不存在"}
                    )
        request.state.tenant_id = tenant_id
        return await call_next(request)


def _knowledge_embedding_provider_for(
    settings_obj: Any,
    *,
    schema_dimensions: int,
) -> object | None:
    """Build the embedding client without leaking or coupling credentials.

    Dedicated values take precedence. ``None`` preserves compatibility with
    deployments that historically reused VLM settings, while an explicit
    empty API key selects an unauthenticated local endpoint.
    """

    if not settings_obj.knowledge_embeddings_enabled:
        return None
    if settings_obj.knowledge_embedding_dimensions != schema_dimensions:
        raise ValueError(
            "KNOWLEDGE_EMBEDDING_DIMENSIONS must match the pgvector "
            f"schema ({schema_dimensions})"
        )
    configured_base_url = getattr(settings_obj, "knowledge_embedding_base_url", None)
    configured_api_key = getattr(settings_obj, "knowledge_embedding_api_key", None)
    legacy_api_key = str(getattr(settings_obj, "vlm_api_key", ""))
    # Preserve the prior disabled-without-VLM-key behavior unless a dedicated
    # embedding endpoint or credential has explicitly been supplied.
    if (
        configured_base_url is None
        and configured_api_key is None
        and not legacy_api_key.strip()
    ):
        return None
    base_url = (
        str(getattr(settings_obj, "vlm_base_url", ""))
        if configured_base_url is None
        else str(configured_base_url)
    )
    api_key = legacy_api_key if configured_api_key is None else str(configured_api_key)
    if not base_url.strip():
        raise ValueError("KNOWLEDGE_EMBEDDING_BASE_URL must not be empty")

    from ..knowledge.embeddings import OpenAIEmbeddingProvider

    return OpenAIEmbeddingProvider(
        api_key=api_key,
        base_url=base_url,
        model=settings_obj.knowledge_embedding_model,
        dimensions=settings_obj.knowledge_embedding_dimensions,
        batch_size=settings_obj.knowledge_embedding_batch_size,
    )


async def _update_knowledge_task_status(
    task_id: str,
    *,
    status: str,
    document_id: str = "",
    version_id: str = "",
    error: str = "",
) -> None:
    if store is None:
        return
    await store.update_knowledge_status(
        task_id,
        status=status,
        document_id=document_id,
        version_id=version_id,
        error=error,
    )


def _final_route_profile_ids(document: dict[str, Any]) -> tuple[str, ...]:
    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    routing = metadata.get("adaptive_routing") if isinstance(metadata, dict) else None
    if (
        not isinstance(routing, dict)
        or routing.get("status") != "resolved"
        or routing.get("policy_applied") is not True
    ):
        return ()
    execution = metadata.get("route_execution") if isinstance(metadata, dict) else None
    if (
        not isinstance(execution, dict)
        or execution.get("primary_attempted") is not True
    ):
        # A persisted/replayed route plan is audit metadata.  It becomes an
        # operational observation only after this invocation ran the current
        # active plan's primary target.
        return ()
    profile_id = str(routing.get("applied_profile_id") or "").strip()
    return (profile_id,) if profile_id else ()


def _final_route_outcome_accepted(document: dict[str, Any], state: Any) -> bool:
    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    execution = metadata.get("route_execution") if isinstance(metadata, dict) else None
    if not isinstance(execution, dict) or execution.get("primary_applied") is not True:
        return False
    if bool(document.get("needs_review")):
        return False
    if isinstance(metadata, dict) and metadata.get("knowledge_sync_eligible") is False:
        return False
    review = document.get("review")
    review_status = (
        str(review.get("status") or "").strip().casefold()
        if isinstance(review, dict)
        else ""
    )
    if review_status:
        return review_status in {"approved", "reviewed"}
    authority = getattr(state, "mineru_shadow", None)
    return isinstance(authority, dict) and authority.get("authority_selected") is True


def _final_route_failure_code(document: dict[str, Any], state: Any) -> str:
    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    execution = metadata.get("route_execution") if isinstance(metadata, dict) else None
    if isinstance(execution, dict) and execution.get("primary_applied") is not True:
        route_code = str(execution.get("outcome_code") or "").strip()
        return route_code or "ROUTE_PRIMARY_EXECUTION_FAILED"
    if bool(document.get("needs_review")):
        return "DOCUMENT_REQUIRES_REVIEW"
    if isinstance(metadata, dict) and metadata.get("knowledge_sync_eligible") is False:
        return "DOCUMENT_KNOWLEDGE_INELIGIBLE"
    review = document.get("review")
    review_status = (
        str(review.get("status") or "").strip().casefold()
        if isinstance(review, dict)
        else ""
    )
    if review_status:
        return "DOCUMENT_REVIEW_NOT_APPROVED"
    authority = getattr(state, "mineru_shadow", None)
    if isinstance(authority, dict) and authority.get("authority_selected") is not True:
        return "DOCUMENT_AUTHORITY_NOT_SELECTED"
    return "DOCUMENT_NOT_FINAL"


async def _record_final_document_route_outcomes(
    task_id: str,
    document: dict[str, Any],
    *,
    state: Any,
    tenant_id: str,
) -> None:
    runtime = document_routing_runtime
    profile_ids = _final_route_profile_ids(document)
    if runtime is None or not profile_ids:
        return

    success = _final_route_outcome_accepted(document, state)
    error_code = "" if success else _final_route_failure_code(document, state)
    for profile_id in profile_ids:
        await runtime.record_outcome(
            tenant_id=tenant_id,
            task_id=task_id,
            profile_id=profile_id,
            success=success,
            latency_ms=0,
            error_code=error_code,
            attempt=0,
        )


async def _sync_document_to_knowledge(task_id: str, document: dict[str, Any]) -> Any:
    """TaskStore sink; always leaves a durable, user-visible sync outcome."""

    if knowledge_runtime is None:
        return
    from ..knowledge.eligibility import knowledge_sync_eligibility

    state = await store.load(task_id) if store is not None else None
    tenant_id = (
        state.tenant_id if state is not None else settings.knowledge_default_tenant_id
    )
    eligible, reason = knowledge_sync_eligibility(document)
    if not eligible:
        await _update_knowledge_task_status(
            task_id,
            status="skipped",
            error=reason,
        )
        try:
            await _record_final_document_route_outcomes(
                task_id,
                document,
                state=state,
                tenant_id=tenant_id,
            )
        except Exception as exc:
            logger.warning(
                "Final document route outcome persistence degraded error_type={}",
                exc.__class__.__name__,
            )
            if settings.document_router_required:
                raise
        return None
    await _update_knowledge_task_status(task_id, status="pending", error="")
    try:
        outcome = await knowledge_runtime.sync_document(
            tenant_id=tenant_id,
            task_id=task_id,
            document=document,
        )
    except Exception as exc:
        await _update_knowledge_task_status(
            task_id,
            status="failed",
            error=exc.__class__.__name__,
        )
        raise
    await _update_knowledge_task_status(
        task_id,
        status=outcome.status,
        document_id=outcome.document.document_id,
        version_id=outcome.document.version_id,
        error=outcome.graph_error or outcome.embedding_error,
    )
    try:
        await _record_final_document_route_outcomes(
            task_id,
            document,
            state=state,
            tenant_id=tenant_id,
        )
    except Exception as exc:
        logger.warning(
            "Final document route outcome persistence degraded error_type={}",
            exc.__class__.__name__,
        )
        if settings.document_router_required:
            raise
    return outcome


def _document_routing_status_snapshot() -> dict[str, Any]:
    """Return a secret-free local status snapshot for health composition."""

    return dict(document_routing_status)


def _entity_routing_status_snapshot() -> dict[str, Any]:
    """Return a secret-free local entity-router startup snapshot."""

    return dict(entity_routing_status)


def _tabular_layout_routing_status_snapshot() -> dict[str, Any]:
    """Return startup state merged with secret-free runtime telemetry."""

    payload = dict(tabular_layout_routing_status)
    runtime = tabular_layout_routing_runtime
    snapshot = getattr(runtime, "status_snapshot", None)
    if callable(snapshot):
        runtime_payload = snapshot()
        if isinstance(runtime_payload, dict):
            payload.update(runtime_payload)
    return payload


def _field_semantic_routing_status_snapshot() -> dict[str, Any]:
    return _adaptive_route_manager.snapshot("field")


def _visual_region_routing_status_snapshot() -> dict[str, Any]:
    return _adaptive_route_manager.snapshot("visual")


def _region_capability_routing_status_snapshot() -> dict[str, Any]:
    return _adaptive_route_manager.snapshot("region")


def _content_region_routing_status_snapshot() -> dict[str, Any]:
    return _adaptive_route_manager.snapshot("content")


def _sync_adaptive_route_globals() -> None:
    """Keep legacy module attributes aligned with the extracted manager."""

    global field_semantic_routing_client, field_semantic_routing_runtime
    global field_semantic_routing_status
    global visual_region_routing_client, visual_region_routing_runtime
    global visual_region_routing_status
    global region_capability_routing_client, region_capability_routing_runtime
    global region_capability_routing_status
    global content_region_routing_client, content_region_routing_runtime
    global content_region_routing_status
    field_semantic_routing_client = _adaptive_route_manager.field_client
    field_semantic_routing_runtime = _adaptive_route_manager.field_runtime
    field_semantic_routing_status = _adaptive_route_manager.field_status
    visual_region_routing_client = _adaptive_route_manager.visual_client
    visual_region_routing_runtime = _adaptive_route_manager.visual_runtime
    visual_region_routing_status = _adaptive_route_manager.visual_status
    region_capability_routing_client = _adaptive_route_manager.region_client
    region_capability_routing_runtime = _adaptive_route_manager.region_runtime
    region_capability_routing_status = _adaptive_route_manager.region_status
    content_region_routing_client = _adaptive_route_manager.content_client
    content_region_routing_runtime = _adaptive_route_manager.content_runtime
    content_region_routing_status = _adaptive_route_manager.content_status


def _wire_region_capability_consumer(document_parser: Any | None) -> tuple[str, ...]:
    return _adaptive_route_manager.wire_region_consumer(document_parser)


def _record_region_capability_consumers(
    settings_obj: Any,
    consumers: tuple[str, ...],
) -> None:
    _adaptive_route_manager.record_region_consumers(settings_obj, consumers)


def _record_content_region_consumers(
    settings_obj: Any,
    consumers: tuple[str, ...],
) -> None:
    _adaptive_route_manager.record_content_consumers(settings_obj, consumers)


def _wire_field_semantic_consumers(
    *,
    mineru_shadow_runner: Any | None,
) -> tuple[str, ...]:
    return _adaptive_route_manager.wire_field_consumers(
        mineru_shadow_runner=mineru_shadow_runner,
    )


def _record_field_semantic_consumers(
    settings_obj: Any,
    consumers: tuple[str, ...],
) -> None:
    _adaptive_route_manager.record_field_consumers(settings_obj, consumers)


async def _init_field_semantic_routing(settings_obj: Any) -> None:
    try:
        await _adaptive_route_manager.init_field(settings_obj, knowledge_runtime)
    finally:
        _sync_adaptive_route_globals()


async def _close_field_semantic_routing_runtime() -> None:
    try:
        await _adaptive_route_manager.close_field()
    finally:
        _sync_adaptive_route_globals()


async def _init_visual_region_routing(settings_obj: Any) -> None:
    try:
        await _adaptive_route_manager.init_visual(settings_obj, knowledge_runtime)
    finally:
        _sync_adaptive_route_globals()


async def _close_visual_region_routing_runtime() -> None:
    try:
        await _adaptive_route_manager.close_visual()
    finally:
        _sync_adaptive_route_globals()


async def _init_region_capability_routing(settings_obj: Any) -> None:
    try:
        await _adaptive_route_manager.init_region(settings_obj, knowledge_runtime)
    finally:
        _sync_adaptive_route_globals()


async def _close_region_capability_routing_runtime() -> None:
    try:
        await _adaptive_route_manager.close_region()
    finally:
        _sync_adaptive_route_globals()


async def _init_content_region_routing(settings_obj: Any) -> None:
    try:
        await _adaptive_route_manager.init_content(settings_obj, knowledge_runtime)
    finally:
        _sync_adaptive_route_globals()


async def _close_content_region_routing_runtime() -> None:
    try:
        await _adaptive_route_manager.close_content()
    finally:
        _sync_adaptive_route_globals()


async def _init_adaptive_route_runtimes(settings_obj: Any) -> None:
    """Initialize extension routers and unwind earlier clients on failure."""

    try:
        await _init_field_semantic_routing(settings_obj)
        await _init_visual_region_routing(settings_obj)
        await _init_region_capability_routing(settings_obj)
        await _init_content_region_routing(settings_obj)
    except Exception:
        await _close_content_region_routing_runtime()
        await _close_region_capability_routing_runtime()
        await _close_visual_region_routing_runtime()
        await _close_field_semantic_routing_runtime()
        raise


async def _init_tabular_layout_routing(
    settings_obj: Any,
    mineru_shadow_runner: Any | None,
) -> None:
    """Attach governed tabular profiles to MinerU Instructor.

    The selector owns an independent transport contract. Deployments may point
    both consumers at the same model process, but credentials are never copied
    from MinerU, VLM, or document-router integrations.
    """

    global tabular_layout_routing_client
    global tabular_layout_routing_runtime, tabular_layout_routing_status
    enabled = bool(getattr(settings_obj, "tabular_layout_router_enabled", False))
    required = bool(getattr(settings_obj, "tabular_layout_router_required", False))
    tabular_layout_routing_client = None
    tabular_layout_routing_runtime = None
    tabular_layout_routing_status = {
        "enabled": enabled,
        "required": required,
        "ready": not enabled,
        "degraded": False,
        "error_type": None,
    }
    if not enabled:
        return

    client = None
    runtime = None
    try:
        if knowledge_runtime is None:
            raise RuntimeError("tabular layout routing requires the knowledge runtime")
        instructor = getattr(mineru_shadow_runner, "instructor_service", None)
        if instructor is None:
            raise RuntimeError(
                "tabular layout routing requires the MinerU Instructor service"
            )
        from ..documents.parsing.tabular_layout_routing import (
            PydanticTabularLayoutSelector,
            TabularLayoutRoutingRuntime,
        )
        from ..structured_llm import StructuredModelClient

        base_url = str(settings_obj.resolved_tabular_layout_router_base_url)
        api_key = str(settings_obj.resolved_tabular_layout_router_api_key)
        model = str(settings_obj.resolved_tabular_layout_router_model)
        timeout = float(settings_obj.tabular_layout_router_timeout_seconds)
        client = StructuredModelClient(
            api_key=api_key,
            base_url=base_url,
            model=model,
            temperature=0.0,
            max_tokens=1024,
            enable_thinking=False,
            timeout=timeout,
            retries=1,
            output_mode="prompted",
            validation_retry_timeout_per_attempt=True,
        )
        runtime = TabularLayoutRoutingRuntime(
            store=knowledge_runtime.store,
            embedding_provider=knowledge_runtime.embedding_provider,
            selector=PydanticTabularLayoutSelector(client),
            required=required,
            circuit_failures=int(settings_obj.tabular_layout_router_circuit_failures),
            circuit_seconds=float(settings_obj.tabular_layout_router_circuit_seconds),
        )
        if required:
            probe = getattr(client, "probe", None)
            if not callable(probe):
                raise TypeError("tabular layout router model probe is unavailable")
            result = await probe()
            if isinstance(result, dict) and result.get("ready") is False:
                raise RuntimeError("tabular layout router model probe failed")
        instructor.tabular_layout_router = runtime
        tabular_layout_routing_client = client
        tabular_layout_routing_runtime = runtime
        tabular_layout_routing_status.update(ready=True, degraded=False)
        logger.info("Tabular layout routing runtime initialized")
    except Exception as exc:
        if client is not None:
            close = getattr(client, "close", None)
            if callable(close):
                result = close()
                if inspect.isawaitable(result):
                    await result
        tabular_layout_routing_runtime = runtime
        tabular_layout_routing_status.update(
            ready=False,
            degraded=True,
            error_type=exc.__class__.__name__,
        )
        logger.warning(
            "Tabular layout routing initialization degraded error_type={}",
            exc.__class__.__name__,
        )
        if required:
            tabular_layout_routing_runtime = None
            raise


async def _close_tabular_layout_routing_runtime() -> None:
    global tabular_layout_routing_client
    global tabular_layout_routing_runtime, tabular_layout_routing_status
    client = tabular_layout_routing_client
    runtime = tabular_layout_routing_runtime
    tabular_layout_routing_client = None
    tabular_layout_routing_runtime = None
    if runtime is not None:
        close = getattr(runtime, "close", None)
        if callable(close):
            result = close()
            if inspect.isawaitable(result):
                await result
    if client is not None:
        close = getattr(client, "close", None)
        if callable(close):
            result = close()
            if inspect.isawaitable(result):
                await result
    tabular_layout_routing_status = {
        **tabular_layout_routing_status,
        "ready": not bool(tabular_layout_routing_status.get("enabled")),
    }


async def _init_entity_routing(settings_obj: Any) -> None:
    """Attach optional entity identity routing after knowledge storage is ready."""

    global entity_routing_runtime, entity_routing_status
    entity_routing_runtime = None
    entity_routing_status = {
        "enabled": bool(settings_obj.entity_router_enabled),
        "ready": not bool(settings_obj.entity_router_enabled),
        "degraded": False,
        "error_type": None,
    }
    if not settings_obj.entity_router_enabled:
        if knowledge_runtime is not None:
            knowledge_runtime.entity_routing_runtime = None
        return
    runtime = None
    try:
        if knowledge_runtime is None:
            raise RuntimeError("entity routing requires the knowledge runtime")
        from ..knowledge.entity_routing_runtime import EntityRoutingRuntime

        runtime = EntityRoutingRuntime.from_settings(
            settings_obj,
            store=knowledge_runtime.store,
            embedding_provider=knowledge_runtime.embedding_provider,
        )
        model_client = getattr(runtime, "_owned_model_client", None)
        probe = getattr(model_client, "probe", None)
        if not callable(probe):
            raise TypeError("entity router model probe is unavailable")
        result = await probe()
        if isinstance(result, dict) and result.get("ready") is False:
            raise RuntimeError("entity router model probe failed")
        entity_routing_runtime = runtime
        knowledge_runtime.entity_routing_runtime = runtime
        entity_routing_status.update(ready=True, degraded=False, error_type=None)
        logger.info("Entity identity routing runtime initialized")
    except Exception as exc:
        entity_routing_runtime = runtime
        if knowledge_runtime is not None:
            knowledge_runtime.entity_routing_runtime = runtime
        entity_routing_status.update(
            ready=False,
            degraded=True,
            error_type=exc.__class__.__name__,
        )
        logger.warning(
            "Entity identity routing initialization degraded error_type={}",
            exc.__class__.__name__,
        )
        if settings_obj.entity_router_required:
            if runtime is not None:
                await runtime.close()
            entity_routing_runtime = None
            if knowledge_runtime is not None:
                knowledge_runtime.entity_routing_runtime = None
            raise


async def _close_entity_routing_runtime() -> None:
    global entity_routing_runtime, entity_routing_status
    runtime = entity_routing_runtime
    entity_routing_runtime = None
    if knowledge_runtime is not None:
        knowledge_runtime.entity_routing_runtime = None
    if runtime is not None:
        await runtime.close()
    entity_routing_status = {
        **entity_routing_status,
        "ready": not bool(entity_routing_status.get("enabled")),
    }


async def _init_document_routing(settings_obj: Any) -> None:
    """Build the governed router only after the knowledge runtime is ready."""

    global document_routing_runtime, document_routing_status
    document_routing_runtime = None
    document_routing_status = {
        "enabled": bool(settings_obj.document_router_enabled),
        "mode": str(settings_obj.document_router_mode),
        "ready": not bool(settings_obj.document_router_enabled),
        "degraded": False,
        "error_type": None,
    }
    if not settings_obj.document_router_enabled:
        return

    runtime = None
    try:
        if knowledge_runtime is None:
            raise RuntimeError("document routing requires the knowledge runtime")
        from ..documents.parsing.document_routing_runtime import (
            DocumentRoutingRuntime,
        )

        runtime = DocumentRoutingRuntime.from_settings(
            settings_obj,
            store=knowledge_runtime.store,
            embedding_provider=knowledge_runtime.embedding_provider,
        )
        model_client = getattr(runtime, "_owned_model_client", None)
        probe = getattr(model_client, "probe", None)
        if not callable(probe):
            raise TypeError("document router model probe is unavailable")
        probe_result = await probe()
        if isinstance(probe_result, dict) and probe_result.get("ready") is False:
            raise RuntimeError("document router model probe failed")
        document_routing_runtime = runtime
        document_routing_status.update(ready=True, degraded=False, error_type=None)
        logger.info(
            "Document routing runtime initialized mode={}",
            settings_obj.document_router_mode,
        )
    except Exception as exc:
        document_routing_runtime = runtime
        document_routing_status.update(
            ready=False,
            degraded=True,
            error_type=exc.__class__.__name__,
        )
        logger.warning(
            "Document routing initialization degraded error_type={}",
            exc.__class__.__name__,
        )
        if settings_obj.document_router_required:
            if runtime is not None:
                await runtime.close()
            document_routing_runtime = None
            raise


async def _close_document_routing_runtime() -> None:
    global document_routing_runtime, document_routing_status
    runtime = document_routing_runtime
    document_routing_runtime = None
    if runtime is not None:
        await runtime.close()
    document_routing_status = {
        **document_routing_status,
        "ready": not bool(document_routing_status.get("enabled")),
    }


async def _init_knowledge(settings_obj) -> None:
    global knowledge_runtime, knowledge_init_error
    knowledge_runtime = None
    knowledge_init_error = ""
    if not settings_obj.knowledge_enabled:
        if store is not None:
            store.set_document_sink(None)
        return
    knowledge_store = None
    graph_sink = None
    lightrag_shadow = None
    runtime = None
    try:
        from ..knowledge.lightrag_shadow import LightRAGShadowClient
        from ..knowledge.persistence import (
            KNOWLEDGE_EMBEDDING_DIMENSIONS,
            KnowledgeStore,
        )
        from ..knowledge.runtime import KnowledgeRuntime
        from ..knowledge.sinks import InMemoryGraphSink, Neo4jGraphSink

        knowledge_store = KnowledgeStore(settings_obj.resolved_knowledge_database_url)
        backend = settings_obj.graph_backend.strip().casefold()
        if backend == "memory":
            graph_sink = InMemoryGraphSink()
        elif backend == "neo4j":
            graph_sink = Neo4jGraphSink(
                settings_obj.neo4j_uri,
                auth=(settings_obj.neo4j_user, settings_obj.neo4j_password),
                database=settings_obj.neo4j_database,
            )
        else:
            raise ValueError(f"unsupported graph backend: {backend}")
        embedding_provider = _knowledge_embedding_provider_for(
            settings_obj,
            schema_dimensions=KNOWLEDGE_EMBEDDING_DIMENSIONS,
        )
        if settings_obj.lightrag_shadow_enabled:
            lightrag_shadow = LightRAGShadowClient(
                settings_obj.lightrag_base_url,
                api_key=settings_obj.lightrag_api_key,
                workspace=settings_obj.lightrag_workspace,
                timeout_seconds=settings_obj.lightrag_timeout_seconds,
            )
        runtime = KnowledgeRuntime(
            knowledge_store,
            graph_sink,
            auto_project=settings_obj.knowledge_auto_project,
            embedding_provider=embedding_provider,
            lightrag_shadow=lightrag_shadow,
            outbox_max_attempts=settings_obj.knowledge_outbox_max_attempts,
        )
        # Local SQLite/test stores own their schema so a fresh development
        # database remains usable.  Production PostgreSQL is still strictly
        # validation-only unless the one-shot migration service explicitly
        # enables startup migration through the setting.
        migrate_schema = bool(settings_obj.knowledge_migrate_on_startup)
        if knowledge_store.engine.url.get_backend_name() == "sqlite":
            migrate_schema = True
        await runtime.init(
            default_tenant_id=_normalize_tenant_id(
                settings_obj.knowledge_default_tenant_id
            ),
            default_tenant_name=settings_obj.knowledge_default_tenant_name,
            migrate_schema=migrate_schema,
        )
        knowledge_runtime = runtime
        _start_outbox_worker(settings_obj)
        if store is not None:
            store.set_document_sink(_sync_document_to_knowledge)
        logger.info(
            "Knowledge runtime initialized wiki_backend={} graph_backend={}",
            knowledge_store.engine.url.get_backend_name(),
            backend,
        )
    except Exception as exc:
        knowledge_init_error = exc.__class__.__name__
        logger.error(
            "Knowledge runtime initialization failed error_type={}",
            knowledge_init_error,
        )
        if store is not None:
            store.set_document_sink(None)
        try:
            if runtime is not None:
                await runtime.close()
            else:
                if graph_sink is not None:
                    await asyncio.to_thread(graph_sink.close)
                if lightrag_shadow is not None:
                    await lightrag_shadow.close()
                if knowledge_store is not None:
                    await knowledge_store.close()
        except Exception as cleanup_exc:  # noqa: BLE001
            logger.warning(
                "Knowledge runtime cleanup failed error_type={}",
                cleanup_exc.__class__.__name__,
            )
        if settings_obj.knowledge_required:
            raise


async def _close_knowledge_runtime() -> None:
    global knowledge_runtime, _outbox_health_task, _outbox_worker_task
    worker = _outbox_worker_task
    _outbox_worker_task = None
    health_worker = _outbox_health_task
    _outbox_health_task = None
    tenant_tasks = list(_outbox_tenant_tasks.values())
    _outbox_tenant_tasks.clear()
    _outbox_tenant_reservations.clear()
    _outbox_tenant_started_at.clear()
    _outbox_health_by_tenant.clear()
    tasks = [
        task for task in (worker, health_worker, *tenant_tasks) if task is not None
    ]
    for task in tasks:
        task.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _outbox_worker_status["running"] = False
    await _close_tabular_layout_routing_runtime()
    await _close_content_region_routing_runtime()
    await _close_region_capability_routing_runtime()
    await _close_visual_region_routing_runtime()
    await _close_field_semantic_routing_runtime()
    await _close_document_routing_runtime()
    await _close_entity_routing_runtime()
    runtime = knowledge_runtime
    knowledge_runtime = None
    if runtime is not None:
        await runtime.close()


def _utc_timestamp() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat()


def _configured_outbox_tenant_ids(settings_obj: Any) -> list[str]:
    """Return configured tenant IDs in deterministic, duplicate-free order."""

    candidates: list[str] = [str(settings_obj.knowledge_default_tenant_id)]
    explicit = getattr(settings_obj, "knowledge_outbox_tenant_ids_list", ())
    if isinstance(explicit, str):
        candidates.extend(explicit.split(","))
    else:
        candidates.extend(str(item) for item in (explicit or ()))

    raw_credentials = str(getattr(settings_obj, "tenant_api_key_hashes", "") or "")
    if raw_credentials.strip():
        credentials = _parse_tenant_credentials(raw_credentials)
        candidates.extend(
            str(identity["tenant_id"]) for identity in credentials.values()
        )

    tenant_ids: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        if not str(candidate).strip():
            continue
        tenant_id = _normalize_tenant_id(candidate)
        if tenant_id not in seen:
            seen.add(tenant_id)
            tenant_ids.append(tenant_id)
    return tenant_ids


async def _register_configured_outbox_tenants(settings_obj: Any) -> list[str]:
    """Persist startup tenants when the TaskStore supports the registry API."""

    tenant_ids = _configured_outbox_tenant_ids(settings_obj)
    register = getattr(store, "register_outbox_tenant", None)
    if callable(register):
        for tenant_id in tenant_ids:
            await register(tenant_id)
    return tenant_ids


async def _list_outbox_tenant_ids(settings_obj: Any) -> list[str]:
    """Refresh the durable registry while retaining single-tenant compatibility."""

    tenant_ids = _configured_outbox_tenant_ids(settings_obj)
    listed = getattr(store, "list_outbox_tenant_ids", None)
    if not callable(listed):
        return tenant_ids

    seen = set(tenant_ids)
    for candidate in await listed():
        try:
            tenant_id = _normalize_tenant_id(str(candidate))
        except HTTPException:
            logger.warning("Ignoring invalid tenant ID in outbox registry")
            continue
        if tenant_id not in seen:
            seen.add(tenant_id)
            tenant_ids.append(tenant_id)
    return tenant_ids


def _outbox_cycle_plan(
    tenant_ids: list[str],
    *,
    cursor: int,
    batch_size: int,
    max_participants: int = _OUTBOX_TENANT_DRAIN_CONCURRENCY,
) -> tuple[list[tuple[str, int]], int]:
    """Allocate one concurrent wave from a bounded global drain budget."""

    if not tenant_ids:
        return [], 0
    start = cursor % len(tenant_ids)
    ordered = tenant_ids[start:] + tenant_ids[:start]
    allocation_count = min(len(ordered), batch_size)
    participant_count = min(allocation_count, max(0, int(max_participants)))
    if participant_count == 0:
        return [], start
    participants = ordered[:participant_count]
    # Quotas are calculated across every tenant that could consume at least
    # one event this tick, not only the first concurrent wave. This keeps a
    # sparse tenant from reserving a large unused share of the global budget.
    base_limit, extra = divmod(batch_size, allocation_count)
    plan = [
        (tenant_id, base_limit + (1 if index < extra else 0))
        for index, tenant_id in enumerate(participants)
    ]
    advance = participant_count if len(tenant_ids) > participant_count else 1
    return plan, (start + advance) % len(tenant_ids)


def _outbox_retained_status() -> dict[str, Any]:
    """Return anonymous retained-task pressure for health reporting."""

    now = asyncio.get_running_loop().time()
    active_tenants = [
        tenant_id for tenant_id, task in _outbox_tenant_tasks.items() if not task.done()
    ]
    ages = [
        max(0.0, now - _outbox_tenant_started_at.get(tenant_id, now))
        for tenant_id in active_tenants
    ]
    oldest = max(ages, default=0.0)
    return {
        "retained_count": len(active_tenants),
        "retained_reserved": sum(
            max(0, int(_outbox_tenant_reservations.get(tenant_id, 0)))
            for tenant_id in active_tenants
        ),
        "oldest_retained_age_seconds": round(oldest, 3),
        "retained_stalled": oldest >= _OUTBOX_RETAINED_STALL_SECONDS,
    }


async def _drain_outbox_cycle(
    settings_obj: Any,
    *,
    tenant_ids: list[str],
    cursor: int,
    batch_size: int,
    cycle_timeout_seconds: float | None = None,
) -> tuple[dict[str, Any], int]:
    """Drain fair concurrent waves within one time and lease budget."""

    runtime = knowledge_runtime
    loop = asyncio.get_running_loop()
    expired_tasks: list[asyncio.Task] = []
    retained_expired = 0
    for tenant_id, task in list(_outbox_tenant_tasks.items()):
        started_at = _outbox_tenant_started_at.setdefault(tenant_id, loop.time())
        if not task.done() and loop.time() - started_at >= _OUTBOX_RETAINED_MAX_SECONDS:
            task.cancel()
            expired_tasks.append(task)
            retained_expired += 1
            _outbox_tenant_tasks.pop(tenant_id, None)
            _outbox_tenant_reservations.pop(tenant_id, None)
            _outbox_tenant_started_at.pop(tenant_id, None)
            continue
        if task.done():
            _outbox_tenant_tasks.pop(tenant_id, None)
            _outbox_tenant_reservations.pop(tenant_id, None)
            _outbox_tenant_started_at.pop(tenant_id, None)
            try:
                task.result()
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # noqa: BLE001 - already reported by task
                logger.warning(
                    "Knowledge outbox retained tenant task failed error_type={}",
                    exc.__class__.__name__,
                )
    if expired_tasks:
        await asyncio.gather(*expired_tasks, return_exceptions=True)
    aggregate: dict[str, Any] = {
        "leased": 0,
        "delivered": 0,
        "retried": 0,
        "lifecycle_waits": 0,
        "terminal_failures": 0,
        "tenant_count": len(tenant_ids),
        "tenants_attempted": 0,
        "tenant_errors": retained_expired,
        "retained_expired": retained_expired,
    }
    aggregate.update(_outbox_retained_status())
    if runtime is None:
        return aggregate, cursor

    if not tenant_ids:
        return aggregate, 0
    start = cursor % len(tenant_ids)
    ordered_tenants = tenant_ids[start:] + tenant_ids[:start]
    eligible_tenants = [
        tenant_id
        for tenant_id in ordered_tenants
        if tenant_id not in _outbox_tenant_tasks
    ]
    timeout_seconds = (
        _OUTBOX_TENANT_DRAIN_TIMEOUT_SECONDS
        if cycle_timeout_seconds is None
        else max(0.001, float(cycle_timeout_seconds))
    )
    cycle_deadline = loop.time() + timeout_seconds

    async def drain_tenant(
        tenant_id: str, limit: int, *, timeout: float
    ) -> tuple[dict[str, Any] | None, str | None]:
        task = asyncio.create_task(
            runtime.drain_outbox(
                tenant_id=tenant_id,
                limit=limit,
                protect_fresh_seconds=float(
                    settings_obj.knowledge_outbox_protect_fresh_seconds
                ),
            ),
            name="m1-knowledge-outbox-tenant",
        )
        _outbox_tenant_tasks[tenant_id] = task
        _outbox_tenant_reservations[tenant_id] = limit
        _outbox_tenant_started_at[tenant_id] = loop.time()
        try:
            outcome = await asyncio.wait_for(
                asyncio.shield(task),
                timeout=timeout,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - other tenants must progress
            logger.warning(
                "Knowledge outbox tenant drain failed error_type={}",
                exc.__class__.__name__,
            )
            return None, exc.__class__.__name__
        finally:
            if task.done() and _outbox_tenant_tasks.get(tenant_id) is task:
                _outbox_tenant_tasks.pop(tenant_id, None)
                _outbox_tenant_reservations.pop(tenant_id, None)
                _outbox_tenant_started_at.pop(tenant_id, None)
        return outcome.model_dump(mode="json"), None

    first_error_type: str | None = "RetainedTaskExpired" if retained_expired else None
    remaining_budget = max(
        0,
        int(batch_size) - int(aggregate["retained_reserved"]),
    )
    attempted_count = 0
    last_attempted_tenant: str | None = None
    first_pass_plan, _ = _outbox_cycle_plan(
        eligible_tenants,
        cursor=0,
        batch_size=remaining_budget,
        max_participants=len(eligible_tenants),
    )
    saturated_tenants: list[str] = []

    async def run_wave(plan: list[tuple[str, int]], remaining_time: float) -> None:
        nonlocal first_error_type, remaining_budget

        aggregate["tenants_attempted"] += len(plan)
        reservation = sum(limit for _tenant_id, limit in plan)
        # Reserve the whole assigned quota before starting a wave. A tenant may
        # lease rows and then fail before it can report ``leased``; treating an
        # exception as zero would let later waves exceed the hard tick budget.
        remaining_budget -= reservation
        results = await asyncio.gather(
            *(
                drain_tenant(
                    tenant_id,
                    limit,
                    timeout=min(
                        _OUTBOX_TENANT_DRAIN_TIMEOUT_SECONDS,
                        remaining_time,
                    ),
                )
                for tenant_id, limit in plan
            )
        )
        for (tenant_id, limit), (result, error_type) in zip(plan, results, strict=True):
            if error_type is not None or result is None:
                aggregate["tenant_errors"] += 1
                first_error_type = first_error_type or error_type or "UnknownError"
                continue
            leased = min(limit, max(0, int(result.get("leased") or 0)))
            remaining_budget += max(0, limit - leased)
            if leased >= limit:
                saturated_tenants.append(tenant_id)
            for field in (
                "leased",
                "delivered",
                "retried",
                "lifecycle_waits",
                "terminal_failures",
            ):
                aggregate[field] += (
                    leased if field == "leased" else int(result.get(field) or 0)
                )

    # Keep first-pass quotas fixed for the whole cycle. Reclaimed quota is not
    # redistributed until every initially selected tenant has had one chance.
    while first_pass_plan:
        available_slots = max(
            0,
            _OUTBOX_TENANT_DRAIN_CONCURRENCY - len(_outbox_tenant_tasks),
        )
        remaining_time = cycle_deadline - loop.time()
        if available_slots <= 0 or remaining_time <= 0:
            break
        plan = first_pass_plan[:available_slots]
        del first_pass_plan[:available_slots]
        attempted_count += len(plan)
        last_attempted_tenant = plan[-1][0]
        await run_wave(plan, remaining_time)

    # Only saturated tenants can consume quota reclaimed from sparse tenants.
    # Failed or timed-out tenants keep their reservation and are never retried
    # in the same cycle because their lease outcome is unknown.
    while not first_pass_plan and saturated_tenants and remaining_budget > 0:
        available_slots = max(
            0,
            _OUTBOX_TENANT_DRAIN_CONCURRENCY - len(_outbox_tenant_tasks),
        )
        remaining_time = cycle_deadline - loop.time()
        if available_slots <= 0 or remaining_time <= 0:
            break
        plan, _ = _outbox_cycle_plan(
            saturated_tenants,
            cursor=0,
            batch_size=remaining_budget,
            max_participants=available_slots,
        )
        if not plan:
            break
        attempted_ids = {tenant_id for tenant_id, _limit in plan}
        saturated_tenants = [
            tenant_id
            for tenant_id in saturated_tenants
            if tenant_id not in attempted_ids
        ]
        attempted_count += len(plan)
        last_attempted_tenant = plan[-1][0]
        await run_wave(plan, remaining_time)
    aggregate["error_type"] = first_error_type
    aggregate.update(_outbox_retained_status())
    if attempted_count == 0 or last_attempted_tenant is None:
        next_cursor = start
    elif attempted_count >= len(tenant_ids):
        next_cursor = (start + 1) % len(tenant_ids)
    else:
        next_cursor = (tenant_ids.index(last_attempted_tenant) + 1) % len(tenant_ids)
    return aggregate, next_cursor


async def _outbox_health_snapshot(tenant_ids: list[str]) -> dict[str, Any] | None:
    """Build an anonymous aggregate from bounded, rotating tenant probes."""

    global _outbox_health_cursor
    runtime = knowledge_runtime
    projection_health = getattr(
        getattr(runtime, "store", None), "projection_outbox_health", None
    )
    if not callable(projection_health):
        return None
    semaphore = asyncio.Semaphore(_OUTBOX_HEALTH_PROBE_CONCURRENCY)

    async def probe(tenant_id: str) -> tuple[dict[str, Any] | None, str | None]:
        async with semaphore:
            try:
                result = await asyncio.wait_for(
                    projection_health(tenant_id),
                    timeout=_OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS,
                )
                if not isinstance(result, dict):
                    raise TypeError("projection outbox health must return a mapping")
                return result, None
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - anonymous error category only
                return None, exc.__class__.__name__

    active_tenants = set(tenant_ids)
    for cached_tenant in tuple(_outbox_health_by_tenant):
        if cached_tenant not in active_tenants:
            del _outbox_health_by_tenant[cached_tenant]

    if tenant_ids:
        start = _outbox_health_cursor % len(tenant_ids)
        ordered_tenants = tenant_ids[start:] + tenant_ids[:start]
        cycle_tenants = ordered_tenants[:_OUTBOX_HEALTH_PROBE_CONCURRENCY]
        _outbox_health_cursor = (start + len(cycle_tenants)) % len(tenant_ids)
    else:
        cycle_tenants = []
    tasks = [asyncio.create_task(probe(tenant_id)) for tenant_id in cycle_tenants]
    if tasks:
        done, pending = await asyncio.wait(
            tasks,
            timeout=_OUTBOX_HEALTH_CYCLE_TIMEOUT_SECONDS,
        )
        for task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        cycle_results = [
            task.result() if task in done else (None, "HealthCycleTimeout")
            for task in tasks
        ]
        for tenant_id, result in zip(cycle_tenants, cycle_results, strict=True):
            _outbox_health_by_tenant[tenant_id] = result
    results = [
        _outbox_health_by_tenant.get(tenant_id, (None, "HealthCyclePending"))
        for tenant_id in tenant_ids
    ]
    aggregate: dict[str, Any] = {
        "pending": 0,
        "oldest_pending_age_seconds": 0.0,
        "terminal_failures": 0,
        "max_attempts": 0,
        "by_projection": {},
        "tenant_count": len(tenant_ids),
        "status_error_count": 0,
    }
    first_error_type: str | None = None
    for tenant_health, error_type in results:
        if error_type is not None or tenant_health is None:
            aggregate["status_error_count"] += 1
            first_error_type = first_error_type or error_type or "UnknownError"
            continue
        try:
            aggregate["pending"] += int(tenant_health.get("pending") or 0)
            aggregate["oldest_pending_age_seconds"] = max(
                float(aggregate["oldest_pending_age_seconds"]),
                float(tenant_health.get("oldest_pending_age_seconds") or 0.0),
            )
            aggregate["terminal_failures"] += int(
                tenant_health.get("terminal_failures") or 0
            )
            aggregate["max_attempts"] = max(
                int(aggregate["max_attempts"]),
                int(tenant_health.get("max_attempts") or 0),
            )
            by_projection = tenant_health.get("by_projection")
            if by_projection is None:
                by_projection = {}
            if not isinstance(by_projection, dict):
                raise TypeError("by_projection must be a mapping")
            aggregate_projection = aggregate["by_projection"]
            for projection, statuses in by_projection.items():
                if not isinstance(statuses, dict):
                    raise TypeError("projection statuses must be a mapping")
                projection_totals = aggregate_projection.setdefault(str(projection), {})
                for status, count in statuses.items():
                    projection_totals[str(status)] = int(
                        projection_totals.get(str(status), 0)
                    ) + int(count or 0)
        except (TypeError, ValueError, OverflowError) as exc:
            aggregate["status_error_count"] += 1
            first_error_type = first_error_type or exc.__class__.__name__
            continue
    aggregate["health_complete"] = aggregate["status_error_count"] == 0
    aggregate["refreshed_at"] = _utc_timestamp()
    if first_error_type is not None:
        aggregate["status_error"] = first_error_type
    return aggregate


async def _refresh_outbox_health_cache(
    tenant_ids: list[str], *, registry_error_type: str | None
) -> None:
    """Refresh health asynchronously so a slow tenant never pauses delivery."""

    global _outbox_health_task
    try:
        snapshot = await _outbox_health_snapshot(tenant_ids)
        if snapshot is None:
            return
        if registry_error_type is not None:
            snapshot["health_complete"] = False
            snapshot["registry_error_type"] = registry_error_type
        _outbox_worker_status["health"] = snapshot
    except asyncio.CancelledError:
        raise
    except Exception as exc:  # noqa: BLE001 - retain metrics but mark them stale
        previous = dict(_outbox_worker_status.get("health") or {})
        previous.update(
            {
                "tenant_count": len(tenant_ids),
                "health_complete": False,
                "refresh_error_type": exc.__class__.__name__,
                "refreshed_at": _utc_timestamp(),
            }
        )
        _outbox_worker_status["health"] = previous
    finally:
        if _outbox_health_task is asyncio.current_task():
            _outbox_health_task = None


def _schedule_outbox_health_refresh(
    tenant_ids: list[str], *, registry_error_type: str | None
) -> bool:
    global _outbox_health_task
    if _outbox_health_task is not None and not _outbox_health_task.done():
        return False
    _outbox_health_task = asyncio.create_task(
        _refresh_outbox_health_cache(
            list(tenant_ids),
            registry_error_type=registry_error_type,
        ),
        name="m1-knowledge-outbox-health",
    )
    return True


async def _outbox_worker_loop(settings_obj) -> None:
    global _outbox_tenant_cursor
    _outbox_worker_status.update(
        {
            "enabled": True,
            "running": True,
            "last_started_at": _utc_timestamp(),
            "last_error_type": None,
            "registry_error_type": None,
            "health": None,
            "retained_count": 0,
            "retained_reserved": 0,
            "oldest_retained_age_seconds": 0.0,
            "retained_stalled": False,
        }
    )
    interval = max(0.1, float(settings_obj.knowledge_outbox_interval_seconds))
    batch_size = max(1, min(int(settings_obj.knowledge_outbox_batch_size), 200))
    next_health_refresh = 0.0
    next_drain_not_before = 0.0
    while True:
        tick_started = asyncio.get_running_loop().time()
        next_drain_not_before = tick_started + interval
        try:
            runtime = knowledge_runtime
            if runtime is not None:
                registry_error_type: str | None = None
                try:
                    tenant_ids = await asyncio.wait_for(
                        _list_outbox_tenant_ids(settings_obj),
                        timeout=_OUTBOX_REGISTRY_TIMEOUT_SECONDS,
                    )
                except Exception as exc:  # noqa: BLE001 - drain configured fallback
                    registry_error_type = exc.__class__.__name__
                    tenant_ids = _configured_outbox_tenant_ids(settings_obj)
                tick_started = asyncio.get_running_loop().time()
                next_drain_not_before = tick_started + interval
                outcome, _outbox_tenant_cursor = await _drain_outbox_cycle(
                    settings_obj,
                    tenant_ids=tenant_ids,
                    cursor=_outbox_tenant_cursor,
                    batch_size=batch_size,
                    cycle_timeout_seconds=max(
                        0.001,
                        interval - (asyncio.get_running_loop().time() - tick_started),
                    ),
                )
                tenant_error_type = outcome.pop("error_type", None)
                loop_time = asyncio.get_running_loop().time()
                if loop_time >= next_health_refresh:
                    _schedule_outbox_health_refresh(
                        tenant_ids,
                        registry_error_type=registry_error_type,
                    )
                    next_health_refresh = asyncio.get_running_loop().time() + interval
                status_update: dict[str, Any] = {
                    "last_completed_at": _utc_timestamp(),
                    "last_error_type": tenant_error_type,
                    "registry_error_type": registry_error_type,
                    "tenant_count": len(tenant_ids),
                    "last_result": outcome,
                }
                for field in (
                    "retained_count",
                    "retained_reserved",
                    "oldest_retained_age_seconds",
                    "retained_stalled",
                    "retained_expired",
                ):
                    status_update[field] = outcome.get(field, 0)
                _outbox_worker_status.update(status_update)
            await asyncio.sleep(
                max(
                    0.001,
                    next_drain_not_before - asyncio.get_running_loop().time(),
                )
            )
        except asyncio.CancelledError:
            _outbox_worker_status["running"] = False
            raise
        except Exception as exc:  # noqa: BLE001 - durable events remain pending
            _outbox_worker_status.update(
                {
                    "last_completed_at": _utc_timestamp(),
                    "last_error_type": exc.__class__.__name__,
                }
            )
            logger.warning(
                "Knowledge outbox worker degraded error_type={}",
                exc.__class__.__name__,
            )
            now = asyncio.get_running_loop().time()
            if next_drain_not_before <= now:
                next_drain_not_before = now + interval
            await asyncio.sleep(max(0.001, next_drain_not_before - now))


def _start_outbox_worker(settings_obj) -> None:
    global _outbox_worker_task
    enabled = bool(settings_obj.knowledge_outbox_worker_enabled)
    _outbox_worker_status["enabled"] = enabled
    if not enabled or _outbox_worker_task is not None:
        return
    _outbox_worker_task = asyncio.create_task(
        _outbox_worker_loop(settings_obj),
        name="m1-knowledge-outbox-worker",
    )


async def init_app() -> None:
    """初始化 DB + 依赖 (FastAPI lifespan 会调用)。

    若依赖已注入 (测试场景调用了 init_deps), 则跳过创建真实 VLM 客户端,
    但 store 仍按 settings.database_url 创建。
    """
    global store, engine, _processing_semaphore
    from ..documents.parsing import build_document_parser_service
    from ..documents.parsing.mineru_shadow import build_mineru_shadow_runner
    from ..extractors import VLMExtractor
    from ..parsers import ParserRouter

    s = settings
    store = TaskStore(s.database_url)
    await store.init(migrate_schema=s.task_store_migrate_on_startup)
    await _register_configured_outbox_tenants(s)
    await _init_knowledge(s)
    await _init_entity_routing(s)
    await _init_document_routing(s)
    await _init_adaptive_route_runtimes(s)
    _processing_semaphore = asyncio.Semaphore(s.max_concurrent)

    try:
        deps = get_deps()
    except RuntimeError:
        deps = None
    if deps is not None:
        deps.document_routing_runtime = document_routing_runtime
        deps.field_semantic_routing_runtime = field_semantic_routing_runtime
        deps.visual_region_routing_runtime = visual_region_routing_runtime
        deps.region_capability_routing_runtime = region_capability_routing_runtime
        deps.content_region_routing_runtime = content_region_routing_runtime
        region_consumers = _wire_region_capability_consumer(
            getattr(deps, "document_parser", None)
        )
        _record_region_capability_consumers(s, region_consumers)
        _record_content_region_consumers(s, ("workflow_postbuild",))
        await _init_tabular_layout_routing(
            s,
            getattr(deps, "mineru_shadow_runner", None),
        )
        consumers = _wire_field_semantic_consumers(
            mineru_shadow_runner=getattr(deps, "mineru_shadow_runner", None),
        )
        _record_field_semantic_consumers(s, consumers)
        # 测试已注入 fake deps, 直接复用, 但绑定到本 store
        engine = WorkflowEngine(deps, store)
        await _recover_batch_tasks()
        logger.info("FastAPI 初始化完成 (复用已注入依赖, 测试场景)")
        return

    created_vlm = None
    created_mineru_shadow_runner = None
    created_document_parser = None
    try:
        created_vlm = VLMExtractor(
            api_key=s.vlm_api_key,
            base_url=s.vlm_base_url,
            model=s.vlm_model,
            timeout=s.vlm_timeout_seconds,
            temperature=s.vlm_temperature,
            max_tokens=s.vlm_max_tokens,
            max_images=s.vlm_max_images,
            enable_thinking=s.vlm_enable_thinking,
        )
        created_mineru_shadow_runner = build_mineru_shadow_runner(
            s,
            field_semantic_router=field_semantic_routing_runtime,
            field_semantic_registry=getattr(
                field_semantic_routing_runtime,
                "registry",
                None,
            ),
        )
        await _init_tabular_layout_routing(s, created_mineru_shadow_runner)
        consumers = _wire_field_semantic_consumers(
            mineru_shadow_runner=created_mineru_shadow_runner,
        )
        _record_field_semantic_consumers(s, consumers)
        if created_mineru_shadow_runner is not None:
            try:
                await created_mineru_shadow_runner.probe()
            except Exception as exc:
                if s.mineru_shadow_required:
                    raise
                logger.warning(
                    "MinerU shadow startup probe degraded error_type={}",
                    exc.__class__.__name__,
                )
        created_document_parser = build_document_parser_service(s)
        region_consumers = _wire_region_capability_consumer(created_document_parser)
        _record_region_capability_consumers(s, region_consumers)
        _record_content_region_consumers(s, ("workflow_postbuild",))
    except Exception:
        await _close_tabular_layout_routing_runtime()
        await _close_content_region_routing_runtime()
        await _close_region_capability_routing_runtime()
        await _close_visual_region_routing_runtime()
        await _close_field_semantic_routing_runtime()
        for client in (
            getattr(created_vlm, "client", None),
            created_mineru_shadow_runner,
        ):
            close = getattr(client, "close", None)
            if callable(close):
                result = close()
                if inspect.isawaitable(result):
                    await result
        raise

    deps = WorkflowDeps(
        parser_router=ParserRouter(),
        vlm_agent=created_vlm,
        confidence_threshold=s.confidence_threshold,
        # 注入文档分类器: 复用 VLM 的 OpenAI client 做 VLM 看图分类
        document_parser=created_document_parser,
        mineru_shadow_runner=created_mineru_shadow_runner,
        document_routing_runtime=document_routing_runtime,
        document_router_probe_timeout_seconds=s.document_router_probe_timeout_seconds,
        field_semantic_routing_runtime=field_semantic_routing_runtime,
        visual_region_routing_runtime=visual_region_routing_runtime,
        region_capability_routing_runtime=region_capability_routing_runtime,
        content_region_routing_runtime=content_region_routing_runtime,
    )
    init_deps(deps)
    engine = WorkflowEngine(deps, store)
    await _recover_batch_tasks()
    logger.info(
        f"FastAPI 初始化完成, model={s.vlm_model}, "
        f"db_backend={store.engine.url.get_backend_name()}, "
        "document_authority=mineru_instructor_full"
    )


# ----------------------------------------------------------------------
# 后台任务管理
# ----------------------------------------------------------------------
async def _run_in_background(state: TaskState) -> None:
    """后台推进任务到完成/暂停/失败。异常被 engine 内部 catch 落 FAILED,
    这里再加一层防御, 避免 "Task exception was never retrieved"。
    """
    logger.info(f"后台任务启动 task={state.task_id}")
    try:
        await engine.run_to_completion(state)  # type: ignore[union-attr]
    except Exception as e:  # noqa: BLE001
        logger.error(
            "后台任务异常 task={} ({})",
            state.task_id,
            _safe_exception_message(e),
        )


def _spawn(
    state: TaskState, semaphore: asyncio.Semaphore | None = None
) -> asyncio.Task:
    """创建后台任务推进 state, 注册到 _task_registry, 完成后自动移除。"""
    existing = _task_registry.get(state.task_id)
    if existing is not None and not existing.done():
        return existing

    async def _limited_run() -> None:
        limiter = semaphore or _processing_semaphore
        if limiter is None:
            await _run_in_background(state)
            return
        async with limiter:
            await _run_in_background(state)

    task = asyncio.create_task(_limited_run())
    _register_background_task(state.task_id, task)
    return task


def _register_background_task(task_id: str, task: asyncio.Task) -> None:
    _task_registry[task_id] = task

    def _cleanup(completed: asyncio.Task) -> None:
        if _task_registry.get(task_id) is completed:
            _task_registry.pop(task_id, None)

    task.add_done_callback(_cleanup)


async def _resume_review_indexing(task_id: str) -> None:
    try:
        completed = await engine.finalize_review(task_id)  # type: ignore[union-attr]
        if completed.parent_id and store is not None:
            from ..ingest.batch import refresh_parent_status

            await refresh_parent_status(store, completed.parent_id)
    except Exception as exc:  # noqa: BLE001 - durable state remains recoverable
        logger.error(
            "task={} review indexing recovery failed ({})",
            task_id,
            _safe_exception_message(exc),
        )


async def _recover_batch_tasks() -> None:
    if store is None:
        return
    from ..ingest.batch import BatchOrchestrator

    recoverable = (
        TaskStatus.CREATED,
        TaskStatus.PARSING,
        TaskStatus.EXTRACTING,
        TaskStatus.SCORING,
    )
    for state in await store.list_all():
        if state.task_id in _task_registry:
            continue
        if state.processing_stage == "review_indexing":
            task = asyncio.create_task(_resume_review_indexing(state.task_id))
            _register_background_task(state.task_id, task)
            continue
        if state.file_type == "batch":
            recover_parent = state.status in recoverable or (
                state.status
                in {
                    TaskStatus.DONE,
                    TaskStatus.FAILED,
                    TaskStatus.NEEDS_REVIEW,
                }
                and bool(state.child_ids)
                and state.batch_summary_status in {"", "pending"}
            )
            if recover_parent:
                orchestrator = BatchOrchestrator(
                    store,
                    _spawn,
                    semaphore=_processing_semaphore,
                    task_registry=_task_registry,
                )
                _register_background_task(state.task_id, orchestrator.resume(state))
        elif state.status in recoverable:
            _spawn(state)


async def wait_for_task(task_id: str, timeout: float = 30.0) -> None:
    """(测试用) 等待指定后台任务完成。"""
    task = _task_registry.get(task_id)
    if task is not None:
        await asyncio.wait_for(asyncio.shield(task), timeout=timeout)


async def _drain_tasks() -> None:
    """shutdown 时取消并等待所有后台任务, 避免中断丢数据。"""
    tasks = list(_task_registry.values())
    for t in tasks:
        t.cancel()
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _task_registry.clear()


async def _close_dependency_clients() -> None:
    """Close OpenAI clients created during startup without touching secrets."""

    try:
        deps = get_deps()
    except RuntimeError:
        return
    candidates: list[object] = []
    for owner in (
        getattr(deps, "vlm_agent", None),
        getattr(deps, "mineru_shadow_runner", None),
    ):
        if owner is getattr(deps, "mineru_shadow_runner", None) and owner is not None:
            candidates.append(owner)
            continue
        client = getattr(owner, "client", None)
        if client is not None:
            candidates.append(client)
        primary = getattr(owner, "primary", None)
        primary_client = getattr(primary, "client", None)
        if primary_client is not None:
            candidates.append(primary_client)
    seen: set[int] = set()
    for client in candidates:
        if id(client) in seen:
            continue
        seen.add(id(client))
        close = getattr(client, "close", None)
        if not callable(close):
            continue
        try:
            result = close()
            if inspect.isawaitable(result):
                await result
        except Exception as exc:  # noqa: BLE001 - shutdown must continue
            logger.debug("VLM client cleanup failed: {}", _safe_exception_message(exc))


lifespan = create_lifespan(sys.modules[__name__])


def create_app() -> FastAPI:
    """Create an isolated M1 FastAPI application with all public routes."""

    app = FastAPI(
        title="M1 多模态识别",
        version="0.1.0",
        lifespan=lifespan,
        docs_url=None,
        redoc_url=None,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(ApiKeyMiddleware)
    app.add_middleware(TenantBoundaryMiddleware)

    # Import lazily so route modules can receive this module as their mutable
    # runtime facade without creating a circular import during initialization.
    from .enhanced_health_routes import register_enhanced_health_routes
    from .health_routes import register_health_routes
    from .ingest_routes import register_ingest_routes
    from .knowledge_routes import register_knowledge_routes
    from .review_routes import register_review_routes
    from .task_routes import register_task_routes

    runtime = sys.modules[__name__]
    register_health_routes(app, runtime)
    register_enhanced_health_routes(app, runtime)
    register_ingest_routes(app, runtime)
    register_task_routes(app, runtime)
    register_knowledge_routes(app)
    register_review_routes(app, runtime)

    # Keep the React review console last so API paths win over SPA fallback.
    static_dir = Path(__file__).with_name("static")
    if static_dir.is_dir() and any(static_dir.iterdir()):
        from fastapi.staticfiles import StaticFiles

        app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")
        logger.info("已挂载前端静态文件: {}", static_dir)
    return app


app = create_app()
