"""Human review queue and submission routes."""

from __future__ import annotations

import asyncio
from types import ModuleType

from fastapi import Body, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse
from loguru import logger

from ..state import TaskStatus, TaskSummary
from .contracts import ReviewRequest
from .route_support import (
    PAGINATED_LIST_RESPONSES,
    set_pagination_headers,
    validate_pagination,
)


def register_review_routes(app: FastAPI, runtime: ModuleType) -> None:
    @app.get(
        "/review/queue",
        response_model=list[TaskSummary],
        responses=PAGINATED_LIST_RESPONSES,
    )
    async def review_queue(
        request: Request,
        response: Response,
        limit: int | None = Query(None, ge=1, le=200),
        offset: int | None = Query(None, ge=0),
    ) -> list[dict]:
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        offset = validate_pagination(limit, offset)
        summaries, total = await runtime.store.list_task_summaries(
            tenant_id=request.state.tenant_id,
            status=TaskStatus.NEEDS_REVIEW.value,
            exclude_batch_parents=True,
            limit=limit,
            offset=offset,
        )
        set_pagination_headers(
            response,
            total=total,
            limit=limit,
            offset=offset,
            page_size=len(summaries),
        )
        return [summary.model_dump(mode="json") for summary in summaries]

    @app.post("/review/{task_id}")
    async def submit_review(
        task_id: str,
        payload: ReviewRequest | None = Body(default=None),
        approve_query: bool | None = Query(default=None, alias="approve"),
        reviewer_query: str | None = Query(default=None, alias="reviewer"),
        comment_query: str | None = Query(default=None, alias="comment"),
    ) -> dict:
        if runtime.engine is None:
            raise HTTPException(500, "engine 未初始化")
        review = payload or ReviewRequest()
        approve = (
            review.approve
            if payload is not None
            else (approve_query if approve_query is not None else True)
        )
        reviewer = (
            review.reviewer if payload is not None else (reviewer_query or "anonymous")
        )
        comment = review.comment if payload is not None else (comment_query or "")
        try:
            state = await runtime.engine.prepare_review(
                task_id=task_id,
                corrected_fields=review.corrections,
                header_corrections=review.header_corrections,
                line_corrections=review.line_corrections,
                issue_resolutions=review.issue_resolutions,
                reviewer=reviewer,
                comment=comment,
                approve=approve,
            )

            async def finalize() -> None:
                try:
                    completed = await runtime.engine.finalize_review(task_id)
                    if completed.parent_id and runtime.store is not None:
                        from ..ingest.batch import refresh_parent_status

                        await refresh_parent_status(runtime.store, completed.parent_id)
                except Exception as exc:  # noqa: BLE001 - durable recovery retries it
                    logger.error(
                        "task={} asynchronous review finalization failed type={}",
                        task_id,
                        exc.__class__.__name__,
                    )

            task = asyncio.create_task(finalize())
            register = getattr(runtime, "_register_background_task", None)
            if callable(register):
                register(task_id, task)
        except ValueError as exc:
            raise HTTPException(400, str(exc)) from exc
        return JSONResponse(
            status_code=202,
            headers={"Retry-After": "2"},
            content={
                "code": "M1_REVIEW_ACCEPTED",
                "message": "Review corrections were saved; indexing continues asynchronously.",
                "task_id": state.task_id,
                "status": state.status.value,
                "processing_stage": state.processing_stage,
                "poll_url": f"/tasks/{state.task_id}",
            },
        )
