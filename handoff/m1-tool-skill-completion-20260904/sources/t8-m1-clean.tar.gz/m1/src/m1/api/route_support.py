"""Pure helpers shared by API route registration modules."""

from __future__ import annotations

import asyncio
import io
import zipfile
from pathlib import Path
from urllib.parse import quote

from fastapi import HTTPException, Response, UploadFile

from ..core.config import settings
from ..documents.ooxml import OOXMLPackageError
from ..state import TaskState, TaskSummary

PAGINATED_LIST_RESPONSES = {
    200: {
        "description": "Task summaries with optional offset pagination.",
        "headers": {
            "X-Total-Count": {
                "description": "Total matching task count before pagination.",
                "schema": {"type": "integer", "minimum": 0},
            },
            "X-Page-Limit": {
                "description": "Requested limit, or returned size for legacy calls.",
                "schema": {"type": "integer", "minimum": 0},
            },
            "X-Page-Offset": {
                "description": "Zero-based offset applied to this response.",
                "schema": {"type": "integer", "minimum": 0},
            },
            "X-Has-More": {
                "description": "Whether another bounded page follows.",
                "schema": {"type": "boolean"},
            },
        },
    }
}


async def save_upload_streaming(
    upload: UploadFile,
    destination: Path,
    max_bytes: int,
    chunk_size: int = 1024 * 1024,
) -> int:
    """Stream an upload to disk and remove a partial file after any failure."""

    total = 0
    try:
        with destination.open("wb") as stream:
            while True:
                chunk = await upload.read(chunk_size)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise HTTPException(413, f"上传文件超过限制 {max_bytes} 字节")
                stream.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    return total


async def classify_staged_upload(path: Path) -> str:
    """Validate staged content by magic and apply the correct size boundary."""

    from ..ingest.batch import _detect_ingest_kind

    try:
        kind = await asyncio.to_thread(_detect_ingest_kind, path)
    except OOXMLPackageError as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(
            status_code=422,
            detail={
                "code": "M1_OFFICE_PACKAGE_INVALID",
                "message": "Office package is malformed or exceeds a safe resource boundary.",
                "details": {"reason": str(exc)},
            },
        ) from exc
    if kind == "unknown":
        path.unlink(missing_ok=True)
        raise HTTPException(
            415,
            "Unsupported or damaged content. Upload PDF, Office, CSV, image, CAD, or a supported archive.",
        )
    limit = (
        settings.max_archive_size
        if kind == "archive"
        else settings.max_single_uncompressed
    )
    if path.stat().st_size > limit:
        path.unlink(missing_ok=True)
        raise HTTPException(413, f"Upload exceeds the {limit}-byte limit for {kind}")
    return kind


def state_summary(state: TaskState) -> dict:
    return TaskSummary.from_state(state).model_dump(mode="json")


def set_pagination_headers(
    response: Response,
    *,
    total: int,
    limit: int | None,
    offset: int,
    page_size: int,
) -> None:
    response.headers["X-Total-Count"] = str(total)
    response.headers["X-Page-Limit"] = str(limit if limit is not None else page_size)
    response.headers["X-Page-Offset"] = str(offset)
    has_more = limit is not None and offset + limit < total
    response.headers["X-Has-More"] = str(has_more).lower()


def validate_pagination(limit: int | None, offset: int | None) -> int:
    if limit is None and offset is not None:
        raise HTTPException(422, "limit is required when offset is provided")
    return offset or 0


def state_detail(state: TaskState) -> dict:
    return {
        "task_id": state.task_id,
        "tenant_id": state.tenant_id,
        "filename": state.original_filename,
        "file_path": state.file_path,
        "file_type": state.file_type,
        "doc_type": state.doc_type,
        "document_subtype": state.document_subtype,
        "semantic_enrichment": state.semantic_enrichment,
        "processing_stage": state.processing_stage,
        "knowledge_sync_status": state.knowledge_sync_status or None,
        "knowledge_document_id": state.knowledge_document_id or None,
        "knowledge_version_id": state.knowledge_version_id or None,
        "knowledge_sync_error": state.knowledge_sync_error or None,
        "parent_id": state.parent_id,
        "child_ids": state.child_ids,
        "status": state.status.value,
        "needs_review": state.is_paused(),
        "parsed_content": state.parsed_content[:500] if state.parsed_content else "",
        "extraction": state.extraction.model_dump() if state.extraction else None,
        "scored_result": state.scored_result.model_dump()
        if state.scored_result
        else None,
        "schema_version": state.document_schema_version or None,
        "document": state.document,
        "reviewed_result": (
            state.reviewed_result.model_dump() if state.reviewed_result else None
        ),
        "replication_status": state.replication_status,
        "replication_doc": state.replication_doc,
        "detailed_replication_status": state.detailed_replication_status,
        "detailed_replication_doc": state.detailed_replication_doc,
        "folder_path": state.folder_path,
        "batch_summary_status": state.batch_summary_status,
        "batch_summary": state.batch_summary,
        "reviewer": state.reviewer,
        "review_comment": state.review_comment,
        "error": state.error,
        "document_schema_version": state.document_schema_version or None,
        "created_at": state.created_at,
        "updated_at": state.updated_at,
    }


def media_type_for_path(path: Path) -> str:
    return {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".bmp": "image/bmp",
        ".webp": "image/webp",
        ".gif": "image/gif",
        ".pdf": "application/pdf",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
        ".xls": "application/vnd.ms-excel",
        ".csv": "text/csv; charset=utf-8",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".html": "text/html",
        ".htm": "text/html",
        ".zip": "application/zip",
        ".md": "text/markdown; charset=utf-8",
        ".json": "application/json",
    }.get(path.suffix.lower(), "application/octet-stream")


def attachment_headers(filename: str) -> dict[str, str]:
    quoted = quote(filename)
    ascii_fallback = "".join(
        character if 32 <= ord(character) < 127 else "_" for character in filename
    )
    return {
        "Content-Disposition": (
            f"attachment; filename=\"{ascii_fallback}\"; filename*=UTF-8''{quoted}"
        )
    }


def safe_download_stem(name: str) -> str:
    return safe_archive_name(Path(name).stem or name or "task")


def safe_archive_name(name: str) -> str:
    safe = Path(name).name.replace("\\", "_").replace("/", "_").strip()
    safe = "".join("_" if character in '<>:"|?*' else character for character in safe)
    return safe or "file"


def build_batch_zip(parent: TaskState, children: list[TaskState]) -> bytes:
    from ..reports import build_batch_report, build_task_report

    buffer = io.BytesIO()
    missing: list[str] = []
    parent_report = parent.batch_summary or build_batch_report(parent, children)
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("batch_report.md", parent_report)
        for index, child in enumerate(children, 1):
            original_name = safe_archive_name(
                child.original_filename or f"{child.task_id}.bin"
            )
            path = Path(child.file_path)
            if path.exists():
                archive.write(path, f"documents/{index:03d}_{original_name}")
            else:
                missing.append(
                    f"{child.task_id}: {child.original_filename} -> {child.file_path}"
                )
            child_report = child.replication_doc or build_task_report(child)
            report_stem = safe_download_stem(child.original_filename or child.task_id)
            archive.writestr(
                f"reports/{index:03d}_{report_stem}_report.md", child_report
            )
        if missing:
            archive.writestr("missing_files.txt", "\n".join(missing))
    return buffer.getvalue()
