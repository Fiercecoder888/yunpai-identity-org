"""Task, document, export, report, download, and deletion routes."""

from __future__ import annotations

import asyncio
import io
from pathlib import Path
from types import ModuleType
from typing import Any

from fastapi import Body, FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from loguru import logger

from ..core.config import settings
from ..state import TaskSummary
from .contracts import ReportRequest
from .route_support import (
    PAGINATED_LIST_RESPONSES,
    attachment_headers,
    build_batch_zip,
    media_type_for_path,
    safe_download_stem,
    set_pagination_headers,
    state_detail,
    validate_pagination,
)


def register_task_routes(app: FastAPI, runtime: ModuleType) -> None:
    @app.get("/files/{task_id}")
    async def get_file(task_id: str):
        """返回任务对应的原图 (供审核 UI 预览)。"""

        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        path = Path(state.file_path)
        if not path.exists():
            raise HTTPException(404, f"文件不存在: {path}")
        review_media_type = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".bmp": "image/bmp",
            ".pdf": "application/pdf",
            ".xlsx": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ),
            ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
            ".xls": "application/vnd.ms-excel",
            ".csv": "text/csv; charset=utf-8",
            ".docx": (
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ),
            ".pptx": (
                "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            ),
            ".html": "text/html",
            ".htm": "text/html",
        }.get(path.suffix.lower(), "application/octet-stream")
        return FileResponse(path, media_type=review_media_type)

    @app.get(
        "/tasks",
        response_model=list[TaskSummary],
        responses=PAGINATED_LIST_RESPONSES,
    )
    async def list_tasks(
        request: Request,
        response: Response,
        status: str | None = Query(None),
        limit: int | None = Query(None, ge=1, le=200),
        offset: int | None = Query(None, ge=0),
    ) -> list[dict]:
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        offset = validate_pagination(limit, offset)
        summaries, total = await runtime.store.list_task_summaries(
            tenant_id=request.state.tenant_id,
            status=status,
            root_only=not status,
            limit=limit,
            offset=offset,
        )
        set_pagination_headers(
            response,
            total=total,
            limit=limit,
            offset=offset,
            page_size=len(summaries),
        )
        return [summary.model_dump(mode="json") for summary in summaries]

    @app.get("/tasks/{task_id}")
    async def get_task(task_id: str) -> dict:
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        return state_detail(state)

    @app.get("/tasks/{task_id}/document")
    async def get_task_document(task_id: str) -> dict:
        """返回经过 v2 Schema 校验的完整文档；旧任务无 v2 结果时返回 404。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        document = await runtime.store.get_document(task_id)
        if document is None:
            state = await runtime.store.load(task_id)
            if state is None:
                raise HTTPException(404, f"任务不存在: {task_id}")
            document = state.document
        if document is None:
            raise HTTPException(404, f"任务尚无 m1.document.v2 结果: {task_id}")
        try:
            from ..documents import DocumentRecord

            return DocumentRecord.model_validate(document).model_dump(mode="json")
        except ImportError:
            return document
        except Exception as exc:
            logger.error(
                "task={} 文档记录 Schema 校验失败 ({})",
                task_id,
                runtime._safe_exception_message(exc),
            )
            raise HTTPException(500, "文档记录 Schema 校验失败") from exc

    @app.get("/documents/search")
    async def search_documents(
        request: Request,
        q: str = Query(""),
        document_type: str = Query(""),
        document_subtype: str = Query(""),
        field_path: str = Query(""),
        field_value: str = Query(""),
        limit: int = Query(50, ge=1, le=200),
        offset: int = Query(0, ge=0),
    ) -> list[dict]:
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        return await runtime.store.search_documents(
            tenant_id=request.state.tenant_id,
            query=q,
            document_type=document_type,
            document_subtype=document_subtype,
            field_path=field_path,
            field_value=field_value,
            limit=limit,
            offset=offset,
        )

    @app.get("/orders/search")
    async def search_orders(
        request: Request,
        order_number: str = Query(""),
        model: str = Query(""),
        name: str = Query(""),
        category: str = Query(""),
        date_from: str = Query(""),
        date_to: str = Query(""),
        limit: int = Query(100, ge=1, le=500),
        offset: int = Query(0, ge=0),
    ) -> list[dict]:
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        return await runtime.store.search_orders(
            tenant_id=request.state.tenant_id,
            order_number=order_number,
            model=model,
            name=name,
            category=category,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
            offset=offset,
        )

    @app.get("/tasks/{task_id}/exports/order")
    async def get_order_export_link(task_id: str, request: Request) -> dict:
        """Return a JSON-safe link which an Agent can hand to the caller."""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        document = await runtime.store.get_document(task_id) or state.document
        if document is None or document.get("document_type") != "order":
            raise HTTPException(400, "该任务不是可导出的订单文档")
        filename = (
            f"{safe_download_stem(state.original_filename or task_id)}_标准订单.xlsx"
        )
        return {
            "task_id": task_id,
            "filename": filename,
            "content_type": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ),
            "download_url": str(request.url_for("export_order", task_id=task_id)),
            "generated": bool(state.export_path and Path(state.export_path).is_file()),
        }

    @app.get("/tasks/{task_id}/exports/order.xlsx", name="export_order")
    async def export_order(task_id: str):
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        document = await runtime.store.get_document(task_id) or state.document
        if document is None or document.get("document_type") != "order":
            raise HTTPException(400, "该任务不是可导出的订单文档")

        from ..order_export import export_order_workbook

        export_path = settings.upload_path / "exports" / f"{task_id}_order.xlsx"
        try:
            await asyncio.to_thread(export_order_workbook, document, export_path)
        except Exception as exc:
            logger.error(
                "task={} 订单导出失败 ({})",
                task_id,
                runtime._safe_exception_message(exc),
            )
            raise HTTPException(500, "订单 Excel 导出失败") from exc
        state.export_path = str(export_path)
        await runtime.store.save(state)
        filename = (
            f"{safe_download_stem(state.original_filename or task_id)}_标准订单.xlsx"
        )
        return FileResponse(
            export_path,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers=attachment_headers(filename),
        )

    @app.get("/tasks/{task_id}/download")
    async def download_task_file(task_id: str):
        """下载原始文档；批次父任务会打包所有子文档和报告。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        if state.file_type == "batch" or state.child_ids:
            children = await runtime.store.list_by_parent(task_id)
            data = build_batch_zip(state, children)
            filename = (
                f"{safe_download_stem(state.original_filename or state.task_id)}.zip"
            )
            return StreamingResponse(
                io.BytesIO(data),
                media_type="application/zip",
                headers=attachment_headers(filename),
            )
        path = Path(state.file_path)
        if not path.exists():
            raise HTTPException(404, f"文件不存在: {path}")
        return FileResponse(
            path,
            media_type=media_type_for_path(path),
            filename=state.original_filename or path.name,
        )

    @app.get("/tasks/{task_id}/report/download")
    async def download_task_report(task_id: str):
        """下载 Markdown 综合报告；不存在时按当前数据即时生成。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")

        from ..reports import build_batch_report, build_task_report

        if state.file_type == "batch" or state.child_ids:
            children = await runtime.store.list_by_parent(task_id)
            document = state.batch_summary or build_batch_report(state, children)
            if not state.batch_summary:
                state.batch_summary = document
                state.batch_summary_status = "done"
                await runtime.store.save(state)
            filename = (
                f"{safe_download_stem(state.original_filename or state.task_id)}"
                "_综合报告.md"
            )
        else:
            document = state.replication_doc or build_task_report(state)
            if not state.replication_doc:
                state.replication_doc = document
                state.replication_status = "done"
                await runtime.store.save(state)
            filename = (
                f"{safe_download_stem(state.original_filename or state.task_id)}"
                "_综合报告.md"
            )
        return StreamingResponse(
            io.BytesIO(document.encode("utf-8")),
            media_type="text/markdown; charset=utf-8",
            headers=attachment_headers(filename),
        )

    @app.post("/tasks/{task_id}/replication-report")
    async def generate_replication_report(
        task_id: str, payload: ReportRequest | None = Body(default=None)
    ) -> dict:
        """生成面向工程图复刻的详细 Markdown 报告。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        if state.doc_type != "drawing":
            raise HTTPException(400, "仅 drawing 类型文档支持详细复刻报告")
        note = (payload.note if payload else "").strip()
        force = bool(payload.force if payload else False)
        if (
            state.detailed_replication_status == "done"
            and state.detailed_replication_doc
            and not force
            and not note
        ):
            document = state.detailed_replication_doc
        else:
            state.detailed_replication_status = "pending"
            await runtime.store.save(state)
            try:
                if runtime.engine is None:
                    raise RuntimeError("engine 未初始化")
                document = await runtime.engine.generate_replication(task_id)
            except Exception as exc:  # noqa: BLE001 - deterministic fallback
                logger.warning(
                    "task={} VLM 详细复刻报告失败, 使用确定性兜底 ({})",
                    task_id,
                    runtime._safe_exception_message(exc),
                )
                from ..replication_report import build_replication_report

                document = build_replication_report(state)
            if note:
                document = document.rstrip() + "\n\n## 附加说明\n\n" + note + "\n"
            state = await runtime.store.load(task_id) or state
            state.detailed_replication_doc = document
            state.detailed_replication_status = "done"
            await runtime.store.save(state)
        return {
            "task_id": task_id,
            "report_kind": "replication",
            "report_status": "done",
            "replication_status": state.detailed_replication_status,
            "batch_summary_status": state.batch_summary_status,
            "doc": document,
            "message": "详细复刻报告已生成",
        }

    @app.get("/tasks/{task_id}/replication-report/download")
    async def download_replication_report(task_id: str):
        """下载 Markdown 详细复刻报告。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        if state.doc_type != "drawing":
            raise HTTPException(400, "仅 drawing 类型文档支持详细复刻报告")
        if (
            state.detailed_replication_status == "done"
            and state.detailed_replication_doc
        ):
            document = state.detailed_replication_doc
        else:
            state.detailed_replication_status = "pending"
            await runtime.store.save(state)
            try:
                if runtime.engine is None:
                    raise RuntimeError("engine 未初始化")
                document = await runtime.engine.generate_replication(task_id)
            except Exception as exc:  # noqa: BLE001 - deterministic fallback
                logger.warning(
                    "task={} VLM 详细复刻报告下载失败, 使用确定性兜底 ({})",
                    task_id,
                    runtime._safe_exception_message(exc),
                )
                from ..replication_report import build_replication_report

                document = build_replication_report(state)
            state = await runtime.store.load(task_id) or state
            state.detailed_replication_doc = document
            state.detailed_replication_status = "done"
            await runtime.store.save(state)
        filename = (
            f"{safe_download_stem(state.original_filename or state.task_id)}"
            "_详细复刻报告.md"
        )
        return StreamingResponse(
            io.BytesIO(document.encode("utf-8")),
            media_type="text/markdown; charset=utf-8",
            headers=attachment_headers(filename),
        )

    @app.post("/tasks/{task_id}/report")
    async def generate_report(
        task_id: str, payload: ReportRequest | None = Body(default=None)
    ) -> dict:
        """生成包含当前已抽取内容的 Markdown 综合报告。

        单文件报告写入 replication_doc/replication_status。
        批次或压缩包父任务报告写入 batch_summary/batch_summary_status。
        """
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        note = (payload.note if payload else "").strip()
        force = bool(payload.force if payload else False)

        from ..reports import build_batch_report, build_task_report

        if state.file_type == "batch" or state.child_ids:
            if (
                state.batch_summary_status == "done"
                and state.batch_summary
                and not force
                and not note
            ):
                return {
                    "task_id": task_id,
                    "report_kind": "batch",
                    "report_status": "done",
                    "batch_summary_status": "done",
                    "replication_status": state.replication_status,
                    "message": "综合报告已存在",
                }
            children = await runtime.store.list_by_parent(task_id)
            document = build_batch_report(state, children, note=note)
            state.batch_summary = document
            state.batch_summary_status = "done"
            await runtime.store.save(state)
            logger.info("task={} 批次综合报告生成完成: {} 字符", task_id, len(document))
            return {
                "task_id": task_id,
                "report_kind": "batch",
                "report_status": "done",
                "batch_summary_status": "done",
                "replication_status": state.replication_status,
                "message": "综合报告已生成",
            }
        if (
            state.replication_status == "done"
            and state.replication_doc
            and not force
            and not note
        ):
            return {
                "task_id": task_id,
                "report_kind": "single",
                "report_status": "done",
                "replication_status": "done",
                "batch_summary_status": state.batch_summary_status,
                "message": "综合报告已存在",
            }
        document = build_task_report(state, note=note)
        state.replication_doc = document
        state.replication_status = "done"
        await runtime.store.save(state)
        logger.info("task={} 单文档综合报告生成完成: {} 字符", task_id, len(document))
        return {
            "task_id": task_id,
            "report_kind": "single",
            "report_status": "done",
            "replication_status": "done",
            "batch_summary_status": state.batch_summary_status,
            "message": "综合报告已生成",
        }

    @app.delete("/tasks/{task_id}")
    async def delete_task(task_id: str, request: Request) -> dict:
        """删除任务记录 + 关联的上传文件。"""
        if runtime.store is None:
            raise HTTPException(500, "store 未初始化")
        state = await runtime.store.load(task_id)
        if state is None:
            raise HTTPException(404, f"任务不存在: {task_id}")
        tenant_id = runtime._request_tenant(request)
        if state.tenant_id != tenant_id:
            raise HTTPException(404, "task not found")

        targets = [state]
        for child_id in state.child_ids or []:
            child = await runtime.store.load(child_id)
            if child is not None and child.tenant_id == tenant_id:
                targets.append(child)
        running = []
        for target in targets:
            background = runtime._task_registry.get(target.task_id)
            if background is not None and not background.done():
                background.cancel()
                running.append(background)
        if running:
            await asyncio.gather(*running, return_exceptions=True)

        if settings.knowledge_required and runtime.knowledge_runtime is None:
            raise HTTPException(503, "required knowledge runtime is unavailable")
        knowledge_results: list[dict[str, Any]] = []
        if runtime.knowledge_runtime is not None:
            for target in targets:
                try:
                    outcome = await runtime.knowledge_runtime.tombstone_task(
                        tenant_id=tenant_id,
                        task_id=target.task_id,
                    )
                    knowledge_results.append(outcome.model_dump(mode="json"))
                except Exception as exc:  # noqa: BLE001 - policy handled below
                    if settings.knowledge_required:
                        raise HTTPException(
                            502,
                            f"knowledge tombstone failed: {exc.__class__.__name__}",
                        ) from exc
                    logger.warning(
                        "knowledge tombstone failed task={} ({})",
                        target.task_id,
                        runtime._safe_exception_message(exc),
                    )

        if state.file_path:
            try:
                path = Path(state.file_path)
                if path.exists():
                    path.unlink()
                    logger.info("已删除文件: {}", state.file_path)
            except Exception as exc:  # noqa: BLE001 - deletion remains best effort
                logger.warning(
                    "删除文件失败 (忽略): {}", runtime._safe_exception_message(exc)
                )
        mineru_runner = getattr(
            getattr(runtime.engine, "deps", None),
            "mineru_shadow_runner",
            None,
        )
        delete_mineru_artifact = getattr(mineru_runner, "delete_artifact", None)
        if callable(delete_mineru_artifact):
            for target in targets:
                try:
                    await delete_mineru_artifact(target.task_id)
                except Exception as exc:  # noqa: BLE001 - task deletion remains primary
                    logger.warning(
                        "MinerU shadow artifact cleanup failed task={} ({})",
                        target.task_id,
                        runtime._safe_exception_message(exc),
                    )
        deleted = await runtime.store.delete(task_id)
        for child_id in state.child_ids or []:
            child = await runtime.store.load(child_id)
            if child and child.file_path:
                try:
                    child_path = Path(child.file_path)
                    if child_path.exists():
                        child_path.unlink()
                except Exception:  # noqa: S110 - preserve best-effort cleanup
                    pass
            await runtime.store.delete(child_id)
        return {
            "deleted": deleted,
            "task_id": task_id,
            "children_deleted": len(state.child_ids or []),
            "knowledge_tombstones": knowledge_results,
        }
