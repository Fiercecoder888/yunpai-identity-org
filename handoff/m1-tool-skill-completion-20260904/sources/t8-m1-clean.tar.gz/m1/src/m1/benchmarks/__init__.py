"""Offline, non-production benchmark utilities."""
