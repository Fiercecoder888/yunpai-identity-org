"""Golden-corpus baseline and parser comparison CLI.

Private manifests and outputs are ignored by Git.  The command never calls an
LLM and only records full document payloads in the explicitly selected output
directory.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
import time
import unicodedata
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

from ..documents import (
    parse_docx_document,
    parse_pdf_document,
    parse_spreadsheet_document,
)
from ..documents.parsing.comparison import compare_document_records
from ..documents.parsing.docling import DoclingBackend
from ..documents.parsing.structured import PARSER_MODEL_REQUIREMENTS
from ..documents.parsing.service import DocumentParserService
from ..documents.parsing.structured import PaddleOCRVLBackend, PPStructureV3Backend


_CRITICAL_HEADER_FIELDS = (
    "contract_number",
    "order_number",
    "date_raw",
    "delivery_date_raw",
    "buyer",
    "seller",
    "supplier",
)


def _rss_bytes() -> int | None:
    try:
        import psutil

        return int(psutil.Process().memory_info().rss)
    except (ImportError, OSError):
        return None


def _nearest_rank_p95(values: list[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(len(ordered) * 0.95) - 1)]


def _valid_bbox(value: Any) -> bool:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return False
    try:
        x0, y0, x1, y1 = (float(item) for item in value)
    except (TypeError, ValueError):
        return False
    return all(math.isfinite(item) for item in (x0, y0, x1, y1)) and x1 >= x0 and y1 >= y0


def _normalized_text(value: Any) -> str:
    return "".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def _record_pages(record: dict[str, Any]) -> list[dict[str, Any]]:
    extraction = record.get("extraction")
    raw = extraction.get("raw_content") if isinstance(extraction, dict) else None
    pages = raw.get("pages") if isinstance(raw, dict) else None
    return [page for page in pages or [] if isinstance(page, dict)]


def _valid_pdf_source_ref(record: dict[str, Any], ref: dict[str, Any], value: Any) -> bool:
    try:
        page_number = int(ref.get("page") or 0)
    except (TypeError, ValueError):
        return False
    page = next(
        (
            item
            for index, item in enumerate(_record_pages(record))
            if int(item.get("page_number") or index + 1) == page_number
        ),
        None,
    )
    if page is None:
        return False
    try:
        if float(page.get("coordinate_width") or page.get("width") or 0) <= 0:
            return False
        if float(page.get("coordinate_height") or page.get("height") or 0) <= 0:
            return False
    except (TypeError, ValueError):
        return False
    part = str(ref.get("part") or "")
    if part in {"native_text", "native/text"}:
        expected = _normalized_text(value)
        return any(
            _valid_bbox(block.get("bbox"))
            and expected
            and expected in _normalized_text(
                block.get("text_normalized") or block.get("text_original")
            )
            for block in page.get("text_blocks") or []
            if isinstance(block, dict)
        )
    normalized_part = part.removeprefix("ocr/")
    if normalized_part.startswith("block:"):
        try:
            index = int(normalized_part.split(":", 1)[1])
            line = (page.get("ocr_lines") or [])[index]
        except (IndexError, TypeError, ValueError):
            return False
        return isinstance(line, dict) and _valid_bbox(line.get("bbox"))
    tokens = normalized_part.split("/")
    try:
        table_index = int(tokens[0].split(":", 1)[1])
        row_index = int(tokens[1].split(":", 1)[1])
        column_index = int(tokens[2].split(":", 1)[1])
    except (IndexError, ValueError):
        return False
    tables = page.get("ocr_tables") or page.get("tables") or []
    try:
        table = next(
            (
                item
                for item in tables
                if isinstance(item, dict)
                and int(item.get("table_index") or -1) == table_index
            ),
            None,
        )
        if table is None:
            table = tables[table_index]
        matrix = table.get("cell_bbox_matrix") or []
        if matrix:
            return _valid_bbox(matrix[row_index][column_index])
        columns = int(table.get("column_count") or 0)
        return columns > 0 and _valid_bbox(
            (table.get("cell_bboxes") or [])[row_index * columns + column_index]
        )
    except (IndexError, TypeError, ValueError, AttributeError):
        return False


def _valid_source_ref(record: dict[str, Any], value: Any, ref: Any) -> bool:
    if not isinstance(ref, dict):
        return False
    if ref.get("sheet") and (ref.get("cell") or ref.get("range")):
        return True
    return _valid_pdf_source_ref(record, ref, value)


def _evidence_coverage(record: dict[str, Any]) -> tuple[int, int]:
    metadata = record.get("field_meta") if isinstance(record.get("field_meta"), dict) else {}
    header = record.get("header") if isinstance(record.get("header"), dict) else {}
    paths = [
        (f"$.header.{field}", header.get(field))
        for field in _CRITICAL_HEADER_FIELDS
        if header.get(field) not in (None, "", [], {})
    ]
    for index, line in enumerate(record.get("lines") or []):
        if not isinstance(line, dict):
            continue
        for field, value in line.items():
            if field in {"line_id", "image_refs", "custom_fields", "raw_columns"}:
                continue
            if value not in (None, "", [], {}):
                paths.append((f"$.lines[{index}].{field}", value))
    valid = 0
    for path, value in paths:
        item = metadata.get(path)
        refs = item.get("source_refs") if isinstance(item, dict) else None
        if isinstance(refs, list) and any(
            _valid_source_ref(record, value, ref) for ref in refs
        ):
            valid += 1
    return valid, len(paths)


def _baseline_cell_matches(
    baseline: dict[str, Any], candidate: dict[str, Any]
) -> tuple[int, int]:
    expected = baseline.get("lines") if isinstance(baseline.get("lines"), list) else []
    actual = candidate.get("lines") if isinstance(candidate.get("lines"), list) else []
    matched = 0
    compared = 0
    for index, expected_line in enumerate(expected):
        if not isinstance(expected_line, dict):
            continue
        actual_line = actual[index] if index < len(actual) and isinstance(actual[index], dict) else {}
        for field, value in expected_line.items():
            # line_id is a generated record identity, not a parsed cell value.
            # Comparing it across independent benchmark runs makes an otherwise
            # identical row look wrong and understates extraction accuracy.
            if field in {"line_id", "image_refs", "custom_fields", "raw_columns"}:
                continue
            if value in (None, "", [], {}):
                continue
            compared += 1
            if actual_line.get(field) == value:
                matched += 1
    return matched, compared


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _parse_case(case: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    source = Path(str(case["path"])).expanduser()
    if not source.is_file():
        raise FileNotFoundError(source)
    hints = case.get("hints") if isinstance(case.get("hints"), dict) else {}
    started = time.perf_counter()
    suffix = source.suffix.casefold()
    if suffix == ".pdf":
        record = parse_pdf_document(
            source,
            str(case.get("original_filename") or source.name),
            doc_type_hint=hints.get("document_type"),
            document_subtype_hint=hints.get("document_subtype"),
            render_dir=output_dir / "assets" / str(case["id"]),
            render_pages=False,
        )
    elif suffix in {".xlsx", ".xlsm", ".xls", ".csv"}:
        record = parse_spreadsheet_document(
            source,
            str(case.get("original_filename") or source.name),
            hints.get("document_subtype"),
        )
    elif suffix == ".docx":
        record = parse_docx_document(
            source,
            str(case.get("original_filename") or source.name),
            assets_dir=output_dir / "assets" / str(case["id"]),
        )
    else:
        raise ValueError(f"unsupported golden format: {suffix}")
    payload = record.model_dump(mode="json")
    return {
        "id": str(case["id"]),
        "path": str(source.resolve()),
        "sha256": _sha256(source),
        "size_bytes": source.stat().st_size,
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
        "summary": {
            "document_type": payload.get("document_type"),
            "document_subtype": payload.get("document_subtype"),
            "line_count": len(payload.get("lines") or []),
            "issue_codes": sorted(
                str(issue.get("code"))
                for issue in payload.get("validation_issues") or []
                if isinstance(issue, dict) and issue.get("code")
            ),
            "field_meta_count": len(payload.get("field_meta") or {}),
        },
        "record": payload,
    }


def create_baseline(manifest_path: Path, output_dir: Path) -> dict[str, Any]:
    manifest = _read_json(manifest_path)
    cases = manifest.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("golden manifest must contain a non-empty cases list")
    output_dir.mkdir(parents=True, exist_ok=True)
    results = [_parse_case(case, output_dir) for case in cases if isinstance(case, dict)]
    payload = {
        "schema_version": "m1.parser-benchmark.v1",
        "manifest": str(manifest_path.resolve()),
        "case_count": len(results),
        "cases": results,
    }
    target = output_dir / "baseline.json"
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


async def _parse_candidate_case(
    case: dict[str, Any],
    output_dir: Path,
    service: DocumentParserService,
) -> dict[str, Any]:
    source = Path(str(case["path"])).expanduser()
    if not source.is_file():
        raise FileNotFoundError(source)
    hints = case.get("hints") if isinstance(case.get("hints"), dict) else {}
    started = time.perf_counter()
    rss_before = _rss_bytes()
    peak_rss = rss_before
    sampling_done = asyncio.Event()

    async def sample_rss() -> None:
        nonlocal peak_rss
        while not sampling_done.is_set():
            current = _rss_bytes()
            if current is not None:
                peak_rss = current if peak_rss is None else max(peak_rss, current)
            try:
                await asyncio.wait_for(sampling_done.wait(), timeout=0.05)
            except TimeoutError:
                pass

    sampler = asyncio.create_task(sample_rss())
    suffix = source.suffix.casefold()
    try:
        if suffix == ".pdf":
            record = await service.parse_pdf(
                source,
                str(case.get("original_filename") or source.name),
                doc_type_hint=hints.get("document_type"),
                document_subtype_hint=hints.get("document_subtype"),
                render_dir=output_dir / "assets" / str(case["id"]),
                render_dpi=150,
            )
        elif suffix in {".xlsx", ".xlsm", ".xls", ".csv"}:
            record = await asyncio.to_thread(
                parse_spreadsheet_document,
                source,
                str(case.get("original_filename") or source.name),
                hints.get("document_subtype"),
            )
        elif suffix == ".docx":
            record = await service.parse_docx(
                source,
                str(case.get("original_filename") or source.name),
                assets_dir=output_dir / "assets" / str(case["id"]),
            )
        else:
            raise ValueError(f"unsupported golden format: {suffix}")
    finally:
        sampling_done.set()
        await sampler
    payload = record.model_dump(mode="json")
    return {
        "id": str(case["id"]),
        "path": str(source.resolve()),
        "sha256": _sha256(source),
        "size_bytes": source.stat().st_size,
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 3),
        "rss_before_bytes": rss_before,
        "peak_rss_bytes": peak_rss,
        "peak_rss_delta_bytes": (
            max(0, peak_rss - rss_before)
            if peak_rss is not None and rss_before is not None
            else None
        ),
        "summary": {
            "document_type": payload.get("document_type"),
            "document_subtype": payload.get("document_subtype"),
            "line_count": len(payload.get("lines") or []),
            "issue_codes": sorted(
                str(issue.get("code"))
                for issue in payload.get("validation_issues") or []
                if isinstance(issue, dict) and issue.get("code")
            ),
            "field_meta_count": len(payload.get("field_meta") or {}),
        },
        "record": payload,
    }


async def create_candidate(
    manifest_path: Path,
    output_dir: Path,
    *,
    mode: str,
    model_root: Path,
    device: str,
    enable_vl: bool = False,
    enable_docling: bool = False,
) -> dict[str, Any]:
    manifest = _read_json(manifest_path)
    cases = manifest.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError("golden manifest must contain a non-empty cases list")
    pp = PPStructureV3Backend(
        device=device,
        model_root=model_root,
        runtime_downloads=False,
    )
    vl = (
        PaddleOCRVLBackend(
            device=device,
            model_root=model_root,
            runtime_downloads=False,
        )
        if enable_vl
        else None
    )
    service = DocumentParserService(
        mode=mode,
        pp_structure=pp,
        paddle_vl=vl,
        docling=DoclingBackend() if enable_docling else None,
    )
    readiness = service.readiness()
    if not readiness.get("ready"):
        raise RuntimeError(f"parser cache is not ready: {readiness}")
    output_dir.mkdir(parents=True, exist_ok=True)
    results = [
        await _parse_candidate_case(case, output_dir, service)
        for case in cases
        if isinstance(case, dict)
    ]
    payload = {
        "schema_version": "m1.parser-benchmark.v1",
        "manifest": str(manifest_path.resolve()),
        "mode": mode,
        "parser_readiness": readiness,
        "case_count": len(results),
        "performance": {
            "p95_elapsed_ms": _nearest_rank_p95(
                [float(result["elapsed_ms"]) for result in results]
            ),
            "max_elapsed_ms": max(
                (float(result["elapsed_ms"]) for result in results), default=None
            ),
            "max_peak_rss_bytes": max(
                (
                    int(result["peak_rss_bytes"])
                    for result in results
                    if result.get("peak_rss_bytes") is not None
                ),
                default=None,
            ),
        },
        "cases": results,
    }
    target = output_dir / "candidate.json"
    target.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return payload


def compare_runs(baseline_path: Path, candidate_path: Path, output_path: Path) -> dict[str, Any]:
    baseline = _read_json(baseline_path)
    candidate = _read_json(candidate_path)
    baseline_cases = {
        str(case["id"]): case for case in baseline.get("cases", []) if isinstance(case, dict)
    }
    candidate_cases = {
        str(case["id"]): case for case in candidate.get("cases", []) if isinstance(case, dict)
    }
    reports = []
    classification_matches = 0
    line_count_matches = 0
    header_matches = 0
    header_compared = 0
    cell_matches = 0
    cells_compared = 0
    evidence_valid = 0
    evidence_total = 0
    for case_id in sorted(set(baseline_cases) | set(candidate_cases)):
        before = baseline_cases.get(case_id)
        after = candidate_cases.get(case_id)
        if before is None or after is None:
            reports.append({"id": case_id, "missing": "baseline" if before is None else "candidate"})
            continue
        report = compare_document_records(before.get("record") or {}, after.get("record") or {})
        before_record = before.get("record") or {}
        after_record = after.get("record") or {}
        classification_matches += int(bool(report.get("classification_equal")))
        line_count_matches += int(
            int(report.get("baseline_line_count") or 0)
            == int(report.get("candidate_line_count") or 0)
        )
        before_header = before_record.get("header") if isinstance(before_record.get("header"), dict) else {}
        after_header = after_record.get("header") if isinstance(after_record.get("header"), dict) else {}
        for field in _CRITICAL_HEADER_FIELDS:
            if before_header.get(field) in (None, "", [], {}) and after_header.get(field) in (
                None,
                "",
                [],
                {},
            ):
                continue
            header_compared += 1
            header_matches += int(before_header.get(field) == after_header.get(field))
        matched, compared = _baseline_cell_matches(before_record, after_record)
        cell_matches += matched
        cells_compared += compared
        valid, total = _evidence_coverage(after_record)
        evidence_valid += valid
        evidence_total += total
        reports.append(
            {
                "id": case_id,
                **report,
                "baseline_elapsed_ms": before.get("elapsed_ms"),
                "candidate_elapsed_ms": after.get("elapsed_ms"),
            }
        )
    baseline_times = [
        float(case.get("elapsed_ms") or 0)
        for case in baseline_cases.values()
        if case.get("elapsed_ms") is not None
    ]
    candidate_times = [
        float(case.get("elapsed_ms") or 0)
        for case in candidate_cases.values()
        if case.get("elapsed_ms") is not None
    ]
    baseline_p95 = _nearest_rank_p95(baseline_times)
    candidate_p95 = _nearest_rank_p95(candidate_times)
    p95_ratio = (
        candidate_p95 / baseline_p95
        if candidate_p95 is not None and baseline_p95 not in (None, 0)
        else None
    )
    comparable_count = sum(1 for report in reports if "missing" not in report)
    metrics = {
        "labels": "legacy_baseline_proxy_not_human_ground_truth",
        "classification_exact": {
            "matched": classification_matches,
            "total": comparable_count,
        },
        "critical_header_exact": {
            "matched": header_matches,
            "total": header_compared,
            "accuracy": header_matches / header_compared if header_compared else 1.0,
        },
        "line_count_exact": {
            "matched": line_count_matches,
            "total": comparable_count,
        },
        "nonempty_line_field_accuracy": {
            "matched": cell_matches,
            "total": cells_compared,
            "accuracy": cell_matches / cells_compared if cells_compared else 1.0,
        },
        "source_reference_coverage": {
            "valid": evidence_valid,
            "total": evidence_total,
            "ratio": evidence_valid / evidence_total if evidence_total else 1.0,
        },
        "performance": {
            "baseline_p95_ms": baseline_p95,
            "candidate_p95_ms": candidate_p95,
            "candidate_to_baseline_ratio": p95_ratio,
        },
    }
    metrics["gates"] = {
        "classification_exact": classification_matches == comparable_count,
        "critical_header_exact": header_matches == header_compared,
        "line_count_exact": line_count_matches == comparable_count,
        "nonempty_line_field_accuracy_gte_0_98": (
            cell_matches / cells_compared if cells_compared else 1.0
        )
        >= 0.98,
        "source_reference_coverage_exact": evidence_valid == evidence_total,
        "p95_lte_legacy_1_5x": p95_ratio is not None and p95_ratio <= 1.5,
        "p95_lte_180_seconds": candidate_p95 is not None and candidate_p95 <= 180_000,
    }
    payload = {
        "schema_version": "m1.parser-comparison.v1",
        "case_count": len(reports),
        "metrics": metrics,
        "reports": reports,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def _package_version(distribution: str) -> str:
    try:
        return version(distribution)
    except PackageNotFoundError:
        return "not-installed"


def create_model_manifest(
    model_root: Path,
    *,
    output_path: Path | None = None,
) -> dict[str, Any]:
    if not model_root.is_dir():
        raise FileNotFoundError(model_root)
    official_models = model_root / "official_models"
    if not official_models.is_dir():
        raise ValueError("model root does not contain official_models")
    target = output_path or model_root / "document-parser-models.json"
    required_model_names = set().union(*PARSER_MODEL_REQUIREMENTS.values())
    files = sorted(
        path
        for model_name in sorted(required_model_names)
        for path in (official_models / model_name).rglob("*")
        if path.is_file()
        and ".cache" not in path.relative_to(official_models).parts
        and path.resolve() != target.resolve()
    )
    if not files:
        raise ValueError("model root contains no files")
    models = [
        {
            "name": path.relative_to(official_models).parts[0],
            "path": path.relative_to(model_root).as_posix(),
            "sha256": _sha256(path),
            "size_bytes": path.stat().st_size,
        }
        for path in files
    ]
    available_models = {
        path.parent.name
        for path in model_root.glob("official_models/*/*")
        if path.is_file()
    }
    pipelines = {
        pipeline: {
            "complete": required.issubset(available_models),
            "models": sorted(required),
            "missing_models": sorted(required - available_models),
        }
        for pipeline, required in PARSER_MODEL_REQUIREMENTS.items()
    }
    payload = {
        "schema_version": "m1.document-parser-models.v1",
        "complete": all(item["complete"] for item in pipelines.values()),
        "runtime_downloads_allowed": False,
        "runtime": {
            "paddleocr": {
                "version": _package_version("paddleocr"),
                "license": "Apache-2.0",
            },
            "paddlepaddle": {
                "version": _package_version("paddlepaddle"),
                "license": "Apache-2.0",
            },
            "paddlex": {
                "version": _package_version("paddlex"),
                "license": "Apache-2.0",
            },
        },
        "pipelines": pipelines,
        "models": models,
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    baseline = subparsers.add_parser("baseline")
    baseline.add_argument("manifest", type=Path)
    baseline.add_argument("output_dir", type=Path)

    compare = subparsers.add_parser("compare")
    compare.add_argument("baseline", type=Path)
    compare.add_argument("candidate", type=Path)
    compare.add_argument("output", type=Path)

    candidate = subparsers.add_parser("candidate")
    candidate.add_argument("manifest", type=Path)
    candidate.add_argument("output_dir", type=Path)
    candidate.add_argument("--mode", choices=("shadow", "structured"), default="shadow")
    candidate.add_argument("--model-root", type=Path, required=True)
    candidate.add_argument("--device", default="cpu")
    candidate.add_argument("--enable-vl", action="store_true")
    candidate.add_argument("--enable-docling", action="store_true")

    models = subparsers.add_parser("model-manifest")
    models.add_argument("model_root", type=Path)
    models.add_argument("--output", type=Path)

    args = parser.parse_args()
    if args.command == "baseline":
        result = create_baseline(args.manifest, args.output_dir)
    elif args.command == "candidate":
        result = asyncio.run(
            create_candidate(
                args.manifest,
                args.output_dir,
                mode=args.mode,
                model_root=args.model_root,
                device=args.device,
                enable_vl=args.enable_vl,
                enable_docling=args.enable_docling,
            )
        )
    elif args.command == "compare":
        result = compare_runs(args.baseline, args.candidate, args.output)
    else:
        result = create_model_manifest(args.model_root, output_path=args.output)
    print(json.dumps({key: value for key, value in result.items() if key != "cases"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
