"""Run and archive the explicit M1 enhanced deployment preflight.

This command never accepts a plaintext key on the command line.  It reads the
existing M1 API key from an environment variable, calls the protected explicit
preflight endpoint once, and atomically saves the timestamped safe report.

Example after the optional routes are registered::

    python -m m1.benchmarks.enhanced_preflight \
      --base-url http://127.0.0.1:8080 \
      --output ./data/enhanced-preflight-last.json \
      --require-all
"""

from __future__ import annotations

import argparse
import asyncio
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
from typing import Any

import httpx


async def request_preflight(
    *,
    base_url: str,
    api_key: str,
    preflight_key: str,
    require_all: bool,
    include_lightrag_lifecycle: bool,
    timeout_seconds: float,
    transport: httpx.AsyncBaseTransport | None = None,
) -> tuple[int, dict[str, Any]]:
    """Call the explicit endpoint and return only its already-sanitized report."""

    headers = {"Accept": "application/json"}
    if api_key:
        headers["X-API-Key"] = api_key
    if preflight_key:
        headers["X-M1-Preflight-Key"] = preflight_key
    async with httpx.AsyncClient(
        base_url=base_url.rstrip("/") + "/",
        headers=headers,
        timeout=httpx.Timeout(timeout_seconds),
        transport=transport,
    ) as client:
        response = await client.post(
            "enhanced/preflight",
            json={
                "require_all": require_all,
                "include_lightrag_lifecycle": include_lightrag_lifecycle,
                "confirm_lightrag_lifecycle_side_effects": (
                    include_lightrag_lifecycle
                ),
            },
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError(
            f"enhanced preflight returned non-JSON HTTP {response.status_code}"
        ) from exc
    if not isinstance(payload, dict):
        raise RuntimeError("enhanced preflight returned a non-object response")
    if response.status_code not in {200, 503}:
        raise RuntimeError(f"enhanced preflight failed with HTTP {response.status_code}")
    return response.status_code, payload


def save_report(path: Path, report: dict[str, Any]) -> None:
    """Atomically replace one local report; credentials are never added."""

    output = path.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "report": report,
    }
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=output.parent,
        prefix=output.name + ".",
        suffix=".tmp",
        delete=False,
    ) as stream:
        temporary = Path(stream.name)
        json.dump(payload, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
    temporary.replace(output)


async def _run(args: argparse.Namespace) -> int:
    api_key = os.environ.get(args.api_key_env, "")
    preflight_key = os.environ.get(args.preflight_key_env, "")
    status, report = await request_preflight(
        base_url=args.base_url,
        api_key=api_key,
        preflight_key=preflight_key,
        require_all=args.require_all,
        include_lightrag_lifecycle=args.lightrag_lifecycle,
        timeout_seconds=args.timeout,
    )
    save_report(args.output, report)
    ready = bool(report.get("ready")) and status == 200
    print(
        json.dumps(
            {
                "ready": ready,
                "http_status": status,
                "report_path": str(args.output),
            },
            ensure_ascii=False,
        )
    )
    return 0 if ready else 2


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8080")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--api-key-env",
        default="M1_API_KEY",
        help="environment variable containing the key; never the key itself",
    )
    parser.add_argument(
        "--preflight-key-env",
        default="M1_ENHANCED_PREFLIGHT_KEY",
        help="environment variable containing the independent preflight key",
    )
    parser.add_argument("--require-all", action="store_true")
    parser.add_argument(
        "--lightrag-lifecycle",
        action="store_true",
        help="explicitly allow one isolated LightRAG insert/replay/delete probe",
    )
    parser.add_argument("--timeout", type=float, default=900.0)
    args = parser.parse_args()
    if args.timeout < 1:
        parser.error("--timeout must be at least one second")
    raise SystemExit(asyncio.run(_run(args)))


if __name__ == "__main__":
    main()
