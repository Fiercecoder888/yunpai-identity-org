"""Offline authoritative-vs-LightRAG retrieval comparison.

The comparison calls M1's existing ``/knowledge/search`` route and LightRAG's
existing ``/query`` route, then writes local JSON and HTML.  The optional
lifecycle probe writes and deletes one synthetic LightRAG-only record.  It
does not add an M1 API or mutate M1's authoritative store.
"""
from __future__ import annotations

import argparse
import asyncio
from collections.abc import Iterable, Mapping
import html
import json
from pathlib import Path
import time
from typing import Any
from uuid import uuid4

import httpx

from ..knowledge.lightrag_shadow import LightRAGShadowClient


def _load_cases(path: Path) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    cases = payload.get("cases") if isinstance(payload, dict) else None
    if not isinstance(cases, list) or not cases:
        raise ValueError("comparison input requires a non-empty cases array")
    output = []
    for raw in cases:
        if not isinstance(raw, dict):
            continue
        query = str(raw.get("query") or "").strip()
        if len(query) < 3:
            raise ValueError("each LightRAG query must contain at least 3 characters")
        expected = raw.get("expected_source_record_ids") or []
        if not isinstance(expected, list):
            raise ValueError("expected_source_record_ids must be an array")
        output.append(
            {
                "id": str(raw.get("id") or f"case-{len(output) + 1}"),
                "query": query,
                "expected_source_record_ids": [
                    str(item) for item in expected if str(item).strip()
                ],
            }
        )
    if not output:
        raise ValueError("comparison input contains no valid cases")
    return output


def _reference_strings(value: Any) -> set[str]:
    """Collect opaque LightRAG citation basenames without retaining context."""

    references: set[str] = set()
    if isinstance(value, str):
        for token in value.replace('"', " ").replace("'", " ").split():
            cleaned = token.strip("[](){},;:")
            if "m1shadow-" in cleaned and ".txt" in cleaned:
                start = cleaned.find("m1shadow-")
                end = cleaned.find(".txt", start) + 4
                references.add(cleaned[start:end])
    elif isinstance(value, Mapping):
        for item in value.values():
            references.update(_reference_strings(item))
    elif isinstance(value, Iterable) and not isinstance(value, (bytes, bytearray)):
        for item in value:
            references.update(_reference_strings(item))
    return references


async def compare(
    *,
    cases: list[dict[str, Any]],
    m1_base_url: str,
    tenant_id: str,
    m1_api_key: str,
    lightrag: LightRAGShadowClient,
    top_k: int,
) -> dict[str, Any]:
    m1_headers = {"X-Tenant-ID": tenant_id}
    if m1_api_key:
        m1_headers["X-API-Key"] = m1_api_key
    results: list[dict[str, Any]] = []
    async with httpx.AsyncClient(
        base_url=m1_base_url.rstrip("/") + "/",
        headers=m1_headers,
        timeout=60.0,
    ) as m1:
        for case in cases:
            query = str(case["query"])
            expected = set(case["expected_source_record_ids"])

            started = time.perf_counter()
            authoritative_response = await m1.get(
                "knowledge/search", params={"q": query, "limit": top_k}
            )
            authoritative_response.raise_for_status()
            authoritative_ms = (time.perf_counter() - started) * 1000
            authoritative_body = authoritative_response.json()
            hits = (
                authoritative_body.get("hits", [])
                if isinstance(authoritative_body, dict)
                else []
            )
            authoritative_ids = [
                str((hit.get("document") or {}).get("source_record_id") or "")
                for hit in hits
                if isinstance(hit, dict) and isinstance(hit.get("document"), dict)
            ]

            started = time.perf_counter()
            shadow_body = await lightrag.query(query, mode="mix", top_k=top_k)
            shadow_ms = (time.perf_counter() - started) * 1000
            citations = sorted(_reference_strings(shadow_body))
            expected_prefixes = {
                lightrag.source_prefix(tenant_id, source_id)
                for source_id in expected
            }
            matched_shadow_sources = {
                prefix
                for prefix in expected_prefixes
                if any(citation.startswith(prefix) for citation in citations)
            }
            authoritative_matches = expected.intersection(authoritative_ids[:top_k])
            results.append(
                {
                    "id": case["id"],
                    "query": query,
                    "expected_count": len(expected),
                    "authoritative": {
                        "latency_ms": round(authoritative_ms, 3),
                        "hit_count": len(authoritative_ids),
                        "recall_at_k": (
                            len(authoritative_matches) / len(expected)
                            if expected
                            else None
                        ),
                    },
                    "lightrag": {
                        "latency_ms": round(shadow_ms, 3),
                        "citation_count": len(citations),
                        "recall_at_k": (
                            len(matched_shadow_sources) / len(expected)
                            if expected
                            else None
                        ),
                        "citation_correctness": (
                            sum(
                                any(
                                    citation.startswith(prefix)
                                    for prefix in expected_prefixes
                                )
                                for citation in citations
                            )
                            / len(citations)
                            if citations and expected_prefixes
                            else None
                        ),
                    },
                }
            )
    return {
        "schema_version": "m1.lightrag-comparison.v1",
        "tenant_id": tenant_id,
        "top_k": top_k,
        "case_count": len(results),
        "cases": results,
    }


async def lifecycle_probe(
    lightrag: LightRAGShadowClient,
    *,
    timeout_seconds: float = 120.0,
) -> dict[str, Any]:
    """Measure duplicate-write idempotency and post-delete invisibility."""

    token = uuid4().hex
    marker = f"M1_LIGHTRAG_LIFECYCLE_PROBE_{token}"
    tenant_id = "m1_benchmark_probe"
    source_record_id = f"probe-{token}"
    started = time.perf_counter()
    try:
        first = await lightrag.upsert_document(
            tenant_id=tenant_id,
            source_record_id=source_record_id,
            version="1",
            fingerprint=token,
            texts=[marker],
        )
        deadline = time.monotonic() + timeout_seconds
        prefix = lightrag.source_prefix(tenant_id, source_record_id)
        while True:
            matching = [
                item
                for item in await lightrag.list_documents()
                if item.file_source.startswith(prefix)
            ]
            if matching and all(
                item.status in {"processed", "preprocessed"} for item in matching
            ):
                break
            if time.monotonic() >= deadline:
                raise TimeoutError("LightRAG lifecycle insert did not finish")
            await asyncio.sleep(0.5)
        replay = await lightrag.upsert_document(
            tenant_id=tenant_id,
            source_record_id=source_record_id,
            version="1",
            fingerprint=token,
            texts=[marker],
        )
        matching_after_replay = [
            item
            for item in await lightrag.list_documents()
            if item.file_source.startswith(prefix)
        ]
        # LightRAG can expose ``processed`` in document status just before its
        # vector/graph query indexes become visible.  Poll the public query API
        # instead of treating that short consistency window as a failed index.
        retrieval_deadline = time.monotonic() + timeout_seconds
        indexed_retrievable = False
        while True:
            # Lifecycle verification must observe the indexed source text, not
            # an LLM-authored answer.  ``mix`` may legitimately paraphrase an
            # opaque probe marker even when the vector index is healthy.
            before_delete = await lightrag.query(marker, mode="naive", top_k=5)
            indexed_retrievable = marker in json.dumps(
                before_delete, ensure_ascii=False
            )
            if indexed_retrievable or time.monotonic() >= retrieval_deadline:
                break
            await asyncio.sleep(0.5)

        deletion_deadline = time.monotonic() + timeout_seconds
        while True:
            try:
                await lightrag.delete_source(
                    tenant_id=tenant_id,
                    source_record_id=source_record_id,
                )
                break
            except Exception:  # noqa: BLE001 - bounded async delete polling
                if time.monotonic() >= deletion_deadline:
                    raise
                await asyncio.sleep(0.5)
        remaining = [
            item
            for item in await lightrag.list_documents()
            if item.file_source.startswith(prefix)
        ]
        query_delete_deadline = time.monotonic() + timeout_seconds
        absent_after_delete = False
        while True:
            after_delete = await lightrag.query(marker, mode="naive", top_k=5)
            absent_after_delete = marker not in json.dumps(
                after_delete, ensure_ascii=False
            )
            if absent_after_delete or time.monotonic() >= query_delete_deadline:
                break
            await asyncio.sleep(0.5)
        duplicate_idempotent = (
            first.action in {"inserted", "unchanged"}
            and replay.action == "unchanged"
            and len(matching_after_replay) == 1
        )
        deletion_consistent = (
            indexed_retrievable and not remaining and absent_after_delete
        )
        return {
            "enabled": True,
            "duplicate_idempotent": duplicate_idempotent,
            "repeat_write_document_count": len(matching_after_replay),
            "indexed_retrievable": indexed_retrievable,
            "document_absent_after_delete": not remaining,
            "query_absent_after_delete": absent_after_delete,
            "deletion_consistent": deletion_consistent,
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "error": None,
        }
    except Exception as exc:
        # The probe document uses an isolated opaque source hash. Best-effort
        # cleanup prevents a failed benchmark from polluting future reports.
        try:
            await lightrag.delete_source(
                tenant_id=tenant_id,
                source_record_id=source_record_id,
            )
        except Exception:  # noqa: BLE001
            pass
        return {
            "enabled": True,
            "duplicate_idempotent": False,
            "repeat_write_document_count": None,
            "indexed_retrievable": False,
            "document_absent_after_delete": False,
            "query_absent_after_delete": False,
            "deletion_consistent": False,
            "latency_ms": round((time.perf_counter() - started) * 1000, 3),
            "error": exc.__class__.__name__,
        }


def _html_report(payload: dict[str, Any]) -> str:
    rows = []
    for case in payload["cases"]:
        authoritative = case["authoritative"]
        shadow = case["lightrag"]
        rows.append(
            "<tr>"
            f"<td>{html.escape(str(case['id']))}</td>"
            f"<td>{html.escape(str(case['query']))}</td>"
            f"<td>{authoritative['recall_at_k']}</td>"
            f"<td>{shadow['recall_at_k']}</td>"
            f"<td>{shadow['citation_correctness']}</td>"
            f"<td>{authoritative['latency_ms']}</td>"
            f"<td>{shadow['latency_ms']}</td>"
            "</tr>"
        )
    lifecycle = payload.get("lifecycle_probe") or {"enabled": False}
    lifecycle_summary = html.escape(json.dumps(lifecycle, ensure_ascii=False))
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>M1 LightRAG shadow report</title>
<style>body{font-family:system-ui;margin:2rem}table{border-collapse:collapse;width:100%}
th,td{border:1px solid #ccc;padding:.5rem;text-align:left}th{background:#f4f4f4}</style>
</head><body><h1>M1 LightRAG shadow comparison</h1><p><strong>Lifecycle probe:</strong> """ + lifecycle_summary + """</p><table><thead><tr>
<th>Case</th><th>Query</th><th>M1 Recall@K</th><th>LightRAG Recall@K</th>
<th>Citation correctness</th><th>M1 ms</th><th>LightRAG ms</th></tr></thead><tbody>""" + "".join(rows) + "</tbody></table></body></html>"


async def _main(args: argparse.Namespace) -> None:
    client = LightRAGShadowClient(
        args.lightrag_base_url,
        api_key=args.lightrag_api_key,
        workspace=args.workspace,
        timeout_seconds=args.timeout,
    )
    try:
        payload = await compare(
            cases=_load_cases(args.cases),
            m1_base_url=args.m1_base_url,
            tenant_id=args.tenant,
            m1_api_key=args.m1_api_key,
            lightrag=client,
            top_k=args.top_k,
        )
        payload["lifecycle_probe"] = (
            await lifecycle_probe(client, timeout_seconds=args.probe_timeout)
            if args.lifecycle_probe
            else {"enabled": False}
        )
    finally:
        await client.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    args.output.with_suffix(".html").write_text(
        _html_report(payload), encoding="utf-8"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--m1-base-url", default="http://127.0.0.1:8080")
    parser.add_argument("--m1-api-key", default="")
    parser.add_argument("--tenant", default="default")
    parser.add_argument("--lightrag-base-url", default="http://127.0.0.1:9621")
    parser.add_argument("--lightrag-api-key", default="")
    parser.add_argument("--workspace", default="m1_shadow")
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument(
        "--lifecycle-probe",
        action="store_true",
        help="insert/replay/delete one synthetic record and measure consistency",
    )
    parser.add_argument("--probe-timeout", type=float, default=120.0)
    args = parser.parse_args()
    if not 1 <= args.top_k <= 200:
        parser.error("--top-k must be between 1 and 200")
    asyncio.run(_main(args))


if __name__ == "__main__":
    main()
