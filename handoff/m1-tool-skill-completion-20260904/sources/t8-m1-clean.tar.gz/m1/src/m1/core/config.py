"""全局配置: 从环境变量/.env 加载。"""

import re
from pathlib import Path
from typing import Literal

from pydantic import (
    AliasChoices,
    Field,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pydantic_settings import BaseSettings, SettingsConfigDict

_TENANT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        # Secrets must never be sourced from a dotenv file. Docker Compose
        # injects endpoint settings and credentials explicitly; local runs
        # should export variables.
        env_file=None,
        extra="ignore",
    )

    # ===== 图片推理后端 =====
    vlm_base_url: str = "http://host.docker.internal:18086/v1"
    # VLM_API_KEY is canonical; SILICONFLOW_API_KEY remains a legacy alias.
    vlm_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("VLM_API_KEY", "SILICONFLOW_API_KEY"),
        repr=False,
    )
    vlm_model: str = "Qwen/Qwen2.5-VL-7B-Instruct"
    vlm_timeout_seconds: float = Field(default=300.0, gt=0.0, le=600.0)
    vlm_temperature: float = 0.0
    vlm_max_tokens: int = 8192
    vlm_max_images: int = 8
    vlm_enable_thinking: bool = False
    # Tabular-layout routing is a separate model consumer. Production may point
    # it at the same inference service as MinerU Instructor, but endpoint,
    # credential, model, and timeout are always configured independently.
    tabular_layout_router_enabled: bool = False
    tabular_layout_router_required: bool = Field(
        default=False,
        validate_default=True,
    )
    tabular_layout_router_base_url: str = Field(default="", validate_default=True)
    tabular_layout_router_api_key: str = Field(default="", repr=False)
    tabular_layout_router_model: str = Field(default="", validate_default=True)
    tabular_layout_router_timeout_seconds: float = Field(
        default=30.0,
        gt=0.0,
        le=300.0,
    )
    tabular_layout_router_circuit_failures: int = Field(default=3, ge=1, le=100)
    tabular_layout_router_circuit_seconds: float = Field(
        default=300.0,
        gt=0.0,
        le=86_400.0,
    )

    # ===== Governed adaptive document routing =====
    # Routing is disabled by default. When enabled it uses an independent
    # OpenAI-compatible small-model contract and fails fast on partial
    # configuration instead of borrowing another integration's credentials.
    document_router_enabled: bool = False
    document_router_required: bool = Field(default=False, validate_default=True)
    document_router_mode: Literal["shadow", "guarded"] = "shadow"
    document_router_base_url: str = Field(default="", validate_default=True)
    document_router_api_key: str = Field(
        default="",
        repr=False,
        validate_default=True,
    )
    document_router_model: str = Field(default="", validate_default=True)
    document_router_timeout_seconds: float = Field(default=30.0, gt=0, le=300)
    # Bound source/container inspection independently from the routing-model
    # request. A probe timeout stays on the deterministic parser path.
    document_router_probe_timeout_seconds: float = Field(default=10.0, gt=0, le=60)
    document_router_top_k: int = Field(default=3, ge=1, le=20)
    document_router_auto_min_score: float = Field(default=0.90, ge=0.0, le=1.0)
    document_router_model_min_score: float = Field(
        default=0.75,
        ge=0.0,
        le=1.0,
        validate_default=True,
    )
    document_router_min_margin: float = Field(default=0.08, ge=0.0, le=1.0)
    document_router_min_activation_samples: int = Field(default=3, ge=1)
    document_router_circuit_failures: int = Field(default=3, ge=1, le=100)
    document_router_circuit_seconds: float = Field(
        default=300.0,
        gt=0.0,
        le=86_400.0,
    )

    # ===== Governed entity identity routing =====
    # Entity routing has its own model contract. It never inherits VLM or
    # document-router credentials because entity identity decisions need an
    # explicit operational owner and audit boundary.
    entity_router_enabled: bool = False
    entity_router_required: bool = Field(default=False, validate_default=True)
    entity_router_base_url: str = Field(default="", validate_default=True)
    entity_router_api_key: str = Field(default="", repr=False, validate_default=True)
    entity_router_model: str = Field(default="", validate_default=True)
    entity_router_timeout_seconds: float = Field(default=20.0, gt=0, le=180)
    entity_router_top_k: int = Field(default=5, ge=1, le=5)
    entity_router_auto_min_score: float = Field(default=0.90, ge=0.0, le=1.0)
    entity_router_model_min_confidence: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
    )
    entity_router_min_margin: float = Field(default=0.10, ge=0.0, le=1.0)
    entity_router_circuit_failures: int = Field(default=3, ge=1, le=100)
    entity_router_circuit_seconds: float = Field(default=300.0, gt=0.0, le=86_400.0)

    # ===== Governed field-semantic routing =====
    # Unknown source labels are matched only against tenant-scoped, reviewed
    # profiles.  A model may select a closed candidate index, but cannot emit a
    # JSONPath or activate a mapping.
    field_semantic_router_enabled: bool = False
    field_semantic_router_required: bool = False
    field_semantic_router_mode: Literal["shadow", "guarded"] = "shadow"
    field_semantic_router_base_url: str = ""
    field_semantic_router_api_key: str = Field(default="", repr=False)
    field_semantic_router_model: str = ""
    field_semantic_router_timeout_seconds: float = Field(default=20.0, gt=0, le=180)
    field_semantic_router_max_fields_per_document: int = Field(
        default=128, ge=1, le=2_048
    )

    # ===== Governed unresolved visual-region routing =====
    # Geometry remains authoritative.  This selector is called only for an
    # unresolved region and receives code-owned roles plus reviewed candidates.
    visual_region_router_enabled: bool = False
    visual_region_router_required: bool = False
    visual_region_router_mode: Literal["shadow", "guarded"] = "shadow"
    visual_region_router_base_url: str = ""
    visual_region_router_api_key: str = Field(default="", repr=False)
    visual_region_router_model: str = ""
    visual_region_router_timeout_seconds: float = Field(default=20.0, gt=0, le=180)
    visual_region_router_max_regions_per_document: int = Field(default=32, ge=1, le=64)

    # ===== Governed page-capability routing =====
    # This router is currently wired only to the PP-Structure -> PaddleOCR-VL
    # page escalation boundary. It cannot name or execute arbitrary backends.
    region_capability_router_enabled: bool = False
    region_capability_router_required: bool = False
    region_capability_router_base_url: str = ""
    region_capability_router_api_key: str = Field(default="", repr=False)
    region_capability_router_model: str = ""
    region_capability_router_timeout_seconds: float = Field(default=20.0, gt=0, le=180)
    region_capability_router_circuit_failures: int = Field(default=3, ge=1, le=100)
    region_capability_router_circuit_seconds: float = Field(
        default=300.0, gt=0, le=86_400
    )

    # ===== Governed content-region routing =====
    # The model sees only a redacted semantic sketch and bounded indexes. New
    # patterns remain inactive candidates until separately reviewed.
    content_region_router_enabled: bool = False
    content_region_router_required: bool = False
    content_region_router_base_url: str = ""
    content_region_router_api_key: str = Field(default="", repr=False)
    content_region_router_model: str = ""
    content_region_router_timeout_seconds: float = Field(default=20.0, gt=0, le=180)
    content_region_router_circuit_failures: int = Field(default=3, ge=1, le=100)
    content_region_router_circuit_seconds: float = Field(default=300.0, gt=0, le=86_400)

    @field_validator("tabular_layout_router_required")
    @classmethod
    def _validate_tabular_layout_router_required(
        cls,
        value: bool,
        info: ValidationInfo,
    ) -> bool:
        if value and not info.data.get("tabular_layout_router_enabled", False):
            raise ValueError(
                "TABULAR_LAYOUT_ROUTER_REQUIRED requires TABULAR_LAYOUT_ROUTER_ENABLED"
            )
        return value

    @field_validator("tabular_layout_router_base_url")
    @classmethod
    def _validate_tabular_layout_router_base_url(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("tabular_layout_router_enabled", False) and not normalized:
            raise ValueError(
                "TABULAR_LAYOUT_ROUTER_BASE_URL is required when the router is enabled"
            )
        return normalized

    @field_validator("tabular_layout_router_model")
    @classmethod
    def _validate_tabular_layout_router_model(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("tabular_layout_router_enabled", False) and not normalized:
            raise ValueError(
                "TABULAR_LAYOUT_ROUTER_MODEL is required when the router is enabled"
            )
        return normalized

    @field_validator("document_router_required")
    @classmethod
    def _validate_document_router_required(
        cls,
        value: bool,
        info: ValidationInfo,
    ) -> bool:
        if value and not info.data.get("document_router_enabled", False):
            raise ValueError(
                "DOCUMENT_ROUTER_REQUIRED requires DOCUMENT_ROUTER_ENABLED"
            )
        return value

    @field_validator("document_router_base_url")
    @classmethod
    def _validate_document_router_base_url(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("document_router_enabled", False) and not normalized:
            raise ValueError(
                "DOCUMENT_ROUTER_BASE_URL is required when the router is enabled"
            )
        return normalized

    @field_validator("document_router_api_key")
    @classmethod
    def _validate_document_router_api_key(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        if info.data.get("document_router_enabled", False) and not value.strip():
            raise ValueError(
                "DOCUMENT_ROUTER_API_KEY is required when the router is enabled"
            )
        return value

    @field_validator("document_router_model")
    @classmethod
    def _validate_document_router_model(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("document_router_enabled", False) and not normalized:
            raise ValueError(
                "DOCUMENT_ROUTER_MODEL is required when the router is enabled"
            )
        return normalized

    @field_validator("document_router_model_min_score")
    @classmethod
    def _validate_document_router_score_order(
        cls,
        value: float,
        info: ValidationInfo,
    ) -> float:
        auto_min_score = float(info.data["document_router_auto_min_score"])
        if value > auto_min_score:
            raise ValueError(
                "DOCUMENT_ROUTER_MODEL_MIN_SCORE must not exceed "
                "DOCUMENT_ROUTER_AUTO_MIN_SCORE"
            )
        return value

    @field_validator("entity_router_required")
    @classmethod
    def _validate_entity_router_required(
        cls,
        value: bool,
        info: ValidationInfo,
    ) -> bool:
        if value and not info.data.get("entity_router_enabled", False):
            raise ValueError("ENTITY_ROUTER_REQUIRED requires ENTITY_ROUTER_ENABLED")
        return value

    @field_validator("entity_router_base_url")
    @classmethod
    def _validate_entity_router_base_url(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("entity_router_enabled", False) and not normalized:
            raise ValueError(
                "ENTITY_ROUTER_BASE_URL is required when the router is enabled"
            )
        return normalized

    @field_validator("entity_router_api_key")
    @classmethod
    def _validate_entity_router_api_key(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        if info.data.get("entity_router_enabled", False) and not value.strip():
            raise ValueError(
                "ENTITY_ROUTER_API_KEY is required when the router is enabled"
            )
        return value

    @field_validator("entity_router_model")
    @classmethod
    def _validate_entity_router_model(
        cls,
        value: str,
        info: ValidationInfo,
    ) -> str:
        normalized = value.strip()
        if info.data.get("entity_router_enabled", False) and not normalized:
            raise ValueError(
                "ENTITY_ROUTER_MODEL is required when the router is enabled"
            )
        return normalized

    @model_validator(mode="after")
    def _validate_extension_router_configuration(self) -> "Settings":
        for prefix in (
            "field_semantic_router",
            "visual_region_router",
            "region_capability_router",
            "content_region_router",
        ):
            enabled = bool(getattr(self, f"{prefix}_enabled"))
            required = bool(getattr(self, f"{prefix}_required"))
            if required and not enabled:
                variable = prefix.upper()
                raise ValueError(f"{variable}_REQUIRED requires {variable}_ENABLED")
            if not enabled:
                continue
            missing = [
                suffix.upper()
                for suffix in ("base_url", "api_key", "model")
                if not str(getattr(self, f"{prefix}_{suffix}") or "").strip()
            ]
            if missing:
                variable = prefix.upper()
                names = ", ".join(f"{variable}_{suffix}" for suffix in missing)
                raise ValueError(f"missing enabled router configuration: {names}")
        return self

    # ===== 数据库 =====
    database_url: str = "sqlite+aiosqlite:///./data/m1.db"
    # Standalone development may migrate on startup. Production Compose fixes
    # this to false and runs the dedicated m1-task-store-migrate one-shot first.
    task_store_migrate_on_startup: bool = True

    # ===== Wiki / Graph 基础知识库 =====
    # 默认启用并复用 M1 数据库；生产 Compose 可将其切到独立 Postgres。
    knowledge_enabled: bool = True
    # Production owns DDL through the one-shot m1-knowledge-migrate service.
    # Tests and standalone local runtimes may opt in explicitly.
    knowledge_migrate_on_startup: bool = False
    knowledge_required: bool = False
    knowledge_database_url: str = ""
    knowledge_default_tenant_id: str = "default"
    knowledge_default_tenant_name: str = "Default tenant"
    knowledge_auto_project: bool = True
    knowledge_search_candidates: bool = False
    knowledge_embeddings_enabled: bool = True
    # Dedicated embedding transport.  Unset values preserve the historical
    # VLM endpoint fallback; an explicitly empty API key supports local TEI or
    # vLLM-compatible services that do not require authentication.
    knowledge_embedding_base_url: str | None = None
    knowledge_embedding_api_key: str | None = Field(default=None, repr=False)
    knowledge_embedding_model: str = "BAAI/bge-m3"
    knowledge_embedding_dimensions: int = 1024
    knowledge_embedding_batch_size: int = 16
    graph_backend: str = "memory"  # memory | neo4j
    neo4j_uri: str = "bolt://neo4j:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = Field(default="", repr=False)
    neo4j_database: str = "neo4j"

    @property
    def resolved_knowledge_database_url(self) -> str:
        return self.knowledge_database_url.strip() or self.database_url

    @property
    def resolved_tabular_layout_router_base_url(self) -> str:
        return self.tabular_layout_router_base_url.strip()

    @property
    def resolved_tabular_layout_router_api_key(self) -> str:
        return self.tabular_layout_router_api_key

    @property
    def resolved_tabular_layout_router_model(self) -> str:
        return self.tabular_layout_router_model.strip()

    @property
    def resolved_field_semantic_router_base_url(self) -> str:
        return self.field_semantic_router_base_url.strip()

    @property
    def resolved_field_semantic_router_api_key(self) -> str:
        return self.field_semantic_router_api_key

    @property
    def resolved_field_semantic_router_model(self) -> str:
        return self.field_semantic_router_model.strip()

    @property
    def resolved_visual_region_router_base_url(self) -> str:
        return self.visual_region_router_base_url.strip()

    @property
    def resolved_visual_region_router_api_key(self) -> str:
        return self.visual_region_router_api_key

    @property
    def resolved_visual_region_router_model(self) -> str:
        return self.visual_region_router_model.strip()

    @property
    def resolved_region_capability_router_base_url(self) -> str:
        return self.region_capability_router_base_url.strip()

    @property
    def resolved_region_capability_router_api_key(self) -> str:
        return self.region_capability_router_api_key

    @property
    def resolved_region_capability_router_model(self) -> str:
        return self.region_capability_router_model.strip()

    @property
    def resolved_content_region_router_base_url(self) -> str:
        return self.content_region_router_base_url.strip()

    @property
    def resolved_content_region_router_api_key(self) -> str:
        return self.content_region_router_api_key

    @property
    def resolved_content_region_router_model(self) -> str:
        return self.content_region_router_model.strip()

    @property
    def resolved_knowledge_embedding_base_url(self) -> str:
        if self.knowledge_embedding_base_url is None:
            return self.vlm_base_url
        return self.knowledge_embedding_base_url

    @property
    def resolved_knowledge_embedding_api_key(self) -> str:
        if self.knowledge_embedding_api_key is None:
            return self.vlm_api_key
        return self.knowledge_embedding_api_key

    # ===== 置信度 =====
    confidence_threshold: float = 0.9

    # Optional shell-free argv template. Supported placeholders are {input},
    # {output}, {input_dir}, and {output_dir}; empty auto-discovers dwgread.
    dwg_converter_command: str = ""
    dwg_converter_timeout_seconds: float = 120.0

    # ===== Unified document parser plugins =====
    # Keep the current deterministic path as the zero-surprise default.  A
    # structured backend is only required for readiness in shadow/structured
    # mode, and production never downloads model files during startup.
    document_parser_mode: Literal["legacy", "shadow", "structured"] = "legacy"
    pp_structure_enabled: bool = False
    pp_structure_device: str = "cpu"
    pp_structure_model_root: str = "./data/paddlex"
    pp_structure_timeout_seconds: float = 120.0
    paddleocr_vl_enabled: bool = False
    paddleocr_vl_model_root: str = "./data/paddlex"
    paddleocr_vl_timeout_seconds: float = 180.0
    docling_enabled: bool = False
    parser_runtime_downloads: bool = False

    # ===== MinerU + LLM parsing =====
    # MinerU + Instructor is the only document authority. The historical
    # ``shadow`` setting names remain for artifact/state compatibility.
    mineru_shadow_enabled: bool = False
    mineru_shadow_required: bool = False
    mineru_base_url: str = "http://m1-mineru:8000"
    mineru_backend: Literal["vlm-engine"] = "vlm-engine"
    mineru_effort: Literal["medium", "high"] = "high"
    mineru_language: str = "ch"
    mineru_image_analysis: bool = True
    mineru_timeout_seconds: float = 240.0
    mineru_poll_interval_seconds: float = 1.0
    mineru_max_pages: int = 200
    mineru_max_archive_bytes: int = 64 * 1024 * 1024
    mineru_max_uncompressed_bytes: int = 128 * 1024 * 1024
    mineru_max_concurrency: int = 1
    mineru_shadow_max_pending: int = 32
    mineru_shadow_artifact_retention_seconds: int = 7 * 24 * 60 * 60
    mineru_shadow_artifact_max_bytes: int = 256 * 1024 * 1024
    mineru_document_circuit_failures: int = 3
    mineru_document_circuit_seconds: float = 300.0
    mineru_version: str = "3.4.4"
    mineru_model_revision: str = "bff20d4ae2bf202df9f45284b4d43681555a97ed"
    mineru_shadow_output_dir: str = "./data/mineru-shadow"
    # This is an independent consumer contract even when production points it
    # at the shared Qwen35B endpoint. Never inherit another module's credential.
    mineru_mapper_base_url: str = ""
    mineru_mapper_api_key: str = Field(default="", repr=False)
    mineru_mapper_model: str = ""
    mineru_mapper_timeout_seconds: float = 60.0
    mineru_mapper_max_tokens: int = 4096
    mineru_mapper_max_input_chars: int = 24_000
    # Full authority uses Instructor over the same dedicated text-model
    # endpoint. The legacy mapper limits remain available for shadow rollback.
    mineru_instructor_max_input_chars: int = 80_000
    mineru_instructor_segment_max_input_chars: int = 80_000
    mineru_instructor_max_retries: int = 2
    mineru_visual_assets_enabled: bool = True
    mineru_visual_assets_max: int = 8
    mineru_visual_asset_max_bytes: int = 10 * 1024 * 1024
    mineru_visual_asset_timeout_seconds: float = 180.0
    mineru_drawing_region_vlm_enabled: bool = True
    mineru_drawing_region_vlm_base_url: str = ""
    mineru_drawing_region_vlm_api_key: str = Field(default="", repr=False)
    mineru_drawing_region_vlm_model: str = ""
    mineru_drawing_region_vlm_max_regions: int = 16
    mineru_drawing_region_vlm_request_timeout_seconds: float = 30.0
    mineru_drawing_region_vlm_asset_timeout_seconds: float = 180.0
    mineru_full_timeout_seconds: float = 600.0

    @property
    def mineru_authority_mode(self) -> Literal["full"]:
        """The legacy runner name is retained, but its authority is immutable."""

        return "full"

    @model_validator(mode="after")
    def _validate_mineru_visual_runtime(self) -> "Settings":
        if self.mineru_shadow_required and not self.mineru_shadow_enabled:
            raise ValueError("MINERU_SHADOW_REQUIRED requires MINERU_SHADOW_ENABLED")
        if self.mineru_document_circuit_failures < 1:
            raise ValueError("MINERU_DOCUMENT_CIRCUIT_FAILURES must be positive")
        if self.mineru_document_circuit_seconds <= 0:
            raise ValueError("MINERU_DOCUMENT_CIRCUIT_SECONDS must be positive")
        if self.mineru_shadow_enabled and self.mineru_drawing_region_vlm_enabled:
            if not self.mineru_visual_assets_enabled:
                raise ValueError(
                    "MINERU_DRAWING_REGION_VLM_ENABLED requires "
                    "MINERU_VISUAL_ASSETS_ENABLED"
                )
            if not self.mineru_drawing_region_vlm_base_url.strip():
                raise ValueError("MINERU_DRAWING_REGION_VLM_BASE_URL is required")
            if not self.mineru_drawing_region_vlm_model.strip():
                raise ValueError("MINERU_DRAWING_REGION_VLM_MODEL is required")
            if (
                self.mineru_drawing_region_vlm_asset_timeout_seconds
                < self.mineru_drawing_region_vlm_request_timeout_seconds
            ):
                raise ValueError(
                    "MINERU_DRAWING_REGION_VLM_ASSET_TIMEOUT_SECONDS must be "
                    "greater than or equal to the request timeout"
                )
        return self

    # LightRAG is a non-authoritative, disabled-by-default shadow index.  Its
    # credentials and storage are intentionally separate from governed M1 data.
    lightrag_shadow_enabled: bool = False
    lightrag_base_url: str = "http://m1-lightrag:9621"
    lightrag_api_key: str = Field(default="", repr=False)
    lightrag_workspace: str = "m1-shadow"
    lightrag_timeout_seconds: float = 30.0

    # Durable projection delivery runs continuously in production.  Leases in
    # the outbox make this safe if multiple API processes are ever started.
    knowledge_outbox_worker_enabled: bool = True
    knowledge_outbox_interval_seconds: float = 5.0
    knowledge_outbox_batch_size: int = 200
    knowledge_outbox_max_attempts: int = 10
    knowledge_outbox_protect_fresh_seconds: float = 0.0
    # Optional bootstrap tenants for outbox draining. TaskStore also discovers
    # tenants durably from saved tasks, so this list is only needed before a
    # tenant's first task or when recovering external knowledge-only events.
    knowledge_outbox_tenant_ids: str = ""
    knowledge_search_default_min_score: float = 0.30
    knowledge_search_max_hits_per_source: int = 2

    @field_validator("knowledge_outbox_tenant_ids", mode="before")
    @classmethod
    def _normalize_knowledge_outbox_tenant_ids(cls, value: object) -> str:
        if value is None:
            return ""
        if isinstance(value, str):
            candidates = value.split(",")
        elif isinstance(value, (list, tuple)):
            candidates = list(value)
        else:
            raise ValueError(  # noqa: TRY004
                "KNOWLEDGE_OUTBOX_TENANT_IDS must be comma-separated"
            )

        normalized: list[str] = []
        seen: set[str] = set()
        for candidate in candidates:
            tenant_id = str(candidate).strip().casefold()
            if not tenant_id:
                continue
            if not _TENANT_ID_RE.fullmatch(tenant_id):
                raise ValueError(
                    "KNOWLEDGE_OUTBOX_TENANT_IDS entries must start with a "
                    "letter or digit, contain only letters, digits, dots, "
                    "underscores or hyphens, and be at most 64 characters"
                )
            if tenant_id not in seen:
                seen.add(tenant_id)
                normalized.append(tenant_id)
        return ",".join(normalized)

    @property
    def knowledge_outbox_tenant_ids_list(self) -> list[str]:
        """Return validated explicit worker tenants in declared order."""

        return [
            tenant_id
            for tenant_id in self.knowledge_outbox_tenant_ids.split(",")
            if tenant_id
        ]

    # Explicit enhanced-capability inference is intentionally separate from
    # ordinary liveness/readiness.  Production must inject a random key before
    # POST /enhanced/preflight can run expensive model probes or the isolated
    # LightRAG lifecycle check.
    enhanced_preflight_api_key: str = Field(default="", repr=False)

    # ===== 鉴权 / CORS =====
    # api_auth_key 为空 → 不启用鉴权 (开发态默认)
    # 非空 → 所有受保护端点需带 X-API-Key: <key> (/health 例外)
    api_auth_key: str = ""
    # Production multi-tenant authentication. JSON maps SHA-256(API key) to
    # {tenant_id, actor_id, roles}; plaintext customer keys are never stored.
    # When configured it takes precedence over the legacy global API key and
    # client-supplied tenant/role headers cannot change the bound identity.
    tenant_api_key_hashes: str = Field(default="", repr=False)
    # CORS 白名单; 默认只放行 Vite 开发来源
    # 环境变量 CORS_ORIGINS 用逗号分隔, 如 "http://a.com,http://b.com"
    # 用 str 存储 (避免 pydantic-settings 解析 List 的坑), 通过 cors_origins_list 属性拆分
    # 生产同源无需 CORS
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    @property
    def cors_origins_list(self) -> list[str]:
        """逗号分隔的 cors_origins → list (供 CORSMiddleware 使用)。"""
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    # ===== 服务 =====
    api_port: int = 8080
    upload_dir: str = "./data/uploads"

    @property
    def upload_path(self) -> Path:
        p = Path(self.upload_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    # ===== 批量上传 / 压缩包 =====
    # 并发处理子任务的最大数 (VLM IO-bound, 限流避免打满 API 并发额度)
    max_concurrent: int = 5
    # 单个压缩包最大字节数 (防 OOM)
    max_archive_size: int = 512 * 1024 * 1024
    # 解压后总大小上限 (防 zip bomb)
    max_total_uncompressed: int = 512 * 1024 * 1024
    max_single_uncompressed: int = 100 * 1024 * 1024
    max_archive_entries: int = 5000
    max_archive_recursion: int = 2
    max_compression_ratio: float = 100.0
    # 允许解压的文件扩展名白名单 (压缩包内文件; 支持的文档/图片/CAD/表格格式)
    allowed_extensions: list[str] = [
        # 图片
        "jpg",
        "jpeg",
        "png",
        "bmp",
        "tiff",
        "tif",
        "gif",
        "webp",
        # 文档
        "pdf",
        "docx",
        "pptx",
        "html",
        "htm",
        # CAD
        "dxf",
        "dwg",
        # 表格
        "csv",
        "xls",
        "xlsx",
        "xlsm",
        # 压缩包 (嵌套)
        "zip",
        "tar",
        "gz",
        "tgz",
        "7z",
        "rar",
    ]


settings = Settings()
