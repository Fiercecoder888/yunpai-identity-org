"""Dependency container for the full-authority M1 workflow.

便于:
  - 单元测试时替换为 mock
  - 生产/测试环境切换不同实现 (如云端 API vs 本地 vLLM)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .extractors.vlm_agent import VLMExtractor
from .parsers.router import ParserRouter


@dataclass
class WorkflowDeps:
    """Runtime dependencies shared by the API and workflow coordinator."""

    parser_router: ParserRouter
    vlm_agent: VLMExtractor
    # 置信度阈值 (从 settings 注入)
    confidence_threshold: float = 0.9
    # Unified PDF/Office parser service. Optional keeps existing test fixtures
    # and parser-backend probes compatible.
    document_parser: Any | None = None
    # MinerU + Instructor full-authority runner. The historical attribute name
    # remains internal compatibility for persisted candidate/report metadata.
    mineru_shadow_runner: Any | None = None
    # Optional governed route-profile runtime. It is constructed only when the
    # dedicated feature flag is enabled and never owns parser business facts.
    document_routing_runtime: Any | None = None
    # Source-only structural probe deadline. It is intentionally separate from
    # the document-router model request deadline.
    document_router_probe_timeout_seconds: float = 10.0
    # Optional classification-only facade over the same governed profiles. It
    # may fill unknown taxonomy fields but cannot choose code or mutate facts.
    document_classification_runtime: Any | None = None
    # Optional governed field-semantic runtime. It can only select a canonical
    # field from the code-owned registry and preserves unknown values losslessly.
    field_semantic_routing_runtime: Any | None = None
    # Optional governed visual-region runtime. Deterministic geometry runs
    # first; this dependency can only resolve images left explicitly unresolved.
    visual_region_routing_runtime: Any | None = None
    # Optional governed page-capability runtime. The parser sees only value-free
    # probes and may execute only code-owned capabilities.
    region_capability_routing_runtime: Any | None = None
    # Optional governed semantic-region runtime. Active reviewed profiles select
    # only code-owned roles and strategies; novel routes remain candidates.
    content_region_routing_runtime: Any | None = None


# 全局单例 (进程启动时初始化一次)
_deps: WorkflowDeps | None = None


def get_deps() -> WorkflowDeps:
    """获取已初始化的依赖容器。需先调用 init_deps()。"""
    if _deps is None:
        raise RuntimeError("WorkflowDeps 未初始化, 请先调用 init_deps()")
    return _deps


def init_deps(deps: WorkflowDeps) -> None:
    """注入依赖 (测试时可传入 mock 实现)。"""
    global _deps
    _deps = deps
