"""Container-local operations CLI for governed document route profiles."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence

from .core.config import settings
from .documents.parsing.document_routing_runtime import DocumentRoutingRuntime
from .knowledge.persistence import KnowledgeStore
from .state import TaskStatus
from .workflow.persistence import TaskStore


def _nonempty(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must not be empty")
    return normalized


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.document_routes",
        description="Operate governed document route profiles inside the M1 container.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    approve = commands.add_parser(
        "approve",
        help="Activate a reviewed candidate route that meets its sample threshold.",
    )
    approve.add_argument("--tenant-id", required=True, type=_nonempty)
    approve.add_argument("--profile-id", required=True, type=_nonempty)
    approve.add_argument("--approved-by", required=True, type=_nonempty)
    approve.add_argument("--reviewed-by", required=True, type=_nonempty)
    approve.add_argument("--review-note", required=True, type=_nonempty)
    validate = commands.add_parser(
        "validate",
        help="Record an explicit review of one candidate route against a final task.",
    )
    validate.add_argument("--tenant-id", required=True, type=_nonempty)
    validate.add_argument("--profile-id", required=True, type=_nonempty)
    validate.add_argument("--task-id", required=True, type=_nonempty)
    validate.add_argument(
        "--decision", required=True, choices=("approve", "reject")
    )
    validate.add_argument("--reviewed-by", required=True, type=_nonempty)
    validate.add_argument("--review-note", required=True, type=_nonempty)
    return parser


async def _approve(args: argparse.Namespace) -> dict[str, object]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    runtime: DocumentRoutingRuntime | None = None
    try:
        await store.init()
        runtime = DocumentRoutingRuntime(
            store=store,
            embedding_provider=None,
            mode=settings.document_router_mode,
            min_activation_samples=settings.document_router_min_activation_samples,
        )
        profile = await runtime.approve_candidate(
            tenant_id=args.tenant_id,
            profile_id=args.profile_id,
            review_approved=True,
            approved_by=args.approved_by,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": "m1.document-route-operation.v1",
            "operation": "approve",
            "tenant_id": profile.tenant_id,
            "profile_id": profile.profile_id,
            "profile_key": profile.profile_key,
            "version": profile.version,
            "status": str(profile.status),
            "approved_by": profile.approved_by,
            "reviewed_by": profile.reviewed_by,
        }
    finally:
        if runtime is not None:
            await runtime.close()
        await store.close()


async def _validate(args: argparse.Namespace) -> dict[str, object]:
    route_store = KnowledgeStore(settings.resolved_knowledge_database_url)
    task_store = TaskStore(settings.database_url)
    runtime: DocumentRoutingRuntime | None = None
    try:
        await route_store.init()
        state = await task_store.load(args.task_id)
        if state is None:
            raise LookupError("route validation task not found")
        if str(state.tenant_id).strip() != args.tenant_id:
            raise ValueError("route validation task belongs to another tenant")
        if not isinstance(state.document, dict):
            raise TypeError("route validation task has no final document")
        if state.status is not TaskStatus.DONE:
            raise ValueError("route validation requires a completed task")
        if state.knowledge_sync_status != "synced" or not state.knowledge_version_id:
            raise ValueError("route validation requires a synced knowledge version")
        runtime = DocumentRoutingRuntime(
            store=route_store,
            embedding_provider=None,
            mode=settings.document_router_mode,
            min_activation_samples=settings.document_router_min_activation_samples,
        )
        observation = await runtime.record_candidate_validation(
            tenant_id=args.tenant_id,
            task_id=args.task_id,
            profile_id=args.profile_id,
            document=state.document,
            knowledge_version_id=state.knowledge_version_id,
            decision=args.decision,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": "m1.document-route-operation.v1",
            "operation": "validate",
            "tenant_id": observation.tenant_id,
            "profile_id": observation.profile_id,
            "task_ref": observation.details.get("task_ref"),
            "outcome": str(observation.outcome),
            "error_code": observation.error_code,
            "policy_digest": observation.details.get("policy_digest"),
            "document_digest": observation.details.get("document_digest"),
            "knowledge_version_id": observation.details.get("knowledge_version_id"),
            "validator_version": observation.details.get("validator_version"),
            "reviewed_by": observation.details.get("reviewed_by"),
            "check_codes": observation.details.get("check_codes", []),
        }
    finally:
        if runtime is not None:
            await runtime.close()
        await task_store.close()
        await route_store.close()


async def _run(args: argparse.Namespace) -> dict[str, object]:
    if args.command == "approve":
        return await _approve(args)
    if args.command == "validate":
        return await _validate(args)
    raise ValueError(f"unsupported route operation: {args.command}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = asyncio.run(_run(args))
    except Exception as exc:  # noqa: BLE001 - CLI returns a bounded operator error
        print(
            json.dumps(
                {
                    "schema_version": "m1.document-route-operation.v1",
                    "operation": str(getattr(args, "command", "unknown")),
                    "status": "failed",
                    "error_type": exc.__class__.__name__,
                },
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised through main()
    raise SystemExit(main())


__all__ = ["main"]
