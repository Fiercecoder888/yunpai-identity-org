"""Public m1.document.v2 parsing API."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

from .adapters import (
    ArchiveDocumentAdapter,
    ArchiveLimits,
    DOCXDocumentAdapter,
    PDFDocumentAdapter,
    extract_archive,
    parse_archive_document,
    parse_docx_document,
    parse_pdf_document,
)
from .envelope import DocumentAdapter, DocumentEnvelope
from .image_roles import ImageRoleAssessment
from .magic import FileTypeInfo, sniff_file_type
from .models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    DocumentTotals,
    FieldMetadata,
    IdentifierCandidate,
    NameAttributes,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from .orders import (
    _build_order_document_with_image_roles,
    build_order_document,
    enrich_order_line,
    find_table_regions,
)
from .spreadsheets import (
    CsvDocumentAdapter,
    SpreadsheetDependencyError,
    UnsupportedSpreadsheetError,
    XlsDocumentAdapter,
    XlsxDocumentAdapter,
    parse_spreadsheet_envelope,
)
from .tabular import build_tabular_document, find_tabular_regions, infer_tabular_subtype


def parse_spreadsheet_document(
    path: str | Path,
    original_filename: str | None = None,
    subtype_hint: str | None = None,
) -> DocumentRecord:
    """Synchronously parse spreadsheet facts into the v2 document contract."""

    envelope = parse_spreadsheet_envelope(path, original_filename=original_filename)
    return build_spreadsheet_document(envelope, subtype_hint=subtype_hint)


def build_spreadsheet_document(
    envelope: DocumentEnvelope,
    subtype_hint: str | None = None,
) -> DocumentRecord:
    """Build a record from an already decoded spreadsheet envelope."""

    return build_spreadsheet_document_with_image_roles(envelope, subtype_hint)


def build_spreadsheet_document_with_image_roles(
    envelope: DocumentEnvelope,
    subtype_hint: str | None = None,
    *,
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> DocumentRecord:
    """Internal rebuild entrypoint for governed visual-role overrides.

    The asynchronous workflow uses this split so a bounded schema interpreter
    can inspect the same lossless cell envelope without reading the file twice.
    The public synchronous parser remains unchanged for existing callers.
    """

    tabular_subtype = infer_tabular_subtype(envelope, subtype_hint)
    if tabular_subtype:
        return build_tabular_document(envelope, tabular_subtype)
    return _build_order_document_with_image_roles(
        envelope,
        subtype_hint=subtype_hint,
        image_role_overrides=image_role_overrides,
    )


__all__ = [
    "ArchiveDocumentAdapter",
    "ArchiveLimits",
    "CsvDocumentAdapter",
    "DOCXDocumentAdapter",
    "DocumentAdapter",
    "DocumentEnvelope",
    "DocumentHeader",
    "DocumentRecord",
    "DocumentSource",
    "DocumentTotals",
    "FieldMetadata",
    "FileTypeInfo",
    "IdentifierCandidate",
    "NameAttributes",
    "OrderLine",
    "PDFDocumentAdapter",
    "SourceReference",
    "SpreadsheetDependencyError",
    "UnsupportedSpreadsheetError",
    "ValidationIssue",
    "XlsDocumentAdapter",
    "XlsxDocumentAdapter",
    "build_order_document",
    "build_spreadsheet_document",
    "build_tabular_document",
    "enrich_order_line",
    "extract_archive",
    "find_table_regions",
    "find_tabular_regions",
    "infer_tabular_subtype",
    "parse_archive_document",
    "parse_docx_document",
    "parse_pdf_document",
    "parse_spreadsheet_document",
    "parse_spreadsheet_envelope",
    "sniff_file_type",
]
