"""Production deterministic document adapters."""

from .archive import (
    ArchiveDocumentAdapter,
    ArchiveLimits,
    extract_archive,
    parse_archive_document,
)
from .docx import DOCXDocumentAdapter, parse_docx_document
from .pdf import PDFDocumentAdapter, parse_pdf_document

__all__ = [
    "ArchiveDocumentAdapter",
    "ArchiveLimits",
    "DOCXDocumentAdapter",
    "PDFDocumentAdapter",
    "extract_archive",
    "parse_archive_document",
    "parse_docx_document",
    "parse_pdf_document",
]
