"""Secure recursive archive extraction for production document ingestion.

ZIP and TAR use the Python standard library.  RAR and 7Z support is deliberately
optional and reports a dependency/decoder error instead of pretending an unknown
binary is a document.  All archive formats share one recursion budget.
"""

from __future__ import annotations

import hashlib
import posixpath
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile
import unicodedata
import zipfile
from collections.abc import Callable, Iterable
from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, BinaryIO

from ..ooxml import (
    OOXMLPackageError,
    OOXMLPackageLimits,
    preflight_ooxml_package,
)
from .common import build_document_record, file_sha256, source_payload

MIB = 1024 * 1024


class ArchiveAdapterError(RuntimeError):
    """Base class for archive format, decoder and safety failures."""


class UnsupportedArchiveError(ArchiveAdapterError):
    """The input does not have the magic bytes of a supported archive."""


class ArchiveDependencyError(ArchiveAdapterError):
    """An optional, fixed archive decoder is not installed/available."""


class UnsafeArchiveError(ArchiveAdapterError):
    """An archive entry attempts traversal, links or another unsafe operation."""


class ArchiveLimitError(ArchiveAdapterError):
    """An archive exceeds a configured resource budget."""


@dataclass(frozen=True, slots=True)
class ArchiveLimits:
    max_archive_size: int = 512 * MIB
    max_total_uncompressed: int = 512 * MIB
    max_single_file: int = 100 * MIB
    max_entries: int = 5000
    max_compression_ratio: float = 100.0
    max_recursion_depth: int = 2
    chunk_size: int = 1024 * 1024

    def __post_init__(self) -> None:
        for name in (
            "max_archive_size",
            "max_total_uncompressed",
            "max_single_file",
            "max_entries",
            "chunk_size",
        ):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        if self.max_compression_ratio <= 0:
            raise ValueError("max_compression_ratio must be positive")
        if self.max_recursion_depth < 0:
            raise ValueError("max_recursion_depth cannot be negative")


@dataclass(slots=True)
class ArchiveEntry:
    archive_path: str
    raw_name: str
    display_name: str
    stored_relative_path: str | None
    size: int
    compressed_size: int | None
    sha256: str | None = None
    duplicate_of: str | None = None
    ignored: bool = False
    ignore_reason: str | None = None
    nested_archive: bool = False
    depth: int = 0


@dataclass(slots=True)
class ArchiveExtractionResult:
    archive_path: Path
    destination: Path
    archive_type: str
    entries: list[ArchiveEntry] = field(default_factory=list)
    leaf_files: list[Path] = field(default_factory=list)
    total_uncompressed: int = 0
    total_entries: int = 0
    duplicate_count: int = 0
    ignored_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "archive_path": str(self.archive_path),
            "destination": str(self.destination),
            "archive_type": self.archive_type,
            "entries": [asdict(entry) for entry in self.entries],
            "leaf_files": [str(path) for path in self.leaf_files],
            "total_uncompressed": self.total_uncompressed,
            "total_entries": self.total_entries,
            "duplicate_count": self.duplicate_count,
            "ignored_count": self.ignored_count,
        }


@dataclass(slots=True)
class _Budget:
    limits: ArchiveLimits
    total_uncompressed: int = 0
    total_entries: int = 0
    hashes: dict[str, Path] = field(default_factory=dict)

    def add_entry(self) -> None:
        self.total_entries += 1
        if self.total_entries > self.limits.max_entries:
            raise ArchiveLimitError(
                f"Archive entry count exceeds {self.limits.max_entries}"
            )

    def reserve_file(self, size: int, compressed_size: int | None, name: str) -> None:
        if size < 0:
            raise ArchiveLimitError(f"Archive member has a negative size: {name}")
        if size > self.limits.max_single_file:
            raise ArchiveLimitError(
                f"Archive member exceeds the {self.limits.max_single_file} byte "
                f"single-file limit: {name} ({size})"
            )
        if compressed_size is not None:
            if size and compressed_size <= 0:
                raise ArchiveLimitError(f"Invalid compressed size for member: {name}")
            if compressed_size and size / compressed_size > self.limits.max_compression_ratio:
                raise ArchiveLimitError(
                    f"Archive member exceeds {self.limits.max_compression_ratio:g}:1 "
                    f"compression ratio: {name}"
                )
        self.total_uncompressed += size
        if self.total_uncompressed > self.limits.max_total_uncompressed:
            raise ArchiveLimitError(
                "Archive uncompressed total exceeds "
                f"{self.limits.max_total_uncompressed} bytes"
            )


_ARCHIVE_SUFFIXES = (
    ".zip",
    ".tar",
    ".tar.gz",
    ".tgz",
    ".tar.bz2",
    ".tbz2",
    ".tar.xz",
    ".txz",
    ".rar",
    ".7z",
)
_MOJIBAKE_MARKERS = (
    "锟斤拷",
    "Ã",
    "Â",
    "â€",
    "鈥",
    "銆",
    "锛",
    "妗",
    "鎴",
    "鏂",
    "浠",
    "缁",
    "璁",
    "鐨",
    "涓",
    "澶",
    "鏃",
    "绔",
)
_WINDOWS_INVALID = re.compile(r'[<>:"|?*\x00-\x1f]')
_WINDOWS_RESERVED = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def detect_archive_type(path: str | Path) -> str:
    """Detect archives by magic bytes, never by extension alone."""

    archive_path = Path(path)
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)
    with archive_path.open("rb") as stream:
        magic = stream.read(8)
    if magic.startswith((b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")):
        return "zip"
    if magic.startswith((b"Rar!\x1a\x07\x00", b"Rar!\x1a\x07\x01\x00")):
        return "rar"
    if magic.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7z"
    try:
        if tarfile.is_tarfile(archive_path):
            return "tar"
    except (OSError, tarfile.TarError):
        pass
    raise UnsupportedArchiveError(
        f"Unsupported archive magic for {archive_path.name}; suffix is not trusted"
    )


def is_archive(path: str | Path) -> bool:
    try:
        detect_archive_type(path)
        return True
    except (FileNotFoundError, UnsupportedArchiveError, OSError):
        return False


def looks_like_archive_name(name: str) -> bool:
    return name.casefold().endswith(_ARCHIVE_SUFFIXES)


def _is_ooxml_document(path: Path) -> bool:
    """Distinguish ZIP-based Office documents from recursive archives by content."""

    try:
        with zipfile.ZipFile(path, "r") as package:
            names = set(package.namelist())
    except (OSError, zipfile.BadZipFile):
        return False
    if "[Content_Types].xml" not in names:
        return False
    return any(
        required in names
        for required in ("word/document.xml", "xl/workbook.xml", "ppt/presentation.xml")
    )


def _filename_quality(value: str) -> float:
    score = 0.0
    for char in value:
        if char == "\ufffd" or unicodedata.category(char) == "Cc":
            score -= 20
        elif unicodedata.category(char).startswith("L"):
            score += 0.2
        if "\u2500" <= char <= "\u257f":
            score -= 5
    for marker in _MOJIBAKE_MARKERS:
        score -= value.count(marker) * 4
    return score


def repair_display_filename(raw_name: str) -> str:
    """Repair common reversible UTF-8/GB18030 filename mojibake.

    The original string is always retained in :class:`ArchiveEntry`; this function
    only supplies a display candidate.  A candidate is accepted when strict reverse
    transcoding recreates the input and its readability score materially improves.
    """

    candidates = {raw_name}
    for source_encoding, intended_encoding in (
        ("cp437", "gb18030"),
        ("latin1", "utf-8"),
        ("cp1252", "utf-8"),
        ("gb18030", "utf-8"),
    ):
        try:
            raw_bytes = raw_name.encode(source_encoding, errors="strict")
            candidate = raw_bytes.decode(intended_encoding, errors="strict")
            if candidate.encode(intended_encoding).decode(source_encoding) == raw_name:
                candidates.add(candidate)
        except (UnicodeEncodeError, UnicodeDecodeError, LookupError):
            continue
    original_score = _filename_quality(raw_name)
    best = max(candidates, key=lambda value: (_filename_quality(value), -len(value)))
    if _filename_quality(best) >= original_score + 1.0:
        return best
    return raw_name


def _safe_member_parts(raw_name: str) -> tuple[str, ...]:
    if "\x00" in raw_name:
        raise UnsafeArchiveError("Archive member contains a NUL byte")
    normalized = raw_name.replace("\\", "/")
    if normalized.startswith(("/", "//")) or re.match(r"^[A-Za-z]:", normalized):
        raise UnsafeArchiveError(f"Archive member uses an absolute path: {raw_name!r}")
    normalized = posixpath.normpath(normalized)
    parts = PurePosixPath(normalized).parts
    if not parts or normalized in {"", ".", ".."} or any(part == ".." for part in parts):
        raise UnsafeArchiveError(f"Archive member escapes the destination: {raw_name!r}")
    return tuple(part for part in parts if part not in {"", "."})


def _ignored(parts: tuple[str, ...]) -> str | None:
    if "__MACOSX" in parts:
        return "macos_metadata"
    basename = parts[-1]
    if basename == ".DS_Store" or basename.startswith("._"):
        return "appledouble"
    return None


def _storage_component(component: str) -> str:
    cleaned = _WINDOWS_INVALID.sub("_", component).rstrip(" .")
    if not cleaned:
        cleaned = "_"
    stem = cleaned.split(".", 1)[0].upper()
    if stem in _WINDOWS_RESERVED:
        cleaned = f"_{cleaned}"
    return cleaned


def _storage_parts(parts: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(_storage_component(repair_display_filename(part)) for part in parts)


def _safe_target(root: Path, parts: tuple[str, ...]) -> Path:
    target = root.joinpath(*parts)
    try:
        target.resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise UnsafeArchiveError(f"Archive target escapes destination: {target}") from exc
    return target


def _zip_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def _copy_stream(
    source: BinaryIO,
    target: Path,
    *,
    expected_size: int,
    limits: ArchiveLimits,
) -> tuple[int, str]:
    target.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256()
    written = 0
    with target.open("xb") as output:
        while True:
            chunk = source.read(limits.chunk_size)
            if not chunk:
                break
            written += len(chunk)
            if written > limits.max_single_file or written > expected_size:
                raise ArchiveLimitError(f"Archive member expanded beyond declared size: {target.name}")
            output.write(chunk)
            digest.update(chunk)
    if written != expected_size:
        target.unlink(missing_ok=True)
        raise ArchiveAdapterError(
            f"Archive member size mismatch for {target.name}: {written} != {expected_size}"
        )
    return written, digest.hexdigest()


def _unique_target(root: Path, storage_parts: tuple[str, ...], raw_name: str) -> Path:
    target = _safe_target(root, storage_parts)
    if not target.exists():
        return target
    suffix = hashlib.sha256(raw_name.encode("utf-8", errors="surrogatepass")).hexdigest()[:8]
    candidate = target.with_name(f"{target.stem}-{suffix}{target.suffix}")
    collision_index = 2
    while candidate.exists():
        candidate = target.with_name(
            f"{target.stem}-{suffix}-{collision_index}{target.suffix}"
        )
        collision_index += 1
    return candidate


def _entry_after_write(
    *,
    archive_label: str,
    raw_name: str,
    parts: tuple[str, ...],
    target: Path,
    stage_root: Path,
    size: int,
    compressed_size: int | None,
    digest: str,
    depth: int,
    budget: _Budget,
) -> ArchiveEntry:
    relative = target.relative_to(stage_root)
    duplicate = budget.hashes.get(digest)
    if duplicate is not None:
        target.unlink(missing_ok=True)
        return ArchiveEntry(
            archive_path=archive_label,
            raw_name=raw_name,
            display_name="/".join(repair_display_filename(part) for part in parts),
            stored_relative_path=None,
            size=size,
            compressed_size=compressed_size,
            sha256=digest,
            duplicate_of=duplicate.relative_to(stage_root).as_posix(),
            depth=depth,
        )
    budget.hashes[digest] = target
    return ArchiveEntry(
        archive_path=archive_label,
        raw_name=raw_name,
        display_name="/".join(repair_display_filename(part) for part in parts),
        stored_relative_path=relative.as_posix(),
        size=size,
        compressed_size=compressed_size,
        sha256=digest,
        depth=depth,
    )


def _preflight_common(
    *,
    raw_name: str,
    size: int,
    compressed_size: int | None,
    is_directory: bool,
    is_link: bool,
    budget: _Budget,
) -> tuple[tuple[str, ...], str | None]:
    budget.add_entry()
    parts = _safe_member_parts(raw_name)
    if is_link:
        raise UnsafeArchiveError(f"Links are forbidden in archives: {raw_name}")
    reason = _ignored(parts)
    if not is_directory:
        budget.reserve_file(size, compressed_size, raw_name)
    return parts, reason


def _extract_zip(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    try:
        package = zipfile.ZipFile(path, "r")
    except zipfile.BadZipFile as exc:
        raise ArchiveAdapterError(f"Corrupt ZIP archive: {archive_label}: {exc}") from exc
    entries: list[ArchiveEntry] = []
    try:
        prepared: list[tuple[zipfile.ZipInfo, tuple[str, ...], str | None]] = []
        for info in package.infolist():
            parts, reason = _preflight_common(
                raw_name=info.filename,
                size=int(info.file_size),
                compressed_size=int(info.compress_size),
                is_directory=info.is_dir(),
                is_link=_zip_is_symlink(info),
                budget=budget,
            )
            if info.flag_bits & 0x1:
                raise ArchiveAdapterError(f"Encrypted ZIP member is unsupported: {info.filename}")
            prepared.append((info, parts, reason))
        for info, parts, reason in prepared:
            if info.is_dir():
                continue
            if reason:
                entries.append(
                    ArchiveEntry(
                        archive_path=archive_label,
                        raw_name=info.filename,
                        display_name="/".join(repair_display_filename(p) for p in parts),
                        stored_relative_path=None,
                        size=int(info.file_size),
                        compressed_size=int(info.compress_size),
                        ignored=True,
                        ignore_reason=reason,
                        depth=depth,
                    )
                )
                continue
            target = _unique_target(root, _storage_parts(parts), info.filename)
            with package.open(info, "r") as source:
                _, digest = _copy_stream(
                    source,
                    target,
                    expected_size=int(info.file_size),
                    limits=budget.limits,
                )
            entries.append(
                _entry_after_write(
                    archive_label=archive_label,
                    raw_name=info.filename,
                    parts=parts,
                    target=target,
                    stage_root=stage_root,
                    size=int(info.file_size),
                    compressed_size=int(info.compress_size),
                    digest=digest,
                    depth=depth,
                    budget=budget,
                )
            )
    finally:
        package.close()
    return entries


def _extract_tar(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    try:
        package = tarfile.open(path, "r:*")  # noqa: SIM115 - closed in finally
    except tarfile.TarError as exc:
        raise ArchiveAdapterError(f"Corrupt TAR archive: {archive_label}: {exc}") from exc
    entries: list[ArchiveEntry] = []
    try:
        members = package.getmembers()
        file_total = sum(int(member.size) for member in members if member.isfile())
        compressed_archive_size = max(path.stat().st_size, 1)
        if file_total / compressed_archive_size > budget.limits.max_compression_ratio:
            raise ArchiveLimitError(
                f"TAR archive exceeds {budget.limits.max_compression_ratio:g}:1 compression ratio"
            )
        prepared: list[tuple[tarfile.TarInfo, tuple[str, ...], str | None]] = []
        for member in members:
            unsupported = not (member.isdir() or member.isfile())
            parts, reason = _preflight_common(
                raw_name=member.name,
                size=int(member.size),
                compressed_size=None,
                is_directory=member.isdir(),
                is_link=unsupported,
                budget=budget,
            )
            prepared.append((member, parts, reason))
        for member, parts, reason in prepared:
            if member.isdir():
                continue
            if reason:
                entries.append(
                    ArchiveEntry(
                        archive_path=archive_label,
                        raw_name=member.name,
                        display_name="/".join(repair_display_filename(p) for p in parts),
                        stored_relative_path=None,
                        size=int(member.size),
                        compressed_size=None,
                        ignored=True,
                        ignore_reason=reason,
                        depth=depth,
                    )
                )
                continue
            source = package.extractfile(member)
            if source is None:
                raise ArchiveAdapterError(f"Unable to read TAR member: {member.name}")
            target = _unique_target(root, _storage_parts(parts), member.name)
            with source:
                _, digest = _copy_stream(
                    source,
                    target,
                    expected_size=int(member.size),
                    limits=budget.limits,
                )
            entries.append(
                _entry_after_write(
                    archive_label=archive_label,
                    raw_name=member.name,
                    parts=parts,
                    target=target,
                    stage_root=stage_root,
                    size=int(member.size),
                    compressed_size=None,
                    digest=digest,
                    depth=depth,
                    budget=budget,
                )
            )
    finally:
        package.close()
    return entries


def _require_rarfile() -> Any:
    try:
        import rarfile  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ArchiveDependencyError(
            "RAR extraction requires the optional `rarfile` package and a fixed "
            "unrar/unar/bsdtar system decoder."
        ) from exc
    # ``rarfile`` searches for an executable literally named ``bsdtar``.  On
    # current Windows installations libarchive is shipped as ``tar.exe`` even
    # though ``tar --version`` identifies it as bsdtar.  Point rarfile at that
    # fixed system decoder after verifying its implementation; never accept an
    # arbitrary executable merely because it is named tar.
    windows_tar_alias = False
    if not shutil.which(str(rarfile.BSDTAR_TOOL)):
        tar_tool = shutil.which("tar")
        if tar_tool:
            try:
                probe = subprocess.run(
                    [tar_tool, "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError):
                probe = None
            version_text = "" if probe is None else f"{probe.stdout}\n{probe.stderr}"
            if probe is not None and probe.returncode == 0 and "bsdtar" in version_text.casefold():
                rarfile.BSDTAR_TOOL = tar_tool
                windows_tar_alias = Path(tar_tool).name.casefold() == "tar.exe"
    try:
        setup = rarfile.tool_setup()
    except Exception as exc:
        raise ArchiveDependencyError(
            "RAR support is installed, but no usable fixed unrar/unar/bsdtar decoder "
            "was found."
        ) from exc
    if windows_tar_alias and setup.setup is rarfile.BSDTAR_CONFIG:
        # rarfile's generic ToolSetup inserts ``--`` immediately after ``-f``.
        # Windows' bundled bsdtar therefore treats ``--`` as the archive name.
        # Keep the public decoder integration but correct that command ordering
        # for this verified system binary.
        class _WindowsBSDTarSetup(rarfile.ToolSetup):
            def open_cmdline(
                self, pwd: str | None, rarfn: str, filefn: str | None = None
            ) -> list[str]:
                command = [str(rarfile.BSDTAR_TOOL), "-x", "--to-stdout", "-f", rarfn]
                if filefn:
                    command.append(filefn.replace("\\", "/"))
                return command

        corrected_setup = _WindowsBSDTarSetup(rarfile.BSDTAR_CONFIG)
        if not corrected_setup.check():
            raise ArchiveDependencyError(
                "Windows tar.exe was identified as bsdtar but failed its decoder check."
            )
        rarfile.CURRENT_SETUP = corrected_setup
    return rarfile


def _require_py7zr() -> Any:
    try:
        import py7zr  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ArchiveDependencyError(
            "7Z extraction requires the optional `py7zr` package."
        ) from exc
    return py7zr


def _attribute_or_call(value: Any) -> Any:
    return value() if callable(value) else value


from .archive_optional import _Bounded7zWriter, _SevenZipWriterFactory
from .archive_optional import _extract_7z as _extract_7z_impl
from .archive_optional import _extract_rar as _extract_rar_impl


def _extract_rar(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    return _extract_rar_impl(path, root, stage_root, archive_label, depth, budget)


def _extract_7z(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    return _extract_7z_impl(path, root, stage_root, archive_label, depth, budget)


_EXTRACTORS: dict[
    str, Callable[[Path, Path, Path, str, int, _Budget], list[ArchiveEntry]]
] = {
    "zip": _extract_zip,
    "tar": _extract_tar,
    "rar": _extract_rar,
    "7z": _extract_7z,
}


def _extract_recursive(
    archive_path: Path,
    output_root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
    all_entries: list[ArchiveEntry],
    leaf_files: list[Path],
) -> str:
    if archive_path.stat().st_size > budget.limits.max_archive_size:
        raise ArchiveLimitError(
            f"Archive exceeds {budget.limits.max_archive_size} bytes: {archive_label}"
        )
    archive_type = detect_archive_type(archive_path)
    current_entries = _EXTRACTORS[archive_type](
        archive_path, output_root, stage_root, archive_label, depth, budget
    )
    all_entries.extend(current_entries)
    for entry in current_entries:
        if entry.ignored or entry.duplicate_of or not entry.stored_relative_path:
            continue
        extracted = stage_root / entry.stored_relative_path
        if _is_ooxml_document(extracted):
            try:
                package_stats = preflight_ooxml_package(
                    extracted,
                    limits=OOXMLPackageLimits(
                        max_package_size=budget.limits.max_single_file,
                        max_total_uncompressed=budget.limits.max_total_uncompressed,
                        max_part_size=budget.limits.max_single_file,
                        max_xml_part_size=min(100 * MIB, budget.limits.max_single_file),
                        max_entries=budget.limits.max_entries,
                        max_compression_ratio=budget.limits.max_compression_ratio,
                    ),
                )
            except OOXMLPackageError as exc:
                raise ArchiveLimitError(
                    f"Nested OOXML package exceeds archive limits: {entry.raw_name} ({exc})"
                ) from exc
            for member in package_stats.members:
                budget.add_entry()
                if not member.is_dir:
                    budget.reserve_file(
                        member.file_size,
                        member.compressed_size,
                        f"{entry.raw_name}!/{member.name}",
                    )
            leaf_files.append(extracted)
            continue
        nested_type: str | None = None
        try:
            nested_type = detect_archive_type(extracted)
        except UnsupportedArchiveError:
            if looks_like_archive_name(entry.raw_name):
                raise UnsupportedArchiveError(
                    f"Archive-looking member has unsupported magic: {entry.raw_name}"
                )
        if nested_type is None:
            leaf_files.append(extracted)
            continue
        entry.nested_archive = True
        if depth >= budget.limits.max_recursion_depth:
            raise ArchiveLimitError(
                f"Archive recursion exceeds depth {budget.limits.max_recursion_depth}: "
                f"{entry.raw_name}"
            )
        nested_root = extracted.parent / f"{extracted.stem}__contents"
        nested_root.mkdir(parents=True, exist_ok=True)
        budget_entries = budget.total_entries
        budget_uncompressed = budget.total_uncompressed
        budget_hashes = dict(budget.hashes)
        all_entries_count = len(all_entries)
        leaf_count = len(leaf_files)
        try:
            _extract_recursive(
                extracted,
                nested_root,
                stage_root,
                f"{archive_label}!/{entry.raw_name}",
                depth + 1,
                budget,
                all_entries,
                leaf_files,
            )
        except ArchiveAdapterError as exc:
            # Traversal, links and resource-budget violations remain atomic
            # failures for the complete upload. A corrupt or unavailable
            # optional nested decoder is isolated to that member so unrelated
            # documents in the outer archive still enter the batch.
            if isinstance(exc, (UnsafeArchiveError, ArchiveLimitError)):
                raise
            del all_entries[all_entries_count:]
            del leaf_files[leaf_count:]
            budget.total_entries = budget_entries
            budget.total_uncompressed = budget_uncompressed
            budget.hashes = budget_hashes
            shutil.rmtree(nested_root, ignore_errors=True)
            entry.ignored = True
            entry.ignore_reason = (
                f"nested_archive_unreadable:{exc.__class__.__name__}"
            )
    return archive_type


def _publish_staged_files(
    stage: Path, destination: Path, relative_files: Iterable[Path]
) -> list[Path]:
    unique_relative = sorted(
        {path.relative_to(stage) for path in relative_files}, key=lambda item: item.as_posix()
    )
    # Preflight every collision before publishing any file.
    for relative in unique_relative:
        target = _safe_target(destination, relative.parts)
        if target.exists() and file_sha256(target) != file_sha256(stage / relative):
            raise ArchiveAdapterError(f"Extraction target already exists: {target}")
    published: list[Path] = []
    destination.mkdir(parents=True, exist_ok=True)
    for relative in unique_relative:
        source = stage / relative
        target = _safe_target(destination, relative.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            shutil.move(str(source), str(target))
        published.append(target)
    return published


def extract_archive(
    archive_path: str | Path,
    destination: str | Path,
    limits: ArchiveLimits | None = None,
) -> ArchiveExtractionResult:
    """Securely extract unique leaf documents from an archive tree.

    Extraction occurs in an isolated staging directory.  Nothing is published to
    ``destination`` when validation, decoding or a recursive child fails.
    """

    source = Path(archive_path)
    if not source.is_file():
        raise FileNotFoundError(source)
    configured = limits or ArchiveLimits()
    destination_path = Path(destination)
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(
        tempfile.mkdtemp(prefix=".m1-archive-stage-", dir=destination_path.parent)
    )
    budget = _Budget(configured)
    entries: list[ArchiveEntry] = []
    leaves: list[Path] = []
    try:
        archive_type = _extract_recursive(
            source,
            stage,
            stage,
            source.name,
            0,
            budget,
            entries,
            leaves,
        )
        # Publish every unique extracted file, including nested containers retained
        # as evidence, then report only terminal leaf documents to ingestion.
        retained = [path for path in budget.hashes.values() if path.exists()]
        _publish_staged_files(stage, destination_path, retained)
        published_leaves = [destination_path / path.relative_to(stage) for path in leaves]
        for entry in entries:
            if entry.stored_relative_path:
                # The relative path remains stable across staging and destination.
                entry.stored_relative_path = PurePosixPath(entry.stored_relative_path).as_posix()
        return ArchiveExtractionResult(
            archive_path=source,
            destination=destination_path,
            archive_type=archive_type,
            entries=entries,
            leaf_files=published_leaves,
            total_uncompressed=budget.total_uncompressed,
            total_entries=budget.total_entries,
            duplicate_count=sum(entry.duplicate_of is not None for entry in entries),
            ignored_count=sum(entry.ignored for entry in entries),
        )
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def parse_archive_document(
    path: str | Path,
    original_filename: str | None = None,
    *,
    destination: str | Path | None = None,
    limits: ArchiveLimits | None = None,
) -> Any:
    """Return archive inventory/evidence as a public ``DocumentRecord``."""

    archive_path = Path(path)
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)
    active_limits = limits or ArchiveLimits()
    if archive_path.stat().st_size > active_limits.max_archive_size:
        raise ArchiveLimitError(
            f"Archive exceeds {active_limits.max_archive_size} bytes: {archive_path.name}"
        )
    digest = file_sha256(archive_path)
    target = (
        Path(destination)
        if destination is not None
        else archive_path.parent / ".m1_archives" / digest[:16]
    )
    result = extract_archive(archive_path, target, active_limits)
    original = original_filename or archive_path.name
    display = repair_display_filename(original)
    source = source_payload(
        archive_path,
        original_filename=original_filename,
        mime_type={
            "zip": "application/zip",
            "tar": "application/x-tar",
            "rar": "application/vnd.rar",
            "7z": "application/x-7z-compressed",
        }[result.archive_type],
        sha256=digest,
    )
    source["display_filename"] = display
    result_payload = result.to_dict()
    sections = [
        {
            "kind": "archive_entry",
            "index": index,
            "source_ref": f"archive:{entry.archive_path}!/{entry.raw_name}",
            "content": asdict(entry),
        }
        for index, entry in enumerate(result.entries)
    ]
    return build_document_record(
        source=source,
        document_type="archive",
        document_subtype="archive",
        sections=sections,
        raw_content=result_payload,
        metadata={
            "adapter": f"archive-{result.archive_type}",
            "limits": asdict(active_limits),
            "leaf_document_count": len(result.leaf_files),
            "deduplicated_by": "sha256",
            "filename_policy": "raw_preserved_display_repaired",
        },
    )


class ArchiveDocumentAdapter:
    supported_extensions = frozenset(_ARCHIVE_SUFFIXES)

    def __init__(
        self,
        *,
        destination: str | Path | None = None,
        limits: ArchiveLimits | None = None,
    ) -> None:
        self.destination = Path(destination) if destination is not None else None
        self.limits = limits

    def parse(self, path: str | Path, original_filename: str | None = None) -> Any:
        return parse_archive_document(
            path,
            original_filename,
            destination=self.destination,
            limits=self.limits,
        )


parse = parse_archive_document


__all__ = [
    "ArchiveAdapterError",
    "ArchiveDependencyError",
    "ArchiveDocumentAdapter",
    "ArchiveEntry",
    "ArchiveExtractionResult",
    "ArchiveLimitError",
    "ArchiveLimits",
    "UnsafeArchiveError",
    "UnsupportedArchiveError",
    "_Bounded7zWriter",
    "_SevenZipWriterFactory",
    "detect_archive_type",
    "extract_archive",
    "is_archive",
    "looks_like_archive_name",
    "parse_archive_document",
    "repair_display_filename",
]
