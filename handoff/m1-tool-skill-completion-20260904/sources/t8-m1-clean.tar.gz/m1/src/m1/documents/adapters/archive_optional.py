"""Optional RAR and 7Z extraction implementations.

This module is deliberately internal.  The public and private compatibility
surface remains :mod:`m1.documents.adapters.archive`; implementations resolve
helpers through that facade at call time so existing monkeypatch hooks keep
working after the mechanical split.
"""

from __future__ import annotations

import io
import shutil
import tempfile
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING, Any, BinaryIO

if TYPE_CHECKING:
    from .archive import ArchiveEntry, ArchiveLimits, _Budget


def _archive_facade() -> Any:
    from . import archive

    return archive


def _extract_rar(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    archive = _archive_facade()
    rarfile = archive._require_rarfile()
    try:
        package = rarfile.RarFile(str(path))
    except Exception as exc:
        raise archive.ArchiveAdapterError(
            f"Unable to open RAR archive {archive_label}: {exc}"
        ) from exc
    entries: list[ArchiveEntry] = []
    try:
        prepared = []
        for info in package.infolist():
            is_dir = bool(info.isdir())
            is_link_method = getattr(info, "is_symlink", None)
            is_link = bool(is_link_method()) if callable(is_link_method) else False
            parts, reason = archive._preflight_common(
                raw_name=info.filename,
                size=int(info.file_size),
                compressed_size=int(info.compress_size),
                is_directory=is_dir,
                is_link=is_link,
                budget=budget,
            )
            prepared.append((info, parts, reason))
        for info, parts, reason in prepared:
            if info.isdir():
                continue
            if reason:
                entries.append(
                    archive.ArchiveEntry(
                        archive_path=archive_label,
                        raw_name=info.filename,
                        display_name="/".join(
                            archive.repair_display_filename(part) for part in parts
                        ),
                        stored_relative_path=None,
                        size=int(info.file_size),
                        compressed_size=int(info.compress_size),
                        ignored=True,
                        ignore_reason=reason,
                        depth=depth,
                    )
                )
                continue
            target = archive._unique_target(
                root, archive._storage_parts(parts), info.filename
            )
            try:
                source = package.open(info)
            except Exception as exc:
                raise archive.ArchiveDependencyError(
                    f"RAR decoder could not read {info.filename}: {exc}"
                ) from exc
            try:
                with source:
                    _, digest = archive._copy_stream(
                        source,
                        target,
                        expected_size=int(info.file_size),
                        limits=budget.limits,
                    )
            except archive.ArchiveAdapterError:
                raise
            except Exception as exc:
                raise archive.ArchiveAdapterError(
                    f"RAR decoder could not read {info.filename}: {exc}"
                ) from exc
            entries.append(
                archive._entry_after_write(
                    archive_label=archive_label,
                    raw_name=info.filename,
                    parts=parts,
                    target=target,
                    stage_root=stage_root,
                    size=int(info.file_size),
                    compressed_size=int(info.compress_size),
                    digest=digest,
                    depth=depth,
                    budget=budget,
                )
            )
    finally:
        package.close()
    return entries


class _Bounded7zWriter:
    """py7zr output object that enforces the declared size while streaming."""

    def __init__(
        self, target: Path | None, expected_size: int, limits: ArchiveLimits
    ) -> None:
        self.target = target
        self.expected_size = expected_size
        self.limits = limits
        self.position = 0
        self.length = 0
        self._stream: BinaryIO | None = None
        if target is not None:
            target.parent.mkdir(parents=True, exist_ok=True)
            self._stream = target.open("x+b")

    def write(self, data: bytes | bytearray) -> int:
        end = self.position + len(data)
        if end > self.expected_size or end > self.limits.max_single_file:
            raise _archive_facade().ArchiveLimitError(
                "7Z member expanded beyond its declared size"
            )
        if self._stream is not None:
            written = self._stream.write(data)
        else:
            written = len(data)
        self.position += written
        self.length = max(self.length, self.position)
        return written

    def read(self, size: int | None = None) -> bytes:
        if self._stream is None:
            return b""
        return self._stream.read(-1 if size is None else size)

    def seek(self, offset: int, whence: int = io.SEEK_SET) -> int:
        if self._stream is not None:
            position = self._stream.seek(offset, whence)
        elif whence == io.SEEK_SET:
            position = offset
        elif whence == io.SEEK_CUR:
            position = self.position + offset
        elif whence == io.SEEK_END:
            position = self.length + offset
        else:
            raise ValueError(f"Invalid seek mode: {whence}")
        if position < 0 or position > self.expected_size:
            raise _archive_facade().ArchiveLimitError(
                "7Z decoder sought outside the declared member size"
            )
        self.position = position
        return position

    def flush(self) -> None:
        if self._stream is not None:
            self._stream.flush()

    def size(self) -> int:
        return self.length

    def close(self) -> None:
        if self._stream is not None and not self._stream.closed:
            self._stream.flush()
            self._stream.close()


class _SevenZipWriterFactory:
    def __init__(
        self,
        virtual_root: Path,
        plans: dict[str, tuple[Path | None, int]],
        limits: ArchiveLimits,
    ) -> None:
        self.virtual_root = virtual_root.resolve()
        self.plans = plans
        self.limits = limits
        self.products: dict[str, _Bounded7zWriter] = {}

    def create(self, filename: str) -> _Bounded7zWriter:
        archive = _archive_facade()
        try:
            relative = Path(filename).resolve().relative_to(self.virtual_root).as_posix()
        except ValueError as exc:
            raise archive.UnsafeArchiveError(
                f"7Z decoder requested an unsafe output: {filename}"
            ) from exc
        try:
            target, expected = self.plans[relative]
        except KeyError as exc:
            raise archive.UnsafeArchiveError(
                f"7Z decoder requested an unvalidated output: {relative}"
            ) from exc
        writer = _archive_facade()._Bounded7zWriter(
            target, expected, self.limits
        )
        self.products[relative] = writer
        return writer


def _extract_7z(
    path: Path,
    root: Path,
    stage_root: Path,
    archive_label: str,
    depth: int,
    budget: _Budget,
) -> list[ArchiveEntry]:
    archive = _archive_facade()
    py7zr = archive._require_py7zr()
    try:
        package = py7zr.SevenZipFile(path, mode="r")
    except Exception as exc:
        raise archive.ArchiveAdapterError(
            f"Unable to open 7Z archive {archive_label}: {exc}"
        ) from exc
    raw_dir = Path(tempfile.mkdtemp(prefix=".sevenzip-", dir=root))
    entries: list[ArchiveEntry] = []
    try:
        if bool(archive._attribute_or_call(getattr(package, "password_protected", False))):
            raise archive.ArchiveAdapterError(
                "Password-protected 7Z archives are unsupported"
            )
        prepared = []
        duplicate_names: dict[str, int] = {}
        for info in package.list():
            raw_name = str(info.filename)
            size = int(getattr(info, "uncompressed", 0) or 0)
            compressed_value = getattr(info, "compressed", None)
            compressed = int(compressed_value) if compressed_value is not None else None
            is_dir = bool(
                archive._attribute_or_call(getattr(info, "is_directory", False))
            )
            is_link = any(
                bool(archive._attribute_or_call(getattr(info, attribute, False)))
                for attribute in (
                    "is_symlink",
                    "is_hardlink",
                    "is_junction",
                    "is_socket",
                )
            )
            parts, reason = archive._preflight_common(
                raw_name=raw_name,
                size=size,
                compressed_size=compressed,
                is_directory=is_dir,
                is_link=is_link,
                budget=budget,
            )
            if raw_name not in duplicate_names:
                output_name = raw_name
                duplicate_names[raw_name] = 0
            else:
                output_name = f"{raw_name}_{duplicate_names[raw_name]}"
                duplicate_names[raw_name] += 1
            prepared.append(
                (raw_name, output_name, size, compressed, is_dir, parts, reason)
            )
        total_size = sum(
            size for _, _, size, _, is_dir, _, _ in prepared if not is_dir
        )
        if total_size / max(path.stat().st_size, 1) > budget.limits.max_compression_ratio:
            raise archive.ArchiveLimitError(
                f"7Z archive exceeds {budget.limits.max_compression_ratio:g}:1 "
                "compression ratio"
            )
        plans: dict[str, tuple[Path | None, int]] = {}
        targets: dict[str, Path | None] = {}
        for raw_name, output_name, size, _, is_dir, parts, reason in prepared:
            if is_dir:
                continue
            target = (
                None
                if reason
                else archive._unique_target(
                    root, archive._storage_parts(parts), raw_name
                )
            )
            plans[PurePosixPath(output_name).as_posix()] = (target, size)
            targets[output_name] = target
        factory = archive._SevenZipWriterFactory(raw_dir, plans, budget.limits)
        try:
            package.extractall(path=raw_dir, factory=factory)
        except archive.ArchiveAdapterError:
            raise
        except Exception as exc:
            raise archive.ArchiveAdapterError(
                f"7Z decoder could not read {archive_label}: {exc}"
            ) from exc
        for raw_name, output_name, size, compressed, is_dir, parts, reason in prepared:
            if is_dir:
                continue
            writer = factory.products.get(PurePosixPath(output_name).as_posix())
            if writer is None or writer.size() != size:
                raise archive.ArchiveAdapterError(
                    f"7Z member size mismatch for {raw_name}: "
                    f"{writer.size() if writer is not None else 'missing'} != {size}"
                )
            if reason:
                entries.append(
                    archive.ArchiveEntry(
                        archive_path=archive_label,
                        raw_name=raw_name,
                        display_name="/".join(
                            archive.repair_display_filename(part) for part in parts
                        ),
                        stored_relative_path=None,
                        size=size,
                        compressed_size=compressed,
                        ignored=True,
                        ignore_reason=reason,
                        depth=depth,
                    )
                )
                continue
            target = targets[output_name]
            if target is None or not target.is_file():
                raise archive.ArchiveAdapterError(
                    f"7Z member was not materialized: {raw_name}"
                )
            digest = archive.file_sha256(target)
            entries.append(
                archive._entry_after_write(
                    archive_label=archive_label,
                    raw_name=raw_name,
                    parts=parts,
                    target=target,
                    stage_root=stage_root,
                    size=size,
                    compressed_size=compressed,
                    digest=digest,
                    depth=depth,
                    budget=budget,
                )
            )
    finally:
        package.close()
        shutil.rmtree(raw_dir, ignore_errors=True)
    return entries
