"""Shared, dependency-light helpers for deterministic document adapters.

This module deliberately imports the public document models lazily.  The adapters
are useful during application start-up (and while optional format dependencies are
being probed), so importing one must not pull in the complete workflow graph.
"""

from __future__ import annotations

import hashlib
import mimetypes
import unicodedata
from pathlib import Path
from typing import Any, Mapping


def file_sha256(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def nfkc_text(value: str) -> str:
    return unicodedata.normalize("NFKC", value)


def guessed_mime(path: Path, fallback: str) -> str:
    guessed, _ = mimetypes.guess_type(path.name)
    return guessed or fallback


def source_payload(
    path: Path,
    *,
    original_filename: str | None,
    mime_type: str,
    sha256: str | None = None,
    archive_path: str | None = None,
) -> dict[str, Any]:
    """Build the superset source mapping accepted by ``m1.document.v2``.

    Model field names evolved during the M1 migration.  Both canonical and legacy
    aliases are supplied here; :func:`build_document_record` filters them against
    the installed public model.
    """

    original = original_filename or path.name
    digest = sha256 or file_sha256(path)
    return {
        "original_filename": original,
        "filename": original,
        "display_filename": original,
        "repaired_filename": original,
        "file_path": str(path),
        "sha256": digest,
        "mime": mime_type,
        "mime_type": mime_type,
        "archive_path": archive_path,
        "archive_member_path": archive_path,
    }


def _model_fields(model_type: type[Any]) -> Mapping[str, Any]:
    fields = getattr(model_type, "model_fields", None)
    if fields is not None:
        return fields
    return getattr(model_type, "__fields__", {})


def _filter_model_payload(model_type: type[Any], payload: Mapping[str, Any]) -> dict[str, Any]:
    fields = _model_fields(model_type)
    if not fields:
        return dict(payload)
    return {key: value for key, value in payload.items() if key in fields}


def build_document_record(
    *,
    source: Mapping[str, Any],
    document_type: str,
    document_subtype: str,
    sections: list[dict[str, Any]],
    raw_content: Mapping[str, Any],
    metadata: Mapping[str, Any],
    validation_issues: list[dict[str, Any]] | None = None,
) -> Any:
    """Construct the repository's public ``DocumentRecord`` without a hard cycle.

    The migration model intentionally has defaults for non-source fields.  Filtering
    a superset payload keeps these adapters compatible with intermediate branches
    while still returning the real Pydantic model rather than an opaque dictionary.
    """

    from m1.documents.models import DocumentRecord, DocumentSource

    source_model = DocumentSource.model_validate(
        _filter_model_payload(DocumentSource, source)
    )
    payload: dict[str, Any] = {
        "schema_version": "m1.document.v2",
        "contract_version": "m1.document.v2",
        "source": source_model,
        "document_type": document_type,
        "document_subtype": document_subtype,
        "header": {},
        "lines": [],
        "bom": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": validation_issues or [],
        # ``extraction`` is the stable compatibility container retained by the
        # public v2 contract.  Format-specific deterministic evidence lives here
        # even when a deployment uses a stricter model that does not allow extras.
        "extraction": {
            "sections": sections,
            "raw_content": dict(raw_content),
            "metadata": dict(metadata),
        },
        "sections": sections,
        "raw_content": dict(raw_content),
        "metadata": dict(metadata),
    }
    return DocumentRecord.model_validate(_filter_model_payload(DocumentRecord, payload))


def model_dump(record: Any) -> dict[str, Any]:
    """Small compatibility helper used only by adapter composition and tests."""

    if hasattr(record, "model_dump"):
        return record.model_dump(mode="python")
    if hasattr(record, "dict"):
        return record.dict()
    if isinstance(record, dict):
        return record
    raise TypeError(f"Unsupported document record type: {type(record)!r}")
