"""DOCX adapter combining python-docx metadata with lossless OOXML traversal."""

from __future__ import annotations

import hashlib
import posixpath
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable
from xml.etree import ElementTree as ET

from ..ooxml import OOXMLPackageError, preflight_ooxml_package
from ..technical_projection import project_technical_document
from .common import build_document_record, file_sha256, nfkc_text, source_payload


class DOCXAdapterError(RuntimeError):
    """Raised when an OOXML Word package is malformed or unsafe to parse."""


_NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "v": "urn:schemas-microsoft-com:vml",
    "pr": "http://schemas.openxmlformats.org/package/2006/relationships",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
}
_W = f"{{{_NS['w']}}}"
_R = f"{{{_NS['r']}}}"
_MAX_DOCX_SIZE = 100 * 1024 * 1024
_MAX_XML_PART_SIZE = 32 * 1024 * 1024
_MAX_PACKAGE_ENTRIES = 5000
_MAX_RATIO = 100.0


def _read_part(
    package: zipfile.ZipFile, name: str, *, max_size: int = _MAX_XML_PART_SIZE
) -> bytes:
    try:
        info = package.getinfo(name)
    except KeyError as exc:
        raise DOCXAdapterError(f"DOCX package is missing required part: {name}") from exc
    if info.file_size > max_size:
        raise DOCXAdapterError(f"DOCX part is too large: {name} ({info.file_size} bytes)")
    if info.file_size and info.compress_size == 0:
        raise DOCXAdapterError(f"DOCX part has an invalid compression size: {name}")
    if info.compress_size and info.file_size / info.compress_size > _MAX_RATIO:
        raise DOCXAdapterError(f"DOCX part exceeds the 100:1 compression ratio: {name}")
    return package.read(info)


def _xml(package: zipfile.ZipFile, name: str) -> ET.Element:
    try:
        return ET.fromstring(_read_part(package, name))
    except ET.ParseError as exc:
        raise DOCXAdapterError(f"Malformed OOXML part {name}: {exc}") from exc


def _safe_part_target(base_part: str, target: str) -> str:
    if "\x00" in target or target.startswith(("/", "\\")):
        raise DOCXAdapterError(f"Unsafe OOXML relationship target: {target!r}")
    combined = posixpath.normpath(posixpath.join(posixpath.dirname(base_part), target))
    parts = PurePosixPath(combined).parts
    if not combined or combined == ".." or any(part == ".." for part in parts):
        raise DOCXAdapterError(f"OOXML relationship escapes the package: {target!r}")
    return combined


def _relationship_map(package: zipfile.ZipFile) -> dict[str, dict[str, Any]]:
    root = _xml(package, "word/_rels/document.xml.rels")
    relationships: dict[str, dict[str, Any]] = {}
    for rel in root.findall("pr:Relationship", _NS):
        relation_id = rel.get("Id")
        target = rel.get("Target")
        if not relation_id or not target:
            continue
        external = rel.get("TargetMode") == "External"
        resolved = None if external else _safe_part_target("word/document.xml", target)
        relationships[relation_id] = {
            "relationship_id": relation_id,
            "type": rel.get("Type"),
            "target_original": target,
            "target_part": resolved,
            "external": external,
        }
    return relationships


def _content_types(package: zipfile.ZipFile) -> tuple[dict[str, str], dict[str, str]]:
    root = _xml(package, "[Content_Types].xml")
    defaults = {
        item.get("Extension", "").lower(): item.get("ContentType", "")
        for item in root.findall("ct:Default", _NS)
    }
    overrides = {
        item.get("PartName", "").lstrip("/"): item.get("ContentType", "")
        for item in root.findall("ct:Override", _NS)
    }
    return defaults, overrides


def _part_content_type(
    part: str, defaults: dict[str, str], overrides: dict[str, str]
) -> str:
    return overrides.get(part) or defaults.get(PurePosixPath(part).suffix.lstrip(".").lower(), "")


def _walk_text(element: ET.Element, *, skip_textboxes: bool) -> Iterable[str]:
    if skip_textboxes and element.tag == f"{_W}txbxContent":
        return
    if element.tag == f"{_W}t":
        yield element.text or ""
        return
    if element.tag == f"{_W}tab":
        yield "\t"
        return
    if element.tag in {f"{_W}br", f"{_W}cr"}:
        yield "\n"
        return
    for child in element:
        yield from _walk_text(child, skip_textboxes=skip_textboxes)


def _text(element: ET.Element, *, skip_textboxes: bool = False) -> str:
    return "".join(_walk_text(element, skip_textboxes=skip_textboxes))


def _run_payload(run: ET.Element) -> dict[str, Any]:
    value = _text(run, skip_textboxes=True)
    properties = run.find("w:rPr", _NS)
    style = properties.find("w:rStyle", _NS) if properties is not None else None
    return {
        "text_original": value,
        "text_normalized": nfkc_text(value),
        "style": style.get(f"{_W}val") if style is not None else None,
        "bold": properties.find("w:b", _NS) is not None if properties is not None else False,
        "italic": properties.find("w:i", _NS) is not None if properties is not None else False,
        "underline": properties.find("w:u", _NS) is not None if properties is not None else False,
    }


def _paragraph_payload(paragraph: ET.Element, index: int) -> dict[str, Any]:
    properties = paragraph.find("w:pPr", _NS)
    style = properties.find("w:pStyle", _NS) if properties is not None else None
    runs = [_run_payload(run) for run in paragraph.findall(".//w:r", _NS)]
    value = _text(paragraph, skip_textboxes=True)
    return {
        "paragraph_index": index,
        "text_original": value,
        "text_normalized": nfkc_text(value),
        "style": style.get(f"{_W}val") if style is not None else None,
        "runs": runs,
    }


def _table_payload(table: ET.Element, table_index: int) -> dict[str, Any]:
    rows: list[list[dict[str, Any]]] = []
    for row_index, row in enumerate(table.findall("w:tr", _NS)):
        cells: list[dict[str, Any]] = []
        column_index = 0
        for cell in row.findall("w:tc", _NS):
            properties = cell.find("w:tcPr", _NS)
            grid_span = properties.find("w:gridSpan", _NS) if properties is not None else None
            vertical_merge = properties.find("w:vMerge", _NS) if properties is not None else None
            span = int(grid_span.get(f"{_W}val", "1")) if grid_span is not None else 1
            paragraphs = [
                _paragraph_payload(paragraph, paragraph_index)
                for paragraph_index, paragraph in enumerate(cell.findall("w:p", _NS))
            ]
            value = "\n".join(item["text_original"] for item in paragraphs)
            cells.append(
                {
                    "row_index": row_index,
                    "column_index": column_index,
                    "grid_span": span,
                    "vertical_merge": (
                        vertical_merge.get(f"{_W}val", "continue")
                        if vertical_merge is not None
                        else None
                    ),
                    "text_original": value,
                    "text_normalized": nfkc_text(value),
                    "paragraphs": paragraphs,
                }
            )
            column_index += span
        rows.append(cells)
    return {
        "table_index": table_index,
        "row_count": len(rows),
        "column_count": max(
            (sum(int(cell["grid_span"]) for cell in row) for row in rows), default=0
        ),
        "rows": rows,
    }


def _core_properties(package: zipfile.ZipFile) -> dict[str, Any]:
    if "docProps/core.xml" not in package.namelist():
        return {}
    root = _xml(package, "docProps/core.xml")
    properties: dict[str, Any] = {}
    for key, query in {
        "title": "dc:title",
        "subject": "dc:subject",
        "creator": "dc:creator",
        "description": "dc:description",
        "created": "dcterms:created",
        "modified": "dcterms:modified",
    }.items():
        value = root.find(query, _NS)
        if value is not None and value.text:
            properties[key] = value.text
    return properties


def _extract_images(
    package: zipfile.ZipFile,
    document_root: ET.Element,
    relationships: dict[str, dict[str, Any]],
    defaults: dict[str, str],
    overrides: dict[str, str],
    assets_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    references_by_id: dict[str, list[dict[str, Any]]] = {}

    def add_reference(relation_id: str, reference: dict[str, Any]) -> None:
        references_by_id.setdefault(relation_id, []).append(reference)

    for paragraph_index, paragraph in enumerate(document_root.findall(".//w:p", _NS)):
        for container_name in ("inline", "anchor"):
            for container in paragraph.findall(f".//wp:{container_name}", _NS):
                doc_properties = container.find("wp:docPr", _NS)
                extent = container.find("wp:extent", _NS)
                for blip in container.findall(".//a:blip", _NS):
                    relation_id = blip.get(f"{_R}embed") or blip.get(f"{_R}link")
                    if relation_id:
                        add_reference(
                            relation_id,
                            {
                                "representation": "drawingml",
                                "container": container_name,
                                "xml_paragraph_index": paragraph_index,
                                "name": (
                                    doc_properties.get("name")
                                    if doc_properties is not None
                                    else None
                                ),
                                "description": (
                                    doc_properties.get("descr")
                                    if doc_properties is not None
                                    else None
                                ),
                                "extent_emu": (
                                    {
                                        "cx": int(extent.get("cx", "0")),
                                        "cy": int(extent.get("cy", "0")),
                                    }
                                    if extent is not None
                                    else None
                                ),
                            },
                        )
        for image_data in paragraph.findall(".//v:imagedata", _NS):
            relation_id = image_data.get(f"{_R}id")
            if relation_id:
                add_reference(
                    relation_id,
                    {
                        "representation": "vml",
                        "container": "pict",
                        "xml_paragraph_index": paragraph_index,
                        "title": image_data.get("title"),
                    },
                )

    # Preserve unreferenced image relationships as package evidence as well.
    for relation_id, relation in relationships.items():
        if (
            str(relation.get("type", "")).endswith("/image")
            and relation_id not in references_by_id
        ):
            add_reference(
                relation_id,
                {"representation": "relationship_only", "container": None},
            )

    images: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    for relation_id, references in references_by_id.items():
        relation = relationships.get(relation_id)
        if relation is None or relation.get("external"):
            issues.append(
                {
                    "code": "DOCX_IMAGE_RELATION_MISSING",
                    "severity": "warning",
                    "message": f"Image relationship {relation_id} has no internal target.",
                    "paths": [f"$.extraction.raw_content.images[{len(images)}]"],
                    "source_refs": [{"part": "word/document.xml"}],
                    "actual": relation_id,
                }
            )
            continue
        part = str(relation["target_part"])
        try:
            data = _read_part(package, part, max_size=_MAX_DOCX_SIZE)
        except DOCXAdapterError as exc:
            issues.append(
                {
                    "code": "DOCX_IMAGE_PART_UNAVAILABLE",
                    "severity": "warning",
                    "message": str(exc),
                    "paths": [f"$.extraction.raw_content.images[{len(images)}]"],
                    "source_refs": [{"part": part}],
                }
            )
            continue
        digest = hashlib.sha256(data).hexdigest()
        base_name = PurePosixPath(part).name or f"image-{len(images) + 1}"
        assets_dir.mkdir(parents=True, exist_ok=True)
        suffix = PurePosixPath(base_name).suffix
        target = assets_dir / f"{digest}{suffix}"
        try:
            with target.open("xb") as output:
                output.write(data)
        except FileExistsError:
            pass
        images.append(
            {
                **relation,
                "representation": references[0]["representation"],
                "references": references,
                "content_type": _part_content_type(part, defaults, overrides),
                "sha256": digest,
                "byte_size": len(data),
                "asset_path": str(target),
            }
        )
    return images, issues


def _python_docx_metadata(path: Path) -> tuple[str, dict[str, Any]]:
    """Use python-docx when installed; OOXML remains the lossless source of truth."""

    try:
        from docx import Document  # type: ignore[import-not-found]
    except ImportError:
        return "ooxml", {"python_docx_available": False}
    try:
        document = Document(str(path))
        props = document.core_properties
        return "python-docx+ooxml", {
            "python_docx_available": True,
            "python_docx_paragraph_count": len(document.paragraphs),
            "python_docx_table_count": len(document.tables),
            "python_docx_inline_shape_count": len(document.inline_shapes),
            "python_docx_title": props.title,
            "python_docx_author": props.author,
        }
    except Exception as exc:
        # Some producer-specific OOXML constructs are accepted by Word but rejected
        # by python-docx.  Native OOXML parsing should still produce a useful draft.
        return "ooxml", {
            "python_docx_available": True,
            "python_docx_error": str(exc),
        }


def _guess_subtype(filename: str, text: str) -> str:
    sample = f"{filename}\n{text[:2000]}".lower()
    if any(token in sample for token in ("承认书", "承認書", "approval drawing")):
        return "approval_drawing"
    if any(token in sample for token in ("图纸", "圖紙", "drawing")):
        return "approval_drawing"
    if any(token in sample for token in ("规格书", "規格書", "specification", "datasheet")):
        return "product_specification"
    if any(token in sample for token in ("工艺", "流程", "process document")):
        return "process_document"
    return "unknown"


def parse_docx_document(
    path: str | Path,
    original_filename: str | None = None,
    *,
    assets_dir: str | Path | None = None,
) -> Any:
    """Extract body paragraphs, ordered tables, text boxes, images and relations."""

    docx_path = Path(path)
    if not docx_path.is_file():
        raise FileNotFoundError(docx_path)
    if docx_path.stat().st_size > _MAX_DOCX_SIZE:
        raise DOCXAdapterError(
            f"DOCX exceeds the 100 MiB single-file limit: {docx_path.stat().st_size}"
        )
    try:
        preflight_ooxml_package(docx_path, expected_kind="document")
    except OOXMLPackageError as exc:
        raise DOCXAdapterError(
            f"ZIP file is not a Word document: {docx_path.name} ({exc})"
        ) from exc
    digest = file_sha256(docx_path)
    output_dir = (
        Path(assets_dir)
        if assets_dir is not None
        else docx_path.parent / ".m1_assets" / digest[:16] / "docx-images"
    )

    try:
        package = zipfile.ZipFile(docx_path, "r")
    except zipfile.BadZipFile as exc:
        raise DOCXAdapterError(f"Not a valid DOCX/ZIP package: {docx_path.name}") from exc
    try:
        infos = package.infolist()
        if len(infos) > _MAX_PACKAGE_ENTRIES:
            raise DOCXAdapterError(
                f"DOCX contains too many package entries: {len(infos)} > {_MAX_PACKAGE_ENTRIES}"
            )
        names = {info.filename for info in infos}
        if "word/document.xml" not in names or "[Content_Types].xml" not in names:
            raise DOCXAdapterError(f"ZIP file is not a Word document: {docx_path.name}")
        document_root = _xml(package, "word/document.xml")
        relationships = _relationship_map(package)
        defaults, overrides = _content_types(package)
        core_properties = _core_properties(package)

        body = document_root.find("w:body", _NS)
        if body is None:
            raise DOCXAdapterError("word/document.xml has no document body")
        paragraphs: list[dict[str, Any]] = []
        tables: list[dict[str, Any]] = []
        sections: list[dict[str, Any]] = []
        paragraph_index = table_index = 0
        for child in body:
            if child.tag == f"{_W}p":
                payload = _paragraph_payload(child, paragraph_index)
                paragraphs.append(payload)
                sections.append(
                    {
                        "kind": "paragraph",
                        "index": paragraph_index,
                        "source_ref": f"part:word/document.xml#paragraph:{paragraph_index}",
                        "content": payload,
                    }
                )
                paragraph_index += 1
            elif child.tag == f"{_W}tbl":
                payload = _table_payload(child, table_index)
                tables.append(payload)
                sections.append(
                    {
                        "kind": "table",
                        "index": table_index,
                        "source_ref": f"part:word/document.xml#table:{table_index}",
                        "content": payload,
                    }
                )
                table_index += 1

        textboxes: list[dict[str, Any]] = []
        for textbox_index, textbox in enumerate(document_root.findall(".//w:txbxContent", _NS)):
            textbox_paragraphs = [
                _paragraph_payload(paragraph, index)
                for index, paragraph in enumerate(textbox.findall(".//w:p", _NS))
            ]
            value = "\n".join(item["text_original"] for item in textbox_paragraphs)
            textboxes.append(
                {
                    "textbox_index": textbox_index,
                    "text_original": value,
                    "text_normalized": nfkc_text(value),
                    "paragraphs": textbox_paragraphs,
                }
            )

        images, issues = _extract_images(
            package,
            document_root,
            relationships,
            defaults,
            overrides,
            output_dir,
        )
    except zipfile.BadZipFile as exc:
        raise DOCXAdapterError(f"Corrupt DOCX package: {docx_path.name}: {exc}") from exc
    finally:
        package.close()

    body_text_parts: list[str] = []
    for section in sections:
        content = section["content"]
        if section["kind"] == "paragraph":
            body_text_parts.append(content["text_original"])
        else:
            body_text_parts.extend(
                cell["text_original"]
                for row in content["rows"]
                for cell in row
            )
    body_text = "\n".join(part for part in body_text_parts if part)
    textbox_text = "\n".join(item["text_original"] for item in textboxes if item["text_original"])
    all_text = "\n".join(part for part in (body_text, textbox_text) if part)
    engine, python_docx_metadata = _python_docx_metadata(docx_path)
    classification_name = original_filename or str(docx_path)
    subtype = _guess_subtype(classification_name, all_text)
    source = source_payload(
        docx_path,
        original_filename=original_filename,
        mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        sha256=digest,
    )
    record = build_document_record(
        source=source,
        document_type="technical_document" if subtype != "unknown" else "unknown",
        document_subtype=subtype,
        sections=sections,
        raw_content={
            "text_original": all_text,
            "text_normalized": nfkc_text(all_text),
            "paragraphs": paragraphs,
            "tables": tables,
            "textboxes": textboxes,
            "images": images,
            "relationships": list(relationships.values()),
        },
        metadata={
            "adapter": engine,
            "core_properties": core_properties,
            "paragraph_count": len(paragraphs),
            "table_count": len(tables),
            "textbox_count": len(textboxes),
            "image_count": len(images),
            "image_assets_dir": str(output_dir) if images else None,
            **python_docx_metadata,
        },
        validation_issues=issues,
    )
    if record.document_type == "technical_document":
        return project_technical_document(record, filename=classification_name)
    return record


class DOCXDocumentAdapter:
    supported_extensions = frozenset({".docx"})

    def parse(self, path: str | Path, original_filename: str | None = None) -> Any:
        return parse_docx_document(path, original_filename)


parse = parse_docx_document
