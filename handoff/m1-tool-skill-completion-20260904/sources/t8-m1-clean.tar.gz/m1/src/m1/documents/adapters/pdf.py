"""Compatibility facade for deterministic PDF parsing.

Native evidence extraction, classification, and order mapping live in focused
internal modules. Historical public and private symbols remain importable here,
and orchestration functions deliberately resolve dependencies through this
module so tests and integrations can continue to monkeypatch them.
"""

from __future__ import annotations

import contextlib
import copy
import re
import threading
from decimal import Decimal
from pathlib import Path
from typing import Any

from .pdf_classification import (  # noqa: F401 - compatibility re-exports
    _PDF_HEADER_ALIASES,
    _classification_hint,
    _classify_pdf,
    _has_order_table,
    _header_key,
    _match_order_header,
    _resolve_pdf_classification,
    _table_header_mapping,
)
from .pdf_errors import PDFAdapterError, PDFDependencyError  # noqa: F401
from .pdf_drawing import build_pdf_drawing_record
from .pdf_native import (  # noqa: F401 - compatibility re-exports
    _TABLE_FINDER_STREAM_LOCK,
    _asset_dir,
    _coverage_ratio,
    _ocr_recommendation,
    _page_images,
    _rect_list,
    _rect_union_area,
    _require_fitz,
    _span_payload,
    _tables,
    _text_blocks,
)
from .pdf_order import (  # noqa: F401 - compatibility re-exports
    _DATE_CANDIDATE_RE,
    _KNOWN_HEADER_LABELED_LINE,
    _KNOWN_HEADER_LABEL_ONLY,
    _KNOWN_HEADER_LABEL_PATTERN,
    _KNOWN_HEADER_LABELS,
    _NUMERIC_FIELDS,
    _PARTY_ROLE_PREFIX_RE,
    _clean,
    _clean_party_value,
    _date_value,
    _extract_pdf_header,
    _extract_pdf_lines,
    _first_page_containing,
    _is_date_candidate,
    _is_identifier_candidate,
    _is_known_header_boundary,
    _is_non_label_candidate,
    _labeled_value,
    _number,
    _pdf_ref,
    _set_line_value,
    _sum_numbers,
    _validate_pdf_lines,
    _year_from_identifier,
)
from .common import build_document_record, file_sha256, nfkc_text, source_payload
from ..technical_projection import project_technical_document
from m1.documents.models import (  # noqa: F401 - historical module attributes
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    DocumentTotals,
    FieldMetadata,
    IdentifierCandidate,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from m1.documents.orders import (  # noqa: F401 - historical module attributes
    HEADER_ALIASES,
    ORDER_NUMBER_RE,
    attach_derived_line_evidence,
    enrich_order_line,
)


# Keep the lock on the facade: parse_pdf_document resolves it dynamically, so
# existing integrations can replace it while diagnosing deterministic parsing.
_PDF_PARSE_LOCK = threading.RLock()


def _build_pdf_order_record(
    *,
    source: dict[str, Any],
    filename: str,
    subtype: str,
    pages: list[dict[str, Any]],
    sections: list[dict[str, Any]],
    original_text: str,
    metadata: dict[str, Any],
    initial_issues: list[ValidationIssue] | None = None,
) -> DocumentRecord:
    field_meta: dict[str, FieldMetadata] = {}
    issues = list(initial_issues or [])
    header = _extract_pdf_header(filename, pages, subtype, field_meta, issues)
    lines, declared, declared_refs = _extract_pdf_lines(pages, field_meta, issues)
    for line in lines:
        issues.extend(enrich_order_line(line))
    attach_derived_line_evidence(lines, field_meta)
    issues.extend(_validate_pdf_lines(lines))

    calculated_quantity = _sum_numbers([line.quantity for line in lines])
    amount_field = (
        "amount_tax_included"
        if any(line.amount_tax_included is not None for line in lines)
        else "amount_tax_excluded"
    )
    calculated_amount = _sum_numbers([getattr(line, amount_field) for line in lines])
    declared_quantity = declared.get("quantity")
    declared_amount = declared.get("amount")
    quantity_matches = (
        Decimal(declared_quantity) == Decimal(calculated_quantity)
        if declared_quantity is not None and calculated_quantity is not None
        else None
    )
    aggregate_amount_matches = (
        Decimal(declared_amount) == Decimal(calculated_amount)
        if declared_amount is not None and calculated_amount is not None
        else None
    )
    amount_matches = (
        False
        if any(issue.code == "LINE_AMOUNT_MISMATCH" for issue in issues)
        else aggregate_amount_matches
    )
    totals = DocumentTotals(
        declared_quantity=declared_quantity,
        calculated_quantity=calculated_quantity,
        quantity_matches=quantity_matches,
        declared_amount=declared_amount,
        calculated_amount=calculated_amount,
        amount_matches=amount_matches,
        source_declared={"quantity": declared_quantity, "amount": declared_amount},
        system_calculated={"quantity": calculated_quantity, "amount": calculated_amount},
        matches={"quantity": quantity_matches, "amount": amount_matches},
    )
    for key in ("quantity", "amount"):
        if key in declared_refs:
            field_meta[f"$.totals.declared_{key}"] = FieldMetadata(
                source_refs=[declared_refs[key]]
            )
    if quantity_matches is False:
        issues.append(
            ValidationIssue(
                code="TOTAL_QUANTITY_MISMATCH",
                severity="warning",
                message="PDF 声明数量合计与逐行重算值不一致。",
                paths=["$.totals.declared_quantity", "$.totals.calculated_quantity"],
                source_refs=[declared_refs["quantity"]],
                expected=calculated_quantity,
                actual=declared_quantity,
            )
        )
    if aggregate_amount_matches is False:
        issues.append(
            ValidationIssue(
                code="TOTAL_AMOUNT_MISMATCH",
                severity="warning",
                message="PDF 声明金额合计与逐行重算值不一致。",
                paths=["$.totals.declared_amount", "$.totals.calculated_amount"],
                source_refs=[declared_refs["amount"]],
                expected=calculated_amount,
                actual=declared_amount,
            )
        )

    return DocumentRecord(
        source=DocumentSource.model_validate(source),
        document_type="order",
        document_subtype=subtype,
        header=header,
        lines=lines,
        totals=totals,
        field_meta=field_meta,
        validation_issues=issues,
        needs_review=any(issue.severity in {"warning", "error"} for issue in issues),
        extraction={
            "sections": sections,
            "raw_content": {
                "text_original": original_text,
                "text_normalized": nfkc_text(original_text),
                "pages": pages,
            },
            "metadata": metadata,
        },
    )

def rebuild_pdf_document_after_ocr(
    document: dict[str, Any], *, filename: str | None = None
) -> dict[str, Any]:
    """Re-run PDF classification and deterministic order parsing on OCR evidence.

    Native text remains available under ``native_text_*``.  OCR-derived tables
    are appended to native tables and their cell values retain OCR confidence
    and ``ocr/...`` source references in the rebuilt v2 document.
    """

    result = copy.deepcopy(document)
    extraction = result.get("extraction")
    if not isinstance(extraction, dict):
        return result
    raw_content = extraction.get("raw_content")
    metadata = extraction.get("metadata")
    pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    if not isinstance(raw_content, dict) or not isinstance(metadata, dict) or not isinstance(pages, list):
        return result

    analysis_pages = copy.deepcopy(pages)
    ocr_table_count = 0
    for page in analysis_pages:
        native_original = str(
            page.get("native_text_original")
            if page.get("native_text_original") is not None
            else page.get("text_original") or ""
        )
        native_normalized = str(
            page.get("native_text_normalized")
            if page.get("native_text_normalized") is not None
            else page.get("text_normalized") or ""
        )
        ocr_original = str(page.get("ocr_text_original") or "")
        ocr_normalized = str(page.get("ocr_text_normalized") or "")
        page["native_text_original"] = native_original
        page["native_text_normalized"] = native_normalized
        page["text_original"] = "\n".join(
            part for part in (native_original, ocr_original) if part
        )
        page["text_normalized"] = "\n".join(
            part for part in (native_normalized, ocr_normalized) if part
        )
        ocr_tables = list(page.get("ocr_tables") or [])
        ocr_table_count += len(ocr_tables)
        native_tables = [
            table for table in list(page.get("tables") or []) if not table.get("ocr_derived")
        ]
        page["tables"] = [*native_tables, *ocr_tables]

    combined_original = "\n\f\n".join(
        str(page.get("text_original") or "") for page in analysis_pages
    )
    combined_normalized = "\n\f\n".join(
        str(page.get("text_normalized") or "") for page in analysis_pages
    )
    source = copy.deepcopy(result.get("source") or {})
    effective_filename = str(
        filename
        or source.get("original_filename")
        or source.get("display_filename")
        or "document.pdf"
    )
    classified_type, classified_subtype = _classify_pdf(
        effective_filename, combined_normalized, analysis_pages
    )
    fallback_type = (
        classified_type
        if classified_type != "unknown"
        else str(result.get("document_type") or "unknown")
    )
    fallback_subtype = (
        classified_subtype
        if classified_subtype != "unknown"
        else str(result.get("document_subtype") or "unknown")
    )
    prior_classification = metadata.get("classification")
    if not isinstance(prior_classification, dict):
        prior_classification = {}
    (
        document_type,
        document_subtype,
        resolved_classification,
        classification_issues,
    ) = _resolve_pdf_classification(
        fallback_type,
        fallback_subtype,
        doc_type_hint=prior_classification.get("hinted_document_type"),
        document_subtype_hint=prior_classification.get("hinted_document_subtype"),
    )
    metadata["ocr_table_count"] = ocr_table_count
    metadata["classification_after_ocr"] = {
        **resolved_classification,
        "ocr_detected_document_type": classified_type,
        "ocr_detected_document_subtype": classified_subtype,
    }
    sections = [
        {
            "kind": "page",
            "index": int(page.get("page_index") or index),
            "source_ref": f"page:{int(page.get('page_number') or index + 1)}",
            "content": page,
        }
        for index, page in enumerate(analysis_pages)
    ]

    if document_type == "order":
        rebuilt = _build_pdf_order_record(
            source=source,
            filename=effective_filename,
            subtype=document_subtype,
            pages=analysis_pages,
            sections=sections,
            original_text=combined_original,
            metadata=metadata,
            initial_issues=classification_issues,
        ).model_dump(mode="json")
        rebuilt_extraction = rebuilt["extraction"]
        rebuilt_raw = rebuilt_extraction["raw_content"]
        rebuilt_raw["native_text_original"] = raw_content.get("text_original", "")
        rebuilt_raw["native_text_normalized"] = raw_content.get("text_normalized", "")
        rebuilt_raw["ocr_text_original"] = raw_content.get("ocr_text_original", "")
        rebuilt_raw["ocr_text_normalized"] = raw_content.get("ocr_text_normalized", "")
        rebuilt_raw["text_normalized_combined"] = combined_normalized
        return rebuilt

    if (
        document_type == "technical_document"
        and document_subtype == "approval_drawing"
    ):
        rebuilt_record = build_pdf_drawing_record(
            source=source,
            pages=analysis_pages,
            sections=sections,
            original_text=combined_original,
            metadata=metadata,
            initial_issues=classification_issues,
        )
        rebuilt = project_technical_document(
            rebuilt_record, filename=effective_filename
        ).model_dump(mode="json")
        rebuilt_raw = rebuilt["extraction"]["raw_content"]
        rebuilt_raw["native_text_original"] = raw_content.get("text_original", "")
        rebuilt_raw["native_text_normalized"] = raw_content.get("text_normalized", "")
        rebuilt_raw["ocr_text_original"] = raw_content.get("ocr_text_original", "")
        rebuilt_raw["ocr_text_normalized"] = raw_content.get("ocr_text_normalized", "")
        rebuilt_raw["text_normalized_combined"] = combined_normalized
        return rebuilt

    result["document_type"] = document_type
    result["document_subtype"] = document_subtype
    extraction["sections"] = sections
    raw_content["native_text_original"] = raw_content.get("text_original", "")
    raw_content["native_text_normalized"] = raw_content.get("text_normalized", "")
    raw_content["text_original"] = combined_original
    raw_content["text_normalized"] = combined_normalized
    raw_content["text_normalized_combined"] = combined_normalized
    raw_content["pages"] = analysis_pages
    if document_type == "technical_document":
        return project_technical_document(
            DocumentRecord.model_validate(result), filename=effective_filename
        ).model_dump(mode="json")
    return result


def _parse_pdf_document_unlocked(
    path: str | Path,
    original_filename: str | None = None,
    *,
    doc_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    render_dir: str | Path | None = None,
    render_pages: bool = True,
    render_dpi: int = 150,
) -> Any:
    """Parse a PDF into the public ``DocumentRecord``.

    ``render_pages`` is enabled by default so downstream OCR/VLM stages receive one
    bounded image per page.  Passing a common ``render_dir`` makes asset lifecycle
    management explicit for callers that use temporary upload directories.
    """

    pdf_path = Path(path)
    if not pdf_path.is_file():
        raise FileNotFoundError(pdf_path)
    with pdf_path.open("rb") as stream:
        magic = stream.read(5)
    if magic != b"%PDF-":
        raise PDFAdapterError(f"Not a PDF by magic bytes: {pdf_path.name}")
    if render_dpi < 36 or render_dpi > 600:
        raise ValueError("render_dpi must be between 36 and 600")

    fitz = _require_fitz()
    digest = file_sha256(pdf_path)
    assets = _asset_dir(pdf_path, digest, render_dir)
    pages: list[dict[str, Any]] = []
    full_text: list[str] = []
    try:
        document = fitz.open(str(pdf_path))
    except Exception as exc:
        raise PDFAdapterError(f"Unable to open PDF {pdf_path.name}: {exc}") from exc

    try:
        if bool(getattr(document, "needs_pass", False)):
            raise PDFAdapterError(f"Encrypted PDF requires a password: {pdf_path.name}")
        if render_pages:
            assets.mkdir(parents=True, exist_ok=True)
        for page_index, page in enumerate(document):
            blocks, page_text = _text_blocks(page)
            tables = _tables(page)
            images = _page_images(page)
            # PyMuPDF text, table and image boxes are expressed in the
            # unrotated page coordinate system. ``page.rect`` swaps dimensions
            # for 90/270 degree pages, so use the crop box for coverage math.
            page_rect = [
                0.0,
                0.0,
                float(page.cropbox.width),
                float(page.cropbox.height),
            ]
            image_coverage = _coverage_ratio(
                [image["bbox"] for image in images if image.get("bbox")], page_rect
            )
            text_coverage = _coverage_ratio(
                [block["bbox"] for block in blocks if block.get("bbox")], page_rect
            )
            full_text.append(page_text)
            render_path: str | None = None
            if render_pages:
                target = assets / f"page-{page_index + 1:04d}.png"
                pixmap = page.get_pixmap(dpi=render_dpi, alpha=False)
                pixmap.save(str(target))
                render_path = str(target)
            pages.append(
                {
                    "page_number": page_index + 1,
                    "page_index": page_index,
                    "width": float(page.rect.width),
                    "height": float(page.rect.height),
                    "coordinate_width": float(page.cropbox.width),
                    "coordinate_height": float(page.cropbox.height),
                    "rotation": int(page.rotation),
                    "derotation_matrix": [
                        float(value) for value in page.derotation_matrix
                    ],
                    "coordinate_space": "pdf_points",
                    "text_original": page_text,
                    "text_normalized": nfkc_text(page_text),
                    "native_text_char_count": len(
                        re.sub(r"\s+", "", nfkc_text(page_text))
                    ),
                    "text_blocks": blocks,
                    "tables": tables,
                    "images": images,
                    "image_coverage_ratio": image_coverage,
                    "text_block_coverage_ratio": text_coverage,
                    "render_asset": render_path,
                    "render_dpi": render_dpi if render_pages else None,
                }
            )
        pdf_metadata = {
            str(key): value for key, value in (document.metadata or {}).items()
        }
    finally:
        with contextlib.suppress(Exception):
            document.close()

    original_text = "\n\f\n".join(full_text)
    effective_filename = original_filename or pdf_path.name
    detected_type, detected_subtype = _classify_pdf(
        effective_filename, original_text, pages
    )
    (
        document_type,
        document_subtype,
        classification_metadata,
        classification_issues,
    ) = _resolve_pdf_classification(
        detected_type,
        detected_subtype,
        doc_type_hint=doc_type_hint,
        document_subtype_hint=document_subtype_hint,
    )
    source = source_payload(
        pdf_path,
        original_filename=original_filename,
        mime_type="application/pdf",
        sha256=digest,
    )
    sections = [
        {
            "kind": "page",
            "index": page["page_index"],
            "source_ref": f"page:{page['page_number']}",
            "content": page,
        }
        for page in pages
    ]
    ocr_analysis = {
        int(page["page_number"]): {
            "recommended": _ocr_recommendation(page)[0],
            "reasons": _ocr_recommendation(page)[1],
            "native_text_char_count": int(page.get("native_text_char_count") or 0),
            "image_coverage_ratio": float(page.get("image_coverage_ratio") or 0.0),
            "text_block_coverage_ratio": float(
                page.get("text_block_coverage_ratio") or 0.0
            ),
        }
        for page in pages
    }
    metadata = {
        "adapter": "pdf-pymupdf-native",
        "page_count": len(pages),
        "pdf_metadata": pdf_metadata,
        "render_mode": "per_page" if render_pages else "disabled",
        "render_assets_dir": str(assets) if render_pages else None,
        "ocr_recommended_pages": [
            page["page_number"]
            for page in pages
            if ocr_analysis[int(page["page_number"])]["recommended"]
        ],
        "ocr_page_analysis": ocr_analysis,
        "classification": classification_metadata,
    }
    if document_type == "order":
        return _build_pdf_order_record(
            source=source,
            filename=effective_filename,
            subtype=document_subtype,
            pages=pages,
            sections=sections,
            original_text=original_text,
            metadata=metadata,
            initial_issues=classification_issues,
        )
    if (
        document_type == "technical_document"
        and document_subtype == "approval_drawing"
    ):
        drawing_record = build_pdf_drawing_record(
            source=source,
            pages=pages,
            sections=sections,
            original_text=original_text,
            metadata=metadata,
            initial_issues=classification_issues,
        )
        return project_technical_document(drawing_record, filename=effective_filename)
    record = build_document_record(
        source=source,
        document_type=document_type,
        document_subtype=document_subtype,
        sections=sections,
        raw_content={
            "text_original": original_text,
            "text_normalized": nfkc_text(original_text),
            "pages": pages,
        },
        metadata=metadata,
        validation_issues=[
            issue.model_dump(mode="json") for issue in classification_issues
        ],
    )
    if document_type == "technical_document":
        return project_technical_document(record, filename=effective_filename)
    return record


def parse_pdf_document(
    path: str | Path,
    original_filename: str | None = None,
    *,
    doc_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    render_dir: str | Path | None = None,
    render_pages: bool = True,
    render_dpi: int = 150,
) -> Any:
    """Thread-safe public entry point for deterministic PDF parsing."""

    with _PDF_PARSE_LOCK:
        return _parse_pdf_document_unlocked(
            path,
            original_filename,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            render_dir=render_dir,
            render_pages=render_pages,
            render_dpi=render_dpi,
        )


def render_pdf_pages_for_ocr(
    path: str | Path,
    page_numbers: list[int] | set[int],
    *,
    render_dir: str | Path,
    dpi: int,
) -> dict[int, str]:
    """Render only selected 1-based pages at OCR resolution."""

    if dpi < 72 or dpi > 600:
        raise ValueError("OCR render dpi must be between 72 and 600")
    selected = sorted({int(number) for number in page_numbers if int(number) > 0})
    if not selected:
        return {}
    pdf_path = Path(path)
    target_dir = Path(render_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    fitz = _require_fitz()
    rendered: dict[int, str] = {}
    with _PDF_PARSE_LOCK:
        document = fitz.open(str(pdf_path))
        try:
            for page_number in selected:
                if page_number > len(document):
                    continue
                page = document[page_number - 1]
                target = target_dir / f"page-{page_number:04d}-ocr-{dpi}.png"
                page.get_pixmap(dpi=dpi, alpha=False).save(str(target))
                rendered[page_number] = str(target)
        finally:
            document.close()
    return rendered


class PDFDocumentAdapter:
    """Synchronous adapter entry point used by the document router."""

    supported_extensions = frozenset({".pdf"})

    def __init__(self, *, render_pages: bool = True, render_dpi: int = 150) -> None:
        self.render_pages = render_pages
        self.render_dpi = render_dpi

    def parse(self, path: str | Path, original_filename: str | None = None) -> Any:
        return parse_pdf_document(
            path,
            original_filename,
            render_pages=self.render_pages,
            render_dpi=self.render_dpi,
        )
