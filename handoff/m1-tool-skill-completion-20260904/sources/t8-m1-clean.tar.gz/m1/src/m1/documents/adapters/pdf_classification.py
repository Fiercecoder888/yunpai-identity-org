"""PDF classification and table-heading heuristics."""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from .common import nfkc_text
from .pdf_drawing import is_engineering_drawing_evidence
from m1.documents.models import ValidationIssue
from m1.documents.orders import HEADER_ALIASES


def _header_key(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).strip().upper()
    return re.sub(r"[\s\n\r:：()（）/\\·._-]+", "", text)


_PDF_HEADER_ALIASES: dict[str, str] = {
    _header_key(alias): standard
    for standard, aliases in HEADER_ALIASES.items()
    for alias in aliases
}


def _match_order_header(value: Any) -> str | None:
    """Map a PDF table heading to the v2 order line contract.

    PDF producers frequently insert line breaks or units into headings.  Exact
    aliases remain authoritative, while the small semantic fallback handles the
    common ``单价(含税)`` / ``金额(USD)`` variants without guessing row values.
    """

    key = _header_key(value)
    if not key:
        return None
    exact = _PDF_HEADER_ALIASES.get(key)
    if exact:
        return exact
    candidates = [
        (alias, standard)
        for alias, standard in _PDF_HEADER_ALIASES.items()
        if len(alias) >= 2 and (key.startswith(alias) or key.endswith(alias))
    ]
    if candidates:
        return max(candidates, key=lambda item: len(item[0]))[1]
    if "单价" in key or key in {"PRICE", "UNITPRICE"}:
        return (
            "unit_price_tax_included"
            if "含税" in key and "不含税" not in key
            else "unit_price_tax_excluded"
        )
    if "金额" in key or key in {"AMOUNT", "TOTALAMOUNT"}:
        return (
            "amount_tax_included"
            if "含税" in key and "不含税" not in key
            else "amount_tax_excluded"
        )
    return None


def _table_header_mapping(
    rows: list[list[Any]],
) -> tuple[int, dict[str, tuple[int, str]], dict[int, str]] | None:
    """Return the last header row and mapped/custom columns for an order table."""

    for row_index, row in enumerate(rows[:12]):
        width = len(row)
        variants: list[tuple[int, list[str]]] = [
            (row_index, [nfkc_text(str(cell or "")) for cell in row])
        ]
        if row_index + 1 < len(rows):
            next_row = rows[row_index + 1]
            combined = [
                f"{row[column] or ''}{next_row[column] if column < len(next_row) else ''}"
                for column in range(width)
            ]
            variants.append((row_index + 1, combined))
        for header_end, headings in variants:
            mapped: dict[str, tuple[int, str]] = {}
            custom: dict[int, str] = {}
            for column, heading in enumerate(headings):
                raw_heading = nfkc_text(str(heading or "")).strip()
                if not raw_heading:
                    continue
                standard = _match_order_header(raw_heading)
                if standard and standard not in mapped:
                    mapped[standard] = (column, raw_heading)
                else:
                    custom[column] = raw_heading
            standards = set(mapped)
            identity = standards.intersection(
                {"line_no", "model", "product_code", "name_raw", "specification_raw"}
            )
            if "quantity" in standards and identity and len(standards) >= 3:
                return header_end, mapped, custom
    return None


def _has_order_table(pages: list[dict[str, Any]] | None) -> bool:
    return bool(
        pages
        and any(
            _table_header_mapping(table.get("rows_normalized", [])) is not None
            for page in pages
            for table in page.get("tables", [])
        )
    )


def _classify_pdf(
    filename: str, text: str, pages: list[dict[str, Any]] | None = None
) -> tuple[str, str]:
    """Classify from filename, native text and table headings.

    Strong titles take precedence over incidental words in the body.  Unknown
    documents deliberately remain unknown instead of being labelled as drawings.
    """

    sample = f"{filename}\n{text[:8000]}".casefold()
    if "备货单" in sample:
        return "order", "stocking_order"
    if any(token in sample for token in ("客户采购订单", "customer purchase order")):
        return "order", "customer_purchase_order"
    if any(token in sample for token in ("采购合同", "购销合同", "purchase contract")):
        return "order", "purchase_contract"
    if any(
        token in sample
        for token in (
            "采购订单",
            "供应商采购订单",
            "供应商订单",
            "supplier purchase order",
        )
    ):
        return "order", "supplier_purchase_order"
    if any(token in sample for token in ("样品单", "样品申请", "sample request")):
        return "order", "sample_request"
    if any(token in sample for token in ("库存", "inventory")):
        return "inventory", "inventory_snapshot"
    if any(token in sample for token in ("设备台账", "设备一览", "equipment register")):
        return "equipment", "equipment_register"
    if any(token in sample for token in ("模具", "mold mapping")):
        return "mold", "mold_mapping"
    if any(token in sample for token in ("承认书", "承認書", "approval drawing")) or (
        "镭雕" in sample
        and any(token in sample for token in ("正面", "反面", "示图", "图示"))
    ):
        return "technical_document", "approval_drawing"
    if is_engineering_drawing_evidence(filename, text, pages):
        return "technical_document", "approval_drawing"
    if any(token in sample for token in ("规格书", "規格書", "specification", "datasheet")):
        return "technical_document", "product_specification"
    if any(token in sample for token in ("工艺", "流程", "process document")):
        return "technical_document", "process_document"
    if _has_order_table(pages):
        # A table containing quantity plus product identity is stronger evidence
        # than a generic filename.  Price/amount columns indicate procurement,
        # otherwise use the customer-order family as the neutral order subtype.
        has_price = any(
            field.startswith(("unit_price", "amount"))
            for page in pages or []
            for table in page.get("tables", [])
            for mapping in [_table_header_mapping(table.get("rows_normalized", []))]
            if mapping is not None
            for field in mapping[1]
        )
        return (
            "order",
            "supplier_purchase_order" if has_price else "customer_purchase_order",
        )
    if re.search(r"(?:销售订单|客户订单|\bpurchase\s+order\b|\border\b)", sample):
        return "order", "customer_purchase_order"
    return "unknown", "unknown"


def _classification_hint(value: str | None) -> str:
    normalized = re.sub(r"[\s-]+", "_", nfkc_text(value or "").strip().casefold())
    return normalized if re.fullmatch(r"[a-z][a-z0-9_]{0,63}", normalized) else ""


def _resolve_pdf_classification(
    detected_type: str,
    detected_subtype: str,
    *,
    doc_type_hint: str | None,
    document_subtype_hint: str | None,
) -> tuple[str, str, dict[str, Any], list[ValidationIssue]]:
    """Resolve advisory classification hints before subtype-dependent parsing."""

    resolved_type = detected_type
    resolved_subtype = detected_subtype
    issues: list[ValidationIssue] = []
    type_hint = _classification_hint(doc_type_hint)
    subtype_hint = _classification_hint(document_subtype_hint)

    if doc_type_hint and not type_hint:
        issues.append(
            ValidationIssue(
                code="DOCUMENT_TYPE_HINT_INVALID",
                severity="warning",
                message="文档类型提示格式无效，已忽略。",
                paths=["$.document_type"],
                actual=doc_type_hint,
            )
        )
    elif type_hint:
        if detected_type in {"", "unknown"}:
            resolved_type = type_hint
        elif detected_type != type_hint:
            issues.append(
                ValidationIssue(
                    code="DOCUMENT_TYPE_HINT_CONFLICT",
                    severity="warning",
                    message="文档类型提示与确定性分类冲突，已保留确定性分类。",
                    paths=["$.document_type"],
                    expected=detected_type,
                    actual=type_hint,
                )
            )

    if document_subtype_hint and not subtype_hint:
        issues.append(
            ValidationIssue(
                code="DOCUMENT_SUBTYPE_HINT_INVALID",
                severity="warning",
                message="文档子类型提示格式无效，已忽略。",
                paths=["$.document_subtype"],
                actual=document_subtype_hint,
            )
        )
    elif subtype_hint:
        if detected_subtype not in {"", "unknown", subtype_hint}:
            issues.append(
                ValidationIssue(
                    code="DOCUMENT_SUBTYPE_HINT_CONFLICT",
                    severity="warning",
                    message="文档子类型提示与确定性分类冲突，已采用显式提示并保留冲突证据。",
                    paths=["$.document_subtype"],
                    expected=detected_subtype,
                    actual=subtype_hint,
                )
            )
        resolved_subtype = subtype_hint

    metadata = {
        "detected_document_type": detected_type,
        "detected_document_subtype": detected_subtype,
        "hinted_document_type": type_hint or None,
        "hinted_document_subtype": subtype_hint or None,
        "resolved_document_type": resolved_type,
        "resolved_document_subtype": resolved_subtype,
    }
    return resolved_type, resolved_subtype, metadata, issues
