"""Deterministic engineering-drawing classification and business projection.

Engineering PDFs often expose excellent native text while representing the whole
sheet as one rotated table.  This module consumes the existing page/block/table
evidence and maps only facts with a source location into ``m1.document.v2``.  It
does not guess missing title-block or BOM values; incomplete rows remain visible
and are routed to review.
"""

from __future__ import annotations

import re
import unicodedata
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Iterable

from m1.documents.models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from .pdf_drawing_evidence import (
    _ALL_LABELS,
    _CODE_RE,
    _COMPANY_RE,
    _CUSTOMER_CODE_LABELS,
    _CUSTOMER_MATERIAL_LABELS,
    _DATE_RE,
    _DRAWING_NAME_LABELS,
    _DRAWING_NUMBER_LABELS,
    _ENGLISH_COMPANY_RE,
    _MATERIAL_NUMBER_LABELS,
    _PAGE_LABELS,
    _QUANTITY_RE,
    _SCALE_LABELS,
    _UNIT_LABELS,
    _Entry,
    _entries,
    _key,
    _present,
    _ref,
    _text,
    is_engineering_drawing_evidence,
)


def _labeled_tail(value: str, labels: Iterable[str]) -> str | None:
    normalized = unicodedata.normalize("NFKC", value)
    for label in sorted(labels, key=len, reverse=True):
        match = re.search(re.escape(label), normalized, flags=re.IGNORECASE)
        if not match:
            continue
        tail = normalized[match.end() :]
        tail = re.split(r"[\n\r]", tail, maxsplit=1)[0]
        tail = re.sub(r"^[\s:：=\-]+", "", tail).strip()
        if _present(tail):
            return tail
    return None


def _find_labeled(
    entries: list[_Entry],
    labels: Iterable[str],
    *,
    validator: Callable[[str], bool] | None = None,
    reject_labels: Iterable[str] = (),
) -> tuple[str | None, SourceReference | None, float]:
    reject = tuple(value.casefold() for value in reject_labels)
    for entry in entries:
        folded = _text(entry.text).casefold()
        if any(value in folded for value in reject):
            continue
        tail = _labeled_tail(entry.text, labels)
        if tail is None:
            continue
        value = _text(tail)
        if validator is not None and not validator(value):
            continue
        return value, entry.ref, entry.confidence
    return None, None, 0.0


def _row_cells(
    pages: list[dict[str, Any]],
) -> Iterable[tuple[int, int, list[Any], list[Any], int]]:
    for page_index, page in enumerate(pages):
        page_number = int(page.get("page_number") or page_index + 1)
        for table_position, table in enumerate(page.get("tables") or []):
            if not isinstance(table, dict):
                continue
            table_index = int(table.get("table_index") or table_position)
            boxes = table.get("cell_bbox_matrix") or []
            for row_index, row in enumerate(table.get("rows_normalized") or []):
                if isinstance(row, list):
                    row_boxes = boxes[row_index] if row_index < len(boxes) else []
                    yield page_number, table_index, row, row_boxes, row_index


def _row_peer_value(
    pages: list[dict[str, Any]],
    labels: Iterable[str],
    scorer: Callable[[str], float],
) -> tuple[str | None, SourceReference | None, float]:
    label_keys = tuple(_key(label) for label in labels)
    for page_number, table_index, row, boxes, row_index in _row_cells(pages):
        label_columns = [
            index
            for index, cell in enumerate(row)
            if any(label in _key(cell) for label in label_keys)
        ]
        if not label_columns:
            continue
        ranked: list[tuple[float, int, str]] = []
        for column, cell in enumerate(row):
            value = _text(cell)
            if not value or column in label_columns:
                continue
            score = scorer(value)
            if score > 0:
                ranked.append((score, column, value))
        if not ranked:
            continue
        _, column, value = max(ranked)
        bbox = boxes[column] if isinstance(boxes, list) and column < len(boxes) else None
        return (
            value,
            _ref(
                page=page_number,
                part=f"table:{table_index}/row:{row_index}/column:{column}",
                bbox=bbox,
            ),
            0.99,
        )
    return None, None, 0.0


def _vertical_table_value(
    pages: list[dict[str, Any]],
    labels: Iterable[str],
    validator: Callable[[str], bool],
) -> tuple[str | None, SourceReference | None, float]:
    label_keys = tuple(_key(label) for label in labels)
    for page_index, page in enumerate(pages):
        page_number = int(page.get("page_number") or page_index + 1)
        for table_position, table in enumerate(page.get("tables") or []):
            rows = table.get("rows_normalized") or []
            boxes = table.get("cell_bbox_matrix") or []
            table_index = int(table.get("table_index") or table_position)
            for row_index, row in enumerate(rows):
                if not isinstance(row, list):
                    continue
                for column, cell in enumerate(row):
                    if not any(label in _key(cell) for label in label_keys):
                        continue
                    direct = _labeled_tail(str(cell or ""), labels)
                    if direct and validator(_text(direct)):
                        return (
                            _text(direct),
                            _ref(
                                page=page_number,
                                part=f"table:{table_index}/row:{row_index}/column:{column}",
                                bbox=(
                                    boxes[row_index][column]
                                    if row_index < len(boxes)
                                    and column < len(boxes[row_index])
                                    else None
                                ),
                            ),
                            0.99,
                        )
                    for next_row in range(row_index + 1, min(row_index + 4, len(rows))):
                        candidate_row = rows[next_row]
                        if not isinstance(candidate_row, list) or column >= len(candidate_row):
                            continue
                        candidate = _text(candidate_row[column])
                        if not validator(candidate):
                            continue
                        return (
                            candidate,
                            _ref(
                                page=page_number,
                                part=f"table:{table_index}/row:{next_row}/column:{column}",
                                bbox=(
                                    boxes[next_row][column]
                                    if next_row < len(boxes)
                                    and column < len(boxes[next_row])
                                    else None
                                ),
                            ),
                            0.99,
                        )
    return None, None, 0.0


def _is_code(value: str) -> bool:
    normalized = _text(value)
    return bool(_CODE_RE.fullmatch(normalized)) and not _DATE_RE.fullmatch(normalized)


def _is_drawing_number(value: str) -> bool:
    normalized = _text(value)
    return bool(
        _present(normalized)
        and len(normalized) <= 64
        and "<" not in normalized
        and ">" not in normalized
        and re.fullmatch(r"[A-Za-z0-9\u4e00-\u9fff._/+\-]+", normalized)
        and re.search(r"[A-Za-z0-9\u4e00-\u9fff]", normalized)
    )


def _quantity(value: str) -> tuple[Decimal | int | None, str | None, str]:
    normalized = _text(value)
    match = _QUANTITY_RE.fullmatch(normalized)
    if not match:
        return None, None, normalized
    try:
        number = Decimal(match.group(1).replace(",", "."))
    except InvalidOperation:
        return None, None, normalized
    numeric: Decimal | int = int(number) if number == number.to_integral() else number
    return numeric, match.group(2), normalized


def _bom_from_block(entry: _Entry) -> dict[str, Any] | None:
    lines = [_text(line) for line in str(entry.text).splitlines() if _text(line)]
    if len(lines) < 3:
        return None

    index: int | None = None
    code: str | None = None
    raw_quantity = ""
    description: list[str] = []
    if lines[0].isdigit() and _is_code(lines[1]) and _quantity(lines[2])[0] is not None:
        index = int(lines[0])
        code = lines[1]
        raw_quantity = lines[2]
        description = lines[3:]
    elif (
        lines[-1].isdigit()
        and _is_code(lines[-3])
        and _quantity(lines[-2])[0] is not None
    ):
        index = int(lines[-1])
        code = lines[-3]
        raw_quantity = lines[-2]
        description = lines[:-3]
    if index is None or code is None or index <= 0 or index > 999:
        return None
    quantity, unit, _ = _quantity(raw_quantity)
    return {
        "index": index,
        "code": code,
        "quantity": quantity,
        "unit": unit,
        "raw_quantity": raw_quantity,
        "description": _text(" ".join(description)) or None,
        "ref": entry.ref,
        "refs": {
            field: entry.ref
            for field in ("index", "code", "quantity", "unit", "description")
        },
        "confidence": entry.confidence,
    }


def _header_map(row: list[Any]) -> dict[str, int]:
    aliases = {
        "index": ("序号", "item", "item no", "no"),
        "code": ("料号", "物料编码", "part no", "part number", "material no"),
        "quantity": ("用量", "数量", "qty", "quantity"),
        "unit": ("单位", "unit"),
        "description": ("规格描述", "描述", "description", "specification"),
    }
    mapping: dict[str, int] = {}
    for column, value in enumerate(row):
        cell_key = _key(value)
        for field, values in aliases.items():
            if field not in mapping and any(_key(alias) == cell_key for alias in values):
                mapping[field] = column
    return mapping


def _bom_from_tables(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for page_index, page in enumerate(pages):
        page_number = int(page.get("page_number") or page_index + 1)
        for table_position, table in enumerate(page.get("tables") or []):
            if not isinstance(table, dict):
                continue
            rows = table.get("rows_normalized") or []
            table_index = int(table.get("table_index") or table_position)
            boxes = table.get("cell_bbox_matrix") or []
            for header_index, row in enumerate(rows[:12]):
                if not isinstance(row, list):
                    continue
                mapping = _header_map(row)
                if not {"index", "code", "quantity"}.issubset(mapping):
                    continue
                for row_index in range(header_index + 1, len(rows)):
                    values = rows[row_index]
                    if not isinstance(values, list):
                        continue

                    def cell(field: str) -> str:
                        column = mapping.get(field, -1)
                        return _text(values[column]) if 0 <= column < len(values) else ""

                    raw_index, code, raw_quantity = (
                        cell("index"),
                        cell("code"),
                        cell("quantity"),
                    )
                    if not raw_index.isdigit() or not _is_code(code):
                        continue
                    quantity, embedded_unit, _ = _quantity(raw_quantity)
                    if quantity is None:
                        continue
                    def field_ref(field: str) -> SourceReference:
                        source_column = mapping.get(field, mapping["quantity"])
                        bbox = (
                            boxes[row_index][source_column]
                            if row_index < len(boxes)
                            and source_column < len(boxes[row_index])
                            else None
                        )
                        return _ref(
                            page=page_number,
                            part=(
                                f"table:{table_index}/row:{row_index}/"
                                f"column:{source_column}"
                            ),
                            bbox=bbox,
                        )

                    refs = {
                        field: field_ref(field)
                        for field in ("index", "code", "quantity")
                    }
                    refs["unit"] = (
                        field_ref("unit") if "unit" in mapping else refs["quantity"]
                    )
                    if "description" in mapping:
                        refs["description"] = field_ref("description")
                    result.append(
                        {
                            "index": int(raw_index),
                            "code": code,
                            "quantity": quantity,
                            "unit": cell("unit") or embedded_unit,
                            "raw_quantity": raw_quantity,
                            "description": cell("description") or None,
                            "ref": refs["code"],
                            "refs": refs,
                            "confidence": 0.75 if table.get("ocr_derived") else 0.99,
                        }
                    )
                break

            # Rotated engineering title blocks commonly expose BOM headings down
            # the first column and items across columns.
            row_mapping: dict[str, int] = {}
            for row_index, row in enumerate(rows):
                if not isinstance(row, list):
                    continue
                for value in row:
                    key = _key(value)
                    for field, aliases in {
                        "index": ("序号", "item", "itemno"),
                        "code": ("料号", "partno", "partnumber"),
                        "quantity": ("用量", "数量", "qty", "quantity"),
                        "description": ("规格描述", "description", "specification"),
                    }.items():
                        if field not in row_mapping and any(_key(alias) == key for alias in aliases):
                            row_mapping[field] = row_index
            if not {"index", "code", "quantity"}.issubset(row_mapping):
                continue
            width = max((len(row) for row in rows), default=0)
            for column in range(width):
                values: dict[str, str] = {}
                for field, row_index in row_mapping.items():
                    row = rows[row_index]
                    values[field] = _text(row[column]) if column < len(row) else ""
                if not values["index"].isdigit() or not _is_code(values["code"]):
                    continue
                quantity, unit, _ = _quantity(values["quantity"])
                if quantity is None:
                    continue
                def field_ref(field: str) -> SourceReference:
                    source_row = row_mapping.get(field, row_mapping["quantity"])
                    bbox = (
                        boxes[source_row][column]
                        if source_row < len(boxes) and column < len(boxes[source_row])
                        else None
                    )
                    return _ref(
                        page=page_number,
                        part=(
                            f"table:{table_index}/row:{source_row}/column:{column}"
                        ),
                        bbox=bbox,
                    )

                refs = {
                    field: field_ref(field)
                    for field in ("index", "code", "quantity")
                }
                refs["unit"] = refs["quantity"]
                if "description" in row_mapping:
                    refs["description"] = field_ref("description")
                result.append(
                    {
                        "index": int(values["index"]),
                        "code": values["code"],
                        "quantity": quantity,
                        "unit": unit,
                        "raw_quantity": values["quantity"],
                        "description": values.get("description") or None,
                        "ref": refs["code"],
                        "refs": refs,
                        "confidence": 0.75 if table.get("ocr_derived") else 0.99,
                    }
                )
    return result


def _bom_items(
    pages: list[dict[str, Any]], entries: list[_Entry]
) -> list[dict[str, Any]]:
    candidates = [
        item for item in (_bom_from_block(entry) for entry in entries) if item is not None
    ]
    candidates.extend(_bom_from_tables(pages))
    merged: dict[tuple[int, str], dict[str, Any]] = {}
    for item in candidates:
        key = (int(item["index"]), str(item["code"]))
        current = merged.get(key)
        if current is None:
            merged[key] = item
            continue
        for field in ("quantity", "unit", "raw_quantity", "description"):
            if not _present(current.get(field)) and _present(item.get(field)):
                current[field] = item[field]
                source_field = "quantity" if field == "raw_quantity" else field
                source_ref = (item.get("refs") or {}).get(source_field)
                if source_ref is not None:
                    current.setdefault("refs", {})[source_field] = source_ref
        if float(item.get("confidence") or 0.0) > float(current.get("confidence") or 0.0):
            current["ref"] = item["ref"]
            current["confidence"] = item["confidence"]
    return sorted(merged.values(), key=lambda item: (int(item["index"]), str(item["code"])))


def _revision_history(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    label_aliases = {
        "version": ("版本", "revision", "rev"),
        "date": ("日期", "date"),
        "change_content": ("变更内容", "change content", "description"),
        "mark": ("标记", "mark"),
        "ecn": ("ecn号码", "ecn"),
        "design_by": ("变更人", "changed by", "drawn by"),
    }
    for page in pages:
        for table in page.get("tables") or []:
            rows = table.get("rows_normalized") or []
            mapped: dict[str, tuple[int, int]] = {}
            for row_index, row in enumerate(rows):
                if not isinstance(row, list):
                    continue
                for column, value in enumerate(row):
                    key = _key(value)
                    for field, aliases in label_aliases.items():
                        if field not in mapped and any(_key(alias) == key for alias in aliases):
                            mapped[field] = (row_index, column)
            if "version" not in mapped or "date" not in mapped:
                continue
            version_row, label_column = mapped["version"]
            versions = rows[version_row]
            result: list[dict[str, Any]] = []
            for column, raw_version in enumerate(versions):
                version = _text(raw_version)
                if column == label_column or not re.fullmatch(r"[A-Za-z0-9]{1,4}", version):
                    continue
                revision: dict[str, Any] = {"version": version}
                for field, (row_index, _) in mapped.items():
                    if field == "version" or column >= len(rows[row_index]):
                        continue
                    value = _text(rows[row_index][column])
                    if _present(value):
                        revision[field] = value
                result.append(revision)
            if result:
                return result
    return []


def _name_score(value: str) -> float:
    normalized = _text(value)
    folded = normalized.casefold()
    if len(normalized) < 5 or any(_key(label) in _key(normalized) for label in _ALL_LABELS):
        return 0.0
    if _COMPANY_RE.search(normalized) or _ENGLISH_COMPANY_RE.search(normalized):
        return 0.0
    if _DATE_RE.fullmatch(normalized) or _is_code(normalized):
        return 0.0
    bonus = 10.0 if any(token in folded for token in ("cable", "assembly", "product", "线", "组件")) else 0.0
    return bonus + min(len(normalized), 200) / 100.0


def _company(entries: list[_Entry]) -> tuple[str | None, SourceReference | None, float]:
    for entry in entries:
        for line in str(entry.text).splitlines():
            normalized = _text(line)
            match = _COMPANY_RE.search(normalized) or _ENGLISH_COMPANY_RE.search(normalized)
            if match:
                return _text(match.group(1)), entry.ref, entry.confidence
    return None, None, 0.0


def _technical_requirements(
    entries: list[_Entry],
) -> tuple[str | None, SourceReference | None, float]:
    candidates = [
        entry
        for entry in entries
        if any(
            token in _text(entry.text).casefold()
            for token in ("测试条件", "技术要求", "test requirements", "technical requirements")
        )
    ]
    if not candidates:
        return None, None, 0.0
    selected = max(candidates, key=lambda entry: len(_text(entry.text)))
    return _text(selected.text), selected.ref, selected.confidence


def _meta(ref: SourceReference | None, confidence: float) -> FieldMetadata | None:
    if ref is None:
        return None
    return FieldMetadata(source_refs=[ref], confidence=max(0.0, min(confidence, 1.0)))


def _localized_value_ref(
    entries: list[_Entry],
    value: Any,
    current: SourceReference | None,
    confidence: float,
) -> tuple[SourceReference | None, float]:
    """Prefer a text block with a real bbox over a table-only logical locator."""

    if current is not None and (current.model_extra or {}).get("bbox"):
        return current, confidence
    target = _text(value)
    if not target:
        return current, confidence
    exact: list[_Entry] = []
    containing: list[_Entry] = []
    for entry in entries:
        lines = [_text(line) for line in str(entry.text).splitlines() if _text(line)]
        if target in lines:
            exact.append(entry)
        elif target in _text(entry.text):
            containing.append(entry)
    candidates = exact or containing
    if not candidates:
        return current, confidence
    boxed = [
        entry for entry in candidates if (entry.ref.model_extra or {}).get("bbox")
    ]
    candidates = boxed or candidates
    selected = min(candidates, key=lambda entry: len(_text(entry.text)))
    return selected.ref, selected.confidence


def build_pdf_drawing_record(
    *,
    source: dict[str, Any],
    pages: list[dict[str, Any]],
    sections: list[dict[str, Any]],
    original_text: str,
    metadata: dict[str, Any],
    initial_issues: list[ValidationIssue] | None = None,
) -> DocumentRecord:
    """Map title-block, BOM and requirements evidence into ``DocumentRecord``."""

    entries = _entries(pages)
    field_meta: dict[str, FieldMetadata] = {}
    issues = list(initial_issues or [])

    def scalar(
        labels: Iterable[str],
        *,
        validator: Callable[[str], bool] | None = None,
        reject_labels: Iterable[str] = (),
    ) -> tuple[str | None, SourceReference | None, float]:
        return _find_labeled(
            entries,
            labels,
            validator=validator,
            reject_labels=reject_labels,
        )

    drawing_number, drawing_number_ref, drawing_number_conf = scalar(
        _DRAWING_NUMBER_LABELS, validator=_is_drawing_number
    )
    material_number, material_ref, material_conf = scalar(
        _MATERIAL_NUMBER_LABELS,
        validator=_is_code,
        reject_labels=_CUSTOMER_MATERIAL_LABELS,
    )
    customer_material, customer_material_ref, customer_material_conf = scalar(
        _CUSTOMER_MATERIAL_LABELS, validator=_is_code
    )
    customer_code, customer_code_ref, customer_code_conf = scalar(
        _CUSTOMER_CODE_LABELS, validator=lambda value: 2 <= len(value) <= 64
    )
    drawing_name, drawing_name_ref, drawing_name_conf = scalar(
        _DRAWING_NAME_LABELS, validator=lambda value: _name_score(value) > 0
    )
    if not drawing_name:
        drawing_name, drawing_name_ref, drawing_name_conf = _row_peer_value(
            pages, _DRAWING_NAME_LABELS, _name_score
        )
    company, company_ref, company_conf = _company(entries)

    unit, unit_ref, unit_conf = _vertical_table_value(
        pages,
        _UNIT_LABELS,
        lambda value: bool(re.fullmatch(r"[A-Za-z\u4e00-\u9fff]{1,12}", value)),
    )
    page_label, page_ref, page_conf = _vertical_table_value(
        pages,
        _PAGE_LABELS,
        lambda value: bool(re.fullmatch(r"\d+\s*(?:of|/)?\s*\d*", value, re.IGNORECASE)),
    )
    scale, scale_ref, scale_conf = _vertical_table_value(
        pages,
        _SCALE_LABELS,
        lambda value: bool(re.fullmatch(r"(?:free|n/?a|\d+\s*:\s*\d+)", value, re.IGNORECASE)),
    )

    revisions = _revision_history(pages)
    version = str(revisions[0].get("version") or "") if revisions else ""
    version_ref: SourceReference | None = None
    version_conf = 0.0
    if version and revisions:
        revision_date = str(revisions[0].get("date") or "")
        for entry in entries:
            lines = [_text(line) for line in str(entry.text).splitlines() if _text(line)]
            if (
                lines
                and lines[0].casefold() == version.casefold()
                and (not revision_date or revision_date in _text(entry.text))
            ):
                version_ref = entry.ref
                version_conf = entry.confidence
                break
    if not version:
        version, version_ref, version_conf = scalar(
            ("version", "revision", "rev", "版本"),
            validator=lambda value: bool(re.fullmatch(r"[A-Za-z0-9]{1,4}", value)),
        )
    design_date = ""
    drawn_by = ""
    design_ref: SourceReference | None = None
    design_conf = 0.0
    for entry in entries:
        compact = _text(entry.text)
        date_match = _DATE_RE.search(compact)
        if not date_match:
            continue
        if any(token in compact.casefold() for token in ("绘图", "drawn", "design")):
            design_date = date_match.group(1)
            design_ref = entry.ref
            design_conf = entry.confidence
            before_date = compact[: date_match.start()]
            names = re.findall(r"\b[A-Za-z][A-Za-z0-9._-]{1,30}\b", before_date)
            names = [
                name
                for name in names
                if name.casefold() not in {"drawn", "by", "date", "design"}
            ]
            if names:
                drawn_by = names[-1]
            break
    if not design_date and revisions:
        design_date = str(revisions[0].get("date") or "")
    if not drawn_by and revisions:
        drawn_by = str(revisions[0].get("design_by") or "")

    drawing_name_ref, drawing_name_conf = _localized_value_ref(
        entries, drawing_name, drawing_name_ref, drawing_name_conf
    )
    company_ref, company_conf = _localized_value_ref(
        entries, company, company_ref, company_conf
    )
    material_ref, material_conf = _localized_value_ref(
        entries, material_number, material_ref, material_conf
    )
    customer_material_ref, customer_material_conf = _localized_value_ref(
        entries,
        customer_material,
        customer_material_ref,
        customer_material_conf,
    )
    customer_code_ref, customer_code_conf = _localized_value_ref(
        entries, customer_code, customer_code_ref, customer_code_conf
    )
    unit_ref, unit_conf = _localized_value_ref(entries, unit, unit_ref, unit_conf)
    page_ref, page_conf = _localized_value_ref(
        entries, page_label, page_ref, page_conf
    )
    scale_ref, scale_conf = _localized_value_ref(entries, scale, scale_ref, scale_conf)
    version_ref, version_conf = _localized_value_ref(
        entries, version, version_ref, version_conf
    )
    design_ref, design_conf = _localized_value_ref(
        entries, design_date or drawn_by, design_ref, design_conf
    )

    title_block = {
        "drawing_number": drawing_number,
        "drawing_name": drawing_name,
        "material_number": material_number,
        "customer_material_number": customer_material,
        "customer_code": customer_code,
        "scale": scale,
        "unit": unit,
        "design_by": drawn_by or None,
        "design_date": design_date or None,
        "company": company,
        "version": version or None,
        "page": page_label,
    }
    header = DocumentHeader(
        title=drawing_name,
        issuer=company,
        drawing_number=drawing_number,
        material_number=material_number,
        customer_material_number=customer_material,
        customer_code=customer_code,
        scale=scale,
        unit=unit,
        drawn_by=drawn_by or None,
        drawing_date=design_date or None,
        version=version or None,
        page_label=page_label,
    )
    for path, ref_value, confidence in (
        ("$.header.title", drawing_name_ref, drawing_name_conf),
        ("$.header.issuer", company_ref, company_conf),
        ("$.header.drawing_number", drawing_number_ref, drawing_number_conf),
        ("$.header.material_number", material_ref, material_conf),
        ("$.header.customer_material_number", customer_material_ref, customer_material_conf),
        ("$.header.customer_code", customer_code_ref, customer_code_conf),
        ("$.header.unit", unit_ref, unit_conf),
        ("$.header.scale", scale_ref, scale_conf),
        ("$.header.page_label", page_ref, page_conf),
        ("$.header.version", version_ref, version_conf),
        ("$.header.drawing_date", design_ref, design_conf),
        ("$.header.drawn_by", design_ref, design_conf),
    ):
        value = _meta(ref_value, confidence)
        if value is not None:
            field_meta[path] = value

    bom_items = _bom_items(pages, entries)
    lines: list[OrderLine] = []
    missing_descriptions: list[int] = []
    missing_description_paths: list[str] = []
    for item in bom_items:
        index = int(item["index"])
        description = item.get("description")
        refs = item.get("refs") if isinstance(item.get("refs"), dict) else {}
        anchor_ref = refs.get("code") or item["ref"]
        if not description:
            missing_descriptions.append(index)
        line = OrderLine(
            line_id=f"drawing:{anchor_ref.page}:{index}:{item['code']}",
            line_no=index,
            product_code=str(item["code"]),
            name_raw=description,
            specification_raw=description,
            quantity=item.get("quantity"),
            unit=item.get("unit"),
            custom_fields={
                "drawing_item_index": index,
                "raw_quantity": item.get("raw_quantity"),
            },
            raw_columns={
                "index": index,
                "code": item.get("code"),
                "quantity": item.get("raw_quantity"),
                "description": description,
            },
        )
        line_index = len(lines)
        lines.append(line)
        if not description:
            missing_description_paths.append(f"$.lines[{line_index}].name_raw")
        for field, source_field in (
            ("line_no", "index"),
            ("product_code", "code"),
            ("quantity", "quantity"),
            ("unit", "unit"),
        ):
            source_ref = refs.get(source_field) or anchor_ref
            field_meta[f"$.lines[{line_index}].{field}"] = FieldMetadata(
                source_refs=[source_ref],
                confidence=float(item.get("confidence") or 0.75),
            )
        if description:
            for field in ("name_raw", "specification_raw"):
                field_meta[f"$.lines[{line_index}].{field}"] = FieldMetadata(
                    source_refs=[refs.get("description") or anchor_ref],
                    confidence=float(item.get("confidence") or 0.75),
                )

    requirements, requirements_ref, requirements_conf = _technical_requirements(entries)
    requirements_meta = _meta(requirements_ref, requirements_conf)
    if requirements_meta is not None:
        field_meta["$.technical_requirements"] = requirements_meta

    if not drawing_name:
        issues.append(
            ValidationIssue(
                code="DRAWING_NAME_MISSING",
                severity="warning",
                message="工程图标题栏未找到有证据的位置对应的品名或图名。",
                paths=["$.header.title"],
                suggestion="请人工确认标题栏，或提供更高分辨率页面。",
            )
        )
    if not drawing_number:
        issues.append(
            ValidationIssue(
                code="DRAWING_NUMBER_MISSING",
                severity="warning",
                message="工程图标题栏的图号为空或仅为占位符。",
                paths=["$.header.drawing_number"],
                suggestion="请人工确认图号；不得从料号推断图号。",
            )
        )
    if not lines:
        issues.append(
            ValidationIssue(
                code="DRAWING_BOM_EMPTY",
                severity="warning",
                message="检测到工程图，但未形成具有来源证据的 BOM 明细。",
                paths=["$.lines"],
                suggestion="请检查旋转方向、标题栏布局或人工复核。",
            )
        )
    if missing_descriptions:
        issues.append(
            ValidationIssue(
                code="DRAWING_BOM_DESCRIPTION_MISSING",
                severity="warning",
                message="部分 BOM 行已识别料号和用量，但规格描述无法可靠拆分。",
                paths=missing_description_paths,
                actual=missing_descriptions,
                suggestion="请人工核对合并单元格中的规格描述。",
            )
        )

    metadata = dict(metadata)
    metadata["drawing_mapping"] = {
        "strategy": "native-evidence",
        "title_field_count": sum(_present(value) for value in title_block.values()),
        "bom_item_count": len(lines),
        "technical_requirements_present": bool(requirements),
        "revision_count": len(revisions),
    }
    extraction = {
        "sections": sections,
        "raw_content": {
            "text_original": original_text,
            "text_normalized": unicodedata.normalize("NFKC", original_text),
            "pages": pages,
        },
        "metadata": metadata,
        "title_block": title_block,
        "technical_requirements": requirements,
        "revision_history": revisions,
    }
    fields = [
        {"name": f"title_block.{name}", "value": value}
        for name, value in title_block.items()
    ]
    fields.append({"name": "technical_requirements", "value": requirements})
    return DocumentRecord(
        source=DocumentSource.model_validate(source),
        document_type="technical_document",
        document_subtype="approval_drawing",
        header=header,
        lines=lines,
        field_meta=field_meta,
        validation_issues=issues,
        needs_review=any(issue.severity in {"warning", "error"} for issue in issues),
        extraction=extraction,
        fields=fields,
        title_block=title_block,
        technical_requirements=requirements,
        revision_history=revisions,
    )


__all__ = ["build_pdf_drawing_record", "is_engineering_drawing_evidence"]
