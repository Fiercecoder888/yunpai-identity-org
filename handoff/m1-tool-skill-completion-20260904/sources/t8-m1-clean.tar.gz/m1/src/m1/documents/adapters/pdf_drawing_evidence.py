"""Shared evidence primitives for deterministic engineering-drawing parsing."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Any

from m1.documents.models import SourceReference


_SPACE_RE = re.compile(r"\s+")
_PLACEHOLDERS = {"", "/", "-", "--", "n/a", "na", "none", "null"}
_CODE_RE = re.compile(r"(?=.*\d)^[A-Za-z0-9][A-Za-z0-9._/+\-]{2,63}$")
_QUANTITY_RE = re.compile(
    r"^\s*(\d+(?:[.,]\d+)?)\s*"
    r"(pcs?|pieces?|个|件|套|支|只|条|米|毫米|mm|cm|m|g|kg|克|千克)?\s*$",
    re.IGNORECASE,
)
_DATE_RE = re.compile(r"\b(20\d{2}[./-]\d{1,2}[./-]\d{1,2})\b")
_COMPANY_RE = re.compile(
    r"([\u4e00-\u9fffA-Za-z0-9（）()·&\-]{2,}(?:股份有限公司|有限责任公司|有限公司))"
)
_ENGLISH_COMPANY_RE = re.compile(
    r"([A-Za-z][A-Za-z0-9 .,&'()\-]{2,}?(?:Co\.?\s*,?\s*Ltd\.?|Corporation|Corp\.?))",
    re.IGNORECASE,
)

_DRAWING_NUMBER_LABELS = ("drawing number", "drawing no", "dwg no", "图号")
_DRAWING_NAME_LABELS = (
    "product name",
    "drawing name",
    "part name",
    "产品名称",
    "图名",
    "品名",
)
_MATERIAL_NUMBER_LABELS = (
    "material number",
    "material no",
    "part number",
    "part no",
    "物料编号",
    "料号",
)
_CUSTOMER_MATERIAL_LABELS = (
    "customer material number",
    "customer material no",
    "customer part number",
    "customer p/n",
    "客户物料编号",
    "客户料号",
)
_CUSTOMER_CODE_LABELS = ("customer code", "客户代码", "户代码")
_UNIT_LABELS = ("unit", "单位")
_PAGE_LABELS = ("page", "页次", "页码")
_SCALE_LABELS = ("scale", "比例")

_ALL_LABELS = tuple(
    dict.fromkeys(
        (
            *_DRAWING_NUMBER_LABELS,
            *_DRAWING_NAME_LABELS,
            *_MATERIAL_NUMBER_LABELS,
            *_CUSTOMER_MATERIAL_LABELS,
            *_CUSTOMER_CODE_LABELS,
            *_UNIT_LABELS,
            *_PAGE_LABELS,
            *_SCALE_LABELS,
            "version",
            "revision",
            "版本",
            "date",
            "日期",
            "drawn by",
            "绘图",
            "approved by",
            "核准",
            "序号",
            "item",
            "description",
            "规格描述",
            "用量",
            "quantity",
            "qty",
        )
    )
)


def _text(value: Any) -> str:
    return _SPACE_RE.sub(" ", unicodedata.normalize("NFKC", str(value or ""))).strip()


def _key(value: Any) -> str:
    return re.sub(r"[\s:：/\\._\-()（）]+", "", _text(value).casefold())


def _present(value: Any) -> bool:
    return _text(value).casefold() not in _PLACEHOLDERS


def _page_text(pages: list[dict[str, Any]] | None) -> str:
    values: list[str] = []
    for page in pages or []:
        values.append(str(page.get("text_normalized") or page.get("text_original") or ""))
        for table in page.get("tables") or []:
            for row in table.get("rows_normalized") or []:
                values.extend(str(cell or "") for cell in row)
    return "\n".join(values)


def is_engineering_drawing_evidence(
    filename: str,
    text: str,
    pages: list[dict[str, Any]] | None = None,
) -> bool:
    """Return true only for a coherent engineering-drawing signature.

    Generic ``date/version/unit`` occurrences are intentionally insufficient.
    A drawing-specific anchor must be accompanied by title-block, BOM or revision
    evidence so ordinary specifications and purchase tables are not relabelled.
    """

    sample = _text(f"{filename}\n{text[:16000]}\n{_page_text(pages)[:16000]}").casefold()
    drawing_anchors = sum(
        token in sample
        for token in (
            "图号",
            "绘图",
            "未注尺寸公差",
            "版本变更记录",
            "drawing number",
            "drawing no",
            "drawn by",
            "general tolerance",
            "revision history",
            "standard cable wiring",
        )
    )
    title_anchors = sum(
        token in sample
        for token in (
            "品名",
            "客户料号",
            "客户代码",
            "料号",
            "核准",
            "审核",
            "比例",
            "product name",
            "customer part number",
            "customer p/n",
            "part number",
            "approved by",
            "scale",
        )
    )
    bom_anchors = sum(
        token in sample
        for token in (
            "序号",
            "用量",
            "规格描述",
            "item",
            "qty",
            "quantity",
            "description",
        )
    )
    return drawing_anchors >= 2 and (title_anchors >= 2 or bom_anchors >= 3)


@dataclass(slots=True)
class _Entry:
    text: str
    ref: SourceReference
    confidence: float = 0.99


def _ref(
    *,
    page: int,
    part: str,
    bbox: Any = None,
    coordinate_space: str = "pdf_points",
) -> SourceReference:
    payload: dict[str, Any] = {"page": page, "part": part}
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        payload["bbox"] = [round(float(value), 4) for value in bbox[:4]]
        payload["coordinate_space"] = coordinate_space
    return SourceReference.model_validate(payload)


def _entries(pages: list[dict[str, Any]]) -> list[_Entry]:
    result: list[_Entry] = []
    for page_index, page in enumerate(pages):
        page_number = int(page.get("page_number") or page_index + 1)
        for key, prefix, default_confidence in (
            ("text_blocks", "native/text-block", 0.99),
            ("ocr_lines", "ocr/line", 0.75),
        ):
            for index, block in enumerate(page.get(key) or []):
                if not isinstance(block, dict) or not _text(block.get("text_original")):
                    continue
                result.append(
                    _Entry(
                        text=str(block.get("text_original") or ""),
                        ref=_ref(
                            page=page_number,
                            part=f"{prefix}:{index}",
                            bbox=block.get("bbox"),
                            coordinate_space=str(
                                block.get("coordinate_space") or "pdf_points"
                            ),
                        ),
                        confidence=float(block.get("confidence") or default_confidence),
                    )
                )
        for table_position, table in enumerate(page.get("tables") or []):
            if not isinstance(table, dict):
                continue
            table_index = int(table.get("table_index") or table_position)
            rows = table.get("rows_normalized") or []
            boxes = table.get("cell_bbox_matrix") or []
            confidence_matrix = table.get("cell_confidences") or []
            default_confidence = 0.75 if table.get("ocr_derived") else 0.99
            for row_index, row in enumerate(rows):
                if not isinstance(row, list):
                    continue
                for column_index, value in enumerate(row):
                    if not _text(value):
                        continue
                    bbox = (
                        boxes[row_index][column_index]
                        if row_index < len(boxes)
                        and isinstance(boxes[row_index], list)
                        and column_index < len(boxes[row_index])
                        else None
                    )
                    confidence = (
                        confidence_matrix[row_index][column_index]
                        if row_index < len(confidence_matrix)
                        and isinstance(confidence_matrix[row_index], list)
                        and column_index < len(confidence_matrix[row_index])
                        else default_confidence
                    )
                    result.append(
                        _Entry(
                            text=str(value),
                            ref=_ref(
                                page=page_number,
                                part=(
                                    f"table:{table_index}/row:{row_index}/"
                                    f"column:{column_index}"
                                ),
                                bbox=bbox,
                            ),
                            confidence=float(confidence or default_confidence),
                        )
                    )
    return result
