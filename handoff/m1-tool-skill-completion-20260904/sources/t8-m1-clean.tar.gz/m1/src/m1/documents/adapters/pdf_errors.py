"""Shared exceptions for the deterministic PDF adapter."""

from __future__ import annotations


class PDFAdapterError(RuntimeError):
    """Raised when a PDF cannot be opened or parsed deterministically."""


class PDFDependencyError(PDFAdapterError):
    """Raised when PyMuPDF is not installed."""
