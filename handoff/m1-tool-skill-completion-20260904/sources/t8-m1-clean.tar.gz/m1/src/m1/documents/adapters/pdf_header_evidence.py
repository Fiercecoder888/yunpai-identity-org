"""Indexed PDF header evidence and fail-closed commercial-party pairing."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Callable

from m1.documents.models import SourceReference

from .common import nfkc_text
from .pdf_order_evidence import make_pdf_ref


ORDER_NUMBER_LABEL_PATTERN = r"订单号码|订单编号|订单号|采购单号|PO\s*(?:NO\.?)?"
KNOWN_HEADER_LABELS = (
    ORDER_NUMBER_LABEL_PATTERN,
    r"合同编号|合同号|CONTRACT\s*(?:NO\.?)?",
    r"下单日期|订单日期|制单日期|签订日期|签字日期|日期|ORDER\s*DATE|DATE",
    r"交期|交货日期|要求到货日期|(?:DELIVERY|SHIP|DUE)[\s_.-]*DATE",
    r"结算方式|付款方式|PAYMENT\s*TERMS?",
    r"此单价含税率|税率",
    r"交货地址|送货地址|DELIVERY\s*ADDRESS",
    r"买方|甲\s*方|采购方|BUYER",
    r"卖方|乙\s*方|供方|SELLER",
    r"供应商|SUPPLIER",
    r"联系人|手机|电话|摘要",
    r"序号|序|号|物料编码|物料名称|规格型号|单位|数量|单价|合计金额|备注",
    r"合同条款|代表签字|签字日期",
)
KNOWN_HEADER_LABEL_PATTERN = "|".join(
    f"(?:{pattern})" for pattern in KNOWN_HEADER_LABELS
)
KNOWN_HEADER_LABEL_ONLY = re.compile(
    rf"^(?:{KNOWN_HEADER_LABEL_PATTERN})[ \t]*[：:]?$", re.I
)
KNOWN_HEADER_LABELED_LINE = re.compile(
    rf"^(?:{KNOWN_HEADER_LABEL_PATTERN})[ \t]*[：:]", re.I
)

PARTY_ROLE_PREFIX_RE = re.compile(
    r"^\s*(?:甲\s*方|乙\s*方|买\s*方|卖\s*方|供\s*方|采购\s*方|供应\s*商)"
    r"\s*(?:[（(]\s*盖\s*章\s*[）)])?\s*[：:]\s*",
    re.I,
)
PARTY_ROLE_LABEL_ONLY_RE = re.compile(
    r"^(?:甲\s*方|乙\s*方|买\s*方|卖\s*方|供\s*方|采购\s*方|供应\s*商|"
    r"BUYER|SELLER|SUPPLIER)\s*(?:[（(]\s*盖\s*章\s*[）)])?\s*[：:]?$",
    re.I,
)
_PARTY_INLINE_RE = re.compile(
    r"(?:(?<![0-9A-Za-z\u3400-\u9fff])|(?<=公司))"
    r"(?P<label>甲\s*方|乙\s*方|买\s*方|卖\s*方|供\s*方|采购\s*方|"
    r"供应\s*商|BUYER|SELLER|SUPPLIER)\s*"
    r"(?P<stamp>[（(]\s*盖\s*章\s*[）)])?\s*[：:]\s*(?P<value>.+?)"
    rf"(?=[ \t]*(?:(?:{KNOWN_HEADER_LABEL_PATTERN})[ \t]*"
    r"(?:[（(]\s*盖\s*章\s*[）)])?[ \t]*[：:]|$))",
    re.I,
)
_PARTY_COMPANY_RE = re.compile(
    r"(?:股份有限公司|有限责任公司|有限公司|电子厂|公司)$|"
    r"\b(?:LTD\.?|LIMITED|INC\.?|CORP\.?)$",
    re.I,
)


@dataclass(frozen=True, slots=True)
class PdfHeaderFragment:
    page: int
    text: str
    bbox: tuple[float, float, float, float]
    coordinate_space: str
    source_ref: SourceReference


@dataclass(frozen=True, slots=True)
class PdfHeaderEvidenceIndex:
    fragments: tuple[PdfHeaderFragment, ...]

    @classmethod
    def from_pages(cls, pages: list[dict[str, Any]]) -> "PdfHeaderEvidenceIndex":
        fragments: list[PdfHeaderFragment] = []
        seen: set[tuple[int, str, tuple[float, ...], str]] = set()

        def add_fragment(
            *,
            page_number: int,
            text: Any,
            bbox: Any,
            part: str,
            coordinate_space: str,
        ) -> None:
            cleaned = _clean(text)
            positioned_bbox = _bbox(bbox)
            if not cleaned or positioned_bbox is None:
                return
            key = (page_number, cleaned, positioned_bbox, coordinate_space)
            if key in seen:
                return
            seen.add(key)
            fragments.append(
                PdfHeaderFragment(
                    page=page_number,
                    text=cleaned,
                    bbox=positioned_bbox,
                    coordinate_space=coordinate_space,
                    source_ref=make_pdf_ref(
                        page_number,
                        part=part,
                        bbox=list(positioned_bbox),
                        coordinate_space=coordinate_space,
                    ),
                )
            )

        for page in pages:
            page_number = int(page.get("page_number") or 1)
            coordinate_space = str(page.get("coordinate_space") or "pdf_points")
            for block_position, block in enumerate(page.get("text_blocks") or []):
                if not isinstance(block, dict):
                    continue
                block_index = int(block.get("block_index", block_position))
                for line_index, line in enumerate(block.get("lines") or [block]):
                    if not isinstance(line, dict):
                        continue
                    base_part = f"native/text-block:{block_index}/line:{line_index}"
                    # Keep the complete line before its component spans. A PDF
                    # may split one company name whenever the font changes.
                    add_fragment(
                        page_number=page_number,
                        text=line.get("text_normalized") or line.get("text_original"),
                        bbox=line.get("bbox"),
                        part=base_part,
                        coordinate_space=coordinate_space,
                    )
                    spans = [
                        span
                        for span in line.get("spans") or []
                        if isinstance(span, dict)
                    ]
                    for run_index, run in enumerate(_merge_same_baseline_spans(spans)):
                        add_fragment(
                            page_number=page_number,
                            text=run["text"],
                            bbox=run["bbox"],
                            part=f"{base_part}/span-run:{run_index}",
                            coordinate_space=coordinate_space,
                        )
                    for span_index, span in enumerate(spans):
                        add_fragment(
                            page_number=page_number,
                            text=span.get("text_normalized")
                            or span.get("text_original"),
                            bbox=span.get("bbox"),
                            part=f"{base_part}/span:{span_index}",
                            coordinate_space=coordinate_space,
                        )
            for line in page.get("ocr_lines") or []:
                if not isinstance(line, dict):
                    continue
                source = _safe_part(line.get("source") or "structured")
                kind = _safe_part(line.get("kind") or "text")
                add_fragment(
                    page_number=page_number,
                    text=line.get("text_normalized") or line.get("text_original"),
                    bbox=line.get("bbox"),
                    part=f"structured/{source or 'parser'}/{kind or 'text'}",
                    coordinate_space=str(
                        line.get("coordinate_space") or coordinate_space
                    ),
                )
        return cls(fragments=tuple(fragments))


def positioned_labeled_value(
    index: PdfHeaderEvidenceIndex,
    labels: str,
    *,
    validator: Callable[[str], bool] | None = None,
) -> tuple[str, list[SourceReference], float] | None:
    """Locate a scalar header value using the visual relation to its label.

    Native PDF reading order is not a reliable key/value relation: generators
    commonly emit all labels before all values.  Prefer a value on the same
    visual row, then a value immediately below the label.  Inline positioned
    text remains useful when the PDF backend cannot expose separate spans.
    """

    inline_pattern = re.compile(
        rf"(?:(?<![0-9A-Za-z\u3400-\u9fff])|(?<=公司))"
        rf"(?:{labels})[ \t]*[：:][ \t]*"
        rf"(?P<value>[^\n\r]{{1,160}}?)(?=[ \t]*(?:(?:"
        rf"{KNOWN_HEADER_LABEL_PATTERN})[ \t]*[：:]|$))",
        re.I,
    )
    label_only = re.compile(rf"^(?:{labels})[ \t]*[：:]?$", re.I)

    def is_label(text: str) -> bool:
        return bool(
            label_only.fullmatch(text.strip())
            or label_only.fullmatch(re.sub(r"\s+", "", text).strip())
        )

    def accepted(text: str) -> bool:
        candidate = text.strip()
        return bool(
            candidate
            and not is_known_header_boundary(candidate)
            and (validator is None or validator(candidate))
        )

    candidates: list[tuple[float, str, list[SourceReference], float]] = []
    label_fragments: list[PdfHeaderFragment] = []
    for fragment in index.fragments:
        matches = list(inline_pattern.finditer(fragment.text))
        for match in matches:
            value = match.group("value").strip()
            if accepted(value):
                candidates.append(
                    (180.0 - fragment.page, value, [fragment.source_ref], 0.97)
                )
        if not matches and is_label(fragment.text):
            label_fragments.append(fragment)

    value_fragments = [
        fragment
        for fragment in index.fragments
        if not is_label(fragment.text)
        and not inline_pattern.search(fragment.text)
        and accepted(fragment.text)
    ]
    for label in label_fragments:
        lx0, ly0, lx1, ly1 = label.bbox
        label_height = max(1.0, ly1 - ly0)
        for value in value_fragments:
            if value.page != label.page or not _same_coordinate_space(value, label):
                continue
            vx0, vy0, vx1, vy1 = value.bbox
            value_height = max(1.0, vy1 - vy0)
            overlap = min(ly1, vy1) - max(ly0, vy0)
            center_delta = abs((ly0 + ly1) / 2 - (vy0 + vy1) / 2)
            horizontal_gap = vx0 - lx1
            same_row = (
                overlap >= min(label_height, value_height) * 0.35
                or center_delta <= max(label_height, value_height) * 0.55
            )
            if same_row and -3.0 <= horizontal_gap <= 360.0:
                score = (
                    300.0
                    - label.page
                    - max(0.0, horizontal_gap) * 0.15
                    - center_delta
                )
                confidence = 0.99
            else:
                vertical_gap = vy0 - ly1
                horizontal_overlap = min(lx1, vx1) - max(lx0, vx0)
                aligned_below = horizontal_overlap > 0 or abs(vx0 - lx0) <= 16.0
                if (
                    not aligned_below
                    or not -2.0 <= vertical_gap <= label_height * 2.5
                ):
                    continue
                score = (
                    140.0
                    - label.page
                    - max(0.0, vertical_gap)
                    - abs(vx0 - lx0) * 0.1
                )
                confidence = 0.9
            candidates.append(
                (
                    score,
                    value.text,
                    [value.source_ref, label.source_ref],
                    confidence,
                )
            )

    if not candidates:
        return None
    _, value, refs, confidence = max(
        candidates,
        key=lambda item: (item[0], -len(re.sub(r"\s+", "", item[1]))),
    )
    return value, refs, confidence


def is_known_header_boundary(value: str) -> bool:
    text = nfkc_text(value).strip()
    compact = re.sub(r"\s+", "", text)
    return bool(
        KNOWN_HEADER_LABEL_ONLY.fullmatch(text)
        or KNOWN_HEADER_LABEL_ONLY.fullmatch(compact)
        or KNOWN_HEADER_LABELED_LINE.match(text)
        or KNOWN_HEADER_LABELED_LINE.match(compact)
    )


def clean_party_value(value: str | None) -> str | None:
    if not value:
        return None
    cleaned = _clean(PARTY_ROLE_PREFIX_RE.sub("", nfkc_text(value), count=1))
    if not cleaned or not re.search(r"\w", cleaned, re.UNICODE):
        return None
    return cleaned


def positioned_party_values(
    index: PdfHeaderEvidenceIndex,
) -> dict[str, tuple[str, list[SourceReference], float]]:
    candidates: dict[str, list[tuple[float, bool, str, list[SourceReference]]]] = {
        "buyer": [],
        "seller": [],
        "supplier": [],
    }
    labels: list[tuple[str, PdfHeaderFragment]] = []
    for fragment in index.fragments:
        inline_matches = list(_PARTY_INLINE_RE.finditer(fragment.text))
        for inline in inline_matches:
            role = _party_role(inline.group("label"))
            value = clean_party_value(inline.group("value"))
            company_like = bool(value and _PARTY_COMPANY_RE.search(value))
            if role and value and company_like:
                score = 220.0 if inline.group("stamp") else 180.0
                candidates[role].append(
                    (score, company_like, value, [fragment.source_ref])
                )
        if inline_matches:
            continue
        if PARTY_ROLE_LABEL_ONLY_RE.fullmatch(fragment.text):
            role = _party_role(re.sub(r"[（(].*?[）)]|[：:]", "", fragment.text))
            if role:
                labels.append((role, fragment))

    values = [
        fragment
        for fragment in index.fragments
        if not PARTY_ROLE_LABEL_ONLY_RE.fullmatch(fragment.text)
        and not _PARTY_INLINE_RE.search(fragment.text)
        and _is_positioned_party_candidate(fragment.text)
    ]
    for role, label in labels:
        lx0, ly0, lx1, ly1 = label.bbox
        label_height = max(1.0, ly1 - ly0)
        for value in values:
            if value.page != label.page or not _same_coordinate_space(value, label):
                continue
            vx0, vy0, vx1, vy1 = value.bbox
            value_height = max(1.0, vy1 - vy0)
            overlap = min(ly1, vy1) - max(ly0, vy0)
            center_delta = abs((ly0 + ly1) / 2 - (vy0 + vy1) / 2)
            horizontal_gap = vx0 - lx1
            same_row = (
                overlap >= min(label_height, value_height) * 0.35
                or center_delta <= max(label_height, value_height) * 0.55
            )
            company_like = bool(_PARTY_COMPANY_RE.search(value.text))
            if same_row and -3.0 <= horizontal_gap <= 260.0:
                score = (
                    140.0
                    - horizontal_gap * 0.1
                    - center_delta
                    + (35.0 if company_like else 0.0)
                )
            else:
                if not company_like:
                    continue
                vertical_gap = vy0 - ly1
                horizontal_overlap = min(lx1, vx1) - max(lx0, vx0)
                same_column = horizontal_overlap > 0 or abs(vx0 - lx0) <= 12.0
                if not same_column or not -2.0 <= vertical_gap <= label_height * 2.5:
                    continue
                score = 90.0 - max(0.0, vertical_gap) - abs(vx0 - lx0) * 0.1
            candidates[role].append(
                (
                    score,
                    company_like,
                    value.text,
                    [value.source_ref, label.source_ref],
                )
            )

    result: dict[str, tuple[str, list[SourceReference], float]] = {}
    for role, role_candidates in candidates.items():
        if not role_candidates:
            continue
        score, company_like, value, refs = max(
            role_candidates,
            key=lambda item: (item[0], item[1], len(re.sub(r"\s+", "", item[2]))),
        )
        confidence = 1.0 if score >= 150.0 and company_like else 0.85
        result[role] = (value, refs, confidence)
    return result


def _clean(value: Any) -> str:
    return nfkc_text(str(value or "")).strip()


def _same_coordinate_space(left: PdfHeaderFragment, right: PdfHeaderFragment) -> bool:
    return (
        left.coordinate_space.strip().casefold()
        == right.coordinate_space.strip().casefold()
    )


def _bbox(value: Any) -> tuple[float, float, float, float] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        result = tuple(float(item) for item in value)
    except (TypeError, ValueError):
        return None
    return result if result[2] > result[0] and result[3] > result[1] else None


def _safe_part(value: Any) -> str:
    return re.sub(r"[^a-z0-9_.-]+", "-", str(value).casefold()).strip("-")


def _join_span_text(left: str, right: str, gap: float, height: float) -> str:
    separator = ""
    if gap > max(3.0, height * 0.45) or (
        left[-1:].isascii()
        and right[:1].isascii()
        and left[-1:].isalnum()
        and right[:1].isalnum()
    ):
        separator = " "
    return f"{left.rstrip()}{separator}{right.lstrip()}"


def _merge_same_baseline_spans(spans: list[dict[str, Any]]) -> list[dict[str, Any]]:
    positioned = []
    for span in spans:
        text = _clean(span.get("text_normalized") or span.get("text_original"))
        bbox = _bbox(span.get("bbox"))
        if text and bbox is not None:
            positioned.append((bbox, text))
    positioned.sort(key=lambda item: ((item[0][1] + item[0][3]) / 2, item[0][0]))
    runs: list[dict[str, Any]] = []
    for bbox, text in positioned:
        if not runs:
            runs.append({"text": text, "bbox": list(bbox)})
            continue
        previous = runs[-1]
        px0, py0, px1, py1 = (float(item) for item in previous["bbox"])
        x0, y0, x1, y1 = bbox
        previous_height = max(1.0, py1 - py0)
        height = max(1.0, y1 - y0)
        overlap = min(py1, y1) - max(py0, y0)
        center_delta = abs((py0 + py1) / 2 - (y0 + y1) / 2)
        same_baseline = (
            overlap >= min(previous_height, height) * 0.5
            or center_delta <= max(previous_height, height) * 0.35
        )
        gap = x0 - px1
        if same_baseline and -1.0 <= gap <= max(
            12.0, max(previous_height, height) * 1.5
        ):
            previous["text"] = _join_span_text(
                str(previous["text"]), text, gap, max(previous_height, height)
            )
            previous["bbox"] = [min(px0, x0), min(py0, y0), max(px1, x1), max(py1, y1)]
        else:
            runs.append({"text": text, "bbox": list(bbox)})
    return runs


def _party_role(label: str) -> str | None:
    compact = re.sub(r"\s+", "", nfkc_text(label)).casefold()
    if compact in {"甲方", "买方", "采购方", "buyer"}:
        return "buyer"
    if compact in {"乙方", "卖方", "供方", "seller"}:
        return "seller"
    if compact in {"供应商", "supplier"}:
        return "supplier"
    return None


def _is_positioned_party_candidate(value: str) -> bool:
    text = clean_party_value(value)
    compact = re.sub(r"\s+", "", text or "")
    return bool(
        text
        and 2 <= len(compact) <= 80
        and not is_known_header_boundary(text)
        and not PARTY_ROLE_LABEL_ONLY_RE.fullmatch(text)
        and not re.fullmatch(r"[-+\d./年月日:：\s]+", text)
        and not re.search(r"(?:先生|女士|小姐|经理|联系人|电话|手机)$", text)
    )


__all__ = [
    "KNOWN_HEADER_LABEL_ONLY",
    "KNOWN_HEADER_LABEL_PATTERN",
    "KNOWN_HEADER_LABELED_LINE",
    "ORDER_NUMBER_LABEL_PATTERN",
    "PARTY_ROLE_LABEL_ONLY_RE",
    "PdfHeaderEvidenceIndex",
    "clean_party_value",
    "is_known_header_boundary",
    "positioned_labeled_value",
    "positioned_party_values",
]
