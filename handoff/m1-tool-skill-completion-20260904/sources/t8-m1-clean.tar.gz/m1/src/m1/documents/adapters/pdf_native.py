"""Native PyMuPDF evidence extraction helpers.

This module contains no document classification or business mapping. The
facade in m1.documents.adapters.pdf keeps the historical import surface.
"""

from __future__ import annotations

import contextlib
import io
import threading
from pathlib import Path
from typing import Any

from .pdf_errors import PDFDependencyError
from .common import nfkc_text


# redirect_stdout / redirect_stderr mutate process-global state.
_TABLE_FINDER_STREAM_LOCK = threading.Lock()


def _require_fitz() -> Any:
    try:
        import fitz  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover - dependency is in base M1 image
        raise PDFDependencyError(
            "PDF parsing requires PyMuPDF; install the `pymupdf` package."
        ) from exc
    return fitz


def _rect_list(rect: Any) -> list[float]:
    return [float(rect[0]), float(rect[1]), float(rect[2]), float(rect[3])]


def _span_payload(span: dict[str, Any]) -> dict[str, Any]:
    text = str(span.get("text", ""))
    result: dict[str, Any] = {
        "text_original": text,
        "text_normalized": nfkc_text(text),
        "bbox": _rect_list(span.get("bbox", (0, 0, 0, 0))),
        "font": span.get("font"),
        "size": float(span.get("size", 0.0)),
        "flags": int(span.get("flags", 0)),
        "color": span.get("color"),
    }
    if "origin" in span:
        result["origin"] = [float(v) for v in span["origin"]]
    return result


def _text_blocks(page: Any) -> tuple[list[dict[str, Any]], str]:
    page_dict = page.get_text("dict", sort=True)
    blocks: list[dict[str, Any]] = []
    page_text_parts: list[str] = []
    for block_index, block in enumerate(page_dict.get("blocks", [])):
        if block.get("type") != 0:
            continue
        lines: list[dict[str, Any]] = []
        block_text_parts: list[str] = []
        for line in block.get("lines", []):
            spans = [_span_payload(span) for span in line.get("spans", [])]
            line_text = "".join(span["text_original"] for span in spans)
            block_text_parts.append(line_text)
            lines.append(
                {
                    "bbox": _rect_list(line.get("bbox", (0, 0, 0, 0))),
                    "writing_mode": int(line.get("wmode", 0)),
                    "direction": [float(v) for v in line.get("dir", (1, 0))],
                    "text_original": line_text,
                    "text_normalized": nfkc_text(line_text),
                    "spans": spans,
                }
            )
        block_text = "\n".join(block_text_parts)
        page_text_parts.append(block_text)
        blocks.append(
            {
                "block_index": block_index,
                "type": "text",
                "bbox": _rect_list(block.get("bbox", (0, 0, 0, 0))),
                "text_original": block_text,
                "text_normalized": nfkc_text(block_text),
                "lines": lines,
            }
        )
    return blocks, "\n".join(part for part in page_text_parts if part)


def _tables(page: Any) -> list[dict[str, Any]]:
    finder = getattr(page, "find_tables", None)
    if finder is None:
        return []
    try:
        # PyMuPDF emits an optional-layout-package advertisement directly to the
        # process streams in some releases.  Adapter parsing must stay log-clean.
        with _TABLE_FINDER_STREAM_LOCK, contextlib.redirect_stdout(
            io.StringIO()
        ), contextlib.redirect_stderr(io.StringIO()):
            table_finder = finder()
    except Exception:
        # Native text and coordinates remain valid when the heuristic table finder
        # cannot handle a malformed page.
        return []

    result: list[dict[str, Any]] = []
    for table_index, table in enumerate(getattr(table_finder, "tables", ())):
        try:
            rows = table.extract()
        except Exception:
            rows = []
        normalized_rows = [
            [nfkc_text(str(cell)) if cell is not None else None for cell in row]
            for row in rows
        ]
        raw_rows = [
            [str(cell) if cell is not None else None for cell in row] for row in rows
        ]
        cells = []
        for cell in getattr(table, "cells", ()):
            if cell is not None:
                cells.append(_rect_list(cell))
        # ``table.cells`` is a compact list and therefore loses row / column
        # positions whenever PyMuPDF represents a merged cell with ``None``.
        # Preserve the rectangular matrix as well: downstream field evidence
        # needs the bbox for the exact business cell, not merely an anonymous
        # table-level list of rectangles.
        cell_bbox_matrix: list[list[list[float] | None]] = []
        table_rows = list(getattr(table, "rows", ()) or ())
        for row_index in range(len(rows)):
            row_cells = (
                list(getattr(table_rows[row_index], "cells", ()) or ())
                if row_index < len(table_rows)
                else []
            )
            cell_bbox_matrix.append(
                [
                    _rect_list(row_cells[column_index])
                    if column_index < len(row_cells)
                    and row_cells[column_index] is not None
                    else None
                    for column_index in range(len(rows[row_index]))
                ]
            )
        result.append(
            {
                "table_index": table_index,
                "bbox": _rect_list(getattr(table, "bbox", (0, 0, 0, 0))),
                "row_count": int(getattr(table, "row_count", len(rows))),
                "column_count": int(
                    getattr(table, "col_count", max((len(row) for row in rows), default=0))
                ),
                "rows_original": raw_rows,
                "rows_normalized": normalized_rows,
                "cell_bboxes": cells,
                "cell_bbox_matrix": cell_bbox_matrix,
                "coordinate_space": "pdf_points",
                "source": "pymupdf-native",
            }
        )
    return result


def _page_images(page: Any) -> list[dict[str, Any]]:
    # ``get_image_info`` reports every displayed image with its placement,
    # including inline images and images nested in Form XObjects.  The older
    # ``get_images`` resource listing can miss those placements on some PDFs.
    image_info = getattr(page, "get_image_info", None)
    if callable(image_info):
        try:
            info_items = image_info(xrefs=True)
        except TypeError:  # pragma: no cover - older PyMuPDF API
            info_items = image_info()
        except Exception:
            info_items = []
        detailed: list[dict[str, Any]] = []
        seen_info: set[tuple[int, tuple[float, ...]]] = set()
        for info in info_items or []:
            if not isinstance(info, dict):
                continue
            bbox = _rect_list(info.get("bbox") or (0, 0, 0, 0))
            xref = int(info.get("xref") or 0)
            key = (xref, tuple(bbox))
            if key in seen_info:
                continue
            seen_info.add(key)
            detailed.append(
                {
                    "xref": xref,
                    "bbox": bbox,
                    "width": int(info.get("width") or 0),
                    "height": int(info.get("height") or 0),
                    "bits_per_component": int(info.get("bpc") or 0),
                    "color_space": info.get("cs-name") or info.get("colorspace"),
                    "name": str(info.get("number") or ""),
                    "inline": xref == 0,
                }
            )
        if detailed:
            return detailed

    images: list[dict[str, Any]] = []
    seen: set[tuple[int, tuple[float, ...]]] = set()
    for image in page.get_images(full=True):
        xref = int(image[0])
        try:
            rects = page.get_image_rects(xref)
        except Exception:
            rects = []
        if not rects:
            rects = [None]
        for rect in rects:
            bbox = tuple(_rect_list(rect)) if rect is not None else ()
            key = (xref, bbox)
            if key in seen:
                continue
            seen.add(key)
            images.append(
                {
                    "xref": xref,
                    "bbox": list(bbox) if bbox else None,
                    "width": int(image[2]),
                    "height": int(image[3]),
                    "bits_per_component": int(image[4]),
                    "color_space": image[5],
                    "name": image[7],
                }
            )
    return images


def _rect_union_area(rectangles: list[list[float]], bounds: list[float]) -> float:
    """Return the clipped union area of axis-aligned rectangles."""

    bx0, by0, bx1, by1 = bounds
    clipped: list[tuple[float, float, float, float]] = []
    for rect in rectangles:
        if len(rect) < 4:
            continue
        x0, y0 = max(bx0, float(rect[0])), max(by0, float(rect[1]))
        x1, y1 = min(bx1, float(rect[2])), min(by1, float(rect[3]))
        if x1 > x0 and y1 > y0:
            clipped.append((x0, y0, x1, y1))
    xs = sorted({value for rect in clipped for value in (rect[0], rect[2])})
    area = 0.0
    for left, right in zip(xs, xs[1:]):
        if right <= left:
            continue
        intervals = sorted(
            (y0, y1) for x0, y0, x1, y1 in clipped if x0 < right and x1 > left
        )
        covered = 0.0
        start: float | None = None
        end: float | None = None
        for y0, y1 in intervals:
            if start is None:
                start, end = y0, y1
            elif y0 <= float(end):
                end = max(float(end), y1)
            else:
                covered += float(end) - start
                start, end = y0, y1
        if start is not None:
            covered += float(end) - start
        area += (right - left) * covered
    return area


def _coverage_ratio(rectangles: list[list[float]], page_rect: list[float]) -> float:
    width = max(0.0, page_rect[2] - page_rect[0])
    height = max(0.0, page_rect[3] - page_rect[1])
    page_area = width * height
    if page_area <= 0:
        return 0.0
    return round(min(1.0, _rect_union_area(rectangles, page_rect) / page_area), 6)


def _ocr_recommendation(page: dict[str, Any]) -> tuple[bool, list[str]]:
    chars = int(page.get("native_text_char_count") or 0)
    images = list(page.get("images") or [])
    tables = list(page.get("tables") or [])
    image_coverage = float(page.get("image_coverage_ratio") or 0.0)
    text_coverage = float(page.get("text_block_coverage_ratio") or 0.0)
    reasons: list[str] = []
    if chars < 32 and (images or not tables):
        reasons.append("native_text_below_32")
    # Mixed scans often contain only a generated header/footer while the body
    # is a full-page image.  Character count alone silently misses that case.
    if (
        image_coverage >= 0.45
        and not tables
        and (chars < 256 or text_coverage < 0.08)
    ):
        reasons.append("large_image_sparse_native_layout")
    return bool(reasons), reasons


def _asset_dir(path: Path, digest: str, render_dir: str | Path | None) -> Path:
    if render_dir is not None:
        return Path(render_dir)
    return path.parent / ".m1_assets" / digest[:16] / "pdf-pages"
