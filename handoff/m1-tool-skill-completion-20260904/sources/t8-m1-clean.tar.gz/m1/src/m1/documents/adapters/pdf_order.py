"""Deterministic PDF order field and line extraction.

The public compatibility surface remains in m1.documents.adapters.pdf."""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import UTC, date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

from m1.documents.models import (
    DocumentHeader,
    FieldMetadata,
    IdentifierCandidate,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from m1.documents.numeric import decimal_from_value, monetary_values_equal
from m1.documents.orders import ORDER_NUMBER_RE

from .common import nfkc_text
from .pdf_classification import _table_header_mapping
from .pdf_header_evidence import (
    KNOWN_HEADER_LABEL_ONLY as _KNOWN_HEADER_LABEL_ONLY,  # noqa: F401
)
from .pdf_header_evidence import (
    KNOWN_HEADER_LABEL_PATTERN as _KNOWN_HEADER_LABEL_PATTERN,
)
from .pdf_header_evidence import (
    KNOWN_HEADER_LABELED_LINE as _KNOWN_HEADER_LABELED_LINE,  # noqa: F401
)
from .pdf_header_evidence import (
    KNOWN_HEADER_LABELS as _KNOWN_HEADER_LABELS,  # noqa: F401 - compatibility export
)
from .pdf_header_evidence import (
    ORDER_NUMBER_LABEL_PATTERN,
    PdfHeaderEvidenceIndex,
)
from .pdf_header_evidence import (
    PARTY_ROLE_LABEL_ONLY_RE as _PARTY_ROLE_LABEL_ONLY_RE,
)
from .pdf_header_evidence import (
    PARTY_ROLE_PREFIX_RE as _PARTY_ROLE_PREFIX_RE,  # noqa: F401
)
from .pdf_header_evidence import (
    clean_party_value as _clean_party_value,
)
from .pdf_header_evidence import (
    is_known_header_boundary as _is_known_header_boundary,
)
from .pdf_header_evidence import (
    positioned_labeled_value as _positioned_labeled_value,
)
from .pdf_header_evidence import (
    positioned_party_values as _positioned_party_values,
)
from .pdf_order_evidence import (
    cny_symbol_ref as _cny_symbol_ref,
)
from .pdf_order_evidence import (
    make_pdf_ref as _pdf_ref,
)
from .pdf_order_evidence import (
    table_cell_confidence as _table_cell_confidence,
)
from .pdf_order_evidence import (
    table_cell_ref as _table_cell_ref,
)
from .pdf_order_evidence import (
    table_cell_refs as _table_cell_refs,
)
from .pdf_order_evidence import (
    table_cell_value_source as _table_cell_value_source,
)


def _clean(value: Any, *, preserve: bool = False) -> str | None:
    if value is None:
        return None
    text = nfkc_text(str(value))
    return text if preserve and text else (text.strip() or None)


def _number(value: Any) -> int | Decimal | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, Decimal)):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else Decimal(str(value))
    match = re.search(r"[-+]?\d[\d,]*(?:\.\d+)?", nfkc_text(str(value)))
    if not match:
        return None
    try:
        number = Decimal(match.group(0).replace(",", ""))
    except InvalidOperation:
        return None
    return int(number) if number == number.to_integral_value() else number


_NUMERIC_FIELDS = {
    "quantity",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "volume",
}


_AMBIGUOUS_PRICE_HEADERS = {
    "单价": "unit_price_tax_included",
    "unitprice": "unit_price_tax_included",
    "price": "unit_price_tax_included",
    "金额": "amount_tax_included",
    "合计金额": "amount_tax_included",
    "amount": "amount_tax_included",
    "totalamount": "amount_tax_included",
}
_TAX_INCLUDED_PRICE_RE = re.compile(
    r"(?:此|本)?(?:单价|价格|金额)[^\n]{0,12}(?:含税|价税合计)|"
    r"(?:含税|价税合计)[^\n]{0,12}(?:单价|价格|金额)|"
    r"(?:tax[ -]?(?:inclusive|included)|including\s+tax)",
    re.IGNORECASE,
)
_TAX_EXCLUDED_PRICE_RE = re.compile(
    r"(?:单价|价格|金额)[^\n]{0,12}(?:不含税|未税)|"
    r"(?:不含税|未税)[^\n]{0,12}(?:单价|价格|金额)|"
    r"(?:tax[ -]?(?:exclusive|excluded)|excluding\s+tax)",
    re.IGNORECASE,
)


def _contextual_price_mapping(
    pages: list[dict[str, Any]],
    mapped: dict[str, tuple[int, str]],
) -> dict[str, tuple[int, str]]:
    """Promote ambiguous price headings only with explicit document evidence."""

    text = "\n".join(str(page.get("text_normalized") or "") for page in pages)
    if not _TAX_INCLUDED_PRICE_RE.search(text) or _TAX_EXCLUDED_PRICE_RE.search(text):
        return mapped
    result = dict(mapped)
    for source_name, (column, raw_heading) in list(mapped.items()):
        token = re.sub(
            r"[\s\n\r:：()（）/\\·._-]+",
            "",
            nfkc_text(raw_heading).casefold(),
        )
        target_name = _AMBIGUOUS_PRICE_HEADERS.get(token)
        if target_name is None or source_name not in {
            "unit_price_tax_excluded",
            "amount_tax_excluded",
        }:
            continue
        if target_name in result:
            continue
        result.pop(source_name, None)
        result[target_name] = (column, raw_heading)
    return result


def _set_line_value(line: OrderLine, field: str, value: Any) -> None:
    if field == "image":
        return
    if field in _NUMERIC_FIELDS:
        setattr(line, field, _number(value))
    elif field == "line_no":
        parsed = _number(value)
        setattr(line, field, parsed if parsed is not None else _clean(value))
    elif field == "name_raw":
        setattr(line, field, _clean(value, preserve=True))
    else:
        setattr(line, field, _clean(value))


def _sum_numbers(values: list[Any]) -> int | Decimal | None:
    parsed = [decimal_from_value(value) for value in values if value is not None]
    if not parsed:
        return None
    total = sum(parsed, Decimal(0))
    return int(total) if total == total.to_integral_value() else total


def _first_page_containing(pages: list[dict[str, Any]], value: str) -> int:
    needle = nfkc_text(value).casefold()
    for page in pages:
        if needle and needle in page.get("text_normalized", "").casefold():
            return int(page["page_number"])
    return 1


_DATE_CANDIDATE_RE = re.compile(
    r"(?:\d{4}\s*[年./-]\s*)?\d{1,2}\s*(?:月|[./-])\s*\d{1,2}\s*(?:日)?"
)


def _is_identifier_candidate(value: str) -> bool:
    compact = re.sub(r"\s+", "", nfkc_text(value)).strip("：:")
    return bool(
        3 <= len(compact) <= 64
        and re.search(r"\d", compact)
        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/\-]*", compact)
    )


def _is_date_candidate(value: str) -> bool:
    return bool(_DATE_CANDIDATE_RE.search(nfkc_text(value)))


def _is_non_label_candidate(value: str) -> bool:
    return bool(_clean(value)) and not _is_known_header_boundary(value)


def _labeled_value(
    pages: list[dict[str, Any]],
    labels: str,
    *,
    validator: Callable[[str], bool] | None = None,
) -> tuple[str | None, SourceReference | None]:
    pattern = re.compile(
        rf"(?:(?<![0-9A-Za-z\u3400-\u9fff])|(?<=公司))(?:{labels})"
        rf"[ \t]*[：:][ \t]*"
        rf"([^\n\r]{{1,160}}?)(?=[ \t]*(?:(?:{_KNOWN_HEADER_LABEL_PATTERN})"
        rf"[ \t]*(?:[（(][ \t]*盖[ \t]*章[ \t]*[）)])?[ \t]*[：:]|$))",
        re.IGNORECASE | re.MULTILINE,
    )
    label_only = re.compile(rf"^(?:{labels})\s*[：:]?$", re.IGNORECASE)

    def is_label(text: str) -> bool:
        return bool(
            label_only.search(text.strip())
            or label_only.search(re.sub(r"\s+", "", text).strip())
        )

    def accepted(text: str) -> bool:
        candidate = text.strip()
        return bool(
            candidate
            and not _is_known_header_boundary(candidate)
            and (validator is None or validator(candidate))
        )

    def positioned_ref(
        page_number: int,
        *,
        part: str,
        item: dict[str, Any],
        coordinate_space: str,
    ) -> SourceReference:
        bbox = item.get("bbox")
        positioned_bbox = (
            [float(value) for value in bbox]
            if isinstance(bbox, (list, tuple)) and len(bbox) == 4
            else None
        )
        return _pdf_ref(
            page_number,
            part=part,
            bbox=positioned_bbox,
            coordinate_space=coordinate_space,
        )

    for page in pages:
        page_number = int(page["page_number"])

        # A positioned line keeps a role label attached to the company printed
        # beside it. Flat PDF reading order can place both labels before both
        # values and systematically swap party A and party B.
        for block_position, block in enumerate(page.get("text_blocks", [])):
            if not isinstance(block, dict):
                continue
            block_index = int(block.get("block_index", block_position))
            block_lines = block.get("lines") or [block]
            for line_index, line in enumerate(block_lines):
                if not isinstance(line, dict):
                    continue
                text = str(
                    line.get("text_normalized") or line.get("text_original") or ""
                ).strip()
                match = pattern.search(text)
                if not match or not accepted(match.group(1)):
                    continue
                return match.group(1).strip(), positioned_ref(
                    page_number,
                    part=f"native/text-block:{block_index}/line:{line_index}",
                    item=line,
                    coordinate_space=str(
                        page.get("coordinate_space") or "pdf_points"
                    ),
                )

        # PP-Structure produces spatially associated blocks such as
        # ``甲方：...`` and ``乙方：...``. Prefer those blocks over tables and
        # flat reading order when native positioned text is unavailable.
        structured_inline = re.compile(
            rf"^(?:{labels})[ \t]*(?:[（(][ \t]*盖[ \t]*章[ \t]*[）)])?"
            rf"[ \t]*[：:]?[ \t]*(\S[^\n\r]{{0,159}}?)(?=[ \t]*(?:"
            rf"(?:{_KNOWN_HEADER_LABEL_PATTERN})[ \t]*(?:[（(][ \t]*盖[ \t]*章"
            rf"[ \t]*[）)])?[ \t]*[：:]|$))",
            re.IGNORECASE,
        )
        for line in page.get("ocr_lines", []):
            if not isinstance(line, dict):
                continue
            text = str(
                line.get("text_normalized") or line.get("text_original") or ""
            ).strip()
            match = structured_inline.search(text)
            if not match or not accepted(match.group(1)):
                continue
            source = re.sub(
                r"[^a-z0-9_.-]+",
                "-",
                str(line.get("source") or "structured").casefold(),
            ).strip("-")
            kind = re.sub(
                r"[^a-z0-9_.-]+",
                "-",
                str(line.get("kind") or "text").casefold(),
            ).strip("-")
            return match.group(1).strip(), positioned_ref(
                page_number,
                part=f"structured/{source or 'parser'}/{kind or 'text'}",
                item=line,
                coordinate_space=str(
                    line.get("coordinate_space") or "pdf_points"
                ),
            )

        for table in page.get("tables", []):
            table_index = int(table.get("table_index", 0))
            for row_index, row in enumerate(table.get("rows_normalized", [])):
                label_columns = [
                    column
                    for column, cell in enumerate(row)
                    if _clean(cell) and _is_known_header_boundary(str(cell))
                ]
                for column, cell in enumerate(row):
                    cell_text = _clean(cell)
                    if not cell_text:
                        continue
                    inline = pattern.search(cell_text)
                    if inline and accepted(inline.group(1)):
                        return inline.group(1).strip(), _pdf_ref(
                            page_number,
                            table_index=table_index,
                            row_index=row_index,
                            column_index=column,
                        )
                    if is_label(cell_text):
                        # Some PDF table extractors emit a row as
                        # ``甲方 | 乙方 | buyer | seller``. Pair the contiguous
                        # label group and value group by position before trying
                        # the conventional adjacent-cell layout.
                        if column in label_columns and label_columns:
                            values_after_labels = [
                                (value_column, adjacent)
                                for value_column in range(
                                    max(label_columns) + 1, len(row)
                                )
                                if (adjacent := _clean(row[value_column]))
                                and not _is_known_header_boundary(adjacent)
                                and accepted(adjacent)
                            ]
                            label_rank = label_columns.index(column)
                            if len(values_after_labels) >= len(label_columns):
                                value_column, adjacent = values_after_labels[label_rank]
                                return adjacent, _pdf_ref(
                                    page_number,
                                    table_index=table_index,
                                    row_index=row_index,
                                    column_index=value_column,
                                )

                        immediate_column = column + 1
                        immediate = (
                            _clean(row[immediate_column])
                            if immediate_column < len(row)
                            else None
                        )
                        if (
                            immediate
                            and not _is_known_header_boundary(immediate)
                            and accepted(immediate)
                        ):
                            return immediate, _pdf_ref(
                                page_number,
                                table_index=table_index,
                                row_index=row_index,
                                column_index=immediate_column,
                            )

        # Search native and structured text independently before consulting the
        # combined stream.  This prevents a label at the end of native text from
        # consuming a value at the beginning of appended OCR text.
        text_sources = [
            ("native_text", page.get("native_text_normalized")),
            ("native_text", page.get("text_normalized")),
            ("structured/text", page.get("ocr_text_normalized")),
        ]
        seen_text: set[str] = set()
        for part, raw_text in text_sources:
            text = str(raw_text or "")
            if not text or text in seen_text:
                continue
            seen_text.add(text)
            match = pattern.search(text)
            if match and accepted(match.group(1)):
                return match.group(1).strip(), _pdf_ref(page_number, part=part)
        # Many PDF generators place a label and its value in separate text
        # blocks even though they are visually adjacent.  Preserve that reading
        # order and stop when the next token is clearly another label.
        page_lines = [
            line.strip()
            for line in page.get("text_normalized", "").splitlines()
            if line.strip()
        ]
        for line_index, line in enumerate(page_lines):
            if not is_label(line):
                continue
            if _PARTY_ROLE_LABEL_ONLY_RE.fullmatch(line) and (
                (
                    line_index > 0
                    and _PARTY_ROLE_LABEL_ONLY_RE.fullmatch(
                        page_lines[line_index - 1]
                    )
                )
                or (
                    line_index + 1 < len(page_lines)
                    and _PARTY_ROLE_LABEL_ONLY_RE.fullmatch(
                        page_lines[line_index + 1]
                    )
                )
            ):
                # Consecutive party labels make the flat stream ambiguous.
                # Missing is safer than assigning the opposite company.
                continue
            for candidate in page_lines[line_index + 1 : line_index + 4]:
                compact = re.sub(r"\s+", "", candidate)
                if _is_known_header_boundary(candidate) or is_label(candidate) or (
                    len(compact) <= 40 and compact.endswith((":", "："))
                ):
                    break
                if accepted(candidate):
                    return candidate, _pdf_ref(
                        page_number, part="native_text/reading_order"
                    )
    return None, None


def _year_from_identifier(identifier: str | None, month: int, day: int) -> int | None:
    digits = re.sub(r"\D", "", identifier or "")
    for offset in range(max(0, len(digits) - 5)):
        fragment = digits[offset : offset + 6]
        if len(fragment) != 6:
            continue
        year, candidate_month, candidate_day = (
            int(fragment[:2]),
            int(fragment[2:4]),
            int(fragment[4:6]),
        )
        if candidate_month == month and candidate_day == day:
            return 2000 + year if year < 80 else 1900 + year
    return None


def _date_value(raw: str, identifier: str | None) -> tuple[date | None, bool]:
    numbers = [int(value) for value in re.findall(r"\d+", nfkc_text(raw))]
    try:
        if len(numbers) >= 3 and numbers[0] >= 1000:
            return date(numbers[0], numbers[1], numbers[2]), False
        if len(numbers) >= 2:
            month, day = numbers[-2:]
            year = (
                _year_from_identifier(identifier, month, day)
                or datetime.now(UTC).year
            )
            return date(year, month, day), True
    except ValueError:
        return None, False
    return None, False


_ORDER_IDENTIFIER_CONTEXT_RE = re.compile(
    rf"(?:(?:{ORDER_NUMBER_LABEL_PATTERN})\s*[：:]?)",
    re.IGNORECASE,
)
_CONTRACT_IDENTIFIER_CONTEXT_RE = re.compile(
    r"(?:合同(?:编号|号)|CONTRACT\s*(?:NO\.?)?)\s*[：:]?",
    re.IGNORECASE,
)
_PRODUCT_IDENTIFIER_CONTEXT_RE = re.compile(
    r"(?:产品标签|标签条码|条形码|条码|物料(?:编码|编号)|产品(?:编码|编号)|"
    r"货品编号|料号|SKU|MODEL(?:O)?|型号)\s*[：:]?",
    re.IGNORECASE,
)


def _identifier_local_context(text: str, start: int, end: int) -> str:
    """Return the matching line and its immediately preceding label line."""

    line_start = text.rfind("\n", 0, start)
    context_start = text.rfind("\n", 0, max(line_start, 0))
    context_start = 0 if context_start < 0 else context_start + 1
    line_end = text.find("\n", end)
    if line_end < 0:
        return text[context_start:]
    return text[context_start:line_end]


def _identifier_kind(context: str) -> str:
    if _ORDER_IDENTIFIER_CONTEXT_RE.search(context):
        return "order_number"
    if _CONTRACT_IDENTIFIER_CONTEXT_RE.search(context):
        return "contract_number"
    if _PRODUCT_IDENTIFIER_CONTEXT_RE.search(context):
        return "product_identifier"
    return "order_number"


def _identifier_equivalence_key(value: str) -> str:
    compact = re.sub(r"[^A-Z0-9]", "", nfkc_text(value).upper())
    if compact.startswith("P0") and compact[2:].isdigit():
        return f"PO{compact[2:]}"
    return compact


def _identifier_spelling_quality(value: str) -> int:
    normalized = nfkc_text(value).upper().strip()
    compact = re.sub(r"[^A-Z0-9]", "", normalized)
    quality = 1 if compact.startswith("PO") else 0
    if re.match(r"^PO[-/]", normalized):
        quality += 1
    return quality


def _identifier_kind_priority(kind: str) -> int:
    return {
        "order_number": 0,
        "contract_number": 1,
        "product_identifier": 2,
    }.get(kind, 3)


def _identifier_sort_key(candidate: IdentifierCandidate) -> tuple[int, float, int, str]:
    return (
        _identifier_kind_priority(candidate.kind),
        -candidate.score,
        -_identifier_spelling_quality(candidate.value),
        candidate.value,
    )


def _conflicting_identifier_candidates(
    candidates: list[IdentifierCandidate], selected: IdentifierCandidate
) -> list[IdentifierCandidate]:
    selected_key = _identifier_equivalence_key(selected.value)
    return [
        candidate
        for candidate in candidates
        if candidate is not selected
        and candidate.kind == selected.kind
        and _identifier_equivalence_key(candidate.value) != selected_key
    ]


def _extract_pdf_header(
    filename: str,
    pages: list[dict[str, Any]],
    subtype: str,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> DocumentHeader:
    header = DocumentHeader()
    header_evidence = PdfHeaderEvidenceIndex.from_pages(pages)
    title_pattern = re.compile(
        r"备货单|采购(?:订单|合同|单)|销售订单|客户订单|样品(?:单|申请)|"
        r"purchase\s+(?:order|contract)|sample\s+request",
        re.IGNORECASE,
    )
    company_pattern = re.compile(
        r"(?:有限公司|有限责任公司|电子厂|公司)$|\b(?:LTD\.?|LIMITED|INC\.?|CORP\.?)$",
        re.IGNORECASE,
    )
    for page in pages[:3]:
        page_number = int(page["page_number"])
        for line in page.get("text_normalized", "").splitlines():
            candidate = line.strip()
            if not candidate:
                continue
            if header.title is None and title_pattern.search(candidate) and len(candidate) <= 120:
                header.title = candidate
                field_meta["$.header.title"] = FieldMetadata(
                    source_refs=[_pdf_ref(page_number)]
                )
            if header.issuer is None and company_pattern.search(candidate) and len(candidate) <= 160:
                header.issuer = _clean_party_value(candidate)
                field_meta["$.header.issuer"] = FieldMetadata(
                    source_refs=[_pdf_ref(page_number)]
                )

    candidates: dict[str, IdentifierCandidate] = {}
    positioned_number = _positioned_labeled_value(
        header_evidence,
        ORDER_NUMBER_LABEL_PATTERN,
        validator=_is_identifier_candidate,
    )
    if positioned_number is not None:
        explicit_number, explicit_refs, _ = positioned_number
    else:
        explicit_number, explicit_ref = _labeled_value(
            pages,
            ORDER_NUMBER_LABEL_PATTERN,
            validator=_is_identifier_candidate,
        )
        explicit_refs = [explicit_ref] if explicit_ref else []
    filename_upper = nfkc_text(filename).upper()
    for page in pages:
        page_number = int(page["page_number"])
        page_text = page.get("text_normalized", "").upper()
        matches = list(ORDER_NUMBER_RE.finditer(page_text))
        if explicit_number:
            matches.extend(ORDER_NUMBER_RE.finditer(explicit_number.upper()))
        for match in matches:
            value = match.group(1).upper()
            match_text = str(match.string)
            local_context = _identifier_local_context(
                match_text, match.start(1), match.end(1)
            )
            from_explicit_value = bool(
                explicit_number
                and match_text == explicit_number.upper()
                and value in explicit_number.upper()
            )
            kind = (
                "order_number"
                if from_explicit_value
                else _identifier_kind(local_context)
            )
            score = 8.0 if page_number == 1 else 0.0
            if value in filename_upper:
                score += 100.0
            if explicit_number and value in explicit_number.upper():
                score += 50.0
            if kind == "product_identifier":
                score -= 25.0
            refs = (
                list(explicit_refs)
                if explicit_number and value in explicit_number.upper()
                else [_pdf_ref(page_number)]
            )
            existing = candidates.get(value)
            if existing is None:
                candidates[value] = IdentifierCandidate(
                    value=value,
                    kind=kind,
                    context=local_context[:500],
                    source_refs=refs,
                    score=score,
                )
            else:
                for ref in refs:
                    if ref not in existing.source_refs:
                        existing.source_refs.append(ref)
                if score > existing.score:
                    existing.score = score
                    existing.context = local_context[:500]
                if _identifier_kind_priority(kind) < _identifier_kind_priority(
                    existing.kind
                ):
                    existing.kind = kind
    if explicit_number:
        # A spatially paired label is stronger evidence than the legacy global
        # identifier regex.  Keep short and segmented identifiers such as
        # ``PO-123`` or ``AB-12-CD`` instead of silently discarding them because
        # they do not match the historical eight-digit order-number shape.
        explicit_value = re.sub(r"\s+", "", nfkc_text(explicit_number)).strip(
            "：:"
        ).upper()
        if _is_identifier_candidate(explicit_value):
            explicit_score = 50.0
            explicit_pages = [ref.page for ref in explicit_refs if ref.page is not None]
            explicit_score += 8.0 if not explicit_pages or min(explicit_pages) == 1 else 0.0
            if explicit_value in filename_upper:
                explicit_score += 100.0
            existing = candidates.get(explicit_value)
            if existing is None:
                candidates[explicit_value] = IdentifierCandidate(
                    value=explicit_value,
                    kind="order_number",
                    context="PDF labeled order number",
                    source_refs=list(explicit_refs),
                    score=explicit_score,
                )
            else:
                existing.kind = "order_number"
                existing.score = max(existing.score, explicit_score)
                for ref in explicit_refs:
                    if ref not in existing.source_refs:
                        existing.source_refs.append(ref)
    header.candidate_numbers = sorted(candidates.values(), key=_identifier_sort_key)
    positioned_parties = _positioned_party_values(header_evidence)
    labeled_fields: dict[str, tuple[str, Callable[[str], bool]]] = {
        "contract_number": (
            r"合同编号|合同号|CONTRACT\s*(?:NO\.?)?",
            _is_identifier_candidate,
        ),
        "settlement_method": (
            r"结算方式|付款方式|PAYMENT\s*TERMS?",
            _is_non_label_candidate,
        ),
        "delivery_address": (
            r"交货地址|送货地址|DELIVERY\s*ADDRESS",
            _is_non_label_candidate,
        ),
        "buyer": (r"买方|甲\s*方|采购方|BUYER", _is_non_label_candidate),
        "seller": (r"卖方|乙\s*方|供方|SELLER", _is_non_label_candidate),
        "supplier": (r"供应商|SUPPLIER", _is_non_label_candidate),
    }
    for field_name, (labels, validator) in labeled_fields.items():
        positioned_party = positioned_parties.get(field_name)
        if positioned_party is not None:
            value, refs, confidence = positioned_party
        elif field_name in {"buyer", "seller", "supplier"}:
            value, ref = _labeled_value(pages, labels, validator=validator)
            refs = [ref] if ref else []
            confidence = (
                0.7
                if ref is not None
                and str(ref.part or "").endswith("/reading_order")
                else 1.0
            )
        else:
            positioned_value = _positioned_labeled_value(
                header_evidence, labels, validator=validator
            )
            if positioned_value is not None:
                value, refs, confidence = positioned_value
            else:
                value, ref = _labeled_value(pages, labels, validator=validator)
                refs = [ref] if ref else []
                confidence = (
                    0.7
                    if ref is not None
                    and str(ref.part or "").endswith("/reading_order")
                    else 1.0
                )
        if field_name in {"buyer", "seller", "supplier"}:
            value = _clean_party_value(value)
        if value:
            setattr(header, field_name, value)
            field_meta[f"$.header.{field_name}"] = FieldMetadata(
                source_refs=refs, confidence=confidence
            )
    if header.contract_number:
        contract_key = re.sub(r"\s+", "", header.contract_number).upper()
        contract_candidate_found = False
        for candidate in header.candidate_numbers:
            if re.sub(r"\s+", "", candidate.value).upper() == contract_key:
                candidate.kind = "contract_number"
                contract_candidate_found = True
        if (
            not contract_candidate_found
            and 5 <= len(contract_key) <= 64
            and re.search(r"[A-Z]", contract_key)
            and re.search(r"\d", contract_key)
        ):
            contract_meta = field_meta.get("$.header.contract_number")
            header.candidate_numbers.append(
                IdentifierCandidate(
                    value=contract_key,
                    kind="contract_number",
                    context="PDF labeled contract number",
                    source_refs=(
                        list(contract_meta.source_refs) if contract_meta else []
                    ),
                    score=45.0,
                )
            )
    header.candidate_numbers.sort(key=_identifier_sort_key)
    order_candidates = [
        candidate
        for candidate in header.candidate_numbers
        if candidate.kind == "order_number"
    ]
    contract_candidates = [
        candidate
        for candidate in header.candidate_numbers
        if candidate.kind == "contract_number"
    ]
    # ``order_number`` is the compatibility name for the document's primary
    # business identifier. In a purchase contract the explicitly labelled
    # contract number is authoritative; an external PO mentioned in a summary
    # remains an auditable candidate but must not replace the contract identity.
    selectable = (
        contract_candidates or order_candidates
        if subtype == "purchase_contract"
        else order_candidates or contract_candidates
    )
    if selectable:
        selected = selectable[0]
        for candidate in header.candidate_numbers:
            candidate.selected = candidate is selected
        header.order_number = selected.value
        if selected.kind == "contract_number":
            contract_meta = field_meta.get("$.header.contract_number")
            field_meta["$.header.order_number"] = FieldMetadata(
                source_refs=(
                    list(contract_meta.source_refs)
                    if contract_meta
                    else list(selected.source_refs)
                ),
                confidence=(
                    float(contract_meta.confidence) if contract_meta else 0.8
                ),
                inferred=True,
            )
        else:
            field_meta["$.header.order_number"] = FieldMetadata(
                source_refs=selected.source_refs,
                confidence=1.0 if selected.score >= 50 else 0.8,
            )
        conflicts = _conflicting_identifier_candidates(
            header.candidate_numbers, selected
        )
        if conflicts:
            conflict_group = [selected, *conflicts]
            issues.append(
                ValidationIssue(
                    code="ORDER_NUMBER_CONFLICT",
                    severity="warning",
                    message=f"PDF 中存在 {len(conflict_group)} 个同类订单号候选。",
                    paths=["$.header.order_number", "$.header.candidate_numbers"],
                    source_refs=[
                        ref
                        for candidate in conflict_group
                        for ref in candidate.source_refs
                    ],
                    expected=selected.value,
                    actual=[candidate.value for candidate in conflict_group],
                    suggestion="请核对合同正文、页眉和备注中的编号。",
                )
            )
    if not header.order_number:
        issues.append(
            ValidationIssue(
                code="ORDER_NUMBER_MISSING",
                severity="warning",
                message="未在 PDF 原生文本中找到订单号候选。",
                paths=["$.header.order_number"],
                suggestion="请人工确认订单号，或检查该 PDF 是否只有扫描图。",
            )
        )
    if subtype in {"supplier_purchase_order", "purchase_contract"}:
        for target_field, source_field in (
            ("supplier", "seller"),
            ("seller", "supplier"),
        ):
            source = field_meta.get(f"$.header.{source_field}")
            source_value = getattr(header, source_field)
            if (
                getattr(header, target_field) is not None
                or not source_value
                or source is None
                or not source.source_refs
            ):
                continue
            setattr(header, target_field, source_value)
            field_meta[f"$.header.{target_field}"] = FieldMetadata(
                source_refs=list(source.source_refs),
                inferred=True,
                # A role alias cannot be more trustworthy than the located
                # seller/supplier evidence from which it was derived.
                confidence=min(float(source.confidence), 0.9),
                review_required=False,
            )

    # A bare English ``DATE`` is valid only as its own label.  Prevent the
    # suffix in ``DELIVERY DATE``/``SHIP DATE`` (and similar qualified labels)
    # from also becoming the order date; explicit ``ORDER DATE`` remains valid.
    date_labels = (
        r"下单日期|订单日期|制单日期|签订日期|日期|ORDER\s*DATE|"
        r"(?<![^\n\r])DATE"
    )
    positioned_date = _positioned_labeled_value(
        header_evidence, date_labels, validator=_is_date_candidate
    )
    if positioned_date is not None:
        date_raw, date_refs, date_confidence = positioned_date
    else:
        date_raw, date_ref = _labeled_value(
            pages, date_labels, validator=_is_date_candidate
        )
        date_refs = [date_ref] if date_ref else []
        date_confidence = 1.0
    if date_raw:
        # Do not absorb a following field from a line-oriented PDF.
        date_match = re.search(
            r"(?:\d{4}\s*[年./-]\s*)?\d{1,2}\s*(?:月|[./-])\s*\d{1,2}\s*(?:日)?",
            date_raw,
        )
        normalized_raw = re.sub(r"\s+", "", date_match.group(0) if date_match else date_raw)
        parsed, inferred = _date_value(normalized_raw, header.order_number)
        header.date_raw = normalized_raw
        header.date_standard = parsed
        header.date_inferred = inferred
        field_meta["$.header.date_raw"] = FieldMetadata(
            source_refs=date_refs, confidence=date_confidence
        )
        field_meta["$.header.date_standard"] = FieldMetadata(
            source_refs=date_refs,
            inferred=inferred,
            confidence=min(date_confidence, 0.98) if parsed else 0.0,
        )
        if inferred and parsed:
            issues.append(
                ValidationIssue(
                    code="DATE_YEAR_INFERRED",
                    severity="info",
                    message=f"日期原文未写年份，推断为 {parsed.isoformat()}。",
                    paths=["$.header.date_standard"],
                    source_refs=date_refs,
                    actual=normalized_raw,
                )
            )
        elif parsed is None:
            issues.append(
                ValidationIssue(
                    code="DATE_INVALID",
                    severity="warning",
                    message=f"无法解析订单日期：{normalized_raw}",
                    paths=["$.header.date_raw", "$.header.date_standard"],
                    source_refs=date_refs,
                )
            )

    delivery_labels = (
        r"交期|交货日期|要求到货日期|(?:DELIVERY|SHIP|DUE)[\s_.-]*DATE"
    )
    positioned_delivery = _positioned_labeled_value(
        header_evidence, delivery_labels, validator=_is_date_candidate
    )
    if positioned_delivery is not None:
        delivery_raw, delivery_refs, delivery_confidence = positioned_delivery
    else:
        delivery_raw, delivery_ref = _labeled_value(
            pages, delivery_labels, validator=_is_date_candidate
        )
        delivery_refs = [delivery_ref] if delivery_ref else []
        delivery_confidence = 1.0
    if delivery_raw:
        delivery_match = re.search(
            r"(?:\d{4}\s*[年./-]\s*)?\d{1,2}\s*(?:月|[./-])\s*\d{1,2}\s*(?:日)?",
            delivery_raw,
        )
        header.delivery_date_raw = re.sub(
            r"\s+", "", delivery_match.group(0) if delivery_match else delivery_raw
        )
        header.delivery_date_standard = _date_value(
            header.delivery_date_raw, header.order_number
        )[0]
        field_meta["$.header.delivery_date_raw"] = FieldMetadata(
            source_refs=delivery_refs, confidence=delivery_confidence
        )
        field_meta["$.header.delivery_date_standard"] = FieldMetadata(
            source_refs=delivery_refs,
            inferred=not bool(re.search(r"\d{4}", header.delivery_date_raw)),
            confidence=delivery_confidence,
        )

    all_text = "\n".join(page.get("text_normalized", "") for page in pages)
    currency_match = re.search(r"(?:币种\s*[：:]?\s*)?(CNY|RMB|USD|EUR|人民币|美元|欧元)", all_text, re.IGNORECASE)
    if currency_match:
        currency = currency_match.group(1).upper()
        header.currency = {
            "人民币": "CNY",
            "RMB": "CNY",
            "美元": "USD",
            "欧元": "EUR",
        }.get(currency, currency)
        page_number = _first_page_containing(pages, currency_match.group(0))
        field_meta["$.header.currency"] = FieldMetadata(
            source_refs=[_pdf_ref(page_number)]
        )
    else:
        symbol_ref = _cny_symbol_ref(pages)
        if symbol_ref is not None:
            header.currency = "CNY"
            field_meta["$.header.currency"] = FieldMetadata(
                source_refs=[symbol_ref],
                confidence=0.95,
                inferred=True,
            )
    return header


def _extract_pdf_lines(
    pages: list[dict[str, Any]],
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> tuple[list[OrderLine], dict[str, Any], dict[str, SourceReference]]:
    lines: list[OrderLine] = []
    declared: dict[str, Any] = {}
    declared_refs: dict[str, SourceReference] = {}
    custom_headers: set[str] = set()
    found_regions = 0
    stop_pattern = re.compile(r"合计|总计|TOTAL|条款|签字|签章|盖章|制单|审核", re.IGNORECASE)

    for page in pages:
        page_number = int(page["page_number"])
        for table in page.get("tables", []):
            table_index = int(table.get("table_index", 0))
            ocr_derived = bool(table.get("ocr_derived"))

            rows = table.get("rows_normalized", [])
            header_mapping = _table_header_mapping(rows)
            if header_mapping is None:
                continue
            found_regions += 1
            header_end, mapped, custom = header_mapping
            mapped = _contextual_price_mapping(pages, mapped)
            for row_index in range(header_end + 1, len(rows)):
                row = rows[row_index]
                if _table_header_mapping([row]) is not None:
                    continue
                row_text = " ".join(str(cell) for cell in row if cell not in (None, ""))
                values = {
                    field: row[column] if column < len(row) else None
                    for field, (column, _) in mapped.items()
                }
                identity_values = [
                    values.get(field)
                    for field in ("line_no", "model", "product_code", "name_raw", "specification_raw")
                ]
                first_nonempty = next(
                    (str(cell) for cell in row if cell not in (None, "")), ""
                )
                leading_marker = re.sub(r"[\s:：]+", "", first_nonempty)
                is_total = bool(stop_pattern.search(leading_marker)) or (
                    bool(stop_pattern.search(row_text))
                    and not any(
                    value not in (None, "") and not stop_pattern.fullmatch(str(value).strip())
                    for value in identity_values[1:]
                    )
                )
                if is_total:
                    for field, total_key in (
                        ("quantity", "quantity"),
                        ("amount_tax_included", "amount"),
                        ("amount_tax_excluded", "amount"),
                    ):
                        number = _number(values.get(field))
                        if number is not None and total_key not in declared:
                            column = mapped[field][0]
                            declared[total_key] = number
                            declared_refs[total_key] = _table_cell_ref(
                                page_number, table, row_index, column
                            )
                    if "amount" not in declared:
                        monetary_candidates: list[tuple[int, int | Decimal]] = []
                        for column, cell in enumerate(row):
                            cell_text = _clean(cell)
                            if not cell_text or not re.search(
                                r"[¥￥$€]|\d[\d,]*\.\d{2}", cell_text
                            ):
                                continue
                            number = _number(cell_text)
                            if number is not None:
                                monetary_candidates.append((column, number))
                        if monetary_candidates:
                            column, number = monetary_candidates[-1]
                            declared["amount"] = number
                            declared_refs["amount"] = _table_cell_ref(
                                page_number, table, row_index, column
                            )
                    continue
                if stop_pattern.search(row_text) and not any(
                    value not in (None, "") for value in identity_values
                ):
                    break
                has_core = any(
                    values.get(field) not in (None, "")
                    for field in ("model", "product_code", "name_raw", "specification_raw", "quantity")
                )
                if not has_core:
                    continue
                line_index = len(lines)
                line = OrderLine(line_id=f"page:{page_number}/table:{table_index}/row:{row_index}")
                if page.get("render_asset"):
                    line.image_refs.append(str(page["render_asset"]))
                for field, (column, raw_heading) in mapped.items():
                    value = row[column] if column < len(row) else None
                    _set_line_value(line, field, value)
                    raw_key = raw_heading
                    if raw_key in line.raw_columns:
                        raw_key = f"{raw_key}@column:{column}"
                    line.raw_columns[raw_key] = value
                    field_meta[f"$.lines[{line_index}].{field}"] = FieldMetadata(
                        source_refs=_table_cell_refs(
                            page_number, table, row_index, column
                        ),
                        confidence=_table_cell_confidence(
                            table, row_index, column, value
                        ),
                        inferred=ocr_derived
                        and not (
                            table.get("native_aligned")
                            and _table_cell_value_source(table, row_index, column)
                            == "native"
                        ),
                    )
                for column, raw_heading in custom.items():
                    value = row[column] if column < len(row) else None
                    line.custom_fields[raw_heading] = value
                    line.raw_columns[raw_heading] = value
                    custom_headers.add(raw_heading)
                    field_meta[
                        f"$.lines[{line_index}].custom_fields.{raw_heading}"
                    ] = FieldMetadata(
                        source_refs=_table_cell_refs(
                            page_number, table, row_index, column
                        ),
                        confidence=_table_cell_confidence(
                            table, row_index, column, value
                        ),
                        inferred=ocr_derived
                        and not (
                            table.get("native_aligned")
                            and _table_cell_value_source(table, row_index, column)
                            == "native"
                        ),
                    )
                lines.append(line)

    if found_regions == 0:
        issues.append(
            ValidationIssue(
                code="ORDER_TABLE_NOT_FOUND",
                severity="error",
                message="未在 PDF 原生表格中识别到订单明细表头。",
                paths=["$.lines"],
                suggestion="如该 PDF 为扫描件，请启用逐页 OCR/VLM 补充。",
            )
        )
    elif not lines:
        issues.append(
            ValidationIssue(
                code="ORDER_LINES_EMPTY",
                severity="error",
                message="识别到订单表头，但未读取到有效明细行。",
                paths=["$.lines"],
            )
        )
    if custom_headers:
        issues.append(
            ValidationIssue(
                code="UNMAPPED_COLUMNS",
                severity="info",
                message="PDF 未映射列已保留在 custom_fields/raw_columns。",
                paths=["$.lines[*].custom_fields", "$.lines[*].raw_columns"],
                actual=sorted(custom_headers),
            )
        )
    return lines, declared, declared_refs


def _validate_pdf_lines(lines: list[OrderLine]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    numeric_line_numbers = [line.line_no for line in lines if isinstance(line.line_no, int)]
    if len(numeric_line_numbers) != len(set(numeric_line_numbers)):
        issues.append(
            ValidationIssue(
                code="LINE_NUMBER_DUPLICATE",
                severity="warning",
                message="PDF 明细序号存在重复。",
                paths=["$.lines[*].line_no"],
                actual=numeric_line_numbers,
            )
        )
    if numeric_line_numbers:
        expected = list(range(min(numeric_line_numbers), max(numeric_line_numbers) + 1))
        if sorted(set(numeric_line_numbers)) != expected:
            issues.append(
                ValidationIssue(
                    code="LINE_NUMBER_GAP",
                    severity="warning",
                    message="PDF 明细序号存在断档。",
                    paths=["$.lines[*].line_no"],
                    expected=expected,
                    actual=numeric_line_numbers,
                )
            )
    for index, line in enumerate(lines):
        missing: list[str] = []
        if not any((line.model, line.product_code, line.name_raw, line.specification_raw)):
            missing.append("product_identity")
        if line.quantity is None:
            missing.append("quantity")
        if missing:
            issues.append(
                ValidationIssue(
                    code="LINE_CORE_FIELD_MISSING",
                    severity="warning",
                    message=f"第 {line.line_no or index + 1} 行缺少核心字段：{', '.join(missing)}。",
                    paths=[f"$.lines[{index}]"],
                )
            )
        for price_field, amount_field in (
            ("unit_price_tax_included", "amount_tax_included"),
            ("unit_price_tax_excluded", "amount_tax_excluded"),
        ):
            price = getattr(line, price_field)
            amount = getattr(line, amount_field)
            if price is not None and amount is not None and line.quantity is not None:
                calculated = decimal_from_value(price) * decimal_from_value(
                    line.quantity
                )
                if not monetary_values_equal(calculated, amount):
                    issues.append(
                        ValidationIssue(
                            code="LINE_AMOUNT_MISMATCH",
                            severity="warning",
                            message=f"第 {line.line_no or index + 1} 行数量×单价与金额不一致。",
                            paths=[
                                f"$.lines[{index}].quantity",
                                f"$.lines[{index}].{price_field}",
                                f"$.lines[{index}].{amount_field}",
                            ],
                            expected=calculated,
                            actual=amount,
                        )
                    )
    return issues
