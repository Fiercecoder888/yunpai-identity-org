"""Positioned source references used by deterministic PDF order parsing."""

from __future__ import annotations

import re
from typing import Any

from .common import nfkc_text
from m1.documents.models import SourceReference


_CNY_AMOUNT_SYMBOL_RE = re.compile(r"[¥￥]\s*[-+]?\d[\d,]*(?:\.\d+)?")


def _bbox(value: Any) -> list[float] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        result = [float(item) for item in value]
    except (TypeError, ValueError):
        return None
    return result if result[2] > result[0] and result[3] > result[1] else None


def _matrix_value(matrix: Any, row_index: int, column_index: int) -> Any:
    if not isinstance(matrix, list) or row_index >= len(matrix):
        return None
    row = matrix[row_index]
    return row[column_index] if isinstance(row, list) and column_index < len(row) else None


def _value_key(value: Any) -> str:
    return "".join(
        character
        for character in nfkc_text(str(value or "")).casefold()
        if character.isalnum()
    )


def make_pdf_ref(
    page_number: int,
    *,
    table_index: int | None = None,
    row_index: int | None = None,
    column_index: int | None = None,
    part: str | None = None,
    bbox: list[float] | None = None,
    coordinate_space: str | None = None,
) -> SourceReference:
    parts: list[str] = []
    if table_index is not None:
        parts.append(f"table:{table_index}")
    if row_index is not None:
        parts.append(f"row:{row_index}")
    if column_index is not None:
        parts.append(f"column:{column_index}")
    return SourceReference(
        page=page_number,
        part=part or "/".join(parts) or "native_text",
        **({"bbox": bbox} if bbox else {}),
        **({"coordinate_space": coordinate_space} if coordinate_space else {}),
    )


def _cell_bbox(
    table: dict[str, Any], row_index: int, column_index: int, *, native: bool = False
) -> list[float] | None:
    matrix_key = (
        "native_cell_bbox_matrix"
        if native
        else (
            "structured_cell_bbox_matrix"
            if table.get("native_aligned")
            else "cell_bbox_matrix"
        )
    )
    return _bbox(_matrix_value(table.get(matrix_key), row_index, column_index))


def _source_row_index(
    table: dict[str, Any], row_index: int, *, native: bool
) -> int | None:
    if not table.get("native_aligned"):
        return row_index
    indices = table.get(
        "aligned_native_row_indices"
        if native
        else "aligned_structured_row_indices"
    )
    if not isinstance(indices, list) or row_index >= len(indices):
        return None
    value = indices[row_index]
    return int(value) if value is not None else None


def _source_column_index(
    table: dict[str, Any], column_index: int, *, native: bool
) -> int:
    if native or not table.get("native_aligned"):
        return column_index
    indices = table.get("aligned_structured_column_indices")
    if not isinstance(indices, list) or column_index >= len(indices):
        return column_index
    value = indices[column_index]
    return int(value) if value is not None else column_index


def table_cell_ref(
    page_number: int,
    table: dict[str, Any],
    row_index: int,
    column_index: int,
    *,
    native: bool = False,
) -> SourceReference:
    source_row_index = _source_row_index(table, row_index, native=native)
    source_column_index = _source_column_index(
        table, column_index, native=native
    )
    table_index = int(
        table.get("aligned_native_table_index", table.get("table_index", 0))
        if native
        else table.get("table_index", 0)
    )
    coordinate_space = str(
        (
            table.get("native_coordinate_space")
            if native
            else table.get("coordinate_space")
        )
        or "pdf_points"
    )
    ref = make_pdf_ref(
        page_number,
        table_index=table_index,
        row_index=source_row_index if source_row_index is not None else row_index,
        column_index=source_column_index,
        bbox=_cell_bbox(table, row_index, column_index, native=native),
        coordinate_space=coordinate_space,
    )
    if table.get("ocr_derived") and not native:
        ref.part = f"ocr/{ref.part}"
    return ref


def table_cell_value_source(
    table: dict[str, Any], row_index: int, column_index: int
) -> str | None:
    source = _matrix_value(table.get("cell_value_sources"), row_index, column_index)
    return str(source) if source else None


def table_cell_confidence(
    table: dict[str, Any], row_index: int, column_index: int, value: Any
) -> float:
    if value in (None, ""):
        return 0.0
    if not table.get("ocr_derived"):
        return 1.0
    confidence = _matrix_value(
        table.get("cell_confidences"), row_index, column_index
    )
    try:
        return max(0.0, min(1.0, float(confidence)))
    except (TypeError, ValueError):
        return 0.65


def table_cell_refs(
    page_number: int,
    table: dict[str, Any],
    row_index: int,
    column_index: int,
) -> list[SourceReference]:
    if not table.get("native_aligned"):
        return [table_cell_ref(page_number, table, row_index, column_index)]

    refs: list[SourceReference] = []
    structured_row = _source_row_index(table, row_index, native=False)
    if structured_row is not None:
        refs.append(table_cell_ref(page_number, table, row_index, column_index))

    value_source = table_cell_value_source(table, row_index, column_index)
    native_row = _source_row_index(table, row_index, native=True)
    native_value = _matrix_value(
        table.get("native_cell_values"), row_index, column_index
    )
    output_value = _matrix_value(
        table.get("rows_normalized"), row_index, column_index
    )
    native_supports_value = value_source == "native" or (
        native_value not in (None, "")
        and _value_key(native_value) == _value_key(output_value)
    )
    if native_row is not None and native_supports_value:
        refs.append(
            table_cell_ref(
                page_number, table, row_index, column_index, native=True
            )
        )
    return refs


def cny_symbol_ref(pages: list[dict[str, Any]]) -> SourceReference | None:
    """Locate a concrete page/table cell containing a yen-form amount symbol."""

    for page in pages:
        page_number = int(page.get("page_number") or 1)
        for table in page.get("tables") or []:
            if not isinstance(table, dict):
                continue
            rows = table.get("rows_normalized") or table.get("rows_original") or []
            for row_index, row in enumerate(rows):
                if not isinstance(row, list):
                    continue
                for column_index, value in enumerate(row):
                    if _CNY_AMOUNT_SYMBOL_RE.search(nfkc_text(str(value or ""))):
                        refs = table_cell_refs(
                            page_number, table, row_index, column_index
                        )
                        if refs:
                            return refs[0]

        for line_index, line in enumerate(page.get("ocr_lines") or []):
            if not isinstance(line, dict):
                continue
            text = nfkc_text(
                str(line.get("text_normalized") or line.get("text_original") or "")
            )
            if _CNY_AMOUNT_SYMBOL_RE.search(text):
                source = re.sub(
                    r"[^a-z0-9_.-]+",
                    "-",
                    str(line.get("source") or "structured").casefold(),
                ).strip("-")
                return make_pdf_ref(
                    page_number,
                    part=f"structured/{source or 'parser'}/line:{line_index}",
                    bbox=_bbox(line.get("bbox")),
                    coordinate_space=str(
                        line.get("coordinate_space")
                        or page.get("coordinate_space")
                        or "pdf_points"
                    ),
                )

        for block_index, block in enumerate(page.get("text_blocks") or []):
            if not isinstance(block, dict):
                continue
            for line_index, line in enumerate(block.get("lines") or []):
                if not isinstance(line, dict):
                    continue
                text = nfkc_text(
                    str(
                        line.get("text_normalized")
                        or line.get("text_original")
                        or ""
                    )
                )
                if _CNY_AMOUNT_SYMBOL_RE.search(text):
                    return make_pdf_ref(
                        page_number,
                        part=f"native_text/block:{block_index}/line:{line_index}",
                        bbox=_bbox(line.get("bbox")),
                        coordinate_space=str(
                            page.get("coordinate_space") or "pdf_points"
                        ),
                    )

        page_text = nfkc_text(
            str(page.get("native_text_normalized") or page.get("text_normalized") or "")
        )
        if _CNY_AMOUNT_SYMBOL_RE.search(page_text):
            return make_pdf_ref(page_number, part="native_text/currency_symbol")
    return None


__all__ = [
    "cny_symbol_ref",
    "make_pdf_ref",
    "table_cell_confidence",
    "table_cell_ref",
    "table_cell_refs",
    "table_cell_value_source",
]
