"""Lossless-enough deterministic envelope shared by document adapters."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol


@dataclass(slots=True)
class CellValue:
    sheet: str
    coordinate: str
    row: int
    column: int
    value: Any = None
    normalized_value: str | None = None
    formula: str | None = None
    cached_value: Any = None
    data_type: str | None = None
    style_id: int | None = None
    hidden_row: bool = False
    hidden_column: bool = False
    low_visibility_column: bool = False
    merged_range: str | None = None
    inherited_from: str | None = None


@dataclass(slots=True)
class MergedRange:
    ref: str
    min_row: int
    min_col: int
    max_row: int
    max_col: int

    def contains(self, row: int, column: int) -> bool:
        return self.min_row <= row <= self.max_row and self.min_col <= column <= self.max_col


@dataclass(slots=True)
class ImageAnchor:
    image_id: str
    sheet: str
    part_name: str
    media_type: str
    sha256: str
    from_row: int
    from_col: int
    to_row: int
    to_col: int
    relationship_id: str | None = None
    merged_range: str | None = None
    source_kind: str = "drawing"
    display_name: str | None = None


@dataclass(slots=True)
class SheetEnvelope:
    name: str
    cells: dict[tuple[int, int], CellValue] = field(default_factory=dict)
    merged_ranges: list[MergedRange] = field(default_factory=list)
    images: list[ImageAnchor] = field(default_factory=list)
    hidden_rows: set[int] = field(default_factory=set)
    hidden_columns: set[int] = field(default_factory=set)
    low_visibility_columns: set[int] = field(default_factory=set)
    max_row: int = 0
    max_column: int = 0

    def merge_at(self, row: int, column: int) -> MergedRange | None:
        return next((merged for merged in self.merged_ranges if merged.contains(row, column)), None)

    def cell(self, row: int, column: int, *, inherit_merged: bool = False) -> CellValue | None:
        direct = self.cells.get((row, column))
        if direct is not None and direct.value is not None:
            return direct
        if not inherit_merged:
            return direct
        merged = self.merge_at(row, column)
        if merged is None:
            return direct
        anchor = self.cells.get((merged.min_row, merged.min_col))
        if anchor is None:
            return direct
        return CellValue(
            sheet=self.name,
            coordinate=direct.coordinate if direct else coordinate_from_row_col(row, column),
            row=row,
            column=column,
            value=anchor.value,
            normalized_value=anchor.normalized_value,
            formula=anchor.formula,
            cached_value=anchor.cached_value,
            data_type=anchor.data_type,
            style_id=anchor.style_id,
            hidden_row=row in self.hidden_rows,
            hidden_column=column in self.hidden_columns,
            low_visibility_column=column in self.low_visibility_columns,
            merged_range=merged.ref,
            inherited_from=anchor.coordinate,
        )


@dataclass(slots=True)
class DocumentEnvelope:
    path: Path
    original_filename: str
    display_filename: str
    sha256: str
    mime_type: str
    file_kind: str
    date_1904: bool = False
    sheets: list[SheetEnvelope] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class DocumentAdapter(Protocol):
    def parse(self, path: str | Path, original_filename: str | None = None) -> DocumentEnvelope: ...


def column_letters(column: int) -> str:
    result = ""
    while column:
        column, remainder = divmod(column - 1, 26)
        result = chr(65 + remainder) + result
    return result


def coordinate_from_row_col(row: int, column: int) -> str:
    return f"{column_letters(column)}{row}"


__all__ = [
    "CellValue",
    "DocumentAdapter",
    "DocumentEnvelope",
    "ImageAnchor",
    "MergedRange",
    "SheetEnvelope",
    "column_letters",
    "coordinate_from_row_col",
]
