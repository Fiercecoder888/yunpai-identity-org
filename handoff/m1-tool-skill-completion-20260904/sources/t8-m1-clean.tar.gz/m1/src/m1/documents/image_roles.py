"""Geometry-only visual-region roles for spreadsheet images."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Protocol
from zipfile import ZIP_DEFLATED, ZIP_STORED, BadZipFile, ZipFile, ZipInfo

from .envelope import DocumentEnvelope, ImageAnchor, SheetEnvelope
from .parsing.visual_region_routing import (
    GovernedVisualRegionRoutingRuntime,
    VisualAreaBucket,
    VisualAspectBucket,
    VisualGeometryAssessment,
    VisualGeometryReason,
    VisualPositionBucket,
    VisualRegionRole,
    VisualRegionRoutingDecision,
    VisualRegionSourceKind,
    VisualRegionTopology,
)


class HeaderColumnLike(Protocol):
    column: int


class TableRegionLike(Protocol):
    sheet: SheetEnvelope
    header_row: int
    min_column: int
    max_column: int
    columns: Mapping[str, HeaderColumnLike]
    data_start_row: int
    data_end_row: int


@dataclass(frozen=True, slots=True)
class ImageRoleAssessment:
    """Deterministic visual-region role derived from worksheet geometry."""

    role: str
    reason: str
    table_header_row: int | None = None


@dataclass(frozen=True, slots=True)
class AdaptiveImageRoleResult:
    """Value-free decisions plus overrides for one deterministic rebuild."""

    overrides: Mapping[str, ImageRoleAssessment]
    decisions: Mapping[str, VisualRegionRoutingDecision]
    unresolved_image_count: int
    skipped_limit_count: int = 0
    unique_signature_count: int = 0
    reused_decision_count: int = 0
    asset_bytes_read: int = 0
    mode: str = "guarded"
    failures: Mapping[str, str] = field(default_factory=dict)

    def audit_payload(self) -> dict[str, Any]:
        return {
            "schema_version": "m1.spreadsheet-visual-routing.v1",
            "routed_image_count": len(self.decisions),
            "override_count": len(self.overrides),
            "unresolved_image_count": self.unresolved_image_count,
            "skipped_limit_count": self.skipped_limit_count,
            "unique_signature_count": self.unique_signature_count,
            "reused_decision_count": self.reused_decision_count,
            "asset_bytes_read": self.asset_bytes_read,
            "mode": self.mode,
            "status": "degraded" if self.failures else "completed",
            "failures": dict(sorted(self.failures.items())),
            "embedding_semantics": "structural_topology_only",
            "decisions": {
                image_id: decision.model_dump(mode="json")
                for image_id, decision in sorted(self.decisions.items())
            },
        }


def image_row_bounds(image: ImageAnchor, sheet: SheetEnvelope) -> tuple[int, int]:
    if image.merged_range:
        merged = next(
            (item for item in sheet.merged_ranges if item.ref == image.merged_range),
            None,
        )
        if merged:
            return merged.min_row, merged.max_row
    return min(image.from_row, image.to_row), max(image.from_row, image.to_row)


def _image_column_bounds(image: ImageAnchor) -> tuple[int, int]:
    return min(image.from_col, image.to_col), max(image.from_col, image.to_col)


def _overlaps(
    first_start: int, first_end: int, second_start: int, second_end: int
) -> bool:
    return first_start <= second_end and second_start <= first_end


def _compatible_product_anchor(
    image: ImageAnchor,
    regions: list[TableRegionLike],
) -> bool:
    first_col, last_col = _image_column_bounds(image)
    for region in regions:
        if region.sheet.name != image.sheet:
            continue
        first_row, last_row = image_row_bounds(image, region.sheet)
        if _overlaps(
            first_row,
            last_row,
            region.data_start_row,
            region.data_end_row,
        ) and _overlaps(first_col, last_col, region.min_column, region.max_column):
            return True
    return False


def _apply_override(
    image: ImageAnchor,
    regions: list[TableRegionLike],
    assessment: ImageRoleAssessment,
    override: ImageRoleAssessment | None,
) -> ImageRoleAssessment:
    if assessment.role != "unresolved" or override is None:
        return assessment
    try:
        role = VisualRegionRole(override.role)
    except ValueError:
        return assessment
    if role is VisualRegionRole.PRODUCT and not _compatible_product_anchor(
        image,
        regions,
    ):
        return assessment
    return ImageRoleAssessment(
        role=role.value,
        reason=override.reason,
        table_header_row=override.table_header_row,
    )


def classify_image_role(
    image: ImageAnchor,
    regions: list[TableRegionLike],
    *,
    override: ImageRoleAssessment | None = None,
) -> ImageRoleAssessment:
    """Classify one image without inspecting filenames or image pixels.

    Product images are accepted only when their anchor overlaps a detected
    detail-table body and, when present, its explicit image column. Images
    wholly above the table header or sufficiently below the table body are
    structural document visuals. Ambiguous anchors remain unresolved so they
    still trigger ``IMAGE_UNASSOCIATED`` instead of hiding a missing product
    image.
    """

    sheet_regions = [region for region in regions if region.sheet.name == image.sheet]
    if not sheet_regions:
        assessment = ImageRoleAssessment(
            role="unresolved",
            reason="sheet_has_no_detected_table_region",
        )
        return _apply_override(image, regions, assessment, override)

    first_row, last_row = image_row_bounds(image, sheet_regions[0].sheet)
    first_col, last_col = _image_column_bounds(image)
    for region in sheet_regions:
        if not _overlaps(
            first_row,
            last_row,
            region.data_start_row,
            region.data_end_row,
        ):
            continue
        image_column = region.columns.get("image")
        if image_column is not None and first_col <= image_column.column <= last_col:
            return ImageRoleAssessment(
                role="product",
                reason="anchor_overlaps_image_column_and_table_body",
                table_header_row=region.header_row,
            )
        if image_column is None and _overlaps(
            first_col,
            last_col,
            region.min_column,
            region.max_column,
        ):
            return ImageRoleAssessment(
                role="product",
                reason="anchor_overlaps_table_body_without_explicit_image_column",
                table_header_row=region.header_row,
            )

    first_header_row = min(region.header_row for region in sheet_regions)
    if last_row < first_header_row:
        return ImageRoleAssessment(
            role="document_header",
            reason="anchor_precedes_table_header",
            table_header_row=first_header_row,
        )

    last_data_row = max(region.data_end_row for region in sheet_regions)
    if first_row > last_data_row:
        row_gap = first_row - last_data_row - 1
        row_span = last_row - first_row + 1
        # One clear row is strong structural separation. A larger multi-row
        # anchor immediately after the table is also characteristic of a
        # signature/terms block; an adjacent one-row image remains unresolved.
        if row_gap >= 1 or row_span > 1:
            return ImageRoleAssessment(
                role="document_footer",
                reason=(
                    "anchor_follows_table_body_with_structural_gap"
                    if row_gap >= 1
                    else "multirow_anchor_follows_table_body"
                ),
                table_header_row=max(
                    sheet_regions,
                    key=lambda region: region.data_end_row,
                ).header_row,
            )

    assessment = ImageRoleAssessment(
        role="unresolved",
        reason="anchor_does_not_match_structural_or_product_region",
    )
    return _apply_override(image, regions, assessment, override)


def classify_image_roles(
    envelope: DocumentEnvelope,
    regions: list[TableRegionLike],
    *,
    overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> dict[str, ImageRoleAssessment]:
    return {
        image.image_id: classify_image_role(
            image,
            regions,
            override=(overrides or {}).get(image.image_id),
        )
        for sheet in envelope.sheets
        for image in sheet.images
    }


def _position_bucket(
    start: int,
    end: int,
    maximum: int,
) -> VisualPositionBucket:
    if maximum <= 0:
        return VisualPositionBucket.UNKNOWN
    span = max(end - start + 1, 1)
    if span / maximum >= 0.60:
        return VisualPositionBucket.SPANNING
    midpoint = (start + end) / 2
    if midpoint <= maximum / 3:
        return VisualPositionBucket.START
    if midpoint >= maximum * 2 / 3:
        return VisualPositionBucket.END
    return VisualPositionBucket.CENTER


def _area_bucket(image: ImageAnchor, sheet: SheetEnvelope) -> VisualAreaBucket:
    total = max(sheet.max_row, 1) * max(sheet.max_column, 1)
    rows = abs(image.to_row - image.from_row) + 1
    columns = abs(image.to_col - image.from_col) + 1
    ratio = rows * columns / total
    if ratio < 0.01:
        return VisualAreaBucket.TINY
    if ratio < 0.05:
        return VisualAreaBucket.SMALL
    if ratio < 0.20:
        return VisualAreaBucket.MEDIUM
    if ratio < 0.50:
        return VisualAreaBucket.LARGE
    return VisualAreaBucket.DOMINANT


def _aspect_bucket(image: ImageAnchor) -> VisualAspectBucket:
    rows = abs(image.to_row - image.from_row) + 1
    columns = abs(image.to_col - image.from_col) + 1
    ratio = columns / rows
    if ratio < 0.75:
        return VisualAspectBucket.PORTRAIT
    if ratio <= 1.35:
        return VisualAspectBucket.SQUARE
    if ratio <= 3.0:
        return VisualAspectBucket.LANDSCAPE
    return VisualAspectBucket.WIDE


def _spreadsheet_topology(
    image: ImageAnchor,
    sheet: SheetEnvelope,
    regions: list[TableRegionLike],
    *,
    repeated: bool,
) -> VisualRegionTopology:
    first_row, last_row = image_row_bounds(image, sheet)
    first_col, last_col = _image_column_bounds(image)
    sheet_regions = [region for region in regions if region.sheet.name == image.sheet]
    overlapping_regions = [
        region
        for region in sheet_regions
        if _overlaps(
            first_row,
            last_row,
            region.data_start_row,
            region.data_end_row,
        )
        and _overlaps(first_col, last_col, region.min_column, region.max_column)
    ]
    overlaps_text = any(
        first_row <= row <= last_row
        and first_col <= column <= last_col
        and cell.value not in (None, "")
        for (row, column), cell in sheet.cells.items()
    )
    identifier_columns = {
        header.column
        for region in overlapping_regions
        for field_name, header in region.columns.items()
        if field_name in {"product_code", "material_code", "model", "name_raw"}
    }
    return VisualRegionTopology(
        source_kind=VisualRegionSourceKind.SPREADSHEET_ANCHOR,
        horizontal_position=_position_bucket(first_col, last_col, sheet.max_column),
        vertical_position=_position_bucket(first_row, last_row, sheet.max_row),
        area_bucket=_area_bucket(image, sheet),
        aspect_bucket=_aspect_bucket(image),
        overlaps_table_body=bool(overlapping_regions),
        overlaps_text_block=overlaps_text,
        repeated_across_pages=repeated,
        has_nearby_identifier_slot=any(
            first_col - 1 <= column <= last_col + 1 for column in identifier_columns
        ),
    )


_GEOMETRY_REASON_MAP = {
    "anchor_overlaps_image_column_and_table_body": VisualGeometryReason.TABLE_IMAGE_COLUMN,
    "anchor_overlaps_table_body_without_explicit_image_column": VisualGeometryReason.TABLE_BODY,
    "anchor_precedes_table_header": VisualGeometryReason.BEFORE_TABLE_HEADER,
    "anchor_follows_table_body_with_structural_gap": VisualGeometryReason.AFTER_TABLE_BODY,
    "multirow_anchor_follows_table_body": VisualGeometryReason.AFTER_TABLE_BODY,
    "sheet_has_no_detected_table_region": VisualGeometryReason.NO_COMPATIBLE_REGION,
    "anchor_does_not_match_structural_or_product_region": VisualGeometryReason.AMBIGUOUS_OVERLAP,
}


def _geometry_assessment(
    assessment: ImageRoleAssessment,
) -> VisualGeometryAssessment:
    role: VisualRegionRole | None = None
    if assessment.role != "unresolved":
        try:
            role = VisualRegionRole(assessment.role)
        except ValueError:
            role = None
    return VisualGeometryAssessment(
        role=role,
        reason=_GEOMETRY_REASON_MAP.get(
            assessment.reason,
            VisualGeometryReason.INSUFFICIENT_GEOMETRY,
        ),
    )


class SpreadsheetVisualAssetError(RuntimeError):
    """A spreadsheet image cannot cross the visual-model trust boundary."""

    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


_SAFE_IMAGE_MEDIA_TYPES: dict[str, frozenset[str]] = {
    ".bmp": frozenset({"image/bmp", "image/x-ms-bmp"}),
    ".gif": frozenset({"image/gif"}),
    ".jpeg": frozenset({"image/jpeg"}),
    ".jpg": frozenset({"image/jpeg"}),
    ".png": frozenset({"image/png"}),
    ".tif": frozenset({"image/tiff"}),
    ".tiff": frozenset({"image/tiff"}),
    ".webp": frozenset({"image/webp"}),
}
_MAX_SPREADSHEET_IMAGE_BYTES = 20 * 1024 * 1024
_MAX_SPREADSHEET_COMPRESSED_IMAGE_BYTES = 20 * 1024 * 1024
_MAX_SPREADSHEET_IMAGE_COMPRESSION_RATIO = 100.0
_MAX_SPREADSHEET_IMAGE_TOTAL_BYTES = 64 * 1024 * 1024
_MAX_SPREADSHEET_ZIP_ENTRIES = 5000
_SPREADSHEET_IMAGE_READ_CHUNK_BYTES = 1024 * 1024


def _has_expected_image_magic(payload: bytes, suffix: str) -> bool:
    if suffix == ".png":
        return payload.startswith(b"\x89PNG\r\n\x1a\n")
    if suffix in {".jpg", ".jpeg"}:
        return payload.startswith(b"\xff\xd8\xff")
    if suffix == ".gif":
        return payload.startswith((b"GIF87a", b"GIF89a"))
    if suffix == ".bmp":
        return payload.startswith(b"BM")
    if suffix in {".tif", ".tiff"}:
        return payload.startswith((b"II*\x00", b"MM\x00*"))
    if suffix == ".webp":
        return (
            len(payload) >= 12
            and payload.startswith(b"RIFF")
            and payload[8:12] == b"WEBP"
        )
    return False


def _safe_image_type(image: ImageAnchor) -> tuple[str, str]:
    part = PurePosixPath(image.part_name)
    if (
        not image.part_name.startswith("xl/media/")
        or part.is_absolute()
        or ".." in part.parts
        or "\\" in image.part_name
        or "\x00" in image.part_name
    ):
        raise SpreadsheetVisualAssetError("unsafe_asset_locator")
    suffix = part.suffix.casefold()
    media_type = str(image.media_type or "").split(";", 1)[0].strip().casefold()
    if media_type not in _SAFE_IMAGE_MEDIA_TYPES.get(suffix, frozenset()):
        raise SpreadsheetVisualAssetError("unsafe_image_media_type")
    return suffix, media_type


def _validated_zip_info(
    infos_by_name: Mapping[str, tuple[ZipInfo, ...]],
    image: ImageAnchor,
    *,
    max_image_bytes: int,
    max_compressed_image_bytes: int,
    max_compression_ratio: float,
    remaining_total_bytes: int,
) -> tuple[ZipInfo, str, str]:
    suffix, media_type = _safe_image_type(image)
    entries = infos_by_name.get(image.part_name, ())
    if len(entries) != 1:
        raise SpreadsheetVisualAssetError("asset_locator_missing_or_duplicated")
    info = entries[0]
    if info.is_dir() or info.flag_bits & 0x1:
        raise SpreadsheetVisualAssetError("unsafe_image_zip_entry")
    if info.compress_type not in {ZIP_STORED, ZIP_DEFLATED}:
        raise SpreadsheetVisualAssetError("unsafe_image_compression_method")
    file_size = int(info.file_size)
    compressed_size = int(info.compress_size)
    if file_size <= 0 or compressed_size < 0:
        raise SpreadsheetVisualAssetError("invalid_image_entry_size")
    if file_size > max_image_bytes:
        raise SpreadsheetVisualAssetError("image_uncompressed_size_exceeded")
    if compressed_size > max_compressed_image_bytes:
        raise SpreadsheetVisualAssetError("image_compressed_size_exceeded")
    if compressed_size <= 0:
        raise SpreadsheetVisualAssetError("invalid_image_compressed_size")
    if file_size / compressed_size > max_compression_ratio:
        raise SpreadsheetVisualAssetError("image_compression_ratio_exceeded")
    if file_size > remaining_total_bytes:
        raise SpreadsheetVisualAssetError("image_total_read_budget_exceeded")
    return info, suffix, media_type


class _SpreadsheetImageReader:
    """Read verified OOXML images once under a document-wide byte budget."""

    def __init__(
        self,
        source: str | Path,
        *,
        max_image_bytes: int,
        max_compressed_image_bytes: int,
        max_compression_ratio: float,
        max_total_bytes: int,
    ) -> None:
        if min(max_image_bytes, max_compressed_image_bytes, max_total_bytes) < 1:
            raise ValueError("spreadsheet visual byte budgets must be positive")
        if max_compression_ratio <= 0 or not math.isfinite(max_compression_ratio):
            raise ValueError("spreadsheet visual compression ratio must be positive")
        self._source = source
        self._max_image_bytes = min(int(max_image_bytes), _MAX_SPREADSHEET_IMAGE_BYTES)
        self._max_compressed_image_bytes = min(
            int(max_compressed_image_bytes),
            _MAX_SPREADSHEET_COMPRESSED_IMAGE_BYTES,
        )
        self._max_compression_ratio = min(
            float(max_compression_ratio),
            _MAX_SPREADSHEET_IMAGE_COMPRESSION_RATIO,
        )
        self._max_total_bytes = min(
            int(max_total_bytes), _MAX_SPREADSHEET_IMAGE_TOTAL_BYTES
        )
        self._package: ZipFile | None = None
        self._infos_by_name: dict[str, tuple[ZipInfo, ...]] | None = None
        self._payloads: dict[str, bytes] = {}
        self.bytes_read = 0

    def close(self) -> None:
        if self._package is not None:
            self._package.close()
            self._package = None

    def _open(self) -> tuple[ZipFile, Mapping[str, tuple[ZipInfo, ...]]]:
        if self._package is None:
            try:
                self._package = ZipFile(self._source, "r")
            except (BadZipFile, OSError) as exc:
                raise SpreadsheetVisualAssetError("invalid_spreadsheet_zip") from exc
            infos = self._package.infolist()
            if len(infos) > _MAX_SPREADSHEET_ZIP_ENTRIES:
                self.close()
                raise SpreadsheetVisualAssetError(
                    "spreadsheet_zip_entry_limit_exceeded"
                )
            grouped: dict[str, list[ZipInfo]] = {}
            for info in infos:
                grouped.setdefault(info.filename, []).append(info)
            self._infos_by_name = {
                name: tuple(entries) for name, entries in grouped.items()
            }
        assert self._infos_by_name is not None
        return self._package, self._infos_by_name

    def read_verified(self, image: ImageAnchor) -> tuple[bytes, str, str]:
        expected_sha256 = str(image.sha256).strip().casefold()
        if len(expected_sha256) != 64 or any(
            character not in "0123456789abcdef" for character in expected_sha256
        ):
            raise SpreadsheetVisualAssetError("invalid_image_sha256")
        package, infos_by_name = self._open()
        cached = self._payloads.get(image.part_name)
        info, suffix, media_type = _validated_zip_info(
            infos_by_name,
            image,
            max_image_bytes=self._max_image_bytes,
            max_compressed_image_bytes=self._max_compressed_image_bytes,
            max_compression_ratio=self._max_compression_ratio,
            remaining_total_bytes=(
                self._max_total_bytes
                if cached is not None
                else self._max_total_bytes - self.bytes_read
            ),
        )
        if cached is not None:
            actual_sha256 = hashlib.sha256(cached).hexdigest()
            if actual_sha256 != expected_sha256:
                raise SpreadsheetVisualAssetError("image_sha256_mismatch")
            return cached, actual_sha256, media_type

        chunks: list[bytes] = []
        actual_size = 0
        try:
            with package.open(info, "r") as stream:
                while True:
                    chunk = stream.read(_SPREADSHEET_IMAGE_READ_CHUNK_BYTES)
                    if not chunk:
                        break
                    actual_size += len(chunk)
                    if actual_size > int(info.file_size):
                        raise SpreadsheetVisualAssetError("image_entry_size_mismatch")
                    if self.bytes_read + actual_size > self._max_total_bytes:
                        raise SpreadsheetVisualAssetError(
                            "image_total_read_budget_exceeded"
                        )
                    chunks.append(chunk)
        except SpreadsheetVisualAssetError:
            self.bytes_read += actual_size
            raise
        except Exception as exc:
            self.bytes_read += actual_size
            raise SpreadsheetVisualAssetError("image_zip_read_failed") from exc
        self.bytes_read += actual_size
        if actual_size != int(info.file_size):
            raise SpreadsheetVisualAssetError("image_entry_size_mismatch")
        payload = b"".join(chunks)
        if not _has_expected_image_magic(payload, suffix):
            raise SpreadsheetVisualAssetError("image_magic_mismatch")
        actual_sha256 = hashlib.sha256(payload).hexdigest()
        if actual_sha256 != expected_sha256:
            raise SpreadsheetVisualAssetError("image_sha256_mismatch")
        self._payloads[image.part_name] = payload
        return payload, actual_sha256, media_type


_SPREADSHEET_ALLOWED_ROLES = tuple(VisualRegionRole)
_MAX_ROUTED_SPREADSHEET_SIGNATURES = 16


async def route_unresolved_image_roles(
    envelope: DocumentEnvelope,
    regions: list[TableRegionLike],
    *,
    tenant_id: str,
    runtime: GovernedVisualRegionRoutingRuntime,
    max_images: int = _MAX_ROUTED_SPREADSHEET_SIGNATURES,
    max_image_bytes: int = _MAX_SPREADSHEET_IMAGE_BYTES,
    max_compressed_image_bytes: int = _MAX_SPREADSHEET_COMPRESSED_IMAGE_BYTES,
    max_compression_ratio: float = _MAX_SPREADSHEET_IMAGE_COMPRESSION_RATIO,
    max_total_image_bytes: int = _MAX_SPREADSHEET_IMAGE_TOTAL_BYTES,
) -> AdaptiveImageRoleResult:
    """Route only unresolved images and return safe builder overrides."""

    deterministic = classify_image_roles(envelope, regions)
    bounded_max = max(1, min(int(max_images), _MAX_ROUTED_SPREADSHEET_SIGNATURES))
    sha_counts: dict[str, int] = {}
    for sheet in envelope.sheets:
        for image in sheet.images:
            sha_counts[image.sha256] = sha_counts.get(image.sha256, 0) + 1
    overrides: dict[str, ImageRoleAssessment] = {}
    decisions: dict[str, VisualRegionRoutingDecision] = {}
    unresolved_count = 0
    skipped_limit_count = 0
    reused_decision_count = 0
    failures: dict[str, str] = {}
    outcomes: dict[
        tuple[str, str], tuple[VisualRegionRoutingDecision | None, str | None]
    ] = {}
    mode = str(getattr(runtime, "mode", "guarded")).strip().casefold()
    apply_overrides = mode == "guarded"
    reader = _SpreadsheetImageReader(
        envelope.path,
        max_image_bytes=max_image_bytes,
        max_compressed_image_bytes=max_compressed_image_bytes,
        max_compression_ratio=max_compression_ratio,
        max_total_bytes=max_total_image_bytes,
    )
    try:
        for sheet in envelope.sheets:
            for image in sheet.images:
                assessment = deterministic[image.image_id]
                if assessment.role != "unresolved":
                    continue
                unresolved_count += 1
                topology = _spreadsheet_topology(
                    image,
                    sheet,
                    regions,
                    repeated=sha_counts.get(image.sha256, 0) > 1,
                )
                topology_fingerprint = topology.exact_fingerprint()
                claimed_signature = (
                    str(image.sha256).strip().casefold(),
                    topology_fingerprint,
                )
                if len(outcomes) >= bounded_max and claimed_signature not in outcomes:
                    skipped_limit_count += 1
                    continue
                try:
                    image_bytes, verified_sha256, media_type = reader.read_verified(
                        image
                    )
                except SpreadsheetVisualAssetError as exc:
                    if bool(getattr(runtime, "required", False)):
                        raise
                    failures[image.image_id] = exc.code
                    continue
                signature = (verified_sha256, topology_fingerprint)
                if signature in outcomes:
                    decision, failure = outcomes[signature]
                    if failure is not None:
                        failures[image.image_id] = failure
                        continue
                    assert decision is not None
                    reused_decision_count += 1
                else:
                    if len(outcomes) >= bounded_max:
                        skipped_limit_count += 1
                        continue
                    try:
                        decision = await runtime.resolve(
                            tenant_id=tenant_id,
                            geometry=_geometry_assessment(assessment),
                            topology=topology,
                            allowed_roles=_SPREADSHEET_ALLOWED_ROLES,
                            image_bytes=image_bytes,
                            media_type=media_type,
                            asset_sha256=verified_sha256,
                        )
                    except Exception as exc:
                        if bool(getattr(runtime, "required", False)):
                            raise
                        failure = exc.__class__.__name__
                        outcomes[signature] = (None, failure)
                        failures[image.image_id] = failure
                        continue
                    outcomes[signature] = (decision, None)
                decisions[image.image_id] = decision
                if (
                    apply_overrides
                    and decision.action == "route"
                    and decision.role is not None
                ):
                    overrides[image.image_id] = ImageRoleAssessment(
                        role=decision.role.value,
                        reason=f"adaptive_visual_region:{decision.reason}",
                    )
    finally:
        reader.close()
    return AdaptiveImageRoleResult(
        overrides=overrides,
        decisions=decisions,
        unresolved_image_count=unresolved_count,
        skipped_limit_count=skipped_limit_count,
        unique_signature_count=len(outcomes),
        reused_decision_count=reused_decision_count,
        asset_bytes_read=reader.bytes_read,
        mode=mode,
        failures=failures,
    )


__all__ = [
    "AdaptiveImageRoleResult",
    "ImageRoleAssessment",
    "SpreadsheetVisualAssetError",
    "classify_image_role",
    "classify_image_roles",
    "image_row_bounds",
    "route_unresolved_image_roles",
]
