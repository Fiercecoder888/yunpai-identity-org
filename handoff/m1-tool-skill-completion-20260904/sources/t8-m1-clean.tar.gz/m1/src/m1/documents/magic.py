"""Content based file identification for document adapters.

Extensions are hints for decoded text only.  A binary payload never becomes an
image merely because the caller supplied a ``.jpg`` filename.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from zipfile import BadZipFile, ZipFile

from .ooxml import preflight_ooxml_package


@dataclass(frozen=True, slots=True)
class FileTypeInfo:
    kind: str
    mime_type: str
    canonical_extension: str | None = None


_MAGIC_TYPES: tuple[tuple[bytes, FileTypeInfo], ...] = (
    (b"%PDF-", FileTypeInfo("pdf", "application/pdf", ".pdf")),
    (b"\x89PNG\r\n\x1a\n", FileTypeInfo("image", "image/png", ".png")),
    (b"\xff\xd8\xff", FileTypeInfo("image", "image/jpeg", ".jpg")),
    (b"GIF87a", FileTypeInfo("image", "image/gif", ".gif")),
    (b"GIF89a", FileTypeInfo("image", "image/gif", ".gif")),
    (b"BM", FileTypeInfo("image", "image/bmp", ".bmp")),
    (b"II*\x00", FileTypeInfo("image", "image/tiff", ".tif")),
    (b"MM\x00*", FileTypeInfo("image", "image/tiff", ".tif")),
    (
        b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1",
        FileTypeInfo("xls", "application/vnd.ms-excel", ".xls"),
    ),
    (b"Rar!\x1a\x07", FileTypeInfo("rar", "application/vnd.rar", ".rar")),
    (b"7z\xbc\xaf\x27\x1c", FileTypeInfo("7z", "application/x-7z-compressed", ".7z")),
)


def _sniff_zip(path: Path) -> FileTypeInfo:
    try:
        with ZipFile(path) as archive:
            names = {name.lower() for name in archive.namelist()}
            if "xl/workbook.xml" in names:
                preflight_ooxml_package(path, expected_kind="spreadsheet")
                content_types = b""
                try:
                    content_types = archive.read("[Content_Types].xml").lower()
                except KeyError:
                    pass
                if b"macroenabled" in content_types:
                    return FileTypeInfo(
                        "xlsm",
                        "application/vnd.ms-excel.sheet.macroenabled.12",
                        ".xlsm",
                    )
                return FileTypeInfo(
                    "xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    ".xlsx",
                )
            if "word/document.xml" in names:
                preflight_ooxml_package(path, expected_kind="document")
                return FileTypeInfo(
                    "docx",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    ".docx",
                )
            if "ppt/presentation.xml" in names:
                preflight_ooxml_package(path, expected_kind="presentation")
                return FileTypeInfo(
                    "pptx",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    ".pptx",
                )
            return FileTypeInfo("zip", "application/zip", ".zip")
    except (BadZipFile, OSError):
        return FileTypeInfo("unknown", "application/octet-stream")


def _looks_like_delimited_text(data: bytes, suffix: str) -> bool:
    if b"\x00" in data:
        return False
    decoded: str | None = None
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            decoded = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if decoded is None:
        return False
    lines = [line for line in decoded.splitlines() if line.strip()]
    if not lines:
        return suffix in {".csv", ".tsv"}
    delimiters = ("\t",) if suffix == ".tsv" else (",", "\t", ";", "|")
    return suffix in {".csv", ".tsv"} or any(
        delimiter in lines[0] and any(delimiter in line for line in lines[1:4])
        for delimiter in delimiters
    )


def _looks_like_html(data: bytes, suffix: str) -> bool:
    if suffix not in {".html", ".htm"} or b"\x00" in data:
        return False
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            text = data.decode(encoding).lstrip().casefold()
            break
        except UnicodeDecodeError:
            continue
    else:
        return False
    return text.startswith(("<!doctype html", "<html", "<head", "<body"))


def sniff_file_type(path: str | Path) -> FileTypeInfo:
    """Identify a file using bytes, with no binary extension masquerading."""

    source = Path(path)
    with source.open("rb") as stream:
        prefix = stream.read(64 * 1024)
    if prefix.startswith(b"RIFF") and prefix[8:12] == b"WEBP":
        return FileTypeInfo("image", "image/webp", ".webp")
    for signature, result in _MAGIC_TYPES:
        if prefix.startswith(signature):
            return result
    if prefix.startswith(b"PK\x03\x04") or prefix.startswith(b"PK\x05\x06"):
        return _sniff_zip(source)
    suffix = source.suffix.lower()
    if _looks_like_html(prefix, suffix):
        return FileTypeInfo("html", "text/html", ".html")
    if _looks_like_delimited_text(prefix, suffix):
        if suffix == ".tsv" or (b"\t" in prefix and b"," not in prefix):
            return FileTypeInfo("csv", "text/tab-separated-values", ".tsv")
        return FileTypeInfo("csv", "text/csv", ".csv")
    return FileTypeInfo("unknown", "application/octet-stream")


__all__ = ["FileTypeInfo", "sniff_file_type"]
