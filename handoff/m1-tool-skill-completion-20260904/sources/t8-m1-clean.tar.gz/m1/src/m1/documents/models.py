"""Versioned, searchable document contract used by deterministic adapters.

The models in this module deliberately do not depend on the legacy VLM extraction
schemas.  ``DocumentRecord`` keeps those legacy payloads as compatibility fields,
while the typed fields remain the source of truth for document.v2 consumers.
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Severity = Literal["info", "warning", "error"]


class ContractModel(BaseModel):
    """Base class that allows additive fields during the v2 migration."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class DocumentSource(ContractModel):
    original_filename: str
    display_filename: str | None = None
    sha256: str = ""
    mime_type: str = "application/octet-stream"
    archive_path: str | None = None
    sheet: str | None = None
    page: int | None = None

    @model_validator(mode="after")
    def default_display_filename(self) -> DocumentSource:
        if not self.display_filename:
            self.display_filename = self.original_filename
        return self


class SourceReference(ContractModel):
    """Narrow source locator suitable for field and issue evidence."""

    sheet: str | None = None
    page: int | None = None
    cell: str | None = None
    range: str | None = None
    part: str | None = None
    archive_path: str | None = None


class GenericFact(ContractModel):
    """Evidence-backed fact outside the current domain-specific schema."""

    name: str
    value: Any
    source_refs: list[SourceReference] = Field(default_factory=list)
    sensitive: bool = False


class IdentifierCandidate(ContractModel):
    value: str
    kind: str = "order_number"
    context: str | None = None
    source_refs: list[SourceReference] = Field(default_factory=list)
    score: float = 0.0
    selected: bool = False
    hidden: bool = False


class DocumentHeader(ContractModel):
    title: str | None = None
    issuer: str | None = None
    order_number: str | None = None
    candidate_numbers: list[IdentifierCandidate] = Field(default_factory=list)
    contract_number: str | None = None
    date_raw: str | None = None
    date_standard: date | None = None
    date_inferred: bool = False
    delivery_date_raw: str | None = None
    delivery_date_standard: date | None = None
    settlement_method: str | None = None
    delivery_address: str | None = None
    buyer: str | None = None
    seller: str | None = None
    supplier: str | None = None
    currency: str | None = None

    @property
    def order_number_candidates(self) -> list[IdentifierCandidate]:
        """Readable compatibility alias without duplicating the JSON contract."""

        return self.candidate_numbers


class NameAttributes(ContractModel):
    interface: str | None = None
    protocol_version: str | None = None
    resolution: str | None = None
    refresh_rate: str | None = None
    cable_length: str | None = None
    conductor: str | None = None
    shielding: str | None = None
    od: str | None = None
    jacket: str | None = None
    color: str | None = None
    plug: str | None = None
    aluminum_shell: str | None = None
    braided_sleeve: str | None = None
    plating: str | None = None
    branding: str | None = None
    custom: dict[str, Any] = Field(default_factory=dict)


Number = int | float | Decimal


class OrderLine(ContractModel):
    line_id: str
    line_no: int | str | None = None
    model: str | None = None
    product_code: str | None = None
    name_raw: str | None = None
    name_normalized: str | None = None
    full_product_name: str | None = None
    product_category: str | None = None
    name_attributes: NameAttributes = Field(default_factory=NameAttributes)
    specification_raw: str | None = None
    body_printing: str | None = None
    color: str | None = None
    quantity: Number | None = None
    unit: str | None = None
    unit_price_tax_included: Number | None = None
    amount_tax_included: Number | None = None
    unit_price_tax_excluded: Number | None = None
    amount_tax_excluded: Number | None = None
    package_quantity: Number | None = None
    piece_count: Number | None = None
    carton_specification: str | None = None
    volume: Number | None = None
    packaging_requirements: str | None = None
    origin: str | None = None
    remark: str | None = None
    image_refs: list[str] = Field(default_factory=list)
    custom_fields: dict[str, Any] = Field(default_factory=dict)
    raw_columns: dict[str, Any] = Field(default_factory=dict)


class DocumentTotals(ContractModel):
    """Both convenient common totals and lossless generic total maps."""

    declared_quantity: Number | None = None
    calculated_quantity: Number | None = None
    quantity_matches: bool | None = None
    declared_amount: Number | None = None
    calculated_amount: Number | None = None
    amount_matches: bool | None = None
    source_declared: dict[str, Any] = Field(default_factory=dict)
    system_calculated: dict[str, Any] = Field(default_factory=dict)
    matches: dict[str, bool | None] = Field(default_factory=dict)

    @model_validator(mode="after")
    def synchronize_match_aliases(self) -> DocumentTotals:
        """Keep convenience flags and the lossless map as one fact."""

        for key, field_name in (
            ("quantity", "quantity_matches"),
            ("amount", "amount_matches"),
        ):
            direct = getattr(self, field_name)
            if direct is None and key in self.matches:
                setattr(self, field_name, self.matches[key])
            elif direct is not None:
                self.matches[key] = direct
        return self


class FieldMetadata(ContractModel):
    source_refs: list[SourceReference] = Field(default_factory=list)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    inherited_from_merge: bool = False
    inferred: bool = False


class ValidationIssue(ContractModel):
    code: str
    severity: Severity = "warning"
    message: str
    paths: list[str] = Field(default_factory=list)
    source_refs: list[SourceReference] = Field(default_factory=list)
    expected: Any = None
    actual: Any = None
    suggestion: str | None = None


class DocumentRecord(ContractModel):
    schema_version: Literal["m1.document.v2"] = "m1.document.v2"
    source: DocumentSource
    document_type: str = "unknown"
    document_subtype: str = "unknown"
    document_kind_label: str | None = None
    generic_facts: list[GenericFact] = Field(default_factory=list)
    header: DocumentHeader = Field(default_factory=DocumentHeader)
    lines: list[OrderLine] = Field(default_factory=list)
    totals: DocumentTotals = Field(default_factory=DocumentTotals)
    field_meta: dict[str, FieldMetadata] = Field(default_factory=dict)
    validation_issues: list[ValidationIssue] = Field(default_factory=list)
    needs_review: bool = False

    # Legacy M1 response members retained during the migration.
    extraction: dict[str, Any] = Field(default_factory=dict)
    scored_result: dict[str, Any] = Field(default_factory=dict)
    fields: list[Any] = Field(default_factory=list)
    bom: list[dict[str, Any]] = Field(default_factory=list)

    @model_validator(mode="after")
    def synchronize_compatibility_fields(self) -> DocumentRecord:
        if self.document_type == "order" or self.lines:
            self.bom = [line.model_dump(mode="json") for line in self.lines]
        review = (self.model_extra or {}).get("review")
        review_status = review.get("status") if isinstance(review, dict) else None
        unresolved = any(
            issue.severity in {"warning", "error"}
            and str((issue.model_extra or {}).get("status") or "open").casefold()
            not in {"resolved", "accepted", "ignored"}
            for issue in self.validation_issues
        )
        if review_status == "reviewed" and not unresolved:
            self.needs_review = False
        elif review_status == "rejected" or unresolved:
            self.needs_review = True
        return self


__all__ = [
    "DocumentHeader",
    "DocumentRecord",
    "DocumentSource",
    "DocumentTotals",
    "FieldMetadata",
    "GenericFact",
    "IdentifierCandidate",
    "NameAttributes",
    "OrderLine",
    "SourceReference",
    "ValidationIssue",
]
