"""Exact decimal helpers shared by deterministic document adapters."""

from __future__ import annotations

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

MONEY_QUANTUM = Decimal("0.01")
NUMERIC_ABSOLUTE_TOLERANCE = Decimal("1e-9")
NUMERIC_RELATIVE_TOLERANCE = Decimal("1e-12")


def decimal_from_value(value: Any) -> Decimal:
    """Convert numbers without importing a binary float approximation."""

    return value if isinstance(value, Decimal) else Decimal(str(value))


def monetary_values_equal(
    left: Any,
    right: Any,
    *,
    quantum: Decimal = MONEY_QUANTUM,
) -> bool:
    """Compare monetary values at the currency precision used by M1."""

    try:
        return decimal_from_value(left).quantize(
            quantum,
            rounding=ROUND_HALF_UP,
        ) == decimal_from_value(right).quantize(
            quantum,
            rounding=ROUND_HALF_UP,
        )
    except (InvalidOperation, ValueError):
        return False


def numeric_values_equal(
    left: Any,
    right: Any,
    *,
    absolute_tolerance: Decimal = NUMERIC_ABSOLUTE_TOLERANCE,
    relative_tolerance: Decimal = NUMERIC_RELATIVE_TOLERANCE,
) -> bool:
    """Compare non-monetary values while absorbing serialized float noise."""

    try:
        left_value = decimal_from_value(left)
        right_value = decimal_from_value(right)
        if not left_value.is_finite() or not right_value.is_finite():
            return False
        difference = abs(left_value - right_value)
        scale = max(abs(left_value), abs(right_value))
        return difference <= max(absolute_tolerance, scale * relative_tolerance)
    except (InvalidOperation, ValueError):
        return False


__all__ = [
    "MONEY_QUANTUM",
    "NUMERIC_ABSOLUTE_TOLERANCE",
    "NUMERIC_RELATIVE_TOLERANCE",
    "decimal_from_value",
    "monetary_values_equal",
    "numeric_values_equal",
]
