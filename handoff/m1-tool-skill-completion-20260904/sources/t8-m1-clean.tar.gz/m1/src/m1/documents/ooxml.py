"""Bounded preflight for ZIP-based Office packages.

The ZIP container size is not a sufficient safety boundary: a tiny XLSX/DOCX
can expand to hundreds of megabytes of XML.  This module validates the central
directory before any adapter calls ``ZipFile.read`` or an XML parser.
"""
from __future__ import annotations

import posixpath
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

MIB = 1024 * 1024


class OOXMLPackageError(RuntimeError):
    """An Office package is malformed or exceeds a resource boundary."""


@dataclass(frozen=True, slots=True)
class OOXMLPackageLimits:
    max_package_size: int = 100 * MIB
    max_total_uncompressed: int = 512 * MIB
    max_part_size: int = 100 * MIB
    max_xml_part_size: int = 100 * MIB
    max_entries: int = 5000
    max_compression_ratio: float = 100.0


@dataclass(frozen=True, slots=True)
class OOXMLMember:
    name: str
    file_size: int
    compressed_size: int
    is_dir: bool


@dataclass(frozen=True, slots=True)
class OOXMLPackageStats:
    kind: str
    members: tuple[OOXMLMember, ...]
    total_uncompressed: int


def _safe_part_name(name: str) -> str:
    if not name or "\x00" in name or "\\" in name:
        raise OOXMLPackageError(f"Unsafe OOXML part name: {name!r}")
    if name.startswith(("/", "//")) or re.match(r"^[A-Za-z]:", name):
        raise OOXMLPackageError(f"Absolute OOXML part name: {name!r}")
    normalized = posixpath.normpath(name)
    parts = PurePosixPath(normalized).parts
    if normalized in {"", ".", ".."} or any(part == ".." for part in parts):
        raise OOXMLPackageError(f"OOXML part escapes its package: {name!r}")
    return normalized


def preflight_ooxml_package(
    path: str | Path,
    *,
    limits: OOXMLPackageLimits | None = None,
    expected_kind: str | None = None,
) -> OOXMLPackageStats:
    """Validate package entry, expansion and compression budgets.

    No member payload is decompressed.  Returned member metadata can be folded
    into an enclosing archive's shared budget.
    """

    package_path = Path(path)
    policy = limits or OOXMLPackageLimits()
    if not package_path.is_file():
        raise FileNotFoundError(package_path)
    package_size = package_path.stat().st_size
    if package_size > policy.max_package_size:
        raise OOXMLPackageError(
            f"OOXML package exceeds {policy.max_package_size} bytes: {package_size}"
        )
    try:
        with zipfile.ZipFile(package_path, "r") as package:
            infos = package.infolist()
    except (OSError, zipfile.BadZipFile) as exc:
        raise OOXMLPackageError(f"Invalid OOXML ZIP package: {package_path.name}") from exc

    if len(infos) > policy.max_entries:
        raise OOXMLPackageError(
            f"OOXML package has {len(infos)} entries; limit is {policy.max_entries}"
        )

    seen: set[str] = set()
    members: list[OOXMLMember] = []
    total = 0
    for info in infos:
        name = _safe_part_name(info.filename)
        if name in seen:
            raise OOXMLPackageError(f"Duplicate OOXML part: {name}")
        seen.add(name)
        if info.flag_bits & 0x1:
            raise OOXMLPackageError(f"Encrypted OOXML part is unsupported: {name}")
        size = int(info.file_size)
        compressed = int(info.compress_size)
        if size < 0 or compressed < 0:
            raise OOXMLPackageError(f"Invalid OOXML member size: {name}")
        if not info.is_dir():
            part_limit = (
                min(policy.max_part_size, policy.max_xml_part_size)
                if name.casefold().endswith((".xml", ".rels"))
                else policy.max_part_size
            )
            if size > part_limit:
                raise OOXMLPackageError(
                    f"OOXML part exceeds {part_limit} bytes: {name} ({size})"
                )
            if size and compressed <= 0:
                raise OOXMLPackageError(f"Invalid compressed size for OOXML part: {name}")
            if compressed and size / compressed > policy.max_compression_ratio:
                raise OOXMLPackageError(
                    f"OOXML part exceeds {policy.max_compression_ratio:g}:1 "
                    f"compression ratio: {name}"
                )
            total += size
            if total > policy.max_total_uncompressed:
                raise OOXMLPackageError(
                    "OOXML uncompressed total exceeds "
                    f"{policy.max_total_uncompressed} bytes"
                )
        members.append(
            OOXMLMember(
                name=name,
                file_size=size,
                compressed_size=compressed,
                is_dir=info.is_dir(),
            )
        )

    names = {member.name.casefold() for member in members}
    if "[content_types].xml" not in names:
        raise OOXMLPackageError("OOXML package is missing [Content_Types].xml")
    if "xl/workbook.xml" in names:
        kind = "xlsx"
    elif "word/document.xml" in names:
        kind = "docx"
    elif "ppt/presentation.xml" in names:
        kind = "pptx"
    else:
        kind = "unknown"
    if expected_kind == "spreadsheet" and kind != "xlsx":
        raise OOXMLPackageError("OOXML package is not a spreadsheet")
    if expected_kind == "document" and kind != "docx":
        raise OOXMLPackageError("OOXML package is not a Word document")
    if expected_kind == "presentation" and kind != "pptx":
        raise OOXMLPackageError("OOXML package is not a PowerPoint presentation")
    if expected_kind in {"xlsx", "docx", "pptx"} and kind != expected_kind:
        raise OOXMLPackageError(f"Expected OOXML {expected_kind}, got {kind}")
    return OOXMLPackageStats(kind=kind, members=tuple(members), total_uncompressed=total)


__all__ = [
    "OOXMLMember",
    "OOXMLPackageError",
    "OOXMLPackageLimits",
    "OOXMLPackageStats",
    "preflight_ooxml_package",
]
