"""Internal assembly of the normalized order document."""

from __future__ import annotations

import unicodedata
from collections.abc import Mapping
from decimal import Decimal

from .orders import (
    CellValue,
    DocumentEnvelope,
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    DocumentTotals,
    FieldMetadata,
    ImageRoleAssessment,
    ValidationIssue,
    _classify_image_roles,
    _declared_total,
    _document_subtype,
    _extract_date,
    _extract_extended_header,
    _extract_headerless_order_lines,
    _extract_lines,
    _extract_order_numbers,
    _extract_title_and_issuer,
    _source_ref,
    _sum_values,
    _validate_lines,
    attach_derived_line_evidence,
    enrich_order_line,
    find_table_regions,
)

FACADE_DEPENDENCIES = (
    "CellValue",
    "Decimal",
    "DocumentEnvelope",
    "DocumentHeader",
    "DocumentRecord",
    "DocumentSource",
    "DocumentTotals",
    "FieldMetadata",
    "ValidationIssue",
    "_declared_total",
    "_document_subtype",
    "_extract_date",
    "_extract_extended_header",
    "_extract_headerless_order_lines",
    "_extract_lines",
    "_classify_image_roles",
    "_extract_order_numbers",
    "_extract_title_and_issuer",
    "_source_ref",
    "_sum_values",
    "_validate_lines",
    "attach_derived_line_evidence",
    "enrich_order_line",
    "find_table_regions",
)


def _normalized_party(value: str | None) -> str:
    return unicodedata.normalize("NFKC", value or "").strip().casefold()


def _mark_safe_header_derivations(
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    document_subtype: str,
) -> None:
    """Keep auditable party derivations from becoming duplicate review gates.

    ``_extract_extended_header`` may derive the buyer from the document issuer
    for procurement documents.  That is deterministic only when the copied
    value has the exact issuer evidence and is distinct from one unambiguous
    counterparty.  Preserve ``inferred=True`` for audit while explicitly
    marking that narrow case as not requiring another human decision.
    """

    if document_subtype not in {"purchase_contract", "supplier_purchase_order"}:
        return
    buyer_meta = field_meta.get("$.header.buyer")
    issuer_meta = field_meta.get("$.header.issuer")
    if (
        buyer_meta is None
        or issuer_meta is None
        or not buyer_meta.inferred
        or float(buyer_meta.confidence) < 0.9
        or not buyer_meta.source_refs
        or not issuer_meta.source_refs
        or _normalized_party(header.buyer) != _normalized_party(header.issuer)
    ):
        return

    buyer = _normalized_party(header.buyer)
    counterparties = {
        normalized
        for value in (header.seller, header.supplier)
        if (normalized := _normalized_party(value))
    }
    if not buyer or len(counterparties) != 1 or buyer in counterparties:
        return

    buyer_refs = {reference.model_dump_json() for reference in buyer_meta.source_refs}
    issuer_refs = {reference.model_dump_json() for reference in issuer_meta.source_refs}
    if buyer_refs != issuer_refs:
        return
    if not all(
        reference.cell
        or reference.range
        or reference.page is not None
        or reference.part
        for reference in buyer_meta.source_refs
    ):
        return

    buyer_meta.review_required = False


def _build_order_document_impl(
    envelope: DocumentEnvelope,
    subtype_hint: str | None = None,
    *,
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> DocumentRecord:
    field_meta: dict[str, FieldMetadata] = {}
    issues: list[ValidationIssue] = []
    header = DocumentHeader()
    _extract_title_and_issuer(envelope, header, field_meta)
    _extract_order_numbers(envelope, header, field_meta, issues)
    _extract_date(envelope, header, field_meta, issues)
    _extract_extended_header(envelope, header, field_meta, issues)

    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]
    image_roles = _classify_image_roles(envelope, regions, image_role_overrides)
    lines, mapped_images, custom_headers = _extract_lines(
        regions,
        field_meta,
        image_role_overrides,
    )
    headerless_inferred = False
    if not regions:
        lines, inferred_columns = _extract_headerless_order_lines(envelope, field_meta)
        if lines:
            headerless_inferred = True
            custom_headers.update(inferred_columns)
            issues.append(
                ValidationIssue(
                    code="HEADERLESS_TABLE_INFERRED",
                    severity="warning",
                    message="订单缺少显式表头，已依据单位、规格和数值布局保守恢复明细。",
                    paths=["$.lines"],
                    suggestion="请人工确认推断列映射。",
                )
            )
    for line in lines:
        issues.extend(enrich_order_line(line))
    attach_derived_line_evidence(lines, field_meta)
    issues.extend(_validate_lines(lines))

    if not regions and not headerless_inferred:
        issues.append(
            ValidationIssue(
                code="ORDER_TABLE_NOT_FOUND",
                severity="error",
                message="未识别到同时包含数量和产品字段的明细表头。",
                paths=["$.lines"],
                suggestion="确认文档类型或提供 document_subtype_hint。",
            )
        )
    elif not lines:
        issues.append(
            ValidationIssue(
                code="ORDER_LINES_EMPTY",
                severity="error",
                message="识别到表头但未读取到有效明细行。",
                paths=["$.lines"],
            )
        )

    total_label = r"(?:合计|总计|总件数|TOTAL)"
    quantity_columns = [
        region.columns["quantity"].column
        for region in regions
        if "quantity" in region.columns
    ]
    declared_quantity, declared_quantity_cell = _declared_total(
        envelope,
        total_label,
        quantity_columns,
    )
    calculated_quantity = _sum_values(line.quantity for line in lines)
    quantity_matches = (
        (
            declared_quantity is not None
            and calculated_quantity is not None
            and Decimal(declared_quantity) == Decimal(calculated_quantity)
        )
        if declared_quantity is not None
        else None
    )
    totals = DocumentTotals(
        declared_quantity=declared_quantity,
        calculated_quantity=calculated_quantity,
        quantity_matches=quantity_matches,
        source_declared={"quantity": declared_quantity},
        system_calculated={"quantity": calculated_quantity},
        matches={"quantity": quantity_matches},
    )
    if declared_quantity_cell:
        field_meta["$.totals.declared_quantity"] = FieldMetadata(
            source_refs=[_source_ref(declared_quantity_cell)]
        )
    if declared_quantity is not None and quantity_matches is False:
        issues.append(
            ValidationIssue(
                code="TOTAL_QUANTITY_MISMATCH",
                severity="warning",
                message="源文件声明的合计数量与系统逐行重算值不一致。",
                paths=["$.totals.declared_quantity", "$.totals.calculated_quantity"],
                source_refs=[_source_ref(declared_quantity_cell)],
                expected=calculated_quantity,
                actual=declared_quantity,
            )
        )

    amount_field = (
        "amount_tax_included"
        if any(line.amount_tax_included is not None for line in lines)
        else "amount_tax_excluded"
    )
    calculated_amount = _sum_values(getattr(line, amount_field) for line in lines)
    amount_columns = [
        region.columns[amount_field].column
        for region in regions
        if amount_field in region.columns
    ]
    declared_amount: int | Decimal | None = None
    declared_amount_cell: CellValue | None = None
    if amount_columns:
        declared_amount, declared_amount_cell = _declared_total(
            envelope, total_label, amount_columns
        )
    aggregate_amount_matches = (
        (
            declared_amount is not None
            and calculated_amount is not None
            and Decimal(declared_amount) == Decimal(calculated_amount)
        )
        if declared_amount is not None
        else None
    )
    amount_matches = (
        False
        if any(issue.code == "LINE_AMOUNT_MISMATCH" for issue in issues)
        else aggregate_amount_matches
    )
    totals.declared_amount = declared_amount
    totals.calculated_amount = calculated_amount
    totals.amount_matches = amount_matches
    totals.source_declared["amount"] = declared_amount
    totals.system_calculated["amount"] = calculated_amount
    totals.matches["amount"] = amount_matches
    if declared_amount_cell is not None:
        field_meta["$.totals.declared_amount"] = FieldMetadata(
            source_refs=[_source_ref(declared_amount_cell)]
        )
    if declared_amount is not None and aggregate_amount_matches is False:
        issues.append(
            ValidationIssue(
                code="TOTAL_AMOUNT_MISMATCH",
                severity="warning",
                message="源文件声明的合计金额与系统逐行重算值不一致。",
                paths=["$.totals.declared_amount", "$.totals.calculated_amount"],
                source_refs=[_source_ref(declared_amount_cell)],
                expected=calculated_amount,
                actual=declared_amount,
            )
        )

    if custom_headers:
        issues.append(
            ValidationIssue(
                code="UNMAPPED_COLUMNS",
                severity="info",
                message="未映射列已完整保留在 custom_fields/raw_columns。",
                paths=["$.lines[*].custom_fields", "$.lines[*].raw_columns"],
                actual=sorted(custom_headers),
            )
        )
    review_candidate_images = {
        image_id
        for image_id, assessment in image_roles.items()
        if assessment.role in {"product", "unresolved"}
    }
    unmapped_images = sorted(review_candidate_images - mapped_images)
    if unmapped_images:
        issues.append(
            ValidationIssue(
                code="IMAGE_UNASSOCIATED",
                severity="warning",
                message="部分图片无法关联到明细行。",
                paths=["$.lines[*].image_refs"],
                actual=unmapped_images,
            )
        )
    for warning in envelope.warnings:
        if warning.startswith("formula_cache_missing:"):
            issues.append(
                ValidationIssue(
                    code="FORMULA_CACHE_MISSING",
                    severity="warning",
                    message="公式单元格缺少缓存值；未将公式文本冒充确定性数值。",
                    paths=["$.totals"],
                    actual=warning.partition(":")[2],
                )
            )

    source = DocumentSource(
        original_filename=envelope.original_filename,
        display_filename=envelope.display_filename,
        sha256=envelope.sha256,
        mime_type=envelope.mime_type,
        sheet=envelope.sheets[0].name if len(envelope.sheets) == 1 else None,
    )
    document_type = (
        "order"
        if lines or regions or header.order_number or subtype_hint
        else "unknown"
    )
    document_subtype = _document_subtype(
        header.title, subtype_hint, filename=envelope.display_filename
    )
    _mark_safe_header_derivations(header, field_meta, document_subtype)
    if (
        header.supplier is None
        and header.seller
        and document_subtype in {"purchase_contract", "supplier_purchase_order"}
    ):
        header.supplier = header.seller
        seller_meta = field_meta.get("$.header.seller")
        field_meta["$.header.supplier"] = FieldMetadata(
            source_refs=[
                reference.model_copy(deep=True)
                for reference in (seller_meta.source_refs if seller_meta else [])
            ],
            confidence=(
                min(float(seller_meta.confidence), 0.9) if seller_meta else 0.7
            ),
            inferred=True,
            # In a procurement contract, the explicitly labelled seller is
            # the supplier role. Keep the provenance marker without adding a
            # second review blocker for the same source fact.
            review_required=False,
        )
    return DocumentRecord(
        source=source,
        document_type=document_type,
        document_subtype=document_subtype,
        header=header,
        lines=lines,
        totals=totals,
        field_meta=field_meta,
        validation_issues=issues,
        needs_review=any(issue.severity in {"warning", "error"} for issue in issues),
        extraction={
            "adapter": envelope.file_kind,
            "sheet_count": len(envelope.sheets),
            "sheets": [
                {
                    "name": sheet.name,
                    "max_row": sheet.max_row,
                    "max_column": sheet.max_column,
                    "hidden_rows": sorted(sheet.hidden_rows),
                    "hidden_columns": sorted(sheet.hidden_columns),
                    "low_visibility_columns": sorted(sheet.low_visibility_columns),
                    "merged_ranges": [merged.ref for merged in sheet.merged_ranges],
                }
                for sheet in envelope.sheets
            ],
            "formula_cells": [
                {
                    "sheet": cell.sheet,
                    "cell": cell.coordinate,
                    "formula": cell.formula,
                    "cached_value": cell.cached_value,
                }
                for sheet in envelope.sheets
                for cell in sheet.cells.values()
                if cell.formula is not None
            ],
            "images": [
                {
                    "image_id": image.image_id,
                    "sheet": image.sheet,
                    "part_name": image.part_name,
                    "media_type": image.media_type,
                    "sha256": image.sha256,
                    "anchor": {
                        "from_row": image.from_row,
                        "from_column": image.from_col,
                        "to_row": image.to_row,
                        "to_column": image.to_col,
                        "row_span": abs(image.to_row - image.from_row) + 1,
                        "column_span": abs(image.to_col - image.from_col) + 1,
                    },
                    "merged_range": image.merged_range,
                    "source_kind": image.source_kind,
                    "visual_role": image_roles[image.image_id].role,
                    "visual_role_reason": image_roles[image.image_id].reason,
                }
                for sheet in envelope.sheets
                for image in sheet.images
            ],
            "warnings": list(envelope.warnings),
            "table_regions": [
                {
                    "sheet": region.sheet.name,
                    "header_row": region.header_row,
                    "data_start_row": region.data_start_row,
                    "data_end_row": region.data_end_row,
                }
                for region in regions
            ],
        },
    )
