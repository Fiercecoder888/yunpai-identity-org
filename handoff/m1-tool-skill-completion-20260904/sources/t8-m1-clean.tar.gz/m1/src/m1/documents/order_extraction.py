"""Internal deterministic order header and headerless-row extraction."""

from __future__ import annotations

import re
from datetime import date
from decimal import Decimal
from typing import Iterable

from .orders import (
    CellValue,
    DATE_LABEL_RE,
    DocumentEnvelope,
    DocumentHeader,
    FieldMetadata,
    HEADER_ALIASES,
    IdentifierCandidate,
    ORDER_NUMBER_RE,
    OrderLine,
    ValidationIssue,
    _UNIT_VALUES,
    _all_value_cells,
    _candidate_score,
    _clean_string,
    _labeled_value,
    _nfkc,
    _numeric,
    _parse_date_text,
    _source_ref,
    _year_from_order_number,
    column_letters,
)


def _extract_headerless_order_lines_impl(
    envelope: DocumentEnvelope,
    field_meta: dict[str, FieldMetadata],
) -> tuple[list[OrderLine], set[str]]:
    """Conservatively recover compact order rows whose header was deleted.

    This is intentionally narrower than normal region recognition: the sheet must
    contain an order title, a unit cell, a length-like specification and at least
    two explicit numeric cells after the unit.  No blank-cell propagation occurs.
    """

    lines: list[OrderLine] = []
    inferred_columns: set[str] = set()
    for sheet in envelope.sheets:
        sheet_text = "\n".join(
            _nfkc(cell.value)
            for cell in sheet.cells.values()
            if cell.value not in (None, "")
        )
        if not re.search(r"订单|ORDER", sheet_text, re.I):
            continue
        for row in range(1, sheet.max_row + 1):
            cells = [
                sheet.cell(row, column) for column in range(1, sheet.max_column + 1)
            ]
            present = [
                cell
                for cell in cells
                if cell is not None and cell.value not in (None, "")
            ]
            if len(present) < 5:
                continue
            row_text = " ".join(_nfkc(cell.value) for cell in present)
            if re.search(r"合计|总计|总件数|TOTAL", row_text, re.I):
                continue
            unit_cell = next(
                (
                    cell
                    for cell in present
                    if _nfkc(cell.value).strip().upper() in _UNIT_VALUES
                ),
                None,
            )
            if unit_cell is None:
                continue
            spec_cell = next(
                (
                    cell
                    for cell in present
                    if cell.column < unit_cell.column
                    and re.search(
                        r"(?<!\d)\d+(?:\.\d+)?\s*(?:M|米|CM|厘米)(?![A-Z])",
                        _nfkc(cell.value),
                        re.I,
                    )
                ),
                None,
            )
            numeric_after = [
                (cell, _numeric(cell.value))
                for cell in present
                if cell.column > unit_cell.column and _numeric(cell.value) is not None
            ]
            if spec_cell is None or len(numeric_after) < 2:
                continue
            quantity_cell, quantity = max(
                numeric_after, key=lambda item: Decimal(item[1])
            )
            later_numbers = [
                (cell, value)
                for cell, value in numeric_after
                if cell.column > quantity_cell.column
            ]

            identity_cells = [
                cell
                for cell in present
                if 1 < cell.column < unit_cell.column and cell is not spec_cell
            ]
            if not identity_cells:
                continue
            name_cell = max(identity_cells, key=lambda cell: len(_nfkc(cell.value)))
            model_cell = next(
                (
                    cell
                    for cell in identity_cells
                    if cell is not name_cell
                    and re.search(r"[A-Z].*\d|\d.*[A-Z]", _nfkc(cell.value), re.I)
                ),
                None,
            )
            first_cell = present[0]
            line_no = _numeric(first_cell.value) if first_cell.column <= 2 else None
            line = OrderLine(
                line_id=f"{sheet.name}:row:{row}",
                line_no=line_no,
                model=_clean_string(model_cell.value) if model_cell else None,
                name_raw=_clean_string(name_cell.value, preserve=True),
                specification_raw=_clean_string(spec_cell.value, preserve=True),
                quantity=quantity,
                unit=_clean_string(unit_cell.value),
            )

            text_after_unit = [
                cell
                for cell in present
                if unit_cell.column < cell.column < quantity_cell.column
                and _numeric(cell.value) is None
            ]
            printing = next(
                (
                    cell
                    for cell in text_after_unit
                    if re.search(r"印字|字样|LOGO", _nfkc(cell.value), re.I)
                ),
                None,
            )
            if printing is not None:
                line.body_printing = _clean_string(printing.value, preserve=True)
            packaging_cells = [cell for cell in text_after_unit if cell is not printing]
            if packaging_cells:
                line.packaging_requirements = "；".join(
                    _clean_string(cell.value, preserve=True) or ""
                    for cell in packaging_cells
                ).strip("；")
            if later_numbers:
                line.package_quantity = later_numbers[0][1]
            if len(later_numbers) > 1:
                line.piece_count = later_numbers[1][1]
            carton_cell = next(
                (
                    cell
                    for cell in present
                    if cell.column > quantity_cell.column
                    and re.search(r"\d+(?:\.\d+)?\s*[xX*×]\s*\d+", _nfkc(cell.value))
                ),
                None,
            )
            if carton_cell is not None:
                line.carton_specification = _clean_string(carton_cell.value)

            mapped_cells = {
                cell.coordinate
                for cell in (
                    first_cell,
                    model_cell,
                    name_cell,
                    spec_cell,
                    unit_cell,
                    quantity_cell,
                    printing,
                    carton_cell,
                )
                if cell is not None
            }
            for cell in present:
                key = f"column_{column_letters(cell.column)}"
                line.raw_columns[key] = cell.value
                inferred_columns.add(key)
                if cell.coordinate not in mapped_cells:
                    line.custom_fields[key] = cell.value

            line_index = len(lines)
            mapped = {
                "line_no": first_cell,
                "model": model_cell,
                "name_raw": name_cell,
                "specification_raw": spec_cell,
                "unit": unit_cell,
                "quantity": quantity_cell,
                "body_printing": printing,
                "carton_specification": carton_cell,
            }
            for field_name, cell in mapped.items():
                if cell is not None:
                    field_meta[f"$.lines[{line_index}].{field_name}"] = FieldMetadata(
                        source_refs=[_source_ref(cell)],
                        confidence=0.8,
                        inferred=True,
                    )
            lines.append(line)
    return lines, inferred_columns


def _all_value_cells_impl(envelope: DocumentEnvelope) -> Iterable[CellValue]:
    for sheet in envelope.sheets:
        for cell in sheet.cells.values():
            if cell.value not in (None, ""):
                yield cell


def _extract_title_and_issuer_impl(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
) -> None:
    title_markers = re.compile(
        r"备货单|采购(?:订单|合同|单)|销售订单|样品(?:单|申请)|订单|合同"
    )
    party_label = re.compile(
        r"^\s*(?:供应商|供方|卖方|乙方|买方|甲方|采购方|客户名称)\s*[：:]",
        re.I,
    )
    early_cells = sorted(
        _all_value_cells(envelope), key=lambda cell: (cell.row, cell.column)
    )
    for cell in early_cells:
        if cell.row > 12:
            continue
        text = _clean_string(cell.value) or ""
        if header.title is None and title_markers.search(text) and len(text) <= 80:
            header.title = text
            field_meta["$.header.title"] = FieldMetadata(
                source_refs=[_source_ref(cell)]
            )
        company_match = re.search(
            r"([^\n，,；;]{2,80}(?:有限公司|有限责任公司|电子厂|公司|集团))",
            text,
        )
        if (
            header.issuer is None
            and company_match
            and len(text) <= 100
            and not party_label.search(text)
        ):
            header.issuer = company_match.group(1).strip()
            field_meta["$.header.issuer"] = FieldMetadata(
                source_refs=[_source_ref(cell)]
            )


def _candidate_score_impl(
    cell: CellValue,
    value: str,
    filename: str,
    *,
    adjacent_context: str = "",
) -> float:
    context = _nfkc(cell.value).upper()
    nearby = f"{_nfkc(adjacent_context).upper()} {context}".strip()
    score = 0.0
    if value.upper() in _nfkc(filename).upper():
        score += 100.0
    if re.search(r"订单号\s*[：:]", context):
        score += 45.0
    elif re.search(r"订单号码\s*[：:]", context):
        score += 35.0
    # Many order forms put the label in the cell immediately to the left and
    # only the value in this cell.  Treat that explicit pair like an inline
    # label instead of falling back to row/value lexical ordering.
    if re.search(
        r"(?:^|\s)订单(?:号|号码)\s*[：:]?\s*$", _nfkc(adjacent_context).upper()
    ):
        score += 45.0
    if cell.row <= 5:
        score += 8.0
    if cell.merged_range:
        score += 5.0
    if cell.hidden_row or cell.hidden_column or cell.low_visibility_column:
        score -= 30.0
    # Narrative notes are evidence but weak candidates for the primary identifier.
    if len(context) > 40 or re.search(
        r"以免搞混|备注|说明|旧订单号|原订单号|历史订单|错号|误写|作废",
        nearby,
    ):
        score -= 25.0
    return score


_ORDER_IDENTIFIER_CONTEXT_RE = re.compile(
    r"(?:(?:订单(?:号|号码|编号)|采购单号)\s*[：:]?|"
    r"PO\s*(?:NO\.?)?\s*[：:])",
    re.I,
)
_CONTRACT_IDENTIFIER_CONTEXT_RE = re.compile(
    r"(?:合同(?:编号|号)|CONTRACT\s*(?:NO\.?)?)\s*[：:]?",
    re.I,
)
_PRODUCT_IDENTIFIER_CONTEXT_RE = re.compile(
    r"(?:产品标签|标签条码|条形码|条码|物料(?:编码|编号)|产品(?:编码|编号)|"
    r"货品编号|料号|SKU|MODEL(?:O)?|型号)\s*[：:]?",
    re.I,
)


def _identifier_kind(context: str, adjacent_context: str = "") -> str:
    """Classify an identifier by its local label, without discarding evidence."""

    nearby = f"{_nfkc(adjacent_context)} {_nfkc(context)}".strip()
    if _ORDER_IDENTIFIER_CONTEXT_RE.search(nearby):
        return "order_number"
    if _CONTRACT_IDENTIFIER_CONTEXT_RE.search(nearby):
        return "contract_number"
    if _PRODUCT_IDENTIFIER_CONTEXT_RE.search(nearby):
        return "product_identifier"
    return "order_number"


def _identifier_equivalence_key(value: str) -> str:
    """Fold only the common OCR ``PO``/``P0`` prefix ambiguity for comparison.

    The original value remains in ``candidate_numbers`` for audit.  A lone
    identifier beginning with ``P0`` is never rewritten; the key is used only
    to recognize two observed spellings as variants of the same identifier.
    """

    compact = re.sub(r"[^A-Z0-9]", "", _nfkc(value).upper())
    if compact.startswith("P0") and compact[2:].isdigit():
        return f"PO{compact[2:]}"
    return compact


def _identifier_spelling_quality(value: str) -> int:
    normalized = _nfkc(value).upper().strip()
    compact = re.sub(r"[^A-Z0-9]", "", normalized)
    quality = 1 if compact.startswith("PO") else 0
    if re.match(r"^PO[-/]", normalized):
        quality += 1
    return quality


def _identifier_kind_priority(kind: str) -> int:
    return {
        "order_number": 0,
        "contract_number": 1,
        "product_identifier": 2,
    }.get(kind, 3)


def _identifier_sort_key(candidate: IdentifierCandidate) -> tuple[int, float, int, str]:
    return (
        _identifier_kind_priority(candidate.kind),
        -candidate.score,
        -_identifier_spelling_quality(candidate.value),
        candidate.value,
    )


def _conflicting_identifier_candidates(
    candidates: list[IdentifierCandidate], selected: IdentifierCandidate
) -> list[IdentifierCandidate]:
    selected_key = _identifier_equivalence_key(selected.value)
    return [
        candidate
        for candidate in candidates
        if candidate is not selected
        and candidate.kind == selected.kind
        and _identifier_equivalence_key(candidate.value) != selected_key
    ]


def _extract_order_numbers_impl(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    grouped: dict[str, IdentifierCandidate] = {}
    sheets = {sheet.name: sheet for sheet in envelope.sheets}
    for cell in _all_value_cells(envelope):
        text = _nfkc(cell.value).upper()
        for match in ORDER_NUMBER_RE.finditer(text):
            value = match.group(1).upper()
            sheet = sheets.get(cell.sheet)
            adjacent_context = ""
            if sheet is not None:
                left_values = []
                for offset in (1, 2):
                    if cell.column - offset < 1:
                        continue
                    left = sheet.cell(
                        cell.row, cell.column - offset, inherit_merged=True
                    )
                    if left is not None and left.value is not None:
                        left_values.append(_clean_string(left.value) or "")
                adjacent_context = " ".join(value for value in left_values if value)
            score = _candidate_score(
                cell,
                value,
                envelope.original_filename,
                adjacent_context=adjacent_context,
            )
            kind = _identifier_kind(text, adjacent_context)
            candidate = grouped.get(value)
            ref = _source_ref(cell)
            if candidate is None:
                grouped[value] = IdentifierCandidate(
                    value=value,
                    kind=kind,
                    context=text[:500],
                    source_refs=[ref],
                    score=score,
                    hidden=bool(
                        cell.hidden_row
                        or cell.hidden_column
                        or cell.low_visibility_column
                    ),
                )
            else:
                candidate.source_refs.append(ref)
                if score > candidate.score:
                    candidate.score = score
                    candidate.context = text[:500]
                if _identifier_kind_priority(kind) < _identifier_kind_priority(
                    candidate.kind
                ):
                    candidate.kind = kind
                candidate.hidden = candidate.hidden and bool(
                    cell.hidden_row or cell.hidden_column or cell.low_visibility_column
                )
    header.candidate_numbers = sorted(grouped.values(), key=_identifier_sort_key)
    selectable = [
        candidate
        for candidate in header.candidate_numbers
        if candidate.kind in {"order_number", "contract_number"}
    ]
    if not selectable:
        issues.append(
            ValidationIssue(
                code="ORDER_NUMBER_MISSING",
                severity="warning",
                message="未在原文件中找到订单号候选。",
                paths=["$.header.order_number"],
                suggestion="请人工确认订单号。",
            )
        )
        return
    selected = selectable[0]
    selected.selected = True
    header.order_number = selected.value
    field_meta["$.header.order_number"] = FieldMetadata(
        source_refs=selected.source_refs,
        confidence=1.0 if selected.score >= 50 else 0.75,
    )
    conflicts = _conflicting_identifier_candidates(
        header.candidate_numbers, selected
    )
    if conflicts:
        conflict_group = [selected, *conflicts]
        issues.append(
            ValidationIssue(
                code="ORDER_NUMBER_CONFLICT",
                severity="warning",
                message=(
                    f"订单号存在 {len(conflict_group)} 个同类候选；"
                    f"按文件名、显式标签与可见性选择 {selected.value}。"
                ),
                paths=["$.header.order_number", "$.header.candidate_numbers"],
                source_refs=[
                    ref
                    for candidate in conflict_group
                    for ref in candidate.source_refs
                ],
                expected=selected.value,
                actual=[candidate.value for candidate in conflict_group],
                suggestion="审核原文件中的旧号和备注号，确认主订单号。",
            )
        )


def _year_from_order_number_impl(
    order_number: str | None, month: int, day: int
) -> int | None:
    if not order_number:
        return None
    digits = re.sub(r"\D", "", order_number)
    for offset in range(0, max(0, len(digits) - 5)):
        fragment = digits[offset : offset + 6]
        if len(fragment) != 6:
            continue
        year, candidate_month, candidate_day = map(
            int, (fragment[:2], fragment[2:4], fragment[4:6])
        )
        if candidate_month == month and candidate_day == day:
            return 2000 + year if year < 80 else 1900 + year
    return None


def _parse_date_text_impl(
    raw: str, order_number: str | None
) -> tuple[date | None, bool]:
    numbers = [int(number) for number in re.findall(r"\d+", _nfkc(raw))]
    try:
        if len(numbers) >= 3 and numbers[0] >= 1000:
            return date(numbers[0], numbers[1], numbers[2]), False
        if len(numbers) >= 2:
            month, day = numbers[-2], numbers[-1]
            year = (
                _year_from_order_number(order_number, month, day) or date.today().year
            )
            return date(year, month, day), True
    except ValueError:
        return None, False
    return None, False


def _extract_date_impl(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    for cell in _all_value_cells(envelope):
        match = DATE_LABEL_RE.search(_nfkc(cell.value))
        if not match:
            continue
        raw = re.sub(r"\s+", "", match.group(1))
        parsed, inferred = _parse_date_text(raw, header.order_number)
        header.date_raw = raw
        header.date_standard = parsed
        header.date_inferred = inferred
        field_meta["$.header.date_raw"] = FieldMetadata(source_refs=[_source_ref(cell)])
        field_meta["$.header.date_standard"] = FieldMetadata(
            source_refs=[_source_ref(cell)],
            confidence=0.98 if parsed else 0.0,
            inferred=inferred,
        )
        if inferred and parsed:
            issues.append(
                ValidationIssue(
                    code="DATE_YEAR_INFERRED",
                    severity="info",
                    message=f"日期原文未写年份；根据订单号/当前生产年份推断为 {parsed.isoformat()}。",
                    paths=["$.header.date_standard"],
                    source_refs=[_source_ref(cell)],
                    expected="原文包含年份",
                    actual=raw,
                    suggestion="如订单号年份并非下单年份，请人工修正。",
                )
            )
        elif parsed is None:
            issues.append(
                ValidationIssue(
                    code="DATE_INVALID",
                    severity="warning",
                    message=f"无法解析订单日期：{raw}",
                    paths=["$.header.date_raw", "$.header.date_standard"],
                    source_refs=[_source_ref(cell)],
                )
            )
        return

    raw, cell = _labeled_value(
        envelope,
        ("下单日期", "订单日期", "制单日期", "签订日期", "签约日期", "日期"),
    )
    if raw is None or cell is None:
        return
    raw = re.sub(r"\s+", "", raw)
    parsed, inferred = _parse_date_text(raw, header.order_number)
    header.date_raw = raw
    header.date_standard = parsed
    header.date_inferred = inferred
    field_meta["$.header.date_raw"] = FieldMetadata(source_refs=[_source_ref(cell)])
    field_meta["$.header.date_standard"] = FieldMetadata(
        source_refs=[_source_ref(cell)],
        confidence=0.98 if parsed else 0.0,
        inferred=inferred,
    )
    if parsed is None:
        issues.append(
            ValidationIssue(
                code="DATE_INVALID",
                severity="warning",
                message=f"无法解析订单日期：{raw}",
                paths=["$.header.date_raw", "$.header.date_standard"],
                source_refs=[_source_ref(cell)],
            )
        )


_HORIZONTAL_HEADER_LABELS = {
    "合同编号",
    "合同号",
    "CONTRACT NO",
    "CONTRACT NUMBER",
    "订单号",
    "订单号码",
    "采购单号",
    "PO NO",
    "下单日期",
    "订单日期",
    "制单日期",
    "签订日期",
    "合同日期",
    "签约日期",
    "日期",
    "CONTRACT DATE",
    "ORDER DATE",
    "DATE",
    "交期",
    "交货日期",
    "交货时间",
    "到货日期",
    "要求到货日期",
    "DELIVERY DATE",
    "结算方式",
    "结款方式",
    "结算方式及期限",
    "付款方式",
    "支付方式",
    "PAYMENT TERMS",
    "交货地址",
    "送货地址",
    "收货地址",
    "DELIVERY ADDRESS",
    "买方",
    "甲方",
    "采购方",
    "客户名称",
    "BUYER",
    "卖方",
    "乙方",
    "供方",
    "SELLER",
    "供应商",
    "SUPPLIER",
    "币种",
    "CURRENCY",
    "地址",
    "联系人",
    "电话",
    "手机",
    "签约地",
    "合计",
    "总计",
    "TOTAL",
    *(alias for aliases in HEADER_ALIASES.values() for alias in aliases),
}


def _field_label_key(value: object) -> str:
    return re.sub(r"[\s:：.]", "", _nfkc(value)).casefold()


_HORIZONTAL_HEADER_LABEL_KEYS = frozenset(
    _field_label_key(label) for label in _HORIZONTAL_HEADER_LABELS
)
_COMPACT_DATE_LABEL_KEYS = frozenset(
    _field_label_key(label)
    for label in (
        "下单日期",
        "订单日期",
        "制单日期",
        "签订日期",
        "合同日期",
        "签约日期",
        "日期",
        "交期",
        "交货日期",
        "交货时间",
        "到货日期",
        "要求到货日期",
        "CONTRACT DATE",
        "ORDER DATE",
        "DELIVERY DATE",
        "DATE",
    )
)


def _is_explicit_field_label(value: object) -> bool:
    normalized = _nfkc(value).strip()
    compact = _field_label_key(normalized)
    if compact in _HORIZONTAL_HEADER_LABEL_KEYS:
        return True
    if any(
        compact.startswith(label_key)
        and re.match(r"(?:19|20)\d{2}", compact[len(label_key) :])
        for label_key in _COMPACT_DATE_LABEL_KEYS
    ):
        return True
    label = re.split(r"[:：]", normalized, maxsplit=1)[0]
    if _field_label_key(label) in _HORIZONTAL_HEADER_LABEL_KEYS:
        return True
    # Some spreadsheets write an inline field as ``下单日期 2026-07-21``
    # without a colon. Check every whitespace boundary so labels that contain
    # spaces themselves (for example ``CONTRACT DATE``) still work.
    parts = re.split(r"\s+", normalized)
    return any(
        _field_label_key(" ".join(parts[:boundary]))
        in _HORIZONTAL_HEADER_LABEL_KEYS
        for boundary in range(1, len(parts))
    )


def _labeled_value_impl(
    envelope: DocumentEnvelope, labels: tuple[str, ...]
) -> tuple[str | None, CellValue | None]:
    label_pattern = "|".join(
        r"\s*".join(re.escape(character) for character in label)
        for label in labels
    )
    pattern = re.compile(
        rf"(?:^|[\s,，;；、])(?:{label_pattern})\s*"
        rf"(?P<separator>[:：]|NO\.?|编号)?\s*(.*)$",
        re.I,
    )
    label_values = {_field_label_key(label) for label in labels}
    for sheet in envelope.sheets:
        for cell in sorted(
            sheet.cells.values(), key=lambda item: (item.row, item.column)
        ):
            if cell.value in (None, ""):
                continue
            text = _nfkc(cell.value).strip()
            match = pattern.search(text)
            if match is None:
                continue
            inline = match.group(2).strip(" :：")
            if inline and match.group("separator") is None:
                continue
            if inline and _field_label_key(inline) not in label_values:
                if _is_explicit_field_label(inline):
                    continue
                return inline, cell
            for column in range(
                cell.column + 1, min(sheet.max_column, cell.column + 4) + 1
            ):
                candidate = sheet.cell(cell.row, column, inherit_merged=True)
                if candidate is not None and candidate.value not in (None, ""):
                    if candidate.inherited_from == cell.coordinate:
                        continue
                    candidate_text = _nfkc(candidate.value).strip()
                    if _field_label_key(candidate_text) in label_values:
                        continue
                    if _is_explicit_field_label(candidate_text):
                        break
                    return candidate_text, candidate
    return None, None


_CONTRACT_DATE_LABEL_RE = re.compile(
    r"^(?:签订日期|合同日期|下单日期|订单日期|制单日期|签约日期|"
    r"CONTRACT\s+DATE|ORDER\s+DATE|DATE)(?:\s*[：:]|$|\s*(?=(?:19|20)\d{2}))",
    re.I,
)
_CONTRACT_DATE_VALUE_RE = re.compile(
    r"^(?:19|20)\d{2}\s*(?:年|[./-])\s*\d{1,2}\s*"
    r"(?:月|[./-])\s*\d{1,2}\s*(?:日)?(?:[T\s]+00:00(?::00)?)?$",
    re.I,
)


def _contract_number_is_date_contamination(value: str) -> bool:
    normalized = _nfkc(value).strip()
    return bool(
        _CONTRACT_DATE_LABEL_RE.match(normalized)
        or _CONTRACT_DATE_VALUE_RE.fullmatch(normalized)
    )


def _extract_extended_header_impl(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    mappings = {
        "contract_number": ("合同编号", "合同号", "CONTRACT NO", "CONTRACT NUMBER"),
        "settlement_method": (
            "结算方式",
            "结款方式",
            "结算方式及期限",
            "付款方式",
            "支付方式",
            "PAYMENT TERMS",
        ),
        "delivery_address": ("交货地址", "送货地址", "收货地址", "DELIVERY ADDRESS"),
        "buyer": ("买方", "甲方", "采购方", "客户名称", "BUYER"),
        "seller": ("卖方", "乙方", "供方", "SELLER"),
        "supplier": ("供应商", "SUPPLIER"),
        "currency": ("币种", "CURRENCY"),
    }
    for field_name, labels in mappings.items():
        value, cell = _labeled_value(envelope, labels)
        if value is None or cell is None:
            continue
        value = re.split(
            r"(?:[,，;；]|\s{2,})(?=(?:地址|联系人|电话|手机|订单(?:号|号码|日期)|"
            r"签订日期|签约日期|签约地|交货日期|结款方式)\s*[：:])",
            value,
            maxsplit=1,
        )[0].strip()
        if field_name == "contract_number":
            if _contract_number_is_date_contamination(value):
                continue
            value = re.split(r"[,，;；\s]", value, maxsplit=1)[0].strip()
            if (
                not value
                or _contract_number_is_date_contamination(value)
                or re.search(r"X{2,}|待定|暂无|未填", value, re.I)
            ):
                continue
        if field_name == "currency":
            upper = value.upper()
            value = {
                "RMB": "CNY",
                "人民币": "CNY",
                "美元": "USD",
                "欧元": "EUR",
            }.get(upper, upper)
        setattr(header, field_name, value)
        field_meta[f"$.header.{field_name}"] = FieldMetadata(
            source_refs=[_source_ref(cell)]
        )

    delivery_raw, delivery_cell = _labeled_value(
        envelope,
        (
            "交期",
            "交货日期",
            "交货时间",
            "到货日期",
            "要求到货日期",
            "DELIVERY DATE",
        ),
    )
    if delivery_raw and delivery_cell:
        header.delivery_date_raw = delivery_raw
        parsed, inferred = _parse_date_text(delivery_raw, header.order_number)
        header.delivery_date_standard = parsed
        field_meta["$.header.delivery_date_raw"] = FieldMetadata(
            source_refs=[_source_ref(delivery_cell)]
        )
        field_meta["$.header.delivery_date_standard"] = FieldMetadata(
            source_refs=[_source_ref(delivery_cell)], inferred=inferred
        )
        if parsed is None:
            issues.append(
                ValidationIssue(
                    code="DELIVERY_DATE_PARSE_FAILED",
                    severity="warning",
                    message="交期原文已保留，但无法确定性转换为标准日期。",
                    paths=[
                        "$.header.delivery_date_raw",
                        "$.header.delivery_date_standard",
                    ],
                    source_refs=[_source_ref(delivery_cell)],
                    actual=delivery_raw,
                )
            )

    if (
        header.buyer is None
        and header.issuer
        and header.supplier
        and _nfkc(header.issuer).strip().casefold()
        != _nfkc(header.supplier).strip().casefold()
        and header.title
        and "采购" in _nfkc(header.title)
    ):
        header.buyer = header.issuer
        issuer_meta = field_meta.get("$.header.issuer")
        field_meta["$.header.buyer"] = FieldMetadata(
            source_refs=[
                reference.model_copy(deep=True)
                for reference in (issuer_meta.source_refs if issuer_meta else [])
            ],
            inferred=True,
        )
