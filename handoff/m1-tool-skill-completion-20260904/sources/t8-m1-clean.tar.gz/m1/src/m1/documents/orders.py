"""Generic table-region recognition and deterministic order normalization."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from .envelope import (
    CellValue,
    DocumentEnvelope,
    ImageAnchor,
    SheetEnvelope,
)
from .envelope import column_letters as column_letters  # noqa: PLC0414
from .image_roles import (
    ImageRoleAssessment,
    classify_image_role,
    classify_image_roles,
    image_row_bounds,
)
from .models import (
    DocumentHeader,
    DocumentRecord,
    FieldMetadata,
    NameAttributes,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from .models import DocumentSource as DocumentSource  # noqa: PLC0414
from .models import DocumentTotals as DocumentTotals  # noqa: PLC0414
from .models import IdentifierCandidate as IdentifierCandidate  # noqa: PLC0414
from .numeric import decimal_from_value, monetary_values_equal, numeric_values_equal

ORDER_NUMBER_RE = re.compile(
    r"(?<![A-Z0-9])((?:POORD\d{6,14}|[A-Z]{1,6}[-/]?\d{8,14})"
    r"(?:[-/]\d{1,6})*)(?![A-Z0-9])",
    re.IGNORECASE,
)
DATE_LABEL_RE = re.compile(
    r"(?:下单日期|订单日期|制单日期|签订日期|签约日期|日期)\s*[：:]?\s*"
    r"((?:\d{4}\s*[年./-]\s*)?\d{1,2}\s*(?:月|[./-])\s*\d{1,2}\s*(?:日)?)",
    re.IGNORECASE,
)
LENGTH_RE = re.compile(
    r"(?<!\d)(\d+(?:\.\d+)?)\s*(M|米|CM|厘米)(?![A-Z])", re.IGNORECASE
)


def _nfkc(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value))


def normalize_line_header_label(value: Any) -> str:
    """Normalize a source label for all deterministic line-field registries."""

    text = _nfkc(value).strip().upper()
    return re.sub(r"[\s\n\r:：()（）/\\·._-]+", "", text)


def _header_key(value: Any) -> str:
    return normalize_line_header_label(value)


HEADER_ALIASES: dict[str, tuple[str, ...]] = {
    "line_no": ("序号", "项次", "行号", "NO", "NO.", "序列"),
    "image": ("产品图片", "图片", "产品图", "参考图片", "图示"),
    "model": ("型号", "工厂型号", "产品型号", "货号", "款号", "MODEL"),
    "product_code": (
        "产品编码",
        "物料编码",
        "商品编码",
        "产品代码",
        "货品编号",
        "料号",
        "SKU",
    ),
    "name_raw": (
        "名称",
        "产品名称",
        "品名",
        "中文品名",
        "货物",
        "货物名称",
        "物料名称",
        "商品名称",
        "标签名称（中文）",
        "标签名称(中文)",
    ),
    "specification_raw": (
        "规格",
        "产品规格",
        "规格型号",
        "型号规格",
        "规格米数",
        "SPEC",
    ),
    "body_printing": ("线身印字", "印字", "线材印字", "线身字样"),
    "color": ("颜色", "色号"),
    "quantity": (
        "数量",
        "总数量",
        "备货数量",
        "采购数量",
        "订购数量",
        "订单数量",
        "QTY",
    ),
    "unit": ("单位", "计量单位", "UNIT"),
    "unit_price_tax_included": (
        "含税总单价",
        "含税单价",
        "含税价",
        "单价含税",
    ),
    "amount_tax_included": (
        "含税总金额",
        "含税金额",
        "价税合计",
        "金额含税",
    ),
    "unit_price_tax_excluded": (
        "未税单价",
        "不含税总单价",
        "不含税单价",
        "单价",
        "UNITPRICE",
    ),
    "amount_tax_excluded": (
        "未税金额",
        "不含税总金额",
        "不含税金额",
        "金额",
        "AMOUNT",
    ),
    "package_quantity": (
        "装箱数",
        "箱装数",
        "每箱数量",
        "装箱数量",
        "装货数量",
    ),
    "piece_count": ("件数", "箱数", "包装件数"),
    "carton_specification": ("箱规", "外箱规格", "纸箱规格"),
    "volume": ("体积", "方数", "CBM"),
    "packaging_requirements": ("包装要求", "包装方式", "包装"),
    "origin": ("产地", "原产地"),
    "remark": ("备注", "说明", "附注", "REMARK"),
}

ALIAS_LOOKUP: dict[str, str] = {
    _header_key(alias): standard
    for standard, aliases in HEADER_ALIASES.items()
    for alias in aliases
}

_HEADER_DECORATION_RE = re.compile(
    r"^(?:(?:"
    r"RMB|CNY|USD|EUR|HKD|JPY|GBP|"
    r"[￥¥$€£]|"
    r"PCS|PC|EA|SET|KG|MG|MM|CM|KM|ML|M|G|L|T|"
    r"人民币|美元|欧元|港币|日元|元|"
    r"公斤|千克|克|吨|厘米|毫米|千米|米|升|毫升|"
    r"个|件|条|台|套|箱|包|支|卷|瓶|张|组|批|"
    r"不含税|含税|未税|税前|税后|"
    r"TAXINCLUDED|TAXEXCLUDED|INCVAT|EXVAT|"
    r"采购|销售|包运费|含运费|不含运费|包邮|到厂|到岸|"
    r"合计|总计|TOTAL|总"
    r"))+$",
    re.IGNORECASE,
)


def _is_header_decoration(value: str) -> bool:
    return bool(value and _HEADER_DECORATION_RE.fullmatch(value))


@dataclass(slots=True)
class HeaderColumn:
    column: int
    standard_name: str
    raw_name: str
    source: CellValue


@dataclass(slots=True)
class TableRegion:
    sheet: SheetEnvelope
    header_row: int
    min_column: int
    max_column: int
    columns: dict[str, HeaderColumn] = field(default_factory=dict)
    custom_columns: dict[int, HeaderColumn] = field(default_factory=dict)
    data_start_row: int = 0
    data_end_row: int = 0


def _source_ref(cell: CellValue | None, *, part: str | None = None) -> SourceReference:
    if cell is None:
        return SourceReference(part=part)
    return SourceReference(
        sheet=cell.sheet,
        cell=cell.coordinate,
        range=cell.merged_range,
        part=part,
    )


def resolve_line_header_alias(
    value: Any,
    aliases: Mapping[str, str] | None = None,
) -> str | None:
    """Resolve exact or unit/currency-decorated labels by longest alias."""

    if value is None:
        return None
    key = _header_key(value)
    if not key:
        return None
    lookup = ALIAS_LOOKUP if aliases is None else aliases
    exact = lookup.get(key)
    if exact:
        return exact
    # Longer aliases may be decorated with units, e.g. 数量(PCS) or 金额(USD).
    candidates: list[tuple[str, str]] = []
    for alias, standard in lookup.items():
        if len(alias) < 2:
            continue
        prefix, separator, suffix = key.partition(alias)
        decorated = bool(separator) and (
            (not prefix or _is_header_decoration(prefix))
            and (not suffix or _is_header_decoration(suffix))
        )
        if decorated:
            candidates.append((alias, standard))
    return max(candidates, key=lambda item: len(item[0]))[1] if candidates else None


def _match_header(value: Any) -> str | None:
    return resolve_line_header_alias(value)


def find_table_regions(sheet: SheetEnvelope) -> list[TableRegion]:
    """Find horizontally and vertically repeated tables without fixed coordinates."""

    candidate_groups: list[tuple[int, list[HeaderColumn]]] = []
    for row in range(1, sheet.max_row + 1):
        matches: list[HeaderColumn] = []
        for column in range(1, sheet.max_column + 1):
            cell = sheet.cell(row, column)
            if cell is None or cell.value is None:
                continue
            standard = _match_header(cell.value)
            if standard:
                matches.append(
                    HeaderColumn(column, standard, str(cell.value).strip(), cell)
                )
        if len({match.standard_name for match in matches}) < 3:
            continue
        current: list[HeaderColumn] = []
        seen: set[str] = set()
        for match in sorted(matches, key=lambda item: item.column):
            split = bool(
                current
                and len(current) >= 3
                and (
                    (
                        match.standard_name in seen
                        and match.standard_name
                        in {
                            "line_no",
                            "model",
                            "product_code",
                            "name_raw",
                            "quantity",
                            "unit",
                        }
                    )
                    or match.column - current[-1].column > 8
                )
            )
            if split:
                candidate_groups.append((row, current))
                current = []
                seen = set()
            current.append(match)
            seen.add(match.standard_name)
        if len({match.standard_name for match in current}) >= 3:
            candidate_groups.append((row, current))

    regions: list[TableRegion] = []
    for header_row, matches in candidate_groups:
        standards = {match.standard_name for match in matches}
        if "quantity" not in standards or not standards.intersection(
            {"line_no", "model", "product_code", "name_raw", "specification_raw"}
        ):
            continue
        min_column = min(match.column for match in matches)
        max_column = max(match.column for match in matches)
        # Preserve adjacent unknown headers too; otherwise a trailing custom
        # business column would disappear merely because no standard alias exists.
        while min_column > 1:
            neighbor = sheet.cell(header_row, min_column - 1)
            if neighbor is None or neighbor.value in (None, ""):
                break
            min_column -= 1
        while max_column < sheet.max_column:
            neighbor = sheet.cell(header_row, max_column + 1)
            if neighbor is None or neighbor.value in (None, ""):
                break
            max_column += 1
        columns: dict[str, HeaderColumn] = {}
        for match in matches:
            current = columns.get(match.standard_name)
            # Visible candidates win ties; hidden data is still retained.
            if current is None or (
                current.source.low_visibility_column
                and not match.source.low_visibility_column
            ):
                columns[match.standard_name] = match
        custom: dict[int, HeaderColumn] = {}
        for column in range(min_column, max_column + 1):
            cell = sheet.cell(header_row, column)
            if cell is None or cell.value is None or _match_header(cell.value):
                continue
            custom[column] = HeaderColumn(
                column, "custom", str(cell.value).strip(), cell
            )
        region = TableRegion(
            sheet=sheet,
            header_row=header_row,
            min_column=min_column,
            max_column=max_column,
            columns=columns,
            custom_columns=custom,
            data_start_row=header_row + 1,
        )
        region.data_end_row = _find_data_end(region, candidate_groups)
        if region.data_end_row >= region.data_start_row:
            regions.append(region)
    return regions


STOP_ROW_RE = re.compile(
    r"合计|总计|条款|附加|特别注意|签字|签章|制单人|审核人|审批|备注说明"
)


_DIRECT_IDENTITY_FIELDS = {
    "model",
    "product_code",
    "name_raw",
    "specification_raw",
}


def _direct_region_value(region: TableRegion, row: int, field_name: str) -> Any:
    header = region.columns.get(field_name)
    if header is None:
        return None
    cell = region.sheet.cell(row, header.column)
    return cell.value if cell is not None else None


def _has_direct_unmerged_identity(
    region: TableRegion, row: int, field_name: str
) -> bool:
    header = region.columns.get(field_name)
    if header is None:
        return False
    cell = region.sheet.cell(row, header.column)
    if cell is None or cell.value in (None, ""):
        return False
    merged = region.sheet.merge_at(row, header.column)
    return merged is None or merged.max_col == merged.min_col


def _is_numeric_sequence(value: Any) -> bool:
    if value in (None, "") or isinstance(value, bool):
        return False
    if isinstance(value, (int, Decimal)):
        return Decimal(value) == Decimal(value).to_integral_value()
    if isinstance(value, float):
        return value.is_integer()
    return bool(re.fullmatch(r"\d+(?:\.0+)?", _nfkc(value).strip()))


def _qualifies_order_row(region: TableRegion, row: int) -> bool:
    """Require a direct row identity; inherited merged text is not an identity."""

    if any(
        _has_direct_unmerged_identity(region, row, field_name)
        for field_name in _DIRECT_IDENTITY_FIELDS
    ):
        return True
    if not _is_numeric_sequence(_direct_region_value(region, row, "line_no")):
        return False
    return any(
        field_name not in {"line_no", "image"}
        and _direct_region_value(region, row, field_name) not in (None, "")
        for field_name in region.columns
    )


def _is_total_footer_row(region: TableRegion, row: int) -> bool:
    """Recognize a totals structure without matching product free text."""

    marker = re.compile(
        r"^(?:合计(?:数量|金额)?|总计|总数量|总件数|TOTAL(?:\s+AMOUNT)?)\s*[:：]?$",
        re.IGNORECASE,
    )
    mapped_values = [
        _direct_region_value(region, row, field_name) for field_name in region.columns
    ]
    has_product_identity = any(
        _has_direct_unmerged_identity(region, row, field_name)
        and not marker.fullmatch(
            _nfkc(_direct_region_value(region, row, field_name)).strip()
        )
        for field_name in _DIRECT_IDENTITY_FIELDS
    )
    if any(
        marker.fullmatch(_nfkc(value).strip())
        for value in mapped_values
        if value not in (None, "")
    ):
        return not has_product_identity
    row_text = " ".join(
        _nfkc(value).strip() for value in mapped_values if value not in (None, "")
    )
    return (
        bool(
            re.search(
                r"(?:^|\s)(?:合计(?:数量|金额)?|总计|总数量|TOTAL)\s*[:：]?(?:\s|$)",
                row_text,
                re.IGNORECASE,
            )
        )
        and not has_product_identity
    )


def _find_data_end(
    region: TableRegion, all_headers: list[tuple[int, list[HeaderColumn]]]
) -> int:
    next_headers = [
        row
        for row, columns in all_headers
        if row > region.header_row
        and max(item.column for item in columns) >= region.min_column
        and min(item.column for item in columns) <= region.max_column
    ]
    hard_end = min(next_headers) - 1 if next_headers else region.sheet.max_row
    last_data_row = region.header_row
    blank_streak = 0
    for row in range(region.data_start_row, hard_end + 1):
        mapped_values: list[Any] = []
        for header in region.columns.values():
            effective = region.sheet.cell(row, header.column, inherit_merged=True)
            mapped_values.append(effective.value if effective else None)
        row_text = " ".join(
            str(value) for value in mapped_values if value not in (None, "")
        )
        if _is_total_footer_row(region, row):
            break
        qualifies = _qualifies_order_row(region, row)
        if STOP_ROW_RE.search(row_text) and not qualifies:
            break
        if qualifies:
            last_data_row = row
            blank_streak = 0
        else:
            blank_streak += 1
            if blank_streak >= 2 and last_data_row >= region.data_start_row:
                break
    return last_data_row


def _clean_string(value: Any, *, preserve: bool = False) -> str | None:
    if value is None:
        return None
    text = str(value)
    if preserve:
        return text
    text = text.strip()
    return text or None


def _numeric(value: Any) -> int | Decimal | None:
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, Decimal)):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else Decimal(str(value))
    match = re.search(r"[-+]?\d[\d,]*(?:\.\d+)?", _nfkc(value))
    if not match:
        return None
    try:
        number = Decimal(match.group(0).replace(",", ""))
    except InvalidOperation:
        return None
    return int(number) if number == number.to_integral_value() else number


NUMERIC_FIELDS = {
    "quantity",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "volume",
}


def _assign_line_value(line: OrderLine, field_name: str, value: Any) -> None:
    if field_name == "image":
        return
    if field_name in NUMERIC_FIELDS:
        setattr(line, field_name, _numeric(value))
    elif field_name == "line_no":
        number = _numeric(value)
        setattr(
            line, field_name, number if number is not None else _clean_string(value)
        )
    elif field_name == "name_raw":
        setattr(line, field_name, _clean_string(value, preserve=True))
    else:
        setattr(line, field_name, _clean_string(value))


def _image_row_bounds(image: ImageAnchor, sheet: SheetEnvelope) -> tuple[int, int]:
    return image_row_bounds(image, sheet)


def _classify_image_role(
    image: ImageAnchor,
    regions: list[TableRegion],
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> ImageRoleAssessment:
    return classify_image_role(
        image,
        regions,
        override=(image_role_overrides or {}).get(image.image_id),
    )


def _classify_image_roles(
    envelope: DocumentEnvelope,
    regions: list[TableRegion],
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> dict[str, ImageRoleAssessment]:
    return classify_image_roles(
        envelope,
        regions,
        overrides=image_role_overrides,
    )


def _extract_lines(
    regions: list[TableRegion],
    field_meta: dict[str, FieldMetadata],
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> tuple[list[OrderLine], set[str], set[str]]:
    lines: list[OrderLine] = []
    mapped_images: set[str] = set()
    custom_headers: set[str] = set()
    for region in regions:
        for row in range(region.data_start_row, region.data_end_row + 1):
            if _is_total_footer_row(region, row):
                continue
            if not _qualifies_order_row(region, row):
                continue
            line_index = len(lines)
            line = OrderLine(line_id=f"{region.sheet.name}:{row}")
            for standard, header in region.columns.items():
                cell = region.sheet.cell(row, header.column, inherit_merged=True)
                value = cell.value if cell else None
                _assign_line_value(line, standard, value)
                raw_key = header.raw_name
                if raw_key in line.raw_columns:
                    raw_key = f"{raw_key}@{header.source.coordinate}"
                line.raw_columns[raw_key] = value
                field_meta[f"$.lines[{line_index}].{standard}"] = FieldMetadata(
                    source_refs=[_source_ref(cell)],
                    confidence=1.0 if value not in (None, "") else 0.0,
                    inherited_from_merge=bool(cell and cell.inherited_from),
                )
            for column, header in region.custom_columns.items():
                cell = region.sheet.cell(row, column, inherit_merged=True)
                value = cell.value if cell else None
                key = header.raw_name
                if key in line.custom_fields:
                    key = f"{key}@{header.source.coordinate}"
                line.custom_fields[key] = value
                line.raw_columns[key] = value
                custom_headers.add(header.raw_name)
                field_meta[f"$.lines[{line_index}].custom_fields.{key}"] = (
                    FieldMetadata(
                        source_refs=[_source_ref(cell)],
                        confidence=1.0,
                        inherited_from_merge=bool(cell and cell.inherited_from),
                    )
                )
            for image in region.sheet.images:
                # Role classification must be scoped to the table currently
                # producing this line.  With two side-by-side tables on the
                # same rows, a sheet-wide ``product`` verdict for table A must
                # not attach that image to table B merely because row numbers
                # overlap.
                if (
                    _classify_image_role(
                        image,
                        [region],
                        image_role_overrides,
                    ).role
                    != "product"
                ):
                    continue
                first_row, last_row = _image_row_bounds(image, region.sheet)
                if first_row <= row <= last_row:
                    line.image_refs.append(image.image_id)
                    mapped_images.add(image.image_id)
            lines.append(line)
    return lines, mapped_images, custom_headers


_UNIT_VALUES = {"PCS", "PC", "件", "条", "套", "个", "箱", "卷", "EA"}


_ORDER_EXTRACTION_DEPENDENCIES = (
    "CellValue",
    "DATE_LABEL_RE",
    "DocumentEnvelope",
    "DocumentHeader",
    "FieldMetadata",
    "IdentifierCandidate",
    "ORDER_NUMBER_RE",
    "OrderLine",
    "ValidationIssue",
    "_UNIT_VALUES",
    "_all_value_cells",
    "_candidate_score",
    "_clean_string",
    "_labeled_value",
    "_nfkc",
    "_numeric",
    "_parse_date_text",
    "_source_ref",
    "_year_from_order_number",
    "column_letters",
)


def _order_extraction_impl(name: str) -> Any:
    from . import order_extraction

    for dependency in _ORDER_EXTRACTION_DEPENDENCIES:
        setattr(order_extraction, dependency, globals()[dependency])
    return getattr(order_extraction, f"{name}_impl")


def _extract_headerless_order_lines(
    envelope: DocumentEnvelope,
    field_meta: dict[str, FieldMetadata],
) -> tuple[list[OrderLine], set[str]]:
    """Conservatively recover compact order rows whose header was deleted."""

    return _order_extraction_impl("_extract_headerless_order_lines")(
        envelope, field_meta
    )


def _all_value_cells(envelope: DocumentEnvelope) -> Iterable[CellValue]:
    return _order_extraction_impl("_all_value_cells")(envelope)


def _extract_title_and_issuer(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
) -> None:
    _order_extraction_impl("_extract_title_and_issuer")(envelope, header, field_meta)


def _candidate_score(
    cell: CellValue,
    value: str,
    filename: str,
    *,
    adjacent_context: str = "",
) -> float:
    return _order_extraction_impl("_candidate_score")(
        cell, value, filename, adjacent_context=adjacent_context
    )


def _extract_order_numbers(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    _order_extraction_impl("_extract_order_numbers")(
        envelope, header, field_meta, issues
    )


def _year_from_order_number(
    order_number: str | None, month: int, day: int
) -> int | None:
    return _order_extraction_impl("_year_from_order_number")(order_number, month, day)


def _parse_date_text(raw: str, order_number: str | None) -> tuple[date | None, bool]:
    return _order_extraction_impl("_parse_date_text")(raw, order_number)


def _extract_date(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    _order_extraction_impl("_extract_date")(envelope, header, field_meta, issues)


def _labeled_value(
    envelope: DocumentEnvelope, labels: tuple[str, ...]
) -> tuple[str | None, CellValue | None]:
    return _order_extraction_impl("_labeled_value")(envelope, labels)


def _extract_extended_header(
    envelope: DocumentEnvelope,
    header: DocumentHeader,
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
) -> None:
    _order_extraction_impl("_extract_extended_header")(
        envelope, header, field_meta, issues
    )


def _capture_labeled(text: str, labels: str) -> str | None:
    match = re.search(rf"(?:{labels})\s*[：:]\s*([^\n\r]+)", text, re.IGNORECASE)
    return match.group(1).strip() if match else None


def _canonical_length(match: re.Match[str] | None) -> str | None:
    if match is None:
        return None
    value = Decimal(match.group(1))
    number = (
        str(int(value))
        if value == value.to_integral_value()
        else format(value.normalize(), "f")
    )
    unit = match.group(2).upper()
    if unit == "米":
        unit = "M"
    elif unit == "厘米":
        unit = "CM"
    return f"{number}{unit}"


def enrich_order_line(line: OrderLine) -> list[ValidationIssue]:
    """Rule-only product naming; no deterministic fact is modified by a model."""

    raw = _nfkc(line.name_raw or "")
    spec = _nfkc(line.specification_raw or "")
    combined = f"{raw}\n{spec}".strip()
    upper = combined.upper()
    attributes = NameAttributes()
    issues: list[ValidationIssue] = []

    interface_patterns = (
        ("DisplayPort", r"\b(?:DISPLAYPORT|DP)\b|DP(?=\d)"),
        ("HDMI", r"\bHDMI\b|HDMI(?=\d)"),
        ("USB-C", r"\b(?:USB[ -]?C|TYPE[ -]?C)\b"),
        ("USB", r"\bUSB\b|USB(?=\d)"),
        ("RJ45", r"\bRJ45\b"),
        ("VGA", r"\bVGA\b"),
        ("DVI", r"\bDVI\b"),
    )
    for interface, pattern in interface_patterns:
        if re.search(pattern, upper):
            attributes.interface = interface
            break
    if attributes.interface == "DisplayPort":
        version = re.search(r"(?:DISPLAYPORT|DP)\s*V?\s*(\d+(?:\.\d+)?)", upper)
    elif attributes.interface == "HDMI":
        version = re.search(r"HDMI\s*V?\s*(\d+(?:\.\d+)?)", upper)
    elif attributes.interface in {"USB", "USB-C"}:
        version = re.search(r"USB(?:[ -]?C)?\s*V?\s*(\d+(?:\.\d+)?)", upper)
    else:
        version = None
    if version:
        attributes.protocol_version = version.group(1)
    resolution = re.search(r"(?<!\d)(4K|8K|10K|16K)", upper)
    if resolution:
        attributes.resolution = resolution.group(1)
    refresh = re.search(r"(?<!\d)(\d{2,3})\s*HZ\b", upper)
    if refresh:
        attributes.refresh_rate = f"{refresh.group(1)}Hz"
    name_length_match = LENGTH_RE.search(raw)
    spec_length_match = LENGTH_RE.search(spec)
    attributes.cable_length = _canonical_length(spec_length_match or name_length_match)
    attributes.conductor = _capture_labeled(raw, "线芯|导体")
    attributes.shielding = _capture_labeled(raw, "屏蔽")
    od_match = re.search(r"\bOD\s*[：:]?\s*(\d+(?:\.\d+)?\s*MM)", upper)
    if od_match:
        attributes.od = re.sub(r"\s+", "", od_match.group(1)).lower()
    jackets = re.findall(r"外被\s*[：:]\s*([^\n\r]+)", raw, re.IGNORECASE)
    if jackets:
        attributes.jacket = "; ".join(dict.fromkeys(value.strip() for value in jackets))
    attributes.plug = _capture_labeled(raw, "插头")
    attributes.aluminum_shell = _capture_labeled(raw, "铝壳|铝合金壳")
    attributes.braided_sleeve = _capture_labeled(raw, "外编织网|编织网")
    plating = re.search(r"镀(?:金|银|镍|锡)", raw)
    if plating:
        attributes.plating = plating.group(0)
    colors = [
        color
        for color in ("太空灰", "黑灰", "黑色", "灰色", "白色", "蓝色", "红色")
        if color in raw
    ]
    if colors:
        attributes.color = "/".join(dict.fromkeys(colors))
    branding = [value for value in ("中性", "定制", "品牌") if value in raw]
    if branding:
        attributes.branding = "/".join(branding)
    suspicious = [term for term in ("防金头",) if term in raw]
    if suspicious:
        attributes.custom["suspicious_terms"] = suspicious
        issues.append(
            ValidationIssue(
                code="SUSPICIOUS_NAME_TEXT",
                severity="warning",
                message=f"名称包含可疑原文 {', '.join(suspicious)}，已原样保留且未自动纠正。",
                paths=["$.lines[*].name_raw"],
                actual=suspicious,
                suggestion="请审核该词是否应为“镀金头”或其他原始要求。",
            )
        )
    name_length = _canonical_length(name_length_match)
    spec_length = _canonical_length(spec_length_match)
    if name_length and spec_length and name_length != spec_length:
        issues.append(
            ValidationIssue(
                code="NAME_SPEC_LENGTH_CONFLICT",
                severity="warning",
                message=f"名称长度 {name_length} 与规格长度 {spec_length} 不一致。",
                paths=[
                    "$.lines[*].name_raw",
                    "$.lines[*].specification_raw",
                ],
                expected=spec_length,
                actual=name_length,
            )
        )

    normalized_raw = re.sub(r"\s+", " ", raw).strip()
    semantic_tokens = [attributes.branding, attributes.interface]
    if attributes.protocol_version:
        semantic_tokens.append(attributes.protocol_version)
    semantic_tokens.extend(
        [attributes.resolution, attributes.refresh_rate, attributes.cable_length]
    )
    if attributes.interface:
        semantic_tokens.append("线缆")
        line.product_category = f"{attributes.interface} cable"
    else:
        line.product_category = "cable" if re.search(r"线|CABLE", upper) else "other"

    # Keep the complete observed product name as the basis of every derived
    # display name. The earlier token-only form silently reduced long purchase
    # descriptions to values such as ``DisplayPort 2.1 线缆``. Append canonical
    # attributes for search, but never replace or truncate the source wording.
    tokens = [line.product_code, line.model, normalized_raw]
    tokens.extend(semantic_tokens)
    if not any(tokens):
        tokens.append("产品")
    normalized_tokens: list[str] = []
    normalized_text = ""
    for token in tokens:
        candidate = re.sub(r"\s+", " ", str(token or "")).strip()
        if not candidate:
            continue
        candidate_key = _nfkc(candidate).casefold()
        if candidate_key and candidate_key in _nfkc(normalized_text).casefold():
            continue
        normalized_tokens.append(candidate)
        normalized_text = " ".join(normalized_tokens)
    line.name_attributes = attributes
    line.name_normalized = normalized_text
    line.full_product_name = line.name_normalized
    return issues


def attach_derived_line_evidence(
    lines: Iterable[OrderLine],
    field_meta: dict[str, FieldMetadata],
) -> None:
    """Trace semantic name fields back to the deterministic source cells.

    Product category/name normalization is rule-derived, but it still needs
    auditable provenance.  Reuse the raw identity/specification references and
    mark the derived metadata as inferred instead of leaving unsupported facts
    in ``DocumentRecord``.
    """

    source_fields = ("name_raw", "specification_raw", "product_code", "model")
    derived_fields = (
        "name_normalized",
        "full_product_name",
        "product_category",
        "name_attributes",
    )
    for index, line in enumerate(lines):
        source_metadata = [
            field_meta.get(f"$.lines[{index}].{field}") for field in source_fields
        ]
        source_metadata = [item for item in source_metadata if item is not None]
        if not source_metadata:
            continue
        references: list[SourceReference] = []
        seen: set[str] = set()
        for item in source_metadata:
            for reference in item.source_refs:
                key = reference.model_dump_json()
                if key in seen:
                    continue
                seen.add(key)
                references.append(reference.model_copy(deep=True))
        if not references:
            continue
        confidences = [
            float(item.confidence)
            for item in source_metadata
            if item.confidence is not None
        ]
        confidence = min(confidences) if confidences else 1.0
        for field_name in derived_fields:
            value = getattr(line, field_name)
            if value in (None, "", [], {}):
                continue
            path = f"$.lines[{index}].{field_name}"
            field_meta.setdefault(
                path,
                FieldMetadata(
                    source_refs=[item.model_copy(deep=True) for item in references],
                    confidence=confidence,
                    inferred=True,
                    # This value is reproducibly derived from the cited source
                    # cells.  Preserve the inference audit marker without
                    # duplicating the review gate already carried by any
                    # uncertain source field.
                    review_required=False,
                ),
            )


def _sum_values(values: Iterable[Any]) -> int | Decimal | None:
    total = Decimal(0)
    found = False
    for value in values:
        number = _numeric(value)
        if number is None:
            continue
        total += decimal_from_value(number)
        found = True
    if not found:
        return None
    return int(total) if total == total.to_integral_value() else total


def _declared_total(
    envelope: DocumentEnvelope,
    label_pattern: str,
    preferred_columns: Iterable[int] = (),
) -> tuple[int | Decimal | None, CellValue | None]:
    pattern = re.compile(label_pattern)
    preferred = list(dict.fromkeys(preferred_columns))
    for sheet in envelope.sheets:
        for cell in sorted(
            sheet.cells.values(), key=lambda item: (item.row, item.column)
        ):
            if cell.value is None or not pattern.search(_nfkc(cell.value)):
                continue
            candidate_columns = [
                column for column in preferred if 1 <= column <= sheet.max_column
            ]
            if not candidate_columns:
                candidate_columns.extend(range(cell.column + 1, sheet.max_column + 1))
            for column in candidate_columns:
                value_cell = sheet.cell(cell.row, column, inherit_merged=True)
                number = _numeric(value_cell.value if value_cell else None)
                if number is not None:
                    return number, value_cell
    return None, None


def _validate_lines(lines: list[OrderLine]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    line_numbers = [line.line_no for line in lines if isinstance(line.line_no, int)]
    if len(line_numbers) != len(set(line_numbers)):
        issues.append(
            ValidationIssue(
                code="LINE_NUMBER_DUPLICATE",
                severity="warning",
                message="明细序号存在重复。",
                paths=["$.lines[*].line_no"],
                actual=line_numbers,
            )
        )
    if line_numbers:
        expected = list(range(min(line_numbers), max(line_numbers) + 1))
        if sorted(set(line_numbers)) != expected:
            issues.append(
                ValidationIssue(
                    code="LINE_NUMBER_GAP",
                    severity="warning",
                    message="明细序号存在断档。",
                    paths=["$.lines[*].line_no"],
                    expected=expected,
                    actual=line_numbers,
                )
            )
    models = [line.model for line in lines if line.model]
    duplicate_models = sorted({model for model in models if models.count(model) > 1})
    if duplicate_models:
        issues.append(
            ValidationIssue(
                code="MODEL_DUPLICATE",
                severity="warning",
                message="明细中存在重复型号。",
                paths=["$.lines[*].model"],
                actual=duplicate_models,
            )
        )
    for index, line in enumerate(lines):
        identity_fields = ("model", "product_code", "name_raw", "specification_raw")
        missing = [
            field_name
            for field_name in ("quantity", "unit")
            if getattr(line, field_name) in (None, "")
        ]
        if not any(
            getattr(line, field_name) not in (None, "")
            for field_name in identity_fields
        ):
            missing.insert(0, "product_identity")
        if missing:
            missing_paths = [
                f"$.lines[{index}].{field_name}"
                for field_name in missing
                if field_name != "product_identity"
            ]
            if "product_identity" in missing:
                missing_paths = [
                    f"$.lines[{index}].{field_name}" for field_name in identity_fields
                ] + missing_paths
            issues.append(
                ValidationIssue(
                    code="LINE_CORE_FIELD_MISSING",
                    severity="warning",
                    message=(
                        f"第 {line.line_no or index + 1} 行缺少核心字段："
                        f"{', '.join(missing)}。"
                    ),
                    paths=missing_paths,
                )
            )
        if (
            line.package_quantity is not None
            and line.piece_count is not None
            and line.quantity is not None
        ):
            packed = decimal_from_value(line.package_quantity) * decimal_from_value(
                line.piece_count
            )
            if not numeric_values_equal(packed, line.quantity):
                issues.append(
                    ValidationIssue(
                        code="PACKAGING_QUANTITY_MISMATCH",
                        severity="warning",
                        message=f"第 {line.line_no or index + 1} 行装箱数×件数与数量不一致。",
                        paths=[
                            f"$.lines[{index}].package_quantity",
                            f"$.lines[{index}].piece_count",
                            f"$.lines[{index}].quantity",
                        ],
                        expected=line.quantity,
                        actual=packed,
                    )
                )
        for price_field, amount_field in (
            ("unit_price_tax_included", "amount_tax_included"),
            ("unit_price_tax_excluded", "amount_tax_excluded"),
        ):
            price = getattr(line, price_field)
            amount = getattr(line, amount_field)
            if price is not None and amount is not None and line.quantity is not None:
                calculated = decimal_from_value(price) * decimal_from_value(
                    line.quantity
                )
                if not monetary_values_equal(calculated, amount):
                    issues.append(
                        ValidationIssue(
                            code="LINE_AMOUNT_MISMATCH",
                            severity="warning",
                            message=f"第 {line.line_no or index + 1} 行数量×单价与金额不一致。",
                            paths=[
                                f"$.lines[{index}].quantity",
                                f"$.lines[{index}].{price_field}",
                                f"$.lines[{index}].{amount_field}",
                            ],
                            expected=calculated,
                            actual=amount,
                        )
                    )
    return issues


_RECALCULATED_ISSUE_CODES = {
    "LINE_NUMBER_DUPLICATE",
    "LINE_NUMBER_GAP",
    "MODEL_DUPLICATE",
    "LINE_CORE_FIELD_MISSING",
    "PACKAGING_QUANTITY_MISMATCH",
    "LINE_AMOUNT_MISMATCH",
    "TOTAL_QUANTITY_MISMATCH",
    "TOTAL_AMOUNT_MISMATCH",
}


def revalidate_order_document(document: dict[str, Any]) -> dict[str, Any]:
    """Recompute deterministic line/totals validation after manual corrections."""

    if document.get("document_type") != "order":
        return document
    lines = [
        OrderLine.model_validate(line)
        for line in document.get("lines", [])
        if isinstance(line, dict)
    ]
    retained_issues = [
        issue
        for issue in document.get("validation_issues", [])
        if isinstance(issue, dict)
        and str(issue.get("code") or "") not in _RECALCULATED_ISSUE_CODES
    ]
    calculated_issues = [
        issue.model_dump(mode="json") for issue in _validate_lines(lines)
    ]

    totals = dict(document.get("totals") or {})
    calculated_quantity = _sum_values(line.quantity for line in lines)
    totals["calculated_quantity"] = calculated_quantity
    totals.setdefault("system_calculated", {})["quantity"] = calculated_quantity
    declared_quantity = totals.get("declared_quantity")
    quantity_matches = (
        Decimal(str(declared_quantity)) == Decimal(str(calculated_quantity))
        if declared_quantity is not None and calculated_quantity is not None
        else None
    )
    totals["quantity_matches"] = quantity_matches
    totals.setdefault("matches", {})["quantity"] = quantity_matches
    if quantity_matches is False:
        calculated_issues.append(
            ValidationIssue(
                code="TOTAL_QUANTITY_MISMATCH",
                severity="warning",
                message="声明数量合计与审核后逐行重算值不一致。",
                paths=["$.totals.declared_quantity", "$.totals.calculated_quantity"],
                expected=calculated_quantity,
                actual=declared_quantity,
            ).model_dump(mode="json")
        )

    amount_field = (
        "amount_tax_included"
        if any(line.amount_tax_included is not None for line in lines)
        else "amount_tax_excluded"
    )
    calculated_amount = _sum_values(getattr(line, amount_field) for line in lines)
    totals["calculated_amount"] = calculated_amount
    totals.setdefault("system_calculated", {})["amount"] = calculated_amount
    declared_amount = totals.get("declared_amount")
    aggregate_amount_matches = (
        monetary_values_equal(declared_amount, calculated_amount)
        if declared_amount is not None and calculated_amount is not None
        else None
    )
    amount_matches = (
        False
        if any(
            issue.get("code") == "LINE_AMOUNT_MISMATCH" for issue in calculated_issues
        )
        else aggregate_amount_matches
    )
    totals["amount_matches"] = amount_matches
    totals.setdefault("matches", {})["amount"] = amount_matches
    if aggregate_amount_matches is False:
        calculated_issues.append(
            ValidationIssue(
                code="TOTAL_AMOUNT_MISMATCH",
                severity="warning",
                message="声明金额合计与审核后逐行重算值不一致。",
                paths=["$.totals.declared_amount", "$.totals.calculated_amount"],
                expected=calculated_amount,
                actual=declared_amount,
            ).model_dump(mode="json")
        )

    document["lines"] = [line.model_dump(mode="json") for line in lines]
    document["totals"] = totals
    document["validation_issues"] = retained_issues + calculated_issues
    return document


def _document_subtype(
    title: str | None,
    hint: str | None,
    *,
    filename: str = "",
) -> str:
    if hint:
        return hint
    text = _nfkc(f"{title or ''}\n{filename}")
    if "备货" in text:
        return "stocking_order"
    if "样品" in text or "样板" in text:
        return "sample_request"
    if "客户采购" in text or "客户订单" in text:
        return "customer_purchase_order"
    if any(token in text for token in ("采购合同", "购销合同")):
        return "purchase_contract"
    if any(token in text for token in ("采购单", "采购订单")):
        return "supplier_purchase_order"
    return "customer_purchase_order"


def build_order_document(
    envelope: DocumentEnvelope,
    subtype_hint: str | None = None,
) -> DocumentRecord:
    """Build a normalized order record through the internal assembly module."""

    return _build_order_document_with_image_roles(envelope, subtype_hint)


def _build_order_document_with_image_roles(
    envelope: DocumentEnvelope,
    subtype_hint: str | None = None,
    *,
    image_role_overrides: Mapping[str, ImageRoleAssessment] | None = None,
) -> DocumentRecord:
    """Internal rebuild entrypoint for reviewed visual-role overrides."""

    from . import order_builder

    for name in order_builder.FACADE_DEPENDENCIES:
        setattr(order_builder, name, globals()[name])
    return order_builder._build_order_document_impl(
        envelope,
        subtype_hint,
        image_role_overrides=image_role_overrides,
    )
