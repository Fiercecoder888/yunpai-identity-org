"""Structured document parser backends and evidence normalization."""

from .base import (
    DocumentParserBackend,
    PageInput,
    ParserBackendError,
    ParserBackendUnavailable,
)
from .comparison import compare_document_records
from .docling import DoclingBackend
from .document_route_plan import DocumentRoutePlan, RouteBackend, RouteTarget
from .document_route_probe import build_route_probe_evidence
from .evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from .mineru_input import (
    CADRenderResult,
    EzdxfCADRenderer,
    MinerUCADRenderer,
    MinerUCADRendererRequired,
    MinerUCADRenderError,
    MinerUInputContractError,
    MinerUInputError,
    MinerUInputNormalizer,
    MinerUPreparedInput,
    MinerURecursiveMember,
)
from .service import DocumentParserService, build_document_parser_service
from .structured import PaddleOCRVLBackend, PPStructureV3Backend

__all__ = [
    "CADRenderResult",
    "DoclingBackend",
    "DocumentEvidence",
    "DocumentParserBackend",
    "DocumentParserService",
    "DocumentRoutePlan",
    "EvidenceBBox",
    "EvidenceBlock",
    "EvidenceCell",
    "EvidencePage",
    "EvidenceTable",
    "EzdxfCADRenderer",
    "MinerUCADRenderError",
    "MinerUCADRenderer",
    "MinerUCADRendererRequired",
    "MinerUInputContractError",
    "MinerUInputError",
    "MinerUInputNormalizer",
    "MinerUPreparedInput",
    "MinerURecursiveMember",
    "PPStructureV3Backend",
    "PaddleOCRVLBackend",
    "PageInput",
    "ParserBackendError",
    "ParserBackendUnavailable",
    "RouteBackend",
    "RouteTarget",
    "build_document_parser_service",
    "build_route_probe_evidence",
    "compare_document_records",
]
