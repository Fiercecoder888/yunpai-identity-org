"""Governed, format-neutral routing after a ``DocumentRecord`` is built.

The post-build boundary is deliberately additive.  Content and visual routes
produce audit metadata only.  Field routing may fill an empty canonical slot,
but only from a losslessly retained value with replayable source evidence.
No route in this module may replace an existing fact, an explicit subtype, or
source coordinates.
"""

from __future__ import annotations

import copy
import hashlib
import math
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from ..models import DocumentRecord
from .content_region_probes import build_content_region_probes
from .document_route_probe import build_route_probe_evidence
from .evidence import DocumentEvidence, EvidencePage
from .field_semantic_application import route_document_custom_fields
from .field_semantic_contracts import (
    CustomFieldEntry,
    FieldSemanticInput,
    FieldSemanticResolution,
    FieldSemanticResolvedInput,
)
from .field_semantic_registry import (
    CanonicalFieldRegistry,
    build_document_canonical_field_registry,
)
from .visual_region_contracts import (
    VisualAreaBucket,
    VisualAspectBucket,
    VisualGeometryAssessment,
    VisualGeometryReason,
    VisualPositionBucket,
    VisualRegionRole,
    VisualRegionSourceKind,
    VisualRegionTopology,
)

_POSTBUILD_SCHEMA = "m1.adaptive-postbuild.v1"
_MAX_CONTENT_SIGNATURE_GROUPS = 16
_MAX_FIELD_SIGNATURE_GROUPS = 16
_MAX_VISUAL_SIGNATURE_GROUPS = 16
_MAX_VISUAL_ASSET_BYTES = 10 * 1024 * 1024
_SAFE_VISUAL_MEDIA_TYPES = frozenset(
    {
        "image/bmp",
        "image/gif",
        "image/jpeg",
        "image/png",
        "image/tiff",
        "image/webp",
    }
)
_CONTENT_DEPENDENCY_REASONS = frozenset(
    {
        "embedding_failure",
        "store_failure",
        "store_circuit_open",
        "model_failure",
        "model_circuit_open",
        "candidate_store_failure",
    }
)
_VISUAL_DEPENDENCY_REASONS = frozenset(
    {
        "embedding_failure",
        "candidate_store_failure",
        "model_failure",
        "routing_circuit_open",
    }
)


class AdaptivePostbuildError(RuntimeError):
    """A required post-build route failed or violated the fact boundary."""


class _BoundedFieldRuntime:
    """Deduplicate value-free field signatures before the per-field runtime."""

    def __init__(self, delegate: object) -> None:
        self._delegate = delegate
        self.mode = str(getattr(delegate, "mode", "shadow"))
        self.required = _runtime_required(delegate)
        delegate_limit = int(
            getattr(delegate, "max_fields_per_document", _MAX_FIELD_SIGNATURE_GROUPS)
        )
        configured = int(
            getattr(delegate, "max_unique_signatures_per_document", delegate_limit)
        )
        self.max_fields_per_document = max(
            1, min(configured, delegate_limit, _MAX_FIELD_SIGNATURE_GROUPS)
        )
        self.audit: dict[str, int | str] = {
            "unique_signature_limit": self.max_fields_per_document,
            "routing_resolution_count": 0,
            "model_call_upper_bound": 0,
        }

    @staticmethod
    def _fallback(field: FieldSemanticInput) -> FieldSemanticResolvedInput:
        return FieldSemanticResolvedInput(
            source_ref=field.source_ref,
            resolution=FieldSemanticResolution(
                action="custom_field",
                reason="unique_signature_limit",
                custom_fields=(
                    CustomFieldEntry(
                        label=field.probe.label,
                        value=field.value,
                        evidence_refs=field.evidence_refs,
                        reason="unique_signature_limit",
                    ),
                ),
            ),
        )

    @staticmethod
    def _rebind(
        field: FieldSemanticInput,
        resolved: FieldSemanticResolvedInput,
    ) -> FieldSemanticResolvedInput:
        resolution = resolved.resolution
        if resolution.action != "mapped":
            resolution = resolution.model_copy(
                update={
                    "custom_fields": (
                        CustomFieldEntry(
                            label=field.probe.label,
                            value=field.value,
                            evidence_refs=field.evidence_refs,
                            reason=resolution.reason,
                        ),
                    )
                }
            )
        return FieldSemanticResolvedInput(
            source_ref=field.source_ref,
            resolution=resolution,
        )

    async def resolve_fields(
        self,
        *,
        tenant_id: str,
        fields: Sequence[FieldSemanticInput],
        created_by: str,
    ) -> tuple[FieldSemanticResolvedInput, ...]:
        groups: dict[str, list[FieldSemanticInput]] = {}
        for field in fields:
            fingerprint = field.probe.signature().exact_fingerprint()
            groups.setdefault(fingerprint, []).append(field)
        selected = tuple(groups.items())[: self.max_fields_per_document]
        deferred = tuple(groups.items())[self.max_fields_per_document :]
        if self.required and deferred:
            raise AdaptivePostbuildError(
                "required field-semantic route exceeds the unique-signature budget"
            )

        representatives = tuple(group[0] for _fingerprint, group in selected)
        raw = await self._delegate.resolve_fields(
            tenant_id=tenant_id,
            fields=representatives,
            created_by=created_by,
        )
        by_source_ref = {item.source_ref: item for item in raw}
        if len(by_source_ref) != len(representatives) or any(
            field.source_ref not in by_source_ref for field in representatives
        ):
            raise ValueError("field semantic representative resolution mismatch")

        resolved_by_fingerprint = {
            fingerprint: by_source_ref[group[0].source_ref]
            for fingerprint, group in selected
        }
        output: list[FieldSemanticResolvedInput] = []
        for field in fields:
            fingerprint = field.probe.signature().exact_fingerprint()
            resolved = resolved_by_fingerprint.get(fingerprint)
            output.append(
                self._rebind(field, resolved) if resolved else self._fallback(field)
            )

        total_fields = len(fields)
        unique_count = len(groups)
        selected_count = len(selected)
        deferred_count = sum(len(group) for _fingerprint, group in deferred)
        self.audit = {
            "observed_field_count": total_fields,
            "unique_signature_count": unique_count,
            "processed_unique_signature_count": selected_count,
            "deferred_unique_signature_count": len(deferred),
            "deduplicated_field_count": total_fields - unique_count,
            "deferred_field_count": deferred_count,
            "routing_resolution_count": selected_count,
            "model_call_upper_bound": selected_count,
            "unique_signature_limit": self.max_fields_per_document,
            "truncation_reason": ("unique_signature_limit" if deferred else "none"),
        }
        return tuple(output)


def _metadata(document: DocumentRecord) -> dict[str, Any]:
    metadata = document.extraction.setdefault("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
        document.extraction["metadata"] = metadata
    return metadata


def _runtime_required(runtime: object | None) -> bool:
    return bool(getattr(runtime, "required", False))


def _dump(value: object) -> dict[str, Any]:
    method = getattr(value, "model_dump", None)
    if callable(method):
        payload = method(mode="json")
        if isinstance(payload, dict):
            return payload
    raise TypeError("routing decision must provide a mapping model_dump")


def _document_evidence(
    document: DocumentRecord,
    *,
    source_kind: str,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> DocumentEvidence:
    """Recover provider-neutral evidence without reopening model output."""

    metadata = _metadata(document)
    structured = metadata.get("structured_evidence")
    if isinstance(structured, Mapping):
        try:
            evidence = DocumentEvidence.model_validate(structured)
        except Exception:  # noqa: BLE001 - fall through to retained raw evidence
            evidence = None
        else:
            if evidence.pages:
                return evidence

    raw_content = document.extraction.get("raw_content")
    raw_pages = raw_content.get("pages") if isinstance(raw_content, Mapping) else None
    if isinstance(raw_pages, Sequence) and not isinstance(
        raw_pages, (str, bytes, bytearray)
    ):
        try:
            pages = [EvidencePage.model_validate(page) for page in raw_pages]
        except Exception:  # noqa: BLE001 - native page shapes use the safe probe
            pages = []
        if pages:
            return DocumentEvidence(
                backend=str(metadata.get("adapter") or "retained-document-evidence"),
                backend_version=str(
                    metadata.get("backend_version")
                    or metadata.get("candidate_schema_version")
                    or "m1.document.v2"
                ),
                pages=pages,
                raw={"source_kind": source_kind, "postbuild_replay": True},
            )

    return build_route_probe_evidence(
        document.model_dump(mode="python"),
        source_kind,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
    )


async def _content_route(
    document: DocumentRecord,
    *,
    evidence: DocumentEvidence,
    tenant_id: str,
    runtime: object,
) -> dict[str, Any]:
    probes = build_content_region_probes(evidence)
    signature_groups: dict[str, list[Any]] = {}
    for probe in probes:
        signature_groups.setdefault(probe.signature.exact_fingerprint(), []).append(
            probe
        )
    groups = tuple(signature_groups.values())
    limit = max(
        1,
        min(
            int(
                getattr(
                    runtime,
                    "max_unique_signatures_per_document",
                    _MAX_CONTENT_SIGNATURE_GROUPS,
                )
            ),
            _MAX_CONTENT_SIGNATURE_GROUPS,
        ),
    )
    selected_groups = groups[:limit]
    deferred_groups = groups[limit:]
    if not selected_groups:
        return {
            "schema_version": "m1.content-region-postbuild.v1",
            "status": "skipped",
            "reason": "no_routable_regions",
            "evidence_backend": evidence.backend,
            "region_count": 0,
            "unique_signature_count": 0,
            "processed_region_count": 0,
            "processed_unique_signature_count": 0,
            "routing_resolution_count": 0,
            "deduplicated_region_count": 0,
            "deferred_region_count": 0,
            "deferred_unique_signature_count": 0,
            "truncated_region_count": 0,
            "truncation_reason": None,
            "decisions": [],
            "strategy_assignments": [],
            "strategy_execution": {
                "status": "not_applicable",
                "reason": "no_active_strategy_assignment",
                "fact_mutation_allowed": False,
            },
            "failures": [],
            "fact_mutation_allowed": False,
        }

    decisions: list[dict[str, Any]] = []
    assignments: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    required = _runtime_required(runtime)
    resolved_signature_count = 0
    failed_signature_count = 0
    degraded_signature_count = 0
    model_used_signature_count = 0
    for group in selected_groups:
        probe = group[0]
        try:
            decision = await runtime.resolve(
                tenant_id=tenant_id,
                probe=probe,
                allowed_strategy_ids=None,
                created_by="adaptive-postbuild",
            )
            payload = _dump(decision)
            reason = str(payload.get("reason") or "")
            if required and reason in _CONTENT_DEPENDENCY_REASONS:
                raise AdaptivePostbuildError(
                    f"required content-region route failed: {reason}"
                )
        except Exception as exc:
            if required:
                raise
            failed_signature_count += 1
            failures.extend(
                {
                    "source_ref": grouped_probe.source_ref,
                    "error_type": exc.__class__.__name__,
                }
                for grouped_probe in group
            )
            continue
        resolved_signature_count += 1
        if reason in _CONTENT_DEPENDENCY_REASONS:
            degraded_signature_count += 1
            failures.extend(
                {
                    "source_ref": grouped_probe.source_ref,
                    "error_type": "RoutingDependencyDegraded",
                    "reason": reason,
                }
                for grouped_probe in group
            )
        model_used_signature_count += int(bool(payload.get("model_used")))
        for grouped_probe in group:
            reused = grouped_probe is not probe
            decisions.append(
                {
                    "source_ref": grouped_probe.source_ref,
                    "signature_group_size": len(group),
                    "group_decision_reused": reused,
                    **payload,
                }
            )
            if payload.get("action") == "route":
                assignments.append(
                    {
                        "source_ref": grouped_probe.source_ref,
                        "role": payload.get("role"),
                        "strategy_id": payload.get("strategy_id"),
                        "profile_id": payload.get("profile_id"),
                    }
                )

    processed_region_count = sum(len(group) for group in selected_groups)
    deferred_region_count = sum(len(group) for group in deferred_groups)
    deferred_signature_count = len(deferred_groups)
    status = (
        "degraded"
        if failures
        else "deferred"
        if deferred_signature_count
        else "completed"
    )

    return {
        "schema_version": "m1.content-region-postbuild.v1",
        "status": status,
        "evidence_backend": evidence.backend,
        "region_count": len(probes),
        "unique_signature_count": len(groups),
        "processed_region_count": processed_region_count,
        "processed_unique_signature_count": len(selected_groups),
        "resolved_unique_signature_count": resolved_signature_count,
        "failed_unique_signature_count": failed_signature_count,
        "degraded_unique_signature_count": degraded_signature_count,
        "routing_resolution_count": len(selected_groups),
        "model_used_signature_count": model_used_signature_count,
        "model_call_upper_bound": len(selected_groups),
        "unique_signature_limit": limit,
        "deduplicated_region_count": len(probes) - len(groups),
        "reused_decision_region_count": sum(
            max(0, len(group) - 1) for group in selected_groups
        ),
        "deferred_region_count": deferred_region_count,
        "deferred_unique_signature_count": deferred_signature_count,
        "truncated_region_count": deferred_region_count,
        "truncation_reason": (
            "unique_signature_limit" if deferred_signature_count else None
        ),
        "routed_region_count": len(assignments),
        "review_region_count": sum(
            item.get("action") == "review" for item in decisions
        ),
        "candidate_region_count": sum(
            item.get("action") == "new_candidate" for item in decisions
        ),
        "decisions": decisions,
        "strategy_assignments": assignments,
        "strategy_execution": {
            "status": "audit_only" if assignments else "not_applicable",
            "reason": (
                "no_region_scoped_fact_preserving_executor"
                if assignments
                else "no_active_strategy_assignment"
            ),
            "fact_mutation_allowed": False,
        },
        "failures": failures,
        "fact_mutation_allowed": False,
    }


def _has_lossless_fields(document: DocumentRecord) -> bool:
    extraction_fields = document.extraction.get("custom_fields")
    if isinstance(extraction_fields, Mapping) and extraction_fields:
        return True
    return any(line.custom_fields or line.raw_columns for line in document.lines)


def _existing_field_audit(document: DocumentRecord) -> dict[str, Any] | None:
    audit = _metadata(document).get("field_semantic_routing")
    return audit if isinstance(audit, dict) else None


def _assert_existing_facts_preserved(
    before: DocumentRecord,
    after: DocumentRecord,
) -> None:
    """Reject any route that changed an already populated business value."""

    if before.source.model_dump(mode="json") != after.source.model_dump(mode="json"):
        raise AdaptivePostbuildError("field routing changed document source identity")
    if (
        before.document_type != after.document_type
        or before.document_subtype != after.document_subtype
        or before.document_kind_label != after.document_kind_label
    ):
        raise AdaptivePostbuildError("field routing changed document classification")
    if len(before.lines) != len(after.lines):
        raise AdaptivePostbuildError("field routing changed the business row count")

    def populated_values(value: object) -> object:
        if isinstance(value, Mapping):
            return {
                str(key): populated_values(item)
                for key, item in value.items()
                if item not in (None, "")
            }
        if isinstance(value, list):
            return [populated_values(item) for item in value]
        return value

    for before_value, after_value, name in (
        (
            before.header.model_dump(mode="json"),
            after.header.model_dump(mode="json"),
            "header",
        ),
        (
            before.totals.model_dump(mode="json"),
            after.totals.model_dump(mode="json"),
            "totals",
        ),
    ):
        expected = populated_values(before_value)
        actual = populated_values(after_value)
        for key, value in expected.items():
            if actual.get(key) != value:
                raise AdaptivePostbuildError(
                    f"field routing replaced an existing {name} fact: {key}"
                )
    for index, (old, new) in enumerate(zip(before.lines, after.lines, strict=True)):
        expected = populated_values(old.model_dump(mode="json"))
        actual = populated_values(new.model_dump(mode="json"))
        for key, value in expected.items():
            if actual.get(key) != value:
                raise AdaptivePostbuildError(
                    f"field routing replaced an existing line fact: {index}:{key}"
                )
    for path, field_metadata in before.field_meta.items():
        current = after.field_meta.get(path)
        if current is None or current.model_dump(
            mode="json"
        ) != field_metadata.model_dump(mode="json"):
            raise AdaptivePostbuildError(
                f"field routing changed existing source evidence: {path}"
            )


async def _field_route(
    document: DocumentRecord,
    *,
    tenant_id: str,
    runtime: object,
    registry: CanonicalFieldRegistry | None,
) -> tuple[DocumentRecord, dict[str, Any]]:
    existing = _existing_field_audit(document)
    if existing is not None:
        if _runtime_required(runtime) and existing.get("status") == "degraded":
            raise AdaptivePostbuildError(
                "required field-semantic route was already degraded"
            )
        return document, {
            "schema_version": "m1.field-semantic-postbuild.v1",
            "status": "already_routed",
            "route_status": existing.get("status"),
            "duplicate_execution_prevented": True,
        }
    if not _has_lossless_fields(document):
        return document, {
            "schema_version": "m1.field-semantic-postbuild.v1",
            "status": "skipped",
            "reason": "no_lossless_custom_or_raw_fields",
        }

    active_registry = registry or build_document_canonical_field_registry()
    before = document.model_copy(deep=True)
    bounded_runtime = _BoundedFieldRuntime(runtime)
    routed = await route_document_custom_fields(
        document=document,
        tenant_id=tenant_id,
        runtime=bounded_runtime,
        registry=active_registry,
    )
    audit = _existing_field_audit(routed)
    if audit is None:
        raise AdaptivePostbuildError("field-semantic route returned no audit metadata")
    if audit.get("status") == "degraded" and _runtime_required(runtime):
        raise AdaptivePostbuildError("required field-semantic route degraded")
    audit.update(bounded_runtime.audit)
    if int(audit.get("deferred_unique_signature_count") or 0):
        audit["status"] = "deferred"
    _assert_existing_facts_preserved(before, routed)
    return routed, {
        "schema_version": "m1.field-semantic-postbuild.v1",
        "status": str(audit.get("status") or "completed"),
        "observed_fields": int(audit.get("observed_fields") or 0),
        "mapped_fields": int(audit.get("mapped_fields") or 0),
        "populated_values": int(audit.get("populated_values") or 0),
        "unique_signature_count": int(audit.get("unique_signature_count") or 0),
        "processed_unique_signature_count": int(
            audit.get("processed_unique_signature_count") or 0
        ),
        "deferred_unique_signature_count": int(
            audit.get("deferred_unique_signature_count") or 0
        ),
        "routing_resolution_count": int(audit.get("routing_resolution_count") or 0),
        "model_call_upper_bound": int(audit.get("model_call_upper_bound") or 0),
        "unique_signature_limit": int(audit.get("unique_signature_limit") or 0),
        "lossless_source_preserved": True,
    }


def _position_bucket(
    start: float | None,
    end: float | None,
    maximum: float | None,
) -> VisualPositionBucket:
    if start is None or end is None or maximum is None or maximum <= 0:
        return VisualPositionBucket.UNKNOWN
    span = max(0.0, end - start)
    if span / maximum >= 0.60:
        return VisualPositionBucket.SPANNING
    midpoint = (start + end) / 2
    if midpoint <= maximum / 3:
        return VisualPositionBucket.START
    if midpoint >= maximum * 2 / 3:
        return VisualPositionBucket.END
    return VisualPositionBucket.CENTER


def _area_bucket(ratio: float | None) -> VisualAreaBucket:
    if ratio is None or not math.isfinite(ratio) or ratio < 0:
        return VisualAreaBucket.UNKNOWN
    if ratio < 0.01:
        return VisualAreaBucket.TINY
    if ratio < 0.05:
        return VisualAreaBucket.SMALL
    if ratio < 0.20:
        return VisualAreaBucket.MEDIUM
    if ratio < 0.50:
        return VisualAreaBucket.LARGE
    return VisualAreaBucket.DOMINANT


def _aspect_bucket(width: float | None, height: float | None) -> VisualAspectBucket:
    if width is None or height is None or width <= 0 or height <= 0:
        return VisualAspectBucket.UNKNOWN
    ratio = width / height
    if ratio < 0.75:
        return VisualAspectBucket.PORTRAIT
    if ratio <= 1.35:
        return VisualAspectBucket.SQUARE
    if ratio <= 3.0:
        return VisualAspectBucket.LANDSCAPE
    return VisualAspectBucket.WIDE


def _page_dimensions(evidence: DocumentEvidence) -> dict[int, tuple[float, float]]:
    return {
        page.page_number: (float(page.width), float(page.height))
        for page in evidence.pages
    }


def _inventory_topology(
    asset: object,
    *,
    source_kind: VisualRegionSourceKind,
    dimensions: Mapping[int, tuple[float, float]],
) -> VisualRegionTopology:
    references = list(getattr(asset, "source_refs", ()) or ())
    anchor = next(
        (
            getattr(reference, "anchor", None)
            for reference in references
            if getattr(reference, "anchor", None) is not None
        ),
        None,
    )
    bbox = getattr(anchor, "bbox", None) if anchor is not None else None
    page_number = next(
        (
            getattr(getattr(reference, "source_ref", None), "page", None)
            for reference in references
            if getattr(getattr(reference, "source_ref", None), "page", None) is not None
        ),
        None,
    )
    page_size = dimensions.get(int(page_number)) if page_number is not None else None
    if isinstance(bbox, list) and len(bbox) == 4:
        x0, y0, x1, y1 = (float(value) for value in bbox)
        width = max(0.0, x1 - x0)
        height = max(0.0, y1 - y0)
    else:
        x0 = y0 = x1 = y1 = None
        width = height = None
    page_width, page_height = page_size if page_size is not None else (None, None)
    area_ratio = (
        width * height / (page_width * page_height)
        if width is not None
        and height is not None
        and page_width is not None
        and page_height is not None
        and page_width > 0
        and page_height > 0
        else None
    )
    return VisualRegionTopology(
        source_kind=source_kind,
        horizontal_position=_position_bucket(x0, x1, page_width),
        vertical_position=_position_bucket(y0, y1, page_height),
        area_bucket=_area_bucket(area_ratio),
        aspect_bucket=_aspect_bucket(width, height),
        repeated_across_pages=len(references) > 1,
    )


def _source_image(
    source_path: Path,
    document: DocumentRecord,
) -> tuple[bytes, str, str, VisualRegionTopology] | None:
    if (
        not source_path.is_file()
        or source_path.stat().st_size > _MAX_VISUAL_ASSET_BYTES
    ):
        return None
    from ..magic import sniff_file_type

    detected = sniff_file_type(source_path)
    if detected.kind != "image" or detected.mime_type not in _SAFE_VISUAL_MEDIA_TYPES:
        return None
    payload = source_path.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    if document.source.sha256 and document.source.sha256.casefold() != digest:
        raise AdaptivePostbuildError("source image SHA-256 does not match document")
    width = height = None
    try:
        from PIL import Image

        with Image.open(source_path) as image:
            width, height = (float(value) for value in image.size)
    except Exception:  # noqa: BLE001 - identity is valid; geometry stays unknown
        width = height = None
    topology = VisualRegionTopology(
        source_kind=VisualRegionSourceKind.PARSER_REGION,
        horizontal_position=VisualPositionBucket.SPANNING,
        vertical_position=VisualPositionBucket.SPANNING,
        area_bucket=VisualAreaBucket.DOMINANT,
        aspect_bucket=_aspect_bucket(width, height),
    )
    return payload, detected.mime_type, digest, topology


async def _visual_route(
    document: DocumentRecord,
    *,
    evidence: DocumentEvidence,
    tenant_id: str,
    source_path: str,
    source_kind: str,
    runtime: object,
) -> dict[str, Any]:
    extraction_audit = document.extraction.get("visual_region_routing")
    metadata_audit = _metadata(document).get("visual_region_routing")
    if isinstance(extraction_audit, Mapping) or isinstance(metadata_audit, Mapping):
        return {
            "schema_version": "m1.visual-region-postbuild.v1",
            "status": "already_routed",
            "duplicate_execution_prevented": True,
            "fact_mutation_allowed": False,
        }

    source = Path(source_path)
    assets: list[tuple[str, bytes, str, str, VisualRegionTopology]] = []
    inventory_deferred: dict[str, str] = {}
    if source_kind == "image":
        item = _source_image(source, document)
        if item is not None:
            payload, media_type, digest, topology = item
            assets.append(
                (f"asset:sha256:{digest}", payload, media_type, digest, topology)
            )
    elif source_kind in {"pdf", "docx"}:
        from .source_asset_inventory import inventory_source_assets
        from .visual_asset_evidence import _read_asset_payload

        inventory = inventory_source_assets(source)
        if document.source.sha256 and (
            inventory.source_sha256 != document.source.sha256.casefold()
        ):
            raise AdaptivePostbuildError(
                "source asset inventory SHA-256 does not match document"
            )
        routed_source_kind = (
            VisualRegionSourceKind.PDF_FIGURE
            if source_kind == "pdf"
            else VisualRegionSourceKind.OFFICE_SHAPE
        )
        dimensions = _page_dimensions(evidence)
        inventory_limit = max(
            1,
            min(int(getattr(runtime, "max_regions_per_document", 32)), 64),
        )
        for asset in inventory.assets:
            if (
                asset.byte_size > _MAX_VISUAL_ASSET_BYTES
                or asset.mime_type.casefold() not in _SAFE_VISUAL_MEDIA_TYPES
            ):
                continue
            if len(assets) >= inventory_limit:
                inventory_deferred[asset.asset_id] = "region_inventory_limit"
                continue
            payload = _read_asset_payload(source, inventory, asset)
            assets.append(
                (
                    asset.asset_id,
                    payload,
                    asset.mime_type,
                    asset.sha256,
                    _inventory_topology(
                        asset,
                        source_kind=routed_source_kind,
                        dimensions=dimensions,
                    ),
                )
            )

    if not assets:
        return {
            "schema_version": "m1.visual-region-postbuild.v1",
            "status": "skipped",
            "reason": "no_verified_raster_asset",
            "routed_asset_count": 0,
            "fact_mutation_allowed": False,
        }

    signature_groups: dict[
        str, list[tuple[str, bytes, str, str, VisualRegionTopology]]
    ] = {}
    for asset in assets:
        signature_groups.setdefault(asset[4].exact_fingerprint(), []).append(asset)
    groups = tuple(signature_groups.items())
    signature_limit = max(
        1,
        min(
            int(
                getattr(
                    runtime,
                    "max_unique_signatures_per_document",
                    _MAX_VISUAL_SIGNATURE_GROUPS,
                )
            ),
            _MAX_VISUAL_SIGNATURE_GROUPS,
        ),
    )
    selected_groups = groups[:signature_limit]
    over_budget_groups = groups[signature_limit:]
    unsafe_duplicate_count = sum(
        sum(asset[3] != group[0][3] for asset in group[1:])
        for _fingerprint, group in selected_groups
    )
    if _runtime_required(runtime) and (
        inventory_deferred or over_budget_groups or unsafe_duplicate_count
    ):
        raise AdaptivePostbuildError(
            "required visual-region route exceeds the safe unique-signature budget"
        )

    decisions: dict[str, dict[str, Any]] = {}
    failures: dict[str, str] = {}
    deferred: dict[str, str] = dict(inventory_deferred)
    required = _runtime_required(runtime)
    model_used_signature_count = 0
    resolved_signature_count = 0
    failed_signature_count = 0
    degraded_signature_count = 0
    for fingerprint, group in selected_groups:
        asset_id, payload, media_type, digest, topology = group[0]
        try:
            decision = await runtime.resolve(
                tenant_id=tenant_id,
                geometry=VisualGeometryAssessment(
                    role=None,
                    reason=VisualGeometryReason.INSUFFICIENT_GEOMETRY,
                ),
                topology=topology,
                allowed_roles=tuple(VisualRegionRole),
                image_bytes=payload,
                media_type=media_type,
                asset_sha256=digest,
            )
            decision_payload = _dump(decision)
            reason = str(decision_payload.get("reason") or "")
            if required and reason in _VISUAL_DEPENDENCY_REASONS:
                raise AdaptivePostbuildError(
                    f"required visual-region route failed: {reason}"
                )
        except Exception as exc:
            if required:
                raise
            failed_signature_count += 1
            for grouped_asset in group:
                failures[grouped_asset[0]] = exc.__class__.__name__
            continue
        resolved_signature_count += 1
        model_used_signature_count += int(bool(decision_payload.get("model_used")))
        if reason in _VISUAL_DEPENDENCY_REASONS:
            degraded_signature_count += 1
            failures[asset_id] = reason
        if decision_payload.get("action") == "route" and decision_payload.get(
            "case_id"
        ):
            decision_payload.setdefault("profile_id", decision_payload["case_id"])
        decision_payload.update(
            {
                "topology_fingerprint": fingerprint,
                "signature_group_size": len(group),
                "group_decision_reused": False,
            }
        )
        decisions[asset_id] = decision_payload
        for duplicate in group[1:]:
            duplicate_id, _bytes, _media_type, duplicate_digest, _topology = duplicate
            if duplicate_digest == digest:
                reused = copy.deepcopy(decision_payload)
                reused["group_decision_reused"] = True
                decisions[duplicate_id] = reused
                if reason in _VISUAL_DEPENDENCY_REASONS:
                    failures[duplicate_id] = reason
            else:
                deferred[duplicate_id] = "distinct_asset_same_value_free_signature"

    for _fingerprint, group in over_budget_groups:
        for asset_id, _bytes, _media_type, _digest, _topology in group:
            deferred[asset_id] = "unique_signature_limit"

    candidate_profile_ids = sorted(
        {
            str(payload["candidate_profile_id"])
            for payload in decisions.values()
            if payload.get("candidate_profile_id")
        }
    )
    profile_ids = sorted(
        {
            str(payload["profile_id"])
            for payload in decisions.values()
            if payload.get("profile_id")
        }
    )

    return {
        "schema_version": "m1.visual-region-postbuild.v1",
        "status": "degraded" if failures else "deferred" if deferred else "completed",
        "asset_count": len(assets) + len(inventory_deferred),
        "loaded_asset_count": len(assets),
        "inventory_deferred_asset_count": len(inventory_deferred),
        "unique_signature_count": len(groups),
        "processed_unique_signature_count": len(selected_groups),
        "resolved_unique_signature_count": resolved_signature_count,
        "failed_unique_signature_count": failed_signature_count,
        "degraded_unique_signature_count": degraded_signature_count,
        "routing_resolution_count": len(selected_groups),
        "model_used_signature_count": model_used_signature_count,
        "model_call_upper_bound": len(selected_groups),
        "unique_signature_limit": signature_limit,
        "deduplicated_asset_count": len(assets) - len(groups),
        "routed_asset_count": len(decisions),
        "failed_asset_count": len(failures),
        "deferred_asset_count": len(deferred),
        "deferred_unique_signature_count": len(over_budget_groups),
        "candidate_profile_ids": candidate_profile_ids,
        "profile_ids": profile_ids,
        "decisions": decisions,
        "failures": failures,
        "deferred": deferred,
        "fact_mutation_allowed": False,
    }


async def run_adaptive_postbuild(
    document: Mapping[str, Any],
    *,
    tenant_id: str,
    source_path: str,
    source_kind: str,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    content_runtime: object | None = None,
    field_runtime: object | None = None,
    field_registry: CanonicalFieldRegistry | None = None,
    visual_runtime: object | None = None,
) -> dict[str, Any]:
    """Apply every enabled post-build router once and return a valid v2 record."""

    record = DocumentRecord.model_validate(copy.deepcopy(dict(document)))
    metadata = _metadata(record)
    existing = metadata.get("adaptive_postbuild")
    if isinstance(existing, Mapping) and existing.get("schema_version") == (
        _POSTBUILD_SCHEMA
    ):
        return copy.deepcopy(dict(document))

    normalized_tenant = str(tenant_id or "default").strip().casefold() or "default"
    evidence = _document_evidence(
        record,
        source_kind=source_kind,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
    )
    stages: dict[str, dict[str, Any]] = {}

    if content_runtime is not None:
        try:
            audit = await _content_route(
                record,
                evidence=evidence,
                tenant_id=normalized_tenant,
                runtime=content_runtime,
            )
        except Exception as exc:
            if _runtime_required(content_runtime):
                raise
            audit = {
                "schema_version": "m1.content-region-postbuild.v1",
                "status": "degraded",
                "error_type": exc.__class__.__name__,
                "fact_mutation_allowed": False,
            }
        _metadata(record)["content_region_routing"] = audit
        stages["content"] = {
            "status": str(audit.get("status") or "completed"),
            "region_count": int(audit.get("region_count") or 0),
        }
    else:
        stages["content"] = {"status": "disabled"}

    if field_runtime is not None:
        try:
            record, audit = await _field_route(
                record,
                tenant_id=normalized_tenant,
                runtime=field_runtime,
                registry=field_registry,
            )
        except Exception as exc:
            if _runtime_required(field_runtime):
                raise
            audit = {
                "schema_version": "m1.field-semantic-postbuild.v1",
                "status": "degraded",
                "error_type": exc.__class__.__name__,
                "lossless_source_preserved": True,
            }
        stages["field"] = audit
    else:
        stages["field"] = {"status": "disabled"}

    if visual_runtime is not None:
        try:
            audit = await _visual_route(
                record,
                evidence=evidence,
                tenant_id=normalized_tenant,
                source_path=source_path,
                source_kind=source_kind,
                runtime=visual_runtime,
            )
        except Exception as exc:
            if _runtime_required(visual_runtime):
                raise
            audit = {
                "schema_version": "m1.visual-region-postbuild.v1",
                "status": "degraded",
                "error_type": exc.__class__.__name__,
                "fact_mutation_allowed": False,
            }
        _metadata(record)["visual_region_routing"] = audit
        stages["visual"] = {
            "status": str(audit.get("status") or "completed"),
            "routed_asset_count": int(audit.get("routed_asset_count") or 0),
        }
    else:
        stages["visual"] = {"status": "disabled"}

    if document_type_hint and record.document_type != document_type_hint:
        raise AdaptivePostbuildError("post-build routing changed explicit type hint")
    if document_subtype_hint and record.document_subtype != document_subtype_hint:
        raise AdaptivePostbuildError("post-build routing changed explicit subtype hint")

    overall = (
        "degraded"
        if any(stage.get("status") == "degraded" for stage in stages.values())
        else "completed"
    )
    _metadata(record)["adaptive_postbuild"] = {
        "schema_version": _POSTBUILD_SCHEMA,
        "status": overall,
        "invocation_count": 1,
        "evidence_backend": evidence.backend,
        "stages": stages,
    }
    return record.model_dump(mode="json", exclude_unset=True)


__all__ = [
    "AdaptivePostbuildError",
    "run_adaptive_postbuild",
]
