"""Pure adaptive routing policy for reusable document layouts.

The router sees canonical structure and label names only. Raw document text,
filenames, tenant/source identifiers, and extracted business values are not
part of :class:`DocumentRouteSignature` and therefore cannot enter its exact
fingerprint or the selector prompt.

This module deliberately has no parser-pipeline or persistence integration.
Exact matches are deterministic. Approximate reuse requires both an explicit
small-model choice and deterministic score/margin gates; every model absence
or failure fails closed to the generic route.
"""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal, Protocol, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from .document_route_signature import (
    DocumentRouteSignature,
    FormatFamily,
    PageCountBucket,
    RouteTableShape,
    RowCountBucket,
    TableOrientation,
    build_document_route_signature,
)

RouteAction = Literal["reuse", "generic", "propose"]
RouteDecisionReason = Literal[
    "exact_fingerprint",
    "ambiguous_exact_fingerprint",
    "no_model",
    "model_failure",
    "invalid_model_output",
    "model_generic",
    "model_propose",
    "model_reuse",
    "proposal_confidence_below_threshold",
    "reuse_candidate_missing",
    "reuse_candidate_not_top",
    "reuse_confidence_below_threshold",
    "reuse_score_below_threshold",
    "reuse_margin_below_threshold",
]


def _bounded_score(value: float) -> float:
    return round(max(0.0, min(1.0, float(value))), 6)


class DocumentRouteCandidate(BaseModel):
    """Previously accepted reusable route and its value-free signature."""

    model_config = ConfigDict(extra="forbid", frozen=True, str_strip_whitespace=True)

    route_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    signature: DocumentRouteSignature
    signature_vector: tuple[float, ...] | None = None

    @field_validator("signature_vector")
    @classmethod
    def validate_signature_vector(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        vector = tuple(float(item) for item in value)
        if not vector:
            raise ValueError("signature vector must not be empty")
        if not all(math.isfinite(item) for item in vector):
            raise ValueError("signature vector must contain only finite values")
        return vector


class DocumentRouteCandidateContext(BaseModel):
    """Value-free policy facts the selector needs to compare candidates.

    Similarity scores alone do not tell a selector what a route actually does.
    Keep this context limited to closed policy enums, revisions, and aggregate
    reliability counters; source text, filenames, business values, and task
    references must never be included.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_family: str = Field(
        default="generic_layout",
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    document_type: str | None = Field(
        default=None,
        min_length=1,
        max_length=64,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    document_subtype: str | None = Field(
        default=None,
        min_length=1,
        max_length=96,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    backend_chain: tuple[str, ...] = Field(default=(), max_length=8)
    table_roles: tuple[str, ...] = Field(default=(), max_length=64)
    table_role_count: int = Field(default=0, ge=0, le=4096)
    verifier_policy: str = Field(
        default="on_uncertainty",
        min_length=1,
        max_length=32,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    visual_policy: str = Field(
        default="on_uncertainty",
        min_length=1,
        max_length=32,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    authority_policy: str = Field(
        default="evidence_required",
        min_length=1,
        max_length=32,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    contract_revision: str = Field(
        default="m1.document.v2",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    parser_revision: str = Field(
        default="m1.route-parser.v1",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    observation_count: int = Field(default=0, ge=0)
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)

    @field_validator("backend_chain", "table_roles", mode="before")
    @classmethod
    def normalize_policy_tokens(cls, value: object) -> object:
        if value is None:
            return ()
        if isinstance(value, str):
            return (value.strip().casefold(),) if value.strip() else ()
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return tuple(
                str(item).strip().casefold()
                for item in value
                if str(item).strip()
            )
        return value


class DocumentRouteCandidateScore(BaseModel):
    """Auditable three-channel similarity score for one candidate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    route_id: str
    signature: DocumentRouteSignature
    exact_fingerprint: bool = False
    structure_similarity: float = Field(ge=0.0, le=1.0)
    label_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)
    context: DocumentRouteCandidateContext | None = None


class DocumentRouteSelectionRequest(BaseModel):
    """Bounded value-free input supplied to an optional small model."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: DocumentRouteSignature
    candidates: tuple[DocumentRouteCandidateScore, ...] = ()


class DocumentRouteModelChoice(BaseModel):
    """Strict small-model output; arbitrary explanations are intentionally absent."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)

    action: RouteAction
    candidate_route_id: str | None = Field(default=None, min_length=1, max_length=128)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def action_matches_candidate(self) -> Self:
        if self.action == "reuse" and self.candidate_route_id is None:
            raise ValueError("reuse requires candidate_route_id")
        if self.action != "reuse" and self.candidate_route_id is not None:
            raise ValueError("only reuse may include candidate_route_id")
        return self


class DocumentRouteDecision(BaseModel):
    """Side-effect-free routing outcome for a future pipeline integration."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    action: RouteAction
    route_id: str | None = None
    reason: RouteDecisionReason
    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    top1_top2_margin: float = Field(default=0.0, ge=0.0, le=1.0)
    candidates: tuple[DocumentRouteCandidateScore, ...] = ()
    model_used: bool = False
    model_choice: RouteAction | None = None

    @model_validator(mode="after")
    def route_matches_action(self) -> Self:
        if self.action == "reuse" and self.route_id is None:
            raise ValueError("reuse decision requires route_id")
        if self.action != "reuse" and self.route_id is not None:
            raise ValueError("non-reuse decision must not include route_id")
        return self


class DocumentRouteSelector(Protocol):
    async def select(
        self, request: DocumentRouteSelectionRequest
    ) -> DocumentRouteModelChoice | Mapping[str, Any]: ...


class StructuredSelectionClient(Protocol):
    async def run(
        self,
        output_type: type[DocumentRouteModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> Any: ...


class PydanticDocumentRouteSelector:
    """Thin adapter for the existing PromptedOutput structured model client."""

    _INSTRUCTIONS = (
        "Select a document-layout route using only the supplied value-free signature. "
        "Use reuse only for one listed candidate, generic when evidence is ambiguous, "
        "and propose only for a clearly distinct reusable layout. Compare the listed "
        "candidate policy context, backend chain, and aggregate reliability when choosing. "
        "Never infer business facts or emit fields outside the requested schema."
    )

    def __init__(self, client: StructuredSelectionClient) -> None:
        self._client = client

    async def select(
        self, request: DocumentRouteSelectionRequest
    ) -> DocumentRouteModelChoice:
        run = await self._client.run(
            DocumentRouteModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=json.dumps(
                request.model_dump(mode="json"),
                ensure_ascii=True,
                sort_keys=True,
                separators=(",", ":"),
            ),
            request_limit=1,
        )
        return DocumentRouteModelChoice.model_validate(run.output, strict=True)


@dataclass(frozen=True, slots=True)
class DocumentRoutePolicy:
    structure_weight: float = 0.45
    label_weight: float = 0.35
    vector_weight: float = 0.20
    reuse_min_score: float = 0.80
    reuse_min_margin: float = 0.08
    reuse_min_model_confidence: float = 0.70
    proposal_min_model_confidence: float = 0.75
    max_model_candidates: int = 5

    def __post_init__(self) -> None:
        bounded = (
            self.structure_weight,
            self.label_weight,
            self.vector_weight,
            self.reuse_min_score,
            self.reuse_min_margin,
            self.reuse_min_model_confidence,
            self.proposal_min_model_confidence,
        )
        if not all(math.isfinite(item) and 0.0 <= item <= 1.0 for item in bounded):
            raise ValueError("route weights and thresholds must be finite values in [0, 1]")
        if self.structure_weight + self.label_weight + self.vector_weight <= 0.0:
            raise ValueError("at least one similarity weight must be positive")
        if self.max_model_candidates < 1:
            raise ValueError("max_model_candidates must be positive")


def _jaccard(
    first: Sequence[str],
    second: Sequence[str],
    *,
    both_empty: float | None,
) -> float | None:
    left, right = set(first), set(second)
    if not left and not right:
        return both_empty
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def _cosine_similarity(
    first: Sequence[float] | None,
    second: Sequence[float] | None,
) -> float | None:
    if first is None or second is None or len(first) != len(second) or not first:
        return None
    if not all(math.isfinite(float(item)) for item in (*first, *second)):
        return None
    left_norm = math.sqrt(sum(float(item) ** 2 for item in first))
    right_norm = math.sqrt(sum(float(item) ** 2 for item in second))
    if left_norm == 0.0 or right_norm == 0.0:
        return None
    value = sum(float(left) * float(right) for left, right in zip(first, second))
    return _bounded_score(value / (left_norm * right_norm))


class AdaptiveDocumentRouter:
    """Rank known routes and apply a fail-closed approximate-reuse policy."""

    def __init__(
        self,
        *,
        selector: DocumentRouteSelector | None = None,
        policy: DocumentRoutePolicy | None = None,
    ) -> None:
        self.selector = selector
        self.policy = policy or DocumentRoutePolicy()

    def _score_candidate(
        self,
        signature: DocumentRouteSignature,
        candidate: DocumentRouteCandidate,
        signature_vector: Sequence[float] | None,
    ) -> DocumentRouteCandidateScore:
        exact = signature.exact_fingerprint() == candidate.signature.exact_fingerprint()
        structure = 0.0
        if signature.format_family == candidate.signature.format_family:
            structure = float(
                _jaccard(
                    signature.structural_tokens(),
                    candidate.signature.structural_tokens(),
                    both_empty=0.0,
                )
                or 0.0
            )
        labels = _jaccard(
            signature.label_tokens,
            candidate.signature.label_tokens,
            both_empty=None,
        )
        vector = _cosine_similarity(signature_vector, candidate.signature_vector)
        components = [(structure, self.policy.structure_weight)]
        if labels is not None:
            components.append((labels, self.policy.label_weight))
        if vector is not None:
            components.append((vector, self.policy.vector_weight))
        weight = sum(item_weight for _score, item_weight in components)
        fused = (
            sum(score * item_weight for score, item_weight in components) / weight
            if weight > 0.0
            else 0.0
        )
        if exact:
            fused = 1.0
        return DocumentRouteCandidateScore(
            route_id=candidate.route_id,
            signature=candidate.signature,
            exact_fingerprint=exact,
            structure_similarity=_bounded_score(structure),
            label_similarity=None if labels is None else _bounded_score(labels),
            vector_similarity=vector,
            fused_score=_bounded_score(fused),
        )

    def _rank_all(
        self,
        signature: DocumentRouteSignature,
        candidates: Sequence[DocumentRouteCandidate],
        signature_vector: Sequence[float] | None,
    ) -> tuple[DocumentRouteCandidateScore, ...]:
        route_ids = [candidate.route_id for candidate in candidates]
        if len(route_ids) != len(set(route_ids)):
            raise ValueError("route candidate IDs must be unique")
        scores = [
            self._score_candidate(signature, candidate, signature_vector)
            for candidate in candidates
        ]
        return tuple(sorted(scores, key=lambda item: (-item.fused_score, item.route_id)))

    def rank_candidates(
        self,
        signature: DocumentRouteSignature,
        candidates: Sequence[DocumentRouteCandidate],
        *,
        signature_vector: Sequence[float] | None = None,
    ) -> tuple[DocumentRouteCandidateScore, ...]:
        return self._rank_all(signature, candidates, signature_vector)

    @staticmethod
    def _top_metrics(
        ranked: Sequence[DocumentRouteCandidateScore],
    ) -> tuple[float, float]:
        if not ranked:
            return 0.0, 0.0
        top_score = ranked[0].fused_score
        second_score = ranked[1].fused_score if len(ranked) > 1 else 0.0
        return top_score, _bounded_score(top_score - second_score)

    @staticmethod
    def _decision(
        *,
        action: RouteAction,
        route_id: str | None,
        reason: RouteDecisionReason,
        signature: DocumentRouteSignature,
        ranked: tuple[DocumentRouteCandidateScore, ...],
        top_score: float,
        margin: float,
        model_used: bool,
        model_choice: RouteAction | None = None,
    ) -> DocumentRouteDecision:
        return DocumentRouteDecision(
            action=action,
            route_id=route_id,
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            top_score=top_score,
            top1_top2_margin=margin,
            candidates=ranked,
            model_used=model_used,
            model_choice=model_choice,
        )

    async def decide(
        self,
        signature: DocumentRouteSignature,
        candidates: Sequence[DocumentRouteCandidate],
        *,
        signature_vector: Sequence[float] | None = None,
    ) -> DocumentRouteDecision:
        ranked_all = self._rank_all(signature, candidates, signature_vector)
        ranked = ranked_all[: self.policy.max_model_candidates]
        top_score, margin = self._top_metrics(ranked_all)
        exact = [candidate for candidate in ranked_all if candidate.exact_fingerprint]
        if len(exact) == 1:
            return self._decision(
                action="reuse",
                route_id=exact[0].route_id,
                reason="exact_fingerprint",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=False,
            )
        if len(exact) > 1:
            return self._decision(
                action="generic",
                route_id=None,
                reason="ambiguous_exact_fingerprint",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=False,
            )
        if self.selector is None:
            return self._decision(
                action="generic",
                route_id=None,
                reason="no_model",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=False,
            )

        request = DocumentRouteSelectionRequest(
            signature_fingerprint=signature.exact_fingerprint(),
            signature=signature,
            candidates=ranked,
        )
        try:
            raw_choice = await self.selector.select(request)
            choice = DocumentRouteModelChoice.model_validate(raw_choice, strict=True)
        except (TypeError, ValueError, ValidationError):
            return self._decision(
                action="generic",
                route_id=None,
                reason="invalid_model_output",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=True,
            )
        # Selector implementations may surface provider-specific transport and
        # inference exceptions. None may escape into or block document parsing.
        except Exception:  # noqa: BLE001
            return self._decision(
                action="generic",
                route_id=None,
                reason="model_failure",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=True,
            )

        if choice.action == "generic":
            return self._decision(
                action="generic",
                route_id=None,
                reason="model_generic",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=True,
                model_choice=choice.action,
            )
        if choice.action == "propose":
            action: RouteAction = "propose"
            reason: RouteDecisionReason = "model_propose"
            if choice.confidence < self.policy.proposal_min_model_confidence:
                action = "generic"
                reason = "proposal_confidence_below_threshold"
            return self._decision(
                action=action,
                route_id=None,
                reason=reason,
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=True,
                model_choice=choice.action,
            )

        if not ranked:
            reason = "reuse_candidate_missing"
        elif choice.candidate_route_id != ranked[0].route_id:
            reason = "reuse_candidate_not_top"
        elif choice.confidence < self.policy.reuse_min_model_confidence:
            reason = "reuse_confidence_below_threshold"
        elif top_score < self.policy.reuse_min_score:
            reason = "reuse_score_below_threshold"
        elif margin < self.policy.reuse_min_margin:
            reason = "reuse_margin_below_threshold"
        else:
            return self._decision(
                action="reuse",
                route_id=ranked[0].route_id,
                reason="model_reuse",
                signature=signature,
                ranked=ranked,
                top_score=top_score,
                margin=margin,
                model_used=True,
                model_choice=choice.action,
            )
        return self._decision(
            action="generic",
            route_id=None,
            reason=reason,
            signature=signature,
            ranked=ranked,
            top_score=top_score,
            margin=margin,
            model_used=True,
            model_choice=choice.action,
        )


__all__ = [
    "AdaptiveDocumentRouter",
    "DocumentRouteCandidate",
    "DocumentRouteCandidateContext",
    "DocumentRouteCandidateScore",
    "DocumentRouteDecision",
    "DocumentRouteModelChoice",
    "DocumentRoutePolicy",
    "DocumentRouteSelectionRequest",
    "DocumentRouteSelector",
    "DocumentRouteSignature",
    "FormatFamily",
    "PageCountBucket",
    "PydanticDocumentRouteSelector",
    "RouteTableShape",
    "RowCountBucket",
    "TableOrientation",
    "build_document_route_signature",
]
