"""Backend protocol shared by optional document parsing engines."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, Sequence

from .evidence import DocumentEvidence


class ParserBackendError(RuntimeError):
    """A parser backend failed after it was selected."""


class ParserBackendUnavailable(ParserBackendError):
    """A configured optional backend or its offline models are unavailable."""


@dataclass(frozen=True, slots=True)
class PageInput:
    """One rendered page and the coordinate system of the source document."""

    path: Path
    page_number: int
    page_index: int
    coordinate_width: float
    coordinate_height: float
    rotation: int = 0


class DocumentParserBackend(Protocol):
    """Synchronous backend contract; the service owns timeouts and concurrency."""

    name: str

    def parse(
        self,
        path: str | Path,
        *,
        pages: Sequence[PageInput] | None = None,
    ) -> DocumentEvidence: ...

    def readiness(self) -> dict[str, object]: ...


__all__ = [
    "DocumentParserBackend",
    "PageInput",
    "ParserBackendError",
    "ParserBackendUnavailable",
]
