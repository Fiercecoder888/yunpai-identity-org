"""Business-evidence merge and escalation helpers for parser orchestration."""

from __future__ import annotations

import copy
import math
from typing import Any, Iterable

from .evidence import DocumentEvidence


def _safe_error(exc: BaseException) -> str:
    return exc.__class__.__name__


def _value_present(value: Any) -> bool:
    return value not in (None, "", [], {})


def _confidence(metadata: dict[str, Any], path: str) -> float:
    value = metadata.get(path)
    if not isinstance(value, dict):
        return 1.0
    try:
        return float(value.get("confidence", 1.0))
    except (TypeError, ValueError):
        return 1.0


def _positioned_source_ref(ref: Any) -> bool:
    if not isinstance(ref, dict) or not ref.get("page") or not ref.get("part"):
        return False
    bbox = ref.get("bbox")
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        return False
    try:
        x0, y0, x1, y1 = (float(value) for value in bbox)
    except (TypeError, ValueError):
        return False
    return (
        all(math.isfinite(value) for value in (x0, y0, x1, y1))
        and x1 > x0
        and y1 > y0
        and bool(ref.get("coordinate_space"))
    )


def _has_positioned_field_evidence(metadata: dict[str, Any], path: str) -> bool:
    meta = metadata.get(path)
    return isinstance(meta, dict) and any(
        _positioned_source_ref(ref) for ref in meta.get("source_refs") or []
    )


def _merge_vlm_supplement(
    primary: dict[str, Any],
    supplemented: dict[str, Any],
    *,
    doc_type_hint: str | None,
    document_subtype_hint: str | None,
) -> dict[str, Any]:
    """Allow VLM output to fill gaps without replacing trusted PP evidence."""

    primary_meta = (
        primary.get("field_meta") if isinstance(primary.get("field_meta"), dict) else {}
    )
    supplemented_meta = supplemented.setdefault("field_meta", {})
    primary_header = (
        primary.get("header") if isinstance(primary.get("header"), dict) else {}
    )
    supplemented_header = supplemented.setdefault("header", {})
    for field, value in primary_header.items():
        path = f"$.header.{field}"
        if _value_present(value) and _confidence(primary_meta, path) >= 0.75:
            supplemented_header[field] = copy.deepcopy(value)
            if path in primary_meta:
                supplemented_meta[path] = copy.deepcopy(primary_meta[path])

    primary_lines = primary.get("lines") if isinstance(primary.get("lines"), list) else []
    supplemented_lines = (
        supplemented.get("lines") if isinstance(supplemented.get("lines"), list) else []
    )

    def normalized_identity(value: Any) -> str:
        return str(value or "").strip().casefold()

    def matching_line_index(primary_line: dict[str, Any], available: set[int]) -> int | None:
        # Stable business identifiers take precedence over row position.  A VLM
        # may insert or omit a row, so positional merging can silently combine
        # fields from different BOM items.
        has_stable_identity = False
        for field in ("line_id", "product_code"):
            expected = normalized_identity(primary_line.get(field))
            if not expected:
                continue
            has_stable_identity = True
            matches = [
                index
                for index in available
                if isinstance(supplemented_lines[index], dict)
                and normalized_identity(supplemented_lines[index].get(field)) == expected
            ]
            if matches:
                return min(matches)
        if has_stable_identity:
            return None
        expected_line_no = primary_line.get("line_no")
        if expected_line_no is None:
            return None
        matches = [
            index
            for index in available
            if isinstance(supplemented_lines[index], dict)
            and supplemented_lines[index].get("line_no") == expected_line_no
        ]
        return min(matches) if matches else None

    available = set(range(len(supplemented_lines)))
    rejected_description_paths: dict[str, str] = {}
    for index, primary_line in enumerate(primary_lines):
        if not isinstance(primary_line, dict):
            continue
        target_index = matching_line_index(primary_line, available)
        if target_index is None:
            target_index = len(supplemented_lines)
            supplemented_lines.append(copy.deepcopy(primary_line))
            for path, value in primary_meta.items():
                prefix = f"$.lines[{index}]."
                if path.startswith(prefix):
                    supplemented_meta[
                        f"$.lines[{target_index}].{path[len(prefix):]}"
                    ] = copy.deepcopy(value)
            continue
        available.discard(target_index)
        target = supplemented_lines[target_index]
        if not isinstance(target, dict):
            supplemented_lines[target_index] = copy.deepcopy(primary_line)
            continue
        # A VLM description is useful only when it can be traced back to a
        # positioned page region.  Otherwise accepting it would make a missing
        # BOM field look resolved without preserving the evidence contract.
        for field in ("name_raw", "specification_raw"):
            primary_path = f"$.lines[{index}].{field}"
            target_path = f"$.lines[{target_index}].{field}"
            if (
                not _value_present(primary_line.get(field))
                and _value_present(target.get(field))
                and not _has_positioned_field_evidence(
                    supplemented_meta, target_path
                )
            ):
                if field in primary_line:
                    target[field] = copy.deepcopy(primary_line[field])
                else:
                    target.pop(field, None)
                supplemented_meta.pop(target_path, None)
                rejected_description_paths[primary_path] = target_path
        for field, value in primary_line.items():
            primary_path = f"$.lines[{index}].{field}"
            target_path = f"$.lines[{target_index}].{field}"
            if _value_present(value) and _confidence(primary_meta, primary_path) >= 0.75:
                target[field] = copy.deepcopy(value)
                if primary_path in primary_meta:
                    supplemented_meta[target_path] = copy.deepcopy(
                        primary_meta[primary_path]
                    )
                else:
                    supplemented_meta.pop(target_path, None)
    supplemented["lines"] = supplemented_lines

    rejected_required_paths = {
        primary_path: target_path
        for primary_path, target_path in rejected_description_paths.items()
        if primary_path.endswith(".name_raw")
    }
    if rejected_required_paths:
        issues = supplemented.setdefault("validation_issues", [])
        if not isinstance(issues, list):
            issues = []
            supplemented["validation_issues"] = issues
        for issue in primary.get("validation_issues") or []:
            if not isinstance(issue, dict) or str(issue.get("code") or "").upper() != (
                "DRAWING_BOM_DESCRIPTION_MISSING"
            ):
                continue
            primary_issue_paths = [str(path) for path in issue.get("paths") or []]
            if not any(path in rejected_required_paths for path in primary_issue_paths):
                continue
            clone = copy.deepcopy(issue)
            clone["paths"] = [
                rejected_required_paths.get(path, path) for path in primary_issue_paths
            ]
            if not any(
                isinstance(existing, dict)
                and existing.get("code") == clone.get("code")
                and existing.get("paths") == clone.get("paths")
                for existing in issues
            ):
                issues.append(clone)
        supplemented["needs_review"] = True

    if doc_type_hint:
        supplemented["document_type"] = doc_type_hint
    elif primary.get("document_type") not in (None, "", "unknown"):
        supplemented["document_type"] = primary["document_type"]
    if document_subtype_hint:
        supplemented["document_subtype"] = document_subtype_hint
    elif primary.get("document_subtype") not in (None, "", "unknown"):
        supplemented["document_subtype"] = primary["document_subtype"]
    return supplemented


def _is_blocking_evidence_issue(issue: Any) -> bool:
    if not isinstance(issue, dict):
        return False
    code = str(issue.get("code") or "").upper()
    paths = [str(path) for path in issue.get("paths") or []]
    drawing_required_field_missing = (
        code.startswith("DRAWING_")
        and any(token in code for token in ("MISSING", "NOT_FOUND", "EMPTY"))
        and any(
            path == "$.header.title"
            or path == "$.lines"
            or path.startswith("$.lines[")
            for path in paths
        )
    )
    return drawing_required_field_missing or (
        str(issue.get("severity") or "").casefold() == "error"
        and (
            any(path.startswith("$.lines") for path in paths)
            or "MISSING" in code
            or "NOT_FOUND" in code
            or "EMPTY" in code
        )
    )


def _has_blocking_evidence_issue(document: dict[str, Any]) -> bool:
    issues = document.get("validation_issues")
    if not isinstance(issues, list):
        return False
    return any(_is_blocking_evidence_issue(issue) for issue in issues)


def _blocking_evidence_pages(document: dict[str, Any]) -> set[int]:
    """Locate pages for blocking fields, falling back to all pages upstream."""

    issues = document.get("validation_issues")
    field_meta = (
        document.get("field_meta") if isinstance(document.get("field_meta"), dict) else {}
    )
    pages: set[int] = set()

    def add_refs(refs: Any) -> None:
        for ref in refs or []:
            if not isinstance(ref, dict) or ref.get("page") in (None, ""):
                continue
            try:
                pages.add(int(ref["page"]))
            except (TypeError, ValueError):
                continue

    for issue in issues if isinstance(issues, list) else []:
        if not _is_blocking_evidence_issue(issue):
            continue
        add_refs(issue.get("source_refs"))
        for path_value in issue.get("paths") or []:
            path = str(path_value)
            meta = field_meta.get(path)
            if isinstance(meta, dict):
                add_refs(meta.get("source_refs"))
            if path.startswith("$.lines[") and "]." in path:
                line_prefix = path.split("].", 1)[0] + "]."
                for meta_path, sibling_meta in field_meta.items():
                    if str(meta_path).startswith(line_prefix) and isinstance(
                        sibling_meta, dict
                    ):
                        add_refs(sibling_meta.get("source_refs"))
    return pages


def _has_deterministic_drawing_content(document: dict[str, Any]) -> bool:
    if (
        str(document.get("document_type") or "").casefold() != "technical_document"
        or str(document.get("document_subtype") or "").casefold()
        != "approval_drawing"
    ):
        return False
    header = document.get("header") if isinstance(document.get("header"), dict) else {}
    if not all(_value_present(header.get(field)) for field in ("title", "material_number")):
        return False
    lines = document.get("lines") if isinstance(document.get("lines"), list) else []
    if len(lines) < 2:
        return False
    valid_lines = [
        line
        for line in lines
        if isinstance(line, dict)
        and _value_present(line.get("product_code"))
        and _value_present(line.get("quantity"))
    ]
    if len(valid_lines) != len(lines):
        return False
    described = sum(
        _value_present(line.get("name_raw") or line.get("specification_raw"))
        for line in valid_lines
    )
    if described / len(valid_lines) < 0.75:
        return False

    field_meta = (
        document.get("field_meta") if isinstance(document.get("field_meta"), dict) else {}
    )

    def sourced(path: str) -> bool:
        meta = field_meta.get(path)
        if not isinstance(meta, dict) or float(meta.get("confidence", 0.0)) < 0.75:
            return False
        return any(
            _positioned_source_ref(ref) for ref in meta.get("source_refs") or []
        )

    if not all(sourced(path) for path in ("$.header.title", "$.header.material_number")):
        return False
    return all(
        sourced(f"$.lines[{index}].product_code")
        and sourced(f"$.lines[{index}].quantity")
        for index in range(len(valid_lines))
    )


def _business_output_empty(document: dict[str, Any]) -> bool:
    if str(document.get("document_type") or "unknown").casefold() not in {"", "unknown"}:
        return False
    header = document.get("header") if isinstance(document.get("header"), dict) else {}
    header_values = [
        value
        for key, value in header.items()
        if key not in {"candidate_numbers", "date_inferred"}
    ]
    return not any(_value_present(value) for value in header_values) and not bool(
        document.get("lines") or document.get("fields")
    )


def _evidence_has_content(evidence: DocumentEvidence) -> bool:
    return bool(
        evidence.text.strip()
        or any(page.tables or page.markdown.strip() for page in evidence.pages)
    )


def _record_vlm_failure(
    evidence: DocumentEvidence,
    page_numbers: Iterable[int],
    exc: BaseException,
) -> None:
    numbers = sorted({int(number) for number in page_numbers})
    failed = {int(value) for value in evidence.raw.get("vlm_failed_pages", [])}
    failed.update(numbers)
    evidence.raw["vlm_failed_pages"] = sorted(failed)
    failure_types = evidence.raw.setdefault("vlm_failure_types", {})
    for number in numbers:
        failure_types[str(number)] = _safe_error(exc)
    warning = f"paddleocr-vl escalation failed: {_safe_error(exc)}"
    if warning not in evidence.warnings:
        evidence.warnings.append(warning)


def _record_vlm_unavailable(
    evidence: DocumentEvidence,
    page_numbers: Iterable[int],
    *,
    reason: str,
) -> None:
    numbers = sorted({int(number) for number in page_numbers})
    unavailable = {
        int(value) for value in evidence.raw.get("vlm_unavailable_pages", [])
    }
    unavailable.update(numbers)
    evidence.raw["vlm_unavailable_pages"] = sorted(unavailable)
    reasons = evidence.raw.setdefault("vlm_unavailable_reasons", {})
    for number in numbers:
        reasons[str(number)] = reason
    warning = f"paddleocr-vl escalation unavailable: {reason}"
    if warning not in evidence.warnings:
        evidence.warnings.append(warning)


__all__ = [
    "_business_output_empty",
    "_blocking_evidence_pages",
    "_evidence_has_content",
    "_has_blocking_evidence_issue",
    "_has_deterministic_drawing_content",
    "_merge_vlm_supplement",
    "_record_vlm_failure",
    "_record_vlm_unavailable",
    "_safe_error",
]
