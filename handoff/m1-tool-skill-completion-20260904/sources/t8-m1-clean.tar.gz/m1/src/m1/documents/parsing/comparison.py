"""Deterministic parser shadow comparison utilities."""

from __future__ import annotations

import re
import unicodedata
from typing import Any


KEY_HEADER_FIELDS = (
    "order_number",
    "contract_number",
    "date_raw",
    "delivery_date_raw",
    "buyer",
    "seller",
    "supplier",
)


def _normalized(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value))).casefold()


def compare_document_records(baseline: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    """Compare stable business facts without persisting confidential content."""

    baseline_header = baseline.get("header") if isinstance(baseline.get("header"), dict) else {}
    candidate_header = candidate.get("header") if isinstance(candidate.get("header"), dict) else {}
    field_diffs = []
    for field in KEY_HEADER_FIELDS:
        before = baseline_header.get(field)
        after = candidate_header.get(field)
        if _normalized(before) != _normalized(after):
            field_diffs.append({"field": field, "baseline": before, "candidate": after})

    baseline_lines = baseline.get("lines") if isinstance(baseline.get("lines"), list) else []
    candidate_lines = candidate.get("lines") if isinstance(candidate.get("lines"), list) else []
    baseline_cells = sum(
        1
        for line in baseline_lines
        if isinstance(line, dict)
        for value in line.values()
        if value not in (None, "", [], {})
    )
    candidate_cells = sum(
        1
        for line in candidate_lines
        if isinstance(line, dict)
        for value in line.values()
        if value not in (None, "", [], {})
    )
    return {
        "baseline_document_type": baseline.get("document_type"),
        "candidate_document_type": candidate.get("document_type"),
        "baseline_document_subtype": baseline.get("document_subtype"),
        "candidate_document_subtype": candidate.get("document_subtype"),
        "classification_equal": (
            baseline.get("document_type") == candidate.get("document_type")
            and baseline.get("document_subtype") == candidate.get("document_subtype")
        ),
        "header_differences": field_diffs,
        "baseline_line_count": len(baseline_lines),
        "candidate_line_count": len(candidate_lines),
        "line_count_equal": len(baseline_lines) == len(candidate_lines),
        "baseline_nonempty_cells": baseline_cells,
        "candidate_nonempty_cells": candidate_cells,
        "candidate_issue_codes": sorted(
            {
                str(issue.get("code"))
                for issue in candidate.get("validation_issues", [])
                if isinstance(issue, dict) and issue.get("code")
            }
        ),
    }


__all__ = ["KEY_HEADER_FIELDS", "compare_document_records"]
