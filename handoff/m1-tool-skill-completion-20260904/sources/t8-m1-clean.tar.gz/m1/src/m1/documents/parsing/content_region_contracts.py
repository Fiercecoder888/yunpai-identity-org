"""Closed, redacted contracts for governed content-region routing.

The persisted signature deliberately contains no document text, filename,
field value, tenant identifier, task identifier, prompt, schema, or executable
path. Only code-owned semantic tags reach embeddings and selector requests.
Hashes are derived from redacted, allow-listed label identities and are used by
exact replay only.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import unicodedata
from collections.abc import Mapping, Sequence
from enum import StrEnum
from types import MappingProxyType
from typing import Any, Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .semantic_strategy_router import (
    SemanticStrategyId,
    registered_semantic_strategies,
)

CONTENT_REGION_CONTRACT_ID = "m1.content-region"
CONTENT_REGION_CONTRACT_REVISION = "m1.content-region.v2"
CONTENT_REGION_EMBEDDING_SPACE = "m1-content-region-v2"

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_SAFE_TOKEN_RE = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,255}$")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


def normalized_route_token(value: object, *, field_name: str) -> str:
    token = unicodedata.normalize("NFKC", str(value or "")).strip().casefold()
    if _SAFE_TOKEN_RE.fullmatch(token) is None:
        raise ValueError(f"{field_name} must be a stable route token")
    return token


def semantic_label_sha256(value: object) -> str:
    """Return an identity for an already-redacted, allow-listed label token."""

    text = unicodedata.normalize("NFKC", str(value or ""))
    text = " ".join(_CONTROL_RE.sub("", text).strip().casefold().split())[:512]
    if not text:
        raise ValueError("semantic label identities cannot be empty")
    return hashlib.sha256(f"m1-content-label-v2:{text}".encode()).hexdigest()


# Compatibility name for callers that have not yet moved to the v2 spelling.
# The function is safe only for redacted, allow-listed tokens.
semantic_anchor_sha256 = semantic_label_sha256


class ContentRegionSourceFamily(StrEnum):
    MINERU = "mineru"
    PP_STRUCTURE = "pp_structure"
    PADDLEOCR_VL = "paddleocr_vl"
    DOCLING = "docling"
    NATIVE = "native"
    SPREADSHEET = "spreadsheet"
    OTHER = "other"


class ContentRegionKind(StrEnum):
    TITLE = "title"
    SECTION = "section"
    PARAGRAPH = "paragraph"
    LIST = "list"
    TABLE = "table"
    FIGURE = "figure"
    CAPTION = "caption"
    HEADER = "header"
    FOOTER = "footer"
    UNKNOWN = "unknown"


class ContentRegionRole(StrEnum):
    DOCUMENT_TITLE = "document_title"
    SECTION_HEADING = "section_heading"
    BODY_TEXT = "body_text"
    KEY_VALUE_FACTS = "key_value_facts"
    LINE_ITEM_TABLE = "line_item_table"
    SPECIFICATION_TABLE = "specification_table"
    REVISION_TABLE = "revision_table"
    TERMS_AND_CONDITIONS = "terms_and_conditions"
    CONTACT_DETAILS = "contact_details"
    APPROVAL_BLOCK = "approval_block"
    FIGURE_CAPTION = "figure_caption"
    PRODUCT_IMAGE = "product_image"
    ENGINEERING_DIAGRAM = "engineering_diagram"
    OTHER_EVIDENCE = "other_evidence"


class ContentRegionSemanticTag(StrEnum):
    """Closed semantic vocabulary safe for persistence and model routing."""

    DOCUMENT_TITLE = "document_title"
    SECTION_HEADING = "section_heading"
    ORDER_IDENTIFIER = "order_identifier"
    CONTRACT_IDENTIFIER = "contract_identifier"
    PRODUCT_IDENTIFIER = "product_identifier"
    PRODUCT_NAME = "product_name"
    MODEL_IDENTIFIER = "model_identifier"
    MATERIAL_IDENTIFIER = "material_identifier"
    QUANTITY = "quantity"
    UNIT = "unit"
    DELIVERY_DATE = "delivery_date"
    PRICE = "price"
    AMOUNT = "amount"
    PARTY = "party"
    CONTACT = "contact"
    ADDRESS = "address"
    TECHNICAL_PARAMETER = "technical_parameter"
    SPECIFICATION = "specification"
    REVISION = "revision"
    APPROVAL = "approval"
    TERMS = "terms"
    DRAWING = "drawing"
    BOM = "bom"
    INVENTORY = "inventory"
    EQUIPMENT = "equipment"
    MOLD = "mold"
    NOTES = "notes"


class ContentPagePosition(StrEnum):
    SINGLE = "single"
    FIRST = "first"
    MIDDLE = "middle"
    LAST = "last"
    UNKNOWN = "unknown"


class ContentVerticalPosition(StrEnum):
    START = "start"
    MIDDLE = "middle"
    END = "end"
    SPANNING = "spanning"
    UNKNOWN = "unknown"


class ContentAreaBucket(StrEnum):
    TINY = "tiny"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    DOMINANT = "dominant"
    UNKNOWN = "unknown"


class ContentLengthBucket(StrEnum):
    NONE = "none"
    SHORT = "short"
    MEDIUM = "medium"
    LONG = "long"
    VERY_LONG = "very_long"


class ContentCountBucket(StrEnum):
    NONE = "none"
    ONE = "one"
    FEW = "few"
    SEVERAL = "several"
    MANY = "many"


class ContentConfidenceBucket(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"


class ContentNumericDensityBucket(StrEnum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ContentRegionSemanticSketch(BaseModel):
    """Persistable semantic summary containing no source label or value."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.content-region-semantic-sketch.v2"] = (
        "m1.content-region-semantic-sketch.v2"
    )
    semantic_tags: tuple[ContentRegionSemanticTag, ...] = Field(
        default=(), max_length=16
    )
    semantic_label_hashes: tuple[str, ...] = Field(default=(), max_length=16)
    label_count: int = Field(default=0, ge=0, le=64)

    @field_validator("semantic_tags", mode="before")
    @classmethod
    def normalize_tags(cls, value: object) -> tuple[object, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("semantic_tags must be a sequence")
        return tuple(dict.fromkeys(value))

    @field_validator("semantic_label_hashes", mode="before")
    @classmethod
    def normalize_label_hashes(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("semantic_label_hashes must be a sequence")
        normalized: list[str] = []
        for item in value:
            digest = str(item or "").strip().casefold()
            if _SHA256_RE.fullmatch(digest) is None:
                raise ValueError("semantic label identities must be SHA-256 digests")
            normalized.append(digest)
        return tuple(normalized)

    @model_validator(mode="after")
    def validate_counts(self) -> Self:
        if self.label_count < len(self.semantic_label_hashes):
            raise ValueError("label_count cannot be smaller than retained label hashes")
        return self

    def model_tokens(self) -> tuple[str, ...]:
        return tuple(tag.value for tag in self.semantic_tags)


class ContentRegionSignature(BaseModel):
    """Persistable topology plus a closed, redacted semantic sketch."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    contract_id: Literal["m1.content-region"] = CONTENT_REGION_CONTRACT_ID
    contract_revision: Literal["m1.content-region.v2"] = (
        CONTENT_REGION_CONTRACT_REVISION
    )
    source_family: ContentRegionSourceFamily
    region_kind: ContentRegionKind
    page_position: ContentPagePosition = ContentPagePosition.UNKNOWN
    vertical_position: ContentVerticalPosition = ContentVerticalPosition.UNKNOWN
    area_bucket: ContentAreaBucket = ContentAreaBucket.UNKNOWN
    text_length: ContentLengthBucket = ContentLengthBucket.NONE
    line_count: ContentCountBucket = ContentCountBucket.NONE
    table_row_count: ContentCountBucket = ContentCountBucket.NONE
    table_column_count: ContentCountBucket = ContentCountBucket.NONE
    confidence: ContentConfidenceBucket = ContentConfidenceBucket.UNKNOWN
    numeric_density: ContentNumericDensityBucket = ContentNumericDensityBucket.NONE
    neighbor_kinds: tuple[ContentRegionKind, ...] = Field(default=(), max_length=4)
    semantic_sketch: ContentRegionSemanticSketch = Field(
        default_factory=ContentRegionSemanticSketch
    )
    has_coordinates: bool = False
    has_key_value_shape: bool = False
    has_caption_shape: bool = False
    repeated_layout: bool = False

    @field_validator("neighbor_kinds", mode="before")
    @classmethod
    def normalize_neighbor_kinds(cls, value: object) -> tuple[object, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("neighbor_kinds must be a sequence")
        return tuple(value)

    @property
    def has_stable_anchor(self) -> bool:
        return bool(self.semantic_sketch.semantic_label_hashes)

    def exact_fingerprint(self) -> str:
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("ascii")).hexdigest()

    def embedding_text(self) -> str:
        """Return topology plus closed tags; exact-only hashes are omitted."""

        values = self.model_dump(mode="json", exclude={"semantic_sketch"})
        values["semantic_tags"] = "|".join(self.semantic_sketch.model_tokens())
        values["semantic_label_count"] = self.semantic_sketch.label_count
        values["neighbor_kinds"] = "|".join(item.value for item in self.neighbor_kinds)
        return "content_region " + " ".join(
            f"{key}={str(values[key]).casefold()}" for key in sorted(values)
        )

    def model_sketch(self) -> ContentRegionModelSketch:
        return ContentRegionModelSketch(
            source_family=self.source_family,
            region_kind=self.region_kind,
            page_position=self.page_position,
            vertical_position=self.vertical_position,
            area_bucket=self.area_bucket,
            text_length=self.text_length,
            line_count=self.line_count,
            table_row_count=self.table_row_count,
            table_column_count=self.table_column_count,
            confidence=self.confidence,
            numeric_density=self.numeric_density,
            neighbor_kinds=self.neighbor_kinds,
            semantic_tags=self.semantic_sketch.semantic_tags,
            semantic_label_count=self.semantic_sketch.label_count,
            has_coordinates=self.has_coordinates,
            has_key_value_shape=self.has_key_value_shape,
            has_caption_shape=self.has_caption_shape,
            repeated_layout=self.repeated_layout,
        )


class ContentRegionModelSketch(BaseModel):
    """Closed selector input; it cannot carry hashes, labels, or values."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.content-region-model-sketch.v2"] = (
        "m1.content-region-model-sketch.v2"
    )
    source_family: ContentRegionSourceFamily
    region_kind: ContentRegionKind
    page_position: ContentPagePosition
    vertical_position: ContentVerticalPosition
    area_bucket: ContentAreaBucket
    text_length: ContentLengthBucket
    line_count: ContentCountBucket
    table_row_count: ContentCountBucket
    table_column_count: ContentCountBucket
    confidence: ContentConfidenceBucket
    numeric_density: ContentNumericDensityBucket
    neighbor_kinds: tuple[ContentRegionKind, ...] = Field(default=(), max_length=4)
    semantic_tags: tuple[ContentRegionSemanticTag, ...] = Field(
        default=(), max_length=16
    )
    semantic_label_count: int = Field(default=0, ge=0, le=64)
    has_coordinates: bool
    has_key_value_shape: bool
    has_caption_shape: bool
    repeated_layout: bool


class ContentRegionProbe(BaseModel):
    """One source-region reference and its value-free routing signature."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source_ref: str = Field(min_length=1, max_length=1024)
    signature: ContentRegionSignature


class ContentRegionRouteDefinition(BaseModel):
    """One code-owned role and its permitted semantic execution strategies."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    role: ContentRegionRole
    region_kinds: tuple[ContentRegionKind, ...] = Field(min_length=1, max_length=10)
    strategy_ids: tuple[SemanticStrategyId, ...] = Field(min_length=1, max_length=9)

    @model_validator(mode="after")
    def validate_definition(self) -> Self:
        if len(self.region_kinds) != len(set(self.region_kinds)):
            raise ValueError("content region kinds must be unique")
        if len(self.strategy_ids) != len(set(self.strategy_ids)):
            raise ValueError("semantic strategies must be unique")
        registered = registered_semantic_strategies()
        if any(strategy not in registered for strategy in self.strategy_ids):
            raise ValueError("content routes may reference only registered strategies")
        return self


_TEXT_STRATEGIES = (
    SemanticStrategyId.GENERIC,
    SemanticStrategyId.ORDER,
    SemanticStrategyId.INVENTORY,
    SemanticStrategyId.EQUIPMENT,
    SemanticStrategyId.MOLD,
    SemanticStrategyId.PROCUREMENT,
    SemanticStrategyId.TECHNICAL,
    SemanticStrategyId.ARCHIVE,
)
_REGISTERED_CONTENT_REGION_ROUTES = (
    ContentRegionRouteDefinition(
        role=ContentRegionRole.DOCUMENT_TITLE,
        region_kinds=(ContentRegionKind.TITLE, ContentRegionKind.HEADER),
        strategy_ids=_TEXT_STRATEGIES,
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.SECTION_HEADING,
        region_kinds=(ContentRegionKind.SECTION, ContentRegionKind.TITLE),
        strategy_ids=_TEXT_STRATEGIES,
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.BODY_TEXT,
        region_kinds=(ContentRegionKind.PARAGRAPH, ContentRegionKind.LIST),
        strategy_ids=_TEXT_STRATEGIES,
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.KEY_VALUE_FACTS,
        region_kinds=(ContentRegionKind.PARAGRAPH, ContentRegionKind.TABLE),
        strategy_ids=_TEXT_STRATEGIES[:-1],
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.LINE_ITEM_TABLE,
        region_kinds=(ContentRegionKind.TABLE,),
        strategy_ids=(
            SemanticStrategyId.ORDER,
            SemanticStrategyId.INVENTORY,
            SemanticStrategyId.EQUIPMENT,
            SemanticStrategyId.MOLD,
            SemanticStrategyId.PROCUREMENT,
            SemanticStrategyId.GENERIC,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.SPECIFICATION_TABLE,
        region_kinds=(ContentRegionKind.TABLE,),
        strategy_ids=(
            SemanticStrategyId.TECHNICAL,
            SemanticStrategyId.EQUIPMENT,
            SemanticStrategyId.MOLD,
            SemanticStrategyId.GENERIC,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.REVISION_TABLE,
        region_kinds=(ContentRegionKind.TABLE,),
        strategy_ids=(SemanticStrategyId.TECHNICAL, SemanticStrategyId.GENERIC),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.TERMS_AND_CONDITIONS,
        region_kinds=(ContentRegionKind.SECTION, ContentRegionKind.PARAGRAPH),
        strategy_ids=(
            SemanticStrategyId.PROCUREMENT,
            SemanticStrategyId.ORDER,
            SemanticStrategyId.TECHNICAL,
            SemanticStrategyId.GENERIC,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.CONTACT_DETAILS,
        region_kinds=(ContentRegionKind.PARAGRAPH, ContentRegionKind.TABLE),
        strategy_ids=(
            SemanticStrategyId.GENERIC,
            SemanticStrategyId.ORDER,
            SemanticStrategyId.PROCUREMENT,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.APPROVAL_BLOCK,
        region_kinds=(
            ContentRegionKind.PARAGRAPH,
            ContentRegionKind.TABLE,
            ContentRegionKind.FIGURE,
        ),
        strategy_ids=(
            SemanticStrategyId.GENERIC,
            SemanticStrategyId.ORDER,
            SemanticStrategyId.PROCUREMENT,
            SemanticStrategyId.TECHNICAL,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.FIGURE_CAPTION,
        region_kinds=(ContentRegionKind.CAPTION, ContentRegionKind.PARAGRAPH),
        strategy_ids=(
            SemanticStrategyId.VISUAL_GENERIC,
            SemanticStrategyId.TECHNICAL,
            SemanticStrategyId.GENERIC,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.PRODUCT_IMAGE,
        region_kinds=(ContentRegionKind.FIGURE,),
        strategy_ids=(
            SemanticStrategyId.VISUAL_GENERIC,
            SemanticStrategyId.TECHNICAL,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.ENGINEERING_DIAGRAM,
        region_kinds=(ContentRegionKind.FIGURE,),
        strategy_ids=(
            SemanticStrategyId.TECHNICAL,
            SemanticStrategyId.VISUAL_GENERIC,
        ),
    ),
    ContentRegionRouteDefinition(
        role=ContentRegionRole.OTHER_EVIDENCE,
        region_kinds=tuple(ContentRegionKind),
        strategy_ids=(SemanticStrategyId.GENERIC,),
    ),
)


class ContentRegionRouteRegistry:
    """Immutable code registry; storage cannot add roles or strategies."""

    def __init__(self, definitions: Sequence[ContentRegionRouteDefinition]) -> None:
        if not definitions:
            raise ValueError("at least one content-region route is required")
        by_role: dict[ContentRegionRole, ContentRegionRouteDefinition] = {}
        for definition in definitions:
            if definition.role in by_role:
                raise ValueError(f"duplicate content-region role: {definition.role}")
            by_role[definition.role] = definition
        self._by_role = MappingProxyType(by_role)

    def supports(
        self,
        *,
        region_kind: ContentRegionKind,
        role: ContentRegionRole,
        strategy_id: SemanticStrategyId,
    ) -> bool:
        definition = self._by_role.get(role)
        return bool(
            definition
            and region_kind in definition.region_kinds
            and strategy_id in definition.strategy_ids
            and strategy_id in registered_semantic_strategies()
        )

    def pairs(
        self,
        region_kind: ContentRegionKind,
        *,
        allowed_strategy_ids: Sequence[SemanticStrategyId] | None = None,
    ) -> tuple[tuple[ContentRegionRole, SemanticStrategyId], ...]:
        allowed = (
            frozenset(allowed_strategy_ids)
            if allowed_strategy_ids is not None
            else frozenset(registered_semantic_strategies())
        )
        return tuple(
            (definition.role, strategy_id)
            for definition in self._by_role.values()
            if region_kind in definition.region_kinds
            for strategy_id in definition.strategy_ids
            if strategy_id in allowed
        )

    @property
    def definitions(self) -> Mapping[ContentRegionRole, ContentRegionRouteDefinition]:
        return self._by_role


def registered_content_region_routes() -> ContentRegionRouteRegistry:
    return ContentRegionRouteRegistry(_REGISTERED_CONTENT_REGION_ROUTES)


class ContentRegionProfile(BaseModel):
    """Store-owned profile; only reviewed active profiles are executable."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str = Field(min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    status: Literal["candidate", "active", "deprecated", "rejected"]
    contract_id: Literal["m1.content-region"] = CONTENT_REGION_CONTRACT_ID
    contract_revision: Literal["m1.content-region.v2"] = (
        CONTENT_REGION_CONTRACT_REVISION
    )
    embedding_space: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: ContentRegionSignature
    role: ContentRegionRole | None = None
    strategy_id: SemanticStrategyId | None = None
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    reviewed: bool = False
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)

    @field_validator("profile_id", "profile_key", "embedding_space")
    @classmethod
    def validate_tokens(cls, value: str, info) -> str:
        return normalized_route_token(value, field_name=info.field_name)

    @field_validator("embedding")
    @classmethod
    def validate_embedding(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        result = tuple(float(item) for item in value)
        if not result or not all(math.isfinite(item) for item in result):
            raise ValueError("content-region embeddings must be finite")
        return result

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("profile fingerprint does not match its signature")
        if self.contract_id != self.signature.contract_id or (
            self.contract_revision != self.signature.contract_revision
        ):
            raise ValueError("profile and signature contracts do not match")
        if (self.role is None) != (self.strategy_id is None):
            raise ValueError("content role and semantic strategy are an atomic pair")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("profile observation counters are inconsistent")
        if self.status == "active" and (
            not self.reviewed
            or self.role is None
            or self.strategy_id is None
            or self.success_count < 3
            or self.failure_count
        ):
            raise ValueError("active content routes require reviewed success evidence")
        return self


class ContentRegionProfileMatch(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile: ContentRegionProfile
    vector_similarity: float = Field(ge=-1.0, le=1.0)


class ContentRegionCandidateProposal(BaseModel):
    """Value-free candidate request that storage must not activate implicitly."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    contract_id: Literal["m1.content-region"] = CONTENT_REGION_CONTRACT_ID
    contract_revision: Literal["m1.content-region.v2"] = (
        CONTENT_REGION_CONTRACT_REVISION
    )
    embedding_space: str = Field(min_length=1, max_length=256)
    signature: ContentRegionSignature
    suggested_role: ContentRegionRole | None = None
    suggested_strategy_id: SemanticStrategyId | None = None
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    created_by: str = Field(
        default="content-region-router", min_length=1, max_length=256
    )

    @field_validator("profile_key", "embedding_space")
    @classmethod
    def validate_tokens(cls, value: str, info) -> str:
        return normalized_route_token(value, field_name=info.field_name)

    @model_validator(mode="after")
    def validate_candidate(self) -> Self:
        if (self.suggested_role is None) != (self.suggested_strategy_id is None):
            raise ValueError("candidate role and strategy are an atomic pair")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self


class ContentRegionExecutionObservation(BaseModel):
    """Reviewed replay evidence used by explicit profile activation."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: Literal["success", "failure"]
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)

    @field_validator(
        "exact_fingerprint", "task_reference_hash", "review_note_sha256", mode="before"
    )
    @classmethod
    def normalize_hashes(cls, value: object) -> str:
        return str(value or "").strip().casefold()

    @field_validator("error_code", mode="before")
    @classmethod
    def normalize_error_code(cls, value: object) -> str:
        normalized = str(value or "").strip().casefold()
        if normalized and _SAFE_TOKEN_RE.fullmatch(normalized) is None:
            raise ValueError("error_code must be a stable route token")
        return normalized

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome == "success":
            if not self.validation_passed or not self.reviewed_by.strip():
                raise ValueError(
                    "successful content-region samples require reviewed validation"
                )
            if _SHA256_RE.fullmatch(self.review_note_sha256) is None:
                raise ValueError(
                    "successful content-region samples require a review-note hash"
                )
        elif not self.error_code:
            raise ValueError("failed content-region samples require an error code")
        return self


class ContentRegionStore(Protocol):
    async def get_active_content_region_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
    ) -> ContentRegionProfile | None: ...

    async def find_active_content_region_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
        embedding_model: str,
        embedding_dimensions: int,
        region_kind: ContentRegionKind,
        limit: int,
    ) -> Sequence[ContentRegionProfileMatch]: ...

    async def create_content_region_candidate(
        self, proposal: ContentRegionCandidateProposal
    ) -> ContentRegionProfile: ...

    async def record_content_region_execution_observation(
        self, observation: ContentRegionExecutionObservation
    ) -> object: ...


class ContentRegionEmbeddingProvider(Protocol):
    space: str
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class ContentRegionRankedCandidate(BaseModel):
    """Internal ranked match. Its opaque profile ID is hidden from the model."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str
    role: ContentRegionRole
    strategy_id: SemanticStrategyId
    vector_similarity: float = Field(ge=-1.0, le=1.0)
    topology_similarity: float = Field(ge=0.0, le=1.0)
    review_success_rate: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class ContentRegionCandidateOption(BaseModel):
    """Model-safe active profile projection addressed only by list index."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    candidate_index: int = Field(ge=0, le=4)
    role: ContentRegionRole
    strategy_id: SemanticStrategyId
    vector_similarity: float = Field(ge=-1.0, le=1.0)
    topology_similarity: float = Field(ge=0.0, le=1.0)
    review_success_rate: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class ContentRegionRegisteredRouteOption(BaseModel):
    """One role/strategy pair from the immutable process-local registry."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    route_index: int = Field(ge=0, le=63)
    role: ContentRegionRole
    strategy_id: SemanticStrategyId


class ContentRegionSelectionRequest(BaseModel):
    """Bounded payload containing only closed tags and authorized options."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.content-region-selection.v2"] = (
        "m1.content-region-selection.v2"
    )
    sketch: ContentRegionModelSketch
    candidates: tuple[ContentRegionCandidateOption, ...] = Field(max_length=5)
    routes: tuple[ContentRegionRegisteredRouteOption, ...] = Field(max_length=64)

    @model_validator(mode="after")
    def validate_indices(self) -> Self:
        if [item.candidate_index for item in self.candidates] != list(
            range(len(self.candidates))
        ):
            raise ValueError("candidate indices must be consecutive from zero")
        if [item.route_index for item in self.routes] != list(range(len(self.routes))):
            raise ValueError("route indices must be consecutive from zero")
        return self


ContentRegionModelAction = Literal[
    "reuse_active",
    "propose_registered",
    "new_candidate",
    "review",
]


class ContentRegionModelChoice(BaseModel):
    """Closed output: a model cannot emit a role, strategy, schema, or prompt."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: ContentRegionModelAction
    candidate_index: int | None = Field(default=None, ge=0, le=4)
    route_index: int | None = Field(default=None, ge=0, le=63)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_choice(self) -> Self:
        if self.action == "reuse_active":
            if self.candidate_index is None or self.route_index is not None:
                raise ValueError("reuse_active requires only candidate_index")
        elif self.action == "propose_registered":
            if self.route_index is None or self.candidate_index is not None:
                raise ValueError("propose_registered requires only route_index")
        elif self.candidate_index is not None or self.route_index is not None:
            raise ValueError("review and new_candidate cannot include an index")
        return self


class ContentRegionSelector(Protocol):
    async def select(
        self, request: ContentRegionSelectionRequest
    ) -> ContentRegionModelChoice | Mapping[str, Any]: ...


class ContentRegionSelectorFactory(Protocol):
    """Bind ephemeral source content outside the persisted/request contracts."""

    def bind(
        self,
        *,
        region_text: str | None,
        table_headers: Sequence[str],
    ) -> ContentRegionSelector: ...


__all__ = [
    "CONTENT_REGION_CONTRACT_ID",
    "CONTENT_REGION_CONTRACT_REVISION",
    "CONTENT_REGION_EMBEDDING_SPACE",
    "ContentAreaBucket",
    "ContentConfidenceBucket",
    "ContentCountBucket",
    "ContentLengthBucket",
    "ContentNumericDensityBucket",
    "ContentPagePosition",
    "ContentRegionCandidateOption",
    "ContentRegionCandidateProposal",
    "ContentRegionEmbeddingProvider",
    "ContentRegionExecutionObservation",
    "ContentRegionKind",
    "ContentRegionModelChoice",
    "ContentRegionModelSketch",
    "ContentRegionProbe",
    "ContentRegionProfile",
    "ContentRegionProfileMatch",
    "ContentRegionRankedCandidate",
    "ContentRegionRegisteredRouteOption",
    "ContentRegionRole",
    "ContentRegionRouteDefinition",
    "ContentRegionRouteRegistry",
    "ContentRegionSelectionRequest",
    "ContentRegionSelector",
    "ContentRegionSelectorFactory",
    "ContentRegionSemanticSketch",
    "ContentRegionSemanticTag",
    "ContentRegionSignature",
    "ContentRegionSourceFamily",
    "ContentRegionStore",
    "ContentVerticalPosition",
    "normalized_route_token",
    "registered_content_region_routes",
    "semantic_anchor_sha256",
    "semantic_label_sha256",
]
