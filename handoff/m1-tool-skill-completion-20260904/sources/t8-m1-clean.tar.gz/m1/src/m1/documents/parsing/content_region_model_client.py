"""Prompted-output adapters for governed content-region routing."""

from __future__ import annotations

import json
from collections.abc import Sequence
from typing import Any, Protocol

from .content_region_contracts import (
    CONTENT_REGION_EMBEDDING_SPACE,
    ContentRegionEmbeddingProvider,
    ContentRegionModelChoice,
    ContentRegionSelectionRequest,
)


class ContentRegionStructuredClient(Protocol):
    async def run(
        self,
        output_type: type[ContentRegionModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> Any: ...


class TextEmbeddingClient(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class ContentRegionEmbeddingAdapter(ContentRegionEmbeddingProvider):
    """Attach the immutable content-region embedding-space identity."""

    def __init__(self, client: TextEmbeddingClient) -> None:
        self._client = client
        self.space = CONTENT_REGION_EMBEDDING_SPACE
        self.model = str(client.model).strip()
        self.dimensions = int(client.dimensions)
        if not self.model or self.dimensions < 1:
            raise ValueError("content-region embedding client identity is invalid")

    async def embed_texts(
        self,
        texts: Sequence[str],
    ) -> Sequence[Sequence[float]]:
        return await self._client.embed_texts(texts)


class PydanticContentRegionSelector:
    """Select only server-issued candidate or registered-route indexes."""

    _INSTRUCTIONS = (
        "Choose a semantic content-region route using only the supplied "
        "value-free sketch and closed indexes. reuse_active may select only a "
        "candidate_index; propose_registered may select only a route_index. "
        "Never emit source text, business values, identifiers, tenant or TaskID "
        "data, roles, strategies, schemas, prompts, paths, SQL, or code. Choose "
        "review or new_candidate whenever the supplied evidence is insufficient."
    )

    def __init__(self, client: ContentRegionStructuredClient) -> None:
        self._client = client

    async def select(
        self,
        request: ContentRegionSelectionRequest,
    ) -> ContentRegionModelChoice:
        run = await self._client.run(
            ContentRegionModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=json.dumps(
                request.model_dump(mode="json"),
                ensure_ascii=True,
                sort_keys=True,
                separators=(",", ":"),
            ),
            request_limit=1,
        )
        return ContentRegionModelChoice.model_validate(run.output, strict=True)


__all__ = [
    "ContentRegionEmbeddingAdapter",
    "ContentRegionStructuredClient",
    "PydanticContentRegionSelector",
    "TextEmbeddingClient",
]
