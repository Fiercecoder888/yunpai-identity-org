"""Provider-neutral adapter for redacted content-region probes."""

from __future__ import annotations

import re
import unicodedata
from collections import Counter
from dataclasses import dataclass

from .content_region_contracts import (
    ContentRegionKind,
    ContentRegionProbe,
    ContentRegionSemanticSketch,
    ContentRegionSemanticTag,
    ContentRegionSignature,
    semantic_label_sha256,
)
from .content_region_routing import (
    _confidence_bucket,
    _count_bucket,
    _geometry_buckets,
    _key_value_labels,
    _length_bucket,
    _numeric_density,
    _page_position,
    _region_kind,
    _source_family,
)
from .evidence import DocumentEvidence, EvidenceBBox, EvidencePage, EvidenceTable

_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_EMAIL_RE = re.compile(r"\b[^\s@]+@[^\s@]+\.[^\s@]+\b", re.IGNORECASE)
_URL_RE = re.compile(r"(?:https?://|www\.)\S+", re.IGNORECASE)
_DATE_RE = re.compile(r"(?:19|20)\d{2}[年./-]\d{1,2}(?:[月./-]\d{1,2}日?)?")
_LONG_NUMBER_RE = re.compile(r"(?<!\w)\d{4,}(?!\w)")
_BUSINESS_ID_RE = re.compile(
    r"\b(?=[a-z0-9._/-]{4,}\b)(?=[a-z0-9._/-]*[a-z])(?=[a-z0-9._/-]*\d)"
    r"[a-z0-9._/-]+\b",
    re.IGNORECASE,
)
_MONEY_RE = re.compile(r"(?:[¥￥$€]|人民币|美元)\s*\d[\d,.]*|\d[\d,.]*\s*元")
_PHONE_RE = re.compile(
    r"(?<!\d)(?:\+?86[- ]?)?1\d{10}(?!\d)|(?<!\d)\d{3,4}[- ]\d{6,8}(?!\d)"
)
_ORG_RE = re.compile(
    r"[\u3400-\u9fffA-Za-z]{2,}(?:股份有限公司|有限责任公司|有限公司|集团|公司|工厂|厂)"
)
_WHITESPACE_RE = re.compile(r"\s+")


_TAG_PATTERNS: tuple[
    tuple[ContentRegionSemanticTag, tuple[re.Pattern[str], ...]], ...
] = (
    (
        ContentRegionSemanticTag.DOCUMENT_TITLE,
        (re.compile(r"文档标题|文件标题|标题|title", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.SECTION_HEADING,
        (re.compile(r"章节|小节|section|heading", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.ORDER_IDENTIFIER,
        (
            re.compile(
                r"订单号|订单编号|下单编号|order\s*(?:id|no|number)", re.IGNORECASE
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.CONTRACT_IDENTIFIER,
        (re.compile(r"合同号|合同编号|contract\s*(?:id|no|number)", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.PRODUCT_IDENTIFIER,
        (
            re.compile(
                r"产品(?:编码|编号|料号)|物料(?:编码|编号|号)|品号|sku|product\s*(?:id|code|no)",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.PRODUCT_NAME,
        (
            re.compile(
                r"产品名称|物料名称|货品名称|品名|product\s*name|item\s*name",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.MODEL_IDENTIFIER,
        (re.compile(r"型号|机型|model(?:\s*(?:id|no))?", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.MATERIAL_IDENTIFIER,
        (re.compile(r"材料(?:编码|编号|牌号|名称)?|材质|material", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.QUANTITY,
        (re.compile(r"数量|订购量|需求量|库存量|qty|quantity", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.UNIT,
        (re.compile(r"单位|计量单位|unit|uom", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.DELIVERY_DATE,
        (
            re.compile(
                r"交货日期|交期|交付日期|到货日期|delivery\s*date|due\s*date",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.PRICE,
        (re.compile(r"单价|含税价|price|unit\s*price", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.AMOUNT,
        (re.compile(r"金额|总价|合计|小计|amount|total", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.PARTY,
        (
            re.compile(
                r"甲方|乙方|买方|卖方|客户|供应商|采购方|供货方|buyer|seller|supplier|customer",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.CONTACT,
        (
            re.compile(
                r"联系人|联系电话|手机|电话|邮箱|email|contact|phone", re.IGNORECASE
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.ADDRESS,
        (re.compile(r"地址|收货地址|送货地址|address", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.TECHNICAL_PARAMETER,
        (
            re.compile(
                r"技术参数|参数|性能|公差|尺寸|直径|长度|宽度|高度|parameter|tolerance|dimension",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.SPECIFICATION,
        (re.compile(r"规格|规格书|承认书|技术要求|specification|spec", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.REVISION,
        (re.compile(r"版本|版次|修订|变更|revision|version|rev", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.APPROVAL,
        (
            re.compile(
                r"审批|审核|批准|签字|签章|确认|approval|approved|signature",
                re.IGNORECASE,
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.TERMS,
        (
            re.compile(
                r"条款|约定|付款方式|交货方式|质保|违约|terms|conditions", re.IGNORECASE
            ),
        ),
    ),
    (
        ContentRegionSemanticTag.DRAWING,
        (re.compile(r"图纸|工程图|示意图|视图|drawing|diagram", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.BOM,
        (re.compile(r"物料清单|零件清单|bom", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.INVENTORY,
        (re.compile(r"库存|仓库|库位|stock|inventory|warehouse", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.EQUIPMENT,
        (re.compile(r"设备|机器|机台|equipment|machine", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.MOLD,
        (re.compile(r"模具|模号|模号编号|mould|mold", re.IGNORECASE),),
    ),
    (
        ContentRegionSemanticTag.NOTES,
        (re.compile(r"备注|说明|注释|note|remark|description", re.IGNORECASE),),
    ),
)


def _redacted_label_text(value: object) -> str:
    """Normalize one transient label and erase common business-value shapes."""

    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _CONTROL_RE.sub(" ", text).casefold()
    for pattern in (
        _EMAIL_RE,
        _URL_RE,
        _DATE_RE,
        _PHONE_RE,
        _MONEY_RE,
        _BUSINESS_ID_RE,
        _LONG_NUMBER_RE,
        _ORG_RE,
    ):
        text = pattern.sub(" ", text)
    # Any remaining digit is unnecessary for the closed semantic vocabulary.
    text = re.sub(r"\d", " ", text)
    return _WHITESPACE_RE.sub(" ", text).strip()[:256]


def _semantic_tags(value: object) -> tuple[ContentRegionSemanticTag, ...]:
    redacted = _redacted_label_text(value)
    if not redacted:
        return ()
    return tuple(
        tag
        for tag, patterns in _TAG_PATTERNS
        if any(pattern.search(redacted) is not None for pattern in patterns)
    )


def _table_semantic_labels(table: EvidenceTable) -> tuple[object, ...]:
    """Choose the strongest semantic header among the first three non-empty rows."""

    candidates: list[tuple[int, int, tuple[object, ...]]] = []
    for row_index, row in enumerate(table.rows[:3]):
        values = tuple(value for value in row if str(value or "").strip())
        mapped = sum(bool(_semantic_tags(value)) for value in values)
        if mapped:
            # Prefer a row with more mapped cells, then the earliest row.
            candidates.append((mapped, -row_index, values))
    if not candidates:
        return ()
    return max(candidates, key=lambda item: (item[0], item[1]))[2]


def _semantic_labels(
    *,
    kind: ContentRegionKind,
    text: str,
    table: EvidenceTable | None,
) -> tuple[object, ...]:
    if table is not None:
        return _table_semantic_labels(table)
    if kind in {
        ContentRegionKind.TITLE,
        ContentRegionKind.SECTION,
        ContentRegionKind.CAPTION,
        ContentRegionKind.HEADER,
        ContentRegionKind.FOOTER,
    }:
        return (text,) if text.strip() else ()
    if kind in {ContentRegionKind.PARAGRAPH, ContentRegionKind.LIST}:
        return tuple(_key_value_labels(text))
    return ()


def build_content_region_semantic_sketch(
    *,
    kind: ContentRegionKind,
    text: str,
    table: EvidenceTable | None,
) -> ContentRegionSemanticSketch:
    """Build closed semantic tags without retaining source labels or values."""

    semantic_tags: list[ContentRegionSemanticTag] = []
    hashes: list[str] = []
    retained_labels = 0
    if kind is ContentRegionKind.TITLE:
        semantic_tags.append(ContentRegionSemanticTag.DOCUMENT_TITLE)
    elif kind is ContentRegionKind.SECTION:
        semantic_tags.append(ContentRegionSemanticTag.SECTION_HEADING)

    for label in _semantic_labels(kind=kind, text=text, table=table):
        tags = _semantic_tags(label)
        if not tags:
            continue
        retained_labels += 1
        for tag in tags:
            if tag not in semantic_tags:
                semantic_tags.append(tag)
        # Hash only the safe closed identity, never the original or redacted text.
        hashes.append(semantic_label_sha256("|".join(tag.value for tag in tags)))

    return ContentRegionSemanticSketch(
        semantic_tags=tuple(semantic_tags[:16]),
        semantic_label_hashes=tuple(hashes[:16]),
        label_count=min(retained_labels, 64),
    )


@dataclass(frozen=True, slots=True)
class _Region:
    page: EvidencePage
    page_index: int
    order: int
    source_ref: str
    kind: ContentRegionKind
    text: str
    bbox: EvidenceBBox | None
    confidence: float | None
    table: EvidenceTable | None = None


def _page_regions(page: EvidencePage, page_index: int) -> tuple[_Region, ...]:
    regions: list[_Region] = []
    has_tables = bool(page.tables)
    for block in page.blocks:
        kind = _region_kind(block.kind)
        if has_tables and kind is ContentRegionKind.TABLE:
            continue
        regions.append(
            _Region(
                page=page,
                page_index=page_index,
                order=int(block.order),
                source_ref=f"page:{page.page_number}/block:{block.block_id}",
                kind=kind,
                text=block.text,
                bbox=block.bbox,
                confidence=block.confidence,
            )
        )
    for table_index, table in enumerate(page.tables):
        order = getattr(table, "mineru_item_index", None)
        if not isinstance(order, int):
            order = 10_000 + table_index
        text = "\n".join(
            " | ".join(str(value or "") for value in row) for row in table.rows
        )
        regions.append(
            _Region(
                page=page,
                page_index=page_index,
                order=order,
                source_ref=f"page:{page.page_number}/table:{table.table_id}",
                kind=ContentRegionKind.TABLE,
                text=text,
                bbox=table.bbox,
                confidence=table.confidence,
                table=table,
            )
        )
    return tuple(sorted(regions, key=lambda item: (item.order, item.source_ref)))


def build_content_region_probes(
    evidence: DocumentEvidence,
) -> tuple[ContentRegionProbe, ...]:
    """Adapt MinerU or generic evidence without retaining source-region text."""

    pages = tuple(
        _page_regions(page, page_index)
        for page_index, page in enumerate(evidence.pages)
    )
    layout_counts: Counter[tuple[ContentRegionKind, object, object]] = Counter()
    for regions in pages:
        for region in regions:
            vertical, area = _geometry_buckets(region.bbox, region.page)
            layout_counts[(region.kind, vertical, area)] += 1

    probes: list[ContentRegionProbe] = []
    source_family = _source_family(evidence.backend)
    for page_regions in pages:
        for index, region in enumerate(page_regions):
            vertical, area = _geometry_buckets(region.bbox, region.page)
            neighbors = tuple(
                page_regions[position].kind
                for position in (index - 1, index + 1)
                if 0 <= position < len(page_regions)
            )
            rows = len(region.table.rows) if region.table is not None else 0
            columns = (
                max((len(row) for row in region.table.rows), default=0)
                if region.table is not None
                else 0
            )
            key_value_labels = _key_value_labels(region.text)
            signature = ContentRegionSignature(
                source_family=source_family,
                region_kind=region.kind,
                page_position=_page_position(region.page_index, len(evidence.pages)),
                vertical_position=vertical,
                area_bucket=area,
                text_length=_length_bucket(len(region.text.strip())),
                line_count=_count_bucket(
                    len([line for line in region.text.splitlines() if line.strip()])
                ),
                table_row_count=_count_bucket(rows),
                table_column_count=_count_bucket(columns),
                confidence=_confidence_bucket(region.confidence),
                numeric_density=_numeric_density(region.text),
                neighbor_kinds=neighbors,
                semantic_sketch=build_content_region_semantic_sketch(
                    kind=region.kind,
                    text=region.text,
                    table=region.table,
                ),
                has_coordinates=region.bbox is not None,
                has_key_value_shape=bool(key_value_labels),
                has_caption_shape=(
                    region.kind is ContentRegionKind.CAPTION
                    or (
                        region.kind is ContentRegionKind.FIGURE
                        and bool(region.text.strip())
                    )
                ),
                repeated_layout=layout_counts[(region.kind, vertical, area)] > 1,
            )
            probes.append(
                ContentRegionProbe(source_ref=region.source_ref, signature=signature)
            )
    return tuple(probes)


__all__ = [
    "build_content_region_probes",
    "build_content_region_semantic_sketch",
]
