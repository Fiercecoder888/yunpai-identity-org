"""Governed routing for semantic regions in provider-neutral evidence.

Exact and vector retrieval may execute only reviewed ``active`` profiles.  A
small model is an optional closed-set selector: it addresses server-generated
indices and cannot emit roles, semantic strategies, schemas, prompts, paths,
or code.  Every previously unseen pattern remains an inactive candidate.
"""

from __future__ import annotations

import math
import re
from collections.abc import Sequence
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from .content_region_contracts import (
    CONTENT_REGION_CONTRACT_ID,
    CONTENT_REGION_CONTRACT_REVISION,
    CONTENT_REGION_EMBEDDING_SPACE,
    ContentAreaBucket,
    ContentConfidenceBucket,
    ContentCountBucket,
    ContentLengthBucket,
    ContentNumericDensityBucket,
    ContentPagePosition,
    ContentRegionCandidateOption,
    ContentRegionCandidateProposal,
    ContentRegionEmbeddingProvider,
    ContentRegionKind,
    ContentRegionModelChoice,
    ContentRegionProbe,
    ContentRegionProfile,
    ContentRegionProfileMatch,
    ContentRegionRankedCandidate,
    ContentRegionRegisteredRouteOption,
    ContentRegionRole,
    ContentRegionRouteRegistry,
    ContentRegionSelectionRequest,
    ContentRegionSelector,
    ContentRegionSignature,
    ContentRegionSourceFamily,
    ContentRegionStore,
    ContentVerticalPosition,
    normalized_route_token,
    registered_content_region_routes,
)
from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .evidence import EvidenceBBox, EvidencePage
from .semantic_strategy_router import (
    SemanticStrategyId,
    registered_semantic_strategies,
)

_KEY_VALUE_RE = re.compile(r"^\s*([^:：\n]{1,96})\s*[:：]")
_DIGIT_RE = re.compile(r"\d")
_TEXTUAL_RE = re.compile(r"[0-9A-Za-z\u3400-\u9fff]")


def _source_family(backend: str) -> ContentRegionSourceFamily:
    token = str(backend or "").strip().casefold().replace("-", "_")
    if "mineru" in token:
        return ContentRegionSourceFamily.MINERU
    if "structure" in token:
        return ContentRegionSourceFamily.PP_STRUCTURE
    if "paddleocr_vl" in token or "paddleocrvl" in token:
        return ContentRegionSourceFamily.PADDLEOCR_VL
    if "docling" in token:
        return ContentRegionSourceFamily.DOCLING
    if "spreadsheet" in token or "openpyxl" in token:
        return ContentRegionSourceFamily.SPREADSHEET
    if "native" in token or "text_layer" in token:
        return ContentRegionSourceFamily.NATIVE
    return ContentRegionSourceFamily.OTHER


def _region_kind(value: str) -> ContentRegionKind:
    token = str(value or "").strip().casefold().replace("-", "_")
    if token in {"title", "document_title"}:
        return ContentRegionKind.TITLE
    if token in {"section", "section_header", "section_heading", "heading"}:
        return ContentRegionKind.SECTION
    if token in {"paragraph", "text", "plain_text", "formula_text"}:
        return ContentRegionKind.PARAGRAPH
    if token in {"list", "list_item", "bullet", "ordered_list"}:
        return ContentRegionKind.LIST
    if token in {"table", "table_text"}:
        return ContentRegionKind.TABLE
    if token in {"image", "figure", "chart", "diagram", "seal", "stamp"}:
        return ContentRegionKind.FIGURE
    if token in {"caption", "figure_caption", "table_caption"}:
        return ContentRegionKind.CAPTION
    if token in {"header", "page_header"}:
        return ContentRegionKind.HEADER
    if token in {"footer", "page_footer", "footnote"}:
        return ContentRegionKind.FOOTER
    return ContentRegionKind.UNKNOWN


def _count_bucket(value: int) -> ContentCountBucket:
    if value <= 0:
        return ContentCountBucket.NONE
    if value == 1:
        return ContentCountBucket.ONE
    if value <= 4:
        return ContentCountBucket.FEW
    if value <= 20:
        return ContentCountBucket.SEVERAL
    return ContentCountBucket.MANY


def _length_bucket(value: int) -> ContentLengthBucket:
    if value <= 0:
        return ContentLengthBucket.NONE
    if value <= 80:
        return ContentLengthBucket.SHORT
    if value <= 800:
        return ContentLengthBucket.MEDIUM
    if value <= 4_000:
        return ContentLengthBucket.LONG
    return ContentLengthBucket.VERY_LONG


def _confidence_bucket(value: float | None) -> ContentConfidenceBucket:
    if value is None:
        return ContentConfidenceBucket.UNKNOWN
    if value >= 0.85:
        return ContentConfidenceBucket.HIGH
    if value >= 0.65:
        return ContentConfidenceBucket.MEDIUM
    return ContentConfidenceBucket.LOW


def _numeric_density(text: str) -> ContentNumericDensityBucket:
    denominator = len(_TEXTUAL_RE.findall(text))
    if denominator == 0:
        return ContentNumericDensityBucket.NONE
    ratio = len(_DIGIT_RE.findall(text)) / denominator
    if ratio == 0:
        return ContentNumericDensityBucket.NONE
    if ratio < 0.15:
        return ContentNumericDensityBucket.LOW
    if ratio < 0.45:
        return ContentNumericDensityBucket.MEDIUM
    return ContentNumericDensityBucket.HIGH


def _page_position(index: int, count: int) -> ContentPagePosition:
    if count <= 0:
        return ContentPagePosition.UNKNOWN
    if count == 1:
        return ContentPagePosition.SINGLE
    if index == 0:
        return ContentPagePosition.FIRST
    if index == count - 1:
        return ContentPagePosition.LAST
    return ContentPagePosition.MIDDLE


def _normalized_box(
    bbox: EvidenceBBox | None, page: EvidencePage
) -> tuple[float, float, float, float] | None:
    if bbox is None:
        return None
    if bbox.coordinate_space == "normalized":
        values = (bbox.x0, bbox.y0, bbox.x1, bbox.y1)
    else:
        values = (
            bbox.x0 / max(page.width, 1.0),
            bbox.y0 / max(page.height, 1.0),
            bbox.x1 / max(page.width, 1.0),
            bbox.y1 / max(page.height, 1.0),
        )
    x0, y0, x1, y1 = (max(0.0, min(1.0, float(item))) for item in values)
    if x1 < x0 or y1 < y0:
        return None
    return x0, y0, x1, y1


def _geometry_buckets(
    bbox: EvidenceBBox | None, page: EvidencePage
) -> tuple[ContentVerticalPosition, ContentAreaBucket]:
    normalized = _normalized_box(bbox, page)
    if normalized is None:
        return ContentVerticalPosition.UNKNOWN, ContentAreaBucket.UNKNOWN
    x0, y0, x1, y1 = normalized
    height = y1 - y0
    area = max(0.0, x1 - x0) * max(0.0, height)
    if height >= 0.65:
        vertical = ContentVerticalPosition.SPANNING
    elif (y0 + y1) / 2 <= 0.28:
        vertical = ContentVerticalPosition.START
    elif (y0 + y1) / 2 >= 0.72:
        vertical = ContentVerticalPosition.END
    else:
        vertical = ContentVerticalPosition.MIDDLE
    if area <= 0.01:
        area_bucket = ContentAreaBucket.TINY
    elif area <= 0.06:
        area_bucket = ContentAreaBucket.SMALL
    elif area <= 0.22:
        area_bucket = ContentAreaBucket.MEDIUM
    elif area <= 0.62:
        area_bucket = ContentAreaBucket.LARGE
    else:
        area_bucket = ContentAreaBucket.DOMINANT
    return vertical, area_bucket


def _key_value_labels(text: str) -> tuple[str, ...]:
    return tuple(
        match.group(1).strip()
        for line in text.splitlines()
        if (match := _KEY_VALUE_RE.match(line)) is not None
    )[:16]


def content_region_topology_similarity(
    first: ContentRegionSignature,
    second: ContentRegionSignature,
) -> float:
    """Compare only value-free topology; different region kinds are incompatible."""

    if (
        first.contract_id != second.contract_id
        or first.contract_revision != second.contract_revision
        or first.region_kind is not second.region_kind
    ):
        return 0.0
    weighted_fields: tuple[tuple[str, float], ...] = (
        ("source_family", 0.05),
        ("page_position", 0.05),
        ("vertical_position", 0.10),
        ("area_bucket", 0.08),
        ("text_length", 0.08),
        ("line_count", 0.06),
        ("table_row_count", 0.07),
        ("table_column_count", 0.07),
        ("confidence", 0.04),
        ("numeric_density", 0.06),
        ("has_coordinates", 0.02),
        ("has_key_value_shape", 0.08),
        ("has_caption_shape", 0.04),
        ("repeated_layout", 0.04),
    )
    score = sum(
        weight
        for field_name, weight in weighted_fields
        if getattr(first, field_name) == getattr(second, field_name)
    )
    first_neighbors, second_neighbors = (
        set(first.neighbor_kinds),
        set(second.neighbor_kinds),
    )
    if not first_neighbors and not second_neighbors:
        score += 0.06
    elif first_neighbors | second_neighbors:
        score += (
            0.06
            * len(first_neighbors & second_neighbors)
            / len(first_neighbors | second_neighbors)
        )
    first_tags, second_tags = (
        set(first.semantic_sketch.semantic_tags),
        set(second.semantic_sketch.semantic_tags),
    )
    if first_tags and second_tags:
        score += 0.10 * len(first_tags & second_tags) / len(first_tags | second_tags)
    return max(0.0, min(1.0, score))


class ContentRegionRoutingPolicy(BaseModel):
    """Non-model score and confidence gates."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    vector_weight: float = Field(default=0.65, ge=0.0, le=1.0)
    topology_weight: float = Field(default=0.25, ge=0.0, le=1.0)
    review_success_weight: float = Field(default=0.10, ge=0.0, le=1.0)
    candidate_request_min_score: float = Field(default=0.48, ge=0.0, le=1.0)
    candidate_reuse_min_score: float = Field(default=0.80, ge=0.0, le=1.0)
    model_reuse_min_confidence: float = Field(default=0.90, ge=0.0, le=1.0)
    model_proposal_min_confidence: float = Field(default=0.85, ge=0.0, le=1.0)
    selected_max_score_gap: float = Field(default=0.12, ge=0.0, le=1.0)
    max_model_candidates: int = Field(default=5, ge=1, le=5)

    @model_validator(mode="after")
    def validate_policy(self) -> Self:
        if self.vector_weight + self.topology_weight + self.review_success_weight <= 0:
            raise ValueError("content routing weights must have a positive sum")
        if self.candidate_reuse_min_score < self.candidate_request_min_score:
            raise ValueError("reuse threshold cannot be below request threshold")
        return self


ContentRegionAction = Literal["route", "review", "new_candidate"]
ContentRegionReason = Literal[
    "exact_reviewed_active_profile",
    "model_selected_active_profile",
    "model_proposed_registered_route",
    "model_requested_new_candidate",
    "model_requested_review",
    "no_stable_exact_anchor",
    "no_active_profile",
    "selector_unavailable",
    "embedding_unavailable",
    "embedding_failure",
    "store_failure",
    "store_circuit_open",
    "model_failure",
    "model_circuit_open",
    "invalid_model_output",
    "candidate_not_authorized",
    "candidate_score_below_threshold",
    "candidate_score_gap_too_large",
    "candidate_confidence_below_threshold",
    "registered_route_not_authorized",
    "registered_route_confidence_below_threshold",
    "active_profile_not_reusable",
    "candidate_store_failure",
]


class ContentRegionRoutingDecision(BaseModel):
    """Auditable decision containing no source content or executable artifact."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.content-region-routing-decision.v1"] = (
        "m1.content-region-routing-decision.v1"
    )
    action: ContentRegionAction
    reason: ContentRegionReason
    role: ContentRegionRole | None = None
    strategy_id: SemanticStrategyId | None = None
    profile_id: str | None = None
    candidate_profile_id: str | None = None
    suggested_role: ContentRegionRole | None = None
    suggested_strategy_id: SemanticStrategyId | None = None
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    selected_score: float = Field(default=0.0, ge=0.0, le=1.0)
    model_used: bool = False
    model_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    review_required: bool = False

    @model_validator(mode="after")
    def validate_decision(self) -> Self:
        routed = self.action == "route"
        if routed != bool(self.role and self.strategy_id and self.profile_id):
            raise ValueError("routes require an active profile, role, and strategy")
        if routed and self.reason not in {
            "exact_reviewed_active_profile",
            "model_selected_active_profile",
        }:
            raise ValueError("only reviewed active profiles may route")
        if (self.suggested_role is None) != (self.suggested_strategy_id is None):
            raise ValueError("suggested role and strategy are an atomic pair")
        if routed and (
            self.candidate_profile_id is not None or self.suggested_role is not None
        ):
            raise ValueError("an active route cannot also be a candidate")
        if self.review_required != (self.action == "review"):
            raise ValueError("review_required must match the review action")
        return self


def _profile_compatible(
    profile: ContentRegionProfile,
    *,
    tenant_id: str,
    signature: ContentRegionSignature,
    embedding_space: str,
    registry: ContentRegionRouteRegistry,
    allowed_strategies: frozenset[SemanticStrategyId],
) -> bool:
    return bool(
        profile.tenant_id == tenant_id
        and profile.status == "active"
        and profile.reviewed
        and profile.failure_count == 0
        and profile.success_count >= 1
        and profile.contract_id == CONTENT_REGION_CONTRACT_ID
        and profile.contract_revision == CONTENT_REGION_CONTRACT_REVISION
        and profile.signature.contract_id == signature.contract_id
        and profile.signature.contract_revision == signature.contract_revision
        and profile.embedding_space == embedding_space
        and profile.signature.region_kind is signature.region_kind
        and profile.role is not None
        and profile.strategy_id is not None
        and profile.strategy_id in allowed_strategies
        and registry.supports(
            region_kind=signature.region_kind,
            role=profile.role,
            strategy_id=profile.strategy_id,
        )
    )


class ContentRegionRoutingRuntime:
    """Resolve one value-free region signature through governed profiles."""

    def __init__(
        self,
        *,
        store: ContentRegionStore,
        embedding_provider: ContentRegionEmbeddingProvider | None = None,
        selector: ContentRegionSelector | None = None,
        registry: ContentRegionRouteRegistry | None = None,
        policy: ContentRegionRoutingPolicy | None = None,
        embedding_space: str = CONTENT_REGION_EMBEDDING_SPACE,
        required: bool = False,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
    ) -> None:
        self.store = store
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.registry = registry or registered_content_region_routes()
        self.policy = policy or ContentRegionRoutingPolicy()
        self.required = bool(required)
        self.embedding_space = normalized_route_token(
            embedding_space, field_name="embedding_space"
        )
        self._status = DocumentRoutingStatus(
            circuit_failures=circuit_failures,
            circuit_seconds=circuit_seconds,
        )

    def status_snapshot(self) -> dict[str, object]:
        return self._status.snapshot()

    @staticmethod
    def _strategies(
        allowed_strategy_ids: Sequence[SemanticStrategyId] | None,
    ) -> frozenset[SemanticStrategyId]:
        registered = registered_semantic_strategies()
        if allowed_strategy_ids is None:
            return frozenset(registered)
        result = frozenset(SemanticStrategyId(item) for item in allowed_strategy_ids)
        if any(item not in registered for item in result):
            raise ValueError("only registered semantic strategies are allowed")
        return result

    async def _embed(
        self, signature: ContentRegionSignature
    ) -> tuple[tuple[float, ...], str, int]:
        provider = self.embedding_provider
        if provider is None:
            raise RuntimeError("content-region embedding provider unavailable")
        space = normalized_route_token(provider.space, field_name="provider.space")
        if space != self.embedding_space:
            raise ValueError("content-region embedding space mismatch")
        model = str(provider.model).strip()
        dimensions = int(provider.dimensions)
        if not model or dimensions < 1:
            raise ValueError("content-region embedding provider identity is invalid")
        vectors = await provider.embed_texts((signature.embedding_text(),))
        if len(vectors) != 1:
            raise ValueError("content-region embedding returned an invalid count")
        vector = tuple(float(item) for item in vectors[0])
        if len(vector) != dimensions or not all(math.isfinite(item) for item in vector):
            raise ValueError("content-region embedding vector is invalid")
        return vector, model, dimensions

    def _rank(
        self,
        signature: ContentRegionSignature,
        match: ContentRegionProfileMatch,
    ) -> ContentRegionRankedCandidate:
        profile = match.profile
        topology = content_region_topology_similarity(signature, profile.signature)
        review_success = (
            profile.success_count / profile.observation_count
            if profile.observation_count
            else 0.0
        )
        vector = max(0.0, min(1.0, match.vector_similarity))
        denominator = (
            self.policy.vector_weight
            + self.policy.topology_weight
            + self.policy.review_success_weight
        )
        fused = (
            vector * self.policy.vector_weight
            + topology * self.policy.topology_weight
            + review_success * self.policy.review_success_weight
        ) / denominator
        return ContentRegionRankedCandidate(
            profile_id=profile.profile_id,
            role=profile.role,  # type: ignore[arg-type]
            strategy_id=profile.strategy_id,  # type: ignore[arg-type]
            vector_similarity=match.vector_similarity,
            topology_similarity=topology,
            review_success_rate=review_success,
            fused_score=max(0.0, min(1.0, fused)),
        )

    async def _create_candidate(
        self,
        *,
        tenant_id: str,
        signature: ContentRegionSignature,
        suggested_role: ContentRegionRole | None,
        suggested_strategy_id: SemanticStrategyId | None,
        embedding: tuple[float, ...] | None,
        embedding_model: str,
        embedding_dimensions: int,
        created_by: str,
    ) -> str | None:
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return None
        if suggested_role is not None and (
            suggested_strategy_id is None
            or not self.registry.supports(
                region_kind=signature.region_kind,
                role=suggested_role,
                strategy_id=suggested_strategy_id,
            )
        ):
            suggested_role = None
            suggested_strategy_id = None
        suffix = (
            f"{suggested_role.value}:{suggested_strategy_id.value}"
            if suggested_role is not None and suggested_strategy_id is not None
            else "unresolved"
        )
        proposal = ContentRegionCandidateProposal(
            tenant_id=tenant_id,
            profile_key=(
                f"content-region:{signature.exact_fingerprint()[:20]}:{suffix}"
            )[:128],
            embedding_space=self.embedding_space,
            signature=signature,
            suggested_role=suggested_role,
            suggested_strategy_id=suggested_strategy_id,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            created_by=created_by,
        )
        try:
            candidate = await self.store.create_content_region_candidate(proposal)
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - optional persistence is advisory
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return None
        if (
            candidate.status != "candidate"
            or candidate.tenant_id != tenant_id
            or candidate.contract_id != CONTENT_REGION_CONTRACT_ID
            or candidate.contract_revision != CONTENT_REGION_CONTRACT_REVISION
            or candidate.embedding_space != self.embedding_space
            or candidate.exact_fingerprint != signature.exact_fingerprint()
            or candidate.role is not suggested_role
            or candidate.strategy_id is not suggested_strategy_id
        ):
            controlled = self._status.note_dependency_failure(
                "store", ValueError("candidate store returned a mismatched profile")
            )
            if self.required:
                raise controlled from None
            return None
        return candidate.profile_id

    @staticmethod
    def _decision(
        *,
        action: ContentRegionAction,
        reason: ContentRegionReason,
        role: ContentRegionRole | None = None,
        strategy_id: SemanticStrategyId | None = None,
        profile_id: str | None = None,
        candidate_profile_id: str | None = None,
        suggested_role: ContentRegionRole | None = None,
        suggested_strategy_id: SemanticStrategyId | None = None,
        top_score: float = 0.0,
        selected_score: float = 0.0,
        model_used: bool = False,
        model_confidence: float | None = None,
    ) -> ContentRegionRoutingDecision:
        return ContentRegionRoutingDecision(
            action=action,
            reason=reason,
            role=role,
            strategy_id=strategy_id,
            profile_id=profile_id,
            candidate_profile_id=candidate_profile_id,
            suggested_role=suggested_role,
            suggested_strategy_id=suggested_strategy_id,
            top_score=top_score,
            selected_score=selected_score,
            model_used=model_used,
            model_confidence=model_confidence,
            review_required=action == "review",
        )

    async def _resolve(
        self,
        *,
        tenant_id: str,
        probe: ContentRegionProbe,
        allowed_strategy_ids: Sequence[SemanticStrategyId] | None,
        selector: ContentRegionSelector | None,
        created_by: str,
    ) -> ContentRegionRoutingDecision:
        if not tenant_id.strip() or tenant_id != tenant_id.strip():
            raise ValueError("tenant_id must be a normalized non-empty value")
        signature = probe.signature
        allowed = self._strategies(allowed_strategy_ids)
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return self._decision(action="review", reason="store_circuit_open")

        try:
            exact = await self.store.get_active_content_region_profile_by_fingerprint(
                tenant_id,
                signature.exact_fingerprint(),
                contract_id=CONTENT_REGION_CONTRACT_ID,
                contract_revision=CONTENT_REGION_CONTRACT_REVISION,
                embedding_space=self.embedding_space,
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - optional routing fails to review
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self._decision(action="review", reason="store_failure")

        exact_compatible = exact is not None and _profile_compatible(
            exact,
            tenant_id=tenant_id,
            signature=signature,
            embedding_space=self.embedding_space,
            registry=self.registry,
            allowed_strategies=allowed,
        )
        exact_reusable = bool(
            exact_compatible
            and exact is not None
            and exact.exact_fingerprint == signature.exact_fingerprint()
        )
        if exact_reusable and exact is not None and signature.has_stable_anchor:
            return self._decision(
                action="route",
                reason="exact_reviewed_active_profile",
                role=exact.role,
                strategy_id=exact.strategy_id,
                profile_id=exact.profile_id,
                top_score=1.0,
                selected_score=1.0,
            )
        exact_reason: ContentRegionReason | None = None
        if exact is not None and not exact_reusable:
            exact_reason = "active_profile_not_reusable"
        elif exact_reusable and not signature.has_stable_anchor:
            exact_reason = "no_stable_exact_anchor"

        embedding: tuple[float, ...] | None = None
        embedding_model = ""
        embedding_dimensions = 0
        if self.embedding_provider is None and self.required:
            error = RuntimeError("content-region embedding provider unavailable")
            raise self._status.note_dependency_failure("embedding", error) from None
        if self._status.circuit_open("embedding"):
            if self.required:
                raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
        elif self.embedding_provider is not None:
            try:
                embedding, embedding_model, embedding_dimensions = await self._embed(
                    signature
                )
                self._status.note_dependency_success("embedding")
            except Exception as exc:  # noqa: BLE001 - optional exact path remains
                controlled = self._status.note_dependency_failure("embedding", exc)
                if self.required:
                    raise controlled from None

        ranked: tuple[ContentRegionRankedCandidate, ...] = ()
        profiles: dict[str, ContentRegionProfile] = {}
        if embedding is not None:
            try:
                matches = await self.store.find_active_content_region_profiles(
                    tenant_id,
                    embedding,
                    contract_id=CONTENT_REGION_CONTRACT_ID,
                    contract_revision=CONTENT_REGION_CONTRACT_REVISION,
                    embedding_space=self.embedding_space,
                    embedding_model=embedding_model,
                    embedding_dimensions=embedding_dimensions,
                    region_kind=signature.region_kind,
                    limit=min(100, self.policy.max_model_candidates * 4),
                )
                self._status.note_dependency_success("store")
            except Exception as exc:  # noqa: BLE001 - optional routing reviews
                controlled = self._status.note_dependency_failure("store", exc)
                if self.required:
                    raise controlled from None
                return self._decision(action="review", reason="store_failure")
            ranked_items: list[ContentRegionRankedCandidate] = []
            for match in matches:
                profile = match.profile
                if (
                    not _profile_compatible(
                        profile,
                        tenant_id=tenant_id,
                        signature=signature,
                        embedding_space=self.embedding_space,
                        registry=self.registry,
                        allowed_strategies=allowed,
                    )
                    or profile.embedding_model != embedding_model
                    or profile.embedding_dimensions != embedding_dimensions
                    or profile.embedding_space != self.embedding_space
                ):
                    continue
                item = self._rank(signature, match)
                if item.fused_score < self.policy.candidate_request_min_score:
                    continue
                profiles[profile.profile_id] = profile
                ranked_items.append(item)
            ranked = tuple(
                sorted(
                    ranked_items,
                    key=lambda item: (-item.fused_score, item.profile_id),
                )[: self.policy.max_model_candidates]
            )

        route_pairs = self.registry.pairs(
            signature.region_kind,
            allowed_strategy_ids=tuple(allowed),
        )
        request = ContentRegionSelectionRequest(
            sketch=signature.model_sketch(),
            candidates=tuple(
                ContentRegionCandidateOption(
                    candidate_index=index,
                    role=item.role,
                    strategy_id=item.strategy_id,
                    vector_similarity=item.vector_similarity,
                    topology_similarity=item.topology_similarity,
                    review_success_rate=item.review_success_rate,
                    fused_score=item.fused_score,
                )
                for index, item in enumerate(ranked)
            ),
            routes=tuple(
                ContentRegionRegisteredRouteOption(
                    route_index=index,
                    role=role,
                    strategy_id=strategy_id,
                )
                for index, (role, strategy_id) in enumerate(route_pairs[:64])
            ),
        )
        active_selector = selector or self.selector
        top_score = ranked[0].fused_score if ranked else 0.0
        if active_selector is None:
            if self.required:
                error = RuntimeError("content-region selector unavailable")
                raise self._status.note_dependency_failure("model", error) from None
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                suggested_role=None,
                suggested_strategy_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._decision(
                action="new_candidate",
                reason=(exact_reason or "selector_unavailable"),
                candidate_profile_id=candidate_id,
                top_score=top_score,
            )
        if self._status.circuit_open("model"):
            if self.required:
                raise DocumentRoutingDependencyError("model", "CircuitOpen")
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                suggested_role=None,
                suggested_strategy_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._decision(
                action="review",
                reason="model_circuit_open",
                candidate_profile_id=candidate_id,
                top_score=top_score,
            )
        try:
            raw_choice = await active_selector.select(request)
            choice = ContentRegionModelChoice.model_validate(raw_choice, strict=True)
            self._status.note_dependency_success("model")
        except (TypeError, ValueError, ValidationError) as exc:
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            choice = None
            choice_reason: ContentRegionReason = "invalid_model_output"
        except Exception as exc:  # noqa: BLE001 - model output is advisory
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            choice = None
            choice_reason = "model_failure"

        if choice is None:
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                suggested_role=None,
                suggested_strategy_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._decision(
                action="review",
                reason=choice_reason,
                candidate_profile_id=candidate_id,
                top_score=top_score,
                model_used=True,
            )

        common = {
            "top_score": top_score,
            "model_used": True,
            "model_confidence": choice.confidence,
        }

        async def review_unmatched(
            reason: ContentRegionReason,
            *,
            selected_score: float = 0.0,
        ) -> ContentRegionRoutingDecision:
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                suggested_role=None,
                suggested_strategy_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._decision(
                action="review",
                reason=(
                    reason if candidate_id is not None else "candidate_store_failure"
                ),
                candidate_profile_id=candidate_id,
                selected_score=selected_score,
                **common,
            )

        if choice.action == "reuse_active":
            index = choice.candidate_index
            if index is None or index >= len(ranked):
                return await review_unmatched("candidate_not_authorized")
            selected = ranked[index]
            profile = profiles.get(selected.profile_id)
            if profile is None:
                return await review_unmatched("candidate_not_authorized")
            if selected.fused_score < self.policy.candidate_reuse_min_score:
                return await review_unmatched(
                    "candidate_score_below_threshold",
                    selected_score=selected.fused_score,
                )
            if top_score - selected.fused_score > self.policy.selected_max_score_gap:
                return await review_unmatched(
                    "candidate_score_gap_too_large",
                    selected_score=selected.fused_score,
                )
            if choice.confidence < self.policy.model_reuse_min_confidence:
                return await review_unmatched(
                    "candidate_confidence_below_threshold",
                    selected_score=selected.fused_score,
                )
            return self._decision(
                action="route",
                reason="model_selected_active_profile",
                role=profile.role,
                strategy_id=profile.strategy_id,
                profile_id=profile.profile_id,
                selected_score=selected.fused_score,
                **common,
            )

        suggested_role: ContentRegionRole | None = None
        suggested_strategy: SemanticStrategyId | None = None
        reason: ContentRegionReason
        action: ContentRegionAction = "new_candidate"
        if choice.action == "propose_registered":
            index = choice.route_index
            if index is None or index >= len(request.routes):
                reason = "registered_route_not_authorized"
                action = "review"
            elif choice.confidence < self.policy.model_proposal_min_confidence:
                reason = "registered_route_confidence_below_threshold"
                action = "review"
            else:
                route = request.routes[index]
                suggested_role = route.role
                suggested_strategy = route.strategy_id
                reason = "model_proposed_registered_route"
        elif choice.action == "review":
            reason = "model_requested_review"
            action = "review"
        else:
            reason = "model_requested_new_candidate"

        candidate_id = await self._create_candidate(
            tenant_id=tenant_id,
            signature=signature,
            suggested_role=suggested_role,
            suggested_strategy_id=suggested_strategy,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            created_by=created_by,
        )
        if candidate_id is None and not self._status.circuit_open("store"):
            reason = "candidate_store_failure"
            action = "review"
            suggested_role = None
            suggested_strategy = None
        return self._decision(
            action=action,
            reason=reason,
            candidate_profile_id=candidate_id,
            suggested_role=suggested_role,
            suggested_strategy_id=suggested_strategy,
            **common,
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        probe: ContentRegionProbe,
        allowed_strategy_ids: Sequence[SemanticStrategyId] | None = None,
        selector: ContentRegionSelector | None = None,
        created_by: str = "content-region-router",
    ) -> ContentRegionRoutingDecision:
        """Resolve one region without retaining source content or TaskID data."""

        return await self._status.track_operation(
            self._resolve(
                tenant_id=tenant_id,
                probe=probe,
                allowed_strategy_ids=allowed_strategy_ids,
                selector=selector,
                created_by=created_by,
            )
        )


__all__ = [
    "ContentRegionRoutingDecision",
    "ContentRegionRoutingPolicy",
    "ContentRegionRoutingRuntime",
    "content_region_topology_similarity",
]
