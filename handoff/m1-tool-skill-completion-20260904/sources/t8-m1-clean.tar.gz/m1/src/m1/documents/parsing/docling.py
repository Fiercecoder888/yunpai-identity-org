"""Optional Docling backend for Office and born-digital documents."""

from __future__ import annotations

import importlib.util
import time
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Callable, Sequence

from .base import PageInput, ParserBackendError, ParserBackendUnavailable
from .evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
    bbox_from_value,
)


def _docling_version() -> str:
    try:
        return version("docling")
    except PackageNotFoundError:
        return "unknown"


def _provenance(item: dict[str, Any]) -> tuple[int, Any]:
    candidates = item.get("prov") or item.get("provenance") or []
    if isinstance(candidates, dict):
        candidates = [candidates]
    first = candidates[0] if isinstance(candidates, list) and candidates else {}
    if not isinstance(first, dict):
        return 1, None
    return int(first.get("page_no") or first.get("page") or 1), first.get("bbox")


def _table_rows(item: dict[str, Any]) -> tuple[list[list[str | None]], list[EvidenceCell]]:
    data = item.get("data") if isinstance(item.get("data"), dict) else item
    grid = data.get("grid") if isinstance(data, dict) else None
    rows: list[list[str | None]] = []
    cells: list[EvidenceCell] = []
    if isinstance(grid, list):
        for row_index, row in enumerate(grid):
            values: list[str | None] = []
            if not isinstance(row, list):
                continue
            for column_index, cell in enumerate(row):
                payload = cell if isinstance(cell, dict) else {"text": cell}
                text = payload.get("text") or payload.get("text_content")
                values.append(None if text in (None, "") else str(text))
                cells.append(
                    EvidenceCell(
                        row=row_index,
                        column=column_index,
                        text=None if text in (None, "") else str(text),
                        bbox=bbox_from_value(payload.get("bbox"), coordinate_space="pdf_points"),
                    )
                )
            rows.append(values)
        return rows, cells

    raw_cells = data.get("table_cells") if isinstance(data, dict) else None
    if not isinstance(raw_cells, list):
        return rows, cells
    max_row = max((int(cell.get("start_row_offset_idx") or 0) for cell in raw_cells if isinstance(cell, dict)), default=-1)
    max_col = max((int(cell.get("start_col_offset_idx") or 0) for cell in raw_cells if isinstance(cell, dict)), default=-1)
    rows = [[None for _ in range(max_col + 1)] for _ in range(max_row + 1)]
    for raw in raw_cells:
        if not isinstance(raw, dict):
            continue
        row = int(raw.get("start_row_offset_idx") or 0)
        column = int(raw.get("start_col_offset_idx") or 0)
        text = raw.get("text") or raw.get("text_content")
        value = None if text in (None, "") else str(text)
        rows[row][column] = value
        cells.append(
            EvidenceCell(
                row=row,
                column=column,
                text=value,
                bbox=bbox_from_value(raw.get("bbox"), coordinate_space="pdf_points"),
            )
        )
    return rows, cells


class DoclingBackend:
    name = "docling"

    def __init__(self, *, converter_factory: Callable[[], Any] | None = None) -> None:
        self._converter_factory = converter_factory
        self._converter: Any = None

    def _get_converter(self) -> Any:
        if self._converter is not None:
            return self._converter
        if self._converter_factory is not None:
            self._converter = self._converter_factory()
            return self._converter
        try:
            from docling.document_converter import DocumentConverter
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ParserBackendUnavailable(
                "Docling is not installed; install the `document-parsers` extra"
            ) from exc
        self._converter = DocumentConverter()
        return self._converter

    def readiness(self) -> dict[str, object]:
        installed = self._converter_factory is not None or importlib.util.find_spec("docling") is not None
        return {
            "backend": self.name,
            "installed": installed,
            "ready": installed,
            "version": _docling_version(),
        }

    def parse(
        self,
        path: str | Path,
        *,
        pages: Sequence[PageInput] | None = None,
    ) -> DocumentEvidence:
        del pages
        started = time.perf_counter()
        source = Path(path)
        try:
            conversion = self._get_converter().convert(str(source))
            document = conversion.document
            payload = document.export_to_dict()
            markdown = document.export_to_markdown()
        except ParserBackendUnavailable:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ParserBackendError(
                f"Docling conversion failed: {exc.__class__.__name__}"
            ) from exc
        if not isinstance(payload, dict):
            payload = {}

        page_payloads = payload.get("pages")
        page_sizes: dict[int, tuple[float, float]] = {}
        if isinstance(page_payloads, dict):
            iterable = page_payloads.items()
        elif isinstance(page_payloads, list):
            iterable = enumerate(page_payloads, start=1)
        else:
            iterable = []
        for key, value in iterable:
            if not isinstance(value, dict):
                continue
            size = value.get("size") if isinstance(value.get("size"), dict) else value
            page_sizes[int(value.get("page_no") or key or 1)] = (
                float(size.get("width") or 1.0),
                float(size.get("height") or 1.0),
            )

        blocks_by_page: dict[int, list[EvidenceBlock]] = {}
        for index, item in enumerate(payload.get("texts") or []):
            if not isinstance(item, dict):
                continue
            page_number, bbox = _provenance(item)
            blocks_by_page.setdefault(page_number, []).append(
                EvidenceBlock(
                    block_id=str(item.get("self_ref") or item.get("id") or f"text-{index}"),
                    kind=str(item.get("label") or "text"),
                    text=str(item.get("text") or item.get("text_content") or ""),
                    bbox=bbox_from_value(bbox, coordinate_space="pdf_points"),
                    order=index,
                    source=self.name,
                )
            )

        tables_by_page: dict[int, list[EvidenceTable]] = {}
        for index, item in enumerate(payload.get("tables") or []):
            if not isinstance(item, dict):
                continue
            page_number, bbox = _provenance(item)
            rows, cells = _table_rows(item)
            tables_by_page.setdefault(page_number, []).append(
                EvidenceTable(
                    table_id=str(item.get("self_ref") or item.get("id") or f"table-{index}"),
                    rows=rows,
                    cells=cells,
                    bbox=bbox_from_value(bbox, coordinate_space="pdf_points"),
                    source=self.name,
                )
            )

        page_numbers = sorted(set(page_sizes) | set(blocks_by_page) | set(tables_by_page) or {1})
        evidence_pages = []
        for page_number in page_numbers:
            width, height = page_sizes.get(page_number, (1.0, 1.0))
            evidence_pages.append(
                EvidencePage(
                    page_number=page_number,
                    page_index=page_number - 1,
                    width=max(1.0, width),
                    height=max(1.0, height),
                    coordinate_space="pdf_points",
                    blocks=blocks_by_page.get(page_number, []),
                    tables=tables_by_page.get(page_number, []),
                    markdown=str(markdown or "") if page_number == 1 else "",
                )
            )
        return DocumentEvidence(
            backend=self.name,
            backend_version=_docling_version(),
            elapsed_ms=(time.perf_counter() - started) * 1000,
            pages=evidence_pages,
        )


__all__ = ["DoclingBackend"]
