"""Tenant-scoped runtime for governed document classification routing."""

from __future__ import annotations

import copy
import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Self

from pydantic import ValidationError

from ...knowledge.embeddings import EmbeddingProvider, EmbeddingSpaceIdentity
from ...knowledge.routing_schema import RouteProfileRecord, RouteProfileStatus
from .adaptive_routing import (
    AdaptiveDocumentRouter,
    DocumentRouteCandidateScore,
    DocumentRouteSignature,
)
from .document_classification_policy import (
    ClassificationAction,
    DocumentClassificationCandidate,
    DocumentClassificationDecision,
    DocumentClassificationModelChoice,
    DocumentClassificationSelectionRequest,
    DocumentClassificationSelector,
    DocumentRouteCandidateObserver,
    PydanticDocumentClassificationSelector,
    _classification,
    _classification_input_valid,
    _classification_policy,
    _classification_source_refs,
    _known,
    _profile_classification,
    _success_rate,
)
from .document_route_lifecycle import (
    DocumentRouteSignatureBuilder,
    DocumentRouteStore,
    default_signature_builder,
    profile_matches_signature,
    top_metrics,
    typed_policy,
)
from .document_route_policy import (
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
)
from .evidence import DocumentEvidence
from .mineru_domain import CANONICAL_SUBTYPE_TYPES


@dataclass(frozen=True, slots=True)
class _ResolvedCandidate:
    profile: RouteProfileRecord
    policy: RouteProfilePolicy
    score: DocumentRouteCandidateScore


class DocumentClassificationRoutingRuntime:
    """Fill missing taxonomy fields through active, tenant-scoped profiles only."""

    def __init__(
        self,
        *,
        store: DocumentRouteStore,
        observer: DocumentRouteCandidateObserver,
        embedding_provider: EmbeddingProvider | None,
        selector: DocumentClassificationSelector | None = None,
        signature_builder: DocumentRouteSignatureBuilder | None = None,
        top_k: int = 5,
        auto_min_score: float = 0.90,
        model_min_score: float = 0.75,
        min_margin: float = 0.08,
        model_min_confidence: float = 0.70,
    ) -> None:
        if top_k < 1:
            raise ValueError("classification route top_k must be positive")
        thresholds = (
            auto_min_score,
            model_min_score,
            min_margin,
            model_min_confidence,
        )
        if not all(
            math.isfinite(value) and 0.0 <= value <= 1.0 for value in thresholds
        ):
            raise ValueError(
                "classification route thresholds must be finite values in [0, 1]"
            )
        if model_min_score > auto_min_score:
            raise ValueError("model_min_score must not exceed auto_min_score")
        self.store = store
        self.observer = observer
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.signature_builder = signature_builder or default_signature_builder
        self.top_k = min(int(top_k), 5)
        self.auto_min_score = float(auto_min_score)
        self.model_min_score = float(model_min_score)
        self.min_margin = float(min_margin)

        self.model_min_confidence = float(model_min_confidence)
        self._ranker = AdaptiveDocumentRouter()

    @classmethod
    def from_document_routing_runtime(
        cls,
        runtime: Any,
        *,
        selector: DocumentClassificationSelector | None = None,
    ) -> Self:
        return cls(
            store=runtime.store,
            observer=runtime,
            embedding_provider=runtime.embedding_provider,
            selector=selector,
            signature_builder=runtime.signature_builder,
            top_k=min(int(getattr(runtime, "top_k", 5)), 5),
            auto_min_score=float(getattr(runtime, "auto_min_score", 0.90)),
            model_min_score=float(getattr(runtime, "model_min_score", 0.75)),
            min_margin=float(getattr(runtime, "min_margin", 0.08)),
            model_min_confidence=float(
                getattr(runtime, "model_reuse_min_confidence", 0.70)
            ),
        )

    async def _embed_signature(
        self,
        signature: DocumentRouteSignature,
    ) -> tuple[list[float], EmbeddingSpaceIdentity] | None:
        if self.embedding_provider is None:
            return None
        identity = EmbeddingSpaceIdentity.from_provider(self.embedding_provider)
        vectors = await self.embedding_provider.embed_texts(
            [signature.embedding_text()]
        )
        if len(vectors) != 1:
            raise ValueError("classification route embedding count mismatch")
        vector = [float(value) for value in vectors[0]]
        if len(vector) != identity.dimensions:
            raise ValueError("classification route embedding dimension mismatch")
        if not all(math.isfinite(value) for value in vector):
            raise ValueError(
                "classification route embedding contains non-finite values"
            )
        return vector, identity

    @staticmethod
    def _decision(
        *,
        action: ClassificationAction,
        reason: str,
        signature: DocumentRouteSignature,
        document_type: RouteDocumentType | None = None,
        document_subtype: RouteDocumentSubtype | None = None,
        selected_profile_id: str | None = None,
        candidate_profile_id: str | None = None,
        selected_candidate_index: int | None = None,
        candidates: Sequence[DocumentClassificationCandidate] = (),
        top_score: float = 0.0,
        margin: float = 0.0,
        model_used: bool = False,
        model_confidence: float | None = None,
        explicit_hint_locked: bool = False,
        applied_fields: Sequence[str] = (),
    ) -> DocumentClassificationDecision:
        return DocumentClassificationDecision(
            action=action,
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            document_type=document_type,
            document_subtype=document_subtype,
            selected_profile_id=selected_profile_id,
            candidate_profile_id=candidate_profile_id,
            selected_candidate_index=selected_candidate_index,
            candidates=tuple(candidates),
            top_score=top_score,
            top1_top2_margin=margin,
            model_used=model_used,
            model_confidence=model_confidence,
            explicit_hint_locked=explicit_hint_locked,
            applied_fields=tuple(applied_fields),
        )

    @staticmethod
    def _profile_is_compatible(
        policy: RouteProfilePolicy,
        *,
        current_type: RouteDocumentType | None,
        current_subtype: RouteDocumentSubtype | None,
    ) -> bool:
        candidate_type, candidate_subtype = _profile_classification(policy)
        if candidate_type is None:
            return False
        if current_type is not None and candidate_type is not current_type:
            return False
        if current_subtype is not None and candidate_subtype not in {
            None,
            current_subtype,
        }:
            return False
        # Once both facts are known, routing cannot add anything.
        if current_type is not None and current_subtype is not None:
            return False
        # A type-only candidate cannot fill a missing subtype.
        return not (current_type is not None and candidate_subtype is None)

    @staticmethod
    def _model_candidates(
        resolved: Sequence[_ResolvedCandidate],
    ) -> tuple[DocumentClassificationCandidate, ...]:
        return tuple(
            DocumentClassificationCandidate(
                candidate_index=index,
                document_type=_profile_classification(candidate.policy)[0],  # type: ignore[arg-type]
                document_subtype=_profile_classification(candidate.policy)[1],
                fused_score=candidate.score.fused_score,
                exact_fingerprint=candidate.score.exact_fingerprint,
                observation_count=candidate.profile.observation_count,
                success_rate=_success_rate(candidate.profile),
            )
            for index, candidate in enumerate(resolved[:5])
        )

    async def _observe_new_candidate(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None,
        current_type: RouteDocumentType | None,
        current_subtype: RouteDocumentSubtype | None,
        reason: str,
        candidates: Sequence[DocumentClassificationCandidate] = (),
        top_score: float = 0.0,
        margin: float = 0.0,
        model_used: bool = False,
        model_confidence: float | None = None,
    ) -> DocumentClassificationDecision:
        profile = await self.observer.observe_candidate(
            tenant_id=tenant_id,
            task_id=task_id,
            signature=signature,
            embedding=embedding,
            policy=_classification_policy(
                signature,
                current_type,
                current_subtype,
            ),
        )
        if profile.tenant_id != tenant_id:
            raise ValueError("classification candidate crossed a tenant boundary")
        if profile.exact_fingerprint != signature.exact_fingerprint():
            raise ValueError("classification candidate signature mismatch")

        candidate_profile_id = (
            profile.profile_id
            if profile.status is RouteProfileStatus.CANDIDATE
            else None
        )
        return self._decision(
            action="new_candidate",
            reason=reason,
            signature=signature,
            document_type=current_type,
            document_subtype=current_subtype,
            candidate_profile_id=candidate_profile_id,
            candidates=candidates,
            top_score=top_score,
            margin=margin,
            model_used=model_used,
            model_confidence=model_confidence,
        )

    @classmethod
    def _explicit_hint_decision(
        cls,
        signature: DocumentRouteSignature,
        *,
        current_type: RouteDocumentType | None,
        current_subtype: RouteDocumentSubtype | None,
        document_type_hint: object,
        document_subtype_hint: object,
    ) -> DocumentClassificationDecision | None:
        raw_type = _known(document_type_hint)
        raw_subtype = _known(document_subtype_hint)
        if not raw_type and not raw_subtype:
            return None
        if not _classification_input_valid(raw_type, raw_subtype):
            return cls._decision(
                action="review",
                reason="explicit_hint_invalid_or_inconsistent",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                explicit_hint_locked=True,
            )
        hint_type, hint_subtype = _classification(raw_type, raw_subtype)
        if hint_type is None and hint_subtype is None:
            return cls._decision(
                action="review",
                reason="explicit_hint_invalid_or_inconsistent",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                explicit_hint_locked=True,
            )
        # Explicit user intent is always rewritten so its manual-lock provenance
        # survives even when a parser happened to return the same label.
        applied: list[str] = ["document_type"]
        if raw_subtype:
            applied.append("document_subtype")
            result_subtype = hint_subtype
        else:
            result_subtype = current_subtype
            if current_subtype is not None:
                expected = CANONICAL_SUBTYPE_TYPES.get(current_subtype.value)
                if hint_type is not None and expected != hint_type.value:
                    result_subtype = None
                    applied.append("document_subtype")
        return cls._decision(
            action="explicit_hint",
            reason="explicit_hint_locked",
            signature=signature,
            document_type=hint_type,
            document_subtype=result_subtype,
            explicit_hint_locked=True,
            applied_fields=applied,
        )

    @classmethod
    def _selected_profile_decision(
        cls,
        *,
        signature: DocumentRouteSignature,
        selected: _ResolvedCandidate,
        current_type: RouteDocumentType | None,
        current_subtype: RouteDocumentSubtype | None,
        reason: str,
        index: int,
        candidates: Sequence[DocumentClassificationCandidate],
        top_score: float,
        margin: float,
        model_used: bool = False,
        model_confidence: float | None = None,
    ) -> DocumentClassificationDecision:
        document_type, document_subtype = _profile_classification(selected.policy)
        applied = ["document_type"] if current_type is None else []
        if current_subtype is None and document_subtype is not None:
            applied.append("document_subtype")
        return cls._decision(
            action="candidate",
            reason=reason,
            signature=signature,
            document_type=document_type,
            document_subtype=document_subtype or current_subtype,
            selected_profile_id=selected.profile.profile_id,
            selected_candidate_index=index,
            candidates=candidates,
            top_score=top_score,
            margin=margin,
            model_used=model_used,
            model_confidence=model_confidence,
            applied_fields=applied,
        )

    async def resolve(
        self,
        tenant_id: str,
        task_id: str,
        evidence: DocumentEvidence,
        source_kind: str,
        *,
        current_document_type: object = None,
        current_document_subtype: object = None,
        document_type_hint: object = None,
        document_subtype_hint: object = None,
        contract_revision: str = "m1.document.v2",
    ) -> DocumentClassificationDecision:
        """Resolve a missing type/subtype without exposing document values."""

        tenant = tenant_id.strip()
        task = task_id.strip()
        if not tenant or not task:
            raise ValueError("tenant_id and task_id are required")
        signature = self.signature_builder(
            evidence,
            source_kind,
            contract_revision=contract_revision,
        )
        current_valid = _classification_input_valid(
            current_document_type,
            current_document_subtype,
        )
        current_type, current_subtype = _classification(
            current_document_type,
            current_document_subtype,
        )
        hint_decision = self._explicit_hint_decision(
            signature,
            current_type=current_type,
            current_subtype=current_subtype,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
        )

        if hint_decision is not None:
            return hint_decision

        raw_type = _known(current_document_type)
        raw_subtype = _known(current_document_subtype)
        if not current_valid or ((raw_type or raw_subtype) and current_type is None):
            return self._decision(
                action="review",
                reason="existing_classification_invalid_or_inconsistent",
                signature=signature,
            )
        if current_subtype is not None and not raw_type:
            return self._decision(
                action="existing_fact",
                reason="subtype_implies_canonical_type",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                applied_fields=("document_type",),
            )
        if current_type is not None and current_subtype is not None:
            return self._decision(
                action="existing_fact",
                reason="existing_classification_locked",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
            )

        fingerprint = signature.exact_fingerprint()
        exact = await self.store.get_active_route_profile_by_fingerprint(
            tenant, fingerprint
        )
        if exact is not None:
            if exact.tenant_id != tenant:
                return self._decision(
                    action="review",
                    reason="profile_tenant_scope_violation",
                    signature=signature,
                    document_type=current_type,
                    document_subtype=current_subtype,
                )
            policy = typed_policy(exact)
            if policy is None:
                return self._decision(
                    action="review",
                    reason="invalid_active_profile_policy",
                    signature=signature,
                    document_type=current_type,
                    document_subtype=current_subtype,
                )
            if self._profile_is_compatible(
                policy,
                current_type=current_type,
                current_subtype=current_subtype,
            ):
                score = DocumentRouteCandidateScore(
                    route_id=exact.profile_id,
                    signature=exact.signature,
                    exact_fingerprint=True,
                    structure_similarity=1.0,
                    label_similarity=1.0,
                    vector_similarity=1.0,
                    fused_score=1.0,
                )
                selected = _ResolvedCandidate(exact, policy, score)
                candidates = self._model_candidates((selected,))
                return self._selected_profile_decision(
                    signature=signature,
                    selected=selected,
                    current_type=current_type,
                    current_subtype=current_subtype,
                    reason="exact_active_profile",
                    index=0,
                    candidates=candidates,
                    top_score=1.0,
                    margin=1.0,
                )
            exact_type, _ = _profile_classification(policy)
            return self._decision(
                action="review" if exact_type is not None else "generic",
                reason=(
                    "active_profile_conflicts_existing_fact"
                    if exact_type is not None
                    else "exact_active_profile_is_generic"
                ),
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
            )

        try:
            embedded = await self._embed_signature(signature)
        except Exception:  # noqa: BLE001 - optional retrieval must not block parsing
            embedded = None
        embedding: list[float] | None = None
        identity: EmbeddingSpaceIdentity | None = None
        matches = []
        if embedded is not None:
            embedding, identity = embedded
            matches = await self.store.find_route_profiles(
                tenant,
                embedding,
                embedding_model=identity.model,
                embedding_dimensions=identity.dimensions,
                statuses=(RouteProfileStatus.ACTIVE,),
                min_similarity=-1.0,
                limit=self.top_k,
            )

        profiles: dict[str, tuple[RouteProfileRecord, RouteProfilePolicy]] = {}
        route_candidates = []
        conflict = False
        tenant_scope_violation = False
        for match in matches:
            profile = match.profile
            if profile.tenant_id != tenant:
                tenant_scope_violation = True
                continue
            policy = typed_policy(profile)
            if policy is None or not profile_matches_signature(
                profile.signature, signature, policy
            ):
                continue
            profile_type, _ = _profile_classification(policy)
            if profile_type is None:
                continue
            if not self._profile_is_compatible(
                policy,
                current_type=current_type,
                current_subtype=current_subtype,
            ):
                conflict = True
                continue
            profiles[profile.profile_id] = (profile, policy)
            route_candidates.append(profile.as_candidate())

        if not route_candidates:
            if tenant_scope_violation:
                return self._decision(
                    action="review",
                    reason="profile_tenant_scope_violation",
                    signature=signature,
                    document_type=current_type,
                    document_subtype=current_subtype,
                )
            if conflict:
                return self._decision(
                    action="review",
                    reason="active_profile_conflicts_existing_fact",
                    signature=signature,
                    document_type=current_type,
                    document_subtype=current_subtype,
                )
            return await self._observe_new_candidate(
                tenant_id=tenant,
                task_id=task,
                signature=signature,
                embedding=embedding,
                current_type=current_type,
                current_subtype=current_subtype,
                reason=(
                    "no_active_classification_profiles"
                    if identity is not None
                    else "embedding_unavailable"
                ),
            )

        ranked = self._ranker.rank_candidates(
            signature,
            route_candidates,
            signature_vector=embedding,
        )[: self.top_k]
        resolved = tuple(
            _ResolvedCandidate(
                profiles[item.route_id][0],
                profiles[item.route_id][1],
                item,
            )
            for item in ranked
        )
        candidates = self._model_candidates(resolved)
        top_score, margin = top_metrics(ranked)
        if top_score >= self.auto_min_score and margin >= self.min_margin:
            return self._selected_profile_decision(
                signature=signature,
                selected=resolved[0],
                current_type=current_type,
                current_subtype=current_subtype,
                reason="high_confidence_active_profile",
                index=0,
                candidates=candidates,
                top_score=top_score,
                margin=margin,
            )
        if top_score < self.model_min_score:
            return await self._observe_new_candidate(
                tenant_id=tenant,
                task_id=task,
                signature=signature,
                embedding=embedding,
                current_type=current_type,
                current_subtype=current_subtype,
                reason="active_profiles_below_similarity_threshold",
                candidates=candidates,
                top_score=top_score,
                margin=margin,
            )
        return await self._resolve_with_model(
            tenant_id=tenant,
            task_id=task,
            signature=signature,
            embedding=embedding,
            current_type=current_type,
            current_subtype=current_subtype,
            resolved=resolved,
            candidates=candidates,
            top_score=top_score,
            margin=margin,
        )

    async def _resolve_with_model(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None,
        current_type: RouteDocumentType | None,
        current_subtype: RouteDocumentSubtype | None,
        resolved: Sequence[_ResolvedCandidate],
        candidates: tuple[DocumentClassificationCandidate, ...],
        top_score: float,
        margin: float,
    ) -> DocumentClassificationDecision:
        if self.selector is None:
            return self._decision(
                action="review",
                reason="ambiguous_candidates_without_selector",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                candidates=candidates,
                top_score=top_score,
                margin=margin,
            )
        request = DocumentClassificationSelectionRequest(
            signature=signature,
            current_document_type=current_type,
            current_document_subtype=current_subtype,
            candidates=candidates,
        )
        try:
            raw_choice = await self.selector.select(request)
            choice = DocumentClassificationModelChoice.model_validate(
                raw_choice,
                strict=True,
            )
        except (ValidationError, TypeError, ValueError):
            return self._decision(
                action="review",
                reason="invalid_model_output",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                candidates=candidates,
                top_score=top_score,
                margin=margin,
                model_used=True,
            )

        except Exception:  # noqa: BLE001 - the optional selector fails closed
            return self._decision(
                action="review",
                reason="model_failure",
                signature=signature,
                document_type=current_type,
                document_subtype=current_subtype,
                candidates=candidates,
                top_score=top_score,
                margin=margin,
                model_used=True,
            )

        common = {
            "signature": signature,
            "document_type": current_type,
            "document_subtype": current_subtype,
            "candidates": candidates,
            "top_score": top_score,
            "margin": margin,
            "model_used": True,
            "model_confidence": choice.confidence,
        }
        if choice.action == "generic":
            return self._decision(
                action="generic", reason="model_selected_generic", **common
            )
        if choice.action == "review":
            return self._decision(
                action="review", reason="model_requested_review", **common
            )
        if choice.action == "new_candidate":
            return await self._observe_new_candidate(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                current_type=current_type,
                current_subtype=current_subtype,
                reason="model_requested_new_candidate",
                candidates=candidates,
                top_score=top_score,
                margin=margin,
                model_used=True,
                model_confidence=choice.confidence,
            )

        index = choice.candidate_index
        if index is None or index >= len(resolved):
            reason = "model_candidate_index_out_of_range"

        elif index != 0:
            reason = "model_candidate_not_top_ranked"
        elif choice.confidence < self.model_min_confidence:
            reason = "model_confidence_below_threshold"
        elif resolved[index].score.fused_score < self.model_min_score:
            reason = "candidate_score_below_threshold"
        elif margin < self.min_margin:
            reason = "candidate_margin_below_threshold"
        else:
            reason = ""
        if reason:
            return self._decision(action="review", reason=reason, **common)
        return self._selected_profile_decision(
            signature=signature,
            selected=resolved[index],
            current_type=current_type,
            current_subtype=current_subtype,
            reason="model_selected_active_profile",
            index=index,
            candidates=candidates,
            top_score=top_score,
            margin=margin,
            model_used=True,
            model_confidence=choice.confidence,
        )

    @staticmethod
    def apply(
        document: dict[str, Any],
        decision: DocumentClassificationDecision,
        evidence: DocumentEvidence,
    ) -> dict[str, Any]:
        """Apply only admitted type/subtype fields and attach bounded audit data."""

        result = copy.deepcopy(document)
        extraction = result.setdefault("extraction", {})
        if not isinstance(extraction, dict):
            extraction = {}
            result["extraction"] = extraction
        metadata = extraction.setdefault("metadata", {})
        if not isinstance(metadata, dict):
            metadata = {}
            extraction["metadata"] = metadata
        route_metadata = decision.value_free_dump()
        direct_application_allowed = decision.action == "explicit_hint" or (
            decision.action == "existing_fact"
            and decision.reason == "subtype_implies_canonical_type"
        )
        if decision.applied_fields and not direct_application_allowed:
            # The business mapper has already run. Relabeling its payload without
            # a governed mapper replay would create a false type/content pairing.
            route_metadata["advisory_fields"] = list(decision.applied_fields)
            route_metadata["applied_fields"] = []
            route_metadata["application_status"] = "mapper_replay_required"
        else:
            route_metadata["application_status"] = (
                "applied" if decision.applied_fields else "no_change"
            )
        metadata["classification_routing"] = route_metadata

        field_meta = result.setdefault("field_meta", {})
        if not isinstance(field_meta, dict):
            field_meta = {}
            result["field_meta"] = field_meta
        refs = _classification_source_refs(evidence)

        fields_to_apply = decision.applied_fields if direct_application_allowed else ()
        for field in fields_to_apply:
            if field not in {"document_type", "document_subtype"}:
                continue
            value = getattr(decision, field)
            result[field] = value.value if value is not None else "unknown"
            path = f"$.{field}"
            if decision.action == "explicit_hint":
                field_meta[path] = {
                    "source_refs": [],
                    "confidence": 1.0,
                    "inferred": False,
                    "manual_locked": True,
                    "provenance": "explicit_document_hint",
                }
                continue
            prior = field_meta.get(path)
            prior = copy.deepcopy(prior) if isinstance(prior, dict) else {}
            prior.update(
                {
                    "source_refs": refs,
                    "confidence": max(0.0, min(1.0, decision.top_score)),
                    "inferred": True,
                    "model_mapped": decision.model_used,
                    "route_profile_id": decision.selected_profile_id,
                    "provenance": "active_classification_profile",
                }
            )
            field_meta[path] = prior

        mapper_replay_required = bool(
            decision.applied_fields and not direct_application_allowed
        )

        review_reasons = {
            "explicit_hint_invalid_or_inconsistent",
            "existing_classification_invalid_or_inconsistent",
            "invalid_active_profile_policy",
            "active_profile_conflicts_existing_fact",
            "profile_tenant_scope_violation",
            "ambiguous_candidates_without_selector",
            "invalid_model_output",
            "model_failure",
            "model_requested_review",
            "model_candidate_index_out_of_range",
            "model_candidate_not_top_ranked",
            "model_confidence_below_threshold",
            "candidate_score_below_threshold",
            "candidate_margin_below_threshold",
        }
        if decision.reason in review_reasons or mapper_replay_required:
            issues = result.setdefault("validation_issues", [])
            if not isinstance(issues, list):
                issues = []
                result["validation_issues"] = issues
            issue_code = (
                "DOCUMENT_CLASSIFICATION_ROUTE_REMAP_REQUIRED"
                if mapper_replay_required
                else "DOCUMENT_CLASSIFICATION_ROUTE_REVIEW"
            )
            if not any(
                isinstance(issue, dict)
                and issue.get("code") == issue_code
                and isinstance(issue.get("actual"), dict)
                and issue["actual"].get("reason") == decision.reason
                for issue in issues
            ):
                issues.append(
                    {
                        "code": issue_code,
                        "severity": "warning",
                        "message": (
                            "Classification matched an active profile, but the "
                            "business mapper must be replayed before labels can "
                            "change."
                            if mapper_replay_required
                            else "Classification routing could not safely fill a "
                            "missing taxonomy field."
                        ),
                        "paths": ["$.document_type", "$.document_subtype"],
                        "source_refs": refs,
                        "actual": {"reason": decision.reason},
                        "suggestion": (
                            "Replay the approved closed-registry mapper, then "
                            "validate the rebuilt document."
                            if mapper_replay_required
                            else "Review the classification or activate a "
                            "validated route profile."
                        ),
                    }
                )
            result["needs_review"] = True
        return result


__all__ = [
    "DocumentClassificationCandidate",
    "DocumentClassificationDecision",
    "DocumentClassificationModelChoice",
    "DocumentClassificationRoutingRuntime",
    "DocumentClassificationSelectionRequest",
    "DocumentClassificationSelector",
    "PydanticDocumentClassificationSelector",
]
