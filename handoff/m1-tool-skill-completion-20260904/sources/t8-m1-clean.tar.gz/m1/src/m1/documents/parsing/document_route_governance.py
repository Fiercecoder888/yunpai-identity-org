"""Operational outcomes and explicit approval for governed route profiles."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping
from typing import Literal

from ...knowledge.routing_schema import (
    RouteObservationOutcome,
    RouteObservationRecord,
    RouteProfileRecord,
    RouteProfileStatus,
)
from .document_route_lifecycle import (
    is_specialized_policy,
    task_reference,
    typed_policy,
)
from .document_route_validation import (
    CANDIDATE_VALIDATION_KIND,
    CANDIDATE_VALIDATOR_VERSION,
    candidate_policy_preflight,
    route_policy_digest,
)
from .mineru_authority import authority_document_digest

_SAFE_ERROR_CODE = re.compile(r"^[A-Z][A-Z0-9_]{0,127}$")


class DocumentRouteGovernanceMixin:
    """Mixin for runtimes that expose a route store and status tracker."""

    async def record_outcome(
        self,
        *,
        tenant_id: str,
        task_id: str,
        profile_id: str,
        success: bool,
        latency_ms: int = 0,
        error_code: str = "",
        attempt: int = 0,
    ) -> RouteObservationRecord:
        """Record one final outcome for a policy that was actually applied."""

        return await self._status.track_operation(
            self._record_outcome(
                tenant_id=tenant_id,
                task_id=task_id,
                profile_id=profile_id,
                success=success,
                latency_ms=latency_ms,
                error_code=error_code,
                attempt=attempt,
            )
        )

    async def _record_outcome(
        self,
        *,
        tenant_id: str,
        task_id: str,
        profile_id: str,
        success: bool,
        latency_ms: int,
        error_code: str,
        attempt: int,
    ) -> RouteObservationRecord:
        task_ref = task_reference(tenant_id, task_id)
        if latency_ms < 0:
            raise ValueError("latency_ms must not be negative")
        if attempt < 0:
            raise ValueError("attempt must not be negative")
        normalized_error = error_code.strip().upper()
        if normalized_error and _SAFE_ERROR_CODE.fullmatch(normalized_error) is None:
            raise ValueError("error_code must be a bounded symbolic identifier")
        profile = await self._status.store_call(
            self.store.get_route_profile(tenant_id, profile_id)
        )
        if profile is None:
            raise LookupError(f"route profile not found: {profile_id}")
        if profile.status is not RouteProfileStatus.ACTIVE:
            raise ValueError("runtime route outcomes require an active profile")
        observation = RouteObservationRecord(
            tenant_id=tenant_id,
            profile_id=profile.profile_id,
            idempotency_key=f"route-outcome:{task_ref}:{profile.profile_id}",
            exact_fingerprint=profile.exact_fingerprint,
            outcome=(
                RouteObservationOutcome.SUCCESS
                if success
                else RouteObservationOutcome.FAILURE
            ),
            latency_ms=int(latency_ms),
            error_code="" if success else normalized_error,
            details={
                "runtime": "document_router",
                "kind": "applied_policy_outcome",
                "task_ref": task_ref,
                "attempt": int(attempt),
            },
        )
        return await self._status.store_call(
            self.store.record_route_observation(observation)
        )

    async def record_candidate_validation(
        self,
        *,
        tenant_id: str,
        task_id: str,
        profile_id: str,
        document: Mapping[str, object],
        knowledge_version_id: str,
        decision: Literal["approve", "reject"],
        reviewed_by: str,
        review_note: str,
    ) -> RouteObservationRecord:
        """Persist one explicit, route-specific candidate review sample."""

        return await self._status.track_operation(
            self._record_candidate_validation(
                tenant_id=tenant_id,
                task_id=task_id,
                profile_id=profile_id,
                document=document,
                knowledge_version_id=knowledge_version_id,
                decision=decision,
                reviewed_by=reviewed_by,
                review_note=review_note,
            )
        )

    async def _record_candidate_validation(
        self,
        *,
        tenant_id: str,
        task_id: str,
        profile_id: str,
        document: Mapping[str, object],
        knowledge_version_id: str,
        decision: Literal["approve", "reject"],
        reviewed_by: str,
        review_note: str,
    ) -> RouteObservationRecord:
        task_ref = task_reference(tenant_id, task_id)
        normalized_decision = str(decision).strip().casefold()
        if normalized_decision not in {"approve", "reject"}:
            raise ValueError("candidate validation decision must be approve or reject")
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        version_id = knowledge_version_id.strip()
        if not reviewer or len(reviewer) > 256:
            raise ValueError("reviewed_by must be a bounded non-empty identity")
        if not note or len(note) > 4096:
            raise ValueError("review_note must be bounded and non-empty")
        if not version_id or len(version_id) > 128:
            raise ValueError("knowledge_version_id must be bounded and non-empty")

        profile = await self._status.store_call(
            self.store.get_route_profile(tenant_id, profile_id)
        )
        if profile is None:
            raise LookupError(f"route profile not found: {profile_id}")
        if profile.status is not RouteProfileStatus.CANDIDATE:
            raise ValueError("candidate validation requires a candidate profile")
        if typed_policy(profile) is None:
            raise ValueError("candidate route policy is invalid")

        preflight = candidate_policy_preflight(profile, document)
        approved = normalized_decision == "approve" and preflight.accepted
        check_codes = list(preflight.check_codes)
        if normalized_decision == "reject":
            check_codes.append("ROUTE_POLICY_REVIEW_REJECTED")
        error_code = ""
        if not approved:
            error_code = (
                "ROUTE_POLICY_REVIEW_REJECTED"
                if normalized_decision == "reject"
                else "ROUTE_POLICY_PREFLIGHT_FAILED"
            )
        observation = RouteObservationRecord(
            tenant_id=tenant_id,
            profile_id=profile.profile_id,
            idempotency_key=(
                f"route-policy-validation:{task_ref}:{profile.profile_id}"
            ),
            exact_fingerprint=profile.exact_fingerprint,
            outcome=(
                RouteObservationOutcome.SUCCESS
                if approved
                else RouteObservationOutcome.FAILURE
            ),
            error_code=error_code,
            details={
                "runtime": "document_router",
                "kind": CANDIDATE_VALIDATION_KIND,
                "task_ref": task_ref,
                "policy_digest": preflight.policy_digest,
                "document_digest": authority_document_digest(dict(document)),
                # Keep the binding auditable without persisting an opaque
                # version string that may contain a TaskID or business value.
                "knowledge_version_id": hashlib.sha256(
                    version_id.encode("utf-8")
                ).hexdigest(),
                "validator_version": preflight.validator_version,
                "reviewed_by": reviewer,
                "review_note_sha256": hashlib.sha256(note.encode("utf-8")).hexdigest(),
                "decision": normalized_decision,
                "validation_scope": "classification_and_table_roles",
                "advisory_fields": ["verifier_policy", "authority_policy"],
                "check_codes": list(dict.fromkeys(check_codes)),
            },
        )
        return await self._status.store_call(
            self.store.record_route_observation(observation)
        )

    async def approve_candidate(
        self,
        *,
        tenant_id: str,
        profile_id: str,
        review_approved: bool,
        approved_by: str,
        reviewed_by: str,
        review_note: str = "",
    ) -> RouteProfileRecord:
        """Activate a specialized candidate after explicit validated samples."""

        if review_approved is not True:
            raise ValueError("explicit route review approval is required")
        if not approved_by.strip() or not reviewed_by.strip():
            raise ValueError("approved_by and reviewed_by are required")
        profile = await self._status.store_call(
            self.store.get_route_profile(tenant_id, profile_id)
        )
        if profile is None:
            raise LookupError(f"route profile not found: {profile_id}")
        if profile.status is not RouteProfileStatus.CANDIDATE:
            raise ValueError("only candidate route profiles may be approved")
        policy = typed_policy(profile)
        if policy is None:
            raise ValueError("candidate route policy is invalid")
        if not is_specialized_policy(policy):
            raise ValueError("generic/open-domain route candidates cannot be activated")
        digest = route_policy_digest(policy)
        observations: list[RouteObservationRecord] = []
        offset = 0
        while offset < profile.observation_count:
            page = await self._status.store_call(
                self.store.list_route_observations(
                    tenant_id,
                    profile_id=profile.profile_id,
                    limit=1000,
                    offset=offset,
                )
            )
            if not page:
                raise RuntimeError("candidate route observations could not be read fully")
            observations.extend(page)
            offset += len(page)
        if len(observations) != profile.observation_count:
            raise RuntimeError("candidate route observation count changed during approval")
        successful_tasks: set[str] = set()
        failed_tasks: set[str] = set()
        for observation in observations:
            details = observation.details
            if (
                details.get("kind") != CANDIDATE_VALIDATION_KIND
                or details.get("policy_digest") != digest
                or details.get("validator_version") != CANDIDATE_VALIDATOR_VERSION
            ):
                continue
            task_ref = str(details.get("task_ref") or "").strip()
            if not task_ref:
                continue
            if observation.outcome is RouteObservationOutcome.SUCCESS:
                successful_tasks.add(task_ref)
            else:
                failed_tasks.add(task_ref)
        if failed_tasks:
            raise ValueError("candidate route has failed explicit validation samples")
        if len(successful_tasks) < self.min_activation_samples:
            raise ValueError(
                "candidate route does not meet the successful observation threshold"
            )
        return await self._status.store_call(
            self.store.activate_route_profile(
                tenant_id,
                profile_id,
                approved_by=approved_by,
                reviewed_by=reviewed_by,
                review_note=review_note,
                expected_observation_count=profile.observation_count,
            )
        )


__all__ = ["DocumentRouteGovernanceMixin"]
