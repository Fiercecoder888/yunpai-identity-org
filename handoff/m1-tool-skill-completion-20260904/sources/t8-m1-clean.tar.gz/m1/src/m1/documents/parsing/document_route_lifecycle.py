"""Runtime ports and pure lifecycle helpers for governed document routes."""

from __future__ import annotations

import hashlib
from collections.abc import Sequence
from datetime import datetime
from typing import Protocol

from pydantic import ValidationError

from ...knowledge.routing_schema import (
    RouteObservationRecord,
    RouteProfileMatch,
    RouteProfileRecord,
    RouteProfileStatus,
)
from .adaptive_routing import (
    DocumentRouteCandidateScore,
    DocumentRouteSignature,
)
from .document_route_policy import RouteProfilePolicy, RouteSchemaFamily
from .evidence import DocumentEvidence


class DocumentRouteSignatureBuilder(Protocol):
    def __call__(
        self,
        evidence: DocumentEvidence,
        source_kind: str | None = None,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        contract_revision: str = "m1.document.v2",
    ) -> DocumentRouteSignature: ...


class DocumentRouteStore(Protocol):
    async def get_active_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None: ...

    async def get_latest_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None: ...

    async def find_route_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses: Sequence[RouteProfileStatus | str] = (RouteProfileStatus.ACTIVE,),
        min_similarity: float = 0.0,
        limit: int = 5,
    ) -> list[RouteProfileMatch]: ...

    async def create_route_profile(
        self, record: RouteProfileRecord
    ) -> RouteProfileRecord: ...

    async def get_route_profile(
        self, tenant_id: str, profile_id: str
    ) -> RouteProfileRecord | None: ...

    async def record_route_observation(
        self, record: RouteObservationRecord
    ) -> RouteObservationRecord: ...

    async def list_route_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[RouteObservationRecord]: ...

    async def activate_route_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str | None = None,
        review_note: str = "",
        approved_at: datetime | None = None,
        expected_observation_count: int | None = None,
    ) -> RouteProfileRecord: ...


def default_signature_builder(
    evidence: DocumentEvidence,
    source_kind: str | None = None,
    *,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    contract_revision: str = "m1.document.v2",
) -> DocumentRouteSignature:
    from .adaptive_routing import build_document_route_signature

    return build_document_route_signature(
        evidence,
        source_kind,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
        contract_revision=contract_revision,
    )


def top_metrics(
    ranked: Sequence[DocumentRouteCandidateScore],
) -> tuple[float, float]:
    if not ranked:
        return 0.0, 0.0
    top = ranked[0].fused_score
    second = ranked[1].fused_score if len(ranked) > 1 else 0.0
    return top, round(max(0.0, min(1.0, float(top - second))), 6)


def task_reference(tenant_id: str, task_id: str) -> str:
    tenant = tenant_id.strip()
    task = task_id.strip()
    if not tenant or not task:
        raise ValueError("tenant_id and task_id are required")
    return hashlib.sha256(f"{tenant}\0{task}".encode()).hexdigest()


def profile_identity(
    tenant_id: str, fingerprint: str, version: int
) -> tuple[str, str]:
    if version < 1:
        raise ValueError("route profile version must be positive")
    tenant_scope = hashlib.sha256(tenant_id.strip().encode("utf-8")).hexdigest()[:16]
    return (
        f"route-{tenant_scope}-{fingerprint[:32]}-v{version}",
        f"layout-{fingerprint[:32]}",
    )


def is_specialized_policy(policy: RouteProfilePolicy) -> bool:
    return policy.schema_family not in {
        RouteSchemaFamily.GENERIC_LAYOUT,
        RouteSchemaFamily.OPEN_DOMAIN,
    }


def policy_matches_signature(
    policy: RouteProfilePolicy,
    signature: DocumentRouteSignature,
) -> bool:
    table_indexes = {shape.table_index for shape in signature.table_shapes}
    if not all(item.table_index in table_indexes for item in policy.table_roles):
        return False
    allowed_backends = {
        "fixed_page": {
            "auto",
            "mineru",
            "native",
            "pp_structure_v3",
            "paddleocr_vl",
            "generic",
        },
        "image": {
            "auto",
            "mineru",
            "native",
            "pp_structure_v3",
            "paddleocr_vl",
            "generic",
        },
        "spreadsheet": {"auto", "spreadsheet", "mineru", "native", "generic"},
        "word_processing": {"auto", "native", "docling", "mineru", "generic"},
        "presentation": {"auto", "docling", "mineru", "generic"},
        "web": {"auto", "docling", "mineru", "generic"},
        "cad": {"auto", "native", "mineru", "generic"},
        "archive": {"auto", "mineru", "generic"},
        "unknown": {"auto", "generic"},
    }[signature.format_family]
    return all(backend in allowed_backends for backend in policy.backend_chain)


def profile_matches_signature(
    profile_signature: DocumentRouteSignature,
    current_signature: DocumentRouteSignature,
    policy: RouteProfilePolicy,
) -> bool:
    """Apply hard compatibility gates before approximate route reuse."""

    if not policy_matches_signature(policy, current_signature):
        return False
    profile_compat = {
        token
        for token in profile_signature.layout_tokens
        if token.startswith("compat:")
    }
    current_compat = {
        token
        for token in current_signature.layout_tokens
        if token.startswith("compat:")
    }
    if profile_compat != current_compat:
        return False

    profile_shapes = {
        shape.table_index: shape for shape in profile_signature.table_shapes
    }
    current_shapes = {
        shape.table_index: shape for shape in current_signature.table_shapes
    }
    for table_policy in policy.table_roles:
        reference = profile_shapes.get(table_policy.table_index)
        current = current_shapes.get(table_policy.table_index)
        if reference is None or current is None:
            return False
        if table_policy.role.value in {"layout", "ignore"}:
            continue
        if reference.column_count != current.column_count:
            return False
        if (
            reference.orientation != "unknown"
            and current.orientation != "unknown"
            and reference.orientation != current.orientation
        ):
            return False
        if (
            reference.semantic_topology_digest is not None
            and current.semantic_topology_digest is not None
            and reference.semantic_topology_digest
            != current.semantic_topology_digest
        ):
            return False
    return True


def typed_policy(profile: RouteProfileRecord) -> RouteProfilePolicy | None:
    try:
        policy = RouteProfilePolicy.model_validate(profile.policy)
    except (TypeError, ValueError, ValidationError):
        return None
    return policy if policy_matches_signature(policy, profile.signature) else None


def deterministic_reuse_allowed(
    signature: DocumentRouteSignature,
    policy: RouteProfilePolicy,
) -> bool:
    return (
        len(signature.label_tokens) >= 2
        or policy.schema_family is RouteSchemaFamily.GENERIC_LAYOUT
    )


__all__ = [
    "DocumentRouteSignatureBuilder",
    "DocumentRouteStore",
    "default_signature_builder",
    "deterministic_reuse_allowed",
    "is_specialized_policy",
    "policy_matches_signature",
    "profile_identity",
    "profile_matches_signature",
    "task_reference",
    "top_metrics",
    "typed_policy",
]
