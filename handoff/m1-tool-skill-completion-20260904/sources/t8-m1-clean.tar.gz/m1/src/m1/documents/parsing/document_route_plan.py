"""Value-free execution plans for adaptive document routing.

The existing route resolver intentionally decides only whether a known layout
may be reused.  This module gives downstream stages one typed, bounded object
to consume when that decision is made.  A plan contains structural policy and
backend identities only; source text, extracted values, tenant identifiers and
task identifiers are never accepted by the models here.
"""

from __future__ import annotations

from collections.abc import Sequence
from enum import StrEnum
from typing import TYPE_CHECKING, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .adaptive_routing import RouteAction
from .document_route_policy import (
    RouteAuthorityPolicy,
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTablePolicy,
    RouteVerifierPolicy,
    RouteVisualPolicy,
    RoutingMode,
    RoutingRuntimeReason,
)

if TYPE_CHECKING:
    from .document_route_policy import DocumentRoutingResolution


class RouteBackend(StrEnum):
    """Closed backend vocabulary exposed to downstream route consumers."""

    AUTO = "auto"
    MINERU = "mineru"
    NATIVE = "native"
    SPREADSHEET = "spreadsheet"
    DOCLING = "docling"
    PP_STRUCTURE_V3 = "pp_structure_v3"
    PADDLEOCR_VL = "paddleocr_vl"
    GENERIC = "generic"


RouteTargetRole = Literal["primary", "fallback", "supplement"]
RouteTargetRevision = str


# These are execution ceilings, not model configuration.  A route profile may
# supply a lower per-target ceiling through ``RouteTarget.timeout_seconds``;
# the executor also honours a backend's own stricter runtime timeout.  Keeping
# concrete values in the plan makes an approved route replayable and prevents
# a newly added backend from silently inheriting an unbounded request.
_DEFAULT_TARGET_TIMEOUT_SECONDS: dict[RouteBackend, float] = {
    RouteBackend.AUTO: 120.0,
    RouteBackend.MINERU: 600.0,
    RouteBackend.NATIVE: 120.0,
    RouteBackend.SPREADSHEET: 120.0,
    RouteBackend.DOCLING: 120.0,
    RouteBackend.PP_STRUCTURE_V3: 120.0,
    RouteBackend.PADDLEOCR_VL: 600.0,
    RouteBackend.GENERIC: 30.0,
}


def default_target_timeout(backend: RouteBackend | str) -> float:
    """Return the bounded default ceiling for one closed backend name."""

    normalized = backend if isinstance(backend, RouteBackend) else RouteBackend(backend)
    return _DEFAULT_TARGET_TIMEOUT_SECONDS[normalized]


class RouteTarget(BaseModel):
    """One bounded backend target in a primary/fallback execution chain."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    backend: RouteBackend
    role: RouteTargetRole = "primary"
    revision: RouteTargetRevision = Field(
        default="m1.route-parser.v1",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    timeout_seconds: float | None = Field(default=None, gt=0.0, le=900.0)

    @field_validator("backend", mode="before")
    @classmethod
    def normalize_backend(cls, value: object) -> object:
        if isinstance(value, RouteBackend):
            return value
        if isinstance(value, str):
            return RouteBackend(value.strip().casefold())
        return value


class DocumentRoutePlan(BaseModel):
    """A complete, value-free plan shared by parser and model stages."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.route-plan.v1"] = "m1.route-plan.v1"
    mode: RoutingMode
    recommendation: RouteAction
    reason: RoutingRuntimeReason
    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    route_id: str | None = Field(
        default=None,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    candidate_profile_id: str | None = Field(
        default=None,
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    backend_chain: tuple[RouteTarget, ...] = Field(min_length=1, max_length=8)
    schema_family: RouteSchemaFamily = RouteSchemaFamily.GENERIC_LAYOUT
    document_type_hint: RouteDocumentType | None = None
    document_subtype_hint: RouteDocumentSubtype | None = None
    table_roles: tuple[RouteTablePolicy, ...] = ()
    verifier_policy: RouteVerifierPolicy = RouteVerifierPolicy.ON_UNCERTAINTY
    visual_policy: Literal["disabled", "on_uncertainty", "always"] = (
        "on_uncertainty"
    )
    authority_policy: RouteAuthorityPolicy = RouteAuthorityPolicy.EVIDENCE_REQUIRED
    contract_revision: str = Field(
        default="m1.document.v2",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    parser_revision: str = Field(
        default="m1.route-parser.v1",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    model_used: bool = False
    policy_applied: bool = False

    @field_validator("signature_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.strip().casefold()

    @field_validator("backend_chain", mode="before")
    @classmethod
    def normalize_backend_chain(cls, value: object) -> object:
        """Accept concise backend names while retaining typed targets."""

        if isinstance(value, (str, RouteBackend, RouteTarget)):
            return (value,)
        if not isinstance(value, Sequence) or isinstance(value, (bytes, bytearray)):
            return value
        normalized: list[object] = []
        for index, item in enumerate(value):
            if isinstance(item, (str, RouteBackend)):
                normalized.append(
                    RouteTarget(
                        backend=item,
                        role="primary" if index == 0 else "fallback",
                    )
                )
            else:
                normalized.append(item)
        return tuple(normalized)

    @field_validator("table_roles", mode="before")
    @classmethod
    def normalize_table_roles(cls, value: object) -> object:
        if value is None:
            return ()
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            return tuple(value)
        return value

    @model_validator(mode="after")
    def validate_plan(self) -> Self:
        primaries = [
            target for target in self.backend_chain if target.role == "primary"
        ]
        if len(primaries) != 1 or self.backend_chain[0].role != "primary":
            raise ValueError("backend chain must begin with exactly one primary target")
        if self.recommendation == "reuse" and self.route_id is None:
            raise ValueError("reuse plans require route_id")
        if self.recommendation != "reuse" and self.route_id is not None:
            raise ValueError("only reuse plans may include route_id")
        if self.policy_applied:
            if self.mode != "guarded" or self.recommendation != "reuse":
                raise ValueError("only guarded reuse plans may apply policy")
            if self.route_id is None:
                raise ValueError("an applied policy requires route_id")
        indexes = [item.table_index for item in self.table_roles]
        if len(indexes) != len(set(indexes)):
            raise ValueError("route table indexes must be unique")
        if tuple(indexes) != tuple(sorted(indexes)):
            raise ValueError("route table policies must be ordered by table_index")
        if self.document_subtype_hint is not None:
            if self.document_type_hint is None:
                raise ValueError("document subtype hint requires document type hint")
            # RouteProfilePolicy owns the canonical subtype/type mapping.  Use
            # its validation here without retaining a second mapping table.
            RouteProfilePolicy(
                schema_family=self.schema_family,
                document_type_hint=self.document_type_hint,
                document_subtype_hint=self.document_subtype_hint,
                table_roles=self.table_roles,
                verifier_policy=self.verifier_policy,
                authority_policy=self.authority_policy,
            )
        return self

    @classmethod
    def from_resolution(
        cls,
        resolution: DocumentRoutingResolution,
        *,
        policy: RouteProfilePolicy | None = None,
        backend_chain: Sequence[RouteTarget | RouteBackend | str] | None = None,
        contract_revision: str | None = None,
        parser_revision: str | None = None,
        visual_policy: RouteVisualPolicy | None = None,
    ) -> DocumentRoutePlan:
        """Convert an existing resolution without changing its public shape."""

        selected = policy or resolution.applied_policy or RouteProfilePolicy()
        route_id = resolution.applied_profile_id or resolution.recommended_profile_id
        effective_parser_revision = parser_revision or selected.parser_revision
        raw_chain = tuple(backend_chain or selected.backend_chain)
        chain = tuple(
            item
            if isinstance(item, RouteTarget)
            else RouteTarget(
                backend=item,
                role="primary" if index == 0 else "fallback",
                revision=effective_parser_revision,
                timeout_seconds=default_target_timeout(item),
            )
            for index, item in enumerate(raw_chain)
        )
        return cls(
            mode=resolution.mode,
            recommendation=resolution.recommendation,
            reason=resolution.reason,
            signature_fingerprint=resolution.signature_fingerprint,
            route_id=route_id,
            candidate_profile_id=resolution.candidate_profile_id,
            backend_chain=tuple(chain),
            schema_family=selected.schema_family,
            document_type_hint=selected.document_type_hint,
            document_subtype_hint=selected.document_subtype_hint,
            table_roles=selected.table_roles,
            verifier_policy=selected.verifier_policy,
            visual_policy=(
                visual_policy if visual_policy is not None else selected.visual_policy
            ),
            authority_policy=selected.authority_policy,
            contract_revision=contract_revision or selected.contract_revision,
            parser_revision=effective_parser_revision,
            model_used=resolution.model_used,
            policy_applied=resolution.applied_policy is not None,
        )

    def policy_context(self) -> dict[str, object]:
        """Return the legacy Instructor context subset, without plan metadata."""

        return {
            "schema_family": self.schema_family.value,
            "document_type_hint": (
                self.document_type_hint.value
                if self.document_type_hint is not None
                else None
            ),
            "document_subtype_hint": (
                self.document_subtype_hint.value
                if self.document_subtype_hint is not None
                else None
            ),
            "table_roles": [
                {
                    "table_index": item.table_index,
                    "role": item.role.value,
                }
                for item in self.table_roles
            ],
            "verifier_policy": self.verifier_policy.value,
            "authority_policy": self.authority_policy.value,
        }

    def value_free_dump(self) -> dict[str, object]:
        """Serialize the plan for metadata/audit consumers."""

        payload = self.model_dump(mode="json", exclude_none=True)
        for target in payload.get("backend_chain", []):
            if not isinstance(target, dict):
                continue
            backend = str(target.get("backend") or "generic")
            if target.get("timeout_seconds") == default_target_timeout(backend):
                # Preserve the v1 metadata shape for default ceilings. The
                # executor restores the same backend-specific default when the
                # field is absent; only explicit overrides need serialization.
                target.pop("timeout_seconds", None)
        return payload

    def visual_enabled(self, *, configured: bool, uncertain: bool) -> bool:
        """Apply the guarded visual policy without enabling a disabled service."""

        if not configured or not self.policy_applied:
            return configured
        if self.visual_policy == "disabled":
            return False
        if self.visual_policy == "always":
            return True
        return uncertain


__all__ = [
    "DocumentRoutePlan",
    "RouteBackend",
    "RouteTarget",
    "RouteTargetRole",
    "default_target_timeout",
]
