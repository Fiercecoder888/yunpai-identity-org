"""Closed policy models for governed adaptive document routing.

Only canonical structure, semantic label names, and typed policy enums belong
in this module. Policies never contain document text, filenames, business
values, tenant IDs, task IDs, field maps, JSONPath, regexes, or executable code.
"""

from __future__ import annotations

from collections.abc import Mapping
from enum import StrEnum
from typing import Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .adaptive_routing import DocumentRouteSignature, RouteAction

RoutingMode = Literal["shadow", "guarded"]
RouteBackendName = Literal[
    "auto",
    "mineru",
    "native",
    "spreadsheet",
    "docling",
    "pp_structure_v3",
    "paddleocr_vl",
    "generic",
]
RouteVisualPolicy = Literal["disabled", "on_uncertainty", "always"]
RoutingRuntimeReason = Literal[
    "exact_fingerprint",
    "exact_requires_model",
    "vector_auto_reuse",
    "model_reuse",
    "model_generic",
    "model_propose",
    "model_unavailable",
    "model_failure",
    "invalid_model_output",
    "model_confidence_below_threshold",
    "model_candidate_below_threshold",
    "embedding_unavailable",
    "embedding_failure",
    "no_active_profiles",
    "score_below_threshold",
    "invalid_active_policy",
    "policy_proposed",
    "policy_proposal_generic",
    "policy_proposal_low_confidence",
    "policy_proposal_invalid",
    "policy_proposal_failure",
    "policy_proposal_conflict",
]


class RouteSchemaFamily(StrEnum):
    """Closed set of schema families that a reusable route may select."""

    GENERIC_LAYOUT = "generic_layout"
    OPEN_DOMAIN = "open_domain"
    ORDER = "order"
    INVENTORY = "inventory"
    EQUIPMENT = "equipment"
    MOLD = "mold"
    PROCUREMENT = "procurement"
    TECHNICAL = "technical"
    ARCHIVE = "archive"


class RouteDocumentType(StrEnum):
    ORDER = "order"
    INVENTORY = "inventory"
    EQUIPMENT = "equipment"
    MOLD = "mold"
    PROCUREMENT = "procurement"
    TECHNICAL_DOCUMENT = "technical_document"
    ARCHIVE = "archive"


class RouteDocumentSubtype(StrEnum):
    STOCKING_ORDER = "stocking_order"
    CUSTOMER_PURCHASE_ORDER = "customer_purchase_order"
    PURCHASE_CONTRACT = "purchase_contract"
    SUPPLIER_PURCHASE_ORDER = "supplier_purchase_order"
    SAMPLE_REQUEST = "sample_request"
    INVENTORY_SNAPSHOT = "inventory_snapshot"
    EQUIPMENT_REGISTER = "equipment_register"
    MOLD_MAPPING = "mold_mapping"
    PURCHASE_RECEIPT_LEDGER = "purchase_receipt_ledger"
    PURCHASE_REQUISITION_LEDGER = "purchase_requisition_ledger"
    PURCHASE_ORDER_LEDGER = "purchase_order_ledger"
    APPROVAL_DRAWING = "approval_drawing"
    ENGINEERING_DRAWING = "engineering_drawing"
    PRODUCT_SPECIFICATION = "product_specification"
    PROCESS_DOCUMENT = "process_document"
    SERVICE_POLICY = "service_policy"
    PRODUCT_PHOTO = "product_photo"
    PRESENTATION = "presentation"
    WEB_DOCUMENT = "web_document"
    IMAGE_DOCUMENT = "image_document"
    ARCHIVE = "archive"


class RouteTableRole(StrEnum):
    KEY_VALUE = "key_value"
    REPEATED_RECORDS = "repeated_records"
    LAYOUT = "layout"
    TITLE_BLOCK = "title_block"
    BOM = "bom"
    ORDER_LINES = "order_lines"
    INVENTORY_LINES = "inventory_lines"
    EQUIPMENT_LINES = "equipment_lines"
    MOLD_MAPPING = "mold_mapping"
    IGNORE = "ignore"


class RouteVerifierPolicy(StrEnum):
    DISABLED = "disabled"
    ON_UNCERTAINTY = "on_uncertainty"
    ALWAYS = "always"


class RouteAuthorityPolicy(StrEnum):
    CORE_STRICT = "core_strict"
    EVIDENCE_REQUIRED = "evidence_required"
    OPEN_DOMAIN = "open_domain"


_SUBTYPE_TYPES: dict[RouteDocumentSubtype, RouteDocumentType] = {
    RouteDocumentSubtype.STOCKING_ORDER: RouteDocumentType.ORDER,
    RouteDocumentSubtype.CUSTOMER_PURCHASE_ORDER: RouteDocumentType.ORDER,
    RouteDocumentSubtype.PURCHASE_CONTRACT: RouteDocumentType.ORDER,
    RouteDocumentSubtype.SUPPLIER_PURCHASE_ORDER: RouteDocumentType.ORDER,
    RouteDocumentSubtype.SAMPLE_REQUEST: RouteDocumentType.ORDER,
    RouteDocumentSubtype.INVENTORY_SNAPSHOT: RouteDocumentType.INVENTORY,
    RouteDocumentSubtype.EQUIPMENT_REGISTER: RouteDocumentType.EQUIPMENT,
    RouteDocumentSubtype.MOLD_MAPPING: RouteDocumentType.MOLD,
    RouteDocumentSubtype.PURCHASE_RECEIPT_LEDGER: RouteDocumentType.PROCUREMENT,
    RouteDocumentSubtype.PURCHASE_REQUISITION_LEDGER: RouteDocumentType.PROCUREMENT,
    RouteDocumentSubtype.PURCHASE_ORDER_LEDGER: RouteDocumentType.PROCUREMENT,
    RouteDocumentSubtype.APPROVAL_DRAWING: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.ENGINEERING_DRAWING: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.PRODUCT_SPECIFICATION: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.PROCESS_DOCUMENT: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.SERVICE_POLICY: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.PRODUCT_PHOTO: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.PRESENTATION: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.WEB_DOCUMENT: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.IMAGE_DOCUMENT: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteDocumentSubtype.ARCHIVE: RouteDocumentType.ARCHIVE,
}
_FAMILY_TYPES: dict[RouteSchemaFamily, RouteDocumentType] = {
    RouteSchemaFamily.ORDER: RouteDocumentType.ORDER,
    RouteSchemaFamily.INVENTORY: RouteDocumentType.INVENTORY,
    RouteSchemaFamily.EQUIPMENT: RouteDocumentType.EQUIPMENT,
    RouteSchemaFamily.MOLD: RouteDocumentType.MOLD,
    RouteSchemaFamily.PROCUREMENT: RouteDocumentType.PROCUREMENT,
    RouteSchemaFamily.TECHNICAL: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteSchemaFamily.ARCHIVE: RouteDocumentType.ARCHIVE,
}


class RouteTablePolicy(BaseModel):
    """Typed role for a table position; no heading or cell value is retained."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    table_index: int = Field(ge=0, le=4095)
    role: RouteTableRole


class RouteProfilePolicy(BaseModel):
    """Closed reusable policy persisted with one governed route profile."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_family: RouteSchemaFamily = RouteSchemaFamily.GENERIC_LAYOUT
    document_type_hint: RouteDocumentType | None = None
    document_subtype_hint: RouteDocumentSubtype | None = None
    table_roles: tuple[RouteTablePolicy, ...] = ()
    backend_chain: tuple[RouteBackendName, ...] = ("auto",)
    verifier_policy: RouteVerifierPolicy = RouteVerifierPolicy.ON_UNCERTAINTY
    visual_policy: RouteVisualPolicy = "on_uncertainty"
    authority_policy: RouteAuthorityPolicy = RouteAuthorityPolicy.EVIDENCE_REQUIRED
    contract_revision: str = Field(
        default="m1.document.v2",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )
    parser_revision: str = Field(
        default="m1.route-parser.v1",
        min_length=1,
        max_length=128,
        pattern=r"^[A-Za-z0-9_.:-]+$",
    )

    @field_validator("backend_chain")
    @classmethod
    def validate_backend_chain(
        cls, value: tuple[RouteBackendName, ...]
    ) -> tuple[RouteBackendName, ...]:
        normalized = tuple(str(item).strip().casefold() for item in value)
        if not normalized:
            raise ValueError("route backend chain must not be empty")
        if len(normalized) > 8:
            raise ValueError("route backend chain accepts at most eight targets")
        if len(normalized) != len(set(normalized)):
            raise ValueError("route backend chain targets must be unique")
        if "auto" in normalized and len(normalized) != 1:
            raise ValueError("auto backend cannot be combined with explicit targets")
        return normalized  # type: ignore[return-value]

    @model_validator(mode="after")
    def validate_policy(self) -> Self:
        indexes = [item.table_index for item in self.table_roles]
        if len(indexes) != len(set(indexes)):
            raise ValueError("route table indexes must be unique")
        if tuple(indexes) != tuple(sorted(indexes)):
            raise ValueError("route table policies must be ordered by table_index")
        if self.document_subtype_hint is not None:
            expected = _SUBTYPE_TYPES[self.document_subtype_hint]
            if self.document_type_hint is None:
                raise ValueError(
                    "a document subtype hint requires a document type hint"
                )
            if self.document_type_hint is not expected:
                raise ValueError("document type and subtype hints are inconsistent")
        expected_type = _FAMILY_TYPES.get(self.schema_family)
        if expected_type is not None and self.document_type_hint is not expected_type:
            raise ValueError(
                "a specialized schema family requires its matching document type hint"
            )
        if self.schema_family in {
            RouteSchemaFamily.GENERIC_LAYOUT,
            RouteSchemaFamily.OPEN_DOMAIN,
        } and (
            self.document_type_hint is not None
            or self.document_subtype_hint is not None
        ):
            raise ValueError("generic/open-domain policies cannot lock document hints")
        return self


class DocumentRoutePolicyProposal(BaseModel):
    """Strict small-model output for a new, still-inactive route candidate."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    policy: RouteProfilePolicy
    confidence: float = Field(ge=0.0, le=1.0)


class DocumentRoutePolicyProposer(Protocol):
    async def propose(
        self, signature: DocumentRouteSignature
    ) -> DocumentRoutePolicyProposal | Mapping[str, object]: ...


class StructuredPolicyRun(Protocol):
    output: object


class StructuredPolicyClient(Protocol):
    async def run(
        self,
        output_type: type[DocumentRoutePolicyProposal],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> StructuredPolicyRun: ...


class PydanticDocumentRoutePolicyProposer:
    """Propose only a closed policy from a value-free route signature."""

    _INSTRUCTIONS = (
        "Propose a reusable document route policy using only the supplied "
        "value-free structural signature and canonical semantic label names. "
        "Choose only values admitted by the output schema. Table roles may "
        "reference only table_index values present in the signature. Never emit "
        "field maps, JSONPath, source text, identifiers, regexes, code, or extra "
        "keys. Select a backend chain compatible with the signature format; use "
        "auto when the evidence cannot justify an explicit backend. Use "
        "generic_layout when the evidence cannot justify a specialized schema "
        "family."
    )

    def __init__(self, client: StructuredPolicyClient) -> None:
        self._client = client

    async def propose(
        self, signature: DocumentRouteSignature
    ) -> DocumentRoutePolicyProposal:
        run = await self._client.run(
            DocumentRoutePolicyProposal,
            instructions=self._INSTRUCTIONS,
            prompt=signature.model_dump_json(),
            request_limit=1,
        )
        return DocumentRoutePolicyProposal.model_validate(run.output)


class DocumentRoutingResolution(BaseModel):
    """Auditable routing recommendation and the optional guarded application."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    mode: RoutingMode
    recommendation: RouteAction
    reason: RoutingRuntimeReason
    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    recommended_profile_id: str | None = None
    applied_profile_id: str | None = None
    applied_policy: RouteProfilePolicy | None = None
    candidate_profile_id: str | None = None
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    top1_top2_margin: float = Field(default=0.0, ge=0.0, le=1.0)
    model_used: bool = False
    proposal_applied: bool = False
    proposal_schema_family: RouteSchemaFamily | None = None

    def to_route_plan(
        self,
        *,
        policy: RouteProfilePolicy | None = None,
        backend_chain=None,
        contract_revision: str | None = None,
        parser_revision: str | None = None,
        visual_policy: RouteVisualPolicy | None = None,
    ):
        """Convert this resolution to the bounded downstream route plan.

        The import is intentionally local: ``document_route_plan`` reuses the
        closed policy models above, while keeping this legacy resolution model
        import-compatible for callers that do not use plans yet.
        """

        from .document_route_plan import DocumentRoutePlan

        return DocumentRoutePlan.from_resolution(
            self,
            policy=policy,
            backend_chain=backend_chain,
            contract_revision=contract_revision,
            parser_revision=parser_revision,
            visual_policy=visual_policy,
        )

    @model_validator(mode="after")
    def validate_resolution(self) -> Self:
        if self.recommendation == "reuse" and self.recommended_profile_id is None:
            raise ValueError("reuse requires a recommended profile")
        if self.recommendation != "reuse" and self.recommended_profile_id is not None:
            raise ValueError("only reuse may recommend a profile")
        if self.applied_profile_id is None and self.applied_policy is not None:
            raise ValueError("an applied policy requires an applied profile")
        if self.applied_profile_id is not None:
            if self.mode != "guarded" or self.recommendation != "reuse":
                raise ValueError("only guarded reuse may expose an applied profile")
            if self.applied_policy is None:
                raise ValueError("an applied profile requires a typed policy")
        if self.proposal_applied:
            if self.recommendation != "propose" or self.candidate_profile_id is None:
                raise ValueError("an applied proposal requires a candidate recommendation")
            if self.proposal_schema_family is None:
                raise ValueError("an applied proposal requires a schema-family summary")
        elif self.proposal_schema_family is not None:
            raise ValueError("a schema-family proposal summary requires an applied proposal")
        return self


def default_candidate_policy(signature: DocumentRouteSignature) -> RouteProfilePolicy:
    """Build the value-free fallback policy for a previously unseen layout."""

    table_roles: list[RouteTablePolicy] = []
    for shape in signature.table_shapes:
        if shape.orientation == "records_by_row":
            role = RouteTableRole.REPEATED_RECORDS
        elif shape.orientation == "records_by_column":
            role = RouteTableRole.KEY_VALUE
        else:
            role = RouteTableRole.LAYOUT
        table_roles.append(RouteTablePolicy(table_index=shape.table_index, role=role))
    backend_chain: tuple[RouteBackendName, ...]
    if signature.format_family == "spreadsheet":
        backend_chain = ("spreadsheet", "mineru")
    elif signature.format_family == "word_processing":
        backend_chain = ("native", "docling", "mineru")
    elif signature.format_family in {"presentation", "web"}:
        backend_chain = ("docling", "mineru")
    elif signature.format_family in {"fixed_page", "image"}:
        backend_chain = ("mineru", "pp_structure_v3", "native")
    elif signature.format_family == "cad":
        backend_chain = ("native", "mineru")
    else:
        backend_chain = ("generic",)
    return RouteProfilePolicy(
        table_roles=tuple(table_roles),
        backend_chain=backend_chain,
    )


__all__ = [
    "DocumentRoutePolicyProposal",
    "DocumentRoutePolicyProposer",
    "DocumentRoutingResolution",
    "PydanticDocumentRoutePolicyProposer",
    "RouteAuthorityPolicy",
    "RouteBackendName",
    "RouteDocumentSubtype",
    "RouteDocumentType",
    "RouteProfilePolicy",
    "RouteSchemaFamily",
    "RouteTablePolicy",
    "RouteTableRole",
    "RouteVerifierPolicy",
    "RouteVisualPolicy",
    "RoutingMode",
    "RoutingRuntimeReason",
    "StructuredPolicyClient",
    "StructuredPolicyRun",
]


def __getattr__(name: str):
    """Lazily expose the plan type without creating an import cycle."""

    if name == "DocumentRoutePlan":
        from .document_route_plan import DocumentRoutePlan

        return DocumentRoutePlan
    raise AttributeError(name)
