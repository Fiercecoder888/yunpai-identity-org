"""Build bounded, value-free evidence for document route resolution.

Two deliberately separate probe paths live here:

* ``build_route_probe_evidence`` projects an already-built record into a
  value-free signature input.  It remains useful for post-parse observation.
* ``build_source_route_probe`` inspects a source *before* any expensive parser
  or model runs.  It retains only file/container facts, page geometry, text
  layer presence, low-DPI visual structure and table dimensions.  Filenames,
  source text, cell values and identifiers never enter its output.
"""

from __future__ import annotations

import re
import zipfile
from collections.abc import Mapping
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, BinaryIO, Self
from xml.etree import ElementTree

from .evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)

_FIELD_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*$")
_CELL_REFERENCE = re.compile(r"^([A-Z]{1,4})([1-9][0-9]*)$")
_MAX_PROBE_PAGES = 64
_MAX_PROBE_TABLES = 32
_MAX_PROBE_ROWS = 4096
_MAX_PROBE_COLUMNS = 512
_MAX_TEXT_PROBE_BYTES = 4 * 1024 * 1024
_MAX_PROBE_SOURCE_BYTES = 64 * 1024 * 1024
_MAX_PROBE_ZIP_MEMBERS = 256
_MAX_PROBE_COMPRESSED_MEMBER_BYTES = 8 * 1024 * 1024
_MAX_PROBE_UNCOMPRESSED_MEMBER_BYTES = 16 * 1024 * 1024
_MAX_PROBE_TOTAL_UNCOMPRESSED_BYTES = 32 * 1024 * 1024
_MAX_PROBE_PDF_PIXELS = 4_000_000
_PROBE_VERSION = "m1.source-route-probe.v1"


class _ProbeLimitExceeded(RuntimeError):
    """A source is structurally valid but exceeds the route-probe budget."""


class _BoundedReader:
    """Expose a fixed-size readable view without materializing source content."""

    def __init__(
        self,
        stream: BinaryIO,
        *,
        limit: int,
        eof_at_limit: bool = False,
    ) -> None:
        self._stream = stream
        self._remaining = max(0, int(limit))
        self._eof_at_limit = bool(eof_at_limit)

    def read(self, size: int = -1) -> bytes:
        if self._remaining <= 0:
            if self._eof_at_limit:
                return b""
            raise _ProbeLimitExceeded("probe byte budget exhausted")
        requested = self._remaining if size is None or size < 0 else min(size, self._remaining)
        payload = self._stream.read(requested)
        self._remaining -= len(payload)
        return payload

    def close(self) -> None:
        self._stream.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


def _read_prefix(path: Path, *, limit: int) -> bytes:
    """Read at most ``limit`` bytes instead of loading an upload into memory."""

    with path.open("rb") as stream:
        return stream.read(max(0, int(limit)))


def _zip_infos(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    infos = archive.infolist()
    if len(infos) > _MAX_PROBE_ZIP_MEMBERS:
        raise _ProbeLimitExceeded("too many archive members for route probe")
    return infos


def _open_bounded_zip_member(
    archive: zipfile.ZipFile,
    member: str | zipfile.ZipInfo,
    *,
    remaining_total: list[int],
) -> _BoundedReader:
    info = archive.getinfo(member) if isinstance(member, str) else member
    if (
        info.compress_size > _MAX_PROBE_COMPRESSED_MEMBER_BYTES
        or info.file_size > _MAX_PROBE_UNCOMPRESSED_MEMBER_BYTES
        or info.file_size > remaining_total[0]
    ):
        raise _ProbeLimitExceeded("archive member exceeds route-probe budget")
    remaining_total[0] -= max(0, int(info.file_size))
    return _BoundedReader(
        archive.open(info),
        limit=min(_MAX_PROBE_UNCOMPRESSED_MEMBER_BYTES, int(info.file_size)),
        eof_at_limit=info.file_size <= _MAX_PROBE_UNCOMPRESSED_MEMBER_BYTES,
    )


@dataclass(frozen=True, slots=True)
class SourceRouteProbe:
    """The source-only input passed to governed route resolution.

    ``mime_type`` is a magic/container result rather than an upload filename
    hint.  The evidence intentionally contains no source content and is not
    written into a public ``DocumentRecord``.
    """

    evidence: DocumentEvidence
    source_kind: str
    mime_type: str

    def summary(self) -> dict[str, object]:
        return {
            "schema_version": _PROBE_VERSION,
            "source_kind": self.source_kind,
            "mime_type": self.mime_type,
            "page_count": len(self.evidence.pages),
            "table_count": sum(len(page.tables) for page in self.evidence.pages),
        }


def _bounded_dimension(value: int, *, upper: int) -> int:
    return max(1, min(upper, int(value)))


def _empty_table(
    table_id: str,
    *,
    rows: int,
    columns: int,
    source: str,
) -> EvidenceTable:
    """Represent table scale without retaining a single cell value.

    One terminal empty cell is enough for the signature builder to recover the
    dimensions, avoiding allocation of a large matrix for a probe-only table.
    """

    row_count = _bounded_dimension(rows, upper=_MAX_PROBE_ROWS)
    column_count = _bounded_dimension(columns, upper=_MAX_PROBE_COLUMNS)
    return EvidenceTable(
        table_id=table_id,
        cells=[EvidenceCell(row=row_count - 1, column=column_count - 1)],
        source=source,
    )


def _page(
    *,
    number: int,
    width: float = 1.0,
    height: float = 1.0,
    rotation: int = 0,
    blocks: list[EvidenceBlock] | None = None,
    tables: list[EvidenceTable] | None = None,
    route_tokens: set[str] | None = None,
    has_text_layer: bool | None = None,
    coordinate_space: str = "unknown",
) -> EvidencePage:
    raw: dict[str, Any] = {}
    if route_tokens:
        raw["route_structure_tokens"] = sorted(route_tokens)
    if has_text_layer is not None:
        raw["has_text_layer"] = has_text_layer
    return EvidencePage(
        page_number=max(1, int(number)),
        page_index=max(0, int(number) - 1),
        width=max(1.0, float(width)),
        height=max(1.0, float(height)),
        coordinate_space=coordinate_space,  # type: ignore[arg-type]
        rotation=int(rotation) % 360,
        blocks=blocks or [],
        tables=tables or [],
        raw=raw,
    )


def _safe_box(value: Any) -> tuple[float, float, float, float] | None:
    """Return geometry only; provider text and metadata are discarded."""

    if not isinstance(value, (list, tuple)) or len(value) < 4:
        return None
    try:
        x0, y0, x1, y1 = (float(item) for item in value[:4])
    except (TypeError, ValueError):
        return None
    if x1 < x0 or y1 < y0:
        return None
    return x0, y0, x1, y1


def _column_number(reference: str) -> int:
    value = 0
    for character in reference:
        value = value * 26 + ord(character) - ord("A") + 1
    return value


def _cell_position(reference: str) -> tuple[int, int] | None:
    match = _CELL_REFERENCE.fullmatch(reference.upper())
    if match is None:
        return None
    return int(match.group(2)), _column_number(match.group(1))


def _range_dimensions(reference: str) -> tuple[int, int] | None:
    pieces = [item for item in reference.split(":", 1) if item]
    if not pieces:
        return None
    first = _cell_position(pieces[0])
    last = _cell_position(pieces[-1])
    if first is None or last is None:
        return None
    return max(first[0], last[0]), max(first[1], last[1])


def _pdf_vector_grid(page: Any, *, width: float, height: float) -> tuple[int, int] | None:
    """Estimate a grid from vector drawing bounds without inspecting content."""

    try:
        drawings = page.get_drawings()
    except Exception:  # noqa: BLE001 - a probe must not block parsing
        return None
    horizontal: set[int] = set()
    vertical: set[int] = set()
    for drawing in drawings[:2048]:
        if not isinstance(drawing, Mapping):
            continue
        rect = drawing.get("rect")
        try:
            x0, y0, x1, y1 = float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1)
        except Exception:  # noqa: BLE001, S112 - optional PyMuPDF rect variant
            continue
        rect_width = max(0.0, x1 - x0)
        rect_height = max(0.0, y1 - y0)
        if rect_width >= max(8.0, width * 0.10) and rect_height <= max(3.0, height * 0.015):
            horizontal.add(round((y0 + y1) / 2.0))
        if rect_height >= max(8.0, height * 0.10) and rect_width <= max(3.0, width * 0.015):
            vertical.add(round((x0 + x1) / 2.0))
    if len(horizontal) < 3 or len(vertical) < 3:
        return None
    return len(horizontal) - 1, len(vertical) - 1


def _low_dpi_pdf_tokens(page: Any, *, width: float, height: float) -> set[str]:
    """Classify only first-page raster density, never retain pixels or text."""

    rendered_pixels = max(1, int(width * 0.5)) * max(1, int(height * 0.5))
    if rendered_pixels > _MAX_PROBE_PDF_PIXELS:
        return {"pdf:low_dpi_skipped_large"}
    try:
        import fitz

        pixmap = page.get_pixmap(matrix=fitz.Matrix(0.5, 0.5), alpha=False)
        samples = bytes(pixmap.samples)
        channels = max(1, int(pixmap.n))
    except Exception:  # noqa: BLE001 - optional low-DPI inspection
        return set()
    if not samples:
        return set()
    # One byte per sampled pixel channel is sufficient for density; neither
    # original pixels nor a derived bitmap leaves this function.
    stride = max(channels, len(samples) // 8192)
    sampled = samples[::stride]
    if not sampled:
        return set()
    dark = sum(value < 210 for value in sampled) / len(sampled)
    if dark < 0.01:
        return {"pdf:low_dpi_sparse"}
    if dark > 0.22:
        return {"pdf:low_dpi_dense"}
    return {"pdf:low_dpi_ink"}


def _probe_pdf(path: Path) -> list[EvidencePage]:
    """Read PDF geometry, text-layer presence and first-page low-DPI shape."""

    try:
        import fitz

        document = fitz.open(str(path))
        try:
            metadata_present = bool(document.metadata)
            total = min(max(0, len(document)), _MAX_PROBE_PAGES)
            pages: list[EvidencePage] = []
            for index in range(total):
                page = document.load_page(index)
                rect = page.rect
                width = max(1.0, float(rect.width))
                height = max(1.0, float(rect.height))
                tokens = {"pdf:metadata"} if metadata_present else set()
                blocks: list[EvidenceBlock] = []
                text_layer = False
                try:
                    layout = page.get_text("dict")
                    source_blocks = layout.get("blocks") if isinstance(layout, Mapping) else []
                    for block_index, block in enumerate(source_blocks[:256]):
                        if not isinstance(block, Mapping):
                            continue
                        kind = "text" if int(block.get("type", -1)) == 0 else "image"
                        if kind == "text":
                            lines = block.get("lines")
                            text_layer = text_layer or bool(lines)
                        box = _safe_box(block.get("bbox"))
                        blocks.append(
                            EvidenceBlock(
                                block_id=f"probe:{index + 1}:block:{block_index}",
                                kind=kind,
                                text="",
                                bbox=(
                                    None
                                    if box is None
                                    else {
                                        "x0": box[0],
                                        "y0": box[1],
                                        "x1": box[2],
                                        "y1": box[3],
                                        "coordinate_space": "pdf_points",
                                    }
                                ),
                                source="source-route-probe",
                            )
                        )
                except Exception:  # noqa: BLE001, S110 - geometry is sufficient
                    pass
                tokens.add("pdf:text_layer" if text_layer else "pdf:no_text_layer")
                tables: list[EvidenceTable] = []
                grid = _pdf_vector_grid(page, width=width, height=height)
                if grid is not None:
                    tokens.add("pdf:vector_grid")
                    tables.append(
                        _empty_table(
                            f"probe:pdf:{index + 1}:grid",
                            rows=grid[0],
                            columns=grid[1],
                            source="source-route-probe",
                        )
                    )
                    blocks.append(
                        EvidenceBlock(
                            block_id=f"probe:{index + 1}:table",
                            kind="table",
                            text="",
                            source="source-route-probe",
                        )
                    )
                if index == 0:
                    tokens.update(_low_dpi_pdf_tokens(page, width=width, height=height))
                pages.append(
                    _page(
                        number=index + 1,
                        width=width,
                        height=height,
                        rotation=int(page.rotation or 0),
                        blocks=blocks,
                        tables=tables,
                        route_tokens=tokens,
                        has_text_layer=text_layer,
                        coordinate_space="pdf_points",
                    )
                )
            return pages
        finally:
            document.close()
    except Exception:  # noqa: BLE001, S110 - PyMuPDF is optional
        pass

    try:
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        metadata_present = bool(reader.metadata)
        pages = []
        for index, pdf_page in enumerate(reader.pages[:_MAX_PROBE_PAGES]):
            box = pdf_page.mediabox
            width = max(1.0, float(box.width))
            height = max(1.0, float(box.height))
            # The pypdf fallback has no bounded streaming text API.  Treat the
            # text layer as unknown rather than materializing an unbounded page.
            text_layer = False
            tokens = {
                "pdf:metadata" if metadata_present else "pdf:no_text_layer",
                "pdf:text_layer" if text_layer else "pdf:no_text_layer",
            }
            pages.append(
                _page(
                    number=index + 1,
                    width=width,
                    height=height,
                    rotation=int(pdf_page.get("/Rotate", 0) or 0),
                    route_tokens=tokens,
                    has_text_layer=text_layer,
                    coordinate_space="pdf_points",
                )
            )
        return pages
    except Exception:  # noqa: BLE001 - normal parser owns malformed-PDF errors
        return []


def _probe_delimited(path: Path) -> list[EvidencePage]:
    try:
        data = _read_prefix(path, limit=_MAX_TEXT_PROBE_BYTES)
    except OSError:
        return []
    if not data:
        return [_page(number=1, route_tokens={"container:plain", "sheet:unknown"})]
    lines = [line for line in data.splitlines() if line.strip()][:4096]
    candidates = (b",", b"\t", b";", b"|")
    delimiter = max(candidates, key=lambda value: sum(line.count(value) for line in lines[:64]))
    columns = max((line.count(delimiter) + 1 for line in lines), default=1)
    rows = max(1, min(_MAX_PROBE_ROWS, data.count(b"\n") + 1))
    table = _empty_table(
        "probe:delimited:0",
        rows=rows,
        columns=columns,
        source="source-route-probe",
    )
    return [
        _page(
            number=1,
            blocks=[EvidenceBlock(block_id="probe:delimited:table", kind="table", source="source-route-probe")],
            tables=[table],
            route_tokens={"container:plain", "sheet:single", "sheet:tabular"},
        )
    ]


def _zip_members(path: Path) -> set[str]:
    try:
        with zipfile.ZipFile(path) as archive:
            return {info.filename.casefold() for info in _zip_infos(archive)}
    except (OSError, zipfile.BadZipFile, _ProbeLimitExceeded):
        return set()


def _probe_spreadsheet(path: Path) -> list[EvidencePage]:
    try:
        with zipfile.ZipFile(path) as archive:
            infos = _zip_infos(archive)
            remaining_total = [_MAX_PROBE_TOTAL_UNCOMPRESSED_BYTES]
            members = sorted(
                (
                    info
                    for info in infos
                    if info.filename.casefold().startswith("xl/worksheets/sheet")
                    and info.filename.casefold().endswith(".xml")
                ),
                key=lambda info: info.filename.casefold(),
            )[:_MAX_PROBE_TABLES]
            pages: list[EvidencePage] = []
            for index, member in enumerate(members):
                rows = columns = 1
                try:
                    max_row = max_column = 0
                    with _open_bounded_zip_member(
                        archive,
                        member,
                        remaining_total=remaining_total,
                    ) as stream:
                        for _event, element in ElementTree.iterparse(stream, events=("end",)):
                            tag = element.tag.rsplit("}", 1)[-1]
                            if tag == "dimension":
                                dimension = _range_dimensions(str(element.attrib.get("ref") or ""))
                                if dimension is not None:
                                    max_row, max_column = dimension
                            elif tag == "c":
                                position = _cell_position(str(element.attrib.get("r") or ""))
                                if position is not None:
                                    max_row = max(max_row, position[0])
                                    max_column = max(max_column, position[1])
                            element.clear()
                    rows = max(1, max_row)
                    columns = max(1, max_column)
                except Exception:  # noqa: BLE001, S110 - keep generic sheet shape
                    pass
                table = _empty_table(
                    f"probe:sheet:{index}",
                    rows=rows,
                    columns=columns,
                    source="source-route-probe",
                )
                pages.append(
                    _page(
                        number=index + 1,
                        blocks=[EvidenceBlock(block_id=f"probe:sheet:{index}:table", kind="table", source="source-route-probe")],
                        tables=[table],
                        route_tokens={
                            "container:ooxml",
                            "sheet:multiple" if len(members) > 1 else "sheet:single",
                            "sheet:tabular",
                        },
                    )
                )
            return pages or [
                _page(number=1, route_tokens={"container:ooxml", "sheet:unknown"})
            ]
    except (OSError, zipfile.BadZipFile, _ProbeLimitExceeded):
        return [_page(number=1, route_tokens={"container:ole", "sheet:unknown"})]


def _probe_docx(path: Path) -> list[EvidencePage]:
    paragraph_count = table_count = drawing_count = page_break_count = 0
    rows = columns = current_cells = 0
    width = height = 1.0
    try:
        with zipfile.ZipFile(path) as archive:
            _zip_infos(archive)
            with _open_bounded_zip_member(
                archive,
                "word/document.xml",
                remaining_total=[_MAX_PROBE_TOTAL_UNCOMPRESSED_BYTES],
            ) as stream:
                for event, element in ElementTree.iterparse(stream, events=("start", "end")):
                    tag = element.tag.rsplit("}", 1)[-1]
                    if event == "start":
                        if tag == "p":
                            paragraph_count += 1
                        elif tag == "tbl":
                            table_count += 1
                        elif tag in {"drawing", "pict"}:
                            drawing_count += 1
                        elif tag == "tr":
                            current_cells = 0
                        elif tag == "pgSz":
                            try:
                                width = float(element.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}w") or 1.0)
                                height = float(element.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}h") or 1.0)
                            except (TypeError, ValueError):
                                pass
                        elif tag == "br" and str(element.attrib.get("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}type") or "").casefold() == "page" or tag == "lastRenderedPageBreak":
                            page_break_count += 1
                    else:
                        if tag == "tc":
                            current_cells += 1
                        elif tag == "tr":
                            rows += 1
                            columns = max(columns, current_cells)
                        element.clear()
    except (
        OSError,
        KeyError,
        zipfile.BadZipFile,
        ElementTree.ParseError,
        _ProbeLimitExceeded,
    ):
        return []
    page_count = max(1, min(_MAX_PROBE_PAGES, page_break_count + 1))
    tokens = {"container:ooxml"}
    if table_count:
        tokens.add("office:tables")
    if drawing_count:
        tokens.add("office:drawings")
    blocks = [
        EvidenceBlock(block_id="probe:docx:text", kind="text", source="source-route-probe")
    ] if paragraph_count else []
    tables = [
        _empty_table("probe:docx:tables", rows=max(1, rows), columns=max(1, columns), source="source-route-probe")
    ] if table_count else []
    if tables:
        blocks.append(EvidenceBlock(block_id="probe:docx:table", kind="table", source="source-route-probe"))
    if drawing_count:
        blocks.append(EvidenceBlock(block_id="probe:docx:image", kind="image", source="source-route-probe"))
    return [
        _page(
            number=index + 1,
            width=width,
            height=height,
            blocks=blocks if index == 0 else [],
            tables=tables if index == 0 else [],
            route_tokens=tokens,
        )
        for index in range(page_count)
    ]


def _probe_pptx(path: Path) -> list[EvidencePage]:
    try:
        with zipfile.ZipFile(path) as archive:
            infos = _zip_infos(archive)
            remaining_total = [_MAX_PROBE_TOTAL_UNCOMPRESSED_BYTES]
            slides = sorted(
                (
                    info
                    for info in infos
                    if info.filename.casefold().startswith("ppt/slides/slide")
                    and info.filename.casefold().endswith(".xml")
                ),
                key=lambda info: info.filename.casefold(),
            )[:_MAX_PROBE_PAGES]
            pages: list[EvidencePage] = []
            for index, member in enumerate(slides):
                shapes = pictures = tables = 0
                try:
                    with _open_bounded_zip_member(
                        archive,
                        member,
                        remaining_total=remaining_total,
                    ) as stream:
                        for _event, element in ElementTree.iterparse(stream, events=("end",)):
                            tag = element.tag.rsplit("}", 1)[-1]
                            if tag in {"sp", "cxnSp", "graphicFrame"}:
                                shapes += 1
                            elif tag == "pic":
                                pictures += 1
                            elif tag == "tbl":
                                tables += 1
                            element.clear()
                except Exception:  # noqa: BLE001, S110 - keep generic slide shape
                    pass
                tokens = {"container:ooxml", "office:slides"}
                blocks: list[EvidenceBlock] = []
                if shapes:
                    blocks.append(EvidenceBlock(block_id=f"probe:pptx:{index}:text", kind="text", source="source-route-probe"))
                if pictures:
                    tokens.add("office:drawings")
                    blocks.append(EvidenceBlock(block_id=f"probe:pptx:{index}:image", kind="image", source="source-route-probe"))
                page_tables = []
                if tables:
                    tokens.add("office:tables")
                    page_tables.append(_empty_table(f"probe:pptx:{index}:table", rows=1, columns=1, source="source-route-probe"))
                    blocks.append(EvidenceBlock(block_id=f"probe:pptx:{index}:table", kind="table", source="source-route-probe"))
                pages.append(_page(number=index + 1, blocks=blocks, tables=page_tables, route_tokens=tokens))
            return pages or [_page(number=1, route_tokens={"container:ooxml", "office:slides"})]
    except (OSError, zipfile.BadZipFile, _ProbeLimitExceeded):
        return []


class _HtmlStructure(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.tables = 0
        self.rows = 0
        self.columns = 0
        self.current_cells = 0
        self.images = 0
        self.textual_tags = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        del attrs
        normalized = tag.casefold()
        if normalized == "table":
            self.tables += 1
        elif normalized == "tr":
            self.current_cells = 0
        elif normalized in {"td", "th"}:
            self.current_cells += 1
        elif normalized == "img":
            self.images += 1
        elif normalized in {"p", "h1", "h2", "h3", "h4", "li", "div", "span"}:
            self.textual_tags += 1

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() == "tr":
            self.rows += 1
            self.columns = max(self.columns, self.current_cells)


def _probe_html(path: Path) -> list[EvidencePage]:
    try:
        raw = _read_prefix(path, limit=_MAX_TEXT_PROBE_BYTES)
        text = raw.decode("utf-8-sig", errors="ignore")
    except OSError:
        return []
    parser = _HtmlStructure()
    try:
        parser.feed(text)
    except Exception:  # noqa: BLE001, S110 - malformed HTML stays generic
        pass
    tokens = {"container:plain"}
    blocks: list[EvidenceBlock] = []
    if parser.tables:
        tokens.add("web:tables")
        blocks.append(EvidenceBlock(block_id="probe:html:table", kind="table", source="source-route-probe"))
    if parser.images:
        tokens.add("web:images")
        blocks.append(EvidenceBlock(block_id="probe:html:image", kind="image", source="source-route-probe"))
    if parser.textual_tags:
        blocks.append(EvidenceBlock(block_id="probe:html:text", kind="text", source="source-route-probe"))
    tables = [
        _empty_table("probe:html:table", rows=max(1, parser.rows), columns=max(1, parser.columns), source="source-route-probe")
    ] if parser.tables else []
    return [_page(number=1, blocks=blocks, tables=tables, route_tokens=tokens)]


def _probe_image(path: Path) -> list[EvidencePage]:
    try:
        from PIL import Image

        with Image.open(path) as image:
            width, height = image.size
    except Exception:  # noqa: BLE001 - image parser owns malformed images
        return []
    if width * height > _MAX_PROBE_PDF_PIXELS:
        return [
            _page(
                number=1,
                route_tokens={"image:single", "image:oversized"},
            )
        ]
    return [
        _page(
            number=1,
            width=width,
            height=height,
            blocks=[EvidenceBlock(block_id="probe:image", kind="image", source="source-route-probe")],
            route_tokens={"image:single"},
        )
    ]


def _probe_archive(path: Path, *, kind: str) -> list[EvidencePage]:
    tokens = {"container:zip" if kind == "zip" else f"container:{kind}"}
    # Archive member names are intentionally not retained.  A count tells the
    # route only that this is an archive-shaped source, not what it contains.
    member_count = 0
    if kind == "zip":
        member_count = len(_zip_members(path))
    if member_count:
        tokens.add("archive:members")
    return [_page(number=1, route_tokens=tokens)]


def _probe_zip_kind(path: Path) -> tuple[str, str]:
    """Identify an OOXML container using central-directory metadata only."""

    try:
        with zipfile.ZipFile(path) as archive:
            names = {info.filename.casefold() for info in _zip_infos(archive)}
    except (OSError, zipfile.BadZipFile, _ProbeLimitExceeded):
        return "archive", "application/zip"
    if "xl/workbook.xml" in names:
        return (
            "xlsx",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    if "word/document.xml" in names:
        return (
            "docx",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    if "ppt/presentation.xml" in names:
        return (
            "pptx",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        )
    return "archive", "application/zip"


def _source_info(
    path: Path,
    declared_source_kind: str | None,
    *,
    allow_archive_inspection: bool,
) -> tuple[str, str]:
    try:
        prefix = _read_prefix(path, limit=64 * 1024)
    except OSError:
        prefix = b""
    if prefix.startswith((b"PK\x03\x04", b"PK\x05\x06")):
        if allow_archive_inspection:
            return _probe_zip_kind(path)
        return "archive", "application/zip"
    try:
        from ..magic import sniff_file_type

        detected = sniff_file_type(path)
        kind = str(detected.kind or "unknown").casefold()
        mime = str(detected.mime_type or "application/octet-stream")
    except Exception:  # noqa: BLE001 - parser path owns source diagnostics
        kind = "unknown"
        mime = "application/octet-stream"
    if kind == "unknown":
        fallback = str(declared_source_kind or "unknown").strip().casefold()
        if fallback in {
            "pdf", "image", "xlsx", "xlsm", "xls", "csv", "docx", "pptx",
            "html", "dxf", "dwg", "zip", "rar", "7z", "archive",
        }:
            kind = fallback
    if kind in {"zip", "rar", "7z"}:
        kind = "archive"
    return kind, mime


def build_source_route_probe(
    path: str | Path,
    *,
    declared_source_kind: str | None = None,
) -> SourceRouteProbe:
    """Build an inexpensive value-free route probe before parser selection.

    This function may transiently read XML/text layers to count geometry, but
    never returns any of their content.  It must remain safe to send the
    resulting signature to the optional small routing model.
    """

    source = Path(path)
    try:
        source_too_large = source.stat().st_size > _MAX_PROBE_SOURCE_BYTES
    except OSError:
        source_too_large = False
    source_kind, mime_type = _source_info(
        source,
        declared_source_kind,
        allow_archive_inspection=not source_too_large,
    )
    if source_too_large:
        pages = [_page(number=1, route_tokens={"probe:source_too_large"})]
    elif source_kind == "pdf":
        pages = _probe_pdf(source)
    elif source_kind in {"xlsx", "xlsm"}:
        pages = _probe_spreadsheet(source)
    elif source_kind == "xls":
        pages = [_page(number=1, route_tokens={"container:ole", "sheet:unknown"})]
    elif source_kind == "csv":
        pages = _probe_delimited(source)
    elif source_kind == "docx":
        pages = _probe_docx(source)
    elif source_kind == "pptx":
        pages = _probe_pptx(source)
    elif source_kind == "html":
        pages = _probe_html(source)
    elif source_kind == "image":
        pages = _probe_image(source)
    elif source_kind == "archive":
        pages = _probe_archive(source, kind="zip")
    elif source_kind in {"dxf", "dwg"}:
        pages = [_page(number=1, route_tokens={"container:cad"})]
    else:
        pages = []
    evidence = DocumentEvidence(
        # Keep the compatibility identity aligned with the existing native
        # record probe.  Profiles that need source-only specificity still get
        # distinct geometry/tokens, while generic approved profiles can be
        # safely reused before a parser runs.
        backend="native-record-probe",
        backend_version="m1.document.v2",
        pages=pages,
        raw={"source_kind": source_kind, "probe_version": _PROBE_VERSION},
    )
    return SourceRouteProbe(
        evidence=evidence,
        source_kind=source_kind,
        mime_type=mime_type,
    )


def _field_names(document: Mapping[str, Any]) -> list[str]:
    names: list[str] = []
    for path in (document.get("field_meta") or {}):
        value = str(path).rsplit(".", 1)[-1]
        if _FIELD_NAME.fullmatch(value):
            names.append(value)
    for container_name in ("header", "lines", "generic_facts"):
        container = document.get(container_name)
        if isinstance(container, Mapping):
            names.extend(str(key) for key in container if _FIELD_NAME.fullmatch(str(key)))
        elif isinstance(container, list):
            for item in container[:32]:
                if isinstance(item, Mapping):
                    names.extend(
                        str(key)
                        for key in item
                        if _FIELD_NAME.fullmatch(str(key))
                    )
    return list(dict.fromkeys(names))[:256]


def _structured_evidence(document: Mapping[str, Any]) -> DocumentEvidence | None:
    extraction = document.get("extraction")
    if not isinstance(extraction, Mapping):
        return None
    metadata = extraction.get("metadata")
    if not isinstance(metadata, Mapping):
        return None
    candidate = metadata.get("structured_evidence")
    if not isinstance(candidate, Mapping):
        return None
    try:
        return DocumentEvidence.model_validate(candidate)
    except Exception:  # noqa: BLE001 - probe must never block parsing
        return None


def build_route_probe_evidence(
    document: Mapping[str, Any],
    source_kind: str,
    *,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
) -> DocumentEvidence:
    """Return only structure and allowlisted labels from an existing record."""

    structured = _structured_evidence(document)
    if structured is not None:
        raw = dict(structured.raw)
        raw["semantic_labels"] = _field_names(document)
        return structured.model_copy(update={"raw": raw})

    names = _field_names(document)
    header = document.get("header")
    header_names = [
        str(key)
        for key in header
        if _FIELD_NAME.fullmatch(str(key))
    ] if isinstance(header, Mapping) else []
    lines = document.get("lines")
    line_count = len(lines) if isinstance(lines, list) else 0
    column_names = list(dict.fromkeys(header_names + names))[:128]
    rows = [column_names]
    rows.extend([([None] * len(column_names)) for _ in range(min(line_count, 4096))])
    cells = [
        EvidenceCell(row=0, column=index, text=name)
        for index, name in enumerate(column_names)
    ]
    table = EvidenceTable(
        table_id="probe:records",
        rows=rows,
        cells=cells,
        source="native-record-probe",
        orientation="records_by_row",
    )
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=1.0,
        height=1.0,
        blocks=[
            EvidenceBlock(
                block_id="probe:table",
                kind="table",
                text="",
                source="native-record-probe",
            )
        ]
        if column_names
        else [],
        tables=[table] if column_names else [],
    )
    return DocumentEvidence(
        backend="native-record-probe",
        backend_version="m1.document.v2",
        pages=[page],
        raw={
            "source_kind": source_kind,
            "semantic_labels": names,
            "document_type_hint": document_type_hint,
            "document_subtype_hint": document_subtype_hint,
        },
    )


__all__ = [
    "SourceRouteProbe",
    "build_route_probe_evidence",
    "build_source_route_probe",
]
