"""Value-free document route signatures.

Only canonical structural features and allowlisted semantic label names may
enter these models. Raw document text, filenames, identifiers, and extracted
business values are intentionally excluded from fingerprints and embedding
input.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .evidence import DocumentEvidence, EvidencePage, EvidenceTable

FormatFamily = Literal[
    "fixed_page",
    "image",
    "spreadsheet",
    "word_processing",
    "presentation",
    "web",
    "cad",
    "archive",
    "unknown",
]
PageCountBucket = Literal["none", "single", "few", "many"]
RowCountBucket = Literal["none", "single", "few", "many"]
TableOrientation = Literal["records_by_row", "records_by_column", "matrix", "unknown"]

_SAFE_TOKEN = re.compile(r"^[a-z][a-z0-9_.:-]{0,63}$")
_MAX_ROUTE_TOKENS = 256
_ROUTE_DOCUMENT_TYPES = frozenset(
    {"order", "inventory", "equipment", "mold", "procurement", "technical_document", "archive"}
)
_ROUTE_DOCUMENT_SUBTYPES = frozenset(
    {
        "stocking_order",
        "customer_purchase_order",
        "purchase_contract",
        "supplier_purchase_order",
        "sample_request",
        "inventory_snapshot",
        "equipment_register",
        "mold_mapping",
        "purchase_receipt_ledger",
        "purchase_requisition_ledger",
        "purchase_order_ledger",
        "approval_drawing",
        "engineering_drawing",
        "product_specification",
        "process_document",
        "service_policy",
        "product_photo",
        "presentation",
        "web_document",
        "image_document",
        "archive",
    }
)

_SOURCE_FORMAT_ALIASES: dict[str, FormatFamily] = {
    "pdf": "fixed_page",
    ".pdf": "fixed_page",
    "application/pdf": "fixed_page",
    "fixed_page": "fixed_page",
    "image": "image",
    "png": "image",
    "jpg": "image",
    "jpeg": "image",
    "gif": "image",
    "bmp": "image",
    "tif": "image",
    "tiff": "image",
    "webp": "image",
    "spreadsheet": "spreadsheet",
    "table": "spreadsheet",
    "tabular": "spreadsheet",
    "csv": "spreadsheet",
    "tsv": "spreadsheet",
    "xls": "spreadsheet",
    "xlsx": "spreadsheet",
    "ods": "spreadsheet",
    "text/csv": "spreadsheet",
    "text/tab-separated-values": "spreadsheet",
    "application/csv": "spreadsheet",
    "application/vnd.ms-excel": "spreadsheet",
    "application/vnd.oasis.opendocument.spreadsheet": "spreadsheet",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "spreadsheet",
    "doc": "word_processing",
    "docx": "word_processing",
    "odt": "word_processing",
    "rtf": "word_processing",
    "word": "word_processing",
    "word_processing": "word_processing",
    "application/msword": "word_processing",
    "application/rtf": "word_processing",
    "application/vnd.oasis.opendocument.text": "word_processing",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "word_processing",
    "ppt": "presentation",
    "pptx": "presentation",
    "odp": "presentation",
    "presentation": "presentation",
    "application/vnd.ms-powerpoint": "presentation",
    "application/vnd.oasis.opendocument.presentation": "presentation",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "presentation",
    "html": "web",
    "htm": "web",
    "xhtml": "web",
    "web": "web",
    "text/html": "web",
    "application/xhtml+xml": "web",
    "cad": "cad",
    "dwg": "cad",
    "dxf": "cad",
    "image/vnd.dwg": "cad",
    "image/vnd.dxf": "cad",
    "application/dxf": "cad",
    "archive": "archive",
    "zip": "archive",
    "7z": "archive",
    "rar": "archive",
    "tar": "archive",
    "application/zip": "archive",
    "application/x-7z-compressed": "archive",
    "application/vnd.rar": "archive",
}
_SOURCE_EXTENSION_FORMATS: dict[str, FormatFamily] = {
    "pdf": "fixed_page",
    "png": "image",
    "jpg": "image",
    "jpeg": "image",
    "gif": "image",
    "bmp": "image",
    "tif": "image",
    "tiff": "image",
    "webp": "image",
    "csv": "spreadsheet",
    "tsv": "spreadsheet",
    "xls": "spreadsheet",
    "xlsx": "spreadsheet",
    "ods": "spreadsheet",
    "doc": "word_processing",
    "docx": "word_processing",
    "odt": "word_processing",
    "rtf": "word_processing",
    "ppt": "presentation",
    "pptx": "presentation",
    "odp": "presentation",
    "html": "web",
    "htm": "web",
    "xhtml": "web",
    "dwg": "cad",
    "dxf": "cad",
    "zip": "archive",
    "7z": "archive",
    "rar": "archive",
    "tar": "archive",
}

_BLOCK_KIND_ALIASES = {
    "text": "text",
    "paragraph": "text",
    "plain_text": "text",
    "title": "title",
    "document_title": "title",
    "heading": "heading",
    "section_header": "heading",
    "subtitle": "heading",
    "list": "list",
    "list_item": "list",
    "table": "table",
    "table_text": "table",
    "table_caption": "table_caption",
    "image": "image",
    "picture": "image",
    "figure": "figure",
    "chart": "chart",
    "seal": "seal",
    "stamp": "seal",
    "formula": "formula",
    "equation": "formula",
    "interline_equation": "formula",
    "code": "code",
    "page_header": "header",
    "header": "header",
    "page_footer": "footer",
    "footer": "footer",
    "key_value": "key_value",
    "form": "key_value",
}
_VISUAL_BLOCK_KINDS = frozenset({"image", "figure", "chart", "seal"})

# ``DocumentEvidence.raw`` normally contains provider-specific diagnostics and
# must never influence routing.  The source probe is the sole exception: it
# writes only these closed structural markers, each of which is independent of
# filename, text, identifiers and business values.  Keeping an exact allowlist
# prevents an upstream parser from smuggling arbitrary values into an embedding
# or small-model route decision through metadata.
_SAFE_PROBE_LAYOUT_TOKENS = frozenset(
    {
        "archive:members",
        "container:7z",
        "container:cad",
        "container:ole",
        "container:ooxml",
        "container:plain",
        "container:rar",
        "container:unknown",
        "container:zip",
        "image:oversized",
        "image:single",
        "office:drawings",
        "office:slides",
        "office:tables",
        "pdf:low_dpi_dense",
        "pdf:low_dpi_ink",
        "pdf:low_dpi_sparse",
        "pdf:low_dpi_skipped_large",
        "pdf:metadata",
        "pdf:no_text_layer",
        "pdf:text_layer",
        "pdf:vector_grid",
        "sheet:multiple",
        "sheet:single",
        "sheet:tabular",
        "sheet:unknown",
        "probe:source_too_large",
        "web:images",
        "web:tables",
    }
)

_CANONICAL_SEMANTIC_LABELS = frozenset(
    {
        "buyer",
        "contract_number",
        "currency",
        "customer",
        "delivery_address",
        "delivery_date",
        "document_number",
        "document_subtype",
        "document_type",
        "drawing_number",
        "equipment_identifier",
        "inventory_quantity",
        "item_number",
        "line_number",
        "manufacturer",
        "material_id",
        "material_name",
        "model",
        "mold_identifier",
        "order_date",
        "order_number",
        "priority",
        "product_id",
        "product_name",
        "purchase_order_number",
        "quantity",
        "revision",
        "scale",
        "seller",
        "specification",
        "status",
        "supplier",
        "total_amount",
        "unit",
        "unit_price",
        "warehouse",
    }
)
_SEMANTIC_LABEL_ALIASES = {
    **{label: label for label in _CANONICAL_SEMANTIC_LABELS},
    "amount": "total_amount",
    "contract_id": "contract_number",
    "date": "order_date",
    "delivery_date_raw": "delivery_date",
    "document_id": "document_number",
    "drawing_id": "drawing_number",
    "equipment_id": "equipment_identifier",
    "item_id": "item_number",
    "manufacturer_name": "manufacturer",
    "material_code": "material_id",
    "model_number": "model",
    "mold_id": "mold_identifier",
    "order_id": "order_number",
    "order_number_raw": "order_number",
    "product_code": "product_id",
    "product_model": "model",
    "purchase_order_id": "purchase_order_number",
    "qty": "quantity",
    "spec": "specification",
    "total": "total_amount",
    "下单日期": "order_date",
    "交付日期": "delivery_date",
    "交期": "delivery_date",
    "交货日期": "delivery_date",
    "供应商": "supplier",
    "公司": "manufacturer",
    "制造商": "manufacturer",
    "单位": "unit",
    "卖方": "seller",
    "合同号": "contract_number",
    "图号": "drawing_number",
    "客户": "customer",
    "币种": "currency",
    "序号": "line_number",
    "总价": "total_amount",
    "数量": "quantity",
    "文档号": "document_number",
    "文档子类型": "document_subtype",
    "文档类型": "document_type",
    "日期": "order_date",
    "材料名称": "material_name",
    "材料编码": "material_id",
    "模具号": "mold_identifier",
    "模号": "mold_identifier",
    "状态": "status",
    "版本": "revision",
    "甲方": "buyer",
    "产品名称": "product_name",
    "产品编码": "product_id",
    "规格": "specification",
    "订单号": "order_number",
    "设备号": "equipment_identifier",
    "采购单号": "purchase_order_number",
    "采购订单号": "purchase_order_number",
    "金额": "total_amount",
    "仓库": "warehouse",
    "乙方": "seller",
}
_SEMANTIC_PATH = re.compile(
    r"^(?:\$\.)?(?:header|line|lines(?:\[\d+\])?|item|items(?:\[\d+\])?)\.([a-z][a-z0-9_]*)$"
)
_TABLE_ORIENTATION_ALIASES: dict[str, TableOrientation] = {
    "row": "records_by_row",
    "rows": "records_by_row",
    "records_by_row": "records_by_row",
    "column": "records_by_column",
    "columns": "records_by_column",
    "records_by_column": "records_by_column",
    "cross_tab": "matrix",
    "crosstab": "matrix",
    "matrix": "matrix",
    "unknown": "unknown",
}


def _canonical_tokens(values: Sequence[str]) -> tuple[str, ...]:
    normalized = tuple(
        sorted({str(value).strip().casefold() for value in values if str(value).strip()})
    )
    if len(normalized) > _MAX_ROUTE_TOKENS:
        raise ValueError(f"route signature accepts at most {_MAX_ROUTE_TOKENS} tokens")
    invalid = [value for value in normalized if _SAFE_TOKEN.fullmatch(value) is None]
    if invalid:
        raise ValueError("route signature tokens must be canonical non-value identifiers")
    return normalized


def _format_family(source_kind: object | None) -> FormatFamily:
    if source_kind is None:
        return "unknown"
    value = str(source_kind).strip().casefold()
    if not value:
        return "unknown"
    media_type = value.split(";", 1)[0].strip()
    direct = _SOURCE_FORMAT_ALIASES.get(media_type)
    if direct is not None:
        return direct
    if media_type.startswith("image/"):
        return "image"
    path_without_query = re.split(r"[?#]", value, maxsplit=1)[0]
    suffix = re.search(r"\.([a-z0-9]{1,8})$", path_without_query)
    if suffix is not None:
        return _SOURCE_EXTENSION_FORMATS.get(suffix.group(1), "unknown")
    return "unknown"


def _page_count_bucket(count: int) -> PageCountBucket:
    if count <= 0:
        return "none"
    if count == 1:
        return "single"
    if count <= 5:
        return "few"
    return "many"


def _row_count_bucket(count: int) -> RowCountBucket:
    if count <= 0:
        return "none"
    if count == 1:
        return "single"
    if count <= 20:
        return "few"
    return "many"


def _canonical_block_kind(value: object) -> str | None:
    key = str(value).strip().casefold().replace("-", "_").replace(" ", "_")
    return _BLOCK_KIND_ALIASES.get(key)


def _semantic_label(value: object) -> str | None:
    key = str(value).strip().casefold().replace("-", "_").replace(" ", "_")
    direct = _SEMANTIC_LABEL_ALIASES.get(key)
    if direct is not None:
        return direct
    path_match = _SEMANTIC_PATH.fullmatch(key)
    if path_match is None:
        return None
    return _SEMANTIC_LABEL_ALIASES.get(path_match.group(1))


def _semantic_label_from_source_text(value: object) -> str | None:
    """Map a structural label to the fixed vocabulary without retaining text."""

    text = str(value).strip()
    direct = _semantic_label(text)
    if direct is not None:
        return direct
    for delimiter in (":", "\uff1a"):
        if delimiter in text:
            return _semantic_label(text.split(delimiter, 1)[0])
    return None


def _semantic_label_values(value: object) -> tuple[object, ...]:
    if value is None:
        return ()
    if isinstance(value, Mapping):
        return tuple(value.keys())
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Sequence):
        return tuple(value)
    return ()


def _table_dimensions(table: EvidenceTable) -> tuple[int, int]:
    row_count = len(table.rows)
    column_count = max((len(row) for row in table.rows), default=0)
    if table.cells:
        row_count = max(row_count, max(cell.row for cell in table.cells) + 1)
        column_count = max(column_count, max(cell.column for cell in table.cells) + 1)
    return row_count, min(512, column_count)


def _table_orientation(
    table: EvidenceTable,
    *,
    row_count: int,
    column_count: int,
) -> TableOrientation:
    extra = table.model_extra or {}
    for key in ("orientation", "record_orientation", "table_orientation"):
        raw = extra.get(key)
        if isinstance(raw, str):
            orientation = _TABLE_ORIENTATION_ALIASES.get(
                raw.strip().casefold().replace("-", "_")
            )
            if orientation is not None:
                return orientation
    if row_count < 2 or column_count < 2:
        return "unknown"
    if row_count >= column_count * 2:
        return "records_by_row"
    if column_count >= row_count * 2:
        return "records_by_column"
    return "matrix"


def _header_count(table: EvidenceTable) -> int:
    extra = table.model_extra or {}
    for key in ("header_row_count", "header_column_count", "header_count"):
        value = extra.get(key)
        if isinstance(value, int) and not isinstance(value, bool):
            return min(64, max(0, value))

    for key in ("header_indices", "header_rows", "header_columns"):
        value = extra.get(key)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            indexes = {
                item
                for item in value
                if isinstance(item, int) and not isinstance(item, bool) and item >= 0
            }
            if indexes:
                return min(64, len(indexes))

    header_rows = {
        cell.row
        for cell in table.cells
        if (cell.model_extra or {}).get("is_header") is True
    }
    return min(64, len(header_rows))


_MAX_EXACT_SEMANTIC_POSITION = 63


def _semantic_position_bucket(index: int) -> str:
    return str(index) if index <= _MAX_EXACT_SEMANTIC_POSITION else "overflow"


def _table_semantic_layout(
    table: EvidenceTable,
    *,
    row_count: int,
    column_count: int,
) -> tuple[set[str], tuple[str, ...], str | None]:
    """Recover allowlisted labels and their first structural table position.

    Raw values are inspected transiently and discarded. Only exact aliases from
    the fixed semantic vocabulary can leave this function, so arbitrary names,
    identifiers, contact details, and document text never enter the signature.
    """

    labels: set[str] = set()
    first_positions: dict[str, tuple[int, int]] = {}
    topology_entries: set[tuple[int, int, str]] = set()
    orientation = _table_orientation(
        table,
        row_count=row_count,
        column_count=column_count,
    )
    header_count = _header_count(table)

    def retain(value: object, *, row: int, column: int) -> None:
        label = _semantic_label_from_source_text(value)
        if label is None:
            return
        labels.add(label)
        topology_entries.add((row, column, label))
        position = (row, column)
        current = first_positions.get(label)
        if current is None or position < current:
            first_positions[label] = position

    for row_index, row in enumerate(table.rows):
        for column_index, value in enumerate(row):
            structural_position = (
                row_index < max(1, header_count)
                or column_index == 0
                or (
                    orientation == "records_by_column"
                    and column_index < max(1, header_count)
                )
            )
            if not structural_position:
                continue
            retain(value, row=row_index, column=column_index)
    for cell in table.cells:
        extra = cell.model_extra or {}
        if not (
            extra.get("is_header") is True
            or cell.row < max(1, header_count)
            or cell.column == 0
        ):
            continue
        retain(cell.text or "", row=cell.row, column=cell.column)

    positions = tuple(
        f"r{_semantic_position_bucket(row)}:"
        f"c{_semantic_position_bucket(column)}:{label}"
        for label, (row, column) in first_positions.items()
    )
    # Readable tokens stay bounded; the digest covers every exact position so
    # the overflow bucket cannot collapse distinct exact route identities.
    topology_payload = "\n".join(
        f"r{row}:c{column}:{label}"
        for row, column, label in sorted(topology_entries)
    )
    topology_digest = (
        hashlib.sha256(topology_payload.encode("ascii")).hexdigest()
        if topology_payload
        else None
    )
    return labels, positions, topology_digest


def _rotation_token(page: EvidencePage) -> str:
    try:
        degrees = round(float(page.rotation)) % 360
    except (TypeError, ValueError, OverflowError):
        return "rotation:unknown"
    if degrees in {0, 90, 180, 270}:
        return f"rotation:{degrees}"
    return "rotation:other"


def _scan_state(page: EvidencePage) -> Literal["native", "scanned"] | None:
    raw = page.raw if isinstance(page.raw, Mapping) else {}
    for key in ("is_scanned", "scanned", "scan"):
        value = raw.get(key)
        if isinstance(value, bool):
            return "scanned" if value else "native"
    for key in ("has_text_layer", "native_text", "is_native"):
        value = raw.get(key)
        if isinstance(value, bool):
            return "native" if value else "scanned"
    return None


def _layout_tokens(evidence: DocumentEvidence) -> tuple[str, ...]:
    tokens: set[str] = set()
    pages = evidence.pages
    table_count = sum(len(page.tables) for page in pages)
    tokens.add(
        "table:none"
        if table_count == 0
        else "table:single"
        if table_count == 1
        else "table:multiple"
    )

    orientations: set[str] = set()
    rotations: set[str] = set()
    scan_states: set[str] = set()
    visual_present = False
    visual_dominant = False
    for page in pages:
        if page.width > page.height * 1.05:
            orientations.add("landscape")
        elif page.height > page.width * 1.05:
            orientations.add("portrait")
        else:
            orientations.add("square")
        rotations.add(_rotation_token(page))
        state = _scan_state(page)
        if state is not None:
            scan_states.add(state)
        canonical_kinds = {
            kind
            for block in page.blocks
            if (kind := _canonical_block_kind(block.kind)) is not None
        }
        if canonical_kinds & _VISUAL_BLOCK_KINDS:
            visual_present = True
        visual_area = sum(
            block.bbox.area
            for block in page.blocks
            if block.bbox is not None
            and _canonical_block_kind(block.kind) in _VISUAL_BLOCK_KINDS
        )
        if min(1.0, visual_area / max(1.0, page.width * page.height)) > 0.20:
            visual_dominant = True
        raw = page.raw if isinstance(page.raw, Mapping) else {}
        candidates = raw.get("route_structure_tokens")
        if isinstance(candidates, Sequence) and not isinstance(
            candidates, (str, bytes, bytearray)
        ):
            tokens.update(
                str(value)
                for value in candidates
                if str(value) in _SAFE_PROBE_LAYOUT_TOKENS
            )

    tokens.update(f"page_orientation:{value}" for value in orientations)
    tokens.update(rotations or {"rotation:none"})
    tokens.update(f"scan:{value}" for value in scan_states)
    if not scan_states:
        tokens.add("scan:unknown")
    tokens.add("visual:present" if visual_present else "visual:none")
    if visual_dominant:
        tokens.add("visual:dominant")
    return tuple(sorted(tokens))


def _compatibility_tokens(
    evidence: DocumentEvidence,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
    contract_revision: str,
) -> tuple[str, ...]:
    """Return value-free execution-compatibility tokens for route reuse."""

    def digest(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()[:32]

    backend = re.sub(
        r"[^a-z0-9_.:]",
        "_",
        str(evidence.backend or "unknown").strip().casefold(),
    )[:40]
    if not backend or not backend[0].isalpha():
        backend = "unknown"
    tokens = {
        f"compat:backend:{backend}",
        f"compat:backend_rev:{digest(str(evidence.backend_version or 'unknown'))}",
        f"compat:contract:{digest(contract_revision.strip() or 'm1.document.v2')}",
    }
    if evidence.model_fingerprints:
        model_payload = json.dumps(
            evidence.model_fingerprints,
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        tokens.add(f"compat:model_rev:{digest(model_payload)}")
    normalized_type = str(document_type_hint or "").strip().casefold()
    if normalized_type in _ROUTE_DOCUMENT_TYPES:
        tokens.add(f"compat:type_hint:{normalized_type}")
    normalized_subtype = str(document_subtype_hint or "").strip().casefold()
    if normalized_subtype in _ROUTE_DOCUMENT_SUBTYPES:
        tokens.add(f"compat:subtype_hint:{normalized_subtype}")
    return tuple(sorted(tokens))


class RouteTableShape(BaseModel):
    """Value-free shape of one table-like region."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    # Global evidence order (page order, then table order within the page).
    # The identity is value-free but keeps route policies attached to the same
    # table when heterogeneous shapes are canonicalized for fingerprinting.
    table_index: int = Field(ge=0, le=4095)
    row_count_bucket: RowCountBucket
    column_count: int = Field(ge=0, le=512)
    header_row_count: int = Field(default=0, ge=0, le=64)
    orientation: TableOrientation = "unknown"
    semantic_label_positions: tuple[str, ...] = ()
    semantic_topology_digest: str | None = Field(
        default=None,
        pattern=r"^[0-9a-f]{64}$",
    )

    @field_validator("semantic_label_positions")
    @classmethod
    def canonicalize_semantic_label_positions(
        cls, value: tuple[str, ...]
    ) -> tuple[str, ...]:
        return _canonical_tokens(value)


class DocumentRouteSignature(BaseModel):
    """Canonical layout signature containing no extracted business values."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    format_family: FormatFamily
    page_count_bucket: PageCountBucket
    block_kinds: tuple[str, ...] = ()
    table_shapes: tuple[RouteTableShape, ...] = ()
    label_tokens: tuple[str, ...] = ()
    layout_tokens: tuple[str, ...] = ()

    @field_validator("block_kinds", "label_tokens", "layout_tokens")
    @classmethod
    def canonicalize_tokens(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        return _canonical_tokens(value)

    @field_validator("table_shapes")
    @classmethod
    def canonicalize_table_shapes(
        cls, value: tuple[RouteTableShape, ...]
    ) -> tuple[RouteTableShape, ...]:
        ordered = tuple(sorted(value, key=lambda item: item.table_index))
        indexes = tuple(item.table_index for item in ordered)
        if indexes != tuple(range(len(ordered))):
            raise ValueError(
                "route table indexes must be unique and contiguous from zero"
            )
        return ordered

    def structural_tokens(self) -> tuple[str, ...]:
        tokens = {
            f"format:{self.format_family}",
            f"pages:{self.page_count_bucket}",
            *(f"block:{item}" for item in self.block_kinds),
            *(f"layout:{item}" for item in self.layout_tokens),
        }
        tokens.update(
            "table:"
            f"i{shape.table_index}:"
            f"{shape.orientation}:"
            f"{shape.row_count_bucket}:"
            f"c{shape.column_count}:"
            f"h{shape.header_row_count}"
            for shape in self.table_shapes
        )
        tokens.update(
            f"table:i{shape.table_index}:semantic:{position}"
            for shape in self.table_shapes
            for position in shape.semantic_label_positions
        )
        tokens.update(
            f"table:i{shape.table_index}:semantic_digest:{shape.semantic_topology_digest}"
            for shape in self.table_shapes
            if shape.semantic_topology_digest is not None
        )
        return tuple(sorted(tokens))

    def embedding_text(self) -> str:
        """Stable value-free text suitable for an external embedding provider."""

        entries = [
            *(f"structure={item}" for item in self.structural_tokens()),
            *(f"label={item}" for item in self.label_tokens),
        ]
        return "\n".join(entries)

    def exact_fingerprint(self) -> str:
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def build_document_route_signature(
    evidence: DocumentEvidence,
    source_kind: str | None = None,
    *,
    semantic_labels: Sequence[str] | Mapping[str, Any] | None = None,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    contract_revision: str = "m1.document.v2",
) -> DocumentRouteSignature:
    """Build a value-free routing signature from normalized evidence.

    Source text, filenames, IDs, cell values and arbitrary provider metadata are
    intentionally never read. ``semantic_labels`` may be names or mapping keys;
    only labels in the fixed module allowlist survive canonicalization.
    """

    evidence_extra = evidence.model_extra or {}
    effective_source_kind: object | None = source_kind
    if effective_source_kind is None:
        effective_source_kind = evidence_extra.get("source_kind")

    effective_labels: object = semantic_labels
    if effective_labels is None:
        effective_labels = evidence_extra.get("semantic_labels")
    label_tokens = {
        canonical
        for value in _semantic_label_values(effective_labels)
        if (canonical := _semantic_label(value)) is not None
    }
    block_kinds = {
        canonical
        for page in evidence.pages
        for block in page.blocks
        if (canonical := _canonical_block_kind(block.kind)) is not None
    }
    tables = [table for page in evidence.pages for table in page.tables]
    if tables:
        block_kinds.add("table")
    table_shapes: list[RouteTableShape] = []
    for table_index, table in enumerate(tables):
        row_count, column_count = _table_dimensions(table)
        (
            table_labels,
            semantic_label_positions,
            semantic_topology_digest,
        ) = _table_semantic_layout(
            table,
            row_count=row_count,
            column_count=column_count,
        )
        label_tokens.update(table_labels)
        table_shapes.append(
            RouteTableShape(
                table_index=table_index,
                row_count_bucket=_row_count_bucket(row_count),
                column_count=column_count,
                header_row_count=_header_count(table),
                orientation=_table_orientation(
                    table,
                    row_count=row_count,
                    column_count=column_count,
                ),
                semantic_label_positions=semantic_label_positions,
                semantic_topology_digest=semantic_topology_digest,
            )
        )

    return DocumentRouteSignature(
        format_family=_format_family(effective_source_kind),
        page_count_bucket=_page_count_bucket(len(evidence.pages)),
        block_kinds=tuple(block_kinds),
        table_shapes=tuple(table_shapes),
        label_tokens=tuple(label_tokens),
        layout_tokens=tuple(
            {
                *_layout_tokens(evidence),
                *_compatibility_tokens(
                    evidence,
                    document_type_hint=document_type_hint,
                    document_subtype_hint=document_subtype_hint,
                    contract_revision=contract_revision,
                ),
            }
        ),
    )


__all__ = [
    "DocumentRouteSignature",
    "FormatFamily",
    "PageCountBucket",
    "RouteTableShape",
    "RowCountBucket",
    "TableOrientation",
    "build_document_route_signature",
]
