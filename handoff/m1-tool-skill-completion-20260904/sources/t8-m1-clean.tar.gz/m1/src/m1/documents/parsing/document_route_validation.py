"""Deterministic, content-free validation for candidate route policies."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from ...knowledge.routing_schema import RouteProfileRecord
from .document_route_policy import (
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTableRole,
)

CANDIDATE_VALIDATION_KIND = "candidate_policy_validation"
CANDIDATE_VALIDATOR_VERSION = "m1.route-policy-preflight.v1"

_FAMILY_DOCUMENT_TYPES: dict[RouteSchemaFamily, RouteDocumentType] = {
    RouteSchemaFamily.ORDER: RouteDocumentType.ORDER,
    RouteSchemaFamily.INVENTORY: RouteDocumentType.INVENTORY,
    RouteSchemaFamily.EQUIPMENT: RouteDocumentType.EQUIPMENT,
    RouteSchemaFamily.MOLD: RouteDocumentType.MOLD,
    RouteSchemaFamily.PROCUREMENT: RouteDocumentType.PROCUREMENT,
    RouteSchemaFamily.TECHNICAL: RouteDocumentType.TECHNICAL_DOCUMENT,
    RouteSchemaFamily.ARCHIVE: RouteDocumentType.ARCHIVE,
}
_PRIMARY_TABLE_ROLES = frozenset(
    {
        RouteTableRole.REPEATED_RECORDS,
        RouteTableRole.BOM,
        RouteTableRole.ORDER_LINES,
        RouteTableRole.INVENTORY_LINES,
        RouteTableRole.EQUIPMENT_LINES,
        RouteTableRole.MOLD_MAPPING,
    }
)
_NONPRIMARY_TABLE_ROLES = frozenset(
    {
        RouteTableRole.KEY_VALUE,
        RouteTableRole.LAYOUT,
        RouteTableRole.TITLE_BLOCK,
        RouteTableRole.IGNORE,
    }
)


@dataclass(frozen=True, slots=True)
class CandidatePolicyPreflight:
    """Bounded validation result safe to persist in route observations."""

    accepted: bool
    policy_digest: str
    check_codes: tuple[str, ...]
    validator_version: str = CANDIDATE_VALIDATOR_VERSION


def route_policy_digest(policy: RouteProfilePolicy) -> str:
    """Return a stable digest without retaining document or business values."""

    payload = json.dumps(
        policy.model_dump(mode="json"),
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _sequence(value: object) -> Sequence[object]:
    return value if isinstance(value, Sequence) and not isinstance(value, str) else ()


def _document_table_ids(document: Mapping[str, Any]) -> tuple[str, ...]:
    extraction = _mapping(document.get("extraction"))
    raw_content = _mapping(extraction.get("raw_content"))
    table_ids: list[str] = []
    for page in _sequence(raw_content.get("pages")):
        for table in _sequence(_mapping(page).get("tables")):
            table_id = str(_mapping(table).get("table_id") or "").strip()
            if table_id and table_id not in table_ids:
                table_ids.append(table_id)
    return tuple(table_ids)


def candidate_policy_preflight(
    profile: RouteProfileRecord,
    document: Mapping[str, Any],
) -> CandidatePolicyPreflight:
    """Check a candidate against a final record without trusting its raw content.

    This proves structural agreement only. It is intentionally used as a
    prerequisite for an explicit route review and never mints an automatic
    success observation by itself.
    """

    policy = RouteProfilePolicy.model_validate(profile.policy)
    digest = route_policy_digest(policy)
    failures: list[str] = []

    if policy.schema_family in {
        RouteSchemaFamily.GENERIC_LAYOUT,
        RouteSchemaFamily.OPEN_DOMAIN,
    }:
        failures.append("ROUTE_POLICY_GENERIC_NOT_ACTIVATABLE")

    extraction = _mapping(document.get("extraction"))
    metadata = _mapping(extraction.get("metadata"))
    routing = _mapping(metadata.get("adaptive_routing"))
    if routing.get("status") != "resolved":
        failures.append("ROUTE_ROUTING_METADATA_NOT_RESOLVED")
    if str(routing.get("candidate_profile_id") or "").strip() != profile.profile_id:
        failures.append("ROUTE_CANDIDATE_PROFILE_MISMATCH")
    if (
        str(routing.get("signature_fingerprint") or "").strip().casefold()
        != profile.exact_fingerprint
    ):
        failures.append("ROUTE_SIGNATURE_FINGERPRINT_MISMATCH")
    if routing.get("policy_applied") is True:
        failures.append("ROUTE_CANDIDATE_POLICY_ALREADY_APPLIED")

    if bool(document.get("needs_review")):
        failures.append("ROUTE_DOCUMENT_REQUIRES_REVIEW")
    for key, code in (
        ("evidence_complete", "ROUTE_EVIDENCE_INCOMPLETE"),
        ("accounted_complete", "ROUTE_ACCOUNTING_INCOMPLETE"),
        ("retained_complete", "ROUTE_RETENTION_INCOMPLETE"),
    ):
        if metadata.get(key) is not True:
            failures.append(code)

    document_type = str(document.get("document_type") or "").strip().casefold()
    document_subtype = str(document.get("document_subtype") or "").strip().casefold()
    expected_type = _FAMILY_DOCUMENT_TYPES.get(policy.schema_family)
    if expected_type is not None and document_type != expected_type.value:
        failures.append("ROUTE_SCHEMA_FAMILY_MISMATCH")
    if (
        policy.document_type_hint is not None
        and document_type != policy.document_type_hint.value
    ):
        failures.append("ROUTE_DOCUMENT_TYPE_MISMATCH")
    if (
        policy.document_subtype_hint is not None
        and document_subtype != policy.document_subtype_hint.value
    ):
        failures.append("ROUTE_DOCUMENT_SUBTYPE_MISMATCH")

    table_ids = _document_table_ids(document)
    primary_table_ids = {
        str(value).strip()
        for value in _sequence(metadata.get("primary_record_table_ids"))
        if str(value).strip()
    }
    if len(table_ids) != len(profile.signature.table_shapes):
        failures.append("ROUTE_TABLE_TOPOLOGY_MISMATCH")
    for table_policy in policy.table_roles:
        if table_policy.table_index >= len(table_ids):
            failures.append("ROUTE_TABLE_INDEX_UNAVAILABLE")
            continue
        table_id = table_ids[table_policy.table_index]
        if (
            table_policy.role in _PRIMARY_TABLE_ROLES
            and table_id not in primary_table_ids
        ):
            failures.append("ROUTE_PRIMARY_TABLE_ROLE_MISMATCH")
        if (
            table_policy.role in _NONPRIMARY_TABLE_ROLES
            and table_id in primary_table_ids
        ):
            failures.append("ROUTE_NONPRIMARY_TABLE_ROLE_MISMATCH")

    check_codes = tuple(dict.fromkeys(failures))
    return CandidatePolicyPreflight(
        accepted=not check_codes,
        policy_digest=digest,
        check_codes=check_codes or ("ROUTE_POLICY_PREFLIGHT_PASSED",),
    )


__all__ = [
    "CANDIDATE_VALIDATION_KIND",
    "CANDIDATE_VALIDATOR_VERSION",
    "CandidatePolicyPreflight",
    "candidate_policy_preflight",
    "route_policy_digest",
]
