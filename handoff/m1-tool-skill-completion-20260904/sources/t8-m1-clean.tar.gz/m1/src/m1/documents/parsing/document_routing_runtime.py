"""Governed persistence runtime for adaptive document routing.

The runtime joins the pure, value-free routing signature with the existing
knowledge repository and embedding/model providers.  It deliberately does not
touch the parser pipeline: callers decide when to resolve a route and when to
record the resulting parse outcome.

Only canonical structure, semantic label names, and typed policy enums are
persisted.  Document text, filenames, business values, tenant IDs, and task IDs
never enter a signature, embedding prompt, or route policy.
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Literal

from pydantic import ValidationError

from ...knowledge.db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from ...knowledge.embeddings import EmbeddingProvider, EmbeddingSpaceIdentity
from ...knowledge.routing_schema import (
    RouteProfileRecord,
    RouteProfileStatus,
)
from ...structured_llm import StructuredModelClient
from .adaptive_routing import (
    AdaptiveDocumentRouter,
    DocumentRouteCandidateContext,
    DocumentRouteCandidateScore,
    DocumentRouteModelChoice,
    DocumentRouteSelectionRequest,
    DocumentRouteSelector,
    DocumentRouteSignature,
    PydanticDocumentRouteSelector,
)
from .document_route_governance import DocumentRouteGovernanceMixin
from .document_route_lifecycle import (
    DocumentRouteSignatureBuilder,
    DocumentRouteStore,
    default_signature_builder,
    deterministic_reuse_allowed,
    is_specialized_policy,
    policy_matches_signature,
    profile_identity,
    profile_matches_signature,
    task_reference,
    top_metrics,
    typed_policy,
)
from .document_route_policy import (
    DocumentRoutePolicyProposal,
    DocumentRoutePolicyProposer,
    DocumentRoutingResolution,
    PydanticDocumentRoutePolicyProposer,
    RouteAuthorityPolicy,
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTablePolicy,
    RouteTableRole,
    RouteVerifierPolicy,
    RoutingMode,
    RoutingRuntimeReason,
    StructuredPolicyClient,
    StructuredPolicyRun,
    default_candidate_policy,
)
from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .evidence import DocumentEvidence

if TYPE_CHECKING:
    from ...core.config import Settings


class DocumentRoutingRuntime(DocumentRouteGovernanceMixin):
    """Resolve governed document routes and manage their minimal lifecycle."""

    def __init__(
        self,
        *,
        store: DocumentRouteStore,
        embedding_provider: EmbeddingProvider | None,
        selector: DocumentRouteSelector | None = None,
        policy_proposer: DocumentRoutePolicyProposer | None = None,
        mode: RoutingMode = "shadow",
        top_k: int = 3,
        auto_min_score: float = 0.90,
        model_min_score: float = 0.75,
        min_margin: float = 0.08,
        min_activation_samples: int = 3,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
        model_reuse_min_confidence: float = 0.70,
        model_proposal_min_confidence: float = 0.75,
        policy_proposal_min_confidence: float = 0.75,
        required: bool = False,
        signature_builder: DocumentRouteSignatureBuilder | None = None,
        owned_model_client: StructuredModelClient | None = None,
    ) -> None:
        if mode not in {"shadow", "guarded"}:
            raise ValueError("document router mode must be shadow or guarded")
        thresholds = (
            auto_min_score,
            model_min_score,
            min_margin,
            model_reuse_min_confidence,
            model_proposal_min_confidence,
            policy_proposal_min_confidence,
        )
        if not all(
            math.isfinite(value) and 0.0 <= value <= 1.0 for value in thresholds
        ):
            raise ValueError(
                "document router thresholds must be finite values in [0, 1]"
            )
        if model_min_score > auto_min_score:
            raise ValueError("model_min_score must not exceed auto_min_score")
        if top_k < 1:
            raise ValueError("top_k must be positive")
        if min_activation_samples < 1:
            raise ValueError("min_activation_samples must be positive")
        if circuit_failures < 1 or circuit_seconds <= 0:
            raise ValueError("route circuit settings must be positive")

        self.store = store
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.policy_proposer = policy_proposer
        self.mode: RoutingMode = mode
        self.top_k = min(int(top_k), 20)
        self.auto_min_score = float(auto_min_score)
        self.model_min_score = float(model_min_score)
        self.min_margin = float(min_margin)
        self.min_activation_samples = int(min_activation_samples)
        self.model_reuse_min_confidence = float(model_reuse_min_confidence)
        self.model_proposal_min_confidence = float(model_proposal_min_confidence)
        self.policy_proposal_min_confidence = float(
            policy_proposal_min_confidence
        )
        self.required = bool(required)
        self.signature_builder = signature_builder or default_signature_builder
        self._ranker = AdaptiveDocumentRouter()
        self._owned_model_client = owned_model_client
        self._status = DocumentRoutingStatus(
            circuit_failures=int(circuit_failures),
            circuit_seconds=float(circuit_seconds),
        )

    @classmethod
    def from_settings(
        cls,
        settings: Settings,
        *,
        store: DocumentRouteStore,
        embedding_provider: EmbeddingProvider | None,
        model_client: StructuredModelClient | None = None,
        signature_builder: DocumentRouteSignatureBuilder | None = None,
    ) -> DocumentRoutingRuntime:
        """Build the runtime from the dedicated router configuration tuple."""

        if not settings.document_router_enabled:
            raise ValueError("DOCUMENT_ROUTER_ENABLED is false")
        if settings.document_router_required and embedding_provider is None:
            raise RuntimeError(
                "required document routing needs the knowledge embedding provider"
            )
        owned_client: StructuredModelClient | None = None
        if model_client is None:
            owned_client = StructuredModelClient(
                api_key=settings.document_router_api_key,
                base_url=settings.document_router_base_url,
                model=settings.document_router_model,
                temperature=0.0,
                max_tokens=512,
                enable_thinking=False,
                timeout=settings.document_router_timeout_seconds,
                retries=1,
                output_mode="prompted",
            )
            model_client = owned_client
        return cls(
            store=store,
            embedding_provider=embedding_provider,
            selector=PydanticDocumentRouteSelector(model_client),
            policy_proposer=PydanticDocumentRoutePolicyProposer(model_client),
            mode=settings.document_router_mode,
            top_k=settings.document_router_top_k,
            auto_min_score=settings.document_router_auto_min_score,
            model_min_score=settings.document_router_model_min_score,
            min_margin=settings.document_router_min_margin,
            min_activation_samples=settings.document_router_min_activation_samples,
            circuit_failures=getattr(settings, "document_router_circuit_failures", 3),
            circuit_seconds=getattr(settings, "document_router_circuit_seconds", 300.0),
            required=settings.document_router_required,
            signature_builder=signature_builder,
            owned_model_client=owned_client,
        )

    async def close(self) -> None:
        if self._owned_model_client is not None:
            await self._owned_model_client.close()

    def status_snapshot(self) -> dict[str, object]:
        """Return bounded operational state without document or credential data."""

        return self._status.snapshot()

    async def _embed_signature(
        self, signature: DocumentRouteSignature
    ) -> tuple[list[float], EmbeddingSpaceIdentity] | None:
        if self.embedding_provider is None:
            return None
        identity = EmbeddingSpaceIdentity.from_provider(self.embedding_provider)
        if identity.dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "document route embedding provider dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, "
                f"received {identity.dimensions}"
            )
        vectors = await self.embedding_provider.embed_texts(
            [signature.embedding_text()]
        )
        if len(vectors) != 1:
            raise ValueError("document route embedding response count mismatch")
        vector = [float(value) for value in vectors[0]]
        if len(vector) != identity.dimensions:
            raise ValueError("document route embedding dimension mismatch")
        if not all(math.isfinite(value) for value in vector):
            raise ValueError("document route embedding contains non-finite values")
        return vector, identity

    def _reuse_resolution(
        self,
        *,
        signature: DocumentRouteSignature,
        profile: RouteProfileRecord,
        policy: RouteProfilePolicy,
        reason: RoutingRuntimeReason,
        top_score: float,
        margin: float,
        model_used: bool,
    ) -> DocumentRoutingResolution:
        guarded = self.mode == "guarded"
        return DocumentRoutingResolution(
            mode=self.mode,
            recommendation="reuse",
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            recommended_profile_id=profile.profile_id,
            applied_profile_id=profile.profile_id if guarded else None,
            applied_policy=policy if guarded else None,
            top_score=top_score,
            top1_top2_margin=margin,
            model_used=model_used,
        )

    async def _fallback_resolution(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None,
        reason: RoutingRuntimeReason,
        recommendation: Literal["generic", "propose"] = "generic",
        top_score: float = 0.0,
        margin: float = 0.0,
        model_used: bool = False,
        create_candidate: bool = True,
        candidate_policy: RouteProfilePolicy | None = None,
        proposal_applied: bool = False,
        proposal_schema_family: RouteSchemaFamily | None = None,
    ) -> DocumentRoutingResolution:
        candidate_profile_id: str | None = None
        if create_candidate:
            candidate = await self.observe_candidate(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                policy=candidate_policy,
            )
            if candidate.status is RouteProfileStatus.CANDIDATE:
                candidate_profile_id = candidate.profile_id
        return DocumentRoutingResolution(
            mode=self.mode,
            recommendation=recommendation,
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            candidate_profile_id=candidate_profile_id,
            top_score=top_score,
            top1_top2_margin=margin,
            model_used=model_used,
            proposal_applied=proposal_applied,
            proposal_schema_family=proposal_schema_family,
        )

    async def _propose_policy_or_fallback(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None,
        fallback_reason: RoutingRuntimeReason,
        top_score: float = 0.0,
        margin: float = 0.0,
        proposed_reason: RoutingRuntimeReason = "policy_proposed",
        create_candidate: bool = True,
    ) -> DocumentRoutingResolution:
        # A model must not invent a specialized route from pure topology. Two
        # canonical semantic labels are the minimum value-free business signal.
        if len(signature.label_tokens) < 2:
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason=fallback_reason,
                top_score=top_score,
                margin=margin,
                create_candidate=create_candidate,
            )
        if self._status.circuit_open("policy"):
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="model_unavailable",
                top_score=top_score,
                margin=margin,
                create_candidate=False,
            )
        if self.policy_proposer is None:
            if self.required:
                error = RuntimeError("policy proposer unavailable")
                raise self._status.note_dependency_failure("policy", error) from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason=fallback_reason,
                top_score=top_score,
                margin=margin,
                create_candidate=create_candidate,
            )
        try:
            raw_proposal = await self.policy_proposer.propose(signature)
            proposal = DocumentRoutePolicyProposal.model_validate(raw_proposal)
            self._status.note_dependency_success("policy")
        except (TypeError, ValueError, ValidationError) as exc:
            controlled = self._status.note_dependency_failure("policy", exc)
            if self.required:
                raise controlled from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_invalid",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=False,
            )
        except Exception as exc:  # noqa: BLE001 - optional proposer fails open
            controlled = self._status.note_dependency_failure("policy", exc)
            if self.required:
                raise controlled from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_failure",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=False,
            )

        if proposal.confidence < self.policy_proposal_min_confidence:
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_low_confidence",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=False,
            )
        if not policy_matches_signature(proposal.policy, signature):
            error = ValueError("policy references an unknown table")
            controlled = self._status.note_dependency_failure("policy", error)
            if self.required:
                raise controlled from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_invalid",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=False,
            )
        if proposal.policy.schema_family is RouteSchemaFamily.GENERIC_LAYOUT:
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_generic",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=create_candidate,
            )
        try:
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason=proposed_reason,
                recommendation="propose",
                top_score=top_score,
                margin=margin,
                model_used=True,
                candidate_policy=proposal.policy,
                proposal_applied=True,
                proposal_schema_family=proposal.policy.schema_family,
                create_candidate=create_candidate,
            )
        except ValueError:
            # Competing specialized or active policy definitions remain
            # immutable; fall back without changing their governed authority.
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="policy_proposal_conflict",
                top_score=top_score,
                margin=margin,
                model_used=True,
            )

    async def _model_resolution(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None,
        ranked: tuple[DocumentRouteCandidateScore, ...],
        profiles: Mapping[str, tuple[RouteProfileRecord, RouteProfilePolicy]],
        create_candidate: bool,
        unavailable_reason: RoutingRuntimeReason = "model_unavailable",
    ) -> DocumentRoutingResolution:
        top_score, margin = top_metrics(ranked)
        if self._status.circuit_open("model"):
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="model_unavailable",
                top_score=top_score,
                margin=margin,
                create_candidate=False,
            )
        if self.selector is None:
            if self.required:
                error = RuntimeError("route selector unavailable")
                raise self._status.note_dependency_failure("model", error) from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason=unavailable_reason,
                top_score=top_score,
                margin=margin,
                create_candidate=create_candidate,
            )
        request = DocumentRouteSelectionRequest(
            signature_fingerprint=signature.exact_fingerprint(),
            signature=signature,
            candidates=ranked[:3],
        )
        try:
            raw_choice = await self.selector.select(request)
            choice = DocumentRouteModelChoice.model_validate(raw_choice, strict=True)
            self._status.note_dependency_success("model")
        except (TypeError, ValueError, ValidationError) as exc:
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="invalid_model_output",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=create_candidate,
            )
        except Exception as exc:  # noqa: BLE001 - optional selector fails open
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason="model_failure",
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=create_candidate,
            )

        if choice.action == "reuse":
            selected_score = next(
                (
                    item
                    for item in request.candidates
                    if item.route_id == choice.candidate_route_id
                ),
                None,
            )
            selected = profiles.get(choice.candidate_route_id or "")
            if (
                selected_score is not None
                and selected is not None
                and selected_score.fused_score >= self.model_min_score
                and choice.confidence >= self.model_reuse_min_confidence
            ):
                profile, policy = selected
                return self._reuse_resolution(
                    signature=signature,
                    profile=profile,
                    policy=policy,
                    reason="model_reuse",
                    top_score=top_score,
                    margin=margin,
                    model_used=True,
                )
            reason: RoutingRuntimeReason = "model_candidate_below_threshold"
            if choice.confidence < self.model_reuse_min_confidence:
                reason = "model_confidence_below_threshold"
            return await self._fallback_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                reason=reason,
                top_score=top_score,
                margin=margin,
                model_used=True,
                create_candidate=create_candidate,
            )

        if choice.action == "propose" and (
            choice.confidence >= self.model_proposal_min_confidence
        ):
            # A selector's propose decision is only an ambiguity signal. Ask
            # the policy proposer for a typed specialized policy before
            # creating the candidate; otherwise this path would persist the
            # generic fallback and could never become an active route.
            return await self._propose_policy_or_fallback(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                fallback_reason="model_propose",
                top_score=top_score,
                margin=margin,
                proposed_reason="model_propose",
                create_candidate=create_candidate,
            )
        reason = (
            "model_confidence_below_threshold"
            if choice.action == "propose"
            else "model_generic"
        )
        return await self._fallback_resolution(
            tenant_id=tenant_id,
            task_id=task_id,
            signature=signature,
            embedding=embedding,
            reason=reason,
            top_score=top_score,
            margin=margin,
            model_used=True,
            create_candidate=create_candidate,
        )

    @staticmethod
    def _candidate_context(
        profile: RouteProfileRecord,
        policy: RouteProfilePolicy,
    ) -> DocumentRouteCandidateContext:
        """Expose only bounded policy/reliability facts to the small model."""

        observation_count = max(0, int(profile.observation_count))
        success_rate = (
            round(float(profile.success_count) / observation_count, 6)
            if observation_count
            else None
        )
        role_values = tuple(item.role.value for item in policy.table_roles)
        return DocumentRouteCandidateContext(
            schema_family=policy.schema_family.value,
            document_type=(
                policy.document_type_hint.value
                if policy.document_type_hint is not None
                else None
            ),
            document_subtype=(
                policy.document_subtype_hint.value
                if policy.document_subtype_hint is not None
                else None
            ),
            backend_chain=tuple(policy.backend_chain),
            table_roles=role_values[:64],
            table_role_count=len(role_values),
            verifier_policy=policy.verifier_policy.value,
            visual_policy=policy.visual_policy,
            authority_policy=policy.authority_policy.value,
            contract_revision=policy.contract_revision,
            parser_revision=policy.parser_revision,
            observation_count=observation_count,
            success_rate=success_rate,
        )

    @classmethod
    def _attach_candidate_contexts(
        cls,
        ranked: Sequence[DocumentRouteCandidateScore],
        profiles: Mapping[str, tuple[RouteProfileRecord, RouteProfilePolicy]],
    ) -> tuple[DocumentRouteCandidateScore, ...]:
        """Attach policy summaries without changing rank scores."""

        enriched: list[DocumentRouteCandidateScore] = []
        for candidate in ranked:
            selected = profiles.get(candidate.route_id)
            if selected is None:
                enriched.append(candidate)
                continue
            profile, policy = selected
            enriched.append(
                candidate.model_copy(
                    update={"context": cls._candidate_context(profile, policy)}
                )
            )
        return tuple(enriched)

    async def resolve(
        self,
        tenant_id: str,
        task_id: str,
        evidence: DocumentEvidence,
        source_kind: str,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        contract_revision: str = "m1.document.v2",
    ) -> DocumentRoutingResolution:
        """Resolve one document and update secret-free dependency telemetry."""

        return await self._status.track(
            self._resolve(
                tenant_id,
                task_id,
                evidence,
                source_kind,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
                contract_revision=contract_revision,
            )
        )

    async def _resolve(
        self,
        tenant_id: str,
        task_id: str,
        evidence: DocumentEvidence,
        source_kind: str,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        contract_revision: str = "m1.document.v2",
    ) -> DocumentRoutingResolution:
        """Resolve one document without persisting document content or values."""

        task_reference(tenant_id, task_id)
        signature = self.signature_builder(
            evidence,
            source_kind,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            contract_revision=contract_revision,
        )
        fingerprint = signature.exact_fingerprint()
        exact = await self._status.store_call(
            self.store.get_active_route_profile_by_fingerprint(
                tenant_id, fingerprint
            )
        )
        if exact is not None:
            policy = typed_policy(exact)
            if policy is None:
                controlled = self._status.note_dependency_failure(
                    "profile", ValueError("invalid active route policy")
                )
                if self.required:
                    raise controlled from None
                return await self._fallback_resolution(
                    tenant_id=tenant_id,
                    task_id=task_id,
                    signature=signature,
                    embedding=None,
                    reason="invalid_active_policy",
                    create_candidate=False,
                )
            self._status.note_dependency_success("profile")
            if deterministic_reuse_allowed(signature, policy):
                return self._reuse_resolution(
                    signature=signature,
                    profile=exact,
                    policy=policy,
                    reason="exact_fingerprint",
                    top_score=1.0,
                    margin=1.0,
                    model_used=False,
                )
            ranked = self._ranker.rank_candidates(signature, [exact.as_candidate()])
            ranked = self._attach_candidate_contexts(
                ranked,
                {exact.profile_id: (exact, policy)},
            )
            return await self._model_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=None,
                ranked=ranked,
                profiles={exact.profile_id: (exact, policy)},
                create_candidate=False,
                unavailable_reason="exact_requires_model",
            )

        if self.embedding_provider is None:
            if self.required:
                error = RuntimeError("embedding provider unavailable")
                raise self._status.note_dependency_failure(
                    "embedding", error
                ) from None
            return await self._propose_policy_or_fallback(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=None,
                fallback_reason="embedding_unavailable",
            )
        try:
            embedded = await self._embed_signature(signature)
        except Exception as exc:  # noqa: BLE001 - optional provider is advisory
            controlled = self._status.note_dependency_failure("embedding", exc)
            if self.required:
                raise controlled from None
            return await self._propose_policy_or_fallback(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=None,
                fallback_reason="embedding_failure",
            )
        if embedded is None:  # defensive: a configured provider must return one vector
            error = ValueError("embedding provider returned no vector")
            controlled = self._status.note_dependency_failure("embedding", error)
            if self.required:
                raise controlled from None
            return await self._propose_policy_or_fallback(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=None,
                fallback_reason="embedding_failure",
            )
        self._status.note_dependency_success("embedding")
        embedding, embedding_identity = embedded

        matches = await self._status.store_call(
            self.store.find_route_profiles(
                tenant_id,
                embedding,
                embedding_model=embedding_identity.model,
                embedding_dimensions=embedding_identity.dimensions,
                statuses=(RouteProfileStatus.ACTIVE,),
                min_similarity=-1.0,
                limit=self.top_k,
            )
        )
        profiles: dict[str, tuple[RouteProfileRecord, RouteProfilePolicy]] = {}
        candidates = []
        invalid_active_policy_count = 0
        for match in matches:
            policy = typed_policy(match.profile)
            if policy is None:
                invalid_active_policy_count += 1
                continue
            if not profile_matches_signature(match.profile.signature, signature, policy):
                # A valid profile may still target a backend or table position
                # that the current evidence cannot execute. Treat it as a
                # non-candidate rather than allowing vector similarity to
                # bypass the compatibility gate.
                continue
            profiles[match.profile.profile_id] = (match.profile, policy)
            candidates.append(match.profile.as_candidate())
        if not invalid_active_policy_count:
            self._status.note_dependency_success("profile")
        if invalid_active_policy_count:
            controlled = self._status.note_dependency_failure(
                "profile", ValueError("invalid active route policy")
            )
            if self.required:
                raise controlled from None
        if not candidates:
            if matches:
                return await self._fallback_resolution(
                    tenant_id=tenant_id,
                    task_id=task_id,
                    signature=signature,
                    embedding=embedding,
                    reason="invalid_active_policy",
                )
            return await self._propose_policy_or_fallback(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                fallback_reason="no_active_profiles",
            )

        ranked = self._ranker.rank_candidates(
            signature,
            candidates,
            signature_vector=embedding,
        )[: self.top_k]
        ranked = self._attach_candidate_contexts(ranked, profiles)
        top_score, margin = top_metrics(ranked)
        top_profile, top_policy = profiles[ranked[0].route_id]
        if (
            top_score >= self.auto_min_score
            and margin >= self.min_margin
            and deterministic_reuse_allowed(signature, top_policy)
        ):
            return self._reuse_resolution(
                signature=signature,
                profile=top_profile,
                policy=top_policy,
                reason="vector_auto_reuse",
                top_score=top_score,
                margin=margin,
                model_used=False,
            )
        if top_score >= self.model_min_score:
            return await self._model_resolution(
                tenant_id=tenant_id,
                task_id=task_id,
                signature=signature,
                embedding=embedding,
                ranked=ranked,
                profiles=profiles,
                create_candidate=True,
            )
        return await self._propose_policy_or_fallback(
            tenant_id=tenant_id,
            task_id=task_id,
            signature=signature,
            embedding=embedding,
            fallback_reason="score_below_threshold",
            top_score=top_score,
            margin=margin,
        )

    async def observe_candidate(
        self,
        *,
        tenant_id: str,
        task_id: str,
        signature: DocumentRouteSignature,
        embedding: Sequence[float] | None = None,
        policy: RouteProfilePolicy | None = None,
    ) -> RouteProfileRecord:
        """Create an idempotent candidate; never promote it automatically."""

        task_reference(tenant_id, task_id)
        if policy is not None and not isinstance(policy, RouteProfilePolicy):
            raise TypeError("route candidate policy must be a RouteProfilePolicy")
        normalized_embedding = (
            [float(value) for value in embedding] if embedding is not None else None
        )
        embedding_identity: EmbeddingSpaceIdentity | None = None
        if normalized_embedding is not None:
            if self.embedding_provider is None:
                raise ValueError(
                    "a route embedding cannot be stored without a provider identity"
                )
            embedding_identity = EmbeddingSpaceIdentity.from_provider(
                self.embedding_provider
            )
            if len(normalized_embedding) != embedding_identity.dimensions:
                raise ValueError(
                    "route embedding dimensions do not match the provider identity"
                )
        candidate_policy = policy or default_candidate_policy(signature)
        if not policy_matches_signature(candidate_policy, signature):
            raise ValueError("route candidate policy references an unknown table")
        fingerprint = signature.exact_fingerprint()
        _first_profile_id, profile_key = profile_identity(
            tenant_id, fingerprint, 1
        )
        latest = await self._status.store_call(
            self.store.get_latest_route_profile_by_fingerprint(
                tenant_id, fingerprint
            )
        )
        version = 1
        supersedes_profile_id: str | None = None
        if latest is not None:
            if latest.profile_key != profile_key or latest.signature != signature:
                raise ValueError("route candidate lineage has a signature conflict")
            latest_policy = typed_policy(latest)
            if latest.status is RouteProfileStatus.ACTIVE:
                if latest_policy == candidate_policy:
                    return latest
                raise ValueError("an active route profile cannot be revised automatically")
            if latest.status is RouteProfileStatus.CANDIDATE:
                if latest_policy is None:
                    raise ValueError("an existing route candidate policy is invalid")
                if latest_policy == candidate_policy:
                    # Embeddings are part of the immutable profile definition. A
                    # provider-recovery retry reuses the existing candidate.
                    return latest
                latest_is_specialized = is_specialized_policy(latest_policy)
                incoming_is_specialized = is_specialized_policy(candidate_policy)
                if latest_is_specialized and not incoming_is_specialized:
                    return latest
                if latest_is_specialized or not incoming_is_specialized:
                    raise ValueError("an existing route candidate policy is immutable")
            elif not is_specialized_policy(candidate_policy):
                # Rejected/deprecated generic routes stay terminal until a
                # stronger, evidence-backed specialized proposal replaces them.
                return latest
            version = latest.version + 1
            supersedes_profile_id = latest.profile_id
        profile_id, profile_key = profile_identity(tenant_id, fingerprint, version)
        record = RouteProfileRecord(
            profile_id=profile_id,
            tenant_id=tenant_id,
            profile_key=profile_key,
            version=version,
            supersedes_profile_id=supersedes_profile_id,
            status=RouteProfileStatus.CANDIDATE,
            exact_fingerprint=fingerprint,
            signature=signature,
            embedding=normalized_embedding,
            embedding_model=(embedding_identity.model if embedding_identity else ""),
            embedding_dimensions=(
                embedding_identity.dimensions if embedding_identity else 0
            ),
            policy=candidate_policy.model_dump(mode="json"),
            created_by="document-router",
        )
        return await self._status.store_call(self.store.create_route_profile(record))

__all__ = [
    "DocumentRoutePolicyProposal",
    "DocumentRoutePolicyProposer",
    "DocumentRoutingDependencyError",
    "DocumentRoutingResolution",
    "DocumentRoutingRuntime",
    "PydanticDocumentRoutePolicyProposer",
    "RouteAuthorityPolicy",
    "RouteDocumentSubtype",
    "RouteDocumentType",
    "RouteProfilePolicy",
    "RouteSchemaFamily",
    "RouteTablePolicy",
    "RouteTableRole",
    "RouteVerifierPolicy",
    "StructuredPolicyClient",
    "StructuredPolicyRun",
]
