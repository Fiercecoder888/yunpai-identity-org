"""Secret-free operational telemetry for adaptive document routing."""

from __future__ import annotations

import re
from collections.abc import Awaitable
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import TypeVar

from .document_route_policy import DocumentRoutingResolution

T = TypeVar("T")


class DocumentRoutingDependencyError(RuntimeError):
    """Fail-closed error that never includes provider messages or payloads."""

    def __init__(self, dependency: str, error_type: str) -> None:
        self.dependency = dependency
        self.error_type = error_type
        super().__init__(
            f"document router {dependency} dependency failed ({error_type})"
        )


class DocumentRoutingStatus:
    """Track completed route resolutions without retaining request data."""

    _DEPENDENCIES = ("store", "embedding", "model", "policy", "profile")

    def __init__(self, *, circuit_failures: int = 3, circuit_seconds: float = 300.0) -> None:
        if circuit_failures < 1 or circuit_seconds <= 0:
            raise ValueError("route circuit settings must be positive")
        self.circuit_failures = int(circuit_failures)
        self.circuit_seconds = float(circuit_seconds)
        self._dependency_error: ContextVar[tuple[str, str] | None] = ContextVar(
            "document_router_dependency_error", default=None
        )
        self.calls = 0
        self.successes = 0
        self.failures = 0
        self.fallbacks = 0
        self.consecutive_failures = 0
        self.last_success_at: datetime | None = None
        self.last_failure_at: datetime | None = None
        self.last_error_type = ""
        self.degraded = False
        self.dependency_failure = False
        self._operation_degraded = False
        self._dependencies: dict[str, dict[str, object]] = {
            name: {
                "degraded": False,
                "last_success_at": None,
                "last_failure_at": None,
                "last_error_type": "",
                "consecutive_failures": 0,
                "circuit_open_until": None,
            }
            for name in self._DEPENDENCIES
        }

    @staticmethod
    def _safe_error_type(error: BaseException) -> str:
        name = type(error).__name__
        return name if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,127}", name) else "Error"

    def note_dependency_failure(
        self, dependency: str, error: BaseException
    ) -> DocumentRoutingDependencyError:
        if dependency not in self._dependencies:
            # Keep telemetry bounded even if a future caller supplies a new
            # dependency name; the error itself remains safe and typed.
            self._dependencies[dependency] = {
                "degraded": False,
                "last_success_at": None,
                "last_failure_at": None,
                "last_error_type": "",
                "consecutive_failures": 0,
                "circuit_open_until": None,
            }
        error_type = self._safe_error_type(error)
        state = self._dependencies[dependency]
        now = datetime.now(UTC)
        state.update(
            {
                "degraded": True,
                "last_failure_at": now.isoformat(),
                "last_error_type": error_type,
                "consecutive_failures": int(state.get("consecutive_failures") or 0) + 1,
            }
        )
        if int(state["consecutive_failures"]) >= self.circuit_failures:
            from datetime import timedelta

            state["circuit_open_until"] = (
                now + timedelta(seconds=self.circuit_seconds)
            ).isoformat()
        current = self._dependency_error.get()
        if current is None or not current[0]:
            self._dependency_error.set((dependency, error_type))
        return DocumentRoutingDependencyError(dependency, error_type)

    def note_dependency_success(self, dependency: str) -> None:
        """Clear only the dependency that completed successfully.

        A healthy store call must not hide a still-failing model or policy
        provider.  This is deliberately separate from operation-level success.
        """

        if dependency not in self._dependencies:
            self._dependencies[dependency] = {
                "degraded": False,
                "last_success_at": None,
                "last_failure_at": None,
                "last_error_type": "",
                "consecutive_failures": 0,
                "circuit_open_until": None,
            }
        self._dependencies[dependency].update(
            {
                "degraded": False,
                "last_success_at": datetime.now(UTC).isoformat(),
                "last_error_type": "",
                "consecutive_failures": 0,
                "circuit_open_until": None,
            }
        )

    async def store_call(self, operation: Awaitable[T]) -> T:
        try:
            result = await operation
            self.note_dependency_success("store")
            return result
        except (ValueError, LookupError):
            raise
        except Exception as exc:
            self.note_dependency_failure("store", exc)
            raise

    def snapshot(self) -> dict[str, object]:
        dependency_status = {
            name: dict(state) for name, state in self._dependencies.items()
        }
        dependency_degraded = any(
            bool(state.get("degraded")) for state in dependency_status.values()
        )
        now = datetime.now(UTC)
        for state in dependency_status.values():
            until = state.get("circuit_open_until")
            if isinstance(until, str):
                try:
                    state["circuit_open"] = datetime.fromisoformat(until) > now
                except ValueError:
                    state["circuit_open"] = False
            else:
                state["circuit_open"] = False
        return {
            "calls": self.calls,
            "successes": self.successes,
            "failures": self.failures,
            "fallbacks": self.fallbacks,
            "consecutive_failures": self.consecutive_failures,
            "last_success_at": self.last_success_at.isoformat()
            if self.last_success_at
            else None,
            "last_failure_at": self.last_failure_at.isoformat()
            if self.last_failure_at
            else None,
            "last_error_type": self.last_error_type,
            "degraded": bool(self._operation_degraded or dependency_degraded),
            "dependency_failure": dependency_degraded,
            "dependencies": dependency_status,
            "circuit_open": any(
                bool(state.get("circuit_open")) for state in dependency_status.values()
            ),
            "circuit_failures": self.circuit_failures,
            "circuit_seconds": self.circuit_seconds,
            "ready": not bool(self._operation_degraded or dependency_degraded),
        }

    def circuit_open(self, dependency: str) -> bool:
        state = self._dependencies.get(dependency)
        if not state:
            return False
        until = state.get("circuit_open_until")
        if not isinstance(until, str):
            return False
        try:
            return datetime.fromisoformat(until) > datetime.now(UTC)
        except ValueError:
            return False

    async def track(
        self, operation: Awaitable[DocumentRoutingResolution]
    ) -> DocumentRoutingResolution:
        return await self.track_operation(operation)

    async def track_operation(self, operation: Awaitable[T]) -> T:
        """Track one router operation without retaining its request or result."""

        self.calls += 1
        token = self._dependency_error.set(("", ""))
        result: T | None = None
        error: BaseException | None = None
        try:
            result = await operation
            return result
        except BaseException as exc:
            error = exc
            raise
        finally:
            self._finish(
                resolution=(
                    result if isinstance(result, DocumentRoutingResolution) else None
                ),
                error=error,
            )
            self._dependency_error.reset(token)

    def _finish(
        self,
        *,
        resolution: DocumentRoutingResolution | None,
        error: BaseException | None,
    ) -> None:
        dependency, dependency_error = self._dependency_error.get() or ("", "")
        if resolution is not None and resolution.recommendation != "reuse":
            self.fallbacks += 1
        if error is None and not dependency:
            self.successes += 1
            self.consecutive_failures = 0
            self.last_success_at = datetime.now(UTC)
            self._operation_degraded = False
            return
        self.failures += 1
        self.consecutive_failures += 1
        self.last_failure_at = datetime.now(UTC)
        self.last_error_type = (
            dependency_error
            or (self._safe_error_type(error) if error is not None else "Error")
        )
        self._operation_degraded = True


__all__ = ["DocumentRoutingDependencyError", "DocumentRoutingStatus"]
