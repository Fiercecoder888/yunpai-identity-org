"""Evidence-backed classification for native DOCX content.

The classifier deliberately treats the package filename as advisory.  Only
explicit text retained from the OOXML main story can produce an authoritative
subtype, so renamed uploads cannot reverse the document's stated purpose.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping
from typing import Any

_SUBTYPE_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "approval_drawing": tuple(
        re.compile(pattern, re.IGNORECASE)
        for pattern in (
            r"承[认認](?:书|書|图|圖)",
            r"(?:approval|approved)\s+(?:drawing|sheet|document)",
        )
    ),
    "product_specification": tuple(
        re.compile(pattern, re.IGNORECASE)
        for pattern in (
            r"(?:产品|產品|技术|技術)?规格(?:说明)?书",
            r"(?:產品|技術)?規格(?:說明)?書",
            r"(?:product|technical)\s+specification",
            r"specification\s+sheet",
            r"data\s*sheet",
        )
    ),
    "engineering_drawing": tuple(
        re.compile(pattern, re.IGNORECASE)
        for pattern in (
            r"工程[图圖](?:纸|紙)?",
            r"(?:装配|組裝|尺寸)[图圖]",
            r"[图圖][纸紙]",
            r"(?:engineering|mechanical|dimensional|assembly)\s+drawing",
        )
    ),
}
_SUBTYPE_PRIORITY_BONUS = {
    "approval_drawing": 12,
    "product_specification": 6,
    "engineering_drawing": 0,
}

_TITLE_STYLE_RE = re.compile(
    r"(?:^|[-_ ])(?:title|subtitle|heading)\d*(?:$|[-_ ])",
    re.IGNORECASE,
)


def _text(value: Any) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).split())


def _matches(value: str) -> list[tuple[str, str]]:
    matches: list[tuple[str, str]] = []
    for subtype, patterns in _SUBTYPE_PATTERNS.items():
        for pattern in patterns:
            match = pattern.search(value)
            if match is not None:
                matches.append((subtype, match.group(0)))
                break
    return matches


def _signal(
    *,
    subtype: str,
    marker: str,
    source_id: str,
    quote: str,
    role: str,
    score: int,
) -> dict[str, Any]:
    return {
        "document_subtype": subtype,
        "matched_marker": marker,
        "source_id": source_id,
        "evidence_id": source_id,
        "quote": quote,
        "source_ref": {"page": 1, "part": source_id},
        "role": role,
        "score": score,
    }


def classify_docx_native_content(
    *,
    paragraphs: Iterable[Mapping[str, Any]],
    table_cells: Iterable[Mapping[str, Any]],
    original_filename: str,
) -> dict[str, Any]:
    """Classify explicit native DOCX purpose and retain the decision evidence."""

    signals: list[dict[str, Any]] = []
    top_level_seen = 0
    for paragraph in paragraphs:
        value = _text(paragraph.get("text_nfkc") or paragraph.get("text"))
        if not value:
            continue
        source_id = str(paragraph.get("source_id") or "")
        top_level = "#paragraph:" in source_id and "/" not in source_id.split("#", 1)[-1]
        if top_level:
            top_level_seen += 1
        style = _text(paragraph.get("style"))
        title_styled = bool(_TITLE_STYLE_RE.search(style))
        core_title = top_level and top_level_seen <= 12 and len(value) <= 180
        if title_styled:
            role, score = "styled_title", 120
        elif core_title:
            role, score = "core_title", 100
        elif len(value) <= 180:
            role, score = "body_statement", 65
        else:
            # Long prose may quote another document type and is not a title.
            continue
        for subtype, marker in _matches(value):
            signals.append(
                _signal(
                    subtype=subtype,
                    marker=marker,
                    source_id=source_id,
                    quote=value,
                    role=role,
                    score=score,
                )
            )

    for cell_index, cell in enumerate(table_cells):
        value = _text(cell.get("text"))
        if not value or len(value) > 180:
            continue
        for subtype, marker in _matches(value):
            signals.append(
                _signal(
                    subtype=subtype,
                    marker=marker,
                    source_id=str(cell.get("source_id") or f"docx:cell:{cell_index}"),
                    quote=value,
                    role="table_statement",
                    score=80,
                )
            )

    filename_advisory = [
        {
            "document_subtype": subtype,
            "matched_marker": marker,
            "source_id": "source.original_filename",
            "quote": _text(original_filename),
            "source_ref": {
                "part": "source.original_filename",
                "authority": "advisory",
            },
            "role": "filename_advisory",
        }
        for subtype, marker in _matches(_text(original_filename))
    ]

    scores: dict[str, int] = {}
    for subtype in _SUBTYPE_PATTERNS:
        subtype_signals = [
            signal for signal in signals if signal["document_subtype"] == subtype
        ]
        if subtype_signals:
            scores[subtype] = max(signal["score"] for signal in subtype_signals) + min(
                20, 3 * (len(subtype_signals) - 1)
            ) + _SUBTYPE_PRIORITY_BONUS[subtype]

    selected: str | None = None
    if scores:
        ranked = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
        selected = ranked[0][0]
        if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
            selected = None

    selected_signals = [
        signal for signal in signals if signal["document_subtype"] == selected
    ]
    return {
        "schema_version": "m1.native-classification.v1",
        "source": "docx-native-classifier-v1",
        "document_type": "technical_document" if selected else "unknown",
        "document_subtype": selected or "unknown",
        "authority": "native_content" if selected else "none",
        "confidence": (
            min(1.0, max(scores.get(selected or "", 0), 0) / 120.0)
            if selected
            else 0.0
        ),
        "evidence": selected_signals,
        "competing_evidence": [
            signal
            for signal in signals
            if signal["document_subtype"] != selected
        ],
        "filename_advisory": filename_advisory,
    }


__all__ = ["classify_docx_native_content"]
