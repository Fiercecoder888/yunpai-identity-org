"""Lossless native OOXML evidence extraction for DOCX documents.

This parser is intentionally independent from the business DOCX adapter and
from model-backed parsing. It does not classify or normalize business facts.
It preserves the main Word story order, deterministic source identities,
table cells, and relationship-backed image evidence in ``DocumentEvidence``.
"""

from __future__ import annotations

import hashlib
import posixpath
import time
import unicodedata
from collections.abc import Iterable
from pathlib import Path, PurePosixPath
from typing import Any
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile

from ..ooxml import OOXMLPackageError, preflight_ooxml_package
from .docx_native_classification import classify_docx_native_content
from .evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)

_DOCUMENT_PART = "word/document.xml"
_RELATIONSHIP_NS_MARKER = "/relationships"


class DOCXNativeEvidenceError(RuntimeError):
    """A DOCX package cannot produce bounded authoritative OOXML evidence."""


def _local_name(value: str) -> str:
    return value.rsplit("}", 1)[-1]


def _namespace(value: str) -> str:
    return value[1:].split("}", 1)[0] if value.startswith("{") else ""


def _children(element: ET.Element, name: str) -> Iterable[ET.Element]:
    return (child for child in element if _local_name(child.tag) == name)


def _descendants(element: ET.Element, name: str) -> Iterable[ET.Element]:
    return (item for item in element.iter() if _local_name(item.tag) == name)


def _attribute(element: ET.Element | None, name: str, default: str = "") -> str:
    if element is None:
        return default
    for key, value in element.attrib.items():
        if _local_name(key) == name:
            return value
    return default


def _first_child(element: ET.Element | None, name: str) -> ET.Element | None:
    if element is None:
        return None
    return next(_children(element, name), None)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _xml(package: ZipFile, name: str, *, required: bool = True) -> ET.Element | None:
    try:
        payload = package.read(name)
    except KeyError:
        if not required:
            return None
        raise DOCXNativeEvidenceError(f"DOCX package is missing {name}") from None
    try:
        return ET.fromstring(payload)
    except ET.ParseError as exc:
        raise DOCXNativeEvidenceError(f"Malformed OOXML part {name}") from exc


def _relationship_part(part: str) -> str:
    directory, filename = posixpath.split(part)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def _safe_target(base_part: str, target: str) -> str:
    if (
        not target
        or "\x00" in target
        or "\\" in target
        or target.startswith("/")
    ):
        raise DOCXNativeEvidenceError(
            f"Unsafe OOXML relationship target: {target!r}"
        )
    resolved = posixpath.normpath(
        posixpath.join(posixpath.dirname(base_part), target)
    )
    parts = PurePosixPath(resolved).parts
    if resolved in {"", ".", ".."} or any(part == ".." for part in parts):
        raise DOCXNativeEvidenceError(
            f"OOXML relationship escapes the package: {target!r}"
        )
    return resolved


def _relationships(package: ZipFile, part: str) -> dict[str, dict[str, Any]]:
    root = _xml(package, _relationship_part(part), required=False)
    if root is None:
        return {}
    result: dict[str, dict[str, Any]] = {}
    for item in root:
        if _local_name(item.tag) != "Relationship":
            continue
        relation_id = item.get("Id") or ""
        target = item.get("Target") or ""
        if not relation_id or not target:
            continue
        if relation_id in result:
            raise DOCXNativeEvidenceError(
                f"Duplicate OOXML relationship ID: {relation_id}"
            )
        external = (item.get("TargetMode") or "").casefold() == "external"
        result[relation_id] = {
            "relationship_id": relation_id,
            "type": item.get("Type") or "",
            "target_original": target,
            "target_part": None if external else _safe_target(part, target),
            "external": external,
        }
    return result


def _content_types(package: ZipFile) -> tuple[dict[str, str], dict[str, str]]:
    root = _xml(package, "[Content_Types].xml")
    assert root is not None
    defaults: dict[str, str] = {}
    overrides: dict[str, str] = {}
    for item in root:
        kind = _local_name(item.tag)
        if kind == "Default":
            defaults[(item.get("Extension") or "").casefold()] = (
                item.get("ContentType") or ""
            )
        elif kind == "Override":
            overrides[(item.get("PartName") or "").lstrip("/")] = (
                item.get("ContentType") or ""
            )
    return defaults, overrides


def _content_type(
    part: str,
    defaults: dict[str, str],
    overrides: dict[str, str],
) -> str:
    extension = PurePosixPath(part).suffix.lstrip(".").casefold()
    return overrides.get(part) or defaults.get(extension, "")


def _text(element: ET.Element) -> str:
    parts: list[str] = []

    def walk(item: ET.Element) -> None:
        name = _local_name(item.tag)
        if name in {"t", "instrText", "delText", "delInstrText"}:
            parts.append(item.text or "")
            return
        if name in {"tab", "ptab"}:
            parts.append("\t")
            return
        if name in {"br", "cr"}:
            parts.append("\n")
            return
        if name == "noBreakHyphen":
            parts.append("\u2011")
            return
        if name == "softHyphen":
            parts.append("\u00ad")
            return
        if name == "sym":
            raw = _attribute(item, "char")
            try:
                parts.append(chr(int(raw, 16)))
            except (TypeError, ValueError):
                pass
            return
        for child in item:
            walk(child)

    walk(element)
    return "".join(parts)


def _relationship_ids(element: ET.Element) -> list[str]:
    result: list[str] = []
    for item in element.iter():
        for key, value in item.attrib.items():
            if (
                _RELATIONSHIP_NS_MARKER in _namespace(key)
                and _local_name(key) in {"embed", "link", "id"}
                and value
            ):
                result.append(value)
    return list(dict.fromkeys(result))


def _paragraph_style(paragraph: ET.Element) -> dict[str, Any]:
    properties = _first_child(paragraph, "pPr")
    style = _first_child(properties, "pStyle")
    numbering = _first_child(properties, "numPr")
    return {
        "style": _attribute(style, "val") or None,
        "numbering_id": _attribute(_first_child(numbering, "numId"), "val") or None,
        "numbering_level": _attribute(_first_child(numbering, "ilvl"), "val") or None,
    }


def _image_alt_text(paragraph: ET.Element) -> list[str]:
    values: list[str] = []
    for item in _descendants(paragraph, "docPr"):
        for name in ("name", "descr", "title"):
            value = item.get(name)
            if value:
                values.append(value)
    return list(dict.fromkeys(values))


def _is_image_relationship(relation: dict[str, Any] | None) -> bool:
    return bool(relation and str(relation.get("type") or "").endswith("/image"))


def parse_docx_native_evidence(
    path: str | Path,
    *,
    original_filename: str | None = None,
) -> DocumentEvidence:
    """Return deterministic OOXML evidence without classification or model calls."""

    started = time.perf_counter()
    source = Path(path)
    display_filename = original_filename or source.name
    if not source.is_file():
        raise FileNotFoundError(source)
    try:
        package_stats = preflight_ooxml_package(source, expected_kind="document")
    except OOXMLPackageError as exc:
        raise DOCXNativeEvidenceError(str(exc)) from exc

    try:
        package = ZipFile(source, "r")
    except BadZipFile as exc:
        raise DOCXNativeEvidenceError("Invalid DOCX ZIP package") from exc
    try:
        names = set(package.namelist())
        root = _xml(package, _DOCUMENT_PART)
        assert root is not None
        body = next(_descendants(root, "body"), None)
        if body is None:
            raise DOCXNativeEvidenceError("word/document.xml has no body")
        relationships = _relationships(package, _DOCUMENT_PART)
        defaults, overrides = _content_types(package)

        references: dict[str, list[dict[str, Any]]] = {}
        paragraphs: list[dict[str, Any]] = []
        tables: list[EvidenceTable] = []
        blocks: list[EvidenceBlock] = []
        body_order: list[dict[str, Any]] = []
        unknown_body_elements: list[dict[str, Any]] = []
        table_counter = 0

        image_ids = {
            relation_id: f"docx:image:{relation_id}"
            for relation_id, relation in relationships.items()
            if _is_image_relationship(relation)
        }

        def paragraph_record(
            element: ET.Element,
            *,
            source_id: str,
            sequence: int,
        ) -> dict[str, Any]:
            relation_ids = _relationship_ids(element)
            image_refs = [
                image_ids[relation_id]
                for relation_id in relation_ids
                if relation_id in image_ids
            ]
            alt_text = _image_alt_text(element)
            for relation_id in relation_ids:
                references.setdefault(relation_id, []).append(
                    {
                        "source_id": source_id,
                        "image_alt_text": alt_text,
                    }
                )
            value = _text(element)
            record = {
                "source_id": source_id,
                "sequence": sequence,
                "text": value,
                "text_nfkc": unicodedata.normalize("NFKC", value),
                "relationship_ids": relation_ids,
                "image_refs": image_refs,
                "image_alt_text": alt_text,
                **_paragraph_style(element),
            }
            paragraphs.append(record)
            return record

        def table_text(element: ET.Element) -> str:
            rendered_rows: list[str] = []
            for row in _children(element, "tr"):
                rendered_rows.append(
                    "\t".join(_text(cell) for cell in _children(row, "tc"))
                )
            return "\n".join(rendered_rows)

        def parse_table(
            element: ET.Element,
            *,
            source_id: str,
            parent_source_id: str | None,
        ) -> str:
            nonlocal table_counter
            table_id = f"docx:t:{table_counter}"
            table_sequence = table_counter
            table_counter += 1
            matrix: list[list[str | None]] = []
            evidence_cells: list[EvidenceCell] = []
            nested: list[tuple[ET.Element, str, str]] = []
            table_relationship_ids: list[str] = []
            for row_index, row in enumerate(_children(element, "tr")):
                logical_column = 0
                row_values: list[str | None] = []
                for cell_index, cell in enumerate(_children(row, "tc")):
                    properties = _first_child(cell, "tcPr")
                    span_element = _first_child(properties, "gridSpan")
                    merge_element = _first_child(properties, "vMerge")
                    try:
                        span = max(1, int(_attribute(span_element, "val", "1")))
                    except ValueError:
                        span = 1
                    cell_source = (
                        f"{source_id}/row:{row_index}/cell:{cell_index}"
                    )
                    paragraph_ids: list[str] = []
                    nested_ids: list[str] = []
                    pieces: list[str] = []
                    paragraph_index = nested_index = 0
                    for child in cell:
                        kind = _local_name(child.tag)
                        if kind == "p":
                            paragraph_source = (
                                f"{cell_source}/paragraph:{paragraph_index}"
                            )
                            record = paragraph_record(
                                child,
                                source_id=paragraph_source,
                                sequence=len(paragraphs),
                            )
                            paragraph_ids.append(paragraph_source)
                            pieces.append(record["text"])
                            paragraph_index += 1
                        elif kind == "tbl":
                            nested_source = f"{cell_source}/table:{nested_index}"
                            pieces.append(table_text(child))
                            nested.append((child, nested_source, cell_source))
                            nested_ids.append(nested_source)
                            nested_index += 1
                        elif kind != "tcPr":
                            value = _text(child)
                            if value:
                                pieces.append(value)
                    value = "\n".join(piece for piece in pieces if piece)
                    while len(row_values) < logical_column:
                        row_values.append(None)
                    row_values.append(value)
                    row_values.extend([None] * (span - 1))
                    relation_ids = _relationship_ids(cell)
                    table_relationship_ids.extend(relation_ids)
                    evidence_cells.append(
                        EvidenceCell(
                            row=row_index,
                            column=logical_column,
                            text=value,
                            confidence=1.0,
                            source_id=cell_source,
                            grid_span=span,
                            vertical_merge=(
                                _attribute(merge_element, "val", "continue")
                                if merge_element is not None
                                else None
                            ),
                            paragraph_source_ids=paragraph_ids,
                            nested_table_source_ids=nested_ids,
                            relationship_ids=relation_ids,
                            image_refs=[
                                image_ids[relation_id]
                                for relation_id in relation_ids
                                if relation_id in image_ids
                            ],
                        )
                    )
                    logical_column += span
                matrix.append(row_values)
            width = max((len(row) for row in matrix), default=0)
            matrix = [row + [None] * (width - len(row)) for row in matrix]
            tables.append(
                EvidenceTable(
                    table_id=table_id,
                    rows=matrix,
                    cells=evidence_cells,
                    confidence=1.0,
                    source="docx-native-ooxml",
                    source_id=source_id,
                    sequence=table_sequence,
                    parent_source_id=parent_source_id,
                    relationship_ids=list(dict.fromkeys(table_relationship_ids)),
                    image_refs=[
                        image_ids[relation_id]
                        for relation_id in dict.fromkeys(table_relationship_ids)
                        if relation_id in image_ids
                    ],
                )
            )
            for nested_element, nested_source, cell_source in nested:
                parse_table(
                    nested_element,
                    source_id=nested_source,
                    parent_source_id=cell_source,
                )
            return table_id

        top_paragraph_index = top_table_index = 0
        for body_index, child in enumerate(body):
            kind = _local_name(child.tag)
            if kind == "p":
                source_id = (
                    f"{_DOCUMENT_PART}#paragraph:{top_paragraph_index}"
                )
                record = paragraph_record(
                    child,
                    source_id=source_id,
                    sequence=len(paragraphs),
                )
                blocks.append(
                    EvidenceBlock(
                        block_id=f"docx:p:{top_paragraph_index}",
                        kind="paragraph",
                        text=record["text"],
                        confidence=1.0,
                        order=body_index,
                        source="docx-native-ooxml",
                        source_id=source_id,
                        relationship_ids=record["relationship_ids"],
                        image_refs=record["image_refs"],
                        style=record["style"],
                    )
                )
                body_order.append(
                    {
                        "order": body_index,
                        "kind": "paragraph",
                        "source_id": source_id,
                        "block_id": f"docx:p:{top_paragraph_index}",
                    }
                )
                top_paragraph_index += 1
            elif kind == "tbl":
                source_id = f"{_DOCUMENT_PART}#table:{top_table_index}"
                table_id = parse_table(
                    child,
                    source_id=source_id,
                    parent_source_id=None,
                )
                blocks.append(
                    EvidenceBlock(
                        block_id=f"docx:table-marker:{top_table_index}",
                        kind="table",
                        text="",
                        confidence=1.0,
                        order=body_index,
                        source="docx-native-ooxml",
                        source_id=source_id,
                        table_id=table_id,
                    )
                )
                body_order.append(
                    {
                        "order": body_index,
                        "kind": "table",
                        "source_id": source_id,
                        "table_id": table_id,
                    }
                )
                top_table_index += 1
            elif kind != "sectPr":
                unknown_body_elements.append(
                    {
                        "order": body_index,
                        "kind": kind,
                        "source_id": f"{_DOCUMENT_PART}#body:{body_index}",
                        "text": _text(child),
                    }
                )

        warnings: list[str] = []
        for relation_id in references:
            if relation_id not in relationships:
                warnings.append(f"missing_relationship:{relation_id}")

        relationship_records: list[dict[str, Any]] = []
        images: list[dict[str, Any]] = []
        for relation_id, relation in relationships.items():
            references_for_relation = references.get(relation_id, [])
            target_part = relation.get("target_part")
            record = {
                **relation,
                "target_exists": (
                    False
                    if relation["external"]
                    else bool(target_part in names)
                ),
                "content_type": (
                    ""
                    if relation["external"] or not isinstance(target_part, str)
                    else _content_type(target_part, defaults, overrides)
                ),
                "references": references_for_relation,
            }
            relationship_records.append(record)
            if not _is_image_relationship(relation):
                continue
            if relation["external"]:
                warnings.append(f"external_image_relationship:{relation_id}")
                continue
            if not isinstance(target_part, str) or target_part not in names:
                warnings.append(f"missing_image_part:{relation_id}")
                continue
            payload = package.read(target_part)
            images.append(
                {
                    "image_id": image_ids[relation_id],
                    "relationship_id": relation_id,
                    "target_part": target_part,
                    "content_type": record["content_type"],
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "byte_size": len(payload),
                    "references": references_for_relation,
                }
            )

        elapsed_ms = (time.perf_counter() - started) * 1000.0
        native_classification = classify_docx_native_content(
            paragraphs=paragraphs,
            table_cells=(
                {
                    "text": cell.text,
                    "source_id": str((cell.model_extra or {}).get("source_id") or ""),
                }
                for table in tables
                for cell in table.cells
            ),
            original_filename=display_filename,
        )
        return DocumentEvidence(
            backend="docx-native-ooxml",
            backend_version="1",
            elapsed_ms=elapsed_ms,
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=1,
                    height=1,
                    coordinate_space="unknown",
                    blocks=sorted(blocks, key=lambda item: item.order),
                    tables=sorted(
                        tables,
                        key=lambda item: int(
                            (item.model_extra or {}).get("sequence", 0)
                        ),
                    ),
                    raw={
                        "virtual_page": True,
                        "body_order": body_order,
                    },
                )
            ],
            warnings=sorted(set(warnings)),
            raw={
                "contract": "m1.docx-native-evidence.v1",
                "source": {
                    "original_filename": display_filename,
                    "sha256": _sha256(source),
                    "size_bytes": source.stat().st_size,
                },
                "part": _DOCUMENT_PART,
                "native_classification": native_classification,
                "paragraphs": paragraphs,
                "body_order": body_order,
                "relationships": relationship_records,
                "images": images,
                "unknown_body_elements": unknown_body_elements,
                "package": {
                    "entry_count": len(package_stats.members),
                    "total_uncompressed_bytes": package_stats.total_uncompressed,
                },
            },
        )
    except BadZipFile as exc:
        raise DOCXNativeEvidenceError("Corrupt DOCX package") from exc
    finally:
        package.close()


class DOCXNativeEvidenceParser:
    """Small parser object for future injection into the document router."""

    backend = "docx-native-ooxml"

    def parse(self, path: str | Path) -> DocumentEvidence:
        return parse_docx_native_evidence(path)


__all__ = [
    "DOCXNativeEvidenceError",
    "DOCXNativeEvidenceParser",
    "parse_docx_native_evidence",
]
