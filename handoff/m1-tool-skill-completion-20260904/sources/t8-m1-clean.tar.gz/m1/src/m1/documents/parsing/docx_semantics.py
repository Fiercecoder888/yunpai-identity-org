"""Deterministic DOCX process facts and advisory filename metadata.

The helpers in this module are deliberately projection-free.  Verified process
facts come only from an explicit process heading followed by structurally
separated native DOCX paragraphs.  Filename facts are always advisory and can
therefore be retained without mutating authoritative document fields.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from ..models import SourceReference
from .evidence import DocumentEvidence, EvidenceBlock
from .semantic_facts import SemanticEvidence, SemanticFact, stable_fact_id

_DOCX_PARAGRAPH_RE = re.compile(r"(?:^|/)docx:p:(?P<index>\d+)$")
_HEADING_PREFIX_RE = re.compile(
    r"^\s*(?:(?:\d+(?:\.\d+)*|[一二三四五六七八九十]+)[、.．)）]\s*)?"
)
_PROCESS_HEADINGS = {
    "工艺流程",
    "生产工艺流程",
    "制造工艺流程",
    "加工工艺流程",
    "装配工艺流程",
    "作业流程",
    "操作流程",
    "工艺步骤",
    "制造步骤",
    "process flow",
    "manufacturing process",
    "workflow",
}
_FLOW_SEPARATOR_RE = re.compile(
    r"(?:\t+|[ \u3000]{2,}|[\r\n]+|[ \t]*(?:→|➜|➡|⇒|->)[ \t]*)"
)
_NON_STEP_BOUNDARY_RE = re.compile(
    r"(?:图纸|规格表|参数表|产品名称|drawing|specification)",
    re.IGNORECASE,
)
_DATE_RE = re.compile(
    r"(?<!\d)(?:(?:19|20)\d{2}[._-]\d{1,2}[._-]\d{1,2}|"
    r"(?:19|20)\d{6})(?!\d)"
)
_UUID_RE = re.compile(
    r"(?<![0-9a-f])(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-"
    r"[89ab][0-9a-f]{3}-[0-9a-f]{12}|[0-9a-f]{32})(?![0-9a-f])",
    re.IGNORECASE,
)
_DECIMAL_LENGTH_RE = re.compile(
    r"(?<![A-Za-z0-9])(?P<value>\d{1,5}\.\d{1,4})"
    r"(?P<spacing>\s*)(?P<unit>mm|cm|inch|in|m)?(?![A-Za-z0-9])",
    re.IGNORECASE,
)
_ALPHANUMERIC_MODEL_RE = re.compile(
    r"(?<![A-Za-z0-9])(?=[A-Za-z0-9]{3,32}(?![A-Za-z0-9]))"
    r"(?=[A-Za-z0-9]*[A-Za-z])(?=[A-Za-z0-9]*\d)[A-Za-z0-9]+"
)
_NUMERIC_MODEL_RE = re.compile(r"(?<![A-Za-z0-9.])\d{4,12}(?![A-Za-z0-9.])")
_SHAPE_RE = re.compile(
    r"(?:(?:长|短|大|小|内凹|外凸){0,2})"
    r"(?:波浪形|椭圆形|矩形|弧形|圆形|方形|直形|弯形|异形)"
)
_COLOR_RE = re.compile(
    r"(?:透明|本色|玫瑰金|香槟金|"
    r"(?:太空|深空|浅|深|亮|哑光|磨砂)?"
    r"(?:灰|黑|白|红|蓝|绿|黄|金|银)(?:色)?)"
)
_MODEL_NOISE_RE = re.compile(
    r"(?:final|copy|draft|backup|temp|tmp|version|rev|最终版|最新版|定稿|终稿|副本)",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class _NativeBlock:
    page_index: int
    position: int
    block: EvidenceBlock


@dataclass(frozen=True, slots=True)
class _Span:
    start: int
    end: int
    text: str


@dataclass(frozen=True, slots=True)
class _FilenameCandidate:
    name: str
    value: str
    start: int
    end: int
    unit: str | None
    confidence: float


def extract_docx_process_facts(evidence: DocumentEvidence) -> list[SemanticFact]:
    """Atomize unambiguous process flows following explicit DOCX headings.

    The returned character ranges address the original paragraph string.  A
    paragraph without structural separators ends the active section, so normal
    prose and single-space token sequences fail closed instead of being guessed.
    """

    blocks = _ordered_native_blocks(evidence)
    facts: list[SemanticFact] = []
    fact_order = 0
    section_order = 0

    for heading_position, native in enumerate(blocks):
        heading = native.block
        if not _is_process_heading(heading.text):
            continue
        section_order += 1
        order_in_section = 0
        blank_count = 0

        for candidate in blocks[heading_position + 1 :]:
            block = candidate.block
            if _is_process_heading(block.text):
                break
            paragraph_match = _DOCX_PARAGRAPH_RE.search(block.block_id)
            if paragraph_match is None:
                break
            if not block.text.strip():
                blank_count += 1
                if blank_count > 1:
                    break
                continue
            blank_count = 0
            spans = _process_step_spans(block.text)
            if not spans:
                break

            for span in spans:
                fact_order += 1
                order_in_section += 1
                attributes = {
                    "order": fact_order,
                    "section_order": section_order,
                    "order_in_section": order_in_section,
                    "heading_evidence_id": heading.block_id,
                    "parent_evidence_id": block.block_id,
                    "char_start": span.start,
                    "char_end": span.end,
                    "range": f"chars:{span.start}:{span.end}",
                }
                step_evidence = SemanticEvidence(
                    evidence_id=block.block_id,
                    quote=span.text,
                    source_ref=_block_source_ref(
                        block,
                        page_number=evidence.pages[candidate.page_index].page_number,
                        start=span.start,
                        end=span.end,
                    ),
                )
                heading_evidence = SemanticEvidence(
                    evidence_id=heading.block_id,
                    quote=heading.text,
                    source_ref=_block_source_ref(
                        heading,
                        page_number=evidence.pages[native.page_index].page_number,
                    ),
                )
                evidence_refs = [step_evidence, heading_evidence]
                fact_id = stable_fact_id(
                    name="manufacturing_process_step",
                    value=span.text,
                    attributes=attributes,
                    evidence_ids=(item.evidence_id for item in evidence_refs),
                )
                fact_confidence = min(
                    _block_confidence(heading),
                    _block_confidence(block),
                )
                facts.append(
                    SemanticFact(
                        fact_id=fact_id,
                        name="manufacturing_process_step",
                        value=span.text,
                        attributes=attributes,
                        evidence_refs=evidence_refs,
                        extractor="docx_explicit_process_flow",
                        confidence=fact_confidence,
                        status="verified",
                    )
                )
    return facts


def extract_filename_advisory_facts(original_filename: str) -> list[SemanticFact]:
    """Return explainable filename token candidates without promoting them.

    Every quote is an exact substring of the basename stem.  These facts are
    always advisory, even if another evidence source happens to agree with them.
    """

    filename = re.split(r"[\\/]", str(original_filename or ""))[-1]
    stem = Path(filename).stem
    if not stem:
        return []

    excluded = [
        *(match.span() for match in _DATE_RE.finditer(stem)),
        *(match.span() for match in _UUID_RE.finditer(stem)),
    ]
    length_spans: list[tuple[int, int]] = []
    candidates: list[_FilenameCandidate] = []

    for match in _DECIMAL_LENGTH_RE.finditer(stem):
        start, value_end = match.span("value")
        end = match.end("unit") if match.group("unit") else value_end
        if _overlaps((start, end), excluded):
            continue
        unit = match.group("unit")
        candidates.append(
            _FilenameCandidate(
                name="length",
                value=match.group("value"),
                start=start,
                end=end,
                unit=unit.casefold() if unit else None,
                confidence=0.65,
            )
        )
        length_spans.append((start, end))

    protected = [*excluded, *length_spans]
    for pattern in (_ALPHANUMERIC_MODEL_RE, _NUMERIC_MODEL_RE):
        for match in pattern.finditer(stem):
            span = match.span()
            value = match.group(0)
            if _overlaps(span, protected) or _MODEL_NOISE_RE.search(value):
                continue
            candidates.append(
                _FilenameCandidate(
                    name="model",
                    value=value,
                    start=span[0],
                    end=span[1],
                    unit=None,
                    confidence=0.62,
                )
            )

    for name, pattern, confidence in (
        ("shape", _SHAPE_RE, 0.58),
        ("color", _COLOR_RE, 0.58),
    ):
        for match in pattern.finditer(stem):
            start, end = match.span()
            if _overlaps((start, end), excluded):
                continue
            candidates.append(
                _FilenameCandidate(
                    name=name,
                    value=match.group(0),
                    start=start,
                    end=end,
                    unit=None,
                    confidence=confidence,
                )
            )

    facts: list[SemanticFact] = []
    seen: set[tuple[str, str, int, int]] = set()
    for candidate in sorted(candidates, key=lambda item: (item.start, item.end, item.name)):
        marker = (
            candidate.name,
            candidate.value.casefold(),
            candidate.start,
            candidate.end,
        )
        if marker in seen:
            continue
        seen.add(marker)
        quote = stem[candidate.start : candidate.end]
        if quote != candidate.value and candidate.name != "length":
            continue
        if candidate.name == "length" and not quote.startswith(candidate.value):
            continue
        source_range = f"chars:{candidate.start}:{candidate.end}"
        attributes = {
            "authority": "advisory",
            "parent_evidence_id": "source.filename",
            "char_start": candidate.start,
            "char_end": candidate.end,
            "range": source_range,
        }
        evidence_ref = SemanticEvidence(
            evidence_id="source.filename",
            quote=quote,
            source_ref=SourceReference(
                part="source.original_filename",
                range=source_range,
                authority="advisory",
                inferred=True,
                parent_evidence_id="source.filename",
            ),
        )
        fact_id = stable_fact_id(
            name=candidate.name,
            value=candidate.value,
            unit=candidate.unit,
            attributes=attributes,
            evidence_ids=[evidence_ref.evidence_id],
        )
        facts.append(
            SemanticFact(
                fact_id=fact_id,
                name=candidate.name,
                value=candidate.value,
                unit=candidate.unit,
                attributes=attributes,
                evidence_refs=[evidence_ref],
                extractor="filename_token_candidates",
                confidence=candidate.confidence,
                status="advisory",
            )
        )
    return facts


def _ordered_native_blocks(evidence: DocumentEvidence) -> list[_NativeBlock]:
    blocks: list[_NativeBlock] = []
    for page_index, page in enumerate(evidence.pages):
        for position, block in enumerate(page.blocks):
            if not (
                block.source == "docx-native-ooxml"
                or block.block_id.startswith("docx:")
            ):
                continue
            blocks.append(
                _NativeBlock(
                    page_index=page_index,
                    position=position,
                    block=block,
                )
            )
    return sorted(
        blocks,
        key=lambda item: (
            item.page_index,
            item.block.order,
            item.position,
        ),
    )


def _is_process_heading(value: str) -> bool:
    normalized = unicodedata.normalize("NFKC", value or "")
    normalized = _HEADING_PREFIX_RE.sub("", normalized)
    normalized = " ".join(normalized.strip().strip(":：").split()).casefold()
    return normalized in _PROCESS_HEADINGS


def _process_step_spans(value: str) -> list[_Span]:
    matches = list(_FLOW_SEPARATOR_RE.finditer(value))
    if not matches:
        return []
    spans: list[_Span] = []
    cursor = 0
    for match in [*matches, None]:
        end = len(value) if match is None else match.start()
        trimmed = _trim_span(value, cursor, end)
        if trimmed is not None:
            spans.append(trimmed)
        if match is not None:
            cursor = match.end()
    if len(spans) < 2:
        return []
    if any(
        not span.text
        or len(span.text) > 48
        or _NON_STEP_BOUNDARY_RE.search(span.text)
        for span in spans
    ):
        return []
    return spans


def _trim_span(value: str, start: int, end: int) -> _Span | None:
    while start < end and value[start].isspace():
        start += 1
    while end > start and value[end - 1].isspace():
        end -= 1
    if start >= end:
        return None
    text = value[start:end]
    return _Span(start=start, end=end, text=text)


def _block_source_ref(
    block: EvidenceBlock,
    *,
    page_number: int,
    start: int | None = None,
    end: int | None = None,
) -> SourceReference:
    extras = block.model_extra or {}
    payload: dict[str, object] = {
        "page": page_number,
        "part": str(extras.get("source_ref_part") or f"mineru/{block.block_id}"),
    }
    if extras.get("source_id"):
        payload["native_source_id"] = str(extras["source_id"])
    if block.bbox is not None:
        payload["bbox"] = block.bbox.as_list()
        payload["coordinate_space"] = block.bbox.coordinate_space
    if start is not None and end is not None:
        payload.update(
            {
                "range": f"chars:{start}:{end}",
                "parent_evidence_id": block.block_id,
                "coordinate_inferred": True,
            }
        )
    return SourceReference.model_validate(payload)


def _block_confidence(block: EvidenceBlock) -> float:
    return float(block.confidence) if block.confidence is not None else 0.99


def _overlaps(span: tuple[int, int], others: list[tuple[int, int]]) -> bool:
    return any(span[0] < end and span[1] > start for start, end in others)


__all__ = [
    "extract_docx_process_facts",
    "extract_filename_advisory_facts",
]
