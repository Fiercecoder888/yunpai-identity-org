"""Fail-closed region VLM transcription for engineering drawing callouts.

PaddleOCR is used only to propose image regions.  Its recognized text is
reduced to a numeric-selection hint and is never used as fact evidence.  A
small, injected vision model transcribes each bounded crop; the existing
``drawing_semantics`` parser remains the only callout grammar authority.

This module is intentionally runtime-neutral until a caller wires it into a
workflow.  Endpoints, model names, credentials, and offline Paddle model roots
are all supplied by the caller.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import inspect
import io
import math
import re
import tempfile
import threading
import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar, Literal, Protocol

from PIL import Image
from PIL import __version__ as PILLOW_VERSION
from pydantic import Field, computed_field

from ..models import SourceReference
from .drawing_semantics import extract_drawing_semantics
from .semantic_facts import (
    SemanticEvidence,
    SemanticFact,
    StrictSemanticModel,
    stable_fact_id,
)

DRAWING_REGION_PROMPT = (
    "Transcribe the single engineering drawing dimension callout in this crop. "
    "Return exactly one line containing only the callout. Preserve radius, "
    "diameter or thickness markers, the nominal decimal, symmetric or stacked "
    "upper/lower tolerances, signs, decimal points, and unit. Plain text or "
    "LaTeX is allowed. Return INVALID when no single complete callout is visible."
)

_NEWLINE_STOP = ("\n",)
_NUMBER_HINT = re.compile(r"\d")
_SHA256_HEX = re.compile(r"^[0-9a-fA-F]{64}$")
_INVALID_OUTPUT = re.compile(
    r"^(?:invalid|none|n/?a|unknown|not\s+(?:visible|legible|a\s+callout))\.?$",
    re.IGNORECASE,
)
_DECIMAL = r"(?:\d+(?:\.\d+)?|\.\d+)"
_LATEX_STACKED_UPPER_FIRST = re.compile(
    rf"(?P<nominal>{_DECIMAL})\s*"
    rf"\^\{{\s*\+\s*(?P<upper>{_DECIMAL})\s*\}}\s*"
    rf"_\{{\s*-\s*(?P<lower>{_DECIMAL})\s*\}}"
)
_LATEX_STACKED_LOWER_FIRST = re.compile(
    rf"(?P<nominal>{_DECIMAL})\s*"
    rf"_\{{\s*-\s*(?P<lower>{_DECIMAL})\s*\}}\s*"
    rf"\^\{{\s*\+\s*(?P<upper>{_DECIMAL})\s*\}}"
)
_MODEL_CONTROL_SUFFIX = re.compile(
    r"(?:\s*<\|[A-Za-z0-9_:-]+\|>)+\s*$"
)
_PLAIN_STACKED_TOLERANCE = re.compile(
    rf"^(?P<prefix>(?:[RrØΦφ⌀]|厚度\s*[:=]?)?\s*)"
    rf"(?P<nominal>{_DECIMAL})\s*\+\s*(?P<upper>{_DECIMAL})\s*"
    rf"-\s*(?P<lower>{_DECIMAL})(?P<unit>\s*(?:mm|cm|in))?$",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class OCRRegionProposal:
    """One OCR location proposal with no reusable recognized text."""

    bbox: tuple[float, float, float, float]
    score: float
    contains_numeric_hint: bool = False

    def __post_init__(self) -> None:
        if len(self.bbox) != 4 or not all(math.isfinite(value) for value in self.bbox):
            raise ValueError("OCR region bbox must contain four finite coordinates")
        x0, y0, x1, y1 = self.bbox
        if x1 <= x0 or y1 <= y0:
            raise ValueError("OCR region bbox must have positive width and height")
        if not math.isfinite(self.score) or not 0.0 <= self.score <= 1.0:
            raise ValueError("OCR region score must be between zero and one")


@dataclass(frozen=True, slots=True)
class RegionVLMResponse:
    """Minimal response needed from an OpenAI-compatible vision endpoint."""

    text: str
    finish_reason: str | None = None


@dataclass(frozen=True, slots=True)
class DrawingRegionVLMConfig:
    """Bounded defaults for one drawing asset."""

    max_candidates: int = 16
    min_area_pixels: int = 96
    low_confidence_threshold: float = 0.72
    abnormal_aspect_ratio: float = 3.5
    duplicate_iou_threshold: float = 0.85
    padding_ratio: float = 0.35
    minimum_padding_pixels: int = 4
    upscale_factor: int = 4
    rotate_vertical: bool = True
    vertical_rotation_ratio: float = 1.25
    max_tokens: int = 64
    max_response_chars: int = 192
    request_timeout_seconds: float = 30.0

    def __post_init__(self) -> None:
        if self.max_candidates < 1:
            raise ValueError("max_candidates must be positive")
        if self.min_area_pixels < 1:
            raise ValueError("min_area_pixels must be positive")
        if not 0.0 <= self.low_confidence_threshold <= 1.0:
            raise ValueError("low_confidence_threshold must be between zero and one")
        if self.abnormal_aspect_ratio <= 1.0:
            raise ValueError("abnormal_aspect_ratio must be greater than one")
        if not 0.0 < self.duplicate_iou_threshold <= 1.0:
            raise ValueError("duplicate_iou_threshold must be in (0, 1]")
        if self.padding_ratio < 0.0 or self.minimum_padding_pixels < 0:
            raise ValueError("crop padding cannot be negative")
        if self.upscale_factor not in {3, 4}:
            raise ValueError("upscale_factor must be 3 or 4")
        if self.vertical_rotation_ratio <= 1.0:
            raise ValueError("vertical_rotation_ratio must be greater than one")
        if not 1 <= self.max_tokens <= 64:
            raise ValueError("max_tokens must be between 1 and 64")
        if self.max_response_chars < 16:
            raise ValueError("max_response_chars is too small")
        if self.request_timeout_seconds <= 0:
            raise ValueError("request_timeout_seconds must be positive")


class RegionOCR(Protocol):
    """Synchronous OCR locator; callers run it off the event loop."""

    def locate(self, image: Image.Image) -> Sequence[OCRRegionProposal]:
        ...


class RegionVLMClient(Protocol):
    """Injected asynchronous region transcription client."""

    async def transcribe(
        self,
        image_png: bytes,
        *,
        prompt: str,
        temperature: float,
        max_tokens: int,
        stop: Sequence[str],
    ) -> RegionVLMResponse:
        ...


class RegionVLMModelUnavailableError(RuntimeError):
    """The endpoint is reachable but does not serve the configured model."""


DrawingRegionDisposition = Literal[
    "fact",
    "duplicate",
    "candidate_limit",
    "not_a_callout",
    "screened",
    "ambiguous",
    "invalid",
    "failed",
    "truncated",
    "conflict",
]


class DrawingRegionVLMIssue(StrictSemanticModel):
    """A region that could not safely become a semantic fact."""

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    source_ref: SourceReference
    candidate_id: str | None = None
    fact_ids: list[str] = Field(default_factory=list)


class DrawingRegionAudit(StrictSemanticModel):
    """Provider-neutral audit entry for every selected or discarded proposal."""

    candidate_id: str = Field(min_length=1)
    source_ref: SourceReference
    ocr_score: float = Field(ge=0.0, le=1.0)
    selection_reasons: list[str] = Field(default_factory=list)
    rotation_degrees: Literal[0, 90] = 0
    disposition: DrawingRegionDisposition
    normalized_text: str | None = None
    fact_ids: list[str] = Field(default_factory=list)
    issue_codes: list[str] = Field(default_factory=list)


class DrawingRegionVLMResult(StrictSemanticModel):
    """Additive drawing facts plus complete region-level audit state."""

    facts: list[SemanticFact] = Field(default_factory=list)
    issues: list[DrawingRegionVLMIssue] = Field(default_factory=list)
    audit: list[DrawingRegionAudit] = Field(default_factory=list)

    @computed_field(return_type=bool)
    @property
    def needs_review(self) -> bool:
        return bool(self.issues)


class OpenAICompatibleRegionVLMClient:
    """Small async HTTP adapter for an injected OpenAI-compatible endpoint."""

    def __init__(
        self,
        *,
        http_client: Any,
        endpoint: str,
        model: str,
        headers: Mapping[str, str] | None = None,
        owns_http_client: bool = False,
    ) -> None:
        if not endpoint.strip():
            raise ValueError("endpoint must not be empty")
        if not model.strip():
            raise ValueError("model must not be empty")
        self._http_client = http_client
        self.endpoint = endpoint.rstrip("/")
        self.model = model
        self._headers = dict(headers or {})
        self._owns_http_client = owns_http_client

    async def transcribe(
        self,
        image_png: bytes,
        *,
        prompt: str,
        temperature: float,
        max_tokens: int,
        stop: Sequence[str],
    ) -> RegionVLMResponse:
        if not image_png:
            raise ValueError("image_png must not be empty")
        if temperature != 0:
            raise ValueError("drawing region transcription requires temperature=0")
        if not 1 <= max_tokens <= 64:
            raise ValueError("drawing region max_tokens cannot exceed 64")
        if tuple(stop) != _NEWLINE_STOP:
            raise ValueError("drawing region transcription requires newline stop")
        image_url = (
            "data:image/png;base64,"
            + base64.b64encode(image_png).decode("ascii")
        )
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": image_url},
                        },
                    ],
                }
            ],
            "temperature": 0,
            "max_tokens": max_tokens,
            "stop": list(_NEWLINE_STOP),
        }
        response = await self._http_client.post(
            self.endpoint,
            json=payload,
            headers=self._headers or None,
        )
        response.raise_for_status()
        body = response.json()
        choices = body.get("choices") if isinstance(body, Mapping) else None
        if not isinstance(choices, list) or not choices:
            raise ValueError("vision endpoint returned no choices")
        choice = choices[0]
        if not isinstance(choice, Mapping):
            raise TypeError("vision endpoint returned an invalid choice")
        message = choice.get("message")
        content = message.get("content") if isinstance(message, Mapping) else None
        if isinstance(content, list):
            content = "".join(
                str(item.get("text") or "")
                for item in content
                if isinstance(item, Mapping)
            )
        if not isinstance(content, str):
            raise TypeError("vision endpoint returned no text content")
        finish_reason = choice.get("finish_reason")
        return RegionVLMResponse(
            text=content,
            finish_reason=str(finish_reason) if finish_reason is not None else None,
        )

    async def aclose(self) -> None:
        if self._owns_http_client:
            await self._http_client.aclose()

    async def probe(self) -> dict[str, Any]:
        base = self.endpoint
        suffix = "/chat/completions"
        models_endpoint = (
            f"{base[: -len(suffix)]}/models" if base.endswith(suffix) else base
        )
        response = await self._http_client.get(
            models_endpoint,
            headers=self._headers or None,
        )
        response.raise_for_status()
        body = response.json()
        catalog = body.get("data") if isinstance(body, Mapping) else None
        available_models = {
            str(model_id).strip()
            for item in catalog or ()
            if isinstance(item, Mapping)
            and (model_id := item.get("id")) is not None
        }
        if self.model not in available_models:
            raise RegionVLMModelUnavailableError(
                f"configured model {self.model!r} is not served by the endpoint"
            )
        return {
            "ready": True,
            "configured": True,
            "model": self.model,
            "model_verified": True,
        }


class PaddleOCRRegionLocator:
    """Lazy, process-singleton PaddleOCR locator using only offline models."""

    _models: ClassVar[dict[tuple[str, str, str], Any]] = {}
    _models_lock: ClassVar[Any] = threading.Lock()
    _inference_lock: ClassVar[Any] = threading.Lock()

    def __init__(
        self,
        *,
        detection_model_dir: str | Path,
        recognition_model_dir: str | Path,
        device: str = "cpu",
        model_factory: Any | None = None,
    ) -> None:
        self.detection_model_dir = Path(detection_model_dir).expanduser()
        self.recognition_model_dir = Path(recognition_model_dir).expanduser()
        self.device = device.strip() or "cpu"
        self._model_factory = model_factory

    @classmethod
    def from_model_root(
        cls,
        model_root: str | Path,
        *,
        device: str = "cpu",
        model_factory: Any | None = None,
    ) -> PaddleOCRRegionLocator:
        root = Path(model_root).expanduser()
        detection = _offline_model_directory(root, "PP-OCRv5_server_det")
        recognition = _offline_model_directory(root, "PP-OCRv5_server_rec")
        return cls(
            detection_model_dir=detection,
            recognition_model_dir=recognition,
            device=device,
            model_factory=model_factory,
        )

    def _model_key(self) -> tuple[str, str, str]:
        return (
            str(self.detection_model_dir.resolve()),
            str(self.recognition_model_dir.resolve()),
            self.device,
        )

    def _model_options(self) -> dict[str, Any]:
        return {
            "text_detection_model_name": "PP-OCRv5_server_det",
            "text_detection_model_dir": str(self.detection_model_dir),
            "text_recognition_model_name": "PP-OCRv5_server_rec",
            "text_recognition_model_dir": str(self.recognition_model_dir),
            "use_doc_orientation_classify": False,
            "use_doc_unwarping": False,
            "use_textline_orientation": False,
            "enable_mkldnn": False,
            "device": self.device,
        }

    def _load_model(self) -> Any:
        if not self.detection_model_dir.is_dir():
            raise RuntimeError("offline PaddleOCR detection model is unavailable")
        if not self.recognition_model_dir.is_dir():
            raise RuntimeError("offline PaddleOCR recognition model is unavailable")
        key = self._model_key()
        with self._models_lock:
            model = self._models.get(key)
            if model is not None:
                return model
            if self._model_factory is not None:
                model = self._model_factory()
            else:
                try:
                    from paddleocr import PaddleOCR
                except ImportError as exc:  # pragma: no cover - optional runtime
                    raise RuntimeError("PaddleOCR is unavailable") from exc
                model = PaddleOCR(**self._model_options())
            self._models[key] = model
            return model

    def locate(self, image: Image.Image) -> Sequence[OCRRegionProposal]:
        model = self._load_model()
        with tempfile.TemporaryDirectory(prefix="m1_drawing_region_") as directory:
            path = Path(directory) / "asset.png"
            image.save(path, format="PNG")
            with self._inference_lock:
                raw = model.predict(str(path))
        return _paddle_region_proposals(raw)


class DrawingRegionVLMExtractor:
    """Locate and transcribe bounded engineering-drawing callouts."""

    def __init__(
        self,
        *,
        ocr: RegionOCR,
        vlm: RegionVLMClient,
        config: DrawingRegionVLMConfig | None = None,
    ) -> None:
        self.ocr = ocr
        self.vlm = vlm
        self.config = config or DrawingRegionVLMConfig()

    @classmethod
    def from_openai(
        cls,
        *,
        base_url: str,
        model: str,
        paddle_model_root: str | Path,
        device: str = "cpu",
        api_key: str | None = None,
        http_client: Any | None = None,
        config: DrawingRegionVLMConfig | None = None,
    ) -> DrawingRegionVLMExtractor:
        """Build the concrete offline-OCR/HTTP-VLM pair without global state."""

        if not base_url.strip():
            raise ValueError("base_url must not be empty")
        resolved_config = config or DrawingRegionVLMConfig()
        owned = http_client is None
        if http_client is None:
            import httpx

            http_client = httpx.AsyncClient(
                timeout=resolved_config.request_timeout_seconds,
            )
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else None
        return cls(
            ocr=PaddleOCRRegionLocator.from_model_root(
                paddle_model_root,
                device=device,
            ),
            vlm=OpenAICompatibleRegionVLMClient(
                http_client=http_client,
                endpoint=_chat_completions_endpoint(base_url),
                model=model,
                headers=headers,
                owns_http_client=owned,
            ),
            config=resolved_config,
        )

    async def aclose(self) -> None:
        close = getattr(self.vlm, "aclose", None)
        if callable(close):
            await close()

    async def probe(self) -> dict[str, Any]:
        for path in (
            getattr(self.ocr, "detection_model_dir", None),
            getattr(self.ocr, "recognition_model_dir", None),
        ):
            if path is not None and not Path(path).is_dir():
                raise RuntimeError("offline PaddleOCR drawing model is unavailable")
        probe = getattr(self.vlm, "probe", None)
        health: dict[str, Any] = {"ready": True, "configured": True}
        if callable(probe):
            value = probe()
            if inspect.isawaitable(value):
                value = await value
            if isinstance(value, dict):
                health = value
        health["ready"] = health.get("ready") is not False
        health["configured"] = True
        return health

    async def analyze(
        self,
        image: bytes | bytearray | memoryview | Image.Image | str | Path,
        *,
        evidence_id: str,
        source_ref: SourceReference,
        subject: str | None = None,
        default_unit: str | None = None,
        max_regions: int | None = None,
    ) -> DrawingRegionVLMResult:
        if not evidence_id.strip():
            raise ValueError("evidence_id must not be empty")
        if max_regions is not None and max_regions < 1:
            raise ValueError("max_regions must be positive")
        asset_sha256 = _parent_asset_sha256(source_ref)
        if asset_sha256 is None:
            return DrawingRegionVLMResult(
                issues=[
                    _issue(
                        "DRAWING_REGION_ASSET_PROVENANCE_MISSING",
                        "drawing asset source_ref requires a 64-hex asset_sha256",
                        source_ref,
                    )
                ]
            )
        input_sha256 = _input_asset_sha256(image)
        if input_sha256 != asset_sha256:
            return DrawingRegionVLMResult(
                issues=[
                    _issue(
                        "DRAWING_REGION_ASSET_CONTENT_MISMATCH",
                        "drawing asset bytes do not match source_ref asset_sha256",
                        source_ref,
                    )
                ]
            )
        limit = min(
            max_regions or self.config.max_candidates,
            self.config.max_candidates,
        )
        try:
            loaded = _load_image(image)
        except Exception as exc:  # noqa: BLE001 - malformed assets fail closed
            return DrawingRegionVLMResult(
                issues=[
                    _issue(
                        "DRAWING_REGION_IMAGE_INVALID",
                        f"drawing asset could not be opened: {exc.__class__.__name__}",
                        source_ref,
                    )
                ]
            )
        try:
            proposals = list(await asyncio.to_thread(self.ocr.locate, loaded.copy()))
        except Exception as exc:  # noqa: BLE001 - optional OCR must fail closed
            return DrawingRegionVLMResult(
                issues=[
                    _issue(
                        "DRAWING_REGION_OCR_UNAVAILABLE",
                        f"drawing region OCR is unavailable: {exc.__class__.__name__}",
                        source_ref,
                    )
                ]
            )

        selected, duplicates, limited = _select_candidates(
            proposals,
            width=loaded.width,
            height=loaded.height,
            config=self.config,
            limit=limit,
        )
        facts: list[SemanticFact] = []
        issues: list[DrawingRegionVLMIssue] = []
        audit: list[DrawingRegionAudit] = []
        for candidate in duplicates:
            artifact = _region_artifact(
                loaded,
                candidate,
                source_ref=source_ref,
                parent_evidence_id=evidence_id,
                asset_sha256=asset_sha256,
                config=self.config,
                model_transcription=False,
            )
            audit.append(
                DrawingRegionAudit(
                    candidate_id=candidate.candidate_id,
                    source_ref=artifact.source_ref,
                    ocr_score=candidate.proposal.score,
                    selection_reasons=list(candidate.reasons),
                    rotation_degrees=artifact.rotation,
                    disposition="duplicate",
                )
            )
        if limited:
            issues.append(
                _issue(
                    "DRAWING_REGION_CANDIDATE_LIMIT",
                    "drawing region candidate limit was reached",
                    source_ref,
                )
            )
            for candidate in limited:
                artifact = _region_artifact(
                    loaded,
                    candidate,
                    source_ref=source_ref,
                    parent_evidence_id=evidence_id,
                    asset_sha256=asset_sha256,
                    config=self.config,
                    model_transcription=False,
                )
                audit.append(
                    DrawingRegionAudit(
                        candidate_id=candidate.candidate_id,
                        source_ref=artifact.source_ref,
                        ocr_score=candidate.proposal.score,
                        selection_reasons=list(candidate.reasons),
                        rotation_degrees=artifact.rotation,
                        disposition="candidate_limit",
                        issue_codes=["DRAWING_REGION_CANDIDATE_LIMIT"],
                    )
                )

        for candidate in selected:
            artifact = _region_artifact(
                loaded,
                candidate,
                source_ref=source_ref,
                parent_evidence_id=evidence_id,
                asset_sha256=asset_sha256,
                config=self.config,
                model_transcription=True,
            )
            candidate_ref = artifact.source_ref
            rotation = artifact.rotation
            try:
                response = await asyncio.wait_for(
                    self.vlm.transcribe(
                        artifact.image_png,
                        prompt=DRAWING_REGION_PROMPT,
                        temperature=0.0,
                        max_tokens=self.config.max_tokens,
                        stop=_NEWLINE_STOP,
                    ),
                    timeout=self.config.request_timeout_seconds,
                )
            except Exception as exc:  # noqa: BLE001 - model errors remain additive
                code = "DRAWING_REGION_VLM_FAILED"
                issues.append(
                    _issue(
                        code,
                        "drawing region transcription failed: "
                        f"{exc.__class__.__name__}",
                        candidate_ref,
                        candidate_id=candidate.candidate_id,
                    )
                )
                audit.append(
                    _audit(
                        candidate,
                        candidate_ref,
                        rotation,
                        disposition="failed",
                        issue_codes=[code],
                    )
                )
                continue
            if (response.finish_reason or "").casefold() == "length":
                code = "DRAWING_REGION_VLM_TRUNCATED"
                issues.append(
                    _issue(
                        code,
                        "drawing region transcription reached its token limit",
                        candidate_ref,
                        candidate_id=candidate.candidate_id,
                    )
                )
                audit.append(
                    _audit(
                        candidate,
                        candidate_ref,
                        rotation,
                        disposition="truncated",
                        issue_codes=[code],
                    )
                )
                continue
            normalized = normalize_region_callout(
                response.text,
                max_chars=self.config.max_response_chars,
            )
            if normalized is None:
                explicit_no_callout = _single_region_response_line(
                    response.text,
                    max_chars=self.config.max_response_chars,
                )
                if explicit_no_callout is not None and _INVALID_OUTPUT.fullmatch(
                    explicit_no_callout
                ):
                    audit.append(
                        _audit(
                            candidate,
                            candidate_ref,
                            rotation,
                            disposition="not_a_callout",
                            normalized_text=explicit_no_callout,
                        )
                    )
                    continue
                code = "DRAWING_REGION_CALLOUT_INVALID"
                issues.append(
                    _issue(
                        code,
                        "region transcription is not one complete callout",
                        candidate_ref,
                        candidate_id=candidate.candidate_id,
                    )
                )
                audit.append(
                    _audit(
                        candidate,
                        candidate_ref,
                        rotation,
                        disposition="invalid",
                        issue_codes=[code],
                    )
                )
                continue
            region_evidence_id = f"{evidence_id}/region:{artifact.region_sha256}"
            semantics = extract_drawing_semantics(
                normalized,
                evidence_id=region_evidence_id,
                source_ref=candidate_ref,
                localization="region_bbox",
                subject=subject,
                default_unit=default_unit,
            )
            if semantics.issues:
                region_codes = [issue.code for issue in semantics.issues]
                issues.extend(
                    _issue(
                        issue.code,
                        issue.message,
                        candidate_ref,
                        candidate_id=candidate.candidate_id,
                    )
                    for issue in semantics.issues
                )
                audit.append(
                    _audit(
                        candidate,
                        candidate_ref,
                        rotation,
                        disposition="conflict",
                        normalized_text=normalized,
                        issue_codes=region_codes,
                    )
                )
                continue
            if not semantics.facts:
                if _BARE_NUMERIC_CALLOUT.fullmatch(normalized):
                    code = "DRAWING_REGION_CALLOUT_AMBIGUOUS"
                    issues.append(
                        _issue(
                            code,
                            "bare numeric region has no dimension marker, "
                            "tolerance, or unit",
                            candidate_ref,
                            candidate_id=candidate.candidate_id,
                        )
                    )
                    audit.append(
                        _audit(
                            candidate,
                            candidate_ref,
                            rotation,
                            disposition="ambiguous",
                            normalized_text=normalized,
                            issue_codes=[code],
                        )
                    )
                    continue
                if _clearly_not_a_dimension_callout(normalized):
                    audit.append(
                        _audit(
                            candidate,
                            candidate_ref,
                            rotation,
                            disposition="screened",
                            normalized_text=normalized,
                        )
                    )
                    continue
            if len(semantics.facts) != 1 or not _covers_complete_callout(
                normalized,
                semantics.facts,
            ):
                code = "DRAWING_REGION_CALLOUT_INVALID"
                issues.append(
                    _issue(
                        code,
                        "region transcription did not match exactly one "
                        "complete callout",
                        candidate_ref,
                        candidate_id=candidate.candidate_id,
                    )
                )
                audit.append(
                    _audit(
                        candidate,
                        candidate_ref,
                        rotation,
                        disposition="invalid",
                        normalized_text=normalized,
                        issue_codes=[code],
                    )
                )
                continue
            fact = _visual_advisory_fact(
                semantics.facts[0],
                evidence_id=region_evidence_id,
                rotation=rotation,
                source_ref=candidate_ref,
            )
            facts.append(fact)
            audit.append(
                _audit(
                    candidate,
                    candidate_ref,
                    rotation,
                    disposition="fact",
                    normalized_text=normalized,
                    fact_ids=[fact.fact_id],
                )
            )
        return DrawingRegionVLMResult(facts=facts, issues=issues, audit=audit)


@dataclass(frozen=True, slots=True)
class _Candidate:
    proposal: OCRRegionProposal
    bbox: tuple[int, int, int, int]
    reasons: tuple[str, ...]
    candidate_id: str


@dataclass(frozen=True, slots=True)
class _RegionArtifact:
    image_png: bytes
    region_sha256: str
    rotation: Literal[0, 90]
    source_ref: SourceReference


def _select_candidates(
    proposals: Sequence[OCRRegionProposal],
    *,
    width: int,
    height: int,
    config: DrawingRegionVLMConfig,
    limit: int,
) -> tuple[list[_Candidate], list[_Candidate], list[_Candidate]]:
    candidates: list[_Candidate] = []
    for proposal_index, proposal in enumerate(proposals):
        bbox = _clip_bbox(proposal.bbox, width=width, height=height)
        if bbox is None:
            continue
        x0, y0, x1, y1 = bbox
        region_width = x1 - x0
        region_height = y1 - y0
        if region_width * region_height < config.min_area_pixels:
            continue
        ratio = max(region_width / region_height, region_height / region_width)
        reasons: list[str] = []
        if proposal.contains_numeric_hint:
            reasons.append("numeric_hint")
        if proposal.score < config.low_confidence_threshold:
            reasons.append("low_confidence")
        if ratio >= config.abnormal_aspect_ratio:
            reasons.append("abnormal_aspect_ratio")
        if not reasons:
            continue
        candidate_id = f"region:{x0}:{y0}:{x1}:{y1}:{proposal_index}"
        candidates.append(
            _Candidate(
                proposal=proposal,
                bbox=bbox,
                reasons=tuple(reasons),
                candidate_id=candidate_id,
            )
        )
    candidates.sort(
        key=lambda candidate: (
            "numeric_hint" not in candidate.reasons,
            "low_confidence" not in candidate.reasons,
            "abnormal_aspect_ratio" not in candidate.reasons,
            candidate.bbox[1],
            candidate.bbox[0],
            -candidate.proposal.score,
        )
    )
    unique: list[_Candidate] = []
    duplicates: list[_Candidate] = []
    for candidate in candidates:
        if any(
            _bbox_iou(candidate.bbox, existing.bbox) >= config.duplicate_iou_threshold
            for existing in unique
        ):
            duplicates.append(candidate)
        else:
            unique.append(candidate)
    return unique[:limit], duplicates, unique[limit:]


def _clip_bbox(
    bbox: tuple[float, float, float, float],
    *,
    width: int,
    height: int,
) -> tuple[int, int, int, int] | None:
    x0 = max(0, min(width, math.floor(bbox[0])))
    y0 = max(0, min(height, math.floor(bbox[1])))
    x1 = max(0, min(width, math.ceil(bbox[2])))
    y1 = max(0, min(height, math.ceil(bbox[3])))
    return (x0, y0, x1, y1) if x1 > x0 and y1 > y0 else None


def _bbox_iou(
    left: tuple[int, int, int, int],
    right: tuple[int, int, int, int],
) -> float:
    x0 = max(left[0], right[0])
    y0 = max(left[1], right[1])
    x1 = min(left[2], right[2])
    y1 = min(left[3], right[3])
    intersection = max(0, x1 - x0) * max(0, y1 - y0)
    if intersection == 0:
        return 0.0
    left_area = (left[2] - left[0]) * (left[3] - left[1])
    right_area = (right[2] - right[0]) * (right[3] - right[1])
    return intersection / (left_area + right_area - intersection)


def _prepare_crop(
    image: Image.Image,
    bbox: tuple[int, int, int, int],
    config: DrawingRegionVLMConfig,
) -> tuple[Image.Image, Literal[0, 90], tuple[int, int, int, int]]:
    x0, y0, x1, y1 = bbox
    width = x1 - x0
    height = y1 - y0
    pad_x = max(config.minimum_padding_pixels, round(width * config.padding_ratio))
    pad_y = max(config.minimum_padding_pixels, round(height * config.padding_ratio))
    crop_bbox = (
        max(0, x0 - pad_x),
        max(0, y0 - pad_y),
        min(image.width, x1 + pad_x),
        min(image.height, y1 + pad_y),
    )
    crop = image.crop(crop_bbox).convert("RGB")
    rotation: Literal[0, 90] = 0
    if config.rotate_vertical and height > width * config.vertical_rotation_ratio:
        crop = crop.transpose(Image.Transpose.ROTATE_270)
        rotation = 90
    crop = crop.resize(
        (
            crop.width * config.upscale_factor,
            crop.height * config.upscale_factor,
        ),
        Image.Resampling.LANCZOS,
    )
    return crop, rotation, crop_bbox


def _png_bytes(image: Image.Image) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


def _region_artifact(
    image: Image.Image,
    candidate: _Candidate,
    *,
    source_ref: SourceReference,
    parent_evidence_id: str,
    asset_sha256: str,
    config: DrawingRegionVLMConfig,
    model_transcription: bool,
) -> _RegionArtifact:
    crop, rotation, crop_bbox = _prepare_crop(image, candidate.bbox, config)
    image_png = _png_bytes(crop)
    region_sha256 = hashlib.sha256(image_png).hexdigest()
    region_ref = _region_source_ref(
        source_ref,
        candidate.bbox,
        parent_evidence_id=parent_evidence_id,
        asset_sha256=asset_sha256,
        asset_width=image.width,
        asset_height=image.height,
        region_sha256=region_sha256,
        rotation=rotation,
        crop_bbox=crop_bbox,
        output_size=crop.size,
        upscale_factor=config.upscale_factor,
        model_transcription=model_transcription,
    )
    return _RegionArtifact(
        image_png=image_png,
        region_sha256=region_sha256,
        rotation=rotation,
        source_ref=region_ref,
    )


def _load_image(
    value: bytes | bytearray | memoryview | Image.Image | str | Path,
) -> Image.Image:
    if isinstance(value, Image.Image):
        return value.convert("RGB")
    if isinstance(value, (bytes, bytearray, memoryview)):
        with Image.open(io.BytesIO(bytes(value))) as image:
            return image.convert("RGB")
    with Image.open(Path(value)) as image:
        return image.convert("RGB")


def _input_asset_sha256(
    value: bytes | bytearray | memoryview | Image.Image | str | Path,
) -> str | None:
    if isinstance(value, (bytes, bytearray, memoryview)):
        return hashlib.sha256(bytes(value)).hexdigest()
    if isinstance(value, Image.Image):
        return None
    try:
        with Path(value).open("rb") as stream:
            digest = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        return None
    return digest.hexdigest()


def _single_region_response_line(text: str, *, max_chars: int) -> str | None:
    if not isinstance(text, str):
        return None
    normalized = unicodedata.normalize("NFKC", text).strip()
    if not normalized or len(normalized) > max_chars:
        return None
    normalized = _MODEL_CONTROL_SUFFIX.sub("", normalized).strip()
    if normalized.startswith("```") and normalized.endswith("```"):
        normalized = normalized[3:-3].strip()
        if normalized.casefold().startswith(("latex\n", "text\n")):
            normalized = normalized.split("\n", 1)[1].strip()
    nonempty_lines = [line.strip() for line in normalized.splitlines() if line.strip()]
    if len(nonempty_lines) != 1:
        return None
    return nonempty_lines[0]


_BARE_NUMERIC_CALLOUT = re.compile(
    r"[+-]?(?:\d+(?:[.,]\d+)?|[.,]\d+)"
)
_CLEAR_IDENTIFIER = re.compile(
    r"[A-Za-z]{2,}[A-Za-z0-9]*(?:[._/-][A-Za-z0-9]+)*"
)
_DIMENSION_WORD_PREFIX = re.compile(
    r"(?:THK|THICKNESS|厚度)\s*[:=]?\s*\d",
    re.IGNORECASE,
)


def _clearly_not_a_dimension_callout(text: str) -> bool:
    """Recognize only decisive negatives; unknown callout grammars still review."""

    if not _NUMBER_HINT.search(text):
        return True
    if _DIMENSION_WORD_PREFIX.match(text):
        return False
    return _CLEAR_IDENTIFIER.fullmatch(text) is not None


def normalize_region_callout(text: str, *, max_chars: int = 192) -> str | None:
    """Normalize one short LaTeX/plain transcription without repairing facts."""

    normalized = _single_region_response_line(text, max_chars=max_chars)
    if normalized is None:
        return None
    if _INVALID_OUTPUT.fullmatch(normalized):
        return None
    normalized = re.sub(r"^\\(?:boxed|mathrm|text)\{(.+)\}$", r"\1", normalized)
    normalized = normalized.removeprefix("\\(").removesuffix("\\)")
    normalized = normalized.removeprefix("\\[").removesuffix("\\]")
    normalized = normalized.strip("$ ")
    normalized = normalized.replace("\\left", "").replace("\\right", "")
    normalized = re.sub(r"\\(?:text|mathrm)\{\s*([^{}]+)\s*\}", r"\1", normalized)
    normalized = _LATEX_STACKED_UPPER_FIRST.sub(
        lambda match: (
            f"{match.group('nominal')} +{match.group('upper')}/-{match.group('lower')}"
        ),
        normalized,
    )
    normalized = _LATEX_STACKED_LOWER_FIRST.sub(
        lambda match: (
            f"{match.group('nominal')} +{match.group('upper')}/-{match.group('lower')}"
        ),
        normalized,
    )
    replacements = {
        "\\pm": "±",
        "\\diameter": "Ø",
        "\\varnothing": "Ø",
        "\\Phi": "Φ",
        "\\phi": "φ",
        "−": "-",
        "–": "-",
        "—": "-",
        "∅": "Ø",
    }
    for source, target in replacements.items():
        normalized = normalized.replace(source, target)
    normalized = re.sub(r"\\[,;!: ]", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip(" ;,")
    stacked = _PLAIN_STACKED_TOLERANCE.fullmatch(normalized)
    if stacked is not None:
        normalized = (
            f"{stacked.group('prefix')}{stacked.group('nominal')} "
            f"+{stacked.group('upper')}/-{stacked.group('lower')}"
            f"{stacked.group('unit') or ''}"
        ).strip()
    if not normalized or "\\" in normalized or "{" in normalized or "}" in normalized:
        return None
    return normalized


def _covers_complete_callout(text: str, facts: Sequence[SemanticFact]) -> bool:
    if len(facts) != 1 or facts[0].status == "ambiguous":
        return False
    quote = facts[0].evidence_refs[0].quote
    def normalize(value: str) -> str:
        return re.sub(r"\s+", "", value).strip(";,")

    return normalize(text) == normalize(quote)


def _visual_advisory_fact(
    fact: SemanticFact,
    *,
    evidence_id: str,
    rotation: Literal[0, 90],
    source_ref: SourceReference,
) -> SemanticFact:
    attributes = dict(fact.attributes)
    attributes.update(
        {
            "source_boundary": "visual_region_advisory",
            "ocr_text_trusted": False,
            "crop_rotation_degrees": rotation,
            "evidence_kind": "model_transcription",
            "model_transcription": True,
        }
    )
    evidence_refs = [
        SemanticEvidence(
            evidence_id=evidence_id,
            quote=evidence.quote,
            source_ref=source_ref,
        )
        for evidence in fact.evidence_refs
    ]
    evidence_ids = [evidence.evidence_id for evidence in evidence_refs]
    fact_id = stable_fact_id(
        name=fact.name,
        value=fact.value,
        unit=fact.unit,
        subject=fact.subject,
        relation=fact.relation,
        attributes=attributes,
        evidence_ids=evidence_ids,
    )
    return SemanticFact(
        fact_id=fact_id,
        name=fact.name,
        value=fact.value,
        unit=fact.unit,
        subject=fact.subject,
        relation=fact.relation,
        attributes=attributes,
        evidence_refs=evidence_refs,
        extractor="drawing_region_vlm.v1",
        confidence=min(fact.confidence, 0.85),
        status="advisory",
    )


def _region_source_ref(
    source_ref: SourceReference,
    bbox: tuple[int, int, int, int],
    *,
    parent_evidence_id: str,
    asset_sha256: str,
    asset_width: int,
    asset_height: int,
    region_sha256: str,
    rotation: Literal[0, 90],
    crop_bbox: tuple[int, int, int, int],
    output_size: tuple[int, int],
    upscale_factor: int,
    model_transcription: bool,
) -> SourceReference:
    payload = source_ref.model_dump(mode="python")
    payload.update(
        {
            "bbox": [float(value) for value in bbox],
            "coordinate_space": "image_pixels",
            "parent_evidence_id": parent_evidence_id,
            "asset_sha256": asset_sha256,
            "asset_width_pixels": asset_width,
            "asset_height_pixels": asset_height,
            "region_bbox_pixels": list(bbox),
            "region_crop_bbox_pixels": list(crop_bbox),
            "region_output_size_pixels": list(output_size),
            "region_upscale_factor": upscale_factor,
            "region_resampling": "lanczos",
            "region_image_mode": "RGB",
            "region_encoding": "PNG",
            "region_encoding_options": {"optimize": True},
            "region_encoder": f"Pillow/{PILLOW_VERSION}",
            "region_hash_basis": "encoded_region_png_bytes",
            "region_transform_version": "m1.region-crop.v1",
            "region_sha256": region_sha256,
            "region_rotation_degrees": rotation,
            "authority": "advisory",
            "inferred": True,
            "evidence_kind": (
                "model_transcription" if model_transcription else "region_crop"
            ),
            "model_transcription": model_transcription,
        }
    )
    return SourceReference.model_validate(payload)


def _parent_asset_sha256(source_ref: SourceReference) -> str | None:
    value = (source_ref.model_extra or {}).get("asset_sha256")
    rendered = str(value or "").strip()
    return rendered.casefold() if _SHA256_HEX.fullmatch(rendered) else None


def _audit(
    candidate: _Candidate,
    source_ref: SourceReference,
    rotation: Literal[0, 90],
    *,
    disposition: DrawingRegionDisposition,
    normalized_text: str | None = None,
    fact_ids: Sequence[str] = (),
    issue_codes: Sequence[str] = (),
) -> DrawingRegionAudit:
    return DrawingRegionAudit(
        candidate_id=candidate.candidate_id,
        source_ref=source_ref,
        ocr_score=candidate.proposal.score,
        selection_reasons=list(candidate.reasons),
        rotation_degrees=rotation,
        disposition=disposition,
        normalized_text=normalized_text,
        fact_ids=list(fact_ids),
        issue_codes=list(issue_codes),
    )


def _issue(
    code: str,
    message: str,
    source_ref: SourceReference,
    *,
    candidate_id: str | None = None,
    fact_ids: Sequence[str] = (),
) -> DrawingRegionVLMIssue:
    return DrawingRegionVLMIssue(
        code=code,
        message=message,
        source_ref=source_ref,
        candidate_id=candidate_id,
        fact_ids=list(fact_ids),
    )


def _offline_model_directory(root: Path, name: str) -> Path:
    candidates = (
        root / "official_models" / name,
        root / ".paddlex" / "official_models" / name,
        root / name,
    )
    return next(
        (candidate for candidate in candidates if candidate.is_dir()),
        candidates[0],
    )


def _chat_completions_endpoint(base_url: str) -> str:
    normalized = base_url.strip().rstrip("/")
    if normalized.endswith("/chat/completions"):
        return normalized
    if normalized.endswith("/v1"):
        return f"{normalized}/chat/completions"
    return f"{normalized}/v1/chat/completions"


def _paddle_region_proposals(raw: Any) -> list[OCRRegionProposal]:
    proposals: list[OCRRegionProposal] = []
    items = (
        list(raw)
        if isinstance(raw, Iterable) and not isinstance(raw, (str, bytes, Mapping))
        else [raw]
    )
    for item in items:
        payload = _as_mapping(item)
        nested = payload.get("res")
        if isinstance(nested, Mapping):
            payload = nested
        boxes = _first(payload, "rec_polys", "rec_boxes", "dt_polys", "boxes")
        texts = _first(payload, "rec_texts", "texts", "text")
        scores = _first(payload, "rec_scores", "scores", "confidence")
        box_items = _as_sequence(boxes)
        text_items = _as_sequence(texts)
        score_items = _as_sequence(scores)
        for index, box in enumerate(box_items):
            bbox = _flatten_bbox(box)
            if bbox is None:
                continue
            score = _safe_score(score_items[index] if index < len(score_items) else 0.0)
            text = str(text_items[index]) if index < len(text_items) else ""
            try:
                proposals.append(
                    OCRRegionProposal(
                        bbox=bbox,
                        score=score,
                        contains_numeric_hint=bool(_NUMBER_HINT.search(text)),
                    )
                )
            except ValueError:
                continue
    return proposals


def _as_mapping(value: Any) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    for method_name in ("to_dict", "model_dump", "dict"):
        method = getattr(value, method_name, None)
        if callable(method):
            try:
                payload = method()
            except Exception:  # noqa: BLE001, S112 - malformed provider object
                continue
            if isinstance(payload, Mapping):
                return payload
    json_value = getattr(value, "json", None)
    return json_value if isinstance(json_value, Mapping) else {}


def _first(payload: Mapping[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in payload:
            return payload[key]
    return None


def _as_sequence(value: Any) -> list[Any]:
    if value is None or isinstance(value, (str, bytes, Mapping)):
        return [value] if isinstance(value, str) else []
    tolist = getattr(value, "tolist", None)
    if callable(tolist):
        try:
            value = tolist()
        except Exception:  # noqa: BLE001
            return []
    return list(value) if isinstance(value, Sequence) else []


def _flatten_bbox(value: Any) -> tuple[float, float, float, float] | None:
    tolist = getattr(value, "tolist", None)
    if callable(tolist):
        try:
            value = tolist()
        except Exception:  # noqa: BLE001
            return None
    flat: list[float] = []

    def visit(item: Any) -> None:
        nested_tolist = getattr(item, "tolist", None)
        if callable(nested_tolist):
            try:
                item = nested_tolist()
            except Exception:  # noqa: BLE001
                return
        if isinstance(item, Sequence) and not isinstance(item, (str, bytes)):
            for child in item:
                visit(child)
            return
        try:
            number = float(item)
        except (TypeError, ValueError):
            return
        if math.isfinite(number):
            flat.append(number)

    visit(value)
    if len(flat) < 4:
        return None
    if len(flat) == 4:
        return (flat[0], flat[1], flat[2], flat[3])
    xs = flat[0::2]
    ys = flat[1::2]
    return (min(xs), min(ys), max(xs), max(ys))


def _safe_score(value: Any) -> float:
    try:
        score = float(value)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(score):
        return 0.0
    return max(0.0, min(1.0, score))


__all__ = [
    "DRAWING_REGION_PROMPT",
    "DrawingRegionAudit",
    "DrawingRegionVLMConfig",
    "DrawingRegionVLMExtractor",
    "DrawingRegionVLMIssue",
    "DrawingRegionVLMResult",
    "OCRRegionProposal",
    "OpenAICompatibleRegionVLMClient",
    "PaddleOCRRegionLocator",
    "RegionOCR",
    "RegionVLMClient",
    "RegionVLMModelUnavailableError",
    "RegionVLMResponse",
    "normalize_region_callout",
]
