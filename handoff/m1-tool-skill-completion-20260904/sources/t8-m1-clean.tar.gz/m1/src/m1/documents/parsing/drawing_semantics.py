"""Evidence-bounded semantic facts for engineering drawing callouts.

The helpers in this module are deliberately conservative.  They recognize only
complete dimension callouts, preserve decimal values as canonical strings, and
keep whole-image or model-derived observations advisory.  Nothing produced here
is an authoritative ``DocumentRecord`` field.
"""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from decimal import Decimal, InvalidOperation
from typing import Literal

from pydantic import Field, computed_field, model_validator

from ..models import SourceReference
from .semantic_facts import (
    SemanticEvidence,
    SemanticFact,
    StrictSemanticModel,
    stable_fact_id,
)

DrawingLocalization = Literal["token_bbox", "region_bbox", "whole_image_flattened"]
DrawingIssueCode = Literal[
    "DRAWING_CONFLICTING_TOLERANCE",
    "DRAWING_UNASSIGNED_TOLERANCE",
    "DRAWING_ASSET_ASSOCIATION_AMBIGUOUS",
    "DRAWING_VISUAL_COLOR_CONFLICT",
]


class DrawingSemanticIssue(StrictSemanticModel):
    """A drawing observation that cannot be promoted without human review."""

    code: DrawingIssueCode
    message: str = Field(min_length=1)
    evidence: SemanticEvidence
    fact_ids: list[str] = Field(default_factory=list)


class DrawingSemanticResult(StrictSemanticModel):
    """Additive facts and fail-closed issues extracted from drawing text."""

    facts: list[SemanticFact] = Field(default_factory=list)
    issues: list[DrawingSemanticIssue] = Field(default_factory=list)

    @computed_field(return_type=bool)
    @property
    def needs_review(self) -> bool:
        return bool(
            self.issues
            or any(fact.status == "ambiguous" for fact in self.facts)
        )


class DrawingAssetObservation(StrictSemanticModel):
    """One visual asset observation with its original occurrence evidence."""

    asset_id: str = Field(min_length=1)
    evidence_id: str = Field(min_length=1)
    source_ref: SourceReference
    description: str | None = None
    observed_color: str | None = None
    anchored_product_id: str | None = None
    anchor_method: Literal["spreadsheet_row_anchor"] | None = None

    @model_validator(mode="after")
    def require_nonblank_optional_text(self) -> DrawingAssetObservation:
        for field_name in ("description", "observed_color", "anchored_product_id"):
            value = getattr(self, field_name)
            if value is not None and not value.strip():
                raise ValueError(f"{field_name} must be non-empty when supplied")
        if self.anchor_method is not None and self.anchored_product_id is None:
            raise ValueError("anchor_method requires anchored_product_id")
        return self


class DrawingAssetAssociationResult(DrawingSemanticResult):
    """Semantic sidecar result for visual-to-product association."""


_UNSIGNED_DECIMAL = r"(?:\d+(?:\.\d+)?|\.\d+)"
_HSPACE = r"[^\S\r\n]*"
_PLUS_MINUS = rf"(?:\u00b1|\+{_HSPACE}/{_HSPACE}-)"
_UNIT = r"(?:mm|毫米|cm|厘米|in(?:ch(?:es)?)?|英寸)"
_TOLERANCE = (
    rf"(?:\+{_HSPACE}(?P<upper>{_UNSIGNED_DECIMAL}){_HSPACE}"
    rf"/{_HSPACE}-{_HSPACE}(?P<lower>{_UNSIGNED_DECIMAL})|"
    rf"{_PLUS_MINUS}{_HSPACE}"
    rf"(?P<symmetric>{_UNSIGNED_DECIMAL}))"
)
_END_BOUNDARY = r"(?![\w.])"

def _conflict_patterns(
    prefix: str,
) -> tuple[re.Pattern[str], re.Pattern[str]]:
    return (
        re.compile(
            rf"{prefix}{_HSPACE}(?P<nominal>{_UNSIGNED_DECIMAL}){_HSPACE}"
            rf"{_PLUS_MINUS}{_HSPACE}(?P<symmetric>{_UNSIGNED_DECIMAL})"
            rf"{_HSPACE}\+{_HSPACE}(?P<upper>{_UNSIGNED_DECIMAL})"
            rf"{_HSPACE}/{_HSPACE}-{_HSPACE}"
            rf"(?P<lower>{_UNSIGNED_DECIMAL})"
            rf"(?:{_HSPACE}(?P<unit>{_UNIT}))?{_END_BOUNDARY}",
            re.IGNORECASE,
        ),
        re.compile(
            rf"{prefix}{_HSPACE}(?P<nominal>{_UNSIGNED_DECIMAL}){_HSPACE}"
            rf"\+{_HSPACE}(?P<upper>{_UNSIGNED_DECIMAL}){_HSPACE}"
            rf"/{_HSPACE}-{_HSPACE}(?P<lower>{_UNSIGNED_DECIMAL})"
            rf"{_HSPACE}{_PLUS_MINUS}{_HSPACE}"
            rf"(?P<symmetric>{_UNSIGNED_DECIMAL})"
            rf"(?:{_HSPACE}(?P<unit>{_UNIT}))?{_END_BOUNDARY}",
            re.IGNORECASE,
        ),
    )


_CONFLICT_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = tuple(
    (dimension_type, pattern)
    for dimension_type, prefix in (
        ("radius", r"(?<![A-Za-z0-9_])[Rr]"),
        ("diameter", r"[\u2300\u00d8\u03a6\u03c6]"),
        (
            "thickness",
            rf"(?<![A-Za-z0-9_])(?:厚度|板厚|壁厚|肉厚|[Tt]){_HSPACE}[:=]?",
        ),
        ("linear", r"(?<![\w.])"),
    )
    for pattern in _conflict_patterns(prefix)
)


def _dimension_pattern(
    prefix: str,
    *,
    tolerance_required: bool = False,
) -> re.Pattern[str]:
    tolerance = (
        rf"{_HSPACE}{_TOLERANCE}"
        if tolerance_required
        else rf"(?:{_HSPACE}{_TOLERANCE})?"
    )
    return re.compile(
        rf"{prefix}{_HSPACE}(?P<nominal>{_UNSIGNED_DECIMAL}){tolerance}"
        rf"(?:{_HSPACE}(?P<unit>{_UNIT}))?{_END_BOUNDARY}",
        re.IGNORECASE,
    )


_DIMENSION_PATTERNS: tuple[tuple[str, str, re.Pattern[str]], ...] = (
    (
        "drawing_radius",
        "radius",
        _dimension_pattern(r"(?<![A-Za-z0-9_])[Rr]"),
    ),
    (
        "drawing_diameter",
        "diameter",
        _dimension_pattern(r"[\u2300\u00d8\u03a6\u03c6]"),
    ),
    (
        "drawing_thickness",
        "thickness",
        _dimension_pattern(
            rf"(?<![A-Za-z0-9_])(?:厚度|板厚|壁厚|肉厚|[Tt]){_HSPACE}[:=]?"
        ),
    ),
    (
        "drawing_linear_dimension",
        "linear",
        _dimension_pattern(r"(?<![\w.])", tolerance_required=True),
    ),
    (
        "drawing_linear_dimension",
        "linear",
        re.compile(
            rf"(?<![\w.])(?P<nominal>{_UNSIGNED_DECIMAL}){_HSPACE}"
            rf"(?P<unit>{_UNIT}){_END_BOUNDARY}",
            re.IGNORECASE,
        ),
    ),
)

_ISOLATED_ASYMMETRIC = re.compile(
    rf"(?<![\w.])\+{_HSPACE}(?P<upper>{_UNSIGNED_DECIMAL}){_HSPACE}"
    rf"/{_HSPACE}-{_HSPACE}"
    rf"(?P<lower>{_UNSIGNED_DECIMAL}){_END_BOUNDARY}"
)
_ISOLATED_SIGNED_PAIR = re.compile(
    rf"(?<![\w.])\+{_HSPACE}(?P<upper>{_UNSIGNED_DECIMAL})"
    rf"[^\S]*-{_HSPACE}(?P<lower>{_UNSIGNED_DECIMAL}){_END_BOUNDARY}"
)
_ISOLATED_SYMMETRIC = re.compile(
    rf"(?<![\w.]){_PLUS_MINUS}{_HSPACE}"
    rf"(?P<symmetric>{_UNSIGNED_DECIMAL}){_END_BOUNDARY}"
)

_COLOR_ALIASES = {
    "spacegray": "space_gray",
    "spacegrey": "space_gray",
    "太空灰": "space_gray",
    "深空灰": "space_gray",
    "blue": "blue",
    "蓝": "blue",
    "蓝色": "blue",
    "black": "black",
    "黑": "black",
    "黑色": "black",
    "white": "white",
    "白": "white",
    "白色": "white",
    "gray": "gray",
    "grey": "gray",
    "灰": "gray",
    "灰色": "gray",
    "silver": "silver",
    "银": "silver",
    "银色": "silver",
    "red": "red",
    "红": "red",
    "红色": "red",
}


def canonical_decimal(value: str) -> str:
    """Return a finite decimal as a non-exponential, lossless canonical string."""

    cleaned = value.strip().replace(" ", "")
    try:
        parsed = Decimal(cleaned)
    except InvalidOperation as exc:
        raise ValueError(f"invalid decimal value: {value!r}") from exc
    if not parsed.is_finite():
        raise ValueError("drawing decimal values must be finite")
    if parsed == 0:
        return "0"
    rendered = format(parsed, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    if rendered.startswith("."):
        rendered = f"0{rendered}"
    elif rendered.startswith("-."):
        rendered = f"-0{rendered[1:]}"
    return rendered


def _canonical_unit(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip().casefold()
    aliases = {
        "毫米": "mm",
        "厘米": "cm",
        "inch": "in",
        "inches": "in",
        "英寸": "in",
    }
    return aliases.get(normalized, normalized)


def _overlaps(span: tuple[int, int], occupied: Sequence[tuple[int, int]]) -> bool:
    return any(span[0] < other[1] and other[0] < span[1] for other in occupied)


def _evidence(
    text: str,
    match: re.Match[str],
    *,
    evidence_id: str,
    source_ref: SourceReference,
) -> SemanticEvidence:
    start, end = match.span()
    reference = source_ref.model_copy(deep=True)
    if reference.range is None:
        reference.range = f"chars:{start}:{end}"
    return SemanticEvidence(
        evidence_id=f"{evidence_id}/chars:{start}:{end}",
        quote=text[start:end],
        source_ref=reference,
    )


def _fact(
    *,
    name: str,
    value: dict[str, str],
    dimension_type: str,
    evidence: SemanticEvidence,
    unit: str | None,
    subject: str | None,
    localization: DrawingLocalization,
    status: Literal["verified", "ambiguous", "advisory"] | None = None,
    confidence: float | None = None,
) -> SemanticFact:
    resolved_status = status or (
        "advisory" if localization == "whole_image_flattened" else "verified"
    )
    resolved_confidence = confidence
    if resolved_confidence is None:
        resolved_confidence = {
            "token_bbox": 0.98,
            "region_bbox": 0.9,
            "whole_image_flattened": 0.6,
        }[localization]
    attributes = {
        "dimension_type": dimension_type,
        "localization": localization,
        "tolerance_type": (
            "conflicting"
            if "symmetric_deviation" in value and "upper_deviation" in value
            else "asymmetric"
            if "upper_deviation" in value
            else "symmetric"
            if "symmetric_deviation" in value
            else "none"
        ),
    }
    fact_id = stable_fact_id(
        name=name,
        value=value,
        unit=unit,
        subject=subject,
        relation="has_dimension" if subject else None,
        attributes=attributes,
        evidence_ids=[evidence.evidence_id],
    )
    return SemanticFact(
        fact_id=fact_id,
        name=name,
        value=value,
        unit=unit,
        subject=subject,
        relation="has_dimension" if subject else None,
        attributes=attributes,
        evidence_refs=[evidence],
        extractor="drawing_semantics.v1",
        confidence=resolved_confidence,
        status=resolved_status,
    )


def _dimension_value(match: re.Match[str]) -> dict[str, str]:
    value = {"nominal": canonical_decimal(match.group("nominal"))}
    groups = match.groupdict()
    if groups.get("symmetric") is not None:
        value["symmetric_deviation"] = canonical_decimal(groups["symmetric"])
    if groups.get("upper") is not None and groups.get("lower") is not None:
        value["upper_deviation"] = canonical_decimal(groups["upper"])
        value["lower_deviation"] = canonical_decimal(f"-{groups['lower']}")
    return value


def extract_drawing_semantics(
    text: str,
    *,
    evidence_id: str,
    source_ref: SourceReference,
    localization: DrawingLocalization = "whole_image_flattened",
    subject: str | None = None,
    default_unit: str | None = None,
) -> DrawingSemanticResult:
    """Extract complete engineering callouts without guessing spatial relations.

    Plain numbers without a type marker, tolerance, or explicit unit are not
    dimensions.  In particular, a bare ``0.7`` is never promoted to thickness.
    Isolated tolerance fragments are retained as ambiguous facts but are never
    attached to a nearby nominal value.
    """

    if not evidence_id.strip():
        raise ValueError("evidence_id must not be empty")
    if not text:
        return DrawingSemanticResult()
    unit_fallback = _canonical_unit(default_unit)
    facts: list[SemanticFact] = []
    issues: list[DrawingSemanticIssue] = []
    occupied: list[tuple[int, int]] = []

    conflict_matches = sorted(
        (
            (dimension_type, match)
            for dimension_type, pattern in _CONFLICT_PATTERNS
            for match in pattern.finditer(text)
        ),
        key=lambda item: (item[1].start(), -(item[1].end() - item[1].start())),
    )
    for dimension_type, match in conflict_matches:
        if _overlaps(match.span(), occupied):
            continue
        evidence = _evidence(
            text,
            match,
            evidence_id=evidence_id,
            source_ref=source_ref,
        )
        fact = _fact(
            name="drawing_dimension_tolerance_conflict",
            value=_dimension_value(match),
            dimension_type=dimension_type,
            evidence=evidence,
            unit=_canonical_unit(match.groupdict().get("unit")) or unit_fallback,
            subject=subject,
            localization=localization,
            status="ambiguous",
            confidence=0.35,
        )
        facts.append(fact)
        issues.append(
            DrawingSemanticIssue(
                code="DRAWING_CONFLICTING_TOLERANCE",
                message="dimension contains both symmetric and asymmetric tolerances",
                evidence=evidence,
                fact_ids=[fact.fact_id],
            )
        )
        occupied.append(match.span())

    candidates: list[tuple[int, int, str, str, re.Match[str]]] = []
    for priority, (name, dimension_type, pattern) in enumerate(_DIMENSION_PATTERNS):
        candidates.extend(
            (match.start(), priority, name, dimension_type, match)
            for match in pattern.finditer(text)
        )
    candidates.sort(
        key=lambda item: (
            item[0],
            item[1],
            -(item[4].end() - item[4].start()),
        )
    )
    for _start, _priority, name, dimension_type, match in candidates:
        if _overlaps(match.span(), occupied):
            continue
        evidence = _evidence(
            text,
            match,
            evidence_id=evidence_id,
            source_ref=source_ref,
        )
        facts.append(
            _fact(
                name=name,
                value=_dimension_value(match),
                dimension_type=dimension_type,
                evidence=evidence,
                unit=_canonical_unit(match.groupdict().get("unit")) or unit_fallback,
                subject=subject,
                localization=localization,
            )
        )
        occupied.append(match.span())

    isolated_patterns: tuple[tuple[str, re.Pattern[str]], ...] = (
        ("asymmetric", _ISOLATED_ASYMMETRIC),
        ("signed_pair", _ISOLATED_SIGNED_PAIR),
        ("symmetric", _ISOLATED_SYMMETRIC),
    )
    isolated_matches = sorted(
        (
            (kind, match)
            for kind, pattern in isolated_patterns
            for match in pattern.finditer(text)
        ),
        key=lambda item: (item[1].start(), -(item[1].end() - item[1].start())),
    )
    for kind, match in isolated_matches:
        if _overlaps(match.span(), occupied):
            continue
        evidence = _evidence(
            text,
            match,
            evidence_id=evidence_id,
            source_ref=source_ref,
        )
        groups = match.groupdict()
        if kind in {"asymmetric", "signed_pair"}:
            value = {
                "upper_deviation": canonical_decimal(groups["upper"]),
                "lower_deviation": canonical_decimal(f"-{groups['lower']}"),
            }
        else:
            value = {"symmetric_deviation": canonical_decimal(groups["symmetric"])}
        tolerance_type = "asymmetric" if kind == "signed_pair" else kind
        attributes = {
            "localization": localization,
            "tolerance_type": tolerance_type,
        }
        fact_id = stable_fact_id(
            name="drawing_unassigned_tolerance",
            value=value,
            subject=subject,
            attributes=attributes,
            evidence_ids=[evidence.evidence_id],
        )
        fact = SemanticFact(
            fact_id=fact_id,
            name="drawing_unassigned_tolerance",
            value=value,
            subject=subject,
            attributes=attributes,
            evidence_refs=[evidence],
            extractor="drawing_semantics.v1",
            confidence=0.25,
            status="ambiguous",
        )
        facts.append(fact)
        issues.append(
            DrawingSemanticIssue(
                code="DRAWING_UNASSIGNED_TOLERANCE",
                message="tolerance fragment has no safely assignable nominal dimension",
                evidence=evidence,
                fact_ids=[fact.fact_id],
            )
        )
        occupied.append(match.span())

    def evidence_start(evidence: SemanticEvidence) -> int:
        match = re.search(r"/chars:(\d+):(\d+)$", evidence.evidence_id)
        return int(match.group(1)) if match else 0

    facts.sort(key=lambda fact: evidence_start(fact.evidence_refs[0]))
    issues.sort(key=lambda issue: evidence_start(issue.evidence))
    return DrawingSemanticResult(facts=facts, issues=issues)


def _normalize_color(value: str | None) -> str | None:
    if value is None:
        return None
    compact = re.sub(r"[\s_-]+", "", value.casefold())
    if compact in _COLOR_ALIASES:
        return _COLOR_ALIASES[compact]
    for token, normalized in sorted(
        _COLOR_ALIASES.items(),
        key=lambda item: -len(item[0]),
    ):
        if token in compact:
            return normalized
    return compact or None


def _observed_color(asset: DrawingAssetObservation) -> str | None:
    if asset.observed_color is not None:
        return asset.observed_color
    return next(
        (
            token
            for token in sorted(_COLOR_ALIASES, key=len, reverse=True)
            if token in re.sub(r"[\s_-]+", "", (asset.description or "").casefold())
        ),
        None,
    )


def _asset_evidence(asset: DrawingAssetObservation) -> SemanticEvidence:
    return SemanticEvidence(
        evidence_id=asset.evidence_id,
        quote=asset.description or asset.observed_color or asset.asset_id,
        source_ref=asset.source_ref,
    )


def associate_drawing_assets(
    assets: Sequence[DrawingAssetObservation],
    *,
    product_ids: Sequence[str],
    declared_colors: Mapping[str, str] | None = None,
) -> DrawingAssetAssociationResult:
    """Associate visuals only when a product target is deterministic.

    A single product receives unanchored assets deterministically.  With more
    than one product, an explicit valid anchor is mandatory.  Visual facts stay
    advisory; contradictory color observations become ambiguous review items.
    """

    normalized_products = [product_id.strip() for product_id in product_ids]
    if any(not product_id for product_id in normalized_products):
        raise ValueError("product IDs must not be empty")
    if len(normalized_products) != len(set(normalized_products)):
        raise ValueError("product IDs must be unique")
    asset_ids = [asset.asset_id for asset in assets]
    if len(asset_ids) != len(set(asset_ids)):
        raise ValueError("asset IDs must be unique")
    evidence_ids = [asset.evidence_id for asset in assets]
    if len(evidence_ids) != len(set(evidence_ids)):
        raise ValueError("asset evidence IDs must be unique")
    colors = dict(declared_colors or {})
    unknown_color_products = set(colors) - set(normalized_products)
    if unknown_color_products:
        rendered = ", ".join(sorted(unknown_color_products))
        raise ValueError(f"declared colors reference unknown products: {rendered}")

    facts: list[SemanticFact] = []
    issues: list[DrawingSemanticIssue] = []
    product_set = set(normalized_products)
    for asset in assets:
        evidence = _asset_evidence(asset)
        target: str | None = None
        method: str | None = None
        if asset.anchored_product_id is not None:
            if asset.anchored_product_id in product_set:
                target = asset.anchored_product_id
                method = asset.anchor_method or "explicit_product_anchor"
        elif len(normalized_products) == 1:
            target = normalized_products[0]
            method = "single_product_document"

        association_value = {"asset_id": asset.asset_id, "product_id": target}
        association_attributes = {
            "association_method": method or "unresolved",
            "source_boundary": "visual_asset_advisory",
        }
        association_fact_id = stable_fact_id(
            name="product_image_association",
            value=association_value,
            subject=target,
            relation="depicted_by" if target else None,
            attributes=association_attributes,
            evidence_ids=[evidence.evidence_id],
        )
        association_status: Literal["advisory", "ambiguous"] = (
            "advisory" if target is not None else "ambiguous"
        )
        association_fact = SemanticFact(
            fact_id=association_fact_id,
            name="product_image_association",
            value=association_value,
            subject=target,
            relation="depicted_by" if target else None,
            attributes=association_attributes,
            evidence_refs=[evidence],
            extractor="drawing_semantics.v1",
            confidence=(
                0.9
                if method in {"explicit_product_anchor", "spreadsheet_row_anchor"}
                else 0.75
                if target
                else 0.2
            ),
            status=association_status,
        )
        facts.append(association_fact)
        if target is None:
            issues.append(
                DrawingSemanticIssue(
                    code="DRAWING_ASSET_ASSOCIATION_AMBIGUOUS",
                    message=(
                        "visual asset anchor does not match a product"
                        if asset.anchored_product_id is not None
                        else "visual asset cannot be assigned across multiple products"
                        if normalized_products
                        else "visual asset has no product candidate"
                    ),
                    evidence=evidence,
                    fact_ids=[association_fact.fact_id],
                )
            )

        observed = _observed_color(asset)
        if observed is None:
            continue
        normalized_observed = _normalize_color(observed)
        declared = colors.get(target) if target is not None else None
        normalized_declared = _normalize_color(declared)
        is_conflict = bool(
            normalized_declared
            and normalized_observed
            and normalized_declared != normalized_observed
        )
        color_value = {
            "asset_id": asset.asset_id,
            "observed": observed,
            "normalized": normalized_observed or observed,
        }
        color_attributes = {
            "source_boundary": "visual_asset_advisory",
            "conflicts_with_declared": is_conflict,
        }
        if declared is not None:
            color_attributes["declared"] = declared
            color_attributes["declared_normalized"] = normalized_declared or declared
        color_fact_id = stable_fact_id(
            name="visual_color_observation",
            value=color_value,
            subject=target or asset.asset_id,
            attributes=color_attributes,
            evidence_ids=[evidence.evidence_id],
        )
        color_fact = SemanticFact(
            fact_id=color_fact_id,
            name="visual_color_observation",
            value=color_value,
            subject=target or asset.asset_id,
            attributes=color_attributes,
            evidence_refs=[evidence],
            extractor="drawing_semantics.v1",
            confidence=0.5,
            status="ambiguous" if is_conflict else "advisory",
        )
        facts.append(color_fact)
        if is_conflict:
            issues.append(
                DrawingSemanticIssue(
                    code="DRAWING_VISUAL_COLOR_CONFLICT",
                    message=(
                        f"visual color {observed!r} conflicts with "
                        f"declared color {declared!r}"
                    ),
                    evidence=evidence,
                    fact_ids=[color_fact.fact_id],
                )
            )

    return DrawingAssetAssociationResult(facts=facts, issues=issues)


__all__ = [
    "DrawingAssetAssociationResult",
    "DrawingAssetObservation",
    "DrawingLocalization",
    "DrawingSemanticIssue",
    "DrawingSemanticResult",
    "associate_drawing_assets",
    "canonical_decimal",
    "extract_drawing_semantics",
]
