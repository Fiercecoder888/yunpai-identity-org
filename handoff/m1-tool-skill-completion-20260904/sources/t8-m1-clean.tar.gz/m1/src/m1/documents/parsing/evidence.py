"""Provider-neutral document evidence models.

The public ``m1.document.v2`` contract deliberately remains unchanged.  These
models isolate PP-Structure, PaddleOCR-VL and Docling result variants from the
business builders and preserve enough geometry for source references.
"""

from __future__ import annotations

import json
import math
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

CoordinateSpace = Literal["pixels", "pdf_points", "normalized", "unknown"]


class EvidenceModel(BaseModel):
    model_config = ConfigDict(extra="allow")


class EvidenceBBox(EvidenceModel):
    x0: float
    y0: float
    x1: float
    y1: float
    coordinate_space: CoordinateSpace = "pixels"

    @field_validator("x0", "y0", "x1", "y1")
    @classmethod
    def finite_coordinate(cls, value: float) -> float:
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("bbox coordinates must be finite")
        return number

    @field_validator("x1")
    @classmethod
    def ordered_x(cls, value: float, info) -> float:
        x0 = info.data.get("x0")
        if x0 is not None and value < x0:
            raise ValueError("bbox x1 must be greater than or equal to x0")
        return value

    @field_validator("y1")
    @classmethod
    def ordered_y(cls, value: float, info) -> float:
        y0 = info.data.get("y0")
        if y0 is not None and value < y0:
            raise ValueError("bbox y1 must be greater than or equal to y0")
        return value

    @property
    def area(self) -> float:
        return max(0.0, self.x1 - self.x0) * max(0.0, self.y1 - self.y0)

    def as_list(self) -> list[float]:
        return [self.x0, self.y0, self.x1, self.y1]

    def scale_to(
        self,
        *,
        source_width: float,
        source_height: float,
        target_width: float,
        target_height: float,
    ) -> list[float]:
        if self.coordinate_space == "pdf_points":
            return [round(value, 4) for value in self.as_list()]
        if self.coordinate_space == "normalized":
            sx, sy = target_width, target_height
        else:
            sx = target_width / max(1.0, source_width)
            sy = target_height / max(1.0, source_height)
        return [
            round(self.x0 * sx, 4),
            round(self.y0 * sy, 4),
            round(self.x1 * sx, 4),
            round(self.y1 * sy, 4),
        ]


class EvidenceBlock(EvidenceModel):
    block_id: str
    kind: str = "text"
    text: str = ""
    bbox: EvidenceBBox | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    order: int = 0
    source: str = ""


class EvidenceCell(EvidenceModel):
    row: int = Field(ge=0)
    column: int = Field(ge=0)
    text: str | None = None
    bbox: EvidenceBBox | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class EvidenceTable(EvidenceModel):
    table_id: str
    rows: list[list[str | None]] = Field(default_factory=list)
    cells: list[EvidenceCell] = Field(default_factory=list)
    bbox: EvidenceBBox | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    source: str = ""


class EvidencePage(EvidenceModel):
    page_number: int = Field(ge=1)
    page_index: int = Field(ge=0)
    width: float = Field(gt=0)
    height: float = Field(gt=0)
    coordinate_space: CoordinateSpace = "pixels"
    rotation: int = 0
    blocks: list[EvidenceBlock] = Field(default_factory=list)
    tables: list[EvidenceTable] = Field(default_factory=list)
    markdown: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def text(self) -> str:
        return "\n".join(block.text for block in self.blocks if block.text.strip())

    @property
    def mean_text_confidence(self) -> float | None:
        scores = [
            block.confidence
            for block in self.blocks
            if block.text.strip() and block.confidence is not None
        ]
        return sum(scores) / len(scores) if scores else None

    @property
    def visual_coverage_ratio(self) -> float:
        page_area = max(1.0, self.width * self.height)
        visual = 0.0
        for block in self.blocks:
            if block.bbox is None or block.kind.casefold() not in {
                "image",
                "figure",
                "chart",
                "seal",
            }:
                continue
            if block.bbox.coordinate_space == "normalized":
                visual += block.bbox.area
            else:
                visual += block.bbox.area / page_area
        return min(1.0, visual)

    @property
    def dominant_complex_table(self) -> bool:
        """Whether one table has swallowed most of a complex page layout.

        Engineering drawings are occasionally returned as a single giant table
        even though the matrix mixes title blocks, diagrams, wiring and BOM data.
        Intersecting the bbox with the page avoids scores above one when a provider
        reports coordinates after an implicit 90-degree rotation.
        """

        page_area = max(1.0, self.width * self.height)
        independent_text = any(
            block.text.strip()
            and block.kind.casefold() not in {"table", "table_caption", "table_text"}
            for block in self.blocks
        )
        if independent_text:
            return False
        for table in self.tables:
            row_count = len(table.rows)
            column_count = max((len(row) for row in table.rows), default=0)
            cell_count = max(
                len(table.cells),
                sum(len(row) for row in table.rows),
            )
            if cell_count < 100 and not (row_count >= 20 and column_count >= 10):
                continue
            if table.bbox is None:
                continue
            width = max(0.0, min(self.width, table.bbox.x1) - max(0.0, table.bbox.x0))
            height = max(0.0, min(self.height, table.bbox.y1) - max(0.0, table.bbox.y0))
            if (width * height) / page_area >= 0.65:
                return True
        return False

    def needs_vlm(
        self,
        *,
        confidence_threshold: float = 0.75,
        visual_coverage_threshold: float = 0.20,
    ) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        nonempty = bool(
            self.raw.get("nonempty", any(block.bbox for block in self.blocks))
        )
        if not self.text.strip() and nonempty:
            reasons.append("empty_text")
        mean = self.mean_text_confidence
        if mean is not None and mean < confidence_threshold:
            reasons.append("low_text_confidence")
        if any(table.rows == [] for table in self.tables):
            reasons.append("table_without_cells")
        if self.dominant_complex_table:
            reasons.append("page_dominated_by_complex_table")
        if self.visual_coverage_ratio > visual_coverage_threshold:
            reasons.append("visual_region")
        return bool(reasons), reasons


class DocumentEvidence(EvidenceModel):
    backend: str
    backend_version: str = "unknown"
    model_fingerprints: dict[str, str] = Field(default_factory=dict)
    elapsed_ms: float = Field(default=0.0, ge=0.0)
    pages: list[EvidencePage] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def text(self) -> str:
        return "\n\f\n".join(page.text for page in self.pages)

    def summary(self) -> dict[str, Any]:
        summary = {
            "backend": self.backend,
            "backend_version": self.backend_version,
            "model_fingerprints": dict(self.model_fingerprints),
            "elapsed_ms": round(self.elapsed_ms, 3),
            "page_count": len(self.pages),
            "block_count": sum(len(page.blocks) for page in self.pages),
            "table_count": sum(len(page.tables) for page in self.pages),
            "warnings": list(self.warnings),
        }
        for key in (
            "vlm_escalated_pages",
            "vlm_escalation_reasons_by_page",
            "vlm_escalation_skipped_pages",
            "vlm_escalation_suppressed_pages",
            "vlm_failed_pages",
            "vlm_failure_types",
            "vlm_unavailable_pages",
            "vlm_unavailable_reasons",
        ):
            if key in self.raw:
                summary[key] = self.raw[key]
        return summary

    def bounded_dump(self, max_bytes: int = 256 * 1024) -> dict[str, Any]:
        payload = self.model_dump(mode="json")
        encoded = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        if len(encoded) <= max_bytes:
            return payload
        return {
            **self.summary(),
            "truncated": True,
            "original_bytes": len(encoded),
        }


def bbox_from_value(value: Any, *, coordinate_space: CoordinateSpace = "pixels") -> EvidenceBBox | None:
    """Accept Paddle/Docling bbox variants without leaking provider objects."""

    if value is None:
        return None
    if isinstance(value, dict):
        if all(key in value for key in ("l", "t", "r", "b")):
            value = [value["l"], value["t"], value["r"], value["b"]]
        elif all(key in value for key in ("x0", "y0", "x1", "y1")):
            value = [value["x0"], value["y0"], value["x1"], value["y1"]]
        elif "coordinate" in value:
            value = value["coordinate"]
        elif "bbox" in value:
            value = value["bbox"]
    tolist = getattr(value, "tolist", None)
    if callable(tolist):
        value = tolist()
    if isinstance(value, (list, tuple)) and len(value) >= 4:
        if isinstance(value[0], (list, tuple)):
            points = [point for point in value if isinstance(point, (list, tuple)) and len(point) >= 2]
            if not points:
                return None
            value = [
                min(float(point[0]) for point in points),
                min(float(point[1]) for point in points),
                max(float(point[0]) for point in points),
                max(float(point[1]) for point in points),
            ]
        try:
            return EvidenceBBox(
                x0=float(value[0]),
                y0=float(value[1]),
                x1=float(value[2]),
                y1=float(value[3]),
                coordinate_space=coordinate_space,
            )
        except (TypeError, ValueError):
            return None
    return None


__all__ = [
    "CoordinateSpace",
    "DocumentEvidence",
    "EvidenceBBox",
    "EvidenceBlock",
    "EvidenceCell",
    "EvidencePage",
    "EvidenceTable",
    "bbox_from_value",
]
