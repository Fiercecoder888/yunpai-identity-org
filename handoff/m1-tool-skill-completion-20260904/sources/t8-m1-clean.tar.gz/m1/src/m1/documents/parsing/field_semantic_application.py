"""Fail-closed adapters from governed field routes to document targets.

The routing runtime resolves code-owned field IDs.  This module is the only
place that turns those IDs into executable ``DocumentRecord`` paths.  Source
values never enter the selector prompt and remain in their lossless containers
even when an active mapping fills a canonical gap.
"""

from __future__ import annotations

import copy
import json
import re
from collections import OrderedDict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Protocol

from ..envelope import CellValue, DocumentEnvelope
from ..models import DocumentRecord, FieldMetadata, OrderLine
from ..tabular_schema import (
    ColumnMapping,
    HeaderFieldMapping,
    RowMapping,
    TabularSchemaPlan,
    _header_target,
    _line_target,
    _mapping_labels,
    _nonempty,
    _real_cell,
    _sheets,
    _table_cell,
    _table_record_indices,
    _target_is_canonical,
)
from .field_semantic_registry import CanonicalFieldRegistry
from .field_semantic_routing import (
    FieldScope,
    FieldSemanticInput,
    FieldSemanticProbe,
    FieldSemanticResolvedInput,
    FieldValueKind,
    TableRole,
)
from .mineru_domain import mapping_path, parse_number, replay_line_value

_COORDINATE_SUFFIX = re.compile(r"\s+\[[A-Z]+[1-9]\d*\]$", re.IGNORECASE)
_EMPTY_VALUES = (None, "")


class FieldSemanticBatchRuntime(Protocol):
    """Small protocol shared by tabular and MinerU production adapters."""

    mode: str
    max_fields_per_document: int
    required: bool

    async def resolve_fields(
        self,
        *,
        tenant_id: str,
        fields: Sequence[FieldSemanticInput],
        created_by: str = "field-semantic-router",
    ) -> tuple[FieldSemanticResolvedInput, ...]: ...


@dataclass(frozen=True, slots=True)
class FieldRouteAudit:
    source_ref: str
    action: str
    reason: str
    canonical_field_id: str | None = None
    target_path: str | None = None
    profile_id: str | None = None
    candidate_profile_id: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_ref": self.source_ref,
            "action": self.action,
            "reason": self.reason,
            "canonical_field_id": self.canonical_field_id,
            "target_path": self.target_path,
            "profile_id": self.profile_id,
            "candidate_profile_id": self.candidate_profile_id,
        }


@dataclass(frozen=True, slots=True)
class RoutedTabularPlan:
    plan: TabularSchemaPlan
    original_plan: TabularSchemaPlan
    audits: tuple[FieldRouteAudit, ...] = ()
    status: str = "completed"

    @property
    def changed(self) -> bool:
        return self.plan != self.original_plan

    def metadata(self) -> dict[str, Any]:
        mapped = sum(item.action == "mapped" for item in self.audits)
        return {
            "status": self.status,
            "changed": self.changed,
            "observed_fields": len(self.audits),
            "mapped_fields": mapped,
            "preserved_fields": len(self.audits) - mapped,
            "decisions": [item.as_dict() for item in self.audits],
        }


@dataclass(frozen=True, slots=True)
class _PlanField:
    source_ref: str
    mapping: HeaderFieldMapping | ColumnMapping | RowMapping
    field_input: FieldSemanticInput
    allowed_prefixes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _DocumentField:
    line_index: int | None
    container: str
    key: str
    label: str
    value: Any
    metadata_path: str | None
    neighboring_labels: tuple[str, ...] = ()


def _json_value(value: Any) -> Any:
    """Return a bounded JsonValue representation without mutating the source."""

    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    try:
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return str(value)


def _value_kind(values: Iterable[Any]) -> FieldValueKind:
    nonempty = [value for value in values if value not in _EMPTY_VALUES]
    if not nonempty:
        return FieldValueKind.UNKNOWN
    if all(isinstance(value, bool) for value in nonempty):
        return FieldValueKind.BOOLEAN
    if all(isinstance(value, datetime) for value in nonempty):
        return FieldValueKind.DATETIME
    if all(isinstance(value, date) for value in nonempty):
        return FieldValueKind.DATE
    if all(
        isinstance(value, int) and not isinstance(value, bool) for value in nonempty
    ):
        return FieldValueKind.INTEGER
    if all(
        isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)
        for value in nonempty
    ):
        return FieldValueKind.DECIMAL
    return FieldValueKind.TEXT


def _cell_label(cells: Sequence[CellValue], fallback: str) -> str:
    parts = [str(cell.value or "").strip() for cell in cells]
    label = " / ".join(dict.fromkeys(part for part in parts if part))
    return label or str(fallback).strip()


def _cell_refs(sheet: str, cells: Sequence[CellValue]) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            f"{sheet}!{cell.coordinate}"
            for cell in cells
            if str(cell.coordinate or "").strip()
        )
    )[:64]


def _plan_fields(
    envelope: DocumentEnvelope,
    plan: TabularSchemaPlan,
    document: DocumentRecord,
) -> tuple[_PlanField, ...]:
    sheets = _sheets(envelope)
    collected: list[_PlanField] = []
    header_labels: list[str] = []
    header_cells: list[list[CellValue]] = []
    for mapping in plan.header_fields:
        sheet = sheets[mapping.sheet]
        cells = [_real_cell(sheet, coordinate) for coordinate in mapping.label_cells]
        header_cells.append(cells)
        header_labels.append(_cell_label(cells, mapping.field))

    for index, mapping in enumerate(plan.header_fields):
        target = _header_target(mapping)
        if _target_is_canonical(target):
            continue
        sheet = sheets[mapping.sheet]
        values = [_real_cell(sheet, coordinate) for coordinate in mapping.value_cells]
        label_cells = header_cells[index]
        label = header_labels[index]
        source_ref = f"header_fields:{index}"
        collected.append(
            _PlanField(
                source_ref=source_ref,
                mapping=mapping,
                field_input=FieldSemanticInput(
                    source_ref=source_ref,
                    probe=FieldSemanticProbe(
                        label=label,
                        neighboring_labels=tuple(
                            item
                            for peer, item in enumerate(header_labels)
                            if peer != index
                        )[:8],
                        document_domain=document.document_type or "unknown",
                        document_type=document.document_type or "unknown",
                        document_subtype=document.document_subtype or "unknown",
                        field_scope=FieldScope.DOCUMENT,
                        table_role=TableRole.KEY_VALUE,
                        value_kind=_value_kind(cell.value for cell in values),
                        repeated=False,
                    ),
                    value=_json_value(values[0].value),
                    evidence_refs=_cell_refs(mapping.sheet, [*label_cells, *values]),
                ),
                allowed_prefixes=("$.header.", "$.totals."),
            )
        )

    for table_index, table in enumerate(plan.tables):
        sheet = sheets[table.sheet]
        mappings: list[ColumnMapping | RowMapping] = (
            list(table.columns)
            if table.orientation == "rows"
            else list(table.row_fields)
        )
        labels_by_mapping = [
            _cell_label(_mapping_labels(sheet, table, mapping), mapping.field)
            for mapping in mappings
        ]
        record_indices = _table_record_indices(sheet, table)
        for mapping_index, mapping in enumerate(mappings):
            target = _line_target(mapping)
            if _target_is_canonical(target):
                continue
            label_cells = _mapping_labels(sheet, table, mapping)
            value_cells = [
                cell
                for record_index in record_indices
                if _nonempty(cell := _table_cell(sheet, table, mapping, record_index))
            ]
            if not value_cells:
                continue
            axis = "columns" if table.orientation == "rows" else "row_fields"
            source_ref = f"tables:{table_index}:{axis}:{mapping_index}"
            collected.append(
                _PlanField(
                    source_ref=source_ref,
                    mapping=mapping,
                    field_input=FieldSemanticInput(
                        source_ref=source_ref,
                        probe=FieldSemanticProbe(
                            label=labels_by_mapping[mapping_index],
                            neighboring_labels=tuple(
                                item
                                for peer, item in enumerate(labels_by_mapping)
                                if peer != mapping_index
                            )[:8],
                            document_domain=document.document_type or "unknown",
                            document_type=document.document_type or "unknown",
                            document_subtype=document.document_subtype or "unknown",
                            field_scope=FieldScope.LINE_ITEM,
                            table_role=TableRole.LINE_ITEM,
                            value_kind=_value_kind(cell.value for cell in value_cells),
                            repeated=True,
                        ),
                        value=_json_value(value_cells[0].value),
                        evidence_refs=_cell_refs(
                            table.sheet, [*label_cells, *value_cells[:8]]
                        ),
                    ),
                    allowed_prefixes=("$.lines[*].",),
                )
            )
    return tuple(collected)


async def route_tabular_schema_plan(
    *,
    envelope: DocumentEnvelope,
    plan: TabularSchemaPlan,
    document: DocumentRecord,
    tenant_id: str,
    runtime: FieldSemanticBatchRuntime,
    registry: CanonicalFieldRegistry,
) -> RoutedTabularPlan:
    """Rewrite only unknown plan targets backed by active governed routes."""

    original = plan.model_copy(deep=True)
    routed = plan.model_copy(deep=True)
    fields = _plan_fields(envelope, routed, document)
    if not fields:
        return RoutedTabularPlan(plan=routed, original_plan=original)
    try:
        resolutions = await runtime.resolve_fields(
            tenant_id=tenant_id,
            fields=tuple(item.field_input for item in fields),
            created_by="tabular-field-semantic-router",
        )
    except Exception:
        if bool(getattr(runtime, "required", False)):
            raise
        return RoutedTabularPlan(
            plan=original.model_copy(deep=True),
            original_plan=original,
            status="degraded",
            audits=tuple(
                FieldRouteAudit(
                    source_ref=item.source_ref,
                    action="preserved",
                    reason="runtime_failure",
                )
                for item in fields
            ),
        )

    expected_refs = {item.source_ref for item in fields}
    resolved_refs = [item.source_ref for item in resolutions]
    if len(resolved_refs) != len(expected_refs) or set(resolved_refs) != expected_refs:
        return RoutedTabularPlan(
            plan=original.model_copy(deep=True),
            original_plan=original,
            status="degraded",
            audits=tuple(
                FieldRouteAudit(
                    source_ref=item.source_ref,
                    action="preserved",
                    reason="resolution_set_mismatch",
                )
                for item in fields
            ),
        )

    by_ref = {item.source_ref: item for item in fields}
    apply_mappings = str(getattr(runtime, "mode", "shadow")).casefold() == "guarded"
    audits: list[FieldRouteAudit] = []
    for resolved in resolutions:
        planned = by_ref.get(resolved.source_ref)
        if planned is None:
            continue
        decision = resolved.resolution
        target = (
            registry.target_path(decision.canonical_field_id)
            if decision.action == "mapped"
            else None
        )
        if target is not None and not apply_mappings:
            audits.append(
                FieldRouteAudit(
                    source_ref=planned.source_ref,
                    action="preserved",
                    reason="shadow_mapping_observed",
                    canonical_field_id=decision.canonical_field_id,
                    target_path=target,
                    profile_id=decision.profile_id,
                    candidate_profile_id=decision.candidate_profile_id,
                )
            )
            continue
        if target is None or not target.startswith(planned.allowed_prefixes):
            audits.append(
                FieldRouteAudit(
                    source_ref=planned.source_ref,
                    action="preserved",
                    reason=(
                        "target_scope_mismatch"
                        if decision.action == "mapped"
                        else decision.reason
                    ),
                    canonical_field_id=decision.canonical_field_id,
                    profile_id=decision.profile_id,
                    candidate_profile_id=decision.candidate_profile_id,
                )
            )
            continue
        planned.mapping.target_path = target
        audits.append(
            FieldRouteAudit(
                source_ref=planned.source_ref,
                action="mapped",
                reason=decision.reason,
                canonical_field_id=decision.canonical_field_id,
                target_path=target,
                profile_id=decision.profile_id,
                candidate_profile_id=decision.candidate_profile_id,
            )
        )
    return RoutedTabularPlan(
        plan=routed,
        original_plan=original,
        audits=tuple(audits),
    )


def merge_lossless_plan_fields(
    document: DocumentRecord,
    lossless: DocumentRecord,
) -> DocumentRecord:
    """Merge only raw/custom values produced by the pre-route plan."""

    extraction_custom = lossless.extraction.get("custom_fields")
    if isinstance(extraction_custom, Mapping):
        target = document.extraction.setdefault("custom_fields", {})
        if isinstance(target, dict):
            for key, value in extraction_custom.items():
                target.setdefault(str(key), copy.deepcopy(value))
    for key, value in lossless.totals.source_declared.items():
        document.totals.source_declared.setdefault(key, copy.deepcopy(value))

    lossless_by_id = {line.line_id: line for line in lossless.lines}
    for index, line in enumerate(document.lines):
        source = lossless_by_id.get(line.line_id)
        if source is None and index < len(lossless.lines):
            candidate = lossless.lines[index]
            if candidate.line_id == line.line_id:
                source = candidate
        if source is None:
            continue
        for container in ("raw_columns", "custom_fields"):
            target_values = getattr(line, container)
            for key, value in getattr(source, container).items():
                target_values.setdefault(key, copy.deepcopy(value))

    for path, metadata in lossless.field_meta.items():
        if any(
            marker in path
            for marker in (
                ".raw_columns[",
                ".custom_fields[",
                ".custom_fields.",
                "$.extraction.custom_fields.",
                "$.totals.source_declared[",
                "$.totals.source_declared.",
            )
        ):
            document.field_meta.setdefault(path, metadata.model_copy(deep=True))
    return document


def _source_label(metadata: FieldMetadata | None, key: str) -> str:
    candidate = (
        getattr(metadata, "source_label", None) if metadata is not None else None
    )
    label = str(candidate or key).strip()
    return _COORDINATE_SUFFIX.sub("", label).strip() or str(key)


def _metadata_refs(metadata: FieldMetadata | None, path: str | None) -> tuple[str, ...]:
    refs: list[str] = []
    if path:
        refs.append(path)
    if metadata is not None:
        for source in metadata.source_refs:
            if source.sheet and source.cell:
                refs.append(f"{source.sheet}!{source.cell}")
            elif source.page is not None:
                refs.append(f"page:{source.page}:{source.part or ''}".rstrip(":"))
            elif source.part:
                refs.append(source.part)
    return tuple(dict.fromkeys(refs))[:64]


def _document_fields(document: DocumentRecord) -> tuple[_DocumentField, ...]:
    fields: list[_DocumentField] = []
    extraction_custom = document.extraction.get("custom_fields")
    if isinstance(extraction_custom, Mapping):
        extraction_labels = tuple(str(key) for key in extraction_custom)
        for key, value in extraction_custom.items():
            path = mapping_path("$.extraction", "custom_fields", str(key))
            metadata = document.field_meta.get(path)
            fields.append(
                _DocumentField(
                    line_index=None,
                    container="extraction.custom_fields",
                    key=str(key),
                    label=_source_label(metadata, str(key)),
                    value=value,
                    metadata_path=(
                        path if metadata is not None and metadata.source_refs else None
                    ),
                    neighboring_labels=tuple(
                        label for label in extraction_labels if label != str(key)
                    )[:8],
                )
            )
    for line_index, line in enumerate(document.lines):
        line_labels = tuple(
            dict.fromkeys(
                str(key)
                for container in (line.custom_fields, line.raw_columns)
                for key in container
            )
        )
        for container in ("custom_fields", "raw_columns"):
            values = getattr(line, container)
            for key, value in values.items():
                path = mapping_path(f"$.lines[{line_index}]", container, str(key))
                metadata = document.field_meta.get(path)
                fields.append(
                    _DocumentField(
                        line_index=line_index,
                        container=container,
                        key=str(key),
                        label=_source_label(metadata, str(key)),
                        value=value,
                        metadata_path=(
                            path
                            if metadata is not None and metadata.source_refs
                            else None
                        ),
                        neighboring_labels=tuple(
                            label for label in line_labels if label != str(key)
                        )[:8],
                    )
                )
    return tuple(fields)


def _group_document_fields(
    fields: Sequence[_DocumentField],
) -> tuple[tuple[_DocumentField, ...], ...]:
    grouped: OrderedDict[tuple[str, str, tuple[str, ...]], list[_DocumentField]] = (
        OrderedDict()
    )
    for field in fields:
        scope = "document" if field.line_index is None else "line_item"
        key = (
            scope,
            field.label.casefold(),
            tuple(label.casefold() for label in field.neighboring_labels),
        )
        grouped.setdefault(key, []).append(field)
    return tuple(tuple(items) for items in grouped.values())


def _field_metadata(
    document: DocumentRecord, field: _DocumentField
) -> FieldMetadata | None:
    if field.metadata_path is None:
        return None
    return document.field_meta.get(field.metadata_path)


def _document_input(
    document: DocumentRecord,
    group: Sequence[_DocumentField],
    group_index: int,
) -> FieldSemanticInput:
    first = group[0]
    document_scope = first.line_index is None
    metadata = _field_metadata(document, first)
    source_ref = f"document-field:{group_index}"
    return FieldSemanticInput(
        source_ref=source_ref,
        probe=FieldSemanticProbe(
            label=first.label,
            neighboring_labels=first.neighboring_labels,
            document_domain=document.document_type or "unknown",
            document_type=document.document_type or "unknown",
            document_subtype=document.document_subtype or "unknown",
            field_scope=(
                FieldScope.DOCUMENT if document_scope else FieldScope.LINE_ITEM
            ),
            table_role=(TableRole.KEY_VALUE if document_scope else TableRole.LINE_ITEM),
            value_kind=_value_kind(field.value for field in group),
            repeated=not document_scope,
        ),
        value=_json_value(first.value),
        evidence_refs=_metadata_refs(metadata, first.metadata_path),
    )


def _target_is_empty(
    document: DocumentRecord, target: str, line_index: int | None
) -> bool:
    if target.startswith("$.header."):
        return (
            getattr(document.header, target.removeprefix("$.header."), None)
            in _EMPTY_VALUES
        )
    if target.startswith("$.totals."):
        return (
            getattr(document.totals, target.removeprefix("$.totals."), None)
            in _EMPTY_VALUES
        )
    if target.startswith("$.lines[*].") and line_index is not None:
        line = document.lines[line_index]
        relative = target.removeprefix("$.lines[*].")
        if relative.startswith("custom_fields."):
            return (
                line.custom_fields.get(relative.removeprefix("custom_fields."))
                in _EMPTY_VALUES
            )
        return getattr(line, relative, None) in _EMPTY_VALUES
    return False


def _target_metadata_path(target: str, line_index: int | None) -> str | None:
    if target.startswith("$.lines[*].") and line_index is not None:
        relative = target.removeprefix("$.lines[*].")
        if relative.startswith("custom_fields."):
            return mapping_path(
                f"$.lines[{line_index}]",
                "custom_fields",
                relative.removeprefix("custom_fields."),
            )
        return f"$.lines[{line_index}].{relative}"
    if target.startswith(("$.header.", "$.totals.")) and line_index is None:
        return target
    return None


def _set_document_value(
    document: DocumentRecord,
    target: str,
    field: _DocumentField,
) -> bool:
    if not _target_is_empty(document, target, field.line_index):
        return False
    if target.startswith("$.header.") and field.line_index is None:
        name = target.removeprefix("$.header.")
        setattr(document.header, name, str(field.value).strip() or None)
        return getattr(document.header, name) not in _EMPTY_VALUES
    if target.startswith("$.totals.") and field.line_index is None:
        name = target.removeprefix("$.totals.")
        number = parse_number(field.value)
        if number is None:
            return False
        setattr(document.totals, name, number)
        return True
    if target.startswith("$.lines[*].") and field.line_index is not None:
        relative = target.removeprefix("$.lines[*].")
        semantic_target = relative.removeprefix("custom_fields.")
        line: OrderLine = document.lines[field.line_index]
        return replay_line_value(line, semantic_target, field.value) is not None
    return False


def _copy_field_metadata(
    document: DocumentRecord,
    *,
    source: _DocumentField,
    target_path: str,
) -> None:
    source_metadata = _field_metadata(document, source)
    if source_metadata is None:
        return
    payload = source_metadata.model_dump(mode="python")
    payload.update(
        {
            "inferred": True,
            "model_mapped": True,
            "normalized_from": source.label,
        }
    )
    document.field_meta[target_path] = FieldMetadata.model_validate(payload)


def _routing_metadata(document: DocumentRecord) -> dict[str, Any]:
    metadata = document.extraction.setdefault("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
        document.extraction["metadata"] = metadata
    routing = metadata.setdefault("field_semantic_routing", {})
    if not isinstance(routing, dict):
        routing = {}
        metadata["field_semantic_routing"] = routing
    return routing


async def route_document_custom_fields(
    *,
    document: DocumentRecord,
    tenant_id: str,
    runtime: FieldSemanticBatchRuntime,
    registry: CanonicalFieldRegistry,
) -> DocumentRecord:
    """Fill canonical gaps from MinerU raw/custom fields without deleting evidence."""

    result = document.model_copy(deep=True)
    fields = _document_fields(result)
    groups = _group_document_fields(fields)
    if not groups:
        return result
    inputs = tuple(
        _document_input(result, group, index) for index, group in enumerate(groups)
    )
    try:
        resolutions = await runtime.resolve_fields(
            tenant_id=tenant_id,
            fields=inputs,
            created_by="mineru-field-semantic-router",
        )
    except Exception:
        if bool(getattr(runtime, "required", False)):
            raise
        _routing_metadata(result).update(
            {
                "status": "degraded",
                "reason": "runtime_failure",
                "observed_fields": len(groups),
                "mapped_fields": 0,
            }
        )
        return result

    expected_refs = {field.source_ref for field in inputs}
    resolved_refs = [item.source_ref for item in resolutions]
    if len(resolved_refs) != len(expected_refs) or set(resolved_refs) != expected_refs:
        _routing_metadata(result).update(
            {
                "status": "degraded",
                "reason": "resolution_set_mismatch",
                "observed_fields": len(groups),
                "mapped_fields": 0,
            }
        )
        return result

    resolved_by_ref = {item.source_ref: item.resolution for item in resolutions}
    apply_mappings = str(getattr(runtime, "mode", "shadow")).casefold() == "guarded"
    audits: list[FieldRouteAudit] = []
    populated = 0
    for index, group in enumerate(groups):
        source_ref = f"document-field:{index}"
        resolution = resolved_by_ref.get(source_ref)
        target = (
            registry.target_path(resolution.canonical_field_id)
            if resolution is not None and resolution.action == "mapped"
            else None
        )
        expected_prefix = "$.header." if group[0].line_index is None else "$.lines[*]."
        if group[0].line_index is None and target is not None:
            in_scope = target.startswith(("$.header.", "$.totals."))
        else:
            in_scope = target is not None and target.startswith(expected_prefix)
        if (
            resolution is not None
            and target is not None
            and in_scope
            and not apply_mappings
        ):
            audits.append(
                FieldRouteAudit(
                    source_ref=source_ref,
                    action="preserved",
                    reason="shadow_mapping_observed",
                    canonical_field_id=resolution.canonical_field_id,
                    target_path=target,
                    profile_id=resolution.profile_id,
                    candidate_profile_id=resolution.candidate_profile_id,
                )
            )
            continue
        if resolution is None or target is None or not in_scope:
            audits.append(
                FieldRouteAudit(
                    source_ref=source_ref,
                    action="preserved",
                    reason=(
                        "missing_resolution"
                        if resolution is None
                        else (
                            "target_scope_mismatch"
                            if resolution.action == "mapped"
                            else resolution.reason
                        )
                    ),
                    canonical_field_id=(
                        resolution.canonical_field_id
                        if resolution is not None
                        else None
                    ),
                    profile_id=(
                        resolution.profile_id if resolution is not None else None
                    ),
                    candidate_profile_id=(
                        resolution.candidate_profile_id
                        if resolution is not None
                        else None
                    ),
                )
            )
            continue
        for source in group:
            # Canonical facts require replayable source evidence.  A raw value
            # without FieldMetadata remains lossless but is never promoted.
            if source.metadata_path is None:
                continue
            if not _set_document_value(result, target, source):
                continue
            target_metadata = _target_metadata_path(target, source.line_index)
            if target_metadata is not None:
                _copy_field_metadata(
                    result,
                    source=source,
                    target_path=target_metadata,
                )
            populated += 1
        audits.append(
            FieldRouteAudit(
                source_ref=source_ref,
                action="mapped",
                reason=resolution.reason,
                canonical_field_id=resolution.canonical_field_id,
                target_path=target,
                profile_id=resolution.profile_id,
                candidate_profile_id=resolution.candidate_profile_id,
            )
        )
    _routing_metadata(result).update(
        {
            "status": "completed",
            "observed_fields": len(groups),
            "mapped_fields": sum(item.action == "mapped" for item in audits),
            "populated_values": populated,
            "decisions": [item.as_dict() for item in audits],
        }
    )
    try:
        return DocumentRecord.model_validate(result.model_dump(mode="python"))
    except Exception:
        if bool(getattr(runtime, "required", False)):
            raise
        fallback = document.model_copy(deep=True)
        _routing_metadata(fallback).update(
            {
                "status": "degraded",
                "reason": "post_route_validation_failed",
                "observed_fields": len(groups),
                "mapped_fields": 0,
            }
        )
        return fallback


__all__ = [
    "FieldRouteAudit",
    "FieldSemanticBatchRuntime",
    "RoutedTabularPlan",
    "merge_lossless_plan_fields",
    "route_document_custom_fields",
    "route_tabular_schema_plan",
]
