"""Strict data contracts for governed field-semantic routing."""

from __future__ import annotations

import hashlib
import json
import math
import re
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal, Protocol, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    field_validator,
    model_validator,
)

from .field_semantic_registry import (
    CANONICAL_FIELD_ID_RE,
    SAFE_ROUTE_ID_RE,
    FieldScope,
    FieldValueKind,
    TableRole,
)

_LABEL_SEPARATORS = re.compile(r"[\s_:：/\\|,，;；()（）\[\]【】{}<>]+")
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_EMAIL = re.compile(
    r"(?i)(?<![\w.+-])[\w.+-]{1,64}@[a-z0-9-]{1,63}(?:\.[a-z0-9-]{1,63})+"
)
_URL = re.compile(r"(?i)(?:https?://|www\.)\S+")
_PHONE = re.compile(r"(?<!\d)(?:\+?86[-\s]?)?1[3-9]\d{9}(?!\d)")
_LONG_IDENTIFIER = re.compile(r"(?i)(?:\d{6,}|\b[0-9a-f]{24,}\b)")
_PROMPT_INJECTION = re.compile(
    r"(?i)(?:"
    r"ignore\s+(?:all\s+)?previous|system\s*prompt|developer\s*message|"
    r"prompt\s*injection|assistant\s*:|"
    r"忽略.{0,8}(?:指令|规则|提示)|系统.{0,4}(?:提示|消息)|"
    r"执行.{0,8}(?:命令|指令)|输出.{0,4}(?:密码|密钥|token)"
    r")"
)
_UNSAFE_LABEL_SYNTAX = re.compile(
    r"[`{};]|<\s*/?(?:system|assistant|user)\b", re.IGNORECASE
)
_DIGITS = re.compile(r"\d+")
_REDACTED_LABEL = "redacted_label"


def _label_contains_sensitive_content(value: str) -> bool:
    raw = unicodedata.normalize("NFKC", str(value or ""))
    return bool(
        len(raw) > 128
        or _CONTROL_CHARS.search(raw)
        or _EMAIL.search(raw)
        or _URL.search(raw)
        or _PHONE.search(raw)
        or _LONG_IDENTIFIER.search(raw)
        or _PROMPT_INJECTION.search(raw)
        or _UNSAFE_LABEL_SYNTAX.search(raw)
        or len(raw.split()) > 12
    )


def _normalise_label(value: str) -> str:
    if str(value or "") == _REDACTED_LABEL:
        return _REDACTED_LABEL
    if _label_contains_sensitive_content(value):
        return _REDACTED_LABEL
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _CONTROL_CHARS.sub("", text).strip().casefold()
    text = _DIGITS.sub(" number ", text)
    return _LABEL_SEPARATORS.sub(" ", text).strip()[:512]


def _normalise_token(value: str, *, default: str = "unknown") -> str:
    token = unicodedata.normalize("NFKC", str(value or "")).strip().casefold()
    token = re.sub(r"[^a-z0-9_.:-]+", "_", token).strip("_")
    if not token:
        return default
    if SAFE_ROUTE_ID_RE.fullmatch(token) is None:
        raise ValueError("routing context values must be stable structural tokens")
    return token


class FieldSemanticSignature(BaseModel):
    """Value-free routing signature persisted and embedded by the router."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    normalized_label: str = Field(min_length=1, max_length=512)
    label_safety: Literal["safe", "redacted"] = "safe"
    neighboring_labels: tuple[str, ...] = Field(default=(), max_length=8)
    document_domain: str = Field(default="unknown", min_length=1, max_length=128)
    document_type: str = Field(default="unknown", min_length=1, max_length=128)
    document_subtype: str = Field(default="unknown", min_length=1, max_length=128)
    field_scope: FieldScope = FieldScope.UNKNOWN
    table_role: TableRole = TableRole.UNKNOWN
    value_kind: FieldValueKind = FieldValueKind.UNKNOWN
    repeated: bool = False
    contract_revision: str = Field(
        default="m1.field-semantic.v1", min_length=1, max_length=128
    )

    @field_validator("normalized_label", mode="before")
    @classmethod
    def normalize_label(cls, value: object) -> str:
        normalized = _normalise_label(str(value or ""))
        if not normalized:
            raise ValueError("a source field label is required")
        return normalized

    @field_validator("neighboring_labels", mode="before")
    @classmethod
    def normalize_neighbors(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("neighboring_labels must be a sequence")
        return tuple(
            dict.fromkeys(
                label
                for item in value
                if (label := _normalise_label(str(item or "")))
                and label != _REDACTED_LABEL
            )
        )[:8]

    @model_validator(mode="after")
    def validate_label_safety(self) -> Self:
        redacted = self.normalized_label == _REDACTED_LABEL
        if redacted != (self.label_safety == "redacted"):
            raise ValueError("field label safety must match its redacted projection")
        return self

    @field_validator(
        "document_domain",
        "document_type",
        "document_subtype",
        "contract_revision",
        mode="before",
    )
    @classmethod
    def normalize_context_token(cls, value: object) -> str:
        return _normalise_token(str(value or ""))

    def exact_fingerprint(self) -> str:
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def embedding_text(self) -> str:
        """Return structural context only; source values never enter vectors."""

        return "\n".join(
            (
                f"label={self.normalized_label}",
                f"label_safety={self.label_safety}",
                f"neighbors={'|'.join(self.neighboring_labels)}",
                f"document_domain={self.document_domain}",
                f"document_type={self.document_type}",
                f"document_subtype={self.document_subtype}",
                f"field_scope={self.field_scope.value}",
                f"table_role={self.table_role.value}",
                f"value_kind={self.value_kind.value}",
                f"repeated={str(self.repeated).lower()}",
                f"contract_revision={self.contract_revision}",
            )
        )


class FieldSemanticProbe(BaseModel):
    """One observed label and its non-value routing context."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    label: str = Field(min_length=1, max_length=512)
    neighboring_labels: tuple[str, ...] = Field(default=(), max_length=8)
    document_domain: str = Field(default="unknown", min_length=1, max_length=128)
    document_type: str = Field(default="unknown", min_length=1, max_length=128)
    document_subtype: str = Field(default="unknown", min_length=1, max_length=128)
    field_scope: FieldScope = FieldScope.UNKNOWN
    table_role: TableRole = TableRole.UNKNOWN
    value_kind: FieldValueKind = FieldValueKind.UNKNOWN
    repeated: bool = False
    contract_revision: str = "m1.field-semantic.v1"

    def signature(self) -> FieldSemanticSignature:
        normalized_label = _normalise_label(self.label)
        return FieldSemanticSignature(
            normalized_label=normalized_label,
            label_safety=(
                "redacted" if normalized_label == _REDACTED_LABEL else "safe"
            ),
            neighboring_labels=self.neighboring_labels,
            document_domain=self.document_domain,
            document_type=self.document_type,
            document_subtype=self.document_subtype,
            field_scope=self.field_scope,
            table_role=self.table_role,
            value_kind=self.value_kind,
            repeated=self.repeated,
            contract_revision=self.contract_revision,
        )


class FieldSemanticProfile(BaseModel):
    """Store-owned mapping profile; candidate profiles are never executable."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str = Field(min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    status: Literal["candidate", "active", "deprecated", "rejected"]
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: FieldSemanticSignature
    canonical_field_id: str | None = Field(default=None, max_length=128)
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)

    @field_validator("profile_id", "profile_key")
    @classmethod
    def validate_safe_id(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if SAFE_ROUTE_ID_RE.fullmatch(normalized) is None:
            raise ValueError("profile identifiers must be stable opaque tokens")
        return normalized

    @field_validator("canonical_field_id")
    @classmethod
    def validate_canonical_id(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip().casefold()
        if CANONICAL_FIELD_ID_RE.fullmatch(normalized) is None:
            raise ValueError("canonical field IDs must be stable tokens")
        return normalized

    @field_validator("embedding")
    @classmethod
    def validate_embedding(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        normalized = tuple(float(item) for item in value)
        if not normalized or not all(math.isfinite(item) for item in normalized):
            raise ValueError("field semantic embeddings must contain finite values")
        return normalized

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("profile fingerprint does not match its signature")
        if self.status == "active" and not self.canonical_field_id:
            raise ValueError("active field mappings require a canonical field")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("profile observation counters are inconsistent")
        if self.status == "active" and (self.success_count < 3 or self.failure_count):
            raise ValueError("active field mappings require three clean samples")
        return self


class FieldSemanticProfileMatch(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile: FieldSemanticProfile
    vector_similarity: float = Field(ge=-1.0, le=1.0)


class FieldSemanticCandidateProposal(BaseModel):
    """Value-free proposal.  The store may persist it only as a candidate."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    signature: FieldSemanticSignature
    canonical_field_id: str | None = Field(default=None, max_length=128)
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    created_by: str = Field(
        default="field-semantic-router", min_length=1, max_length=256
    )

    @field_validator("profile_key")
    @classmethod
    def validate_profile_key(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if SAFE_ROUTE_ID_RE.fullmatch(normalized) is None:
            raise ValueError("candidate identifiers must be stable tokens")
        return normalized

    @field_validator("canonical_field_id")
    @classmethod
    def validate_canonical_field_id(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip().casefold()
        if CANONICAL_FIELD_ID_RE.fullmatch(normalized) is None:
            raise ValueError("candidate canonical fields must be registry tokens")
        return normalized

    @model_validator(mode="after")
    def validate_candidate(self) -> Self:
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self


class FieldSemanticExecutionObservation(BaseModel):
    """Reviewed validation sample with only a one-way task reference."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    outcome: Literal["success", "failure"]
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome == "success":
            if not self.validation_passed:
                raise ValueError("successful samples must pass validation")
            if not self.reviewed_by.strip():
                raise ValueError("successful samples require a reviewer")
            if not re.fullmatch(r"[0-9a-f]{64}", self.review_note_sha256):
                raise ValueError("successful samples require a hashed review note")
        elif not self.error_code.strip():
            raise ValueError("failed samples require an error code")
        return self


class FieldSemanticStore(Protocol):
    async def get_active_field_semantic_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
    ) -> FieldSemanticProfile | None: ...

    async def find_active_field_semantic_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str,
        limit: int,
    ) -> Sequence[FieldSemanticProfileMatch]: ...

    async def create_field_semantic_candidate(
        self, record: FieldSemanticCandidateProposal
    ) -> FieldSemanticProfile: ...

    async def record_field_semantic_execution_observation(
        self, record: FieldSemanticExecutionObservation
    ) -> Any: ...


class FieldSemanticEmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class FieldSemanticRankedCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source: Literal["active_profile", "registry"]
    profile_id: str | None = None
    canonical_field_id: str
    vector_similarity: float = Field(ge=-1.0, le=1.0)
    label_similarity: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class FieldSemanticSelectionCandidate(BaseModel):
    """Model-safe projection; profile IDs and execution paths are omitted."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    candidate_index: int = Field(ge=0, le=4)
    source: Literal["active_profile", "registry"]
    canonical_field_id: str = Field(min_length=1, max_length=128)
    title: str = Field(min_length=1, max_length=128)
    description: str = Field(default="", max_length=512)
    vector_similarity: float = Field(ge=-1.0, le=1.0)
    label_similarity: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class FieldSemanticSelectionRequest(BaseModel):
    """Bounded prompt data with no tenant, source value, or executable target."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    signature: FieldSemanticSignature
    candidates: tuple[FieldSemanticSelectionCandidate, ...] = Field(max_length=5)


class FieldSemanticModelChoice(BaseModel):
    """The only accepted model result: an action and optional list index."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: Literal["reuse", "custom_field", "review"]
    candidate_index: int | None = Field(default=None, ge=0, le=4)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_choice(self) -> Self:
        if self.action == "reuse" and self.candidate_index is None:
            raise ValueError("reuse requires a candidate index")
        if self.action != "reuse" and self.candidate_index is not None:
            raise ValueError("only reuse may include a candidate index")
        return self


class FieldSemanticSelector(Protocol):
    async def select(
        self, request: FieldSemanticSelectionRequest
    ) -> FieldSemanticModelChoice | Mapping[str, Any]: ...


@dataclass(frozen=True, slots=True)
class FieldSemanticRoutingPolicy:
    max_model_candidates: int = 5
    vector_weight: float = 0.65
    label_weight: float = 0.35
    model_candidate_min_score: float = 0.45
    model_reuse_min_score: float = 0.68
    model_reuse_min_confidence: float = 0.85
    model_selected_max_score_gap: float = 0.15

    def __post_init__(self) -> None:
        if not 1 <= self.max_model_candidates <= 5:
            raise ValueError("max_model_candidates must be between one and five")
        for name in (
            "vector_weight",
            "label_weight",
            "model_candidate_min_score",
            "model_reuse_min_score",
            "model_reuse_min_confidence",
            "model_selected_max_score_gap",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be a finite value in [0, 1]")
        if self.vector_weight + self.label_weight <= 0:
            raise ValueError("routing score weights must have a positive sum")


class CustomFieldEntry(BaseModel):
    """Lossless fallback returned when no governed mapping may execute."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    label: str = Field(min_length=1, max_length=512)
    value: JsonValue
    evidence_refs: tuple[str, ...] = Field(default=(), max_length=64)
    reason: str = Field(min_length=1, max_length=128)


class FieldSemanticInput(BaseModel):
    """Adapter-facing immutable input for one field decision."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source_ref: str = Field(min_length=1, max_length=1024)
    probe: FieldSemanticProbe
    value: JsonValue
    evidence_refs: tuple[str, ...] = Field(default=(), max_length=64)


class FieldSemanticResolution(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: Literal["mapped", "custom_field", "review"]
    reason: str = Field(min_length=1, max_length=128)
    canonical_field_id: str | None = None
    profile_id: str | None = None
    candidate_profile_id: str | None = None
    custom_fields: tuple[CustomFieldEntry, ...] = Field(default=(), max_length=1)
    model_used: bool = False
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_resolution(self) -> Self:
        if self.action == "mapped":
            if not self.canonical_field_id or not self.profile_id:
                raise ValueError("mapped fields require an active profile and field")
            if self.custom_fields or self.candidate_profile_id:
                raise ValueError("mapped fields cannot contain fallback data")
        else:
            if self.canonical_field_id or self.profile_id:
                raise ValueError("unmapped fields cannot expose an executable mapping")
            if len(self.custom_fields) != 1:
                raise ValueError("unmapped fields must preserve one custom field")
        return self


class FieldSemanticResolvedInput(BaseModel):
    """Decision paired with its opaque source reference; input is not mutated."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source_ref: str = Field(min_length=1, max_length=1024)
    resolution: FieldSemanticResolution
