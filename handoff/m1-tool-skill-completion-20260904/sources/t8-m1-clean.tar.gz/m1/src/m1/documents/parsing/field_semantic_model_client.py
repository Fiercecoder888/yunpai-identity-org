"""Prompted-output adapter for the closed field-semantic selector."""

from __future__ import annotations

import json
from typing import Any, Protocol

from .field_semantic_routing import (
    FieldSemanticModelChoice,
    FieldSemanticSelectionRequest,
)


class FieldSemanticStructuredClient(Protocol):
    async def run(
        self,
        output_type: type[FieldSemanticModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> Any: ...


class PydanticFieldSemanticSelector:
    """Use an existing structured client without exposing execution targets."""

    _INSTRUCTIONS = (
        "Choose only from the listed canonical-field candidates. Return reuse "
        "only with candidate_index. Return custom_field when no candidate means "
        "the observed label, and review when ambiguity requires a person. Never "
        "emit a field name, JSONPath, code, expression, source value, or new key."
    )

    def __init__(self, client: FieldSemanticStructuredClient) -> None:
        self._client = client

    async def select(
        self, request: FieldSemanticSelectionRequest
    ) -> FieldSemanticModelChoice:
        run = await self._client.run(
            FieldSemanticModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=json.dumps(
                request.model_dump(mode="json"),
                ensure_ascii=True,
                sort_keys=True,
                separators=(",", ":"),
            ),
            request_limit=1,
        )
        return FieldSemanticModelChoice.model_validate(run.output, strict=True)


__all__ = ["FieldSemanticStructuredClient", "PydanticFieldSemanticSelector"]
