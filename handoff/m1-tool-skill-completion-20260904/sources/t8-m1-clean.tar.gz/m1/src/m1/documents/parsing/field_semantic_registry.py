"""Code-owned canonical field registry used by semantic routing."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping, Sequence
from enum import StrEnum
from types import MappingProxyType

from pydantic import BaseModel, ConfigDict, Field, field_validator

SAFE_ROUTE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")
CANONICAL_FIELD_ID_RE = re.compile(
    r"^[a-z][a-z0-9_]{0,63}(?:\.[a-z][a-z0-9_]{0,63}){0,7}$"
)
_LABEL_SEPARATORS = re.compile(r"[\s_:：/\\|,，;；()（）\[\]【】{}<>]+")
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")


def _normalise_label(value: str) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _CONTROL_CHARS.sub("", text).strip().casefold()
    return _LABEL_SEPARATORS.sub(" ", text).strip()[:512]


def _context_token(value: str) -> str:
    token = unicodedata.normalize("NFKC", str(value or "")).strip().casefold()
    token = re.sub(r"[^a-z0-9_.:-]+", "_", token).strip("_")
    if not token or SAFE_ROUTE_ID_RE.fullmatch(token) is None:
        raise ValueError("compatibility values must be stable structural tokens")
    return token


class FieldScope(StrEnum):
    UNKNOWN = "unknown"
    DOCUMENT = "document"
    LINE_ITEM = "line_item"
    PARTY = "party"
    ASSET = "asset"


class TableRole(StrEnum):
    UNKNOWN = "unknown"
    KEY_VALUE = "key_value"
    HEADER = "header"
    LINE_ITEM = "line_item"
    MATRIX = "matrix"


class FieldValueKind(StrEnum):
    UNKNOWN = "unknown"
    TEXT = "text"
    IDENTIFIER = "identifier"
    INTEGER = "integer"
    DECIMAL = "decimal"
    DATE = "date"
    DATETIME = "datetime"
    BOOLEAN = "boolean"
    CURRENCY = "currency"
    UNIT = "unit"


class CanonicalTargetPath(StrEnum):
    """Complete code-owned execution vocabulary for semantic field routes."""

    HEADER_TITLE = "$.header.title"
    HEADER_ISSUER = "$.header.issuer"
    HEADER_ORDER_NUMBER = "$.header.order_number"
    HEADER_CONTRACT_NUMBER = "$.header.contract_number"
    HEADER_DATE_RAW = "$.header.date_raw"
    HEADER_DELIVERY_DATE_RAW = "$.header.delivery_date_raw"
    HEADER_SETTLEMENT_METHOD = "$.header.settlement_method"
    HEADER_DELIVERY_ADDRESS = "$.header.delivery_address"
    HEADER_BUYER = "$.header.buyer"
    HEADER_SELLER = "$.header.seller"
    HEADER_SUPPLIER = "$.header.supplier"
    HEADER_CURRENCY = "$.header.currency"

    LINE_NO = "$.lines[*].line_no"
    LINE_MODEL = "$.lines[*].model"
    LINE_PRODUCT_CODE = "$.lines[*].product_code"
    LINE_NAME_RAW = "$.lines[*].name_raw"
    LINE_SPECIFICATION_RAW = "$.lines[*].specification_raw"
    LINE_BODY_PRINTING = "$.lines[*].body_printing"
    LINE_COLOR = "$.lines[*].color"
    LINE_QUANTITY = "$.lines[*].quantity"
    LINE_UNIT = "$.lines[*].unit"
    LINE_UNIT_PRICE_TAX_INCLUDED = "$.lines[*].unit_price_tax_included"
    LINE_AMOUNT_TAX_INCLUDED = "$.lines[*].amount_tax_included"
    LINE_UNIT_PRICE_TAX_EXCLUDED = "$.lines[*].unit_price_tax_excluded"
    LINE_AMOUNT_TAX_EXCLUDED = "$.lines[*].amount_tax_excluded"
    LINE_PACKAGE_QUANTITY = "$.lines[*].package_quantity"
    LINE_PIECE_COUNT = "$.lines[*].piece_count"
    LINE_CARTON_SPECIFICATION = "$.lines[*].carton_specification"
    LINE_VOLUME = "$.lines[*].volume"
    LINE_PACKAGING_REQUIREMENTS = "$.lines[*].packaging_requirements"
    LINE_ORIGIN = "$.lines[*].origin"
    LINE_REMARK = "$.lines[*].remark"

    LINE_CUSTOM_WAREHOUSE = "$.lines[*].custom_fields.warehouse"
    LINE_CUSTOM_LOCATION = "$.lines[*].custom_fields.location"
    LINE_CUSTOM_STATUS = "$.lines[*].custom_fields.status"
    LINE_CUSTOM_BATCH_NUMBER = "$.lines[*].custom_fields.batch_number"
    LINE_CUSTOM_AVAILABLE_QUANTITY = "$.lines[*].custom_fields.available_quantity"
    LINE_CUSTOM_RESERVED_QUANTITY = "$.lines[*].custom_fields.reserved_quantity"
    LINE_CUSTOM_CUSTOMER_PRODUCT_CODE = "$.lines[*].custom_fields.customer_product_code"
    LINE_CUSTOM_SUPPLIER_PRODUCT_CODE = "$.lines[*].custom_fields.supplier_product_code"
    LINE_CUSTOM_BOM_NUMBER = "$.lines[*].custom_fields.bom_number"
    LINE_CUSTOM_ASSET_NUMBER = "$.lines[*].custom_fields.asset_number"
    LINE_CUSTOM_MANUFACTURER = "$.lines[*].custom_fields.manufacturer"
    LINE_CUSTOM_COMMISSIONED_DATE = "$.lines[*].custom_fields.commissioned_date"
    LINE_CUSTOM_USAGE = "$.lines[*].custom_fields.usage"
    LINE_CUSTOM_CAVITY_COUNT = "$.lines[*].custom_fields.cavity_count"
    LINE_CUSTOM_MATERIAL = "$.lines[*].custom_fields.material"
    LINE_CUSTOM_SUPPLIER_NAME = "$.lines[*].custom_fields.supplier_name"
    LINE_CUSTOM_CUSTOMER_NAME = "$.lines[*].custom_fields.customer_name"
    LINE_CUSTOM_PURCHASE_ORDER_NUMBER = "$.lines[*].custom_fields.purchase_order_number"
    LINE_CUSTOM_RECEIPT_NUMBER = "$.lines[*].custom_fields.receipt_number"
    LINE_CUSTOM_REQUISITION_NUMBER = "$.lines[*].custom_fields.requisition_number"
    LINE_CUSTOM_SUPPLIER_DELIVERY_NUMBER = (
        "$.lines[*].custom_fields.supplier_delivery_number"
    )
    LINE_CUSTOM_SYSTEM_DOCUMENT_NUMBER = (
        "$.lines[*].custom_fields.system_document_number"
    )
    LINE_CUSTOM_CUSTOMER_ORDER_NUMBER = "$.lines[*].custom_fields.customer_order_number"
    LINE_CUSTOM_DOCUMENT_DATE = "$.lines[*].custom_fields.document_date"
    LINE_CUSTOM_DELIVERY_DATE = "$.lines[*].custom_fields.delivery_date"
    LINE_CUSTOM_SUGGESTED_DATE = "$.lines[*].custom_fields.suggested_date"
    LINE_CUSTOM_UNIT_PRICE = "$.lines[*].custom_fields.unit_price"
    LINE_CUSTOM_AMOUNT = "$.lines[*].custom_fields.amount"
    LINE_CUSTOM_RECORD_DATE = "$.lines[*].custom_fields.record_date"
    LINE_CUSTOM_RECORD_VALUE = "$.lines[*].custom_fields.record_value"

    TOTALS_DECLARED_QUANTITY = "$.totals.declared_quantity"
    TOTALS_DECLARED_AMOUNT = "$.totals.declared_amount"


class CanonicalFieldDefinition(BaseModel):
    """Logical field identity only; execution paths are intentionally absent."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    field_id: str = Field(min_length=1, max_length=128)
    title: str = Field(min_length=1, max_length=128)
    description: str = Field(default="", max_length=512)
    aliases: tuple[str, ...] = Field(default=(), max_length=64)
    document_domains: tuple[str, ...] = Field(default=(), max_length=32)
    document_types: tuple[str, ...] = Field(default=(), max_length=64)
    field_scopes: tuple[FieldScope, ...] = Field(default=(), max_length=8)
    table_roles: tuple[TableRole, ...] = Field(default=(), max_length=8)
    value_kinds: tuple[FieldValueKind, ...] = Field(default=(), max_length=16)
    repeated: bool | None = None

    @field_validator("field_id", mode="before")
    @classmethod
    def validate_field_id(cls, value: object) -> str:
        # Reject rather than sanitize.  JSONPath, array syntax and code-shaped
        # strings must never be transformed into an apparently valid field ID.
        token = str(value or "").strip().casefold()
        if CANONICAL_FIELD_ID_RE.fullmatch(token) is None:
            raise ValueError("canonical field IDs must be code-owned stable tokens")
        return token

    @field_validator("aliases", mode="before")
    @classmethod
    def normalize_aliases(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("aliases must be a sequence")
        return tuple(
            dict.fromkeys(
                alias for item in value if (alias := _normalise_label(str(item or "")))
            )
        )

    @field_validator("document_domains", "document_types", mode="before")
    @classmethod
    def normalize_tokens(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("compatibility tokens must be a sequence")
        return tuple(
            dict.fromkeys(
                _context_token(str(item or ""))
                for item in value
                if str(item or "").strip()
            )
        )


class CanonicalFieldRegistry:
    """Immutable registry supplying the only executable field vocabulary."""

    def __init__(
        self,
        fields: Sequence[CanonicalFieldDefinition],
        *,
        target_paths: Mapping[str, CanonicalTargetPath] | None = None,
    ) -> None:
        by_id: dict[str, CanonicalFieldDefinition] = {}
        for field in fields:
            if field.field_id in by_id:
                raise ValueError(f"duplicate canonical field: {field.field_id}")
            by_id[field.field_id] = field
        if not by_id:
            raise ValueError("at least one canonical field definition is required")
        bound_paths: dict[str, CanonicalTargetPath] = {}
        for raw_field_id, target in (target_paths or {}).items():
            field_id = str(raw_field_id).strip().casefold()
            if field_id not in by_id:
                raise ValueError(f"target path references unknown field: {field_id}")
            # A plain string is deliberately rejected. Executable paths must be
            # selected from this source enum, never deserialized from storage.
            if not isinstance(target, CanonicalTargetPath):
                raise TypeError("canonical target paths must be code-owned enum values")
            bound_paths[field_id] = target
        self._by_id = by_id
        self._target_paths = MappingProxyType(bound_paths)

    def get(self, field_id: str | None) -> CanonicalFieldDefinition | None:
        if not field_id:
            return None
        return self._by_id.get(str(field_id).strip().casefold())

    def target_path(self, field_id: str | None) -> str | None:
        """Resolve an internal field ID to a static path, if it is executable."""

        if not field_id:
            return None
        value = self._target_paths.get(str(field_id).strip().casefold())
        return value.value if value is not None else None

    @property
    def field_ids(self) -> frozenset[str]:
        return frozenset(self._by_id)

    @property
    def definitions(self) -> tuple[CanonicalFieldDefinition, ...]:
        return tuple(self._by_id[key] for key in sorted(self._by_id))

    @property
    def target_paths(self) -> Mapping[str, CanonicalTargetPath]:
        return self._target_paths


_IDENTIFIER_FIELDS = frozenset(
    {
        "header.order_number",
        "header.contract_number",
        "line.line_no",
        "line.model",
        "line.product_code",
        "line.custom.batch_number",
        "line.custom.customer_product_code",
        "line.custom.supplier_product_code",
        "line.custom.bom_number",
        "line.custom.asset_number",
        "line.custom.purchase_order_number",
        "line.custom.receipt_number",
        "line.custom.requisition_number",
        "line.custom.supplier_delivery_number",
        "line.custom.system_document_number",
        "line.custom.customer_order_number",
    }
)
_NUMERIC_FIELDS = frozenset(
    {
        "line.quantity",
        "line.unit_price_tax_included",
        "line.amount_tax_included",
        "line.unit_price_tax_excluded",
        "line.amount_tax_excluded",
        "line.package_quantity",
        "line.piece_count",
        "line.volume",
        "line.custom.available_quantity",
        "line.custom.reserved_quantity",
        "line.custom.cavity_count",
        "line.custom.unit_price",
        "line.custom.amount",
        "line.custom.record_value",
        "totals.declared_quantity",
        "totals.declared_amount",
    }
)
_DATE_FIELDS = frozenset(
    {
        "header.date_raw",
        "header.delivery_date_raw",
        "line.custom.commissioned_date",
        "line.custom.document_date",
        "line.custom.delivery_date",
        "line.custom.suggested_date",
        "line.custom.record_date",
    }
)
_UNIT_FIELDS = frozenset({"line.unit"})
_DOMAIN_FIELDS: dict[str, frozenset[str]] = {
    "order": frozenset(
        {
            "line.custom.status",
            "line.custom.supplier_name",
            "line.custom.customer_name",
            "line.custom.purchase_order_number",
            "line.custom.customer_order_number",
            "line.custom.delivery_date",
        }
    ),
    "inventory": frozenset(
        {
            "line.custom.warehouse",
            "line.custom.location",
            "line.custom.status",
            "line.custom.batch_number",
            "line.custom.available_quantity",
            "line.custom.reserved_quantity",
        }
    ),
    "equipment": frozenset(
        {
            "line.custom.asset_number",
            "line.custom.manufacturer",
            "line.custom.commissioned_date",
            "line.custom.usage",
            "line.custom.status",
            "line.custom.location",
        }
    ),
    "mold": frozenset(
        {
            "line.custom.cavity_count",
            "line.custom.material",
            "line.custom.status",
            "line.custom.location",
        }
    ),
    "procurement": frozenset(
        {
            "line.custom.supplier_name",
            "line.custom.customer_name",
            "line.custom.purchase_order_number",
            "line.custom.receipt_number",
            "line.custom.requisition_number",
            "line.custom.supplier_delivery_number",
            "line.custom.system_document_number",
            "line.custom.customer_order_number",
            "line.custom.document_date",
            "line.custom.delivery_date",
            "line.custom.suggested_date",
            "line.custom.unit_price",
            "line.custom.amount",
        }
    ),
}


def _default_aliases() -> dict[str, tuple[str, ...]]:
    # Imports stay local so the small registry model can be used independently
    # by migrations and repository tests without loading document adapters.
    from ..orders import HEADER_ALIASES as ORDER_LINE_ALIASES
    from ..tabular import HEADER_ALIASES as GENERIC_TABULAR_ALIASES
    from ..tabular_schema_vocabulary import _CRITICAL_LABEL_ALIASES

    collected: dict[str, list[str]] = {}

    def extend(field_id: str, values: Sequence[str]) -> None:
        collected.setdefault(field_id, []).extend(str(value) for value in values)

    for field, aliases in ORDER_LINE_ALIASES.items():
        if field != "image":
            extend(f"line.{field}", aliases)
    for label, field in GENERIC_TABULAR_ALIASES.items():
        direct_id = f"line.{field}"
        custom_id = f"line.custom.{field}"
        if direct_id in _DEFAULT_TARGETS:
            extend(direct_id, (label,))
        elif custom_id in _DEFAULT_TARGETS:
            extend(custom_id, (label,))
    critical_targets = {
        "order_number": "header.order_number",
        "contract_number": "header.contract_number",
        "order_date": "header.date_raw",
        "delivery_date": "header.delivery_date_raw",
        "buyer": "header.buyer",
        "seller": "header.seller",
        "supplier": "header.supplier",
        "currency": "header.currency",
        "line_no": "line.line_no",
    }
    for field, aliases in _CRITICAL_LABEL_ALIASES.items():
        if target := critical_targets.get(field):
            extend(target, aliases)
    return {
        field_id: tuple(dict.fromkeys(values)) for field_id, values in collected.items()
    }


_DEFAULT_TARGETS: dict[str, CanonicalTargetPath] = {
    "header.title": CanonicalTargetPath.HEADER_TITLE,
    "header.issuer": CanonicalTargetPath.HEADER_ISSUER,
    "header.order_number": CanonicalTargetPath.HEADER_ORDER_NUMBER,
    "header.contract_number": CanonicalTargetPath.HEADER_CONTRACT_NUMBER,
    "header.date_raw": CanonicalTargetPath.HEADER_DATE_RAW,
    "header.delivery_date_raw": CanonicalTargetPath.HEADER_DELIVERY_DATE_RAW,
    "header.settlement_method": CanonicalTargetPath.HEADER_SETTLEMENT_METHOD,
    "header.delivery_address": CanonicalTargetPath.HEADER_DELIVERY_ADDRESS,
    "header.buyer": CanonicalTargetPath.HEADER_BUYER,
    "header.seller": CanonicalTargetPath.HEADER_SELLER,
    "header.supplier": CanonicalTargetPath.HEADER_SUPPLIER,
    "header.currency": CanonicalTargetPath.HEADER_CURRENCY,
    "line.line_no": CanonicalTargetPath.LINE_NO,
    "line.model": CanonicalTargetPath.LINE_MODEL,
    "line.product_code": CanonicalTargetPath.LINE_PRODUCT_CODE,
    "line.name_raw": CanonicalTargetPath.LINE_NAME_RAW,
    "line.specification_raw": CanonicalTargetPath.LINE_SPECIFICATION_RAW,
    "line.body_printing": CanonicalTargetPath.LINE_BODY_PRINTING,
    "line.color": CanonicalTargetPath.LINE_COLOR,
    "line.quantity": CanonicalTargetPath.LINE_QUANTITY,
    "line.unit": CanonicalTargetPath.LINE_UNIT,
    "line.unit_price_tax_included": CanonicalTargetPath.LINE_UNIT_PRICE_TAX_INCLUDED,
    "line.amount_tax_included": CanonicalTargetPath.LINE_AMOUNT_TAX_INCLUDED,
    "line.unit_price_tax_excluded": CanonicalTargetPath.LINE_UNIT_PRICE_TAX_EXCLUDED,
    "line.amount_tax_excluded": CanonicalTargetPath.LINE_AMOUNT_TAX_EXCLUDED,
    "line.package_quantity": CanonicalTargetPath.LINE_PACKAGE_QUANTITY,
    "line.piece_count": CanonicalTargetPath.LINE_PIECE_COUNT,
    "line.carton_specification": CanonicalTargetPath.LINE_CARTON_SPECIFICATION,
    "line.volume": CanonicalTargetPath.LINE_VOLUME,
    "line.packaging_requirements": CanonicalTargetPath.LINE_PACKAGING_REQUIREMENTS,
    "line.origin": CanonicalTargetPath.LINE_ORIGIN,
    "line.remark": CanonicalTargetPath.LINE_REMARK,
    "line.custom.warehouse": CanonicalTargetPath.LINE_CUSTOM_WAREHOUSE,
    "line.custom.location": CanonicalTargetPath.LINE_CUSTOM_LOCATION,
    "line.custom.status": CanonicalTargetPath.LINE_CUSTOM_STATUS,
    "line.custom.batch_number": CanonicalTargetPath.LINE_CUSTOM_BATCH_NUMBER,
    "line.custom.available_quantity": CanonicalTargetPath.LINE_CUSTOM_AVAILABLE_QUANTITY,
    "line.custom.reserved_quantity": CanonicalTargetPath.LINE_CUSTOM_RESERVED_QUANTITY,
    "line.custom.customer_product_code": (
        CanonicalTargetPath.LINE_CUSTOM_CUSTOMER_PRODUCT_CODE
    ),
    "line.custom.supplier_product_code": (
        CanonicalTargetPath.LINE_CUSTOM_SUPPLIER_PRODUCT_CODE
    ),
    "line.custom.bom_number": CanonicalTargetPath.LINE_CUSTOM_BOM_NUMBER,
    "line.custom.asset_number": CanonicalTargetPath.LINE_CUSTOM_ASSET_NUMBER,
    "line.custom.manufacturer": CanonicalTargetPath.LINE_CUSTOM_MANUFACTURER,
    "line.custom.commissioned_date": CanonicalTargetPath.LINE_CUSTOM_COMMISSIONED_DATE,
    "line.custom.usage": CanonicalTargetPath.LINE_CUSTOM_USAGE,
    "line.custom.cavity_count": CanonicalTargetPath.LINE_CUSTOM_CAVITY_COUNT,
    "line.custom.material": CanonicalTargetPath.LINE_CUSTOM_MATERIAL,
    "line.custom.supplier_name": CanonicalTargetPath.LINE_CUSTOM_SUPPLIER_NAME,
    "line.custom.customer_name": CanonicalTargetPath.LINE_CUSTOM_CUSTOMER_NAME,
    "line.custom.purchase_order_number": (
        CanonicalTargetPath.LINE_CUSTOM_PURCHASE_ORDER_NUMBER
    ),
    "line.custom.receipt_number": CanonicalTargetPath.LINE_CUSTOM_RECEIPT_NUMBER,
    "line.custom.requisition_number": CanonicalTargetPath.LINE_CUSTOM_REQUISITION_NUMBER,
    "line.custom.supplier_delivery_number": (
        CanonicalTargetPath.LINE_CUSTOM_SUPPLIER_DELIVERY_NUMBER
    ),
    "line.custom.system_document_number": (
        CanonicalTargetPath.LINE_CUSTOM_SYSTEM_DOCUMENT_NUMBER
    ),
    "line.custom.customer_order_number": (
        CanonicalTargetPath.LINE_CUSTOM_CUSTOMER_ORDER_NUMBER
    ),
    "line.custom.document_date": CanonicalTargetPath.LINE_CUSTOM_DOCUMENT_DATE,
    "line.custom.delivery_date": CanonicalTargetPath.LINE_CUSTOM_DELIVERY_DATE,
    "line.custom.suggested_date": CanonicalTargetPath.LINE_CUSTOM_SUGGESTED_DATE,
    "line.custom.unit_price": CanonicalTargetPath.LINE_CUSTOM_UNIT_PRICE,
    "line.custom.amount": CanonicalTargetPath.LINE_CUSTOM_AMOUNT,
    "line.custom.record_date": CanonicalTargetPath.LINE_CUSTOM_RECORD_DATE,
    "line.custom.record_value": CanonicalTargetPath.LINE_CUSTOM_RECORD_VALUE,
    "totals.declared_quantity": CanonicalTargetPath.TOTALS_DECLARED_QUANTITY,
    "totals.declared_amount": CanonicalTargetPath.TOTALS_DECLARED_AMOUNT,
}


def build_document_canonical_field_registry() -> CanonicalFieldRegistry:
    """Build the shared DocumentRecord field vocabulary and static bindings."""

    aliases = _default_aliases()
    definitions: list[CanonicalFieldDefinition] = []
    for field_id in sorted(_DEFAULT_TARGETS):
        document_domains = tuple(
            domain for domain, fields in _DOMAIN_FIELDS.items() if field_id in fields
        )
        if field_id in _IDENTIFIER_FIELDS:
            value_kinds = (
                FieldValueKind.IDENTIFIER,
                FieldValueKind.TEXT,
                FieldValueKind.INTEGER,
            )
        elif field_id in _NUMERIC_FIELDS:
            value_kinds = (
                FieldValueKind.INTEGER,
                FieldValueKind.DECIMAL,
                FieldValueKind.TEXT,
                FieldValueKind.CURRENCY,
            )
        elif field_id in _DATE_FIELDS:
            value_kinds = (
                FieldValueKind.DATE,
                FieldValueKind.DATETIME,
                FieldValueKind.TEXT,
                FieldValueKind.INTEGER,
            )
        elif field_id in _UNIT_FIELDS:
            value_kinds = (FieldValueKind.UNIT, FieldValueKind.TEXT)
        else:
            value_kinds = (FieldValueKind.TEXT, FieldValueKind.IDENTIFIER)
        is_line = field_id.startswith("line.")
        definitions.append(
            CanonicalFieldDefinition(
                field_id=field_id,
                title=field_id.replace(".", " ").replace("_", " ").title(),
                description=f"Code-owned DocumentRecord target for {field_id}.",
                aliases=aliases.get(field_id, ()),
                document_domains=document_domains,
                field_scopes=(
                    (FieldScope.LINE_ITEM,) if is_line else (FieldScope.DOCUMENT,)
                ),
                table_roles=(
                    (TableRole.LINE_ITEM,)
                    if is_line
                    else (TableRole.KEY_VALUE, TableRole.HEADER)
                ),
                value_kinds=value_kinds,
                repeated=is_line,
            )
        )
    return CanonicalFieldRegistry(definitions, target_paths=_DEFAULT_TARGETS)


__all__ = [
    "CANONICAL_FIELD_ID_RE",
    "SAFE_ROUTE_ID_RE",
    "CanonicalFieldDefinition",
    "CanonicalFieldRegistry",
    "CanonicalTargetPath",
    "FieldScope",
    "FieldValueKind",
    "TableRole",
    "build_document_canonical_field_registry",
]
