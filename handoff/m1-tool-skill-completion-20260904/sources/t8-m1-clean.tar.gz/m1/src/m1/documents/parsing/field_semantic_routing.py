"""Governed semantic routing from source labels to canonical fields.

The model is deliberately a closed-set selector.  It can choose only an index
backed by an already active profile; it cannot emit a canonical field, target
path, expression, or executable mapping.  Uncertain input is preserved as a
custom field and may create only an inactive candidate for later review.
"""

from __future__ import annotations

import asyncio
import math
from collections.abc import Sequence
from typing import Literal

from pydantic import JsonValue, ValidationError

from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .field_semantic_contracts import (
    CustomFieldEntry,
    FieldSemanticCandidateProposal,
    FieldSemanticEmbeddingProvider,
    FieldSemanticExecutionObservation,  # noqa: F401 - compatibility re-export
    FieldSemanticInput,
    FieldSemanticModelChoice,
    FieldSemanticProbe,
    FieldSemanticProfile,
    FieldSemanticProfileMatch,
    FieldSemanticRankedCandidate,
    FieldSemanticResolution,
    FieldSemanticResolvedInput,
    FieldSemanticRoutingPolicy,
    FieldSemanticSelectionCandidate,
    FieldSemanticSelectionRequest,
    FieldSemanticSelector,
    FieldSemanticSignature,
    FieldSemanticStore,
    _normalise_label,
)
from .field_semantic_registry import (
    CanonicalFieldDefinition,
    CanonicalFieldRegistry,
    FieldScope,
    FieldValueKind,
    TableRole,
)


def _label_tokens(value: str) -> frozenset[str]:
    compact = value.replace(" ", "")
    words = set(value.split())
    words.update(compact[index : index + 2] for index in range(len(compact) - 1))
    return frozenset(item for item in words if item)


def _label_similarity(left: str, right: str) -> float:
    first, second = _label_tokens(left), _label_tokens(right)
    if not first or not second:
        return 0.0
    return len(first & second) / len(first | second)


def _definition_compatible(
    signature: FieldSemanticSignature,
    definition: CanonicalFieldDefinition,
) -> bool:
    if (
        definition.document_domains
        and signature.document_domain != "unknown"
        and signature.document_domain not in definition.document_domains
    ):
        return False
    if (
        definition.document_types
        and signature.document_type != "unknown"
        and signature.document_type not in definition.document_types
    ):
        return False
    if (
        definition.field_scopes
        and signature.field_scope is not FieldScope.UNKNOWN
        and signature.field_scope not in definition.field_scopes
    ):
        return False
    if (
        definition.table_roles
        and signature.table_role is not TableRole.UNKNOWN
        and signature.table_role not in definition.table_roles
    ):
        return False
    if (
        definition.value_kinds
        and signature.value_kind is not FieldValueKind.UNKNOWN
        and signature.value_kind not in definition.value_kinds
    ):
        return False
    return definition.repeated is None or definition.repeated == signature.repeated


def _profile_compatible(
    profile: FieldSemanticProfile,
    signature: FieldSemanticSignature,
    registry: CanonicalFieldRegistry,
) -> bool:
    if profile.status != "active" or profile.signature.contract_revision != (
        signature.contract_revision
    ):
        return False
    if profile.failure_count:
        return False
    definition = registry.get(profile.canonical_field_id)
    return bool(
        definition
        and _definition_compatible(signature, definition)
        and _definition_compatible(profile.signature, definition)
    )


class FieldSemanticRoutingRuntime:
    """Resolve governed field mappings without losing unknown source content."""

    def __init__(
        self,
        *,
        store: FieldSemanticStore,
        registry: CanonicalFieldRegistry,
        embedding_provider: FieldSemanticEmbeddingProvider | None = None,
        selector: FieldSemanticSelector | None = None,
        policy: FieldSemanticRoutingPolicy | None = None,
        mode: Literal["shadow", "guarded"] = "shadow",
        max_fields_per_document: int = 128,
        required: bool = False,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
        max_concurrency: int = 4,
    ) -> None:
        if mode not in {"shadow", "guarded"}:
            raise ValueError("field semantic routing mode must be shadow or guarded")
        if not 1 <= int(max_fields_per_document) <= 2_048:
            raise ValueError("field semantic field limit must be in [1, 2048]")
        if not 1 <= int(max_concurrency) <= 16:
            raise ValueError("field semantic concurrency must be in [1, 16]")
        self.store = store
        self.registry = registry
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.policy = policy or FieldSemanticRoutingPolicy()
        self.mode = mode
        self.max_fields_per_document = int(max_fields_per_document)
        self.required = bool(required)
        self._semaphore = asyncio.Semaphore(int(max_concurrency))
        self._status = DocumentRoutingStatus(
            circuit_failures=circuit_failures,
            circuit_seconds=circuit_seconds,
        )

    def status_snapshot(self) -> dict[str, object]:
        """Return bounded dependency telemetry without labels or field values."""

        return self._status.snapshot()

    async def _embed(
        self, signature: FieldSemanticSignature
    ) -> tuple[tuple[float, ...], str, int]:
        provider = self.embedding_provider
        if provider is None:
            raise RuntimeError("embedding provider unavailable")
        model = str(provider.model).strip()
        dimensions = int(provider.dimensions)
        if not model or dimensions < 1:
            raise ValueError("embedding provider has no valid identity")
        values = await provider.embed_texts((signature.embedding_text(),))
        if len(values) != 1:
            raise ValueError("embedding provider returned an unexpected vector count")
        vector = tuple(float(item) for item in values[0])
        if len(vector) != dimensions or not all(math.isfinite(item) for item in vector):
            raise ValueError("embedding provider returned an invalid vector")
        return vector, model, dimensions

    def _rank(
        self,
        signature: FieldSemanticSignature,
        match: FieldSemanticProfileMatch,
    ) -> FieldSemanticRankedCandidate:
        label_score = _label_similarity(
            signature.normalized_label,
            match.profile.signature.normalized_label,
        )
        vector_score = max(0.0, min(1.0, match.vector_similarity))
        total = self.policy.vector_weight + self.policy.label_weight
        fused = (
            vector_score * self.policy.vector_weight
            + label_score * self.policy.label_weight
        ) / total
        return FieldSemanticRankedCandidate(
            source="active_profile",
            profile_id=match.profile.profile_id,
            canonical_field_id=match.profile.canonical_field_id or "",
            vector_similarity=match.vector_similarity,
            label_similarity=label_score,
            fused_score=max(0.0, min(1.0, fused)),
        )

    def _registry_candidates(
        self, signature: FieldSemanticSignature
    ) -> tuple[FieldSemanticRankedCandidate, ...]:
        """Rank only code-owned, hard-compatible fields for a new proposal."""

        candidates: list[FieldSemanticRankedCandidate] = []
        for definition in self.registry.definitions:
            if not _definition_compatible(signature, definition):
                continue
            labels = definition.aliases or (_normalise_label(definition.title),)
            label_score = max(
                (
                    _label_similarity(signature.normalized_label, label)
                    for label in labels
                ),
                default=0.0,
            )
            candidates.append(
                FieldSemanticRankedCandidate(
                    source="registry",
                    canonical_field_id=definition.field_id,
                    vector_similarity=0.0,
                    label_similarity=label_score,
                    fused_score=label_score,
                )
            )
        return tuple(
            sorted(
                candidates,
                key=lambda item: (-item.label_similarity, item.canonical_field_id),
            )[: self.policy.max_model_candidates]
        )

    async def _create_candidate(
        self,
        *,
        tenant_id: str,
        signature: FieldSemanticSignature,
        canonical_field_id: str | None,
        embedding: tuple[float, ...] | None,
        embedding_model: str,
        embedding_dimensions: int,
        created_by: str,
    ) -> str | None:
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return None
        if (
            canonical_field_id is not None
            and self.registry.get(canonical_field_id) is None
        ):
            canonical_field_id = None
        proposal = FieldSemanticCandidateProposal(
            tenant_id=tenant_id,
            profile_key=f"field-semantic:{signature.exact_fingerprint()[:24]}",
            signature=signature,
            canonical_field_id=canonical_field_id,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            created_by=created_by,
        )
        try:
            candidate = await self.store.create_field_semantic_candidate(proposal)
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - optional persistence is advisory
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return None
        if (
            candidate.status != "candidate"
            or candidate.tenant_id != tenant_id
            or candidate.exact_fingerprint != signature.exact_fingerprint()
            or candidate.canonical_field_id != canonical_field_id
        ):
            controlled = self._status.note_dependency_failure(
                "store", ValueError("candidate store returned a mismatched profile")
            )
            if self.required:
                raise controlled from None
            return None
        return candidate.profile_id

    @staticmethod
    def _fallback(
        *,
        probe: FieldSemanticProbe,
        value: JsonValue,
        evidence_refs: Sequence[str],
        reason: str,
        action: Literal["custom_field", "review"] = "custom_field",
        candidate_profile_id: str | None = None,
        model_used: bool = False,
        top_score: float = 0.0,
    ) -> FieldSemanticResolution:
        return FieldSemanticResolution(
            action=action,
            reason=reason,
            candidate_profile_id=candidate_profile_id,
            custom_fields=(
                CustomFieldEntry(
                    label=probe.label,
                    value=value,
                    evidence_refs=tuple(str(item) for item in evidence_refs),
                    reason=reason,
                ),
            ),
            model_used=model_used,
            top_score=top_score,
        )

    async def _resolve(
        self,
        *,
        tenant_id: str,
        probe: FieldSemanticProbe,
        value: JsonValue,
        evidence_refs: Sequence[str] = (),
        created_by: str = "field-semantic-router",
    ) -> FieldSemanticResolution:
        """Map an observed field or preserve it losslessly as ``custom_fields``."""

        normalized_tenant = tenant_id.strip()
        if not normalized_tenant or normalized_tenant != tenant_id:
            raise ValueError("tenant_id must be a normalized non-empty value")
        signature = probe.signature()
        fingerprint = signature.exact_fingerprint()

        # Sensitive or instruction-shaped labels remain in the lossless
        # DocumentRecord only. They must never reach route storage, embeddings,
        # the selector prompt, or candidate creation.
        if signature.label_safety == "redacted":
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="unsafe_label",
                action="review",
            )

        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="store_circuit_open",
            )

        try:
            exact = await self.store.get_active_field_semantic_profile_by_fingerprint(
                tenant_id,
                fingerprint,
                contract_revision=signature.contract_revision,
            )
        except Exception as exc:  # noqa: BLE001 - optional routing preserves data
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="store_failure",
            )
        if exact is not None and exact.failure_count:
            self._status.note_dependency_success("store")
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="active_mapping_has_failed_observation",
                action="review",
            )
        if (
            exact is not None
            and exact.tenant_id == tenant_id
            and _profile_compatible(exact, signature, self.registry)
        ):
            self._status.note_dependency_success("store")
            return FieldSemanticResolution(
                action="mapped",
                reason="exact_active_mapping",
                canonical_field_id=exact.canonical_field_id,
                profile_id=exact.profile_id,
                top_score=1.0,
            )

        embedding: tuple[float, ...] | None = None
        embedding_model = ""
        embedding_dimensions = 0
        if self.embedding_provider is None and self.required:
            error = RuntimeError("embedding provider unavailable")
            raise self._status.note_dependency_failure("embedding", error) from None
        if self.embedding_provider is not None:
            if self._status.circuit_open("embedding"):
                if self.required:
                    raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
                self._status.note_dependency_success("store")
                return self._fallback(
                    probe=probe,
                    value=value,
                    evidence_refs=evidence_refs,
                    reason="embedding_circuit_open",
                )
            try:
                embedding, embedding_model, embedding_dimensions = await self._embed(
                    signature
                )
                self._status.note_dependency_success("embedding")
            except Exception as exc:  # noqa: BLE001 - optional exact routing remains
                controlled = self._status.note_dependency_failure("embedding", exc)
                if self.required:
                    raise controlled from None
                embedding = None
                embedding_model = ""
                embedding_dimensions = 0
                if self._status.circuit_open("embedding"):
                    if self.required:
                        raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
                    self._status.note_dependency_success("store")
                    return self._fallback(
                        probe=probe,
                        value=value,
                        evidence_refs=evidence_refs,
                        reason="embedding_circuit_open",
                    )

        ranked: tuple[FieldSemanticRankedCandidate, ...] = ()
        profiles: dict[str, FieldSemanticProfile] = {}
        if embedding is not None:
            try:
                matches = await self.store.find_active_field_semantic_profiles(
                    tenant_id,
                    embedding,
                    embedding_model=embedding_model,
                    embedding_dimensions=embedding_dimensions,
                    contract_revision=signature.contract_revision,
                    limit=min(100, self.policy.max_model_candidates * 4),
                )
            except Exception as exc:  # noqa: BLE001 - optional path preserves data
                controlled = self._status.note_dependency_failure("store", exc)
                if self.required:
                    raise controlled from None
                return self._fallback(
                    probe=probe,
                    value=value,
                    evidence_refs=evidence_refs,
                    reason=(
                        "store_circuit_open"
                        if self._status.circuit_open("store")
                        else "store_failure"
                    ),
                )
            ranked_by_id: dict[str, FieldSemanticRankedCandidate] = {}
            for match in matches:
                profile = match.profile
                if (
                    profile.tenant_id != tenant_id
                    or profile.embedding_model != embedding_model
                    or profile.embedding_dimensions != embedding_dimensions
                    or not _profile_compatible(profile, signature, self.registry)
                ):
                    continue
                item = self._rank(signature, match)
                if item.fused_score < self.policy.model_candidate_min_score:
                    continue
                ranked_by_id[profile.profile_id] = item
                profiles[profile.profile_id] = profile
            ranked = tuple(
                sorted(
                    ranked_by_id.values(),
                    key=lambda item: (
                        -item.fused_score,
                        item.profile_id or item.canonical_field_id,
                    ),
                )[: self.policy.max_model_candidates]
            )

        # With no reusable history, the same closed selector may propose one
        # compatible code-owned field.  The proposal remains inactive and the
        # current value still goes to custom_fields.
        if not ranked:
            ranked = self._registry_candidates(signature)

        top_score = ranked[0].fused_score if ranked else 0.0
        if not ranked:
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                canonical_field_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="no_compatible_mapping",
                candidate_profile_id=candidate_id,
                top_score=top_score,
            )
        if self.selector is None:
            if self.required:
                error = RuntimeError("field semantic selector unavailable")
                raise self._status.note_dependency_failure("model", error) from None
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                canonical_field_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="selector_unavailable",
                candidate_profile_id=candidate_id,
                top_score=top_score,
            )

        selector_candidates: list[FieldSemanticSelectionCandidate] = []
        for index, item in enumerate(ranked):
            definition = self.registry.get(item.canonical_field_id)
            if definition is None:
                continue
            selector_candidates.append(
                FieldSemanticSelectionCandidate(
                    candidate_index=index,
                    source=item.source,
                    canonical_field_id=definition.field_id,
                    title=definition.title,
                    description=definition.description,
                    vector_similarity=item.vector_similarity,
                    label_similarity=item.label_similarity,
                    fused_score=item.fused_score,
                )
            )
        if len(selector_candidates) != len(ranked):
            candidate_id = await self._create_candidate(
                tenant_id=tenant_id,
                signature=signature,
                canonical_field_id=None,
                embedding=embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                created_by=created_by,
            )
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="registry_mismatch",
                candidate_profile_id=candidate_id,
                top_score=top_score,
            )

        request = FieldSemanticSelectionRequest(
            signature=signature,
            candidates=tuple(selector_candidates),
        )
        if self._status.circuit_open("model"):
            if self.required:
                raise DocumentRoutingDependencyError("model", "CircuitOpen")
            self._status.note_dependency_success("store")
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="model_circuit_open",
            )
        else:
            try:
                raw_choice = await self.selector.select(request)
                choice = FieldSemanticModelChoice.model_validate(
                    raw_choice, strict=True
                )
                self._status.note_dependency_success("model")
            except (TypeError, ValueError, ValidationError) as exc:
                controlled = self._status.note_dependency_failure("model", exc)
                if self.required:
                    raise controlled from None
                choice = None
                reason = "invalid_model_output"
            except Exception as exc:  # noqa: BLE001 - optional path preserves facts
                controlled = self._status.note_dependency_failure("model", exc)
                if self.required:
                    raise controlled from None
                choice = None
                reason = "selector_failure"

        if choice is None and self._status.circuit_open("model"):
            if self.required:
                raise DocumentRoutingDependencyError("model", "CircuitOpen")
            self._status.note_dependency_success("store")
            return self._fallback(
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                reason="model_circuit_open",
            )

        proposed_field_id: str | None = None
        if choice is not None and choice.action == "reuse":
            index = choice.candidate_index
            if index is None or index >= len(ranked):
                reason = "model_candidate_invalid"
            else:
                selected = ranked[index]
                proposed_field_id = selected.canonical_field_id
                score_gap = top_score - selected.fused_score
                if (
                    selected.source == "active_profile"
                    and selected.fused_score >= self.policy.model_reuse_min_score
                    and choice.confidence >= self.policy.model_reuse_min_confidence
                    and score_gap <= self.policy.model_selected_max_score_gap
                    and selected.profile_id is not None
                    and (profile := profiles.get(selected.profile_id)) is not None
                ):
                    self._status.note_dependency_success("store")
                    return FieldSemanticResolution(
                        action="mapped",
                        reason="model_selected_active_mapping",
                        canonical_field_id=profile.canonical_field_id,
                        profile_id=profile.profile_id,
                        model_used=True,
                        top_score=top_score,
                    )
                reason = (
                    "model_proposed_canonical_field"
                    if selected.source == "registry"
                    else "model_selection_below_threshold"
                )
        elif choice is not None:
            reason = f"model_{choice.action}"

        candidate_id = await self._create_candidate(
            tenant_id=tenant_id,
            signature=signature,
            canonical_field_id=proposed_field_id,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            created_by=created_by,
        )
        return self._fallback(
            probe=probe,
            value=value,
            evidence_refs=evidence_refs,
            reason=reason,
            action=(
                "review"
                if choice is not None and choice.action == "review"
                else "custom_field"
            ),
            candidate_profile_id=candidate_id,
            model_used=True,
            top_score=top_score,
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        probe: FieldSemanticProbe,
        value: JsonValue,
        evidence_refs: Sequence[str] = (),
        created_by: str = "field-semantic-router",
    ) -> FieldSemanticResolution:
        """Track one fail-closed resolution without retaining request content."""

        return await self._status.track_operation(
            self._resolve(
                tenant_id=tenant_id,
                probe=probe,
                value=value,
                evidence_refs=evidence_refs,
                created_by=created_by,
            )
        )

    async def resolve_field(
        self,
        *,
        tenant_id: str,
        field: FieldSemanticInput,
        created_by: str = "field-semantic-router",
    ) -> FieldSemanticResolvedInput:
        """Resolve one field without modifying its source document or raw value."""

        async with self._semaphore:
            resolution = await self.resolve(
                tenant_id=tenant_id,
                probe=field.probe,
                value=field.value,
                evidence_refs=field.evidence_refs,
                created_by=created_by,
            )
        return FieldSemanticResolvedInput(
            source_ref=field.source_ref,
            resolution=resolution,
        )

    async def resolve_fields(
        self,
        *,
        tenant_id: str,
        fields: Sequence[FieldSemanticInput],
        created_by: str = "field-semantic-router",
    ) -> tuple[FieldSemanticResolvedInput, ...]:
        """Resolve a bounded batch in source order without mutating any record."""

        if len(fields) > self.max_fields_per_document:
            raise ValueError(
                "field semantic batch exceeds max_fields_per_document: "
                f"{len(fields)} > {self.max_fields_per_document}"
            )
        return tuple(
            await asyncio.gather(
                *(
                    self.resolve_field(
                        tenant_id=tenant_id,
                        field=field,
                        created_by=created_by,
                    )
                    for field in fields
                )
            )
        )
