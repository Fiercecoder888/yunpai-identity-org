"""Pure document-finalization helpers used by parser orchestration."""

from __future__ import annotations

import copy
import unicodedata
from typing import Any

from .evidence import DocumentEvidence


def metadata(document: dict[str, Any]) -> dict[str, Any]:
    extraction = document.setdefault("extraction", {})
    if not isinstance(extraction, dict):
        extraction = {}
        document["extraction"] = extraction
    value = extraction.setdefault("metadata", {})
    if not isinstance(value, dict):
        value = {}
        extraction["metadata"] = value
    return value


def evidence_sections(evidence: DocumentEvidence) -> list[dict[str, Any]]:
    sections: list[dict[str, Any]] = []
    for page in evidence.pages:
        for block in sorted(page.blocks, key=lambda item: item.order):
            sections.append(
                {
                    "kind": block.kind or "text",
                    "index": len(sections),
                    "source_ref": f"page:{page.page_number}/block:{block.block_id}",
                    "content": {
                        "text_original": block.text,
                        "text_normalized": unicodedata.normalize("NFKC", block.text),
                        "bbox": block.bbox.as_list() if block.bbox else None,
                        "coordinate_space": (
                            block.bbox.coordinate_space
                            if block.bbox
                            else page.coordinate_space
                        ),
                        "confidence": block.confidence,
                        "source": block.source,
                        "source_metadata": copy.deepcopy(block.model_extra or {}),
                    },
                }
            )
        for table in page.tables:
            sections.append(
                {
                    "kind": "table",
                    "index": len(sections),
                    "source_ref": f"page:{page.page_number}/table:{table.table_id}",
                    "content": {
                        "rows": copy.deepcopy(table.rows),
                        "bbox": table.bbox.as_list() if table.bbox else None,
                        "coordinate_space": (
                            table.bbox.coordinate_space
                            if table.bbox
                            else page.coordinate_space
                        ),
                        "confidence": table.confidence,
                        "cells": [
                            cell.model_dump(mode="json") for cell in table.cells
                        ],
                        "source": table.source,
                        "source_metadata": copy.deepcopy(table.model_extra or {}),
                    },
                }
            )
    return sections


def apply_docling_evidence(
    baseline: dict[str, Any], evidence: DocumentEvidence
) -> dict[str, Any]:
    candidate = copy.deepcopy(baseline)
    extraction = candidate.setdefault("extraction", {})
    raw = extraction.setdefault("raw_content", {})
    if raw.get("text_original") and "legacy_text_original" not in raw:
        raw["legacy_text_original"] = raw["text_original"]
    raw["text_original"] = evidence.text
    raw["text_normalized"] = unicodedata.normalize("NFKC", evidence.text)
    raw["docling_pages"] = [
        {
            "page_number": page.page_number,
            "page_index": page.page_index,
            "width": page.width,
            "height": page.height,
            "rotation": page.rotation,
            "coordinate_space": page.coordinate_space,
        }
        for page in evidence.pages
    ]
    extraction["sections"] = evidence_sections(evidence)
    value = metadata(candidate)
    value["structured_parser"] = evidence.summary()
    value["structured_evidence"] = evidence.bounded_dump()
    value["business_builder"] = "docling-evidence+existing-validation"
    return candidate


def reproject_structured_technical_document(
    candidate: dict[str, Any],
    *,
    filename: str,
) -> dict[str, Any]:
    """Project technical fields after final structured evidence is attached."""

    if str(candidate.get("document_type") or "").casefold() != "technical_document":
        return candidate

    from ..models import DocumentRecord
    from ..technical_projection import project_technical_document

    record = DocumentRecord.model_validate(candidate)
    return project_technical_document(record, filename=filename).model_dump(mode="json")
