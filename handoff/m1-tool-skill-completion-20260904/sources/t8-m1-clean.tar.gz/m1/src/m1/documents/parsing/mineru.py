"""MinerU 3.4.x HTTP client and provider-neutral evidence adapter."""

from __future__ import annotations

import asyncio
import copy
import io
import json
import mimetypes
import re
import tempfile
import time
import zipfile
from collections.abc import Iterable
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from typing import Any

import httpx

from .evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)


class MinerUError(RuntimeError):
    """A bounded MinerU request failed."""


class MinerUContractError(MinerUError):
    """MinerU returned a payload outside the pinned 3.4.x contract."""


class MinerUTaskLost(MinerUError):
    """The in-memory MinerU task disappeared before its result was fetched."""


_IDEMPOTENT_GET_RECONNECTS = 1


@dataclass(slots=True)
class MinerUParseResult:
    evidence: DocumentEvidence
    task_id: str
    member_name: str
    content_list_v2: list[list[dict[str, Any]]]
    middle_json: dict[str, Any] | list[Any] | None
    elapsed_ms: float


class _HTMLTableParser(HTMLParser):
    """Small, dependency-free HTML table reader with rowspan/colspan support."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str | None]] = []
        self._row: list[str | None] | None = None
        self._cell_parts: list[str] | None = None
        self._rowspan = 1
        self._colspan = 1
        self._pending: dict[int, tuple[int, str]] = {}

    @staticmethod
    def _span(attrs: list[tuple[str, str | None]], name: str) -> int:
        value = next((value for key, value in attrs if key == name), None)
        try:
            return max(1, min(256, int(value or 1)))
        except (TypeError, ValueError):
            return 1

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        token = tag.casefold()
        if token == "tr":
            self._row = []
            self._materialize_pending()
        elif token in {"td", "th"} and self._row is not None:
            self._materialize_pending()
            self._cell_parts = []
            self._rowspan = self._span(attrs, "rowspan")
            self._colspan = self._span(attrs, "colspan")
        elif token == "br" and self._cell_parts is not None:
            self._cell_parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self._cell_parts is not None:
            self._cell_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        token = tag.casefold()
        if token in {"td", "th"} and self._row is not None:
            text = " ".join("".join(self._cell_parts or []).split())
            start = len(self._row)
            for offset in range(self._colspan):
                self._row.append(text if offset == 0 else None)
                if self._rowspan > 1:
                    self._pending[start + offset] = (self._rowspan - 1, text)
            self._cell_parts = None
        elif token == "tr" and self._row is not None:
            self._materialize_pending()
            if any(value not in (None, "") for value in self._row):
                self.rows.append(self._row)
            self._row = None

    def _materialize_pending(self) -> None:
        if self._row is None:
            return
        column = len(self._row)
        while column in self._pending:
            remaining, value = self._pending[column]
            self._row.append(value)
            if remaining <= 1:
                self._pending.pop(column, None)
            else:
                self._pending[column] = (remaining - 1, value)
            column += 1


def _normalized_bbox(value: Any) -> EvidenceBBox | None:
    if not isinstance(value, (list, tuple)) or len(value) < 4:
        return None
    try:
        x0, y0, x1, y1 = (float(value[index]) / 1000.0 for index in range(4))
    except (TypeError, ValueError):
        return None
    if not (0.0 <= x0 <= x1 <= 1.0 and 0.0 <= y0 <= y1 <= 1.0):
        return None
    return EvidenceBBox(
        x0=x0,
        y0=y0,
        x1=x1,
        y1=y1,
        coordinate_space="normalized",
    )


def _span_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(_span_text(item) for item in value)
    if isinstance(value, dict):
        if isinstance(value.get("content"), str):
            return str(value["content"])
        if "children" in value:
            children = _span_text(value["children"])
            if children:
                return children
        parts: list[str] = []
        for key in (
            "title_content",
            "paragraph_content",
            "math_content",
            "page_header_content",
            "page_footer_content",
            "page_aside_text_content",
            "page_footnote_content",
            "page_number_content",
            "list_items",
            "image_caption",
            "chart_caption",
            "table_caption",
            "image_footnote",
            "table_footnote",
            "chart_footnote",
            "code_content",
            "code_caption",
            "code_footnote",
            "algorithm_content",
            "algorithm_caption",
            "algorithm_footnote",
        ):
            if key in value:
                text = _span_text(value[key]).strip()
                if text:
                    parts.append(text)
        return "\n".join(dict.fromkeys(parts))
    return ""


def _table_rows(content: dict[str, Any]) -> list[list[str | None]]:
    html = content.get("html")
    if not isinstance(html, str) or not html.strip():
        return []
    parser = _HTMLTableParser()
    try:
        parser.feed(html)
        parser.close()
    except Exception as exc:
        raise MinerUContractError("invalid MinerU table HTML") from exc
    width = max((len(row) for row in parser.rows), default=0)
    return [row + [None] * (width - len(row)) for row in parser.rows]


def _table_cells(
    table_id: str,
    rows: Iterable[list[str | None]],
    bbox: EvidenceBBox | None,
) -> list[EvidenceCell]:
    cells: list[EvidenceCell] = []
    for row_index, row in enumerate(rows):
        for column_index, value in enumerate(row):
            cells.append(
                EvidenceCell(
                    row=row_index,
                    column=column_index,
                    text=value,
                    # MinerU VLM exposes a table bbox, not individual cell geometry.
                    # Preserve that honest precision instead of inventing coordinates.
                    bbox=bbox,
                    source=f"{table_id}:r{row_index}:c{column_index}",
                    bbox_precision="table",
                )
            )
    return cells


def adapt_content_list_v2(
    payload: Any,
    *,
    backend: str,
    backend_version: str,
    model_revision: str,
    elapsed_ms: float,
    member_name: str = "",
    middle_json: dict[str, Any] | list[Any] | None = None,
) -> DocumentEvidence:
    """Convert MinerU's pinned page-oriented v2 output to ``DocumentEvidence``."""

    if not isinstance(payload, list) or any(not isinstance(page, list) for page in payload):
        raise MinerUContractError("content_list_v2 must be a list of page lists")
    middle_pages = (
        middle_json.get("pdf_info")
        if isinstance(middle_json, dict)
        and isinstance(middle_json.get("pdf_info"), list)
        else []
    )
    pages: list[EvidencePage] = []
    warnings: list[str] = []
    for page_index, items in enumerate(payload):
        blocks: list[EvidenceBlock] = []
        tables: list[EvidenceTable] = []
        for item_index, item in enumerate(items):
            if not isinstance(item, dict):
                raise MinerUContractError("content_list_v2 item must be an object")
            kind = str(item.get("type") or "unknown").casefold()
            content = item.get("content")
            content = content if isinstance(content, dict) else {}
            bbox = _normalized_bbox(item.get("bbox"))
            block_id = f"p{page_index + 1}:b{item_index}"
            if kind == "table":
                table_id = f"p{page_index + 1}:t{len(tables)}"
                rows = _table_rows(content)
                tables.append(
                    EvidenceTable(
                        table_id=table_id,
                        rows=rows,
                        cells=_table_cells(table_id, rows, bbox),
                        bbox=bbox,
                        source="mineru-content-list-v2",
                        html=str(content.get("html") or ""),
                        table_type=content.get("table_type"),
                        # The normalized matrix is used for replay, while the
                        # original MinerU item remains available for any
                        # format-specific detail that does not fit the common
                        # evidence model (for example a caption or table
                        # rendering hint).
                        mineru_item_index=item_index,
                    )
                )
                text = "\n".join(
                    " | ".join(str(value or "") for value in row) for row in rows
                )
            else:
                text = _span_text(content)
            text = "\n".join(line.rstrip() for line in text.splitlines()).strip()
            if text or kind in {"image", "chart", "seal", "table"}:
                blocks.append(
                    EvidenceBlock(
                        block_id=block_id,
                        kind=kind,
                        text=text,
                        bbox=bbox,
                        order=item_index,
                        source="mineru-content-list-v2",
                        sub_type=item.get("sub_type"),
                        mineru_item_index=item_index,
                    )
                )
            if item.get("bbox") is not None and bbox is None:
                warnings.append(f"invalid_bbox:{block_id}")
        middle_page = (
            middle_pages[page_index]
            if page_index < len(middle_pages)
            and isinstance(middle_pages[page_index], dict)
            else {}
        )
        page_size = middle_page.get("page_size")
        if not isinstance(page_size, (list, tuple)) or len(page_size) < 2:
            page_size = [1.0, 1.0]
        try:
            width = max(1.0, float(page_size[0]))
            height = max(1.0, float(page_size[1]))
        except (TypeError, ValueError):
            width, height = 1.0, 1.0
        try:
            rotation = int(
                middle_page.get("rotation")
                or middle_page.get("rotate_angle")
                or middle_page.get("angle")
                or 0
            )
        except (TypeError, ValueError):
            rotation = 0
        pages.append(
            EvidencePage(
                page_number=page_index + 1,
                page_index=page_index,
                width=width,
                height=height,
                coordinate_space="normalized",
                rotation=rotation,
                blocks=blocks,
                tables=tables,
                # Preserve every source item, including unknown element types
                # and visual metadata.  The business mapper may only use the
                # normalized evidence, but the document record must never make
                # source content disappear merely because a later stage cannot
                # yet classify it.
                raw={
                    "item_count": len(items),
                    "mineru_content_items": copy.deepcopy(items),
                },
            )
        )
    return DocumentEvidence(
        backend=f"mineru:{backend}",
        backend_version=backend_version,
        model_fingerprints={"mineru_vlm": model_revision},
        elapsed_ms=elapsed_ms,
        pages=pages,
        warnings=sorted(set(warnings)),
        raw={
            "contract": "content_list_v2",
            "contract_version": "mineru-3.4.x",
            "member_name": member_name,
        },
    )


class MinerUClient:
    """Bounded asynchronous client for one internal MinerU API instance."""

    def __init__(
        self,
        *,
        base_url: str,
        backend: str = "vlm-engine",
        effort: str = "high",
        language: str = "ch",
        image_analysis: bool = True,
        timeout_seconds: float = 240.0,
        poll_interval_seconds: float = 1.0,
        max_pages: int = 200,
        max_archive_bytes: int = 64 * 1024 * 1024,
        max_uncompressed_bytes: int = 128 * 1024 * 1024,
        backend_version: str = "3.4.4",
        model_revision: str = "",
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if backend != "vlm-engine":
            raise ValueError("M1 MinerU integration only permits vlm-engine")
        if effort not in {"medium", "high"}:
            raise ValueError("MinerU effort must be medium or high")
        self.base_url = base_url.rstrip("/")
        self.backend = backend
        self.effort = effort
        self.language = language
        self.image_analysis = bool(image_analysis)
        self.timeout_seconds = max(1.0, float(timeout_seconds))
        self.poll_interval_seconds = max(0.05, float(poll_interval_seconds))
        self.max_pages = max(1, int(max_pages))
        self.max_archive_bytes = max(1024, int(max_archive_bytes))
        self.max_uncompressed_bytes = max(1024, int(max_uncompressed_bytes))
        self.backend_version = backend_version
        self.model_revision = model_revision
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=httpx.Timeout(30.0, read=60.0),
            transport=transport,
        )
        self._calls = 0
        self._successes = 0
        self._failures = 0
        self._last_error_type = ""
        self._last_duration_ms: float | None = None
        self._last_task_id = ""
        self._last_failure_stage = ""
        self._transport_disconnects = 0
        self._transport_reconnects = 0
        self._transport_retry_exhaustions = 0
        self._last_transport_operation = ""
        self._last_transport_error_type = ""
        self._health: dict[str, Any] = {}

    async def close(self) -> None:
        await self._client.aclose()

    def status(self) -> dict[str, Any]:
        return {
            "base_url": self.base_url,
            "backend": self.backend,
            "backend_version": self.backend_version,
            "model_revision": self.model_revision,
            "max_pages": self.max_pages,
            "calls": self._calls,
            "successes": self._successes,
            "failures": self._failures,
            "last_error_type": self._last_error_type or None,
            "last_duration_ms": self._last_duration_ms,
            "last_task_id": self._last_task_id or None,
            "last_failure_stage": self._last_failure_stage or None,
            "transport_disconnects": self._transport_disconnects,
            "transport_reconnects": self._transport_reconnects,
            "transport_retry_exhaustions": self._transport_retry_exhaustions,
            "last_transport_operation": self._last_transport_operation or None,
            "last_transport_error_type": self._last_transport_error_type or None,
            "upstream_health": dict(self._health),
        }

    async def probe(self) -> dict[str, Any]:
        response = await self._idempotent_get(
            "/health",
            started=time.monotonic(),
            stage="health",
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise MinerUContractError("MinerU health payload must be an object")
        self._health = {
            key: payload.get(key)
            for key in (
                "status",
                "version",
                "protocol_version",
                "queued_tasks",
                "processing_tasks",
                "completed_tasks",
                "failed_tasks",
                "max_concurrent_requests",
                "processing_window_size",
                "task_retention_seconds",
                "task_cleanup_interval_seconds",
            )
            if key in payload
        }
        return dict(self._health)

    async def parse(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> MinerUParseResult:
        source = Path(path)
        if not source.is_file():
            raise FileNotFoundError(source)
        self._calls += 1
        started = time.monotonic()
        archive_path: Path | None = None
        failure_stage = "preflight"
        try:
            known_pages = self._known_page_count(source)
            if known_pages is not None and known_pages > self.max_pages:
                raise MinerUContractError(
                    "MINERU_PAGE_LIMIT_EXCEEDED: "
                    f"document has {known_pages} pages; limit is {self.max_pages}"
                )
            for submit_attempt in range(2):
                failure_stage = "submit"
                task_id = await self._submit(source, original_filename)
                self._last_task_id = task_id
                try:
                    failure_stage = "status_poll"
                    await self._wait(task_id, started)
                    failure_stage = "result_download"
                    archive_path = await self._result(task_id, started)
                    break
                except MinerUTaskLost:
                    if submit_attempt:
                        raise
            else:  # pragma: no cover - loop always breaks or raises
                raise MinerUTaskLost("MinerU task disappeared twice")
            elapsed_ms = (time.monotonic() - started) * 1000.0
            if archive_path is None:  # pragma: no cover - defensive loop guard
                raise MinerUContractError("MinerU result archive is missing")
            failure_stage = "archive_contract"
            member_name, payload, middle_json = self._read_archive(archive_path)
            if len(payload) > self.max_pages:
                raise MinerUContractError(
                    "MINERU_PAGE_LIMIT_EXCEEDED: "
                    f"result has {len(payload)} pages; limit is {self.max_pages}"
                )
            self._validate_result_contract(middle_json)
            evidence = adapt_content_list_v2(
                payload,
                backend=self.backend,
                backend_version=self.backend_version,
                model_revision=self.model_revision,
                elapsed_ms=elapsed_ms,
                member_name=member_name,
                middle_json=middle_json,
            )
            self._successes += 1
            self._last_error_type = ""
            self._last_failure_stage = ""
            self._last_duration_ms = round(elapsed_ms, 3)
            return MinerUParseResult(
                evidence=evidence,
                task_id=task_id,
                member_name=member_name,
                content_list_v2=payload,
                middle_json=middle_json,
                elapsed_ms=elapsed_ms,
            )
        except Exception as exc:
            self._failures += 1
            self._last_error_type = exc.__class__.__name__
            self._last_failure_stage = failure_stage
            raise
        finally:
            if archive_path is not None:
                archive_path.unlink(missing_ok=True)

    @staticmethod
    def _known_page_count(source: Path) -> int | None:
        suffix = source.suffix.casefold()
        if suffix == ".pdf":
            try:
                import fitz

                with fitz.open(source) as document:
                    return int(document.page_count)
            except Exception:  # noqa: BLE001 - MinerU owns damaged-file diagnosis
                return None
        if suffix in {".pptx", ".xlsx"}:
            try:
                with zipfile.ZipFile(source) as bundle:
                    pattern = (
                        r"^ppt/slides/slide\d+\.xml$"
                        if suffix == ".pptx"
                        else r"^xl/worksheets/sheet\d+\.xml$"
                    )
                    return sum(
                        bool(re.fullmatch(pattern, name))
                        for name in bundle.namelist()
                    )
            except zipfile.BadZipFile:
                return None
        if suffix in {
            ".png",
            ".jpeg",
            ".jpg",
            ".jp2",
            ".webp",
            ".gif",
            ".bmp",
            ".tiff",
            ".tif",
        }:
            return 1
        return None

    def _validate_result_contract(self, middle_json: Any) -> None:
        if not isinstance(middle_json, dict):
            raise MinerUContractError(
                "MinerU result is missing the required middle JSON contract"
            )
        version = str(middle_json.get("_version_name") or "")
        backend = str(middle_json.get("_backend") or "")
        if version != self.backend_version:
            raise MinerUContractError(
                f"unsupported MinerU result version: {version or 'missing'}"
            )
        if backend != "vlm":
            raise MinerUContractError(
                f"unsupported MinerU result backend: {backend or 'missing'}"
            )

    async def _submit(self, source: Path, original_filename: str | None) -> str:
        filename = original_filename or source.name
        mime_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        data = {
            "backend": self.backend,
            "effort": self.effort,
            "lang_list": self.language,
            "parse_method": "auto",
            "formula_enable": "true",
            "table_enable": "true",
            "image_analysis": str(self.image_analysis).lower(),
            "return_md": "true",
            "return_middle_json": "true",
            "return_model_output": "false",
            "return_content_list": "true",
            # The candidate consumes structured blocks and coordinates only.
            # Returning extracted image binaries inflates the ZIP and can hit
            # the bounded archive limit without improving LLM mapping.
            "return_images": "false",
            "response_format_zip": "true",
            "return_original_file": "false",
            "client_side_output_generation": "false",
        }
        with source.open("rb") as stream:
            response = await self._client.post(
                "/tasks",
                data=data,
                files={"files": (filename, stream, mime_type)},
            )
        if response.status_code != 202:
            raise MinerUError(f"MinerU submit failed with HTTP {response.status_code}")
        payload = response.json()
        task_id = payload.get("task_id") if isinstance(payload, dict) else None
        if not isinstance(task_id, str) or not task_id:
            raise MinerUContractError("MinerU submit response is missing task_id")
        return task_id

    async def _idempotent_get(
        self,
        path: str,
        *,
        started: float,
        stage: str,
    ) -> httpx.Response:
        """Reconnect bounded idempotent reads without resubmitting a task."""

        for reconnect in range(_IDEMPOTENT_GET_RECONNECTS + 1):
            try:
                return await self._client.get(path)
            except httpx.RemoteProtocolError as exc:
                self._transport_disconnects += 1
                self._last_transport_operation = stage.replace(" ", "_")
                self._last_transport_error_type = exc.__class__.__name__
                if reconnect >= _IDEMPOTENT_GET_RECONNECTS:
                    self._transport_retry_exhaustions += 1
                    raise
                remaining = self.timeout_seconds - (time.monotonic() - started)
                if remaining <= 0:
                    raise TimeoutError(f"MinerU {stage} timed out") from exc
                self._transport_reconnects += 1
                await asyncio.sleep(min(0.1 * (2**reconnect), remaining))
        raise AssertionError("bounded MinerU reconnect loop exhausted")

    async def _wait(self, task_id: str, started: float) -> None:
        while True:
            remaining = self.timeout_seconds - (time.monotonic() - started)
            if remaining <= 0:
                raise TimeoutError("MinerU task timed out")
            response = await self._idempotent_get(
                f"/tasks/{task_id}",
                started=started,
                stage="status poll",
            )
            if response.status_code == 404:
                raise MinerUTaskLost("MinerU task state was lost")
            response.raise_for_status()
            payload = response.json()
            status = str(payload.get("status") or "") if isinstance(payload, dict) else ""
            if status == "completed":
                return
            if status == "failed":
                raise MinerUError("MinerU task failed")
            if status not in {"pending", "processing"}:
                raise MinerUContractError(f"unsupported MinerU task status: {status}")
            await asyncio.sleep(min(self.poll_interval_seconds, remaining))

    async def _result(self, task_id: str, started: float) -> Path:
        reconnect = 0
        while True:
            remaining = self.timeout_seconds - (time.monotonic() - started)
            if remaining <= 0:
                raise TimeoutError("MinerU result timed out")
            try:
                archive = await self._result_once(task_id)
            except httpx.RemoteProtocolError as exc:
                self._transport_disconnects += 1
                self._last_transport_operation = "result_download"
                self._last_transport_error_type = exc.__class__.__name__
                if reconnect >= _IDEMPOTENT_GET_RECONNECTS:
                    self._transport_retry_exhaustions += 1
                    raise
                remaining = self.timeout_seconds - (time.monotonic() - started)
                if remaining <= 0:
                    raise TimeoutError("MinerU result timed out") from exc
                self._transport_reconnects += 1
                await asyncio.sleep(min(0.1 * (2**reconnect), remaining))
                reconnect += 1
                continue
            if archive is not None:
                return archive
            # Status and result are separate endpoints. Treat a transient
            # not-ready response as a race, then poll the same task outside the
            # result-download retry scope. A status disconnect therefore cannot
            # consume a second, mislabeled result retry.
            await asyncio.sleep(min(self.poll_interval_seconds, remaining))
            await self._wait(task_id, started)

    async def _result_once(self, task_id: str) -> Path | None:
        """Download one result response; return ``None`` for HTTP 202."""

        # Do not use ``response.content`` here.  The result is generated from
        # user supplied documents and a malicious/buggy sidecar can return a
        # body larger than the configured archive budget.  The normal httpx
        # request API buffers that whole body before this method can inspect it.
        async with self._client.stream("GET", f"/tasks/{task_id}/result") as response:
            if response.status_code == 404:
                raise MinerUTaskLost("MinerU result was lost")
            if response.status_code == 202:
                return None
            if response.status_code == 409:
                raise MinerUError("MinerU task result reports failed status")
            if response.status_code != 200:
                raise MinerUError(
                    f"MinerU result failed with HTTP {response.status_code}"
                )
            content_length = response.headers.get("content-length")
            try:
                declared_length = int(content_length) if content_length else None
            except ValueError:
                declared_length = None
            if (
                declared_length is not None
                and declared_length > self.max_archive_bytes
            ):
                raise MinerUContractError("MinerU ZIP exceeds configured size limit")

            temporary_path: Path | None = None
            try:
                with tempfile.NamedTemporaryFile(
                    prefix="m1-mineru-result-",
                    suffix=".zip",
                    mode="wb",
                    delete=False,
                ) as stream:
                    temporary_path = Path(stream.name)
                    total = 0
                    prefix = bytearray()
                    async for chunk in response.aiter_bytes():
                        if not chunk:
                            continue
                        total += len(chunk)
                        if total > self.max_archive_bytes:
                            raise MinerUContractError(
                                "MinerU ZIP exceeds configured size limit"
                            )
                        if len(prefix) < 2:
                            prefix.extend(chunk[: 2 - len(prefix)])
                        stream.write(chunk)
                    stream.flush()
                if bytes(prefix) != b"PK":
                    raise MinerUContractError("MinerU result is not a ZIP archive")
                return temporary_path
            except Exception:
                if temporary_path is not None:
                    temporary_path.unlink(missing_ok=True)
                raise

    def _read_archive(
        self, archive: bytes | Path
    ) -> tuple[str, list[list[dict[str, Any]]], dict[str, Any] | list[Any] | None]:
        try:
            bundle = zipfile.ZipFile(
                archive if isinstance(archive, Path) else io.BytesIO(archive)
            )
        except zipfile.BadZipFile as exc:
            raise MinerUContractError("invalid MinerU ZIP") from exc
        with bundle:
            infos = bundle.infolist()
            if len(infos) > 4096:
                raise MinerUContractError("MinerU ZIP contains too many members")
            if sum(info.file_size for info in infos) > self.max_uncompressed_bytes:
                raise MinerUContractError(
                    "MinerU ZIP expands beyond configured size limit"
                )
            for info in infos:
                if "\x00" in info.filename:
                    raise MinerUContractError("unsafe MinerU ZIP member")
                path = PurePosixPath(info.filename.replace("\\", "/"))
                if path.is_absolute() or ".." in path.parts:
                    raise MinerUContractError("unsafe MinerU ZIP member")
            candidates = [
                info
                for info in infos
                if info.filename.endswith("_content_list_v2.json")
            ]
            if len(candidates) != 1:
                raise MinerUContractError("MinerU ZIP must contain one content_list_v2")
            member = candidates[0]
            try:
                payload = json.loads(bundle.read(member).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise MinerUContractError(
                    "invalid MinerU content_list_v2 JSON"
                ) from exc
            if not isinstance(payload, list):
                raise MinerUContractError("MinerU content_list_v2 root must be a list")
            middle_json: dict[str, Any] | list[Any] | None = None
            middle_candidates = [
                info for info in infos if info.filename.endswith("_middle.json")
            ]
            if len(middle_candidates) == 1:
                try:
                    middle_json = json.loads(
                        bundle.read(middle_candidates[0]).decode("utf-8")
                    )
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise MinerUContractError("invalid MinerU middle JSON") from exc
            return member.filename, payload, middle_json


__all__ = [
    "MinerUClient",
    "MinerUContractError",
    "MinerUError",
    "MinerUParseResult",
    "MinerUTaskLost",
    "adapt_content_list_v2",
]
