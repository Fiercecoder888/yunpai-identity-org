"""Hard gates for promoting an independent MinerU candidate."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

from ..models import DocumentRecord
from .mineru_domain import (
    CANONICAL_SUBTYPE_TYPES,
    classify_line_business_payload,
    domain_minimum_failures,
    evidence_fact_paths,
)
from .mineru_regions import (
    RecordRegionAssessment,
    assess_record_regions_from_raw_pages,
    record_region_binding_report,
    record_region_raw_pages_fingerprint,
)

_HEADER_EVIDENCE_FIELDS = (
    "title",
    "issuer",
    "order_number",
    "contract_number",
    "date_raw",
    "delivery_date_raw",
    "settlement_method",
    "delivery_address",
    "buyer",
    "seller",
    "supplier",
    "currency",
)
_LINE_IDENTITY_FIELDS = ("model", "product_code", "name_raw", "specification_raw")
_LINE_EVIDENCE_FIELDS = (
    "line_no",
    *_LINE_IDENTITY_FIELDS,
    "quantity",
    "unit",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "carton_specification",
    "volume",
    "packaging_requirements",
    "body_printing",
    "color",
    "origin",
    "remark",
)
_BLOCKING_LINE_ISSUES = {
    "LINE_CORE_FIELD_MISSING",
    "MINERU_LOCAL_FIELD_TYPE_REJECTED",
    "MINERU_MAPPER_EVIDENCE_REJECTED",
    "MINERU_MAPPED_VALUE_INVALID",
}
_FULL_AUTHORITY_REVIEWABLE_REASONS = frozenset(
    {
        # These conditions mean the candidate contains useful MinerU evidence,
        # but its coverage is not strong enough for unattended projection. Keep
        # it available to a reviewer instead of discarding all parsed content.
        "instructor_incomplete",
        "inconclusive_record_region_assessment",
        "missing_record_region_assessment",
        "missing_record_region_bindings",
        "unmapped_record_regions",
        "missing_source_refs",
        "unknown_classification",
        "incomplete_classification",
        "dropped_mappings",
        "dropped_tables",
        "local_fact_rejections",
        "invalid_domain_records",
        "invalid_business_lines",
        "missing_order_identifier",
        "missing_order_records",
        "missing_inventory_records",
        "missing_equipment_records",
        "missing_mold_records",
        "missing_procurement_records",
        "physical_type_conflict",
    }
)
_LOCAL_REJECTED_FACT_CODES = frozenset(
    {
        "MINERU_INSTRUCTOR_UNSUPPORTED_FACT_VALUE",
        "MINERU_INSTRUCTOR_IGNORED_MODEL_FACT",
        "MINERU_ORDER_NUMBER_CONFLICT",
    }
)
_LOCAL_REJECTED_CITATION_CODES = frozenset(
    {
        "MINERU_INSTRUCTOR_UNKNOWN_EVIDENCE_ID",
        "MINERU_INSTRUCTOR_OUT_OF_SEGMENT_EVIDENCE_ID",
        "MINERU_INSTRUCTOR_ADVISORY_EVIDENCE_FORBIDDEN",
        "MINERU_INSTRUCTOR_UNSUPPORTED_EVIDENCE_REF",
    }
)
_ORDER_SUBTYPES = {
    "supplier_purchase_order",
    "customer_purchase_order",
    "purchase_contract",
    "stocking_order",
    "sample_request",
}
_DOCX_CELL_PART = re.compile(
    r"^mineru/(?P<table_id>docx:t:\d+)(?::|/)r(?P<row>\d+)(?::|/)c(?P<column>\d+)$"
)
_DOCX_BLOCK_PART = re.compile(r"^mineru/(?P<block_id>docx:p:\d+)$")
_LINE_PATH = re.compile(r"^\$\.lines\[(?P<index>\d+)\](?P<suffix>.*)$")
_GENERIC_FACT_VALUE_PATH = re.compile(
    r"^\$\.generic_facts\[(?P<index>\d+)\]\.value$"
)


def _present(value: Any) -> bool:
    return value not in (None, "", [], {})


def _normalized(value: Any) -> str:
    return "".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def _unresolved_mapper_drop_count(summary: dict[str, Any], kind: str) -> int:
    """Prefer final replan counters while accepting historical summaries."""

    for key in (f"mapper_unresolved_dropped_{kind}", f"mapper_dropped_{kind}"):
        if key not in summary:
            continue
        try:
            return int(summary.get(key) or 0)
        except (TypeError, ValueError):
            return 0
    return 0


def _summary_count(summary: dict[str, Any], key: str) -> int:
    try:
        return max(0, int(summary.get(key) or 0))
    except (TypeError, ValueError):
        return 0


def _record_region_authority_failures(
    candidate: DocumentRecord,
    summary: dict[str, Any],
) -> list[str]:
    """Validate the persisted full-evidence gate without trusting mapper counters."""

    payload = summary.get("record_region_assessment")
    if not isinstance(payload, dict):
        return ["missing_record_region_assessment"]
    assessment_fields = {
        "status",
        "evidence_fingerprint",
        "assessed_table_ids",
        "no_record_table_ids",
        "record_regions",
        "inconclusive_table_ids",
        "reasons",
    }
    try:
        assessment = RecordRegionAssessment.model_validate(
            {key: payload.get(key) for key in assessment_fields if key in payload}
        )
    except Exception:  # noqa: BLE001 - malformed assessment must fail closed
        return ["invalid_record_region_assessment"]
    reasons: list[str] = []
    raw_content = candidate.extraction.get("raw_content")
    raw_pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    candidate_fingerprint = record_region_raw_pages_fingerprint(raw_pages)
    if not assessment.evidence_fingerprint:
        reasons.append("missing_record_region_evidence_fingerprint")
    elif candidate_fingerprint is None:
        reasons.append("missing_candidate_record_region_evidence")
    elif assessment.evidence_fingerprint != candidate_fingerprint:
        reasons.append("record_region_evidence_fingerprint_mismatch")
    recomputed = assess_record_regions_from_raw_pages(raw_pages)
    if recomputed is None:
        reasons.append("record_region_assessment_recompute_failed")
    elif assessment.model_dump(mode="json") != recomputed.model_dump(mode="json"):
        reasons.append("record_region_assessment_mismatch")
    if assessment.status != "complete":
        reasons.append("inconclusive_record_region_assessment")
    bindings = payload.get("mapped_region_bindings")
    if not isinstance(bindings, list):
        return [*reasons, "missing_record_region_bindings"]
    normalized_bindings = [item for item in bindings if isinstance(item, dict)]
    if len(normalized_bindings) != len(bindings):
        return [*reasons, "invalid_record_region_bindings"]
    report = record_region_binding_report(assessment, normalized_bindings)
    reported_ids = payload.get("mapped_region_ids")
    if isinstance(reported_ids, list):
        normalized_reported = [str(value) for value in reported_ids]
        if (
            len(normalized_reported) != len(set(normalized_reported))
            or set(normalized_reported) != set(report.mapped_region_ids)
        ):
            reasons.append("record_region_binding_contract_mismatch")
    if report.unmapped_region_ids:
        reasons.append("unmapped_record_regions")
    if report.fabricated_region_ids or report.missing_region_id_count:
        reasons.append("fabricated_record_region")
    if report.cross_region_ids:
        reasons.append("cross_region_mapping")
    if report.overlapping_region_ids:
        reasons.append("overlapping_region_mappings")
    return reasons


def _docx_native_locator_text(
    candidate: DocumentRecord,
    reference: Any,
) -> str | None:
    """Replay one bounded OOXML locator from the persisted evidence pages."""

    extras = reference.model_extra or {}
    if extras.get("authority") == "advisory" or extras.get("asset_sha256"):
        return None
    part = str(reference.part or "").strip()
    cell_match = _DOCX_CELL_PART.fullmatch(part)
    block_match = _DOCX_BLOCK_PART.fullmatch(part)
    native_part = part if part.startswith("word/document.xml#") else ""
    if cell_match is None and block_match is None and not native_part:
        return None
    extraction = candidate.extraction.get("raw_content")
    raw_pages = extraction.get("pages") if isinstance(extraction, dict) else None
    if not isinstance(raw_pages, list) or not reference.page:
        return None
    page_number = int(reference.page)
    for page_index, page in enumerate(raw_pages):
        if not isinstance(page, dict):
            continue
        raw_page_number = int(page.get("page_number") or page_index + 1)
        if raw_page_number != page_number:
            continue
        if native_part:
            for block in page.get("blocks") or []:
                if (
                    isinstance(block, dict)
                    and block.get("source") == "docx-native-ooxml"
                    and block.get("source_id") == native_part
                ):
                    return str(block.get("text") or "")
            for table in page.get("tables") or []:
                if not isinstance(table, dict):
                    continue
                if table.get("source") != "docx-native-ooxml":
                    continue
                for cell in table.get("cells") or []:
                    if isinstance(cell, dict) and cell.get("source_id") == native_part:
                        return str(cell.get("text") or "")
            return None
        if cell_match is not None:
            tables = page.get("tables")
            if not isinstance(tables, list):
                return None
            for table in tables:
                if not isinstance(table, dict):
                    continue
                if table.get("table_id") != cell_match.group("table_id"):
                    continue
                if table.get("source") != "docx-native-ooxml":
                    return None
                rows = table.get("rows")
                row = int(cell_match.group("row"))
                column = int(cell_match.group("column"))
                if (
                    not isinstance(rows, list)
                    or row >= len(rows)
                    or not isinstance(rows[row], list)
                    or column >= len(rows[row])
                ):
                    return None
                value = rows[row][column]
                return str(value) if value is not None else None
            return None
        blocks = page.get("blocks")
        if not isinstance(blocks, list):
            return None
        for block in blocks:
            if not isinstance(block, dict):
                continue
            if block.get("block_id") != block_match.group("block_id"):
                continue
            if block.get("source") != "docx-native-ooxml":
                return None
            return str(block.get("text") or "")
        return None
    return None


def _docx_native_reference_text(
    candidate: DocumentRecord,
    reference: Any,
) -> str | None:
    """Replay a native locator only when its persisted attestation is intact."""

    extras = reference.model_extra or {}
    part = str(reference.part or "").strip()
    cell_match = _DOCX_CELL_PART.fullmatch(part)
    block_match = _DOCX_BLOCK_PART.fullmatch(part)
    native_part = part if part.startswith("word/document.xml#") else ""
    if cell_match is None and block_match is None and not native_part:
        return None
    evidence_id = str(extras.get("evidence_id") or "").strip()
    evidence_quote = str(extras.get("evidence_quote") or "").strip()
    expected_id = None
    if cell_match is not None:
        expected_id = (
            f"{cell_match.group('table_id')}:r{cell_match.group('row')}:"
            f"c{cell_match.group('column')}"
        )
    elif block_match is not None:
        expected_id = str(block_match.group("block_id"))
    if not evidence_id or not evidence_quote or (
        expected_id is not None and evidence_id != expected_id
    ):
        return None
    return _docx_native_locator_text(candidate, reference)


def _generic_fact_native_refs_are_positioned(
    candidate: DocumentRecord,
    path: str,
    references: list[Any],
) -> bool:
    match = _GENERIC_FACT_VALUE_PATH.fullmatch(path)
    if match is None or not references:
        return False
    index = int(match.group("index"))
    if not 0 <= index < len(candidate.generic_facts):
        return False
    fact = candidate.generic_facts[index]
    extras = fact.model_extra or {}
    deterministic_projection = bool(extras.get("projection_role"))
    exact_content = (
        extras.get("binding_source") is not None
        and extras.get("authority") == "source"
        and isinstance(fact.value, str)
    )
    if not deterministic_projection and not exact_content:
        return False

    located_texts: list[str] = []
    for reference in references:
        text = _docx_native_locator_text(candidate, reference)
        if text is None or not _normalized(text):
            return False
        located_texts.append(text)
    if exact_content:
        return all(_normalized(text) == _normalized(fact.value) for text in located_texts)
    serialized_value = json.dumps(
        fact.value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    normalized_value = _normalized(serialized_value)
    return all(_normalized(text) in normalized_value for text in located_texts)


def _has_positioned_source_refs(candidate: DocumentRecord, path: str) -> bool:
    metadata = candidate.field_meta.get(path)
    if metadata is None:
        return False
    metadata_extras = metadata.model_extra or {}
    if metadata_extras.get("inference_source"):
        # Context inherited from another row is useful for review, but it is
        # not positioned evidence for the current field. Genuine merged-cell
        # provenance is carried by inherited_from_merge without this marker.
        return False
    for reference in metadata.source_refs:
        extras = reference.model_extra or {}
        sheet = str(reference.sheet or "").strip()
        cell = str(reference.cell or "").strip()
        cell_range = str(reference.range or "").strip()
        if sheet and (cell or cell_range):
            return True
        native_text = _docx_native_reference_text(candidate, reference)
        evidence_quote = str(extras.get("evidence_quote") or "")
        if native_text is not None and _normalized(evidence_quote) in _normalized(
            native_text
        ):
            return True
        bbox = extras.get("bbox")
        coordinate_space = str(extras.get("coordinate_space") or "").strip()
        if not reference.page or int(reference.page) <= 0:
            continue
        if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
            continue
        try:
            x0, y0, x1, y1 = (float(value) for value in bbox)
        except (TypeError, ValueError):
            continue
        if (
            coordinate_space
            and all(math.isfinite(value) for value in (x0, y0, x1, y1))
            and x1 > x0
            and y1 > y0
        ):
            return True
    return _generic_fact_native_refs_are_positioned(
        candidate,
        path,
        list(metadata.source_refs),
    )


@dataclass(frozen=True, slots=True)
class MinerUAuthorityDecision:
    accepted: bool
    reasons: tuple[str, ...]
    missing_source_paths: tuple[str, ...] = ()
    invalid_line_paths: tuple[str, ...] = ()
    lost_baseline_paths: tuple[str, ...] = ()
    mismatched_baseline_paths: tuple[str, ...] = ()
    locally_rejected_fact_proposals: int = 0
    locally_rejected_citations: int = 0

    def summary(self) -> dict[str, Any]:
        return {
            "passed": self.accepted,
            "reasons": list(self.reasons),
            "missing_source_paths": list(self.missing_source_paths),
            "invalid_line_paths": list(self.invalid_line_paths),
            "lost_baseline_paths": list(self.lost_baseline_paths),
            "mismatched_baseline_paths": list(self.mismatched_baseline_paths),
            "locally_rejected_fact_proposals": (
                self.locally_rejected_fact_proposals
            ),
            "locally_rejected_citations": self.locally_rejected_citations,
        }


def _evaluate_guarded_mineru_authority(
    candidate: DocumentRecord,
    summary: dict[str, Any],
    *,
    baseline: dict[str, Any],
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> MinerUAuthorityDecision:
    """Compatibility gate for the legacy guarded transition mode."""

    reasons: list[str] = []
    missing_source_paths: set[str] = set()
    invalid_line_paths: set[str] = set()
    lost_baseline_paths: set[str] = set()
    mismatched_baseline_paths: set[str] = set()

    if str(summary.get("status") or "") != "completed":
        reasons.append("candidate_not_completed")
    if int(summary.get("rejected_citations") or 0) != 0:
        reasons.append("rejected_citations")
    if _unresolved_mapper_drop_count(summary, "mappings") != 0:
        reasons.append("dropped_mappings")
    if _unresolved_mapper_drop_count(summary, "tables") != 0:
        reasons.append("dropped_tables")
    if int(summary.get("mapper_invalid_facts") or 0) != 0:
        reasons.append("invalid_fact_proposals")
    if any(
        issue.code == "MINERU_CLASSIFICATION_PHYSICAL_TYPE_CONFLICT"
        for issue in candidate.validation_issues
    ):
        reasons.append("physical_type_conflict")
    coverage = summary.get("source_reference_coverage")
    try:
        coverage_ratio = float(coverage.get("ratio")) if isinstance(coverage, dict) else 0.0
    except (TypeError, ValueError):
        coverage_ratio = 0.0
    if coverage_ratio != 1.0:
        reasons.append("incomplete_source_reference_coverage")

    if document_type_hint and candidate.document_type != document_type_hint:
        reasons.append("document_type_hint_mismatch")
    if (
        document_subtype_hint
        and candidate.document_subtype != document_subtype_hint
    ):
        reasons.append("document_subtype_hint_mismatch")
    if candidate.document_type in {"", "unknown"} or candidate.document_subtype in {
        "",
        "unknown",
    }:
        reasons.append("unknown_classification")

    baseline_type = str(baseline.get("document_type") or "unknown")
    baseline_subtype = str(baseline.get("document_subtype") or "unknown")
    explicit_order_hint = str(document_type_hint or "").casefold() == "order" or str(
        document_subtype_hint or ""
    ).casefold() in _ORDER_SUBTYPES
    if (
        baseline_type not in {"", "unknown", "order"}
        or candidate.document_type != "order"
        or (baseline_type in {"", "unknown"} and not explicit_order_hint)
    ):
        reasons.append("unsupported_authority_domain")
    if baseline_type not in {"", "unknown"} and candidate.document_type != baseline_type:
        mismatched_baseline_paths.add("$.document_type")
    if (
        not document_subtype_hint
        and
        baseline_subtype not in {"", "unknown"}
        and candidate.document_subtype != baseline_subtype
    ):
        mismatched_baseline_paths.add("$.document_subtype")

    baseline_header = (
        baseline.get("header") if isinstance(baseline.get("header"), dict) else {}
    )
    for field in _HEADER_EVIDENCE_FIELDS:
        baseline_value = baseline_header.get(field)
        candidate_value = getattr(candidate.header, field)
        if not _present(baseline_value):
            continue
        path = f"$.header.{field}"
        if not _present(candidate_value):
            lost_baseline_paths.add(path)
        if _normalized(candidate_value) != _normalized(baseline_value):
            mismatched_baseline_paths.add(path)

    for field in _HEADER_EVIDENCE_FIELDS:
        if _present(getattr(candidate.header, field)):
            path = f"$.header.{field}"
            if not _has_positioned_source_refs(candidate, path):
                missing_source_paths.add(path)

    if candidate.document_type == "order":
        if not _present(candidate.header.order_number) and not _present(
            candidate.header.contract_number
        ):
            reasons.append("missing_order_identifier")
        if not candidate.lines:
            reasons.append("missing_order_lines")

    for index, line in enumerate(candidate.lines):
        if not any(_present(getattr(line, field)) for field in _LINE_IDENTITY_FIELDS):
            invalid_line_paths.add(f"$.lines[{index}]")
        for field in _LINE_EVIDENCE_FIELDS:
            if not _present(getattr(line, field)):
                continue
            path = f"$.lines[{index}].{field}"
            if not _has_positioned_source_refs(candidate, path):
                missing_source_paths.add(path)

    baseline_totals = (
        baseline.get("totals") if isinstance(baseline.get("totals"), dict) else {}
    )
    for field in ("declared_quantity", "declared_amount"):
        candidate_value = getattr(candidate.totals, field)
        path = f"$.totals.{field}"
        if _present(candidate_value) and not _has_positioned_source_refs(candidate, path):
            missing_source_paths.add(path)
        baseline_value = baseline_totals.get(field)
        if _present(baseline_value) and _normalized(candidate_value) != _normalized(
            baseline_value
        ):
            mismatched_baseline_paths.add(path)

    for issue in candidate.validation_issues:
        if issue.code not in _BLOCKING_LINE_ISSUES:
            continue
        invalid_line_paths.update(
            path for path in issue.paths if str(path).startswith("$.lines[")
        )

    baseline_lines = baseline.get("lines") if isinstance(baseline.get("lines"), list) else []
    baseline_business_lines = [
        (index, line)
        for index, line in enumerate(baseline_lines)
        if isinstance(line, dict)
        and any(_present(line.get(field)) for field in _LINE_EVIDENCE_FIELDS)
    ]
    candidate_business_lines = [
        (index, line)
        for index, line in enumerate(candidate.lines)
        if any(_present(getattr(line, field)) for field in _LINE_EVIDENCE_FIELDS)
    ]
    if baseline_business_lines and len(candidate_business_lines) != len(
        baseline_business_lines
    ):
        reasons.append("business_line_count_mismatch")
    if len(candidate_business_lines) == len(baseline_business_lines):
        for (_baseline_index, baseline_line), (candidate_index, candidate_line) in zip(
            baseline_business_lines, candidate_business_lines, strict=True
        ):
            for field in _LINE_EVIDENCE_FIELDS:
                baseline_value = baseline_line.get(field)
                if not _present(baseline_value):
                    continue
                if _normalized(getattr(candidate_line, field)) != _normalized(
                    baseline_value
                ):
                    mismatched_baseline_paths.add(
                        f"$.lines[{candidate_index}].{field}"
                    )

    if lost_baseline_paths:
        reasons.append("baseline_header_loss")
    if mismatched_baseline_paths:
        reasons.append("baseline_fact_mismatch")

    if missing_source_paths:
        reasons.append("missing_source_refs")
    if invalid_line_paths:
        reasons.append("invalid_business_lines")

    deduplicated_reasons = tuple(dict.fromkeys(reasons))
    return MinerUAuthorityDecision(
        accepted=not deduplicated_reasons,
        reasons=deduplicated_reasons,
        missing_source_paths=tuple(sorted(missing_source_paths)),
        invalid_line_paths=tuple(sorted(invalid_line_paths)),
        lost_baseline_paths=tuple(sorted(lost_baseline_paths)),
        mismatched_baseline_paths=tuple(sorted(mismatched_baseline_paths)),
    )


def _evaluate_full_mineru_authority(
    candidate: DocumentRecord,
    summary: dict[str, Any],
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> MinerUAuthorityDecision:
    """Validate a MinerU-only authority result without consulting legacy facts."""

    reasons: list[str] = []
    missing_source_paths: set[str] = set()
    invalid_line_paths: set[str] = set()
    locally_rejected_fact_proposals = _summary_count(
        summary, "mapper_rejected_fact_proposals"
    )
    locally_rejected_citations = _summary_count(
        summary, "mapper_rejected_citations"
    )

    if str(summary.get("status") or "") != "completed":
        reasons.append("candidate_not_completed")
    if str(summary.get("pipeline") or "") != "mineru_instructor":
        reasons.append("unexpected_candidate_pipeline")
    metadata = candidate.extraction.get("metadata")
    adapter = metadata.get("adapter") if isinstance(metadata, dict) else None
    if adapter != "mineru_instructor":
        reasons.append("unexpected_candidate_adapter")
    evidence_complete = (
        metadata.get("evidence_complete") if isinstance(metadata, dict) else None
    )
    if (
        summary.get("instructor_complete") is not True
        or evidence_complete is not True
    ):
        reasons.append("instructor_incomplete")
    if int(summary.get("rejected_citations") or 0) != 0:
        reasons.append("rejected_citations")
    if _unresolved_mapper_drop_count(summary, "mappings") != 0:
        reasons.append("dropped_mappings")
    if _unresolved_mapper_drop_count(summary, "tables") != 0:
        reasons.append("dropped_tables")
    if int(summary.get("mapper_invalid_facts") or 0) != 0:
        reasons.append("invalid_fact_proposals")
    candidate_local_fact_count = sum(
        issue.code in _LOCAL_REJECTED_FACT_CODES
        for issue in candidate.validation_issues
    )
    candidate_local_citation_count = sum(
        issue.code in _LOCAL_REJECTED_CITATION_CODES
        for issue in candidate.validation_issues
    )
    if (
        candidate_local_fact_count != locally_rejected_fact_proposals
        or candidate_local_citation_count != locally_rejected_citations
    ):
        reasons.append("local_rejection_audit_mismatch")
    elif locally_rejected_fact_proposals or locally_rejected_citations:
        reasons.append("local_fact_rejections")
    reasons.extend(_record_region_authority_failures(candidate, summary))

    if document_type_hint and candidate.document_type != document_type_hint:
        reasons.append("document_type_hint_mismatch")
    if document_subtype_hint and candidate.document_subtype != document_subtype_hint:
        reasons.append("document_subtype_hint_mismatch")

    document_type = str(candidate.document_type or "unknown")
    document_subtype = str(candidate.document_subtype or "unknown")
    document_kind_label = str(candidate.document_kind_label or "").strip()
    expected_type = CANONICAL_SUBTYPE_TYPES.get(document_subtype)
    if expected_type is not None and document_type != expected_type:
        reasons.append("inconsistent_classification")
    if document_subtype == "unknown":
        if document_type in {"order", "purchase_order", "technical_document"}:
            reasons.append("incomplete_classification")
        elif document_type == "unknown" and document_kind_label.casefold() in {
            "",
            "unknown",
        }:
            reasons.append("unknown_classification")
    elif document_type == "unknown":
        reasons.append("incomplete_classification")

    domain_reasons, domain_invalid_paths = domain_minimum_failures(candidate)
    reasons.extend(domain_reasons)
    invalid_line_paths.update(domain_invalid_paths)

    for path in evidence_fact_paths(candidate):
        if not _has_positioned_source_refs(candidate, path):
            missing_source_paths.add(path)

    for issue in candidate.validation_issues:
        if issue.code not in _BLOCKING_LINE_ISSUES:
            continue
        invalid_line_paths.update(
            path for path in issue.paths if str(path).startswith("$.lines[")
        )
        if issue.code == "MINERU_MAPPER_EVIDENCE_REJECTED":
            reasons.append("rejected_citations")
        elif issue.code == "MINERU_MAPPED_VALUE_INVALID":
            reasons.append("invalid_mapped_values")

    if missing_source_paths:
        reasons.append("missing_source_refs")
    if invalid_line_paths:
        reasons.append("invalid_business_lines")

    deduplicated_reasons = tuple(dict.fromkeys(reasons))
    return MinerUAuthorityDecision(
        accepted=not deduplicated_reasons,
        reasons=deduplicated_reasons,
        missing_source_paths=tuple(sorted(missing_source_paths)),
        invalid_line_paths=tuple(sorted(invalid_line_paths)),
        locally_rejected_fact_proposals=locally_rejected_fact_proposals,
        locally_rejected_citations=locally_rejected_citations,
    )


def evaluate_mineru_authority(
    candidate: DocumentRecord,
    summary: dict[str, Any],
    *,
    baseline: dict[str, Any] | None = None,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    authority_mode: str = "guarded",
) -> MinerUAuthorityDecision:
    """Evaluate a candidate under the guarded or MinerU-only authority contract."""

    mode = str(authority_mode or "guarded").strip().casefold()
    if mode == "full":
        return _evaluate_full_mineru_authority(
            candidate,
            summary,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
        )
    if mode != "guarded":
        raise ValueError("MinerU authority mode must be guarded or full")
    return _evaluate_guarded_mineru_authority(
        candidate,
        summary,
        baseline=baseline or {},
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
    )


def full_authority_rejection_is_reviewable(decision: MinerUAuthorityDecision) -> bool:
    """Return whether an untrusted candidate can still be shown for review.

    A reviewable rejection never becomes an authoritative document or enters
    knowledge projection. It is limited to incomplete evidence-coverage and
    classification conditions; citation, value, fingerprint, and mapping
    integrity failures remain fully fail-closed.
    """

    reasons = set(decision.reasons)
    return bool(reasons) and not decision.accepted and reasons.issubset(
        _FULL_AUTHORITY_REVIEWABLE_REASONS
    )


def selected_candidate_payload(
    candidate: DocumentRecord,
    *,
    authority_mode: str = "guarded",
    revalidate_order: bool = True,
) -> dict[str, Any]:
    """Mark provenance without copying the previous authoritative facts."""

    payload = candidate.model_dump(mode="json")
    if str(authority_mode or "guarded").strip().casefold() == "full":
        field_meta = payload.get("field_meta")
        if isinstance(field_meta, dict):
            for path, metadata in field_meta.items():
                if (
                    not isinstance(metadata, dict)
                    or metadata.get("inferred") is not True
                    or metadata.get("accepted") is False
                ):
                    continue
                try:
                    confidence = float(metadata.get("confidence", 1.0))
                except (TypeError, ValueError):
                    continue
                if confidence < 0.9 or not _has_positioned_source_refs(
                    candidate, str(path)
                ):
                    continue
                metadata["review_required"] = False
                metadata["authority_evidence_replayed"] = True
    if revalidate_order and payload.get("document_type") == "order":
        from ..orders import revalidate_order_document

        payload = revalidate_order_document(payload)
    extraction = payload.setdefault("extraction", {})
    metadata = extraction.setdefault("metadata", {})
    mode = str(authority_mode or "guarded").strip().casefold()
    if mode not in {"guarded", "full"}:
        raise ValueError("MinerU authority mode must be guarded or full")
    metadata["adapter"] = (
        "mineru_llm_guarded" if mode == "guarded" else "mineru_llm_full_authority"
    )
    metadata["candidate_isolation"] = False
    metadata["authority_mode"] = mode
    return payload


def locally_accepted_candidate_payload(
    candidate: DocumentRecord,
    decision: MinerUAuthorityDecision,
    *,
    authority_mode: str = "full",
    preserve_candidate_contract: bool = False,
) -> dict[str, Any]:
    """Keep verified facts while removing only explicitly invalid whole rows."""

    payload = (
        candidate.model_dump(mode="json")
        if preserve_candidate_contract
        else selected_candidate_payload(
            candidate,
            authority_mode=authority_mode,
            revalidate_order=False,
        )
    )
    requested_drop_indexes = {
        int(match.group("index"))
        for path in decision.invalid_line_paths
        if (match := _LINE_PATH.fullmatch(path)) is not None
        and not match.group("suffix")
    }
    lines = payload.get("lines")
    if not isinstance(lines, list):
        lines = []
        payload["lines"] = lines
    line_assessments = {}
    for index in requested_drop_indexes:
        if not 0 <= index < len(candidate.lines):
            continue
        prefix = f"$.lines[{index}]"
        line_assessments[index] = classify_line_business_payload(
            candidate.lines[index],
            document_type=candidate.document_type,
            structural_issue_codes=(
                issue.code
                for issue in candidate.validation_issues
                if prefix in issue.paths
            ),
        )
    dropped_indexes = {
        index
        for index in requested_drop_indexes
        if 0 <= index < len(lines)
        and isinstance(lines[index], dict)
        and (assessment := line_assessments.get(index)) is not None
        and assessment.provably_structural
    }
    protected_indexes = {
        index
        for index in requested_drop_indexes
        if 0 <= index < len(lines) and index not in dropped_indexes
    }
    index_map: dict[int, int] = {}
    retained_lines: list[Any] = []
    for old_index, line in enumerate(lines):
        if old_index in dropped_indexes:
            continue
        index_map[old_index] = len(retained_lines)
        retained_lines.append(line)
    payload["lines"] = retained_lines

    def remap_path(path: object) -> str | None:
        value = str(path)
        match = _LINE_PATH.match(value)
        if match is None:
            return value
        old_index = int(match.group("index"))
        new_index = index_map.get(old_index)
        if new_index is None:
            return None
        return f"$.lines[{new_index}]{match.group('suffix')}"

    field_meta = payload.get("field_meta")
    if isinstance(field_meta, dict):
        remapped_meta: dict[str, Any] = {}
        for path, metadata in field_meta.items():
            remapped = remap_path(path)
            if remapped is not None:
                remapped_meta[remapped] = metadata
        payload["field_meta"] = remapped_meta
    issues = payload.get("validation_issues")
    dropped_issue_codes: list[str] = []
    if isinstance(issues, list):
        retained_issues: list[Any] = []
        for issue in issues:
            if not isinstance(issue, dict) or not isinstance(issue.get("paths"), list):
                retained_issues.append(issue)
                continue
            remapped_paths = [
                remapped
                for path in issue["paths"]
                if (remapped := remap_path(path)) is not None
            ]
            if issue["paths"] and not remapped_paths:
                dropped_issue_codes.append(str(issue.get("code") or "unknown"))
                continue
            issue["paths"] = list(dict.fromkeys(remapped_paths))
            retained_issues.append(issue)
        payload["validation_issues"] = retained_issues

    payload["bom"] = copy.deepcopy(retained_lines)
    if payload.get("document_type") == "order":
        from ..orders import revalidate_order_document

        payload = revalidate_order_document(payload)

    extraction = payload.setdefault("extraction", {})
    metadata = extraction.setdefault("metadata", {})
    metadata["local_fact_acceptance"] = {
        "mode": "field_and_row",
        "dropped_line_count": len(dropped_indexes),
        "dropped_line_paths": [f"$.lines[{index}]" for index in sorted(dropped_indexes)],
        "protected_line_paths": [
            f"$.lines[{index}]" for index in sorted(protected_indexes)
        ],
        "line_index_map": {
            str(old_index): new_index
            for old_index, new_index in sorted(index_map.items())
        },
        "dropped_validation_issue_codes": list(dict.fromkeys(dropped_issue_codes)),
        "review_path_count": len(decision.invalid_line_paths),
        "locally_rejected_fact_proposals": (
            decision.locally_rejected_fact_proposals
        ),
        "locally_rejected_citations": decision.locally_rejected_citations,
    }
    try:
        return DocumentRecord.model_validate(payload).model_dump(mode="json")
    except Exception:  # noqa: BLE001 - preserve the already validated candidate
        fallback = selected_candidate_payload(candidate, authority_mode=authority_mode)
        fallback_extraction = fallback.setdefault("extraction", {})
        fallback_metadata = fallback_extraction.setdefault("metadata", {})
        fallback_lines = fallback.get("lines")
        fallback_line_count = (
            len(fallback_lines) if isinstance(fallback_lines, list) else 0
        )
        fallback_metadata["local_fact_acceptance"] = {
            "mode": "transform_failed",
            "dropped_line_count": 0,
            "dropped_line_paths": [],
            "protected_line_paths": [],
            "line_index_map": {
                str(index): index for index in range(fallback_line_count)
            },
            "dropped_validation_issue_codes": [],
            "review_path_count": len(decision.invalid_line_paths),
            "locally_rejected_fact_proposals": (
                decision.locally_rejected_fact_proposals
            ),
            "locally_rejected_citations": decision.locally_rejected_citations,
        }
        return fallback


def fail_closed_authority_payload(
    candidate_or_source_seed: DocumentRecord | dict[str, Any],
    *,
    code: str,
    message: str,
    gate: dict[str, Any],
    error_type: str | None = None,
) -> dict[str, Any]:
    """Return a review-only MinerU result without copying legacy business facts."""

    if isinstance(candidate_or_source_seed, DocumentRecord):
        incoming = candidate_or_source_seed.model_dump(mode="json")
    else:
        incoming = copy.deepcopy(candidate_or_source_seed)
    source = incoming.get("source") if isinstance(incoming.get("source"), dict) else {}
    source = copy.deepcopy(source)
    source.setdefault("original_filename", "unknown")

    safe_extraction: dict[str, Any] = {}
    extraction = incoming.get("extraction")
    if isinstance(extraction, dict):
        metadata = extraction.get("metadata")
        adapter = str(metadata.get("adapter") or "") if isinstance(metadata, dict) else ""
        if adapter.startswith("mineru"):
            for key in ("sections", "raw_content"):
                if key in extraction:
                    safe_extraction[key] = copy.deepcopy(extraction[key])
            if isinstance(metadata, dict) and isinstance(metadata.get("mineru"), dict):
                safe_extraction["metadata"] = {
                    "mineru": copy.deepcopy(metadata["mineru"])
                }

    metadata = safe_extraction.setdefault("metadata", {})
    metadata.update(
        {
            "adapter": "mineru_llm_full_authority",
            "candidate_isolation": False,
            "authority_mode": "full",
            "authority_selected": False,
            # This payload remains visible in the M1 task store for review, but
            # a failed full-authority run has no evidence-backed business facts
            # to place in the governed knowledge projection.
            "knowledge_sync_eligible": False,
            "knowledge_sync_block_reason": code,
            "authority_failure": {
                "code": code,
                "reasons": list(gate.get("reasons") or []),
                **({"error_type": error_type} if error_type else {}),
            },
        }
    )
    paths = [
        *[str(path) for path in gate.get("missing_source_paths") or []],
        *[str(path) for path in gate.get("invalid_line_paths") or []],
    ]
    document = DocumentRecord(
        source=source,
        document_type="unknown",
        document_subtype="unknown",
        extraction=safe_extraction,
        validation_issues=[
            {
                "code": code,
                "severity": "error",
                "message": message,
                "paths": list(dict.fromkeys(paths)) or ["$"],
                "source_refs": [],
                "expected": {"authority_gate": "passed"},
                "actual": {
                    "authority_gate": "failed_closed",
                    "reasons": list(gate.get("reasons") or []),
                    **({"error_type": error_type} if error_type else {}),
                },
                "suggestion": "MinerU 或结构化映射恢复后重新处理，或提交人工审核。",
            }
        ],
        needs_review=True,
    )
    return document.model_dump(mode="json")


def authority_document_digest(document: dict[str, Any]) -> str:
    """Hash the final payload while excluding the digest field itself."""

    payload = dict(document)
    extraction = dict(payload.get("extraction") or {})
    metadata = dict(extraction.get("metadata") or {})
    authority = dict(metadata.get("mineru_authority") or {})
    authority.pop("final_document_sha256", None)
    if authority:
        metadata["mineru_authority"] = authority
    else:
        metadata.pop("mineru_authority", None)
    extraction["metadata"] = metadata
    payload["extraction"] = extraction
    digest = hashlib.sha256()
    encoder = json.JSONEncoder(
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    for chunk in encoder.iterencode(payload):
        digest.update(chunk.encode("utf-8"))
    return digest.hexdigest()


def finalize_authority_digest(document: dict[str, Any]) -> str:
    digest = authority_document_digest(document)
    extraction = document.setdefault("extraction", {})
    metadata = extraction.setdefault("metadata", {})
    authority = metadata.setdefault("mineru_authority", {})
    authority["final_document_sha256"] = digest
    return digest


def _remap_local_acceptance_gate(
    document: dict[str, Any],
    gate: dict[str, Any],
) -> dict[str, Any]:
    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    acceptance = (
        metadata.get("local_fact_acceptance")
        if isinstance(metadata, dict)
        else None
    )
    if not isinstance(acceptance, dict) or "line_index_map" not in acceptance:
        return copy.deepcopy(gate)
    raw_index_map = acceptance.get("line_index_map")
    if not isinstance(raw_index_map, dict):
        return copy.deepcopy(gate)
    index_map = {
        int(old): int(new)
        for old, new in raw_index_map.items()
        if str(old).isdigit() and isinstance(new, int) and new >= 0
    }
    remapped_gate = copy.deepcopy(gate)
    dropped_paths: list[str] = []
    for key in (
        "missing_source_paths",
        "invalid_line_paths",
        "lost_baseline_paths",
        "mismatched_baseline_paths",
    ):
        active_paths: list[str] = []
        for raw_path in remapped_gate.get(key) or []:
            path = str(raw_path)
            match = _LINE_PATH.match(path)
            if match is None:
                active_paths.append(path)
                continue
            new_index = index_map.get(int(match.group("index")))
            if new_index is None:
                dropped_paths.append(path)
                continue
            active_paths.append(
                f"$.lines[{new_index}]{match.group('suffix')}"
            )
        remapped_gate[key] = list(dict.fromkeys(active_paths))
    acceptance["dropped_gate_paths"] = list(dict.fromkeys(dropped_paths))
    return remapped_gate


def preserved_document_with_issue(
    document: dict[str, Any],
    *,
    code: str,
    message: str,
    gate: dict[str, Any],
) -> dict[str, Any]:
    """Keep all existing facts and add only a bounded review issue."""

    preserved = copy.deepcopy(document)
    gate = _remap_local_acceptance_gate(preserved, gate)
    issues = preserved.setdefault("validation_issues", [])
    if not isinstance(issues, list):
        issues = []
        preserved["validation_issues"] = issues
    paths = [
        *[str(path) for path in gate.get("missing_source_paths") or []],
        *[str(path) for path in gate.get("invalid_line_paths") or []],
        *[str(path) for path in gate.get("lost_baseline_paths") or []],
        *[str(path) for path in gate.get("mismatched_baseline_paths") or []],
    ]
    reasons = list(gate.get("reasons") or [])
    for issue in issues:
        if not isinstance(issue, dict) or issue.get("code") != code:
            continue
        actual = issue.get("actual")
        if isinstance(actual, dict) and list(actual.get("reasons") or []) == reasons:
            return preserved
    issues.append(
        {
            "code": code,
            "severity": "warning",
            "message": message,
            "paths": list(dict.fromkeys(paths))
            or ["$.extraction.metadata.local_fact_acceptance"],
            "source_refs": [],
            "expected": {"authority_gate": "passed"},
            "actual": {
                "authority_gate": "rejected",
                "reasons": reasons,
            },
            "suggestion": "已保留当前解析结果；可通过状态摘要审计 MinerU 门禁失败项。",
        }
    )
    preserved["needs_review"] = True
    return preserved


__all__ = [
    "MinerUAuthorityDecision",
    "authority_document_digest",
    "evaluate_mineru_authority",
    "fail_closed_authority_payload",
    "finalize_authority_digest",
    "full_authority_rejection_is_reviewable",
    "locally_accepted_candidate_payload",
    "preserved_document_with_issue",
    "selected_candidate_payload",
]
