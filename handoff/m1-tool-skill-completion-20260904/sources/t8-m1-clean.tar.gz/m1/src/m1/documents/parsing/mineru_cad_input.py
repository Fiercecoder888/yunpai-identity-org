"""Fail-closed CAD renderer contract for MinerU input normalization."""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
from pathlib import Path
import subprocess
from typing import Any, Mapping, Protocol


class MinerUCADRendererRequired(RuntimeError):
    """CAD was supplied without an approved renderer implementation."""


class MinerUCADRenderError(RuntimeError):
    """An approved CAD renderer failed or returned an invalid artifact."""


class MinerUCADSourceError(RuntimeError):
    """The supplied CAD bytes could not be decoded by an approved renderer."""


@dataclass(frozen=True, slots=True)
class CADRenderResult:
    """One bounded CAD renderer output and its source-page correspondence."""

    path: Path
    renderer_name: str
    renderer_version: str
    page_map: tuple[Mapping[str, Any], ...] = ()
    sidecar_metadata: Mapping[str, Any] = field(default_factory=dict)


class MinerUCADRenderer(Protocol):
    """Renderer boundary; implementations must not mutate the source CAD file."""

    def render(self, source: Path, *, output_dir: Path) -> CADRenderResult: ...


class EzdxfCADRenderer:
    """Render DXF/DWG modelspace to a single bounded PDF for MinerU."""

    name = "ezdxf-pymupdf"

    def __init__(self, *, timeout_seconds: float = 120.0) -> None:
        self.timeout_seconds = max(1.0, float(timeout_seconds))

    def render(self, source: Path, *, output_dir: Path) -> CADRenderResult:
        try:
            import ezdxf
            from ezdxf.addons.drawing import Frontend, RenderContext, layout, pymupdf
        except ImportError as exc:  # pragma: no cover - core M1 dependencies
            raise MinerUCADRenderError(
                "MINERU_CAD_RENDER_FAILED: ezdxf/PyMuPDF backend is unavailable"
            ) from exc

        dxf_path = source
        converter = "native-dxf"
        if source.suffix.casefold() == ".dwg":
            dxf_path, converter = self._convert_dwg(source, output_dir)
        try:
            document = ezdxf.readfile(dxf_path)
        except Exception as exc:
            raise MinerUCADSourceError(
                f"CAD source could not be decoded: {exc.__class__.__name__}"
            ) from exc
        try:
            backend = pymupdf.PyMuPdfBackend()
            Frontend(RenderContext(document), backend).draw_layout(
                document.modelspace()
            )
            page = layout.Page(
                297,
                210,
                layout.Units.mm,
                margins=layout.Margins.all(8),
            )
            pdf_bytes = backend.get_pdf_bytes(page)
        except Exception as exc:
            raise MinerUCADRenderError(
                f"MINERU_CAD_RENDER_FAILED: vector rendering {exc.__class__.__name__}"
            ) from exc
        if not pdf_bytes or not bytes(pdf_bytes).startswith(b"%PDF-"):
            raise MinerUCADRenderError(
                "MINERU_CAD_RENDER_FAILED: renderer returned an invalid PDF"
            )
        output = output_dir / "normalized.pdf"
        output.write_bytes(bytes(pdf_bytes))

        # Preserve the deterministic CAD text/geometry summary beside the
        # visual page. It remains evidence metadata, never rendered authority.
        from ...parsers.cad import parse_dxf

        summary = parse_dxf(dxf_path)
        summary_bytes = summary.encode("utf-8", errors="replace")
        summary_limit = 32 * 1024
        summary_snapshot = summary_bytes[:summary_limit].decode(
            "utf-8", errors="ignore"
        )
        return CADRenderResult(
            path=output,
            renderer_name=self.name,
            renderer_version=str(getattr(ezdxf, "__version__", "unknown")),
            page_map=(
                {
                    "rendered_page": 1,
                    "source_layout": "modelspace",
                    "fit": "a4_landscape",
                },
            ),
            sidecar_metadata={
                "dwg_converter": converter,
                "geometry_summary": summary_snapshot,
                "geometry_summary_sha256": hashlib.sha256(summary_bytes).hexdigest(),
                "geometry_summary_truncated": len(summary_bytes) > summary_limit,
            },
        )

    def _convert_dwg(self, source: Path, output_dir: Path) -> tuple[Path, str]:
        from ...parsers.cad import _dwg_command

        output = output_dir / "converted.dxf"
        command, converter = _dwg_command(source, output)
        try:
            completed = subprocess.run(
                command,
                cwd=output_dir,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise MinerUCADRenderError(
                "MINERU_CAD_RENDER_FAILED: DWG conversion timed out"
            ) from exc
        if completed.returncode != 0:
            raise MinerUCADSourceError(
                f"DWG source could not be decoded by {converter}"
            )
        if not output.is_file() and converter == "dwg2dxf":
            output = next(iter(sorted(output_dir.glob("*.dxf"))), output)
        if not output.is_file() or output.stat().st_size == 0:
            raise MinerUCADRenderError(
                f"MINERU_CAD_RENDER_FAILED: {converter} produced no DXF"
            )
        return output, converter


__all__ = [
    "CADRenderResult",
    "EzdxfCADRenderer",
    "MinerUCADRenderError",
    "MinerUCADRenderer",
    "MinerUCADRendererRequired",
    "MinerUCADSourceError",
]
