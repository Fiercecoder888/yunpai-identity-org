"""Evidence-cited LLM mapping and deterministic MinerU candidate replay."""

from __future__ import annotations

import copy
import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any, Literal, get_args

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..adapters.common import guessed_mime, source_payload
from ..models import (
    DocumentRecord,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from ..orders import (
    _parse_date_text,
    _validate_lines,
    attach_derived_line_evidence,
    enrich_order_line,
)
from .evidence import DocumentEvidence, EvidenceBBox, EvidencePage, EvidenceTable
from .finalization import evidence_sections
from .mineru_domain import (
    CANONICAL_SUBTYPE_TYPES,
    LINE_TARGET_SET,
    LINE_TARGET_VALUES,
    DocumentSubtype,
    DocumentType,
    FactTarget,
    LineTarget,
    allowed_line_targets,
    mapper_domain_instructions,
    mapping_path,
    mold_identifier_validation_issues,
    parse_number,
    replay_line_value,
    target_storage_key,
)
from .mineru_regions import (
    RecordRegionAssessment,
    RecordRegionBindingReport,
    assess_record_regions,
    record_region_binding_report,
)


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class MinerUFactPlan(_StrictModel):
    target: FactTarget
    evidence_id: str = Field(min_length=1, max_length=160)
    quote: str = Field(min_length=1, max_length=1000)
    value: str = Field(min_length=1, max_length=1000)


class _MinerUFactPlanProposal(_StrictModel):
    """Tolerant model-wire shape for optional/blank document fields.

    MinerU frequently exposes labelled but empty form fields.  Those are not
    facts and must not make the complete mapper response fail validation.  The
    strict :class:`MinerUFactPlan` remains the internal replay contract; this
    wire model accepts blank (and null) values and normalization below filters
    them before constructing that contract.
    """

    target: str | None = Field(
        default="",
        max_length=160,
        json_schema_extra={"enum": list(get_args(FactTarget))},
    )
    evidence_id: str | None = Field(default="", max_length=160)
    quote: str | None = Field(default="", max_length=1000)
    value: str | None = Field(default="", max_length=1000)


class MinerUAxisMapping(_StrictModel):
    axis_index: int = Field(ge=0, le=10000)
    field: LineTarget
    header_evidence_id: str = Field(min_length=1, max_length=160)
    header_quote: str = Field(min_length=1, max_length=500)


class _MinerUAxisMappingProposal(_StrictModel):
    """Tolerant model-wire shape; accepted values are normalized before replay."""

    axis_index: int = Field(ge=0, le=10000)
    field: str = Field(
        default="",
        max_length=64,
        json_schema_extra={"enum": list(LINE_TARGET_VALUES)},
    )
    header_evidence_id: str = Field(default="", max_length=160)
    header_quote: str = Field(default="", max_length=500)


class MinerUTablePlan(_StrictModel):
    table_id: str = Field(min_length=1, max_length=160)
    region_id: str | None = Field(default=None, min_length=1, max_length=80)
    orientation: Literal["rows", "columns"] = "rows"
    header_indices: list[int] = Field(default_factory=list, max_length=20)
    data_start: int = Field(ge=0, le=10000)
    data_end: int | None = Field(default=None, ge=0, le=10000)
    mappings: list[MinerUAxisMapping] = Field(default_factory=list, max_length=80)


class _MinerUTablePlanProposal(_StrictModel):
    table_id: str = Field(min_length=1, max_length=160)
    region_id: str | None = Field(default=None, min_length=1, max_length=80)
    orientation: Literal["rows", "columns"] = "rows"
    header_indices: list[int] = Field(default_factory=list, max_length=20)
    data_start: int = Field(ge=0, le=10000)
    data_end: int | None = Field(default=None, ge=0, le=10000)
    mappings: list[_MinerUAxisMappingProposal] = Field(
        default_factory=list,
        max_length=80,
    )


class _MinerUTableReplanProposal(_StrictModel):
    """A bounded repair response that cannot alter document-level facts."""

    tables: list[_MinerUTablePlanProposal] = Field(default_factory=list, max_length=40)


class MinerUBusinessPlan(_StrictModel):
    document_type: DocumentType = "unknown"
    document_subtype: DocumentSubtype = "unknown"
    classification_evidence_ids: list[str] = Field(default_factory=list, max_length=12)
    facts: list[MinerUFactPlan] = Field(default_factory=list, max_length=80)
    tables: list[MinerUTablePlan] = Field(default_factory=list, max_length=40)

    @model_validator(mode="after")
    def canonical_classification_pair(self) -> MinerUBusinessPlan:
        expected = CANONICAL_SUBTYPE_TYPES.get(self.document_subtype)
        if expected is not None and self.document_type != expected:
            raise ValueError(
                "document_subtype is inconsistent with canonical document_type"
            )
        if self.document_type == "unknown" and self.document_subtype != "unknown":
            raise ValueError("unknown document_type requires unknown document_subtype")
        return self


class _MinerUBusinessPlanProposal(_StrictModel):
    document_type: DocumentType = "unknown"
    document_subtype: DocumentSubtype = "unknown"
    classification_evidence_ids: list[str] = Field(default_factory=list, max_length=12)
    facts: list[_MinerUFactPlanProposal] = Field(default_factory=list, max_length=80)
    tables: list[_MinerUTablePlanProposal] = Field(default_factory=list, max_length=40)

    @model_validator(mode="after")
    def canonical_classification_pair(self) -> _MinerUBusinessPlanProposal:
        expected = CANONICAL_SUBTYPE_TYPES.get(self.document_subtype)
        if expected is not None and self.document_type != expected:
            raise ValueError(
                "document_subtype is inconsistent with canonical document_type"
            )
        if self.document_type == "unknown" and self.document_subtype != "unknown":
            raise ValueError("unknown document_type requires unknown document_subtype")
        return self


@dataclass(frozen=True, slots=True)
class _EvidenceValue:
    evidence_id: str
    text: str
    source_ref: SourceReference


@dataclass(slots=True)
class MinerUCandidateResult:
    document: DocumentRecord
    plan: MinerUBusinessPlan
    mapper_duration_seconds: float
    mapper_usage: dict[str, int]
    rejected_citations: int
    record_region_assessment: RecordRegionAssessment | None = None
    record_region_bindings: RecordRegionBindingReport | None = None


_CURRENCY_MAP = {
    "人民币": "CNY",
    "rmb": "CNY",
    "cny": "CNY",
    "美元": "USD",
    "usd": "USD",
    "欧元": "EUR",
    "eur": "EUR",
}
_BUYER_ROLE_LABEL = re.compile(
    r"(?:甲方|采购方|购货方|买方|需方|buyer|purchaser|customer)",
    re.IGNORECASE,
)
_SELLER_ROLE_LABEL = re.compile(
    r"(?:乙方|供方|供应商|卖方|销货方|seller|supplier|vendor)",
    re.IGNORECASE,
)
_MAPPING_LABEL_ALIASES: dict[str, tuple[str, ...]] = {
    "line_no": (
        "line no",
        "line number",
        "item no",
        "item number",
        "position",
        "pos",
        "\u5e8f\u53f7",
        "\u884c\u53f7",
    ),
    "code": (
        "code",
        "part no",
        "part number",
        "material code",
        "material number",
        "sku",
        "model",
        "drawing no",
        "\u7269\u6599\u7f16\u7801",
        "\u7269\u6599\u53f7",
        "\u4ea7\u54c1\u7f16\u7801",
        "\u6599\u53f7",
        "\u578b\u53f7",
        "\u56fe\u53f7",
        "\u7f16\u53f7",
    ),
    "name": (
        "name",
        "description",
        "material name",
        "item name",
        "\u7269\u6599\u540d\u79f0",
        "\u4ea7\u54c1\u540d\u79f0",
        "\u540d\u79f0",
        "\u54c1\u540d",
    ),
    "specification": (
        "spec",
        "specification",
        "requirement",
        "\u89c4\u683c",
        "\u89c4\u683c\u578b\u53f7",
        "\u578b\u53f7\u89c4\u683c",
        "\u6280\u672f\u8981\u6c42",
    ),
    "quantity": (
        "qty",
        "quantity",
        "usage",
        "\u6570\u91cf",
        "\u7528\u91cf",
        "\u9700\u6c42\u6570\u91cf",
    ),
    "unit": ("unit", "uom", "\u5355\u4f4d"),
    "price": (
        "price",
        "unit price",
        "\u5355\u4ef7",
        "\u542b\u7a0e\u5355\u4ef7",
        "\u672a\u7a0e\u5355\u4ef7",
    ),
    "amount": (
        "amount",
        "total amount",
        "\u91d1\u989d",
        "\u5408\u8ba1\u91d1\u989d",
    ),
    "date": (
        "date",
        "delivery date",
        "due date",
        "\u65e5\u671f",
        "\u4ea4\u8d27\u65e5\u671f",
        "\u4ea4\u671f",
    ),
    "remark": ("remark", "note", "\u5907\u6ce8", "\u8bf4\u660e"),
}
_TARGET_LABEL_CATEGORY: dict[str, str] = {
    "line_no": "line_no",
    "model": "code",
    "product_code": "code",
    "equipment_code": "code",
    "mold_number": "code",
    "material_code": "code",
    "technical_drawing_number": "code",
    "record_code": "code",
    "asset_number": "code",
    "batch_number": "code",
    "bom_number": "code",
    "customer_product_code": "code",
    "supplier_product_code": "code",
    "name_raw": "name",
    "equipment_name": "name",
    "mold_name": "name",
    "material_name": "name",
    "technical_product_name": "name",
    "record_name": "name",
    "parameter_name": "name",
    "specification_raw": "specification",
    "description": "specification",
    "requirement": "specification",
    "parameter_value": "specification",
    "quantity": "quantity",
    "package_quantity": "quantity",
    "piece_count": "quantity",
    "available_quantity": "quantity",
    "reserved_quantity": "quantity",
    "cavity_count": "quantity",
    "unit": "unit",
    "unit_price_tax_included": "price",
    "unit_price_tax_excluded": "price",
    "unit_price": "price",
    "amount_tax_included": "amount",
    "amount_tax_excluded": "amount",
    "amount": "amount",
    "record_value": "amount",
    "document_date": "date",
    "delivery_date": "date",
    "suggested_date": "date",
    "commissioned_date": "date",
    "remark": "remark",
}


def _normalized(value: Any) -> str:
    return "".join(unicodedata.normalize("NFKC", str(value or "")).casefold().split())


def _mapping_label_key(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    return re.sub(r"[\s\W_]+", "", normalized)


def _mapping_label_categories(value: str) -> set[str]:
    key = _mapping_label_key(value)
    if not key:
        return set()
    categories: set[str] = set()
    for category, aliases in _MAPPING_LABEL_ALIASES.items():
        for alias in aliases:
            alias_key = _mapping_label_key(alias)
            if not alias_key:
                continue
            if alias_key == key or (len(alias_key) >= 4 and alias_key in key):
                categories.add(category)
                break
    return categories


def _mapping_label_conflicts(field: str, header_quote: str) -> bool:
    """Treat a known, mutually exclusive table label as hard negative evidence."""

    expected = _TARGET_LABEL_CATEGORY.get(field)
    categories = _mapping_label_categories(header_quote)
    return bool(expected and categories and expected not in categories)


def _bounded(value: Any, limit: int = 320) -> str:
    text = str(value or "")
    return text if len(text) <= limit else f"{text[:limit]}..."


def _source_reference(
    *,
    page: EvidencePage,
    part: str,
    bbox: EvidenceBBox | None,
    granularity: str,
) -> SourceReference:
    return SourceReference(
        page=page.page_number,
        part=part,
        bbox=bbox.as_list() if bbox else None,
        coordinate_space=(bbox.coordinate_space if bbox else page.coordinate_space),
        granularity=granularity,
    )


def evidence_lookup(evidence: DocumentEvidence) -> dict[str, _EvidenceValue]:
    values: dict[str, _EvidenceValue] = {}
    for page in evidence.pages:
        for block in page.blocks:
            values[block.block_id] = _EvidenceValue(
                evidence_id=block.block_id,
                text=block.text,
                source_ref=_source_reference(
                    page=page,
                    part=f"mineru/block:{block.block_id}",
                    bbox=block.bbox,
                    granularity="block",
                ),
            )
        for table in page.tables:
            for cell in table.cells:
                cell_id = f"{table.table_id}:r{cell.row}:c{cell.column}"
                values[cell_id] = _EvidenceValue(
                    evidence_id=cell_id,
                    text=str(cell.text or ""),
                    source_ref=_source_reference(
                        page=page,
                        part=(
                            f"mineru/table:{table.table_id}/row:{cell.row}/"
                            f"column:{cell.column}"
                        ),
                        bbox=cell.bbox or table.bbox,
                        granularity=(
                            "cell" if getattr(cell, "bbox_precision", "") == "cell" else "table"
                        ),
                    ),
                )
    return values


def _citation(
    lookup: dict[str, _EvidenceValue],
    evidence_id: str,
    quote: str,
    value: str | None = None,
) -> _EvidenceValue | None:
    source = lookup.get(evidence_id)
    if source is None:
        return None
    normalized_source = _normalized(source.text)
    normalized_quote = _normalized(quote)
    normalized_value = _normalized(value if value is not None else quote)
    if not normalized_source or not normalized_quote or normalized_quote not in normalized_source:
        return None
    if not normalized_value or normalized_value not in normalized_quote:
        return None
    return source


def _sample_indices(size: int, limit: int = 24) -> list[int]:
    if size <= limit:
        return list(range(size))
    head = list(range(min(12, size)))
    tail = list(range(max(len(head), size - 8), size))
    middle_start = max(len(head), size // 2 - 2)
    middle = list(range(middle_start, min(size - len(tail), middle_start + 4)))
    return sorted({*head, *middle, *tail})[:limit]


def _region_context_axis_indices(
    *,
    axis_size: int,
    data_start: int,
    data_end: int,
) -> list[int]:
    """Keep table-header context plus first/middle/last verified records."""

    before = range(max(0, data_start - 2), min(axis_size, data_start))
    record_points = {
        data_start,
        data_end,
        data_start + (data_end - data_start) // 2,
    }
    return sorted(
        {
            *before,
            *(index for index in record_points if 0 <= index < axis_size),
        }
    )


def _spread_indices(size: int, limit: int) -> list[int]:
    if size <= limit:
        return list(range(size))
    if limit <= 1:
        return [0]
    return sorted(
        {
            round(index * (size - 1) / (limit - 1))
            for index in range(limit)
        }
    )


def _record_region_context(
    evidence: DocumentEvidence,
    assessment: RecordRegionAssessment,
    *,
    max_chars: int,
) -> list[dict[str, Any]]:
    """Render exact local context for every fixed region without full-table replay."""

    def render(field_limit: int, value_limit: int) -> list[dict[str, Any]]:
        contexts: list[dict[str, Any]] = []
        for region in assessment.record_regions:
            located = _table_page(evidence, region.table_id)
            if located is None:
                contexts.append(
                    {"region_id": region.region_id, "table_missing": True}
                )
                continue
            _, table = located
            record_axis_size = (
                len(table.rows)
                if region.orientation == "rows"
                else max((len(row) for row in table.rows), default=0)
            )
            field_axis_size = (
                max((len(row) for row in table.rows), default=0)
                if region.orientation == "rows"
                else len(table.rows)
            )
            field_indices = _spread_indices(field_axis_size, field_limit)
            axis_examples: list[dict[str, Any]] = []
            for record_axis in _region_context_axis_indices(
                axis_size=record_axis_size,
                data_start=region.data_start,
                data_end=region.data_end,
            ):
                cells: list[dict[str, Any]] = []
                for field_axis in field_indices:
                    row, column = (
                        (record_axis, field_axis)
                        if region.orientation == "rows"
                        else (field_axis, record_axis)
                    )
                    raw_value = (
                        table.rows[row][column]
                        if row < len(table.rows) and column < len(table.rows[row])
                        else None
                    )
                    cells.append(
                        {
                            "id": f"{table.table_id}:r{row}:c{column}",
                            "row": row,
                            "column": column,
                            "value": _bounded(raw_value, value_limit),
                        }
                    )
                axis_examples.append({"axis_index": record_axis, "cells": cells})
            contexts.append(
                {
                    "region_id": region.region_id,
                    "table_id": region.table_id,
                    "orientation": region.orientation,
                    "data_start": region.data_start,
                    "data_end": region.data_end,
                    "record_axis_count": record_axis_size,
                    "field_axis_count": field_axis_size,
                    "field_axis_truncated": field_axis_size > len(field_indices),
                    "axis_examples": axis_examples,
                }
            )
        return contexts

    field_limit = 48
    value_limit = 96
    while True:
        contexts = render(field_limit, value_limit)
        encoded_size = len(
            json.dumps(contexts, ensure_ascii=False, separators=(",", ":"))
        )
        if encoded_size <= max_chars:
            return contexts
        if field_limit > 8:
            field_limit = max(8, field_limit // 2)
            continue
        if value_limit > 48:
            value_limit = 48
            continue
        raise ValueError(
            "MinerU record-region context exceeds the mapper evidence budget"
        )


def mapper_evidence_payload(
    evidence: DocumentEvidence,
    *,
    max_chars: int = 24_000,
    table_ids: set[str] | None = None,
    record_region_assessment: RecordRegionAssessment | None = None,
) -> dict[str, Any]:
    blocks: list[dict[str, Any]] = []
    tables: list[dict[str, Any]] = []
    for page in evidence.pages:
        for block in sorted(page.blocks, key=lambda value: value.order):
            if block.kind == "table":
                continue
            blocks.append(
                {
                    "id": block.block_id,
                    "page": page.page_number,
                    "type": block.kind,
                    "text": _bounded(block.text, 400),
                }
            )
        for table in page.tables:
            if table_ids is not None and table.table_id not in table_ids:
                continue
            sample_rows = []
            for row_index in _sample_indices(len(table.rows)):
                row = table.rows[row_index]
                sample_rows.append(
                    {
                        "index": row_index,
                        "cells": [
                            {
                                "id": f"{table.table_id}:r{row_index}:c{column_index}",
                                "column": column_index,
                                "value": _bounded(row[column_index], 160),
                            }
                            for column_index in _sample_indices(len(row))
                        ],
                    }
                )
            tables.append(
                {
                    "id": table.table_id,
                    "page": page.page_number,
                    "row_count": len(table.rows),
                    "column_count": max((len(row) for row in table.rows), default=0),
                    "sample_rows": sample_rows,
                }
            )
    payload = {
        "blocks": blocks[:80],
        "tables": tables[:30],
        "truncated": {
            "block_count": len(blocks),
            "table_count": len(tables),
            "blocks_omitted": max(0, len(blocks) - 80),
            "tables_omitted": max(0, len(tables) - 30),
            "content_reduced": len(blocks) > 80 or len(tables) > 30,
        },
    }
    if record_region_assessment is not None:
        # This is deliberately never sampled or shortened.  A full-authority
        # mapper may only select these already-assessed evidence ranges.
        payload["record_region_assessment"] = {
            "status": record_region_assessment.status,
            "no_record_table_ids": list(
                record_region_assessment.no_record_table_ids
            ),
            "record_regions": [
                {
                    "region_id": region.region_id,
                    "table_id": region.table_id,
                    "orientation": region.orientation,
                    "data_start": region.data_start,
                    "data_end": region.data_end,
                    "boundary_evidence_ids": list(region.boundary_evidence_ids),
                }
                for region in record_region_assessment.record_regions
            ],
            "region_context": _record_region_context(
                evidence,
                record_region_assessment,
                max_chars=max(2_000, int(max_chars * 0.6)),
            ),
        }

    def serialized_size() -> int:
        metadata = payload["truncated"]
        metadata["blocks_included"] = len(payload["blocks"])
        metadata["tables_included"] = len(payload["tables"])
        return len(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        )

    while serialized_size() > max_chars:
        payload["truncated"]["content_reduced"] = True
        if len(payload["blocks"]) > 16:
            payload["blocks"].pop()
            continue
        largest = max(
            payload["tables"],
            key=lambda table: len(table["sample_rows"]),
            default=None,
        )
        if largest is not None and len(largest["sample_rows"]) > 4:
            largest["sample_rows"].pop(len(largest["sample_rows"]) // 2)
            continue
        widest = max(
            (
                row
                for table in payload["tables"]
                for row in table["sample_rows"]
            ),
            key=lambda row: len(row["cells"]),
            default=None,
        )
        if widest is not None and len(widest["cells"]) > 8:
            widest["cells"].pop(len(widest["cells"]) // 2)
            continue
        if len(payload["tables"]) > 8:
            payload["tables"].pop()
            continue
        longest_block = max(
            payload["blocks"],
            key=lambda block: len(block["text"]),
            default=None,
        )
        if longest_block is not None and len(longest_block["text"]) > 120:
            longest_block["text"] = _bounded(longest_block["text"], 120)
            continue
        longest_cell = max(
            (
                cell
                for table in payload["tables"]
                for row in table["sample_rows"]
                for cell in row["cells"]
            ),
            key=lambda cell: len(cell["value"]),
            default=None,
        )
        if longest_cell is not None and len(longest_cell["value"]) > 64:
            longest_cell["value"] = _bounded(longest_cell["value"], 64)
            continue
        if largest is not None and len(largest["sample_rows"]) > 1:
            largest["sample_rows"].pop()
            continue
        if len(payload["blocks"]) > 4:
            payload["blocks"].pop()
            continue
        if payload["tables"]:
            payload["tables"].pop()
            continue
        if payload["blocks"]:
            payload["blocks"].pop()
            continue
        raise ValueError("MinerU mapper max input is too small for metadata")
    if serialized_size() > max_chars:  # pragma: no cover - guarded by loop
        raise AssertionError("MinerU mapper payload exceeds configured hard limit")
    return payload


def _mapper_prompt(
    evidence: DocumentEvidence,
    *,
    max_input_chars: int,
    envelope: dict[str, Any],
    table_ids: set[str] | None = None,
    record_region_assessment: RecordRegionAssessment | None = None,
) -> str:
    prompt_envelope = {**envelope, "evidence": {}}
    envelope_size = len(
        json.dumps(
            prompt_envelope,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    )
    payload = mapper_evidence_payload(
        evidence,
        max_chars=max_input_chars - envelope_size,
        table_ids=table_ids,
        record_region_assessment=record_region_assessment,
    )
    prompt_envelope["evidence"] = payload
    prompt = json.dumps(
        prompt_envelope,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    if len(prompt) > max_input_chars:
        raise AssertionError("MinerU mapper prompt exceeds configured hard limit")
    return prompt


class MinerUBusinessMapper:
    """One evidence-only model call that returns a replayable mapping plan."""

    def __init__(self, *, client: Any, model: str, max_input_chars: int = 24_000) -> None:
        self.client = client
        self.model = model
        self.max_input_chars = max(4_000, int(max_input_chars))
        self._calls = 0
        self._successes = 0
        self._failures = 0
        self._last_error_type = ""

    async def close(self) -> None:
        close = getattr(self.client, "close", None)
        if callable(close):
            await close()

    async def probe(self) -> dict[str, Any]:
        """Probe the mapper endpoint without sending document content."""

        probe = getattr(self.client, "probe", None)
        if callable(probe):
            result = probe()
            if hasattr(result, "__await__"):
                result = await result
            if isinstance(result, dict):
                return result
        if not self.model:
            raise RuntimeError("MinerU mapper model is not configured")
        return {"ready": True, "model": self.model, "configured": True}

    def status(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "calls": self._calls,
            "successes": self._successes,
            "failures": self._failures,
            "last_error_type": self._last_error_type or None,
        }

    async def plan(
        self,
        evidence: DocumentEvidence,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        record_region_assessment: RecordRegionAssessment | None = None,
        strict_record_regions: bool = False,
    ) -> tuple[MinerUBusinessPlan, float, dict[str, int]]:
        if strict_record_regions and record_region_assessment is None:
            raise ValueError("strict MinerU mapping requires a record-region assessment")
        prompt = _mapper_prompt(
            evidence,
            max_input_chars=self.max_input_chars,
            envelope={
                "explicit_document_type_hint": _bounded(
                    document_type_hint or "", 128
                ),
                "explicit_document_subtype_hint": _bounded(
                    document_subtype_hint or "", 128
                ),
            },
            record_region_assessment=(
                record_region_assessment if strict_record_regions else None
            ),
        )
        instructions = (
            "You map Chinese manufacturing and commercial documents using only the "
            "provided MinerU evidence. Explicit hints are authoritative. Classify the "
            "document using only the canonical English enum tokens in the schema. For "
            "every known classification, including a hinted one, provide only the "
            "classification_evidence_ids that visibly support it; never cite an unrelated "
            "block or cell. "
            "Use supplier_purchase_order for 采购订单/供应商采购订单, "
            "customer_purchase_order for 客户采购订单/销售订单, purchase_contract "
            "for 采购合同, and stocking_order for 备货单. "
            "Treat 甲方/采购方/购货方 as buyer, and 乙方/供方/供应商 as "
            "seller or supplier; never reverse those labelled roles. "
            "Include every explicit, unambiguous header or total fact, especially "
            "an order/contract identifier printed in a title or labelled field. "
            "Cite each fact with an exact evidence id, quote, "
            "and value that is a substring of that quote. Only plan a table when it "
            "contains repeated business records or BOM rows, specification parameters, "
            "equipment, molds, inventory, procurement ledger entries, or otherwise "
            "meaningful records. Ignore visual layout grids, while retaining revision, "
            "dimension, and inspection tables when they contain business facts. "
            f"{mapper_domain_instructions()} For each included table, describe only "
            "its orientation, header axes, inclusive data range, and source-axis to line "
            "field mapping. header_indices are record-axis indexes: row indexes when "
            "orientation is rows, or column indexes when orientation is columns; they "
            "are never field-axis indexes. Use every field at most once. Omit a mapping rather than "
            "inventing a field token, header evidence id, or header quote. Never enumerate "
            "data rows and never invent a value. For a table without a real header, "
            "header_indices may be empty only when every mapping cites a representative "
            "cell from the same record row or column inside one explicit, contiguous data "
            "range. In mixed drawing tables, map only the contiguous BOM or repeated-record "
            "range; title blocks, revision rows, and layout rows remain evidence and must "
            "not become lines. Use zero-based row and column indexes exactly as shown. "
            "Omit uncertain facts."
            " Do not emit a fact when its value is blank or whitespace; a labelled "
            "empty form field is not a fact and must be omitted."
        )
        if strict_record_regions:
            instructions += (
                " The record_region_assessment is authoritative and was derived from "
                "the complete table evidence, not a sample. For every table plan, set "
                "region_id to one listed record region and copy its table_id, orientation, "
                "data_start, and data_end exactly. Emit exactly one plan for every listed "
                "record region and no plan for a no_record table. Never combine, split, "
                "expand, shrink, or invent a record region."
            )
        self._calls += 1
        try:
            run = await self.client.run(
                _MinerUBusinessPlanProposal,
                instructions=instructions,
                prompt=prompt,
                request_limit=2,
            )
            plan, normalization_usage = _normalize_mineru_plan(
                evidence,
                run.output,
                record_region_assessment=record_region_assessment,
                strict_record_regions=strict_record_regions,
            )
        except Exception as exc:
            self._failures += 1
            self._last_error_type = exc.__class__.__name__
            raise
        duration_seconds = float(run.duration_seconds)
        usage = dict(run.usage)
        usage.update(normalization_usage)
        usage.update(
            {
                # Preserve the first-pass quality signal for audit, while the
                # authority gate consumes the final unresolved counts below.
                "initial_dropped_mappings": int(
                    normalization_usage.get("dropped_mappings") or 0
                ),
                "initial_dropped_tables": int(
                    normalization_usage.get("dropped_tables") or 0
                ),
                "unresolved_dropped_mappings": int(
                    normalization_usage.get("dropped_mappings") or 0
                ),
                "unresolved_dropped_tables": int(
                    normalization_usage.get("dropped_tables") or 0
                ),
            }
        )
        usage.update(
            {
                "replan_attempted": 0,
                "replan_failed": 0,
                "replan_rejected": 0,
                "replan_replaced_tables": 0,
                "replan_requests": 0,
            }
        )
        target_table_ids = _replan_target_table_ids(
            run.output,
            plan,
            normalization_usage,
            strict_record_regions=strict_record_regions,
            record_region_assessment=record_region_assessment,
        )
        if target_table_ids:
            usage["replan_attempted"] = 1
            try:
                replan_table_id_set = (
                    {
                        region.table_id
                        for target_region_id in target_table_ids
                        if (
                            region := record_region_assessment.region_by_id(
                                target_region_id
                            )
                        )
                        is not None
                    }
                    if strict_record_regions
                    else set(target_table_ids)
                )
                replan_envelope: dict[str, Any] = {
                    "target_table_ids": sorted(replan_table_id_set),
                }
                if strict_record_regions:
                    replan_envelope["target_region_ids"] = list(target_table_ids)
                replan_prompt = _mapper_prompt(
                    evidence,
                    max_input_chars=self.max_input_chars,
                    envelope=replan_envelope,
                    table_ids=replan_table_id_set,
                    record_region_assessment=(
                        record_region_assessment if strict_record_regions else None
                    ),
                )
                replan_instructions = (
                    "Repair only the table mapping plans for the exact target_table_ids "
                    "in the prompt, using only the provided MinerU evidence. You must not "
                    "output document classification or facts. Output exactly one complete "
                    "table plan for every target and no other table. Every mapping must use "
                    "a real cited cell, a canonical allowed field, and a zero-based source "
                    "axis. header_indices are record-axis indexes. For a headerless table, "
                    "use an explicit contiguous data range and cite every mapping from one "
                    "representative record row or column in that range. Do not invent values, "
                    "headers, or mappings. If any target cannot be planned completely, return "
                    "no table plans."
                )
                if strict_record_regions:
                    replan_instructions += (
                        " target_region_ids are fixed evidence ranges. Return exactly one "
                        "plan for each target region_id, copy each target table_id, orientation, "
                        "data_start, and data_end exactly, and do not output another region."
                    )
                self._calls += 1
                replan_run = await self.client.run(
                    _MinerUTableReplanProposal,
                    instructions=replan_instructions,
                    prompt=replan_prompt,
                    request_limit=2,
                )
                replan_proposal = _MinerUBusinessPlanProposal(
                    document_type=plan.document_type,
                    document_subtype=plan.document_subtype,
                    tables=replan_run.output.tables,
                )
                replan_plan, replan_usage = _normalize_mineru_plan(
                    evidence,
                    replan_proposal,
                    record_region_assessment=record_region_assessment,
                    strict_record_regions=strict_record_regions,
                )
                duration_seconds += float(replan_run.duration_seconds)
                for metric in (
                    "requests",
                    "prompt_tokens",
                    "completion_tokens",
                    "total_tokens",
                ):
                    usage[metric] = int(usage.get(metric) or 0) + int(
                        replan_run.usage.get(metric) or 0
                    )
                usage["replan_requests"] = int(
                    replan_run.usage.get("requests") or 0
                )
                if _is_complete_table_replan(
                    replan_plan,
                    target_table_ids=target_table_ids,
                    normalization_usage=replan_usage,
                    strict_record_regions=strict_record_regions,
                ):
                    plan = _replace_replanned_tables(
                        plan,
                        run.output,
                        replan_plan.tables,
                        strict_record_regions=strict_record_regions,
                        record_region_assessment=record_region_assessment,
                    )
                    usage["replan_replaced_tables"] = len(target_table_ids)
                    # A complete replan covers each initially rejected table
                    # exactly once and is normalized again before replacement.
                    # Keep the first-pass counters for diagnostics, but do not
                    # reject the final evidence-replayable plan as unresolved.
                    usage["unresolved_dropped_mappings"] = 0
                    usage["unresolved_dropped_tables"] = 0
                else:
                    usage["replan_rejected"] = 1
            except Exception:  # noqa: BLE001 - advisory repair must not replace valid plan
                # A repair is advisory. The first evidence-replayable plan remains
                # authoritative when its bounded retry cannot be validated.
                usage["replan_failed"] = 1
        self._successes += 1
        self._last_error_type = ""
        return plan, duration_seconds, usage


def _replan_target_table_ids(
    proposal: _MinerUBusinessPlanProposal,
    plan: MinerUBusinessPlan,
    normalization_usage: dict[str, int],
    *,
    strict_record_regions: bool = False,
    record_region_assessment: RecordRegionAssessment | None = None,
) -> tuple[str, ...]:
    if strict_record_regions:
        if record_region_assessment is None:
            return ()
        normalized_by_id = {
            table.region_id: table
            for table in plan.tables
            if table.region_id is not None
        }
        proposal_by_id = {
            table.region_id: table
            for table in proposal.tables
            if table.region_id is not None
        }
        return tuple(
            region.region_id
            for region in record_region_assessment.record_regions
            if (
                (normalized := normalized_by_id.get(region.region_id)) is None
                or (
                    (proposed := proposal_by_id.get(region.region_id)) is not None
                    and len(normalized.mappings) != len(proposed.mappings)
                )
            )
        )
    if not (
        normalization_usage["dropped_mappings"]
        or normalization_usage["dropped_tables"]
    ):
        return ()
    proposal_ids = [
        (table.region_id if strict_record_regions else table.table_id)
        for table in proposal.tables
    ]
    normalized_by_id = {
        (table.region_id if strict_record_regions else table.table_id): table
        for table in plan.tables
    }
    return tuple(
        (table_proposal.region_id if strict_record_regions else table_proposal.table_id)
        for table_proposal in proposal.tables
        if (target_id := (
            table_proposal.region_id if strict_record_regions else table_proposal.table_id
        ))
        and proposal_ids.count(target_id) == 1
        and (
            (normalized := normalized_by_id.get(target_id)) is None
            or len(normalized.mappings) != len(table_proposal.mappings)
        )
    )


def _is_complete_table_replan(
    plan: MinerUBusinessPlan,
    *,
    target_table_ids: tuple[str, ...],
    normalization_usage: dict[str, int],
    strict_record_regions: bool = False,
) -> bool:
    table_ids = [
        (table.region_id if strict_record_regions else table.table_id)
        for table in plan.tables
    ]
    return (
        not normalization_usage["dropped_mappings"]
        and not normalization_usage["dropped_tables"]
        and len(table_ids) == len(target_table_ids)
        and len(table_ids) == len(set(table_ids))
        and set(table_ids) == set(target_table_ids)
        and all(table.mappings for table in plan.tables)
    )


def _replace_replanned_tables(
    original_plan: MinerUBusinessPlan,
    original_proposal: _MinerUBusinessPlanProposal,
    replan_tables: list[MinerUTablePlan],
    *,
    strict_record_regions: bool = False,
    record_region_assessment: RecordRegionAssessment | None = None,
) -> MinerUBusinessPlan:
    replacements = {
        (table.region_id if strict_record_regions else table.table_id): table
        for table in replan_tables
    }
    original_by_id = {
        (table.region_id if strict_record_regions else table.table_id): table
        for table in original_plan.tables
    }
    if strict_record_regions and record_region_assessment is not None:
        ordered_tables = [
            selected
            for region in record_region_assessment.record_regions
            if (
                selected := replacements.get(region.region_id)
                or original_by_id.get(region.region_id)
            )
            is not None
        ]
        return MinerUBusinessPlan(
            document_type=original_plan.document_type,
            document_subtype=original_plan.document_subtype,
            classification_evidence_ids=list(original_plan.classification_evidence_ids),
            facts=list(original_plan.facts),
            tables=ordered_tables,
        )
    ordered_tables: list[MinerUTablePlan] = []
    seen_table_ids: set[str] = set()
    for proposal_table in original_proposal.tables:
        table_id = (
            proposal_table.region_id
            if strict_record_regions
            else proposal_table.table_id
        )
        if not table_id:
            continue
        if table_id in seen_table_ids:
            continue
        selected = replacements.get(table_id) or original_by_id.get(table_id)
        if selected is not None:
            ordered_tables.append(selected)
            seen_table_ids.add(table_id)
    return MinerUBusinessPlan(
        document_type=original_plan.document_type,
        document_subtype=original_plan.document_subtype,
        classification_evidence_ids=list(original_plan.classification_evidence_ids),
        facts=list(original_plan.facts),
        tables=ordered_tables,
    )


def _raw_labels(table: EvidenceTable, plan: MinerUTablePlan) -> dict[int, str]:
    labels: dict[int, str] = {}
    if plan.orientation == "rows":
        width = max((len(row) for row in table.rows), default=0)
        for column in range(width):
            parts = [
                str(table.rows[row][column] or "").strip()
                for row in plan.header_indices
                if 0 <= row < len(table.rows) and column < len(table.rows[row])
            ]
            label = " / ".join(dict.fromkeys(part for part in parts if part))
            labels[column] = label or f"column_{column + 1}"
    else:
        for row_index, row in enumerate(table.rows):
            parts = [
                str(row[column] or "").strip()
                for column in plan.header_indices
                if 0 <= column < len(row)
            ]
            label = " / ".join(dict.fromkeys(part for part in parts if part))
            labels[row_index] = label or f"row_{row_index + 1}"
    return labels


def _table_page(evidence: DocumentEvidence, table_id: str) -> tuple[EvidencePage, EvidenceTable] | None:
    for page in evidence.pages:
        for table in page.tables:
            if table.table_id == table_id:
                return page, table
    return None


def _declared_header_evidence_ids(
    table: EvidenceTable,
    *,
    orientation: Literal["rows", "columns"],
    header_indices: list[int],
    axis_index: int,
) -> set[str]:
    if orientation == "rows":
        return {
            f"{table.table_id}:r{row}:c{axis_index}"
            for row in header_indices
            if 0 <= row < len(table.rows) and axis_index < len(table.rows[row])
        }
    return {
        f"{table.table_id}:r{axis_index}:c{column}"
        for column in header_indices
        if 0 <= axis_index < len(table.rows)
        and 0 <= column < len(table.rows[axis_index])
    }


def _declared_data_evidence_ids(
    table: EvidenceTable,
    *,
    orientation: Literal["rows", "columns"],
    data_start: int,
    data_end: int,
    axis_index: int,
) -> set[str]:
    if orientation == "rows":
        return {
            f"{table.table_id}:r{row}:c{axis_index}"
            for row in range(data_start, data_end + 1)
            if 0 <= row < len(table.rows) and axis_index < len(table.rows[row])
        }
    return {
        f"{table.table_id}:r{axis_index}:c{column}"
        for column in range(data_start, data_end + 1)
        if 0 <= axis_index < len(table.rows)
        and 0 <= column < len(table.rows[axis_index])
    }


def _normalize_mineru_plan(
    evidence: DocumentEvidence,
    proposal: _MinerUBusinessPlanProposal,
    *,
    record_region_assessment: RecordRegionAssessment | None = None,
    strict_record_regions: bool = False,
) -> tuple[MinerUBusinessPlan, dict[str, int]]:
    """Convert tolerant model output into the strict, evidence-replayable plan."""

    if strict_record_regions and record_region_assessment is None:
        raise ValueError("strict MinerU normalization requires a record-region assessment")
    lookup = evidence_lookup(evidence)
    facts: list[MinerUFactPlan] = []
    dropped_facts = 0
    empty_facts = 0
    invalid_facts = 0
    for fact_proposal in proposal.facts:
        # Keep citation mismatches for build_mineru_candidate to reject and
        # report as review issues.  Only facts that cannot be represented by
        # the strict replay contract are discarded here.
        target = str(fact_proposal.target or "").strip()
        evidence_id = str(fact_proposal.evidence_id or "").strip()
        quote = str(fact_proposal.quote or "").strip()
        value = str(fact_proposal.value or "").strip()
        if not value:
            dropped_facts += 1
            empty_facts += 1
            continue
        if not target or not evidence_id or not quote:
            dropped_facts += 1
            invalid_facts += 1
            continue
        try:
            facts.append(
                MinerUFactPlan(
                    target=target,
                    evidence_id=evidence_id,
                    quote=quote,
                    value=value,
                )
            )
        except (TypeError, ValueError):
            # Unknown targets and malformed non-empty proposals cannot be
            # replayed safely.  They are counted, while valid facts in the
            # same model response continue through the pipeline.
            dropped_facts += 1
            invalid_facts += 1

    tables: list[MinerUTablePlan] = []
    repaired_mappings = 0
    dropped_mappings = 0
    dropped_tables = 0
    seen_region_ids: set[str] = set()
    for table_proposal in proposal.tables:
        expected_region = None
        if strict_record_regions:
            region_id = str(table_proposal.region_id or "").strip()
            expected_region = record_region_assessment.region_by_id(region_id)  # type: ignore[union-attr]
            if (
                not region_id
                or expected_region is None
                or region_id in seen_region_ids
                or table_proposal.table_id != expected_region.table_id
                or table_proposal.orientation != expected_region.orientation
                or table_proposal.data_start != expected_region.data_start
                or table_proposal.data_end != expected_region.data_end
            ):
                dropped_mappings += len(table_proposal.mappings)
                dropped_tables += 1
                continue
            seen_region_ids.add(region_id)
        located = _table_page(evidence, table_proposal.table_id)
        if located is None:
            dropped_mappings += len(table_proposal.mappings)
            dropped_tables += 1
            continue
        _, table = located
        record_axis_size = (
            len(table.rows)
            if table_proposal.orientation == "rows"
            else max((len(row) for row in table.rows), default=0)
        )
        data_end = table_proposal.data_end
        if data_end is None:
            data_end = record_axis_size - 1
        data_end_repaired = False
        if not strict_record_regions and (
            table_proposal.data_end is not None
            and data_end == record_axis_size
            and table_proposal.data_start < record_axis_size
        ):
            # Some models return the exclusive row/column count despite the
            # inclusive contract. Only repair the exact one-past-end case.
            data_end = record_axis_size - 1
            data_end_repaired = True
        if (
            table_proposal.data_start >= record_axis_size
            or data_end < table_proposal.data_start
            or data_end >= record_axis_size
        ):
            dropped_mappings += len(table_proposal.mappings)
            dropped_tables += 1
            continue
        declared_headers = sorted(set(table_proposal.header_indices))
        headerless = not declared_headers
        if headerless and table_proposal.data_end is None:
            dropped_mappings += len(table_proposal.mappings)
            dropped_tables += 1
            continue
        mapping_results: list[tuple[MinerUAxisMapping, bool]] = []
        derived_header_indices: set[int] = set()
        sample_record_axes: set[int] = set()
        seen_storage: set[str] = set()
        allowed_targets = allowed_line_targets(proposal.document_type)
        for mapping in table_proposal.mappings:
            field = mapping.field.strip()
            evidence_id = mapping.header_evidence_id.strip()
            storage_key = target_storage_key(field)
            if (
                field not in LINE_TARGET_SET
                or field not in allowed_targets
                or storage_key is None
                or not evidence_id
                or storage_key in seen_storage
            ):
                dropped_mappings += 1
                continue
            repaired = (
                field != mapping.field or evidence_id != mapping.header_evidence_id
            )
            cell_match = re.fullmatch(
                rf"{re.escape(table.table_id)}:r(?P<row>\d+):c(?P<column>\d+)",
                evidence_id,
            )
            source = lookup.get(evidence_id)
            if cell_match is None or source is None:
                dropped_mappings += 1
                continue
            row = int(cell_match.group("row"))
            column = int(cell_match.group("column"))
            mapping_axis = column if table_proposal.orientation == "rows" else row
            header_axis = row if table_proposal.orientation == "rows" else column
            if mapping_axis != mapping.axis_index:
                dropped_mappings += 1
                continue
            quote = mapping.header_quote.strip()
            if not quote:
                quote = source.text.strip()[:500]
                if not quote:
                    dropped_mappings += 1
                    continue
                repaired = True
            if _citation(lookup, evidence_id, quote) is None:
                source_quote = source.text.strip()[:500]
                if not source_quote:
                    dropped_mappings += 1
                    continue
                quote = source_quote
                repaired = True
            if not headerless and _mapping_label_conflicts(field, quote):
                dropped_mappings += 1
                continue
            mapping_results.append(
                (
                    MinerUAxisMapping(
                        axis_index=mapping.axis_index,
                        field=field,
                        header_evidence_id=evidence_id,
                        header_quote=quote,
                    ),
                    repaired,
                )
            )
            derived_header_indices.add(header_axis)
            sample_record_axes.add(header_axis)
            seen_storage.add(storage_key)
        if not mapping_results:
            dropped_tables += 1
            continue
        if headerless:
            if (
                len(sample_record_axes) != 1
                or not sample_record_axes.intersection(
                    range(table_proposal.data_start, data_end + 1)
                )
            ):
                dropped_mappings += len(mapping_results)
                dropped_tables += 1
                continue
            inferred_headers: list[int] = []
            header_repaired = False
        else:
            inferred_headers = sorted(derived_header_indices)
            if (
                not inferred_headers
                or any(
                    index < 0 or index >= record_axis_size
                    for index in inferred_headers
                )
                or set(inferred_headers).intersection(
                    range(table_proposal.data_start, data_end + 1)
                )
            ):
                dropped_mappings += len(mapping_results)
                dropped_tables += 1
                continue
            header_repaired = inferred_headers != declared_headers
        mappings = [mapping for mapping, _repaired in mapping_results]
        repaired_mappings += sum(
            1
            for _mapping, repaired in mapping_results
            if repaired or header_repaired or data_end_repaired
        )
        tables.append(
            MinerUTablePlan(
                table_id=table_proposal.table_id,
                region_id=(expected_region.region_id if expected_region else None),
                orientation=table_proposal.orientation,
                header_indices=inferred_headers,
                data_start=table_proposal.data_start,
                data_end=(data_end if table_proposal.data_end is not None else None),
                mappings=mappings,
            )
        )
    return (
        MinerUBusinessPlan(
            document_type=proposal.document_type,
            document_subtype=proposal.document_subtype,
            classification_evidence_ids=list(proposal.classification_evidence_ids),
            facts=facts,
            tables=tables,
        ),
        {
            "dropped_facts": dropped_facts,
            "empty_facts": empty_facts,
            "invalid_facts": invalid_facts,
            "repaired_mappings": repaired_mappings,
            "dropped_mappings": dropped_mappings,
            "dropped_tables": dropped_tables,
        },
    )


def _table_source(
    lookup: dict[str, _EvidenceValue], table_id: str, row: int, column: int
) -> _EvidenceValue | None:
    return lookup.get(f"{table_id}:r{row}:c{column}")


def _append_rejected_issue(
    issues: list[ValidationIssue], *, target: str, evidence_id: str
) -> None:
    issues.append(
        ValidationIssue(
            code="MINERU_MAPPER_EVIDENCE_REJECTED",
            severity="warning",
            message="A MinerU mapper proposal did not match its cited evidence.",
            paths=[f"$.{target}"],
            actual={"evidence_id": evidence_id},
        )
    )


def _replay_table(
    evidence: DocumentEvidence,
    lookup: dict[str, _EvidenceValue],
    table_plan: MinerUTablePlan,
    lines: list[OrderLine],
    field_meta: dict[str, FieldMetadata],
    issues: list[ValidationIssue],
    *,
    record_region_assessment: RecordRegionAssessment | None = None,
    strict_record_regions: bool = False,
) -> int:
    if strict_record_regions:
        if record_region_assessment is None:
            _append_rejected_issue(issues, target="lines", evidence_id="missing-region-assessment")
            return 1
        expected_region = record_region_assessment.region_by_id(
            str(table_plan.region_id or "")
        )
        if (
            expected_region is None
            or table_plan.table_id != expected_region.table_id
            or table_plan.orientation != expected_region.orientation
            or table_plan.data_start != expected_region.data_start
            or table_plan.data_end != expected_region.data_end
        ):
            _append_rejected_issue(
                issues,
                target="lines",
                evidence_id=str(table_plan.region_id or table_plan.table_id),
            )
            return 1
    located = _table_page(evidence, table_plan.table_id)
    if located is None:
        _append_rejected_issue(
            issues, target="lines", evidence_id=table_plan.table_id
        )
        return 1
    _, table = located
    axis_size = (
        len(table.rows)
        if table_plan.orientation == "rows"
        else max((len(row) for row in table.rows), default=0)
    )
    end = table_plan.data_end if table_plan.data_end is not None else axis_size - 1
    if (
        table_plan.data_start >= axis_size
        or end < table_plan.data_start
        or end >= axis_size
        or any(index < 0 or index >= axis_size for index in table_plan.header_indices)
        or set(table_plan.header_indices).intersection(
            range(table_plan.data_start, end + 1)
        )
    ):
        _append_rejected_issue(
            issues, target="lines", evidence_id=table_plan.table_id
        )
        return 1
    valid_mappings: list[MinerUAxisMapping] = []
    rejected = 0
    seen_storage: set[str] = set()
    mapping_axis_size = (
        max((len(row) for row in table.rows), default=0)
        if table_plan.orientation == "rows"
        else len(table.rows)
    )
    for mapping in table_plan.mappings:
        storage_key = target_storage_key(mapping.field)
        if table_plan.header_indices:
            valid_header_ids = _declared_header_evidence_ids(
                table,
                orientation=table_plan.orientation,
                header_indices=table_plan.header_indices,
                axis_index=mapping.axis_index,
            )
        else:
            valid_header_ids = _declared_data_evidence_ids(
                table,
                orientation=table_plan.orientation,
                data_start=table_plan.data_start,
                data_end=end,
                axis_index=mapping.axis_index,
            )
        citation = _citation(
            lookup,
            mapping.header_evidence_id,
            mapping.header_quote,
        )
        if (
            mapping.axis_index >= mapping_axis_size
            or mapping.header_evidence_id not in valid_header_ids
            or storage_key is None
            or storage_key in seen_storage
            or citation is None
            or (
                bool(table_plan.header_indices)
                and _mapping_label_conflicts(mapping.field, mapping.header_quote)
            )
        ):
            rejected += 1
            _append_rejected_issue(
                issues,
                target=f"lines[*].{mapping.field}",
                evidence_id=mapping.header_evidence_id,
            )
            continue
        seen_storage.add(storage_key)
        valid_mappings.append(mapping)
    labels = _raw_labels(table, table_plan)
    for record_axis in range(table_plan.data_start, end + 1):
        mapped: dict[str, tuple[str, _EvidenceValue]] = {}
        raw_columns: dict[str, Any] = {}
        raw_sources: dict[str, _EvidenceValue] = {}

        def preserve_raw(
            label: str,
            raw_value: Any,
            source: _EvidenceValue | None,
            axis: int,
            raw_columns_ref: dict[str, Any] = raw_columns,
            raw_sources_ref: dict[str, _EvidenceValue] = raw_sources,
        ) -> None:
            key = label
            if key in raw_columns_ref:
                key = f"{label} [{axis + 1}]"
            raw_columns_ref[key] = raw_value
            if source is not None and str(raw_value or "").strip():
                raw_sources_ref[key] = source

        if table_plan.orientation == "rows":
            row = table.rows[record_axis]
            for column, raw_value in enumerate(row):
                preserve_raw(
                    labels.get(column, f"column_{column + 1}"),
                    raw_value,
                    _table_source(lookup, table.table_id, record_axis, column),
                    column,
                )
            for mapping in valid_mappings:
                if mapping.axis_index >= len(row):
                    continue
                source = _table_source(
                    lookup, table.table_id, record_axis, mapping.axis_index
                )
                raw_value = str(row[mapping.axis_index] or "").strip()
                if source is not None and raw_value:
                    mapped[mapping.field] = (raw_value, source)
        else:
            for row_index, row in enumerate(table.rows):
                raw_value = row[record_axis] if record_axis < len(row) else None
                preserve_raw(
                    labels.get(row_index, f"row_{row_index + 1}"),
                    raw_value,
                    _table_source(lookup, table.table_id, row_index, record_axis),
                    row_index,
                )
            for mapping in valid_mappings:
                if mapping.axis_index >= len(table.rows):
                    continue
                row = table.rows[mapping.axis_index]
                if record_axis >= len(row):
                    continue
                source = _table_source(
                    lookup, table.table_id, mapping.axis_index, record_axis
                )
                raw_value = str(row[record_axis] or "").strip()
                if source is not None and raw_value:
                    mapped[mapping.field] = (raw_value, source)
        if not mapped:
            continue
        line_id = hashlib.sha256(
            f"{table.table_id}:{table_plan.orientation}:{record_axis}".encode()
        ).hexdigest()[:20]
        line = OrderLine(line_id=f"mineru-{line_id}", raw_columns=raw_columns)
        line_index = len(lines)
        prefix = f"$.lines[{line_index}]"
        for key, source in raw_sources.items():
            field_meta[mapping_path(prefix, "raw_columns", key)] = FieldMetadata(
                source_refs=[source.source_ref.model_copy(deep=True)],
                confidence=0.9,
                inferred=False,
                model_mapped=False,
                review_required=False,
            )
        for field, (raw_value, source) in mapped.items():
            replayed = replay_line_value(line, field, raw_value)
            if replayed is None:
                issues.append(
                    ValidationIssue(
                        code="MINERU_MAPPED_VALUE_INVALID",
                        severity="warning",
                        message="A mapped numeric value could not be parsed.",
                        paths=[f"$.lines[{line_index}].{field}"],
                        source_refs=[source.source_ref.model_copy(deep=True)],
                    )
                )
                continue
            relative_path, _value = replayed
            if relative_path.startswith("custom_fields."):
                path = mapping_path(
                    prefix,
                    "custom_fields",
                    relative_path.removeprefix("custom_fields."),
                )
            else:
                path = f"{prefix}.{relative_path}"
            field_meta[path] = FieldMetadata(
                source_refs=[source.source_ref.model_copy(deep=True)],
                confidence=0.85,
                inferred=True,
                model_mapped=True,
                review_required=True,
            )
        lines.append(line)
    return rejected


def build_mineru_candidate(
    *,
    path: str | Path,
    original_filename: str | None,
    evidence: DocumentEvidence,
    plan: MinerUBusinessPlan,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    record_region_assessment: RecordRegionAssessment | None = None,
    strict_record_regions: bool = False,
) -> tuple[DocumentRecord, int]:
    """Build a candidate without copying any fact from the authoritative record."""

    if strict_record_regions and record_region_assessment is None:
        raise ValueError("strict MinerU replay requires a record-region assessment")
    source_path = Path(path)
    source = source_payload(
        source_path,
        original_filename=original_filename,
        mime_type=guessed_mime(source_path, "application/octet-stream"),
    )
    lookup = evidence_lookup(evidence)
    classification_ids = [
        evidence_id
        for evidence_id in plan.classification_evidence_ids
        if evidence_id in lookup
    ]
    document_type = (
        document_type_hint
        or (plan.document_type if classification_ids else "unknown")
        or "unknown"
    )
    document_subtype = (
        document_subtype_hint
        or (plan.document_subtype if classification_ids else "unknown")
        or "unknown"
    )
    if document_subtype_hint and not document_type_hint:
        document_type = CANONICAL_SUBTYPE_TYPES.get(
            document_subtype_hint,
            document_type,
        )
    record = DocumentRecord(
        source=source,
        document_type=document_type,
        document_subtype=document_subtype,
        extraction={
            "sections": evidence_sections(evidence),
            "raw_content": {
                "text_original": evidence.text,
                "pages": [
                    {
                        "page_number": page.page_number,
                        "page_index": page.page_index,
                        "width": page.width,
                        "height": page.height,
                        "coordinate_space": page.coordinate_space,
                        "rotation": page.rotation,
                        "markdown": page.markdown,
                        "blocks": [
                            block.model_dump(mode="json") for block in page.blocks
                        ],
                        "tables": [
                            table.model_dump(mode="json") for table in page.tables
                        ],
                        "mineru_raw": copy.deepcopy(page.raw),
                    }
                    for page in evidence.pages
                ],
            },
            "metadata": {
                "adapter": "mineru_llm_shadow",
                "candidate_isolation": True,
                "mineru": evidence.summary(),
            },
        },
    )
    classification_refs = [
        lookup[evidence_id].source_ref.model_copy(deep=True)
        for evidence_id in classification_ids
    ]
    if classification_refs and document_type not in {"", "unknown"}:
        record.field_meta["$.document_type"] = FieldMetadata(
            source_refs=[reference.model_copy(deep=True) for reference in classification_refs],
            confidence=0.85,
            inferred=True,
            model_mapped=True,
            review_required=True,
        )
    if classification_refs and document_subtype not in {"", "unknown"}:
        record.field_meta["$.document_subtype"] = FieldMetadata(
            source_refs=[reference.model_copy(deep=True) for reference in classification_refs],
            confidence=0.85,
            inferred=True,
            model_mapped=True,
            review_required=True,
        )
    rejected = 0
    issues: list[ValidationIssue] = []
    for fact in plan.facts:
        source_value = _citation(
            lookup, fact.evidence_id, fact.quote, fact.value
        )
        if source_value is None:
            rejected += 1
            _append_rejected_issue(
                issues, target=fact.target, evidence_id=fact.evidence_id
            )
            continue
        if fact.target == "header.contract_number" and re.fullmatch(
            r"\d{4}[-/.]\d{1,2}[-/.]\d{1,2}", fact.value.strip()
        ):
            rejected += 1
            _append_rejected_issue(
                issues, target=fact.target, evidence_id=fact.evidence_id
            )
            continue
        if (
            fact.target in {"header.seller", "header.supplier"}
            and _BUYER_ROLE_LABEL.search(fact.quote)
        ) or (
            fact.target == "header.buyer"
            and _SELLER_ROLE_LABEL.search(fact.quote)
        ):
            rejected += 1
            _append_rejected_issue(
                issues, target=fact.target, evidence_id=fact.evidence_id
            )
            continue
        if fact.target == "header.delivery_date_raw" and not re.search(
            r"交货|交期|交付|到货|delivery|due",
            fact.quote,
            re.IGNORECASE,
        ):
            rejected += 1
            _append_rejected_issue(
                issues, target=fact.target, evidence_id=fact.evidence_id
            )
            continue
        namespace, field = fact.target.split(".", 1)
        path_key = f"$.{fact.target}"
        if namespace == "header":
            value = fact.value.strip()
            if field == "currency":
                value = _CURRENCY_MAP.get(_normalized(value), value)
            setattr(record.header, field, value)
            record.field_meta[path_key] = FieldMetadata(
                source_refs=[source_value.source_ref.model_copy(deep=True)],
                confidence=0.85,
                inferred=True,
                model_mapped=True,
                review_required=True,
            )
        else:
            number = parse_number(fact.value)
            if number is None:
                rejected += 1
                _append_rejected_issue(
                    issues, target=fact.target, evidence_id=fact.evidence_id
                )
                continue
            setattr(record.totals, field, number)
            record.field_meta[path_key] = FieldMetadata(
                source_refs=[source_value.source_ref.model_copy(deep=True)],
                confidence=0.85,
                inferred=True,
                model_mapped=True,
                review_required=True,
            )
    region_report: RecordRegionBindingReport | None = None
    invalid_region_ids: set[str] = set()
    if strict_record_regions:
        region_report = record_region_binding_report(
            record_region_assessment,  # type: ignore[arg-type]
            [
                {
                    "region_id": table.region_id,
                    "table_id": table.table_id,
                    "orientation": table.orientation,
                    "data_start": table.data_start,
                    "data_end": table.data_end,
                }
                for table in plan.tables
            ],
        )
        record.extraction.setdefault("metadata", {})["mineru_record_regions"] = {
            **record_region_assessment.summary(),  # type: ignore[union-attr]
            **region_report.summary(),
        }
        invalid_region_ids.update(region_report.fabricated_region_ids)
        invalid_region_ids.update(region_report.cross_region_ids)
        invalid_region_ids.update(region_report.overlapping_region_ids)
        if region_report.assessment_status != "complete":
            invalid_region_ids.update(
                str(table.region_id or "") for table in plan.tables
            )
    for table_plan in plan.tables:
        if strict_record_regions and str(table_plan.region_id or "") in invalid_region_ids:
            _append_rejected_issue(
                issues,
                target="lines",
                evidence_id=str(table_plan.region_id or table_plan.table_id),
            )
            rejected += 1
            continue
        rejected += _replay_table(
            evidence,
            lookup,
            table_plan,
            record.lines,
            record.field_meta,
            issues,
            record_region_assessment=record_region_assessment,
            strict_record_regions=strict_record_regions,
        )
    if record.header.date_raw:
        parsed, inferred = _parse_date_text(
            record.header.date_raw, record.header.order_number
        )
        record.header.date_standard = parsed
        record.header.date_inferred = inferred
        if parsed and "$.header.date_raw" in record.field_meta:
            record.field_meta["$.header.date_standard"] = record.field_meta[
                "$.header.date_raw"
            ].model_copy(deep=True)
    if record.header.delivery_date_raw:
        parsed, _ = _parse_date_text(
            record.header.delivery_date_raw, record.header.order_number
        )
        record.header.delivery_date_standard = parsed
        if parsed and "$.header.delivery_date_raw" in record.field_meta:
            record.field_meta["$.header.delivery_date_standard"] = record.field_meta[
                "$.header.delivery_date_raw"
            ].model_copy(deep=True)
    if record.document_type in {"order", "inventory", "procurement"}:
        for line in record.lines:
            issues.extend(enrich_order_line(line))
        attach_derived_line_evidence(record.lines, record.field_meta)
    if record.document_type == "order":
        issues.extend(_validate_lines(record.lines))
    issues.extend(mold_identifier_validation_issues(record))
    if record.lines:
        calculated_quantity = sum(
            (Decimal(line.quantity) for line in record.lines if line.quantity is not None),
            Decimal(0),
        )
        if any(line.quantity is not None for line in record.lines):
            record.totals.calculated_quantity = calculated_quantity
            if record.totals.declared_quantity is not None:
                record.totals.quantity_matches = (
                    Decimal(record.totals.declared_quantity) == calculated_quantity
                )
    record.validation_issues.extend(issues)
    record.needs_review = True
    # Re-validate after all model-derived values and additive metadata are attached.
    return DocumentRecord.model_validate(record.model_dump(mode="python")), rejected


async def map_mineru_candidate(
    *,
    mapper: MinerUBusinessMapper,
    path: str | Path,
    original_filename: str | None,
    evidence: DocumentEvidence,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    record_region_assessment: RecordRegionAssessment | None = None,
    strict_record_regions: bool = False,
) -> MinerUCandidateResult:
    assessment = record_region_assessment
    if strict_record_regions and assessment is None:
        assessment = assess_record_regions(evidence)
    plan, duration, usage = await mapper.plan(
        evidence,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
        record_region_assessment=assessment,
        strict_record_regions=strict_record_regions,
    )
    bindings = (
        record_region_binding_report(
            assessment,
            [
                {
                    "region_id": table.region_id,
                    "table_id": table.table_id,
                    "orientation": table.orientation,
                    "data_start": table.data_start,
                    "data_end": table.data_end,
                }
                for table in plan.tables
            ],
        )
        if strict_record_regions and assessment is not None
        else None
    )
    document, rejected = build_mineru_candidate(
        path=path,
        original_filename=original_filename,
        evidence=evidence,
        plan=plan,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
        record_region_assessment=assessment,
        strict_record_regions=strict_record_regions,
    )
    return MinerUCandidateResult(
        document=document,
        plan=copy.deepcopy(plan),
        mapper_duration_seconds=duration,
        mapper_usage=usage,
        rejected_citations=rejected,
        record_region_assessment=assessment,
        record_region_bindings=bindings,
    )


__all__ = [
    "MinerUAxisMapping",
    "MinerUBusinessMapper",
    "MinerUBusinessPlan",
    "MinerUCandidateResult",
    "MinerUFactPlan",
    "MinerUTablePlan",
    "build_mineru_candidate",
    "evidence_lookup",
    "map_mineru_candidate",
    "mapper_evidence_payload",
]
