"""Domain vocabulary and evidence-bound replay helpers for MinerU.

The model is allowed to describe *where* a business value belongs, but it does
not write arbitrary JSON paths.  This module keeps that vocabulary finite and
maps every accepted target into the additive ``m1.document.v2`` contract.
"""

from __future__ import annotations

import json
import re
import unicodedata
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Literal, get_args

from ..models import DocumentRecord, OrderLine, ValidationIssue
from ..orders import ALIAS_LOOKUP as ORDER_LINE_ALIAS_LOOKUP
from ..orders import normalize_line_header_label, resolve_line_header_alias

DocumentType = Literal[
    "unknown",
    "order",
    "inventory",
    "equipment",
    "mold",
    "procurement",
    "technical_document",
    "commercial_document",
    "archive",
]

DocumentSubtype = Literal[
    "unknown",
    "supplier_purchase_order",
    "customer_purchase_order",
    "purchase_contract",
    "stocking_order",
    "sample_request",
    "inventory_snapshot",
    "equipment_register",
    "mold_mapping",
    "purchase_receipt_ledger",
    "purchase_requisition_ledger",
    "purchase_order_ledger",
    "bill_of_materials",
    "approval_drawing",
    "engineering_drawing",
    "product_specification",
    "process_document",
    "service_policy",
    "product_photo",
    "presentation",
    "web_document",
    "image_document",
    "quotation",
    "archive",
]

FactTarget = Literal[
    "header.title",
    "header.issuer",
    "header.order_number",
    "header.contract_number",
    "header.date_raw",
    "header.delivery_date_raw",
    "header.settlement_method",
    "header.delivery_address",
    "header.buyer",
    "header.seller",
    "header.supplier",
    "header.currency",
    "header.document_number",
    "header.drawing_number",
    "header.product_number",
    "header.material_number",
    "header.version",
    "header.scale",
    "header.unit",
    "header.manufacture",
    "header.status",
    "header.warehouse",
    "header.receipt_number",
    "header.purchase_order_number",
    "totals.declared_quantity",
    "totals.declared_amount",
]

LineTarget = Literal[
    # Stable OrderLine fields shared by several business domains.
    "line_no",
    "model",
    "product_code",
    "name_raw",
    "specification_raw",
    "body_printing",
    "color",
    "quantity",
    "unit",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "carton_specification",
    "volume",
    "packaging_requirements",
    "origin",
    "remark",
    # Inventory and general ledger fields.
    "warehouse",
    "location",
    "status",
    "batch_number",
    "available_quantity",
    "reserved_quantity",
    "customer_product_code",
    "customer_model",
    "supplier_product_code",
    "bom_number",
    # Equipment and mold aliases retain domain meaning while replaying into the
    # existing identity fields consumed by the knowledge canonicalizer.
    "equipment_code",
    "equipment_name",
    "asset_number",
    "manufacturer",
    "commissioned_date",
    "usage",
    "mold_number",
    "mold_name",
    "cavity_count",
    # Procurement ledgers.
    "material_code",
    "material_name",
    "supplier_name",
    "customer_name",
    "purchase_order_number",
    "receipt_number",
    "requisition_number",
    "supplier_delivery_number",
    "system_document_number",
    "customer_order_number",
    "document_date",
    "delivery_date",
    "suggested_date",
    "unit_price",
    "amount",
    # Technical documents and generic fail-closed records.
    "technical_drawing_number",
    "technical_product_name",
    "material",
    "process_step",
    "requirement",
    "parameter_name",
    "parameter_value",
    "record_code",
    "record_name",
    "description",
    "record_date",
    "record_value",
]

CANONICAL_SUBTYPE_TYPES: dict[str, str] = {
    "supplier_purchase_order": "order",
    "customer_purchase_order": "order",
    "purchase_contract": "order",
    "stocking_order": "order",
    "sample_request": "order",
    "inventory_snapshot": "inventory",
    "equipment_register": "equipment",
    "mold_mapping": "mold",
    "purchase_receipt_ledger": "procurement",
    "purchase_requisition_ledger": "procurement",
    "purchase_order_ledger": "procurement",
    "bill_of_materials": "technical_document",
    "approval_drawing": "technical_document",
    "engineering_drawing": "technical_document",
    "product_specification": "technical_document",
    "process_document": "technical_document",
    "service_policy": "technical_document",
    "product_photo": "technical_document",
    "presentation": "technical_document",
    "web_document": "technical_document",
    "image_document": "technical_document",
    "quotation": "commercial_document",
    "archive": "archive",
}

LINE_TARGET_VALUES = tuple(str(value) for value in get_args(LineTarget))
LINE_TARGET_SET = frozenset(LINE_TARGET_VALUES)


@dataclass(frozen=True, slots=True)
class LineTargetSpec:
    direct_field: str | None = None
    custom_key: str | None = None
    numeric: bool = False

    @property
    def storage_key(self) -> str:
        if self.direct_field:
            return f"field:{self.direct_field}"
        return f"custom:{self.custom_key}"


_ORDER_LINE_DIRECT_TARGETS = {
    "line_no",
    "model",
    "product_code",
    "name_raw",
    "specification_raw",
    "body_printing",
    "color",
    "quantity",
    "unit",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "carton_specification",
    "volume",
    "packaging_requirements",
    "origin",
    "remark",
}
_DIRECT_FIELDS = {
    target: LineTargetSpec(
        direct_field=target,
        numeric=target
        in {
            "quantity",
            "unit_price_tax_included",
            "amount_tax_included",
            "unit_price_tax_excluded",
            "amount_tax_excluded",
            "package_quantity",
            "piece_count",
            "volume",
        },
    )
    for target in _ORDER_LINE_DIRECT_TARGETS
}
_ALIAS_FIELDS = {
    "equipment_code": LineTargetSpec(direct_field="product_code"),
    "equipment_name": LineTargetSpec(direct_field="name_raw"),
    "mold_number": LineTargetSpec(direct_field="product_code"),
    "mold_name": LineTargetSpec(direct_field="name_raw"),
    "material_code": LineTargetSpec(direct_field="product_code"),
    "material_name": LineTargetSpec(direct_field="name_raw"),
    "technical_drawing_number": LineTargetSpec(direct_field="product_code"),
    "technical_product_name": LineTargetSpec(direct_field="name_raw"),
    "process_step": LineTargetSpec(direct_field="name_raw"),
    "requirement": LineTargetSpec(direct_field="specification_raw"),
    "parameter_name": LineTargetSpec(direct_field="name_raw"),
    "parameter_value": LineTargetSpec(direct_field="specification_raw"),
    "record_code": LineTargetSpec(direct_field="product_code"),
    "record_name": LineTargetSpec(direct_field="name_raw"),
    "description": LineTargetSpec(direct_field="specification_raw"),
}
_NUMERIC_CUSTOM_FIELDS = {
    "available_quantity",
    "reserved_quantity",
    "cavity_count",
    "unit_price",
    "amount",
    "record_value",
}
_CUSTOM_FIELDS = {
    target: LineTargetSpec(
        custom_key=target,
        numeric=target in _NUMERIC_CUSTOM_FIELDS,
    )
    for target in LINE_TARGET_VALUES
    if target not in _DIRECT_FIELDS and target not in _ALIAS_FIELDS
}
LINE_TARGET_SPECS = {**_DIRECT_FIELDS, **_ALIAS_FIELDS, **_CUSTOM_FIELDS}

_UNIVERSAL_TARGETS = frozenset(_DIRECT_FIELDS)
_DOMAIN_TARGETS: dict[str, frozenset[str]] = {
    "order": frozenset(
        {
            "customer_product_code",
            "customer_model",
            "supplier_product_code",
            "bom_number",
            "supplier_name",
            "customer_name",
            "purchase_order_number",
            "customer_order_number",
            "delivery_date",
            "status",
        }
    ),
    "inventory": frozenset(
        {
            "warehouse",
            "location",
            "status",
            "batch_number",
            "available_quantity",
            "reserved_quantity",
            "customer_product_code",
            "customer_model",
            "supplier_product_code",
            "bom_number",
            "material_code",
            "material_name",
            "unit_price",
            "amount",
        }
    ),
    "equipment": frozenset(
        {
            "equipment_code",
            "equipment_name",
            "asset_number",
            "manufacturer",
            "commissioned_date",
            "usage",
            "status",
            "location",
        }
    ),
    "mold": frozenset(
        {
            "mold_number",
            "mold_name",
            "cavity_count",
            "material",
            "status",
            "location",
            "technical_product_name",
        }
    ),
    "procurement": frozenset(
        {
            "material_code",
            "material_name",
            "supplier_name",
            "customer_name",
            "purchase_order_number",
            "receipt_number",
            "requisition_number",
            "supplier_delivery_number",
            "system_document_number",
            "customer_order_number",
            "document_date",
            "delivery_date",
            "suggested_date",
            "warehouse",
            "status",
            "unit_price",
            "amount",
        }
    ),
    "technical_document": frozenset(
        {
            "technical_drawing_number",
            "technical_product_name",
            "material",
            "process_step",
            "requirement",
            "parameter_name",
            "parameter_value",
            "status",
        }
    ),
    "unknown": frozenset(
        {
            "record_code",
            "record_name",
            "description",
            "record_date",
            "record_value",
            "status",
        }
    ),
}


def allowed_line_targets(document_type: str) -> frozenset[str]:
    domain = str(document_type or "unknown").casefold()
    if domain in {"commercial_document", "archive"}:
        domain = "unknown"
    return _UNIVERSAL_TARGETS | _DOMAIN_TARGETS.get(domain, _DOMAIN_TARGETS["unknown"])


_DOMAIN_SOURCE_LABEL_TARGETS: dict[str, LineTarget] = {
    "序号": "line_no",
    "项次": "line_no",
    "行号": "line_no",
    "item": "line_no",
    "line": "line_no",
    "lineno": "line_no",
    "linenumber": "line_no",
    "型号": "model",
    "工厂型号": "model",
    "产品型号": "model",
    "物料型号": "model",
    "商品型号": "model",
    "model": "model",
    "modelno": "model",
    "modelnumber": "model",
    "产品编码": "product_code",
    "产品编号": "product_code",
    "商品编码": "product_code",
    "货号": "product_code",
    "productcode": "product_code",
    "itemcode": "product_code",
    "code": "product_code",
    "sku": "product_code",
    "物料编码": "material_code",
    "物料代码": "material_code",
    "物料编号": "material_code",
    "材料编码": "material_code",
    "材料编号": "material_code",
    "料号": "material_code",
    "materialcode": "material_code",
    "partnumber": "material_code",
    "仓库": "warehouse",
    "仓库名称": "warehouse",
    "库位": "location",
    "库位名称": "location",
    "客户料号": "customer_product_code",
    "客户物料号": "customer_product_code",
    "客户型号": "customer_model",
    "供应商料号": "supplier_product_code",
    "bom单号": "bom_number",
    "bom编号": "bom_number",
    "货物": "name_raw",
    "产品": "name_raw",
    "物料名称": "name_raw",
    "材料名称": "material_name",
    "原材料名称": "material_name",
    "产品名称": "name_raw",
    "商品名称": "name_raw",
    "品名": "name_raw",
    "名称": "name_raw",
    "materialname": "name_raw",
    "description": "name_raw",
    "productname": "name_raw",
    "itemname": "name_raw",
    "规格型号": "specification_raw",
    "型号规格": "specification_raw",
    "规格": "specification_raw",
    "specification": "specification_raw",
    "spec": "specification_raw",
    "设备编号": "asset_number",
    "设备编码": "equipment_code",
    "资产编号": "asset_number",
    "资产编码": "asset_number",
    "设备名称": "equipment_name",
    "设备型号": "model",
    "生产厂家": "manufacturer",
    "制造商": "manufacturer",
    "投产日期": "commissioned_date",
    "启用日期": "commissioned_date",
    "设备状态": "status",
    "设备状况": "status",
    "使用状态": "status",
    "用途": "usage",
    "模号": "mold_number",
    "模具编号": "mold_number",
    "模具编码": "mold_number",
    "外模": "mold_name",
    "内模": "mold_name",
    "模型": "mold_name",
    "模具名称": "mold_name",
    "外模类型": "mold_name",
    "型腔数": "cavity_count",
    "穴数": "cavity_count",
    "单位": "unit",
    "计量单位": "unit",
    "unit": "unit",
    "uom": "unit",
    "数量": "quantity",
    "实际用量": "quantity",
    "单位用量": "quantity",
    "单耗": "quantity",
    "用量": "quantity",
    "备货数量": "quantity",
    "需求数量": "quantity",
    "订购数量": "quantity",
    "采购数量": "quantity",
    "订单数量": "quantity",
    "quantity": "quantity",
    "qty": "quantity",
    "即时库存数量": "available_quantity",
    "库存数量": "available_quantity",
    "当前库存数量": "available_quantity",
    "现有库存数量": "available_quantity",
    "可用库存数量": "available_quantity",
    "可用数量": "available_quantity",
    "availablequantity": "available_quantity",
    "availableqty": "available_quantity",
    "onhandquantity": "available_quantity",
    "onhandqty": "available_quantity",
    "stockquantity": "available_quantity",
    "预留数量": "reserved_quantity",
    "reservedquantity": "reserved_quantity",
    "reservedqty": "reserved_quantity",
    "装箱数量": "package_quantity",
    "包装数量": "package_quantity",
    "每箱数量": "package_quantity",
    "件数": "piece_count",
    "箱数": "piece_count",
    "箱规": "carton_specification",
    "箱规cm": "carton_specification",
    "纸箱规格": "carton_specification",
    "单价": "unit_price_tax_excluded",
    "材料单价": "unit_price_tax_excluded",
    "含税单价": "unit_price_tax_included",
    "未税单价": "unit_price_tax_excluded",
    "unitprice": "unit_price_tax_excluded",
    "金额": "amount_tax_excluded",
    "成本": "amount_tax_excluded",
    "成本价格(元)": "amount_tax_excluded",
    "合计金额": "amount_tax_excluded",
    "含税金额": "amount_tax_included",
    "未税金额": "amount_tax_excluded",
    "amount": "amount_tax_excluded",
    "线身印字": "body_printing",
    "线材印字": "body_printing",
    "印字": "body_printing",
    "颜色": "color",
    "包装要求": "packaging_requirements",
    "包装方式": "packaging_requirements",
    "包装说明": "packaging_requirements",
    "备注": "remark",
    "remark": "remark",
    "note": "remark",
}
_SOURCE_LABEL_TARGETS: dict[str, str] = {
    **ORDER_LINE_ALIAS_LOOKUP,
    **{
        normalize_line_header_label(label): target
        for label, target in _DOMAIN_SOURCE_LABEL_TARGETS.items()
    },
}


def source_label_line_target(
    source_label: str,
    document_type: str,
) -> str | None:
    """Resolve only stable schema vocabulary; unknown labels remain model-routed."""

    target = resolve_line_header_alias(source_label, _SOURCE_LABEL_TARGETS)
    if document_type.casefold() == "order":
        target = {
            "material_code": "product_code",
            "material_name": "name_raw",
        }.get(str(target), target)
    if target not in LINE_TARGET_SET or target not in allowed_line_targets(
        document_type
    ):
        return None
    return str(target)


def target_storage_key(target: str) -> str | None:
    spec = LINE_TARGET_SPECS.get(target)
    return spec.storage_key if spec else None


def target_direct_field(target: str) -> str | None:
    """Return the compatible DocumentRecord line field for a semantic target."""

    spec = LINE_TARGET_SPECS.get(target)
    return spec.direct_field if spec else None


def parse_number(value: Any) -> Decimal | None:
    token = unicodedata.normalize("NFKC", str(value or "")).strip()
    token = re.sub(r"(?i)(?:rmb|cny|usd|eur)", "", token)
    token = re.sub(r"[,$￥¥€\s]", "", token)
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)", token):
        return None
    try:
        return Decimal(token)
    except InvalidOperation:
        return None


def replay_line_value(line: OrderLine, target: str, raw_value: Any) -> tuple[str, Any] | None:
    """Write one allow-listed value and return its relative metadata path."""

    spec = LINE_TARGET_SPECS.get(target)
    if spec is None:
        return None
    text = unicodedata.normalize("NFKC", str(raw_value or "")).strip()
    if not text:
        return None
    value: Any = parse_number(text) if spec.numeric else text
    if spec.numeric and value is None:
        return None
    if spec.direct_field == "line_no":
        number = parse_number(text)
        if number is not None and number == number.to_integral_value():
            value = int(number)
    if spec.direct_field:
        setattr(line, spec.direct_field, value)
        return spec.direct_field, value
    if not spec.custom_key:  # pragma: no cover - registry invariant
        return None
    line.custom_fields[spec.custom_key] = value
    return f"custom_fields.{spec.custom_key}", value


def mapping_path(prefix: str, container: str, key: str) -> str:
    encoded = json.dumps(str(key), ensure_ascii=False)
    return f"{prefix}.{container}[{encoded}]"


def _mapping_leaf_paths(prefix: str, value: Any) -> set[str]:
    """Return exact JSON-style paths for meaningful mapping leaves."""

    if isinstance(value, Mapping):
        paths: set[str] = set()
        for key, nested in value.items():
            encoded = json.dumps(str(key), ensure_ascii=False)
            paths.update(_mapping_leaf_paths(f"{prefix}[{encoded}]", nested))
        return paths
    return {prefix} if _meaningful(value) else set()


def _meaningful(value: Any) -> bool:
    if value in (None, "", [], {}):
        return False
    if isinstance(value, dict):
        return any(_meaningful(item) for item in value.values())
    return True


@dataclass(frozen=True, slots=True)
class LineBusinessPayloadAssessment:
    meaningful_business_payload: bool
    provably_structural: bool
    structural_kind: str | None = None
    strong_business_payload: bool = False


_DIRECT_BUSINESS_IDENTITY_FIELDS = frozenset(
    {"model", "product_code", "name_raw", "specification_raw"}
)
_CUSTOM_BUSINESS_IDENTITY_TARGETS = frozenset(
    {"asset_number", "batch_number", "bom_number", "customer_model", "customer_order_number",
     "customer_product_code", "purchase_order_number", "receipt_number", "record_code",
     "record_name", "requisition_number", "supplier_delivery_number",
     "supplier_product_code", "system_document_number"}
)
_BUSINESS_IDENTITY_TARGETS = frozenset(
    target
    for target, spec in LINE_TARGET_SPECS.items()
    if spec.direct_field in _DIRECT_BUSINESS_IDENTITY_FIELDS
) | _CUSTOM_BUSINESS_IDENTITY_TARGETS
_STRONG_BUSINESS_IDENTITY_TARGETS = _BUSINESS_IDENTITY_TARGETS - {
    "name_raw",
    "specification_raw",
    "record_name",
}
_BUSINESS_SUPPORT_TARGETS = frozenset(
    {
        "amount",
        "amount_tax_excluded",
        "amount_tax_included",
        "available_quantity",
        "cavity_count",
        "commissioned_date",
        "delivery_date",
        "document_date",
        "location",
        "package_quantity",
        "piece_count",
        "quantity",
        "record_date",
        "record_value",
        "reserved_quantity",
        "status",
        "suggested_date",
        "unit",
        "unit_price",
        "unit_price_tax_excluded",
        "unit_price_tax_included",
        "volume",
        "warehouse",
    }
)
_NON_CONTENT_LINE_FIELDS = frozenset({"line_id", "line_no", "name_attributes", "custom_fields", "raw_columns"})
_PLACEHOLDER_VALUES = frozenset(
    {"-", "--", "---", "/", "\\", "n/a", "na", "none", "null",
     "not applicable", "\u65e0", "\u6682\u65e0", "\u672a\u586b", "\u672a\u586b\u5199", "\u5f85\u5b9a"}
)
_TOTAL_MARKERS = frozenset(
    {"\u5408\u8ba1", "\u603b\u8ba1", "\u5c0f\u8ba1", "\u5408\u8ba1\u6570\u91cf", "\u6570\u91cf\u5408\u8ba1", "\u603b\u6570\u91cf",
     "\u603b\u4ef6\u6570", "\u5408\u8ba1\u91d1\u989d", "\u91d1\u989d\u5408\u8ba1", "total", "subtotal",
     "grandtotal", "totalamount", "totalquantity"}
)
_NOTE_MARKERS = frozenset({"\u6ce8", "\u5907\u6ce8", "\u8bf4\u660e", "\u9644\u6ce8", "note", "notes", "remark", "remarks"})
@dataclass(frozen=True, slots=True)
class _LinePayloadEntry:
    container: str
    key: str
    value: Any
    target: str | None


def _marker_token(value: Any) -> str:
    normalized = unicodedata.normalize("NFKC", str(value or "")).casefold().strip()
    return re.sub(r"[\s_:：;；,.，。()（）\[\]【】]+", "", normalized)


def _is_placeholder(value: Any) -> bool:
    return isinstance(value, str) and (
        unicodedata.normalize("NFKC", value).casefold().strip()
        in _PLACEHOLDER_VALUES
    )


def _leaf_values(value: Any) -> Iterable[Any]:
    if isinstance(value, Mapping):
        for nested in value.values():
            yield from _leaf_values(nested)
        return
    if isinstance(value, (list, tuple, set, frozenset)):
        for nested in value:
            yield from _leaf_values(nested)
        return
    yield value


def _line_payload_entries(
    line: OrderLine | Mapping[str, Any],
    domain: str,
) -> tuple[list[_LinePayloadEntry], bool]:
    payload = (
        line.model_dump(mode="python")
        if isinstance(line, OrderLine)
        else dict(line)
    )
    entries: list[_LinePayloadEntry] = []
    for key, value in payload.items():
        if key in _NON_CONTENT_LINE_FIELDS or key in {"image_refs", "remark"}:
            continue
        if _meaningful(value):
            entries.append(_LinePayloadEntry("direct", str(key), value, str(key)))
    if _meaningful(payload.get("remark")):
        entries.append(_LinePayloadEntry("direct", "remark", payload["remark"], "remark"))
    for container in ("custom_fields", "raw_columns"):
        values = payload.get(container)
        if not isinstance(values, Mapping):
            continue
        for key, value in values.items():
            if _meaningful(value):
                text_key = str(key)
                entries.append(
                    _LinePayloadEntry(
                        container,
                        text_key,
                        value,
                        text_key
                        if text_key in LINE_TARGET_SET
                        else source_label_line_target(text_key, domain),
                    )
                )
    has_images = bool(payload.get("image_refs"))
    return entries, has_images


def _entry_has_business_identity(entry: _LinePayloadEntry) -> bool:
    has_real_value = any(
        _meaningful(value)
        and not _is_placeholder(value)
        and (
            entry.target in _STRONG_BUSINESS_IDENTITY_TARGETS
            or _marker_token(value) not in _TOTAL_MARKERS | _NOTE_MARKERS
        )
        for value in _leaf_values(entry.value)
    )
    # Unknown source columns are deliberately retained as possible business
    # identity. A known quantity/status/remark field cannot establish identity.
    return has_real_value and (
        (entry.container == "direct" and entry.key in _DIRECT_BUSINESS_IDENTITY_FIELDS)
        or (entry.container == "direct" and entry.target in _BUSINESS_IDENTITY_TARGETS)
        or (
            entry.container == "direct"
            and entry.target not in LINE_TARGET_SET
            and _marker_token(entry.key) not in _TOTAL_MARKERS | _NOTE_MARKERS
        )
        or (entry.container != "direct" and entry.target in _BUSINESS_IDENTITY_TARGETS)
        or (
            entry.container != "direct"
            and entry.target is None
            and _marker_token(entry.key) not in _TOTAL_MARKERS | _NOTE_MARKERS
        )
    )


def _entry_has_real_target(
    entry: _LinePayloadEntry,
    targets: frozenset[str],
) -> bool:
    return entry.target in targets and any(
        _meaningful(value) and not _is_placeholder(value)
        for value in _leaf_values(entry.value)
    )


def _numeric_like(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    token = re.sub(r"(?i)(?:rmb|cny|usd|eur)", "", str(value or ""))
    return parse_number(token.strip("$\u00a5\uffe5 ")) is not None


def _is_proven_total(entries: list[_LinePayloadEntry]) -> bool:
    marker_found = any(
        _marker_token(entry.key) in _TOTAL_MARKERS
        or any(_marker_token(value) in _TOTAL_MARKERS for value in _leaf_values(entry.value))
        for entry in entries
    )
    if not marker_found:
        return False
    if any(
        entry.target in _STRONG_BUSINESS_IDENTITY_TARGETS
        and any(_meaningful(value) and not _is_placeholder(value) for value in _leaf_values(entry.value))
        for entry in entries
    ):
        return False
    for entry in entries:
        for value in _leaf_values(entry.value):
            if not _meaningful(value) or _is_placeholder(value):
                continue
            if _marker_token(value) in _TOTAL_MARKERS:
                continue
            if entry.target in _BUSINESS_IDENTITY_TARGETS:
                return False
            if _numeric_like(value):
                continue
            if entry.target == "unit" and len(str(value).strip()) <= 12:
                continue
            return False
    return True


def _is_proven_note(entries: list[_LinePayloadEntry]) -> bool:
    marker_found = any(
        _marker_token(entry.key) in _NOTE_MARKERS
        or any(_marker_token(value) in _NOTE_MARKERS for value in _leaf_values(entry.value))
        for entry in entries
    )
    if not marker_found:
        return False
    # A note marker elsewhere cannot turn an independent raw/custom fact,
    # product identity, quantity, or status into a disposable note row.
    return all(
        _marker_token(entry.key) in _NOTE_MARKERS
        or entry.target == "remark"
        or (
            (values := [
                value
                for value in _leaf_values(entry.value)
                if _meaningful(value) and not _is_placeholder(value)
            ])
            and all(_marker_token(value) in _NOTE_MARKERS for value in values)
        )
        for entry in entries
    )


def classify_line_business_payload(
    line: OrderLine | Mapping[str, Any],
    *,
    document_type: str = "unknown",
    structural_issue_codes: Iterable[str] = (),
) -> LineBusinessPayloadAssessment:
    """Keep unknown business payload reviewable; delete only proven structure."""

    # Kept in the signature for callers carrying legacy validation output.
    # Issue labels alone never authorize deletion; the retained values must
    # independently prove that the row is structural.
    del structural_issue_codes
    domain = str(document_type or "unknown").casefold()
    entries, has_images = _line_payload_entries(line, domain)
    leaf_values = [
        value
        for entry in entries
        for value in _leaf_values(entry.value)
        if _meaningful(value)
    ]
    if not leaf_values and not has_images:
        return LineBusinessPayloadAssessment(False, True, "empty")
    if leaf_values and all(_is_placeholder(value) for value in leaf_values) and not has_images:
        return LineBusinessPayloadAssessment(False, True, "placeholder")
    if has_images:
        return LineBusinessPayloadAssessment(
            True,
            False,
            strong_business_payload=True,
        )
    if _is_proven_total(entries):
        return LineBusinessPayloadAssessment(False, True, "total")
    if _is_proven_note(entries):
        return LineBusinessPayloadAssessment(False, True, "note")

    meaningful_business_payload = any(
        _entry_has_business_identity(entry) for entry in entries
    )
    if meaningful_business_payload:
        strong_identity = any(
            _entry_has_real_target(entry, _STRONG_BUSINESS_IDENTITY_TARGETS)
            for entry in entries
        )
        supporting_fact = any(
            _entry_has_real_target(entry, _BUSINESS_SUPPORT_TARGETS)
            for entry in entries
        )
        return LineBusinessPayloadAssessment(
            True,
            False,
            strong_business_payload=strong_identity or supporting_fact,
        )
    return LineBusinessPayloadAssessment(False, False)


_MOLD_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/+\-']{0,63}$")


def has_mold_identifier_shape(value: Any) -> bool:
    """Return whether a value has the lexical shape of a business identifier."""

    token = unicodedata.normalize("NFKC", str(value or "")).strip()
    return bool(token and _MOLD_IDENTIFIER_RE.fullmatch(token))


def mold_identifier_validation_issues(
    document: DocumentRecord,
) -> list[ValidationIssue]:
    """Flag narrative mold identifiers without modifying the retained source value."""

    if str(document.document_type or "unknown").casefold() != "mold":
        return []
    existing_paths = {
        tuple(issue.paths)
        for issue in document.validation_issues
        if issue.code == "MOLD_IDENTIFIER_AMBIGUOUS"
    }
    issues: list[ValidationIssue] = []
    for index, line in enumerate(document.lines):
        value = line.product_code
        if not _meaningful(value) or has_mold_identifier_shape(value):
            continue
        path = f"$.lines[{index}].product_code"
        if (path,) in existing_paths:
            continue
        metadata = document.field_meta.get(path)
        issues.append(
            ValidationIssue(
                code="MOLD_IDENTIFIER_AMBIGUOUS",
                severity="warning",
                message="模号列中的值更像自然语言说明，已原样保留并等待复核。",
                paths=[path],
                source_refs=list(metadata.source_refs) if metadata else [],
                actual=value,
                suggestion="请确认该值是合法模号、库位说明还是缺失编号。",
            )
        )
    return issues


def evidence_fact_paths(document: DocumentRecord) -> set[str]:
    """Return every source-derived fact that must carry positioned evidence."""

    paths: set[str] = set()
    if document.document_type not in {"", "unknown"}:
        paths.add("$.document_type")
    if document.document_subtype not in {"", "unknown"}:
        paths.add("$.document_subtype")
    if document.document_kind_label not in {None, "", "unknown"}:
        paths.add("$.document_kind_label")
    for index, fact in enumerate(document.generic_facts):
        if _meaningful(fact.value):
            paths.add(f"$.generic_facts[{index}].value")

    header = document.header.model_dump(mode="python")
    for field, value in header.items():
        if field in {"candidate_numbers", "date_inferred"} or not _meaningful(value):
            continue
        paths.add(f"$.header.{field}")

    direct_excluded = {"line_id", "image_refs", "custom_fields", "raw_columns"}
    for index, line in enumerate(document.lines):
        payload = line.model_dump(mode="python")
        prefix = f"$.lines[{index}]"
        for field, value in payload.items():
            if field in direct_excluded or not _meaningful(value):
                continue
            # Derived attributes are cited as one reproducible value rather
            # than requiring a separate locator for every nested attribute.
            paths.add(f"{prefix}.{field}")
        for container in ("custom_fields", "raw_columns"):
            values = payload.get(container)
            if not isinstance(values, dict):
                continue
            for key, value in values.items():
                if _meaningful(value):
                    paths.update(
                        _mapping_leaf_paths(
                            mapping_path(prefix, container, str(key)),
                            value,
                        )
                    )

    totals = document.totals.model_dump(mode="python")
    for field in ("declared_quantity", "declared_amount"):
        if _meaningful(totals.get(field)):
            paths.add(f"$.totals.{field}")
    source_declared = totals.get("source_declared")
    if isinstance(source_declared, dict):
        for key, value in source_declared.items():
            if _meaningful(value):
                paths.add(mapping_path("$.totals", "source_declared", str(key)))
    return paths


def domain_minimum_failures(document: DocumentRecord) -> tuple[list[str], set[str]]:
    """Validate the minimum useful facts for each authority domain."""

    domain = str(document.document_type or "unknown").casefold()
    reasons: list[str] = []
    invalid: set[str] = set()
    record_domains = {"order", "inventory", "equipment", "mold", "procurement"}
    if domain in record_domains and not document.lines:
        reasons.append(f"missing_{domain}_records")
    if domain == "order" and not (
        document.header.order_number or document.header.contract_number
    ):
        reasons.append("missing_order_identifier")

    quantity_domains = {"order", "procurement"}

    for index, line in enumerate(document.lines):
        prefix = f"$.lines[{index}]"
        structural_issue_codes = (
            issue.code
            for issue in document.validation_issues
            if prefix in issue.paths
        )
        assessment = classify_line_business_payload(
            line,
            document_type=domain,
            structural_issue_codes=structural_issue_codes,
        )
        if domain in record_domains and not assessment.meaningful_business_payload:
            invalid.add(prefix)
        if domain in quantity_domains:
            for field in ("quantity", "unit"):
                if not _meaningful(getattr(line, field)):
                    invalid.add(f"{prefix}.{field}")
        elif domain == "inventory":
            inventory_quantity = (
                line.quantity,
                line.custom_fields.get("available_quantity"),
                line.custom_fields.get("reserved_quantity"),
            )
            if not any(_meaningful(value) for value in inventory_quantity):
                invalid.add(f"{prefix}.quantity")
                invalid.add(mapping_path(prefix, "custom_fields", "available_quantity"))
            if not _meaningful(line.unit):
                invalid.add(f"{prefix}.unit")
    if invalid:
        reasons.append("invalid_domain_records")

    raw_content = document.extraction.get("raw_content")
    raw_text = raw_content.get("text_original") if isinstance(raw_content, dict) else ""
    if (
        domain in {"technical_document", "commercial_document", "archive", "unknown"}
        and not str(raw_text or "").strip()
        and not document.lines
    ):
        reasons.append("empty_mineru_content")
    return reasons, invalid


def mapper_domain_instructions() -> str:
    groups = {
        domain: sorted(targets - _UNIVERSAL_TARGETS)
        for domain, targets in _DOMAIN_TARGETS.items()
    }
    return (
        "Map table columns with the common targets "
        f"{', '.join(sorted(_UNIVERSAL_TARGETS))}. Domain-specific targets are "
        f"{json.dumps(groups, ensure_ascii=False, separators=(',', ':'))}. "
        "For unfamiliar tables use record_code, record_name, description, "
        "record_date, record_value, status, quantity, unit, or remark; all "
        "unmapped source columns are retained losslessly with cell evidence."
    )


__all__ = [
    "CANONICAL_SUBTYPE_TYPES",
    "LINE_TARGET_SET",
    "LINE_TARGET_SPECS",
    "LINE_TARGET_VALUES",
    "DocumentSubtype",
    "DocumentType",
    "FactTarget",
    "LineBusinessPayloadAssessment",
    "LineTarget",
    "allowed_line_targets",
    "classify_line_business_payload",
    "domain_minimum_failures",
    "evidence_fact_paths",
    "has_mold_identifier_shape",
    "mapper_domain_instructions",
    "mapping_path",
    "mold_identifier_validation_issues",
    "parse_number",
    "replay_line_value",
    "source_label_line_target",
    "target_storage_key",
]
