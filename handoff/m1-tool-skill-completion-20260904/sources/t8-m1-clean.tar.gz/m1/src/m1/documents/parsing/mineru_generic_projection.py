"""Evidence-only projection for document types without a dedicated business schema."""

from __future__ import annotations

import copy
import json
import re
from typing import Any

from .evidence import DocumentEvidence
from .mineru_instructor_poc import (
    OPEN_DOMAIN_DOCUMENT_SUBTYPES,
    MinerUInstructorResult,
    evidence_inventory,
)
from .mineru_regions import assess_record_regions, is_revision_history_table

_TECHNICAL_DOCUMENT_TYPE = "technical_document"


def _native_locator(model_extra: dict[str, Any]) -> str | None:
    candidates: list[Any] = [
        model_extra.get("native_part"),
        model_extra.get("source_ref_part"),
        model_extra.get("source_id"),
    ]
    for reference in model_extra.get("native_source_refs") or []:
        if isinstance(reference, dict):
            candidates.extend(
                [
                    reference.get("native_part"),
                    reference.get("part"),
                    reference.get("source_id"),
                ]
            )
    for candidate in candidates:
        value = str(candidate or "").strip()
        if (
            value
            and len(value) <= 1024
            and not any(ord(character) < 32 for character in value)
        ):
            return value
    return None


def _native_locator_index(evidence: DocumentEvidence | None) -> dict[str, str]:
    if evidence is None:
        return {}
    locators: dict[str, str] = {}
    for page in evidence.pages:
        for block in page.blocks:
            locator = _native_locator(block.model_extra or {})
            if locator is not None:
                locators[block.block_id] = locator
        for table in page.tables:
            for cell in table.cells:
                locator = _native_locator(cell.model_extra or {})
                if locator is not None:
                    locators[f"{table.table_id}:r{cell.row}:c{cell.column}"] = locator
    return locators


def _quoted_source_ref(
    source_ref: Any,
    *,
    evidence_id: str,
    exact_text: str,
    native_part: str | None = None,
) -> dict[str, Any]:
    payload = source_ref.model_dump(mode="json", exclude_none=True)
    payload.setdefault("evidence_id", evidence_id)
    payload.setdefault("evidence_quote", exact_text)
    if native_part is not None:
        payload.setdefault("native_part", native_part)
    return payload


def content_fact_payloads(
    extracted: MinerUInstructorResult,
    *,
    evidence: DocumentEvidence | None = None,
    excluded_evidence_ids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Expose exact undedicated content without converting it into business fields."""

    if (
        extracted.document_subtype not in OPEN_DOMAIN_DOCUMENT_SUBTYPES
        and extracted.document_intent_family != _TECHNICAL_DOCUMENT_TYPE
    ):
        return []
    dedicated_ids = set(excluded_evidence_ids or ())
    for fact in [
        *extracted.document_facts,
        *extracted.generic_facts,
        *(fact for segment in extracted.segments for fact in segment.facts),
        *(
            fact
            for segment in extracted.segments
            for record in segment.records
            for fact in record.fields
        ),
    ]:
        dedicated_ids.update(reference.evidence_id for reference in fact.evidence_refs)
    native_locators = _native_locator_index(evidence)
    payloads: list[dict[str, Any]] = []
    for unit in extracted.content_units:
        if unit.evidence_id in dedicated_ids:
            continue
        exact_text = str(unit.exact_text or "").strip()
        if not exact_text:
            continue
        content_kind = (
            re.sub(
                r"[^a-z0-9]+",
                "_",
                str(unit.content_kind or "content").casefold(),
            ).strip("_")
            or "content"
        )
        advisory = extracted.document_subtype == "product_photo"
        source_ref = _quoted_source_ref(
            unit.source_ref,
            evidence_id=unit.evidence_id,
            exact_text=exact_text,
            native_part=native_locators.get(unit.evidence_id),
        )
        if advisory:
            source_ref = copy.deepcopy(source_ref)
            source_ref.update({"authority": "advisory", "inferred": True})
        fact_name = (
            "visual_description"
            if advisory
            and str(unit.source_kind or "").casefold() in {"image", "figure"}
            else f"content_{content_kind}"[:128]
        )
        payloads.append(
            {
                "name": fact_name,
                "value": exact_text,
                "source_refs": [source_ref],
                "sensitive": False,
                "evidence_id": unit.evidence_id,
                "content_kind": unit.content_kind,
                "label": unit.label,
                "binding_source": unit.binding_source,
                "authority": "advisory" if advisory else "source",
                "inferred": advisory,
            }
        )
    return payloads


def _lossless_key(target: dict[str, Any], label: str) -> str:
    base = str(label or "column").strip() or "column"
    if base not in target:
        return base
    index = 2
    while f"{base} [{index}]" in target:
        index += 1
    return f"{base} [{index}]"


def _text(value: Any) -> str:
    return str(value or "").strip()


def _axis_values(table: Any, orientation: str) -> list[list[str]]:
    if orientation == "rows":
        return [[_text(value) for value in row] for row in table.rows]
    width = max((len(row) for row in table.rows), default=0)
    return [
        [
            _text(table.rows[row][column]) if column < len(table.rows[row]) else ""
            for row in range(len(table.rows))
        ]
        for column in range(width)
    ]


def _cell_evidence_id(
    table_id: str,
    *,
    orientation: str,
    axis_index: int,
    field_axis: int,
) -> str:
    row, column = (
        (axis_index, field_axis) if orientation == "rows" else (field_axis, axis_index)
    )
    return f"{table_id}:r{row}:c{column}"


def _key_label(value: str) -> bool:
    if not 2 <= len(value) <= 64:
        return False
    if not any(
        character.isalpha() or "\u3400" <= character <= "\u9fff" for character in value
    ):
        return False
    if re.fullmatch(r"[+-]?\d+(?:[.,]\d+)?(?:\s*[%a-z]+)?", value, re.IGNORECASE):
        return False
    return re.fullmatch(r"[A-Za-z]+[-_/.]?\d+[A-Za-z0-9._/-]*", value) is None


def _key_value_records(
    axes: list[list[str]],
) -> list[tuple[int, int, str, str]]:
    """Recognize alternating label/value pairs without a vocabulary rule."""

    width = max((len(axis) for axis in axes), default=0)
    if width < 2 or width % 2:
        return []
    records: list[tuple[int, int, str, str]] = []
    nonempty_cell_count = 0
    labels: set[str] = set()
    for axis_index, axis in enumerate(axes):
        nonempty_cell_count += sum(bool(value) for value in axis)
        for pair_index, field_axis in enumerate(range(0, width, 2)):
            label = axis[field_axis] if field_axis < len(axis) else ""
            value = axis[field_axis + 1] if field_axis + 1 < len(axis) else ""
            if not label and not value:
                continue
            if not label or not value or not _key_label(label):
                return []
            labels.add(label.casefold())
            records.append((axis_index, pair_index, label, value))
    if len(records) < 2 or len(labels) < 2 or len(records) * 2 != nonempty_cell_count:
        return []
    return records


def _likely_header_axis(axes: list[list[str]]) -> int | None:
    nonempty_axes = [
        index for index, axis in enumerate(axes) if any(value for value in axis)
    ]
    for axis_index in nonempty_axes[:3]:
        values = [value for value in axes[axis_index] if value]
        if len(values) < 2 or not all(_key_label(value) for value in values):
            continue
        if any(index > axis_index for index in nonempty_axes):
            return axis_index
    return None


def _regions_for_table(assessment: Any, table_id: str) -> list[Any]:
    return [
        region for region in assessment.record_regions if region.table_id == table_id
    ]


def _record_binding(
    *,
    orientation: str,
    axis_index: int,
    regions: list[Any],
) -> dict[str, Any]:
    return {
        "orientation": orientation,
        "axis_index": axis_index,
        "region_ids": [
            region.region_id
            for region in regions
            if region.orientation == orientation
            and region.data_start <= axis_index <= region.data_end
        ],
    }


def table_fact_payloads(
    evidence: DocumentEvidence,
    *,
    document_type: str | None = None,
    document_subtype: str | None,
    primary_table_ids: list[str] | tuple[str, ...] | set[str] = (),
) -> list[dict[str, Any]]:
    """Project open-domain or auxiliary technical tables as exact generic facts."""

    open_domain = document_subtype in OPEN_DOMAIN_DOCUMENT_SUBTYPES
    technical = document_type == _TECHNICAL_DOCUMENT_TYPE
    if not open_domain and not technical:
        return []
    excluded_table_ids = set() if open_domain else set(primary_table_ids)
    inventory = evidence_inventory(evidence)
    native_locators = _native_locator_index(evidence)
    assessment = assess_record_regions(evidence)

    def source_ref(evidence_id: str) -> dict[str, Any] | None:
        item = inventory.get(evidence_id)
        if item is None:
            return None
        return _quoted_source_ref(
            item.source_ref,
            evidence_id=item.evidence_id,
            exact_text=item.exact_text or item.text,
            native_part=native_locators.get(item.evidence_id),
        )

    def unique_refs(values: list[dict[str, Any] | None]) -> list[dict[str, Any]]:
        refs: list[dict[str, Any]] = []
        seen: set[str] = set()
        for value in values:
            if value is None:
                continue
            marker = json.dumps(
                value,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
            if marker in seen:
                continue
            seen.add(marker)
            refs.append(copy.deepcopy(value))
        return refs

    payloads: list[dict[str, Any]] = []
    for page in evidence.pages:
        for table in page.tables:
            if table.table_id in excluded_table_ids:
                continue
            regions = _regions_for_table(assessment, table.table_id)
            orientations = {region.orientation for region in regions}
            orientation = next(iter(orientations)) if len(orientations) == 1 else "rows"
            axes = _axis_values(table, orientation)
            width = max((len(axis) for axis in axes), default=0)
            nonempty_axes = [
                index for index, axis in enumerate(axes) if any(value for value in axis)
            ]
            if width == 0 or not nonempty_axes:
                continue
            role = "open_domain" if open_domain else "auxiliary_technical"

            header_index: int | None = None
            if regions:
                candidate = min(region.data_start for region in regions) - 1
                if (
                    candidate >= 0
                    and sum(bool(value) for value in axes[candidate]) >= 2
                ):
                    header_index = candidate
            if header_index is None:
                header_index = _likely_header_axis(axes)
            key_value_records = (
                _key_value_records(axes)
                if orientation == "rows" and header_index is None
                else []
            )
            if is_revision_history_table(table):
                header_index = next(
                    (
                        index
                        for index in nonempty_axes[:3]
                        if len([value for value in axes[index] if value]) >= 3
                    ),
                    header_index,
                )

            if key_value_records:
                schema_refs = unique_refs(
                    [
                        source_ref(
                            _cell_evidence_id(
                                table.table_id,
                                orientation="rows",
                                axis_index=axis_index,
                                field_axis=pair_index * 2,
                            )
                        )
                        for axis_index, pair_index, _label, _value in key_value_records
                    ]
                )
                if not schema_refs:
                    continue
                payloads.append(
                    {
                        "name": "table_schema",
                        "value": {
                            "table_id": table.table_id,
                            "orientation": "rows",
                            "layout": "key_value",
                            "columns": [
                                {"name": "field", "source_axes": [1]},
                                {"name": "value", "source_axes": [2]},
                            ],
                        },
                        "source_refs": schema_refs,
                        "sensitive": False,
                        "table_id": table.table_id,
                        "page": page.page_number,
                        "projection_role": role,
                        "inferred": True,
                    }
                )
                for axis_index, pair_index, label, value in key_value_records:
                    label_ref = source_ref(
                        _cell_evidence_id(
                            table.table_id,
                            orientation="rows",
                            axis_index=axis_index,
                            field_axis=pair_index * 2,
                        )
                    )
                    value_ref = source_ref(
                        _cell_evidence_id(
                            table.table_id,
                            orientation="rows",
                            axis_index=axis_index,
                            field_axis=pair_index * 2 + 1,
                        )
                    )
                    record_refs = unique_refs([label_ref, value_ref])
                    if len(record_refs) < 2:
                        continue
                    payloads.append(
                        {
                            "name": "table_record",
                            "value": {"field": label, "value": value},
                            "source_refs": record_refs,
                            "sensitive": False,
                            "table_id": table.table_id,
                            "page": page.page_number,
                            "row_index": axis_index,
                            "pair_index": pair_index,
                            "field_source_refs": {
                                "field": unique_refs([label_ref]),
                                "value": unique_refs([value_ref]),
                            },
                            "record_binding": _record_binding(
                                orientation="rows",
                                axis_index=axis_index,
                                regions=regions,
                            ),
                            "projection_role": role,
                        }
                    )
                continue

            has_semantic_header = header_index is not None
            header = (
                list(axes[header_index])
                if header_index is not None
                else [f"column_{index + 1}" for index in range(width)]
            )
            header += [""] * max(0, width - len(header))
            starts = [index for index, value in enumerate(header[:width]) if value]
            if not has_semantic_header:
                starts = list(range(width))
            data_axes = [index for index in nonempty_axes if index != header_index]

            columns: list[tuple[str, range]] = []
            used_names: dict[str, Any] = {}
            for position, start in enumerate(starts):
                end = starts[position + 1] if position + 1 < len(starts) else width
                label = header[start] or f"column_{start + 1}"
                key = _lossless_key(used_names, label)
                used_names[key] = True
                columns.append((key, range(start, end)))

            schema_source_axis = (
                header_index if header_index is not None else nonempty_axes[0]
            )
            header_refs = unique_refs(
                [
                    source_ref(
                        _cell_evidence_id(
                            table.table_id,
                            orientation=orientation,
                            axis_index=schema_source_axis,
                            field_axis=column,
                        )
                    )
                    for column in (starts if has_semantic_header else range(width))
                ]
            )
            if not header_refs:
                continue
            payloads.append(
                {
                    "name": "table_schema",
                    "value": {
                        "table_id": table.table_id,
                        "orientation": orientation,
                        "layout": "header_records" if has_semantic_header else "matrix",
                        "columns": [
                            {
                                "name": name,
                                "source_axes": [index + 1 for index in indices],
                                **(
                                    {"source_columns": [index + 1 for index in indices]}
                                    if orientation == "rows"
                                    else {
                                        "source_rows": [index + 1 for index in indices]
                                    }
                                ),
                            }
                            for name, indices in columns
                        ],
                    },
                    "source_refs": header_refs,
                    "sensitive": False,
                    "table_id": table.table_id,
                    "page": page.page_number,
                    "projection_role": role,
                    "inferred": not has_semantic_header,
                }
            )

            for axis_index in data_axes:
                axis = list(axes[axis_index])
                fields: dict[str, Any] = {}
                field_source_refs: dict[str, list[dict[str, Any]]] = {}
                record_refs: list[dict[str, Any] | None] = list(header_refs)
                unresolved_source = False
                for name, indices in columns:
                    values: list[str] = []
                    refs: list[dict[str, Any] | None] = []
                    for column in indices:
                        value = (
                            str(axis[column] or "").strip()
                            if column < len(axis)
                            else ""
                        )
                        if not value:
                            continue
                        values.append(value)
                        refs.append(
                            source_ref(
                                _cell_evidence_id(
                                    table.table_id,
                                    orientation=orientation,
                                    axis_index=axis_index,
                                    field_axis=column,
                                )
                            )
                        )
                    if not values:
                        continue
                    fields[name] = values[0] if len(values) == 1 else values
                    resolved_refs = unique_refs(refs)
                    if len(resolved_refs) != len(values):
                        unresolved_source = True
                        break
                    field_source_refs[name] = resolved_refs
                    record_refs.extend(resolved_refs)
                if unresolved_source or not fields:
                    continue
                payloads.append(
                    {
                        "name": "table_record",
                        "value": fields,
                        "source_refs": unique_refs(record_refs),
                        "sensitive": False,
                        "table_id": table.table_id,
                        "page": page.page_number,
                        **(
                            {"row_index": axis_index}
                            if orientation == "rows"
                            else {"column_index": axis_index}
                        ),
                        "field_source_refs": field_source_refs,
                        "record_binding": _record_binding(
                            orientation=orientation,
                            axis_index=axis_index,
                            regions=regions,
                        ),
                        "projection_role": role,
                    }
                )
    return payloads


__all__ = ["content_fact_payloads", "table_fact_payloads"]
