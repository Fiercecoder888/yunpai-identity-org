"""Controlled source normalization before documents are submitted to MinerU.

MinerU accepts modern office documents, PDFs and images directly.  Legacy
spreadsheets and HTML are converted into bounded, auditable inputs first.  The
business mapper must still receive the original path and filename so the
``m1.document.v2`` source identity never changes to a temporary conversion.
"""

from __future__ import annotations

import hashlib
import tempfile
from dataclasses import dataclass, field
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Literal, Self

from ..adapters.archive import ArchiveLimits, extract_archive
from ..adapters.common import file_sha256
from ..envelope import DocumentEnvelope, SheetEnvelope, coordinate_from_row_col
from ..magic import sniff_file_type
from ..spreadsheets import parse_spreadsheet_envelope
from .mineru_cad_input import (
    CADRenderResult,
    EzdxfCADRenderer,
    MinerUCADRenderer,
    MinerUCADRendererRequired,
    MinerUCADRenderError,
    MinerUCADSourceError,
)

MinerUInputAction = Literal["parse", "recurse"]

_NATIVE_FILE_TYPES = frozenset({"pdf", "image", "docx", "pptx"})
_SPREADSHEET_CONVERSION_TYPES = frozenset({"xlsx", "xls", "xlsm", "csv"})
_ARCHIVE_FILE_TYPES = frozenset({"archive", "zip", "rar", "7z", "tar"})
_CAD_FILE_TYPES = frozenset({"dxf", "dwg"})
_IMAGE_SUFFIXES = frozenset(
    {".png", ".jpeg", ".jpg", ".jp2", ".webp", ".gif", ".bmp", ".tiff", ".tif"}
)
_CANONICAL_SUFFIX = {
    "pdf": ".pdf",
    "docx": ".docx",
    "pptx": ".pptx",
    "xlsx": ".xlsx",
    "xls": ".xls",
    "xlsm": ".xlsm",
    "csv": ".csv",
    "html": ".html",
    "dxf": ".dxf",
    "dwg": ".dwg",
}
_HTML_ALLOWED_TAGS = frozenset(
    {
        "article",
        "b",
        "blockquote",
        "br",
        "code",
        "dd",
        "div",
        "dl",
        "dt",
        "em",
        "footer",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "header",
        "hr",
        "i",
        "li",
        "main",
        "ol",
        "p",
        "pre",
        "section",
        "span",
        "strong",
        "sub",
        "sup",
        "table",
        "tbody",
        "td",
        "tfoot",
        "th",
        "thead",
        "tr",
        "u",
        "ul",
    }
)
_HTML_VOID_TAGS = frozenset({"br", "hr"})
_HTML_BLOCKED_CONTENT_TAGS = frozenset(
    {"applet", "canvas", "embed", "form", "iframe", "noscript", "object", "script", "style"}
)
_HTML_CELL_ATTRIBUTES = frozenset({"colspan", "rowspan"})
_DEFAULT_CAD_RENDERER = object()
_SPREADSHEET_RENDER_ROWS = 40
_SPREADSHEET_RENDER_COLUMNS = 12


class MinerUInputError(RuntimeError):
    """A source could not be made into an auditable MinerU input."""


class MinerUInputContractError(MinerUInputError):
    """The source or a conversion result violates the normalization contract."""


@dataclass(frozen=True, slots=True)
class MinerURecursiveMember:
    """A terminal archive member which the caller must ingest recursively."""

    path: Path
    archive_path: str
    original_filename: str
    sha256: str
    file_type: str

    def metadata(self) -> dict[str, Any]:
        return {
            "archive_path": self.archive_path,
            "original_filename": self.original_filename,
            "sha256": self.sha256,
            "file_type": self.file_type,
        }


@dataclass(slots=True)
class MinerUPreparedInput:
    """A scoped MinerU input or an archive recursion decision.

    Converted files and extracted members live only until :meth:`close` is
    called.  Callers should always use this object as a context manager.
    """

    action: MinerUInputAction
    source_path: Path
    original_filename: str
    source_sha256: str
    source_file_type: str
    metadata: dict[str, Any]
    path: Path | None = None
    upload_filename: str | None = None
    normalized_file_type: str | None = None
    recursive_members: tuple[MinerURecursiveMember, ...] = ()
    _temporary_directory: Any | None = field(default=None, repr=False)

    @property
    def ready(self) -> bool:
        return self.action == "parse" and self.path is not None

    def close(self) -> None:
        temporary = self._temporary_directory
        self._temporary_directory = None
        if temporary is not None:
            temporary.cleanup()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


class _HTMLSanitizer(HTMLParser):
    """Retain document structure while removing executable/external content."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.text_parts: list[str] = []
        self.dropped_tags = 0
        self._blocked_depth = 0

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        token = tag.casefold()
        if token in _HTML_BLOCKED_CONTENT_TAGS:
            self._blocked_depth += 1
            self.dropped_tags += 1
            return
        if self._blocked_depth:
            return
        if token not in _HTML_ALLOWED_TAGS:
            self.dropped_tags += 1
            return
        rendered_attrs = ""
        if token in {"td", "th"}:
            retained: list[str] = []
            for name, value in attrs:
                attribute = name.casefold()
                if attribute not in _HTML_CELL_ATTRIBUTES or value is None:
                    continue
                try:
                    bounded = max(1, min(256, int(value)))
                except ValueError:
                    continue
                retained.append(f'{attribute}="{bounded}"')
            if retained:
                rendered_attrs = " " + " ".join(retained)
        self.parts.append(f"<{token}{rendered_attrs}>")

    def handle_startendtag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        self.handle_starttag(tag, attrs)
        token = tag.casefold()
        if token in _HTML_ALLOWED_TAGS and token not in _HTML_VOID_TAGS:
            self.handle_endtag(token)

    def handle_endtag(self, tag: str) -> None:
        token = tag.casefold()
        if token in _HTML_BLOCKED_CONTENT_TAGS:
            if self._blocked_depth:
                self._blocked_depth -= 1
            return
        if self._blocked_depth:
            return
        if token in _HTML_ALLOWED_TAGS and token not in _HTML_VOID_TAGS:
            self.parts.append(f"</{token}>")

    def handle_data(self, data: str) -> None:
        if self._blocked_depth:
            return
        self.parts.append(escape(data, quote=False))
        if data.strip():
            self.text_parts.append(data)

    @property
    def sanitized_html(self) -> str:
        return "<html><body>" + "".join(self.parts) + "</body></html>"

    @property
    def visible_text(self) -> str:
        return " ".join(" ".join(value.split()) for value in self.text_parts)


class MinerUInputNormalizer:
    """Normalize every supported source without changing its business identity."""

    def __init__(
        self,
        *,
        max_source_bytes: int = 512 * 1024 * 1024,
        max_spreadsheet_sheets: int = 200,
        max_spreadsheet_cells: int = 1_000_000,
        max_spreadsheet_rows: int = 100_000,
        max_spreadsheet_columns: int = 16_384,
        max_html_bytes: int = 32 * 1024 * 1024,
        max_html_pages: int = 200,
        archive_limits: ArchiveLimits | None = None,
        cad_renderer: MinerUCADRenderer | None | object = _DEFAULT_CAD_RENDERER,
    ) -> None:
        self.max_source_bytes = max(1, int(max_source_bytes))
        self.max_spreadsheet_sheets = max(1, int(max_spreadsheet_sheets))
        self.max_spreadsheet_cells = max(1, int(max_spreadsheet_cells))
        self.max_spreadsheet_rows = max(1, int(max_spreadsheet_rows))
        self.max_spreadsheet_columns = max(1, int(max_spreadsheet_columns))
        self.max_html_bytes = max(1, int(max_html_bytes))
        self.max_html_pages = max(1, int(max_html_pages))
        self.archive_limits = archive_limits or ArchiveLimits()
        self.cad_renderer = (
            EzdxfCADRenderer()
            if cad_renderer is _DEFAULT_CAD_RENDERER
            else cad_renderer
        )

    def prepare(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
        file_type: str | None = None,
        native_evidence_available: bool = False,
    ) -> MinerUPreparedInput:
        source = Path(path)
        if not source.is_file():
            raise FileNotFoundError(source)
        if source.is_symlink():
            raise MinerUInputContractError("symlinked MinerU source is not permitted")
        source_size = source.stat().st_size
        if source_size > self.max_source_bytes:
            raise MinerUInputContractError(
                f"MinerU source exceeds {self.max_source_bytes} bytes"
            )
        original = _safe_basename(original_filename or source.name)
        declared = str(file_type or "").strip().casefold()
        detected = sniff_file_type(source).kind
        effective = _effective_type(source, declared=declared, detected=detected)
        source_digest = file_sha256(source)
        if native_evidence_available and effective in _SPREADSHEET_CONVERSION_TYPES:
            return self._native_evidence(
                source,
                original=original,
                file_type=effective,
                source_sha256=source_digest,
                source_size=source_size,
            )
        if effective in _NATIVE_FILE_TYPES:
            return self._native(
                source,
                original=original,
                file_type=effective,
                source_sha256=source_digest,
                source_size=source_size,
            )
        if effective in _SPREADSHEET_CONVERSION_TYPES:
            return self._spreadsheet(
                source,
                original=original,
                file_type=effective,
                source_sha256=source_digest,
                source_size=source_size,
            )
        if effective == "html":
            return self._html(
                source,
                original=original,
                source_sha256=source_digest,
                source_size=source_size,
            )
        if effective in _ARCHIVE_FILE_TYPES:
            return self._archive(
                source,
                original=original,
                source_sha256=source_digest,
                source_size=source_size,
            )
        if effective in _CAD_FILE_TYPES:
            return self._cad(
                source,
                original=original,
                file_type=effective,
                source_sha256=source_digest,
                source_size=source_size,
            )
        raise MinerUInputContractError(
            f"unsupported MinerU input type: {effective or detected or declared or 'unknown'}"
        )

    def _native_evidence(
        self,
        source: Path,
        *,
        original: str,
        file_type: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        """Keep the original input when a lossless adapter already owns evidence."""

        upload_filename = _upload_filename(original, source, file_type)
        metadata = _base_metadata(
            original=original,
            source_sha256=source_sha256,
            source_size=source_size,
            source_file_type=file_type,
            normalized_filename=upload_filename,
            normalized_sha256=source_sha256,
            normalized_file_type=file_type,
            conversion="native_evidence_identity",
        )
        metadata["mapping"] = {
            "strategy": "identity",
            "complete": True,
            "authority": "native_document_evidence",
        }
        return MinerUPreparedInput(
            action="parse",
            source_path=source,
            original_filename=original,
            source_sha256=source_sha256,
            source_file_type=file_type,
            metadata=metadata,
            path=source,
            upload_filename=upload_filename,
            normalized_file_type=file_type,
        )

    def _native(
        self,
        source: Path,
        *,
        original: str,
        file_type: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        upload_filename = _upload_filename(original, source, file_type)
        metadata = _base_metadata(
            original=original,
            source_sha256=source_sha256,
            source_size=source_size,
            source_file_type=file_type,
            normalized_filename=upload_filename,
            normalized_sha256=source_sha256,
            normalized_file_type=file_type,
            conversion="native",
        )
        metadata["mapping"] = {"strategy": "identity", "complete": True}
        return MinerUPreparedInput(
            action="parse",
            source_path=source,
            original_filename=original,
            source_sha256=source_sha256,
            source_file_type=file_type,
            metadata=metadata,
            path=source,
            upload_filename=upload_filename,
            normalized_file_type=file_type,
        )

    def _spreadsheet(
        self,
        source: Path,
        *,
        original: str,
        file_type: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        temporary = tempfile.TemporaryDirectory(prefix="m1-mineru-sheet-")
        try:
            envelope = parse_spreadsheet_envelope(
                source, original_filename=original
            )
            if envelope.file_kind != file_type:
                raise MinerUInputContractError(
                    "spreadsheet type changed between preflight and conversion"
                )
            if envelope.sha256 != source_sha256:
                raise MinerUInputContractError(
                    "spreadsheet source changed while it was being normalized"
                )
            output = Path(temporary.name) / "normalized.pdf"
            mapping = self._render_spreadsheet_pdf(envelope, output)
            normalized_sha256 = file_sha256(output)
            upload_filename = f"{_safe_stem(original)}.pdf"
            metadata = _base_metadata(
                original=original,
                source_sha256=source_sha256,
                source_size=source_size,
                source_file_type=file_type,
                normalized_filename=upload_filename,
                normalized_sha256=normalized_sha256,
                normalized_file_type="pdf",
                conversion=f"{file_type}_to_pdf",
            )
            metadata["spreadsheet_mapping"] = mapping
            return MinerUPreparedInput(
                action="parse",
                source_path=source,
                original_filename=original,
                source_sha256=source_sha256,
                source_file_type=file_type,
                metadata=metadata,
                path=output,
                upload_filename=upload_filename,
                normalized_file_type="pdf",
                _temporary_directory=temporary,
            )
        except Exception:
            temporary.cleanup()
            raise

    def _render_spreadsheet_pdf(
        self, envelope: DocumentEnvelope, output: Path
    ) -> dict[str, Any]:
        """Render bounded spreadsheet slices into the VLM-only MinerU input path.

        MinerU's Office backend does not provide the positioned VLM evidence that
        the full-authority gate requires.  The workbook is therefore rendered as
        a visible PDF view while the original sheet/range mapping remains in the
        normalization metadata.
        """

        if len(envelope.sheets) > self.max_spreadsheet_sheets:
            raise MinerUInputContractError(
                "spreadsheet exceeds the configured sheet limit"
            )
        cell_count = sum(len(sheet.cells) for sheet in envelope.sheets)
        if cell_count > self.max_spreadsheet_cells:
            raise MinerUInputContractError(
                "spreadsheet exceeds the configured cell limit"
            )
        if any(sheet.max_row > self.max_spreadsheet_rows for sheet in envelope.sheets):
            raise MinerUInputContractError(
                "spreadsheet exceeds the configured row limit"
            )
        if any(
            sheet.max_column > self.max_spreadsheet_columns
            for sheet in envelope.sheets
        ):
            raise MinerUInputContractError(
                "spreadsheet exceeds the configured column limit"
            )
        try:
            import fitz
        except ImportError as exc:  # pragma: no cover - a core M1 dependency
            raise MinerUInputContractError(
                "controlled spreadsheet rendering requires PyMuPDF"
            ) from exc

        sheets = envelope.sheets or [SheetEnvelope(name="Sheet1")]
        chunks: list[tuple[dict[str, Any], str]] = []
        planned_pages = 0
        for sheet in sheets:
            max_row = max(1, int(sheet.max_row or 0))
            max_column = max(1, int(sheet.max_column or 0))
            row_chunks = (max_row + _SPREADSHEET_RENDER_ROWS - 1) // _SPREADSHEET_RENDER_ROWS
            column_chunks = (
                max_column + _SPREADSHEET_RENDER_COLUMNS - 1
            ) // _SPREADSHEET_RENDER_COLUMNS
            planned_pages += row_chunks * column_chunks
            if planned_pages > self.max_html_pages:
                raise MinerUInputContractError(
                    "spreadsheet rendering exceeds the configured page limit"
                )
            for row_start in range(1, max_row + 1, _SPREADSHEET_RENDER_ROWS):
                row_end = min(max_row, row_start + _SPREADSHEET_RENDER_ROWS - 1)
                for column_start in range(
                    1, max_column + 1, _SPREADSHEET_RENDER_COLUMNS
                ):
                    column_end = min(
                        max_column,
                        column_start + _SPREADSHEET_RENDER_COLUMNS - 1,
                    )
                    cell_range = (
                        f"{coordinate_from_row_col(row_start, column_start)}:"
                        f"{coordinate_from_row_col(row_end, column_end)}"
                    )
                    descriptor = {
                        "sheet": sheet.name,
                        "range": cell_range,
                        "row_start": row_start,
                        "row_end": row_end,
                        "column_start": column_start,
                        "column_end": column_end,
                    }
                    chunks.append(
                        (
                            descriptor,
                            _spreadsheet_chunk_html(
                                sheet,
                                row_start=row_start,
                                row_end=row_end,
                                column_start=column_start,
                                column_end=column_end,
                                source_range=cell_range,
                            ),
                        )
                    )

        sheet_mappings: list[dict[str, Any]] = []
        for source_sheet in sheets:
            last_coordinate = (
                coordinate_from_row_col(source_sheet.max_row, source_sheet.max_column)
                if source_sheet.max_row and source_sheet.max_column
                else None
            )
            sheet_mappings.append(
                {
                    "source_sheet": source_sheet.name,
                    "source_range": f"A1:{last_coordinate}" if last_coordinate else None,
                    "max_row": source_sheet.max_row,
                    "max_column": source_sheet.max_column,
                    "cell_count": len(source_sheet.cells),
                    "merged_ranges": [merged.ref for merged in source_sheet.merged_ranges],
                    "cell_mapping": {
                        "strategy": "identity_a1",
                        "source_coordinate_system": (
                            "csv_1_based_row_column"
                            if envelope.file_kind == "csv"
                            else "excel_a1"
                        ),
                        "normalized_coordinate_system": "pdf_page_range",
                        "complete": True,
                    },
                }
            )

        rendered_pages: list[dict[str, Any]] = []
        rendered_page_count = 0
        try:
            rendered = fitz.open()
            try:
                for index, (descriptor, html) in enumerate(chunks, 1):
                    chunk_output = output.parent / f"spreadsheet-{index}.pdf"
                    try:
                        count = self._render_html_pdf(
                            html,
                            chunk_output,
                            landscape=(
                                descriptor["column_end"]
                                - descriptor["column_start"]
                                + 1
                                > 8
                            ),
                        )
                        if len(rendered) + count > self.max_html_pages:
                            raise MinerUInputContractError(
                                "spreadsheet rendering exceeds the configured page limit"
                            )
                        with fitz.open(chunk_output) as chunk:
                            start_page = len(rendered) + 1
                            rendered.insert_pdf(chunk)
                            end_page = len(rendered)
                        rendered_page_count += count
                        rendered_pages.append(
                            {
                                **descriptor,
                                "page_start": start_page,
                                "page_end": end_page,
                            }
                        )
                    finally:
                        chunk_output.unlink(missing_ok=True)
                rendered.save(output)
            finally:
                rendered.close()
        except Exception as exc:
            if isinstance(exc, MinerUInputContractError):
                raise
            raise MinerUInputContractError(
                f"controlled spreadsheet rendering failed: {exc.__class__.__name__}"
            ) from exc
        if not output.is_file() or output.stat().st_size == 0:
            raise MinerUInputContractError(
                "controlled spreadsheet rendering produced no PDF"
            )
        return {
            "schema_version": "m1.mineru-spreadsheet-map.v2",
            "mapping_complete": True,
            "source_kind": envelope.file_kind,
            "source_mime_type": envelope.mime_type,
            "source_sha256": envelope.sha256,
            "sheet_count": len(sheets),
            "cell_count": cell_count,
            "rendered_page_count": rendered_page_count,
            "renderer": "pymupdf-story",
            "warnings": list(envelope.warnings),
            "sheets": sheet_mappings,
            "rendered_pages": rendered_pages,
        }

    def _html(
        self,
        source: Path,
        *,
        original: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        if source_size > self.max_html_bytes:
            raise MinerUInputContractError(
                f"HTML source exceeds {self.max_html_bytes} bytes"
            )
        raw = source.read_bytes()
        text, encoding = _decode_text(raw)
        sanitizer = _HTMLSanitizer()
        try:
            sanitizer.feed(text)
            sanitizer.close()
        except Exception as exc:
            raise MinerUInputContractError("invalid HTML input") from exc
        if not sanitizer.visible_text:
            raise MinerUInputContractError("HTML input has no parseable text evidence")
        safe_html = sanitizer.sanitized_html
        temporary = tempfile.TemporaryDirectory(prefix="m1-mineru-html-")
        try:
            output = Path(temporary.name) / "normalized.pdf"
            page_count = self._render_html_pdf(safe_html, output)
            normalized_sha256 = file_sha256(output)
            upload_filename = f"{_safe_stem(original)}.pdf"
            metadata = _base_metadata(
                original=original,
                source_sha256=source_sha256,
                source_size=source_size,
                source_file_type="html",
                normalized_filename=upload_filename,
                normalized_sha256=normalized_sha256,
                normalized_file_type="pdf",
                conversion="html_to_pdf",
            )
            metadata["html_evidence"] = {
                "source_encoding": encoding,
                "sanitized_html_sha256": hashlib.sha256(
                    safe_html.encode("utf-8")
                ).hexdigest(),
                "visible_text_sha256": hashlib.sha256(
                    sanitizer.visible_text.encode("utf-8")
                ).hexdigest(),
                "dropped_tag_count": sanitizer.dropped_tags,
                "rendered_page_count": page_count,
                "external_resources_enabled": False,
                "script_execution_enabled": False,
            }
            return MinerUPreparedInput(
                action="parse",
                source_path=source,
                original_filename=original,
                source_sha256=source_sha256,
                source_file_type="html",
                metadata=metadata,
                path=output,
                upload_filename=upload_filename,
                normalized_file_type="pdf",
                _temporary_directory=temporary,
            )
        except Exception:
            temporary.cleanup()
            raise

    def _render_html_pdf(
        self, html: str, output: Path, *, landscape: bool = False
    ) -> int:
        try:
            import fitz
        except ImportError as exc:  # pragma: no cover - a core M1 dependency
            raise MinerUInputContractError(
                "HTML normalization requires PyMuPDF"
            ) from exc
        if landscape:
            media_box = fitz.Rect(0, 0, 842, 595)
            content_box = fitz.Rect(36, 36, 806, 559)
        else:
            media_box = fitz.Rect(0, 0, 595, 842)
            content_box = fitz.Rect(36, 36, 559, 806)
        user_css = (
            "body{font-family:sans-serif;font-size:10pt;color:#111;}"
            "table{border-collapse:collapse;width:100%;}"
            "th,td{border:0.5pt solid #555;padding:3pt;vertical-align:top;"
            "overflow-wrap:anywhere;}"
            "pre,code{white-space:pre-wrap;}"
        )
        writer = fitz.DocumentWriter(str(output))
        pages = 0
        try:
            story = fitz.Story(html=html, user_css=user_css)
            more = True
            while more:
                if pages >= self.max_html_pages:
                    raise MinerUInputContractError(
                        "HTML rendering exceeds the configured page limit"
                    )
                device = writer.begin_page(media_box)
                more, _filled = story.place(content_box)
                story.draw(device)
                writer.end_page()
                pages += 1
        except MinerUInputContractError:
            raise
        except Exception as exc:
            raise MinerUInputContractError(
                f"HTML rendering failed: {exc.__class__.__name__}"
            ) from exc
        finally:
            writer.close()
        if pages < 1 or not output.is_file() or output.stat().st_size == 0:
            raise MinerUInputContractError("HTML rendering produced no PDF")
        return pages

    def _archive(
        self,
        source: Path,
        *,
        original: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        temporary = tempfile.TemporaryDirectory(prefix="m1-mineru-archive-")
        try:
            destination = Path(temporary.name) / "members"
            result = extract_archive(source, destination, self.archive_limits)
            members: list[MinerURecursiveMember] = []
            for child in result.leaf_files:
                relative = child.relative_to(result.destination).as_posix()
                detected = sniff_file_type(child).kind
                members.append(
                    MinerURecursiveMember(
                        path=child,
                        archive_path=relative,
                        original_filename=child.name,
                        sha256=file_sha256(child),
                        file_type=detected,
                    )
                )
            metadata = {
                "schema_version": "m1.mineru-input.v1",
                "action": "recurse",
                "source": {
                    "original_filename": original,
                    "sha256": source_sha256,
                    "size_bytes": source_size,
                    "file_type": result.archive_type,
                },
                "archive": {
                    "archive_type": result.archive_type,
                    "total_entries": result.total_entries,
                    "total_uncompressed": result.total_uncompressed,
                    "duplicate_count": result.duplicate_count,
                    "ignored_count": result.ignored_count,
                    "recursive_members": [member.metadata() for member in members],
                },
            }
            return MinerUPreparedInput(
                action="recurse",
                source_path=source,
                original_filename=original,
                source_sha256=source_sha256,
                source_file_type=result.archive_type,
                metadata=metadata,
                recursive_members=tuple(members),
                _temporary_directory=temporary,
            )
        except Exception:
            temporary.cleanup()
            raise

    def _cad(
        self,
        source: Path,
        *,
        original: str,
        file_type: str,
        source_sha256: str,
        source_size: int,
    ) -> MinerUPreparedInput:
        if self.cad_renderer is None:
            raise MinerUCADRendererRequired(
                "MINERU_CAD_RENDERER_REQUIRED: configure an approved renderer "
                "that implements MinerUCADRenderer; CAD never falls back silently"
            )
        temporary = tempfile.TemporaryDirectory(prefix="m1-mineru-cad-")
        root = Path(temporary.name).resolve()
        try:
            try:
                result = self.cad_renderer.render(source, output_dir=root)
            except MinerUCADSourceError as exc:
                raise MinerUInputContractError(str(exc)) from exc
            except (MinerUInputError, MinerUCADRenderError):
                raise
            except Exception as exc:
                raise MinerUCADRenderError(
                    f"MINERU_CAD_RENDER_FAILED: {exc.__class__.__name__}"
                ) from exc
            if not isinstance(result, CADRenderResult):
                raise MinerUCADRenderError(
                    "MINERU_CAD_RENDER_FAILED: renderer returned an invalid contract"
                )
            rendered = result.path.resolve()
            if not rendered.is_relative_to(root) or rendered.is_symlink():
                raise MinerUCADRenderError(
                    "MINERU_CAD_RENDER_FAILED: renderer output escaped its workspace"
                )
            if not rendered.is_file() or rendered.stat().st_size == 0:
                raise MinerUCADRenderError(
                    "MINERU_CAD_RENDER_FAILED: renderer produced no artifact"
                )
            rendered_info = sniff_file_type(rendered)
            rendered_type = rendered_info.kind
            if rendered_type not in {"pdf", "image"}:
                raise MinerUCADRenderError(
                    "MINERU_CAD_RENDER_FAILED: output must be a PDF or image"
                )
            normalized_sha256 = file_sha256(rendered)
            suffix = rendered_info.canonical_extension or rendered.suffix.casefold()
            upload_filename = f"{_safe_stem(original)}{suffix}"
            metadata = _base_metadata(
                original=original,
                source_sha256=source_sha256,
                source_size=source_size,
                source_file_type=file_type,
                normalized_filename=upload_filename,
                normalized_sha256=normalized_sha256,
                normalized_file_type=rendered_type,
                conversion=f"{file_type}_renderer",
            )
            metadata["cad_renderer"] = {
                "name": result.renderer_name,
                "version": result.renderer_version,
                "page_map": [dict(item) for item in result.page_map],
                "contract": "m1.mineru-cad-renderer.v1",
                "sidecar": dict(result.sidecar_metadata),
            }
            return MinerUPreparedInput(
                action="parse",
                source_path=source,
                original_filename=original,
                source_sha256=source_sha256,
                source_file_type=file_type,
                metadata=metadata,
                path=rendered,
                upload_filename=upload_filename,
                normalized_file_type=rendered_type,
                _temporary_directory=temporary,
            )
        except Exception:
            temporary.cleanup()
            raise


def _effective_type(source: Path, *, declared: str, detected: str) -> str:
    declared = {"htm": "html", "tsv": "csv"}.get(declared, declared)
    if declared in _ARCHIVE_FILE_TYPES:
        # Extraction performs its own magic-byte verification.
        return declared
    if declared in _CAD_FILE_TYPES:
        if source.suffix.casefold() != _CANONICAL_SUFFIX[declared]:
            raise MinerUInputContractError(
                "CAD extension does not match its declared renderer contract"
            )
        return declared
    if declared and declared != "unknown" and detected != declared:
        raise MinerUInputContractError(
            f"declared MinerU input type {declared} does not match content type {detected}"
        )
    return declared if declared and declared != "unknown" else detected


def _base_metadata(
    *,
    original: str,
    source_sha256: str,
    source_size: int,
    source_file_type: str,
    normalized_filename: str,
    normalized_sha256: str,
    normalized_file_type: str,
    conversion: str,
) -> dict[str, Any]:
    return {
        "schema_version": "m1.mineru-input.v1",
        "action": "parse",
        "source": {
            "original_filename": original,
            "sha256": source_sha256,
            "size_bytes": source_size,
            "file_type": source_file_type,
        },
        "normalized": {
            "filename": normalized_filename,
            "sha256": normalized_sha256,
            "file_type": normalized_file_type,
            "conversion": conversion,
        },
    }


def _spreadsheet_chunk_html(
    sheet: SheetEnvelope,
    *,
    row_start: int,
    row_end: int,
    column_start: int,
    column_end: int,
    source_range: str,
) -> str:
    rows: list[str] = []
    for row in range(row_start, row_end + 1):
        cells: list[str] = []
        for column in range(column_start, column_end + 1):
            cells.append(
                "<td>"
                + escape(_spreadsheet_cell_text(sheet, row=row, column=column))
                + "</td>"
            )
        rows.append("<tr>" + "".join(cells) + "</tr>")
    return (
        "<html><body>"
        f"<h1>Spreadsheet: {escape(sheet.name)}</h1>"
        f"<p>Source range: {escape(source_range)}</p>"
        "<table><tbody>"
        + "".join(rows)
        + "</tbody></table></body></html>"
    )


def _spreadsheet_cell_text(
    sheet: SheetEnvelope, *, row: int, column: int
) -> str:
    cell = sheet.cells.get((row, column))
    if cell is None:
        return ""
    if cell.cached_value is not None:
        value = cell.cached_value
    elif cell.formula is not None:
        formula = str(cell.formula)
        value = formula if formula.startswith("=") else f"={formula}"
    else:
        value = cell.value
    return "" if value is None else str(value)


def _safe_basename(value: str) -> str:
    # The stored source identity must preserve the user's Unicode spelling.
    # Only the separate upload filename is normalized for the parser runtime.
    basename = str(value or "document").replace("\\", "/").split("/")[-1]
    basename = "".join(character for character in basename if ord(character) >= 32)
    return basename.strip(" .")[:240] or "document"


def _safe_stem(filename: str) -> str:
    stem = Path(filename).stem
    safe = "".join(
        character if character.isalnum() or character in {"-", "_", "."} else "_"
        for character in stem
    )
    return safe.strip("._")[:180] or "document"


def _upload_filename(original: str, source: Path, file_type: str) -> str:
    suffix = source.suffix.casefold()
    if file_type == "image" and suffix in _IMAGE_SUFFIXES:
        selected_suffix = suffix
    else:
        selected_suffix = _CANONICAL_SUFFIX.get(file_type, suffix)
    return f"{_safe_stem(original)}{selected_suffix}"


def _decode_text(data: bytes) -> tuple[str, str]:
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            return data.decode(encoding), encoding
        except UnicodeDecodeError:
            continue
    try:
        from charset_normalizer import from_bytes

        best = from_bytes(data).best()
        if best is not None:
            return str(best), best.encoding or "unknown"
    except ImportError:
        pass
    raise MinerUInputContractError("unsupported text encoding")


__all__ = [
    "CADRenderResult",
    "EzdxfCADRenderer",
    "MinerUCADRenderError",
    "MinerUCADRenderer",
    "MinerUCADRendererRequired",
    "MinerUInputContractError",
    "MinerUInputError",
    "MinerUInputNormalizer",
    "MinerUPreparedInput",
    "MinerURecursiveMember",
]
