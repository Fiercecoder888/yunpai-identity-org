"""Standalone MinerU plus Instructor extraction proof of concept.
This module is intentionally not wired into the M1 runtime.  It demonstrates
an evidence-first two-stage protocol for an OpenAI-compatible Instructor
client:

1. classify the document and partition every recovered table into segments;
2. extract facts and records for each declared segment.

Every source value remains in the returned audit inventory.  A model may leave
a value unmapped, but it cannot make the value disappear: unreferenced values
are returned as ``unmapped_evidence`` and malformed citations make the result
incomplete.  The POC therefore gives a future authority path a concrete,
testable no-silent-loss boundary without changing the existing parser.

Non-table narrative evidence has a separate semantic-content projection.  The
model can bind only an evidence ID to a kind and label; exact source text and
its locator are copied locally, while every unbound block receives an explicit
source-kind fallback.  These content metrics remain independent from business
field mapping metrics.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import re
import statistics
import unicodedata
from collections.abc import Mapping, Sequence
from contextlib import suppress
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
from itertools import pairwise
from typing import Any, Literal, Protocol, TypeVar

import httpx
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from ..models import SourceReference
from .evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from .mineru_domain import (
    LineTarget,
    allowed_line_targets,
    source_label_line_target,
)
from .mineru_regions import (
    EvidenceRecordRegion,
    RecordRegionAssessment,
    assess_record_regions,
)
from .semantic_strategy_executor import (
    SemanticExecutionSpec,
    SemanticMapperRole,
    SemanticStrategyExecutor,
)

T = TypeVar("T", bound=BaseModel)
CanonicalDocumentIntent = Literal[
    "order",
    "inventory",
    "equipment",
    "mold",
    "procurement",
    "technical_document",
    "commercial_document",
    "archive",
    "unknown",
]
SegmentIntent = Literal["records", "metadata", "layout", "unknown"]
RecordOrientation = Literal["rows", "columns"]
RecordKind = Literal["product", "narrative", "total", "metadata", "unknown"]
ContentBindingSource = Literal["model", "local_fallback"]
RouteSchemaFamily = Literal[
    "generic_layout",
    "open_domain",
    "order",
    "inventory",
    "equipment",
    "mold",
    "procurement",
    "technical",
    "archive",
]
RouteVerifierPolicy = Literal["disabled", "on_uncertainty", "always"]
RouteAuthorityPolicy = Literal[
    "core_strict",
    "evidence_required",
    "open_domain",
]
_PARTITION_ISSUE_PREFIXES = (
    "missing_table_intent",
    "unknown_table_intent",
    "duplicate_table_intent",
    "segment_out_of_bounds",
    "overlapping_segments",
    "incomplete_table_partition",
    "segments_for_empty_table",
)


class InstructorUnavailableError(RuntimeError):
    """Raised only when a caller requests the optional Instructor transport."""


class OllamaNativeOutputError(RuntimeError):
    """Ollama exhausted bounded attempts without valid structured output."""


class SemanticExecutionBudgetExceeded(RuntimeError):
    """A workflow-issued semantic capability exhausted its hard budget."""


class RecordGeometryContractError(ValueError):
    """A declared record axis would violate the bounded projection contract."""


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


def _bounded_text(value: str, *, name: str, minimum: int, maximum: int) -> str:
    if len(value) < minimum or len(value) > maximum:
        raise ValueError(f"{name} length must be between {minimum} and {maximum}")
    return value


class ProposedFact(_StrictModel):
    name: str = Field(min_length=1, max_length=128)
    value: str = Field(min_length=1, max_length=4000)
    citations: list[str] = Field(min_length=1, max_length=12)
    sensitive: bool = False

    @field_validator("name")
    @classmethod
    def bounded_name(cls, value: str) -> str:
        return _bounded_text(value, name="fact name", minimum=1, maximum=128)

    @field_validator("value")
    @classmethod
    def bounded_value(cls, value: str) -> str:
        return _bounded_text(value, name="fact value", minimum=1, maximum=4000)


class ProposedRecord(_StrictModel):
    fields: list[ProposedFact] = Field(min_length=1, max_length=100)
    record_kind: RecordKind = "unknown"
    record_kind_citations: list[str] = Field(default_factory=list, max_length=12)


class TableSegmentIntent(_StrictModel):
    start: int = Field(ge=0, le=100_000)
    end: int = Field(ge=0, le=100_000)
    intent: SegmentIntent

    @model_validator(mode="after")
    def ordered_range(self) -> TableSegmentIntent:
        if self.end < self.start:
            raise ValueError("segment end precedes start")
        return self


class TableIntent(_StrictModel):
    table_id: str
    orientation: RecordOrientation
    segments: list[TableSegmentIntent] = Field(default_factory=list, max_length=500)

    @field_validator("table_id")
    @classmethod
    def bounded_table_id(cls, value: str) -> str:
        return _bounded_text(value, name="table_id", minimum=1, maximum=200)


class TablePartition(_StrictModel):
    """Compact table-only correction used after document classification."""

    tables: list[TableIntent] = Field(default_factory=list, max_length=200)


class ProposedContentBinding(_StrictModel):
    """A semantic label for one source block; source text stays local."""

    evidence_id: str = Field(min_length=1, max_length=200)
    content_kind: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    label: str = Field(min_length=1, max_length=128)

    @field_validator("evidence_id")
    @classmethod
    def bounded_evidence_id(cls, value: str) -> str:
        return _bounded_text(value, name="evidence_id", minimum=1, maximum=200)

    @field_validator("label")
    @classmethod
    def bounded_label(cls, value: str) -> str:
        return _bounded_text(value, name="content label", minimum=1, maximum=128)


class DocumentIntent(_StrictModel):
    document_intent: str
    document_kind_label: str | None = Field(default=None, max_length=128)
    document_subtype: str = Field(default="unknown", max_length=128)
    document_facts: list[ProposedFact] = Field(default_factory=list, max_length=100)
    primary_record_table_ids: list[str] = Field(default_factory=list, max_length=200)
    content_bindings: list[ProposedContentBinding] = Field(
        default_factory=list,
        max_length=2000,
    )
    tables: list[TableIntent] = Field(default_factory=list, max_length=200)

    @field_validator("document_intent")
    @classmethod
    def bounded_document_intent(cls, value: str) -> str:
        return _bounded_text(
            value,
            name="document_intent",
            minimum=1,
            maximum=128,
        )


class DocumentClassification(_StrictModel):
    document_intent: CanonicalDocumentIntent
    document_kind_label: str | None = Field(default=None, max_length=128)
    document_subtype: str = Field(default="unknown", max_length=128)
    primary_record_table_ids: list[str] = Field(default_factory=list, max_length=200)

    @field_validator("document_intent")
    @classmethod
    def bounded_document_intent(cls, value: str) -> str:
        return _bounded_text(
            value,
            name="document_intent",
            minimum=1,
            maximum=128,
        )


class _BlockFactProposal(_StrictModel):
    name: str = Field(default="", max_length=128)
    value: str = Field(default="", max_length=4000)
    citations: list[str] = Field(default_factory=list, max_length=12)
    sensitive: bool = False


class _BlockContentProposal(_StrictModel):
    evidence_id: str = Field(default="", max_length=200)
    content_kind: str = Field(default="", max_length=64)
    label: str = Field(default="", max_length=128)


class BlockSemantics(_StrictModel):
    # Small local models frequently preserve the requested shape but emit one
    # empty optional proposal. Accept the envelope, then validate every item
    # against the strict authority models before it can affect the document.
    document_facts: list[_BlockFactProposal] = Field(
        default_factory=list,
        max_length=100,
    )
    content_bindings: list[_BlockContentProposal] = Field(
        default_factory=list,
        max_length=1000,
    )

    @field_validator("document_facts", "content_bindings", mode="before")
    @classmethod
    def accept_strict_proposal_models(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            item.model_dump(mode="json") if isinstance(item, BaseModel) else item
            for item in value
        ]


class _SegmentFactProposal(_StrictModel):
    """Transport-only fact proposal; authority validation remains local."""

    name: str = Field(default="", max_length=128)
    value: str = Field(default="", max_length=4000)
    citations: list[str] = Field(default_factory=list, max_length=12)
    sensitive: bool = False


class _SegmentRecordProposal(_StrictModel):
    fields: list[_SegmentFactProposal] = Field(default_factory=list, max_length=100)
    record_kind: str = Field(default="unknown", max_length=32)
    record_kind_citations: list[str] = Field(default_factory=list, max_length=12)

    @field_validator("fields", mode="before")
    @classmethod
    def accept_strict_fact_models(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            item.model_dump(mode="json") if isinstance(item, BaseModel) else item
            for item in value
        ]


class _SegmentFactsOutput(_StrictModel):
    facts: list[_SegmentFactProposal] = Field(default_factory=list, max_length=100)


class _SegmentRecordsOutput(_StrictModel):
    records: list[_SegmentRecordProposal] = Field(default_factory=list, max_length=2000)


class SegmentExtraction(_StrictModel):
    # Compatibility echoes only. The caller binds both identities locally.
    table_id: str = ""
    segment_id: str = ""
    facts: list[_SegmentFactProposal] = Field(default_factory=list, max_length=100)
    records: list[_SegmentRecordProposal] = Field(default_factory=list, max_length=2000)

    @field_validator("facts", "records", mode="before")
    @classmethod
    def accept_strict_proposal_models(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            item.model_dump(mode="json") if isinstance(item, BaseModel) else item
            for item in value
        ]

    @field_validator("table_id")
    @classmethod
    def bounded_table_echo(cls, value: str) -> str:
        return _bounded_text(value, name="table_id", minimum=0, maximum=200)

    @field_validator("segment_id")
    @classmethod
    def bounded_segment_echo(cls, value: str) -> str:
        return _bounded_text(value, name="segment_id", minimum=0, maximum=100)


class RecordFieldBinding(_StrictModel):
    """A semantic name for one locally bound row or column field axis."""

    axis_index: int = Field(ge=0, le=100_000)
    field_name: LineTarget


class RecordFieldMapping(_StrictModel):
    """Compact model output used instead of echoing every long-table record."""

    field_axis_count: int = Field(ge=0, le=100_000)
    bindings: list[RecordFieldBinding] = Field(default_factory=list, max_length=2000)

    @model_validator(mode="after")
    def unique_in_bounds_bindings(self) -> RecordFieldMapping:
        indexes = [binding.axis_index for binding in self.bindings]
        if any(index >= self.field_axis_count for index in indexes):
            raise ValueError("field binding axis is outside field_axis_count")
        if len(indexes) != len(set(indexes)):
            raise ValueError("duplicate field axis binding")
        names = [_normalize(binding.field_name).casefold() for binding in self.bindings]
        if len(names) != len(set(names)):
            raise ValueError("duplicate field name binding")
        return self


class RecordCellRemap(_StrictModel):
    """Evidence-bound correction for one cell whose column meaning is wrong."""

    evidence_id: str = Field(min_length=1, max_length=200)
    field_name: LineTarget


class RecordKindDecision(_StrictModel):
    """A model classification for one locally identified record axis."""

    axis_index: int = Field(ge=0, le=100_000)
    record_kind: RecordKind
    citations: list[str] = Field(min_length=1, max_length=12)
    field_remaps: list[RecordCellRemap] = Field(default_factory=list, max_length=32)


class RecordKindMapping(_StrictModel):
    decisions: list[RecordKindDecision] = Field(default_factory=list, max_length=2000)


class _RecordCellRemapProposal(_StrictModel):
    evidence_id: str | None = Field(default=None, max_length=200)
    field_name: str | None = Field(default=None, max_length=128)


class _RecordKindDecisionProposal(_StrictModel):
    axis_index: int | str | None = None
    record_kind: str | None = Field(default=None, max_length=32)
    citations: list[str] = Field(default_factory=list, max_length=12)
    field_remaps: list[_RecordCellRemapProposal] = Field(
        default_factory=list,
        max_length=32,
    )


class _RecordKindMappingOutput(_StrictModel):
    decisions: list[_RecordKindDecisionProposal] = Field(
        default_factory=list,
        max_length=2000,
    )


class _RecordFieldBindingProposal(_StrictModel):
    """Transport-only binding; M1 owns axis bounds and canonical validation."""

    axis_index: int | str | None = None
    field_name: str | None = Field(default=None, max_length=128)


class _RecordFieldMappingOutput(_StrictModel):
    bindings: list[_RecordFieldBindingProposal] = Field(
        default_factory=list,
        max_length=2000,
    )


def _record_field_axis_count(messages: list[dict[str, str]]) -> int:
    for message in reversed(messages):
        if str(message.get("role") or "").casefold() != "user":
            continue
        try:
            payload = json.loads(str(message.get("content") or ""))
            count = payload["evidence"]["field_axis"]["count"]
        except (KeyError, TypeError, json.JSONDecodeError):
            continue
        if isinstance(count, bool):
            break
        try:
            normalized = int(count)
        except (TypeError, ValueError):
            break
        if 0 <= normalized <= 100_000:
            return normalized
        break
    raise ValueError("record field mapping requires a bounded field axis count")


def _validated_record_field_mapping(
    output: _RecordFieldMappingOutput,
    *,
    field_axis_count: int,
) -> RecordFieldMapping:
    bindings: list[RecordFieldBinding] = []
    seen_axes: set[int] = set()
    seen_names: set[str] = set()
    for proposal in output.bindings:
        raw_index = proposal.axis_index
        if isinstance(raw_index, bool):
            continue
        try:
            axis_index = int(raw_index) if raw_index is not None else -1
        except (TypeError, ValueError):
            continue
        if axis_index < 0 or axis_index >= field_axis_count:
            continue
        try:
            binding = RecordFieldBinding.model_validate(
                {
                    "axis_index": axis_index,
                    "field_name": proposal.field_name,
                }
            )
        except ValidationError:
            continue
        normalized_name = _normalize(binding.field_name).casefold()
        if axis_index in seen_axes or normalized_name in seen_names:
            continue
        seen_axes.add(axis_index)
        seen_names.add(normalized_name)
        bindings.append(binding)
    return RecordFieldMapping(
        field_axis_count=field_axis_count,
        bindings=bindings,
    )


def _record_kind_context(
    messages: list[dict[str, str]],
) -> tuple[dict[int, set[str]], set[str]]:
    """Recover caller-owned axis and evidence bounds from a model request."""

    for message in reversed(messages):
        if str(message.get("role") or "").casefold() != "user":
            continue
        try:
            payload = json.loads(str(message.get("content") or ""))["evidence"]
            candidates = payload["candidates"]
            allowed_names = payload["allowed_field_names"]
        except (KeyError, TypeError, json.JSONDecodeError):
            continue
        if not isinstance(candidates, list) or not isinstance(allowed_names, list):
            break
        axes: dict[int, set[str]] = {}
        for candidate in candidates:
            if not isinstance(candidate, Mapping):
                continue
            axis = candidate.get("axis_index")
            if isinstance(axis, bool) or not isinstance(axis, int) or axis < 0:
                continue
            fields = candidate.get("fields")
            if not isinstance(fields, list):
                continue
            evidence_ids = {
                str(field.get("evidence_id") or "")
                for field in fields
                if isinstance(field, Mapping) and field.get("evidence_id")
            }
            if evidence_ids:
                axes[axis] = evidence_ids
        return axes, {
            str(name) for name in allowed_names if isinstance(name, str) and name
        }
    raise ValueError("record kind mapping requires bounded candidate evidence")


def _validated_record_kind_mapping(
    output: _RecordKindMappingOutput,
    *,
    messages: list[dict[str, str]],
) -> RecordKindMapping:
    axes, allowed_field_names = _record_kind_context(messages)
    decisions: list[RecordKindDecision] = []
    seen_axes: set[int] = set()
    for proposal in output.decisions:
        raw_axis = proposal.axis_index
        if isinstance(raw_axis, bool):
            continue
        try:
            axis = int(raw_axis) if raw_axis is not None else -1
        except (TypeError, ValueError):
            continue
        allowed_evidence = axes.get(axis)
        if not allowed_evidence or axis in seen_axes:
            continue
        citations = list(
            dict.fromkeys(
                citation
                for citation in proposal.citations
                if citation in allowed_evidence
            )
        )
        if not citations:
            continue
        remaps: list[RecordCellRemap] = []
        remapped_evidence: set[str] = set()
        for remap in proposal.field_remaps:
            evidence_id = str(remap.evidence_id or "")
            field_name = str(remap.field_name or "")
            if (
                evidence_id not in allowed_evidence
                or evidence_id in remapped_evidence
                or field_name not in allowed_field_names
            ):
                continue
            try:
                validated = RecordCellRemap.model_validate(
                    {"evidence_id": evidence_id, "field_name": field_name}
                )
            except ValidationError:
                continue
            remapped_evidence.add(evidence_id)
            remaps.append(validated)
        try:
            decision = RecordKindDecision.model_validate(
                {
                    "axis_index": axis,
                    "record_kind": proposal.record_kind,
                    "citations": citations,
                    "field_remaps": remaps,
                }
            )
        except ValidationError:
            continue
        seen_axes.add(axis)
        decisions.append(decision)
    return RecordKindMapping(decisions=decisions)


class EvidenceReference(_StrictModel):
    """A validated model citation paired with M1's typed source locator."""

    evidence_id: str = Field(min_length=1, max_length=200)
    quote: str = Field(min_length=1)
    source_ref: SourceReference


class ExtractedFact(_StrictModel):
    name: str = Field(min_length=1, max_length=128)
    value: str = Field(min_length=1, max_length=4000)
    evidence_refs: list[EvidenceReference] = Field(min_length=1, max_length=12)
    sensitive: bool = False
    inferred: bool = False
    inference_source: str | None = Field(default=None, max_length=96)
    mapping_source: str | None = Field(default=None, max_length=96)
    original_name: str | None = Field(default=None, max_length=128)


_MAX_EXTRACTED_RECORD_FIELDS = 2000


class ExtractedRecord(_StrictModel):
    fields: list[ExtractedFact] = Field(
        min_length=1,
        max_length=_MAX_EXTRACTED_RECORD_FIELDS,
    )
    record_kind: RecordKind = "unknown"
    record_kind_evidence_refs: list[EvidenceReference] = Field(default_factory=list)
    record_kind_source: Literal["model", "local_fallback"] = "local_fallback"
    record_axis: int | None = Field(default=None, ge=0, le=100_000)


class ExtractedSegment(_StrictModel):
    table_id: str
    segment_id: str
    intent: SegmentIntent
    orientation: RecordOrientation | None = None
    start: int | None = Field(default=None, ge=0, le=100_000)
    end: int | None = Field(default=None, ge=0, le=100_000)
    facts: list[ExtractedFact] = Field(default_factory=list)
    records: list[ExtractedRecord] = Field(default_factory=list)

    @model_validator(mode="after")
    def complete_optional_range(self) -> ExtractedSegment:
        values = (self.orientation, self.start, self.end)
        if any(value is not None for value in values) and not all(
            value is not None for value in values
        ):
            raise ValueError("segment orientation/start/end must be supplied together")
        if self.start is not None and self.end is not None and self.end < self.start:
            raise ValueError("segment end precedes start")
        return self


class ContentUnit(_StrictModel):
    """Exact locally projected non-table content with model or fallback semantics."""

    evidence_id: str = Field(min_length=1, max_length=200)
    content_kind: str = Field(min_length=1, max_length=64)
    label: str = Field(min_length=1, max_length=128)
    exact_text: str = Field(min_length=1)
    source_ref: SourceReference
    source_kind: str = Field(min_length=1, max_length=64)
    binding_source: ContentBindingSource
    alternate_semantics: list[dict[str, str]] = Field(default_factory=list)


class DocumentRoutePolicyAdvice(_StrictModel):
    """Safe, typed policy advice; authority and verifier remain caller-owned."""

    schema_family: RouteSchemaFamily | None = None
    verifier_policy: RouteVerifierPolicy | None = None
    authority_policy: RouteAuthorityPolicy | None = None


class ModelFailureDiagnostic(_StrictModel):
    """Bounded, non-content diagnostics for one structured-model call.

    A provider exception often carries the full prompt, completion, request
    arguments, and response body.  None of those values belong in a document
    result.  This model contains only stable identifiers and redacted schema
    error summaries so operators can distinguish validation, transport, and
    timeout failures without exposing document data or credentials.
    """

    stage: str = Field(min_length=1, max_length=96)
    response_model: str = Field(min_length=1, max_length=128)
    error_type: str = Field(min_length=1, max_length=128)
    reason: str = Field(min_length=1, max_length=64)
    root_error_type: str | None = Field(default=None, max_length=128)
    http_status: int | None = Field(default=None, ge=100, le=599)
    provider_error_code: str | None = Field(default=None, max_length=96)
    provider_error_type: str | None = Field(default=None, max_length=96)
    attempt_count: int | None = Field(default=None, ge=1, le=100)
    failed_attempt_count: int = Field(default=0, ge=0, le=100)
    total_usage_tokens: int | None = Field(default=None, ge=0)
    validation_errors: list[dict[str, Any]] = Field(
        default_factory=list,
        max_length=8,
    )
    failed_attempts: list[dict[str, Any]] = Field(
        default_factory=list,
        max_length=8,
    )


class MinerUInstructorResult(_StrictModel):
    """POC result that preserves all otherwise-unmapped evidence explicitly."""

    document_intent: str
    document_intent_family: str = "unknown"
    document_kind_label: str | None = None
    document_subtype: str | None = None
    primary_record_table_ids: list[str] = Field(default_factory=list)
    document_facts: list[ExtractedFact] = Field(default_factory=list)
    generic_facts: list[ExtractedFact] = Field(default_factory=list)
    route_policy_advice: DocumentRoutePolicyAdvice | None = None
    segments: list[ExtractedSegment] = Field(default_factory=list)
    content_units: list[ContentUnit] = Field(default_factory=list)
    schema_evidence: list[EvidenceReference] = Field(default_factory=list)
    redundant_evidence: list[EvidenceReference] = Field(default_factory=list)
    raw_content_evidence: list[EvidenceReference] = Field(default_factory=list)
    unmapped_evidence: list[EvidenceReference] = Field(default_factory=list)
    issues: list[str] = Field(default_factory=list)
    # Bounded, redacted diagnostics for model transport/validation failures.
    # The legacy issue strings above remain the stable compatibility surface.
    model_diagnostics: list[ModelFailureDiagnostic] = Field(default_factory=list)
    complete: bool
    semantic_complete: bool
    accounted_complete: bool
    retained_complete: bool
    total_evidence_count: int = Field(ge=0)
    mapped_evidence_count: int = Field(ge=0)
    schema_evidence_count: int = Field(ge=0)
    redundant_evidence_count: int = Field(ge=0)
    raw_content_evidence_count: int = Field(ge=0)
    unresolved_evidence_count: int = Field(ge=0)
    retained_evidence_count: int = Field(ge=0)
    unmapped_evidence_count: int = Field(ge=0)
    content_evidence_count: int = Field(default=0, ge=0)
    content_unit_count: int = Field(default=0, ge=0)
    content_model_bound_count: int = Field(default=0, ge=0)
    content_local_fallback_count: int = Field(default=0, ge=0)
    content_accounted_complete: bool = True
    content_semantic_coverage_ratio: float = Field(default=1.0, ge=0.0, le=1.0)
    content_accounting_ratio: float = Field(default=1.0, ge=0.0, le=1.0)
    evidence_coverage_ratio: float = Field(ge=0.0, le=1.0)
    semantic_accounting_ratio: float = Field(ge=0.0, le=1.0)
    evidence_accounting_ratio: float = Field(ge=0.0, le=1.0)
    retained_evidence_ratio: float = Field(ge=0.0, le=1.0)
    intent_calls: int = Field(ge=0)
    segment_calls: int = Field(ge=0)
    record_kind_calls: int = Field(default=0, ge=0)


_MODEL_DIAGNOSTIC_MAX_ITEMS = 8
_MODEL_DIAGNOSTIC_MAX_LOC_PARTS = 8
_MODEL_DIAGNOSTIC_MAX_TOKEN_LENGTH = 96
_DEFAULT_MODEL_REQUEST_LIMIT = 8
_RECORD_MAPPING_MAX_RETRIES = 1
_MODEL_DIAGNOSTIC_VALIDATION_TYPES = frozenset(
    {
        "bool_parsing",
        "dict_type",
        "enum",
        "extra_forbidden",
        "float_parsing",
        "int_parsing",
        "json_invalid",
        "list_type",
        "literal_error",
        "missing",
        "model_type",
        "string_too_long",
        "string_too_short",
        "string_type",
        "value_error",
    }
)
_MODEL_DIAGNOSTIC_PROVIDER_VALUES = frozenset(
    {
        "authentication_error",
        "bad_request",
        "context_length_exceeded",
        "insufficient_quota",
        "internal_server_error",
        "invalid_request_error",
        "json_schema_validation",
        "model_not_found",
        "rate_limit_error",
        "server_error",
        "service_unavailable",
        "timeout",
    }
)
_STRUCTURED_FAILURE_CODES = frozenset(
    {
        "STRUCTURED_MODEL_CALL_FAILED",
        "STRUCTURED_OUTPUT_SCHEMA_INVALID",
        "STRUCTURED_REQUEST_BUDGET_EXHAUSTED",
        "STRUCTURED_REQUEST_TIMEOUT",
    }
)
_STRUCTURED_FAILURE_REASONS = frozenset(
    {
        "model_call_failed",
        "request_budget_exhausted",
        "timeout",
        "unexpected_model_output",
    }
)


def _diagnostic_token(value: object, *, default: str = "") -> str:
    """Return a bounded identifier without copying arbitrary exception text."""

    if value is None:
        return default
    text = str(value).strip()
    if not text:
        return default
    # Class names, provider codes, and Pydantic error types are identifiers;
    # reject control characters and keep only a small bounded representation.
    text = "".join(character for character in text if character.isprintable())
    return text[:_MODEL_DIAGNOSTIC_MAX_TOKEN_LENGTH] or default


def _diagnostic_exception_type(value: object) -> str:
    exception_type = type(value)
    return _diagnostic_token(
        getattr(exception_type, "__name__", None),
        default="UnknownError",
    )


def _diagnostic_exception_chain(exception: BaseException) -> list[BaseException]:
    """Follow a short exception chain while avoiding cycles and huge graphs."""

    chain: list[BaseException] = []
    seen: set[int] = set()
    current: BaseException | None = exception
    while current is not None and id(current) not in seen and len(chain) < 6:
        seen.add(id(current))
        chain.append(current)
        cause = current.__cause__ or current.__context__
        current = cause if isinstance(cause, BaseException) else None
    return chain


def _diagnostic_http_status(exception: BaseException) -> int | None:
    """Read only an HTTP status from common provider/httpx exception shapes."""

    for candidate in _diagnostic_exception_chain(exception):
        status = getattr(candidate, "status_code", None)
        if isinstance(status, int) and 100 <= status <= 599:
            return status
        response = getattr(candidate, "response", None)
        response_status = getattr(response, "status_code", None)
        if isinstance(response_status, int) and 100 <= response_status <= 599:
            return response_status
    return None


def _diagnostic_provider_value(exception: BaseException, name: str) -> str | None:
    """Extract only allowlisted provider identifiers, never arbitrary text."""

    def safe_value(value: object) -> str | None:
        if isinstance(value, int):
            return str(value)
        if not isinstance(value, str):
            return None
        normalized = value.strip().casefold()
        return normalized if normalized in _MODEL_DIAGNOSTIC_PROVIDER_VALUES else None

    for candidate in _diagnostic_exception_chain(exception):
        value = getattr(candidate, name, None)
        if (safe := safe_value(value)) is not None:
            return safe
        body = getattr(candidate, "body", None)
        if isinstance(body, Mapping):
            error = body.get("error")
            if isinstance(error, Mapping):
                value = error.get(name)
                if (safe := safe_value(value)) is not None:
                    return safe
    return None


def _diagnostic_location_part(value: object) -> int | str:
    """Return an index or an opaque digest, never a schema/property value."""

    if isinstance(value, int) and 0 <= value <= 1_000_000:
        return value
    digest = hashlib.sha256(str(value).encode("utf-8", errors="replace")).hexdigest()
    return f"field#{digest[:12]}"


def _diagnostic_validation_errors(exception: BaseException) -> list[dict[str, Any]]:
    """Summarize Pydantic-like errors without retaining input or context values."""

    errors_method = getattr(exception, "errors", None)
    if not callable(errors_method):
        return []
    try:
        errors = errors_method(
            include_url=False,
            include_context=False,
            include_input=False,
        )
    except TypeError:
        try:
            errors = errors_method()
        except Exception:  # noqa: BLE001 - diagnostics must never mask fallback
            return []
    except Exception:  # noqa: BLE001 - diagnostics must never mask fallback
        return []
    if not isinstance(errors, list):
        return []
    summaries: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in errors:
        if not isinstance(item, Mapping):
            continue
        raw_loc = item.get("loc")
        if isinstance(raw_loc, (list, tuple)):
            location = [
                _diagnostic_location_part(part)
                for part in raw_loc[:_MODEL_DIAGNOSTIC_MAX_LOC_PARTS]
            ]
        elif raw_loc is None:
            location = []
        else:
            location = [_diagnostic_location_part(raw_loc)]
        candidate_type = str(item.get("type") or "").strip().casefold()
        error_type = (
            candidate_type
            if candidate_type in _MODEL_DIAGNOSTIC_VALIDATION_TYPES
            else "validation_error"
        )
        summary = {"loc": location, "type": error_type}
        key = json.dumps(summary, ensure_ascii=False, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        summaries.append(summary)
        if len(summaries) >= _MODEL_DIAGNOSTIC_MAX_ITEMS:
            break
    return summaries


def _diagnostic_reason(
    exception: BaseException,
    *,
    http_status: int | None = None,
) -> str:
    """Classify a failure using exception metadata, never its free-form text."""

    name = _diagnostic_exception_type(exception).casefold()
    if name == "instructorretryexception":
        return "retry_exhausted"
    if http_status is not None:
        return "http_error"
    if "timeout" in name or isinstance(exception, TimeoutError):
        return "timeout"
    if _diagnostic_validation_errors(exception):
        return "schema_validation"
    if "json" in name or "output" in name or "decode" in name:
        return "invalid_output"
    if "connection" in name or "transport" in name:
        return "transport_error"
    return "unknown"


def _diagnostic_attempt_payload(
    attempt: object,
) -> dict[str, Any] | None:
    exception = getattr(attempt, "exception", None)
    if not isinstance(exception, BaseException):
        return None
    status = _diagnostic_http_status(exception)
    attempt_number = getattr(attempt, "attempt_number", 1)
    try:
        attempt_number = max(1, int(attempt_number or 1))
    except (TypeError, ValueError):
        attempt_number = 1
    payload: dict[str, Any] = {
        "attempt": attempt_number,
        "exception_type": _diagnostic_exception_type(exception),
        "reason": _diagnostic_reason(exception, http_status=status),
        "validation_errors": _diagnostic_validation_errors(exception),
    }
    if status is not None:
        payload["http_status"] = status
    provider_code = _diagnostic_provider_value(exception, "code")
    provider_type = _diagnostic_provider_value(exception, "type")
    if provider_code is not None:
        payload["provider_error_code"] = provider_code
    if provider_type is not None:
        payload["provider_error_type"] = provider_type
    completion = getattr(attempt, "completion", None)
    if completion is not None:
        payload["completion_type"] = _diagnostic_token(
            type(completion).__name__,
            default="unknown",
        )
    return payload


def _model_failure_diagnostic(
    *,
    stage: str,
    response_model: type[BaseModel],
    exception: BaseException,
) -> ModelFailureDiagnostic:
    """Build a bounded diagnostic for an Instructor/transport failure.

    Deliberately do not inspect ``messages``, ``create_kwargs``,
    ``last_completion`` or exception string values: those can contain source
    document text, credentials, or complete provider responses.
    """

    status = _diagnostic_http_status(exception)
    structured_attempts = getattr(exception, "_m1_structured_attempts", None)
    if not isinstance(structured_attempts, int) or not 1 <= structured_attempts <= 100:
        structured_attempts = None
    structured_reason_value = getattr(
        exception,
        "_m1_structured_failure_reason",
        None,
    )
    structured_reason = (
        structured_reason_value
        if structured_reason_value in _STRUCTURED_FAILURE_REASONS
        else None
    )
    structured_code_value = getattr(
        exception,
        "_m1_structured_failure_code",
        None,
    )
    structured_code = (
        structured_code_value
        if structured_code_value in _STRUCTURED_FAILURE_CODES
        else None
    )
    chain = _diagnostic_exception_chain(exception)
    root_exception: BaseException | None = None
    failed_attempts = getattr(exception, "failed_attempts", None)
    attempt_payloads: list[dict[str, Any]] = []
    if isinstance(failed_attempts, (list, tuple)):
        # Instructor wraps provider exceptions; status/code/type therefore
        # often live on the last FailedAttempt rather than the wrapper.
        for attempt in failed_attempts:
            attempt_exception = getattr(attempt, "exception", None)
            if not isinstance(attempt_exception, BaseException):
                continue
            if status is None:
                status = _diagnostic_http_status(attempt_exception)
            if status is not None:
                break
        for attempt in failed_attempts[:_MODEL_DIAGNOSTIC_MAX_ITEMS]:
            payload = _diagnostic_attempt_payload(attempt)
            if payload is not None:
                attempt_payloads.append(payload)
        if attempt_payloads:
            last_exception = getattr(failed_attempts[-1], "exception", None)
            if isinstance(last_exception, BaseException):
                root_exception = last_exception
    if root_exception is None:
        for candidate in chain[1:]:
            root_exception = candidate
            break
    if root_exception is None and chain:
        root_exception = chain[0]

    validation_errors: list[dict[str, Any]] = []
    for candidate in ([root_exception] if root_exception else []) + chain:
        if not isinstance(candidate, BaseException):
            continue
        for summary in _diagnostic_validation_errors(candidate):
            if summary not in validation_errors:
                validation_errors.append(summary)
            if len(validation_errors) >= _MODEL_DIAGNOSTIC_MAX_ITEMS:
                break
        if len(validation_errors) >= _MODEL_DIAGNOSTIC_MAX_ITEMS:
            break

    attempt_count = getattr(exception, "n_attempts", None)
    if not isinstance(attempt_count, int) or not 1 <= attempt_count <= 100:
        attempt_count = (
            len(failed_attempts)
            if isinstance(failed_attempts, (list, tuple))
            else structured_attempts
        )
    total_usage = getattr(exception, "total_usage", None)
    if not isinstance(total_usage, int) or total_usage < 0:
        total_usage = None
    provider_code = _diagnostic_provider_value(exception, "code")
    provider_type = _diagnostic_provider_value(exception, "type")
    if isinstance(failed_attempts, (list, tuple)):
        for attempt in failed_attempts:
            attempt_exception = getattr(attempt, "exception", None)
            if not isinstance(attempt_exception, BaseException):
                continue
            if provider_code is None:
                provider_code = _diagnostic_provider_value(attempt_exception, "code")
            if provider_type is None:
                provider_type = _diagnostic_provider_value(attempt_exception, "type")
            if provider_code is not None and provider_type is not None:
                break
    if provider_code is None:
        provider_code = structured_code
    failed_attempt_count = (
        len(failed_attempts)
        if isinstance(failed_attempts, (list, tuple))
        else (structured_attempts or 0)
    )
    return ModelFailureDiagnostic(
        stage=_diagnostic_token(stage, default="unknown_stage"),
        response_model=_diagnostic_token(
            getattr(response_model, "__name__", None),
            default="UnknownModel",
        ),
        error_type=_diagnostic_exception_type(exception),
        reason=(structured_reason or _diagnostic_reason(exception, http_status=status)),
        root_error_type=(
            _diagnostic_exception_type(root_exception)
            if root_exception is not None
            else None
        ),
        http_status=status,
        provider_error_code=provider_code,
        provider_error_type=provider_type,
        attempt_count=attempt_count,
        failed_attempt_count=failed_attempt_count,
        total_usage_tokens=total_usage,
        validation_errors=validation_errors[:_MODEL_DIAGNOSTIC_MAX_ITEMS],
        failed_attempts=attempt_payloads,
    )


_ROUTE_CONTEXT_KEYS = frozenset(
    {
        "schema_family",
        "document_type_hint",
        "document_subtype_hint",
        "table_roles",
        "verifier_policy",
        "authority_policy",
    }
)
_ROUTE_SCHEMA_FAMILIES = frozenset(
    {
        "generic_layout",
        "open_domain",
        "order",
        "inventory",
        "equipment",
        "mold",
        "procurement",
        "technical",
        "archive",
    }
)
_ROUTE_DOCUMENT_TYPES = frozenset(
    {
        "order",
        "inventory",
        "equipment",
        "mold",
        "procurement",
        "technical_document",
        "commercial_document",
        "archive",
    }
)
_DOCUMENT_TYPE_DEFINITIONS = {
    "order": (
        "customer or supplier order, purchase contract, stocking order, quotation "
        "request, or other document whose purpose is to request or commit goods"
    ),
    "inventory": (
        "inventory snapshot or stock ledger describing quantities already held; "
        "the mere presence of a quantity column does not make a document inventory"
    ),
    "equipment": "equipment, machine, or fixed-asset register",
    "mold": "mold register, mold mapping, or mold status list",
    "procurement": "procurement receipt, requisition, purchase ledger, or sourcing ledger",
    "technical_document": (
        "product specification, drawing, approval sheet, test specification, process "
        "document, service policy, presentation, web document, or product photograph"
    ),
    "commercial_document": "commercial document without committed order lines",
    "archive": "archive or collection manifest rather than one business document",
    "unknown": "insufficient evidence to select any other type",
}
_DOCUMENT_SUBTYPE_DEFINITIONS = {
    "bill_of_materials": (
        "a bill of materials or cost/BOM analysis listing component materials, "
        "usage, units, formulas, or material costs; it is not a customer order"
    ),
    "service_policy": (
        "after-sales, warranty, repair, return, replacement, or service policy whose "
        "purpose is to state service coverage and terms"
    ),
    "product_photo": (
        "natural photograph whose primary subject is one or more physical products; "
        "not a scan, screenshot, drawing, form, or text-centric page"
    ),
}
_ROUTE_DOCUMENT_SUBTYPE_TYPES = {
    "stocking_order": "order",
    "customer_purchase_order": "order",
    "purchase_contract": "order",
    "supplier_purchase_order": "order",
    "sample_request": "order",
    "inventory_snapshot": "inventory",
    "equipment_register": "equipment",
    "mold_mapping": "mold",
    "purchase_receipt_ledger": "procurement",
    "purchase_requisition_ledger": "procurement",
    "purchase_order_ledger": "procurement",
    "bill_of_materials": "technical_document",
    "approval_drawing": "technical_document",
    "engineering_drawing": "technical_document",
    "product_specification": "technical_document",
    "process_document": "technical_document",
    "service_policy": "technical_document",
    "product_photo": "technical_document",
    "presentation": "technical_document",
    "web_document": "technical_document",
    "image_document": "technical_document",
    "archive": "archive",
}
OPEN_DOMAIN_DOCUMENT_SUBTYPES = frozenset(
    {
        "bill_of_materials",
        "service_policy",
        "product_photo",
        "presentation",
        "web_document",
        "image_document",
    }
)
_ROUTE_TABLE_ROLES = frozenset(
    {
        "key_value",
        "repeated_records",
        "layout",
        "title_block",
        "bom",
        "order_lines",
        "inventory_lines",
        "equipment_lines",
        "mold_mapping",
        "ignore",
    }
)
_ROUTE_PRIMARY_TABLE_ROLES = frozenset(
    {
        "repeated_records",
        "bom",
        "order_lines",
        "inventory_lines",
        "equipment_lines",
        "mold_mapping",
    }
)
_ROUTE_METADATA_TABLE_ROLES = frozenset({"key_value", "title_block"})
_ROUTE_NONPRIMARY_TABLE_ROLES = frozenset(
    {"key_value", "title_block", "layout", "ignore"}
)
_ROUTE_VERIFIER_POLICIES = frozenset({"disabled", "on_uncertainty", "always"})
_ROUTE_AUTHORITY_POLICIES = frozenset(
    {"core_strict", "evidence_required", "open_domain"}
)
_ROUTE_SCHEMA_TYPES = {
    "order": "order",
    "inventory": "inventory",
    "equipment": "equipment",
    "mold": "mold",
    "procurement": "procurement",
    "technical": "technical_document",
    "archive": "archive",
}


@dataclass(frozen=True, slots=True)
class _GuardedDocumentRouteContext:
    schema_family: str | None = None
    document_type_hint: str | None = None
    document_subtype_hint: str | None = None
    table_roles: tuple[tuple[int, str], ...] = ()
    verifier_policy: str | None = None
    authority_policy: str | None = None

    @property
    def generic_facts_only(self) -> bool:
        return self.schema_family in {"generic_layout", "open_domain"}

    def policy_advice(self) -> DocumentRoutePolicyAdvice | None:
        if not any((self.schema_family, self.verifier_policy, self.authority_policy)):
            return None
        return DocumentRoutePolicyAdvice(
            schema_family=self.schema_family,
            verifier_policy=self.verifier_policy,
            authority_policy=self.authority_policy,
        )


def _safe_route_enum(
    payload: Mapping[str, Any],
    key: str,
    allowed: frozenset[str],
    issues: list[str],
) -> str | None:
    if key not in payload or payload[key] is None:
        return None
    value = payload[key]
    if not isinstance(value, str) or value.strip() not in allowed:
        issues.append(f"ignored_document_route_context:invalid_{key}")
        return None
    return value.strip()


def _document_route_context(
    evidence: DocumentEvidence,
) -> tuple[_GuardedDocumentRouteContext, list[str]]:
    """Read only the bounded, value-free policy written by the routing runtime."""

    raw = evidence.raw if isinstance(evidence.raw, dict) else {}
    payload = raw.get("document_route_context")
    if payload is None:
        return _GuardedDocumentRouteContext(), []
    if not isinstance(payload, Mapping):
        return (
            _GuardedDocumentRouteContext(),
            ["ignored_document_route_context:not_object"],
        )

    issues: list[str] = []
    extra_count = sum(key not in _ROUTE_CONTEXT_KEYS for key in payload)
    if extra_count:
        issues.append(f"ignored_document_route_context:extra_keys:{extra_count}")
    schema_family = _safe_route_enum(
        payload,
        "schema_family",
        _ROUTE_SCHEMA_FAMILIES,
        issues,
    )
    document_type_hint = _safe_route_enum(
        payload,
        "document_type_hint",
        _ROUTE_DOCUMENT_TYPES,
        issues,
    )
    document_subtype_hint = _safe_route_enum(
        payload,
        "document_subtype_hint",
        frozenset(_ROUTE_DOCUMENT_SUBTYPE_TYPES),
        issues,
    )
    verifier_policy = _safe_route_enum(
        payload,
        "verifier_policy",
        _ROUTE_VERIFIER_POLICIES,
        issues,
    )
    authority_policy = _safe_route_enum(
        payload,
        "authority_policy",
        _ROUTE_AUTHORITY_POLICIES,
        issues,
    )

    table_roles: list[tuple[int, str]] = []
    table_payload = payload.get("table_roles")
    invalid_table_roles = 0
    if table_payload is not None:
        if not isinstance(table_payload, list) or len(table_payload) > 256:
            issues.append("ignored_document_route_context:invalid_table_roles")
        else:
            seen_indexes: set[int] = set()
            for item in table_payload:
                if (
                    not isinstance(item, Mapping)
                    or set(item) != {"table_index", "role"}
                    or type(item.get("table_index")) is not int
                    or not 0 <= item["table_index"] <= 255
                    or not isinstance(item.get("role"), str)
                    or item["role"].strip() not in _ROUTE_TABLE_ROLES
                    or item["table_index"] in seen_indexes
                ):
                    invalid_table_roles += 1
                    continue
                index = item["table_index"]
                seen_indexes.add(index)
                table_roles.append((index, item["role"].strip()))
    if invalid_table_roles:
        issues.append(
            "ignored_document_route_context:invalid_table_role_items:"
            f"{invalid_table_roles}"
        )
    table_roles.sort(key=lambda item: item[0])

    expected_subtype_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(
        document_subtype_hint or ""
    )
    if document_subtype_hint and (
        document_type_hint is None or expected_subtype_type != document_type_hint
    ):
        issues.append(
            "ignored_document_route_context:inconsistent_document_subtype_hint"
        )
        document_subtype_hint = None
    expected_schema_type = _ROUTE_SCHEMA_TYPES.get(schema_family or "")
    if (
        expected_schema_type is not None
        and document_type_hint is not None
        and document_type_hint != expected_schema_type
    ):
        issues.append("ignored_document_route_context:inconsistent_schema_type_hint")
        document_type_hint = None
        document_subtype_hint = None

    return (
        _GuardedDocumentRouteContext(
            schema_family=schema_family,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            table_roles=tuple(table_roles),
            verifier_policy=verifier_policy,
            authority_policy=authority_policy,
        ),
        issues,
    )


class InstructorAsyncClient(Protocol):
    """Small protocol shared by the real optional client and deterministic tests."""

    async def create(
        self,
        response_model: type[T],
        *,
        messages: list[dict[str, str]],
        max_retries: int,
    ) -> T: ...


class _OpenAIInstructorTransport:
    """Lazy Instructor wrapper so importing the POC never requires Instructor."""

    def __init__(
        self,
        *,
        client: Any,
        raw_client: Any,
        model: str,
        temperature: float,
        max_tokens: int,
        extra_body: dict[str, Any] | None,
    ) -> None:
        self._client = client
        self._raw_client = raw_client
        self._model = model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._extra_body = dict(extra_body or {})

    async def create(
        self,
        response_model: type[T],
        *,
        messages: list[dict[str, str]],
        max_retries: int,
    ) -> T:
        transport_model: type[BaseModel] = response_model
        field_axis_count: int | None = None
        if response_model is RecordFieldMapping:
            field_axis_count = _record_field_axis_count(messages)
            transport_model = _RecordFieldMappingOutput
        elif response_model is RecordKindMapping:
            transport_model = _RecordKindMappingOutput
        kwargs: dict[str, Any] = {
            "model": self._model,
            "response_model": transport_model,
            "messages": messages,
            "max_retries": max_retries,
            "temperature": self._temperature,
            "max_tokens": self._max_tokens,
        }
        if self._extra_body:
            kwargs["extra_body"] = self._extra_body
        result = await self._client.chat.completions.create(
            **kwargs,
        )
        if not isinstance(result, transport_model):
            raise TypeError("Instructor returned an unexpected response model")
        if response_model is RecordFieldMapping:
            return _validated_record_field_mapping(
                result,
                field_axis_count=field_axis_count,
            )
        if response_model is RecordKindMapping:
            return _validated_record_kind_mapping(result, messages=messages)
        return result

    async def probe(self) -> dict[str, Any]:
        await self._raw_client.models.list()
        return {"ready": True, "configured": True, "model": self._model}

    async def close(self) -> None:
        await self._raw_client.close()


class _PromptedOutputTransport:
    """PydanticAI transport for OpenAI-compatible models that reject JSON schema.

    The full-authority path previously sent ``response_format`` through
    Instructor's ``JSON_SCHEMA`` mode.  Several vLLM/Qwen deployments accept
    the request but return prose or a schema-incompatible object.  The shared
    ``StructuredModelClient`` already uses PromptedOutput and bounded
    validation retries for the other M1 model consumers, so keep this adapter
    limited to the small ``InstructorAsyncClient`` protocol used by the
    evidence-first extractor.
    """

    def __init__(self, client: Any, *, model: str) -> None:
        self._client = client
        self._model = model

    @staticmethod
    def _max_output_tokens(response_model: type[BaseModel]) -> int:
        return {
            DocumentClassification: 768,
            TablePartition: 1_536,
            BlockSemantics: 2_048,
            RecordFieldMapping: 512,
            RecordKindMapping: 4_096,
            SegmentExtraction: 3_072,
            DocumentIntent: 3_072,
        }.get(response_model, 2_048)

    @staticmethod
    def _split_messages(messages: list[dict[str, str]]) -> tuple[str, str]:
        instructions: list[str] = []
        prompt: list[str] = []
        for message in messages:
            role = str(message.get("role") or "user").casefold()
            content = str(message.get("content") or "")
            if not content:
                continue
            if role == "system":
                instructions.append(content)
            else:
                prompt.append(content)
        return "\n\n".join(instructions), "\n\n".join(prompt)

    @staticmethod
    def _segment_intent(messages: list[dict[str, str]]) -> SegmentIntent:
        for message in reversed(messages):
            if str(message.get("role") or "").casefold() != "user":
                continue
            try:
                payload = json.loads(str(message.get("content") or ""))
                intent = payload["evidence"]["intent"]
            except (KeyError, TypeError, json.JSONDecodeError):
                continue
            if intent in {"records", "metadata", "layout", "unknown"}:
                return intent
        raise ValueError("segment extraction requires a declared segment intent")

    async def create(
        self,
        response_model: type[T],
        *,
        messages: list[dict[str, str]],
        max_retries: int,
    ) -> T:
        instructions, prompt = self._split_messages(messages)
        output_type: type[BaseModel] = response_model
        segment_intent: SegmentIntent | None = None
        field_axis_count: int | None = None
        if response_model is SegmentExtraction:
            segment_intent = self._segment_intent(messages)
            output_type = (
                _SegmentRecordsOutput
                if segment_intent == "records"
                else _SegmentFactsOutput
            )
        elif response_model is RecordFieldMapping:
            field_axis_count = _record_field_axis_count(messages)
            output_type = _RecordFieldMappingOutput
        elif response_model is RecordKindMapping:
            output_type = _RecordKindMappingOutput
        run = await self._client.run(
            output_type,
            instructions=instructions,
            prompt=prompt,
            retries=max(0, min(2, int(max_retries))),
            max_tokens=self._max_output_tokens(response_model),
        )
        output = getattr(run, "output", run)
        if response_model is RecordFieldMapping:
            typed_output = (
                output
                if isinstance(output, _RecordFieldMappingOutput)
                else _RecordFieldMappingOutput.model_validate(output, strict=True)
            )
            return _validated_record_field_mapping(
                typed_output,
                field_axis_count=field_axis_count,
            )
        if response_model is RecordKindMapping:
            typed_output = (
                output
                if isinstance(output, _RecordKindMappingOutput)
                else _RecordKindMappingOutput.model_validate(output, strict=True)
            )
            return _validated_record_kind_mapping(typed_output, messages=messages)
        if response_model is SegmentExtraction:
            typed_output = (
                output
                if isinstance(output, output_type)
                else output_type.model_validate(output, strict=True)
            )
            if segment_intent == "records":
                return response_model(records=typed_output.records)
            return response_model(facts=typed_output.facts)
        if isinstance(output, response_model):
            return output
        # Keep the protocol strict even when a test/model override returns a
        # dictionary instead of the typed Pydantic object.
        return response_model.model_validate(output, strict=True)

    async def probe(self) -> dict[str, Any]:
        probe = getattr(self._client, "probe", None)
        if callable(probe):
            result = probe()
            if inspect.isawaitable(result):
                result = await result
            if isinstance(result, dict):
                return result
        return {"ready": True, "configured": True, "model": self._model}

    async def close(self) -> None:
        close = getattr(self._client, "close", None)
        if callable(close):
            result = close()
            if inspect.isawaitable(result):
                await result


class _OllamaNativeTransport:
    """Bounded native Ollama JSON-Schema transport without OpenAI emulation."""

    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        timeout: float,
        temperature: float,
        max_tokens: int,
        num_ctx: int,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._model = model
        self._temperature = float(temperature)
        self._max_tokens = max(1, int(max_tokens))
        self._num_ctx = max(1024, int(num_ctx))
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=max(0.001, float(timeout)),
            transport=transport,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def probe(self) -> dict[str, Any]:
        response = await self._client.get("/api/tags")
        response.raise_for_status()
        return {"ready": True, "configured": True, "model": self._model}

    @staticmethod
    def _grammar_schema(
        response_model: type[T],
        *,
        messages: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        """Keep schema shape while deferring unsupported limits to Pydantic."""

        unsupported = {
            "default",
            "maxItems",
            "minItems",
            "maximum",
            "minimum",
            "maxLength",
            "minLength",
            "title",
        }

        def clean(value: Any) -> Any:
            if isinstance(value, list):
                return [clean(item) for item in value]
            if not isinstance(value, dict):
                return value
            result = {
                key: clean(item)
                for key, item in value.items()
                if key not in unsupported
            }
            properties = result.get("properties")
            if result.get("type") == "object" and isinstance(properties, dict):
                # Ollama treats fields with Pydantic defaults as optional and
                # otherwise emits identity-only objects. Requiring the full
                # shape still leaves semantic validation to Pydantic below.
                result["required"] = list(properties)
            return result

        schema_model = (
            _RecordFieldMappingOutput
            if response_model is RecordFieldMapping
            else (
                _RecordKindMappingOutput
                if response_model is RecordKindMapping
                else response_model
            )
        )
        schema = clean(schema_model.model_json_schema())
        if not isinstance(schema, dict):  # pragma: no cover - Pydantic invariant
            raise TypeError("Pydantic produced a non-object JSON schema")
        if response_model is SegmentExtraction and messages:
            try:
                request = json.loads(messages[1]["content"])
                segment_intent = request["evidence"]["intent"]
            except (IndexError, KeyError, TypeError, json.JSONDecodeError):
                segment_intent = None
            selected = "records" if segment_intent == "records" else "facts"
            properties = schema.get("properties")
            if isinstance(properties, dict) and selected in properties:
                schema["properties"] = {selected: properties[selected]}
                schema["required"] = [selected]
        return schema

    @staticmethod
    def _correction_messages(
        messages: list[dict[str, str]],
        *,
        invalid_content: str,
        validation_error: ValidationError,
    ) -> list[dict[str, str]]:
        errors = validation_error.errors(
            include_url=False,
            include_context=False,
            include_input=False,
        )
        correction = {
            "task": "correct_structured_output",
            "instruction": (
                "Return only one JSON object that satisfies the required schema. "
                "Preserve supported facts and citations; remove or correct only "
                "the fields identified by validation_errors."
            ),
            "validation_errors": errors[:20],
        }
        return [
            *messages,
            {
                "role": "assistant",
                "content": invalid_content[:16_000],
            },
            {
                "role": "user",
                "content": json.dumps(
                    correction,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]

    async def create(
        self,
        response_model: type[T],
        *,
        messages: list[dict[str, str]],
        max_retries: int,
    ) -> T:
        retries = max(0, min(2, int(max_retries)))
        request_messages = list(messages)
        last_validation: ValidationError | None = None
        output_model: type[BaseModel] = response_model
        field_axis_count: int | None = None
        if response_model is RecordFieldMapping:
            field_axis_count = _record_field_axis_count(messages)
            output_model = _RecordFieldMappingOutput
        elif response_model is RecordKindMapping:
            output_model = _RecordKindMappingOutput
        for attempt in range(retries + 1):
            response = await self._client.post(
                "/api/chat",
                json={
                    "model": self._model,
                    "messages": request_messages,
                    "stream": False,
                    "think": False,
                    "format": self._grammar_schema(
                        response_model,
                        messages=messages,
                    ),
                    "options": {
                        "temperature": self._temperature,
                        "num_ctx": self._num_ctx,
                        "num_predict": self._max_tokens,
                    },
                },
            )
            response.raise_for_status()
            payload = response.json()
            message = payload.get("message") if isinstance(payload, dict) else None
            content = message.get("content") if isinstance(message, dict) else None
            if not isinstance(content, str):
                raise OllamaNativeOutputError(
                    "Ollama native response is missing message.content"
                )
            try:
                output = output_model.model_validate_json(content)
                if response_model is RecordFieldMapping:
                    return _validated_record_field_mapping(
                        output,
                        field_axis_count=field_axis_count,
                    )
                if response_model is RecordKindMapping:
                    return _validated_record_kind_mapping(output, messages=messages)
                return output
            except ValidationError as exc:
                last_validation = exc
                if attempt >= retries:
                    break
                request_messages = self._correction_messages(
                    messages,
                    invalid_content=content,
                    validation_error=exc,
                )
        attempts = retries + 1
        raise OllamaNativeOutputError(
            f"Ollama returned invalid structured output after {attempts} attempts"
        ) from last_validation


@dataclass(frozen=True, slots=True)
class _EvidenceItem:
    evidence_id: str
    text: str
    source_ref: SourceReference
    exact_text: str | None = None
    table_id: str | None = None
    row: int | None = None
    column: int | None = None
    positioned: bool = True
    source_kind: str = "text"


def _normalize(value: object) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).split())


def _segment_id(
    table_id: str,
    orientation: RecordOrientation,
    start: int,
    end: int,
) -> str:
    payload = f"{table_id}\x1f{orientation}\x1f{start}\x1f{end}"
    return f"mineru-instructor-{hashlib.sha256(payload.encode()).hexdigest()[:20]}"


def _source_reference_provenance_extras(
    model_extra: dict[str, Any],
) -> dict[str, Any]:
    """Carry additive native and visual-asset provenance into field citations."""

    extras: dict[str, Any] = {}
    if model_extra.get("native_source_refs"):
        extras["native_source_refs"] = model_extra["native_source_refs"]
    for key in (
        "derived_from_table",
        "derived_geometry",
        "inferred",
        "raw_ocr_indices",
    ):
        if key in model_extra and model_extra[key] is not None:
            extras[key] = model_extra[key]
    extras.update(
        {
            key: value
            for key, value in model_extra.items()
            if key.startswith("asset_") and value is not None
        }
    )
    if any(key.startswith("asset_") for key in extras):
        # Image captions are useful evidence, but they are model-generated and
        # must never outrank native text or deterministic table cells.
        extras.update({"authority": "advisory", "inferred": True})
    return extras


def _source_ref_for_block(page_number: int, block: EvidenceBlock) -> SourceReference:
    model_extra = block.model_extra or {}
    extras = _source_reference_provenance_extras(model_extra)
    if block.bbox is not None:
        extras.update(
            {
                "bbox": block.bbox.as_list(),
                "coordinate_space": block.bbox.coordinate_space,
            }
        )
    part = str(model_extra.get("source_ref_part") or f"mineru/{block.block_id}")
    native_refs = extras.get("native_source_refs") or []
    native_cell = next(
        (
            reference
            for reference in native_refs
            if isinstance(reference, dict)
            and reference.get("sheet")
            and reference.get("cell")
        ),
        None,
    )
    if native_cell is not None:
        return SourceReference(
            page=page_number,
            sheet=str(native_cell["sheet"]),
            cell=str(native_cell["cell"]),
            part=part,
            **extras,
        )
    return SourceReference(page=page_number, part=part, **extras)


def _source_ref_for_cell(
    page_number: int,
    table: EvidenceTable,
    cell: EvidenceCell,
) -> SourceReference:
    model_extra = cell.model_extra or {}
    extras = _source_reference_provenance_extras(model_extra)
    if cell.bbox is not None:
        extras.update(
            {
                "bbox": cell.bbox.as_list(),
                "coordinate_space": cell.bbox.coordinate_space,
            }
        )
    sheet = model_extra.get("sheet")
    coordinate = model_extra.get("cell")
    if sheet and coordinate:
        inherited_from = model_extra.get("inherited_from")
        merged_range = model_extra.get("merged_range")
        physical_coordinate = inherited_from or coordinate
        extras.update(
            {
                "source_row": model_extra.get("source_row"),
                "source_column": model_extra.get("source_column"),
            }
        )
        if inherited_from:
            extras.update(
                {
                    "inherited_from_merge": True,
                    "logical_cell": str(coordinate),
                    "logical_source_row": model_extra.get("source_row"),
                    "logical_source_column": model_extra.get("source_column"),
                }
            )
        return SourceReference(
            page=page_number,
            sheet=str(sheet),
            cell=str(physical_coordinate),
            range=str(merged_range) if merged_range else None,
            part=f"spreadsheet/{sheet}/{physical_coordinate}",
            **extras,
        )
    return SourceReference(
        page=page_number,
        part=f"mineru/{table.table_id}/r{cell.row}/c{cell.column}",
        **extras,
    )


def _source_ref_for_unpositioned_table_value(
    page_number: int,
    table: EvidenceTable,
    *,
    row: int,
    column: int,
) -> SourceReference:
    """Preserve a row value even when MinerU omitted its cell geometry."""

    extras = _source_reference_provenance_extras(table.model_extra or {})
    extras["coordinate_inferred"] = True
    if table.bbox is not None:
        extras.update(
            {
                "bbox": table.bbox.as_list(),
                "coordinate_space": table.bbox.coordinate_space,
            }
        )
    return SourceReference(
        page=page_number,
        part=f"mineru/{table.table_id}/r{row}/c{column}",
        **extras,
    )


def evidence_inventory(evidence: DocumentEvidence) -> dict[str, _EvidenceItem]:
    """Index every non-empty block and recovered table cell exactly once."""

    items: dict[str, _EvidenceItem] = {}
    for page in evidence.pages:
        for block in page.blocks:
            text = _normalize(block.text)
            if not text:
                continue
            if block.block_id in items:
                raise ValueError(f"duplicate MinerU evidence id: {block.block_id}")
            items[block.block_id] = _EvidenceItem(
                evidence_id=block.block_id,
                text=text,
                source_ref=_source_ref_for_block(page.page_number, block),
                exact_text=block.text,
                source_kind=_normalize(block.kind).casefold() or "text",
            )
        for table in page.tables:
            seen_coordinates: set[tuple[int, int]] = set()
            for cell in table.cells:
                coordinate = (cell.row, cell.column)
                if coordinate in seen_coordinates:
                    raise ValueError(
                        f"duplicate MinerU cell coordinate: {table.table_id}:{coordinate}"
                    )
                seen_coordinates.add(coordinate)
                if cell.row >= len(table.rows) or cell.column >= len(
                    table.rows[cell.row]
                ):
                    raise ValueError(
                        f"MinerU cell falls outside recovered rows: {table.table_id}:{coordinate}"
                    )
                text = _normalize(cell.text)
                if not text:
                    continue
                evidence_id = f"{table.table_id}:r{cell.row}:c{cell.column}"
                if evidence_id in items:
                    raise ValueError(f"duplicate MinerU evidence id: {evidence_id}")
                items[evidence_id] = _EvidenceItem(
                    evidence_id=evidence_id,
                    text=text,
                    source_ref=_source_ref_for_cell(page.page_number, table, cell),
                    exact_text=cell.text,
                    table_id=table.table_id,
                    row=cell.row,
                    column=cell.column,
                    source_kind="table_cell",
                )
            for row, values in enumerate(table.rows):
                for column, value in enumerate(values):
                    text = _normalize(value)
                    if not text:
                        continue
                    evidence_id = f"{table.table_id}:r{row}:c{column}"
                    existing = items.get(evidence_id)
                    if existing is not None:
                        if existing.text != text:
                            raise ValueError(
                                "MinerU row/cell text mismatch: "
                                f"{table.table_id}:r{row}:c{column}"
                            )
                        continue
                    items[evidence_id] = _EvidenceItem(
                        evidence_id=evidence_id,
                        text=text,
                        source_ref=_source_ref_for_unpositioned_table_value(
                            page.page_number,
                            table,
                            row=row,
                            column=column,
                        ),
                        exact_text=str(value),
                        table_id=table.table_id,
                        row=row,
                        column=column,
                        positioned=False,
                        source_kind="table_cell",
                    )
    return items


def _same_bbox(left: Any, right: Any) -> bool:
    if left is None or right is None:
        return False
    if left.coordinate_space != right.coordinate_space:
        return False
    return all(
        abs(first - second) <= 1e-6
        for first, second in zip(left.as_list(), right.as_list())
    )


def _pipe_value_sequence(value: str) -> list[str]:
    return [
        normalized
        for token in re.split(r"[|\r\n]+", value)
        if (normalized := _normalize(token))
    ]


def _redundant_table_block_ids(evidence: DocumentEvidence) -> set[str]:
    """Find provider table blocks that exactly duplicate recovered table cells."""

    result: set[str] = set()
    for page in evidence.pages:
        candidates = [
            (
                table,
                [
                    normalized
                    for row in table.rows
                    for value in row
                    if (normalized := _normalize(value))
                ],
            )
            for table in page.tables
        ]
        for block in page.blocks:
            if block.kind.casefold() != "table" or not _normalize(block.text):
                continue
            block_values = _pipe_value_sequence(block.text)
            if not block_values:
                continue
            block_item_index = (block.model_extra or {}).get("mineru_item_index")
            declared_table_id = str((block.model_extra or {}).get("table_id") or "")
            for table, table_values in candidates:
                if declared_table_id and declared_table_id != table.table_id:
                    continue
                table_item_index = (table.model_extra or {}).get("mineru_item_index")
                if (
                    block_item_index is not None
                    and block_item_index == table_item_index
                    and _same_bbox(block.bbox, table.bbox)
                ):
                    result.add(block.block_id)
                    break
                if block_values == table_values and _same_bbox(block.bbox, table.bbox):
                    result.add(block.block_id)
                    break
    return result


_REDUNDANT_DIMENSION_LINE_RE = re.compile(
    r"^(?P<prefix>[RrΦφØ]?[ \t]*)?"
    r"(?P<nominal>\d+(?:[.,]\d+)?)"
    r"(?P<tolerance>[ \t]*(?:±|\+|-)[ \t]*\d+(?:[.,]\d+)?)?"
    r"[ \t]*(?P<unit>mm|cm|inch|in|m)?$",
    re.IGNORECASE,
)


def _redundant_line_keys(value: str) -> set[str]:
    normalized = _normalize(value)
    keys = {f"exact:{normalized}"} if len(normalized) >= 6 else set()
    match = _REDUNDANT_DIMENSION_LINE_RE.fullmatch(normalized)
    if match is None or not (
        str(match.group("prefix") or "").strip()
        or match.group("tolerance")
        or match.group("unit")
    ):
        return keys
    canonical = re.sub(r"(?<=\d),(?=\d)", ".", normalized)
    canonical = re.sub(r"[ \t]+", "", canonical).casefold()
    keys.add(f"dimension:{canonical}")
    return keys


def _redundant_consumed_block_ids(
    inventory: dict[str, _EvidenceItem],
    consumed: set[str],
) -> set[str]:
    """Identify retained block evidence that exactly repeats consumed lines."""

    consumed_lines: set[str] = set()
    for evidence_id in consumed:
        item = inventory.get(evidence_id)
        if item is None or item.table_id is not None:
            continue
        for line in (item.exact_text or item.text).splitlines():
            consumed_lines.update(_redundant_line_keys(line))
    if not consumed_lines:
        return set()

    redundant: set[str] = set()
    for evidence_id, item in inventory.items():
        if evidence_id in consumed or item.table_id is not None:
            continue
        provenance = item.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get(
            "asset_sha256"
        ):
            continue
        lines = [
            keys
            for line in (item.exact_text or item.text).splitlines()
            if (keys := _redundant_line_keys(line))
        ]
        if lines and all(
            bool(keys & consumed_lines)
            for keys in lines
        ):
            redundant.add(evidence_id)
    return redundant


def _table_axis_size(table: EvidenceTable, orientation: RecordOrientation) -> int:
    if orientation == "rows":
        return len(table.rows)
    return max((len(row) for row in table.rows), default=0)


def _table_payload(table: EvidenceTable) -> dict[str, Any]:
    """Serialize every cell and every row; never sample or truncate source evidence."""

    return {
        "table_id": table.table_id,
        "rows": [list(row) for row in table.rows],
        "cells": [
            {
                "evidence_id": f"{table.table_id}:r{cell.row}:c{cell.column}",
                "row": cell.row,
                "column": cell.column,
                "value": cell.text,
            }
            for cell in table.cells
            if _normalize(cell.text)
        ],
    }


def _spread_indices(size: int, limit: int) -> list[int]:
    if size <= limit:
        return list(range(size))
    if limit <= 1:
        return [0]
    return sorted({round(index * (size - 1) / (limit - 1)) for index in range(limit)})


def _intent_table_payload(table: EvidenceTable) -> dict[str, Any]:
    """Provide document structure without putting an entire long table in one call."""

    row_indices = _spread_indices(len(table.rows), 12)
    width = max((len(row) for row in table.rows), default=0)
    column_indices = _spread_indices(width, 24)
    return {
        "table_id": table.table_id,
        "row_count": len(table.rows),
        "column_count": width,
        "sampled": len(row_indices) < len(table.rows) or len(column_indices) < width,
        "sample_rows": [
            {
                "row": row_index,
                "cells": [
                    {
                        "evidence_id": f"{table.table_id}:r{row_index}:c{column}",
                        "column": column,
                        "value": str(table.rows[row_index][column])[:200],
                        "truncated": len(str(table.rows[row_index][column])) > 200,
                    }
                    for column in column_indices
                    if column < len(table.rows[row_index])
                    and _normalize(table.rows[row_index][column])
                ],
            }
            for row_index in row_indices
        ],
    }


def _evidence_payload(evidence: DocumentEvidence) -> dict[str, Any]:
    return {
        "backend": evidence.backend,
        "backend_version": evidence.backend_version,
        "blocks": [
            {
                "evidence_id": block.block_id,
                "page": page.page_number,
                "kind": block.kind,
                "visual_asset": bool((block.model_extra or {}).get("asset_sha256")),
                "value": block.text[:800],
                "truncated": len(block.text) > 800,
            }
            for page in evidence.pages
            for block in page.blocks
            if (
                _normalize(block.text)
                and block.kind != "table"
                # Visual captions are advisory and can be numerous. They are
                # retained as content units, but must not steer document intent
                # or crowd native facts out of the bounded classifier request.
                and not (block.model_extra or {}).get("asset_sha256")
            )
        ],
        "tables": [
            {
                "page": page.page_number,
                **_intent_table_payload(table),
            }
            for page in evidence.pages
            for table in page.tables
            if not (table.model_extra or {}).get("asset_sha256")
            and not (table.model_extra or {}).get("derived_geometry")
        ],
    }


def _classification_evidence_payload(
    evidence: DocumentEvidence,
    *,
    max_payload_chars: int,
) -> dict[str, Any]:
    """Build a bounded classifier view while retaining every table identity."""

    budget = max(256, int(max_payload_chars))
    payload: dict[str, Any] = {
        "backend": evidence.backend,
        "backend_version": evidence.backend_version,
        "page_count": len(evidence.pages),
        "source_filename": str((evidence.raw or {}).get("source_filename") or "")[:240],
        # Preserve the first-page purpose signal before table samples consume
        # the bounded request. This is source text, not a locally assigned
        # class, so the model still owns the open-format classification.
        "title_region_text": _native_title_text(evidence)[:1_200],
        "blocks": [],
        "tables": [],
    }

    def fits() -> bool:
        return (
            len(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
            <= budget
        )

    table_entries: list[tuple[EvidenceTable, dict[str, Any]]] = []
    for page in evidence.pages:
        for table in page.tables:
            if (table.model_extra or {}).get("asset_sha256") or (
                table.model_extra or {}
            ).get("derived_geometry"):
                continue
            width = max((len(row) for row in table.rows), default=0)
            entry: dict[str, Any] = {
                "table_id": table.table_id,
                "page": page.page_number,
                "row_count": len(table.rows),
                "column_count": width,
                "sampled": True,
                "sample_rows": [],
            }
            payload["tables"].append(entry)
            if not fits():
                payload["tables"].pop()
                continue
            table_entries.append((table, entry))

    for table, entry in table_entries:
        width = int(entry["column_count"])
        row_indices = sorted(
            {
                *range(min(4, len(table.rows))),
                *_spread_indices(len(table.rows), min(4, len(table.rows))),
            }
        )
        column_indices = sorted(
            {
                *range(min(8, width)),
                *_spread_indices(width, min(8, width)),
            }
        )
        for row_index in row_indices:
            row_entry = {
                "row": row_index,
                "cells": [
                    {
                        "column": column,
                        "value": str(table.rows[row_index][column])[:80],
                    }
                    for column in column_indices
                    if column < len(table.rows[row_index])
                    and _normalize(table.rows[row_index][column])
                ],
            }
            entry["sample_rows"].append(row_entry)
            if not fits():
                entry["sample_rows"].pop()
                break
        entry["sampled"] = (
            len(entry["sample_rows"]) < len(table.rows) or len(column_indices) < width
        )

    block_candidates = [
        (page.page_number, block)
        for page in evidence.pages
        for block in page.blocks
        if _normalize(block.text)
        and block.kind != "table"
        and not (block.model_extra or {}).get("asset_sha256")
    ]
    for selected in _spread_indices(len(block_candidates), 8):
        page_number, block = block_candidates[selected]
        entry = {
            "evidence_id": block.block_id,
            "page": page_number,
            "kind": block.kind,
            "value": block.text[:240],
            "truncated": len(block.text) > 240,
        }
        payload["blocks"].append(entry)
        if not fits():
            payload["blocks"].pop()
            break
    return payload


def _compact_classification_messages(
    evidence: DocumentEvidence,
    *,
    max_input_chars: int,
    semantic_execution: SemanticExecutionSpec | None,
) -> tuple[dict[str, Any], list[dict[str, str]]]:
    """Keep one classifier request within its complete prompt budget.

    Type and subtype definitions are part of the classification contract and
    must never be silently dropped to make room for a large workbook.  Only the
    sampled evidence view is reduced; the authoritative evidence remains in
    ``DocumentEvidence`` and is projected locally later in the pipeline.
    """

    constraints = {
        "allowed_document_types": sorted(_ROUTE_DOCUMENT_TYPES),
        "document_type_definitions": _DOCUMENT_TYPE_DEFINITIONS,
        "allowed_document_subtypes": sorted(_ROUTE_DOCUMENT_SUBTYPE_TYPES),
        "document_subtype_definitions": _DOCUMENT_SUBTYPE_DEFINITIONS,
    }
    evidence_budget = max(256, int(max_input_chars))
    last_budget = -1
    while evidence_budget != last_budget:
        last_budget = evidence_budget
        payload = _classification_evidence_payload(
            evidence,
            max_payload_chars=evidence_budget,
        )
        payload.update(constraints)
        messages = _messages(
            role="document_classification",
            payload=payload,
            semantic_execution=semantic_execution,
        )
        overflow = _prompt_size(messages) - max_input_chars
        if overflow <= 0:
            return payload, messages
        evidence_budget = max(256, evidence_budget - overflow - 128)

    # The fixed definitions are deliberately small enough for the compact
    # contract.  If an unusually long execution directive consumes the rest of
    # the budget, retain only source identity and let the caller use its normal
    # no-call fallback rather than issuing an oversized request.
    payload = {
        "backend": evidence.backend,
        "backend_version": evidence.backend_version,
        "page_count": len(evidence.pages),
        "source_filename": str((evidence.raw or {}).get("source_filename") or "")[:240],
        "title_region_text": _native_title_text(evidence)[:1_200],
        "blocks": [],
        "tables": [],
        **constraints,
    }
    return payload, _messages(
        role="document_classification",
        payload=payload,
        semantic_execution=semantic_execution,
    )


def _is_native_spreadsheet_evidence(evidence: DocumentEvidence) -> bool:
    """Return whether exact workbook cells, rather than OCR rows, are authoritative."""

    return evidence.backend.casefold() == "spreadsheet-envelope"


def _block_semantic_payloads(
    evidence: DocumentEvidence,
    *,
    max_input_chars: int,
    max_blocks: int = 16,
) -> list[dict[str, Any]]:
    blocks = _evidence_payload(evidence)["blocks"]
    batches: list[dict[str, Any]] = []
    current: list[dict[str, Any]] = []
    for block in blocks:
        candidate = [*current, block]
        payload = {"blocks": candidate}
        if current and (
            len(candidate) > max_blocks
            or _prompt_size(_messages(role="block_semantics", payload=payload))
            > max_input_chars
        ):
            batches.append({"blocks": current})
            current = [block]
        else:
            current = candidate
    if current:
        batches.append({"blocks": current})
    return batches


_SPREADSHEET_EXPLICIT_TITLE_MARKERS = frozenset({"采购合同", "备货单"})


def _is_horizontal_spreadsheet_merge(cell: EvidenceCell) -> bool:
    merged_range = _normalize((cell.model_extra or {}).get("merged_range"))
    if not merged_range:
        return False
    local_range = merged_range.rsplit("!", 1)[-1]
    match = re.fullmatch(
        r"\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)",
        local_range,
        flags=re.IGNORECASE,
    )
    if match is None:
        return False
    start_column, start_row, end_column, end_row = match.groups()
    return start_row == end_row and start_column.casefold() != end_column.casefold()


def _spreadsheet_title_cells(table: EvidenceTable) -> list[str]:
    top_rows: dict[int, list[EvidenceCell]] = {}
    for cell in table.cells:
        extras = cell.model_extra or {}
        source_row = extras.get("source_row")
        text = _normalize(cell.text)
        horizontal_merge = _is_horizontal_spreadsheet_merge(cell)
        if (
            not isinstance(source_row, int)
            or not 1 <= source_row <= 4
            or not text
            or extras.get("hidden_row")
            or (extras.get("hidden_column") and not horizontal_merge)
        ):
            continue
        top_rows.setdefault(source_row, []).append(cell)

    titles: list[str] = []
    for cells in top_rows.values():
        isolated_row = len(cells) == 1
        for cell in cells:
            horizontal_merge = _is_horizontal_spreadsheet_merge(cell)
            marker_lines = {
                compact
                for line in str(cell.text or "").splitlines()
                if (compact := _normalize(line).replace(" ", ""))
                in _SPREADSHEET_EXPLICIT_TITLE_MARKERS
            }
            if not marker_lines:
                continue
            # Some spreadsheet producers hide the anchor column of a visible
            # horizontal merge. The anchor still owns the displayed title, so
            # its hidden-column flag must not discard the merged evidence.
            if isolated_row or horizontal_merge:
                titles.extend(sorted(marker_lines))
    return titles


_GENERIC_ORDER_TITLE_RE = re.compile(
    r"(?i)^(?!.*(?:订单号|订单编号|order\s*(?:no|number))\s*[:：])"
    r".{0,96}(?:订单|order)\s*$"
)


def _native_generic_order_title(evidence: DocumentEvidence) -> str:
    """Return one explicit top-row order title, never an order-number field."""

    if not evidence.pages:
        return ""
    page = evidence.pages[0]
    candidates: list[str] = []
    for table in page.tables:
        rows: dict[int, list[EvidenceCell]] = {}
        for cell in table.cells:
            extras = cell.model_extra or {}
            source_row = extras.get("source_row")
            if not isinstance(source_row, int):
                source_row = cell.row + 1
            text = _normalize(cell.text)
            if (
                source_row > 4
                or not text
                or extras.get("hidden_row")
                or not _GENERIC_ORDER_TITLE_RE.fullmatch(text)
            ):
                continue
            rows.setdefault(source_row, []).append(cell)
        for cells in rows.values():
            for cell in cells:
                if len(cells) == 1 or _is_horizontal_spreadsheet_merge(cell):
                    candidates.append(_normalize(cell.text))
    unique = list(dict.fromkeys(candidates))
    if len(unique) == 1:
        return unique[0]

    filename = _normalize((evidence.raw or {}).get("source_filename"))
    stem = re.sub(r"\.[A-Za-z0-9]{1,8}$", "", filename).strip()
    if not unique and len(stem) <= 128 and _GENERIC_ORDER_TITLE_RE.fullmatch(stem):
        return stem
    return ""


def _native_title_text(evidence: DocumentEvidence) -> str:
    if not evidence.pages:
        return ""
    page = evidence.pages[0]
    values: list[str] = []
    for block in page.blocks:
        if (block.model_extra or {}).get("asset_sha256"):
            continue
        explicit_heading = _normalize(block.kind).casefold() in {"title", "heading"}
        if not explicit_heading and block.bbox is None:
            continue
        if not explicit_heading and page.height:
            assert block.bbox is not None
            y0 = block.bbox.y0
            if block.bbox.coordinate_space == "normalized":
                if y0 > 0.35:
                    continue
            elif y0 / page.height > 0.35:
                continue
        values.append(block.text)
    for table in page.tables:
        if (table.model_extra or {}).get("asset_sha256"):
            continue
        if table.bbox is None:
            if evidence.backend == "spreadsheet-envelope":
                values.extend(_spreadsheet_title_cells(table))
            continue
        y0 = table.bbox.y0
        if table.bbox.coordinate_space == "normalized":
            if y0 > 0.35:
                continue
        elif y0 / page.height > 0.35:
            continue
        values.extend(str(value) for row in table.rows[:4] for value in row)
    return _normalize("\n".join(values))


_PRODUCT_SPECIFICATION_TITLE_MARKERS = (
    "产品规格书",
    "产品承认书",
    "product specification",
    "product datasheet",
    "technical datasheet",
)
_PRODUCT_SPECIFICATION_SIGNAL_GROUPS = (
    ("产品编号", "产品料号", "product number", "product code"),
    ("产品名称", "product name"),
    ("规格参数", "technical parameter", "specification parameter"),
    ("接口类型", "interface type"),
    ("支持协议", "protocol"),
    ("带宽", "bandwidth", "gbps"),
    ("分辨率", "resolution"),
    ("工作电压", "operating voltage"),
    ("传输距离", "transmission distance"),
    ("工作温度", "储存温度", "operating temperature", "storage temperature"),
)

_TECHNICAL_DRAWING_SIGNAL_GROUPS = (
    ("dwg no", "drawing no", "drawing number", "图号"),
    ("part no", "part number", "零件号", "料号"),
    ("scale", "比例", "1:1"),
    ("revision", "reviser", "version", "版本", "版次"),
    ("tolerance", "公差", "±", "+/-"),
    ("drawn", "designed", "checked", "approved", "审核", "批准"),
    (
        "third angle projection",
        "surface roughness",
        "投影法",
        "表面粗糙度",
    ),
    (
        "镭雕",
        "laser engraving",
        "示图",
        "engineering drawing",
        "technical line drawing",
        "工程图",
        "装配图",
        "外形图",
    ),
    ("正面", "反面", "front view", "rear view", "side view", "俯视图"),
)
_TECHNICAL_SPECIFICATION_SIGNAL_GROUPS = (
    ("electrical test", "electrical characteristic", "电气特性", "电气测试"),
    ("mechanical", "mechanical characteristic", "机械特性", "机械测试"),
    (
        "rohs",
        "reach",
        "environmental protection",
        "环保测试",
        "环境测试",
    ),
    (
        "operating temperature",
        "storage temperature",
        "使用温度",
        "工作温度",
        "储存温度",
    ),
    (
        "insulation resistance",
        "contact resistance",
        "withstand voltage",
        "绝缘阻抗",
        "接触阻抗",
        "耐电压",
    ),
    ("durability", "tensile strength", "耐力测试", "拉力测试", "插拔测试"),
)
_COMMERCIAL_DOCUMENT_SIGNAL_GROUPS = (
    (
        "purchase order",
        "sales order",
        "采购合同",
        "采购订单",
        "销售订单",
        "备货单",
        "样品需求单",
        "样品申请单",
        "样品单",
        "订货单",
        "订单",
    ),
    (
        "buyer",
        "seller",
        "supplier",
        "purchaser",
        "甲方",
        "乙方",
        "采购方",
        "供应商",
    ),
    ("unit price", "total amount", "tax rate", "单价", "金额", "税率"),
    (
        "delivery date",
        "payment terms",
        "交货日期",
        "付款方式",
        "结算方式",
        "收货地址",
    ),
    ("order no", "po no", "contract no", "订单号", "合同编号", "合同号"),
)
_TECHNICAL_DIMENSION_RE = re.compile(
    r"(?:[ØΦR]\s*)?\d+(?:\.\d+)?\s*(?:±|\+/-)\s*\d+(?:\.\d+)?",
    re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class _TechnicalDocumentSignals:
    drawing_groups: int
    specification_groups: int
    commercial_groups: int
    dimension_count: int
    order_marker: bool

    @property
    def is_technical_document(self) -> bool:
        technical_groups = self.drawing_groups + self.specification_groups
        has_technical_shape = (
            self.specification_groups >= 3
            or self.drawing_groups >= 3
            or (self.dimension_count >= 4 and self.drawing_groups >= 2)
        )
        return (
            has_technical_shape
            and not self.order_marker
            and self.commercial_groups <= 1
            and technical_groups >= self.commercial_groups + 3
        )

    @property
    def subtype(self) -> str | None:
        if not self.is_technical_document:
            return None
        if self.specification_groups >= 3:
            return "product_specification"
        return "engineering_drawing"


def _technical_document_signals(
    text: str,
    *,
    order_anchor_text: str | None = None,
) -> _TechnicalDocumentSignals:
    folded = _normalize(text).casefold()
    anchor = (
        _normalize(order_anchor_text).casefold()
        if order_anchor_text is not None
        else folded
    )

    def matched_groups(groups: tuple[tuple[str, ...], ...]) -> int:
        return sum(
            any(_normalize(marker).casefold() in folded for marker in group)
            for group in groups
        )

    return _TechnicalDocumentSignals(
        drawing_groups=matched_groups(_TECHNICAL_DRAWING_SIGNAL_GROUPS),
        specification_groups=matched_groups(_TECHNICAL_SPECIFICATION_SIGNAL_GROUPS),
        commercial_groups=matched_groups(_COMMERCIAL_DOCUMENT_SIGNAL_GROUPS),
        dimension_count=len(_TECHNICAL_DIMENSION_RE.findall(folded)),
        order_marker=any(
            _normalize(marker).casefold() in anchor
            for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[0]
        ),
    )


def _table_axis_value(
    table: EvidenceTable,
    orientation: RecordOrientation,
    axis: int,
    field_axis: int,
) -> str:
    row, column = (axis, field_axis) if orientation == "rows" else (field_axis, axis)
    if row >= len(table.rows) or column >= len(table.rows[row]):
        return ""
    return _normalize(table.rows[row][column])


def _has_commercial_record_structure(evidence: DocumentEvidence) -> bool:
    """Detect an order commitment, not merely a generic repeated-record table."""

    identity_targets = {
        "model",
        "product_code",
        "name_raw",
        "specification_raw",
    }
    quantity_targets = {
        "quantity",
        "package_quantity",
        "piece_count",
    }
    price_amount_targets = {
        "unit_price_tax_included",
        "amount_tax_included",
        "unit_price_tax_excluded",
        "amount_tax_excluded",
    }
    allowed_targets = allowed_line_targets("order")
    title_text = _native_title_text(evidence).casefold()
    native_text = _native_evidence_text(evidence).casefold()
    title_has_order_anchor = any(
        _normalize(marker).casefold() in title_text
        for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[0]
    )
    native_has_order_identifier = any(
        _normalize(marker).casefold() in native_text
        for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[4]
    )
    native_has_parties = any(
        _normalize(marker).casefold() in native_text
        for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[1]
    )
    native_has_delivery = any(
        _normalize(marker).casefold() in native_text
        for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[3]
    )
    quantity_commitment_context = (
        title_has_order_anchor
        or native_has_order_identifier
        or (native_has_parties and native_has_delivery)
    )
    for page in evidence.pages:
        for table in page.tables:
            if (table.model_extra or {}).get("asset_sha256") or not table.rows:
                continue
            width = max((len(row) for row in table.rows), default=0)
            for orientation in ("rows", "columns"):
                axis_size = len(table.rows) if orientation == "rows" else width
                field_size = width if orientation == "rows" else len(table.rows)

                for label_axis in range(axis_size):
                    targets_by_field: dict[int, str] = {}
                    identity_fields: set[int] = set()
                    for field_axis in range(field_size):
                        label = _table_axis_value(
                            table,
                            orientation,
                            label_axis,
                            field_axis,
                        )
                        target = source_label_line_target(label, "order")
                        if target in allowed_targets:
                            targets_by_field[field_axis] = str(target)
                        if target in identity_targets or "identifier" in (
                            _technical_table_role_hits(label)
                        ):
                            identity_fields.add(field_axis)
                    quantity_fields = {
                        field_axis
                        for field_axis, target in targets_by_field.items()
                        if target in quantity_targets
                    }
                    price_amount_fields = {
                        field_axis
                        for field_axis, target in targets_by_field.items()
                        if target in price_amount_targets
                    }
                    if not identity_fields or not (
                        quantity_fields or price_amount_fields
                    ):
                        continue
                    for value_axis in range(axis_size):
                        if value_axis == label_axis:
                            continue
                        has_identity = any(
                            _table_axis_value(
                                table,
                                orientation,
                                value_axis,
                                field_axis,
                            )
                            for field_axis in identity_fields
                        )
                        has_quantity = any(
                            _table_axis_value(
                                table,
                                orientation,
                                value_axis,
                                field_axis,
                            )
                            for field_axis in quantity_fields
                        )
                        has_price_or_amount = any(
                            _table_axis_value(
                                table,
                                orientation,
                                value_axis,
                                field_axis,
                            )
                            for field_axis in price_amount_fields
                        )
                        if has_identity and (
                            has_price_or_amount
                            or (has_quantity and quantity_commitment_context)
                        ):
                            return True
    return False


def _looks_like_product_specification(text: str) -> bool:
    folded = _normalize(text).casefold()
    compact = re.sub(r"\s+", "", folded)
    if any(
        re.sub(r"\s+", "", marker) in compact
        for marker in _PRODUCT_SPECIFICATION_TITLE_MARKERS
    ):
        return True
    signal_count = sum(
        any(re.sub(r"\s+", "", signal) in compact for signal in group)
        for group in _PRODUCT_SPECIFICATION_SIGNAL_GROUPS
    )
    return signal_count >= 3


_SERVICE_POLICY_TITLE_RE = re.compile(
    r"(?:售后(?:服务)?政策|产品保修政策|保修服务政策|退换货政策|"
    r"after[ -]?sales\s+(?:service\s+)?policy|warranty\s+policy|"
    r"returns?\s+(?:and\s+replacements?\s+)?policy)",
    re.IGNORECASE,
)


def _looks_like_service_policy(text: str) -> bool:
    """Recognize an explicit policy purpose, not a warranty note in another document."""

    return bool(_SERVICE_POLICY_TITLE_RE.search(_normalize(text)))


def _is_natural_image_document(evidence: DocumentEvidence) -> bool:
    """Return true only for pages dominated by native natural-image evidence."""

    if not evidence.pages or any(page.tables for page in evidence.pages):
        return False
    for page in evidence.pages:
        visual_blocks = [
            block
            for block in page.blocks
            if block.kind.casefold() in {"image", "figure"}
            and str((block.model_extra or {}).get("sub_type") or "").casefold()
            in {"natural_image", "natural-image", "photo", "photograph"}
        ]
        if not visual_blocks or page.visual_coverage_ratio < 0.75:
            return False
        non_visual_text = sum(
            len(_normalize(block.text))
            for block in page.blocks
            if block not in visual_blocks and _normalize(block.text)
        )
        if non_visual_text > 160:
            return False
    return True


def _explicit_document_intent(evidence: DocumentEvidence) -> str | None:
    """Return an intent only when native title-region evidence is explicit."""

    native_type, _native_subtype = _trusted_native_classification(evidence)
    if native_type:
        return native_type
    text = _native_title_text(evidence).replace(" ", "")
    if "采购合同" in text:
        return "purchase_contract"
    if "备货单" in text:
        return "purchase_order"
    if any(marker in text for marker in ("样品需求单", "样品申请单", "样品单")):
        return "sample_request"
    native_text = _native_evidence_text(evidence)
    compact_native = native_text.replace(" ", "")
    if any(
        marker in compact_native for marker in ("样品需求单", "样品申请单", "样品单")
    ):
        return "sample_request"
    commercial_records = _has_commercial_record_structure(evidence)
    if _looks_like_service_policy(native_text) and not commercial_records:
        return "technical_document"
    if _is_natural_image_document(evidence):
        return "technical_document"
    if _looks_like_product_specification(native_text) and not commercial_records:
        return "technical_document"
    if not commercial_records and all(
        token in compact_native for token in ("外径尺寸", "内径尺寸", "下料尺寸")
    ):
        return "technical_document"
    folded_native = native_text.casefold()
    if not commercial_records and any(
        token in folded_native
        for token in ("图号", "drawing_number", "drawing number", "测试条件")
    ):
        return "technical_document"
    if (
        not commercial_records
        and _technical_document_signals(
            native_text,
            order_anchor_text=_native_title_text(evidence),
        ).is_technical_document
    ):
        return "technical_document"
    return None


def _order_intent_has_native_support(
    intent: DocumentIntent,
    evidence: DocumentEvidence,
) -> bool:
    """Reject order routing when neither text nor a selected table supports it."""

    filename = _normalize((evidence.raw or {}).get("source_filename"))
    context = f"{_native_evidence_text(evidence)}\n{filename}".casefold()
    if re.search(r"(?<![a-z0-9])order(?![a-z0-9])", context):
        return True
    if any(
        _normalize(marker).casefold() in context
        for group in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS
        for marker in group
    ):
        return True
    if _has_commercial_record_structure(evidence):
        return True
    selected_ids = set(intent.primary_record_table_ids)
    if not selected_ids:
        return False
    for page in evidence.pages:
        for table in page.tables:
            if table.table_id not in selected_ids:
                continue
            for row in table.rows:
                values = [_normalize(value) for value in row if _normalize(value)]
                if len(values) < 3:
                    continue
                has_measure = any(
                    re.fullmatch(
                        r"[+-]?(?:\d+(?:[.,]\d+)?|\.\d+)\s*"
                        r"(?:%|[A-Za-z]{0,8}|[\u4e00-\u9fff]{0,3})",
                        value,
                    )
                    for value in values
                )
                has_description = any(
                    re.search(r"[A-Za-z\u4e00-\u9fff]", value)
                    and not re.fullmatch(r"[A-Za-z]{1,8}", value)
                    for value in values
                )
                if has_measure and has_description:
                    return True
    return False


def _document_intent_family(document_intent: str) -> str:
    normalized = _normalize(document_intent).casefold().replace(" ", "_")
    subtype_family = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(normalized)
    if subtype_family:
        return subtype_family
    if normalized in {
        "purchase_contract",
        "purchase_order",
        "stocking_order",
        "supplier_purchase_order",
    }:
        return "order"
    if normalized in {
        "engineering_drawing",
        "product_specification",
        "process_specification",
        "technical_document",
    }:
        return "technical_document"
    if normalized in _ROUTE_DOCUMENT_TYPES:
        return normalized
    return "unknown"


def _trusted_fallback_document_intent(
    evidence: DocumentEvidence,
    route_context: _GuardedDocumentRouteContext,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> str | None:
    """Resolve only explicit evidence or governed classification hints."""

    explicit = _explicit_document_intent(evidence)
    if explicit:
        return explicit
    subtype_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(
        str(document_subtype_hint or "").strip()
    )
    if subtype_type:
        return subtype_type
    type_hint = str(document_type_hint or "").strip()
    if _document_intent_family(type_hint) != "unknown":
        return type_hint
    route_type = route_context.document_type_hint or _ROUTE_SCHEMA_TYPES.get(
        route_context.schema_family or ""
    )
    if route_type and _document_intent_family(route_type) != "unknown":
        return route_type
    return None


def _intent_route_type(document_intent: str) -> str:
    return _document_intent_family(document_intent)


def _unknown_classification(value: str | None) -> bool:
    return not value or _normalize(value).casefold().replace(" ", "_") == "unknown"


def _apply_guarded_route_classification(
    intent: DocumentIntent,
    evidence: DocumentEvidence,
    route_context: _GuardedDocumentRouteContext,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
    issues: list[str] | None = None,
) -> tuple[DocumentIntent, bool]:
    """Apply explicit/native classification first and route hints only as fallback."""

    issue_target = issues if issues is not None else []
    type_hint = str(document_type_hint or "").strip()
    subtype_hint = str(document_subtype_hint or "").strip()
    if type_hint or subtype_hint:
        update: dict[str, Any] = {}
        canonical_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(subtype_hint)
        effective_type = type_hint or canonical_type
        if effective_type and len(effective_type) <= 128:
            update["document_intent"] = effective_type
        if subtype_hint and len(subtype_hint) <= 128:
            update["document_subtype"] = subtype_hint
        return intent.model_copy(update=update, deep=True), False

    native_intent = _explicit_document_intent(evidence)
    if native_intent:
        if native_intent != intent.document_intent:
            issue_target.append(
                "explicit_document_intent_override:"
                f"{intent.document_intent}:{native_intent}"
            )
        return (
            intent.model_copy(
                update={"document_intent": native_intent},
                deep=True,
            ),
            False,
        )

    if _document_intent_family(
        intent.document_intent
    ) == "order" and not _order_intent_has_native_support(intent, evidence):
        issue_target.append("unsupported_model_document_intent:order")
        intent = intent.model_copy(
            update={
                "document_intent": "unknown",
                "document_kind_label": "unknown",
                "document_subtype": "unknown",
                "primary_record_table_ids": [],
            },
            deep=True,
        )

    update = {}
    route_type = route_context.document_type_hint or _ROUTE_SCHEMA_TYPES.get(
        route_context.schema_family or ""
    )
    if _unknown_classification(intent.document_intent) and route_type:
        update["document_intent"] = route_type
        issue_target.append("document_route_classification_fallback:document_type")

    current_type = _intent_route_type(
        str(update.get("document_intent", intent.document_intent))
    )
    route_subtype = route_context.document_subtype_hint
    if (
        _unknown_classification(intent.document_subtype)
        and route_subtype
        and _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(route_subtype) == current_type
    ):
        update["document_subtype"] = route_subtype
        issue_target.append("document_route_classification_fallback:document_subtype")
    return intent.model_copy(update=update, deep=True), True


_FACT_TARGETS_BY_SUBTYPE: dict[str, tuple[str, ...]] = {
    "engineering_drawing": (
        "company",
        "product_name",
        "material_number",
        "customer_material_number",
        "customer_code",
        "drawing_number",
        "version",
        "unit",
        "page_count_label",
        "overall_length",
    ),
    "purchase_contract": (
        "title",
        "contract_number",
        "order_date",
        "delivery_date",
        "buyer",
        "seller",
        "supplier",
        "summary",
        "payment_terms",
        "tax_rate",
        "total_amount",
    ),
    "stocking_order": (
        "company",
        "document_title",
        "source_order_number",
        "order_number",
        "order_date_raw",
        "delivery_date_raw",
    ),
    "product_specification": (
        "company",
        "product_name",
        "product_number",
        "material_number",
        "document_number",
        "version",
        "unit",
        "interface",
        "protocol_version",
        "bandwidth",
        "resolution",
        "voltage",
        "transmission_distance",
        "operating_temperature",
        "storage_temperature",
    ),
}

_FACT_DEFINITIONS: dict[str, str] = {
    "title": "the explicit document title, never a summary or clause",
    "company": "full legal company name in the source language",
    "product_name": "full product or drawing title, never a part number",
    "material_number": "the source material/part number",
    "customer_material_number": "the customer material/part number",
    "customer_code": "the explicit customer code",
    "version": "revision/version value without its label",
    "unit": "measurement unit without its label",
    "product_number": "the explicit product identifier or product number",
    "interface": "the explicit connector or interface family",
    "protocol_version": "the explicit protocol or standard version",
    "bandwidth": "the explicit bandwidth or data rate including its unit",
    "resolution": "the explicit supported display or image resolution",
    "voltage": "the explicit rated or operating voltage including its unit",
    "transmission_distance": "the explicit transmission distance including its unit",
    "operating_temperature": "the explicit operating temperature or range",
    "storage_temperature": "the explicit storage temperature or range",
    "page_count_label": "page count such as 1 of 1 without its label",
    "overall_length": (
        "finished product overall length, preferably the value with tolerance; "
        "never a component cut length"
    ),
    "contract_number": "contract or purchase order identifier without its label",
    "order_date": "explicit order/signing date, not delivery date",
    "delivery_date": "explicit delivery date, not order date",
    "buyer": "company explicitly labeled buyer/甲方/采购方",
    "seller": "company explicitly labeled seller/乙方/供方",
    "supplier": "company explicitly labeled supplier/供方",
}


def _fact_target_context(
    document_intent: str,
    document_subtype: str | None,
    *,
    generic_facts_only: bool = False,
) -> dict[str, Any]:
    subtype = document_subtype or "unknown"
    targets = (
        ()
        if generic_facts_only
        else _FACT_TARGETS_BY_SUBTYPE.get(
            subtype,
            (
                "document_title",
                "document_number",
                "company",
                "buyer",
                "seller",
                "supplier",
                "customer",
                "order_number",
                "order_date",
                "delivery_date",
            ),
        )
    )
    return {
        "document_intent": _document_intent_family(document_intent),
        "document_subtype": subtype,
        "allowed_fact_names": list(targets),
        "generic_facts_only": generic_facts_only,
        "fact_definitions": {
            name: _FACT_DEFINITIONS[name]
            for name in targets
            if name in _FACT_DEFINITIONS
        },
    }


_FACT_NAME_ALIASES = {
    "document_title": "title",
    "company_name": "company",
    "supplier_name": "supplier",
    "buyer_name": "buyer",
    "seller_name": "seller",
    "part_number": "material_number",
    "material_code": "material_number",
    "customer_part_number": "customer_material_number",
    "revision": "version",
    "uom": "unit",
    "length": "overall_length",
}


def _canonical_fact_name(
    name: str,
    allowed_names: set[str],
) -> str | None:
    normalized = re.sub(
        r"[^a-z0-9]+",
        "_",
        unicodedata.normalize("NFKC", name).casefold(),
    ).strip("_")
    if normalized in allowed_names:
        return normalized
    normalized = _FACT_NAME_ALIASES.get(normalized, normalized)
    if normalized in allowed_names:
        return normalized
    if normalized.endswith("_name") and normalized[:-5] in allowed_names:
        return normalized[:-5]
    return None


_FACT_VALUE_PREFIXES: dict[str, tuple[str, ...]] = {
    "company": ("公司", "公司名称", "company"),
    "buyer": ("甲方", "需方", "采购方", "buyer"),
    "seller": ("乙方", "供方", "销售方", "seller"),
    "supplier": (
        "供应商名称",
        "供应单位",
        "供应商",
        "供货商",
        "供方",
        "supplier name",
        "supplier",
    ),
    "product_name": ("品名", "产品名称", "product name"),
    "customer_material_number": ("客户物料编号", "客户料号"),
    "customer_code": ("客户代码", "客户编码"),
    "material_number": ("物料编号", "物料号", "料号"),
    "overall_length": ("总长", "总长度", "成品长度", "overall length", "L="),
    "version": ("版本", "revision", "rev"),
    "unit": ("单位", "unit", "uom"),
    "page_count_label": ("页次", "页码", "page"),
    "contract_number": (
        "合同编号",
        "合同号",
        "采购订单号",
        "采购单号",
        "订单号",
        "purchase order no",
        "po no",
    ),
    "order_number": (
        "采购订单号",
        "采购单号",
        "订单号码",
        "订单编号",
        "订单号",
        "purchase order no",
        "purchase order",
        "order no",
        "po no",
        "po号",
        "order",
    ),
    "source_order_number": (
        "来源订单号",
        "原订单号",
        "订单号码",
        "source order no",
        "source order",
    ),
    "order_date": ("下单日期", "订单日期", "签订日期", "order date"),
    "order_date_raw": ("下单日期", "订单日期", "order date"),
    "delivery_date": ("交货日期", "交期", "delivery date"),
    "delivery_date_raw": ("交货日期", "交期", "delivery date"),
    "payment_terms": (
        "付款条件",
        "付款方式",
        "支付方式",
        "结算条件",
        "结算方式",
        "payment terms",
        "payment method",
    ),
    "summary": ("摘要", "用途", "summary"),
    "tax_rate": ("税率", "tax rate"),
    "total_amount": ("总金额", "合计金额", "价税合计", "total amount"),
    "drawing_number": ("图号", "drawing number"),
}

_FACT_VALUE_BOUNDARY_PREFIXES = (
    "合计数量",
    "数量合计",
    "总数量",
    "合计金额",
    "总金额",
    "价税合计",
)
_FACT_LABEL_SEPARATORS = " \t:/：：-—_·."


def _fact_value_labels() -> tuple[str, ...]:
    labels = {
        unicodedata.normalize("NFKC", label).strip()
        for prefixes in _FACT_VALUE_PREFIXES.values()
        for label in prefixes
    }
    labels.update(_FACT_VALUE_BOUNDARY_PREFIXES)
    return tuple(sorted((label for label in labels if label), key=len, reverse=True))


def _label_occurrences(
    text: str,
    labels: tuple[str, ...],
) -> list[tuple[int, int]]:
    folded = text.casefold()
    matches: list[tuple[int, int]] = []
    for label in labels:
        folded_label = label.casefold()
        start = 0
        while True:
            index = folded.find(folded_label, start)
            if index < 0:
                break
            end = index + len(folded_label)
            before = text[index - 1] if index else ""
            after = text[end] if end < len(text) else ""
            bounded_before = (
                not before or before.isspace() or before in ":：/|-—_·.;；,，"
            )
            bounded_after = not after or after.isspace() or after in ":：/|-—_·.;；,，"
            explicit_cjk_label = (
                bool(after)
                and after in ":："
                and any(ord(character) > 127 for character in label)
            )
            if (bounded_before or explicit_cjk_label) and bounded_after:
                matches.append((index, end))
            start = index + max(len(folded_label), 1)
    # Resolve overlaps independently of caller ordering. A short label such as
    # ``order`` must not survive inside ``source order`` and create a second,
    # conflicting value boundary.
    selected: list[tuple[int, int]] = []
    for match in sorted(set(matches), key=lambda item: (-(item[1] - item[0]), item[0])):
        if any(start <= match[0] and match[1] <= end for start, end in selected):
            continue
        selected.append(match)
    return sorted(selected)


def _bounded_labeled_values(
    text: str,
    prefixes: tuple[str, ...],
) -> list[str]:
    """Extract adjacent values, bounded by the next known field label."""

    normalized_text = unicodedata.normalize("NFKC", text)
    target_labels = tuple(
        sorted(
            {
                unicodedata.normalize("NFKC", prefix).strip()
                for prefix in prefixes
                if prefix.strip()
            },
            key=len,
            reverse=True,
        )
    )
    known_labels = _fact_value_labels()
    known_occurrences = _label_occurrences(normalized_text, known_labels)
    candidates: list[str] = []
    for _, label_end in _label_occurrences(normalized_text, target_labels):
        value_end = len(normalized_text)
        for boundary_start, _ in known_occurrences:
            if boundary_start >= label_end:
                value_end = boundary_start
                break
        candidate = _normalize(
            normalized_text[label_end:value_end].strip(_FACT_LABEL_SEPARATORS + "\r\n")
        )
        if not candidate or len(candidate) > 512:
            continue
        candidates.append(candidate)
    return list(dict.fromkeys(candidates))


def _narrow_proposed_fact_value(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
) -> ProposedFact:
    prefixes = _FACT_VALUE_PREFIXES.get(fact.name, ())
    if not prefixes:
        return fact
    candidates: list[str] = []
    for evidence_id in fact.citations:
        item = inventory.get(evidence_id)
        if item is None:
            continue
        text = (item.exact_text or item.text).strip()
        candidates.extend(_bounded_labeled_values(text, prefixes))
    candidates_by_value: dict[str, str] = {}
    for candidate in candidates:
        candidates_by_value.setdefault(_normalize(candidate).casefold(), candidate)
    candidates = list(candidates_by_value.values())
    if not candidates:
        return fact

    proposed_value = _normalize(fact.value).casefold()
    exact = [
        candidate
        for candidate in candidates
        if _normalize(candidate).casefold() == proposed_value
    ]
    if len(exact) == 1:
        return fact.model_copy(update={"value": exact[0]})

    aligned = [
        candidate
        for candidate in candidates
        if (
            _normalize(candidate).casefold() in proposed_value
            or proposed_value in _normalize(candidate).casefold()
        )
    ]
    if len(aligned) == 1:
        return fact.model_copy(update={"value": aligned[0]})
    if len(candidates) == 1:
        return fact.model_copy(update={"value": candidates[0]})
    return fact


def _label_only_fact_value(name: str, value: str) -> bool:
    compact_value = _normalize(value).casefold().strip("/：:-._ ")
    return any(
        compact_value == _normalize(prefix).casefold().strip("/：:-._ ")
        for prefix in _FACT_VALUE_PREFIXES.get(name, ())
    )


def _labeled_fact_value_supported(name: str, value: str, text: str) -> bool:
    """Require a directly adjacent source label for a sliced header value."""

    folded_text = _normalize(text).casefold()
    folded_value = _normalize(value).casefold()
    if not folded_value:
        return False
    for prefix in _FACT_VALUE_PREFIXES.get(name, ()):
        folded_prefix = _normalize(prefix).casefold()
        start = 0
        while True:
            label_index = folded_text.find(folded_prefix, start)
            if label_index < 0:
                break
            value_index = folded_text.find(
                folded_value,
                label_index + len(folded_prefix),
            )
            if value_index < 0:
                break
            separator = folded_text[label_index + len(folded_prefix) : value_index]
            if len(separator) <= 12 and not separator.strip(" /：:-._—"):
                return True
            start = label_index + len(folded_prefix)
    return False


_ROLE_FACT_NAMES = frozenset({"buyer", "seller", "supplier"})


def _same_table_axis(left: _EvidenceItem, right: _EvidenceItem) -> bool:
    if left.table_id is None or left.table_id != right.table_id:
        return False
    return (
        left.row is not None
        and left.row == right.row
        or left.column is not None
        and left.column == right.column
    )


def _role_fact_supporting_ids(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
    *,
    allowed_ids: set[str] | None,
) -> tuple[set[str], set[str]]:
    """Bind a role value only to an inline or same-axis explicit role label."""

    if fact.name not in _ROLE_FACT_NAMES:
        return set(), set()
    value = _normalize(fact.value)
    cited: dict[str, _EvidenceItem] = {}
    for evidence_id in fact.citations:
        item = inventory.get(evidence_id)
        if item is None or (allowed_ids is not None and evidence_id not in allowed_ids):
            continue
        provenance = item.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get("asset_sha256"):
            continue
        cited[evidence_id] = item

    value_ids: set[str] = set()
    label_ids: set[str] = set()
    explicit_labels = {
        evidence_id: item
        for evidence_id, item in cited.items()
        if _label_only_fact_value(fact.name, item.text)
    }
    for evidence_id, item in cited.items():
        if _labeled_fact_value_supported(fact.name, value, item.text):
            value_ids.add(evidence_id)
            continue
        if value != item.text:
            continue
        matching_labels = {
            label_id
            for label_id, label_item in explicit_labels.items()
            if _same_table_axis(label_item, item)
        }
        if matching_labels:
            value_ids.add(evidence_id)
            label_ids.update(matching_labels)
    return value_ids, label_ids


def _native_evidence_text(evidence: DocumentEvidence) -> str:
    values: list[str] = []
    for page in evidence.pages:
        values.extend(
            block.text
            for block in page.blocks
            if not (block.model_extra or {}).get("asset_sha256")
        )
        values.extend(
            str(value)
            for table in page.tables
            if not (table.model_extra or {}).get("asset_sha256")
            for row in table.rows
            for value in row
        )
    return _normalize("\n".join(values))


def _native_classification_source_texts(
    evidence: DocumentEvidence,
    source_ref: dict[str, Any],
) -> list[str]:
    """Resolve one native classification locator back to retained source text."""

    target_page = source_ref.get("page")
    target_sheet = str(source_ref.get("sheet") or "")
    target_cell = str(source_ref.get("cell") or "")
    target_part = str(source_ref.get("part") or "")
    if target_part == "source.original_filename":
        return []
    if not ((target_sheet and target_cell) or target_part):
        return []

    def page_allowed(page: EvidencePage) -> bool:
        return target_page in (None, page.page_number)

    def part_allowed(parts: set[str]) -> bool:
        return not target_part or target_part in parts

    def cell_allowed(extras: dict[str, Any]) -> bool:
        if not (target_sheet and target_cell):
            return True
        direct_sheet = str(extras.get("sheet") or "")
        direct_cell = str(extras.get("inherited_from") or extras.get("cell") or "")
        if (direct_sheet, direct_cell) == (target_sheet, target_cell):
            return True
        return any(
            isinstance(reference, dict)
            and str(reference.get("sheet") or "") == target_sheet
            and str(reference.get("cell") or "") == target_cell
            for reference in extras.get("native_source_refs") or []
        )

    texts: list[str] = []
    for page in evidence.pages:
        if not page_allowed(page):
            continue
        for block in page.blocks:
            extras = block.model_extra or {}
            parts = {
                str(extras.get("source_id") or ""),
                str(extras.get("source_ref_part") or ""),
                block.block_id,
                f"mineru/{block.block_id}",
            }
            if cell_allowed(extras) and part_allowed(parts) and block.text.strip():
                texts.append(block.text)
        for table in page.tables:
            table_extras = table.model_extra or {}
            table_parts = {
                str(table_extras.get("source_id") or ""),
                table.table_id,
                f"mineru/{table.table_id}",
            }
            if (
                not (target_sheet and target_cell)
                and part_allowed(table_parts)
                and target_part
            ):
                texts.extend(
                    str(value)
                    for row in table.rows
                    for value in row
                    if value not in (None, "")
                )
            for cell in table.cells:
                extras = cell.model_extra or {}
                sheet = str(extras.get("sheet") or "")
                physical_cell = str(
                    extras.get("inherited_from") or extras.get("cell") or ""
                )
                parts = {
                    str(extras.get("source_id") or ""),
                    str(extras.get("source_ref_part") or ""),
                    f"mineru/{table.table_id}/r{cell.row}/c{cell.column}",
                }
                if sheet and physical_cell:
                    parts.add(f"spreadsheet/{sheet}/{physical_cell}")
                if (
                    cell_allowed(extras)
                    and part_allowed(parts)
                    and cell.text not in (None, "")
                ):
                    texts.append(str(cell.text))
    return texts


def _native_classification_has_replayable_evidence(
    evidence: DocumentEvidence,
    payload: dict[str, Any],
    *,
    document_subtype: str,
) -> bool:
    if payload.get("authority") != "native_content":
        return False
    values = payload.get("evidence")
    if not isinstance(values, list):
        return False
    for value in values:
        if not isinstance(value, dict):
            continue
        evidence_subtype = str(value.get("document_subtype") or document_subtype)
        if evidence_subtype != document_subtype:
            continue
        source_ref = value.get("source_ref")
        if not isinstance(source_ref, dict):
            continue
        if source_ref.get("authority") == "advisory" or source_ref.get(
            "asset_sha256"
        ):
            continue
        quote = _normalize(value.get("quote") or value.get("matched_marker"))
        if not quote:
            continue
        replayed = _native_classification_source_texts(evidence, source_ref)
        if any(quote.casefold() in _normalize(text).casefold() for text in replayed):
            return True
    return False


def _trusted_native_classification(
    evidence: DocumentEvidence,
) -> tuple[str | None, str | None]:
    """Read only adapter-owned, replayable classification evidence."""

    payload = (evidence.raw or {}).get("native_classification")
    trusted_sources = {
        "spreadsheet-envelope": "spreadsheet-tabular-v1",
        "docx-native-ooxml": "docx-native-classifier-v1",
    }
    if (
        not isinstance(payload, dict)
        or payload.get("schema_version") != "m1.native-classification.v1"
        or payload.get("source") != trusted_sources.get(evidence.backend)
    ):
        return None, None
    document_type = str(payload.get("document_type") or "").strip()
    document_subtype = str(payload.get("document_subtype") or "").strip()
    if document_type not in _ROUTE_DOCUMENT_TYPES:
        return None, None
    expected_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(document_subtype)
    if expected_type != document_type or not _native_classification_has_replayable_evidence(
        evidence,
        payload,
        document_subtype=document_subtype,
    ):
        return None, None
    return document_type, document_subtype


def _model_subtype_supported(
    subtype: str,
    evidence: DocumentEvidence,
) -> bool:
    """Require native corroboration for model subtypes that trigger projections."""

    _native_type, native_subtype = _trusted_native_classification(evidence)
    if subtype == native_subtype:
        return True
    text = _native_evidence_text(evidence)
    compact = text.replace(" ", "")
    title = _native_title_text(evidence).replace(" ", "")
    filename = _normalize((evidence.raw or {}).get("source_filename")).replace(" ", "")
    title_context = f"{title}\n{filename}"
    if subtype == "purchase_contract":
        return "采购合同" in title_context or "购销合同" in title_context
    if subtype == "stocking_order":
        return "备货单" in title_context or "备货订单" in title_context
    if subtype == "product_specification":
        return _looks_like_product_specification(text) or (
            _technical_document_signals(text, order_anchor_text=title).subtype
            == "product_specification"
        )
    if subtype == "service_policy":
        return _looks_like_service_policy(text)
    if subtype == "product_photo":
        return _is_natural_image_document(evidence)
    if subtype == "image_document":
        return any(
            block.kind.casefold() in {"image", "figure"}
            for page in evidence.pages
            for block in page.blocks
        )
    if subtype in {"engineering_drawing", "approval_drawing"}:
        return True
    if subtype in {"inventory_snapshot", "equipment_register", "mold_mapping"}:
        return subtype == native_subtype
    if subtype in {
        "customer_purchase_order",
        "supplier_purchase_order",
        "sample_request",
    }:
        return any(
            _normalize(marker).casefold() in f"{compact}\n{filename}".casefold()
            for marker in _COMMERCIAL_DOCUMENT_SIGNAL_GROUPS[0]
        )
    return True


def _document_subtype(
    intent: DocumentIntent,
    evidence: DocumentEvidence,
) -> str | None:
    """Resolve known subtypes from native evidence, then use the model hint."""

    _native_type, native_subtype = _trusted_native_classification(evidence)
    if native_subtype:
        return native_subtype
    text = _native_evidence_text(evidence)
    compact = text.replace(" ", "")
    compact_title = _native_title_text(evidence).replace(" ", "")
    if any(marker in compact for marker in ("样品需求单", "样品申请单", "样品单")):
        return "sample_request"
    if "采购合同" in compact_title:
        return "purchase_contract"
    if "备货单" in compact_title:
        return "stocking_order"
    if any(
        marker in compact_title for marker in ("样品需求单", "样品申请单", "样品单")
    ):
        return "sample_request"
    if _looks_like_service_policy(text):
        return "service_policy"
    if _is_natural_image_document(evidence):
        return "product_photo"
    specification_headers = {
        "产品名称",
        "外径尺寸",
        "内径尺寸",
        "下料尺寸",
        "公差",
    }
    if evidence.backend.casefold().startswith("docx") and any(
        specification_headers.issubset({_normalize(value) for value in row})
        for page in evidence.pages
        for table in page.tables
        for row in table.rows
    ):
        return "product_specification"
    normalized_intent = _normalize(intent.document_intent).casefold().replace(" ", "_")
    if normalized_intent in _ROUTE_DOCUMENT_SUBTYPE_TYPES:
        return normalized_intent
    family = _document_intent_family(intent.document_intent)
    if family == "order" and _native_generic_order_title(evidence):
        return "customer_purchase_order"
    if family == "technical_document":
        if _looks_like_product_specification(text):
            return "product_specification"
        if all(token in compact for token in ("外径尺寸", "内径尺寸", "下料尺寸")):
            return "product_specification"
        if any(
            token in compact.casefold()
            for token in ("图号", "drawing_number", "drawing number", "测试条件")
        ):
            return "engineering_drawing"
        technical_subtype = _technical_document_signals(
            text,
            order_anchor_text=_native_title_text(evidence),
        ).subtype
        if technical_subtype:
            return technical_subtype
    if (
        intent.document_subtype
        and intent.document_subtype != "unknown"
        and _model_subtype_supported(intent.document_subtype, evidence)
    ):
        return intent.document_subtype
    if intent.document_intent == "purchase_contract":
        return "purchase_contract"
    return None


def _resolved_document_subtype(
    intent: DocumentIntent,
    evidence: DocumentEvidence,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
    issues: list[str] | None = None,
) -> str | None:
    subtype_hint = str(document_subtype_hint or "").strip()
    if subtype_hint:
        return subtype_hint
    subtype = _document_subtype(intent, evidence)
    type_hint = str(document_type_hint or "").strip()
    if not subtype:
        if (
            issues is not None
            and intent.document_subtype
            and intent.document_subtype != "unknown"
        ):
            issues.append(
                f"unsupported_model_document_subtype:{intent.document_subtype}"
            )
        return subtype
    document_type = _document_intent_family(type_hint or intent.document_intent)
    subtype_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(subtype)
    if subtype == "engineering_drawing":
        subtype_type = "technical_document"
    if (
        subtype_type is not None
        and document_type != "unknown"
        and subtype_type != document_type
    ):
        if issues is not None:
            issues.append(
                "document_classification_consistency_repair:"
                f"{document_type}:{subtype_type}"
            )
        # A stale model subtype must not reverse a trusted family. Re-run the
        # existing evidence resolver without that subtype so native evidence
        # can still select a compatible specialization.
        subtype = _document_subtype(
            intent.model_copy(update={"document_subtype": "unknown"}, deep=True),
            evidence,
        )
        subtype_type = _ROUTE_DOCUMENT_SUBTYPE_TYPES.get(str(subtype or ""))
        if subtype == "engineering_drawing":
            subtype_type = "technical_document"
    return subtype if subtype_type in {None, document_type} else None


def _base_messages(*, role: str, payload: dict[str, Any]) -> list[dict[str, str]]:
    if role == "record_kind_mapping":
        return [
            {
                "role": "system",
                "content": (
                    "Classify every supplied candidate axis exactly once. record_kind "
                    "must be product, narrative, total, metadata, or unknown. A product "
                    "is one business item even when fields are blank. Narrative is a "
                    "clause, instruction, note, or prose continuation; total is an "
                    "aggregate/subtotal row; metadata is a document-level label/value "
                    "row. Use unknown when the evidence is genuinely ambiguous. Every "
                    "decision must cite at least one evidence_id from that same candidate. "
                    "Never invent or rewrite a value. field_remaps is normally empty; use "
                    "it only when a cited cell's current_field_name is semantically "
                    "incompatible with its value and the row context supports one allowed "
                    "field_name. Do not fill missing values and do not remap merely because "
                    "a field is blank. Return decisions only. /no_think"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"task": role, "evidence": payload},
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
    if role == "long_record_field_mapping":
        return [
            {
                "role": "system",
                "content": (
                    "Use only the supplied header_context and field_axis_samples. "
                    "Return only bindings; M1 binds field_axis_count locally. Bind a "
                    "field_name to an axis_index only when the label is supported. "
                    "field_name must "
                    "be one of allowed_field_names; map by meaning rather than exact "
                    "header spelling. Do not emit "
                    "records, cell values, citations, or record-axis identities. Omit "
                    "uncertain field axes; M1 assigns deterministic generic names. "
                    "/no_think"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"task": role, "evidence": payload},
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
    if role == "document_classification":
        return [
            {
                "role": "system",
                "content": (
                    "Classify only from the supplied native text and table samples. "
                    "Return document_intent from allowed_document_types and set "
                    "document_kind_label to a concise open-domain label only when it "
                    "adds useful specificity; it never replaces document_intent. "
                    "Set document_subtype to unknown unless a listed narrower subtype "
                    "is explicit; use document_subtype_definitions when supplied. "
                    "primary_record_table_ids may contain only tables holding the main "
                    "business rows, such as order lines or a BOM. Exclude pin maps, test "
                    "matrices, dimensions, and revision tables. Use only listed table IDs; "
                    "Choose from the document's primary purpose, source filename, and explicit "
                    "title-region text. A drawing, specification, or approval document remains "
                    "technical_document when it contains a BOM, quantities, units, a pin map, "
                    "test matrix, dimensions, tolerances, drawing number, or revision table. "
                    "Choose order only when native evidence shows a commercial commitment such "
                    "as buyer/seller roles, an order or contract identifier, an order/delivery "
                    "date, price, amount, or explicit order/contract title. Do not infer order "
                    "or inventory merely because rows contain quantities. do not return facts, "
                    "citations, content, rows, or summaries. /no_think"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"task": role, "evidence": payload},
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
    if role == "block_semantics":
        return [
            {
                "role": "system",
                "content": (
                    "Use only the supplied native text blocks. document_facts may contain "
                    "only explicit label-value facts. Every fact citation must be one "
                    "listed evidence_id whose value contains the exact extracted value; "
                    "extract the narrowest value without its label. Use content_bindings "
                    "for titles, clauses, process steps, drawing notes, and narrative "
                    "instructions. A binding contains only evidence_id, concise "
                    "lowercase snake_case content_kind, and concise label; never copy or "
                    "rewrite block text. Copy every evidence_id verbatim from the input. "
                    "For every listed block choose exactly one outcome: cite it from one "
                    "document fact, or emit exactly one content binding. Never silently "
                    "omit a block. Classify layout-only text with content_kind "
                    "layout_marker and an explanatory semantic label. Bind each evidence "
                    "ID at most once. Emit facts "
                    "only with a name listed in document_context.allowed_fact_names. "
                    "When document_context.generic_facts_only is true, explicit "
                    "label-value facts may instead use one concise lowercase snake_case "
                    "name; M1 stores them only in the generic_facts container after "
                    "evidence validation. Everything else is content. /no_think"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"task": role, "evidence": payload},
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
    if role == "table_partition_correction":
        return [
            {
                "role": "system",
                "content": (
                    "Return only the tables array required by the response schema. "
                    "Name every recovered table exactly once. For each table choose "
                    "rows or columns, then cover that complete axis with continuous, "
                    "non-overlapping inclusive segments. Use records only for repeated "
                    "business rows; use metadata for label/value regions and layout for "
                    "titles, summaries, dimensions, pin maps, and other non-record "
                    "regions. Never return document facts, source values, citations, "
                    "rows, summaries, or new table IDs. /no_think"
                ),
            },
            {
                "role": "user",
                "content": json.dumps(
                    {"task": role, "evidence": payload},
                    ensure_ascii=False,
                    separators=(",", ":"),
                ),
            },
        ]
    correction_instruction = (
        " For document_and_table_intent_correction, return one complete "
        "DocumentIntent. Copy document_intent, document_subtype, document_facts, "
        "primary_record_table_ids, and content_bindings exactly from the previous "
        "intent and replace only tables. Name every table exactly "
        "once. For the selected orientation with size N, use only inclusive "
        "indices 0 through N-1 and cover every index exactly once with "
        "continuous, non-overlapping segments. Never use N as an index. An "
        "empty selected axis must have no segments."
        if role == "document_and_table_intent_correction"
        else ""
    )
    partition_instruction = (
        "For document_intent_local_partition, tables must be an empty list; "
        "M1 has already bound every table axis from complete local evidence."
        if role == "document_intent_local_partition"
        else (
            "For document_and_table_intent, name every recovered table exactly "
            "once and partition every row or every column axis with non-overlapping "
            "inclusive segments."
        )
    )
    return [
        {
            "role": "system",
            "content": (
                "Use only the supplied MinerU evidence. Never invent a value, "
                "citation, table, row, column, or range. Every citation must name an "
                "existing evidence ID whose text contains the exact value. For "
                "document_and_table_intent, set document_intent to one concise "
                "lowercase snake_case category label of at most 64 characters "
                "(for example technical_document or purchase_order). document_facts "
                "Set document_subtype to unknown unless native evidence supports a "
                "narrower label such as purchase_contract, stocking_order, "
                "product_specification, or engineering_drawing. "
                "may contain only explicit label-value facts; never emit summaries "
                "of a table, list, image, or the whole document. Leave document_facts "
                "empty when no exact header fact is visible. A table_id is only a "
                "structural identifier and is never a citation or evidence_id. "
                "primary_record_table_ids must contain only table IDs whose rows or "
                "columns are the document's main business records (for example order "
                "lines or a BOM). Exclude pin maps, test matrices, revision history, "
                "dimension grids, and other auxiliary tables. Include every fragment "
                "of one logical primary table. This selection changes only the compact "
                "business projection; all auxiliary table evidence remains retained. "
                "Use content_bindings for non-table blocks such as titles, contract "
                "clauses, process steps, drawing notes, and narrative instructions. "
                "Each binding must contain only one existing block evidence_id, one "
                "concise lowercase snake_case content_kind, and one concise semantic "
                "label. Never copy, shorten, paraphrase, translate, or otherwise echo "
                "the source block text in a content binding; M1 projects the exact text "
                "and SourceReference locally. Bind each evidence_id at most once and "
                "never bind a table_id or table-cell evidence ID. "
                "A block marked visual_asset is a model-generated advisory caption: "
                "it may be classified as content, but it must never become a "
                "document_fact or override native text or table evidence. "
                f"{partition_instruction} For segment_extraction, "
                "cite only values inside the supplied segment. A table field value must "
                "exactly equal its cited cell after whitespace normalization; never "
                "shorten, complete, translate, or paraphrase a cell value. Extract the "
                "narrowest visible value without its label. In Chinese commercial "
                "documents 甲方/采购方/购货方 is buyer and 乙方/供方/供应商 is "
                "seller or supplier; never infer seller or supplier from a buyer label. "
                "For records segments populate records only and leave facts empty. For "
                "Every record must include record_kind and record_kind_citations from "
                "that record's own evidence. "
                "metadata, layout, or unknown segments populate facts only and leave "
                "records empty. For layout facts use only names listed in "
                "document_context.allowed_fact_names, unless "
                "document_context.generic_facts_only is true; in that mode use a "
                "concise lowercase snake_case name and M1 stores the validated value "
                "only in generic_facts. Emit one narrow, exact source value per fact; "
                "never emit structural names such as header_context, "
                "page_header, image_data, or dimension_value. header_context may name "
                "fields but is not a record and "
                "must never be cited. citations is a list of evidence ID strings; do not repeat "
                "source text inside citations."
                f"{correction_instruction} /no_think"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {"task": role, "evidence": payload},
                ensure_ascii=False,
                separators=(",", ":"),
            ),
        },
    ]


_SEMANTIC_EXECUTION_ROLES: dict[str, SemanticMapperRole] = {
    "document_classification": "document_classification",
    "document_and_table_intent": "document_intent",
    "document_and_table_intent_correction": "document_intent",
    "document_intent_local_partition": "document_intent",
    "table_partition_correction": "table_partition",
    "block_semantics": "block_semantics",
    "long_record_field_mapping": "record_field_mapping",
    "record_kind_mapping": "record_kind_mapping",
    "segment_extraction": "segment_extraction",
}
_SEMANTIC_EXECUTION_OUTPUT_TYPES: dict[SemanticMapperRole, type[BaseModel]] = {
    "document_classification": DocumentClassification,
    "document_intent": DocumentIntent,
    "table_partition": TablePartition,
    "block_semantics": BlockSemantics,
    "record_field_mapping": RecordFieldMapping,
    "record_kind_mapping": RecordKindMapping,
    "segment_extraction": SegmentExtraction,
}


def _messages(
    *,
    role: str,
    payload: dict[str, Any],
    semantic_execution: SemanticExecutionSpec | None = None,
) -> list[dict[str, str]]:
    messages = _base_messages(role=role, payload=payload)
    if semantic_execution is None:
        return messages
    mapper_role = _SEMANTIC_EXECUTION_ROLES.get(role)
    if mapper_role is None:
        raise ValueError(f"semantic execution role is not registered: {role}")
    directive = SemanticStrategyExecutor.prompt_directive(
        semantic_execution,
        role=mapper_role,
    )
    SemanticStrategyExecutor.validate_output_schema(
        semantic_execution,
        role=mapper_role,
        output_type=_SEMANTIC_EXECUTION_OUTPUT_TYPES[mapper_role],
    )
    messages[0]["content"] = f"{messages[0]['content']} {directive}"
    return messages


def _prompt_size(messages: list[dict[str, str]]) -> int:
    return len(json.dumps(messages, ensure_ascii=False, separators=(",", ":")))


def _strict_segment_fact_proposals(
    proposals: list[_SegmentFactProposal],
    *,
    segment_id: str,
    issues: list[str],
) -> list[ProposedFact]:
    accepted: list[ProposedFact] = []
    for index, proposal in enumerate(proposals):
        try:
            accepted.append(
                ProposedFact.model_validate(proposal.model_dump(mode="json"))
            )
        except ValidationError:
            issues.append(
                f"ignored_model_fact:invalid_segment_proposal:{segment_id}:{index}"
            )
    return accepted


def _strict_segment_record_proposals(
    proposals: list[_SegmentRecordProposal],
    *,
    segment_id: str,
    issues: list[str],
) -> list[ProposedRecord]:
    accepted: list[ProposedRecord] = []
    for record_index, proposal in enumerate(proposals):
        fields = _strict_segment_fact_proposals(
            proposal.fields,
            segment_id=f"{segment_id}:record:{record_index}",
            issues=issues,
        )
        if fields:
            try:
                accepted.append(
                    ProposedRecord(
                        fields=fields,
                        record_kind=proposal.record_kind,
                        record_kind_citations=proposal.record_kind_citations,
                    )
                )
            except ValidationError:
                issues.append(
                    "ignored_model_fact:invalid_record_kind:"
                    f"{segment_id}:{record_index}"
                )
                accepted.append(ProposedRecord(fields=fields))
        elif proposal.fields:
            issues.append(
                f"ignored_model_fact:empty_segment_record:{segment_id}:{record_index}"
            )
    return accepted


def _citation_prefix_matches_fact(prefix: str, fact_name: str) -> bool:
    """Accept only the current fact name or a JSON path ending in that name."""

    normalized_prefix = unicodedata.normalize("NFKC", prefix).strip().casefold()
    normalized_name = unicodedata.normalize("NFKC", fact_name).strip().casefold()
    if normalized_prefix == normalized_name:
        return True
    if not normalized_prefix.startswith("$."):
        return False
    terminal = normalized_prefix.rsplit(".", 1)[-1]
    terminal = re.sub(r"\[\d+\]$", "", terminal)
    return terminal == normalized_name


def _resolve_fact_evidence_id(
    evidence_id: str,
    *,
    fact_name: str,
    inventory: dict[str, _EvidenceItem],
) -> str:
    """Repair a model-added fact prefix without guessing an evidence ID."""

    if evidence_id in inventory:
        return evidence_id
    matches = [
        candidate
        for candidate in inventory
        if evidence_id.endswith(f":{candidate}")
    ]
    if len(matches) != 1:
        return evidence_id
    candidate = matches[0]
    prefix = evidence_id[: -(len(candidate) + 1)]
    if not _citation_prefix_matches_fact(prefix, fact_name):
        return evidence_id
    return candidate


def _normalize_fact_citations(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
) -> ProposedFact:
    citations = [
        _resolve_fact_evidence_id(
            evidence_id,
            fact_name=fact.name,
            inventory=inventory,
        )
        for evidence_id in fact.citations
    ]
    if citations == fact.citations:
        return fact
    return fact.model_copy(update={"citations": citations})


_OVERALL_LENGTH_LABEL_RE = re.compile(
    r"(?i)(?:总长度?|成品长度|overall\s+length|(?<![a-z0-9])l)"
    r"\s*[:=]?\s*(?P<nominal>\d+(?:[.,]\d+)?)\s*(?P<unit>mm|cm|m)?"
)
_TOLERANCED_LENGTH_RE = re.compile(
    r"(?i)^(?P<nominal>\d+(?:[.,]\d+)?)\s*"
    r"(?:±|\+/-)\s*(?P<tolerance>\d+(?:[.,]\d+)?)\s*(?P<unit>mm|cm|m)?$"
)
_COMPANY_VALUE_TAIL_RE = re.compile(
    r"(?i)(?:有限公司|股份有限公司|集团|公司|工厂|厂|电子科技|科技|"
    r"technology|industr(?:y|ies)|co\.?\s*,?\s*ltd\.?)$"
)
_DOCUMENT_TITLE_TAIL_RE = re.compile(
    r"(?i)(?:规格|图纸|承认书|订单|合同|清单|明细|"
    r"specification|drawing|order|contract)"
)
_DRAWING_NUMBER_TAIL_RE = re.compile(r"(?i)^.{0,16}(?:图号|图纸|drawing)")
_PRODUCT_TITLE_END_RE = re.compile(
    r"(?i)(?:图纸|规格(?:书|表)?|承认书|drawing|specification)$"
)
_STRUCTURAL_TITLE_REMAINDER_RE = re.compile(
    r"(?i)^.{0,12}(?:长度|尺寸|宽度|高度|料号|图号|版本|"
    r"length|dimension|width|height|part|revision)"
)
_TITLE_OVERALL_LENGTH_RE = re.compile(
    r"(?i)^(?P<title>.+?(?:图纸|规格(?:书|表)?|承认书|drawing|specification))"
    r"\s+(?:长度|length)\s*[:=]?\s*"
    r"(?P<nominal>\d+(?:[.,]\d+)?)\s*(?P<unit>mm|cm|m)?\s*$"
)


def _authoritative_fact_items(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
    *,
    allowed_ids: set[str] | None,
) -> list[_EvidenceItem]:
    items: list[_EvidenceItem] = []
    for evidence_id in fact.citations:
        item = inventory.get(evidence_id)
        if item is None or (allowed_ids is not None and evidence_id not in allowed_ids):
            continue
        provenance = item.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get("asset_sha256"):
            continue
        items.append(item)
    return items


def _company_title_value_supported(value: str, text: str) -> bool:
    folded_value = _normalize(value).casefold()
    folded_text = _normalize(text).casefold()
    if len(folded_value) < 6 or not folded_text.startswith(folded_value):
        return False
    remainder = folded_text[len(folded_value) :].strip(" /:：-._")
    return bool(
        remainder
        and _COMPANY_VALUE_TAIL_RE.search(folded_value)
        and _DOCUMENT_TITLE_TAIL_RE.search(remainder[:48])
    )


def _drawing_number_value_supported(value: str, text: str) -> bool:
    folded_value = _normalize(value).casefold()
    folded_text = _normalize(text).casefold()
    if not folded_value or not folded_text.startswith(folded_value):
        return False
    remainder = folded_text[len(folded_value) :].strip(" /:：-._")
    return bool(remainder and _DRAWING_NUMBER_TAIL_RE.match(remainder))


def _product_title_value_supported(value: str, text: str) -> bool:
    folded_value = _normalize(value).casefold()
    folded_text = _normalize(text).casefold()
    if not folded_value or not folded_text.startswith(folded_value):
        return False
    remainder = folded_text[len(folded_value) :].strip(" /:：-._")
    return bool(
        remainder
        and _PRODUCT_TITLE_END_RE.search(folded_value)
        and _STRUCTURAL_TITLE_REMAINDER_RE.match(remainder)
    )


def _title_overall_length_value_supported(value: str, text: str) -> bool:
    match = _TITLE_OVERALL_LENGTH_RE.fullmatch(_normalize(text))
    if match is None:
        return False
    fact_match = re.fullmatch(
        r"(?i)(?P<nominal>\d+(?:[.,]\d+)?)\s*(?P<unit>mm|cm|m)?",
        _normalize(value),
    )
    if fact_match is None:
        return False
    nominal = _measurement_decimal(match.group("nominal"))
    fact_nominal = _measurement_decimal(fact_match.group("nominal"))
    source_unit = (match.group("unit") or "").casefold()
    fact_unit = (fact_match.group("unit") or "").casefold()
    return nominal == fact_nominal and (
        not source_unit or not fact_unit or source_unit == fact_unit
    )


def _anchored_document_fact_value_supported(
    fact_name: str,
    value: str,
    text: str,
) -> bool:
    if fact_name == "company":
        return _company_title_value_supported(value, text)
    if fact_name == "drawing_number":
        return _drawing_number_value_supported(value, text)
    if fact_name == "product_name":
        return _product_title_value_supported(value, text)
    if fact_name == "overall_length":
        return _title_overall_length_value_supported(value, text)
    return False


def _append_document_fact(
    facts: list[ExtractedFact],
    proposed: ExtractedFact,
) -> None:
    for index, existing in enumerate(facts):
        if existing.name != proposed.name or _normalize(existing.value) != _normalize(
            proposed.value
        ):
            continue
        references = {item.evidence_id: item for item in existing.evidence_refs}
        references.update({item.evidence_id: item for item in proposed.evidence_refs})
        facts[index] = existing.model_copy(
            update={"evidence_refs": list(references.values())}
        )
        return
    facts.append(proposed)


def _measurement_decimal(value: str) -> Decimal | None:
    try:
        return Decimal(value.replace(",", "."))
    except InvalidOperation:
        return None


def _overall_length_fact(
    inventory: dict[str, _EvidenceItem],
    *,
    allowed_ids: set[str] | None,
) -> ProposedFact | None:
    eligible = [
        item
        for item in inventory.values()
        if (allowed_ids is None or item.evidence_id in allowed_ids)
        and not (item.source_ref.model_extra or {}).get("asset_sha256")
        and (item.source_ref.model_extra or {}).get("authority") != "advisory"
    ]
    labeled: dict[Decimal, list[tuple[_EvidenceItem, re.Match[str]]]] = {}
    for item in eligible:
        for match in _OVERALL_LENGTH_LABEL_RE.finditer(item.text):
            nominal = _measurement_decimal(match.group("nominal"))
            if nominal is not None:
                labeled.setdefault(nominal, []).append((item, match))
    if len(labeled) != 1:
        return None
    nominal, labeled_matches = next(iter(labeled.items()))

    toleranced: dict[str, _EvidenceItem] = {}
    for item in eligible:
        match = _TOLERANCED_LENGTH_RE.fullmatch(item.text)
        if match is None or _measurement_decimal(match.group("nominal")) != nominal:
            continue
        toleranced.setdefault(item.text, item)
    if len(toleranced) == 1:
        value, item = next(iter(toleranced.items()))
        return ProposedFact(
            name="overall_length",
            value=value,
            citations=[item.evidence_id],
        )

    values = {
        f"{match.group('nominal')}{match.group('unit') or ''}": item
        for item, match in labeled_matches
    }
    if len(values) != 1:
        return None
    value, item = next(iter(values.items()))
    return ProposedFact(
        name="overall_length",
        value=value,
        citations=[item.evidence_id],
    )


def _repair_document_fact_from_evidence(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
    *,
    allowed_ids: set[str] | None,
) -> ProposedFact:
    """Correct fact semantics only when authoritative source evidence proves it."""

    items = _authoritative_fact_items(fact, inventory, allowed_ids=allowed_ids)
    value = _normalize(fact.value)
    if fact.name in _ROLE_FACT_NAMES:
        role_value_ids, _role_label_ids = _role_fact_supporting_ids(
            fact,
            inventory,
            allowed_ids=allowed_ids,
        )
        if not role_value_ids and any(
            item.text == value and _COMPANY_VALUE_TAIL_RE.search(value)
            for item in items
        ):
            return fact.model_copy(update={"name": "company"})
    if fact.name == "overall_length":
        repaired = _overall_length_fact(inventory, allowed_ids=allowed_ids)
        return repaired or fact
    if fact.name in {"material_number", "product_number", "product_name"} and any(
        _drawing_number_value_supported(value, item.text) for item in items
    ):
        return fact.model_copy(update={"name": "drawing_number"})
    return fact


def _validated_fact(
    fact: ProposedFact,
    inventory: dict[str, _EvidenceItem],
    *,
    allowed_ids: set[str] | None,
    issues: list[str],
    allow_table_substring: bool = False,
) -> tuple[ExtractedFact | None, set[str]]:
    fact = _normalize_fact_citations(fact, inventory)
    refs: list[EvidenceReference] = []
    consumed: set[str] = set()
    value = _normalize(fact.value)
    if not value:
        issues.append(f"unsupported_fact_value:{fact.name}")
        return None, consumed
    if _label_only_fact_value(fact.name, value):
        issues.append(f"unsupported_fact_value:{fact.name}")
        return None, consumed
    role_value_ids, role_label_ids = _role_fact_supporting_ids(
        fact,
        inventory,
        allowed_ids=allowed_ids,
    )
    for evidence_id in fact.citations:
        item = inventory.get(evidence_id)
        if item is None:
            issues.append(f"unknown_evidence_id:{evidence_id}")
            continue
        if allowed_ids is not None and evidence_id not in allowed_ids:
            issues.append(f"out_of_segment_evidence_id:{evidence_id}")
            continue
        provenance = item.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get("asset_sha256"):
            issues.append(f"advisory_evidence_forbidden:{evidence_id}")
            continue
        if evidence_id in role_label_ids:
            refs.append(
                EvidenceReference(
                    evidence_id=item.evidence_id,
                    quote=item.text,
                    source_ref=item.source_ref.model_copy(deep=True),
                )
            )
            consumed.add(item.evidence_id)
            continue
        value_supported = value == item.text
        if not value_supported and value in item.text:
            labeled = _labeled_fact_value_supported(
                fact.name,
                value,
                item.text,
            )
            anchored = _anchored_document_fact_value_supported(
                fact.name,
                value,
                item.text,
            )
            value_supported = labeled or anchored or (
                item.table_id is not None
                and allow_table_substring
                and fact.name not in _FACT_VALUE_PREFIXES
                and len(value) >= 2
            )
        if fact.name in _ROLE_FACT_NAMES and evidence_id not in role_value_ids:
            value_supported = False
        if not value_supported:
            issues.append(f"unsupported_evidence_ref:{fact.name}:{evidence_id}")
            continue
        refs.append(
            EvidenceReference(
                evidence_id=item.evidence_id,
                quote=fact.value,
                source_ref=item.source_ref.model_copy(deep=True),
            )
        )
        consumed.add(item.evidence_id)
    if not refs:
        return None, consumed
    return ExtractedFact(
        name=fact.name,
        value=fact.value,
        evidence_refs=refs,
        sensitive=fact.sensitive,
    ), consumed


def _table_index(evidence: DocumentEvidence) -> dict[str, EvidenceTable]:
    tables: dict[str, EvidenceTable] = {}
    for page in evidence.pages:
        for table in page.tables:
            if table.table_id in tables:
                raise ValueError(f"duplicate MinerU table id: {table.table_id}")
            tables[table.table_id] = table
    return tables


def _intent_correction_payload(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    partition_issues: list[str],
    *,
    table_only: bool = False,
) -> dict[str, Any]:
    """Build one compact repair request with explicit inclusive axis bounds."""

    constraints: list[dict[str, Any]] = []
    for table_id, table in tables.items():
        row_count = len(table.rows)
        column_count = max((len(row) for row in table.rows), default=0)
        sampled_rows = _spread_indices(row_count, min(4, row_count))
        constraints.append(
            {
                "table_id": table_id,
                "valid_axes": {
                    "rows": {
                        "size": row_count,
                        "inclusive_start": 0 if row_count else None,
                        "inclusive_end": row_count - 1 if row_count else None,
                    },
                    "columns": {
                        "size": column_count,
                        "inclusive_start": 0 if column_count else None,
                        "inclusive_end": column_count - 1 if column_count else None,
                    },
                },
                "sample_rows": [
                    {
                        "row": row_index,
                        "values": [
                            ("" if value is None else str(value))[:80]
                            for value in table.rows[row_index][:10]
                        ],
                    }
                    for row_index in sampled_rows
                ],
            }
        )
    return {
        "previous_intent": (
            {"tables": [table.model_dump(mode="json") for table in intent.tables]}
            if table_only
            else intent.model_dump(mode="json")
        ),
        "partition_errors": list(partition_issues),
        "table_constraints": constraints,
    }


@dataclass(frozen=True, slots=True)
class _ValidatedSegment:
    table_id: str
    orientation: RecordOrientation
    start: int
    end: int
    intent: SegmentIntent

    @property
    def segment_id(self) -> str:
        return _segment_id(self.table_id, self.orientation, self.start, self.end)


def _validate_intent_partition(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    issues: list[str],
) -> list[_ValidatedSegment]:
    """Require a non-overlapping full axis partition for every recovered table."""

    proposed: dict[str, TableIntent] = {}
    for table_intent in intent.tables:
        if table_intent.table_id in proposed:
            issues.append(f"duplicate_table_intent:{table_intent.table_id}")
            continue
        proposed[table_intent.table_id] = table_intent
    expected_ids = set(tables)
    if set(proposed) != expected_ids:
        for table_id in sorted(expected_ids - set(proposed)):
            issues.append(f"missing_table_intent:{table_id}")
        for table_id in sorted(set(proposed) - expected_ids):
            issues.append(f"unknown_table_intent:{table_id}")

    segments: list[_ValidatedSegment] = []
    for table_id, table in tables.items():
        table_intent = proposed.get(table_id)
        if table_intent is None:
            continue
        axis_size = _table_axis_size(table, table_intent.orientation)
        if axis_size == 0:
            if table_intent.segments:
                issues.append(f"segments_for_empty_table:{table_id}")
            continue
        covered: set[int] = set()
        valid: list[_ValidatedSegment] = []
        for segment in table_intent.segments:
            if segment.start >= axis_size or segment.end >= axis_size:
                issues.append(
                    f"segment_out_of_bounds:{table_id}:{segment.start}:{segment.end}"
                )
                continue
            indexes = set(range(segment.start, segment.end + 1))
            if covered & indexes:
                issues.append(
                    f"overlapping_segments:{table_id}:{segment.start}:{segment.end}"
                )
                continue
            covered.update(indexes)
            valid.append(
                _ValidatedSegment(
                    table_id=table_id,
                    orientation=table_intent.orientation,
                    start=segment.start,
                    end=segment.end,
                    intent=segment.intent,
                )
            )
        if covered != set(range(axis_size)):
            issues.append(f"incomplete_table_partition:{table_id}")
            continue
        segments.extend(valid)
    return segments


def _segments_cover_axis(segments: list[TableSegmentIntent], size: int) -> bool:
    if size == 0:
        return not segments
    cursor = 0
    for segment in sorted(segments, key=lambda value: (value.start, value.end)):
        if segment.start != cursor or segment.end >= size:
            return False
        cursor = segment.end + 1
    return cursor == size


def _segments_from_axis_intents(
    intents: list[SegmentIntent],
) -> list[TableSegmentIntent]:
    if not intents:
        return []
    segments: list[TableSegmentIntent] = []
    start = 0
    current = intents[0]
    for index, intent in enumerate(intents[1:], start=1):
        if intent == current:
            continue
        segments.append(TableSegmentIntent(start=start, end=index - 1, intent=current))
        start = index
        current = intent
    segments.append(
        TableSegmentIntent(start=start, end=len(intents) - 1, intent=current)
    )
    return segments


@dataclass(frozen=True, slots=True)
class _PartitionRepair:
    segments: tuple[TableSegmentIntent, ...]
    geometry_changed: bool = False
    ambiguity_changed: bool = False


def _axis_has_content(
    table: EvidenceTable,
    orientation: RecordOrientation,
    index: int,
) -> bool:
    if orientation == "rows":
        return index < len(table.rows) and any(
            _normalize(value) for value in table.rows[index]
        )
    return any(index < len(row) and _normalize(row[index]) for row in table.rows)


def _repair_axis_partition(
    table: EvidenceTable,
    orientation: RecordOrientation,
    segments: list[TableSegmentIntent],
) -> _PartitionRepair:
    """Make model-advised geometry total without expanding record authority."""

    size = _table_axis_size(table, orientation)
    if size == 0:
        return _PartitionRepair(
            segments=(),
            geometry_changed=bool(segments),
        )
    votes: list[set[SegmentIntent]] = [set() for _ in range(size)]
    geometry_changed = False
    for segment in segments:
        start = max(0, segment.start)
        end = min(size - 1, segment.end)
        if start > end:
            geometry_changed = True
            continue
        if start != segment.start or end != segment.end:
            geometry_changed = True
        for index in range(start, end + 1):
            if segment.intent in votes[index]:
                geometry_changed = True
            votes[index].add(segment.intent)

    ambiguity_changed = False
    intents: list[SegmentIntent] = []
    for index, proposed in enumerate(votes):
        if len(proposed) == 1:
            intents.append(next(iter(proposed)))
            continue
        ambiguity_changed = True
        intents.append(
            "metadata" if _axis_has_content(table, orientation, index) else "layout"
        )
    repaired = tuple(_segments_from_axis_intents(intents))
    if list(repaired) != segments and not ambiguity_changed:
        geometry_changed = True
    return _PartitionRepair(
        segments=repaired,
        geometry_changed=geometry_changed,
        ambiguity_changed=ambiguity_changed,
    )


def _safe_nonrecord_table_intent(
    table_id: str,
    table: EvidenceTable,
) -> TableIntent:
    intents: list[SegmentIntent] = [
        "metadata" if _axis_has_content(table, "rows", index) else "layout"
        for index in range(len(table.rows))
    ]
    return TableIntent(
        table_id=table_id,
        orientation="rows",
        segments=_segments_from_axis_intents(intents),
    )


def _trusted_native_record_intent(
    table_id: str,
    table: EvidenceTable,
) -> TableIntent | None:
    """Apply an adapter-owned record partition without model reinterpretation."""

    if table.source != "spreadsheet-envelope":
        return None
    raw = (table.model_extra or {}).get("native_record_layout")
    if not isinstance(raw, dict) or raw.get("source") != "spreadsheet-tabular-v1":
        return None
    orientation = raw.get("orientation")
    if orientation not in {"rows", "columns"}:
        return None
    raw_record_axes = raw.get("record_axes")
    raw_header_axes = raw.get("header_axes")
    if not isinstance(raw_record_axes, list) or not isinstance(raw_header_axes, list):
        return None
    if any(
        isinstance(axis, bool) or not isinstance(axis, int)
        for axis in (*raw_record_axes, *raw_header_axes)
    ):
        return None
    record_axes = sorted(set(raw_record_axes))
    header_axes = set(raw_header_axes)
    if not record_axes or len(record_axes) != len(raw_record_axes):
        return None
    if len(header_axes) != len(raw_header_axes) or header_axes & set(record_axes):
        return None
    axis_size = _table_axis_size(table, orientation)
    if any(axis < 0 or axis >= axis_size for axis in (*record_axes, *header_axes)):
        return None
    if any(not _axis_has_content(table, orientation, axis) for axis in record_axes):
        return None
    axis_intents: list[SegmentIntent] = ["layout"] * axis_size
    for axis in record_axes:
        axis_intents[axis] = "records"
    return TableIntent(
        table_id=table_id,
        orientation=orientation,
        segments=_segments_from_axis_intents(axis_intents),
    )


@dataclass(frozen=True, slots=True)
class _TableOrientationEvidence:
    orientation: RecordOrientation
    score: float
    label_axes: frozenset[int]
    record_axes: frozenset[int]


def _table_orientation_evidence(
    table: EvidenceTable,
    document_type: str,
) -> _TableOrientationEvidence | None:
    """Prefer a record axis only when source field labels make it unambiguous.

    A horizontal record table concentrates several business labels in one row;
    its remaining populated rows are records.  A transposed table concentrates
    those labels in one column and needs at least two populated value columns
    so that an ordinary key/value metadata table is not treated as records.
    """

    if not table.rows:
        return None
    width = max((len(row) for row in table.rows), default=0)
    if not width:
        return None
    allowed_targets = allowed_line_targets(document_type)
    labels: dict[tuple[int, int], str] = {}
    for row_index, row in enumerate(table.rows):
        for column_index, value in enumerate(row):
            source_label = _normalize(value)
            if not source_label:
                continue
            target = source_label_line_target(source_label, document_type)
            if target in allowed_targets:
                labels[(row_index, column_index)] = str(target)
    if len(set(labels.values())) < 2:
        return None

    identity_targets = {
        "model",
        "product_code",
        "name_raw",
        "specification_raw",
        "material_code",
        "material_name",
        "equipment_code",
        "equipment_name",
        "mold_number",
        "mold_name",
        "technical_drawing_number",
        "technical_product_name",
        "process_step",
        "parameter_name",
        "record_code",
        "record_name",
        "description",
    }

    def candidate(
        orientation: RecordOrientation,
    ) -> _TableOrientationEvidence | None:
        axis_size = len(table.rows) if orientation == "rows" else width
        field_size = width if orientation == "rows" else len(table.rows)

        def coordinates(axis: int, field_axis: int) -> tuple[int, int]:
            if orientation == "rows":
                return axis, field_axis
            return field_axis, axis

        targets_by_axis: list[set[str]] = [set() for _index in range(axis_size)]
        for (row, column), target in labels.items():
            axis = row if orientation == "rows" else column
            targets_by_axis[axis].add(target)
        label_axis = max(
            range(axis_size),
            key=lambda index: (len(targets_by_axis[index]), -index),
        )
        coverage = len(targets_by_axis[label_axis])
        if coverage < 2:
            return None
        identity_field_axes = {
            field_axis
            for field_axis in range(field_size)
            if labels.get(coordinates(label_axis, field_axis)) in identity_targets
        }
        if not identity_field_axes:
            return None
        record_axes = frozenset(
            axis
            for axis in range(axis_size)
            if axis != label_axis
            and any(
                row < len(table.rows)
                and column < len(table.rows[row])
                and _normalize(table.rows[row][column])
                and (row, column) not in labels
                for row, column in (
                    coordinates(axis, field_axis) for field_axis in identity_field_axes
                )
            )
        )
        minimum_records = 1 if orientation == "rows" else 2
        if len(record_axes) < minimum_records:
            return None
        label_axes = frozenset(
            index for index, targets in enumerate(targets_by_axis) if len(targets) >= 2
        )
        return _TableOrientationEvidence(
            orientation=orientation,
            score=(
                2.0 * coverage
                + min(len(record_axes), 3)
                + coverage / max(len(labels), 1)
            ),
            label_axes=label_axes,
            record_axes=record_axes - label_axes,
        )

    candidates = [
        evidence
        for orientation in ("rows", "columns")
        if (evidence := candidate(orientation)) is not None
    ]
    if len(candidates) == 1:
        return candidates[0] if candidates[0].record_axes else None
    if len(candidates) != 2:
        return None
    candidates.sort(key=lambda candidate: candidate.score, reverse=True)
    strongest, alternative = candidates
    if (
        strongest.record_axes
        and strongest.score >= alternative.score + 2.0
        and strongest.score >= alternative.score * 1.25
    ):
        return strongest
    return None


def _partition_from_orientation_evidence(
    evidence: _TableOrientationEvidence,
    axis_size: int,
) -> list[TableSegmentIntent]:
    axis_intents: list[SegmentIntent] = ["layout"] * axis_size
    for index in evidence.record_axes:
        if 0 <= index < axis_size:
            axis_intents[index] = "records"
    return _segments_from_axis_intents(axis_intents)


def _normalize_intent_partition(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    evidence: DocumentEvidence,
    *,
    issues: list[str] | None = None,
    complete_missing: bool = False,
) -> DocumentIntent:
    """Bind model semantics to valid axes and deterministic record boundaries."""

    assessment = assess_record_regions(evidence)
    region_axes: dict[tuple[str, RecordOrientation], set[int]] = {}
    region_orientations: dict[str, set[RecordOrientation]] = {}
    for region in assessment.record_regions:
        region_axes.setdefault((region.table_id, region.orientation), set()).update(
            range(region.data_start, region.data_end + 1)
        )
        region_orientations.setdefault(region.table_id, set()).add(region.orientation)
    no_record_tables = set(assessment.no_record_table_ids)
    native_intents = {
        table_id: native_intent
        for table_id, table in tables.items()
        if (native_intent := _trusted_native_record_intent(table_id, table)) is not None
    }
    normalized_tables: list[TableIntent] = []
    normalized_table_ids: set[str] = set()
    for proposed in intent.tables:
        table = tables.get(proposed.table_id)
        if table is None:
            if not complete_missing:
                normalized_tables.append(proposed)
            continue
        if proposed.table_id in normalized_table_ids:
            continue
        normalized_table_ids.add(proposed.table_id)
        if native_intent := native_intents.get(proposed.table_id):
            normalized_tables.append(native_intent)
            continue
        document_type = _document_intent_family(intent.document_intent)
        deterministic_orientations = region_orientations.get(proposed.table_id, set())
        if len(deterministic_orientations) == 1:
            orientation = next(iter(deterministic_orientations))
            selected_size = _table_axis_size(table, orientation)
            confirmed_records = region_axes[(proposed.table_id, orientation)]
            orientation_evidence = _table_orientation_evidence(table, document_type)
            if (
                orientation_evidence is not None
                and orientation_evidence.orientation == orientation
            ):
                narrowed_records = confirmed_records & set(
                    orientation_evidence.record_axes
                )
                if narrowed_records:
                    if narrowed_records != confirmed_records and issues is not None:
                        issues.append(
                            "record_region_narrowed_by_header_evidence:"
                            f"{proposed.table_id}"
                        )
                    confirmed_records = narrowed_records
            normalized_tables.append(
                TableIntent(
                    table_id=proposed.table_id,
                    orientation=orientation,
                    segments=_segments_from_axis_intents(
                        [
                            "records" if index in confirmed_records else "layout"
                            for index in range(selected_size)
                        ]
                    ),
                )
            )
            continue
        if proposed.table_id in no_record_tables:
            normalized_tables.append(
                TableIntent(
                    table_id=proposed.table_id,
                    orientation="rows",
                    segments=(
                        [
                            TableSegmentIntent(
                                start=0,
                                end=len(table.rows) - 1,
                                intent="metadata",
                            )
                        ]
                        if table.rows
                        else []
                    ),
                )
            )
            continue
        orientation_evidence = _table_orientation_evidence(table, document_type)
        if orientation_evidence is not None:
            evidence_size = _table_axis_size(
                table,
                orientation_evidence.orientation,
            )
            proposed_is_valid = (
                proposed.orientation == orientation_evidence.orientation
                and _segments_cover_axis(proposed.segments, evidence_size)
            )
            if not proposed_is_valid:
                proposed = TableIntent(
                    table_id=proposed.table_id,
                    orientation=orientation_evidence.orientation,
                    segments=_partition_from_orientation_evidence(
                        orientation_evidence,
                        evidence_size,
                    ),
                )
        orientation = proposed.orientation
        selected_size = _table_axis_size(table, orientation)
        alternative: RecordOrientation = "columns" if orientation == "rows" else "rows"
        alternative_size = _table_axis_size(table, alternative)
        selected_valid = _segments_cover_axis(proposed.segments, selected_size)
        alternative_valid = _segments_cover_axis(proposed.segments, alternative_size)
        if not selected_valid and alternative_valid:
            orientation = alternative
            selected_size = alternative_size
            selected_valid = True
        if not selected_valid:
            deterministic_orientations = region_orientations.get(
                proposed.table_id, set()
            )
            selected_records = region_axes.get((proposed.table_id, orientation), set())
            proposed_axes: set[int] = set()
            proposed_within_axis = True
            for segment in proposed.segments:
                if segment.end >= selected_size:
                    proposed_within_axis = False
                    break
                proposed_axes.update(range(segment.start, segment.end + 1))
            if (
                selected_records
                and proposed_within_axis
                and proposed_axes == selected_records
            ):
                axis_intents = [
                    "records" if index in selected_records else "layout"
                    for index in range(selected_size)
                ]
                normalized_tables.append(
                    TableIntent(
                        table_id=proposed.table_id,
                        orientation=orientation,
                        segments=_segments_from_axis_intents(axis_intents),
                    )
                )
                continue
            flattened_size = len(table.rows) * max(
                (len(row) for row in table.rows),
                default=0,
            )
            flattened_partition = _segments_cover_axis(
                proposed.segments,
                flattened_size,
            )
            if len(deterministic_orientations) == 1 and flattened_partition:
                orientation = next(iter(deterministic_orientations))
                selected_size = _table_axis_size(table, orientation)
                confirmed_records = region_axes[(proposed.table_id, orientation)]
                axis_intents = [
                    "records" if index in confirmed_records else "layout"
                    for index in range(selected_size)
                ]
                normalized_tables.append(
                    TableIntent(
                        table_id=proposed.table_id,
                        orientation=orientation,
                        segments=_segments_from_axis_intents(axis_intents),
                    )
                )
                continue
            if proposed.table_id in no_record_tables and flattened_partition:
                normalized_tables.append(
                    TableIntent(
                        table_id=proposed.table_id,
                        orientation="rows",
                        segments=(
                            [
                                TableSegmentIntent(
                                    start=0,
                                    end=max(0, len(table.rows) - 1),
                                    intent="metadata",
                                )
                            ]
                            if table.rows
                            else []
                        ),
                    )
                )
                continue
            if flattened_partition:
                if complete_missing:
                    normalized_tables.append(
                        _safe_nonrecord_table_intent(proposed.table_id, table)
                    )
                    if issues is not None:
                        issues.append(
                            f"intent_partition_ambiguity_repaired:{proposed.table_id}"
                        )
                else:
                    normalized_tables.append(proposed)
                continue
            if document_type == "technical_document":
                # Technical BOMs need the existing evidence-shape scorer to
                # exclude title/revision rows. Geometry repair alone cannot
                # safely decide that every in-bounds row is a business record.
                normalized_tables.append(proposed)
                continue
            repair = _repair_axis_partition(
                table,
                orientation,
                proposed.segments,
            )
            if repair.geometry_changed and issues is not None:
                issues.append(f"intent_partition_geometry_repaired:{proposed.table_id}")
            if repair.ambiguity_changed and issues is not None:
                issues.append(
                    f"intent_partition_ambiguity_repaired:{proposed.table_id}"
                )
            proposed = TableIntent(
                table_id=proposed.table_id,
                orientation=orientation,
                segments=list(repair.segments),
            )
            selected_valid = _segments_cover_axis(
                proposed.segments,
                selected_size,
            )
            if not selected_valid:
                if complete_missing:
                    normalized_tables.append(
                        _safe_nonrecord_table_intent(proposed.table_id, table)
                    )
                else:
                    normalized_tables.append(proposed)
                continue
        axis_intents: list[SegmentIntent] = ["unknown"] * selected_size
        for segment in proposed.segments:
            for index in range(segment.start, segment.end + 1):
                axis_intents[index] = segment.intent
        confirmed_records = region_axes.get((proposed.table_id, orientation))
        if confirmed_records:
            for index in range(selected_size):
                if index in confirmed_records:
                    axis_intents[index] = "records"
                elif axis_intents[index] == "records":
                    axis_intents[index] = "layout"
        elif proposed.table_id in no_record_tables:
            axis_intents = [
                "metadata" if value in {"records", "layout"} else value
                for value in axis_intents
            ]
        normalized_tables.append(
            TableIntent(
                table_id=proposed.table_id,
                orientation=orientation,
                segments=_segments_from_axis_intents(axis_intents),
            )
        )
    for table_id, table in tables.items():
        if table_id in normalized_table_ids:
            continue
        if native_intent := native_intents.get(table_id):
            normalized_tables.append(native_intent)
            continue
        deterministic_orientations = region_orientations.get(table_id, set())
        if len(deterministic_orientations) == 1:
            orientation = next(iter(deterministic_orientations))
            size = _table_axis_size(table, orientation)
            records = region_axes[(table_id, orientation)]
            orientation_evidence = _table_orientation_evidence(
                table,
                _document_intent_family(intent.document_intent),
            )
            if (
                orientation_evidence is not None
                and orientation_evidence.orientation == orientation
            ):
                narrowed_records = records & set(orientation_evidence.record_axes)
                if narrowed_records:
                    if narrowed_records != records and issues is not None:
                        issues.append(
                            f"record_region_narrowed_by_header_evidence:{table_id}"
                        )
                    records = narrowed_records
            normalized_tables.append(
                TableIntent(
                    table_id=table_id,
                    orientation=orientation,
                    segments=_segments_from_axis_intents(
                        [
                            "records" if index in records else "layout"
                            for index in range(size)
                        ]
                    ),
                )
            )
        elif table_id in no_record_tables:
            normalized_tables.append(
                TableIntent(
                    table_id=table_id,
                    orientation="rows",
                    segments=(
                        [
                            TableSegmentIntent(
                                start=0,
                                end=len(table.rows) - 1,
                                intent="layout",
                            )
                        ]
                        if table.rows
                        else []
                    ),
                )
            )
        else:
            orientation_evidence = _table_orientation_evidence(
                table,
                _document_intent_family(intent.document_intent),
            )
            if orientation_evidence is not None:
                size = _table_axis_size(table, orientation_evidence.orientation)
                normalized_tables.append(
                    TableIntent(
                        table_id=table_id,
                        orientation=orientation_evidence.orientation,
                        segments=_partition_from_orientation_evidence(
                            orientation_evidence,
                            size,
                        ),
                    )
                )
                if issues is not None:
                    issues.append(f"intent_partition_geometry_repaired:{table_id}")
            elif complete_missing:
                normalized_tables.append(_safe_nonrecord_table_intent(table_id, table))
                if issues is not None:
                    issues.append(f"intent_partition_ambiguity_repaired:{table_id}")
    return intent.model_copy(update={"tables": normalized_tables}, deep=True)


_TECHNICAL_TABLE_IDENTIFIER_RE = re.compile(
    r"(?:\b[A-Za-z]{2,}[A-Za-z0-9._/-]*\d[A-Za-z0-9._/-]*\b|"
    r"\b\d{3,}[A-Za-z0-9._/-]*[-/]\d+[A-Za-z0-9._/-]*\b)"
)
_TECHNICAL_TABLE_PIN_RE = re.compile(
    r"^(?:[AB]\d{1,2}|D[+-]|CC|GND|VBUS|VCONN|SUB[12]|SSTX[+-]?\s*\d*|"
    r"SSRX[+-]?\s*\d*)$",
    re.IGNORECASE,
)


def _technical_table_role_hits(value: object) -> set[str]:
    return {
        role
        for role, tokens in _TECHNICAL_TABLE_ROLE_TOKENS.items()
        if any(_technical_table_token_matches(value, token) for token in tokens)
    }


def _technical_table_auxiliary_hits(value: object) -> set[str]:
    return {
        role
        for role, tokens in _TECHNICAL_TABLE_AUXILIARY_TOKENS.items()
        if any(_technical_table_token_matches(value, token) for token in tokens)
    }


def _technical_table_identifier(value: object) -> bool:
    text = _normalize(value)
    if not text or _TECHNICAL_TABLE_PIN_RE.fullmatch(text):
        return False
    compact = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text))
    # A date, a bare row number, and a dimension are not material identities.
    if re.fullmatch(r"\d{1,2}[./-]\d{1,2}[./-]\d{2,4}", compact):
        return False
    if re.fullmatch(r"\d{1,3}", compact):
        return False
    # Numeric-only material codes are common in BOMs.  Keep short numbers
    # reserved for line numbers, while accepting longer codes unless they are
    # clearly dates or decimal dimensions.
    if re.fullmatch(r"\d{4,18}", compact):
        if re.fullmatch(r"(?:19|20)\d{2}", compact):
            return False
        if len(compact) == 8:
            try:
                date(
                    int(compact[:4]),
                    int(compact[4:6]),
                    int(compact[6:]),
                )
            except ValueError:
                return True
            return False
        return True
    return bool(_TECHNICAL_TABLE_IDENTIFIER_RE.search(compact))


def _technical_table_description(value: object) -> bool:
    text = _normalize(value)
    if not text or _technical_table_identifier(value):
        return False
    if _TECHNICAL_TABLE_PIN_RE.fullmatch(text):
        return False
    if _TECHNICAL_TABLE_MEASURE_RE.fullmatch(text):
        return False
    if re.fullmatch(r"[A-Za-z]{1,8}[+-]?", text):
        return False
    # Descriptions normally contain either several CJK characters or at least
    # two alphabetic words.  This excludes title-block labels and pin values.
    cjk_count = sum("\u3400" <= char <= "\u9fff" for char in text)
    word_count = len(re.findall(r"[A-Za-z]{2,}", text))
    return cjk_count >= 2 or word_count >= 2 or len(text) >= 12


@dataclass(frozen=True, slots=True)
class _GeometryOCRToken:
    """One native OCR token used for evidence-only row reconstruction."""

    index: int
    text: str
    bbox: EvidenceBBox
    score: float | None = None

    @property
    def x(self) -> float:
        return (self.bbox.x0 + self.bbox.x1) / 2.0

    @property
    def y(self) -> float:
        return (self.bbox.y0 + self.bbox.y1) / 2.0


_GEOMETRY_HEADER_MARKERS = frozenset(
    {
        "序号",
        "料号",
        "用量",
        "规格描述",
        "item",
        "item no",
        "part no",
        "quantity",
        "description",
    }
)
_GEOMETRY_COMPANY_RE = re.compile(
    r"(?:有限公司|股份有限公司|technology\s+co\.?|limited|\bco\.?\s*,?\s*ltd\.?\b)",
    re.IGNORECASE,
)
_GEOMETRY_PRODUCT_WORDS = frozenset(
    {
        "abs",
        "cable",
        "copper",
        "foil",
        "material",
        "plug",
        "rohs",
        "shell",
        "tpe",
        "胶料",
        "内模",
        "外壳",
        "铜箔",
    }
)
_GEOMETRY_STRONG_CONTEXT_TOKENS = (
    "signal",
    "pin",
    "vbus",
    "vconn",
    "drawing",
    "drawing no",
    "drawing number",
    "图号",
    "版本变更",
    "客户代码",
    "样品代码",
    "测试条件",
)
_GEOMETRY_NON_PRODUCT_RE = re.compile(
    r"^(?:with|without)\s+e[- ]?mark$|^type\s*c\s*[ab]$|^(?:signal|gnd|vbus|vconn|shield)$",
    re.IGNORECASE,
)
_GEOMETRY_PIN_TOKEN_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:[AB]\d{1,2}|D[+-]|CC|GND|VBUS|VCONN|SUB[12])"
    r"(?![A-Za-z0-9])[,，、/\\s]*",
    re.IGNORECASE,
)


def _page_ocr_tokens(page: EvidencePage) -> list[_GeometryOCRToken]:
    """Read bounded native OCR tokens without copying provider payloads."""

    raw = page.raw.get("overall_ocr_res")
    if not isinstance(raw, Mapping):
        return []
    texts = raw.get("rec_texts")
    boxes = raw.get("rec_boxes")
    scores = raw.get("rec_scores")
    if not isinstance(texts, list) or not isinstance(boxes, list):
        return []
    tokens: list[_GeometryOCRToken] = []
    for index, (raw_text, raw_box) in enumerate(zip(texts, boxes, strict=False)):
        text = _normalize(raw_text)
        if not text or not isinstance(raw_box, (list, tuple)) or len(raw_box) < 4:
            continue
        try:
            x0, y0, x1, y1 = (float(value) for value in raw_box[:4])
            bbox = EvidenceBBox(
                x0=min(x0, x1),
                y0=min(y0, y1),
                x1=max(x0, x1),
                y1=max(y0, y1),
                coordinate_space=page.coordinate_space,
            )
        except (TypeError, ValueError):
            continue
        score: float | None = None
        if isinstance(scores, list) and index < len(scores):
            try:
                candidate = float(scores[index])
                if 0.0 <= candidate <= 1.0:
                    score = candidate
            except (TypeError, ValueError):
                pass
        tokens.append(_GeometryOCRToken(index=index, text=text, bbox=bbox, score=score))
    return tokens


def _geometry_token_in_table(
    token: _GeometryOCRToken,
    table: EvidenceTable,
) -> bool:
    bbox = table.bbox
    if (
        bbox is None
        or bbox.coordinate_space == "unknown"
        or token.bbox.coordinate_space == "unknown"
        or bbox.coordinate_space != token.bbox.coordinate_space
    ):
        return False
    # A small tolerance handles OCR boxes that touch the table border.
    tolerance = max(
        2.0,
        min(bbox.x1 - bbox.x0, bbox.y1 - bbox.y0) * 0.005,
    )
    return (
        token.x >= bbox.x0 - tolerance
        and token.x <= bbox.x1 + tolerance
        and token.y >= bbox.y0 - tolerance
        and token.y <= bbox.y1 + tolerance
    )


def _geometry_line_number(text: str) -> int | None:
    normalized = _normalize(text)
    match = re.fullmatch(r"\d{1,2}", normalized)
    if match:
        return int(normalized)
    # Providers occasionally preserve circled numerals as a single Unicode
    # character; use Unicode numeric metadata instead of a locale-specific map.
    if len(normalized) == 1:
        try:
            value = unicodedata.numeric(normalized)
        except (TypeError, ValueError):
            return None
        if value.is_integer() and 1 <= value <= 99:
            return int(value)
    return None


def _geometry_description_candidate(text: str) -> bool:
    normalized = _normalize(text)
    if not normalized:
        return False
    compact = re.sub(r"\s+", "", normalized).casefold()
    if compact in {marker.casefold() for marker in _GEOMETRY_HEADER_MARKERS}:
        return False
    if _GEOMETRY_NON_PRODUCT_RE.fullmatch(normalized):
        return False
    if not _GEOMETRY_PIN_TOKEN_RE.sub("", normalized).strip(" ,/"):
        return False
    if re.search(r"[\u00b1$^]|\bX(?:\.[X0-9]+)+", normalized, re.IGNORECASE):
        return False
    if _GEOMETRY_COMPANY_RE.search(normalized):
        return False
    if _technical_table_quantity(normalized):
        return False
    if _technical_table_identifier(normalized) and re.fullmatch(
        r"[A-Za-z0-9._/-]{3,32}",
        re.sub(r"\s+", "", normalized),
    ):
        return False
    auxiliary = _technical_table_auxiliary_hits(normalized)
    if auxiliary & {"pin", "revision", "dimension", "title"}:
        # Keep a mixed pin/material description (for example ``A1 ... Shell``)
        # but discard pure title, dimension, and revision labels.  CJK alone is
        # not enough: labels such as ``版本`` and ``日期`` are CJK too.
        words = {word.casefold() for word in re.findall(r"[A-Za-z]{2,}", normalized)}
        lowered = normalized.casefold()
        has_product_word = bool(words & _GEOMETRY_PRODUCT_WORDS) or any(
            marker in lowered
            for marker in ("铜箔", "胶料", "内模", "外壳", "插头", "线材")
        )
        if not has_product_word:
            return False
    if re.fullmatch(r"[A-Za-z]{1,8}[+-]?", normalized):
        return False
    if _technical_table_description(normalized):
        return True
    if _technical_table_identifier(normalized):
        cjk_count = sum("\u3400" <= char <= "\u9fff" for char in normalized)
        word_count = len(re.findall(r"[A-Za-z]{2,}", normalized))
        return cjk_count >= 2 or word_count >= 2 or len(normalized) >= 12
    return len(normalized) >= 5 and bool(
        re.search(r"[A-Za-z]|[\u3400-\u9fff]", normalized)
    )


def _geometry_union_bbox(tokens: list[_GeometryOCRToken]) -> EvidenceBBox | None:
    if not tokens:
        return None
    coordinate_space = tokens[0].bbox.coordinate_space
    return EvidenceBBox(
        x0=min(token.bbox.x0 for token in tokens),
        y0=min(token.bbox.y0 for token in tokens),
        x1=max(token.bbox.x1 for token in tokens),
        y1=max(token.bbox.y1 for token in tokens),
        coordinate_space=coordinate_space,
    )


def _geometry_identifier_clusters(
    tokens: list[_GeometryOCRToken],
) -> list[list[_GeometryOCRToken]]:
    identifiers = [token for token in tokens if _technical_table_identifier(token.text)]
    if not identifiers:
        return []
    widths = sorted(token.bbox.x1 - token.bbox.x0 for token in identifiers)
    gap = max(48.0, (widths[len(widths) // 2] if widths else 16.0) * 3.0)
    clusters: list[list[_GeometryOCRToken]] = []
    for token in sorted(identifiers, key=lambda item: item.x):
        if not clusters or token.x - clusters[-1][-1].x > gap:
            clusters.append([token])
        else:
            clusters[-1].append(token)
    return clusters


def _complete_geometry_line_sequence(
    line_values: list[int | None],
    valid_indexes: list[int],
) -> None:
    """Fill only missing values in one fully corroborated integer sequence."""

    observed = [
        (index, value) for index, value in enumerate(line_values) if value is not None
    ]
    if len(observed) < 2:
        return
    steps = [
        (right_value - left_value) / (right_index - left_index)
        for (left_index, left_value), (right_index, right_value) in pairwise(observed)
        if right_index != left_index
    ]
    if not steps:
        return
    step = round(statistics.median(steps))
    first_index, first_value = observed[0]
    if (
        not step
        or any(candidate != step for candidate in steps)
        or any(
            value != first_value + step * (index - first_index)
            for index, value in observed
        )
    ):
        return
    for index in valid_indexes:
        if line_values[index] is not None:
            continue
        inferred = first_value + step * (index - first_index)
        if 1 <= inferred <= 999:
            line_values[index] = inferred


def _technical_geometry_bom_table(
    page: EvidencePage,
    table: EvidenceTable,
) -> EvidenceTable | None:
    """Recover logical BOM rows from native OCR geometry when HTML merged cells.

    PP-Structure can flatten a rotated engineering drawing into one HTML table.
    The native OCR boxes still retain the independent row positions.  This
    helper creates a *derived* table only when several identifier/quantity pairs
    share one x-axis cluster.  The original table remains untouched and is still
    returned as layout evidence, so the derived rows cannot hide source data.
    """

    if (table.model_extra or {}).get("derived_geometry"):
        return None
    row_count = len(table.rows)
    column_count = max((len(row) for row in table.rows), default=0)
    cell_count = max(len(table.cells), sum(len(row) for row in table.rows))
    auxiliary_roles = set().union(
        *(
            _technical_table_auxiliary_hits(value)
            for row in table.rows
            for value in row
            if _normalize(value)
        )
    )
    strong_context = any(
        _technical_table_token_matches(value, token)
        for row in table.rows
        for value in row
        if _normalize(value)
        for token in _GEOMETRY_STRONG_CONTEXT_TOKENS
    )
    if (
        row_count < 12
        or column_count < 6
        or cell_count < 100
        or len(auxiliary_roles & {"pin", "revision", "dimension", "title"}) < 2
        or not strong_context
    ):
        return None
    tokens = [
        token
        for token in _page_ocr_tokens(page)
        if _geometry_token_in_table(token, table)
    ]
    if len(tokens) < 8:
        return None
    clusters = _geometry_identifier_clusters(tokens)
    if not clusters:
        return None

    quantity_evidence = [
        token for token in tokens if _technical_table_quantity(token.text)
    ]

    def has_quantity_near(token: _GeometryOCRToken) -> bool:
        return any(
            abs(candidate.y - token.y) <= max(18.0, token.bbox.y1 - token.bbox.y0)
            and candidate.x > token.x - 28.0
            for candidate in quantity_evidence
        )

    scored_clusters = [
        cluster
        for cluster in clusters
        if sum(has_quantity_near(token) for token in cluster) >= 3
    ]
    if not scored_clusters:
        return None
    code_cluster = max(
        scored_clusters,
        key=lambda cluster: (
            sum(has_quantity_near(token) for token in cluster),
            len({round(token.y, 1) for token in cluster}),
        ),
    )
    code_tokens = sorted(
        (token for token in code_cluster if has_quantity_near(token)),
        key=lambda token: token.y,
    )
    if len(code_tokens) < 3:
        return None
    # A horizontal code run is a column-oriented table; leave it to the
    # existing deterministic/table-intent path instead of guessing its axes.
    y_span = code_tokens[-1].y - code_tokens[0].y
    x_span = max(token.x for token in code_tokens) - min(
        token.x for token in code_tokens
    )
    if y_span <= max(24.0, x_span * 1.2):
        return None
    code_x = sum(token.x for token in code_tokens) / len(code_tokens)
    quantity_tokens = [
        token
        for token in quantity_evidence
        if token.x > code_x - 32.0
        and any(abs(token.y - code.y) <= 22.0 for code in code_tokens)
    ]
    if len(quantity_tokens) < len(code_tokens) * 0.7:
        return None
    quantity_x = sorted(token.x for token in quantity_tokens)[len(quantity_tokens) // 2]
    # Keep the first description band and reject the pin/title columns that
    # typically follow it in a swallowed drawing table.
    table_x0 = table.bbox.x0 if table.bbox is not None else 0.0
    table_x1 = table.bbox.x1 if table.bbox is not None else page.width
    description_limit = table_x0 + (table_x1 - table_x0) * 0.75
    line_values: list[int | None] = []
    line_observed: list[bool] = []
    rows: list[list[str]] = []
    row_tokens: list[list[list[_GeometryOCRToken]]] = []
    y_values = [token.y for token in code_tokens]
    boundaries = [
        (
            float("-inf")
            if index == 0
            else (y_values[index - 1] + y_values[index]) / 2.0,
            float("inf")
            if index == len(code_tokens) - 1
            else (y_values[index] + y_values[index + 1]) / 2.0,
        )
        for index in range(len(code_tokens))
    ]
    for index, (code, (lower, upper)) in enumerate(
        zip(code_tokens, boundaries, strict=True)
    ):
        in_band = [token for token in tokens if lower <= token.y < upper]
        line_tokens = [
            token
            for token in in_band
            if token.x < code_x - 32.0 and _geometry_line_number(token.text) is not None
        ]
        line_source_tokens = line_tokens or [
            min(
                (
                    token
                    for token in in_band
                    if token.x < code_x - 32.0 and len(token.text) <= 3
                ),
                key=lambda token: abs(token.y - code.y),
                default=None,
            )
        ]
        line_source_tokens = [
            token for token in line_source_tokens if token is not None
        ]
        quantities = [
            token
            for token in in_band
            if _technical_table_quantity(token.text)
            and token.x >= code_x - 32.0
            and token.x <= quantity_x + max(80.0, quantity_x - code_x)
        ]
        descriptions = [
            token
            for token in in_band
            if token.x > quantity_x + 20.0
            and token.x <= description_limit
            and _geometry_description_candidate(token.text)
        ]
        # The last logical row often wraps into the next physical cell.  Keep
        # only the continuation text, never a newly detected title/header row.
        if descriptions:
            descriptions.sort(key=lambda token: (token.y, token.x))
        line_value = (
            _geometry_line_number(
                min(line_tokens, key=lambda token: abs(token.y - code.y)).text
            )
            if line_tokens
            else None
        )
        line_observed.append(line_value is not None)
        line_values.append(line_value)
        rows.append(
            [
                str(line_value) if line_value is not None else "",
                code.text,
                " ".join(dict.fromkeys(token.text for token in quantities)),
                " ".join(token.text for token in descriptions if token.text),
            ]
        )
        row_tokens.append([line_source_tokens, [code], quantities, descriptions])
    valid = [index for index, row in enumerate(rows) if row[1] and row[2]]
    if len(valid) < 3:
        return None
    # Fill missing line numbers only when every observed value proves one exact
    # integer sequence.  Never replace an OCR-observed value.
    _complete_geometry_line_sequence(line_values, valid)
    for index in valid:
        if line_values[index] is not None:
            rows[index][0] = str(line_values[index])
    table_id = f"{table.table_id}:geometry-bom"
    cells: list[EvidenceCell] = []
    all_tokens: list[_GeometryOCRToken] = []
    logical_row_positions = {
        row_index: position for position, row_index in enumerate(valid)
    }
    for row_index in valid:
        for column, value in enumerate(rows[row_index]):
            if not _normalize(value):
                continue
            selected_tokens = row_tokens[row_index][column]
            if not selected_tokens:
                selected_tokens = row_tokens[row_index][1]
            all_tokens.extend(selected_tokens)
            cells.append(
                EvidenceCell(
                    row=logical_row_positions[row_index],
                    column=column,
                    text=value,
                    bbox=_geometry_union_bbox(selected_tokens),
                    confidence=(
                        min(
                            (
                                token.score
                                for token in selected_tokens
                                if token.score is not None
                            ),
                            default=1.0,
                        )
                    ),
                    derived_geometry=True,
                    derived_from_table=table.table_id,
                    raw_ocr_indices=[token.index for token in selected_tokens],
                    inferred=(column == 0 and not line_observed[row_index]),
                )
            )
    if len(cells) < len(valid) * 3:
        return None
    return EvidenceTable(
        table_id=table_id,
        rows=[rows[index] for index in valid],
        cells=cells,
        bbox=_geometry_union_bbox(all_tokens),
        confidence=min(
            (token.score for token in all_tokens if token.score is not None),
            default=1.0,
        ),
        source="ocr-geometry-reconstruction",
        derived_geometry=True,
        derived_from_table=table.table_id,
        logical_row_count=len(valid),
    )


def _augment_geometry_tables(evidence: DocumentEvidence) -> list[str]:
    """Append evidence-only geometry tables and return their IDs."""

    derived_ids: list[str] = []
    for page in evidence.pages:
        existing = {table.table_id for table in page.tables}
        derived_ids.extend(
            table.table_id
            for table in page.tables
            if (table.model_extra or {}).get("derived_geometry")
        )
        for table in list(page.tables):
            derived = _technical_geometry_bom_table(page, table)
            if derived is None or derived.table_id in existing:
                continue
            page.tables.append(derived)
            existing.add(derived.table_id)
            derived_ids.append(derived.table_id)
    return derived_ids


def _technical_table_header_categories(table: EvidenceTable) -> set[str]:
    categories: set[str] = set()
    # Headers may be emitted as a separate first row, a merged row, or a pair
    # of adjacent rows.  Inspect only the first few rows so a long description
    # cannot masquerade as a header.
    for row in table.rows[:6]:
        row_hits: set[str] = set()
        for value in row:
            row_hits.update(_technical_table_role_hits(value))
        if len(row_hits) >= 2:
            categories.update(row_hits)
    return categories


# Keep the fallback source ASCII-only.  The repository is edited on hosts with
# mixed code pages; unicode escapes prevent Chinese labels and unit symbols
# from being silently transcoded before Python evaluates this module.
_TECHNICAL_TABLE_MEASURE_RE = re.compile(
    r"^[+-]?(?:\d+(?:[.,]\d+)?|\.\d+)(?:\s*[\u00b1+\-\u00d7x*/].*)?"
    r"\s*(?:mm|cm|m|um|\u03bcm|g|kg|pcs?|ea|\u5957|\u4e2a|\u4ef6|"
    r"\u53ea|\u6839|\u7c73|\u514b)?$",
    re.IGNORECASE,
)
_TECHNICAL_TABLE_ROLE_TOKENS = {
    "identifier": (
        "item",
        "item no",
        "part",
        "part no",
        "part number",
        "material",
        "material no",
        "material number",
        "material code",
        "product code",
        "code",
        "sku",
        "model",
        "\u6599\u53f7",
        "\u7269\u6599\u53f7",
        "\u7269\u6599\u7f16\u7801",
        "\u7269\u6599\u7f16\u53f7",
        "\u4ea7\u54c1\u7f16\u7801",
        "\u4ea7\u54c1\u7f16\u53f7",
        "\u7f16\u7801",
        "\u7f16\u53f7",
        "\u578b\u53f7",
        "\u5e8f\u53f7",
    ),
    "description": (
        "description",
        "product name",
        "product",
        "name",
        "material name",
        "specification",
        "spec",
        "remark",
        "\u63cf\u8ff0",
        "\u54c1\u540d",
        "\u540d\u79f0",
        "\u7269\u6599\u540d\u79f0",
        "\u4ea7\u54c1\u540d\u79f0",
        "\u89c4\u683c",
        "\u89c4\u683c\u63cf\u8ff0",
    ),
    "quantity": (
        "qty",
        "quantity",
        "amount",
        "usage",
        "\u7528\u91cf",
        "\u6570\u91cf",
    ),
    "unit": ("unit", "uom", "\u5355\u4f4d"),
}
_TECHNICAL_TABLE_AUXILIARY_TOKENS = {
    "pin": (
        "signal",
        "type c a",
        "type c b",
        "typeca",
        "typecb",
        "\u5f15\u811a",
        "\u9488\u811a",
        "pin",
        "vbus",
        "vconn",
        "gnd",
        "shield",
        "\u5c4f\u853d",
    ),
    "revision": (
        "revision",
        "rev",
        "version",
        "change",
        "ecn",
        "date",
        "checker",
        "\u5ba1\u6838",
        "\u6838\u51c6",
        "\u7ed8\u56fe",
        "\u7248\u672c",
        "\u53d8\u66f4",
        "\u53d8\u66f4\u5185\u5bb9",
        "\u65e5\u671f",
        "\u5ba1\u6838\u4eba",
    ),
    "title": (
        "title",
        "drawing",
        "drawing no",
        "drawing number",
        "\u56fe\u53f7",
        "\u56fe\u7eb8\u7f16\u53f7",
        "\u5ba2\u6237\u4ee3\u7801",
        "\u5ba2\u6237\u6599\u53f7",
        "\u6837\u54c1\u4ee3\u7801",
        "\u5355\u4f4d",
        "\u6bd4\u4f8b",
        "\u54c1\u540d",
    ),
    "dimension": (
        "dimension",
        "tolerance",
        "diameter",
        "length",
        "\u5c3a\u5bf8",
        "\u516c\u5dee",
        "\u5916\u5f84",
        "\u5185\u5f84",
        "\u76f4\u5f84",
    ),
}


def _technical_table_compact_text(value: object) -> str:
    return re.sub(r"[\s_\-/:\uFF1A\\]+", "", _normalize(value).casefold())


def _technical_table_token_matches(value: object, token: str) -> bool:
    compact = _technical_table_compact_text(value)
    compact_token = _technical_table_compact_text(token)
    if not compact or not compact_token:
        return False
    if compact_token.isascii() and len(compact_token) <= 6:
        words = re.findall(r"[a-z0-9]+", _normalize(value).casefold())
        return compact_token in words
    if compact_token.isascii():
        source_ascii = re.sub(r"[^a-z0-9]+", "", _normalize(value).casefold())
        return compact_token in source_ascii
    return compact_token in compact


def _technical_table_quantity(value: object) -> bool:
    text = _normalize(value)
    if not text or _TECHNICAL_TABLE_PIN_RE.fullmatch(text):
        return False
    compact = re.sub(r"\s+", "", unicodedata.normalize("NFKC", text))
    if not _TECHNICAL_TABLE_MEASURE_RE.fullmatch(compact):
        return False
    return bool(
        re.search(
            r"(?:mm|cm|m|um|\u03bcm|g|kg|pcs?|ea|\u5957|\u4e2a|\u4ef6|"
            r"\u53ea|\u6839|\u7c73|\u514b)$",
            compact,
            re.IGNORECASE,
        )
    )


_TECHNICAL_TABLE_PLAIN_NUMBER_RE = re.compile(r"^[+-]?(?:\d+(?:[.,]\d+)?|\.\d+)$")


def _technical_table_plain_number(value: object) -> bool:
    """Recognize a quantity whose unit is carried by a neighboring column.

    A bare number is not enough to classify a drawing table by itself because
    it can be a line number or a dimension.  Callers only use this predicate
    after an explicit quantity header or a unit-column relationship has been
    established.
    """

    text = _normalize(value)
    if not text or _TECHNICAL_TABLE_PIN_RE.fullmatch(text):
        return False
    return bool(_TECHNICAL_TABLE_PLAIN_NUMBER_RE.fullmatch(text.replace(" ", "")))


def _technical_table_header_roles(
    rows: list[list[str]],
) -> tuple[dict[int, set[str]], set[int]]:
    """Map semantic header roles to columns and identify header rows.

    MinerU sometimes omits a header row from ``cells`` but keeps it in
    ``rows``; conversely, a transposed drawing table can place the labels in a
    single first column.  This helper intentionally only uses role tokens in
    the first few axes and never treats arbitrary model output as a header.
    """

    roles_by_column: dict[int, set[str]] = {}
    header_rows: set[int] = set()
    for row_index, row in enumerate(rows[:8]):
        row_roles: set[str] = set()
        for column, value in enumerate(row):
            hits = _technical_table_role_hits(value)
            if not hits:
                continue
            row_roles.update(hits)
            roles_by_column.setdefault(column, set()).update(hits)
        # Two or more distinct role labels are a strong header signal.  A
        # single explicit quantity/identifier label is also useful for compact
        # two-column tables, provided it is an exact-ish role token.
        if len(row_roles) >= 2 or (
            len(row_roles) == 1
            and any(
                _technical_table_token_matches(value, token)
                for value in row
                for token in (
                    "qty",
                    "quantity",
                    "unit",
                    "item",
                    "part number",
                    "material",
                    "code",
                    "name",
                    "description",
                    "型号",
                    "物料号",
                    "数量",
                    "单位",
                )
            )
        ):
            header_rows.add(row_index)
    return roles_by_column, header_rows


def _technical_table_row_business_shape(
    rows: list[list[str]],
    row_index: int,
    *,
    roles_by_column: Mapping[int, set[str]],
    header_rows: set[int],
) -> tuple[bool, bool, bool]:
    """Return ``(identifier, description, quantity)`` for one table axis."""

    if row_index in header_rows or row_index >= len(rows):
        return False, False, False
    row = rows[row_index]
    identifier = False
    description = False
    quantity = False
    quantity_columns = {
        column for column, roles in roles_by_column.items() if "quantity" in roles
    }
    unit_columns = {
        column for column, roles in roles_by_column.items() if "unit" in roles
    }
    description_columns = {
        column for column, roles in roles_by_column.items() if "description" in roles
    }
    for column, value in enumerate(row):
        text = _normalize(value)
        if not text:
            continue
        roles = roles_by_column.get(column, set())
        if "identifier" in roles:
            # A value under an explicit identity header is authoritative even
            # when it is a pure numeric material code.  Header axes have
            # already been excluded above.
            identifier = True
        elif _technical_table_identifier(text):
            identifier = True
        if "description" in roles:
            auxiliary = _technical_table_auxiliary_hits(text)
            if not auxiliary & {"pin", "revision", "dimension", "title"}:
                description = True
        elif _technical_table_description(text):
            description = True
        if (
            _technical_table_quantity(text)
            or column in quantity_columns
            and _technical_table_plain_number(text)
            or (
                _technical_table_plain_number(text)
                and any(
                    neighbor < len(row)
                    and _technical_table_token_matches(row[neighbor], token)
                    for neighbor in (column - 1, column + 1)
                    if neighbor >= 0
                    for token in (
                        "pcs",
                        "pc",
                        "ea",
                        "set",
                        "unit",
                        "uom",
                        "个",
                        "件",
                        "只",
                        "根",
                    )
                )
            )
        ):
            quantity = True
    # A separate unit column makes a plain numeric quantity unambiguous even
    # when the unit value itself is not a recognized token (for example a
    # localized ``PCS`` rendered with whitespace).
    if not quantity and quantity_columns and unit_columns:
        for quantity_column in quantity_columns:
            if quantity_column >= len(row) or not _technical_table_plain_number(
                row[quantity_column]
            ):
                continue
            if any(
                unit_column < len(row) and _normalize(row[unit_column])
                for unit_column in unit_columns
            ):
                quantity = True
                break
    # If a table has an explicit description column, a short one-word value
    # remains meaningful (``Screw``, ``Nut``, ``USB``), unlike free-form text
    # in an unheaded drawing.
    if not description and description_columns:
        description = any(
            column < len(row)
            and _normalize(row[column])
            and not (
                _technical_table_auxiliary_hits(row[column])
                & {"pin", "revision", "dimension", "title"}
            )
            for column in description_columns
        )
    return identifier, description, quantity


def _technical_table_inferred_business_columns(
    rows: list[list[str]],
) -> tuple[int | None, int | None]:
    """Infer code and bare-quantity columns when a table has no headers."""

    width = max((len(row) for row in rows), default=0)
    code_scores: dict[int, int] = {}
    quantity_scores: dict[int, int] = {}
    for column in range(width):
        values = [
            row[column] for row in rows if column < len(row) and _normalize(row[column])
        ]
        code_scores[column] = sum(
            _technical_table_identifier(value)
            and not bool(re.fullmatch(r"\d{1,3}", _normalize(value)))
            for value in values
        )
        quantity_scores[column] = sum(
            _technical_table_plain_number(value) for value in values
        )
    code_column = max(code_scores, key=code_scores.get, default=None)
    if code_column is None or code_scores.get(code_column, 0) < 2:
        code_column = None
    quantity_candidates = [
        column
        for column, score in quantity_scores.items()
        if score >= 2 and column != code_column
    ]
    quantity_column = max(
        quantity_candidates,
        key=lambda column: quantity_scores[column],
        default=None,
    )
    return code_column, quantity_column


def _technical_table_inferred_description_column(
    rows: list[list[str]],
    *,
    excluded_columns: set[int] = frozenset(),
) -> int | None:
    """Find a repeated human-readable column in an unheaded BOM."""

    width = max((len(row) for row in rows), default=0)
    scores: dict[int, int] = {}
    for column in range(width):
        if column in excluded_columns:
            continue
        score = 0
        for row in rows:
            if column >= len(row):
                continue
            value = _normalize(row[column])
            if not value or _technical_table_plain_number(value):
                continue
            if _technical_table_auxiliary_hits(value) & {
                "pin",
                "revision",
                "dimension",
                "title",
            }:
                continue
            if _TECHNICAL_TABLE_PIN_RE.fullmatch(value):
                continue
            if re.search(r"[A-Za-z\u3400-\u9fff]", value):
                score += 1
        scores[column] = score
    candidate = max(scores, key=scores.get, default=None)
    if candidate is None or scores.get(candidate, 0) < 2:
        return None
    return candidate


def _technical_table_candidate_score(
    table: EvidenceTable,
    *,
    record_table: bool,
) -> tuple[int, set[str], dict[str, int]]:
    """Score one table using stable source-cell patterns, not model output."""

    rows = [
        [_normalize(value) for value in row]
        for row in table.rows
        if any(_normalize(value) for value in row)
    ]
    if not rows:
        return -10_000, set(), {}
    width = max((len(row) for row in rows), default=0)
    roles_by_column, header_rows = _technical_table_header_roles(rows)
    header_categories = _technical_table_header_categories(table)
    for roles in roles_by_column.values():
        header_categories.update(roles)
    column_categories: set[str] = set()
    column_profile: dict[str, int] = {
        "identifier": 0,
        "description": 0,
        "quantity": 0,
    }
    inferred_code_column, inferred_quantity_column = (
        _technical_table_inferred_business_columns(rows)
    )
    inferred_description_column = _technical_table_inferred_description_column(
        rows,
        excluded_columns={
            column
            for column in (inferred_code_column, inferred_quantity_column)
            if column is not None
        },
    )
    if inferred_code_column is not None:
        column_categories.add("identifier")
    if inferred_quantity_column is not None:
        column_categories.add("quantity")
    if inferred_description_column is not None:
        column_categories.add("description")
    row_signal_count = 0
    pin_like_rows = 0
    for row_index, row in enumerate(rows):
        value_count = sum(bool(value) for value in row)
        row_roles = set().union(*(_technical_table_role_hits(value) for value in row))
        if len(row_roles) >= 2:
            # Header role hits are evidence even when a provider omitted the
            # explicit header row from its recovered table.
            header_categories.update(row_roles)
        identifiers, descriptions, quantities = _technical_table_row_business_shape(
            rows,
            row_index,
            roles_by_column=roles_by_column,
            header_rows=header_rows,
        )
        if (
            identifiers
            and (quantities or descriptions)
            or (
                inferred_code_column is not None
                and (
                    inferred_quantity_column is not None
                    or inferred_description_column is not None
                )
                and row_index not in header_rows
                and inferred_code_column < len(row)
                and _technical_table_identifier(row[inferred_code_column])
                and (
                    (
                        inferred_quantity_column is not None
                        and inferred_quantity_column < len(row)
                        and _technical_table_plain_number(row[inferred_quantity_column])
                    )
                    or (
                        inferred_description_column is not None
                        and inferred_description_column < len(row)
                        and bool(_normalize(row[inferred_description_column]))
                    )
                )
            )
        ):
            row_signal_count += 1
        if (
            value_count >= 2
            and not quantities
            and not descriptions
            and sum(
                bool(_TECHNICAL_TABLE_PIN_RE.fullmatch(value)) for value in row if value
            )
            >= max(2, value_count - 1)
        ):
            pin_like_rows += 1
    # Derive column roles from the full source matrix.  This is what lets a
    # BOM with a missing header still beat a pin map or title block.
    for column in range(width):
        values = [row[column] for row in rows if column < len(row) and row[column]]
        if not values:
            continue
        if sum(_technical_table_identifier(value) for value in values) >= max(
            1, (len(values) + 1) // 3
        ):
            column_categories.add("identifier")
            column_profile["identifier"] += 1
        if sum(_technical_table_quantity(value) for value in values) >= max(
            1, (len(values) + 1) // 4
        ):
            column_categories.add("quantity")
            column_profile["quantity"] += 1
        if sum(_technical_table_description(value) for value in values) >= max(
            1, (len(values) + 1) // 4
        ):
            column_categories.add("description")
            column_profile["description"] += 1

    auxiliary_hits = set().union(
        *(_technical_table_auxiliary_hits(value) for row in rows for value in row)
    )
    score = 0
    score += (
        len(header_categories & {"identifier", "description", "quantity", "unit"}) * 12
    )
    score += len(column_categories & {"identifier", "description", "quantity"}) * 16
    score += min(row_signal_count, 24) * 4
    score += min(len(rows), 12)
    if width >= 3:
        score += 5
    if "identifier" in column_categories and (
        "quantity" in column_categories or "description" in column_categories
    ):
        score += 18
    if "identifier" in header_categories and (
        "quantity" in header_categories or "description" in header_categories
    ):
        score += 24
    score -= pin_like_rows * 8
    if "pin" in auxiliary_hits:
        score -= 20
    if "revision" in auxiliary_hits:
        score -= 22
    if "dimension" in auxiliary_hits:
        score -= 12
    if width <= 2 and "quantity" not in column_categories:
        score -= 12
    if not record_table:
        score -= 8
    return score, header_categories | column_categories, column_profile


def _technical_specification_table_shape(table: EvidenceTable) -> bool:
    """Recognize a property matrix without confusing a drawing title block."""

    rows = [[_normalize(value) for value in row] for row in table.rows]
    for header_index, header in enumerate(rows[:-1]):
        identity_columns = {
            column
            for column, value in enumerate(header)
            if any(
                _technical_table_token_matches(value, token)
                for token in ("product name", "产品名称", "品名")
            )
        }
        property_columns = {
            column
            for column, value in enumerate(header)
            if "dimension" in _technical_table_auxiliary_hits(value)
        }
        if not identity_columns or len(property_columns) < 2:
            continue
        for values in rows[header_index + 1 :]:
            if not any(
                column < len(values) and _technical_table_description(values[column])
                for column in identity_columns
            ):
                continue
            measured_properties = sum(
                column < len(values)
                and bool(_TECHNICAL_TABLE_MEASURE_RE.fullmatch(values[column]))
                for column in property_columns
            )
            if measured_properties >= 2:
                return True
    return False


_TECHNICAL_WIRING_SIGNAL_RE = re.compile(
    r"^(?:[AB]\d{1,2}|GND|VCC|CEC|SCL|SDA|HPD|UTY|CC|D[+-]|VBUS|VCONN|"
    r"SSTX[+-]?\s*\d*|SSRX[+-]?\s*\d*)$",
    re.IGNORECASE,
)


def _technical_wiring_matrix(table: EvidenceTable) -> bool:
    """Identify pin/signal matrices without matching incidental BOM prose."""

    values = [
        _normalize(value) for row in table.rows for value in row if _normalize(value)
    ]
    has_header = any(
        _technical_table_compact_text(value) in {"pin", "signal", "typeca", "typecb"}
        or "焊盘丝印" in value
        or "焊线规格" in value
        for value in values
    )
    if not has_header:
        return False
    return (
        sum(bool(_TECHNICAL_WIRING_SIGNAL_RE.fullmatch(value)) for value in values) >= 3
    )


def _technical_primary_table_candidates(
    tables: dict[str, EvidenceTable],
    *,
    assessment: RecordRegionAssessment,
    record_table_ids: set[str],
) -> list[str]:
    """Return high-confidence BOM-like tables in source order.

    The threshold intentionally requires both an identity column and either a
    quantity or description column.  A table that only contains pin labels,
    revision metadata, or dimensions therefore cannot become a primary table.
    Multiple equally strong tables are retained for legitimate multi-page BOMs.
    """

    derived_geometry_ids = [
        table_id
        for table_id, table in tables.items()
        if (table.model_extra or {}).get("derived_geometry")
    ]
    if derived_geometry_ids:
        # Native OCR geometry is a stronger row-boundary signal than a model's
        # table-role guess.  Keep all derived pages in source order.
        return derived_geometry_ids
    scored: list[tuple[str, int, set[str], dict[str, int]]] = []
    for table_id, table in tables.items():
        if (table.model_extra or {}).get("asset_sha256"):
            continue
        if _technical_wiring_matrix(table):
            continue
        score, roles, profile = _technical_table_candidate_score(
            table,
            record_table=table_id in record_table_ids,
        )
        if score <= -9_000:
            continue
        scored.append((table_id, score, roles, profile))
    if not scored:
        return []
    specification_table_ids = {
        table_id
        for table_id, table in tables.items()
        if _technical_specification_table_shape(table)
    }
    qualified = [
        item
        for item in scored
        if item[0] in specification_table_ids
        or {"identifier", "description"} <= item[2]
        or {"identifier", "quantity"} <= item[2]
    ]
    # A two-column code/value table is usually a title-block key/value map in
    # an engineering drawing (for example ``TYPE C 外模 | CY...``).  Without a
    # quantity signal it is not safe to promote it to BOM rows.  Wider tables
    # and explicit quantity headers remain eligible for two-column documents.
    qualified = [
        item
        for item in qualified
        if not (
            {"identifier", "description"} <= item[2]
            and "quantity" not in item[2]
            and max((len(row) for row in tables[item[0]].rows), default=0) <= 2
            and len(tables[item[0]].rows) < 4
        )
    ]
    qualified = [
        item
        for item in qualified
        if not (
            "quantity" not in item[2]
            and (
                set().union(
                    *(
                        _technical_table_auxiliary_hits(value)
                        for row in tables[item[0]].rows[:4]
                        for value in row
                    )
                )
                & {"revision", "dimension", "title"}
            )
        )
    ]
    # A dimension/tolerance block can look like a BOM when its numeric values
    # carry ``mm`` or another unit.  Keep it only when a real quantity/unit
    # header or multiple identifier-plus-description rows corroborate the
    # business interpretation.
    auxiliary_filtered: list[tuple[str, int, set[str], dict[str, int]]] = []
    for item in qualified:
        table = tables[item[0]]
        auxiliary = set().union(
            *(
                _technical_table_auxiliary_hits(value)
                for row in table.rows
                for value in row
                if _normalize(value)
            )
        )
        if "pin" in auxiliary and not {"identifier", "quantity"} <= item[2]:
            continue
        if (
            auxiliary & {"dimension", "revision", "title"}
            and item[0] not in specification_table_ids
        ):
            headers = _technical_table_header_categories(table)
            meaningful_rows = len(_technical_primary_record_rows(table))
            if not ({"quantity", "unit"} & headers) and meaningful_rows < 2:
                continue
        auxiliary_filtered.append(item)
    qualified = auxiliary_filtered
    if not qualified:
        return []
    best_score = max(item[1] for item in qualified)
    # Keep close-scoring candidates only when they have the same business
    # shape.  This preserves split/continued BOM tables but excludes a weaker
    # pin or revision table that happens to be long.
    # Keep close-scoring candidates in source order.  Separate pages may have
    # slightly different extracted columns, so requiring identical role sets
    # would drop a legitimate continuation table.  A short continuation with a
    # verified quantity column is allowed a wider margin; auxiliary tables do
    # not satisfy the identifier+quantity gate.
    continuation_margin = max(12, int(best_score * 0.50))
    selected: list[str] = []
    for item in qualified:
        has_quantity_shape = {"identifier", "quantity"} <= item[2]
        margin = continuation_margin if has_quantity_shape else 12
        if item[1] >= best_score - margin:
            selected.append(item[0])
    return selected


def _technical_primary_record_rows(table: EvidenceTable) -> set[int]:
    """Find BOM data rows while excluding title-block rows in a swallowed table.

    MinerU can return a drawing's BOM and title block as one rectangular table.
    A repeated line number is a useful boundary signal: an identical repeated
    row is retained (the duplicate merger handles it later), while a different
    row with the same line number marks the beginning of the title block.
    """

    rows = [[_normalize(value) for value in row] for row in table.rows]
    if not rows:
        return set()
    roles_by_column, header_rows = _technical_table_header_roles(rows)
    inferred_code_column, inferred_quantity_column = (
        _technical_table_inferred_business_columns(rows)
    )
    inferred_description_column = _technical_table_inferred_description_column(
        rows,
        excluded_columns={
            column
            for column in (inferred_code_column, inferred_quantity_column)
            if column is not None
        },
    )
    width = max((len(row) for row in rows), default=0)
    identifier_columns: list[int] = []
    quantity_columns: list[int] = []
    description_columns: list[int] = []
    for column in range(width):
        values = [row[column] for row in rows if column < len(row) and row[column]]
        if not values:
            continue
        threshold = max(1, (len(values) + 1) // 3)
        if sum(_technical_table_identifier(value) for value in values) >= threshold:
            identifier_columns.append(column)
        if sum(_technical_table_quantity(value) for value in values) >= threshold:
            quantity_columns.append(column)
        if sum(_technical_table_description(value) for value in values) >= threshold:
            description_columns.append(column)
    candidates: set[int] = set()

    def row_candidate(row_index: int, row: list[str]) -> bool:
        """Score one row when provider spans hide the logical columns."""

        identifier, description, quantity = _technical_table_row_business_shape(
            rows,
            row_index,
            roles_by_column=roles_by_column,
            header_rows=header_rows,
        )
        identifier_count = int(identifier)
        quantity_count = int(quantity)
        description_count = int(description)
        has_line_number = any(re.fullmatch(r"\d{1,3}", value) for value in row if value)
        auxiliary = set().union(
            *(_technical_table_auxiliary_hits(value) for value in row if value)
        )
        # Version/pin/dimension/title rows often contain an identifier-like
        # token, but without a quantity they are not BOM records.
        if auxiliary & {"pin", "revision", "dimension", "title"} and not quantity_count:
            return False
        return bool(
            (identifier_count and (quantity_count or description_count))
            or (quantity_count and has_line_number)
        )

    for row_index, row in enumerate(rows):
        if row_index in header_rows:
            continue
        if row_candidate(row_index, row):
            candidates.add(row_index)
            continue
        # Prefer the stricter column-level test when a provider did preserve a
        # regular matrix; the row-level branch above is for merged/irregular
        # tables and does not broaden an otherwise valid exclusion.
        has_identifier = any(
            column < len(row) and _technical_table_identifier(row[column])
            for column in identifier_columns
        )
        has_quantity = any(
            column < len(row) and _technical_table_quantity(row[column])
            for column in quantity_columns
        )
        has_description = any(
            column < len(row) and _technical_table_description(row[column])
            for column in description_columns
        )
        if has_identifier and (has_quantity or has_description):
            candidates.add(row_index)
            continue
        if (
            inferred_code_column is not None
            and (
                inferred_quantity_column is not None
                or inferred_description_column is not None
            )
            and inferred_code_column < len(row)
            and _technical_table_identifier(row[inferred_code_column])
            and (
                (
                    inferred_quantity_column is not None
                    and inferred_quantity_column < len(row)
                    and _technical_table_plain_number(row[inferred_quantity_column])
                )
                or (
                    inferred_description_column is not None
                    and inferred_description_column < len(row)
                    and bool(_normalize(row[inferred_description_column]))
                )
            )
        ):
            candidates.add(row_index)
    if len(candidates) < 2:
        return candidates

    def has_structural_auxiliary_marker(row: list[str]) -> bool:
        """Detect a title/revision axis without rejecting BOM descriptions."""

        boundary_roles = {"revision", "title", "dimension"}
        boundary_tokens = tuple(
            token
            for role in boundary_roles
            for token in _TECHNICAL_TABLE_AUXILIARY_TOKENS[role]
        )
        for value in row:
            text = _normalize(value)
            if not text:
                continue
            markers = _technical_table_auxiliary_hits(text)
            if not markers & boundary_roles:
                continue
            compact = _technical_table_compact_text(text)
            for token in boundary_tokens:
                compact_token = _technical_table_compact_text(token)
                if compact == compact_token:
                    return True
                if compact_token in {"drawing", "length", "date", "title"}:
                    if compact_token == "drawing" and compact.startswith(
                        ("drawingno", "drawingnumber")
                    ):
                        return True
                    continue
                if compact.startswith(compact_token):
                    return True
            if re.search(r"[:/\\\uFF1A]", text) and len(text) <= 40:
                return True
        return False

    # Locate a conventional line-number axis.  It is deliberately independent
    # of the model's field mapping, so a malformed mapping cannot move the
    # boundary into the title block.
    line_column: int | None = None
    line_score = 0
    for column in range(width):
        values = [
            row[column]
            for row_index, row in enumerate(rows)
            if row_index in candidates and column < len(row) and row[column]
        ]
        numeric = [value for value in values if re.fullmatch(r"\d{1,3}", value)]
        score = len(numeric)
        if score >= max(3, (len(candidates) + 1) // 3) and score > line_score:
            line_column = column
            line_score = score
    if line_column is None:
        ordered_candidates = sorted(candidates)
        for position, row_index in enumerate(ordered_candidates):
            if position >= 2 and has_structural_auxiliary_marker(rows[row_index]):
                return set(ordered_candidates[:position])
        return candidates

    ordered = sorted(candidates)

    def ignorable_gap(start: int, end: int) -> bool:
        """Allow blank/repeated header axes in a continued BOM."""

        for gap_index in range(start, end):
            gap = rows[gap_index]
            if not any(gap):
                continue
            if gap_index in header_rows:
                continue
            gap_roles = set().union(
                *(_technical_table_role_hits(value) for value in gap if value)
            )
            if (
                len(gap_roles) >= 2
                and not _technical_table_row_business_shape(
                    rows,
                    gap_index,
                    roles_by_column=roles_by_column,
                    header_rows=header_rows,
                )[0]
            ):
                continue
            if set().union(
                *(_technical_table_auxiliary_hits(value) for value in gap if value)
            ) & {"pin", "revision", "dimension", "title"}:
                return False
            return False
        return True

    start_position = 0
    while start_position < len(ordered):
        row_index = ordered[start_position]
        if line_column < len(rows[row_index]) and re.fullmatch(
            r"\d{1,3}", rows[row_index][line_column]
        ):
            break
        start_position += 1
    if start_position >= len(ordered):
        return candidates
    kept: list[int] = [ordered[start_position]]
    previous_number = int(rows[kept[0]][line_column])
    direction: int | None = None
    for row_index in ordered[start_position + 1 :]:
        if row_index != kept[-1] + 1 and not ignorable_gap(
            kept[-1] + 1,
            row_index,
        ):
            break
        value = (
            rows[row_index][line_column] if line_column < len(rows[row_index]) else ""
        )
        if not re.fullmatch(r"\d{1,3}", value):
            break
        number = int(value)
        if number == previous_number:
            previous_row = rows[kept[-1]]
            if rows[row_index] == previous_row:
                kept.append(row_index)
                continue
            # A non-identical repeated line number is normally title-block
            # metadata (the drawing sample has several rows labelled ``1``).
            # If the row has no title/revision marker, retain it as a possible
            # section reset rather than silently dropping a legitimate BOM.
            if has_structural_auxiliary_marker(rows[row_index]):
                break
            kept.append(row_index)
            direction = None
            previous_number = number
            continue
        step = number - previous_number
        if direction is None:
            direction = 1 if step > 0 else -1
        if (direction > 0 and step <= 0) or (direction < 0 and step >= 0):
            if has_structural_auxiliary_marker(rows[row_index]):
                break
            direction = 1 if step > 0 else -1
        kept.append(row_index)
        previous_number = number
    return set(kept)


def _technical_primary_record_axes(
    table: EvidenceTable,
    orientation: RecordOrientation,
) -> set[int]:
    """Apply the technical row detector in either table orientation."""

    if orientation == "rows":
        return _technical_primary_record_rows(table)
    width = max((len(row) for row in table.rows), default=0)
    transposed = EvidenceTable(
        table_id=table.table_id,
        rows=[
            [_normalize(row[column]) if column < len(row) else "" for row in table.rows]
            for column in range(width)
        ],
    )
    return _technical_primary_record_rows(transposed)


def _technical_preferred_orientation(
    table: EvidenceTable,
) -> tuple[RecordOrientation, set[int]]:
    """Choose the evidence-backed axis when the model did not provide one."""

    row_axes = _technical_primary_record_axes(table, "rows")
    column_axes = _technical_primary_record_axes(table, "columns")
    if len(column_axes) > len(row_axes):
        return "columns", column_axes
    return "rows", row_axes


def _refine_technical_primary_table_segments(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    primary_table_ids: list[str],
    issues: list[str],
    *,
    assessment: RecordRegionAssessment | None = None,
) -> DocumentIntent:
    """Keep record axes only in evidence-backed technical business tables."""

    if _document_intent_family(intent.document_intent) != "technical_document":
        return intent
    planned = {table.table_id: table for table in intent.tables}
    changed = False
    refined_primary = False
    primary_set = set(primary_table_ids)
    for table_id, current in list(planned.items()):
        if table_id in primary_set or not any(
            segment.intent == "records" for segment in current.segments
        ):
            continue
        planned[table_id] = current.model_copy(
            update={
                "segments": [
                    segment.model_copy(update={"intent": "layout"}, deep=True)
                    if segment.intent == "records"
                    else segment
                    for segment in current.segments
                ]
            },
            deep=True,
        )
        changed = True
    demoted_nonprimary = changed
    deterministic_regions: dict[str, list[EvidenceRecordRegion]] = {}
    if assessment is not None:
        for region in assessment.record_regions:
            deterministic_regions.setdefault(region.table_id, []).append(region)
    for table_id in primary_table_ids:
        table = tables.get(table_id)
        current = planned.get(table_id)
        if table is None or current is None:
            continue
        table_regions = deterministic_regions.get(table_id, [])
        deterministic_orientations = {region.orientation for region in table_regions}
        if len(deterministic_orientations) == 1:
            deterministic_orientation = next(iter(deterministic_orientations))
            if current.orientation == deterministic_orientation and any(
                segment.intent == "records" for segment in current.segments
            ):
                # Normalization already reconciled model intent with the
                # complete evidence geometry. Drawing-specific shape scoring
                # must not transpose or narrow that stronger partition.
                continue
            record_rows = {
                axis
                for region in table_regions
                for axis in range(region.data_start, region.data_end + 1)
            }
            orientation = deterministic_orientation
        else:
            orientation, record_rows = _technical_preferred_orientation(table)
        if not record_rows:
            orientation = current.orientation
            record_rows = _technical_primary_record_axes(table, orientation)
        if not record_rows:
            continue
        size = _table_axis_size(table, orientation)
        if record_rows == set(range(size)) and orientation == current.orientation:
            continue
        axis_intents: list[SegmentIntent] = [
            "records" if index in record_rows else "layout" for index in range(size)
        ]
        planned[table_id] = TableIntent(
            table_id=table_id,
            orientation=orientation,
            segments=_segments_from_axis_intents(axis_intents),
        )
        changed = True
        refined_primary = True
    if not changed:
        return intent
    if demoted_nonprimary:
        issues.append("technical_nonprimary_record_segments_demoted")
    if refined_primary:
        issues.append("primary_record_rows_refined:evidence_shape")
    return intent.model_copy(update={"tables": list(planned.values())}, deep=True)


def _safe_technical_partition_fallback(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    assessment: RecordRegionAssessment,
    issues: list[str],
    *,
    emit_issue: bool = True,
) -> DocumentIntent | None:
    """Build a complete, reviewable partition when the intent model is down.

    ``RecordRegionAssessment`` is intentionally conservative and may be
    ``inconclusive`` for a drawing whose giant table mixes BOM and title-block
    cells.  Returning no segments in that case loses source rows.  This
    fallback uses the same evidence scorer as primary-table selection, marks
    every non-primary table as layout, and only exposes rows that satisfy the
    BOM column/sequence checks.  It never promotes an unclassified auxiliary
    table to records and remains subject to the normal authority/review gate.
    """

    if _document_intent_family(intent.document_intent) != "technical_document":
        return None
    record_table_ids = {region.table_id for region in assessment.record_regions}
    primary_ids = _technical_primary_table_candidates(
        tables,
        assessment=assessment,
        record_table_ids=record_table_ids,
    )
    if not primary_ids:
        return None
    regions_by_table: dict[str, list[EvidenceRecordRegion]] = {}
    for region in assessment.record_regions:
        regions_by_table.setdefault(region.table_id, []).append(region)
    planned: list[TableIntent] = []
    primary_set = set(primary_ids)
    for table_id, table in tables.items():
        if not table.rows:
            planned.append(
                TableIntent(table_id=table_id, orientation="rows", segments=[])
            )
            continue
        table_regions = regions_by_table.get(table_id, [])
        region_orientations = {region.orientation for region in table_regions}
        if len(region_orientations) == 1:
            orientation = next(iter(region_orientations))
            axis_indexes = (
                _technical_primary_record_axes(table, orientation)
                if table_id in primary_set
                else set()
            )
        elif table_id in primary_set:
            orientation, axis_indexes = _technical_preferred_orientation(table)
        else:
            orientation, axis_indexes = "rows", set()
        if table_id in primary_set and not axis_indexes:
            axis_indexes = {
                index
                for region in table_regions
                if region.orientation == orientation
                for index in range(region.data_start, region.data_end + 1)
            }
        axis_size = _table_axis_size(table, orientation)
        if table_id not in primary_set or not axis_indexes:
            axis_intents: list[SegmentIntent] = ["layout" for _ in range(axis_size)]
        else:
            axis_intents = [
                "records" if index in axis_indexes else "layout"
                for index in range(axis_size)
            ]
        planned.append(
            TableIntent(
                table_id=table_id,
                orientation=orientation,
                segments=_segments_from_axis_intents(axis_intents),
            )
        )
    if emit_issue:
        issues.append("technical_partition_fallback:evidence_shape")
    document_intent = intent.document_intent
    if not document_intent or document_intent == "unknown":
        document_intent = "technical_document"
    return intent.model_copy(
        update={
            "document_intent": document_intent,
            "primary_record_table_ids": primary_ids,
            "tables": planned,
        },
        deep=True,
    )


def _apply_geometry_table_partition(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    derived_table_ids: list[str],
    issues: list[str],
) -> DocumentIntent:
    """Make high-confidence OCR geometry rows the sole technical record set."""

    if not derived_table_ids:
        return intent
    family = _document_intent_family(intent.document_intent)
    derived_set = set(derived_table_ids)
    if family not in {"technical_document", "unknown"}:
        planned = {table.table_id: table for table in intent.tables}
        for table_id in derived_table_ids:
            table = tables.get(table_id)
            if table is None:
                continue
            size = _table_axis_size(table, "rows")
            planned[table_id] = TableIntent(
                table_id=table_id,
                orientation="rows",
                segments=(
                    [
                        TableSegmentIntent(
                            start=0,
                            end=size - 1,
                            intent="layout",
                        )
                    ]
                    if size
                    else []
                ),
            )
        filtered_primary = [
            table_id
            for table_id in intent.primary_record_table_ids
            if table_id not in derived_set
        ]
        return intent.model_copy(
            update={
                "primary_record_table_ids": filtered_primary,
                # Derived evidence remains in the validation universe.  Mark it
                # as layout instead of dropping its table intent, otherwise a
                # false-positive geometry reconstruction empties normal order
                # and inventory results at the full-partition gate.
                "tables": list(planned.values()),
            },
            deep=True,
        )
    source_ids = {
        str((tables[table_id].model_extra or {}).get("derived_from_table"))
        for table_id in derived_table_ids
        if table_id in tables
        and (tables[table_id].model_extra or {}).get("derived_from_table")
    }
    planned = {table.table_id: table for table in intent.tables}
    changed = False
    for table_id, table in tables.items():
        if table_id in derived_set:
            planned[table_id] = TableIntent(
                table_id=table_id,
                orientation="rows",
                segments=(
                    [
                        TableSegmentIntent(
                            start=0,
                            end=len(table.rows) - 1,
                            intent="records",
                        )
                    ]
                    if table.rows
                    else []
                ),
            )
            changed = True
        elif table_id in source_ids and table_id in planned:
            current = planned[table_id]
            if any(segment.intent == "records" for segment in current.segments):
                planned[table_id] = TableIntent(
                    table_id=table_id,
                    orientation=current.orientation,
                    segments=[
                        segment.model_copy(update={"intent": "layout"}, deep=True)
                        for segment in current.segments
                    ],
                )
                changed = True
    if not changed:
        return intent
    if family == "unknown":
        issues.append("technical_geometry_document_intent_inferred")
    issues.append(
        "technical_geometry_primary_tables_applied:" + ",".join(derived_table_ids)
    )
    return intent.model_copy(
        update={
            "document_intent": (
                "technical_document" if family == "unknown" else intent.document_intent
            ),
            "primary_record_table_ids": list(derived_table_ids),
            "tables": list(planned.values()),
        },
        deep=True,
    )


def _select_primary_record_table_ids(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    assessment: RecordRegionAssessment,
    issues: list[str],
) -> list[str]:
    """Choose compact business rows without discarding auxiliary table evidence.

    A failed intent call used to fall back to every deterministic record table.
    That is unsafe for engineering drawings: a single page commonly contains a
    BOM beside pin maps, a revision history, dimensions, and a title block.  In
    that situation the original table evidence is a better source of truth than
    the sampled model payload.  We therefore score tables by *column roles* and
    *row shape* and use the score only when the model did not provide a
    meaningful, non-exhaustive selection.  Explicit model selections remain
    authoritative; all auxiliary evidence is still retained in the result.
    """

    intent_family = _document_intent_family(intent.document_intent)
    record_counts: dict[str, int] = {}
    for region in assessment.record_regions:
        table = tables.get(region.table_id)
        if table is None or (table.model_extra or {}).get("asset_sha256"):
            continue
        if (table.model_extra or {}).get("derived_geometry") and intent_family not in {
            "technical_document",
            "unknown",
        }:
            continue
        record_counts[region.table_id] = record_counts.get(region.table_id, 0) + (
            region.data_end - region.data_start + 1
        )
    ordered_record_ids = [table_id for table_id in tables if table_id in record_counts]
    selected: list[str] = []
    seen: set[str] = set()
    for table_id in intent.primary_record_table_ids:
        if table_id in seen:
            continue
        seen.add(table_id)
        if table_id not in record_counts:
            issues.append(f"ignored_primary_record_table:{table_id}")
            continue
        selected.append(table_id)
    native_record_ids: list[str] = []
    parallel_groups: dict[str, list[str]] = {}
    for table_id in ordered_record_ids:
        table = tables[table_id]
        layout = (table.model_extra or {}).get("native_record_layout")
        if not isinstance(layout, dict):
            continue
        group = str(layout.get("parallel_group") or "").strip()
        native_type = _document_intent_family(
            str(layout.get("document_type") or "unknown")
        )
        if (
            layout.get("source") == "spreadsheet-tabular-v1"
            and native_type == intent_family
            and _trusted_native_record_intent(table_id, table) is not None
        ):
            native_record_ids.append(table_id)
            if group:
                parallel_groups.setdefault(group, []).append(table_id)
    promoted = set(selected) | set(native_record_ids)
    for group_ids in parallel_groups.values():
        if len(group_ids) >= 2:
            promoted.update(group_ids)
    if promoted != set(selected):
        selected = [table_id for table_id in ordered_record_ids if table_id in promoted]
        issues.append("native_parallel_record_tables_applied")
    if (
        selected
        and set(selected) == set(ordered_record_ids)
        and all(
            _trusted_native_record_intent(table_id, tables[table_id]) is not None
            for table_id in selected
        )
    ):
        return selected
    # For technical documents, even a single deterministic region may be a
    # pin/title table.  Run the evidence scorer whenever the model did not
    # provide an explicit selection; non-technical documents retain the fast
    # path.
    if len(ordered_record_ids) <= 1 and intent_family != "technical_document":
        return selected or ordered_record_ids

    if intent_family in {"technical_document", "unknown"} and (
        not selected or set(selected) == set(ordered_record_ids)
    ):
        evidence_candidates = _technical_primary_table_candidates(
            tables,
            assessment=assessment,
            record_table_ids=set(ordered_record_ids),
        )
        if evidence_candidates:
            issues.append(
                "primary_record_table_fallback:business_evidence:"
                + ",".join(evidence_candidates)
            )
            return evidence_candidates

        if intent_family == "technical_document":
            if any(
                _normalize(value)
                for table in tables.values()
                for row in table.rows
                for value in row
            ):
                issues.append("primary_record_table_fallback:no_business_evidence")
            return []

    if selected:
        return selected

    if intent.document_intent in {
        "technical_document",
        "engineering_drawing",
        "product_specification",
        "process_specification",
    }:
        if any(
            _normalize(value)
            for table in tables.values()
            for row in table.rows
            for value in row
        ):
            issues.append("primary_record_table_fallback:no_business_evidence")
        return []

    issues.append("primary_record_table_fallback:all_record_tables")
    return ordered_record_ids


def _route_table_roles_by_id(
    tables: dict[str, EvidenceTable],
    route_context: _GuardedDocumentRouteContext,
    issues: list[str],
) -> dict[str, str]:
    ordered_table_ids = list(tables)
    result: dict[str, str] = {}
    invalid_indexes = 0
    for table_index, role in route_context.table_roles:
        if table_index >= len(ordered_table_ids):
            invalid_indexes += 1
            continue
        result[ordered_table_ids[table_index]] = role
    if invalid_indexes:
        issues.append(
            f"ignored_document_route_context:table_index_out_of_range:{invalid_indexes}"
        )
    return result


def _migrate_route_roles_to_geometry_tables(
    tables: Mapping[str, EvidenceTable],
    table_roles: Mapping[str, str],
    derived_table_ids: list[str],
    *,
    document_intent: str,
    issues: list[str],
) -> dict[str, str]:
    """Move source primary roles to the derived table that replaces its rows."""

    if not table_roles or not derived_table_ids:
        return dict(table_roles)
    allow_derived_primary = _document_intent_family(document_intent) in {
        "technical_document",
        "unknown",
    }
    source_roles = dict(table_roles)
    migrated = dict(source_roles)
    migrations: list[str] = []
    for derived_id in derived_table_ids:
        table = tables.get(derived_id)
        if table is None or not (table.model_extra or {}).get("derived_geometry"):
            continue
        source_id = str(
            (table.model_extra or {}).get("derived_from_table") or ""
        ).strip()
        if not source_id or source_id not in source_roles:
            continue
        role = source_roles[source_id]
        if role in _ROUTE_PRIMARY_TABLE_ROLES:
            if not allow_derived_primary:
                continue
            migrated.pop(source_id, None)
        migrated[derived_id] = role
        migrations.append(f"{source_id}->{derived_id}:{role}")
    if migrations:
        issues.append("document_route_geometry_roles_migrated:" + ",".join(migrations))
    return migrated


def _apply_route_table_partitions(
    intent: DocumentIntent,
    tables: dict[str, EvidenceTable],
    table_roles: Mapping[str, str],
) -> DocumentIntent:
    """Constrain metadata/layout tables without manufacturing record regions."""

    if not table_roles:
        return intent
    planned = {table.table_id: table for table in intent.tables}
    routed_tables: list[TableIntent] = []
    for table_id, table in tables.items():
        current = planned.get(table_id)
        role = table_roles.get(table_id)
        if role not in _ROUTE_METADATA_TABLE_ROLES | {"layout", "ignore"}:
            if current is not None:
                routed_tables.append(current)
            continue
        orientation: RecordOrientation = (
            current.orientation if current is not None else "rows"
        )
        size = _table_axis_size(table, orientation)
        segment_intent: SegmentIntent = (
            "metadata" if role in _ROUTE_METADATA_TABLE_ROLES else "layout"
        )
        routed_tables.append(
            TableIntent(
                table_id=table_id,
                orientation=orientation,
                segments=(
                    [
                        TableSegmentIntent(
                            start=0,
                            end=size - 1,
                            intent=segment_intent,
                        )
                    ]
                    if size
                    else []
                ),
            )
        )
    routed_ids = {table.table_id for table in routed_tables}
    routed_tables.extend(
        table
        for table in intent.tables
        if table.table_id not in routed_ids and table.table_id not in tables
    )
    return intent.model_copy(update={"tables": routed_tables}, deep=True)


def _apply_route_primary_table_policy(
    selected: list[str],
    tables: dict[str, EvidenceTable],
    assessment: RecordRegionAssessment,
    table_roles: Mapping[str, str],
    issues: list[str],
    *,
    document_intent: str,
) -> list[str]:
    """Use typed roles as a filter over deterministic record-region candidates."""

    allow_derived_primary = _document_intent_family(document_intent) in {
        "technical_document",
        "unknown",
    }
    if not table_roles:
        return [
            table_id
            for table_id in selected
            if table_id in tables
            and (
                allow_derived_primary
                or not (tables[table_id].model_extra or {}).get("derived_geometry")
            )
        ]
    record_table_ids = {region.table_id for region in assessment.record_regions}
    routed_primary = [
        table_id
        for table_id in tables
        if table_roles.get(table_id) in _ROUTE_PRIMARY_TABLE_ROLES
        and table_id in record_table_ids
        and (
            allow_derived_primary
            or not (tables[table_id].model_extra or {}).get("derived_geometry")
        )
    ]
    missing_regions = sum(
        role in _ROUTE_PRIMARY_TABLE_ROLES and table_id not in record_table_ids
        for table_id, role in table_roles.items()
    )
    if missing_regions:
        issues.append(
            "ignored_document_route_context:primary_role_without_record_region:"
            f"{missing_regions}"
        )
    if routed_primary:
        if selected != routed_primary:
            issues.append("document_route_primary_tables_applied")
        return routed_primary
    filtered = [
        table_id
        for table_id in selected
        if table_roles.get(table_id) not in _ROUTE_NONPRIMARY_TABLE_ROLES
        and (
            allow_derived_primary
            or not (tables[table_id].model_extra or {}).get("derived_geometry")
        )
    ]
    if filtered != selected:
        issues.append("document_route_nonprimary_tables_filtered")
    return filtered


def _align_geometry_primary_partition(
    intent: DocumentIntent,
    tables: Mapping[str, EvidenceTable],
    derived_table_ids: list[str],
    primary_table_ids: list[str],
    issues: list[str],
) -> DocumentIntent:
    """Keep exactly one authoritative record partition for geometry tables."""

    if not derived_table_ids:
        return intent.model_copy(
            update={"primary_record_table_ids": list(primary_table_ids)},
            deep=True,
        )
    derived_set = set(derived_table_ids)
    primary_set = set(primary_table_ids)
    selected_sources = {
        str((tables[table_id].model_extra or {}).get("derived_from_table"))
        for table_id in derived_set & primary_set
        if table_id in tables
        and (tables[table_id].model_extra or {}).get("derived_from_table")
    }
    planned: list[TableIntent] = []
    changed = intent.primary_record_table_ids != list(primary_table_ids)
    for current in intent.tables:
        table = tables.get(current.table_id)
        if table is None:
            planned.append(current)
            continue
        if current.table_id in derived_set:
            if current.table_id in primary_set:
                size = _table_axis_size(table, "rows")
                replacement = TableIntent(
                    table_id=current.table_id,
                    orientation="rows",
                    segments=(
                        [
                            TableSegmentIntent(
                                start=0,
                                end=size - 1,
                                intent="records",
                            )
                        ]
                        if size
                        else []
                    ),
                )
            else:
                replacement = current.model_copy(
                    update={
                        "segments": [
                            segment.model_copy(
                                update={"intent": "layout"},
                                deep=True,
                            )
                            if segment.intent == "records"
                            else segment
                            for segment in current.segments
                        ]
                    },
                    deep=True,
                )
            changed = changed or replacement != current
            planned.append(replacement)
            continue
        if current.table_id in selected_sources:
            replacement = current.model_copy(
                update={
                    "segments": [
                        segment.model_copy(update={"intent": "layout"}, deep=True)
                        if segment.intent == "records"
                        else segment
                        for segment in current.segments
                    ]
                },
                deep=True,
            )
            changed = changed or replacement != current
            planned.append(replacement)
            continue
        planned.append(current)
    if changed:
        issues.append("technical_geometry_record_segments_aligned")
    return intent.model_copy(
        update={
            "primary_record_table_ids": list(primary_table_ids),
            "tables": planned,
        },
        deep=True,
    )


def _segment_evidence_ids(
    inventory: dict[str, _EvidenceItem],
    segment: _ValidatedSegment,
) -> set[str]:
    ids: set[str] = set()
    for item in inventory.values():
        if item.table_id != segment.table_id:
            continue
        axis = item.row if segment.orientation == "rows" else item.column
        if axis is not None and segment.start <= axis <= segment.end:
            ids.add(item.evidence_id)
    return ids


def _record_schema_evidence_ids(
    inventory: dict[str, _EvidenceItem],
    segment: _ValidatedSegment,
) -> set[str]:
    """Return only the adjacent field-label axis used by record mapping.

    These cells explain record field names but are not business values. Keeping
    them separate prevents table headers from inflating the business mapping
    ratio while proving that the schema evidence was actually consumed.
    """

    if segment.intent != "records" or segment.start <= 0:
        return set()
    header_axis = segment.start - 1
    result: set[str] = set()
    for item in inventory.values():
        if item.table_id != segment.table_id:
            continue
        axis = item.row if segment.orientation == "rows" else item.column
        if axis == header_axis:
            result.add(item.evidence_id)
    return result


_INLINE_METADATA = re.compile(
    r"^\s*(?P<label>[^:：\r\n]{1,64})\s*[:：]\s*(?P<value>\S(?:.*\S)?)\s*$"
)


def _metadata_label(value: str) -> str | None:
    normalized = _normalize(value).rstrip(":：").strip()
    if not normalized or len(normalized) > 64:
        return None
    if not any(
        character.isalpha() or "\u3400" <= character <= "\u9fff"
        for character in normalized
    ):
        return None
    if len(normalized) > 32 and not value.rstrip().endswith((":", "：")):
        return None
    if any(character in normalized for character in ("。", "！", "？", ";", "；")):
        return None
    return normalized


def _evidence_reference(item: _EvidenceItem) -> EvidenceReference:
    return EvidenceReference(
        evidence_id=item.evidence_id,
        quote=item.text,
        source_ref=item.source_ref.model_copy(deep=True),
    )


def _fallback_content_kind(item: _EvidenceItem) -> str:
    token = re.sub(r"[^a-z0-9]+", "_", item.source_kind.casefold()).strip("_")
    return (token or "text")[:64]


_PDF_TEXT_BINDING_PREFIX = "native:pdf-text-block-"


def _content_binding_text_key(value: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", value)).casefold()


def _resolve_content_binding_evidence_id(
    evidence_id: str,
    inventory: dict[str, _EvidenceItem],
) -> tuple[str | None, str | None]:
    """Repair only deterministic ID aliases or one unique exact-text hint."""

    if evidence_id in inventory:
        return evidence_id, None
    alias = evidence_id
    if alias.startswith("mineru/"):
        alias = alias.removeprefix("mineru/")
    alias = alias.replace(
        "native:pdf:pdf-text-block-",
        _PDF_TEXT_BINDING_PREFIX,
        1,
    )
    if alias in inventory:
        return alias, "normalized_id"
    if not alias.startswith(_PDF_TEXT_BINDING_PREFIX):
        return None, None
    hint = alias.removeprefix(_PDF_TEXT_BINDING_PREFIX)
    # A missing hash remains untrusted. Only outputs that accidentally put a
    # visible source fragment in the ID are eligible for exact replay.
    if re.fullmatch(r"[0-9a-f]{12,64}", hint, flags=re.IGNORECASE):
        return None, None
    hint_key = _content_binding_text_key(hint)
    if len(hint_key) < 5:
        return None, None
    matches = {
        candidate_id
        for candidate_id, item in inventory.items()
        if item.table_id is None
        and item.source_kind.casefold() != "table"
        and hint_key
        in _content_binding_text_key(str(item.exact_text or item.text or ""))
    }
    if len(matches) != 1:
        return None, None
    return next(iter(matches)), "unique_exact_text"


def _project_content_units(
    inventory: dict[str, _EvidenceItem],
    *,
    consumed: set[str],
    excluded: set[str],
    bindings: list[ProposedContentBinding],
    issues: list[str],
) -> tuple[list[ContentUnit], int, int]:
    """Bind non-table source blocks without allowing the model to rewrite text."""

    eligible = {
        evidence_id: item
        for evidence_id, item in inventory.items()
        if item.table_id is None
        and item.source_kind.casefold() != "table"
        and evidence_id not in consumed
        and evidence_id not in excluded
    }
    accepted: dict[str, list[ProposedContentBinding]] = {}
    for binding in bindings:
        original_evidence_id = binding.evidence_id
        evidence_id, repair_reason = _resolve_content_binding_evidence_id(
            original_evidence_id,
            inventory,
        )
        if evidence_id is None:
            issues.append(
                f"invalid_content_binding:unknown_evidence_id:{original_evidence_id}"
            )
            continue
        if repair_reason is not None:
            binding = binding.model_copy(
                update={"evidence_id": evidence_id},
                deep=True,
            )
            issues.append(
                "content_binding_evidence_id_repaired:"
                f"{repair_reason}:{evidence_id}"
            )
        item = inventory.get(evidence_id)
        assert item is not None
        if item.table_id is not None or item.source_kind.casefold() == "table":
            issues.append(
                f"invalid_content_binding:non_block_evidence_id:{evidence_id}"
            )
            continue
        if evidence_id in consumed:
            issues.append(
                f"ignored_content_binding:document_fact_consumed:{evidence_id}"
            )
            continue
        candidates = accepted.setdefault(evidence_id, [])
        semantic_key = (binding.content_kind, binding.label)
        if any(
            (candidate.content_kind, candidate.label) == semantic_key
            for candidate in candidates
        ):
            issues.append(f"ignored_content_binding:exact_duplicate:{evidence_id}")
            continue
        if candidates:
            issues.append(f"ignored_content_binding:merged_semantics:{evidence_id}")
        candidates.append(binding)

    units: list[ContentUnit] = []
    model_bound_count = 0
    fallback_count = 0
    for evidence_id, item in eligible.items():
        semantic_bindings = accepted.get(evidence_id, [])
        source_kind = (item.source_kind or "text")[:64]
        if not semantic_bindings:
            fallback_kind = _fallback_content_kind(item)
            units.append(
                ContentUnit(
                    evidence_id=evidence_id,
                    content_kind=fallback_kind,
                    label=f"local_fallback:{fallback_kind}",
                    exact_text=item.exact_text or item.text,
                    source_ref=item.source_ref.model_copy(deep=True),
                    source_kind=source_kind,
                    binding_source="local_fallback",
                )
            )
            fallback_count += 1
            continue
        binding = semantic_bindings[0]
        units.append(
            ContentUnit(
                evidence_id=evidence_id,
                content_kind=binding.content_kind,
                label=binding.label,
                exact_text=item.exact_text or item.text,
                source_ref=item.source_ref.model_copy(deep=True),
                source_kind=source_kind,
                binding_source="model",
                alternate_semantics=[
                    {
                        "content_kind": alternate.content_kind,
                        "label": alternate.label,
                    }
                    for alternate in semantic_bindings[1:]
                ],
            )
        )
        model_bound_count += 1
    return units, model_bound_count, fallback_count


def _document_fact_allowed_evidence_ids(
    inventory: dict[str, _EvidenceItem],
    assessment: RecordRegionAssessment,
) -> set[str]:
    """Exclude record rows/columns and their adjacent schema axis from facts."""

    allowed: set[str] = set()
    regions_by_table: dict[str, list[EvidenceRecordRegion]] = {}
    for region in assessment.record_regions:
        regions_by_table.setdefault(region.table_id, []).append(region)
    for evidence_id, item in inventory.items():
        provenance = item.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get("asset_sha256"):
            continue
        if item.table_id is None:
            allowed.add(evidence_id)
            continue
        forbidden = False
        for region in regions_by_table.get(item.table_id, []):
            axis = item.row if region.orientation == "rows" else item.column
            if axis is None:
                continue
            if max(0, region.data_start - 1) <= axis <= region.data_end:
                forbidden = True
                break
        if not forbidden:
            allowed.add(evidence_id)
    return allowed


def _is_blocking_issue(issue: str) -> bool:
    # These diagnostics describe model proposals that `_validated_fact`
    # rejected locally. They never enter ExtractedFact, so they must not turn
    # otherwise valid rows and fields into a document-wide extraction failure.
    # They remain in `issues` for review and audit.
    return not issue.startswith(
        (
            "ignored_model_fact:",
            "unsupported_fact_value:",
            "unknown_evidence_id:",
            "out_of_segment_evidence_id:",
            "advisory_evidence_forbidden:",
            "unsupported_evidence_ref:",
            "ignored_content_binding:",
            "invalid_content_binding:",
            "content_binding_evidence_id_repaired:",
            "ignored_primary_record_table:",
            "unmapped_supported_fact:",
            "explicit_document_intent_override:",
            "document_classification_trusted_family_reconciled:",
            "ignored_document_route_context:",
            "document_route_classification_fallback:",
            "document_classification_consistency_repair:",
            "document_fact_evidence_repaired:",
            "document_kind_label_inferred_from_evidence",
            "native_document_classification_applied",
            "native_parallel_record_tables_applied",
            "document_route_primary_tables_applied",
            "document_route_nonprimary_tables_filtered",
            "document_route_geometry_roles_migrated:",
            "technical_geometry_rows_reconstructed:",
            "technical_geometry_primary_tables_applied:",
            "technical_geometry_record_segments_aligned",
            "technical_nonprimary_record_segments_demoted",
            "primary_record_table_fallback:",
            "primary_record_table_refined:",
            "primary_record_rows_refined:",
            "long_record_field_mapping_fallback:",
            "record_kind_mapping_fallback:",
            "record_kind_mapping_correction_fallback:",
            "record_kind_mapping_incomplete:",
            "record_kind_mapping_input_limit:",
            "record_field_remapped:",
            "record_field_remap_conflict:",
            "record_context_inherited:",
            "model_request_budget_exhausted:",
            "intent_partition_geometry_repaired:",
        )
    )


def _local_metadata_fallback(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    inventory: dict[str, _EvidenceItem],
    *,
    already_consumed: set[str],
) -> tuple[list[ExtractedFact], set[str]]:
    """Recover strict same-axis label/value metadata without model rewriting.

    The fallback runs only for a model-declared metadata segment. Values are
    copied verbatim from one source cell (or a narrow ``label: value`` slice)
    and every label/value cell is cited. It never operates on record segments.
    """

    if segment.intent != "metadata":
        return [], set()
    axes: list[list[_EvidenceItem]] = []
    for axis in range(segment.start, segment.end + 1):
        items = [
            item
            for item in inventory.values()
            if item.table_id == segment.table_id
            and (item.row if segment.orientation == "rows" else item.column) == axis
        ]
        items.sort(
            key=lambda item: (
                item.column if segment.orientation == "rows" else item.row,
                item.evidence_id,
            )
        )
        if items:
            axes.append(items)

    facts: list[ExtractedFact] = []
    consumed: set[str] = set()
    for items in axes:
        if len(items) == 1:
            if items[0].evidence_id in already_consumed:
                continue
            match = _INLINE_METADATA.match(items[0].text)
            if match is None:
                continue
            label = _metadata_label(match.group("label"))
            value = _normalize(match.group("value"))
            if label is None or not value:
                continue
            facts.append(
                ExtractedFact(
                    name=label,
                    value=value,
                    evidence_refs=[_evidence_reference(items[0])],
                )
            )
            consumed.add(items[0].evidence_id)
            continue

        index = 0
        while index + 1 < len(items):
            label_item = items[index]
            value_item = items[index + 1]
            label_position = (
                label_item.column if segment.orientation == "rows" else label_item.row
            )
            value_position = (
                value_item.column if segment.orientation == "rows" else value_item.row
            )
            if (
                label_item.evidence_id in already_consumed
                or value_item.evidence_id in already_consumed
                or label_position is None
                or value_position != label_position + 1
            ):
                index += 1
                continue
            label = _metadata_label(label_item.text)
            if label is None or not value_item.text:
                index += 1
                continue
            facts.append(
                ExtractedFact(
                    name=label,
                    value=value_item.text,
                    evidence_refs=[
                        _evidence_reference(label_item),
                        _evidence_reference(value_item),
                    ],
                )
            )
            consumed.update({label_item.evidence_id, value_item.evidence_id})
            index += 2
    return facts, consumed


def _record_axis(
    record: ExtractedRecord,
    inventory: dict[str, _EvidenceItem],
    segment: _ValidatedSegment,
) -> int | None:
    axes: set[int] = set()
    for fact in record.fields:
        for reference in fact.evidence_refs:
            item = inventory.get(reference.evidence_id)
            if item is None or item.table_id != segment.table_id:
                continue
            axis = item.row if segment.orientation == "rows" else item.column
            if axis is not None:
                axes.add(axis)
    return next(iter(axes)) if len(axes) == 1 else None


def _axis_values(
    table: EvidenceTable, orientation: RecordOrientation
) -> list[list[str]]:
    if orientation == "rows":
        return [[_normalize(value) for value in row] for row in table.rows]
    width = max((len(row) for row in table.rows), default=0)
    return [
        [_normalize(row[column]) if column < len(row) else "" for row in table.rows]
        for column in range(width)
    ]


def _bounded_record_kind_evidence(
    records: Sequence[ExtractedRecord],
    *,
    limit: int = 12,
) -> list[EvidenceReference]:
    """Bound citations while retaining evidence from every contributing record."""

    buckets: list[list[EvidenceReference]] = []
    for record in records:
        seen: set[str] = set()
        bucket: list[EvidenceReference] = []
        for reference in record.record_kind_evidence_refs:
            if reference.evidence_id in seen:
                continue
            seen.add(reference.evidence_id)
            bucket.append(reference)
        if bucket:
            buckets.append(bucket)
    selected: list[EvidenceReference] = []
    selected_ids: set[str] = set()
    for bucket in buckets:
        reference = next(
            (
                candidate
                for candidate in bucket
                if candidate.evidence_id not in selected_ids
            ),
            None,
        )
        if reference is None:
            continue
        selected.append(reference)
        selected_ids.add(reference.evidence_id)
        if len(selected) >= limit:
            return selected
    for bucket in buckets:
        for reference in bucket:
            if reference.evidence_id in selected_ids:
                continue
            selected.append(reference)
            selected_ids.add(reference.evidence_id)
            if len(selected) >= limit:
                return selected
    return selected


def _merge_adjacent_duplicate_records(
    records: list[ExtractedRecord],
    *,
    table: EvidenceTable,
    segment: _ValidatedSegment,
    inventory: dict[str, _EvidenceItem],
    issues: list[str],
) -> list[ExtractedRecord]:
    """Merge only adjacent, byte-equivalent source axes and retain every citation."""

    if segment.intent != "records" or len(records) < 2:
        return records
    axes = _axis_values(table, segment.orientation)
    by_axis: dict[int, tuple[int, ExtractedRecord]] = {}
    for index, record in enumerate(records):
        axis = _record_axis(record, inventory, segment)
        if axis is not None:
            by_axis[axis] = (index, record)
    removed: set[int] = set()
    for axis in range(segment.start + 1, segment.end + 1):
        previous_values = axes[axis - 1] if axis - 1 < len(axes) else []
        current_values = axes[axis] if axis < len(axes) else []
        if not any(previous_values) or previous_values != current_values:
            continue
        previous = by_axis.get(axis - 1)
        current = by_axis.get(axis)
        if previous is None or current is None:
            issues.append(
                f"duplicate_record_evidence_unbound:{segment.table_id}:{axis - 1}:{axis}"
            )
            continue
        previous_index, previous_record = previous
        current_index, current_record = current
        previous_facts = {
            (fact.name, _normalize(fact.value)): fact for fact in previous_record.fields
        }
        current_facts = {
            (fact.name, _normalize(fact.value)): fact for fact in current_record.fields
        }
        if set(previous_facts) != set(current_facts):
            issues.append(
                f"duplicate_record_mapping_conflict:{segment.table_id}:{axis - 1}:{axis}"
            )
            continue
        merged_fields: list[ExtractedFact] = []
        for key, fact in previous_facts.items():
            references = [*fact.evidence_refs]
            known = {reference.evidence_id for reference in references}
            references.extend(
                reference
                for reference in current_facts[key].evidence_refs
                if reference.evidence_id not in known
            )
            merged_fields.append(fact.model_copy(update={"evidence_refs": references}))
        kind_values = {previous_record.record_kind, current_record.record_kind}
        concrete_kinds = kind_values - {"unknown"}
        if len(concrete_kinds) == 1:
            merged_kind = next(iter(concrete_kinds))
        elif len(kind_values) == 1:
            merged_kind = previous_record.record_kind
        else:
            merged_kind = "unknown"
            issues.append(
                "duplicate_record_kind_conflict:"
                f"{segment.table_id}:{axis - 1}:{axis}"
            )
        kind_refs = _bounded_record_kind_evidence(
            (previous_record, current_record)
        )
        records[previous_index] = previous_record.model_copy(
            update={
                "fields": merged_fields,
                "record_kind": merged_kind,
                "record_kind_evidence_refs": kind_refs,
                "record_kind_source": (
                    "model"
                    if merged_kind != "unknown"
                    and any(
                        candidate_record.record_kind == merged_kind
                        and candidate_record.record_kind_source == "model"
                        for candidate_record in (previous_record, current_record)
                    )
                    else "local_fallback"
                ),
            }
        )
        by_axis[axis - 1] = (previous_index, records[previous_index])
        removed.add(current_index)
        issues.append(
            f"duplicate_record_evidence_merged:{segment.table_id}:{axis - 1}:{axis}"
        )
    return [record for index, record in enumerate(records) if index not in removed]


_PRIMARY_FIELD_CATEGORY_TOKENS: dict[str, tuple[str, ...]] = {
    "identifier": (
        "item",
        "part",
        "code",
        "number",
        "sku",
        "序号",
        "料号",
        "编码",
        "编号",
        "型号",
    ),
    "description": (
        "description",
        "name",
        "product",
        "material",
        "名称",
        "品名",
        "产品",
        "物料",
        "描述",
        "规格",
    ),
    "quantity": (
        "qty",
        "quantity",
        "unit",
        "uom",
        "数量",
        "用量",
        "单位",
    ),
}


def _primary_field_category_count(records: list[ExtractedRecord]) -> int:
    names = " ".join(
        _normalize(fact.name).casefold()
        for record in records[:5]
        for fact in record.fields
    )
    return sum(
        1
        for tokens in _PRIMARY_FIELD_CATEGORY_TOKENS.values()
        if any(token in names for token in tokens)
    )


def _refine_primary_record_table_ids(
    document_intent: str,
    selected: list[str],
    segments: list[ExtractedSegment],
    issues: list[str],
) -> list[str]:
    """Require business-column corroboration for heterogeneous technical tables."""

    if _document_intent_family(document_intent) != "technical_document":
        return selected
    records_by_table: dict[str, list[ExtractedRecord]] = {}
    for segment in segments:
        if segment.records:
            records_by_table.setdefault(segment.table_id, []).extend(segment.records)
    if len(records_by_table) <= 1:
        return selected or list(records_by_table)
    scores = {
        table_id: _primary_field_category_count(records)
        for table_id, records in records_by_table.items()
    }
    best_score = max(scores.values(), default=0)
    candidates = [table_id for table_id, score in scores.items() if score == best_score]
    if best_score >= 2 and len(candidates) == 1:
        if selected != candidates:
            issues.append("primary_record_table_refined:business_column_corroboration")
        return candidates
    return selected or list(records_by_table)


def _segment_payload(
    table: EvidenceTable,
    segment: _ValidatedSegment,
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    if segment.orientation == "rows":
        for row_index in range(segment.start, segment.end + 1):
            values = table.rows[row_index] if row_index < len(table.rows) else []
            rows.append(
                {
                    "axis_index": row_index,
                    "cells": [
                        {
                            "evidence_id": f"{table.table_id}:r{row_index}:c{column}",
                            "column": column,
                            "value": value,
                        }
                        for column, value in enumerate(values)
                        if _normalize(value)
                    ],
                }
            )
    else:
        width = max((len(row) for row in table.rows), default=0)
        for column in range(segment.start, segment.end + 1):
            rows.append(
                {
                    "axis_index": column,
                    "cells": [
                        {
                            "evidence_id": f"{table.table_id}:r{row}:c{column}",
                            "row": row,
                            "value": values[column],
                        }
                        for row, values in enumerate(table.rows)
                        if column < width
                        and column < len(values)
                        and _normalize(values[column])
                    ],
                }
            )
    header_context: dict[str, Any] | None = None
    if segment.start > 0:
        header_axis = segment.start - 1
        if segment.orientation == "rows" and header_axis < len(table.rows):
            header_context = {
                "axis_index": header_axis,
                "cells": [
                    {"column": column, "value": value}
                    for column, value in enumerate(table.rows[header_axis])
                    if _normalize(value)
                ],
            }
        elif segment.orientation == "columns":
            header_context = {
                "axis_index": header_axis,
                "cells": [
                    {"row": row, "value": values[header_axis]}
                    for row, values in enumerate(table.rows)
                    if header_axis < len(values) and _normalize(values[header_axis])
                ],
            }
    return {
        "table_id": segment.table_id,
        "segment_id": segment.segment_id,
        "orientation": segment.orientation,
        "start": segment.start,
        "end": segment.end,
        "intent": segment.intent,
        "axis_contract": {
            "axis_kind": "row" if segment.orientation == "rows" else "column",
            "independent_axes": True,
            "record_rule": (
                "For records intent, each data-row axis is one independent record; "
                "never copy a value from one axis_index into another."
                if segment.orientation == "rows"
                else "Treat each column axis independently; never copy values between axes."
            ),
        },
        "header_context": header_context,
        "axes": rows,
    }


def _adjacent_header_labels(
    table: EvidenceTable,
    segment: _ValidatedSegment,
) -> dict[int, str]:
    """Return source header labels aligned to the record field axes."""

    if segment.start <= 0:
        return {}
    header_axis = segment.start - 1
    if segment.orientation == "rows":
        if header_axis >= len(table.rows):
            return {}
        labels = {
            index: label
            for index, value in enumerate(table.rows[header_axis])
            if (label := _normalize(value))
        }
        header_cells = sorted(
            (
                cell
                for cell in table.cells
                if cell.row == header_axis and _normalize(cell.text)
            ),
            key=lambda cell: cell.column,
        )
        record_positions = [
            [
                cell.column
                for cell in sorted(
                    (
                        cell
                        for cell in table.cells
                        if cell.row == record_axis and _normalize(cell.text)
                    ),
                    key=lambda cell: cell.column,
                )
            ]
            for record_axis in range(segment.start, segment.end + 1)
        ]
    else:
        labels = {
            row_index: label
            for row_index, row in enumerate(table.rows)
            if header_axis < len(row) and (label := _normalize(row[header_axis]))
        }
        header_cells = sorted(
            (
                cell
                for cell in table.cells
                if cell.column == header_axis and _normalize(cell.text)
            ),
            key=lambda cell: cell.row,
        )
        record_positions = [
            [
                cell.row
                for cell in sorted(
                    (
                        cell
                        for cell in table.cells
                        if cell.column == record_axis and _normalize(cell.text)
                    ),
                    key=lambda cell: cell.row,
                )
            ]
            for record_axis in range(segment.start, segment.end + 1)
        ]
    header_positions = [
        cell.column if segment.orientation == "rows" else cell.row
        for cell in header_cells
    ]
    if (
        header_cells
        and record_positions
        and all(
            len(positions) == len(header_cells) and positions == record_positions[0]
            for positions in record_positions
        )
        and record_positions[0] != header_positions
    ):
        # Adjacent Word rows can merge different logical grid columns. Equal
        # physical cell counts retain their intended top-to-bottom pairing.
        return {
            index: _normalize(cell.text)
            for index, cell in zip(record_positions[0], header_cells, strict=True)
        }
    return labels


def _native_record_header_labels(
    table: EvidenceTable,
    segment: _ValidatedSegment,
) -> tuple[dict[int, str], tuple[int, ...]]:
    """Return exact native header axes when the adapter declared their layout."""

    raw = (table.model_extra or {}).get("native_record_layout")
    native_intent = _trusted_native_record_intent(table.table_id, table)
    if (
        not isinstance(raw, dict)
        or native_intent is None
        or native_intent.orientation != segment.orientation
    ):
        return {}, ()
    declared_record_axes = {
        axis
        for declared in native_intent.segments
        if declared.intent == "records"
        for axis in range(declared.start, declared.end + 1)
    }
    if not set(range(segment.start, segment.end + 1)) <= declared_record_axes:
        return {}, ()
    raw_axes = raw.get("header_axes")
    if not isinstance(raw_axes, list) or any(
        isinstance(axis, bool) or not isinstance(axis, int) for axis in raw_axes
    ):
        return {}, ()
    header_axes = tuple(sorted(set(raw_axes)))
    labels_by_field: dict[int, list[str]] = {}
    for header_axis in header_axes:
        if segment.orientation == "rows":
            if not 0 <= header_axis < len(table.rows):
                return {}, ()
            values = enumerate(table.rows[header_axis])
        else:
            if header_axis < 0:
                return {}, ()
            values = (
                (row_index, row[header_axis])
                for row_index, row in enumerate(table.rows)
                if header_axis < len(row)
            )
        for field_axis, raw_value in values:
            label = _normalize(raw_value)
            if not label:
                continue
            labels = labels_by_field.setdefault(field_axis, [])
            if label not in labels:
                labels.append(label)
    return (
        {
            field_axis: " / ".join(labels)
            for field_axis, labels in labels_by_field.items()
        },
        header_axes,
    )


def _record_mapping_header_labels(
    table: EvidenceTable,
    segment: _ValidatedSegment,
) -> tuple[dict[int, str], tuple[int, ...]]:
    native_labels, native_axes = _native_record_header_labels(table, segment)
    if native_labels:
        return native_labels, native_axes
    labels = _adjacent_header_labels(table, segment)
    return labels, ((segment.start - 1,) if labels and segment.start > 0 else ())


def _record_mapping_schema_key(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    *,
    document_type: str,
    field_axis_count: int,
) -> tuple[Any, ...]:
    """Identify one reusable field schema without including any record values."""

    header_labels, _ = _record_mapping_header_labels(table, segment)
    header_signature = tuple(sorted(header_labels.items()))
    raw_layout = (table.model_extra or {}).get("native_record_layout")
    layout_signature: tuple[tuple[str, str], ...] = ()
    if isinstance(raw_layout, dict):
        stable_layout = {
            key: raw_layout[key]
            for key in (
                "source",
                "orientation",
                "header_axes",
                "document_type",
                "document_subtype",
            )
            if key in raw_layout
        }
        layout_signature = tuple(
            (key, json.dumps(value, ensure_ascii=False, sort_keys=True))
            for key, value in sorted(stable_layout.items())
        )
    # Headerless, undeclared regions have no evidence-backed proof that their
    # field roles match. Keep them distinct and let the document hard cap send
    # the remainder through deterministic local projection.
    unscoped_identity: tuple[str, ...] = ()
    if not header_signature and not layout_signature:
        unscoped_identity = (table.table_id, segment.segment_id)
    return (
        document_type,
        segment.orientation,
        field_axis_count,
        header_signature,
        layout_signature,
        unscoped_identity,
    )


def _long_record_mapping_payload(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    *,
    document_type: str,
) -> dict[str, Any]:
    """Send bounded field-axis examples; full record cells stay local to M1."""

    field_axis_count = (
        max((len(row) for row in table.rows), default=0)
        if segment.orientation == "rows"
        else len(table.rows)
    )
    header_context: dict[str, Any] | None = None
    header_labels, header_axes = _record_mapping_header_labels(table, segment)
    if header_labels:
        axis_key = "column" if segment.orientation == "rows" else "row"
        header_indexes = sorted(header_labels)
        if len(header_indexes) > 32:
            header_indexes = [
                header_indexes[index]
                for index in _spread_indices(len(header_indexes), 32)
            ]
        header_context = {
            "axis_index": header_axes[-1] if header_axes else segment.start - 1,
            "axis_indices": list(header_axes),
            "cells": [
                {axis_key: index, "value": value[:64]}
                for index in header_indexes
                if (value := _normalize(header_labels[index]))
            ],
        }
    record_axes = list(range(segment.start, segment.end + 1))
    sampled_record_axes = [
        record_axes[index]
        for index in _spread_indices(len(record_axes), min(2, len(record_axes)))
    ]
    examples_by_field_axis: dict[int, list[str]] = {}
    for record_axis in sampled_record_axes:
        if segment.orientation == "rows":
            values = table.rows[record_axis]
            field_values = enumerate(values)
        else:
            field_values = (
                (row, values[record_axis])
                for row, values in enumerate(table.rows)
                if record_axis < len(values) and _normalize(values[record_axis])
            )
        for field_axis_index, raw_value in field_values:
            value = _normalize(raw_value)
            if not value:
                continue
            examples = examples_by_field_axis.setdefault(field_axis_index, [])
            bounded = value[:64]
            if bounded not in examples and len(examples) < 2:
                examples.append(bounded)
    sampled_field_axes = sorted(examples_by_field_axis)
    if len(sampled_field_axes) > 16:
        sampled_field_axes = [
            sampled_field_axes[index]
            for index in _spread_indices(len(sampled_field_axes), 16)
        ]
    field_axis_samples = [
        {
            "field_axis_index": field_axis_index,
            "examples": examples_by_field_axis[field_axis_index],
        }
        for field_axis_index in sampled_field_axes
    ]
    allowed_targets = sorted(allowed_line_targets(document_type))
    return {
        "table_id": segment.table_id,
        "orientation": segment.orientation,
        "record_axis": {
            "start": segment.start,
            "end": segment.end,
            "count": segment.end - segment.start + 1,
        },
        "field_axis": {
            "kind": "column" if segment.orientation == "rows" else "row",
            "count": field_axis_count,
        },
        "header_context": header_context,
        "field_axis_samples": field_axis_samples,
        "document_type": document_type,
        "allowed_field_names": allowed_targets,
    }


def _field_names_from_mapping(
    mapping: RecordFieldMapping,
    *,
    orientation: RecordOrientation,
    expected_count: int,
    fallback_names: dict[int, str] | None = None,
    document_type: str = "unknown",
) -> dict[int, str]:
    if mapping.field_axis_count != expected_count:
        raise ValueError("field_axis_count mismatch")
    prefix = "column" if orientation == "rows" else "row"
    names = {
        index: (fallback_names or {}).get(index, f"{prefix}_{index}")
        for index in range(expected_count)
    }
    locked: set[int] = set()
    for index, source_label in names.items():
        target = (
            source_label
            if source_label in allowed_line_targets(document_type)
            else source_label_line_target(source_label, document_type)
        )
        if target is None:
            continue
        names[index] = target
        locked.add(index)
    for binding in mapping.bindings:
        if binding.axis_index >= expected_count:
            raise ValueError("field binding axis is out of bounds")
        if binding.axis_index in locked:
            continue
        names[binding.axis_index] = binding.field_name
    normalized = [_normalize(name).casefold() for name in names.values()]
    if len(normalized) != len(set(normalized)):
        raise ValueError("field mapping collides with a generic field name")
    return names


def _generic_field_names(
    table: EvidenceTable,
    orientation: RecordOrientation,
) -> dict[int, str]:
    count = _table_axis_size(table, "columns" if orientation == "rows" else "rows")
    prefix = "column" if orientation == "rows" else "row"
    return {index: f"{prefix}_{index}" for index in range(count)}


def _technical_inferred_field_names(
    table: EvidenceTable,
    orientation: RecordOrientation,
    *,
    document_type: str | None = None,
) -> dict[int, str]:
    """Infer a small set of stable line fields from an unheaded table.

    MinerU sometimes emits a BOM as a dense matrix without the source header
    row (common in engineering drawings).  A failed model mapping must still
    expose useful standard fields.  This helper uses independent column/row
    evidence ratios and only returns labels when the source has corroborating
    identity, quantity, or description signals.  It never invents values and
    leaves ambiguous axes as generic ``column_N``/``row_N`` names.
    """

    generic = _generic_field_names(table, orientation)
    if not table.rows:
        return generic
    if orientation == "rows":
        width = max((len(row) for row in table.rows), default=0)
        axes = [
            [row[index] for row in table.rows if index < len(row)]
            for index in range(width)
        ]
    else:
        axes = [list(row) for row in table.rows]
    if not axes:
        return generic

    def ratio(values: list[str], predicate: Any) -> float:
        meaningful = [value for value in values if _normalize(value)]
        if not meaningful:
            return 0.0
        return sum(bool(predicate(value)) for value in meaningful) / len(meaningful)

    def strict_line_sequence(values: list[str]) -> bool:
        meaningful = [_normalize(value) for value in values if _normalize(value)]
        if len(meaningful) < 2 or any(
            not re.fullmatch(r"\d{1,3}", value) for value in meaningful
        ):
            return False
        numbers = [int(value) for value in meaningful]
        steps = [right - left for left, right in pairwise(numbers)]
        return (
            bool(steps)
            and abs(steps[0]) == 1
            and all(step == steps[0] for step in steps)
        )

    profiles: dict[int, dict[str, float]] = {}
    for index, values in enumerate(axes):
        normalized = [_normalize(value) for value in values]
        profiles[index] = {
            "identifier": ratio(normalized, _technical_table_identifier),
            "quantity": ratio(normalized, _technical_table_quantity),
            "description": ratio(normalized, _technical_table_description),
            "line_no": float(strict_line_sequence(normalized)),
            "plain_quantity": ratio(
                normalized,
                _technical_table_plain_number,
            ),
        }

    assigned: set[int] = set()
    inferred: dict[int, str] = dict(generic)

    def best_axis(role: str, *, minimum: float) -> int | None:
        candidates = [
            (profile[role], index)
            for index, profile in profiles.items()
            if index not in assigned and profile[role] >= minimum
        ]
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], item[1]))
        return candidates[0][1]

    line_axis = best_axis("line_no", minimum=0.5)
    if line_axis is not None:
        inferred[line_axis] = "line_no"
        assigned.add(line_axis)
    identity_axis = best_axis("identifier", minimum=0.25)
    if identity_axis is not None:
        inferred[identity_axis] = (
            "product_code"
            if str(document_type or "").casefold() == "order"
            else "material_code"
        )
        assigned.add(identity_axis)
    description_axis = best_axis("description", minimum=0.25)
    if description_axis is not None:
        inferred[description_axis] = "name_raw"
        assigned.add(description_axis)
    quantity_axis = best_axis("quantity", minimum=0.25)
    if (
        quantity_axis is None
        and identity_axis is not None
        and description_axis is not None
    ):
        quantity_axis = best_axis("plain_quantity", minimum=0.5)
    if quantity_axis is not None:
        inferred[quantity_axis] = "quantity"
        assigned.add(quantity_axis)
    return inferred


_ORDER_UNIT_VALUE_RE = re.compile(
    r"(?i)^(?:pcs?|ea|set|kg|g|m|cm|mm|箱|包|卷|套|个|件|条|台|支|张|组|批)$"
)
_ORDER_LENGTH_VALUE_RE = re.compile(r"(?i)^\d+(?:\.\d+)?\s*(?:m|cm|mm|米|厘米|毫米)$")
_ORDER_CARTON_DIMENSION_RE = re.compile(
    r"(?i)^\s*\d+(?:\.\d+)?\s*[x×*]\s*\d+(?:\.\d+)?"
    r"\s*[x×*]\s*\d+(?:\.\d+)?\s*(?:cm|mm)?\s*$"
)


def _order_unheaded_field_names(
    table: EvidenceTable,
    segment: _ValidatedSegment,
) -> dict[int, str] | None:
    """Recover conservative order roles after a model mapping failure.

    This fallback uses relationships inside each retained record rather than a
    template: an explicit unit value, an adjacent length specification, and a
    unique ``quantity = package_quantity * piece_count`` relationship. Unknown
    axes stay generic and therefore remain lossless without being promoted.
    """

    if segment.orientation != "rows" or segment.end < segment.start:
        return None
    adjacent_labels = _adjacent_header_labels(table, segment)
    if (
        sum(
            source_label_line_target(label, "order") is not None
            for label in adjacent_labels.values()
        )
        >= 2
    ):
        return None
    rows = [
        table.rows[index]
        for index in range(segment.start, segment.end + 1)
        if index < len(table.rows)
    ]
    width = max((len(row) for row in rows), default=0)
    if not rows or width < 3:
        return None

    values_by_axis = {
        axis: [
            _normalize(row[axis])
            for row in rows
            if axis < len(row) and _normalize(row[axis])
        ]
        for axis in range(width)
    }
    unit_axes = [
        axis
        for axis, values in values_by_axis.items()
        if values and all(_ORDER_UNIT_VALUE_RE.fullmatch(value) for value in values)
    ]
    if len(unit_axes) != 1:
        return None
    unit_axis = unit_axes[0]
    names = _generic_field_names(table, segment.orientation)
    names[unit_axis] = "unit"

    specification_axis = unit_axis - 1
    specification_values = values_by_axis.get(specification_axis, [])
    if specification_values and all(
        _ORDER_LENGTH_VALUE_RE.fullmatch(value) for value in specification_values
    ):
        names[specification_axis] = "specification_raw"

    description_axes = [
        axis
        for axis in range(max(unit_axis - 1, 0))
        if values_by_axis.get(axis)
        and sum(_technical_table_description(value) for value in values_by_axis[axis])
        / len(values_by_axis[axis])
        >= 0.5
    ]
    if description_axes:
        names[description_axes[0]] = "name_raw"

    first_values = values_by_axis.get(0, [])
    if first_values and all(re.fullmatch(r"\d{1,4}", value) for value in first_values):
        numbers = [int(value) for value in first_values]
        if len(numbers) == 1 or all(
            right - left == 1 for left, right in pairwise(numbers)
        ):
            names[0] = "line_no"

    def decimal_at(row: list[str | None], axis: int) -> Decimal | None:
        if axis >= len(row):
            return None
        token = _normalize(row[axis]).replace(",", "")
        if not _TECHNICAL_TABLE_PLAIN_NUMBER_RE.fullmatch(token):
            return None
        try:
            return Decimal(token)
        except InvalidOperation:
            return None

    numeric_axes = [
        axis
        for axis in range(unit_axis + 1, width)
        if all(decimal_at(row, axis) is not None for row in rows)
    ]
    arithmetic_candidates: list[tuple[int, int, int]] = []
    for quantity_axis, package_axis, piece_axis in zip(
        numeric_axes,
        numeric_axes[1:],
        numeric_axes[2:],
    ):
        if not (quantity_axis < package_axis < piece_axis):
            continue
        if all(
            decimal_at(row, quantity_axis)
            == decimal_at(row, package_axis) * decimal_at(row, piece_axis)  # type: ignore[operator]
            for row in rows
        ):
            arithmetic_candidates.append((quantity_axis, package_axis, piece_axis))
    if len(arithmetic_candidates) == 1:
        quantity_axis, package_axis, piece_axis = arithmetic_candidates[0]
        names[quantity_axis] = "quantity"
        names[package_axis] = "package_quantity"
        names[piece_axis] = "piece_count"
    elif len(numeric_axes) == 1:
        names[numeric_axes[0]] = "quantity"

    carton_axes = [
        axis
        for axis in range(unit_axis + 1, width)
        if values_by_axis.get(axis)
        and all(
            _ORDER_CARTON_DIMENSION_RE.fullmatch(value)
            for value in values_by_axis[axis]
        )
    ]
    if len(carton_axes) == 1:
        names[carton_axes[0]] = "carton_specification"
    return names


def _evidence_backed_field_names(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    *,
    document_type: str | None = None,
) -> dict[int, str]:
    """Use the adjacent source header when the model cannot name fields."""

    unheaded_names = (
        _order_unheaded_field_names(table, segment)
        if str(document_type or "").casefold() == "order"
        else None
    )
    names = unheaded_names or _technical_inferred_field_names(
        table,
        segment.orientation,
        document_type=document_type,
    )
    labels_by_index = (
        {}
        if unheaded_names is not None
        else _record_mapping_header_labels(table, segment)[0]
    )
    reserved = {_normalize(value).casefold() for value in names.values()}
    for index, value in labels_by_index.items():
        label = _normalize(value)
        folded = label.casefold()
        if index not in names or not label or len(label) > 128 or folded in reserved:
            continue
        reserved.discard(_normalize(names[index]).casefold())
        names[index] = label
        reserved.add(folded)
    if document_type:
        for index, source_label in names.items():
            target = source_label_line_target(source_label, document_type)
            if target is not None:
                names[index] = target
    return names


def _project_long_record_segment(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    inventory: dict[str, _EvidenceItem],
    field_names: dict[int, str],
) -> tuple[list[ExtractedRecord], set[str]]:
    """Project every non-empty source cell without asking the model to echo it."""

    records: list[ExtractedRecord] = []
    consumed: set[str] = set()
    for record_axis in range(segment.start, segment.end + 1):
        if segment.orientation == "rows":
            cells = [
                (column, f"{table.table_id}:r{record_axis}:c{column}")
                for column, value in enumerate(table.rows[record_axis])
                if _normalize(value)
            ]
        else:
            cells = [
                (row, f"{table.table_id}:r{row}:c{record_axis}")
                for row, values in enumerate(table.rows)
                if record_axis < len(values) and _normalize(values[record_axis])
            ]
        if len(cells) > _MAX_EXTRACTED_RECORD_FIELDS:
            raise RecordGeometryContractError(
                "record_field_axis_exceeds_limit:"
                f"{table.table_id}:{segment.orientation}:"
                f"record_axis={record_axis}:field_count={len(cells)}:"
                f"limit={_MAX_EXTRACTED_RECORD_FIELDS}"
            )
        fields: list[ExtractedFact] = []
        for field_axis, evidence_id in cells:
            item = inventory[evidence_id]
            fields.append(
                ExtractedFact(
                    name=field_names[field_axis],
                    value=item.text,
                    evidence_refs=[
                        EvidenceReference(
                            evidence_id=evidence_id,
                            quote=item.text,
                            source_ref=item.source_ref.model_copy(deep=True),
                        )
                    ],
                )
            )
            consumed.add(evidence_id)
        if fields:
            record_refs = [
                reference.model_copy(deep=True)
                for fact in fields
                for reference in fact.evidence_refs
            ]
            records.append(
                ExtractedRecord(
                    fields=fields,
                    record_kind_evidence_refs=record_refs[:12],
                    record_axis=record_axis,
                )
            )
    return records, consumed


def _record_kind_candidate(record: ExtractedRecord) -> dict[str, Any] | None:
    if record.record_axis is None:
        return None
    fields: list[dict[str, Any]] = []
    seen_evidence: set[str] = set()
    for fact in record.fields:
        for reference in fact.evidence_refs:
            if reference.evidence_id in seen_evidence:
                continue
            seen_evidence.add(reference.evidence_id)
            value = fact.value
            fields.append(
                {
                    "evidence_id": reference.evidence_id,
                    "current_field_name": fact.name,
                    "value": value[:1000],
                    **({"value_truncated": True} if len(value) > 1000 else {}),
                }
            )
    if not fields:
        return None
    return {"axis_index": record.record_axis, "fields": fields}


def _record_kind_payload_batches(
    records: list[ExtractedRecord],
    *,
    table_id: str,
    orientation: RecordOrientation,
    document_type: str,
    document_subtype: str | None,
    max_input_chars: int,
) -> tuple[list[dict[str, Any]], set[int]]:
    """Build bounded classification batches without dropping candidate axes."""

    base = {
        "table_id": table_id,
        "orientation": orientation,
        "document_type": document_type,
        "document_subtype": document_subtype or "unknown",
        "allowed_record_kinds": [
            "product",
            "narrative",
            "total",
            "metadata",
            "unknown",
        ],
        "allowed_field_names": sorted(allowed_line_targets(document_type)),
    }
    candidates = [
        candidate
        for record in records
        if (candidate := _record_kind_candidate(record)) is not None
    ]
    batches: list[dict[str, Any]] = []
    oversized_axes: set[int] = set()
    current: list[dict[str, Any]] = []
    for candidate in candidates:
        proposed = [*current, candidate]
        payload = {**base, "candidates": proposed}
        exceeds_count = len(proposed) > 96
        exceeds_chars = _prompt_size(
            _base_messages(role="record_kind_mapping", payload=payload)
        ) > max_input_chars
        if current and (exceeds_count or exceeds_chars):
            batches.append({**base, "candidates": current})
            single_payload = {**base, "candidates": [candidate]}
            if _prompt_size(
                _base_messages(role="record_kind_mapping", payload=single_payload)
            ) > max_input_chars:
                oversized_axes.add(int(candidate["axis_index"]))
                current = []
            else:
                current = [candidate]
        elif not current and exceeds_chars:
            oversized_axes.add(int(candidate["axis_index"]))
            continue
        else:
            current = proposed
    if current:
        batches.append({**base, "candidates": current})
    return batches, oversized_axes


def _apply_record_kind_mapping(
    records: list[ExtractedRecord],
    mapping: RecordKindMapping,
    *,
    inventory: dict[str, _EvidenceItem],
    table_id: str,
    document_type: str,
    issues: list[str],
) -> list[ExtractedRecord]:
    decisions = {decision.axis_index: decision for decision in mapping.decisions}
    result: list[ExtractedRecord] = []
    for record in records:
        decision = decisions.get(record.record_axis) if record.record_axis is not None else None
        if decision is None:
            result.append(record)
            continue
        target_counts: dict[str, int] = {}
        for fact in record.fields:
            target = _fact_target_name(fact, document_type)
            target_counts[target] = target_counts.get(target, 0) + 1
        proposed_remaps = {
            remap.evidence_id: remap.field_name for remap in decision.field_remaps
        }
        remaps: dict[str, LineTarget] = {}
        for fact in record.fields:
            evidence_ids = [reference.evidence_id for reference in fact.evidence_refs]
            proposed_names = {
                proposed_remaps[evidence_id]
                for evidence_id in evidence_ids
                if evidence_id in proposed_remaps
            }
            if len(proposed_names) != 1 or not all(
                evidence_id in proposed_remaps for evidence_id in evidence_ids
            ):
                continue
            remapped_name = next(iter(proposed_names))
            old_target = _fact_target_name(fact, document_type)
            if remapped_name != old_target and target_counts.get(remapped_name, 0):
                issues.append(
                    "record_field_remap_conflict:"
                    f"{table_id}:{record.record_axis}:{evidence_ids[0]}:"
                    f"{old_target}:{remapped_name}"
                )
                continue
            target_counts[old_target] = max(0, target_counts.get(old_target, 1) - 1)
            target_counts[remapped_name] = target_counts.get(remapped_name, 0) + 1
            for evidence_id in evidence_ids:
                remaps[evidence_id] = remapped_name
        fields: list[ExtractedFact] = []
        for fact in record.fields:
            remapped_references = [
                reference
                for reference in fact.evidence_refs
                if reference.evidence_id in remaps
            ]
            remapped_names = {
                remaps[reference.evidence_id] for reference in remapped_references
            }
            if (
                len(remapped_names) == 1
                and len(remapped_references) == len(fact.evidence_refs)
            ):
                remapped_name = next(iter(remapped_names))
                if remapped_name != fact.name:
                    issues.append(
                        "record_field_remapped:"
                        f"{table_id}:{record.record_axis}:{fact.name}:{remapped_name}"
                    )
                    fact = fact.model_copy(
                        update={
                            "name": remapped_name,
                            "mapping_source": "record_kind_model_remap",
                            "original_name": fact.name,
                        },
                        deep=True,
                    )
            fields.append(fact)
        kind_refs = [
            _evidence_reference(inventory[evidence_id])
            for evidence_id in decision.citations
            if evidence_id in inventory
        ]
        result.append(
            record.model_copy(
                update={
                    "fields": fields,
                    "record_kind": decision.record_kind,
                    "record_kind_evidence_refs": kind_refs,
                    "record_kind_source": "model",
                },
                deep=True,
            )
        )
    return result


def _fact_target_name(fact: ExtractedFact, document_type: str) -> str:
    allowed = set(allowed_line_targets(document_type))
    if fact.name in allowed:
        return fact.name
    return source_label_line_target(fact.name, document_type) or fact.name


def _unique_record_facts_by_target(
    record: ExtractedRecord,
    document_type: str,
) -> dict[str, ExtractedFact]:
    grouped: dict[str, list[ExtractedFact]] = {}
    for fact in record.fields:
        grouped.setdefault(_fact_target_name(fact, document_type), []).append(fact)
    unique: dict[str, ExtractedFact] = {}
    for target, facts in grouped.items():
        values = {_normalize(fact.value).casefold() for fact in facts}
        if len(values) == 1:
            unique[target] = facts[0]
    return unique


def _inherit_record_context(
    records: list[ExtractedRecord],
    *,
    document_type: str,
    table_id: str,
    issues: list[str],
) -> list[ExtractedRecord]:
    """Carry only auditable context inside one contiguous model-approved group."""

    result: list[ExtractedRecord] = []
    previous: ExtractedRecord | None = None
    for index, record in enumerate(records):
        consecutive = (
            previous is not None
            and previous.record_axis is not None
            and record.record_axis == previous.record_axis + 1
        )
        model_product_group = (
            consecutive
            and previous is not None
            and previous.record_kind == "product"
            and previous.record_kind_source == "model"
            and record.record_kind == "product"
            and record.record_kind_source == "model"
        )
        if not model_product_group:
            result.append(record)
            previous = record if record.record_kind == "product" else None
            continue

        current_by_target = _unique_record_facts_by_target(record, document_type)
        previous_by_target = _unique_record_facts_by_target(previous, document_type)
        additions: list[ExtractedFact] = []
        shared_identity = any(
            name in current_by_target
            and name in previous_by_target
            and _normalize(current_by_target[name].value).casefold()
            == _normalize(previous_by_target[name].value).casefold()
            for name in ("model", "product_code")
        )
        following = records[index + 1] if index + 1 < len(records) else None
        following_by_target = (
            _unique_record_facts_by_target(following, document_type)
            if following is not None
            and record.record_axis is not None
            and following.record_axis == record.record_axis + 1
            and following.record_kind == "product"
            and following.record_kind_source == "model"
            else {}
        )
        surrounding_unit_agrees = (
            "unit" in previous_by_target
            and "unit" in following_by_target
            and _normalize(previous_by_target["unit"].value).casefold()
            == _normalize(following_by_target["unit"].value).casefold()
        )
        if (
            "unit" not in current_by_target
            and "quantity" in current_by_target
            and (source := previous_by_target.get("unit")) is not None
            and (shared_identity or surrounding_unit_agrees)
            and any(
                name in current_by_target
                for name in ("model", "product_code", "name_raw", "specification_raw")
            )
        ):
            additions.append(
                source.model_copy(
                    update={
                        "name": "unit",
                        "inferred": True,
                        "inference_source": (
                            "shared_identity_record_group"
                            if shared_identity
                            else "surrounding_unit_consensus"
                        ),
                    },
                    deep=True,
                )
            )
            issues.append(
                f"record_context_inherited:{table_id}:{record.record_axis}:unit"
            )

        if (
            "name_raw" not in current_by_target
            and shared_identity
            and (source := previous_by_target.get("name_raw")) is not None
        ):
            additions.append(
                source.model_copy(
                    update={
                        "name": "name_raw",
                        "inferred": True,
                        "inference_source": "shared_identity_record_group",
                    },
                    deep=True,
                )
            )
            issues.append(
                f"record_context_inherited:{table_id}:{record.record_axis}:name_raw"
            )

        if additions:
            record = record.model_copy(
                update={"fields": [*record.fields, *additions]},
                deep=True,
            )
        result.append(record)
        previous = record
    return result


def _split_segment_for_budget(
    table: EvidenceTable,
    segment: _ValidatedSegment,
    *,
    max_input_chars: int,
) -> list[_ValidatedSegment]:
    """Split a declared semantic segment without dropping or reordering an axis."""

    chunks: list[_ValidatedSegment] = []
    start = segment.start
    while start <= segment.end:
        accepted_end: int | None = None
        for end in range(start, segment.end + 1):
            candidate = _ValidatedSegment(
                table_id=segment.table_id,
                orientation=segment.orientation,
                start=start,
                end=end,
                intent=segment.intent,
            )
            messages = _messages(
                role="segment_extraction",
                payload=_segment_payload(table, candidate),
            )
            if _prompt_size(messages) > max_input_chars:
                break
            accepted_end = end
        if accepted_end is None:
            return []
        chunks.append(
            _ValidatedSegment(
                table_id=segment.table_id,
                orientation=segment.orientation,
                start=start,
                end=accepted_end,
                intent=segment.intent,
            )
        )
        start = accepted_end + 1
    return chunks


class MinerUInstructorExtractor:
    """Evidence-preserving two-stage Instructor POC with no runtime wiring."""

    def __init__(
        self,
        *,
        client: InstructorAsyncClient,
        max_input_chars: int = 80_000,
        max_segment_input_chars: int | None = None,
        max_retries: int = 2,
        compact_intent: bool = False,
    ) -> None:
        self._client = client
        self.max_input_chars = max(4_000, int(max_input_chars))
        self.max_segment_input_chars = max(
            4_000,
            int(max_segment_input_chars or self.max_input_chars),
        )
        self.max_retries = max(0, min(2, int(max_retries)))
        self.compact_intent = bool(compact_intent)

    @classmethod
    def from_openai(
        cls,
        *,
        base_url: str,
        api_key: str,
        model: str,
        timeout: float = 60.0,
        temperature: float = 0.0,
        max_tokens: int = 4096,
        max_input_chars: int = 80_000,
        max_segment_input_chars: int | None = None,
        max_retries: int = 2,
        extra_body: dict[str, Any] | None = None,
        compact_intent: bool = False,
        output_mode: Literal["instructor", "prompted"] = "instructor",
    ) -> MinerUInstructorExtractor:
        """Build a structured transport for an OpenAI-compatible endpoint.

        ``instructor`` remains the explicit compatibility mode.  Production
        full-authority uses ``prompted`` because local vLLM endpoints are not
        required to implement OpenAI ``response_format`` JSON Schema.
        """

        if output_mode == "prompted":
            try:
                from ...structured_llm import StructuredModelClient
            except ImportError as exc:  # pragma: no cover - dependency contract
                raise InstructorUnavailableError(
                    "Prompted MinerU extraction requires the structured model client"
                ) from exc
            structured_client = StructuredModelClient(
                api_key=api_key or "EMPTY",
                base_url=base_url,
                model=model,
                temperature=float(temperature),
                max_tokens=max(1, int(max_tokens)),
                enable_thinking=False,
                timeout=max(0.001, float(timeout)),
                retries=max(0, min(2, int(max_retries))),
                output_mode="prompted",
                validation_retry_timeout_per_attempt=True,
            )
            return cls(
                client=_PromptedOutputTransport(structured_client, model=model),
                max_input_chars=max_input_chars,
                max_segment_input_chars=max_segment_input_chars,
                max_retries=max_retries,
                compact_intent=compact_intent,
            )

        try:
            import instructor
        except ImportError as exc:  # pragma: no cover - depends on optional package
            raise InstructorUnavailableError(
                "The MinerU Instructor POC requires the optional 'instructor' package; "
                "install it in an isolated experiment before enabling this POC."
            ) from exc
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:  # pragma: no cover - declared M1 dependency
            raise InstructorUnavailableError(
                "The OpenAI client is unavailable"
            ) from exc
        raw_client = AsyncOpenAI(
            api_key=api_key or "EMPTY",
            base_url=base_url.rstrip("/"),
            timeout=max(0.001, float(timeout)),
            max_retries=0,
        )
        transport = _OpenAIInstructorTransport(
            client=instructor.from_openai(
                raw_client,
                mode=instructor.Mode.JSON_SCHEMA,
            ),
            raw_client=raw_client,
            model=model,
            temperature=float(temperature),
            max_tokens=max(1, int(max_tokens)),
            extra_body=extra_body,
        )
        return cls(
            client=transport,
            max_input_chars=max_input_chars,
            max_segment_input_chars=max_segment_input_chars,
            max_retries=max_retries,
            compact_intent=compact_intent,
        )

    @classmethod
    def from_ollama_native(
        cls,
        *,
        base_url: str,
        model: str,
        timeout: float = 60.0,
        temperature: float = 0.0,
        max_tokens: int = 4096,
        num_ctx: int = 16_384,
        max_input_chars: int = 80_000,
        max_segment_input_chars: int | None = None,
        max_retries: int = 2,
        transport: httpx.AsyncBaseTransport | None = None,
        compact_intent: bool = False,
    ) -> MinerUInstructorExtractor:
        """Use Ollama's native structured-output API with thinking disabled."""

        return cls(
            client=_OllamaNativeTransport(
                base_url=base_url,
                model=model,
                timeout=timeout,
                temperature=temperature,
                max_tokens=max_tokens,
                num_ctx=num_ctx,
                transport=transport,
            ),
            max_input_chars=max_input_chars,
            max_segment_input_chars=max_segment_input_chars,
            max_retries=max_retries,
            compact_intent=compact_intent,
        )

    async def close(self) -> None:
        """Close an owned optional transport when it exposes a close hook."""

        close = getattr(self._client, "close", None)
        if not callable(close):
            return
        result = close()
        if inspect.isawaitable(result):
            await result

    async def probe(self) -> dict[str, Any]:
        """Probe an owned transport without issuing a generation request."""

        probe = getattr(self._client, "probe", None)
        if not callable(probe):
            return {"ready": True, "configured": True}
        result = probe()
        if inspect.isawaitable(result):
            result = await result
        return result if isinstance(result, dict) else {"ready": True}

    async def extract(
        self,
        evidence: DocumentEvidence,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUInstructorResult:
        """Return typed facts plus every locally retained but unmapped source value."""

        if semantic_execution is not None:
            SemanticStrategyExecutor.validate_capability(semantic_execution)
            max_input_chars = SemanticStrategyExecutor.effective_input_limit(
                semantic_execution,
                self.max_input_chars,
            )
            max_segment_input_chars = SemanticStrategyExecutor.effective_input_limit(
                semantic_execution,
                self.max_segment_input_chars,
            )
        else:
            max_input_chars = self.max_input_chars
            max_segment_input_chars = self.max_segment_input_chars
        model_input_chars = (
            min(max_input_chars, 5_000) if self.compact_intent else max_input_chars
        )
        classification_input_chars = (
            min(max_input_chars, 12_000)
            if self.compact_intent
            else max_input_chars
        )
        model_segment_input_chars = (
            min(max_segment_input_chars, 5_000)
            if self.compact_intent
            else max_segment_input_chars
        )
        model_request_limit = _DEFAULT_MODEL_REQUEST_LIMIT
        if semantic_execution is not None:
            model_request_limit = min(
                model_request_limit,
                semantic_execution.budget.max_model_requests,
            )
        model_request_count = 0
        model_budget_skips: dict[str, int] = {}
        model_diagnostics: list[ModelFailureDiagnostic] = []
        route_context, route_context_issues = _document_route_context(evidence)
        trusted_initial_intent = _trusted_fallback_document_intent(
            evidence,
            route_context,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
        )
        trusted_family = _document_intent_family(trusted_initial_intent or "")
        _native_type, trusted_native_subtype = _trusted_native_classification(evidence)
        trusted_native_open_domain = (
            trusted_native_subtype in OPEN_DOMAIN_DOCUMENT_SUBTYPES
        )
        derived_geometry_table_ids = (
            []
            if trusted_native_open_domain
            or trusted_family not in {"unknown", "technical_document"}
            else _augment_geometry_tables(evidence)
        )

        def model_request_available() -> bool:
            return model_request_count < model_request_limit

        def note_model_budget_skip(role: str, count: int = 1) -> None:
            model_budget_skips[role] = model_budget_skips.get(role, 0) + max(1, count)

        def append_model_budget_issue(issues: list[str]) -> None:
            if not model_budget_skips:
                return
            skipped = ",".join(
                f"{role}={model_budget_skips[role]}"
                for role in sorted(model_budget_skips)
            )
            issues.append(
                f"model_request_budget_exhausted:limit={model_request_limit}:{skipped}"
            )

        async def create_model_output(
            response_model: type[T],
            *,
            role: str,
            messages: list[dict[str, str]],
            max_retries: int,
        ) -> T:
            nonlocal model_request_count
            if semantic_execution is not None:
                mapper_role = _SEMANTIC_EXECUTION_ROLES.get(role)
                if mapper_role is None:
                    raise ValueError(
                        f"semantic execution role is not registered: {role}"
                    )
                expected_schema = SemanticStrategyExecutor.output_schema_name(
                    semantic_execution,
                    role=mapper_role,
                )
                if expected_schema != response_model.__name__:
                    raise ValueError(
                        "semantic execution output schema does not match mapper role"
                    )
            if not model_request_available():
                note_model_budget_skip(role)
                raise SemanticExecutionBudgetExceeded(
                    "semantic execution model request budget exhausted"
                )
            model_request_count += 1
            try:
                return await self._client.create(
                    response_model,
                    messages=messages,
                    max_retries=max_retries,
                )
            except Exception as exc:
                # Diagnostics are best effort and must never replace the
                # existing compatibility issue or alter fallback behavior.
                with suppress(Exception):
                    model_diagnostics.append(
                        _model_failure_diagnostic(
                            stage=role,
                            response_model=response_model,
                            exception=exc,
                        )
                    )
                raise

        inventory = evidence_inventory(evidence)
        tables = _table_index(evidence)
        route_policy_advice = route_context.policy_advice()
        issues: list[str] = list(route_context_issues)
        if derived_geometry_table_ids:
            issues.append(
                "technical_geometry_rows_reconstructed:"
                + ",".join(derived_geometry_table_ids)
            )
        for item in inventory.values():
            if not item.positioned:
                issues.append(f"unpositioned_table_value:{item.evidence_id}")
        consumed: set[str] = set()
        schema_consumed: set[str] = set()
        redundant_evidence = _redundant_table_block_ids(evidence)
        intent_calls = 0
        segment_calls = 0
        record_kind_calls = 0
        fallback_intent = "unknown"

        def trusted_fallback_intent() -> str:
            """Use only explicit evidence or governed hints after model failure."""

            return trusted_initial_intent or fallback_intent

        record_region_assessment = assess_record_regions(evidence)
        document_fact_allowed_ids = _document_fact_allowed_evidence_ids(
            inventory,
            record_region_assessment,
        )
        if self.compact_intent:
            native_type, native_subtype = _trusted_native_classification(evidence)
            if native_type and native_subtype and not document_subtype_hint:
                classification = DocumentClassification(
                    document_intent=native_type,
                    document_kind_label=native_subtype,
                    document_subtype=native_subtype,
                )
                issues.append("native_document_classification_applied")
            else:
                _classification_payload, intent_messages = (
                    _compact_classification_messages(
                        evidence,
                        max_input_chars=classification_input_chars,
                        semantic_execution=semantic_execution,
                    )
                )
                if _prompt_size(intent_messages) > classification_input_chars:
                    issues.append("intent_input_limit_exceeded")
                    classification = DocumentClassification(
                        document_intent=_document_intent_family(
                            trusted_fallback_intent()
                        )
                    )
                else:
                    intent_calls += 1
                    try:
                        classification = await create_model_output(
                            DocumentClassification,
                            role="document_classification",
                            messages=intent_messages,
                            max_retries=0,
                        )
                    except Exception as exc:  # noqa: BLE001 - local fallback remains
                        issues.append(f"intent_model_error:{exc.__class__.__name__}")
                        classification = DocumentClassification(
                            document_intent=_document_intent_family(
                                trusted_fallback_intent()
                            )
                        )
            kind_family = _document_intent_family(
                classification.document_kind_label or ""
            )
            subtype_family = _document_intent_family(
                classification.document_subtype or ""
            )
            specific_families = {
                family
                for family in (kind_family, subtype_family)
                if family != "unknown"
            }
            declared_family = classification.document_intent
            if (
                declared_family not in specific_families
                and len(specific_families) == 1
                and trusted_family in specific_families
            ):
                reconciled_family = next(iter(specific_families))
                issues.append(
                    "document_classification_trusted_family_reconciled:"
                    f"{declared_family}:{reconciled_family}"
                )
                classification = classification.model_copy(
                    update={"document_intent": reconciled_family},
                    deep=True,
                )
                declared_family = reconciled_family
            if (
                kind_family != "unknown"
                and kind_family != declared_family
            ):
                issues.append(
                    "document_classification_consistency_repair:"
                    f"{declared_family}:{kind_family}"
                )
            proposed_facts: list[ProposedFact] = []
            proposed_content: list[ProposedContentBinding] = []
            semantic_probe = DocumentIntent(
                document_intent=classification.document_intent,
                document_kind_label=classification.document_kind_label,
                document_subtype=classification.document_subtype,
                primary_record_table_ids=classification.primary_record_table_ids,
            )
            semantic_probe, semantic_route_applicable = (
                _apply_guarded_route_classification(
                    semantic_probe,
                    evidence,
                    route_context,
                    document_type_hint=document_type_hint,
                    document_subtype_hint=document_subtype_hint,
                )
            )
            semantic_intent = semantic_probe.document_intent
            semantic_subtype = _resolved_document_subtype(
                semantic_probe,
                evidence,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
                issues=issues,
            )
            document_context = _fact_target_context(
                semantic_intent,
                semantic_subtype,
                generic_facts_only=(
                    semantic_route_applicable and route_context.generic_facts_only
                )
                or semantic_subtype in OPEN_DOMAIN_DOCUMENT_SUBTYPES,
            )
            block_payloads = (
                []
                if _is_native_spreadsheet_evidence(evidence)
                else _block_semantic_payloads(
                    evidence,
                    max_input_chars=model_input_chars,
                )
            )
            for block_index, block_payload in enumerate(block_payloads):
                payload = {
                    **block_payload,
                    "document_context": document_context,
                }
                messages = _messages(
                    role="block_semantics",
                    payload=payload,
                    semantic_execution=semantic_execution,
                )
                if _prompt_size(messages) > model_input_chars:
                    issues.append("block_semantics_input_limit_exceeded")
                    continue
                if not model_request_available():
                    note_model_budget_skip(
                        "block_semantics",
                        len(block_payloads) - block_index,
                    )
                    break
                intent_calls += 1
                try:
                    semantics = await create_model_output(
                        BlockSemantics,
                        role="block_semantics",
                        messages=messages,
                        max_retries=0,
                    )
                except Exception as exc:  # noqa: BLE001 - content stays retained
                    issues.append(
                        f"block_semantics_model_error:{exc.__class__.__name__}"
                    )
                    continue
                for proposal in semantics.document_facts:
                    proposal_payload = proposal.model_dump(mode="json")
                    if not any(
                        (
                            str(proposal_payload.get("name") or "").strip(),
                            str(proposal_payload.get("value") or "").strip(),
                            proposal_payload.get("citations") or [],
                            bool(proposal_payload.get("sensitive")),
                        )
                    ):
                        # Small models commonly emit one all-empty optional item.
                        # It is an omitted proposal, not a rejected fact.
                        continue
                    try:
                        proposed_facts.append(
                            ProposedFact.model_validate(proposal_payload)
                        )
                    except ValidationError:
                        issues.append(
                            "ignored_model_fact:invalid_block_semantics_proposal"
                        )
                for proposal in semantics.content_bindings:
                    proposal_payload = proposal.model_dump(mode="json")
                    if not any(
                        str(proposal_payload.get(field) or "").strip()
                        for field in ("evidence_id", "content_kind", "label")
                    ):
                        continue
                    try:
                        proposed_content.append(
                            ProposedContentBinding.model_validate(proposal_payload)
                        )
                    except ValidationError:
                        issues.append(
                            "invalid_content_binding:invalid_block_semantics_proposal"
                        )
            intent = DocumentIntent(
                document_intent=classification.document_intent,
                document_kind_label=classification.document_kind_label,
                document_subtype=classification.document_subtype,
                primary_record_table_ids=(classification.primary_record_table_ids),
                document_facts=proposed_facts,
                content_bindings=proposed_content,
            )
        else:
            intent_role = (
                "document_intent_local_partition"
                if record_region_assessment.status == "complete"
                else "document_and_table_intent"
            )
            intent_payload = _evidence_payload(evidence)
            intent_payload.update(
                {
                    "allowed_document_types": sorted(_ROUTE_DOCUMENT_TYPES),
                    "document_type_definitions": _DOCUMENT_TYPE_DEFINITIONS,
                    "allowed_document_subtypes": sorted(_ROUTE_DOCUMENT_SUBTYPE_TYPES),
                    "document_subtype_definitions": _DOCUMENT_SUBTYPE_DEFINITIONS,
                }
            )
            intent_messages = _messages(
                role=intent_role,
                payload=intent_payload,
                semantic_execution=semantic_execution,
            )
            intent_recovered = False
            if _prompt_size(intent_messages) > model_input_chars:
                issues.append("intent_input_limit_exceeded")
                seed_intent = DocumentIntent(document_intent=trusted_fallback_intent())
                intent = _safe_technical_partition_fallback(
                    seed_intent,
                    tables,
                    record_region_assessment,
                    issues,
                )
                if intent is None:
                    if not record_region_assessment.record_regions:
                        return self._result(
                            document_intent=seed_intent.document_intent,
                            document_facts=[],
                            segments=[],
                            inventory=inventory,
                            consumed=consumed,
                            issues=issues,
                            intent_calls=intent_calls,
                            segment_calls=segment_calls,
                            model_diagnostics=model_diagnostics,
                            route_policy_advice=route_policy_advice,
                        )
                    intent = seed_intent
                intent_recovered = True

            if not intent_recovered:
                intent_calls += 1
                try:
                    intent = await create_model_output(
                        DocumentIntent,
                        role=intent_role,
                        messages=intent_messages,
                        max_retries=self.max_retries,
                    )
                except Exception as exc:  # noqa: BLE001 - retain auditable evidence
                    issues.append(f"intent_model_error:{exc.__class__.__name__}")
                    seed_intent = DocumentIntent(
                        document_intent=trusted_fallback_intent()
                    )
                    fallback_partition = _safe_technical_partition_fallback(
                        seed_intent,
                        tables,
                        record_region_assessment,
                        issues,
                    )
                    if fallback_partition is not None:
                        intent = fallback_partition
                    elif not record_region_assessment.record_regions:
                        return self._result(
                            document_intent=fallback_intent,
                            document_facts=[],
                            segments=[],
                            inventory=inventory,
                            consumed=consumed,
                            issues=issues,
                            intent_calls=intent_calls,
                            segment_calls=segment_calls,
                            model_diagnostics=model_diagnostics,
                            route_policy_advice=route_policy_advice,
                        )
                    else:
                        intent = seed_intent
        intent, route_classification_applicable = _apply_guarded_route_classification(
            intent,
            evidence,
            route_context,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            issues=issues,
        )
        intent = _normalize_intent_partition(
            intent,
            tables,
            evidence,
            issues=issues,
            complete_missing=trusted_native_open_domain,
        )
        table_roles = (
            {}
            if trusted_native_open_domain
            else _route_table_roles_by_id(tables, route_context, issues)
        )
        if not trusted_native_open_domain:
            table_roles = _migrate_route_roles_to_geometry_tables(
                tables,
                table_roles,
                derived_geometry_table_ids,
                document_intent=intent.document_intent,
                issues=issues,
            )
            intent = _apply_geometry_table_partition(
                intent,
                tables,
                derived_geometry_table_ids,
                issues,
            )
        if (
            not trusted_native_open_domain
            and "technical_partition_fallback:evidence_shape" in issues
        ):
            safe_partition = _safe_technical_partition_fallback(
                intent,
                tables,
                record_region_assessment,
                issues,
                emit_issue=False,
            )
            if safe_partition is not None:
                intent = safe_partition
        if trusted_native_open_domain:
            primary_record_table_ids = [
                table.table_id
                for table in intent.tables
                if any(segment.intent == "records" for segment in table.segments)
            ]
        else:
            intent = _apply_route_table_partitions(intent, tables, table_roles)
            primary_record_table_ids = _select_primary_record_table_ids(
                intent,
                tables,
                record_region_assessment,
                issues,
            )
            primary_record_table_ids = _apply_route_primary_table_policy(
                primary_record_table_ids,
                tables,
                record_region_assessment,
                table_roles,
                issues,
                document_intent=intent.document_intent,
            )
            intent = _align_geometry_primary_partition(
                intent,
                tables,
                derived_geometry_table_ids,
                primary_record_table_ids,
                issues,
            )
            intent = _refine_technical_primary_table_segments(
                intent,
                tables,
                primary_record_table_ids,
                issues,
                assessment=record_region_assessment,
            )
        document_subtype = _resolved_document_subtype(
            intent,
            evidence,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            issues=issues,
        )
        canonical_document_intent = _document_intent_family(intent.document_intent)
        document_kind_label = intent.document_kind_label or intent.document_intent
        kind_family = _document_intent_family(document_kind_label)
        if (
            canonical_document_intent != "unknown"
            and kind_family != "unknown"
            and kind_family != canonical_document_intent
        ):
            issues.append(
                "document_classification_consistency_repair:"
                f"{canonical_document_intent}:{kind_family}"
            )
            document_kind_label = document_subtype or canonical_document_intent
        elif canonical_document_intent != "unknown" and kind_family == "unknown":
            document_kind_label = document_subtype or canonical_document_intent
            issues.append("document_kind_label_inferred_from_evidence")
        if canonical_document_intent != intent.document_intent:
            intent = intent.model_copy(
                update={"document_intent": canonical_document_intent},
                deep=True,
            )
        generic_facts_only = (
            route_classification_applicable and route_context.generic_facts_only
        ) or document_subtype in OPEN_DOMAIN_DOCUMENT_SUBTYPES
        fallback_intent = intent.document_intent
        document_facts: list[ExtractedFact] = []
        generic_facts: list[ExtractedFact] = []
        for proposed in intent.document_facts:
            proposed = _normalize_fact_citations(proposed, inventory)
            is_generic = generic_facts_only
            if self.compact_intent:
                allowed_names = set(
                    _fact_target_context(
                        intent.document_intent,
                        document_subtype,
                        generic_facts_only=generic_facts_only,
                    )["allowed_fact_names"]
                )
                canonical_name = _canonical_fact_name(
                    proposed.name,
                    allowed_names,
                )
                if canonical_name is None:
                    is_generic = True
                else:
                    proposed = proposed.model_copy(update={"name": canonical_name})
                    proposed = _narrow_proposed_fact_value(proposed, inventory)
            original_proposed = proposed
            proposed = _repair_document_fact_from_evidence(
                proposed,
                inventory,
                allowed_ids=document_fact_allowed_ids,
            )
            if proposed != original_proposed:
                repair_issue = (
                    "document_fact_evidence_repaired:"
                    f"{original_proposed.name}:{proposed.name}"
                )
                if repair_issue not in issues:
                    issues.append(repair_issue)
            table_id_citations = [
                evidence_id
                for evidence_id in proposed.citations
                if evidence_id in tables
            ]
            if table_id_citations:
                issues.append(
                    "ignored_model_fact:table_id_is_not_citation:"
                    f"{proposed.name}:{','.join(table_id_citations)}"
                )
                continue
            forbidden_citations = [
                evidence_id
                for evidence_id in proposed.citations
                if evidence_id not in document_fact_allowed_ids
            ]
            if forbidden_citations:
                issues.append(
                    "ignored_model_fact:record_or_schema_evidence:"
                    f"{proposed.name}:{','.join(forbidden_citations)}"
                )
                continue
            fact_issues: list[str] = []
            fact, fact_consumed = _validated_fact(
                proposed,
                inventory,
                allowed_ids=None,
                issues=fact_issues,
                allow_table_substring=True,
            )
            if fact is None:
                issues.extend(f"ignored_model_fact:{issue}" for issue in fact_issues)
                continue
            issues.extend(fact_issues)
            consumed.update(fact_consumed)
            if is_generic:
                generic_facts.append(fact)
                issues.append(f"unmapped_supported_fact:{fact.name}")
            else:
                _append_document_fact(document_facts, fact)

        partition_issues: list[str] = []
        planned_segments = _validate_intent_partition(
            intent,
            tables,
            partition_issues,
        )
        if any(
            issue.startswith(_PARTITION_ISSUE_PREFIXES) for issue in partition_issues
        ):
            correction_recovered = False
            correction_role = (
                "table_partition_correction"
                if self.compact_intent
                else "document_and_table_intent_correction"
            )
            correction_model: type[BaseModel] = (
                TablePartition if self.compact_intent else DocumentIntent
            )
            correction_messages = _messages(
                role=correction_role,
                payload=_intent_correction_payload(
                    intent,
                    tables,
                    partition_issues,
                    table_only=self.compact_intent,
                ),
                semantic_execution=semantic_execution,
            )
            if _prompt_size(correction_messages) > model_input_chars:
                issues.extend(partition_issues)
                issues.append("intent_partition_correction_input_limit_exceeded")
                fallback_partition = _safe_technical_partition_fallback(
                    intent,
                    tables,
                    record_region_assessment,
                    issues,
                )
                intent = fallback_partition or _normalize_intent_partition(
                    intent,
                    tables,
                    evidence,
                    issues=issues,
                    complete_missing=True,
                )
                correction = intent
                correction_recovered = True
                planned_segments = _validate_intent_partition(
                    intent,
                    tables,
                    [],
                )
            intent_calls += 0 if correction_recovered else 1
            try:
                correction = (
                    intent
                    if correction_recovered
                    else await create_model_output(
                        correction_model,
                        role=correction_role,
                        messages=correction_messages,
                        max_retries=self.max_retries,
                    )
                )
            except Exception as exc:  # noqa: BLE001 - POC must fail closed
                issues.extend(partition_issues)
                issues.append(
                    f"intent_partition_correction_error:{exc.__class__.__name__}"
                )
                fallback_partition = _safe_technical_partition_fallback(
                    intent,
                    tables,
                    record_region_assessment,
                    issues,
                )
                intent = fallback_partition or _normalize_intent_partition(
                    intent,
                    tables,
                    evidence,
                    issues=issues,
                    complete_missing=True,
                )
                correction = intent
                planned_segments = _validate_intent_partition(
                    intent,
                    tables,
                    [],
                )
            corrected_intent = intent.model_copy(
                update={"tables": correction.tables},
                deep=True,
            )
            corrected_intent = _normalize_intent_partition(
                corrected_intent,
                tables,
                evidence,
                issues=issues,
                complete_missing=True,
            )
            corrected_intent = _apply_geometry_table_partition(
                corrected_intent,
                tables,
                derived_geometry_table_ids,
                issues,
            )
            if "technical_partition_fallback:evidence_shape" in issues:
                safe_partition = _safe_technical_partition_fallback(
                    corrected_intent,
                    tables,
                    record_region_assessment,
                    issues,
                    emit_issue=False,
                )
                if safe_partition is not None:
                    corrected_intent = safe_partition
            corrected_intent = _apply_route_table_partitions(
                corrected_intent,
                tables,
                table_roles,
            )
            corrected_intent = _align_geometry_primary_partition(
                corrected_intent,
                tables,
                derived_geometry_table_ids,
                primary_record_table_ids,
                issues,
            )
            corrected_intent = _refine_technical_primary_table_segments(
                corrected_intent,
                tables,
                primary_record_table_ids,
                issues,
                assessment=record_region_assessment,
            )
            corrected_issues: list[str] = []
            corrected_segments = _validate_intent_partition(
                corrected_intent,
                tables,
                corrected_issues,
            )
            if any(
                issue.startswith(_PARTITION_ISSUE_PREFIXES)
                for issue in corrected_issues
            ):
                issues.extend(partition_issues)
                issues.extend(corrected_issues)
                issues.append("intent_partition_correction_failed")
                safe_seed = intent.model_copy(update={"tables": []}, deep=True)
                intent = _normalize_intent_partition(
                    safe_seed,
                    tables,
                    evidence,
                    issues=issues,
                    complete_missing=True,
                )
                corrected_segments = _validate_intent_partition(
                    intent,
                    tables,
                    [],
                )
            planned_segments = corrected_segments

        if generic_facts_only:
            # The production open-domain projector emits exact table_schema and
            # table_record facts directly from DocumentEvidence. Building a
            # second ExtractedRecord graph here duplicates every cell and its
            # SourceReference, only for _production_document() to clear those
            # temporary typed lines. Preserve the complete physical partition
            # and account for every cell as schema-less table evidence instead.
            projected_segments: list[ExtractedSegment] = []
            for segment in planned_segments:
                projected_segments.append(
                    ExtractedSegment(
                        table_id=segment.table_id,
                        segment_id=segment.segment_id,
                        intent=segment.intent,
                        orientation=segment.orientation,
                        start=segment.start,
                        end=segment.end,
                    )
                )
            # The next candidate stage converts every table cell into a cited
            # generic fact. Account for that local projection now; otherwise
            # _result() materializes tens of thousands of duplicate schema and
            # unmapped references before those same facts are built again.
            consumed.update(
                evidence_id
                for evidence_id, item in inventory.items()
                if item.table_id is not None
            )
            append_model_budget_issue(issues)
            return self._result(
                document_intent=intent.document_intent,
                document_kind_label=document_kind_label,
                document_subtype=document_subtype,
                primary_record_table_ids=primary_record_table_ids,
                document_facts=document_facts,
                generic_facts=generic_facts,
                segments=projected_segments,
                inventory=inventory,
                consumed=consumed,
                schema_consumed=schema_consumed,
                redundant_evidence=redundant_evidence,
                content_bindings=intent.content_bindings,
                issues=issues,
                intent_calls=intent_calls,
                segment_calls=segment_calls,
                model_diagnostics=model_diagnostics,
                route_policy_advice=route_policy_advice,
            )

        layout_segments: list[ExtractedSegment] = []
        extraction_segments: list[tuple[_ValidatedSegment, bool]] = []
        for segment in planned_segments:
            table = tables[segment.table_id]
            if segment.intent == "layout":
                schema_consumed.update(_segment_evidence_ids(inventory, segment))
                layout_segments.append(
                    ExtractedSegment(
                        table_id=segment.table_id,
                        segment_id=segment.segment_id,
                        intent=segment.intent,
                        orientation=segment.orientation,
                        start=segment.start,
                        end=segment.end,
                    )
                )
                continue
            if segment.intent == "records":
                extraction_segments.append((segment, True))
                continue
            chunks = _split_segment_for_budget(
                table,
                segment,
                max_input_chars=model_segment_input_chars,
            )
            if not chunks:
                issues.append(f"segment_input_limit_exceeded:{segment.segment_id}")
                continue
            extraction_segments.extend((chunk, False) for chunk in chunks)

        extracted_segments: list[ExtractedSegment] = list(layout_segments)
        record_mapping_cache: dict[tuple[Any, ...], dict[int, str]] = {}
        document_type = _intent_route_type(intent.document_intent)
        for segment, use_field_mapping in extraction_segments:
            table = tables[segment.table_id]
            if use_field_mapping:
                schema_consumed.update(_record_schema_evidence_ids(inventory, segment))
                mapping_payload = _long_record_mapping_payload(
                    table,
                    segment,
                    document_type=document_type,
                )
                fallback_field_names = _evidence_backed_field_names(
                    table,
                    segment,
                    document_type=document_type,
                )
                field_names: dict[int, str]
                # Open-domain tables are projected losslessly from local evidence
                # after extraction. A model mapping here would only build temporary
                # typed lines that production deliberately clears, while adding one
                # request per distinct table schema. Keep the physical record
                # segments for the region-contract gate, but name their fields from
                # evidence locally.
                if (
                    generic_facts_only
                    or segment.table_id not in primary_record_table_ids
                ):
                    field_names = fallback_field_names
                else:
                    expected_count = mapping_payload["field_axis"]["count"]
                    mapping_key = _record_mapping_schema_key(
                        table,
                        segment,
                        document_type=document_type,
                        field_axis_count=expected_count,
                    )
                    cached_field_names = record_mapping_cache.get(mapping_key)
                    if cached_field_names is not None:
                        field_names = dict(cached_field_names)
                    else:
                        mapping_messages = _messages(
                            role="long_record_field_mapping",
                            payload=mapping_payload,
                            semantic_execution=semantic_execution,
                        )
                        if _prompt_size(mapping_messages) > model_segment_input_chars:
                            issues.append(
                                "long_record_field_mapping_fallback:"
                                f"{segment.segment_id}:input_limit"
                            )
                            field_names = fallback_field_names
                        elif not model_request_available():
                            note_model_budget_skip("long_record_field_mapping")
                            field_names = fallback_field_names
                        else:
                            segment_calls += 1
                            try:
                                mapping = await create_model_output(
                                    RecordFieldMapping,
                                    role="long_record_field_mapping",
                                    messages=mapping_messages,
                                    max_retries=min(
                                        self.max_retries,
                                        _RECORD_MAPPING_MAX_RETRIES,
                                    ),
                                )
                                field_names = _field_names_from_mapping(
                                    mapping,
                                    orientation=segment.orientation,
                                    expected_count=expected_count,
                                    fallback_names=fallback_field_names,
                                    document_type=document_type,
                                )
                            except Exception as exc:  # noqa: BLE001 - local fallback
                                issues.append(
                                    "long_record_field_mapping_fallback:"
                                    f"{segment.segment_id}:{exc.__class__.__name__}"
                                )
                                field_names = fallback_field_names
                        record_mapping_cache[mapping_key] = dict(field_names)
                records, record_consumed = _project_long_record_segment(
                    table,
                    segment,
                    inventory,
                    field_names,
                )
                records = _merge_adjacent_duplicate_records(
                    records,
                    table=table,
                    segment=segment,
                    inventory=inventory,
                    issues=issues,
                )
                consumed.update(record_consumed)
                extracted_segments.append(
                    ExtractedSegment(
                        table_id=segment.table_id,
                        segment_id=segment.segment_id,
                        intent=segment.intent,
                        orientation=segment.orientation,
                        start=segment.start,
                        end=segment.end,
                        records=records,
                    )
                )
                continue
            if _is_native_spreadsheet_evidence(evidence):
                if segment.intent == "metadata":
                    facts, fallback_consumed = _local_metadata_fallback(
                        table,
                        segment,
                        inventory,
                        already_consumed=consumed,
                    )
                    consumed.update(fallback_consumed)
                    if facts:
                        extracted_segments.append(
                            ExtractedSegment(
                                table_id=segment.table_id,
                                segment_id=segment.segment_id,
                                intent=segment.intent,
                                orientation=segment.orientation,
                                start=segment.start,
                                end=segment.end,
                                facts=facts,
                            )
                        )
                continue
            segment_payload = _segment_payload(table, segment)
            segment_payload["document_context"] = _fact_target_context(
                intent.document_intent,
                document_subtype,
                generic_facts_only=generic_facts_only,
            )
            segment_messages = _messages(
                role="segment_extraction",
                payload=segment_payload,
                semantic_execution=semantic_execution,
            )
            if _prompt_size(segment_messages) > model_segment_input_chars:
                issues.append(f"segment_input_limit_exceeded:{segment.segment_id}")
                continue
            if not model_request_available():
                note_model_budget_skip("segment_extraction")
                if segment.intent == "metadata":
                    facts, fallback_consumed = _local_metadata_fallback(
                        table,
                        segment,
                        inventory,
                        already_consumed=consumed,
                    )
                    consumed.update(fallback_consumed)
                    if facts:
                        extracted_segments.append(
                            ExtractedSegment(
                                table_id=segment.table_id,
                                segment_id=segment.segment_id,
                                intent=segment.intent,
                                orientation=segment.orientation,
                                start=segment.start,
                                end=segment.end,
                                facts=facts,
                            )
                        )
                continue
            segment_calls += 1
            try:
                response = await create_model_output(
                    SegmentExtraction,
                    role="segment_extraction",
                    messages=segment_messages,
                    max_retries=self.max_retries,
                )
            except Exception as exc:  # noqa: BLE001 - isolate one failed segment
                issues.append(
                    f"segment_model_error:{segment.segment_id}:{exc.__class__.__name__}"
                )
                if segment.intent == "records":
                    records, record_consumed = _project_long_record_segment(
                        table,
                        segment,
                        inventory,
                        _evidence_backed_field_names(
                            table,
                            segment,
                            document_type=document_type,
                        ),
                    )
                    consumed.update(record_consumed)
                    extracted_segments.append(
                        ExtractedSegment(
                            table_id=segment.table_id,
                            segment_id=segment.segment_id,
                            intent=segment.intent,
                            orientation=segment.orientation,
                            start=segment.start,
                            end=segment.end,
                            records=records,
                        )
                    )
                elif segment.intent == "metadata":
                    facts, fallback_consumed = _local_metadata_fallback(
                        table,
                        segment,
                        inventory,
                        already_consumed=consumed,
                    )
                    consumed.update(fallback_consumed)
                    if facts:
                        extracted_segments.append(
                            ExtractedSegment(
                                table_id=segment.table_id,
                                segment_id=segment.segment_id,
                                intent=segment.intent,
                                orientation=segment.orientation,
                                start=segment.start,
                                end=segment.end,
                                facts=facts,
                            )
                        )
                continue
            allowed_ids = _segment_evidence_ids(inventory, segment)
            facts: list[ExtractedFact] = []
            if segment.intent == "records" and response.facts:
                issues.append(f"facts_in_records_segment:{segment.segment_id}")
            if segment.intent != "records" and response.records:
                issues.append(f"records_in_nonrecord_segment:{segment.segment_id}")
            proposed_facts = (
                _strict_segment_fact_proposals(
                    response.facts,
                    segment_id=segment.segment_id,
                    issues=issues,
                )
                if segment.intent != "records"
                else []
            )
            proposed_records = (
                _strict_segment_record_proposals(
                    response.records,
                    segment_id=segment.segment_id,
                    issues=issues,
                )
                if segment.intent == "records"
                else []
            )
            for proposed in proposed_facts:
                proposed = _normalize_fact_citations(proposed, inventory)
                is_generic = generic_facts_only
                if self.compact_intent:
                    allowed_names = set(
                        _fact_target_context(
                            intent.document_intent,
                            document_subtype,
                            generic_facts_only=generic_facts_only,
                        )["allowed_fact_names"]
                    )
                    canonical_name = _canonical_fact_name(
                        proposed.name,
                        allowed_names,
                    )
                    if canonical_name is None:
                        is_generic = True
                    else:
                        proposed = proposed.model_copy(update={"name": canonical_name})
                        proposed = _narrow_proposed_fact_value(proposed, inventory)
                fact, fact_consumed = _validated_fact(
                    proposed,
                    inventory,
                    allowed_ids=allowed_ids,
                    issues=issues,
                    allow_table_substring=True,
                )
                consumed.update(fact_consumed)
                if fact is not None:
                    if is_generic:
                        generic_facts.append(fact)
                        issues.append(f"unmapped_supported_fact:{fact.name}")
                    else:
                        facts.append(fact)
            records: list[ExtractedRecord] = []
            for proposed_record in proposed_records:
                record_facts: list[ExtractedFact] = []
                for proposed in proposed_record.fields:
                    fact, fact_consumed = _validated_fact(
                        proposed,
                        inventory,
                        allowed_ids=allowed_ids,
                        issues=issues,
                    )
                    consumed.update(fact_consumed)
                    if fact is not None:
                        record_facts.append(fact)
                if record_facts:
                    record_ids = {
                        reference.evidence_id
                        for fact in record_facts
                        for reference in fact.evidence_refs
                    }
                    kind_citations = list(
                        dict.fromkeys(
                            evidence_id
                            for evidence_id in proposed_record.record_kind_citations
                            if evidence_id in allowed_ids and evidence_id in record_ids
                        )
                    )
                    if (
                        proposed_record.record_kind != "unknown"
                        and not kind_citations
                    ):
                        issues.append(
                            "record_kind_mapping_fallback:"
                            f"{segment.segment_id}:missing_record_citation"
                        )
                    extracted_record = ExtractedRecord(
                        fields=record_facts,
                        record_kind=(
                            proposed_record.record_kind
                            if kind_citations
                            else "unknown"
                        ),
                        record_kind_evidence_refs=[
                            _evidence_reference(inventory[evidence_id])
                            for evidence_id in (
                                kind_citations or sorted(record_ids)[:12]
                            )
                            if evidence_id in inventory
                        ],
                        record_kind_source=(
                            "model" if kind_citations else "local_fallback"
                        ),
                        record_axis=None,
                    )
                    records.append(
                        extracted_record.model_copy(
                            update={
                                "record_axis": _record_axis(
                                    extracted_record,
                                    inventory,
                                    segment,
                                )
                            }
                        )
                    )
            if segment.intent == "metadata":
                fallback_facts, fallback_consumed = _local_metadata_fallback(
                    table,
                    segment,
                    inventory,
                    already_consumed=consumed,
                )
                facts.extend(fallback_facts)
                consumed.update(fallback_consumed)
            records = _merge_adjacent_duplicate_records(
                records,
                table=table,
                segment=segment,
                inventory=inventory,
                issues=issues,
            )
            extracted_segments.append(
                ExtractedSegment(
                    table_id=segment.table_id,
                    segment_id=segment.segment_id,
                    intent=segment.intent,
                    orientation=segment.orientation,
                    start=segment.start,
                    end=segment.end,
                    facts=facts,
                    records=records,
                )
            )

        primary_record_table_ids = _refine_primary_record_table_ids(
            intent.document_intent,
            primary_record_table_ids,
            extracted_segments,
            issues,
        )
        record_groups: dict[tuple[str, RecordOrientation], list[int]] = {}
        for index, extracted_segment in enumerate(extracted_segments):
            if (
                not extracted_segment.records
                or extracted_segment.table_id not in primary_record_table_ids
                or extracted_segment.orientation is None
            ):
                continue
            record_groups.setdefault(
                (extracted_segment.table_id, extracted_segment.orientation),
                [],
            ).append(index)
        for (table_id, orientation), segment_indexes in record_groups.items():
            records = [
                record
                for segment_index in segment_indexes
                for record in extracted_segments[segment_index].records
            ]
            kind_payloads, oversized_axes = _record_kind_payload_batches(
                records,
                table_id=table_id,
                orientation=orientation,
                document_type=document_type,
                document_subtype=document_subtype,
                max_input_chars=max_segment_input_chars,
            )
            group_label = f"{table_id}:{orientation}"
            if oversized_axes:
                issues.append(
                    "record_kind_mapping_input_limit:"
                    f"{group_label}:count={len(oversized_axes)}"
                )
            kind_decisions: list[RecordKindDecision] = []
            for payload_index, kind_payload in enumerate(kind_payloads):
                if not model_request_available():
                    note_model_budget_skip(
                        "record_kind_mapping",
                        len(kind_payloads) - payload_index,
                    )
                    break
                kind_messages = _messages(
                    role="record_kind_mapping",
                    payload=kind_payload,
                    semantic_execution=semantic_execution,
                )
                if _prompt_size(kind_messages) > max_segment_input_chars:
                    issues.append(
                        "record_kind_mapping_input_limit:"
                        f"{group_label}:batch={payload_index}"
                    )
                    continue
                record_kind_calls += 1
                try:
                    kind_mapping = await create_model_output(
                        RecordKindMapping,
                        role="record_kind_mapping",
                        messages=kind_messages,
                        max_retries=0,
                    )
                except Exception as exc:  # noqa: BLE001 - retain source rows
                    issues.append(
                        "record_kind_mapping_fallback:"
                        f"{group_label}:{exc.__class__.__name__}"
                    )
                    continue
                kind_decisions.extend(kind_mapping.decisions)
                expected_batch_axes = {
                    int(candidate["axis_index"])
                    for candidate in kind_payload["candidates"]
                }
                decided_batch_axes = {
                    decision.axis_index for decision in kind_mapping.decisions
                }
                missing_batch_axes = expected_batch_axes - decided_batch_axes
                if missing_batch_axes and model_request_available():
                    correction_payload = {
                        **kind_payload,
                        "candidates": [
                            candidate
                            for candidate in kind_payload["candidates"]
                            if int(candidate["axis_index"]) in missing_batch_axes
                        ],
                        "correction": "classify every previously omitted axis",
                    }
                    correction_messages = _messages(
                        role="record_kind_mapping",
                        payload=correction_payload,
                        semantic_execution=semantic_execution,
                    )
                    record_kind_calls += 1
                    try:
                        correction_mapping = await create_model_output(
                            RecordKindMapping,
                            role="record_kind_mapping",
                            messages=correction_messages,
                            max_retries=0,
                        )
                    except Exception as exc:  # noqa: BLE001 - retain source rows
                        issues.append(
                            "record_kind_mapping_correction_fallback:"
                            f"{group_label}:{exc.__class__.__name__}"
                        )
                    else:
                        kind_decisions.extend(correction_mapping.decisions)
            combined_mapping = RecordKindMapping(decisions=kind_decisions)
            records = _apply_record_kind_mapping(
                records,
                combined_mapping,
                inventory=inventory,
                table_id=table_id,
                document_type=document_type,
                issues=issues,
            )
            expected_axes = {
                record.record_axis for record in records if record.record_axis is not None
            }
            decided_axes = {
                decision.axis_index for decision in combined_mapping.decisions
            }
            if expected_axes - decided_axes:
                issues.append(
                    "record_kind_mapping_incomplete:"
                    f"{group_label}:expected={len(expected_axes)}:"
                    f"received={len(decided_axes)}"
                )
            records = _inherit_record_context(
                records,
                document_type=document_type,
                table_id=table_id,
                issues=issues,
            )
            offset = 0
            for segment_index in segment_indexes:
                record_count = len(extracted_segments[segment_index].records)
                extracted_segments[segment_index] = extracted_segments[
                    segment_index
                ].model_copy(
                    update={"records": records[offset : offset + record_count]},
                    deep=True,
                )
                offset += record_count
        append_model_budget_issue(issues)
        return self._result(
            document_intent=intent.document_intent,
            document_kind_label=document_kind_label,
            document_subtype=document_subtype,
            primary_record_table_ids=primary_record_table_ids,
            document_facts=document_facts,
            generic_facts=generic_facts,
            segments=extracted_segments,
            inventory=inventory,
            consumed=consumed,
            schema_consumed=schema_consumed,
            redundant_evidence=redundant_evidence,
            content_bindings=intent.content_bindings,
            issues=issues,
            intent_calls=intent_calls,
            segment_calls=segment_calls,
            record_kind_calls=record_kind_calls,
            model_diagnostics=model_diagnostics,
            route_policy_advice=route_policy_advice,
        )

    @staticmethod
    def _result(
        *,
        document_intent: str,
        document_kind_label: str | None = None,
        document_facts: list[ExtractedFact],
        segments: list[ExtractedSegment],
        inventory: dict[str, _EvidenceItem],
        consumed: set[str],
        schema_consumed: set[str] | None = None,
        redundant_evidence: set[str] | None = None,
        content_bindings: list[ProposedContentBinding] | None = None,
        issues: list[str],
        intent_calls: int,
        segment_calls: int,
        record_kind_calls: int = 0,
        generic_facts: list[ExtractedFact] | None = None,
        route_policy_advice: DocumentRoutePolicyAdvice | None = None,
        primary_record_table_ids: list[str] | None = None,
        document_subtype: str | None = None,
        model_diagnostics: list[ModelFailureDiagnostic] | None = None,
    ) -> MinerUInstructorResult:
        schema_ids = (schema_consumed or set()) - consumed
        redundant_ids = (redundant_evidence or set()) - consumed - schema_ids
        redundant_ids.update(
            _redundant_consumed_block_ids(inventory, consumed)
            - consumed
            - schema_ids
        )
        content_units, content_model_bound_count, content_fallback_count = (
            _project_content_units(
                inventory,
                consumed=consumed,
                excluded=redundant_ids,
                bindings=content_bindings or [],
                issues=issues,
            )
        )
        schema = [
            _evidence_reference(item)
            for evidence_id, item in sorted(inventory.items())
            if evidence_id in schema_ids
        ]
        redundant = [
            _evidence_reference(item)
            for evidence_id, item in sorted(inventory.items())
            if evidence_id in redundant_ids
        ]
        raw_content_ids = set(inventory) - consumed - schema_ids - redundant_ids
        raw_content = [
            _evidence_reference(item)
            for evidence_id, item in sorted(inventory.items())
            if evidence_id in raw_content_ids
        ]
        unmapped = [
            _evidence_reference(item)
            for evidence_id, item in sorted(inventory.items())
            if evidence_id not in consumed
        ]
        total_count = len(inventory)
        mapped_count = len(set(inventory) & consumed)
        semantic_count = mapped_count + len(schema) + len(redundant)
        accounted_count = semantic_count + len(raw_content)
        unresolved_count = max(0, total_count - accounted_count)
        retained_count = mapped_count + len(unmapped)
        content_evidence_count = len(content_units)
        content_accounted_count = content_model_bound_count + content_fallback_count
        model_bound_content_ids = {
            unit.evidence_id for unit in content_units if unit.binding_source == "model"
        }
        unaccounted_semantic_ids = raw_content_ids - model_bound_content_ids
        blocking_issues = [issue for issue in issues if _is_blocking_issue(issue)]
        return MinerUInstructorResult(
            document_intent=document_intent,
            document_intent_family=_document_intent_family(document_intent),
            document_kind_label=document_kind_label or document_intent,
            document_subtype=document_subtype,
            primary_record_table_ids=primary_record_table_ids or [],
            document_facts=document_facts,
            generic_facts=generic_facts or [],
            route_policy_advice=route_policy_advice,
            segments=segments,
            content_units=content_units,
            schema_evidence=schema,
            redundant_evidence=redundant,
            raw_content_evidence=raw_content,
            unmapped_evidence=unmapped,
            issues=list(dict.fromkeys(issues)),
            model_diagnostics=list(model_diagnostics or [])[
                :_MODEL_DIAGNOSTIC_MAX_ITEMS
            ],
            complete=not blocking_issues,
            semantic_complete=(not blocking_issues and not unaccounted_semantic_ids),
            accounted_complete=accounted_count == total_count,
            retained_complete=retained_count == total_count,
            total_evidence_count=total_count,
            mapped_evidence_count=mapped_count,
            schema_evidence_count=len(schema),
            redundant_evidence_count=len(redundant),
            raw_content_evidence_count=len(raw_content),
            unresolved_evidence_count=unresolved_count,
            retained_evidence_count=retained_count,
            unmapped_evidence_count=len(unmapped),
            content_evidence_count=content_evidence_count,
            content_unit_count=len(content_units),
            content_model_bound_count=content_model_bound_count,
            content_local_fallback_count=content_fallback_count,
            content_accounted_complete=(
                content_accounted_count == content_evidence_count
            ),
            content_semantic_coverage_ratio=(
                content_model_bound_count / content_evidence_count
                if content_evidence_count
                else 1.0
            ),
            content_accounting_ratio=(
                content_accounted_count / content_evidence_count
                if content_evidence_count
                else 1.0
            ),
            evidence_coverage_ratio=(
                mapped_count / total_count if total_count else 1.0
            ),
            semantic_accounting_ratio=(
                semantic_count / total_count if total_count else 1.0
            ),
            evidence_accounting_ratio=(
                accounted_count / total_count if total_count else 1.0
            ),
            retained_evidence_ratio=(
                retained_count / total_count if total_count else 1.0
            ),
            intent_calls=intent_calls,
            segment_calls=segment_calls,
            record_kind_calls=record_kind_calls,
        )


__all__ = [
    "OPEN_DOMAIN_DOCUMENT_SUBTYPES",
    "ContentUnit",
    "DocumentIntent",
    "DocumentRoutePolicyAdvice",
    "EvidenceReference",
    "ExtractedFact",
    "ExtractedRecord",
    "ExtractedSegment",
    "InstructorAsyncClient",
    "InstructorUnavailableError",
    "MinerUInstructorExtractor",
    "MinerUInstructorResult",
    "ModelFailureDiagnostic",
    "OllamaNativeOutputError",
    "ProposedContentBinding",
    "ProposedFact",
    "ProposedRecord",
    "RecordFieldBinding",
    "RecordFieldMapping",
    "RecordGeometryContractError",
    "RecordKindDecision",
    "RecordKindMapping",
    "SegmentExtraction",
    "TableIntent",
    "TablePartition",
    "TableSegmentIntent",
    "evidence_inventory",
]
