"""Production MinerU plus Instructor document extraction service.

The module owns the evidence-first candidate pipeline used by production full
authority and by the standalone benchmark CLI. It has no task-store or
knowledge-side effects; workflow authority remains with ``MinerUShadowRunner``.
"""

from __future__ import annotations

import argparse
import asyncio
import copy
import hashlib
import inspect
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unicodedata
from contextlib import suppress
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher
from pathlib import Path, PurePosixPath
from typing import Any, Protocol
from zipfile import BadZipFile, ZipFile

from m1.documents.envelope import coordinate_from_row_col
from m1.documents.models import DocumentRecord, SourceReference
from m1.documents.parsing.document_route_plan import DocumentRoutePlan
from m1.documents.parsing.docx_native_evidence import (
    parse_docx_native_evidence,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.field_semantic_application import (
    FieldSemanticBatchRuntime,
    route_document_custom_fields,
)
from m1.documents.parsing.field_semantic_registry import CanonicalFieldRegistry
from m1.documents.parsing.mineru import (
    MinerUClient,
    MinerUContractError,
    MinerUError,
    MinerUParseResult,
    adapt_content_list_v2,
)
from m1.documents.parsing.mineru_domain import (
    CANONICAL_SUBTYPE_TYPES,
    classify_line_business_payload,
    source_label_line_target,
    target_direct_field,
    target_storage_key,
)
from m1.documents.parsing.mineru_generic_projection import (
    content_fact_payloads,
    table_fact_payloads,
)
from m1.documents.parsing.mineru_input import (
    MinerUInputContractError,
    MinerUInputNormalizer,
)
from m1.documents.parsing.mineru_instructor_poc import (
    OPEN_DOMAIN_DOCUMENT_SUBTYPES,
    ExtractedFact,
    ExtractedRecord,
    MinerUInstructorExtractor,
    MinerUInstructorResult,
    SemanticExecutionBudgetExceeded,
    _canonical_fact_name,
    _fact_target_context,
    evidence_inventory,
)
from m1.documents.parsing.mineru_regions import (
    assess_record_regions_from_raw_pages,
    is_structural_summary_axis,
    record_region_binding_report,
)
from m1.documents.parsing.pdf_text_layer_evidence import (
    PdfTextLayerError,
    apply_pdf_text_layer_fusion,
    extract_pdf_text_layer,
)
from m1.documents.parsing.semantic_completion import build_semantic_completion
from m1.documents.parsing.semantic_strategy_executor import (
    SemanticExecutionSpec,
    SemanticStrategyExecutor,
)
from m1.documents.parsing.source_asset_inventory import (
    SourceAsset,
    SourceAssetInventory,
    SourceAssetInventoryError,
    inventory_source_assets,
)
from m1.documents.parsing.visual_asset_evidence import (
    enrich_visual_asset_evidence,
)
from m1.documents.spreadsheets import (
    UnsupportedSpreadsheetError,
    parse_spreadsheet_envelope,
)
from m1.documents.tabular import (
    _infer_tabular_classification,
    find_tabular_regions,
)

_SAFE_FIELD = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
_SOURCE_RANGE = re.compile(
    r"^Source range:\s*([A-Z]+)(\d+):([A-Z]+)(\d+)\s*$",
    re.IGNORECASE,
)
_SPREADSHEET_SHEET = re.compile(r"^Spreadsheet:\s*(.+?)\s*$", re.IGNORECASE)
_CLI_CLEANUP_RESERVE_SECONDS = 5.0
_CLI_LOG_TAIL_BYTES = 8_192


def _consume_background_task(task: asyncio.Task[Any]) -> None:
    if not task.cancelled():
        task.exception()


async def _wait_process_hard(process: Any, *, timeout_seconds: float) -> int | None:
    """Wait without allowing a broken subprocess transport to block forever."""

    if timeout_seconds <= 0:
        raise TimeoutError("subprocess wait deadline expired")
    waiter = asyncio.create_task(process.wait())
    done, _pending = await asyncio.wait({waiter}, timeout=timeout_seconds)
    if waiter in done:
        return waiter.result()
    waiter.cancel()
    waiter.add_done_callback(_consume_background_task)
    raise TimeoutError("subprocess did not exit before the hard deadline")


def _process_group_kwargs() -> dict[str, Any]:
    if sys.platform == "win32":
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def _taskkill_process_tree(pid: int, timeout_seconds: float) -> None:
    subprocess.run(
        ["taskkill", "/PID", str(pid), "/T", "/F"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=max(timeout_seconds, 0.1),
    )


async def _terminate_process_tree(
    process: Any,
    *,
    timeout_seconds: float = _CLI_CLEANUP_RESERVE_SECONDS,
) -> None:
    """Terminate a CLI and all descendants within one absolute deadline."""

    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(timeout_seconds, 0.1)
    pid = getattr(process, "pid", None)

    if getattr(process, "returncode", None) is None and isinstance(pid, int):
        if sys.platform == "win32":
            remaining = max(deadline - loop.time(), 0.1)
            try:
                await asyncio.wait_for(
                    asyncio.to_thread(
                        _taskkill_process_tree,
                        pid,
                        min(remaining, 3.0),
                    ),
                    timeout=min(remaining, 3.5),
                )
            except (OSError, subprocess.SubprocessError, TimeoutError):
                pass
        else:
            try:
                os.killpg(pid, signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                pass
            remaining = deadline - loop.time()
            if remaining > 0:
                try:
                    await _wait_process_hard(
                        process,
                        timeout_seconds=min(remaining, 1.0),
                    )
                    return
                except TimeoutError:
                    pass
            try:
                os.killpg(pid, signal.SIGKILL)
            except (ProcessLookupError, PermissionError):
                pass

    if getattr(process, "returncode", None) is None:
        try:
            process.kill()
        except ProcessLookupError:
            pass

    remaining = deadline - loop.time()
    if remaining <= 0:
        return
    try:
        await _wait_process_hard(process, timeout_seconds=remaining)
    except TimeoutError:
        # The direct process has already received the hard kill.  Returning here
        # is intentional: cleanup must never turn cancellation into an infinite wait.
        return


def _read_log_tail(path: Path) -> str:
    try:
        with path.open("rb") as stream:
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - _CLI_LOG_TAIL_BYTES))
            payload = stream.read(_CLI_LOG_TAIL_BYTES)
    except OSError:
        return ""
    return payload.decode("utf-8", errors="replace").strip()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _spreadsheet_cell_text(cell: Any) -> str | None:
    """Return the best lossless display value available in the envelope."""

    for value in (
        cell.normalized_value,
        cell.value,
        cell.cached_value,
        cell.formula,
    ):
        if value is None:
            continue
        text = unicodedata.normalize("NFKC", str(value))
        if text != "":
            return text
    return None


def _spreadsheet_parallel_regions(
    sheet: Any,
    *,
    regions: list[Any] | None = None,
) -> list[Any]:
    """Return logical tables only when their source rectangles are disjoint."""

    regions = list(regions) if regions is not None else find_tabular_regions(sheet)
    if len(regions) < 2:
        return []
    rectangles = [
        (
            region.header_row,
            region.data_end_row,
            region.start_column,
            region.end_column,
        )
        for region in regions
    ]
    for index, left in enumerate(rectangles):
        for right in rectangles[index + 1 :]:
            rows_overlap = left[0] <= right[1] and right[0] <= left[1]
            columns_overlap = left[2] <= right[3] and right[2] <= left[3]
            if rows_overlap and columns_overlap:
                return []
    return regions


_NATIVE_SUMMARY_LABEL_RE = re.compile(
    r"^(?:合计|总计|小计|subtotal|grand\s*total|total)\s*[:：]?$",
    re.IGNORECASE,
)
_NATIVE_DOCUMENT_CONTROL_RE = re.compile(
    r"(?:制定|制表|编制|审核|批准|签字)(?:日期)?\s*[:：]",
    re.IGNORECASE,
)


def _native_region_record_axes(
    region: Any,
    *,
    table_min_row: int,
) -> list[int]:
    """Return source-backed business axes without totals or control rows."""

    axes: list[int] = []
    prior_records: list[list[str | None]] = []
    line_number_columns = {
        column for column, name in region.headers.items() if name == "line_no"
    }
    identity_columns = {
        column
        for column, name in region.headers.items()
        if name in {"model", "product_code", "name_raw", "quantity"}
    }
    for source_row in range(region.data_start_row, region.data_end_row + 1):
        values = {
            column: _spreadsheet_cell_text(cell)
            for column in range(region.start_column, region.end_column + 1)
            if (
                cell := region.sheet.cell(
                    source_row,
                    column,
                    inherit_merged=True,
                )
            )
            is not None
            and _spreadsheet_cell_text(cell) is not None
        }
        ordered_values = [
            values.get(column)
            for column in range(region.start_column, region.end_column + 1)
        ]
        nonempty = [value.strip() for value in values.values() if value.strip()]
        if not nonempty:
            continue
        if any(_NATIVE_SUMMARY_LABEL_RE.fullmatch(value) for value in nonempty[:2]):
            continue
        if is_structural_summary_axis(ordered_values, prior_records):
            continue
        row_text = " ".join(nonempty)
        if _NATIVE_DOCUMENT_CONTROL_RE.search(row_text):
            continue
        if line_number_columns and any(
            column in values for column in line_number_columns
        ) and not any(column in values for column in identity_columns):
            continue
        axes.append(source_row - table_min_row)
        prior_records.append(ordered_values)
    return axes


def _native_headerless_bom_record_axes(
    sheet: Any,
    *,
    min_row: int,
    max_row: int,
    min_column: int,
    max_column: int,
) -> list[int]:
    """Bind row-major BOM evidence without inventing missing field labels."""

    axes: list[int] = []
    prior_records: list[list[str | None]] = []
    for source_row in range(min_row, max_row + 1):
        ordered_values: list[str | None] = []
        for column in range(min_column, max_column + 1):
            cell = sheet.cell(source_row, column, inherit_merged=True)
            ordered_values.append(
                _spreadsheet_cell_text(cell) if cell is not None else None
            )
        nonempty = [value.strip() for value in ordered_values if value and value.strip()]
        if len(nonempty) < 2:
            continue
        if any(_NATIVE_SUMMARY_LABEL_RE.fullmatch(value) for value in nonempty[:2]):
            continue
        if is_structural_summary_axis(ordered_values, prior_records):
            continue
        if _NATIVE_DOCUMENT_CONTROL_RE.search(" ".join(nonempty)):
            continue
        axes.append(source_row - min_row)
        prior_records.append(ordered_values)
    return axes


def _spreadsheet_evidence_table(
    *,
    page_index: int,
    sheet: Any,
    nonempty: list[tuple[Any, str]],
    min_row: int,
    max_row: int,
    min_column: int,
    max_column: int,
    table_suffix: str = "",
    native_record_layout: dict[str, Any] | None = None,
) -> EvidenceTable:
    rows: list[list[str | None]] = [
        [None] * (max_column - min_column + 1)
        for _ in range(max_row - min_row + 1)
    ]
    cells: list[EvidenceCell] = []
    for cell, text in sorted(
        nonempty,
        key=lambda item: (item[0].row, item[0].column),
    ):
        local_row = cell.row - min_row
        local_column = cell.column - min_column
        rows[local_row][local_column] = text
        cells.append(
            EvidenceCell(
                row=local_row,
                column=local_column,
                text=text,
                sheet=sheet.name,
                cell=cell.coordinate,
                source_row=cell.row,
                source_column=cell.column,
                formula=cell.formula,
                cached_value=cell.cached_value,
                hidden_row=cell.hidden_row,
                hidden_column=cell.hidden_column,
                low_visibility_column=cell.low_visibility_column,
                merged_range=cell.merged_range,
                inherited_from=cell.inherited_from,
            )
        )
    source_range = (
        f"{coordinate_from_row_col(min_row, min_column)}:"
        f"{coordinate_from_row_col(max_row, max_column)}"
    )
    table_payload: dict[str, Any] = {
        "table_id": f"spreadsheet:s{page_index}{table_suffix}",
        "rows": rows,
        "cells": cells,
        "source": "spreadsheet-envelope",
        "sheet": sheet.name,
        "source_range": source_range,
        "source_row_offset": min_row,
        "source_column_offset": min_column,
    }
    if native_record_layout is not None:
        table_payload["native_record_layout"] = native_record_layout
    return EvidenceTable(**table_payload)


def _spreadsheet_nonempty_cells(sheet: Any) -> list[tuple[Any, str]]:
    """Return physical values plus vertical-merge inheritance with provenance."""

    by_position: dict[tuple[int, int], tuple[Any, str]] = {
        (cell.row, cell.column): (cell, text)
        for cell in sheet.cells.values()
        if (text := _spreadsheet_cell_text(cell)) is not None
    }
    for merged in sheet.merged_ranges:
        if merged.max_row <= merged.min_row:
            continue
        for row in range(merged.min_row + 1, merged.max_row + 1):
            position = (row, merged.min_col)
            if position in by_position:
                continue
            inherited = sheet.cell(row, merged.min_col, inherit_merged=True)
            if inherited is None:
                continue
            text = _spreadsheet_cell_text(inherited)
            if text is not None:
                by_position[position] = (inherited, text)
    return [by_position[position] for position in sorted(by_position)]


def _spreadsheet_document_evidence(
    source: Path,
    *,
    original_filename: str,
) -> DocumentEvidence | None:
    """Build row-preserving evidence directly from an original spreadsheet.

    A rendered spreadsheet page is useful visual context, but it is not a
    lossless record boundary: adjacent rows can be joined by OCR.  The envelope
    remains the authority for cell values and physical row boundaries while the
    model is limited to interpreting their semantics.
    """

    try:
        envelope = parse_spreadsheet_envelope(
            source,
            original_filename=original_filename,
        )
    except UnsupportedSpreadsheetError:
        return None

    native_classification = _infer_tabular_classification(envelope)
    native_subtype = native_classification.document_subtype
    native_type = CANONICAL_SUBTYPE_TYPES.get(str(native_subtype or ""))
    pages: list[EvidencePage] = []
    for page_index, sheet in enumerate(envelope.sheets):
        nonempty = _spreadsheet_nonempty_cells(sheet)
        tables: list[EvidenceTable] = []
        blocks: list[EvidenceBlock] = []
        if nonempty:
            deterministic_regions = find_tabular_regions(sheet)
            parallel_regions = _spreadsheet_parallel_regions(
                sheet,
                regions=deterministic_regions,
            )
            if parallel_regions:
                claimed: set[tuple[int, int]] = set()
                for region_index, region in enumerate(parallel_regions):
                    region_cells = [
                        (cell, text)
                        for cell, text in nonempty
                        if region.header_row <= cell.row <= region.data_end_row
                        and region.start_column <= cell.column <= region.end_column
                    ]
                    if not region_cells:
                        continue
                    claimed.update((cell.row, cell.column) for cell, _text in region_cells)
                    tables.append(
                        _spreadsheet_evidence_table(
                            page_index=page_index,
                            sheet=sheet,
                            nonempty=region_cells,
                            min_row=region.header_row,
                            max_row=region.data_end_row,
                            min_column=region.start_column,
                            max_column=region.end_column,
                            table_suffix=f":region{region_index}",
                            native_record_layout={
                                "source": "spreadsheet-tabular-v1",
                                "orientation": "rows",
                                "header_axes": [0],
                                "record_axes": _native_region_record_axes(
                                    region,
                                    table_min_row=region.header_row,
                                ),
                                "parallel_group": f"spreadsheet:s{page_index}",
                                "document_type": native_type,
                                "document_subtype": native_subtype,
                            },
                        )
                    )
                for order, (cell, text) in enumerate(
                    item for item in nonempty if (item[0].row, item[0].column) not in claimed
                ):
                    blocks.append(
                        EvidenceBlock(
                            block_id=(
                                f"spreadsheet:s{page_index}:"
                                f"r{cell.row}:c{cell.column}:layout"
                            ),
                            kind="spreadsheet_cell",
                            text=text,
                            order=order,
                            source="spreadsheet-envelope",
                            source_ref_part=f"spreadsheet/{sheet.name}/{cell.coordinate}",
                            native_source_refs=[
                                {"sheet": sheet.name, "cell": cell.coordinate}
                            ],
                        )
                    )
            else:
                min_row = min(cell.row for cell, _text in nonempty)
                max_row = max(cell.row for cell, _text in nonempty)
                min_column = min(cell.column for cell, _text in nonempty)
                max_column = max(cell.column for cell, _text in nonempty)
                native_record_layout: dict[str, Any] | None = None
                if len(deterministic_regions) == 1:
                    region = deterministic_regions[0]
                    record_axes = _native_region_record_axes(
                        region,
                        table_min_row=min_row,
                    )
                    header_axis = region.header_row - min_row
                    if record_axes and 0 <= header_axis <= max_row - min_row:
                        native_record_layout = {
                            "source": "spreadsheet-tabular-v1",
                            "orientation": "rows",
                            "header_axes": [header_axis],
                            "record_axes": record_axes,
                            "document_type": native_type,
                            "document_subtype": native_subtype,
                        }
                elif not deterministic_regions and native_subtype == "bill_of_materials":
                    record_axes = _native_headerless_bom_record_axes(
                        sheet,
                        min_row=min_row,
                        max_row=max_row,
                        min_column=min_column,
                        max_column=max_column,
                    )
                    if record_axes:
                        native_record_layout = {
                            "source": "spreadsheet-tabular-v1",
                            "orientation": "rows",
                            "header_axes": [],
                            "record_axes": record_axes,
                            "document_type": native_type,
                            "document_subtype": native_subtype,
                        }
                tables.append(
                    _spreadsheet_evidence_table(
                        page_index=page_index,
                        sheet=sheet,
                        nonempty=nonempty,
                        min_row=min_row,
                        max_row=max_row,
                        min_column=min_column,
                        max_column=max_column,
                        native_record_layout=native_record_layout,
                    )
                )
        pages.append(
            EvidencePage(
                page_number=page_index + 1,
                page_index=page_index,
                width=float(max(1, sheet.max_column)),
                height=float(max(1, sheet.max_row)),
                coordinate_space="unknown",
                blocks=blocks,
                tables=tables,
                raw={"sheet": sheet.name},
            )
        )
    return DocumentEvidence(
        backend="spreadsheet-envelope",
        backend_version="1",
        pages=pages,
        warnings=list(envelope.warnings),
        raw={
            "source_kind": envelope.file_kind,
            "source_sha256": envelope.sha256,
            "source_filename": original_filename,
            "spreadsheet_date_1904": envelope.date_1904,
            "native_classification": {
                "schema_version": "m1.native-classification.v1",
                "source": "spreadsheet-tabular-v1",
                "document_type": native_type,
                "document_subtype": native_subtype,
                "authority": native_classification.authority,
                "confidence": native_classification.confidence,
                "evidence": copy.deepcopy(list(native_classification.evidence)),
                "filename_advisory": copy.deepcopy(
                    list(native_classification.filename_advisory)
                ),
            },
            "mineru_visual_context_available": False,
        },
    )


class _MinerUParser(Protocol):
    async def parse(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> MinerUParseResult: ...


class _CachedMinerUParser:
    """Replay one pinned MinerU result while iterating on semantic extraction."""

    def __init__(
        self,
        *,
        content_list_v2_path: Path,
        middle_json_path: Path,
        backend_version: str,
        model_revision: str,
    ) -> None:
        self._content_list_v2_path = content_list_v2_path.resolve()
        self._middle_json_path = middle_json_path.resolve()
        self._backend_version = backend_version
        self._model_revision = model_revision

    async def parse(
        self,
        _path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> MinerUParseResult:
        del original_filename
        return _load_mineru_output(
            content_list_v2_path=self._content_list_v2_path,
            middle_json_path=self._middle_json_path,
            backend_version=self._backend_version,
            model_revision=self._model_revision,
            backend="vlm-engine",
            elapsed_ms=0.0,
            task_id_prefix="cached",
        )

    async def close(self) -> None:
        return None


def _load_mineru_output(
    *,
    content_list_v2_path: Path,
    middle_json_path: Path,
    backend_version: str,
    model_revision: str,
    backend: str,
    elapsed_ms: float,
    task_id_prefix: str,
) -> MinerUParseResult:
    content_bytes = content_list_v2_path.read_bytes()
    middle_bytes = middle_json_path.read_bytes()
    try:
        payload = json.loads(content_bytes)
        middle_json = json.loads(middle_bytes)
    except json.JSONDecodeError as exc:
        raise MinerUContractError("MinerU output JSON is invalid") from exc
    if not isinstance(payload, list):
        raise MinerUContractError("content_list_v2 root must be a list")
    if not isinstance(middle_json, dict):
        raise MinerUContractError("middle JSON root must be an object")
    version = str(middle_json.get("_version_name") or "")
    middle_backend = str(middle_json.get("_backend") or "")
    if version != backend_version or middle_backend not in {"vlm", "office"}:
        raise MinerUContractError(
            "MinerU result does not match the pinned vlm/office contract"
        )
    member_name = content_list_v2_path.name
    evidence = adapt_content_list_v2(
        payload,
        backend=backend,
        backend_version=backend_version,
        model_revision=model_revision,
        elapsed_ms=elapsed_ms,
        member_name=member_name,
        middle_json=middle_json,
    )
    if middle_backend == "office":
        evidence.backend = f"mineru:{backend}:office"
        evidence.model_fingerprints = {}
    output_id = hashlib.sha256(content_bytes + b"\0" + middle_bytes).hexdigest()[:20]
    return MinerUParseResult(
        evidence=evidence,
        task_id=f"{task_id_prefix}-{output_id}",
        member_name=member_name,
        content_list_v2=payload,
        middle_json=middle_json,
        elapsed_ms=elapsed_ms,
    )


def _current_environment_mineru() -> Path:
    suffix = ".exe" if sys.platform == "win32" else ""
    environment_candidate = Path(sys.executable).with_name(f"mineru{suffix}")
    if environment_candidate.is_file():
        return environment_candidate.resolve()
    raise FileNotFoundError(
        "mineru executable is not installed in the current Python environment"
    )


def _unique_mineru_output(root: Path, suffix: str) -> Path:
    resolved_root = root.resolve()
    matches: list[Path] = []
    for candidate in root.rglob(f"*{suffix}"):
        if not candidate.is_file():
            continue
        resolved = candidate.resolve()
        try:
            resolved.relative_to(resolved_root)
        except ValueError as exc:
            raise MinerUContractError(
                "MinerU output escaped the temporary directory"
            ) from exc
        matches.append(resolved)
    if len(matches) != 1:
        raise MinerUContractError(
            f"expected exactly one *{suffix} output, found {len(matches)}"
        )
    return matches[0]


def _discover_mineru_output_pair(root: Path) -> tuple[Path, Path]:
    content_path = _unique_mineru_output(root, "_content_list_v2.json")
    middle_path = _unique_mineru_output(root, "_middle.json")
    content_prefix = content_path.name.removesuffix("_content_list_v2.json")
    middle_prefix = middle_path.name.removesuffix("_middle.json")
    if content_path.parent != middle_path.parent or content_prefix != middle_prefix:
        raise MinerUContractError("MinerU content and middle outputs are not a pair")
    return content_path, middle_path


def _mineru_output_files(root: Path, suffix: str) -> list[Path]:
    resolved_root = root.resolve()
    matches: list[Path] = []
    for candidate in root.rglob(f"*{suffix}"):
        if not candidate.is_file():
            continue
        resolved = candidate.resolve()
        try:
            resolved.relative_to(resolved_root)
        except ValueError as exc:
            raise MinerUContractError(
                "MinerU batch output escaped the temporary directory"
            ) from exc
        matches.append(resolved)
    return matches


def _discover_mineru_batch_output_pairs(
    root: Path,
    expected_stems: list[str],
) -> dict[str, tuple[Path, Path] | MinerUContractError]:
    """Map strict per-input MinerU output pairs without cross-file guessing."""

    if len(set(expected_stems)) != len(expected_stems):
        raise MinerUContractError("MinerU batch input stems are not unique")
    expected = set(expected_stems)
    content_suffix = "_content_list_v2.json"
    middle_suffix = "_middle.json"
    content_by_stem: dict[str, list[Path]] = {stem: [] for stem in expected_stems}
    middle_by_stem: dict[str, list[Path]] = {stem: [] for stem in expected_stems}
    for suffix, target in (
        (content_suffix, content_by_stem),
        (middle_suffix, middle_by_stem),
    ):
        for output in _mineru_output_files(root, suffix):
            stem = output.name.removesuffix(suffix)
            if stem not in expected:
                raise MinerUContractError(
                    f"MinerU batch returned unexpected output stem {stem!r}"
                )
            target[stem].append(output)

    pairs: dict[str, tuple[Path, Path] | MinerUContractError] = {}
    for stem in expected_stems:
        content_matches = content_by_stem[stem]
        middle_matches = middle_by_stem[stem]
        if len(content_matches) != 1 or len(middle_matches) != 1:
            pairs[stem] = MinerUContractError(
                "expected exactly one MinerU content/middle output pair for "
                f"{stem!r}; found {len(content_matches)} content and "
                f"{len(middle_matches)} middle files"
            )
            continue
        content_path = content_matches[0]
        middle_path = middle_matches[0]
        if content_path.parent != middle_path.parent:
            pairs[stem] = MinerUContractError(
                f"MinerU batch outputs for {stem!r} are not in one directory"
            )
            continue
        pairs[stem] = (content_path, middle_path)
    return pairs


class _MinerUVLMHTTPClientParser:
    """Run MinerU's local CLI against a remote VLM endpoint for benchmark use."""

    def __init__(
        self,
        *,
        base_url: str,
        timeout_seconds: float,
        backend_version: str,
        model_revision: str,
        executable: str | Path | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout_seconds = float(timeout_seconds)
        if self._timeout_seconds <= 0:
            raise ValueError("MinerU CLI timeout must be positive")
        self._backend_version = backend_version
        self._model_revision = model_revision
        self._executable = (
            Path(executable).resolve()
            if executable is not None
            else _current_environment_mineru()
        )

    async def _run_cli(
        self,
        input_path: Path,
        output_root: Path,
        *,
        concurrency: int = 1,
        timeout_seconds: float | None = None,
    ) -> float:
        if concurrency < 1:
            raise ValueError("MinerU CLI concurrency must be positive")
        run_timeout = (
            self._timeout_seconds
            if timeout_seconds is None
            else min(float(timeout_seconds), self._timeout_seconds)
        )
        if run_timeout <= 0:
            raise ValueError("MinerU CLI timeout must be positive")

        started = time.perf_counter()
        output_root.mkdir(parents=True, exist_ok=True)
        log_path = output_root / ".mineru-cli.log"
        child_environment = os.environ.copy()
        child_environment["MINERU_API_MAX_CONCURRENT_REQUESTS"] = str(concurrency)
        child_environment["MINERU_PDF_RENDER_THREADS"] = "1"

        with log_path.open("w+b") as log_stream:
            process = await asyncio.create_subprocess_exec(
                str(self._executable),
                "-p",
                str(input_path),
                "-o",
                str(output_root),
                "-b",
                "vlm-http-client",
                "-u",
                self._base_url,
                "-t",
                "true",
                "--image-analysis",
                "true",
                "--client-side-output-generation",
                "true",
                "--max-concurrency",
                str(concurrency),
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                env=child_environment,
                **_process_group_kwargs(),
            )
            elapsed_seconds = time.perf_counter() - started
            cleanup_reserve = min(
                _CLI_CLEANUP_RESERVE_SECONDS,
                max(run_timeout * 0.1, 0.1),
            )
            execution_timeout = max(
                run_timeout - elapsed_seconds - cleanup_reserve,
                0.01,
            )
            try:
                await _wait_process_hard(
                    process,
                    timeout_seconds=execution_timeout,
                )
            except TimeoutError as exc:
                remaining = max(
                    run_timeout - (time.perf_counter() - started),
                    0.1,
                )
                await _terminate_process_tree(
                    process,
                    timeout_seconds=min(remaining, cleanup_reserve),
                )
                raise MinerUError(
                    f"MinerU CLI timed out after {run_timeout:g} seconds"
                ) from exc
            except asyncio.CancelledError:
                cleanup = asyncio.create_task(
                    _terminate_process_tree(
                        process,
                        timeout_seconds=_CLI_CLEANUP_RESERVE_SECONDS,
                    )
                )
                try:
                    await asyncio.shield(cleanup)
                except asyncio.CancelledError:
                    cleanup.add_done_callback(_consume_background_task)
                raise
            log_stream.flush()
        if process.returncode != 0:
            log_tail = _read_log_tail(log_path)
            detail = f"; log tail:\n{log_tail}" if log_tail else ""
            raise MinerUError(
                f"MinerU CLI exited with status {process.returncode}{detail}"
            )
        return (time.perf_counter() - started) * 1000

    async def parse(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> MinerUParseResult:
        del original_filename
        source = Path(path).resolve()
        if not source.is_file():
            raise FileNotFoundError(source)
        with tempfile.TemporaryDirectory(prefix="m1-mineru-cli-") as temporary:
            output_root = Path(temporary).resolve()
            elapsed_ms = await self._run_cli(source, output_root, concurrency=1)
            content_path, middle_path = _discover_mineru_output_pair(output_root)
            return _load_mineru_output(
                content_list_v2_path=content_path,
                middle_json_path=middle_path,
                backend_version=self._backend_version,
                model_revision=self._model_revision,
                backend="vlm-http-client",
                elapsed_ms=elapsed_ms,
                task_id_prefix="cli",
            )

    async def parse_many(
        self,
        paths: list[Path],
        *,
        original_filenames: list[str | None] | None = None,
        concurrency: int = 1,
        timeout_seconds: float | None = None,
    ) -> dict[Path, MinerUParseResult | Exception]:
        """Parse a bounded image set with one MinerU CLI process."""

        sources = [Path(path).resolve() for path in paths]
        if concurrency < 1:
            raise ValueError("batch concurrency must be positive")
        if original_filenames is not None and len(original_filenames) != len(sources):
            raise ValueError("original_filenames must align with paths")
        if len(set(sources)) != len(sources):
            raise ValueError("batch paths must be unique")
        for source in sources:
            if not source.is_file():
                raise FileNotFoundError(source)
        if not sources:
            return {}

        with (
            tempfile.TemporaryDirectory(prefix="m1-mineru-batch-input-") as input_dir,
            tempfile.TemporaryDirectory(prefix="m1-mineru-batch-output-") as output_dir,
        ):
            input_root = Path(input_dir).resolve()
            output_root = Path(output_dir).resolve()
            source_by_stem: dict[str, Path] = {}
            expected_stems: list[str] = []
            for index, source in enumerate(sources):
                source_sha256 = _sha256_file(source)
                suffix = source.suffix.casefold()
                if not re.fullmatch(r"\.[a-z0-9]{1,10}", suffix):
                    suffix = ".bin"
                stem = f"asset_{index:04d}_{source_sha256[:16]}"
                destination = (input_root / f"{stem}{suffix}").resolve()
                destination.relative_to(input_root)
                shutil.copyfile(source, destination)
                if destination.stat().st_size != source.stat().st_size:
                    raise MinerUContractError("MinerU batch input copy changed size")
                if _sha256_file(destination) != source_sha256:
                    raise MinerUContractError("MinerU batch input copy changed content")
                source_by_stem[stem] = source
                expected_stems.append(stem)

            run_error: Exception | None = None
            batch_started = time.perf_counter()
            try:
                elapsed_ms = await self._run_cli(
                    input_root,
                    output_root,
                    concurrency=concurrency,
                    timeout_seconds=timeout_seconds,
                )
            except MinerUError as exc:
                run_error = exc
                elapsed_ms = (time.perf_counter() - batch_started) * 1000
            try:
                discovered = _discover_mineru_batch_output_pairs(
                    output_root,
                    expected_stems,
                )
            except Exception as exc:  # noqa: BLE001 - report every submitted asset
                failure = run_error or exc
                return {source: failure for source in sources}
            results: dict[Path, MinerUParseResult | Exception] = {}
            for stem in expected_stems:
                source = source_by_stem[stem]
                pair = discovered[stem]
                if isinstance(pair, Exception):
                    results[source] = run_error or pair
                    continue
                content_path, middle_path = pair
                try:
                    results[source] = _load_mineru_output(
                        content_list_v2_path=content_path,
                        middle_json_path=middle_path,
                        backend_version=self._backend_version,
                        model_revision=self._model_revision,
                        backend="vlm-http-client",
                        elapsed_ms=elapsed_ms,
                        task_id_prefix="cli-batch",
                    )
                except Exception as exc:  # noqa: BLE001 - isolate one output pair
                    results[source] = exc
            return results

    async def close(self) -> None:
        return None


class _InstructorExtractor(Protocol):
    async def extract(
        self,
        evidence: Any,
        *,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUInstructorResult: ...


def _consumed_route_summary(
    route_plan: DocumentRoutePlan,
    *,
    routing_attempt: int,
) -> dict[str, Any]:
    """Serialize only the already-authorized workflow routing capability."""

    return {
        "schema_version": "m1.adaptive-routing.v1",
        "enabled": True,
        "status": "consumed",
        "stage": "preparse",
        "mode": str(route_plan.mode),
        "recommendation": str(route_plan.recommendation),
        "reason": str(route_plan.reason),
        "signature_fingerprint": route_plan.signature_fingerprint,
        "recommended_profile_id": route_plan.route_id,
        "applied_profile_id": (
            route_plan.route_id if route_plan.policy_applied else None
        ),
        "candidate_profile_id": route_plan.candidate_profile_id,
        "model_used": route_plan.model_used,
        "policy_applied": route_plan.policy_applied,
        "execution_status": "consumed",
        "executed_backend": "mineru",
        "routing_authority": "workflow_preparse",
        "processing_attempt": max(0, int(routing_attempt)),
        "route_plan": route_plan.value_free_dump(),
    }


async def _extract_with_explicit_hints(
    extractor: _InstructorExtractor,
    evidence: DocumentEvidence,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
    semantic_execution: SemanticExecutionSpec | None,
) -> MinerUInstructorResult:
    """Call new extractors with explicit hints while retaining old test fakes."""

    extract = extractor.extract
    try:
        parameters = inspect.signature(extract).parameters.values()
    except (TypeError, ValueError):
        parameters = ()
    names = {parameter.name for parameter in parameters}
    accepts_kwargs = any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters
    )
    kwargs: dict[str, Any] = {}
    for name, value in (
        ("document_type_hint", document_type_hint),
        ("document_subtype_hint", document_subtype_hint),
        ("semantic_execution", semantic_execution),
    ):
        if accepts_kwargs or name in names:
            kwargs[name] = value
    return await extract(evidence, **kwargs)


class _DrawingRegionVLMExtractor(Protocol):
    async def analyze(
        self,
        image: bytes,
        *,
        evidence_id: str,
        source_ref: SourceReference,
        subject: str | None = None,
        default_unit: str | None = None,
        max_regions: int | None = None,
    ) -> Any: ...


def _field_key(name: str) -> str:
    """Return a stable benchmark-path-safe key without losing the source label."""

    normalized = unicodedata.normalize("NFKC", name).strip()
    if _SAFE_FIELD.fullmatch(normalized):
        return normalized
    slug = re.sub(r"[^A-Za-z0-9_]+", "_", normalized).strip("_")[:64]
    if slug and not slug[0].isdigit():
        return slug
    fingerprint = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:12]
    return f"field_{fingerprint}"


def _unique_key(target: dict[str, Any], name: str) -> str:
    base = _field_key(name)
    used = {key.casefold() for key in target}
    if base.casefold() not in used:
        return base
    index = 2
    while f"{base}__{index}".casefold() in used:
        index += 1
    return f"{base}__{index}"


def _source_refs(fact: ExtractedFact) -> list[dict[str, Any]]:
    refs: list[dict[str, Any]] = []
    seen: set[str] = set()
    for evidence_ref in fact.evidence_refs:
        source_ref = evidence_ref.source_ref.model_dump(
            mode="json",
            exclude_none=True,
        )
        source_ref["evidence_id"] = evidence_ref.evidence_id
        source_ref["evidence_quote"] = evidence_ref.quote
        marker = json.dumps(source_ref, ensure_ascii=False, sort_keys=True)
        if marker in seen:
            continue
        seen.add(marker)
        refs.append(source_ref)
    return refs


def _source_refs_inherit_merge(source_refs: list[dict[str, Any]]) -> bool:
    return any(bool(reference.get("inherited_from_merge")) for reference in source_refs)


def _projection_source_refs_are_locatable(source_refs: Any) -> bool:
    if not isinstance(source_refs, list) or not source_refs:
        return False
    return all(
        isinstance(reference, dict)
        and reference.get("authority") != "advisory"
        and not reference.get("asset_sha256")
        and any(
            reference.get(field) not in (None, "")
            for field in ("sheet", "page", "cell", "range", "part", "archive_path")
        )
        for reference in source_refs
    )


def _trusted_source_ref(source_ref: Any) -> bool:
    provenance = source_ref.model_extra or {}
    return not (
        provenance.get("authority") == "advisory" or provenance.get("asset_sha256")
    )


def _extracted_text_sources(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> list[tuple[str, Any]]:
    """Return unique, non-advisory source text with its exact locator."""

    sources: list[tuple[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    def append(text: str, source_ref: Any) -> None:
        normalized = unicodedata.normalize("NFKC", str(text)).strip()
        if not normalized or not _trusted_source_ref(source_ref):
            return
        locator = json.dumps(
            source_ref.model_dump(mode="json", exclude_none=True),
            ensure_ascii=False,
            sort_keys=True,
        )
        marker = (normalized, locator)
        if marker in seen:
            return
        seen.add(marker)
        sources.append((normalized, source_ref))

    if evidence is not None:
        for item in evidence_inventory(evidence).values():
            append(item.exact_text or item.text, item.source_ref)

    facts = [
        *extracted.document_facts,
        *(
            fact
            for segment in extracted.segments
            for fact in [
                *segment.facts,
                *(field for record in segment.records for field in record.fields),
            ]
        ),
    ]
    for fact in facts:
        for reference in fact.evidence_refs:
            append(reference.quote, reference.source_ref)
    for reference in [
        *extracted.schema_evidence,
        *extracted.redundant_evidence,
        *extracted.raw_content_evidence,
        *extracted.unmapped_evidence,
    ]:
        append(reference.quote, reference.source_ref)
    for unit in extracted.content_units:
        append(unit.exact_text, unit.source_ref)
    return sources


def _trusted_exact_evidence(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
    *,
    preserve_text: bool = False,
) -> list[tuple[str, str, Any, str]]:
    """Return every trusted exact quote, including evidence consumed as a fact."""

    items: list[tuple[str, str, Any, str]] = []
    seen: set[tuple[str, str, str]] = set()

    def append(
        evidence_id: str,
        text: str,
        source_ref: Any,
        source_kind: str,
    ) -> None:
        original = str(text)
        normalized = unicodedata.normalize("NFKC", original).strip()
        if not normalized or not _trusted_source_ref(source_ref):
            return
        locator = json.dumps(
            source_ref.model_dump(mode="json", exclude_none=True),
            ensure_ascii=False,
            sort_keys=True,
        )
        marker = (evidence_id, normalized, locator)
        if marker in seen:
            return
        seen.add(marker)
        items.append(
            (
                evidence_id,
                original if preserve_text else normalized,
                source_ref,
                source_kind,
            )
        )

    if evidence is not None:
        for item in evidence_inventory(evidence).values():
            append(
                item.evidence_id,
                item.exact_text or item.text,
                item.source_ref,
                item.source_kind,
            )

    for reference in [
        *extracted.raw_content_evidence,
        *extracted.unmapped_evidence,
        *extracted.schema_evidence,
        *extracted.redundant_evidence,
    ]:
        append(
            reference.evidence_id,
            reference.quote,
            reference.source_ref,
            "native_text" if "docx:" in reference.source_ref.part else "text",
        )
    for unit in extracted.content_units:
        append(
            unit.evidence_id,
            unit.exact_text,
            unit.source_ref,
            unit.source_kind,
        )
    for fact in [
        *extracted.document_facts,
        *(
            fact
            for segment in extracted.segments
            for fact in [
                *segment.facts,
                *(field for record in segment.records for field in record.fields),
            ]
        ),
    ]:
        for reference in fact.evidence_refs:
            append(
                reference.evidence_id,
                reference.quote,
                reference.source_ref,
                ("native_text" if "docx:" in reference.source_ref.part else "text"),
            )
    return items


_ENGINEERING_HEADER_PREFIXES: dict[str, tuple[str, ...]] = {
    "material_number": ("料号", "物料号", "物料编号", "material number"),
    "customer_material_number": (
        "客户料号",
        "客户物料号",
        "客户物料编号",
        "customer material number",
    ),
    "customer_code": ("客户代码", "客户编码", "customer code"),
    "version": ("版本", "版次", "revision", "rev"),
    "unit": ("单位", "unit", "uom"),
    "page_count_label": ("页次", "页码", "page"),
    "drawing_number": ("图号", "drawing number"),
}
_CHINESE_LEGAL_COMPANY = re.compile(
    r"(?=.{3,128}\Z)(?=.*[\u4e00-\u9fff])"
    r"[\u4e00-\u9fffA-Za-z0-9()（）·&＆\- ]+"
    r"(?:股份有限公司|有限责任公司|有限公司|公司|集团|研究院|工厂|厂)"
)
_TITLE_LENGTH = re.compile(
    r"(?:^|[\s(])(?:L|总长|全长|overall\s+length|cable\s+length)"
    r"\s*[=:：]?\s*(?P<value>\d+(?:[.,]\d+)?)\s*mm\b",
    re.IGNORECASE,
)
_EXPLICIT_OVERALL_LENGTH = re.compile(
    r"(?:总长|全长|overall\s+length|cable\s+length)\s*[=:：]?\s*"
    r"(?P<value>\d+(?:[.,]\d+)?\s*±\s*\d+(?:[.,]\d+)?(?:\s*mm)?)",
    re.IGNORECASE,
)
_TOLERANCED_DIMENSION = re.compile(
    r"(?<!\d)(?P<value>(?P<nominal>\d+(?:[.,]\d+)?)\s*±\s*"
    r"\d+(?:[.,]\d+)?(?:\s*mm)?)(?!\d)",
    re.IGNORECASE,
)


def _normalized_decimal_token(value: str) -> str:
    return value.replace(",", ".").lstrip("0") or "0"


def _single_evidence_value(
    candidates: list[tuple[str, Any]],
) -> tuple[str, list[dict[str, Any]]] | None:
    by_value: dict[str, tuple[str, list[dict[str, Any]]]] = {}
    for value, source_ref in candidates:
        marker = unicodedata.normalize("NFKC", value).casefold()
        serialized = source_ref.model_dump(mode="json", exclude_none=True)
        if marker not in by_value:
            by_value[marker] = (value, [serialized])
            continue
        refs = by_value[marker][1]
        if serialized not in refs:
            refs.append(serialized)
    if len(by_value) != 1:
        return None
    return next(iter(by_value.values()))


def _party_values_equivalent(values: set[str]) -> bool:
    normalized = [
        re.sub(
            r"[\s()（）·&＆\-]+",
            "",
            unicodedata.normalize("NFKC", value).casefold(),
        )
        for value in values
        if str(value).strip()
    ]
    if len(normalized) <= 1:
        return bool(normalized)
    if any(_PARTY_LEGAL_SUFFIX.search(value) is None for value in normalized):
        return False
    for index, left in enumerate(normalized):
        for right in normalized[index + 1 :]:
            prefix_length = min(5, len(left), len(right))
            if (
                prefix_length < 4
                or left[:prefix_length] != right[:prefix_length]
                or SequenceMatcher(None, left, right).ratio() < 0.90
            ):
                return False
    return True


def _single_party_evidence_value(
    candidates: list[tuple[str, Any]],
) -> tuple[str, list[dict[str, Any]]] | None:
    exact = _single_evidence_value(candidates)
    if exact is not None:
        return exact
    values = {unicodedata.normalize("NFKC", value).strip() for value, _ref in candidates}
    if not _party_values_equivalent(values):
        return None
    selected = max(values, key=lambda value: (len(value), value))
    refs: list[dict[str, Any]] = []
    for _value, source_ref in candidates:
        serialized = source_ref.model_dump(mode="json", exclude_none=True)
        if serialized not in refs:
            refs.append(serialized)
    return selected, refs


def _inline_labeled_value(
    text: str,
    prefixes: tuple[str, ...],
) -> str | None:
    for prefix in prefixes:
        match = re.fullmatch(
            rf"\s*{re.escape(prefix)}\s*[/：:\-]?\s*(?P<value>.+?)\s*",
            text,
            re.IGNORECASE,
        )
        if match is None:
            continue
        value = match.group("value").strip()
        if not value or len(value) > 256:
            continue
        if "|" in value or "\n" in value or "\r" in value:
            continue
        if not any(character.isalnum() for character in value):
            continue
        if value.casefold() == prefix.casefold():
            continue
        return value
    return None


def _numbered_item_numbers(text: str) -> list[int]:
    return [
        int(value)
        for value in re.findall(
            r"(?m)(?:^|\n)\s*(\d{1,2})\s*[.\u3001\u3002\uFF0E\uFF09)]",
            text,
        )
    ]


def _ordered_numbered_sequence_count(text: str) -> int:
    numbers = _numbered_item_numbers(text)
    unique_in_order = list(dict.fromkeys(numbers))
    if unique_in_order == list(range(1, len(unique_in_order) + 1)):
        return len(unique_in_order)
    return 0


def _numbered_test_condition_count(
    extracted: MinerUInstructorResult,
) -> tuple[int, list[dict[str, Any]]] | None:
    grouped_units: dict[
        tuple[str | None, str | None, int | None],
        dict[str, Any],
    ] = {}
    for unit in extracted.content_units:
        if not _trusted_source_ref(unit.source_ref):
            continue
        semantics = f"{unit.content_kind} {unit.label}".casefold()
        is_test_semantic = any(
            marker in semantics
            for marker in (
                "test_condition",
                "test condition",
                "test_requirement",
                "test requirement",
                "test_result",
                "test result",
            )
        )
        explicit_test_text = f"{unit.label}\n{unit.exact_text}".casefold()
        is_test_semantic = is_test_semantic and (
            "test" in explicit_test_text
            or bool(re.search(r"测试|检验|试验|实测", explicit_test_text))
        )
        scope = (
            unit.source_ref.archive_path,
            unit.source_ref.sheet,
            unit.source_ref.page,
        )
        group = grouped_units.setdefault(
            scope,
            {"has_heading": False, "units": []},
        )
        is_heading = (
            unit.content_kind in {"section_header", "title"} and is_test_semantic
        ) or bool(
            re.search(
                r"测试条件|test\s+conditions?",
                unit.exact_text,
                re.IGNORECASE,
            )
        )
        group["has_heading"] = group["has_heading"] or is_heading
        if is_test_semantic:
            numbers = list(dict.fromkeys(_numbered_item_numbers(unit.exact_text)))
            if numbers:
                group["units"].append((numbers, unit.source_ref))

    numbered_groups = [group for group in grouped_units.values() if group["units"]]
    if not numbered_groups or not any(
        group["has_heading"] for group in grouped_units.values()
    ):
        return None
    if any(not group["has_heading"] for group in numbered_groups):
        return 0, []

    complete_groups: list[tuple[int, list[dict[str, Any]]]] = []
    for group in numbered_groups:
        units = group["units"]
        all_numbers = sorted(
            {number for numbers, _source_ref in units for number in numbers}
        )
        if len(all_numbers) < 2 or all_numbers != list(range(1, len(all_numbers) + 1)):
            continue
        source_refs: list[dict[str, Any]] = []
        selected_indexes: set[int] = set()
        covered_numbers: set[int] = set()
        ranked_units = sorted(
            enumerate(units),
            key=lambda item: (-len(set(item[1][0])), item[0]),
        )
        for index, (numbers, _source_ref) in ranked_units:
            if set(numbers) <= covered_numbers:
                continue
            selected_indexes.add(index)
            covered_numbers.update(numbers)
        for index, (_numbers, source_ref) in enumerate(units):
            if index not in selected_indexes:
                continue
            serialized = source_ref.model_dump(mode="json", exclude_none=True)
            if serialized not in source_refs:
                source_refs.append(serialized)
        complete_groups.append((len(all_numbers), source_refs))

    if len(complete_groups) == 1:
        return complete_groups[0]
    return 0, []


def _primary_engineering_product_name_selection(
    extracted: MinerUInstructorResult,
) -> tuple[tuple[str, list[dict[str, Any]]] | None, bool]:
    primary_table_ids = set(extracted.primary_record_table_ids)
    if not primary_table_ids:
        primary_table_ids = {
            segment.table_id
            for segment in extracted.segments
            if segment.intent in {"metadata", "layout"}
            and any(fact.name == "product_name" for fact in segment.facts)
        }
    if not primary_table_ids:
        primary_table_ids = {
            segment.table_id for segment in extracted.segments if segment.records
        }
    candidates: list[tuple[str, Any]] = []
    for segment in extracted.segments:
        if segment.table_id not in primary_table_ids:
            continue
        for fact in segment.facts:
            if fact.name != "product_name" or not _header_fact_plausible(
                extracted.document_subtype,
                fact.name,
                fact.value,
            ):
                continue
            candidates.extend(
                (fact.value, reference.source_ref)
                for reference in fact.evidence_refs
                if _trusted_source_ref(reference.source_ref)
            )
    return _single_evidence_value(candidates), bool(candidates)


def _derived_engineering_headers(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> dict[str, tuple[Any, list[dict[str, Any]]]]:
    """Recover singular drawing facts only when exact evidence is unambiguous."""

    sources = _extracted_text_sources(extracted)
    derived: dict[str, tuple[Any, list[dict[str, Any]]]] = {}

    selected, _has_primary_candidates = _primary_engineering_product_name_selection(
        extracted
    )
    if selected is not None:
        derived["product_name"] = selected

    if evidence is not None:
        company_candidates = [
            (text, item.source_ref)
            for item in evidence_inventory(evidence).values()
            if _trusted_source_ref(item.source_ref)
            and (
                text := unicodedata.normalize(
                    "NFKC", item.exact_text or item.text
                ).strip()
            )
            and _CHINESE_LEGAL_COMPANY.fullmatch(text)
        ]
        if selected := _single_evidence_value(company_candidates):
            derived["company"] = selected

    for name, prefixes in _ENGINEERING_HEADER_PREFIXES.items():
        candidates = [
            (value, source_ref)
            for text, source_ref in sources
            if (value := _inline_labeled_value(text, prefixes)) is not None
        ]
        if selected := _single_evidence_value(candidates):
            derived[name] = selected

    nominal_hints = {
        _normalized_decimal_token(match.group("value"))
        for text, _source_ref in sources
        for match in _TITLE_LENGTH.finditer(text)
    }
    explicit_lengths: list[tuple[str, Any]] = []
    corroborated_lengths: list[tuple[str, Any]] = []
    for text, source_ref in sources:
        explicit_lengths.extend(
            (re.sub(r"\s+", "", match.group("value")), source_ref)
            for match in _EXPLICIT_OVERALL_LENGTH.finditer(text)
        )
        for match in _TOLERANCED_DIMENSION.finditer(text):
            if _normalized_decimal_token(match.group("nominal")) in nominal_hints:
                corroborated_lengths.append(
                    (re.sub(r"\s+", "", match.group("value")), source_ref)
                )
    selected_length = _single_evidence_value(explicit_lengths)
    if selected_length is None:
        selected_length = _single_evidence_value(corroborated_lengths)
    if selected_length is not None:
        derived["overall_length"] = selected_length

    numbered_conditions = _numbered_test_condition_count(extracted)
    if numbered_conditions is not None:
        if numbered_conditions[0] > 0:
            derived["test_condition_count"] = numbered_conditions
    else:
        content_sources = [
            (unit.exact_text, unit.source_ref)
            for unit in extracted.content_units
            if _trusted_source_ref(unit.source_ref)
        ]
        if any(
            re.search(r"测试条件|test\s+conditions?", text, re.IGNORECASE)
            for text, _source_ref in content_sources
        ):
            numbered = [
                (_ordered_numbered_sequence_count(text), source_ref)
                for text, source_ref in content_sources
            ]
            best_count = max((count for count, _source_ref in numbered), default=0)
            best_refs = [
                source_ref
                for count, source_ref in numbered
                if count == best_count and count >= 2
            ]
            if best_refs:
                derived["test_condition_count"] = (
                    best_count,
                    [
                        source_ref.model_dump(mode="json", exclude_none=True)
                        for source_ref in best_refs
                    ],
                )
    return derived


_PURCHASE_TITLE = re.compile(
    r"(?:采购|购销|供货|销售|purchase\s*)[^\n]{0,24}(?:合同|订单|函)",
    re.IGNORECASE,
)
_PARTY_LEGAL_SUFFIX = re.compile(
    r"(?:股份有限公司|有限责任公司|有限公司|公司|集团|工厂|厂)$",
    re.IGNORECASE,
)
_PARTY_VALUE_BOUNDARY = (
    r"(?:甲方|乙方|需方|供方|买方|卖方|采购方|供应商|buyer|seller|supplier|"
    r"地址|联系(?:人|电话)|联系人|联系电话|电话|手机|传真|邮箱|邮编|"
    r"签订日期|签约日期|签约地|合同编号|采购订单号|采购单号|"
    r"订单编号|订单号码|订单号)"
)
_PURCHASE_HEADER_PATTERNS: dict[str, re.Pattern[str]] = {
    "contract_number": re.compile(
        r"(?:合同编号|合同号码|合同号|contract\s*(?:number|no\.?))\s*[:：]?\s*"
        r"(?P<value>[A-Za-z0-9][A-Za-z0-9_.\-/]{1,127})",
        re.IGNORECASE,
    ),
    "order_number": re.compile(
        r"(?:采购订单号|采购单号|订单编号|订单号码|订单号|"
        r"purchase\s+order\s*(?:number|no\.?)|order\s*(?:number|no\.?))"
        r"\s*[:：]?\s*(?P<value>[A-Za-z0-9][A-Za-z0-9_.\-/]{1,127})",
        re.IGNORECASE,
    ),
    "order_date": re.compile(
        r"(?:下单日期|采购订单日期|订单日期|签订日期|合同日期|签约日期|"
        r"order\s+date)\s*[:：]?\s*"
        r"(?P<value>\d{4}\s*(?:年|[-./])\s*\d{1,2}\s*(?:月|[-./])\s*"
        r"\d{1,2}\s*日?)",
        re.IGNORECASE,
    ),
    "delivery_date": re.compile(
        r"(?:交货日期|交货时间|交付日期|交期|delivery\s+date)\s*[:：]?\s*"
        r"(?P<value>\d{4}\s*(?:年|[-./])\s*\d{1,2}\s*(?:月|[-./])\s*"
        r"\d{1,2}\s*日?)",
        re.IGNORECASE,
    ),
    "buyer": re.compile(
        r"(?:甲方|需方|买方|采购方|buyer)\s*[:：]\s*"
        r"(?P<value>[^\n|;；]{2,128}?)(?=\s*(?:\n|$)|\s+"
        + _PARTY_VALUE_BOUNDARY
        + r"\s*[:：])",
        re.IGNORECASE,
    ),
    "seller": re.compile(
        r"(?:乙方|供方|卖方|seller)\s*[:：]\s*"
        r"(?P<value>[^\n|;；]{2,128}?)(?=\s*(?:\n|$)|\s+"
        + _PARTY_VALUE_BOUNDARY
        + r"\s*[:：])",
        re.IGNORECASE,
    ),
    "supplier": re.compile(
        r"(?:乙方|供方|卖方|供\s*应\s*商|supplier)\s*[:：]\s*"
        r"(?P<value>[^\n|;；]{2,128}?)(?=\s*(?:\n|$)|\s+"
        + _PARTY_VALUE_BOUNDARY
        + r"\s*[:：])",
        re.IGNORECASE,
    ),
    "summary": re.compile(
        r"(?:摘要|用途|summary)\s*[:：]\s*(?P<value>[^\n|]+)",
        re.IGNORECASE,
    ),
    "payment_terms": re.compile(
        r"(?:付款方式|付款条件|结款方式|结算方式(?:及期限)?|payment\s+terms)"
        r"\s*[:：]\s*(?P<value>月结\s*\d+\s*天|"
        r"[一二三四五六七八九十\d]+\s*个?月账期|现金|"
        r"预付[^\n，。,;；]*|货到[^\n，。,;；]*|转账)",
        re.IGNORECASE,
    ),
    "delivery_address": re.compile(
        r"(?:交货地址|送货地址|收货地址|delivery\s+address)\s*[:：]\s*"
        r"(?P<value>[^\n|]{4,512})",
        re.IGNORECASE,
    ),
    "tax_rate": re.compile(
        r"(?:含税率|税率|tax\s+rate)\s*[:：]?\s*(?P<value>\d+(?:[.,]\d+)?)\s*%?",
        re.IGNORECASE,
    ),
    "total_amount": re.compile(
        r"(?:合同总额|合同金额|价税合计|总金额|合计金额|金额合计|"
        r"grand\s+total|total\s+amount)[ \t]*[:：]?[ \t]*"
        r"(?P<value>[¥￥$]?\s*\d[\d,]*(?:\.\d+)?)",
        re.IGNORECASE,
    ),
}

_PURCHASE_SPATIAL_LABELS: dict[str, re.Pattern[str]] = {
    "order_number": re.compile(
        r"^(?:采购订单号|采购单号|订单编号|订单号码|订单号|"
        r"purchase\s+order\s*(?:number|no\.?)|order\s*(?:number|no\.?))"
        r"\s*[:：]?$",
        re.IGNORECASE,
    ),
    "contract_number": re.compile(r"^(?:合同编号|合同号码|合同号)\s*[:：]?$"),
    "order_date": re.compile(r"^(?:下单日期|采购订单日期|订单日期|签订日期|合同日期)\s*[:：]?$"),
    "delivery_date": re.compile(r"^(?:交货日期|交付日期|交期)\s*[:：]?$"),
    "buyer": re.compile(
        r"^(?:甲\s*方|需方|买方|采购方|收货单位(?:签字盖章)?)\s*[:：]?$"
    ),
    "seller": re.compile(
        r"^(?:乙\s*方|供方|卖方|发货单位(?:签字盖章)?)\s*[:：]?$"
    ),
    "supplier": re.compile(
        r"^(?:乙\s*方|供方|供\s*应\s*商|发货单位(?:签字盖章)?)\s*[:：]?$"
    ),
}
_PURCHASE_GRID_LABELS: dict[str, re.Pattern[str]] = {
    **_PURCHASE_SPATIAL_LABELS,
    "payment_terms": re.compile(
        r"^(?:付款方式|付款条件|结款方式|结算方式(?:及期限)?|payment\s+terms)"
        r"\s*[:：]?$",
        re.IGNORECASE,
    ),
    "delivery_address": re.compile(
        r"^(?:交货地址|送货地址|收货地址|delivery\s+address)\s*[:：]?$",
        re.IGNORECASE,
    ),
    "currency": re.compile(r"^(?:币种|currency)\s*[:：]?$", re.IGNORECASE),
}
_COMPLETE_PURCHASE_DATE = re.compile(
    r"^(?P<year>\d{4})\s*(?:年|[-./])\s*"
    r"(?P<month>\d{1,2})\s*(?:月|[-./])\s*"
    r"(?P<day>\d{1,2})\s*日?$"
)
_PURCHASE_SPATIAL_NUMBER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-/]{1,127}$")
_PURCHASE_SPATIAL_COMPANY = re.compile(
    r"^[\u4e00-\u9fffA-Za-z0-9()（）·\s]{2,128}(?:有限公司|公司|工厂|厂)$"
)
_PURCHASE_PAYMENT_TERMS = re.compile(
    r"^(?:"
    r"(?:月结|账期|票到|货到|验收后|预付|定金|尾款|款到|现结|现金)"
    r"[^\s]{0,32}|"
    r"\d{1,4}\s*天|"
    r"(?:COD|T/?T|L/?C)(?:\s*\d{1,4}\s*(?:DAYS?|天))?"
    r")$",
    re.IGNORECASE,
)
_PURCHASE_ADDRESS_SIGNAL = re.compile(
    r"(?:省|市|区|县|镇|乡|街道|街|路|大道|巷|号|楼|栋|园区|工业园|"
    r"收货|地址|\d{7,})"
)


def _complete_purchase_date_iso(value: str) -> str | None:
    normalized = " ".join(unicodedata.normalize("NFKC", value).split())
    match = _COMPLETE_PURCHASE_DATE.fullmatch(normalized)
    if match is None:
        return None
    try:
        parsed = date(
            int(match.group("year")),
            int(match.group("month")),
            int(match.group("day")),
        )
    except ValueError:
        return None
    return parsed.isoformat()


def _a1_position(value: object) -> tuple[int, int] | None:
    match = re.fullmatch(
        r"\$?(?P<column>[A-Za-z]+)\$?(?P<row>\d+)",
        str(value or ""),
    )
    if match is None:
        return None
    column = 0
    for character in match.group("column").upper():
        column = column * 26 + ord(character) - ord("A") + 1
    row = int(match.group("row"))
    return (row, column) if row > 0 and column > 0 else None


def _spreadsheet_item_position(item: Any) -> tuple[tuple[int, str], int, int] | None:
    """Recover a physical worksheet coordinate from native evidence provenance."""

    source_ref = item.source_ref
    extras = source_ref.model_extra or {}
    row = extras.get("source_row")
    column = extras.get("source_column")
    if isinstance(row, int) and isinstance(column, int) and row > 0 and column > 0:
        sheet = str(source_ref.sheet or "").strip()
        if not sheet:
            native_refs = extras.get("native_source_refs") or []
            sheet = next(
                (
                    str(reference.get("sheet") or "").strip()
                    for reference in native_refs
                    if isinstance(reference, dict) and reference.get("sheet")
                ),
                "",
            )
        return (int(source_ref.page or 0), sheet or "Sheet1"), row, column

    candidates: list[tuple[str, str]] = []
    if source_ref.sheet and source_ref.cell:
        candidates.append((str(source_ref.sheet), str(source_ref.cell)))
    for reference in extras.get("native_source_refs") or []:
        if not isinstance(reference, dict):
            continue
        if reference.get("sheet") and reference.get("cell"):
            candidates.append((str(reference["sheet"]), str(reference["cell"])))
    part_match = re.fullmatch(
        r"spreadsheet/(?P<sheet>[^/]+)/(?P<cell>\$?[A-Za-z]+\$?\d+)",
        str(source_ref.part or ""),
    )
    if part_match is not None:
        candidates.append((part_match.group("sheet"), part_match.group("cell")))
    for sheet, cell in candidates:
        position = _a1_position(cell)
        if position is not None:
            return (int(source_ref.page or 0), sheet), position[0], position[1]
    return None


def _quoted_source_ref(item: Any) -> SourceReference:
    payload = item.source_ref.model_dump(mode="json", exclude_none=True)
    payload.setdefault("evidence_id", item.evidence_id)
    payload.setdefault("evidence_quote", item.exact_text or item.text)
    return SourceReference.model_validate(payload)


def _purchase_grid_value(
    name: str,
    value: str,
    *,
    date_1904: bool = False,
) -> str | None:
    normalized = " ".join(unicodedata.normalize("NFKC", value).split())
    if name in {"order_date", "delivery_date"}:
        match = re.search(
            r"(?:19|20)\d{2}\s*(?:年|[-./])\s*\d{1,2}\s*"
            r"(?:月|[-./])\s*\d{1,2}\s*日?",
            normalized,
        )
        if match:
            return _complete_purchase_date_iso(match.group(0))
        try:
            serial = Decimal(normalized)
        except (InvalidOperation, ValueError):
            return None
        minimum_serial = Decimal(0) if date_1904 else Decimal(1)
        if not serial.is_finite() or not minimum_serial <= serial <= Decimal(2958465):
            return None
        base = date(1904, 1, 1) if date_1904 else date(1899, 12, 30)
        try:
            return (base + timedelta(days=int(serial))).isoformat()
        except (OverflowError, ValueError):
            return None
    if name in {"contract_number", "order_number"}:
        return normalized if _PURCHASE_SPATIAL_NUMBER.fullmatch(normalized) else None
    if name in {"buyer", "seller", "supplier"}:
        candidates = {
            line
            for raw_line in unicodedata.normalize("NFKC", value).splitlines()
            if (line := " ".join(raw_line.split()))
            and _PURCHASE_SPATIAL_COMPANY.fullmatch(line)
        }
        return next(iter(candidates)) if len(candidates) == 1 else None
    if name == "payment_terms":
        return (
            normalized
            if 1 < len(normalized) <= 256
            and _PURCHASE_PAYMENT_TERMS.fullmatch(normalized)
            else None
        )
    if name == "delivery_address":
        return (
            normalized
            if 4 <= len(normalized) <= 512
            and _PURCHASE_ADDRESS_SIGNAL.search(normalized)
            else None
        )
    if name == "currency":
        token = normalized.upper()
        aliases = {
            "RMB": "CNY",
            "人民币": "CNY",
            "美元": "USD",
            "欧元": "EUR",
            "港币": "HKD",
            "日元": "JPY",
        }
        if re.fullmatch(r"[A-Z]{3}|人民币|美元|欧元|港币|日元", token):
            return aliases.get(token, token)
    return None


def _purchase_grid_label_names(value: str) -> tuple[str, ...]:
    normalized = " ".join(unicodedata.normalize("NFKC", value).split())
    return tuple(
        name
        for name, pattern in _PURCHASE_GRID_LABELS.items()
        if pattern.fullmatch(normalized) is not None
    )


def _grid_purchase_header_candidates(
    evidence: DocumentEvidence,
) -> dict[str, list[tuple[str, Any]]]:
    """Pair sparse worksheet label/value cells using physical coordinates."""

    grouped: dict[tuple[tuple[int, str], int], list[tuple[int, Any]]] = {}
    for item in evidence_inventory(evidence).values():
        position = _spreadsheet_item_position(item)
        if position is None:
            continue
        page_sheet, row, column = position
        grouped.setdefault((page_sheet, row), []).append((column, item))

    result: dict[str, list[tuple[str, Any]]] = {}
    for row_items in grouped.values():
        ordered = sorted(row_items, key=lambda pair: pair[0])
        for index, (_label_column, label) in enumerate(ordered):
            names = _purchase_grid_label_names(label.exact_text or label.text)
            if not names:
                continue
            for _candidate_column, candidate in ordered[index + 1 :]:
                candidate_text = candidate.exact_text or candidate.text
                if _purchase_grid_label_names(candidate_text):
                    break
                for name in names:
                    value = _purchase_grid_value(
                        name,
                        candidate_text,
                        date_1904=bool(
                            (evidence.raw or {}).get("spreadsheet_date_1904")
                        ),
                    )
                    if value is None:
                        continue
                    result.setdefault(name, []).append(
                        (value, _quoted_source_ref(candidate))
                    )
                # The first populated cell after a label is the only safe
                # grid neighbour. Skipping over an unrelated note silently
                # binds a later value to the wrong label.
                break
    return result


def _unlabeled_purchase_company_candidates(
    evidence: DocumentEvidence,
    *,
    excluded_values: set[str],
) -> list[tuple[str, Any]]:
    """Find one letterhead company after explicit counterparties are excluded."""

    excluded = {
        unicodedata.normalize("NFKC", value).strip().casefold()
        for value in excluded_values
        if value
    }
    inventory = list(evidence_inventory(evidence).values())
    title_positions = [
        position
        for item in inventory
        if _PURCHASE_TITLE.fullmatch(
            re.sub(r"\s+", "", item.exact_text or item.text).strip()
        )
        and (position := _spreadsheet_item_position(item)) is not None
    ]
    if not title_positions:
        return []

    candidates: list[tuple[str, Any]] = []
    for item in inventory:
        position = _spreadsheet_item_position(item)
        if position is None:
            continue
        page_sheet, row, _column = position
        if not any(
            title_page_sheet == page_sheet and -1 <= title_row - row <= 4
            for title_page_sheet, title_row, _title_column in title_positions
        ):
            continue
        raw = item.exact_text or item.text
        normalized = " ".join(unicodedata.normalize("NFKC", raw).split())
        if _purchase_grid_label_names(normalized):
            continue
        if not _PURCHASE_SPATIAL_COMPANY.fullmatch(normalized):
            continue
        if normalized.casefold() in excluded:
            continue
        candidates.append((normalized, _quoted_source_ref(item)))
    return candidates


def _reference_bbox(source_ref: Any) -> tuple[float, float, float, float] | None:
    raw = (getattr(source_ref, "model_extra", None) or {}).get("bbox")
    if not isinstance(raw, (list, tuple)) or len(raw) != 4:
        return None
    try:
        x0, y0, x1, y1 = (float(value) for value in raw)
    except (TypeError, ValueError):
        return None
    return (x0, y0, x1, y1) if x1 > x0 and y1 > y0 else None


def _purchase_spatial_value(name: str, value: str) -> str | None:
    normalized = " ".join(unicodedata.normalize("NFKC", value).split())
    if name in {"order_date", "delivery_date"}:
        return _complete_purchase_date_iso(normalized)
    if name in {"contract_number", "order_number"}:
        return normalized if _PURCHASE_SPATIAL_NUMBER.fullmatch(normalized) else None
    if name in {"buyer", "seller", "supplier"}:
        candidates = {
            line
            for raw_line in unicodedata.normalize("NFKC", value).splitlines()
            if (line := " ".join(raw_line.split()))
            and _PURCHASE_SPATIAL_COMPANY.fullmatch(line)
        }
        return next(iter(candidates)) if len(candidates) == 1 else None
    return None


def _spatial_purchase_header_candidates(
    evidence: DocumentEvidence,
) -> dict[str, list[tuple[str, Any]]]:
    items = [
        item
        for item in evidence_inventory(evidence).values()
        if item.table_id is None and _reference_bbox(item.source_ref) is not None
    ]
    result: dict[str, list[tuple[str, Any]]] = {}
    for label in items:
        label_text = " ".join(label.text.split())
        label_bbox = _reference_bbox(label.source_ref)
        if label_bbox is None:
            continue
        for name, pattern in _PURCHASE_SPATIAL_LABELS.items():
            if pattern.fullmatch(label_text) is None:
                continue
            lx0, ly0, lx1, ly1 = label_bbox
            label_height = ly1 - ly0
            candidates: list[tuple[float, Any, str]] = []
            for item in items:
                if item.evidence_id == label.evidence_id:
                    continue
                if item.source_ref.page != label.source_ref.page:
                    continue
                candidate_value = _purchase_spatial_value(
                    name,
                    item.exact_text or item.text,
                )
                if candidate_value is None:
                    continue
                candidate_bbox = _reference_bbox(item.source_ref)
                if candidate_bbox is None:
                    continue
                x0, y0, x1, y1 = candidate_bbox
                vertical_overlap = max(0.0, min(ly1, y1) - max(ly0, y0))
                right_aligned = (
                    x0 >= lx1 - label_height * 0.25
                    and vertical_overlap >= min(label_height, y1 - y0) * 0.35
                )
                horizontal_overlap = max(0.0, min(lx1, x1) - max(lx0, x0))
                below_aligned = (
                    y0 >= ly1 - label_height * 0.25
                    and horizontal_overlap >= min(lx1 - lx0, x1 - x0) * 0.35
                )
                if right_aligned:
                    score = max(0.0, x0 - lx1) + abs((y0 + y1) - (ly0 + ly1)) * 2
                elif below_aligned:
                    score = max(0.0, y0 - ly1) * 3 + abs((x0 + x1) - (lx0 + lx1))
                else:
                    continue
                candidates.append((score, item, candidate_value))
            if not candidates:
                continue
            best_score = min(score for score, _item, _value in candidates)
            winners = [
                (item, value)
                for score, item, value in candidates
                if abs(score - best_score) <= max(1e-6, label_height * 0.1)
            ]
            values = {value for _item, value in winners}
            if len(values) != 1:
                continue
            selected, selected_value = winners[0]
            result.setdefault(name, []).append(
                (selected_value, selected.source_ref)
            )
    return result


def _layout_split_text_sources(
    sources: list[tuple[str, Any]],
) -> list[tuple[str, Any]]:
    return [
        (re.sub(r"[ \t]{2,}", "\n", text), source_ref) for text, source_ref in sources
    ]


_PURCHASE_TITLE_COMPANY = re.compile(
    r"[\u4e00-\u9fff]{2,64}"
    r"(?:股份有限公司|有限责任公司|有限公司|集团公司|公司|工厂|厂)"
)


def _purchase_title_buyer_candidates(
    sources: list[tuple[str, Any]],
) -> list[tuple[str, Any]]:
    """Find the legal entity immediately associated with a purchase title."""

    candidates: list[tuple[str, Any]] = []
    for text, source_ref in sources:
        lines = [
            line.strip(" \t|")
            for line in unicodedata.normalize("NFKC", text).splitlines()
            if line.strip(" \t|")
        ]
        for index, line in enumerate(lines):
            title = _PURCHASE_TITLE.search(line)
            if title is None:
                continue
            prefix = line[: title.start()]
            if any(
                _PURCHASE_HEADER_PATTERNS[role].search(prefix) is not None
                for role in ("buyer", "seller", "supplier")
            ):
                continue
            inline = list(_PURCHASE_TITLE_COMPANY.finditer(prefix))
            if inline:
                candidates.append((inline[-1].group(0), source_ref))
                continue
            if index == 0:
                continue
            previous = _PURCHASE_TITLE_COMPANY.fullmatch(lines[index - 1])
            if previous is not None:
                candidates.append((previous.group(0), source_ref))

    # Layout parsers commonly emit a letterhead company and the document title
    # as two adjacent blocks. Accept only the immediately preceding block on
    # the same page; labeled counterpart evidence is still required by the
    # caller before this candidate may become the buyer.
    for index in range(1, len(sources)):
        title_text, title_ref = sources[index]
        title_lines = [
            line.strip(" \t|")
            for line in unicodedata.normalize("NFKC", title_text).splitlines()
            if line.strip(" \t|")
        ]
        if not title_lines or _PURCHASE_TITLE.fullmatch(title_lines[0]) is None:
            continue
        company_text, company_ref = sources[index - 1]
        company_lines = [
            line.strip(" \t|")
            for line in unicodedata.normalize("NFKC", company_text).splitlines()
            if line.strip(" \t|")
        ]
        if len(company_lines) != 1:
            continue
        company = _PURCHASE_TITLE_COMPANY.fullmatch(company_lines[0])
        if company is None:
            continue
        title_page = getattr(title_ref, "page", None)
        company_page = getattr(company_ref, "page", None)
        if (
            title_page is not None
            and company_page is not None
            and title_page != company_page
        ):
            continue
        title_bbox = _reference_bbox(title_ref)
        company_bbox = _reference_bbox(company_ref)
        if title_bbox is None or company_bbox is None:
            continue
        tx0, ty0, tx1, ty1 = title_bbox
        cx0, cy0, cx1, cy1 = company_bbox
        title_height = ty1 - ty0
        company_height = cy1 - cy0
        horizontal_overlap = max(0.0, min(tx1, cx1) - max(tx0, cx0))
        if (
            cy1 > ty0 + max(title_height, company_height) * 0.25
            or ty0 - cy1 > max(title_height, company_height) * 3
            or horizontal_overlap < min(tx1 - tx0, cx1 - cx0) * 0.2
        ):
            continue
        candidates.append((company.group(0), company_ref))
    return candidates


_TOTAL_LABEL_TOKENS = {
    "合同总额",
    "合同金额",
    "价税合计",
    "总金额",
    "合计金额",
    "金额合计",
    "grandtotal",
    "totalamount",
}
_MONEY_VALUE = re.compile(r"^[¥￥$]?\s*\d[\d,]*(?:\.\d+)?$")
_DECLARED_QUANTITY_LABELS = {
    "合计",
    "总计",
    "总数量",
    "合计数量",
    "数量合计",
    "总件数",
    "件数合计",
    "total",
    "totalquantity",
}
_DECLARED_AMOUNT_LABELS = {
    "合同总额",
    "合同金额",
    "价税合计",
    "总金额",
    "合计金额",
    "金额合计",
    "grandtotal",
    "totalamount",
}


def _decimal_source_value(value: Any) -> Decimal | None:
    token = re.sub(r"^[¥￥$]\s*", "", str(value or "").strip()).replace(",", "")
    try:
        parsed = Decimal(token)
    except (InvalidOperation, ValueError):
        return None
    return parsed if parsed.is_finite() else None


def _derived_declared_order_totals(
    lines: list[dict[str, Any]],
    evidence: DocumentEvidence,
) -> dict[str, tuple[Any, list[dict[str, Any]]]]:
    """Preserve unique labeled source totals even when the source is inconsistent."""

    if not lines:
        return {}
    label_sets = {
        "declared_quantity": _DECLARED_QUANTITY_LABELS,
        "declared_amount": _DECLARED_AMOUNT_LABELS,
    }
    rows: dict[tuple[Any, ...], list[tuple[int, Any]]] = {}
    for item in evidence_inventory(evidence).values():
        physical = _spreadsheet_item_position(item)
        if physical is not None:
            page_sheet, row, column = physical
            rows.setdefault(("sheet", *page_sheet, row), []).append((column, item))
            continue
        if item.table_id is not None and item.row is not None and item.column is not None:
            rows.setdefault(("table", item.table_id, item.row), []).append(
                (item.column, item)
            )

    derived: dict[str, tuple[Any, list[dict[str, Any]]]] = {}
    for field, labels in label_sets.items():
        candidates: list[tuple[Decimal, Any]] = []
        all_summary_labels = set().union(*label_sets.values())
        for row_items in rows.values():
            ordered = sorted(row_items, key=lambda pair: pair[0])
            for index, (_label_column, label) in enumerate(ordered):
                if _field_alias_token(label.exact_text or label.text) not in labels:
                    continue
                for _value_column, item in ordered[index + 1 :]:
                    token = _field_alias_token(item.exact_text or item.text)
                    if token in all_summary_labels:
                        break
                    value = _decimal_source_value(item.exact_text or item.text)
                    if value is None:
                        continue
                    candidates.append((value, item))
                    break
        by_value: dict[Decimal, list[dict[str, Any]]] = {}
        for value, item in candidates:
            reference = _quoted_source_ref(item).model_dump(
                mode="json",
                exclude_none=True,
            )
            references = by_value.setdefault(value, [])
            if reference not in references:
                references.append(reference)
        if len(by_value) != 1:
            continue
        selected_value, references = next(iter(by_value.items()))
        value: Any = (
            int(selected_value)
            if selected_value == selected_value.to_integral_value()
            else selected_value
        )
        derived[field] = (value, references)
    return derived


def _purchase_table_total_candidates(
    evidence: DocumentEvidence,
    primary_table_ids: set[str] | None = None,
) -> list[tuple[str, Any]]:
    inventory = evidence_inventory(evidence)
    rows: dict[tuple[str, int], list[Any]] = {}
    table_rows: dict[str, set[int]] = {}
    for item in inventory.values():
        if item.table_id is None or item.row is None or item.column is None:
            continue
        rows.setdefault((item.table_id, item.row), []).append(item)
        table_rows.setdefault(item.table_id, set()).add(item.row)

    allowed_table_ids = set(primary_table_ids or ())
    if not allowed_table_ids and len(table_rows) == 1:
        allowed_table_ids = set(table_rows)

    candidates: list[tuple[str, Any]] = []
    for (table_id, row), items in rows.items():
        if table_id not in allowed_table_ids:
            continue
        last_row = max(table_rows[table_id])
        if row < last_row - 1:
            continue
        ordered = sorted(items, key=lambda item: item.column)
        label_columns = [
            item.column
            for item in ordered
            if re.sub(
                r"[\s_\-:/：()（）]+",
                "",
                unicodedata.normalize("NFKC", item.exact_text or item.text).casefold(),
            )
            in _TOTAL_LABEL_TOKENS
        ]
        if not label_columns:
            continue
        values = [
            item
            for item in ordered
            if item.column > min(label_columns)
            and _MONEY_VALUE.fullmatch((item.exact_text or item.text).strip())
        ]
        unique_values = {
            _normalized_header_value("total_amount", item.exact_text or item.text)
            for item in values
        }
        if len(unique_values) != 1:
            continue
        value = next(iter(unique_values))
        for item in values:
            if (
                _normalized_header_value("total_amount", item.exact_text or item.text)
                == value
            ):
                candidates.append((value, item.source_ref))
                break
    return candidates


def _derived_purchase_headers(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> dict[str, tuple[Any, list[dict[str, Any]]]]:
    sources = _layout_split_text_sources(_extracted_text_sources(extracted, evidence))
    spatial_candidates = (
        _spatial_purchase_header_candidates(evidence) if evidence is not None else {}
    )
    grid_candidates = (
        _grid_purchase_header_candidates(evidence) if evidence is not None else {}
    )
    derived: dict[str, tuple[Any, list[dict[str, Any]]]] = {}
    labeled_counterparties: set[str] = set()
    title_candidates = [
        (compact, source_ref)
        for text, source_ref in sources
        for line in text.splitlines()
        if len(line.strip()) <= 64
        for compact in [re.sub(r"\s+", "", line.strip())]
        for match in [_PURCHASE_TITLE.fullmatch(compact)]
        if match is not None
    ]
    if title := _single_evidence_value(title_candidates):
        derived["title"] = title
    for name, pattern in _PURCHASE_HEADER_PATTERNS.items():
        candidates = [
            (
                _normalized_header_value(
                    name,
                    re.sub(r"\s+", "", match.group("value")).strip(),
                ),
                source_ref,
            )
            for text, source_ref in sources
            for match in pattern.finditer(text)
            if match.group("value").strip()
            and (
                name not in {"order_date", "delivery_date"}
                or _complete_purchase_date_iso(match.group("value")) is not None
            )
            and (
                name != "total_amount"
                or (source_ref.cell is None and "/r" not in str(source_ref.part or ""))
            )
        ]
        candidates.extend(spatial_candidates.get(name, []))
        candidates.extend(grid_candidates.get(name, []))
        if name == "total_amount" and evidence is not None:
            candidates.extend(
                _purchase_table_total_candidates(
                    evidence,
                    set(extracted.primary_record_table_ids),
                )
            )
        if name == "order_number":
            candidates = _reconcile_labeled_order_number_candidates(candidates)
        if name in {"buyer", "seller", "supplier"}:
            candidates = [
                (value, source_ref)
                for value, source_ref in candidates
                if _PARTY_LEGAL_SUFFIX.search(
                    unicodedata.normalize("NFKC", value).strip()
                )
            ]
        if name in {"seller", "supplier"}:
            labeled_counterparties.update(
                value
                for value, _source_ref in candidates
                if _PARTY_LEGAL_SUFFIX.search(
                    unicodedata.normalize("NFKC", value).strip()
                )
            )
        selector = (
            _single_party_evidence_value
            if name in {"buyer", "seller", "supplier"}
            else _single_evidence_value
        )
        if selected := selector(candidates):
            derived[name] = selected
    if "supplier" in derived and "seller" not in derived:
        derived["seller"] = copy.deepcopy(derived["supplier"])
    elif "seller" in derived and "supplier" not in derived:
        derived["supplier"] = copy.deepcopy(derived["seller"])
    if "buyer" not in derived:
        counterparties = {
            str(derived[name][0]) for name in ("seller", "supplier") if name in derived
        } | labeled_counterparties
        if counterparties:
            title_candidates = [
                (value, source_ref)
                for value, source_ref in _purchase_title_buyer_candidates(sources)
                if not any(
                    _party_values_equivalent({value, counterparty})
                    for counterparty in counterparties
                )
            ]
            if selected_buyer := _single_party_evidence_value(title_candidates):
                derived["buyer"] = selected_buyer
                derived["issuer"] = copy.deepcopy(selected_buyer)
    if "buyer" not in derived and evidence is not None and derived.get("title"):
        counterparties = {
            str(derived[name][0]) for name in ("seller", "supplier") if name in derived
        } | labeled_counterparties
        if counterparties:
            selected_buyer = _single_party_evidence_value(
                _unlabeled_purchase_company_candidates(
                    evidence,
                    excluded_values=counterparties,
                )
            )
            if selected_buyer is not None:
                derived["buyer"] = selected_buyer
                derived["issuer"] = copy.deepcopy(selected_buyer)
    currency_candidates = [
        (match.group(1).upper(), source_ref)
        for text, source_ref in sources
        for match in re.finditer(
            r"(?<![A-Za-z])(?:currency\s*[:：]\s*)?"
            r"(RMB|CNY|USD|EUR|HKD|JPY|GBP)(?![A-Za-z])",
            text,
            re.IGNORECASE,
        )
    ]
    currency_candidates.extend(grid_candidates.get("currency", []))
    if selected_currency := _single_evidence_value(currency_candidates):
        derived["currency"] = selected_currency
    return derived


_STOCKING_HEADER_PATTERNS: dict[str, re.Pattern[str]] = {
    "source_order_number": re.compile(
        r"(?:来源订单号|原订单号|订单号码)\s*[:：]?\s*"
        r"(?P<value>[A-Za-z0-9][A-Za-z0-9_.\-/]{1,127})",
        re.IGNORECASE,
    ),
    "order_number": re.compile(
        r"(?:备货单号|订单号(?!码)|order\s*(?:number|no\.?))\s*[:：]?\s*"
        r"(?P<value>[A-Za-z0-9][A-Za-z0-9_.\-/]{1,127})",
        re.IGNORECASE,
    ),
    "order_date_raw": re.compile(
        r"(?:下单日期|订单日期|order\s+date)\s*[:：]?\s*"
        r"(?P<value>(?:\d{4}\s*(?:年|[-./])\s*)?\d{1,2}\s*"
        r"(?:月|[-./])\s*\d{1,2}\s*日?)",
        re.IGNORECASE,
    ),
    "delivery_date_raw": re.compile(
        r"(?:交货日期|交期|delivery\s+date)\s*[:：]?\s*"
        r"(?P<value>(?:\d{4}\s*(?:年|[-./])\s*)?\d{1,2}\s*"
        r"(?:月|[-./])\s*\d{1,2}\s*日?)",
        re.IGNORECASE,
    ),
}
_STOCKING_TITLE = re.compile(r"(?:备货单|stocking\s+order)", re.IGNORECASE)
_LEGAL_COMPANY = re.compile(
    r"[\u4e00-\u9fffA-Za-z0-9()（）·]{2,128}(?:有限公司|公司|工厂|厂)",
    re.IGNORECASE,
)


def _derived_stocking_headers(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> dict[str, tuple[Any, list[dict[str, Any]]]]:
    sources = _layout_split_text_sources(_extracted_text_sources(extracted, evidence))
    derived: dict[str, tuple[Any, list[dict[str, Any]]]] = {}
    title_candidates = [
        (line.strip(), source_ref)
        for text, source_ref in sources
        for line in text.splitlines()
        if _STOCKING_TITLE.fullmatch(line.strip())
    ]
    if selected := _single_evidence_value(title_candidates):
        derived["document_title"] = selected
    company_candidates = [
        (line.strip(), source_ref)
        for text, source_ref in sources
        for line in text.splitlines()
        if _LEGAL_COMPANY.fullmatch(line.strip())
    ]
    if selected := _single_evidence_value(company_candidates):
        derived["company"] = selected
    for name, pattern in _STOCKING_HEADER_PATTERNS.items():
        candidates = [
            (match.group("value").strip(), source_ref)
            for text, source_ref in sources
            for match in pattern.finditer(text)
        ]
        if selected := _single_evidence_value(candidates):
            derived[name] = selected
    return derived


_GENERIC_ORDER_TITLE = re.compile(
    r"(?i)^(?!.*(?:订单号|订单编号|order\s*(?:no|number))\s*[:：])"
    r".{0,96}(?:订单|order|样品(?:需求|申请)?单)\s*$"
)
_TITLE_DATE = re.compile(
    r"(?P<value>(?:20\d{2}\s*年\s*)?\d{1,2}\s*月\s*\d{1,2}\s*日)"
)
_SAMPLE_REQUEST_TITLE = re.compile(r"样品(?:需求|申请)?单")
_GENERIC_ORDER_DATE = re.compile(
    r"(?:下单日期|订单日期|日期)\s*[:：]?\s*"
    r"(?P<value>20\d{2}\s*(?:年|[-./])\s*\d{1,2}\s*"
    r"(?:月|[-./])\s*\d{1,2}\s*日?)"
)
_GENERIC_ORDER_SUPPLIER = re.compile(
    r"(?:供应商|供方|卖方)\s*[:：]\s*(?P<value>[^\n|;；]{2,128})"
)


def _derived_generic_order_headers(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> dict[str, tuple[Any, list[dict[str, Any]]]]:
    """Recover source-backed title/date fields shared by ordinary orders."""

    candidates: list[tuple[str, Any]] = []
    for text, source_ref in _extracted_text_sources(extracted, evidence):
        normalized = unicodedata.normalize("NFKC", text).strip()
        if not _GENERIC_ORDER_TITLE.fullmatch(normalized):
            continue
        cell = str(source_ref.cell or "")
        cell_match = re.fullmatch(r"[A-Za-z]+(\d+)", cell)
        part = str(source_ref.part or "")
        top_block = source_ref.page == 1 and "/b" in part
        if cell_match is not None and int(cell_match.group(1)) <= 4 or top_block:
            sample_title = _SAMPLE_REQUEST_TITLE.search(normalized)
            candidates.append(
                (sample_title.group(0) if sample_title else normalized, source_ref)
            )
    derived: dict[str, tuple[Any, list[dict[str, Any]]]] = {}
    title = _single_evidence_value(candidates)
    if title is None:
        return derived
    derived["document_title"] = title
    date_candidates = [
        (match.group("value"), source_ref)
        for value, source_ref in candidates
        if (match := _TITLE_DATE.search(value)) is not None
    ]
    if selected_date := _single_evidence_value(date_candidates):
        derived["order_date_raw"] = selected_date
    if _SAMPLE_REQUEST_TITLE.search(str(title[0])) is not None:
        sources = _extracted_text_sources(extracted, evidence)
        company_candidates = [
            (match.group(0), source_ref)
            for text, source_ref in sources
            for match in _PURCHASE_TITLE_COMPANY.finditer(text)
        ]
        if selected_company := _single_party_evidence_value(company_candidates):
            derived["company"] = selected_company
            derived["buyer"] = copy.deepcopy(selected_company)
        supplier_candidates = [
            (match.group("value").strip(), source_ref)
            for text, source_ref in sources
            for match in _GENERIC_ORDER_SUPPLIER.finditer(text)
        ]
        if selected_supplier := _single_party_evidence_value(supplier_candidates):
            derived["supplier"] = selected_supplier
            derived["seller"] = copy.deepcopy(selected_supplier)
        explicit_dates = [
            (_normalized_header_value("order_date", match.group("value")), source_ref)
            for text, source_ref in sources
            for match in _GENERIC_ORDER_DATE.finditer(text)
        ]
        if selected_date := _single_evidence_value(explicit_dates):
            derived["order_date_raw"] = selected_date
    return derived


def _purchase_fact_has_labeled_evidence(fact: ExtractedFact) -> bool:
    pattern_name = {
        "order_date_raw": "order_date",
        "delivery_date_raw": "delivery_date",
    }.get(fact.name, fact.name)
    pattern = _PURCHASE_HEADER_PATTERNS.get(pattern_name)
    if pattern is None:
        return True
    expected = _normalized_header_value(pattern_name, fact.value)
    expected_token = re.sub(r"\s+", "", expected).casefold()
    return any(
        expected_token
        == re.sub(
            r"\s+",
            "",
            _normalized_header_value(pattern_name, match.group("value")),
        ).casefold()
        for reference in fact.evidence_refs
        if _trusted_source_ref(reference.source_ref)
        for match in pattern.finditer(reference.quote)
    )


_CONTRACT_CLAUSE_MARKER = re.compile(
    r"(?m)^[ \t]*(?P<number>\d{1,2})\s*(?:[、．)）]|[.](?!\d))\s*"
)
_CONTRACT_TERMS_HEADING = re.compile(
    r"(?:^|\n)[ \t]*(?:合同条款|contract\s+terms?)[ \t]*[:：]?[ \t]*(?:\n|$)",
    re.IGNORECASE,
)
_CONTRACT_REGION_BOUNDARY = re.compile(
    r"^(?:附件|附录|签章|签署|签字|盖章|甲方签章|乙方签章|"
    r"法定代表人|授权代表|备注|产品明细|采购明细|物料明细|"
    r"appendix|annex|signatures?|remarks?)[ \t]*[:：]?$",
    re.IGNORECASE,
)


def _contract_clause_spans(text: str) -> list[tuple[int, int, int, str]]:
    matches = list(_CONTRACT_CLAUSE_MARKER.finditer(text))
    spans: list[tuple[int, int, int, str]] = []
    for index, match in enumerate(matches):
        raw_start = match.start()
        raw_end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        raw_slice = text[raw_start:raw_end]
        leading = len(raw_slice) - len(raw_slice.lstrip())
        trailing = len(raw_slice) - len(raw_slice.rstrip())
        start = raw_start + leading
        end = raw_end - trailing
        exact_text = text[start:end]
        if exact_text:
            spans.append((int(match.group("number")), start, end, exact_text))
    return spans


def _normalized_clause_text(value: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", value)).casefold()


def _contract_clause_region_boundary(text: str, source_kind: str) -> bool:
    stripped = unicodedata.normalize("NFKC", text).strip()
    if not stripped:
        return False
    first_line = stripped.splitlines()[0].strip()
    if _CONTRACT_REGION_BOUNDARY.fullmatch(first_line):
        return True
    if source_kind.casefold() == "table_cell":
        token = _field_alias_token(stripped)
        return token in (_GENERIC_TABLE_LABELS - {_field_alias_token("合同条款")})
    return False


def _contract_clause_region(
    evidence: list[tuple[str, str, Any, str]],
) -> list[tuple[int, str, int, int, str, Any, str]]:
    """Select one unambiguous numbered region after an explicit heading."""

    regions: list[list[tuple[int, str, int, int, str, Any, str]]] = []
    active: list[tuple[int, str, int, int, str, Any, str]] | None = None
    active_page: int | None = None

    def finish() -> None:
        nonlocal active
        if active:
            regions.append(active)
        active = None

    for evidence_id, text, source_ref, source_kind in evidence:
        heading = _CONTRACT_TERMS_HEADING.search(text)
        page = source_ref.page
        if heading is not None:
            finish()
            active = []
            active_page = page
            scan_text = text[heading.end() :]
            offset = heading.end()
        elif active is not None:
            if page != active_page or _contract_clause_region_boundary(
                text,
                source_kind,
            ):
                finish()
                continue
            scan_text = text
            offset = 0
        else:
            continue

        for number, start, end, exact_text in _contract_clause_spans(scan_text):
            absolute_start = offset + start
            absolute_end = offset + end
            if text[absolute_start:absolute_end] != exact_text:
                continue
            active.append(
                (
                    number,
                    evidence_id,
                    absolute_start,
                    absolute_end,
                    exact_text,
                    source_ref,
                    source_kind,
                )
            )
    finish()

    valid_regions: list[list[tuple[int, str, int, int, str, Any, str]]] = []
    for region in regions:
        by_number: dict[
            int,
            list[tuple[int, str, int, int, str, Any, str]],
        ] = {}
        seen: set[tuple[int, str, str]] = set()
        for item in region:
            number, evidence_id, _start, _end, exact_text, _ref, _kind = item
            marker = (number, _normalized_clause_text(exact_text), evidence_id)
            if marker in seen:
                continue
            seen.add(marker)
            by_number.setdefault(number, []).append(item)
        numbers = sorted(by_number)
        if not numbers or numbers != list(range(1, numbers[-1] + 1)):
            continue
        if numbers[-1] < 3:
            continue
        if any(
            len({_normalized_clause_text(item[4]) for item in items}) != 1
            for items in by_number.values()
        ):
            continue
        valid_regions.append([by_number[number][0] for number in numbers])

    signatures = {
        tuple((item[0], _normalized_clause_text(item[4])) for item in region)
        for region in valid_regions
    }
    if len(signatures) != 1:
        return []
    return valid_regions[0]


_DOCX_PARAGRAPH = re.compile(r"(?:^|/)docx:p:(?P<index>\d+)$")


def _deterministic_docx_process_units(
    evidence: list[tuple[str, str, Any, str]],
) -> list[dict[str, Any]]:
    """Bind only paragraphs immediately following an explicit process heading."""

    paragraphs: list[tuple[int, str, str, Any, str]] = []
    for evidence_id, text, source_ref, source_kind in evidence:
        match = _DOCX_PARAGRAPH.search(str(source_ref.part or ""))
        if match is None:
            continue
        paragraphs.append(
            (int(match.group("index")), evidence_id, text, source_ref, source_kind)
        )
    paragraphs.sort(key=lambda value: value[0])
    heading_indexes = [
        index
        for index, _evidence_id, text, _source_ref, _source_kind in paragraphs
        if _field_alias_token(text) in {"工艺流程", "processflow", "workflow"}
    ]
    if len(heading_indexes) != 1:
        return []

    heading_index = heading_indexes[0]
    selected: list[tuple[int, str, str, Any, str]] = []
    previous = heading_index
    for item in paragraphs:
        index, _evidence_id, text, _source_ref, _source_kind = item
        if index <= heading_index:
            continue
        if index - previous > 2:
            break
        if re.search(
            r"规格表|参数表|图纸|产品名称|外径尺寸|内径尺寸|drawing|specification",
            text,
            re.IGNORECASE,
        ):
            break
        tokens = [token for token in re.split(r"\s+|→|->|⇒", text) if token]
        if len(tokens) < 2:
            break
        selected.append(item)
        previous = index
    if not selected:
        return []

    units: list[dict[str, Any]] = []
    for index, evidence_id, text, source_ref, source_kind in selected:
        serialized_ref = source_ref.model_dump(mode="json", exclude_none=True)
        serialized_ref["parent_evidence_id"] = evidence_id
        units.append(
            {
                "evidence_id": f"{evidence_id}#process:{index}",
                "content_kind": "manufacturing_process",
                "label": "process_steps",
                "exact_text": text,
                "source_ref": serialized_ref,
                "source_kind": source_kind,
                "binding_source": "deterministic",
                "alternate_semantics": [],
                "atomization_source": "explicit_process_heading",
            }
        )
    return units


def _semantic_content_units_payload(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence | None = None,
) -> list[dict[str, Any]]:
    original = [item.model_dump(mode="json") for item in extracted.content_units]
    exact_evidence = _trusted_exact_evidence(extracted, evidence)
    result = list(original)

    if extracted.document_subtype == "purchase_contract":
        clause_evidence = _trusted_exact_evidence(
            extracted,
            evidence,
            preserve_text=True,
        )
        if evidence is not None:
            inventory_ids = set(evidence_inventory(evidence))
            seen_inventory_ids: set[str] = set()
            inventory_evidence = []
            for item in clause_evidence:
                if item[0] not in inventory_ids or item[0] in seen_inventory_ids:
                    continue
                seen_inventory_ids.add(item[0])
                inventory_evidence.append(item)
            clause_evidence = inventory_evidence

        existing_clauses: set[tuple[int, str]] = set()
        for item in result:
            if item.get("content_kind") != "contract_clause":
                continue
            label_match = re.search(
                r"(?:clause[_ -]?)?(\d{1,2})$",
                str(item.get("label", "")),
                re.IGNORECASE,
            )
            marker_match = _CONTRACT_CLAUSE_MARKER.search(
                str(item.get("exact_text", ""))
            )
            if label_match is None and marker_match is None:
                continue
            number = int(
                label_match.group(1)
                if label_match is not None
                else marker_match.group("number")
            )
            existing_clauses.add(
                (number, _normalized_clause_text(str(item.get("exact_text", ""))))
            )

        for (
            number,
            evidence_id,
            start,
            end,
            exact_text,
            source_ref,
            source_kind,
        ) in _contract_clause_region(clause_evidence):
            semantic_key = (number, _normalized_clause_text(exact_text))
            if semantic_key in existing_clauses:
                continue
            serialized_ref = source_ref.model_dump(mode="json", exclude_none=True)
            serialized_ref["parent_evidence_id"] = evidence_id
            parent_text = next(
                (
                    text
                    for candidate_id, text, _ref, _kind in clause_evidence
                    if candidate_id == evidence_id
                ),
                None,
            )
            if parent_text is not None and parent_text[start:end] == exact_text:
                serialized_ref.update(
                    {
                        "range": f"chars:{start}:{end}",
                        "coordinate_inferred": True,
                    }
                )
            result.append(
                {
                    "evidence_id": f"{evidence_id}#clause:{number}",
                    "content_kind": "contract_clause",
                    "label": f"clause_{number}",
                    "exact_text": exact_text,
                    "source_ref": serialized_ref,
                    "source_kind": source_kind,
                    "binding_source": "deterministic",
                    "alternate_semantics": [],
                    "atomization_source": "numbered_contract_clause",
                }
            )
            existing_clauses.add(semantic_key)

    if not any(
        item.get("binding_source") in {"model", "deterministic"}
        and any(
            marker
            in (f"{item.get('content_kind', '')} {item.get('label', '')}").casefold()
            for marker in ("process", "workflow", "step", "工艺", "步骤")
        )
        for item in result
    ):
        result.extend(_deterministic_docx_process_units(exact_evidence))
    return result


def _place_fact(
    fact: ExtractedFact,
    *,
    target: dict[str, Any],
    path_prefix: str,
    field_meta: dict[str, Any],
    field_names: dict[str, str],
    semantic_name: str | None = None,
    projected_value: Any | None = None,
    inferred: bool = False,
) -> None:
    projected_name = semantic_name or fact.name
    key = _unique_key(target, projected_name)
    value = fact.value if projected_value is None else projected_value
    target[key] = value
    path = f"{path_prefix}.{key}"
    source_refs = _source_refs(fact)
    effective_inferred = inferred or fact.inferred
    field_meta[path] = {
        "source_refs": source_refs,
        "inferred": effective_inferred,
        "inherited_from_merge": _source_refs_inherit_merge(source_refs),
        "source_label": fact.name,
    }
    if fact.inference_source:
        field_meta[path]["inference_source"] = fact.inference_source
        field_meta[path]["review_required"] = True
        field_meta[path]["confidence"] = 0.65
    if fact.mapping_source:
        field_meta[path]["mapping_source"] = fact.mapping_source
    if fact.original_name:
        field_meta[path]["original_source_label"] = fact.original_name
    if value != fact.value:
        field_meta[path]["source_value"] = fact.value
    field_names[path] = projected_name


_LINE_NUMBER_TOKENS = {"序号", "项次", "行号", "item", "lineno", "linenumber"}
_TYPED_ORDER_LINE_FIELDS = {
    "line_no",
    "model",
    "product_code",
    "name_raw",
    "name_normalized",
    "full_product_name",
    "product_category",
    "specification_raw",
    "body_printing",
    "color",
    "quantity",
    "unit",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "carton_specification",
    "volume",
    "packaging_requirements",
    "origin",
    "remark",
}


def _field_alias_token(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    return re.sub(r"[\s_\-:/：()（）]+", "", normalized)


def _lossless_mapping_key(target: dict[str, Any], label: str) -> str:
    base = str(label or "column").strip() or "column"
    if base not in target:
        return base
    index = 2
    while f"{base} [{index}]" in target:
        index += 1
    return f"{base} [{index}]"


def _mapping_field_path(prefix: str, container: str, key: str) -> str:
    return f"{prefix}.{container}[{json.dumps(key, ensure_ascii=False)}]"


def _canonical_record_field_name(
    document_subtype: str | None,
    source_label: str,
    *,
    document_type: str | None = None,
) -> str:
    if target_storage_key(source_label) is not None:
        return source_label
    domain = str(document_type or "").strip().casefold()
    if domain in {"", "unknown"}:
        domain = CANONICAL_SUBTYPE_TYPES.get(
            str(document_subtype or "").strip().casefold(),
            "unknown",
        )
    if domain not in {"order", "inventory", "equipment", "mold", "procurement"}:
        return source_label
    return source_label_line_target(source_label, domain) or source_label


_TAX_INCLUDED_CONTEXT_RE = re.compile(
    r"(?:此|本)?(?:单价|价格|金额)[^\n]{0,12}(?:含税|价税合计)|"
    r"(?:含税|价税合计)[^\n]{0,12}(?:单价|价格|金额)|"
    r"(?:tax[ -]?(?:inclusive|included)|including\s+tax)",
    re.IGNORECASE,
)
_TAX_EXCLUDED_CONTEXT_RE = re.compile(
    r"(?:单价|价格|金额)[^\n]{0,12}(?:不含税|未税)|"
    r"(?:不含税|未税)[^\n]{0,12}(?:单价|价格|金额)|"
    r"(?:tax[ -]?(?:exclusive|excluded)|excluding\s+tax)",
    re.IGNORECASE,
)
_AMBIGUOUS_PRICE_LABEL_TOKENS = {
    "单价",
    "价格",
    "金额",
    "unitprice",
    "price",
    "amount",
}


def _evidence_price_tax_mode(evidence: DocumentEvidence) -> str | None:
    """Return a document-wide price tax mode only when evidence is unambiguous."""

    text = "\n".join(
        [
            *(block.text for page in evidence.pages for block in page.blocks),
            *(
                str(cell)
                for page in evidence.pages
                for table in page.tables
                for row in table.rows
                for cell in row
                if cell not in (None, "")
            ),
        ]
    )
    included = bool(_TAX_INCLUDED_CONTEXT_RE.search(text))
    excluded = bool(_TAX_EXCLUDED_CONTEXT_RE.search(text))
    if included == excluded:
        return None
    return "included" if included else "excluded"


def _has_ambiguous_record_price_labels(extracted: MinerUInstructorResult) -> bool:
    return any(
        _field_alias_token(fact.name) in _AMBIGUOUS_PRICE_LABEL_TOKENS
        for segment in extracted.segments
        for record in segment.records
        for fact in record.fields
    )


def _apply_evidence_price_tax_mode(name: str, mode: str | None) -> str:
    if mode != "included":
        return name
    return {
        "unit_price_tax_excluded": "unit_price_tax_included",
        "amount_tax_excluded": "amount_tax_included",
    }.get(name, name)


def _normalize_document_classification_pair(
    document_type: str | None,
    document_subtype: str | None,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> tuple[str, str | None, bool, str | None]:
    """Keep a type/subtype pair coherent without letting a stale subtype win."""

    current_type = str(document_type or "unknown").strip() or "unknown"
    current_type = CANONICAL_SUBTYPE_TYPES.get(current_type, current_type)
    current_subtype = str(document_subtype or "").strip() or None
    if current_subtype == "unknown":
        current_subtype = None
    type_hint = str(document_type_hint or "").strip()
    subtype_hint = str(document_subtype_hint or "").strip()
    hinted_subtype_type = CANONICAL_SUBTYPE_TYPES.get(subtype_hint)
    if type_hint and subtype_hint and hinted_subtype_type and (
        type_hint != hinted_subtype_type
    ):
        raise MinerUContractError(
            "document type hint conflicts with the canonical subtype type"
        )

    selected_subtype = subtype_hint or current_subtype
    canonical_type = CANONICAL_SUBTYPE_TYPES.get(str(selected_subtype or ""))
    if subtype_hint:
        selected_type = canonical_type or type_hint or current_type
    elif type_hint:
        selected_type = type_hint
    else:
        selected_type = current_type

    conflict_type: str | None = None
    if canonical_type:
        if selected_type in {"", "unknown"}:
            selected_type = canonical_type
        elif canonical_type != selected_type:
            conflict_type = canonical_type
            selected_subtype = None
            canonical_type = None
    selected_type = str(selected_type or "unknown").strip() or "unknown"
    return selected_type, selected_subtype, bool(canonical_type), conflict_type


def _normalized_instructor_classification(
    extracted: MinerUInstructorResult,
    *,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> tuple[MinerUInstructorResult, dict[str, Any]]:
    """Lock explicit hints and keep subtype/type pairs canonical."""

    type_hint = str(document_type_hint or "").strip()
    subtype_hint = str(document_subtype_hint or "").strip()
    document_kind_label = (
        extracted.document_kind_label or extracted.document_intent
    )
    kind_type = CANONICAL_SUBTYPE_TYPES.get(str(document_kind_label or ""))
    kind_subtype_applied = bool(
        not extracted.document_subtype
        and kind_type
        and kind_type == extracted.document_intent_family
    )
    classification_subtype = (
        str(document_kind_label) if kind_subtype_applied else extracted.document_subtype
    )
    document_type, subtype, canonical_type_applied, conflict_type = (
        _normalize_document_classification_pair(
            extracted.document_intent_family,
            classification_subtype,
            document_type_hint=type_hint,
            document_subtype_hint=subtype_hint,
        )
    )
    structural_type = _structural_record_document_type(extracted)
    structural_type_applied = bool(
        structural_type
        and not type_hint
        and not subtype_hint
        and not canonical_type_applied
        and structural_type != document_type
    )
    if structural_type_applied:
        document_type = structural_type
        subtype_type = CANONICAL_SUBTYPE_TYPES.get(str(subtype or ""))
        if subtype_type and subtype_type != document_type:
            conflict_type = subtype_type
            subtype = None
    if kind_type and kind_type != document_type:
        conflict_type = conflict_type or kind_type
        document_kind_label = subtype or document_type
    issues = list(extracted.issues)
    if conflict_type:
        issues.append(
            "document_classification_consistency_repair:"
            f"{document_type}:{conflict_type}"
        )
    normalized = extracted.model_copy(
        update={
            "document_intent": document_type,
            "document_intent_family": document_type,
            "document_kind_label": document_kind_label,
            "document_subtype": subtype,
            "issues": list(dict.fromkeys(issues)),
        }
    )
    return normalized, {
        "document_type_hint_applied": bool(type_hint),
        "document_subtype_hint_applied": bool(subtype_hint),
        "canonical_subtype_type_applied": canonical_type_applied,
        "document_kind_subtype_applied": kind_subtype_applied,
        "structural_type_candidate": structural_type,
        "structural_type_applied": structural_type_applied,
        "model_document_type": extracted.document_intent_family,
        "model_document_kind_label": extracted.document_kind_label,
        "model_classification_changed": (
            document_type != extracted.document_intent_family
            or subtype != extracted.document_subtype
        ),
    }


def _structural_record_document_type(
    extracted: MinerUInstructorResult,
) -> str | None:
    """Resolve only strong schema-level contradictions in model classification."""

    names = {
        fact.name
        for segment in extracted.segments
        for record in segment.records
        for fact in record.fields
    }
    order_signals = names & {
        "package_quantity",
        "piece_count",
        "carton_specification",
        "packaging_requirements",
        "unit_price_tax_included",
        "amount_tax_included",
        "unit_price_tax_excluded",
        "amount_tax_excluded",
    }
    inventory_signals = names & {
        "warehouse",
        "location",
        "available_quantity",
        "reserved_quantity",
        "batch_number",
    }
    if len(order_signals) >= 2 and not inventory_signals:
        return "order"
    if len(inventory_signals) >= 2 and not order_signals:
        return "inventory"
    return None


_GENERIC_TABLE_LABELS = {
    _field_alias_token(value)
    for value in (
        "序号",
        "物料编码",
        "物料名称",
        "规格型号",
        "单位",
        "数量",
        "单价",
        "合计金额",
        "备注",
        "合同条款",
    )
}


def _header_fact_plausible(
    document_subtype: str | None,
    name: str,
    value: str,
) -> bool:
    text = unicodedata.normalize("NFKC", value).strip()
    token = _field_alias_token(text)
    if not text or token in _GENERIC_TABLE_LABELS:
        return False
    if name in {"buyer", "seller", "supplier", "company"}:
        return bool(
            re.search(
                r"公司|集团|厂|研究院|co\.?\s*,?\s*ltd|corporation|company",
                text,
                re.IGNORECASE,
            )
        )
    if name in {"contract_number", "order_number", "source_order_number"}:
        return bool(re.search(r"\d", text)) and len(text) <= 128
    if name in {"order_date", "order_date_raw", "delivery_date", "delivery_date_raw"}:
        if document_subtype == "purchase_contract" and name in {
            "order_date",
            "delivery_date",
        }:
            return _complete_purchase_date_iso(text) is not None
        return bool(
            re.search(
                r"\d{1,4}\s*(?:[/.-]|年|月)\s*\d{1,2}",
                text,
            )
        )
    if name in {"tax_rate", "total_amount"}:
        return bool(re.search(r"\d", text))
    if name == "payment_terms":
        return bool(re.search(r"月结|现金|预付|货到|转账|付款|天", text))
    if name == "summary":
        return not re.match(r"^\s*\d{1,2}\s*[、.．]", text)
    if name == "title" and document_subtype == "purchase_contract":
        return len(text) <= 64 and bool(
            re.fullmatch(
                r"(?:采购|购销|供货|销售|purchase\s*)[^\n]{0,24}(?:合同|订单|函)",
                text,
                re.IGNORECASE,
            )
        )
    if name == "product_name":
        if re.fullmatch(
            r"[A-Za-z\u3400-\u9fff][A-Za-z\u3400-\u9fff\s]{0,31}\s*[/\\:：-]\s*",
            text,
        ):
            return False
        return bool(re.search(r"[A-Za-z\u3400-\u9fff]", text)) and not bool(
            re.fullmatch(r"[A-Za-z]*\d[\w.-]*", text)
        )
    if name in {"material_number", "customer_material_number", "customer_code"}:
        return bool(re.search(r"\d", text)) and len(text) <= 128
    if name == "unit":
        return bool(
            re.fullmatch(
                r"(?i)(?:mm|cm|m|kg|g|pcs?|set|套|个|支|箱|卷)",
                text,
            )
        )
    return True


def _normalized_header_value(name: str, value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).strip()
    if name in {"order_date", "delivery_date"}:
        return _complete_purchase_date_iso(normalized) or normalized
    if name == "total_amount":
        return re.sub(r"^[¥￥$]\s*", "", normalized)
    if name == "tax_rate":
        return re.sub(r"\s*%\s*$", "", normalized)
    return normalized


_PO_OCR_CONFUSABLE = re.compile(
    r"^P(?P<glyph>O|0)(?P<suffix>[-/]\d{6,14}(?:[-/]\d{1,6})*)$",
    re.IGNORECASE,
)


def _po_order_number_parts(value: str) -> tuple[str, str] | None:
    normalized = unicodedata.normalize("NFKC", value).strip().upper()
    match = _PO_OCR_CONFUSABLE.fullmatch(normalized)
    if match is None:
        return None
    return match.group("glyph"), match.group("suffix")


def _po_order_numbers_are_ocr_equivalent(left: str, right: str) -> bool:
    left_parts = _po_order_number_parts(left)
    right_parts = _po_order_number_parts(right)
    if left_parts is None or right_parts is None:
        return False
    return left_parts[1] == right_parts[1] and {left_parts[0], right_parts[0]} == {
        "O",
        "0",
    }


def _source_ref_has_native_provenance(source_ref: Any) -> bool:
    if isinstance(source_ref, dict):
        native_refs = source_ref.get("native_source_refs") or []
        part = source_ref.get("part")
    else:
        extras = getattr(source_ref, "model_extra", None) or {}
        native_refs = extras.get("native_source_refs") or []
        part = getattr(source_ref, "part", None)
    return bool(native_refs) or str(part or "").startswith(
        ("pdf-text/", "spreadsheet/", "docx/")
    )


def _reconcile_labeled_order_number_candidates(
    candidates: list[tuple[str, Any]],
) -> list[tuple[str, Any]]:
    """Collapse P0 into PO only when both labeled evidence forms exist."""

    po_values: dict[str, str] = {}
    for value, source_ref in candidates:
        parts = _po_order_number_parts(value)
        if (
            parts is not None
            and parts[0] == "O"
            and _source_ref_has_native_provenance(source_ref)
        ):
            po_values.setdefault(parts[1], value)
    reconciled: list[tuple[str, Any]] = []
    for value, source_ref in candidates:
        parts = _po_order_number_parts(value)
        if parts is not None and parts[0] == "0" and parts[1] in po_values:
            value = po_values[parts[1]]
        reconciled.append((value, source_ref))
    return reconciled


def _issue_code(issue: str) -> str:
    category = issue.partition(":")[0]
    token = re.sub(r"[^A-Za-z0-9]+", "_", category).strip("_").upper()
    return f"MINERU_INSTRUCTOR_{token or 'ISSUE'}"


def _issue_severity(issue: str) -> str:
    """Keep evidence-accounting diagnostics visible without blocking review."""

    if issue.startswith(
        (
            "unmapped_supported_fact:",
            "ignored_model_fact:invalid_block_semantics_proposal",
            "primary_record_table_fallback:",
            "content_binding_evidence_id_repaired:",
            "document_fact_evidence_repaired:",
            "ignored_content_binding:",
            "explicit_document_intent_override:",
            "document_classification_consistency_repair:",
            "document_classification_trusted_family_reconciled:",
            "long_record_field_mapping_fallback:",
        )
    ) or issue in {
        "document_kind_label_inferred_from_evidence",
        "native_document_classification_applied",
        "native_parallel_record_tables_applied",
        "technical_nonprimary_record_segments_demoted",
    }:
        return "info"
    return "warning"


_LOCAL_REJECTED_CITATION_PREFIXES = (
    "unknown_evidence_id:",
    "out_of_segment_evidence_id:",
    "advisory_evidence_forbidden:",
    "unsupported_evidence_ref:",
)
_LOCAL_REJECTED_FACT_PREFIXES = (
    "unsupported_fact_value:",
    "ignored_model_fact:",
)


def _has_local_rejected_proposal(issues: list[str]) -> bool:
    return any(
        not issue.startswith("ignored_model_fact:invalid_block_semantics_proposal")
        and
        issue.startswith(
            (*_LOCAL_REJECTED_CITATION_PREFIXES, *_LOCAL_REJECTED_FACT_PREFIXES)
        )
        for issue in issues
    )


def _model_diagnostic_payloads(
    extracted: MinerUInstructorResult,
) -> list[dict[str, Any]]:
    """Serialize only the bounded diagnostics emitted by the POC extractor."""

    payloads: list[dict[str, Any]] = []
    for item in list(getattr(extracted, "model_diagnostics", ()) or ())[:8]:
        if isinstance(item, dict):
            payload = copy.deepcopy(item)
        else:
            dump = getattr(item, "model_dump", None)
            if not callable(dump):
                continue
            payload = None
            with suppress(Exception):
                payload = dump(mode="json", exclude_none=True)
            if not isinstance(payload, dict):
                continue
        if isinstance(payload, dict):
            payloads.append(payload)
    return payloads


def _column_number(value: str) -> int:
    result = 0
    for character in value.upper():
        if not "A" <= character <= "Z":
            raise ValueError("invalid spreadsheet column")
        result = result * 26 + ord(character) - ord("A") + 1
    return result


def _spreadsheet_table_ranges(
    evidence: DocumentEvidence,
) -> dict[str, tuple[str, int, int, int, int]]:
    ranges: dict[str, tuple[str, int, int, int, int]] = {}
    for page in evidence.pages:
        if len(page.tables) != 1:
            continue
        sheet: str | None = None
        source_range: tuple[int, int, int, int] | None = None
        for block in page.blocks:
            if match := _SPREADSHEET_SHEET.fullmatch(block.text.strip()):
                sheet = match.group(1).strip()
            if match := _SOURCE_RANGE.fullmatch(block.text.strip()):
                source_range = (
                    _column_number(match.group(1)),
                    int(match.group(2)),
                    _column_number(match.group(3)),
                    int(match.group(4)),
                )
        if sheet and source_range:
            ranges[page.tables[0].table_id] = (sheet, *source_range)
    return ranges


def _spreadsheet_continuation_groups(
    evidence: DocumentEvidence,
    extracted: MinerUInstructorResult,
) -> list[tuple[str, ...]]:
    ranges = _spreadsheet_table_ranges(evidence)
    records_by_table: dict[str, list[ExtractedRecord]] = {}
    for segment in extracted.segments:
        if segment.records:
            records_by_table.setdefault(segment.table_id, []).extend(segment.records)
    buckets: dict[tuple[str, int, int, int], list[tuple[int, int, str]]] = {}
    for table_id, records in records_by_table.items():
        location = ranges.get(table_id)
        if location is None or not records:
            continue
        sheet, column_start, row_start, column_end, row_end = location
        buckets.setdefault(
            (sheet, row_start, row_end, len(records)),
            [],
        ).append((column_start, column_end, table_id))
    groups: list[tuple[str, ...]] = []
    for candidates in buckets.values():
        ordered = sorted(candidates)
        run: list[tuple[int, int, str]] = []
        for candidate in ordered:
            if run and candidate[0] != run[-1][1] + 1:
                if len(run) > 1:
                    groups.append(tuple(item[2] for item in run))
                run = []
            run.append(candidate)
        if len(run) > 1:
            groups.append(tuple(item[2] for item in run))
    return groups


_TABLE_CELL_COORDINATE = re.compile(
    r"^(?:mineru/)?(?P<table>.+?)(?:/|:)r(?P<row>\d+)(?:/|:)c(?P<column>\d+)$"
)


def _evidence_table_coordinate(
    reference: Any,
) -> tuple[str, int, int] | None:
    for locator in (reference.evidence_id, reference.source_ref.part):
        if match := _TABLE_CELL_COORDINATE.fullmatch(str(locator or "")):
            return (
                match.group("table"),
                int(match.group("row")),
                int(match.group("column")),
            )
    return None


def _hidden_table_coordinates(
    evidence: DocumentEvidence,
) -> tuple[dict[str, set[int]], dict[str, set[int]]]:
    hidden_columns: dict[str, set[int]] = {}
    hidden_rows: dict[str, set[int]] = {}
    for page in evidence.pages:
        for table in page.tables:
            for cell in table.cells:
                metadata = cell.model_extra or {}
                if metadata.get("hidden_column"):
                    hidden_columns.setdefault(table.table_id, set()).add(cell.column)
                if metadata.get("hidden_row"):
                    hidden_rows.setdefault(table.table_id, set()).add(cell.row)
    return hidden_columns, hidden_rows


def _record_fact_coordinates(
    extracted: MinerUInstructorResult,
    primary_table_ids: set[str],
    hidden_columns: dict[str, set[int]],
) -> dict[str, dict[int, set[int]]]:
    coordinates: dict[str, dict[int, set[int]]] = {}
    for segment in extracted.segments:
        if segment.table_id not in primary_table_ids:
            continue
        for record in segment.records:
            for fact in record.fields:
                for reference in fact.evidence_refs:
                    coordinate = _evidence_table_coordinate(reference)
                    if coordinate is None:
                        continue
                    table_id, row, column = coordinate
                    if table_id != segment.table_id or column in hidden_columns.get(
                        table_id, set()
                    ):
                        continue
                    coordinates.setdefault(table_id, {}).setdefault(row, set()).add(
                        column
                    )
    return coordinates


def _nearest_authoritative_header_row(
    rows: dict[int, dict[int, str]],
    record_rows: dict[int, set[int]],
) -> int | None:
    if not record_rows:
        return None
    first_data_row = min(record_rows)
    record_columns = set().union(*record_rows.values())
    required_overlap = min(2, len(record_columns))
    if required_overlap == 0:
        return None
    for row in sorted((row for row in rows if row < first_data_row), reverse=True):
        labels = rows[row]
        overlapping_labels = [
            label for column, label in labels.items() if column in record_columns
        ]
        if len(overlapping_labels) < required_overlap:
            continue
        if (
            sum(
                any(character.isalpha() for character in label)
                for label in overlapping_labels
            )
            < required_overlap
        ):
            continue
        return row
    return None


def _schema_line_field_order(
    extracted: MinerUInstructorResult,
    ordered_primary_table_ids: list[str],
    evidence: DocumentEvidence | None = None,
) -> list[str]:
    """Recover declared columns from authoritative numeric table coordinates."""

    table_rank = {
        table_id: index for index, table_id in enumerate(ordered_primary_table_ids)
    }
    hidden_columns: dict[str, set[int]] = {}
    hidden_rows: dict[str, set[int]] = {}
    if evidence is not None:
        hidden_columns, hidden_rows = _hidden_table_coordinates(evidence)
    by_position: dict[tuple[int, int, int], set[str]] = {}
    for reference in extracted.schema_evidence:
        coordinate = _evidence_table_coordinate(reference)
        if coordinate is None:
            continue
        table_id, row, column = coordinate
        if (
            table_id not in table_rank
            or column in hidden_columns.get(table_id, set())
            or row in hidden_rows.get(table_id, set())
        ):
            continue
        label = unicodedata.normalize("NFKC", reference.quote).strip()
        if not label:
            continue
        by_position.setdefault((table_rank[table_id], row, column), set()).add(label)

    if evidence is not None and evidence.backend in {
        "docx-native-ooxml",
        "spreadsheet-envelope",
    }:
        authoritative_rows: dict[str, dict[int, dict[int, str]]] = {}
        for item in evidence_inventory(evidence).values():
            if (
                item.table_id not in table_rank
                or item.row is None
                or item.column is None
                or item.column in hidden_columns.get(item.table_id, set())
                or item.row in hidden_rows.get(item.table_id, set())
            ):
                continue
            label = unicodedata.normalize("NFKC", item.exact_text or item.text).strip()
            if label:
                authoritative_rows.setdefault(item.table_id, {}).setdefault(
                    item.row, {}
                )[item.column] = label

        schema_rows: dict[str, dict[int, int]] = {}
        for _rank, row, _column in by_position:
            table_id = ordered_primary_table_ids[_rank]
            counts = schema_rows.setdefault(table_id, {})
            counts[row] = counts.get(row, 0) + 1
        record_coordinates = _record_fact_coordinates(
            extracted,
            set(table_rank),
            hidden_columns,
        )
        for table_id in ordered_primary_table_ids:
            counts = schema_rows.get(table_id)
            if counts:
                header_row = max(counts, key=lambda row: (counts[row], -row))
            else:
                header_row = _nearest_authoritative_header_row(
                    authoritative_rows.get(table_id, {}),
                    record_coordinates.get(table_id, {}),
                )
            if header_row is None:
                continue
            for column, label in (
                authoritative_rows.get(table_id, {}).get(header_row, {}).items()
            ):
                by_position.setdefault(
                    (table_rank[table_id], header_row, column), set()
                ).add(label)

    result: list[str] = []
    for position in sorted(by_position):
        labels = by_position[position]
        if len(labels) != 1:
            continue
        semantic_name = _canonical_record_field_name(
            extracted.document_subtype,
            next(iter(labels)),
        )
        if semantic_name not in result:
            result.append(semantic_name)
    return result


_PURCHASE_AUTHORITATIVE_HEADER_NAMES = {
    "contract_number",
    "order_number",
    "order_date",
    "order_date_raw",
    "delivery_date",
    "delivery_date_raw",
    "buyer",
    "seller",
    "supplier",
    "payment_terms",
    "delivery_address",
    "currency",
    "tax_rate",
    "total_amount",
}


def _fact_uses_record_or_schema_evidence(
    fact: ExtractedFact,
    excluded_evidence_ids: set[str],
) -> bool:
    return any(
        reference.evidence_id in excluded_evidence_ids
        for reference in fact.evidence_refs
    )


def _purchase_authoritative_header_conflicts(
    extracted: MinerUInstructorResult,
    evidence: DocumentEvidence,
    excluded_evidence_ids: set[str],
) -> set[str]:
    aliases = {
        "order_date_raw": "order_date",
        "delivery_date_raw": "delivery_date",
    }
    candidates: dict[str, set[str]] = {}

    def append(name: str, value: str) -> None:
        canonical_name = aliases.get(name, name)
        if canonical_name in {"order_date", "delivery_date"} and (
            _complete_purchase_date_iso(value) is None
        ):
            return
        normalized = _normalized_header_value(canonical_name, value)
        marker = re.sub(r"\s+", "", normalized).casefold()
        if marker:
            candidates.setdefault(canonical_name, set()).add(marker)

    facts = [
        *extracted.document_facts,
        *(fact for segment in extracted.segments for fact in segment.facts),
    ]
    for fact in facts:
        if fact.name not in _PURCHASE_AUTHORITATIVE_HEADER_NAMES:
            continue
        if _fact_uses_record_or_schema_evidence(fact, excluded_evidence_ids):
            continue
        if not _purchase_fact_has_labeled_evidence(fact):
            continue
        if not _header_fact_plausible(
            extracted.document_subtype,
            fact.name,
            fact.value,
        ):
            continue
        append(fact.name, fact.value)

    sources = _layout_split_text_sources(_extracted_text_sources(extracted, evidence))
    for name, pattern in _PURCHASE_HEADER_PATTERNS.items():
        for text, source_ref in sources:
            if name == "total_amount" and (
                source_ref.cell is not None or "/r" in str(source_ref.part or "")
            ):
                continue
            for match in pattern.finditer(text):
                if match.group("value").strip():
                    append(name, match.group("value"))
    for name, values in _grid_purchase_header_candidates(evidence).items():
        for value, _source_ref in values:
            append(name, value)
    for value, _source_ref in _purchase_table_total_candidates(
        evidence,
        set(extracted.primary_record_table_ids),
    ):
        append("total_amount", value)

    order_number_values = candidates.get("order_number")
    if order_number_values:
        reconciled_values = _reconcile_labeled_order_number_candidates(
            [(value, None) for value in order_number_values]
        )
        candidates["order_number"] = {value for value, _ref in reconciled_values}

    conflicting_canonical_names = {
        name
        for name, values in candidates.items()
        if len(values) > 1
        and not (
            name in {"buyer", "seller", "supplier"}
            and _party_values_equivalent(values)
        )
    }
    return {
        name
        for name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
        if aliases.get(name, name) in conflicting_canonical_names
    }


def _benchmark_projection(
    *,
    source_sha256: str,
    original_filename: str,
    parsed: MinerUParseResult,
    extracted: MinerUInstructorResult,
) -> tuple[dict[str, Any], dict[str, str]]:
    """Project generic typed facts into the benchmark's record-shaped adapter."""

    header: dict[str, Any] = {}
    lines: list[dict[str, Any]] = []
    totals: dict[str, Any] = {}
    field_meta: dict[str, Any] = {}
    field_names: dict[str, str] = {}
    model_diagnostic_payloads = _model_diagnostic_payloads(extracted)
    record_kind_counts = {
        kind: 0 for kind in ("product", "narrative", "total", "metadata", "unknown")
    }
    isolated_record_count = 0
    unknown_record_locations: list[str] = []

    ordered_primary_table_ids = list(
        dict.fromkeys(extracted.primary_record_table_ids)
    ) or list(
        dict.fromkeys(
            segment.table_id for segment in extracted.segments if segment.records
        )
    )
    primary_record_table_ids = set(ordered_primary_table_ids)
    price_tax_mode = _evidence_price_tax_mode(parsed.evidence)
    line_field_order = [
        _apply_evidence_price_tax_mode(name, price_tax_mode)
        for name in _schema_line_field_order(
        extracted,
        ordered_primary_table_ids,
        parsed.evidence,
        )
    ]
    record_or_schema_evidence_ids = {
        reference.evidence_id for reference in extracted.schema_evidence
    } | {
        reference.evidence_id
        for segment in extracted.segments
        for record in segment.records
        for fact in record.fields
        for reference in fact.evidence_refs
    }
    purchase_header_conflicts = (
        _purchase_authoritative_header_conflicts(
            extracted,
            parsed.evidence,
            record_or_schema_evidence_ids,
        )
        if extracted.document_subtype == "purchase_contract"
        else set()
    )
    projection_issues = [
        f"PURCHASE_AUTHORITATIVE_HEADER_CONFLICT:{name}"
        for name in sorted(purchase_header_conflicts)
        if not name.endswith("_raw")
    ]
    if price_tax_mode is None and _has_ambiguous_record_price_labels(extracted):
        projection_issues.append("AMBIGUOUS_PRICE_TAX_SEMANTICS")
    generic_facts: list[dict[str, Any]] = []
    generic_markers: set[str] = set()

    def append_generic_fact(payload: dict[str, Any]) -> None:
        source_refs = list(payload.get("source_refs") or [])
        marker = json.dumps(
            {
                "name": payload.get("name"),
                "value": payload.get("value"),
                "source_refs": source_refs,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        if marker in generic_markers:
            return
        generic_markers.add(marker)
        index = len(generic_facts)
        generic_facts.append(copy.deepcopy(payload))
        field_meta[f"$.generic_facts[{index}].value"] = {
            "source_refs": copy.deepcopy(source_refs),
            "inferred": bool(payload.get("inferred")),
            "inherited_from_merge": _source_refs_inherit_merge(source_refs),
            "confidence": 0.65 if payload.get("authority") == "advisory" else 1.0,
            "sensitive": bool(payload.get("sensitive")),
            "source_label": str(payload.get("name") or "generic_fact"),
            **(
                {"authority": payload["authority"]}
                if payload.get("authority")
                else {}
            ),
            **(
                {
                    "record_kind": payload["record_kind"],
                    "record_kind_source_refs": copy.deepcopy(
                        payload.get("record_kind_source_refs") or []
                    ),
                    "model_mapped": True,
                }
                if payload.get("record_kind")
                else {}
            ),
        }

    for fact in extracted.generic_facts:
        append_generic_fact(
            {
                "name": fact.name,
                "value": fact.value,
                "source_refs": _source_refs(fact),
                "sensitive": fact.sensitive,
            }
        )
    for payload in table_fact_payloads(
        parsed.evidence,
        document_type=extracted.document_intent_family,
        document_subtype=extracted.document_subtype,
        primary_table_ids=ordered_primary_table_ids,
    ):
        append_generic_fact(payload)

    def header_has_name(name: str) -> bool:
        return any(
            path.startswith("$.header.") and semantic_name == name
            for path, semantic_name in field_names.items()
        )

    for fact in extracted.document_facts:
        if fact.name in purchase_header_conflicts:
            continue
        if (
            extracted.document_subtype == "purchase_contract"
            and _fact_uses_record_or_schema_evidence(
                fact,
                record_or_schema_evidence_ids,
            )
        ):
            continue
        if (
            extracted.document_subtype == "purchase_contract"
            and fact.name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
            and not _purchase_fact_has_labeled_evidence(fact)
        ):
            continue
        if not _header_fact_plausible(
            extracted.document_subtype,
            fact.name,
            fact.value,
        ):
            continue
        if (
            extracted.document_subtype == "purchase_contract"
            and fact.name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
            and header_has_name(fact.name)
        ):
            continue
        normalized_value = _normalized_header_value(fact.name, fact.value)
        _place_fact(
            fact,
            target=header,
            path_prefix="$.header",
            field_meta=field_meta,
            field_names=field_names,
            projected_value=normalized_value,
            inferred=normalized_value != fact.value,
        )
    records_by_table: dict[str, list[ExtractedRecord]] = {}
    for segment in extracted.segments:
        if segment.records:
            records_by_table.setdefault(segment.table_id, []).extend(segment.records)
    continuation_groups: list[tuple[str, ...]] = []
    for group in _spreadsheet_continuation_groups(parsed.evidence, extracted):
        conflicting_indexes: list[int] = []
        for index in range(len(records_by_table[group[0]])):
            physical_rows = [
                {
                    int(source_row)
                    for fact in records_by_table[table_id][index].fields
                    for reference in fact.evidence_refs
                    if (
                        source_row := (reference.source_ref.model_extra or {}).get(
                            "source_row"
                        )
                    )
                    is not None
                }
                for table_id in group
            ]
            if any(len(rows) != 1 for rows in physical_rows) or len(
                set().union(*physical_rows)
            ) != 1:
                conflicting_indexes.append(index)
        if conflicting_indexes:
            projection_issues.append(
                "CONTINUATION_RECORD_AXIS_CONFLICT:"
                f"{','.join(group)}:count={len(conflicting_indexes)}:"
                f"sample={','.join(str(index) for index in conflicting_indexes[:8])}"
            )
            continue
        continuation_groups.append(group)
    group_by_table = {
        table_id: group for group in continuation_groups for table_id in group
    }
    emitted_groups: set[tuple[str, ...]] = set()
    for segment in extracted.segments:
        if segment.table_id in primary_record_table_ids:
            for fact in segment.facts:
                if fact.name in purchase_header_conflicts:
                    continue
                if (
                    extracted.document_subtype == "purchase_contract"
                    and _fact_uses_record_or_schema_evidence(
                        fact,
                        record_or_schema_evidence_ids,
                    )
                ):
                    continue
                if (
                    extracted.document_subtype == "purchase_contract"
                    and fact.name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
                    and not _purchase_fact_has_labeled_evidence(fact)
                ):
                    continue
                if not _header_fact_plausible(
                    extracted.document_subtype,
                    fact.name,
                    fact.value,
                ):
                    continue
                if (
                    extracted.document_subtype == "purchase_contract"
                    and fact.name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
                    and header_has_name(fact.name)
                ):
                    continue
                normalized_value = _normalized_header_value(
                    fact.name,
                    fact.value,
                )
                _place_fact(
                    fact,
                    target=header,
                    path_prefix="$.header",
                    field_meta=field_meta,
                    field_names=field_names,
                    projected_value=normalized_value,
                    inferred=normalized_value != fact.value,
                )
        records: list[ExtractedRecord] = (
            list(segment.records)
            if segment.table_id in primary_record_table_ids
            and extracted.document_subtype not in OPEN_DOMAIN_DOCUMENT_SUBTYPES
            else []
        )
        group = group_by_table.get(segment.table_id)
        if group is not None:
            if (
                not all(table_id in primary_record_table_ids for table_id in group)
                or group in emitted_groups
                or segment.table_id != group[0]
            ):
                records = []
            else:
                emitted_groups.add(group)

                def merged_group_record(
                    index: int,
                    group_ids: tuple[str, ...] = group,
                ) -> ExtractedRecord:
                    parts = [
                        records_by_table[table_id][index] for table_id in group_ids
                    ]
                    kinds = {part.record_kind for part in parts}
                    record_kind = next(iter(kinds)) if len(kinds) == 1 else "unknown"
                    physical_rows = [
                        {
                            int(source_row)
                            for fact in part.fields
                            for reference in fact.evidence_refs
                            if (
                                source_row := (reference.source_ref.model_extra or {}).get(
                                    "source_row"
                                )
                            )
                            is not None
                        }
                        for part in parts
                    ]
                    comparable_rows = [rows for rows in physical_rows if rows]
                    rows_aligned = (
                        not comparable_rows
                        or len(set().union(*comparable_rows)) == 1
                    )
                    if not rows_aligned:
                        record_kind = "unknown"
                        projection_issues.append(
                            "CONTINUATION_RECORD_AXIS_CONFLICT:"
                            f"{','.join(group_ids)}:{index}"
                        )
                    refs_by_id = {
                        reference.evidence_id: reference
                        for part in parts
                        for reference in part.record_kind_evidence_refs
                    }
                    return ExtractedRecord(
                        fields=[fact for part in parts for fact in part.fields],
                        record_kind=record_kind,
                        record_kind_evidence_refs=list(refs_by_id.values())[:12],
                        record_kind_source=(
                            "model"
                            if record_kind != "unknown"
                            and all(part.record_kind_source == "model" for part in parts)
                            else "local_fallback"
                        ),
                        record_axis=(
                            next(iter(set().union(*comparable_rows)))
                            if comparable_rows and rows_aligned
                            else parts[0].record_axis
                            if rows_aligned
                            else None
                        ),
                    )

                records = [
                    merged_group_record(index)
                    for index in range(len(records_by_table[group[0]]))
                ]
        for segment_record_index, record in enumerate(records):
            line: dict[str, Any] = {}
            candidate_meta: dict[str, Any] = {}
            candidate_names: dict[str, str] = {}
            candidate_semantic_names: list[str] = []
            candidate_prefix = "$.__candidate_line"
            line_number = next(
                (
                    fact.value.strip()
                    for fact in record.fields
                    if _field_alias_token(fact.name) in _LINE_NUMBER_TOKENS
                    and fact.value.strip()
                ),
                None,
            )
            for fact in record.fields:
                semantic_name = _canonical_record_field_name(
                    extracted.document_subtype,
                    fact.name,
                )
                semantic_name = _apply_evidence_price_tax_mode(
                    semantic_name,
                    price_tax_mode,
                )
                projected_value = fact.value
                inferred = False
                if semantic_name in {"material_code", "product_code"} and line_number:
                    match = re.fullmatch(
                        rf"\s*{re.escape(line_number)}\s+(.+?)\s*",
                        fact.value,
                    )
                    if match and re.search(r"\d", match.group(1)):
                        projected_value = match.group(1)
                        inferred = True
                _place_fact(
                    fact,
                    target=line,
                    path_prefix=candidate_prefix,
                    field_meta=candidate_meta,
                    field_names=candidate_names,
                    semantic_name=semantic_name,
                    projected_value=projected_value,
                    inferred=inferred,
                )
                if fact.inference_source:
                    projection_issues.append(
                        "CONTEXT_INHERITANCE_REVIEW_REQUIRED:"
                        f"{segment.table_id}:{record.record_axis}:{semantic_name}"
                    )
                if semantic_name not in candidate_semantic_names:
                    candidate_semantic_names.append(semantic_name)
            if not line:
                continue

            assessment = classify_line_business_payload(
                line,
                document_type=extracted.document_intent_family,
            )
            effective_kind = record.record_kind
            if (
                effective_kind in {"narrative", "metadata", "total"}
                and record.record_kind_source != "model"
            ):
                projection_issues.append(
                    "RECORD_KIND_UNVERIFIED_RETAINED:"
                    f"{segment.table_id}:{record.record_axis}:{effective_kind}"
                )
                effective_kind = "unknown"
            if (
                effective_kind in {"narrative", "metadata", "total"}
                and assessment.strong_business_payload
            ):
                projection_issues.append(
                    "RECORD_KIND_CONFLICT_RETAINED:"
                    f"{segment.table_id}:{record.record_axis}:{effective_kind}"
                )
                effective_kind = "product"
            if effective_kind == "product" and assessment.provably_structural:
                effective_kind = (
                    "total"
                    if assessment.structural_kind == "total"
                    else "narrative"
                    if assessment.structural_kind == "note"
                    else "metadata"
                )
                projection_issues.append(
                    "RECORD_KIND_PRODUCT_REJECTED:"
                    f"{segment.table_id}:{record.record_axis}:"
                    f"{assessment.structural_kind or 'structural'}"
                )
            elif effective_kind == "unknown" and assessment.provably_structural:
                effective_kind = (
                    "total"
                    if assessment.structural_kind == "total"
                    else "narrative"
                    if assessment.structural_kind == "note"
                    else "metadata"
                )

            record_kind_counts[record.record_kind] += 1
            if effective_kind in {"narrative", "metadata", "total"}:
                isolated_record_count += 1
                if effective_kind == "total":
                    source_declared = totals.setdefault("source_declared", {})
                    total_values: dict[str, Any] = {}
                    total_source_refs: list[dict[str, Any]] = []
                    for fact in record.fields:
                        key = _unique_key(source_declared, fact.name)
                        source_declared[key] = fact.value
                        total_values[key] = fact.value
                        path = _mapping_field_path(
                            "$.totals",
                            "source_declared",
                            key,
                        )
                        source_refs = _source_refs(fact)
                        field_meta[path] = {
                            "source_refs": source_refs,
                            "inferred": fact.inferred,
                            "inherited_from_merge": _source_refs_inherit_merge(
                                source_refs
                            ),
                            "source_label": fact.name,
                            "record_kind": "total",
                            "record_kind_source_refs": [
                                reference.model_dump(mode="json")
                                for reference in record.record_kind_evidence_refs
                            ],
                            "model_mapped": record.record_kind_source == "model",
                        }
                        field_names[path] = fact.name
                        for source_ref in source_refs:
                            if source_ref not in total_source_refs:
                                total_source_refs.append(copy.deepcopy(source_ref))
                    append_generic_fact(
                        {
                            "name": "total_record",
                            "value": total_values,
                            "source_refs": total_source_refs,
                            "sensitive": False,
                            "record_kind": "total",
                            "record_axis": record.record_axis,
                            "table_id": segment.table_id,
                            "record_kind_source_refs": [
                                reference.model_dump(mode="json")
                                for reference in record.record_kind_evidence_refs
                            ],
                        }
                    )
                else:
                    for fact in record.fields:
                        append_generic_fact(
                            {
                                "name": f"{effective_kind}.{fact.name}",
                                "value": fact.value,
                                "source_refs": _source_refs(fact),
                                "sensitive": fact.sensitive,
                                "record_kind": effective_kind,
                                "record_axis": record.record_axis,
                                "table_id": segment.table_id,
                                "record_kind_source_refs": [
                                    reference.model_dump(mode="json")
                                    for reference in record.record_kind_evidence_refs
                                ],
                            }
                        )
                continue

            if effective_kind == "unknown" and (
                record.record_axis is not None or record.record_kind_evidence_refs
            ):
                record_locator = (
                    str(record.record_axis)
                    if record.record_axis is not None
                    else f"segment-record-{segment_record_index}"
                )
                unknown_record_locations.append(
                    f"{segment.table_id}:{record_locator}"
                )
            line_index = len(lines)
            line_prefix = f"$.lines[{line_index}]"
            for path, metadata in candidate_meta.items():
                target_path = line_prefix + path.removeprefix(candidate_prefix)
                enriched_metadata = copy.deepcopy(metadata)
                if (
                    record.record_kind_source == "model"
                    or record.record_axis is not None
                    or record.record_kind_evidence_refs
                ):
                    enriched_metadata.update(
                        {
                            "record_kind": record.record_kind,
                            "record_kind_effective": effective_kind,
                            "record_kind_source": record.record_kind_source,
                            "record_kind_source_refs": [
                                reference.model_dump(mode="json")
                                for reference in record.record_kind_evidence_refs
                            ],
                            "record_kind_model_mapped": (
                                record.record_kind_source == "model"
                            ),
                        }
                    )
                field_meta[target_path] = enriched_metadata
            for path, semantic_name in candidate_names.items():
                target_path = line_prefix + path.removeprefix(candidate_prefix)
                field_names[target_path] = semantic_name
            for semantic_name in candidate_semantic_names:
                if semantic_name not in line_field_order:
                    line_field_order.append(semantic_name)
            lines.append(line)

    if unknown_record_locations:
        projection_issues.append(
            "RECORD_KIND_UNKNOWN_RETAINED:"
            f"count={len(unknown_record_locations)}:sample="
            + ",".join(unknown_record_locations[:12])
        )

    allowed_content_facts = set(
        _fact_target_context(
            extracted.document_intent,
            extracted.document_subtype,
        )["allowed_fact_names"]
    )
    dedicated_content_evidence_ids: set[str] = set()
    for unit in extracted.content_units:
        if unit.binding_source != "model":
            continue
        if unit.content_kind not in {
            "metadata",
            "header_field",
            "title",
            "company",
            "party",
        }:
            continue
        provenance = unit.source_ref.model_extra or {}
        if provenance.get("authority") == "advisory" or provenance.get("asset_sha256"):
            continue
        canonical_name = _canonical_fact_name(unit.label, allowed_content_facts)
        if canonical_name is None:
            canonical_name = _canonical_fact_name(
                unit.content_kind,
                allowed_content_facts,
            )
        if canonical_name is None:
            continue
        if (
            extracted.document_subtype == "purchase_contract"
            and canonical_name in _PURCHASE_AUTHORITATIVE_HEADER_NAMES
        ):
            continue
        if not _header_fact_plausible(
            extracted.document_subtype,
            canonical_name,
            unit.exact_text,
        ):
            continue
        key = _unique_key(header, canonical_name)
        header[key] = unit.exact_text
        path = f"$.header.{key}"
        field_names[path] = canonical_name
        field_meta[path] = {
            "source_refs": [unit.source_ref.model_dump(mode="json", exclude_none=True)],
            "inferred": True,
        }
        dedicated_content_evidence_ids.add(unit.evidence_id)

    for payload in content_fact_payloads(
        extracted,
        evidence=parsed.evidence,
        excluded_evidence_ids=dedicated_content_evidence_ids,
    ):
        append_generic_fact(payload)

    def remove_header_name(name: str) -> None:
        existing_paths = [
            path
            for path, existing_name in field_names.items()
            if path.startswith("$.header.") and existing_name == name
        ]
        for path in existing_paths:
            key = path.removeprefix("$.header.")
            header.pop(key, None)
            field_meta.pop(path, None)
            field_names.pop(path, None)

    def place_derived_header(
        name: str,
        value: Any,
        source_refs: list[dict[str, Any]],
        *,
        replace: bool = False,
    ) -> None:
        has_existing = any(
            path.startswith("$.header.") and existing_name == name
            for path, existing_name in field_names.items()
        )
        if has_existing and not replace:
            return
        if replace:
            remove_header_name(name)
        key = _unique_key(header, name)
        header[key] = value
        path = f"$.header.{key}"
        field_names[path] = name
        metadata = {
            "source_refs": source_refs,
            "inferred": True,
            "mapping_source": "deterministic_header_projection",
        }
        if _projection_source_refs_are_locatable(source_refs):
            metadata["review_required"] = False
        field_meta[path] = metadata

    def promote_unique_line_value(
        header_name: str,
        aliases: set[str],
    ) -> None:
        candidates: dict[str, tuple[Any, list[dict[str, Any]]]] = {}
        for index, line in enumerate(lines):
            containers = [
                (None, line),
                ("custom_fields", line.get("custom_fields") or {}),
                ("raw_columns", line.get("raw_columns") or {}),
            ]
            for container, values in containers:
                if not isinstance(values, dict):
                    continue
                for key, value in values.items():
                    if value in (None, ""):
                        continue
                    path = (
                        f"$.lines[{index}].{key}"
                        if container is None
                        else _mapping_field_path(
                            f"$.lines[{index}]",
                            container,
                            str(key),
                        )
                    )
                    metadata = field_meta.get(path)
                    if not isinstance(metadata, dict) or not metadata.get("source_refs"):
                        continue
                    source_label = str(metadata.get("source_label") or key)
                    if (
                        _field_alias_token(str(key)) not in aliases
                        and _field_alias_token(source_label) not in aliases
                    ):
                        continue
                    marker = unicodedata.normalize("NFKC", str(value)).casefold()
                    current = candidates.setdefault(marker, (value, []))
                    for reference in metadata.get("source_refs") or []:
                        if reference not in current[1]:
                            current[1].append(copy.deepcopy(reference))
        if len(candidates) == 1:
            value, refs = next(iter(candidates.values()))
            place_derived_header(header_name, value, refs)

    if extracted.document_intent_family == "order":
        for name, (value, source_refs) in _derived_generic_order_headers(
            extracted,
            parsed.evidence,
        ).items():
            place_derived_header(name, value, source_refs)
        promote_unique_line_value(
            "order_number",
            {
                "customerordernumber",
                "customerorderno",
                "客户订单号",
                "订单号",
                "订单编号",
            },
        )
        promote_unique_line_value(
            "project_number",
            {
                "projectnumber",
                "projectno",
                "projectid",
                "项目号",
                "项目编号",
                "项目代码",
            },
        )

    if extracted.document_subtype == "engineering_drawing":
        product_name, has_primary_product_name = (
            _primary_engineering_product_name_selection(extracted)
        )
        if has_primary_product_name and product_name is None:
            remove_header_name("product_name")
            projection_issues.append("engineering_product_name_conflict")
        test_condition_count = _numbered_test_condition_count(extracted)
        if test_condition_count is not None and test_condition_count[0] == 0:
            projection_issues.append("engineering_test_condition_sequence_conflict")
        for name, (value, source_refs) in _derived_engineering_headers(
            extracted,
            parsed.evidence,
        ).items():
            place_derived_header(
                name,
                value,
                source_refs,
                replace=True,
            )
    if extracted.document_subtype == "purchase_contract":
        for name, (value, source_refs) in _derived_purchase_headers(
            extracted,
            parsed.evidence,
        ).items():
            if name in purchase_header_conflicts:
                continue
            place_derived_header(
                name,
                value,
                source_refs,
                replace=True,
            )
    if extracted.document_subtype == "stocking_order":
        for name, (value, source_refs) in _derived_stocking_headers(
            extracted,
            parsed.evidence,
        ).items():
            place_derived_header(
                name,
                value,
                source_refs,
                replace=True,
            )

    if extracted.document_intent_family == "order":
        for name, (value, source_refs) in _derived_declared_order_totals(
            lines,
            parsed.evidence,
        ).items():
            totals[name] = value
            field_meta[f"$.totals.{name}"] = {
                "source_refs": source_refs,
                "inferred": False,
            }

    if extracted.document_subtype == "engineering_drawing" and lines:
        boundary_refs: list[dict[str, Any]] = []
        for index in {0, len(lines) - 1}:
            prefix = f"$.lines[{index}]."
            for path, metadata in field_meta.items():
                if path.startswith(prefix) and isinstance(metadata, dict):
                    boundary_refs.extend(metadata.get("source_refs") or [])
        place_derived_header("bom_line_count", len(lines), boundary_refs)

    pages = []
    for page in parsed.evidence.pages:
        page_payload = page.model_dump(mode="json")
        page_payload["tables"] = []
        for table in page.tables:
            table_payload = table.model_dump(mode="json")
            table_payload["row_count"] = len(table.rows)
            table_payload["column_count"] = max(
                (len(row) for row in table.rows),
                default=0,
            )
            page_payload["tables"].append(table_payload)
        pages.append(page_payload)
    asset_inventory = parsed.evidence.raw.get("source_asset_inventory")
    if not isinstance(asset_inventory, dict):
        asset_inventory = {}
    asset_count = int(asset_inventory.get("asset_count") or 0)
    requirement_count = int(asset_inventory.get("requirement_count") or 0)
    analysis_unit_count = asset_count + requirement_count
    analyzed_count = int(asset_inventory.get("analyzed_count") or 0)
    records_by_semantic_table: dict[str, list[ExtractedRecord]] = {}
    for segment in extracted.segments:
        if segment.records:
            records_by_semantic_table.setdefault(segment.table_id, []).extend(
                segment.records
            )
    encountered_semantic_table_ids = list(
        dict.fromkeys(
            segment.table_id
            for segment in extracted.segments
            if segment.records or segment.facts
        )
    )
    semantic_table_ids = [
        table_id
        for table_id in ordered_primary_table_ids
        if table_id in encountered_semantic_table_ids
    ] + [
        table_id
        for table_id in encountered_semantic_table_ids
        if table_id not in primary_record_table_ids
    ]
    record_sets = [
        {
            "table_id": table_id,
            "role": (
                "primary_business_records"
                if table_id in primary_record_table_ids
                else "auxiliary_records"
            ),
            "records": [
                {
                    "record_kind": semantic_record.record_kind,
                    "record_kind_source": semantic_record.record_kind_source,
                    "record_axis": semantic_record.record_axis,
                    "record_kind_evidence_refs": [
                        reference.model_dump(mode="json")
                        for reference in semantic_record.record_kind_evidence_refs
                    ],
                    "fields": [
                        {
                            "name": fact.name,
                            "canonical_name": _canonical_record_field_name(
                                extracted.document_subtype,
                                fact.name,
                            ),
                            "value": fact.value,
                            "source_refs": _source_refs(fact),
                            "inferred": fact.inferred,
                            "inference_source": fact.inference_source,
                            "mapping_source": fact.mapping_source,
                            "original_name": fact.original_name,
                        }
                        for fact in semantic_record.fields
                    ]
                }
                for semantic_record in semantic_records
            ],
            "facts": [
                {
                    "name": fact.name,
                    "value": fact.value,
                    "source_refs": _source_refs(fact),
                }
                for segment in extracted.segments
                if segment.table_id == table_id
                for fact in segment.facts
            ],
        }
        for table_id in semantic_table_ids
        for semantic_records in [records_by_semantic_table.get(table_id, [])]
    ]
    product_photo_refs = [
        copy.deepcopy(reference)
        for fact in generic_facts
        if fact.get("name") == "visual_description"
        for reference in fact.get("source_refs") or []
    ]
    product_photo_issues = (
        [
            {
                "code": "MINERU_PRODUCT_PHOTO_DESCRIPTION_ADVISORY",
                "severity": "warning",
                "message": (
                    "product photo descriptions are model-derived advisory evidence "
                    "and require human review"
                ),
                "paths": ["$.generic_facts"],
                "source_refs": product_photo_refs[:12],
            }
        ]
        if extracted.document_subtype == "product_photo"
        else []
    )
    record = {
        "schema_version": "m1.mineru-instructor-benchmark-record.v1",
        "document_type": extracted.document_intent_family,
        "document_subtype": extracted.document_subtype,
        "document_kind_label": (
            extracted.document_kind_label or extracted.document_intent
        ),
        "generic_facts": generic_facts,
        "source": {
            "original_filename": original_filename,
            "sha256": source_sha256,
        },
        "header": header,
        "lines": lines,
        "totals": totals,
        "field_meta": field_meta,
        "validation_issues": [
            {
                "code": _issue_code(issue),
                "severity": _issue_severity(issue),
                "message": issue,
            }
            for issue in [*extracted.issues, *projection_issues]
        ]
        + [
            {
                "code": "MINERU_INSTRUCTOR_MODEL_DIAGNOSTIC",
                "severity": "warning",
                "message": (
                    "structured model call failed at "
                    f"{item.get('stage') or 'unknown_stage'}: "
                    f"{item.get('error_type') or 'UnknownError'} "
                    f"({item.get('reason') or 'unknown'})"
                ),
                "details": copy.deepcopy(item),
            }
            for item in model_diagnostic_payloads
        ]
        + product_photo_issues,
        "needs_review": (
            not extracted.complete
            or bool(projection_issues)
            or bool(model_diagnostic_payloads)
            or _has_local_rejected_proposal(extracted.issues)
            or extracted.document_subtype == "product_photo"
        ),
        "extraction": {
            "metadata": {
                "adapter": "mineru_instructor_poc",
                "mineru_task_id": parsed.task_id,
                "mineru_member_name": parsed.member_name,
                "document_intent": extracted.document_intent,
                "document_intent_family": extracted.document_intent_family,
                "document_subtype": extracted.document_subtype,
                "primary_record_table_ids": list(ordered_primary_table_ids),
                "auxiliary_record_table_ids": sorted(
                    {
                        segment.table_id
                        for segment in extracted.segments
                        if segment.records
                        and segment.table_id not in primary_record_table_ids
                    }
                ),
                "evidence_complete": extracted.complete,
                "semantic_complete": extracted.semantic_complete,
                "accounted_complete": extracted.accounted_complete,
                "retained_complete": extracted.retained_complete,
                "evidence_coverage_ratio": extracted.evidence_coverage_ratio,
                "semantic_accounting_ratio": (extracted.semantic_accounting_ratio),
                "evidence_accounting_ratio": (extracted.evidence_accounting_ratio),
                "retained_evidence_ratio": extracted.retained_evidence_ratio,
                "evidence_total_count": extracted.total_evidence_count,
                "evidence_mapped_count": extracted.mapped_evidence_count,
                "evidence_schema_count": extracted.schema_evidence_count,
                "evidence_redundant_count": (extracted.redundant_evidence_count),
                "evidence_raw_content_count": (extracted.raw_content_evidence_count),
                "evidence_unresolved_count": (extracted.unresolved_evidence_count),
                "evidence_retained_count": extracted.retained_evidence_count,
                "evidence_unmapped_count": extracted.unmapped_evidence_count,
                "content_evidence_count": extracted.content_evidence_count,
                "content_unit_count": extracted.content_unit_count,
                "content_model_bound_count": (extracted.content_model_bound_count),
                "content_local_fallback_count": (
                    extracted.content_local_fallback_count
                ),
                "content_accounted_complete": (extracted.content_accounted_complete),
                "content_semantic_coverage_ratio": (
                    extracted.content_semantic_coverage_ratio
                ),
                "content_accounting_ratio": extracted.content_accounting_ratio,
                "instructor_model_diagnostics": copy.deepcopy(
                    model_diagnostic_payloads
                ),
                "spreadsheet_continuation_groups": [
                    list(group) for group in continuation_groups
                ],
                "record_kind_counts": copy.deepcopy(record_kind_counts),
                "isolated_non_product_record_count": isolated_record_count,
                "source_asset_inventory_status": asset_inventory.get("coverage_status"),
                "source_asset_count": asset_count,
                "source_asset_media_part_count": int(
                    asset_inventory.get("media_part_count") or 0
                ),
                "source_asset_occurrence_count": int(
                    asset_inventory.get("occurrence_count") or 0
                ),
                "source_asset_requirement_count": requirement_count,
                "source_asset_analyzed_asset_count": int(
                    asset_inventory.get("analyzed_asset_count") or 0
                ),
                "source_asset_fulfilled_requirement_count": int(
                    asset_inventory.get("fulfilled_requirement_count") or 0
                ),
                "source_asset_analyzed_count": analyzed_count,
                "source_asset_inventory_ratio": (
                    1.0 if asset_inventory.get("coverage_status") == "complete" else 0.0
                ),
                "source_asset_analysis_ratio": (
                    analyzed_count / analysis_unit_count if analysis_unit_count else 1.0
                ),
            },
            "raw_content": {
                "text_original": parsed.evidence.text,
                "text_normalized": unicodedata.normalize("NFKC", parsed.evidence.text),
                "pages": pages,
                **(
                    {
                        "native_classification": copy.deepcopy(
                            parsed.evidence.raw["native_classification"]
                        )
                    }
                    if isinstance(
                        parsed.evidence.raw.get("native_classification"), dict
                    )
                    else {}
                ),
                "source_asset_inventory": asset_inventory,
                "evidence_dispositions": {
                    "schema_label": [
                        item.model_dump(mode="json")
                        for item in extracted.schema_evidence
                    ],
                    "redundant_alias": [
                        item.model_dump(mode="json")
                        for item in extracted.redundant_evidence
                    ],
                    "raw_content": [
                        item.model_dump(mode="json")
                        for item in extracted.raw_content_evidence
                    ],
                    "content_model_bound": [
                        item.model_dump(mode="json")
                        for item in extracted.content_units
                        if item.binding_source == "model"
                    ],
                    "content_local_fallback": [
                        item.model_dump(mode="json")
                        for item in extracted.content_units
                        if item.binding_source == "local_fallback"
                    ],
                },
            },
            "record_sets": record_sets,
            "line_field_order": line_field_order,
        },
    }
    return record, field_names


_DRAWING_REGION_VLM_SCHEMA_VERSION = "m1.drawing-region-vlm-sidecar.v1"
_DRAWING_REGION_VLM_MAX_ASSETS = 8
_DRAWING_REGION_VLM_MAX_REGIONS = 16
_DRAWING_REGION_VLM_MAX_TIMEOUT_SECONDS = 180.0
_DRAWING_REGION_VLM_CONSUMED_DISPOSITIONS = {
    "fact",
    "not_a_callout",
    "screened",
    "ambiguous",
    "invalid",
    "failed",
    "truncated",
    "conflict",
}


def _sidecar_issue(code: str, message: str) -> dict[str, str]:
    return {"code": code, "message": message}


def _model_payload(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return copy.deepcopy(value)
    dump = getattr(value, "model_dump", None)
    if not callable(dump):
        raise TypeError("drawing region audit values must be Pydantic models")
    payload = dump(mode="json", exclude_none=True)
    if not isinstance(payload, dict):
        raise TypeError("drawing region audit values must serialize as objects")
    return payload


def _drawing_region_parent_evidence(
    parent_inventory: dict[str, Any],
    asset: SourceAsset,
) -> tuple[str, SourceReference] | None:
    candidates = sorted(
        (
            item
            for item in parent_inventory.values()
            if str(
                (item.source_ref.model_extra or {}).get("asset_sha256") or ""
            ).casefold()
            == asset.sha256
        ),
        key=lambda item: item.evidence_id,
    )
    if not candidates:
        return None
    parent = candidates[0]
    payload = parent.source_ref.model_dump(mode="python", exclude_none=True)
    payload.update(
        {
            "asset_id": asset.asset_id,
            "asset_sha256": asset.sha256,
            "asset_parts": list(asset.parts),
        }
    )
    return parent.evidence_id, SourceReference.model_validate(payload)


def _verified_docx_asset_bytes(source: Path, asset: SourceAsset) -> bytes:
    selected: bytes | None = None
    try:
        package = ZipFile(source, "r")
    except BadZipFile as exc:
        raise ValueError("invalid DOCX package") from exc
    try:
        names = package.namelist()
        for part in asset.parts:
            candidate = PurePosixPath(part)
            if (
                not part.startswith("word/media/")
                or candidate.is_absolute()
                or ".." in candidate.parts
                or "\\" in part
                or "\x00" in part
            ):
                raise ValueError("unsafe DOCX media locator")
            if names.count(part) != 1:
                raise ValueError("DOCX media locator is missing or duplicated")
            payload = package.read(part)
            if len(payload) != asset.byte_size:
                raise ValueError("DOCX media byte size does not match inventory")
            if hashlib.sha256(payload).hexdigest() != asset.sha256:
                raise ValueError("DOCX media SHA-256 does not match inventory")
            if selected is None:
                selected = payload
    finally:
        package.close()
    if selected is None:
        raise ValueError("DOCX media asset has no locator")
    return selected


async def _drawing_region_vlm_sidecar(
    source: Path,
    evidence: DocumentEvidence,
    inventory: SourceAssetInventory,
    extractor: _DrawingRegionVLMExtractor | None,
    *,
    max_assets: int,
    max_asset_bytes: int,
    max_regions: int,
    timeout_seconds: float,
    setup_failure_type: str | None = None,
) -> tuple[list[Any], dict[str, Any]]:
    """Screen verified DOCX images and return additive facts plus audit state."""

    sidecar: dict[str, Any] = {
        "schema_version": _DRAWING_REGION_VLM_SCHEMA_VERSION,
        "status": "not_applicable",
        "source_kind": inventory.source_kind,
        "max_assets": max_assets,
        "max_asset_bytes": max_asset_bytes,
        "max_regions": max_regions,
        "timeout_seconds": timeout_seconds,
        "asset_count": len(inventory.assets),
        "analyzed_asset_count": 0,
        "region_call_count": 0,
        "fact_count": 0,
        "needs_review": False,
        "issues": [],
        "assets": [],
    }
    if inventory.source_kind != "docx":
        sidecar.update(
            status="unsupported",
            needs_review=True,
            issues=[
                _sidecar_issue(
                    "DRAWING_REGION_SOURCE_UNSUPPORTED",
                    "drawing region VLM currently supports DOCX embedded images only",
                )
            ],
        )
        return [], sidecar
    if extractor is None:
        failure_suffix = (
            f": {setup_failure_type}" if setup_failure_type is not None else ""
        )
        sidecar.update(
            status="misconfigured",
            needs_review=True,
            issues=[
                _sidecar_issue(
                    "DRAWING_REGION_EXTRACTOR_UNAVAILABLE",
                    "drawing region VLM was enabled without an extractor"
                    f"{failure_suffix}",
                )
            ],
        )
        return [], sidecar
    if (
        source.stat().st_size != inventory.source_byte_size
        or _sha256_file(source) != inventory.source_sha256
    ):
        sidecar.update(
            status="failed",
            needs_review=True,
            issues=[
                _sidecar_issue(
                    "DRAWING_REGION_SOURCE_MISMATCH",
                    "source bytes do not match the asset inventory",
                )
            ],
        )
        return [], sidecar

    facts: list[Any] = []
    parent_inventory = evidence_inventory(evidence)
    eligible_position = 0
    remaining_regions = max_regions
    completed_assets = 0
    failed_assets = 0
    for asset in inventory.assets:
        asset_payload: dict[str, Any] = {
            "asset_id": asset.asset_id,
            "asset_sha256": asset.sha256,
            "mime_type": asset.mime_type,
            "byte_size": asset.byte_size,
        }
        if (
            not asset.mime_type.casefold().startswith("image/")
            or asset.coverage_status != "inventoried_referenced"
            or not asset.source_refs
        ):
            asset_payload.update(
                status="skipped",
                reason="not_a_referenced_embedded_image",
            )
            sidecar["assets"].append(asset_payload)
            continue
        if eligible_position >= max_assets:
            issue = _sidecar_issue(
                "DRAWING_REGION_ASSET_LIMIT",
                "drawing region asset limit left this source asset unanalyzed",
            )
            asset_payload.update(
                status="skipped",
                reason="max_assets",
                needs_review=True,
                issues=[issue],
            )
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            eligible_position += 1
            continue
        eligible_position += 1
        if asset.byte_size > max_asset_bytes:
            issue = _sidecar_issue(
                "DRAWING_REGION_ASSET_TOO_LARGE",
                "drawing region asset exceeded the configured byte limit",
            )
            asset_payload.update(
                status="skipped",
                reason="max_asset_bytes",
                needs_review=True,
                issues=[issue],
            )
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            continue
        if remaining_regions <= 0:
            issue = _sidecar_issue(
                "DRAWING_REGION_REGION_LIMIT",
                "drawing region call limit left this source asset unanalyzed",
            )
            asset_payload.update(
                status="skipped",
                reason="max_regions",
                needs_review=True,
                issues=[issue],
            )
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            continue
        parent_evidence = _drawing_region_parent_evidence(parent_inventory, asset)
        if parent_evidence is None:
            issue = _sidecar_issue(
                "DRAWING_REGION_PARENT_EVIDENCE_MISSING",
                "embedded image has no replayable visual evidence parent",
            )
            asset_payload.update(status="failed", issues=[issue], audit=[])
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            failed_assets += 1
            continue
        parent_evidence_id, parent_source_ref = parent_evidence
        try:
            image_bytes = _verified_docx_asset_bytes(source, asset)
        except Exception as exc:  # noqa: BLE001 - fail closed per source asset
            issue = _sidecar_issue(
                "DRAWING_REGION_ASSET_READ_FAILED",
                f"verified DOCX media could not be read: {exc.__class__.__name__}",
            )
            asset_payload.update(status="failed", issues=[issue], audit=[])
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            failed_assets += 1
            continue
        try:
            result = await asyncio.wait_for(
                extractor.analyze(
                    image_bytes,
                    evidence_id=parent_evidence_id,
                    source_ref=parent_source_ref,
                    max_regions=remaining_regions,
                ),
                timeout=timeout_seconds,
            )
            raw_result_facts = list(result.facts)
            result_issues = [_model_payload(item) for item in result.issues]
            result_audit = [_model_payload(item) for item in result.audit]
        except TimeoutError:
            issue = _sidecar_issue(
                "DRAWING_REGION_ASSET_TIMEOUT",
                "drawing region analysis exceeded its per-asset timeout",
            )
            asset_payload.update(status="failed", issues=[issue], audit=[])
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            failed_assets += 1
            continue
        except Exception as exc:  # noqa: BLE001 - optional enhancement is isolated
            issue = _sidecar_issue(
                "DRAWING_REGION_ASSET_FAILED",
                f"drawing region analysis failed: {exc.__class__.__name__}",
            )
            asset_payload.update(status="failed", issues=[issue], audit=[])
            sidecar["issues"].append(issue)
            sidecar["assets"].append(asset_payload)
            failed_assets += 1
            continue

        audited_fact_ids = {
            fact_id
            for item in result_audit
            if item.get("disposition") == "fact"
            for fact_id in item.get("fact_ids", [])
            if isinstance(fact_id, str)
        }
        returned_fact_ids = {
            str(getattr(fact, "fact_id", "")) for fact in raw_result_facts
        }
        result_facts = [
            fact
            for fact in raw_result_facts
            if str(getattr(fact, "fact_id", "")) in audited_fact_ids
        ]
        if audited_fact_ids != returned_fact_ids:
            result_issues.append(
                _sidecar_issue(
                    "DRAWING_REGION_AUDIT_MISMATCH",
                    "drawing region facts and region audit do not match",
                )
            )
        consumed_regions = sum(
            item.get("disposition") in _DRAWING_REGION_VLM_CONSUMED_DISPOSITIONS
            for item in result_audit
        )
        if result_facts and consumed_regions == 0:
            consumed_regions = min(len(result_facts), remaining_regions)
        remaining_regions = max(0, remaining_regions - consumed_regions)
        facts.extend(result_facts)
        sidecar["issues"].extend(copy.deepcopy(result_issues))
        sidecar["region_call_count"] += consumed_regions
        sidecar["analyzed_asset_count"] += 1
        if result_facts:
            asset_status = "partial" if result_issues else "completed"
        elif result_issues:
            asset_status = "failed"
        else:
            asset_status = "screened_no_regions"
        asset_payload.update(
            status=asset_status,
            fact_count=len(result_facts),
            region_call_count=consumed_regions,
            needs_review=bool(result_issues),
            issues=result_issues,
            audit=result_audit,
        )
        sidecar["assets"].append(asset_payload)
        if asset_status == "failed":
            failed_assets += 1
        else:
            completed_assets += 1

    sidecar["fact_count"] = len(facts)
    sidecar["needs_review"] = bool(sidecar["issues"] or failed_assets)
    if completed_assets and sidecar["needs_review"]:
        sidecar["status"] = "partial"
    elif completed_assets:
        sidecar["status"] = "completed"
    elif failed_assets:
        sidecar["status"] = "failed"
    elif eligible_position:
        sidecar["status"] = "skipped"
    return facts, sidecar


async def run_candidate(
    source: Path,
    *,
    mineru: _MinerUParser,
    extractor: _InstructorExtractor,
    original_filename: str | None = None,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    normalizer: MinerUInputNormalizer | None = None,
    visual_assets_enabled: bool = False,
    visual_assets_max: int = 8,
    visual_asset_max_bytes: int = 10 * 1024 * 1024,
    visual_asset_timeout_seconds: float = 180.0,
    drawing_region_vlm_enabled: bool = False,
    drawing_region_vlm_extractor: _DrawingRegionVLMExtractor | None = None,
    drawing_region_vlm_max_regions: int = 16,
    drawing_region_vlm_timeout_seconds: float = 30.0,
    drawing_region_vlm_setup_failure_type: str | None = None,
    route_plan: DocumentRoutePlan | None = None,
    semantic_execution: SemanticExecutionSpec | None = None,
    tenant_id: str = "",
    task_id: str = "",
    source_kind: str = "",
    routing_attempt: int = 0,
) -> dict[str, Any]:
    """Execute one read-only candidate under workflow-issued capabilities."""

    if route_plan is not None and not isinstance(route_plan, DocumentRoutePlan):
        raise TypeError("MinerU requires an in-memory DocumentRoutePlan capability")
    if semantic_execution is not None:
        SemanticStrategyExecutor.validate_capability(semantic_execution)
    route_type_hint = (
        route_plan.document_type_hint.value
        if route_plan is not None and route_plan.document_type_hint is not None
        else None
    )
    route_subtype_hint = (
        route_plan.document_subtype_hint.value
        if route_plan is not None and route_plan.document_subtype_hint is not None
        else None
    )
    semantic_type_hint = (
        semantic_execution.document_type_hint.value
        if semantic_execution is not None
        and semantic_execution.document_type_hint is not None
        else None
    )
    document_type_hint = document_type_hint or route_type_hint or semantic_type_hint
    document_subtype_hint = document_subtype_hint or route_subtype_hint
    if drawing_region_vlm_enabled:
        if not 1 <= drawing_region_vlm_max_regions <= _DRAWING_REGION_VLM_MAX_REGIONS:
            raise ValueError("drawing_region_vlm_max_regions must be between 1 and 16")
        if not (
            0
            < drawing_region_vlm_timeout_seconds
            <= _DRAWING_REGION_VLM_MAX_TIMEOUT_SECONDS
        ):
            raise ValueError("drawing_region_vlm_timeout_seconds must be in (0, 180]")
    source = source.resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    display_filename = original_filename or source.name
    started = time.perf_counter()
    adaptive_routing = (
        _consumed_route_summary(route_plan, routing_attempt=routing_attempt)
        if route_plan is not None
        else None
    )
    effective_visual_assets_enabled = bool(visual_assets_enabled)
    effective_drawing_region_vlm_enabled = bool(drawing_region_vlm_enabled)
    effective_visual_assets_max = visual_assets_max
    effective_drawing_region_vlm_max_regions = drawing_region_vlm_max_regions
    if semantic_execution is not None:
        visual_limit = semantic_execution.budget.max_visual_regions
        effective_visual_assets_enabled = bool(
            effective_visual_assets_enabled and visual_limit > 0
        )
        effective_drawing_region_vlm_enabled = bool(
            effective_drawing_region_vlm_enabled and visual_limit > 0
        )
        effective_visual_assets_max = min(visual_assets_max, visual_limit)
        effective_drawing_region_vlm_max_regions = min(
            drawing_region_vlm_max_regions,
            visual_limit,
        )
    try:
        asset_inventory = await asyncio.to_thread(inventory_source_assets, source)
    except SourceAssetInventoryError as exc:
        asset_inventory = SourceAssetInventory(
            source_kind=source.suffix.lstrip(".").casefold() or "unknown",
            source_name=source.name,
            source_sha256=_sha256_file(source),
            source_byte_size=source.stat().st_size,
            coverage_status="partial",
            warnings=[f"source_asset_inventory_error:{exc.__class__.__name__}"],
        )
    spreadsheet_evidence = await asyncio.to_thread(
        _spreadsheet_document_evidence,
        source,
        original_filename=display_filename,
    )
    docx_evidence = None
    if source.suffix.casefold() == ".docx":
        # Keep compatibility with injected one-argument test/adapter callables
        # while allowing the native parser to preserve the original filename.
        docx_kwargs: dict[str, Any] = {}
        try:
            parameters = inspect.signature(parse_docx_native_evidence).parameters
            if "original_filename" in parameters or any(
                parameter.kind is inspect.Parameter.VAR_KEYWORD
                for parameter in parameters.values()
            ):
                docx_kwargs["original_filename"] = display_filename
        except (TypeError, ValueError):
            docx_kwargs["original_filename"] = display_filename
        docx_evidence = await asyncio.to_thread(
            parse_docx_native_evidence,
            source,
            **docx_kwargs,
        )
    authority_evidence = (
        spreadsheet_evidence if spreadsheet_evidence is not None else docx_evidence
    )
    input_normalizer = normalizer or MinerUInputNormalizer()
    with input_normalizer.prepare(
        source,
        original_filename=display_filename,
        native_evidence_available=authority_evidence is not None,
    ) as prepared:
        if not prepared.ready or prepared.path is None:
            raise MinerUInputContractError(
                "benchmark candidate requires one terminal document input"
            )
        normalization_finished = time.perf_counter()
        source_sha256 = prepared.source_sha256
        display_filename = prepared.original_filename
        normalization_metadata = copy.deepcopy(prepared.metadata)
        if authority_evidence is None:
            parsed = await mineru.parse(
                prepared.path,
                original_filename=prepared.upload_filename,
            )
            if source.suffix.casefold() == ".pdf":
                try:
                    parsed.evidence, _fusion = apply_pdf_text_layer_fusion(
                        extract_pdf_text_layer(source),
                        parsed.evidence,
                    )
                except PdfTextLayerError as exc:
                    parsed.evidence.warnings.append(
                        f"pdf_native_text_unavailable:{exc.__class__.__name__}"
                    )
        else:
            parsed = MinerUParseResult(
                evidence=authority_evidence,
                task_id=(
                    f"spreadsheet-{source_sha256[:20]}"
                    if spreadsheet_evidence is not None
                    else f"docx-native-{source_sha256[:20]}"
                ),
                member_name=display_filename,
                content_list_v2=[],
                middle_json=None,
                elapsed_ms=0.0,
            )
        parsed.evidence.raw["input_normalization"] = copy.deepcopy(
            normalization_metadata
        )
        parsed_pages = {page.page_number for page in parsed.evidence.pages}
        fulfilled_requirements = sum(
            1
            for requirement in asset_inventory.requirements
            if requirement.kind == "pdf_page_render"
            and requirement.source_ref.page in parsed_pages
            and source.suffix.casefold() == ".pdf"
        )
        parsed.evidence.raw["source_asset_inventory"] = {
            **asset_inventory.model_dump(mode="json"),
            **asset_inventory.summary(),
            "analyzed_asset_count": 0,
            "fulfilled_requirement_count": fulfilled_requirements,
            "analyzed_count": fulfilled_requirements,
        }
        if semantic_execution is not None:
            page_count = len(parsed.evidence.pages)
            table_count = sum(len(page.tables) for page in parsed.evidence.pages)
            if page_count > semantic_execution.budget.max_pages:
                raise SemanticExecutionBudgetExceeded(
                    "semantic execution page budget exceeded"
                )
            if table_count > semantic_execution.budget.max_tables:
                raise SemanticExecutionBudgetExceeded(
                    "semantic execution table budget exceeded"
                )
        if route_plan is not None:
            parsed.evidence.raw["document_route_context"] = route_plan.policy_context()
            route_uncertain = bool(asset_inventory.requirements) or any(
                page.needs_vlm()[0] for page in parsed.evidence.pages
            )
            effective_visual_assets_enabled = route_plan.visual_enabled(
                configured=effective_visual_assets_enabled,
                uncertain=route_uncertain,
            )
            effective_drawing_region_vlm_enabled = route_plan.visual_enabled(
                configured=effective_drawing_region_vlm_enabled,
                uncertain=route_uncertain,
            )
        if effective_visual_assets_enabled:
            parsed.evidence = await enrich_visual_asset_evidence(
                source,
                parsed.evidence,
                asset_inventory,
                mineru,
                max_assets=effective_visual_assets_max,
                max_asset_bytes=visual_asset_max_bytes,
                timeout_seconds=visual_asset_timeout_seconds,
                concurrency=1,
            )
            enrichment = parsed.evidence.raw["visual_asset_enrichment"]
            analyzed_asset_count = int(enrichment["success_count"])
            parsed.evidence.raw["source_asset_inventory"] = {
                **asset_inventory.model_dump(mode="json"),
                **asset_inventory.summary(),
                "analyzed_asset_count": analyzed_asset_count,
                "fulfilled_requirement_count": fulfilled_requirements,
                "analyzed_count": analyzed_asset_count + fulfilled_requirements,
            }
    mineru_finished = time.perf_counter()
    extracted = await _extract_with_explicit_hints(
        extractor,
        parsed.evidence,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
        semantic_execution=semantic_execution,
    )
    extracted, classification_normalization = _normalized_instructor_classification(
        extracted,
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
    )
    instructor_finished = time.perf_counter()
    semantic_content_units = _semantic_content_units_payload(
        extracted,
        parsed.evidence,
    )
    record, field_names = _benchmark_projection(
        source_sha256=source_sha256,
        original_filename=display_filename,
        parsed=parsed,
        extracted=extracted,
    )
    semantic_projection_record = record
    if record.get("document_type") == "technical_document":
        from ..technical_projection import project_technical_document

        technical_record = _production_document(
            {
                "schema_version": "m1.mineru-instructor-candidate.v1",
                "record": copy.deepcopy(record),
                "result": extracted.model_dump(mode="json"),
            },
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
        )
        semantic_projection_record = project_technical_document(
            technical_record,
            filename=display_filename,
        ).model_dump(mode="json")
    record["extraction"]["metadata"]["classification_normalization"] = copy.deepcopy(
        classification_normalization
    )
    projection_finished = time.perf_counter()
    drawing_region_facts: list[Any] = []
    drawing_region_sidecar: dict[str, Any] | None = None
    if effective_drawing_region_vlm_enabled:
        drawing_region_max_assets = min(
            effective_visual_assets_max,
            _DRAWING_REGION_VLM_MAX_ASSETS,
        )
        try:
            (
                drawing_region_facts,
                drawing_region_sidecar,
            ) = await _drawing_region_vlm_sidecar(
                source,
                parsed.evidence,
                asset_inventory,
                drawing_region_vlm_extractor,
                max_assets=drawing_region_max_assets,
                max_asset_bytes=visual_asset_max_bytes,
                max_regions=effective_drawing_region_vlm_max_regions,
                timeout_seconds=drawing_region_vlm_timeout_seconds,
                setup_failure_type=drawing_region_vlm_setup_failure_type,
            )
        except Exception as exc:  # noqa: BLE001 - optional enhancement is isolated
            drawing_region_facts = []
            drawing_region_sidecar = {
                "schema_version": _DRAWING_REGION_VLM_SCHEMA_VERSION,
                "status": "failed",
                "source_kind": asset_inventory.source_kind,
                "max_assets": drawing_region_max_assets,
                "max_asset_bytes": visual_asset_max_bytes,
                "max_regions": effective_drawing_region_vlm_max_regions,
                "timeout_seconds": drawing_region_vlm_timeout_seconds,
                "asset_count": len(asset_inventory.assets),
                "analyzed_asset_count": 0,
                "region_call_count": 0,
                "fact_count": 0,
                "needs_review": True,
                "issues": [
                    _sidecar_issue(
                        "DRAWING_REGION_ENHANCEMENT_FAILED",
                        "drawing region enhancement failed without changing "
                        f"deterministic extraction: {exc.__class__.__name__}",
                    )
                ],
                "assets": [],
            }
    drawing_region_finished = time.perf_counter()
    semantic_completion = None
    semantic_completion_failure_type: str | None = None
    try:
        semantic_completion = build_semantic_completion(
            parsed.evidence,
            display_filename,
            extracted,
            semantic_projection_record,
            additional_facts=drawing_region_facts,
        )
    except Exception as exc:  # noqa: BLE001 - optional completion is fail-open
        if drawing_region_facts and drawing_region_sidecar is not None:
            excluded_fact_count = len(drawing_region_facts)
            drawing_region_facts = []
            completion_issue = _sidecar_issue(
                "DRAWING_REGION_COMPLETION_REJECTED",
                "drawing region facts failed semantic completion validation and "
                f"were excluded: {exc.__class__.__name__}",
            )
            drawing_region_sidecar["status"] = "failed"
            drawing_region_sidecar["excluded_fact_count"] = excluded_fact_count
            drawing_region_sidecar["fact_count"] = 0
            drawing_region_sidecar["needs_review"] = True
            drawing_region_sidecar["issues"].append(completion_issue)
            try:
                semantic_completion = build_semantic_completion(
                    parsed.evidence,
                    display_filename,
                    extracted,
                    semantic_projection_record,
                )
            except Exception as fallback_exc:  # noqa: BLE001 - fail open below
                semantic_completion_failure_type = fallback_exc.__class__.__name__
        else:
            semantic_completion_failure_type = exc.__class__.__name__

    if semantic_completion is None:
        failure_issue = _sidecar_issue(
            "SEMANTIC_COMPLETION_FAILED",
            "semantic completion failed; deterministic extraction was retained: "
            f"{semantic_completion_failure_type or 'UnknownError'}",
        )
        semantic_facts: list[dict[str, Any]] = []
        semantic_dispositions: list[dict[str, Any]] = []
        completion_payload = {
            "schema_version": "m1.semantic-completion-failure.v1",
            "status": "failed",
            "review_required": True,
            "issues": [failure_issue],
        }
        record["needs_review"] = True
        if not any(
            issue.get("code") == "SEMANTIC_COMPLETION_FAILED"
            for issue in record["validation_issues"]
        ):
            record["validation_issues"].append(
                {
                    "code": "SEMANTIC_COMPLETION_FAILED",
                    "severity": "warning",
                    "message": failure_issue["message"],
                }
            )
    else:
        completion_payload = semantic_completion.model_dump(mode="json")
        semantic_facts = completion_payload.pop("facts")
        semantic_dispositions = completion_payload.pop("dispositions")
    if (
        semantic_completion is not None
        and semantic_completion.review_required
        and not record["needs_review"]
    ):
        record["needs_review"] = True
        record["validation_issues"].append(
            {
                "code": "SEMANTIC_COMPLETION_REVIEW_REQUIRED",
                "severity": "warning",
                "message": "semantic completion contains evidence requiring review",
            }
        )
    semantic_finished = time.perf_counter()

    result_payload = extracted.model_dump(mode="json")
    final_semantic_complete = bool(
        semantic_completion is not None and not semantic_completion.review_required
    )
    result_payload["instructor_raw_semantic_complete"] = bool(
        extracted.semantic_complete
    )
    result_payload["semantic_complete"] = final_semantic_complete
    result_payload["content_units"] = semantic_content_units
    result_payload["semantic_facts"] = copy.deepcopy(semantic_facts)
    result_payload["semantic_evidence_dispositions"] = copy.deepcopy(
        semantic_dispositions
    )
    result_payload["semantic_completeness_audit"] = copy.deepcopy(completion_payload)
    record_metadata = record["extraction"]["metadata"]
    record_metadata["instructor_raw_semantic_complete"] = bool(
        extracted.semantic_complete
    )
    record_metadata["semantic_complete"] = final_semantic_complete
    record_raw_content = record["extraction"]["raw_content"]
    record_raw_content["semantic_facts"] = copy.deepcopy(semantic_facts)
    record_raw_content["semantic_evidence_dispositions"] = copy.deepcopy(
        semantic_dispositions
    )
    record_raw_content["semantic_completeness_audit"] = copy.deepcopy(
        completion_payload
    )
    if drawing_region_sidecar is not None:
        result_payload["drawing_region_vlm"] = copy.deepcopy(drawing_region_sidecar)
        record_raw_content["drawing_region_vlm"] = copy.deepcopy(drawing_region_sidecar)
    finished = time.perf_counter()
    timing_payload = {
        "normalization_ms": round(
            (normalization_finished - started) * 1000,
            3,
        ),
        "mineru_ms": round(
            (mineru_finished - normalization_finished) * 1000,
            3,
        ),
        "instructor_ms": round(
            (instructor_finished - mineru_finished) * 1000,
            3,
        ),
        "projection_ms": round(
            (projection_finished - instructor_finished) * 1000,
            3,
        ),
        "semantic_completion_ms": round(
            (semantic_finished - drawing_region_finished) * 1000,
            3,
        ),
        "total_ms": round((finished - started) * 1000, 3),
    }
    if effective_drawing_region_vlm_enabled:
        timing_payload["drawing_region_vlm_ms"] = round(
            (drawing_region_finished - projection_finished) * 1000,
            3,
        )
    payload = {
        "schema_version": "m1.mineru-instructor-candidate.v1",
        "record": record,
        "result": result_payload,
        "evidence_summary": parsed.evidence.summary(),
        "source_asset_inventory": copy.deepcopy(
            parsed.evidence.raw["source_asset_inventory"]
        ),
        "visual_asset_enrichment": copy.deepcopy(
            parsed.evidence.raw.get("visual_asset_enrichment")
        ),
        "input_normalization": normalization_metadata,
        "projection": {
            "field_names": field_names,
            "record_count": len(record["lines"]),
            "document_intent_family": extracted.document_intent_family,
            "document_subtype": extracted.document_subtype,
            "primary_record_table_ids": list(extracted.primary_record_table_ids),
            "auxiliary_record_table_ids": sorted(
                {
                    segment.table_id
                    for segment in extracted.segments
                    if segment.records
                    and segment.table_id not in extracted.primary_record_table_ids
                }
            ),
            "content_unit_count": extracted.content_unit_count,
            "content_model_bound_count": extracted.content_model_bound_count,
            "content_local_fallback_count": (extracted.content_local_fallback_count),
            "content_semantic_coverage_ratio": (
                extracted.content_semantic_coverage_ratio
            ),
        },
        "timing": timing_payload,
    }
    if semantic_execution is not None:
        payload["semantic_execution"] = semantic_execution.value_free_dump()
    if adaptive_routing is not None:
        payload["adaptive_routing"] = adaptive_routing
    if drawing_region_sidecar is not None:
        payload["drawing_region_vlm"] = copy.deepcopy(drawing_region_sidecar)
    return payload


@dataclass(slots=True)
class MinerUInstructorServiceResult:
    """Validated production result plus its bounded authority summary."""

    document: DocumentRecord
    summary: dict[str, Any]
    payload: dict[str, Any]


def _annotate_pipeline_failure(
    exc: Exception,
    *,
    stage: str,
    reason: str,
) -> Exception:
    """Attach bounded diagnostics without retaining provider or document text."""

    if not str(getattr(exc, "failure_stage", "") or ""):
        with suppress(Exception):
            exc.__dict__.setdefault("failure_stage", stage[:96])
    if not str(getattr(exc, "failure_reason", "") or ""):
        with suppress(Exception):
            exc.__dict__.setdefault("failure_reason", reason[:64])
    return exc


def _production_line_id(
    source_sha256: str,
    line_index: int,
    line: dict[str, Any],
) -> str:
    canonical = json.dumps(
        line,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    digest = hashlib.sha256(
        f"{source_sha256}\x1f{line_index}\x1f{canonical}".encode()
    ).hexdigest()[:20]
    return f"mineru-instructor-{digest}"


_PRODUCTION_LINE_ALIASES = {
    "material_code": "product_code",
    "name": "name_raw",
    "specification": "specification_raw",
    "unit_price": "unit_price_tax_included",
    "amount": "amount_tax_included",
}
_NUMERIC_PRODUCTION_LINE_FIELDS = frozenset(
    {
        "quantity",
        "unit_price_tax_included",
        "amount_tax_included",
        "unit_price_tax_excluded",
        "amount_tax_excluded",
        "package_quantity",
        "piece_count",
        "volume",
    }
)

_PRODUCTION_HEADER_ALIASES = {
    "document_title": "title",
    "company": "issuer",
    "order_date": "date_raw",
    "order_date_raw": "date_raw",
    "delivery_date": "delivery_date_raw",
    "payment_terms": "settlement_method",
}
_ORDER_NUMBER_DATE_FRAGMENT = re.compile(r"(?<!\d)(?P<date>20\d{6})(?!\d)")
_METER_VALUE = re.compile(
    r"(?<![\d.])(?P<value>\d+(?:\.\d+)?)\s*(?:M|米)(?![A-Za-z])",
    re.IGNORECASE,
)
_IDENTIFIER_TRAILING_NUMBER = re.compile(
    r"(?:^|[-_/])(?P<value>\d+(?:\.\d+)?)$",
    re.IGNORECASE,
)


def _append_issue_once(record: dict[str, Any], issue: dict[str, Any]) -> bool:
    issues = record.setdefault("validation_issues", [])
    if not isinstance(issues, list):
        return False
    code = issue.get("code")
    paths = issue.get("paths") or []
    if any(
        isinstance(existing, dict)
        and existing.get("code") == code
        and (existing.get("paths") or []) == paths
        for existing in issues
    ):
        return False
    issues.append(issue)
    record["needs_review"] = True
    return True


def _order_number_date(value: object) -> str | None:
    match = _ORDER_NUMBER_DATE_FRAGMENT.search(str(value or ""))
    if match is None:
        return None
    token = match.group("date")
    try:
        return date(int(token[:4]), int(token[4:6]), int(token[6:8])).isoformat()
    except ValueError:
        return None


def _line_meter_values(value: object) -> set[Decimal]:
    return {
        Decimal(match.group("value"))
        for match in _METER_VALUE.finditer(str(value or ""))
    }


def _append_line_semantic_conflicts(record: dict[str, Any]) -> int:
    """Report strong cross-field contradictions without rewriting source facts."""

    lines = record.get("lines")
    field_meta = record.get("field_meta")
    if not isinstance(lines, list) or not isinstance(field_meta, dict):
        return 0
    added = 0
    for index, line in enumerate(lines):
        if not isinstance(line, dict):
            continue
        identifier_field = "model" if line.get("model") not in (None, "") else "product_code"
        identifier = str(line.get(identifier_field) or "").strip()
        identifier_match = _IDENTIFIER_TRAILING_NUMBER.search(identifier)
        if identifier_match is None:
            continue
        identifier_value = Decimal(identifier_match.group("value"))
        name_values = _line_meter_values(line.get("name_raw"))
        specification_values = _line_meter_values(line.get("specification_raw"))
        if (
            identifier_value not in name_values
            or not specification_values
            or identifier_value in specification_values
        ):
            continue
        paths = [
            f"$.lines[{index}].{identifier_field}",
            f"$.lines[{index}].name_raw",
            f"$.lines[{index}].specification_raw",
        ]
        source_refs: list[dict[str, Any]] = []
        for path in paths:
            metadata = field_meta.get(path)
            if not isinstance(metadata, dict):
                continue
            for reference in metadata.get("source_refs") or []:
                if reference not in source_refs:
                    source_refs.append(copy.deepcopy(reference))
        if _append_issue_once(
            record,
            {
                "code": "LINE_IDENTITY_SPECIFICATION_CONFLICT",
                "severity": "warning",
                "message": (
                    "model/name length evidence conflicts with the explicit "
                    "specification; all source values were preserved"
                ),
                "paths": paths,
                "source_refs": source_refs,
                "expected": str(identifier_value),
                "actual": sorted(str(value) for value in specification_values),
            },
        ):
            added += 1
    return added


def _normalize_production_header(record: dict[str, Any]) -> dict[str, int]:
    """Project semantic header names into the stable DocumentHeader contract."""

    header = record.setdefault("header", {})
    field_meta = record.setdefault("field_meta", {})
    issues = record.setdefault("validation_issues", [])
    if not isinstance(header, dict) or not isinstance(field_meta, dict):
        return {}

    normalized_count = 0
    conflict_count = 0
    for source_name, target_name in _PRODUCTION_HEADER_ALIASES.items():
        source_value = header.get(source_name)
        if source_value in (None, ""):
            continue
        projected_value = source_value
        if target_name in {"date_raw", "delivery_date_raw"}:
            projected_value = _complete_purchase_date_iso(str(source_value))
            if projected_value is None:
                continue
        target_value = header.get(target_name)
        if target_value not in (None, ""):
            target_marker = unicodedata.normalize("NFKC", str(target_value)).casefold()
            source_marker = unicodedata.normalize(
                "NFKC", str(projected_value)
            ).casefold()
            if target_marker != source_marker:
                conflict_count += 1
                if isinstance(issues, list) and not any(
                    isinstance(issue, dict)
                    and issue.get("code") == "MINERU_HEADER_ALIAS_CONFLICT"
                    and target_name in (issue.get("paths") or [""])[0]
                    for issue in issues
                ):
                    issues.append(
                        {
                            "code": "MINERU_HEADER_ALIAS_CONFLICT",
                            "severity": "warning",
                            "message": (
                                "semantic and standard header values conflict; "
                                "the existing standard value was preserved"
                            ),
                            "paths": [f"$.header.{target_name}"],
                            "source_refs": copy.deepcopy(
                                (
                                    field_meta.get(f"$.header.{source_name}")
                                    or {}
                                ).get("source_refs")
                                or []
                            ),
                            "expected": target_value,
                            "actual": projected_value,
                        }
                    )
                    record["needs_review"] = True
            continue
        header[target_name] = projected_value
        source_metadata = field_meta.get(f"$.header.{source_name}")
        if isinstance(source_metadata, dict):
            projected_metadata = {
                **copy.deepcopy(source_metadata),
                "inferred": True,
                "normalized_from": source_name,
            }
            if (
                source_metadata.get("review_required") is not True
                and source_metadata.get("sensitive") is not True
                and _projection_source_refs_are_locatable(
                    source_metadata.get("source_refs")
                )
            ):
                projected_metadata["review_required"] = False
            field_meta[f"$.header.{target_name}"] = projected_metadata
        normalized_count += 1

    for raw_name, standard_name in (
        ("date_raw", "date_standard"),
        ("delivery_date_raw", "delivery_date_standard"),
    ):
        raw_value = header.get(raw_name)
        if raw_value in (None, ""):
            continue
        parsed = _complete_purchase_date_iso(str(raw_value))
        if parsed is None:
            continue
        header[raw_name] = parsed
        raw_metadata = field_meta.get(f"$.header.{raw_name}")
        standard_value = header.get(standard_name)
        if standard_value not in (None, ""):
            standard_parsed = _complete_purchase_date_iso(str(standard_value))
            if standard_parsed != parsed and _append_issue_once(
                record,
                {
                    "code": "MINERU_HEADER_ALIAS_CONFLICT",
                    "severity": "warning",
                    "message": (
                        "raw and standard date values conflict; the "
                        "existing standard value was preserved"
                    ),
                    "paths": [
                        f"$.header.{standard_name}",
                        f"$.header.{raw_name}",
                    ],
                    "source_refs": copy.deepcopy(
                        raw_metadata.get("source_refs") or []
                        if isinstance(raw_metadata, dict)
                        else []
                    ),
                    "expected": standard_value,
                    "actual": parsed,
                },
            ):
                conflict_count += 1
            continue
        header[standard_name] = parsed
        if isinstance(raw_metadata, dict):
            projected_metadata = {
                **copy.deepcopy(raw_metadata),
                "inferred": True,
                "normalized_from": raw_name,
            }
            if (
                raw_metadata.get("review_required") is not True
                and raw_metadata.get("sensitive") is not True
                and _projection_source_refs_are_locatable(
                    raw_metadata.get("source_refs")
                )
            ):
                projected_metadata["review_required"] = False
            field_meta[f"$.header.{standard_name}"] = projected_metadata

    identifier_date = _order_number_date(header.get("order_number"))
    order_date = str(header.get("date_standard") or "").strip()
    if identifier_date and order_date and identifier_date != order_date:
        refs: list[dict[str, Any]] = []
        for path in ("$.header.order_number", "$.header.date_raw"):
            metadata = field_meta.get(path)
            if not isinstance(metadata, dict):
                continue
            for reference in metadata.get("source_refs") or []:
                if reference not in refs:
                    refs.append(copy.deepcopy(reference))
        if _append_issue_once(
            record,
            {
                "code": "ORDER_NUMBER_DATE_CONFLICT",
                "severity": "warning",
                "message": (
                    "the explicitly labeled order date differs from the date "
                    "encoded in the order number; neither value was overwritten"
                ),
                "paths": ["$.header.order_number", "$.header.date_raw"],
                "source_refs": refs,
                "expected": identifier_date,
                "actual": order_date,
            },
        ):
            conflict_count += 1

    order_number = str(header.get("order_number") or "").strip()
    candidates = header.setdefault("candidate_numbers", [])
    if order_number and isinstance(candidates, list) and not candidates:
        metadata = field_meta.get("$.header.order_number")
        candidates.append(
            {
                "value": order_number,
                "kind": "order_number",
                "source_refs": copy.deepcopy(
                    metadata.get("source_refs") or []
                    if isinstance(metadata, dict)
                    else []
                ),
                "score": 100.0,
                "selected": True,
            }
        )
    return {
        "normalized_header_field_count": normalized_count,
        "header_alias_conflict_count": conflict_count,
    }


def _supported_numeric_value(value: object) -> bool:
    if isinstance(value, bool):
        return False
    try:
        parsed = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        return False
    return parsed.is_finite()


_STANDALONE_LENGTH_SPEC = re.compile(
    r"^(?:L(?:ENGTH)?)\s*[:=]\s*"
    r"(?P<number>\d+(?:\.\d+)?)\s*(?P<unit>MM|CM|M)$",
    re.IGNORECASE,
)


def _normalized_standalone_length_spec(value: object) -> str | None:
    """Remove an explicit label from a specification containing only length."""

    normalized = unicodedata.normalize("NFKC", str(value or "")).strip()
    match = _STANDALONE_LENGTH_SPEC.fullmatch(normalized)
    if match is None:
        return None
    return f"{match.group('number')}{match.group('unit').upper()}"


_SPREADSHEET_CELL_COORDINATE = re.compile(
    r"^\$?(?P<column>[A-Z]{1,4})\$?(?P<row>\d+)$",
    re.IGNORECASE,
)
_SPREADSHEET_DISPIMG_IDENTIFIER = re.compile(
    r"(?:^|[=._])DISPIMG\(\s*[\"'](?P<identifier>[^\"']+)[\"']",
    re.IGNORECASE,
)


def _spreadsheet_coordinate_position(value: object) -> tuple[int, int] | None:
    match = _SPREADSHEET_CELL_COORDINATE.fullmatch(str(value or "").strip())
    if match is None:
        return None
    column = 0
    for character in match.group("column").upper():
        column = column * 26 + ord(character) - ord("A") + 1
    return int(match.group("row")), column


def _source_ref_spreadsheet_position(
    source_ref: dict[str, Any],
) -> tuple[str, int, int] | None:
    sheet = str(source_ref.get("sheet") or "").strip()
    if not sheet:
        return None
    row = source_ref.get("logical_source_row", source_ref.get("source_row"))
    column = source_ref.get(
        "logical_source_column",
        source_ref.get("source_column"),
    )
    try:
        if row is not None and column is not None:
            return sheet, int(row), int(column)
    except (TypeError, ValueError):
        pass
    coordinate = source_ref.get("logical_cell") or source_ref.get("cell")
    position = _spreadsheet_coordinate_position(coordinate)
    if position is None:
        return None
    return sheet, position[0], position[1]


def _native_spreadsheet_source_label(
    record: dict[str, Any],
    source_metadata: dict[str, Any],
) -> str | None:
    """Recover the physical column label that produced a mapped value.

    The model may choose a canonical field name, but it may not relabel a native
    spreadsheet column.  ``native_record_layout`` supplies the record/header
    axes, so this recovery works for arbitrary row positions without template
    coordinates or filename rules.
    """

    extraction = record.get("extraction")
    raw_content = extraction.get("raw_content") if isinstance(extraction, dict) else None
    pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    if not isinstance(pages, list):
        return None
    positions = [
        position
        for source_ref in source_metadata.get("source_refs") or []
        if isinstance(source_ref, dict)
        and (position := _source_ref_spreadsheet_position(source_ref)) is not None
    ]
    for sheet, source_row, source_column in positions:
        for page in pages:
            if not isinstance(page, dict):
                continue
            for table in page.get("tables") or []:
                if not isinstance(table, dict) or str(table.get("sheet") or "") != sheet:
                    continue
                layout = table.get("native_record_layout")
                rows = table.get("rows")
                if not isinstance(layout, dict) or not isinstance(rows, list):
                    continue
                if layout.get("orientation") != "rows":
                    continue
                try:
                    local_row = source_row - int(table.get("source_row_offset") or 1)
                    local_column = source_column - int(
                        table.get("source_column_offset") or 1
                    )
                except (TypeError, ValueError):
                    continue
                record_axes = {
                    int(axis)
                    for axis in layout.get("record_axes") or []
                    if isinstance(axis, int) or str(axis).isdigit()
                }
                if local_row not in record_axes or local_column < 0:
                    continue
                header_axes = sorted(
                    {
                        int(axis)
                        for axis in layout.get("header_axes") or []
                        if isinstance(axis, int) or str(axis).isdigit()
                    },
                    reverse=True,
                )
                for header_axis in header_axes:
                    if header_axis < 0 or header_axis >= len(rows):
                        continue
                    header_row = rows[header_axis]
                    if not isinstance(header_row, list) or local_column >= len(header_row):
                        continue
                    label = unicodedata.normalize(
                        "NFKC", str(header_row[local_column] or "")
                    ).strip()
                    if label:
                        return label
    return None


def _spreadsheet_asset_ids_for_value(
    record: dict[str, Any],
    value: object,
) -> list[str]:
    match = _SPREADSHEET_DISPIMG_IDENTIFIER.search(
        unicodedata.normalize("NFKC", str(value or ""))
    )
    if match is None:
        return []
    identifier = match.group("identifier").strip().casefold()
    extraction = record.get("extraction")
    raw_content = extraction.get("raw_content") if isinstance(extraction, dict) else None
    inventory = (
        raw_content.get("source_asset_inventory")
        if isinstance(raw_content, dict)
        else None
    )
    assets = inventory.get("assets") if isinstance(inventory, dict) else None
    if not isinstance(assets, list):
        return []
    matched: list[str] = []
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        aliases = {
            str(alias).strip().casefold()
            for reference in asset.get("source_refs") or []
            if isinstance(reference, dict)
            for alias in reference.get("alt_text") or []
            if str(alias).strip()
        }
        asset_id = str(asset.get("asset_id") or "").strip()
        if identifier in aliases and asset_id and asset_id not in matched:
            matched.append(asset_id)
    return matched


def _attach_line_image_assets(
    line: dict[str, Any],
    *,
    line_prefix: str,
    field_meta: dict[str, Any],
    source_metadata: dict[str, Any],
    asset_ids: list[str],
) -> None:
    if not asset_ids:
        return
    image_refs = line.setdefault("image_refs", [])
    if not isinstance(image_refs, list):
        return
    for asset_id in asset_ids:
        if asset_id not in image_refs:
            image_refs.append(asset_id)
    path = f"{line_prefix}.image_refs"
    existing = field_meta.get(path)
    source_refs = copy.deepcopy(source_metadata.get("source_refs") or [])
    if isinstance(existing, dict):
        for source_ref in existing.get("source_refs") or []:
            if source_ref not in source_refs:
                source_refs.append(copy.deepcopy(source_ref))
    field_meta[path] = {
        **(copy.deepcopy(existing) if isinstance(existing, dict) else {}),
        "source_refs": source_refs,
        "inferred": False,
        "asset_ids": list(image_refs),
        "association_method": "spreadsheet_display_formula",
    }


def _promote_inventory_available_quantity(
    record: dict[str, Any],
    line: dict[str, Any],
    *,
    line_prefix: str,
    field_meta: dict[str, Any],
    candidates: list[tuple[Any, dict[str, Any], str]],
) -> None:
    """Expose the inventory-specific quantity through the stable line view."""

    if str(record.get("document_type") or "").casefold() != "inventory":
        return
    numeric_candidates = [
        (Decimal(str(value).strip()), value, metadata, path)
        for value, metadata, path in candidates
        if _supported_numeric_value(value)
    ]
    distinct_values = {value for value, *_rest in numeric_candidates}
    if not numeric_candidates or len(distinct_values) != 1:
        return
    _numeric, source_value, source_metadata, source_path = numeric_candidates[0]
    quantity_path = f"{line_prefix}.quantity"
    current = line.get("quantity")
    if current not in (None, ""):
        if _supported_numeric_value(current) and Decimal(str(current).strip()) == _numeric:
            return
        source_refs = copy.deepcopy(source_metadata.get("source_refs") or [])
        current_metadata = field_meta.get(quantity_path)
        if isinstance(current_metadata, dict):
            for source_ref in current_metadata.get("source_refs") or []:
                if source_ref not in source_refs:
                    source_refs.append(copy.deepcopy(source_ref))
        _append_issue_once(
            record,
            {
                "code": "MINERU_INVENTORY_QUANTITY_VIEW_CONFLICT",
                "severity": "warning",
                "message": (
                    "available inventory quantity conflicts with an existing standard "
                    "quantity; both source values were preserved"
                ),
                "paths": [quantity_path, source_path],
                "source_refs": source_refs,
                "expected": current,
                "actual": source_value,
            },
        )
        record["needs_review"] = True
        return
    line["quantity"] = source_value
    field_meta[quantity_path] = {
        **copy.deepcopy(source_metadata),
        "inferred": True,
        "review_required": False,
        "normalized_from": source_path,
        "inventory_quantity_view": "available_quantity",
    }


def _normalize_production_lines(record: dict[str, Any]) -> dict[str, int]:
    lines = record.get("lines")
    field_meta = record.setdefault("field_meta", {})
    if not isinstance(lines, list) or not isinstance(field_meta, dict):
        return {}
    populated: dict[str, int] = {}
    for line_index, line in enumerate(lines):
        if not isinstance(line, dict):
            continue
        raw_columns = line.setdefault("raw_columns", {})
        custom_fields = line.setdefault("custom_fields", {})
        if not isinstance(raw_columns, dict) or not isinstance(custom_fields, dict):
            continue
        line_prefix = f"$.lines[{line_index}]"
        available_quantity_candidates: list[tuple[Any, dict[str, Any], str]] = []
        source_items = [
            (name, value)
            for name, value in line.items()
            if name
            not in {
                "line_id",
                "raw_columns",
                "custom_fields",
                "image_refs",
                "name_attributes",
            }
            and isinstance(field_meta.get(f"{line_prefix}.{name}"), dict)
        ]
        normalized_targets: dict[str, str] = {}
        for source_name, value in source_items:
            source_path = f"{line_prefix}.{source_name}"
            source_metadata = field_meta[source_path]
            model_source_label = str(
                source_metadata.get("source_label") or source_name
            )
            native_source_label = _native_spreadsheet_source_label(
                record,
                source_metadata,
            )
            source_label = native_source_label or model_source_label
            native_label_recovered = bool(
                native_source_label
                and _field_alias_token(native_source_label)
                != _field_alias_token(model_source_label)
            )
            if native_label_recovered:
                source_metadata = {
                    **copy.deepcopy(source_metadata),
                    "source_label": source_label,
                    "model_source_label": model_source_label,
                    "source_label_recovered_from_native_header": True,
                }
                field_meta[source_path] = source_metadata
            context_inherited = bool(source_metadata.get("inference_source"))
            if not context_inherited:
                raw_key = _lossless_mapping_key(raw_columns, source_label)
                raw_columns[raw_key] = value
                field_meta[_mapping_field_path(line_prefix, "raw_columns", raw_key)] = {
                    **copy.deepcopy(source_metadata),
                    "inferred": bool(source_metadata.get("inferred")),
                }
            canonical_name = _canonical_record_field_name(
                str(record.get("document_subtype") or ""),
                source_label,
                document_type=str(record.get("document_type") or ""),
            )
            target_name = target_direct_field(canonical_name) or (
                _PRODUCTION_LINE_ALIASES.get(canonical_name, canonical_name)
            )
            _attach_line_image_assets(
                line,
                line_prefix=line_prefix,
                field_meta=field_meta,
                source_metadata=source_metadata,
                asset_ids=_spreadsheet_asset_ids_for_value(record, value),
            )
            if target_name not in _TYPED_ORDER_LINE_FIELDS:
                storage_key = target_storage_key(canonical_name)
                canonical_custom_key = (
                    storage_key.removeprefix("custom:")
                    if str(storage_key or "").startswith("custom:")
                    else source_label
                )
                custom_key = _lossless_mapping_key(
                    custom_fields,
                    canonical_custom_key,
                )
                custom_fields[custom_key] = value
                custom_path = _mapping_field_path(
                    line_prefix,
                    "custom_fields",
                    custom_key,
                )
                field_meta[custom_path] = {
                    **copy.deepcopy(source_metadata),
                    "inferred": bool(source_metadata.get("inferred")),
                }
                if canonical_name == "available_quantity":
                    available_quantity_candidates.append(
                        (value, source_metadata, custom_path)
                    )
                if native_label_recovered and source_name in _TYPED_ORDER_LINE_FIELDS:
                    line[source_name] = None
                    field_meta.pop(source_path, None)
                continue
            if (
                native_label_recovered
                and source_name in _TYPED_ORDER_LINE_FIELDS
                and source_name != target_name
            ):
                target_path = f"{line_prefix}.{target_name}"
                target_value = line.get(target_name)
                if target_value in (None, ""):
                    line[target_name] = value
                    field_meta[target_path] = {
                        **copy.deepcopy(source_metadata),
                        "inferred": False,
                        "normalized_from": source_name,
                        "native_header_reconciled": True,
                    }
                elif unicodedata.normalize("NFKC", str(target_value)).strip().casefold() != (
                    unicodedata.normalize("NFKC", str(value)).strip().casefold()
                ):
                    _append_issue_once(
                        record,
                        {
                            "code": "MINERU_LINE_ALIAS_CONFLICT",
                            "severity": "warning",
                            "message": (
                                "a native spreadsheet header conflicts with an "
                                "existing standard field; the existing value was preserved"
                            ),
                            "paths": [target_path, source_path],
                            "source_refs": copy.deepcopy(
                                source_metadata.get("source_refs") or []
                            ),
                            "expected": target_value,
                            "actual": value,
                        },
                    )
                line[source_name] = None
                field_meta.pop(source_path, None)
                continue
            normalized_targets[source_name] = target_name
        aliases = {**_PRODUCTION_LINE_ALIASES, **normalized_targets}
        for source_name, target_name in aliases.items():
            value = line.get(source_name)
            if value in (None, ""):
                continue
            target_value = line.get(target_name)
            if target_value not in (None, ""):
                source_marker = unicodedata.normalize(
                    "NFKC", str(value)
                ).strip().casefold()
                target_marker = unicodedata.normalize(
                    "NFKC", str(target_value)
                ).strip().casefold()
                if source_name != target_name and source_marker != target_marker:
                    source_path = f"{line_prefix}.{source_name}"
                    target_path = f"{line_prefix}.{target_name}"
                    source_refs: list[dict[str, Any]] = []
                    for path in (target_path, source_path):
                        metadata = field_meta.get(path)
                        if not isinstance(metadata, dict):
                            continue
                        for reference in metadata.get("source_refs") or []:
                            if reference not in source_refs:
                                source_refs.append(copy.deepcopy(reference))
                    _append_issue_once(
                        record,
                        {
                            "code": "MINERU_LINE_ALIAS_CONFLICT",
                            "severity": "warning",
                            "message": (
                                "semantic aliases map to different values; "
                                "the existing standard field was preserved"
                            ),
                            "paths": [target_path, source_path],
                            "source_refs": source_refs,
                            "expected": target_value,
                            "actual": value,
                        },
                    )
                continue
            line[target_name] = value
            source_path = f"{line_prefix}.{source_name}"
            target_path = f"{line_prefix}.{target_name}"
            source_metadata = field_meta.get(source_path)
            if isinstance(source_metadata, dict):
                field_meta[target_path] = {
                    **copy.deepcopy(source_metadata),
                    "inferred": True,
                    **(
                        {"review_required": False}
                        if source_metadata.get(
                            "source_label_recovered_from_native_header"
                        )
                        else {}
                    ),
                    "normalized_from": source_name,
                }
        _promote_inventory_available_quantity(
            record,
            line,
            line_prefix=line_prefix,
            field_meta=field_meta,
            candidates=available_quantity_candidates,
        )
        specification = line.get("specification_raw")
        specification_path = f"{line_prefix}.specification_raw"
        specification_metadata = field_meta.get(specification_path)
        normalized_specification = _normalized_standalone_length_spec(specification)
        if (
            normalized_specification is not None
            and normalized_specification != specification
            and isinstance(specification_metadata, dict)
            and specification_metadata.get("source_refs")
        ):
            line["specification_raw"] = normalized_specification
            field_meta[specification_path] = {
                **copy.deepcopy(specification_metadata),
                "inferred": True,
                "value_normalized_from": specification,
            }
        for name in _NUMERIC_PRODUCTION_LINE_FIELDS:
            value = line.get(name)
            if value in (None, "") or _supported_numeric_value(value):
                continue
            path = f"{line_prefix}.{name}"
            source_metadata = field_meta.get(path)
            source_label = (
                str(source_metadata.get("source_label") or name)
                if isinstance(source_metadata, dict)
                else name
            )
            custom_key = _lossless_mapping_key(custom_fields, source_label)
            custom_fields[custom_key] = value
            if isinstance(source_metadata, dict):
                field_meta[
                    _mapping_field_path(line_prefix, "custom_fields", custom_key)
                ] = {
                    **copy.deepcopy(source_metadata),
                    "inferred": bool(source_metadata.get("inferred")),
                }
            line[name] = None
            removed_metadata = field_meta.pop(path, None)
            issues = record.setdefault("validation_issues", [])
            if isinstance(issues, list):
                issues.append(
                    {
                        "code": "MINERU_LOCAL_FIELD_TYPE_REJECTED",
                        "severity": "warning",
                        "message": (
                            "A source value did not satisfy the standard numeric "
                            "field type and remains available as raw evidence."
                        ),
                        "paths": [path],
                        "source_refs": (
                            copy.deepcopy(removed_metadata.get("source_refs") or [])
                            if isinstance(removed_metadata, dict)
                            else []
                        ),
                    }
                )
            record["needs_review"] = True
        for name in ("model", "product_code", "name_raw", "quantity", "unit"):
            if line.get(name) not in (None, ""):
                populated[name] = populated.get(name, 0) + 1
    return populated


def _positioned_order_number_candidates(
    record: dict[str, Any],
) -> dict[str, tuple[str, list[dict[str, Any]]]]:
    extraction = record.get("extraction")
    raw_content = (
        extraction.get("raw_content") if isinstance(extraction, dict) else None
    )
    pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    raw_candidates: list[tuple[str, dict[str, Any]]] = []
    if not isinstance(pages, list):
        return {}
    pattern = _PURCHASE_HEADER_PATTERNS["order_number"]

    def append_candidates(text: str, source_ref: dict[str, Any]) -> None:
        for match in pattern.finditer(text):
            value = unicodedata.normalize("NFKC", match.group("value")).strip()
            if not value:
                continue
            reference = copy.deepcopy(source_ref)
            reference["evidence_quote"] = match.group(0)
            raw_candidates.append((value, reference))

    def positioned_ref(
        page: dict[str, Any],
        page_number: int,
        item: dict[str, Any],
        part: str,
    ) -> dict[str, Any] | None:
        bbox = item.get("bbox")
        if not isinstance(bbox, dict):
            return None
        try:
            bbox_list = [float(bbox[name]) for name in ("x0", "y0", "x1", "y1")]
        except (KeyError, TypeError, ValueError):
            return None
        reference = {
            "page": page_number,
            "part": f"mineru/{part}",
            "bbox": bbox_list,
            "coordinate_space": str(
                bbox.get("coordinate_space")
                or page.get("coordinate_space")
                or "unknown"
            ),
        }
        native_refs = item.get("native_source_refs")
        if isinstance(native_refs, list) and native_refs:
            reference["native_source_refs"] = copy.deepcopy(native_refs)
        for name in ("sheet", "cell", "source_row", "source_column"):
            if item.get(name) not in (None, ""):
                reference[name] = item[name]
        return reference

    for page in pages:
        if not isinstance(page, dict):
            continue
        try:
            page_number = int(page.get("page_number") or 0)
        except (TypeError, ValueError):
            continue
        for block in page.get("blocks") or []:
            if not isinstance(block, dict):
                continue
            source_ref = positioned_ref(
                page,
                page_number,
                block,
                str(block.get("block_id") or "block"),
            )
            if source_ref is None:
                continue
            append_candidates(str(block.get("text") or ""), source_ref)
        for table in page.get("tables") or []:
            if not isinstance(table, dict):
                continue
            table_id = str(table.get("table_id") or "table")
            for cell in table.get("cells") or []:
                if not isinstance(cell, dict):
                    continue
                cell_part = str(
                    cell.get("source")
                    or f"{table_id}:r{cell.get('row', 0)}:c{cell.get('column', 0)}"
                )
                source_ref = positioned_ref(page, page_number, cell, cell_part)
                if source_ref is None:
                    continue
                append_candidates(str(cell.get("text") or ""), source_ref)

    reconciled = _reconcile_labeled_order_number_candidates(raw_candidates)
    candidates: dict[str, tuple[str, list[dict[str, Any]]]] = {}
    for value, source_ref in reconciled:
        key = value.casefold()
        if key not in candidates:
            candidates[key] = (value, [source_ref])
        elif source_ref not in candidates[key][1]:
            candidates[key][1].append(source_ref)
    return candidates


def _recover_explicit_order_number(record: dict[str, Any]) -> dict[str, Any]:
    candidates = _positioned_order_number_candidates(record)
    diagnostics = {
        "positioned_order_number_candidate_count": len(candidates),
        "order_number_recovered": False,
        "order_number_conflict": False,
    }
    if not candidates:
        return diagnostics
    header = record.setdefault("header", {})
    field_meta = record.setdefault("field_meta", {})
    issues = record.setdefault("validation_issues", [])
    if not isinstance(header, dict) or not isinstance(field_meta, dict):
        return diagnostics
    existing = str(header.get("order_number") or "").strip()
    all_refs = [
        copy.deepcopy(reference)
        for _value, references in candidates.values()
        for reference in references
    ]
    if len(candidates) == 1:
        value, references = next(iter(candidates.values()))
        if not existing:
            header["order_number"] = value
            diagnostics["order_number_recovered"] = True
        elif existing.casefold() != value.casefold():
            value_parts = _po_order_number_parts(value)
            if (
                _po_order_numbers_are_ocr_equivalent(existing, value)
                and value_parts is not None
                and value_parts[0] == "O"
                and any(
                    _source_ref_has_native_provenance(reference)
                    for reference in references
                )
            ):
                header["order_number"] = value
                diagnostics["order_number_ocr_corrected"] = True
            else:
                diagnostics["order_number_conflict"] = True
        if not diagnostics["order_number_conflict"]:
            metadata = {
                "source_refs": copy.deepcopy(references),
                "inferred": True,
                "normalized_from": (
                    "contextual_po_ocr_reconciliation"
                    if diagnostics.get("order_number_ocr_corrected")
                    else "explicit_order_number_label"
                ),
            }
            if _projection_source_refs_are_locatable(references):
                metadata["review_required"] = False
            if diagnostics.get("order_number_ocr_corrected"):
                field_meta["$.header.order_number"] = metadata
            else:
                field_meta.setdefault("$.header.order_number", metadata)
    else:
        diagnostics["order_number_conflict"] = True
    if diagnostics["order_number_conflict"]:
        header["order_number"] = None
        if isinstance(issues, list) and not any(
            isinstance(issue, dict)
            and issue.get("code") == "MINERU_ORDER_NUMBER_CONFLICT"
            for issue in issues
        ):
            issues.append(
                {
                    "code": "MINERU_ORDER_NUMBER_CONFLICT",
                    "severity": "warning",
                    "message": (
                        "positioned explicit order-number facts conflict; "
                        "no inferred value was selected"
                    ),
                    "paths": ["$.header.order_number"],
                    "source_refs": all_refs[:12],
                }
            )
        record["needs_review"] = True
    return diagnostics


def _production_document(
    payload: dict[str, Any],
    *,
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
) -> DocumentRecord:
    raw_record = payload.get("record")
    if not isinstance(raw_record, dict):
        raise MinerUContractError("Instructor candidate record must be an object")
    record = copy.deepcopy(raw_record)
    record["schema_version"] = "m1.document.v2"
    record["document_type"] = str(record.get("document_type") or "unknown")
    record["document_subtype"] = str(record.get("document_subtype") or "unknown")
    type_hint = str(document_type_hint or "").strip()
    subtype_hint = str(document_subtype_hint or "").strip()
    (
        record["document_type"],
        normalized_subtype,
        canonical_type_applied,
        conflict_type,
    ) = _normalize_document_classification_pair(
        record["document_type"],
        record["document_subtype"],
        document_type_hint=type_hint,
        document_subtype_hint=subtype_hint,
    )
    record["document_subtype"] = normalized_subtype or "unknown"
    if record["document_subtype"] in OPEN_DOMAIN_DOCUMENT_SUBTYPES:
        record["lines"] = []
        record["bom"] = []
        field_meta = record.get("field_meta")
        if isinstance(field_meta, dict):
            record["field_meta"] = {
                path: metadata
                for path, metadata in field_meta.items()
                if not path.startswith(("$.lines[", "$.bom["))
            }
    kind_label = str(record.get("document_kind_label") or "").strip()
    kind_type = CANONICAL_SUBTYPE_TYPES.get(kind_label)
    if kind_type and kind_type != record["document_type"]:
        conflict_type = conflict_type or kind_type
        record["document_kind_label"] = normalized_subtype or record["document_type"]
    if conflict_type:
        issues = record.setdefault("validation_issues", [])
        if isinstance(issues, list) and not any(
            isinstance(issue, dict)
            and issue.get("code") == "MINERU_CLASSIFICATION_SUBTYPE_CONFLICT"
            for issue in issues
        ):
            issues.append(
                {
                    "code": "MINERU_CLASSIFICATION_SUBTYPE_CONFLICT",
                    "severity": "warning",
                    "message": (
                        "A model subtype conflicted with the trusted document "
                        "type and was not applied."
                    ),
                    "paths": ["$.document_type", "$.document_subtype"],
                    "source_refs": [],
                }
            )
        record["needs_review"] = True
    source = record.get("source")
    if not isinstance(source, dict):
        raise MinerUContractError("Instructor candidate source must be an object")
    source_sha256 = str(source.get("sha256") or "")
    lines = record.get("lines")
    if not isinstance(lines, list):
        raise MinerUContractError("Instructor candidate lines must be a list")
    for line_index, line in enumerate(lines):
        if not isinstance(line, dict):
            raise MinerUContractError("Instructor candidate line must be an object")
        if not str(line.get("line_id") or "").strip():
            line["line_id"] = _production_line_id(source_sha256, line_index, line)
    typed_line_field_counts = _normalize_production_lines(record)
    line_semantic_conflict_count = _append_line_semantic_conflicts(record)
    order_number_diagnostics = _recover_explicit_order_number(record)
    header_normalization = _normalize_production_header(record)
    extraction = record.setdefault("extraction", {})
    if not isinstance(extraction, dict):
        raise MinerUContractError("Instructor candidate extraction must be an object")
    metadata = extraction.setdefault("metadata", {})
    if not isinstance(metadata, dict):
        raise MinerUContractError(
            "Instructor candidate extraction metadata must be an object"
        )
    metadata["adapter"] = "mineru_instructor"
    metadata["candidate_schema_version"] = payload.get("schema_version")
    normalization = metadata.setdefault("production_normalization", {})
    if not isinstance(normalization, dict):
        normalization = {}
        metadata["production_normalization"] = normalization
    normalization.update(
        {
            "document_type_hint_applied": bool(type_hint),
            "document_subtype_hint_applied": bool(subtype_hint),
            "canonical_subtype_type_applied": canonical_type_applied,
            "typed_line_field_counts": typed_line_field_counts,
            "line_semantic_conflict_count": line_semantic_conflict_count,
            **header_normalization,
            **order_number_diagnostics,
        }
    )
    if conflict_type:
        normalization["subtype_conflict_repaired"] = True
    field_meta = record.setdefault("field_meta", {})
    if not isinstance(field_meta, dict):
        raise MinerUContractError("Instructor candidate field_meta must be an object")

    explicit_hint_paths: set[str] = set()
    if type_hint or (subtype_hint and CANONICAL_SUBTYPE_TYPES.get(subtype_hint)):
        explicit_hint_paths.add("$.document_type")
    if subtype_hint:
        explicit_hint_paths.add("$.document_subtype")
        if str(record.get("document_kind_label") or "") == subtype_hint:
            explicit_hint_paths.add("$.document_kind_label")

    for path in explicit_hint_paths:
        field_meta[path] = {
            "source_refs": [],
            "confidence": 1.0,
            "inferred": False,
            "model_mapped": False,
            "manual_locked": True,
            "review_required": False,
            "classification_evidence_source": "explicit_hint",
        }

    result_payload = payload.get("result")
    if isinstance(result_payload, dict):
        classification_refs = _native_classification_source_refs(record)
        classification_evidence_source = "native_classification"
        if not classification_refs:
            classification_refs = _classification_source_refs(result_payload)
            classification_evidence_source = "model"
        if not classification_refs:
            classification_refs = _generic_fact_classification_source_refs(record)
            classification_evidence_source = "local_projection"
        if classification_refs:
            completion_audit = result_payload.get("semantic_completeness_audit")
            classification_review_safe = bool(
                not conflict_type
                and result_payload.get("complete") is True
                and result_payload.get("semantic_complete") is True
                and result_payload.get("accounted_complete") is True
                and result_payload.get("retained_complete") is True
                and int(result_payload.get("unresolved_evidence_count") or 0) == 0
                and isinstance(completion_audit, dict)
                and completion_audit.get("review_required") is False
                and _projection_source_refs_are_locatable(classification_refs)
            )
            for path in (
                "$.document_type",
                "$.document_subtype",
                "$.document_kind_label",
            ):
                if path in explicit_hint_paths:
                    continue
                prior = field_meta.get(path)
                metadata = copy.deepcopy(prior) if isinstance(prior, dict) else {}
                metadata.update(
                    {
                        "source_refs": copy.deepcopy(classification_refs),
                        "inferred": (
                            classification_evidence_source
                            != "native_classification"
                        ),
                        "model_mapped": classification_evidence_source == "model",
                        "classification_evidence_source": (
                            classification_evidence_source
                        ),
                    }
                )
                if (
                    classification_evidence_source == "native_classification"
                    or classification_review_safe
                ):
                    metadata["review_required"] = False
                field_meta[path] = metadata
    try:
        return DocumentRecord.model_validate(record)
    except Exception as exc:
        raise MinerUContractError(
            "Instructor candidate is not a valid m1.document.v2 record"
        ) from exc


def _apply_physical_classification_guard(
    document: DocumentRecord,
    *,
    source: str | Path,
    source_kind: str,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
) -> DocumentRecord:
    """Reject physically impossible archive classifications without guessing facts."""

    if document.document_type != "archive" and document.document_subtype != "archive":
        return document
    if str(document_type_hint or "").casefold() == "archive" or str(
        document_subtype_hint or ""
    ).casefold() == "archive":
        return document
    normalized_kind = str(source_kind or "").strip().casefold()
    suffix = Path(source).suffix.casefold()
    if normalized_kind in {"archive", "zip"} or suffix == ".zip":
        return document

    payload = document.model_dump(mode="json")
    if normalized_kind == "image" or suffix in {
        ".bmp",
        ".gif",
        ".jpeg",
        ".jpg",
        ".png",
        ".tif",
        ".tiff",
        ".webp",
    }:
        payload["document_type"] = "technical_document"
        payload["document_subtype"] = "image_document"
    else:
        payload["document_type"] = "unknown"
        payload["document_subtype"] = "unknown"
    payload["needs_review"] = True
    payload.setdefault("validation_issues", []).append(
        {
            "code": "MINERU_CLASSIFICATION_PHYSICAL_TYPE_CONFLICT",
            "severity": "warning",
            "message": (
                "model archive classification conflicts with the physical input container"
            ),
            "paths": ["$.document_type", "$.document_subtype"],
            "source_refs": [],
            "expected": {"archive_container": True},
            "actual": {"source_kind": normalized_kind or suffix.lstrip(".")},
        }
    )
    return DocumentRecord.model_validate(payload)


def _classification_source_refs(result_payload: dict[str, Any]) -> list[dict[str, Any]]:
    if result_payload.get("document_subtype") == "product_photo":
        return []
    open_domain = result_payload.get("document_subtype") in (
        OPEN_DOMAIN_DOCUMENT_SUBTYPES
    )
    references: list[dict[str, Any]] = []

    def add_fact(fact: Any) -> None:
        if not isinstance(fact, dict):
            return
        values = fact.get("evidence_refs")
        if not isinstance(values, list):
            return
        for value in values:
            source_ref = value.get("source_ref") if isinstance(value, dict) else None
            add_source_ref(
                source_ref,
                evidence_id=str(value.get("evidence_id") or ""),
                evidence_quote=str(value.get("quote") or ""),
            )

    def add_source_ref(
        source_ref: Any,
        *,
        evidence_id: str = "",
        evidence_quote: str = "",
    ) -> None:
        if not isinstance(source_ref, dict):
            return
        if source_ref.get("authority") == "advisory" or source_ref.get("asset_sha256"):
            return
        source_ref = copy.deepcopy(source_ref)
        if evidence_id:
            source_ref["evidence_id"] = evidence_id
        if evidence_quote:
            source_ref["evidence_quote"] = evidence_quote
        canonical = json.dumps(
            source_ref,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        if canonical not in seen:
            seen.add(canonical)
            references.append(copy.deepcopy(source_ref))

    seen: set[str] = set()
    if not open_domain:
        for fact in result_payload.get("document_facts") or []:
            add_fact(fact)
    for fact in result_payload.get("generic_facts") or []:
        add_fact(fact)
    if not open_domain:
        for segment in result_payload.get("segments") or []:
            if not isinstance(segment, dict):
                continue
            for fact in segment.get("facts") or []:
                add_fact(fact)
            for record in segment.get("records") or []:
                if not isinstance(record, dict):
                    continue
                for fact in record.get("fields") or []:
                    add_fact(fact)
    for unit in result_payload.get("content_units") or []:
        if isinstance(unit, dict) and unit.get("binding_source") == "model":
            add_source_ref(
                unit.get("source_ref"),
                evidence_id=str(unit.get("evidence_id") or ""),
                evidence_quote=str(unit.get("exact_text") or ""),
            )
    return references[:12]


def _native_classification_source_refs(
    record: dict[str, Any],
) -> list[dict[str, Any]]:
    """Replay adapter-owned classification evidence into bounded source refs."""

    extraction = record.get("extraction")
    raw_content = (
        extraction.get("raw_content") if isinstance(extraction, dict) else None
    )
    native = (
        raw_content.get("native_classification")
        if isinstance(raw_content, dict)
        else None
    )
    native_type = (
        str(native.get("document_type") or "").strip()
        if isinstance(native, dict)
        else ""
    )
    native_subtype = (
        str(native.get("document_subtype") or "").strip()
        if isinstance(native, dict)
        else ""
    )
    native_source = str(native.get("source") or "") if isinstance(native, dict) else ""
    if (
        not isinstance(native, dict)
        or native.get("schema_version") != "m1.native-classification.v1"
        or native_source
        not in {"spreadsheet-tabular-v1", "docx-native-classifier-v1"}
        or native.get("authority") != "native_content"
        or not native_type
        or not native_subtype
        or native_type != str(record.get("document_type") or "").strip()
        or native_subtype != str(record.get("document_subtype") or "").strip()
    ):
        return []
    pages = raw_content.get("pages")
    if not isinstance(pages, list):
        return []

    signals = native.get("evidence")
    if not isinstance(signals, list):
        return []

    references: list[dict[str, Any]] = []
    seen: set[str] = set()
    for native_signal in signals:
        if not isinstance(native_signal, dict):
            continue
        signal_subtype = str(
            native_signal.get("document_subtype") or native_subtype
        ).strip()
        source_ref = native_signal.get("source_ref")
        if signal_subtype != native_subtype or not isinstance(source_ref, dict):
            continue
        if source_ref.get("authority") == "advisory" or source_ref.get(
            "asset_sha256"
        ):
            continue
        evidence_quote = str(
            native_signal.get("quote")
            or native_signal.get("matched_marker")
            or ""
        ).strip()
        if not evidence_quote or not _serialized_source_ref_replays_quote(
            pages,
            source_ref,
            evidence_quote,
        ):
            continue
        reference = copy.deepcopy(source_ref)
        evidence_id = str(native_signal.get("evidence_id") or "").strip()
        if evidence_id:
            reference["evidence_id"] = evidence_id
        reference["evidence_quote"] = evidence_quote
        canonical = json.dumps(
            reference,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )
        if canonical in seen:
            continue
        seen.add(canonical)
        references.append(reference)
        if len(references) == 12:
            break
    return references


def _serialized_source_ref_replays_quote(
    pages: list[Any],
    source_ref: dict[str, Any],
    quote: str,
) -> bool:
    """Verify a native locator and quote against serialized DocumentEvidence."""

    target_page = source_ref.get("page")
    target_sheet = str(source_ref.get("sheet") or "").strip()
    target_cell = str(source_ref.get("cell") or "").strip()
    target_part = str(source_ref.get("part") or "").strip()
    if target_part == "source.original_filename":
        return False
    if not ((target_sheet and target_cell) or target_part):
        return False
    normalized_quote = _classification_replay_text(quote)
    if not normalized_quote:
        return False

    def matches_locator(item: dict[str, Any], parts: set[str]) -> bool:
        if target_part and target_part not in parts:
            return False
        if not (target_sheet and target_cell):
            return True
        item_sheet = str(item.get("sheet") or "").strip()
        item_cell = str(item.get("inherited_from") or item.get("cell") or "").strip()
        if (item_sheet, item_cell) == (target_sheet, target_cell):
            return True
        return any(
            isinstance(reference, dict)
            and str(reference.get("sheet") or "").strip() == target_sheet
            and str(reference.get("cell") or "").strip() == target_cell
            for reference in item.get("native_source_refs") or []
        )

    for page_index, page in enumerate(pages):
        if not isinstance(page, dict):
            continue
        page_number = page.get("page_number", page_index + 1)
        if target_page not in (None, page_number):
            continue
        for block in page.get("blocks") or []:
            if not isinstance(block, dict):
                continue
            block_id = str(block.get("block_id") or "").strip()
            parts = {
                str(block.get("source_id") or "").strip(),
                str(block.get("source_ref_part") or "").strip(),
                block_id,
                f"mineru/{block_id}" if block_id else "",
            }
            if matches_locator(block, parts) and normalized_quote in (
                _classification_replay_text(block.get("text"))
            ):
                return True
        for table in page.get("tables") or []:
            if not isinstance(table, dict):
                continue
            table_id = str(table.get("table_id") or "").strip()
            for cell in table.get("cells") or []:
                if not isinstance(cell, dict):
                    continue
                try:
                    row = int(cell.get("row"))
                    column = int(cell.get("column"))
                except (TypeError, ValueError):
                    continue
                sheet = str(cell.get("sheet") or table.get("sheet") or "").strip()
                coordinate = str(
                    cell.get("inherited_from") or cell.get("cell") or ""
                ).strip()
                parts = {
                    str(cell.get("source_id") or "").strip(),
                    str(cell.get("source_ref_part") or "").strip(),
                    f"mineru/{table_id}/r{row}/c{column}",
                    f"spreadsheet/{sheet}/{coordinate}"
                    if sheet and coordinate
                    else "",
                }
                if matches_locator(cell, parts) and normalized_quote in (
                    _classification_replay_text(cell.get("text"))
                ):
                    return True
    return False


def _classification_replay_text(value: Any) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).split()).casefold()


def _generic_fact_classification_source_refs(
    record: dict[str, Any],
) -> list[dict[str, Any]]:
    """Return non-advisory local evidence for open-domain classification fields."""

    references: list[dict[str, Any]] = []
    seen: set[str] = set()
    for fact in record.get("generic_facts") or []:
        if not isinstance(fact, dict) or fact.get("authority") == "advisory":
            continue
        for source_ref in fact.get("source_refs") or []:
            if not isinstance(source_ref, dict):
                continue
            if source_ref.get("authority") == "advisory" or source_ref.get(
                "asset_sha256"
            ):
                continue
            canonical = json.dumps(
                source_ref,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
            if canonical in seen:
                continue
            seen.add(canonical)
            references.append(copy.deepcopy(source_ref))
            if len(references) == 12:
                return references
    return references


def _instructor_segment_id(
    table_id: str,
    orientation: str,
    data_start: int,
    data_end: int,
) -> str:
    value = f"{table_id}\x1f{orientation}\x1f{data_start}\x1f{data_end}"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:20]
    return f"mineru-instructor-{digest}"


def _record_region_summary(
    document: DocumentRecord,
    result_payload: dict[str, Any],
) -> dict[str, Any]:
    raw_content = document.extraction.get("raw_content")
    raw_pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    assessment = assess_record_regions_from_raw_pages(raw_pages)
    if assessment is None:
        raise MinerUContractError(
            "Instructor candidate cannot replay its record-region evidence"
        )
    segments = result_payload.get("segments")
    if not isinstance(segments, list):
        segments = []
    generic_record_table_ids: set[str] = set()
    generic_record_counts: dict[str, int] = {}
    generic_bound_axes: dict[tuple[str, str], set[int]] = {}
    for fact in document.generic_facts:
        if fact.name != "table_record":
            continue
        extras = fact.model_extra or {}
        table_id = str(extras.get("table_id") or "")
        if not table_id:
            continue
        generic_record_table_ids.add(table_id)
        generic_record_counts[table_id] = generic_record_counts.get(table_id, 0) + 1
        binding = extras.get("record_binding")
        if isinstance(binding, dict):
            orientation = str(binding.get("orientation") or "")
            raw_axis = binding.get("axis_index")
            if (
                orientation in {"rows", "columns"}
                and isinstance(raw_axis, int)
                and not isinstance(raw_axis, bool)
                and raw_axis >= 0
            ):
                generic_bound_axes.setdefault((table_id, orientation), set()).add(
                    raw_axis
                )
                continue
        raw_row = extras.get("row_index")
        if isinstance(raw_row, int) and not isinstance(raw_row, bool) and raw_row >= 0:
            generic_bound_axes.setdefault((table_id, "rows"), set()).add(raw_row)
            continue
        raw_column = extras.get("column_index")
        if (
            isinstance(raw_column, int)
            and not isinstance(raw_column, bool)
            and raw_column >= 0
        ):
            generic_bound_axes.setdefault((table_id, "columns"), set()).add(raw_column)
    generic_projection_authoritative = bool(generic_bound_axes)
    mapped_segment_record_counts: dict[str, int] = {}
    mapped_ranges: dict[tuple[str, str], list[tuple[int, int]]] = {}
    for segment in segments:
        if (
            not isinstance(segment, dict)
            or not isinstance(segment.get("records"), list)
            or not segment["records"]
        ):
            continue
        segment_id = str(segment.get("segment_id") or "")
        if segment_id:
            mapped_segment_record_counts[segment_id] = len(segment["records"])
        table_id = str(segment.get("table_id") or "")
        orientation = str(segment.get("orientation") or "")
        try:
            start = int(segment.get("start"))
            end = int(segment.get("end"))
        except (TypeError, ValueError):
            continue
        expected_records = end - start + 1
        if (
            table_id
            and orientation in {"rows", "columns"}
            and 0 <= start <= end
            and len(segment["records"]) == expected_records
        ):
            mapped_ranges.setdefault((table_id, orientation), []).append((start, end))

    def region_is_fully_mapped(region: Any) -> bool:
        # Auxiliary and open-domain records carry locally generated evidence-axis
        # bindings.  Replay requires every axis in the assessed region, so one
        # partial generic record cannot accidentally authorize the whole table.
        bound_axes = generic_bound_axes.get(
            (region.table_id, region.orientation), set()
        )
        if all(
            axis in bound_axes for axis in range(region.data_start, region.data_end + 1)
        ):
            return True
        # Old open-domain candidates predate record_binding but still carry one
        # row_index per record. Preserve only the bounded count fallback for
        # serialized historical payloads; technical auxiliary projection never
        # relies on it.
        if (
            document.document_subtype in OPEN_DOMAIN_DOCUMENT_SUBTYPES
            and not bound_axes
            and generic_record_counts.get(region.table_id, 0)
            == region.data_end - region.data_start + 1
        ):
            return True
        legacy_segment_id = _instructor_segment_id(
            region.table_id,
            region.orientation,
            region.data_start,
            region.data_end,
        )
        if mapped_segment_record_counts.get(legacy_segment_id) == (
            region.data_end - region.data_start + 1
        ):
            return True
        intervals = sorted(mapped_ranges.get((region.table_id, region.orientation), []))
        cursor = region.data_start
        for start, end in intervals:
            if end < cursor or start > region.data_end:
                continue
            if start > cursor:
                return False
            cursor = max(cursor, end + 1)
            if cursor > region.data_end:
                return True
        return cursor > region.data_end

    bindings = [
        {
            "region_id": region.region_id,
            "table_id": region.table_id,
            "orientation": region.orientation,
            "data_start": region.data_start,
            "data_end": region.data_end,
        }
        for region in assessment.record_regions
        if region_is_fully_mapped(region)
    ]
    report = record_region_binding_report(assessment, bindings)
    summary = assessment.model_dump(mode="json")
    summary["summary"] = assessment.summary()
    summary.update(report.summary())
    summary["generic_record_table_ids"] = sorted(generic_record_table_ids)
    summary["generic_record_bindings"] = [
        {
            "table_id": table_id,
            "orientation": orientation,
            "axis_indices": sorted(axis_indices),
        }
        for (table_id, orientation), axis_indices in sorted(generic_bound_axes.items())
    ]
    summary["generic_projection_authoritative"] = generic_projection_authoritative
    return summary


def _issue_count(result_payload: dict[str, Any], prefixes: tuple[str, ...]) -> int:
    issues = result_payload.get("issues")
    if not isinstance(issues, list):
        return 0
    return sum(
        any(str(issue).startswith(prefix) for prefix in prefixes) for issue in issues
    )


class MinerUInstructorService:
    """Side-effect-free production service for the complete candidate chain."""

    def __init__(
        self,
        *,
        mineru: _MinerUParser,
        extractor: _InstructorExtractor,
        normalizer: MinerUInputNormalizer | None = None,
        visual_assets_enabled: bool = True,
        visual_assets_max: int = 8,
        visual_asset_max_bytes: int = 10 * 1024 * 1024,
        visual_asset_timeout_seconds: float = 180.0,
        drawing_region_vlm_enabled: bool = True,
        drawing_region_vlm_extractor: _DrawingRegionVLMExtractor | None = None,
        drawing_region_vlm_max_regions: int = 16,
        drawing_region_vlm_timeout_seconds: float = 30.0,
        total_timeout_seconds: float = 600.0,
        field_semantic_router: FieldSemanticBatchRuntime | None = None,
        field_semantic_registry: CanonicalFieldRegistry | None = None,
        tabular_layout_router: Any | None = None,
    ) -> None:
        if visual_assets_max < 0 or visual_asset_max_bytes < 0:
            raise ValueError("visual asset limits must be non-negative")
        if visual_asset_timeout_seconds <= 0 or total_timeout_seconds <= 0:
            raise ValueError("service timeouts must be positive")
        if drawing_region_vlm_enabled and not visual_assets_enabled:
            raise ValueError("drawing-region VLM requires visual asset enrichment")
        if drawing_region_vlm_enabled and drawing_region_vlm_extractor is None:
            raise ValueError(
                "drawing-region VLM extractor is required when the stage is enabled"
            )
        self.mineru = mineru
        self.extractor = extractor
        self.normalizer = normalizer or MinerUInputNormalizer()
        self.visual_assets_enabled = bool(visual_assets_enabled)
        self.visual_assets_max = int(visual_assets_max)
        self.visual_asset_max_bytes = int(visual_asset_max_bytes)
        self.visual_asset_timeout_seconds = float(visual_asset_timeout_seconds)
        self.drawing_region_vlm_enabled = bool(drawing_region_vlm_enabled)
        self.drawing_region_vlm_extractor = drawing_region_vlm_extractor
        self.drawing_region_vlm_max_regions = int(drawing_region_vlm_max_regions)
        self.drawing_region_vlm_timeout_seconds = float(
            drawing_region_vlm_timeout_seconds
        )
        self.total_timeout_seconds = float(total_timeout_seconds)
        self.field_semantic_router = field_semantic_router
        self.field_semantic_registry = field_semantic_registry or getattr(
            field_semantic_router, "registry", None
        )
        self.tabular_layout_router = tabular_layout_router
        if field_semantic_router is not None and self.field_semantic_registry is None:
            raise ValueError("field semantic routing requires a canonical registry")
        self._ready = False
        self._mapper_model = ""

    async def probe(self) -> dict[str, Any]:
        extractor_probe = getattr(self.extractor, "probe", None)
        extractor_health: dict[str, Any] = {"ready": True, "configured": True}
        if callable(extractor_probe):
            value = extractor_probe()
            if inspect.isawaitable(value):
                value = await value
            if isinstance(value, dict):
                extractor_health = value
        drawing_health: dict[str, Any] = {
            "ready": not self.drawing_region_vlm_enabled,
            "enabled": self.drawing_region_vlm_enabled,
        }
        if self.drawing_region_vlm_enabled:
            drawing = self.drawing_region_vlm_extractor
            if drawing is None:
                raise RuntimeError("drawing-region VLM is not configured")
            drawing_probe = getattr(drawing, "probe", None)
            drawing_health = {"ready": True, "enabled": True, "configured": True}
            if callable(drawing_probe):
                value = drawing_probe()
                if inspect.isawaitable(value):
                    value = await value
                if isinstance(value, dict):
                    drawing_health = value
        if (
            extractor_health.get("ready") is False
            or drawing_health.get("ready") is False
        ):
            raise RuntimeError("MinerU Instructor service probe failed")
        self._mapper_model = str(extractor_health.get("model") or "").strip()
        self._ready = True
        return {
            "ready": True,
            "pipeline": "mineru_instructor",
            "instructor": extractor_health,
            "visual_assets": {
                "enabled": self.visual_assets_enabled,
                "max_assets": self.visual_assets_max,
                "max_asset_bytes": self.visual_asset_max_bytes,
                "timeout_seconds": self.visual_asset_timeout_seconds,
            },
            "drawing_region_vlm": drawing_health,
            "tabular_layout_routing": self._tabular_layout_status(),
        }

    def _tabular_layout_status(self) -> dict[str, Any]:
        router = self.tabular_layout_router
        if router is None:
            return {"enabled": False, "ready": True}
        snapshot = getattr(router, "status_snapshot", None)
        if callable(snapshot):
            value = snapshot()
            if isinstance(value, dict):
                return {"enabled": True, **copy.deepcopy(value)}
        return {"enabled": True, "ready": True}

    def status(self) -> dict[str, Any]:
        payload = {
            "ready": self._ready,
            "model": self._mapper_model,
            "pipeline": "mineru_instructor",
            "visual_assets_enabled": self.visual_assets_enabled,
            "drawing_region_vlm_enabled": self.drawing_region_vlm_enabled,
            "tabular_layout_routing": self._tabular_layout_status(),
        }
        return payload

    async def close(self) -> None:
        closed: set[int] = set()
        for owner in (self.extractor, self.drawing_region_vlm_extractor):
            if owner is None or id(owner) in closed:
                continue
            closed.add(id(owner))
            close = getattr(owner, "close", None) or getattr(owner, "aclose", None)
            if not callable(close):
                continue
            value = close()
            if inspect.isawaitable(value):
                await value
        self._ready = False

    async def run(
        self,
        source: str | Path,
        *,
        original_filename: str | None = None,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        tenant_id: str = "",
        task_id: str = "",
        source_kind: str = "",
        routing_attempt: int = 0,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUInstructorServiceResult:
        return await asyncio.wait_for(
            self._run_pipeline(
                source,
                original_filename=original_filename,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
                tenant_id=tenant_id,
                task_id=task_id,
                source_kind=source_kind,
                routing_attempt=routing_attempt,
                route_plan=route_plan,
                semantic_execution=semantic_execution,
            ),
            timeout=self.total_timeout_seconds,
        )

    async def _run_pipeline(
        self,
        source: str | Path,
        *,
        original_filename: str | None = None,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        tenant_id: str = "",
        task_id: str = "",
        source_kind: str = "",
        routing_attempt: int = 0,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUInstructorServiceResult:
        return await self._run_pipeline_inner(
            source,
            original_filename=original_filename,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            tenant_id=tenant_id,
            task_id=task_id,
            source_kind=source_kind,
            routing_attempt=routing_attempt,
            route_plan=route_plan,
            semantic_execution=semantic_execution,
        )

    async def _run_pipeline_inner(
        self,
        source: str | Path,
        *,
        original_filename: str | None = None,
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        tenant_id: str = "",
        task_id: str = "",
        source_kind: str = "",
        routing_attempt: int = 0,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUInstructorServiceResult:
        try:
            payload = await run_candidate(
                Path(source),
                mineru=self.mineru,
                extractor=self.extractor,
                original_filename=original_filename,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
                normalizer=self.normalizer,
                visual_assets_enabled=self.visual_assets_enabled,
                visual_assets_max=self.visual_assets_max,
                visual_asset_max_bytes=self.visual_asset_max_bytes,
                visual_asset_timeout_seconds=self.visual_asset_timeout_seconds,
                drawing_region_vlm_enabled=self.drawing_region_vlm_enabled,
                drawing_region_vlm_extractor=self.drawing_region_vlm_extractor,
                drawing_region_vlm_max_regions=self.drawing_region_vlm_max_regions,
                drawing_region_vlm_timeout_seconds=(
                    self.drawing_region_vlm_timeout_seconds
                ),
                tenant_id=tenant_id,
                task_id=task_id,
                source_kind=source_kind,
                routing_attempt=routing_attempt,
                route_plan=route_plan,
                semantic_execution=semantic_execution,
            )
        except Exception as exc:  # noqa: BLE001 - preserve original typed failure
            client_status = self.mineru.status()
            client_stage = str(client_status.get("last_failure_stage") or "")
            raise _annotate_pipeline_failure(
                exc,
                stage=(f"mineru_{client_stage}" if client_stage else "candidate_extraction"),
                reason=(
                    "mineru_read_or_contract_failure"
                    if client_stage
                    else "candidate_pipeline_failure"
                ),
            )
        if payload.get("schema_version") != "m1.mineru-instructor-candidate.v1":
            raise _annotate_pipeline_failure(
                MinerUContractError("unsupported Instructor candidate schema"),
                stage="candidate_schema",
                reason="unsupported_candidate_schema",
            )
        try:
            document = _production_document(
                payload,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
            )
        except Exception as exc:  # noqa: BLE001 - annotate projection boundary
            raise _annotate_pipeline_failure(
                exc,
                stage="document_projection",
                reason="invalid_document_record_projection",
            )
        document = _apply_physical_classification_guard(
            document,
            source=source,
            source_kind=source_kind,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
        )
        if (
            self.tabular_layout_router is not None
            and document.document_subtype not in OPEN_DOMAIN_DOCUMENT_SUBTYPES
        ):
            from .mineru_tabular_layout import apply_governed_tabular_layout

            try:
                document = await apply_governed_tabular_layout(
                    document,
                    source=source,
                    original_filename=original_filename,
                    source_kind=(
                        source_kind or Path(source).suffix.lstrip(".").casefold()
                    ),
                    tenant_id=tenant_id,
                    task_id=task_id,
                    document_type_hint=document_type_hint,
                    document_subtype_hint=document_subtype_hint,
                    model=(
                        self._mapper_model
                        or str(getattr(self.extractor, "model", "") or "")
                    ),
                    router=self.tabular_layout_router,
                )
            except Exception as exc:  # noqa: BLE001 - annotate routing boundary
                raise _annotate_pipeline_failure(
                    exc,
                    stage="tabular_layout_routing",
                    reason="tabular_layout_application_failure",
                )
        if (
            self.field_semantic_router is not None
            and self.field_semantic_registry is not None
            and document.document_subtype not in OPEN_DOMAIN_DOCUMENT_SUBTYPES
        ):
            try:
                document = await route_document_custom_fields(
                    document=document,
                    tenant_id=str(tenant_id or "default").strip() or "default",
                    runtime=self.field_semantic_router,
                    registry=self.field_semantic_registry,
                )
            except Exception as exc:  # noqa: BLE001 - annotate routing boundary
                raise _annotate_pipeline_failure(
                    exc,
                    stage="field_semantic_routing",
                    reason="field_semantic_application_failure",
                )
        if document.document_type == "technical_document":
            from ..technical_projection import project_technical_document

            document = project_technical_document(
                document,
                filename=original_filename or Path(source).name,
            )
        adaptive_routing = payload.get("adaptive_routing")
        if isinstance(adaptive_routing, dict):
            metadata = document.extraction.setdefault("metadata", {})
            metadata["adaptive_routing"] = copy.deepcopy(adaptive_routing)
            # The candidate summary carries the same bounded plan consumed by
            # the native pipeline. Persist it at the canonical metadata path
            # so replay/version gates can verify contract and parser revisions
            # without reopening the model payload.
            route_plan_payload = adaptive_routing.get("route_plan")
            if isinstance(route_plan_payload, dict):
                metadata["route_plan"] = copy.deepcopy(route_plan_payload)
        result_payload = payload.get("result")
        if not isinstance(result_payload, dict):
            raise _annotate_pipeline_failure(
                MinerUContractError("Instructor result must be an object"),
                stage="candidate_schema",
                reason="missing_instructor_result",
            )
        try:
            region_summary = _record_region_summary(document, result_payload)
        except Exception as exc:  # noqa: BLE001 - annotate replay boundary
            raise _annotate_pipeline_failure(
                exc,
                stage="record_region_replay",
                reason="record_region_contract_failure",
            )
        unresolved = int(result_payload.get("unresolved_evidence_count") or 0)
        locally_rejected_citations = _issue_count(
            result_payload,
            _LOCAL_REJECTED_CITATION_PREFIXES,
        )
        locally_rejected_facts = _issue_count(
            result_payload,
            _LOCAL_REJECTED_FACT_PREFIXES,
        )
        timing = payload.get("timing")
        if not isinstance(timing, dict):
            timing = {}
        metadata = document.extraction.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        production_normalization = metadata.get("production_normalization")
        if not isinstance(production_normalization, dict):
            production_normalization = {}
        evidence_summary = payload.get("evidence_summary")
        if not isinstance(evidence_summary, dict):
            evidence_summary = {}
        unmapped_regions = region_summary.get("unmapped_region_ids")
        dropped_tables = (
            len(unmapped_regions) if isinstance(unmapped_regions, list) else 0
        )
        summary = {
            "status": "completed",
            "candidate_isolation": False,
            "pipeline": "mineru_instructor",
            "mineru_task_id": metadata.get("mineru_task_id"),
            "backend": evidence_summary.get("backend"),
            "backend_version": evidence_summary.get("backend_version"),
            "mineru_elapsed_ms": float(timing.get("mineru_ms") or 0.0),
            "mapper_elapsed_ms": float(timing.get("instructor_ms") or 0.0),
            "total_elapsed_ms": float(timing.get("total_ms") or 0.0),
            "mapper_requests": int(result_payload.get("intent_calls") or 0)
            + int(result_payload.get("segment_calls") or 0),
            "mapper_repaired_mappings": 0,
            "mapper_unresolved_dropped_mappings": unresolved,
            "mapper_unresolved_dropped_tables": dropped_tables,
            "mapper_dropped_mappings": unresolved,
            "mapper_dropped_tables": dropped_tables,
            "mapper_dropped_facts": unresolved,
            "mapper_empty_facts": 0,
            # Invalid proposals were already removed field-by-field by the
            # extractor. Keep them separate from final-candidate integrity so
            # the authority gate can preserve all surviving evidence.
            "mapper_rejected_fact_proposals": locally_rejected_facts
            + int(bool(production_normalization.get("order_number_conflict"))),
            "mapper_rejected_citations": locally_rejected_citations,
            "mapper_invalid_facts": 0,
            "rejected_citations": 0,
            "record_region_assessment": region_summary,
            "instructor_complete": bool(result_payload.get("complete")),
            "instructor_semantic_complete": bool(
                result_payload.get("semantic_complete")
            ),
            "instructor_raw_semantic_complete": bool(
                result_payload.get("instructor_raw_semantic_complete")
            ),
            "instructor_accounted_complete": bool(
                result_payload.get("accounted_complete")
            ),
            "instructor_retained_complete": bool(
                result_payload.get("retained_complete")
            ),
            "visual_asset_enrichment": copy.deepcopy(
                payload.get("visual_asset_enrichment")
            ),
            "drawing_region_vlm": copy.deepcopy(payload.get("drawing_region_vlm")),
            "production_normalization": copy.deepcopy(production_normalization),
        }
        return MinerUInstructorServiceResult(
            document=document,
            summary=summary,
            payload=payload,
        )


def _extra_body(value: str) -> dict[str, Any]:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise argparse.ArgumentTypeError("--llm-extra-body must be valid JSON") from exc
    if not isinstance(payload, dict):
        raise argparse.ArgumentTypeError("--llm-extra-body must be a JSON object")
    return payload


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read-only MinerU plus Instructor benchmark candidate.",
    )
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--original-filename")
    parser.add_argument(
        "--mineru-transport",
        choices=("tasks-api", "vlm-http-client"),
        default="tasks-api",
        help=(
            "Use the existing MinerU tasks API or invoke this Python "
            "environment's MinerU CLI against a remote VLM server."
        ),
    )
    parser.add_argument("--mineru-base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--mineru-timeout-seconds", type=float, default=240.0)
    parser.add_argument("--mineru-poll-interval-seconds", type=float, default=1.0)
    parser.add_argument("--mineru-backend-version", default="3.4.4")
    parser.add_argument("--mineru-model-revision", default="")
    parser.add_argument(
        "--visual-assets-enabled",
        action="store_true",
        help=(
            "Parse bounded embedded image assets with the live MinerU transport "
            "before semantic extraction. Disabled by default."
        ),
    )
    parser.add_argument("--visual-assets-max", type=int, default=8)
    parser.add_argument(
        "--visual-asset-max-bytes",
        type=int,
        default=10 * 1024 * 1024,
    )
    parser.add_argument(
        "--visual-asset-timeout-seconds",
        type=float,
        default=180.0,
    )
    parser.add_argument(
        "--drawing-region-vlm-enabled",
        action="store_true",
        help=(
            "Screen verified DOCX embedded images with offline PaddleOCR and "
            "transcribe only bounded drawing callout regions. Requires "
            "--visual-assets-enabled and is disabled by default."
        ),
    )
    parser.add_argument(
        "--drawing-region-vlm-base-url",
        help=(
            "OpenAI-compatible vision base URL. When omitted, reuse "
            "--mineru-base-url only with --mineru-transport=vlm-http-client."
        ),
    )
    parser.add_argument(
        "--drawing-region-vlm-model",
        help="Vision model name; defaults to --mineru-model-revision when set.",
    )
    parser.add_argument(
        "--drawing-region-vlm-paddle-model-root",
        type=Path,
        help="Offline Paddle model root; runtime downloads are never attempted.",
    )
    parser.add_argument(
        "--drawing-region-vlm-device",
        default="cpu",
        help="PaddleOCR device selector. Defaults to cpu.",
    )
    parser.add_argument(
        "--drawing-region-vlm-max-regions",
        type=int,
        default=16,
        help="Maximum total VLM callout regions across one document.",
    )
    parser.add_argument(
        "--drawing-region-vlm-timeout-seconds",
        type=float,
        default=30.0,
        help="Per-region VLM request timeout.",
    )
    parser.add_argument(
        "--drawing-region-vlm-asset-timeout-seconds",
        type=float,
        default=180.0,
        help="Total drawing-region budget for one embedded asset.",
    )
    parser.add_argument(
        "--mineru-content-list-v2",
        type=Path,
        help="Replay a previously generated MinerU content_list_v2 JSON.",
    )
    parser.add_argument(
        "--mineru-middle-json",
        type=Path,
        help="Pinned middle JSON paired with --mineru-content-list-v2.",
    )
    parser.add_argument(
        "--llm-transport",
        choices=("instructor-openai", "ollama-native"),
        default="instructor-openai",
    )
    parser.add_argument(
        "--llm-base-url",
        help=(
            "Defaults to Ollama /v1 for instructor-openai and the Ollama root "
            "for ollama-native."
        ),
    )
    parser.add_argument("--llm-model", default="qwen3:8b")
    parser.add_argument("--llm-api-key", default="EMPTY")
    parser.add_argument("--llm-timeout-seconds", type=float, default=60.0)
    parser.add_argument("--llm-max-tokens", type=int, default=4096)
    parser.add_argument("--llm-max-input-chars", type=int, default=80_000)
    parser.add_argument("--llm-segment-max-input-chars", type=int)
    parser.add_argument("--llm-max-retries", type=int, choices=range(3), default=2)
    parser.add_argument("--llm-num-ctx", type=int, default=16_384)
    parser.add_argument("--llm-extra-body", type=_extra_body, default={})
    return parser


def _build_extractor(args: argparse.Namespace) -> MinerUInstructorExtractor:
    if args.llm_transport == "ollama-native":
        return MinerUInstructorExtractor.from_ollama_native(
            base_url=args.llm_base_url or "http://127.0.0.1:11434",
            model=args.llm_model,
            timeout=args.llm_timeout_seconds,
            max_tokens=args.llm_max_tokens,
            num_ctx=args.llm_num_ctx,
            max_input_chars=args.llm_max_input_chars,
            max_segment_input_chars=args.llm_segment_max_input_chars,
            max_retries=args.llm_max_retries,
            compact_intent=True,
        )
    return MinerUInstructorExtractor.from_openai(
        base_url=args.llm_base_url or "http://127.0.0.1:11434/v1",
        api_key=args.llm_api_key,
        model=args.llm_model,
        timeout=args.llm_timeout_seconds,
        max_tokens=args.llm_max_tokens,
        max_input_chars=args.llm_max_input_chars,
        max_segment_input_chars=args.llm_segment_max_input_chars,
        max_retries=args.llm_max_retries,
        extra_body=args.llm_extra_body,
        compact_intent=True,
    )


def _drawing_region_vlm_connection(args: argparse.Namespace) -> tuple[str, str]:
    base_url = args.drawing_region_vlm_base_url
    if not base_url and args.mineru_transport == "vlm-http-client":
        base_url = args.mineru_base_url
    model = args.drawing_region_vlm_model or args.mineru_model_revision
    return (base_url or "", model or "")


def _append_drawing_region_sidecar_issue(
    payload: dict[str, Any],
    *,
    code: str,
    message: str,
) -> None:
    issue = _sidecar_issue(code, message)
    sidecars = [
        payload.get("drawing_region_vlm"),
        payload.get("result", {}).get("drawing_region_vlm"),
        payload.get("record", {})
        .get("extraction", {})
        .get("raw_content", {})
        .get("drawing_region_vlm"),
    ]
    for sidecar in sidecars:
        if not isinstance(sidecar, dict):
            continue
        sidecar["status"] = (
            "partial" if sidecar.get("analyzed_asset_count") else "failed"
        )
        sidecar["needs_review"] = True
        issues = sidecar.setdefault("issues", [])
        if not any(item.get("code") == code for item in issues):
            issues.append(copy.deepcopy(issue))


async def _run_configured(args: argparse.Namespace) -> dict[str, Any]:
    if args.mineru_content_list_v2 is not None:
        mineru: _MinerUParser = _CachedMinerUParser(
            content_list_v2_path=args.mineru_content_list_v2,
            middle_json_path=args.mineru_middle_json,
            backend_version=args.mineru_backend_version,
            model_revision=args.mineru_model_revision,
        )
    elif args.mineru_transport == "vlm-http-client":
        mineru = _MinerUVLMHTTPClientParser(
            base_url=args.mineru_base_url,
            timeout_seconds=args.mineru_timeout_seconds,
            backend_version=args.mineru_backend_version,
            model_revision=args.mineru_model_revision,
        )
    else:
        mineru = MinerUClient(
            base_url=args.mineru_base_url,
            timeout_seconds=args.mineru_timeout_seconds,
            poll_interval_seconds=args.mineru_poll_interval_seconds,
            backend_version=args.mineru_backend_version,
            model_revision=args.mineru_model_revision,
        )
    extractor = _build_extractor(args)
    drawing_region_extractor = None
    drawing_region_setup_failure_type = None
    if args.drawing_region_vlm_enabled:
        try:
            from m1.documents.parsing.drawing_region_vlm import (
                DrawingRegionVLMConfig,
                DrawingRegionVLMExtractor,
            )

            base_url, model = _drawing_region_vlm_connection(args)
            drawing_region_extractor = DrawingRegionVLMExtractor.from_openai(
                base_url=base_url,
                model=model,
                paddle_model_root=args.drawing_region_vlm_paddle_model_root,
                device=args.drawing_region_vlm_device,
                config=DrawingRegionVLMConfig(
                    max_candidates=args.drawing_region_vlm_max_regions,
                    request_timeout_seconds=(args.drawing_region_vlm_timeout_seconds),
                ),
            )
        except Exception as exc:  # noqa: BLE001 - enhancement setup is optional
            drawing_region_setup_failure_type = exc.__class__.__name__
    payload: dict[str, Any] | None = None
    drawing_region_close_failure_type: str | None = None
    try:
        payload = await run_candidate(
            args.input,
            mineru=mineru,
            extractor=extractor,
            original_filename=args.original_filename,
            visual_assets_enabled=args.visual_assets_enabled,
            visual_assets_max=args.visual_assets_max,
            visual_asset_max_bytes=args.visual_asset_max_bytes,
            visual_asset_timeout_seconds=args.visual_asset_timeout_seconds,
            drawing_region_vlm_enabled=args.drawing_region_vlm_enabled,
            drawing_region_vlm_extractor=drawing_region_extractor,
            drawing_region_vlm_max_regions=args.drawing_region_vlm_max_regions,
            drawing_region_vlm_timeout_seconds=(
                args.drawing_region_vlm_asset_timeout_seconds
            ),
            drawing_region_vlm_setup_failure_type=(drawing_region_setup_failure_type),
        )
    finally:
        try:
            if drawing_region_extractor is not None:
                try:
                    await drawing_region_extractor.aclose()
                except Exception as exc:  # noqa: BLE001 - optional close is isolated
                    drawing_region_close_failure_type = exc.__class__.__name__
        finally:
            try:
                await extractor.close()
            finally:
                await mineru.close()
    if payload is None:
        raise RuntimeError("candidate did not produce a payload")
    if drawing_region_close_failure_type is not None:
        _append_drawing_region_sidecar_issue(
            payload,
            code="DRAWING_REGION_CLOSE_FAILED",
            message=(
                "drawing region client close failed after extraction: "
                f"{drawing_region_close_failure_type}"
            ),
        )
    return payload


def _write_output(path: Path, rendered: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(rendered, encoding="utf-8")
    temporary.replace(path)


def main() -> int:
    args = _parser().parse_args()
    if args.mineru_timeout_seconds <= 0 or args.llm_timeout_seconds <= 0:
        raise SystemExit("timeouts must be positive")
    if args.mineru_poll_interval_seconds <= 0:
        raise SystemExit("--mineru-poll-interval-seconds must be positive")
    if args.visual_assets_max < 0:
        raise SystemExit("--visual-assets-max must be non-negative")
    if args.visual_asset_max_bytes < 0:
        raise SystemExit("--visual-asset-max-bytes must be non-negative")
    if args.visual_asset_timeout_seconds <= 0:
        raise SystemExit("--visual-asset-timeout-seconds must be positive")
    if not 1 <= args.drawing_region_vlm_max_regions <= _DRAWING_REGION_VLM_MAX_REGIONS:
        raise SystemExit("--drawing-region-vlm-max-regions must be between 1 and 16")
    if not (
        0
        < args.drawing_region_vlm_timeout_seconds
        <= _DRAWING_REGION_VLM_MAX_TIMEOUT_SECONDS
    ):
        raise SystemExit("--drawing-region-vlm-timeout-seconds must be in (0, 180]")
    if not (
        args.drawing_region_vlm_timeout_seconds
        <= args.drawing_region_vlm_asset_timeout_seconds
        <= _DRAWING_REGION_VLM_MAX_TIMEOUT_SECONDS
    ):
        raise SystemExit(
            "--drawing-region-vlm-asset-timeout-seconds must be greater than "
            "or equal to the request timeout and no more than 180"
        )
    if args.drawing_region_vlm_enabled:
        if not args.visual_assets_enabled:
            raise SystemExit(
                "--drawing-region-vlm-enabled requires --visual-assets-enabled"
            )
        drawing_base_url, drawing_model = _drawing_region_vlm_connection(args)
        if not drawing_base_url:
            raise SystemExit(
                "--drawing-region-vlm-base-url is required unless the MinerU "
                "transport is vlm-http-client"
            )
        if not drawing_model:
            raise SystemExit(
                "--drawing-region-vlm-model or --mineru-model-revision is required"
            )
        if args.drawing_region_vlm_paddle_model_root is None:
            raise SystemExit(
                "--drawing-region-vlm-paddle-model-root is required when enabled"
            )
        if not args.drawing_region_vlm_device.strip():
            raise SystemExit("--drawing-region-vlm-device must not be empty")
    if args.llm_max_tokens <= 0 or args.llm_max_input_chars <= 0:
        raise SystemExit("LLM token and input limits must be positive")
    if (
        args.llm_segment_max_input_chars is not None
        and args.llm_segment_max_input_chars <= 0
    ):
        raise SystemExit("--llm-segment-max-input-chars must be positive")
    if args.llm_num_ctx <= 0:
        raise SystemExit("--llm-num-ctx must be positive")
    cached_paths = (args.mineru_content_list_v2, args.mineru_middle_json)
    if sum(path is not None for path in cached_paths) == 1:
        raise SystemExit(
            "--mineru-content-list-v2 and --mineru-middle-json must be used together"
        )
    if args.visual_assets_enabled and args.mineru_content_list_v2 is not None:
        raise SystemExit(
            "--visual-assets-enabled requires a live MinerU transport; cached "
            "document evidence cannot parse individual assets"
        )
    try:
        payload = asyncio.run(_run_configured(args))
    except Exception as exc:  # noqa: BLE001 - benchmark needs a bounded case outcome
        print(
            json.dumps(
                {"status": "error", "error_type": exc.__class__.__name__},
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    rendered = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    if args.output is None:
        print(rendered)
    else:
        _write_output(args.output, rendered)
        print(json.dumps({"status": "completed", "output": args.output.name}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
