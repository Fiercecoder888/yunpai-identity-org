"""Independent, full-evidence record-region gates for MinerU mappings.

The mapper may choose fields, but it must not decide which unseen portion of a
table is a business record.  This module inspects every recovered table axis,
creates deterministic record-region identifiers, and exposes a compact binding
report that both replay and authority validation can verify.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from statistics import median
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .evidence import DocumentEvidence, EvidencePage, EvidenceTable

RecordOrientation = Literal["rows", "columns"]
AssessmentStatus = Literal["complete", "inconclusive"]


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


def record_region_id(
    table_id: str,
    orientation: RecordOrientation,
    data_start: int,
    data_end: int,
) -> str:
    """Return a stable, non-model-invented identity for an evidence range."""

    payload = f"{table_id}\x1f{orientation}\x1f{data_start}\x1f{data_end}"
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]
    return f"mineru-region-{digest}"


class EvidenceRecordRegion(_StrictModel):
    region_id: str = Field(min_length=1, max_length=80)
    table_id: str = Field(min_length=1, max_length=160)
    orientation: RecordOrientation
    data_start: int = Field(ge=0, le=10000)
    data_end: int = Field(ge=0, le=10000)
    boundary_evidence_ids: list[str] = Field(min_length=2, max_length=2)

    @model_validator(mode="after")
    def validate_region_identity(self) -> EvidenceRecordRegion:
        if self.data_end < self.data_start:
            raise ValueError("record region end precedes start")
        expected = record_region_id(
            self.table_id,
            self.orientation,
            self.data_start,
            self.data_end,
        )
        if self.region_id != expected:
            raise ValueError("record region id is not derived from its evidence range")
        return self


class RecordRegionAssessment(_StrictModel):
    """A complete assessment describes every evidence table exactly once."""

    status: AssessmentStatus
    evidence_fingerprint: str = Field(default="", max_length=64)
    assessed_table_ids: list[str] = Field(default_factory=list, max_length=200)
    no_record_table_ids: list[str] = Field(default_factory=list, max_length=200)
    record_regions: list[EvidenceRecordRegion] = Field(default_factory=list, max_length=500)
    inconclusive_table_ids: list[str] = Field(default_factory=list, max_length=200)
    reasons: list[str] = Field(default_factory=list, max_length=200)

    @model_validator(mode="after")
    def validate_complete_partition(self) -> RecordRegionAssessment:
        assessed = set(self.assessed_table_ids)
        no_record = set(self.no_record_table_ids)
        inconclusive = set(self.inconclusive_table_ids)
        region_tables = {region.table_id for region in self.record_regions}
        if len(assessed) != len(self.assessed_table_ids):
            raise ValueError("duplicate assessed table")
        if len(no_record) != len(self.no_record_table_ids):
            raise ValueError("duplicate no-record table")
        if len(inconclusive) != len(self.inconclusive_table_ids):
            raise ValueError("duplicate inconclusive table")
        if not (no_record | inconclusive | region_tables) <= assessed:
            raise ValueError("record assessment references an unassessed table")
        if no_record & (inconclusive | region_tables):
            raise ValueError("table cannot be both no-record and mapped")
        if inconclusive & region_tables:
            raise ValueError("inconclusive table cannot expose record regions")
        if assessed != no_record | inconclusive | region_tables:
            raise ValueError("every assessed table needs an explicit classification")
        if self.status == "complete" and inconclusive:
            raise ValueError("complete assessment cannot have inconclusive tables")
        if self.status == "inconclusive" and not inconclusive:
            raise ValueError("inconclusive assessment needs an inconclusive table")
        if self.evidence_fingerprint and not re.fullmatch(
            r"[0-9a-f]{64}", self.evidence_fingerprint
        ):
            raise ValueError("record assessment has an invalid evidence fingerprint")
        seen_ids: set[str] = set()
        intervals: dict[tuple[str, str], list[tuple[int, int]]] = {}
        for region in self.record_regions:
            if region.region_id in seen_ids:
                raise ValueError("duplicate record region id")
            seen_ids.add(region.region_id)
            key = (region.table_id, region.orientation)
            for start, end in intervals.setdefault(key, []):
                if region.data_start <= end and start <= region.data_end:
                    raise ValueError("record regions overlap")
            intervals[key].append((region.data_start, region.data_end))
        return self

    def summary(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "evidence_fingerprint": self.evidence_fingerprint or None,
            "assessed_table_ids": list(self.assessed_table_ids),
            "no_record_table_ids": list(self.no_record_table_ids),
            "inconclusive_table_ids": list(self.inconclusive_table_ids),
            "record_region_ids": [region.region_id for region in self.record_regions],
            "record_region_count": len(self.record_regions),
            "reasons": list(self.reasons),
        }

    def region_by_id(self, region_id: str) -> EvidenceRecordRegion | None:
        return next(
            (region for region in self.record_regions if region.region_id == region_id),
            None,
        )


class RecordRegionBindingReport(_StrictModel):
    assessment_status: AssessmentStatus
    mapped_region_ids: list[str] = Field(default_factory=list)
    mapped_region_bindings: list[dict[str, Any]] = Field(default_factory=list)
    unmapped_region_ids: list[str] = Field(default_factory=list)
    fabricated_region_ids: list[str] = Field(default_factory=list)
    cross_region_ids: list[str] = Field(default_factory=list)
    overlapping_region_ids: list[str] = Field(default_factory=list)
    missing_region_id_count: int = Field(default=0, ge=0)

    @property
    def accepted(self) -> bool:
        return (
            self.assessment_status == "complete"
            and not self.unmapped_region_ids
            and not self.fabricated_region_ids
            and not self.cross_region_ids
            and not self.overlapping_region_ids
            and self.missing_region_id_count == 0
        )

    def summary(self) -> dict[str, Any]:
        return {
            "assessment_status": self.assessment_status,
            "mapped_region_ids": list(self.mapped_region_ids),
            "mapped_region_bindings": list(self.mapped_region_bindings),
            "unmapped_region_ids": list(self.unmapped_region_ids),
            "fabricated_region_ids": list(self.fabricated_region_ids),
            "cross_region_ids": list(self.cross_region_ids),
            "overlapping_region_ids": list(self.overlapping_region_ids),
            "missing_region_id_count": self.missing_region_id_count,
            "accepted": self.accepted,
        }


_ENGLISH_HEADER_TOKENS = frozenset(
    {
    "item",
    "item no",
    "item number",
    "position",
    "pos",
    "part",
    "part no",
    "part number",
    "p n",
    "number",
    "code",
    "material code",
    "material no",
    "material number",
    "sku",
    "model",
    "description",
    "name",
    "spec",
    "specification",
    "qty",
    "quantity",
    "uom",
    "unit",
    "remark",
    "price",
    "unit price",
    "amount",
    "total",
    "date",
    "delivery date",
    "due date",
    "signal",
    }
)
_CHINESE_HEADER_TOKENS = (
    "\u5e8f\u53f7",
    "\u7269\u6599\u53f7",
    "\u7269\u6599\u7f16\u7801",
    "\u7269\u6599\u540d\u79f0",
    "\u6599\u53f7",
    "\u4ea7\u54c1\u7f16\u7801",
    "\u4ea7\u54c1\u540d\u79f0",
    "\u7269\u54c1\u7f16\u7801",
    "\u7f16\u7801",
    "\u578b\u53f7",
    "\u578b\u53f7\u89c4\u683c",
    "\u89c4\u683c\u578b\u53f7",
    "\u7f16\u53f7",
    "\u54c1\u540d",
    "\u540d\u79f0",
    "\u89c4\u683c",
    "\u6570\u91cf",
    "\u5355\u4f4d",
    "\u7528\u91cf",
    "\u5907\u6ce8",
    "\u5355\u4ef7",
    "\u91d1\u989d",
    "\u65e5\u671f",
    "\u4ea4\u8d27\u65e5\u671f",
    "\u4ea4\u671f",
    "\u5916\u5f84\u5c3a\u5bf8",
    "\u5185\u5f84\u5c3a\u5bf8",
    "\u4e0b\u6599\u5c3a\u5bf8",
    "\u516c\u5dee",
    "\u5c3a\u5bf8",
    "\u957f\u5ea6",
    "\u5bbd\u5ea6",
    "\u9ad8\u5ea6",
)
_TITLE_OR_REVISION_TOKENS = (
    "dwg",
    "dwg no",
    "drawing",
    "drawing no",
    "rev",
    "revision",
    "version",
    "scale",
    "date",
    "approved",
    "checked",
    "checker",
    "approver",
    "prepared",
    "designed",
    "title block",
    "\u56fe\u53f7",
    "\u7248\u672c",
    "\u6bd4\u4f8b",
    "\u8bbe\u8ba1",
    "\u6821\u5bf9",
    "\u5ba1\u6838",
    "\u6279\u51c6",
    "\u6807\u9898\u680f",
    "\u9875\u6b21",
)
_REVISION_HEADER_TOKENS: dict[str, tuple[str, ...]] = {
    "revision": (
        "rev",
        "revision",
        "version",
        "edition",
        "ecn",
        "change no",
        "\u7248\u672c",
        "\u7248\u6b21",
        "\u4fee\u8ba2",
        "\u4fee\u8ba2\u53f7",
        "\u53d8\u66f4\u53f7",
    ),
    "date": (
        "date",
        "release date",
        "effective date",
        "release on",
        "when",
        "\u65e5\u671f",
        "\u751f\u6548\u65e5\u671f",
        "\u53d1\u5e03\u65e5\u671f",
    ),
    "change": (
        "change",
        "change details",
        "description",
        "details",
        "reason",
        "amendment",
        "modification",
        "\u66f4\u6539\u5185\u5bb9",
        "\u53d8\u66f4\u5185\u5bb9",
        "\u4fee\u6539\u5185\u5bb9",
        "\u4fee\u8ba2\u5185\u5bb9",
        "\u53d8\u66f4\u8bf4\u660e",
    ),
    "actor": (
        "by",
        "changed by",
        "revised by",
        "approved by",
        "checked by",
        "reviser",
        "owner",
        "\u4fee\u6539\u4eba",
        "\u4fee\u8ba2\u4eba",
        "\u53d8\u66f4\u4eba",
        "\u5ba1\u6838\u4eba",
        "\u6279\u51c6\u4eba",
    ),
    "sequence": (
        "no",
        "number",
        "item",
        "\u5e8f\u53f7",
        "\u9879\u6b21",
    ),
}
_REVISION_DATE_RE = re.compile(
    r"(?:\b(?:19|20)\d{2}[-/.]\d{1,2}[-/.]\d{1,2}\b|\b(?:19|20)\d{6}\b)"
)
_NONRECORD_ANNOTATION_TOKENS = (
    "total",
    "subtotal",
    "grand total",
    "note",
    "signature",
    "\u5408\u8ba1",
    "\u5c0f\u8ba1",
    "\u5907\u6ce8",
    "\u8bf4\u660e",
    "\u6ce8\u610f",
    "\u7b7e\u5b57",
)
_DOCUMENT_CONTROL_LABEL_RE = re.compile(
    r"(?:^|\s)(?:\u5236\u5b9a|\u5236\u8868|\u7f16\u5236|\u5ba1\u6838|\u6279\u51c6|\u7b7e\u5b57)"
    r"(?:\u65e5\u671f)?\s*[\uff1a:]",
    re.IGNORECASE,
)
_BOM_OR_DETAIL_SIGNAL_RE = re.compile(
    r"(?:\b(?:bom|bill\s+of\s+materials|parts?\s+list|material\s+list)\b|"
    r"\u7269\u6599\u6e05\u5355|\u96f6\u4ef6\u660e\u7ec6|\u96f6\u90e8\u4ef6\u660e\u7ec6|"
    r"\u90e8\u4ef6\u660e\u7ec6|\u6750\u6599\u6e05\u5355|\u660e\u7ec6\u8868)",
    re.IGNORECASE,
)
_QUANTITY_LABEL_RE = re.compile(
    r"(?:\b(?:qty|quantity|pieces?|sets?|units?)\b|\u6570\u91cf|\u7528\u91cf|\u4e2a\u6570|\u4ef6\u6570)",
    re.IGNORECASE,
)
_COUNT_VALUE_RE = re.compile(
    r"(?:\b\d+(?:[.,]\d+)?\s*(?:pcs?|pieces?|sets?|ea|units?|boxes?|ctns?)\b|"
    r"\d+(?:[.,]\d+)?\s*(?:\u4e2a|\u4ef6|\u5957|\u53ea|\u7247|\u7bb1|\u652f))",
    re.IGNORECASE,
)
_DETAIL_HEADER_CATEGORIES: dict[str, tuple[str, ...]] = {
    "identifier": (
        "item",
        "item no",
        "item number",
        "part",
        "part no",
        "part number",
        "material code",
        "material number",
        "sku",
        "model",
        "code",
        "\u5e8f\u53f7",
        "\u7269\u6599\u53f7",
        "\u7269\u6599\u7f16\u7801",
        "\u6599\u53f7",
        "\u4ea7\u54c1\u7f16\u7801",
        "\u578b\u53f7",
    ),
    "description": (
        "description",
        "name",
        "spec",
        "specification",
        "\u540d\u79f0",
        "\u54c1\u540d",
        "\u7269\u6599\u540d\u79f0",
        "\u89c4\u683c",
        "\u63cf\u8ff0",
    ),
    "quantity": (
        "qty",
        "quantity",
        "uom",
        "unit",
        "\u6570\u91cf",
        "\u7528\u91cf",
        "\u5355\u4f4d",
    ),
}
_IDENTIFIER_TOKEN_RE = re.compile(
    r"[A-Za-z0-9][A-Za-z0-9._/-]{1,127}",
    re.ASCII,
)
_MEASURE_RE = re.compile(
    r"^[+-]?\d+(?:[.,]\d+)?(?:\s*(?:%|mm|cm|m|kg|g|pcs?|sets?|ea|box|ctn))?$",
    re.IGNORECASE,
)


def _text(value: object) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip()


def _contains_english_token(value: str, token: str) -> bool:
    return re.search(
        rf"(?<![a-z0-9]){re.escape(token)}(?![a-z0-9])",
        value.casefold(),
    ) is not None


def _detail_header_category_count(value: str) -> int:
    """Count independent record-header categories in unstructured page text."""

    normalized = unicodedata.normalize("NFKC", value)
    categories: set[str] = set()
    for category, tokens in _DETAIL_HEADER_CATEGORIES.items():
        for token in tokens:
            if token.isascii():
                if _contains_english_token(normalized, token):
                    categories.add(category)
                    break
            elif token in normalized:
                categories.add(category)
                break
    return len(categories)


def _page_has_unrecovered_record_signal(page: EvidencePage) -> bool:
    """Detect record-like text when MinerU failed to recover a table object.

    This is deliberately a fail-closed detector.  It only runs for pages with
    no recovered tables and requires a BOM/detail marker, multiple independent
    table-header categories, or both an identifier and a count signal.  A
    regular drawing title such as ``DWG-001`` with dimensions alone therefore
    remains eligible for the explicit no-record path.
    """

    text = "\n".join(
        value
        for value in (
            *(block.text for block in page.blocks),
            page.markdown,
        )
        if _text(value)
    )
    if not text:
        return False
    if _BOM_OR_DETAIL_SIGNAL_RE.search(text):
        return True
    if _detail_header_category_count(text) >= 2:
        return True
    return _contains_identifier(text) and bool(
        _QUANTITY_LABEL_RE.search(text) or _COUNT_VALUE_RE.search(text)
    )


def _unrecovered_record_content_id(page: EvidencePage) -> str:
    return f"p{page.page_number}:unrecovered-record-content"


def _canonical_table_payload(
    *,
    page_number: int,
    table: EvidenceTable,
) -> dict[str, Any]:
    payload = {
        "page_number": page_number,
        "table_id": table.table_id,
        "rows": table.rows,
        "cells": [
            {"row": cell.row, "column": cell.column, "text": cell.text}
            for cell in sorted(table.cells, key=lambda value: (value.row, value.column))
        ],
    }
    native_record_layout = (table.model_extra or {}).get("native_record_layout")
    if native_record_layout is not None:
        payload["native_record_layout"] = native_record_layout
    return payload


def _native_record_regions(
    table: EvidenceTable,
) -> tuple[EvidenceRecordRegion, ...] | None:
    """Read a bounded row partition emitted by the native spreadsheet adapter."""

    if table.source != "spreadsheet-envelope":
        return None
    raw = (table.model_extra or {}).get("native_record_layout")
    if not isinstance(raw, dict):
        return None
    if raw.get("source") != "spreadsheet-tabular-v1":
        return None
    if raw.get("orientation") != "rows":
        return None
    raw_axes = raw.get("record_axes")
    raw_headers = raw.get("header_axes")
    if not isinstance(raw_axes, list) or not isinstance(raw_headers, list):
        return None
    if any(isinstance(value, bool) or not isinstance(value, int) for value in raw_axes):
        return None
    if any(
        isinstance(value, bool) or not isinstance(value, int)
        for value in raw_headers
    ):
        return None
    record_axes = sorted(set(raw_axes))
    header_axes = set(raw_headers)
    if not record_axes or len(record_axes) != len(raw_axes):
        return None
    if header_axes & set(record_axes):
        return None
    if record_axes[0] < 0 or record_axes[-1] >= len(table.rows):
        return None
    if any(axis < 0 or axis >= len(table.rows) for axis in header_axes):
        return None
    if any(
        not any(_text(value) for value in table.rows[axis])
        for axis in record_axes
    ):
        return None

    spans: list[tuple[int, int]] = []
    start = previous = record_axes[0]
    for axis in record_axes[1:]:
        if axis == previous + 1:
            previous = axis
            continue
        spans.append((start, previous))
        start = previous = axis
    spans.append((start, previous))

    regions: list[EvidenceRecordRegion] = []
    for data_start, data_end in spans:
        first = _axis_boundary_evidence_id(
            table,
            orientation="rows",
            axis_index=data_start,
        )
        last = _axis_boundary_evidence_id(
            table,
            orientation="rows",
            axis_index=data_end,
        )
        if not first or not last:
            return None
        regions.append(
            EvidenceRecordRegion(
                region_id=record_region_id(
                    table.table_id,
                    "rows",
                    data_start,
                    data_end,
                ),
                table_id=table.table_id,
                orientation="rows",
                data_start=data_start,
                data_end=data_end,
                boundary_evidence_ids=[first, last],
            )
        )
    return tuple(regions)


def _fingerprint_table_payloads(payloads: list[dict[str, Any]]) -> str:
    encoded = json.dumps(
        payloads,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def record_region_evidence_fingerprint(evidence: DocumentEvidence) -> str:
    payloads = [
        _canonical_table_payload(page_number=page.page_number, table=table)
        for page in evidence.pages
        for table in page.tables
    ]
    return _fingerprint_table_payloads(payloads)


def record_region_raw_pages_fingerprint(raw_pages: Any) -> str | None:
    """Hash the exact table evidence embedded in a candidate DocumentRecord."""

    if not isinstance(raw_pages, list):
        return None
    payloads: list[dict[str, Any]] = []
    try:
        for page_index, raw_page in enumerate(raw_pages):
            if not isinstance(raw_page, dict):
                return None
            page_number = int(raw_page.get("page_number") or page_index + 1)
            tables = raw_page.get("tables")
            if not isinstance(tables, list):
                return None
            for raw_table in tables:
                table = EvidenceTable.model_validate(raw_table)
                payloads.append(
                    _canonical_table_payload(page_number=page_number, table=table)
                )
    except (TypeError, ValueError):
        return None
    return _fingerprint_table_payloads(payloads)


def assess_record_regions_from_raw_pages(
    raw_pages: Any,
) -> RecordRegionAssessment | None:
    """Recompute the gate from the candidate's preserved raw MinerU evidence."""

    if not isinstance(raw_pages, list):
        return None
    try:
        pages = [EvidencePage.model_validate(page) for page in raw_pages]
    except (TypeError, ValueError):
        return None
    return assess_record_regions(
        DocumentEvidence(backend="authority-replay", pages=pages)
    )


def _folded(values: list[str]) -> str:
    return " ".join(value.casefold() for value in values if value)


def _header_cell(value: str) -> bool:
    """Match labels, not arbitrary data containing an English label fragment."""

    folded = value.casefold().strip()
    compact = re.sub(r"[^a-z0-9]+", " ", folded).strip()
    if compact in _ENGLISH_HEADER_TOKENS:
        return True
    compact_cjk = re.sub(r"[\s:\uff1a/\\()\[\]{}]", "", value)
    if compact_cjk in _CHINESE_HEADER_TOKENS:
        return True
    if (
        len(compact_cjk) > 8
        or any(character.isdigit() or character.isascii() for character in compact_cjk)
    ):
        return False
    return any(
        len(token) >= 2
        and (compact_cjk.startswith(token) or compact_cjk.endswith(token))
        for token in _CHINESE_HEADER_TOKENS
    )


def _axis_values(table: EvidenceTable, orientation: RecordOrientation) -> list[list[str]]:
    if orientation == "rows":
        return [[_text(value) for value in row] for row in table.rows]
    width = max((len(row) for row in table.rows), default=0)
    return [
        [_text(row[column]) if column < len(row) else "" for row in table.rows]
        for column in range(width)
    ]


def _is_record_header(values: list[str]) -> bool:
    # A multi-column label row is a reliable header signal.  A lone label is
    # never enough on its own: values such as "blue 105 size" and product
    # descriptions routinely contain one header-like word.
    matches = [value for value in values if _header_cell(value)]
    if len(matches) >= 2:
        return True
    nonempty = [value.strip() for value in values if value.strip()]
    if len(nonempty) == 1 and matches and (
        matches[0].casefold().strip() in _ENGLISH_HEADER_TOKENS
        or re.sub(r"[\s:\uff1a/\\()\[\]{}]", "", matches[0])
        in _CHINESE_HEADER_TOKENS
    ):
        return True
    if matches and matches[0].casefold().strip() == "signal":
        return len(nonempty) >= 2 and all(
            len(value) <= 24 and not any(character.isdigit() for character in value)
            for value in nonempty
        )
    return False


def _is_title_or_revision(values: list[str]) -> bool:
    folded = _folded(values)
    matches = sum(token in folded for token in _TITLE_OR_REVISION_TOKENS)
    return matches >= 2 or any(
        marker in folded for marker in ("title block", "revision", "\u6807\u9898\u680f")
    )


def _revision_header_category(value: str) -> str | None:
    normalized = re.sub(
        r"[^0-9a-z\u3400-\u9fff]+",
        " ",
        unicodedata.normalize("NFKC", value).casefold(),
    ).strip()
    compact = normalized.replace(" ", "")
    if not normalized:
        return None
    for category, tokens in _REVISION_HEADER_TOKENS.items():
        for token in tokens:
            if token.isascii():
                if normalized == token or _contains_english_token(normalized, token):
                    return category
            elif compact == token.replace(" ", ""):
                return category
    return None


def _revision_history_header_axis(table: EvidenceTable) -> int | None:
    """Return a revision header only when its following row proves the layout."""

    axes = _axis_values(table, "rows")
    for header_axis, values in enumerate(axes[:3]):
        categories_by_column = {
            column: category
            for column, value in enumerate(values)
            if (category := _revision_header_category(value)) is not None
        }
        categories = set(categories_by_column.values())
        if "revision" not in categories or len(categories) < 3:
            continue
        revision_columns = {
            column
            for column, category in categories_by_column.items()
            if category == "revision"
        }
        date_columns = {
            column
            for column, category in categories_by_column.items()
            if category == "date"
        }
        semantic_columns = {
            column
            for column, category in categories_by_column.items()
            if category in {"change", "actor"}
        }
        for row in axes[header_axis + 1 :]:
            if sum(bool(value) for value in row) < 2:
                continue
            revision_values = [
                row[column]
                for column in revision_columns
                if column < len(row) and row[column]
            ]
            if not revision_values or any(
                len(value) > 32 or _revision_header_category(value) is not None
                for value in revision_values
            ):
                continue
            has_date = any(
                column < len(row) and _REVISION_DATE_RE.search(row[column])
                for column in date_columns
            )
            has_semantic_value = any(
                column < len(row) and bool(row[column]) for column in semantic_columns
            )
            if has_date or has_semantic_value:
                return header_axis
    return None


def is_revision_history_table(table: EvidenceTable) -> bool:
    """Whether a table is structurally proven revision history, not a BOM."""

    return _revision_history_header_axis(table) is not None


def _is_nonrecord_annotation(values: list[str]) -> bool:
    folded = _folded(values)
    compact = re.sub(r"\s+", "", folded)
    annotation_match = any(
        token in folded
        if token.isascii()
        else re.sub(r"\s+", "", token) in compact
        for token in _NONRECORD_ANNOTATION_TOKENS
    )
    nonempty = [value for value in values if value]
    control_label_match = bool(nonempty) and any(
        _DOCUMENT_CONTROL_LABEL_RE.search(value) for value in nonempty
    )
    if not annotation_match and not control_label_match:
        return False
    # A remark is commonly one field inside a dense business row.  Annotation
    # words can classify the whole axis only when there is no independent
    # identifier-plus-measure record shape around them.
    return not (
        len(nonempty) >= 4
        and _has_identifier(nonempty)
        and any(_MEASURE_RE.fullmatch(value) for value in nonempty)
    )


def _contains_identifier(value: str) -> bool:
    for match in _IDENTIFIER_TOKEN_RE.finditer(value):
        token = match.group(0)
        digits = sum(character.isdigit() for character in token)
        letters = sum(character.isalpha() for character in token)
        if token[0].isalpha() and digits:
            return True
        if token[0].isdigit() and len(token) >= 3 and token[:3].isdigit():
            return True
        if digits and letters >= 2 and any(mark in token for mark in "._/-"):
            return True
    return False


def _has_identifier(values: list[str]) -> bool:
    return any(_contains_identifier(value) for value in values)


def _is_plausible_record(values: list[str]) -> bool:
    nonempty = [value for value in values if value]
    if (
        len(nonempty) < 2
        or _is_record_header(nonempty)
        or _is_title_or_revision(nonempty)
    ):
        return False
    if _has_identifier(nonempty):
        return True
    # A row without a formal code is common in inventory, specifications and
    # service ledgers.  Treat it as a record only in a record-header context;
    # otherwise a dense title block stays inconclusive rather than being guessed.
    return len(nonempty) >= 3 and any(_MEASURE_RE.fullmatch(value) for value in nonempty)


def _decimal_cell(value: str) -> Decimal | None:
    token = unicodedata.normalize("NFKC", value).strip()
    token = re.sub(r"(?i)(?:rmb|cny|usd|eur)", "", token)
    token = re.sub(r"[,￥¥$€%\s]", "", token)
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d+)?|\.\d+)", token):
        return None
    try:
        return Decimal(token)
    except InvalidOperation:
        return None


def _is_self_describing_record(values: list[str]) -> bool:
    """Recognize a dense record row even when the source omits a header row."""

    nonempty = [value for value in values if value]
    if (
        len(nonempty) < 4
        or _is_record_header(nonempty)
        or _is_title_or_revision(nonempty)
        or _is_nonrecord_annotation(nonempty)
    ):
        return False
    numeric_count = sum(_decimal_cell(value) is not None for value in nonempty)
    measured_count = sum(_MEASURE_RE.fullmatch(value) is not None for value in nonempty)
    descriptive_count = sum(
        _decimal_cell(value) is None and _MEASURE_RE.fullmatch(value) is None
        for value in nonempty
    )
    return descriptive_count >= 1 and (
        numeric_count >= 2 or (numeric_count >= 1 and measured_count >= 2)
    )


def _is_structural_summary(
    values: list[str],
    prior_records: list[list[str]],
) -> bool:
    """Detect sparse aggregate axes from arithmetic evidence, not row labels."""

    if not prior_records or any(
        _decimal_cell(value) is None and _contains_identifier(value)
        for value in values
    ):
        return False
    nonempty_count = sum(bool(value) for value in values)
    prior_density = median(
        sum(bool(value) for value in record) for record in prior_records
    )
    if nonempty_count >= prior_density:
        return False
    aggregate_matches = 0
    for index, value in enumerate(values):
        total = _decimal_cell(value)
        if total is None:
            continue
        parts = [
            parsed
            for record in prior_records
            if index < len(record)
            and (parsed := _decimal_cell(record[index])) is not None
        ]
        minimum_parts = 2 if len(prior_records) >= 2 else 1
        if len(parts) >= minimum_parts and total == sum(parts, Decimal(0)):
            aggregate_matches += 1
    required_matches = 1 if len(prior_records) >= 2 else 2
    return aggregate_matches >= required_matches


def is_structural_summary_axis(
    values: list[str | None],
    prior_records: list[list[str | None]],
) -> bool:
    """Expose the evidence-based summary test to native table adapters."""

    normalized = [_text(value) for value in values]
    normalized_prior = [[_text(value) for value in row] for row in prior_records]
    return _is_nonrecord_annotation(normalized) or _is_structural_summary(
        normalized,
        normalized_prior,
    )


def _is_unknown_dense(values: list[str]) -> bool:
    nonempty = [value for value in values if value]
    return (
        len(nonempty) >= 2
        and not _is_record_header(nonempty)
        and not _is_title_or_revision(nonempty)
    )


def _axis_boundary_evidence_id(
    table: EvidenceTable,
    *,
    orientation: RecordOrientation,
    axis_index: int,
) -> str | None:
    known_cells = {(cell.row, cell.column) for cell in table.cells}
    if orientation == "rows":
        if axis_index >= len(table.rows):
            return None
        for column, value in enumerate(table.rows[axis_index]):
            if _text(value) and (axis_index, column) in known_cells:
                return f"{table.table_id}:r{axis_index}:c{column}"
        return None
    for row_index, row in enumerate(table.rows):
        if axis_index < len(row) and _text(row[axis_index]) and (row_index, axis_index) in known_cells:
            return f"{table.table_id}:r{row_index}:c{axis_index}"
    return None


def _orthogonal_structural_axes(
    table: EvidenceTable,
    orientation: RecordOrientation,
) -> set[int]:
    """Return cross-axes that contain structure rather than record payload.

    A sparse row-oriented table can otherwise look like a column-oriented
    record: its header contributes one value and its total row contributes a
    second value in the same column. Neither cell is independent business
    data, so that perpendicular axis must not become a record region.
    """

    orthogonal: RecordOrientation = "columns" if orientation == "rows" else "rows"
    return {
        index
        for index, values in enumerate(_axis_values(table, orthogonal))
        if _is_dominantly_structural_axis(values)
    }


def _is_dominantly_structural_axis(values: list[str]) -> bool:
    """Distinguish a pure structural axis from a data axis with repeated labels."""

    nonempty = [value for value in values if value]
    if not nonempty:
        return False
    header_matches = sum(_header_cell(value) for value in nonempty)
    header_dominant = _is_record_header(nonempty) and (
        len(nonempty) == 1 or header_matches * 2 >= len(nonempty)
    )
    sparse_context = len(nonempty) * 2 <= len(values) and (
        _is_title_or_revision(nonempty) or _is_nonrecord_annotation(nonempty)
    )
    return header_dominant or sparse_context


def _has_independent_record_payload(
    values: list[str],
    orthogonal_structural_axes: set[int],
) -> bool:
    """Whether an axis has data outside perpendicular headers and summaries."""

    return any(
        value and field_axis not in orthogonal_structural_axes
        for field_axis, value in enumerate(values)
    )


@dataclass(frozen=True, slots=True)
class _OrientationAssessment:
    regions: tuple[EvidenceRecordRegion, ...]
    unknown_axes: tuple[int, ...]
    score: int


def _assess_orientation(
    table: EvidenceTable,
    orientation: RecordOrientation,
) -> _OrientationAssessment:
    axes = _axis_values(table, orientation)
    orthogonal_structural_axes = _orthogonal_structural_axes(table, orientation)
    field_axis_count = (
        max((len(row) for row in table.rows), default=0)
        if orientation == "rows"
        else len(table.rows)
    )
    record_axes: set[int] = set()
    header_axes: set[int] = set()
    ignored_axes: set[int] = set()
    first_record_header: int | None = None
    record_values: list[list[str]] = []
    context: Literal["none", "record", "nonrecord"] = "none"

    def add_record_axis(index: int, values: list[str]) -> None:
        if _has_independent_record_payload(values, orthogonal_structural_axes):
            record_axes.add(index)
            record_values.append(values)
        else:
            ignored_axes.add(index)

    for index, values in enumerate(axes):
        if not any(values):
            context = "none"
            continue
        if _is_title_or_revision(values):
            context = "nonrecord"
            ignored_axes.add(index)
            continue
        # A real multi-column header commonly contains labels such as
        # "remark".  Classify the complete row before treating those labels as
        # standalone annotations, otherwise the metadata row above the table
        # makes the whole record region inconclusive.
        if _is_record_header(values):
            context = "record"
            header_axes.add(index)
            if first_record_header is None:
                first_record_header = index
                header_strength = sum(_header_cell(value) for value in values if value)
                if header_strength >= 2:
                    # Rows above the first strong field header are document
                    # metadata even when an order number or date gives them an
                    # identifier-like shape.  Reclassify provisional records
                    # instead of letting the preamble become a data region.
                    preamble_axes = {axis for axis in record_axes if axis < index}
                    if preamble_axes:
                        record_axes.difference_update(preamble_axes)
                        ignored_axes.update(preamble_axes)
                        record_values = [
                            axes[axis] for axis in sorted(record_axes)
                        ]
            continue
        if _is_nonrecord_annotation(values):
            context = "none"
            ignored_axes.add(index)
            continue
        if context == "nonrecord":
            # Values below a revision/title header may look code-like (for
            # example V1 or DWG-001), but are never business record evidence.
            ignored_axes.add(index)
            continue
        if record_values and _is_structural_summary(values, record_values):
            context = "none"
            ignored_axes.add(index)
            continue
        if context == "record" and field_axis_count == 1:
            add_record_axis(index, values)
            continue
        if _is_plausible_record(values) and (
            _has_identifier(values) or context == "record"
        ):
            add_record_axis(index, values)
            continue
        if _is_self_describing_record(values):
            add_record_axis(index, values)
            context = "record"
            continue
        if context == "record" and _is_unknown_dense(values):
            # Once a strong header establishes a record table, text-only rows
            # such as connector shell mappings remain legitimate records even
            # when they contain no numeric identifier or measure.
            add_record_axis(index, values)
            continue
    regions: list[EvidenceRecordRegion] = []
    unknown: set[int] = set()
    start: int | None = None
    spans: list[tuple[int, int]] = []
    for index in range(len(axes) + 1):
        if index < len(axes) and index in record_axes:
            if start is None:
                start = index
            continue
        if start is not None:
            spans.append((start, index - 1))
            start = None
    covered: set[int] = set()
    for data_start, data_end in spans:
        nearby_headers = [
            header
            for header in header_axes
            if header in {data_start - 2, data_start - 1}
        ]
        nearby_header_strength = max(
            (
                sum(_header_cell(value) for value in axes[header] if value)
                for header in nearby_headers
            ),
            default=0,
        )
        if (
            data_end == data_start
            and nearby_header_strength < 2
            and not (field_axis_count == 1 and nearby_header_strength == 1)
            and not _is_self_describing_record(axes[data_start])
        ):
            unknown.add(data_start)
            continue
        first = _axis_boundary_evidence_id(
            table,
            orientation=orientation,
            axis_index=data_start,
        )
        last = _axis_boundary_evidence_id(
            table,
            orientation=orientation,
            axis_index=data_end,
        )
        if not first or not last:
            unknown.update(range(data_start, data_end + 1))
            continue
        regions.append(
            EvidenceRecordRegion(
                region_id=record_region_id(
                    table.table_id,
                    orientation,
                    data_start,
                    data_end,
                ),
                table_id=table.table_id,
                orientation=orientation,
                data_start=data_start,
                data_end=data_end,
                boundary_evidence_ids=[first, last],
            )
        )
        covered.update(range(data_start, data_end + 1))
    for index, values in enumerate(axes):
        if index in covered or index in header_axes or index in ignored_axes:
            continue
        if first_record_header is not None and index < first_record_header:
            continue
        if _is_unknown_dense(values):
            unknown.add(index)
    if first_record_header is not None:
        unknown = {
            index for index in unknown if index > first_record_header
        }
    strongest_header = max(
        (
            sum(_header_cell(value) for value in axes[index] if value)
            for index in header_axes
        ),
        default=0,
    )
    header_density = max(
        (
            sum(_header_cell(value) for value in axes[index] if value)
            / max(1, sum(bool(value) for value in axes[index]))
            for index in header_axes
        ),
        default=0.0,
    )
    record_density = [
        sum(bool(value) for value in axes[index]) for index in sorted(record_axes)
    ]
    regularity = (
        1.0
        - (max(record_density) - min(record_density)) / max(record_density)
        if record_density and max(record_density)
        else 0.0
    )
    record_count = sum(
        region.data_end - region.data_start + 1 for region in regions
    )
    score = int(
        strongest_header * 100
        + header_density * 50
        + regularity * 40
        + min(record_count, 10) * 2
        - max(0, len(regions) - 1) * 20
        - len(unknown) * 25
    )
    return _OrientationAssessment(
        regions=tuple(regions),
        unknown_axes=tuple(sorted(unknown)),
        score=score,
    )


def assess_record_regions(evidence: DocumentEvidence) -> RecordRegionAssessment:
    """Assess every MinerU table from full evidence, never a sampled payload.

    The assessor is deliberately conservative.  If the evidence has a dense
    table region that cannot be classified as a record range or a title/revision
    area, the whole table is marked inconclusive and cannot become authoritative.
    """

    assessed: list[str] = []
    no_record: list[str] = []
    inconclusive: list[str] = []
    regions: list[EvidenceRecordRegion] = []
    reasons: list[str] = []
    for page in evidence.pages:
        if not page.tables and _page_has_unrecovered_record_signal(page):
            synthetic_table_id = _unrecovered_record_content_id(page)
            assessed.append(synthetic_table_id)
            inconclusive.append(synthetic_table_id)
            reasons.append(f"{synthetic_table_id}:record_signal_without_table")
        for table in page.tables:
            assessed.append(table.table_id)
            if not table.rows or not any(
                _text(value)
                for row in table.rows
                for value in row
            ):
                no_record.append(table.table_id)
                continue
            if is_revision_history_table(table):
                no_record.append(table.table_id)
                continue
            native_regions = _native_record_regions(table)
            if native_regions is not None:
                regions.extend(native_regions)
                continue
            row_assessment = _assess_orientation(table, "rows")
            column_assessment = _assess_orientation(table, "columns")
            candidates = [
                candidate
                for candidate in (row_assessment, column_assessment)
                if candidate.regions and not candidate.unknown_axes
            ]
            if candidates:
                candidates.sort(key=lambda candidate: candidate.score, reverse=True)
                selected = candidates[0]
                if (
                    len(candidates) > 1
                    and candidates[1].score * 10 >= selected.score * 9
                ):
                    inconclusive.append(table.table_id)
                    reasons.append(f"{table.table_id}:ambiguous_orientation")
                    continue
                regions.extend(selected.regions)
                continue
            if not row_assessment.unknown_axes and not column_assessment.unknown_axes:
                no_record.append(table.table_id)
                continue
            inconclusive.append(table.table_id)
            reasons.append(f"{table.table_id}:unclassified_dense_region")
    status: AssessmentStatus = "inconclusive" if inconclusive else "complete"
    return RecordRegionAssessment(
        status=status,
        evidence_fingerprint=record_region_evidence_fingerprint(evidence),
        assessed_table_ids=assessed,
        no_record_table_ids=no_record,
        record_regions=regions,
        inconclusive_table_ids=inconclusive,
        reasons=reasons,
    )


def record_region_binding_report(
    assessment: RecordRegionAssessment,
    bindings: list[dict[str, Any]],
) -> RecordRegionBindingReport:
    """Validate mapper/replay plans against fixed assessment region identities."""

    expected = {region.region_id: region for region in assessment.record_regions}
    mapped: list[str] = []
    valid: set[str] = set()
    fabricated: set[str] = set()
    cross: set[str] = set()
    overlaps: set[str] = set()
    missing_region_id_count = 0
    intervals: dict[tuple[str, str], list[tuple[int, int, str]]] = {}
    normalized_bindings: list[dict[str, Any]] = []
    for index, binding in enumerate(bindings):
        region_id = str(binding.get("region_id") or "").strip()
        table_id = str(binding.get("table_id") or "").strip()
        orientation = str(binding.get("orientation") or "").strip()
        try:
            data_start = int(binding.get("data_start"))
            data_end = int(binding.get("data_end"))
        except (TypeError, ValueError):
            data_start = -1
            data_end = -1
        normalized = {
            "region_id": region_id,
            "table_id": table_id,
            "orientation": orientation,
            "data_start": data_start,
            "data_end": data_end,
        }
        normalized_bindings.append(normalized)
        if not region_id:
            missing_region_id_count += 1
            continue
        mapped.append(region_id)
        expected_region = expected.get(region_id)
        if expected_region is None:
            fabricated.add(region_id)
            continue
        if region_id in valid:
            overlaps.add(region_id)
            continue
        if (
            table_id != expected_region.table_id
            or orientation != expected_region.orientation
            or data_start != expected_region.data_start
            or data_end != expected_region.data_end
        ):
            cross.add(region_id)
            continue
        key = (table_id, orientation)
        for start, end, other_region_id in intervals.setdefault(key, []):
            if data_start <= end and start <= data_end:
                overlaps.update({region_id, other_region_id})
        intervals[key].append((data_start, data_end, region_id))
        valid.add(region_id)
    return RecordRegionBindingReport(
        assessment_status=assessment.status,
        mapped_region_ids=sorted(dict.fromkeys(mapped)),
        mapped_region_bindings=normalized_bindings,
        unmapped_region_ids=sorted(set(expected) - valid),
        fabricated_region_ids=sorted(fabricated),
        cross_region_ids=sorted(cross),
        overlapping_region_ids=sorted(overlaps),
        missing_region_id_count=missing_region_id_count,
    )


__all__ = [
    "AssessmentStatus",
    "EvidenceRecordRegion",
    "RecordOrientation",
    "RecordRegionAssessment",
    "RecordRegionBindingReport",
    "assess_record_regions",
    "assess_record_regions_from_raw_pages",
    "is_revision_history_table",
    "record_region_binding_report",
    "record_region_evidence_fingerprint",
    "record_region_id",
    "record_region_raw_pages_fingerprint",
]
