"""Isolated MinerU + LLM shadow execution and comparison artifacts."""

from __future__ import annotations

import asyncio
import copy
import hashlib
import inspect
import json
import os
import re
import threading
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar

from ..models import DocumentRecord
from .comparison import compare_document_records
from .document_route_plan import DocumentRoutePlan
from .mineru import MinerUClient
from .mineru_candidate import (
    MinerUBusinessMapper,
    MinerUBusinessPlan,
    map_mineru_candidate,
)
from .mineru_input import (
    MinerUCADRendererRequired,
    MinerUInputContractError,
    MinerUInputNormalizer,
)
from .mineru_instructor_service import (
    MinerUInstructorService,
    MinerUInstructorServiceResult,
)
from .mineru_shadow_lifecycle import (
    MinerUShadowLifecycleMixin,
    _ArtifactDeleted,
    _ShadowJob,
    _SnapshotTooLarge,
)
from .semantic_strategy_executor import SemanticExecutionSpec

_HEADER_FIELDS = (
    "title",
    "issuer",
    "order_number",
    "contract_number",
    "date_raw",
    "delivery_date_raw",
    "settlement_method",
    "delivery_address",
    "buyer",
    "seller",
    "supplier",
    "currency",
)
_LINE_COMPARE_EXCLUDED = {
    "line_id",
    "image_refs",
    "custom_fields",
    "raw_columns",
    "name_attributes",
}
_MAX_ARTIFACT_BYTES_HARD = 256 * 1024 * 1024
_DEFAULT_MAX_QUEUED_BYTES = 64 * 1024 * 1024
_NATIVE_DOCX_PART = re.compile(
    r"^(?:mineru/)?docx:(?:p:\d+|t:\d+(?::r\d+:c\d+|/r\d+/c\d+))$"
)
_NATIVE_OOXML_PART = re.compile(
    r"^word/document\.xml#(?:paragraph:\d+|table:\d+/row:\d+/cell:\d+)$"
)
_EXTERNAL_CLASSIFICATION_PATHS = frozenset(
    {"$.document_type", "$.document_subtype", "$.document_kind_label"}
)


def _canonical_digest(value: Any) -> str:
    digest = hashlib.sha256()
    encoder = json.JSONEncoder(
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    for chunk in encoder.iterencode(value):
        digest.update(chunk.encode("utf-8"))
    return digest.hexdigest()


def _mapper_usage_count(usage: dict[str, Any], *keys: str) -> int:
    """Read a mapper counter while preserving compatibility with old runs."""

    for key in keys:
        if key in usage:
            try:
                return int(usage.get(key) or 0)
            except (TypeError, ValueError):
                return 0
    return 0


def _bounded_json_size(value: Any, limit: int) -> int:
    """Count JSON bytes without materializing the complete payload."""

    encoder = json.JSONEncoder(
        ensure_ascii=False,
        separators=(",", ":"),
        default=str,
    )
    total = 0
    for chunk in encoder.iterencode(value):
        total += len(chunk.encode("utf-8"))
        if total > limit:
            return total
    return total


def _bind_spreadsheet_source_refs(
    document: DocumentRecord, input_metadata: dict[str, Any]
) -> DocumentRecord:
    """Attach original sheet/range provenance to evidence from a rendered PDF."""

    spreadsheet_mapping = input_metadata.get("spreadsheet_mapping")
    if not isinstance(spreadsheet_mapping, dict):
        return document
    rendered_pages = spreadsheet_mapping.get("rendered_pages")
    if not isinstance(rendered_pages, list):
        return document

    page_map: list[tuple[int, int, str, str]] = []
    for item in rendered_pages:
        if not isinstance(item, dict):
            continue
        try:
            start = int(item.get("page_start"))
            end = int(item.get("page_end"))
        except (TypeError, ValueError):
            continue
        sheet = str(item.get("sheet") or "").strip()
        cell_range = str(item.get("range") or "").strip()
        if start > 0 and end >= start and sheet and cell_range:
            page_map.append((start, end, sheet, cell_range))
    if not page_map:
        return document

    def lookup(page: object) -> tuple[str, str] | None:
        try:
            page_number = int(page)
        except (TypeError, ValueError):
            return None
        for start, end, sheet, cell_range in page_map:
            if start <= page_number <= end:
                return sheet, cell_range
        return None

    payload = document.model_dump(mode="json")

    def walk(value: object) -> None:
        if isinstance(value, dict):
            refs = value.get("source_refs")
            if isinstance(refs, list):
                for reference in refs:
                    if not isinstance(reference, dict) or reference.get("sheet"):
                        continue
                    mapped = lookup(reference.get("page"))
                    if mapped is None:
                        continue
                    reference["sheet"], reference["range"] = mapped
                    reference["normalized_from"] = "spreadsheet_pdf"
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(payload)
    return type(document).model_validate(payload)


def _bounded_artifact_parts(
    authoritative: dict[str, Any],
    candidate: dict[str, Any],
    *,
    limit: int,
) -> tuple[dict[str, Any], dict[str, Any], bool]:
    """Keep private comparison artifacts bounded before building large diffs."""

    # The mapper output normally stays well below this budget. For a malformed
    # sidecar response, avoid constructing a second full comparison object and
    # retain only an auditable digest plus small business summaries.
    candidate_budget = max(64 * 1024, limit // 2)
    if _bounded_json_size(candidate, candidate_budget) <= candidate_budget:
        return candidate, compare_document_records(authoritative, candidate), False
    compact = {
        "truncated": True,
        "reason": "candidate_exceeds_artifact_budget",
        "candidate_digest": _canonical_digest(candidate),
        "line_count": len(candidate.get("lines") or [])
        if isinstance(candidate.get("lines"), list)
        else None,
        "header": candidate.get("header")
        if isinstance(candidate.get("header"), dict)
        else {},
    }
    return (
        compact,
        {
            "truncated": True,
            "reason": "candidate_exceeds_artifact_budget",
            "authoritative_digest": _canonical_digest(authoritative),
            "candidate_digest": compact["candidate_digest"],
        },
        True,
    )


def _normalized(value: Any) -> str:
    return "".join(str(value or "").casefold().split())


def _source_reference_is_located(reference: Any) -> bool:
    if not isinstance(reference, dict):
        return False
    sheet = str(reference.get("sheet") or "").strip()
    cell = str(reference.get("cell") or "").strip()
    cell_range = str(reference.get("range") or "").strip()
    if sheet and (cell or cell_range):
        return True

    part = str(reference.get("part") or "").strip()
    if part == "word/document.xml" and (cell or cell_range):
        return True
    try:
        page = int(reference.get("page") or 0)
    except (TypeError, ValueError):
        return False
    if page <= 0:
        return False
    if _NATIVE_DOCX_PART.fullmatch(part) or _NATIVE_OOXML_PART.fullmatch(part):
        return True
    bbox = reference.get("bbox")
    return isinstance(bbox, list) and len(bbox) == 4


def _source_reference_coverage(candidate: dict[str, Any]) -> dict[str, int | float]:
    metadata = candidate.get("field_meta")
    metadata = metadata if isinstance(metadata, dict) else {}
    total = 0
    located = 0
    for path, item in metadata.items():
        if not isinstance(item, dict):
            continue
        # Explicit route hints are request provenance, not document-derived
        # facts. They intentionally have no page coordinates and must not
        # dilute the coverage of fields extracted from the source document.
        if (
            path in _EXTERNAL_CLASSIFICATION_PATHS
            and item.get("manual_locked") is True
            and item.get("classification_evidence_source") == "explicit_hint"
            and item.get("model_mapped") is False
            and item.get("inferred") is False
        ):
            continue
        total += 1
        references = item.get("source_refs")
        if not isinstance(references, list):
            continue
        if any(_source_reference_is_located(reference) for reference in references):
            located += 1
    return {
        "located": located,
        "total": total,
        "ratio": round(located / total, 6) if total else 1.0,
    }


def sanitized_comparison(
    baseline: dict[str, Any], candidate: dict[str, Any]
) -> dict[str, Any]:
    baseline_header = baseline.get("header")
    baseline_header = baseline_header if isinstance(baseline_header, dict) else {}
    candidate_header = candidate.get("header")
    candidate_header = candidate_header if isinstance(candidate_header, dict) else {}
    header_matches = {
        field: _normalized(baseline_header.get(field))
        == _normalized(candidate_header.get(field))
        for field in _HEADER_FIELDS
        if baseline_header.get(field) not in (None, "")
        or candidate_header.get(field) not in (None, "")
    }
    baseline_lines = [
        value for value in baseline.get("lines") or [] if isinstance(value, dict)
    ]
    candidate_lines = [
        value for value in candidate.get("lines") or [] if isinstance(value, dict)
    ]
    compared = 0
    matched = 0
    critical_line_field_matches: dict[str, bool] = {}
    if baseline_lines and candidate_lines:
        for field in ("line_no", "product_code", "name_raw", "quantity", "unit"):
            if baseline_lines[0].get(field) not in (None, ""):
                critical_line_field_matches[field] = _normalized(
                    baseline_lines[0].get(field)
                ) == _normalized(candidate_lines[0].get(field))
    for index in range(min(len(baseline_lines), len(candidate_lines))):
        fields = (
            set(baseline_lines[index]) | set(candidate_lines[index])
        ) - _LINE_COMPARE_EXCLUDED
        for field in fields:
            left = baseline_lines[index].get(field)
            right = candidate_lines[index].get(field)
            if left in (None, "", [], {}) and right in (None, "", [], {}):
                continue
            compared += 1
            matched += _normalized(left) == _normalized(right)
    return {
        "candidate_isolation": True,
        "classification_match": (
            baseline.get("document_type") == candidate.get("document_type")
            and baseline.get("document_subtype") == candidate.get("document_subtype")
        ),
        "header_field_matches": header_matches,
        "header_exact": {
            "matched": sum(header_matches.values()),
            "total": len(header_matches),
        },
        "line_count": {
            "authoritative": len(baseline_lines),
            "mineru": len(candidate_lines),
        },
        "line_field_exact": {
            "matched": matched,
            "total": compared,
            "ratio": round(matched / compared, 6) if compared else None,
        },
        "first_line_critical_matches": critical_line_field_matches,
        "source_reference_coverage": _source_reference_coverage(candidate),
        "authoritative_digest": _canonical_digest(baseline),
        "candidate_digest": _canonical_digest(candidate),
    }


@dataclass(slots=True)
class MinerUCandidateRunResult:
    """One inline MinerU candidate, before any authority decision is made."""

    document: DocumentRecord
    summary: dict[str, Any]
    plan: MinerUBusinessPlan


class MinerUShadowRunner(MinerUShadowLifecycleMixin):
    """Run the retained MinerU candidate lifecycle in its configured authority mode."""

    supported_file_types: ClassVar[set[str]] = {
        "pdf",
        "docx",
        "pptx",
        "xlsx",
        "xls",
        "xlsm",
        "csv",
        "html",
        "image",
        "dxf",
        "dwg",
    }

    def __init__(
        self,
        *,
        client: MinerUClient,
        mapper: MinerUBusinessMapper | None = None,
        instructor_service: MinerUInstructorService | None = None,
        output_dir: str | Path,
        required: bool = False,
        authority_mode: str = "shadow",
        max_concurrency: int = 1,
        max_pending: int = 32,
        max_queued_bytes: int = _DEFAULT_MAX_QUEUED_BYTES,
        artifact_retention_seconds: int = 7 * 24 * 60 * 60,
        artifact_max_bytes: int = _MAX_ARTIFACT_BYTES_HARD,
        document_circuit_failures: int = 3,
        document_circuit_seconds: float = 300.0,
        input_normalizer: MinerUInputNormalizer | None = None,
    ) -> None:
        self.client = client
        self.mapper = mapper
        self.instructor_service = instructor_service
        self.input_normalizer = input_normalizer or MinerUInputNormalizer()
        self.output_dir = Path(output_dir)
        self.required = bool(required)
        normalized_authority_mode = str(authority_mode or "shadow").strip().casefold()
        if normalized_authority_mode not in {"shadow", "guarded", "full"}:
            raise ValueError("MinerU authority mode must be shadow, guarded, or full")
        self.authority_mode = normalized_authority_mode
        if self.authority_mode == "full" and self.instructor_service is None:
            raise ValueError("full MinerU authority requires an Instructor service")
        if self.authority_mode != "full" and self.mapper is None:
            raise ValueError(
                "shadow and guarded MinerU modes require a business mapper"
            )
        self._semaphore = asyncio.Semaphore(max(1, int(max_concurrency)))
        self.max_pending = max(1, int(max_pending))
        self.max_queued_bytes = max(1024 * 1024, int(max_queued_bytes))
        self.artifact_retention_seconds = max(60, int(artifact_retention_seconds))
        self.artifact_max_bytes = min(
            _MAX_ARTIFACT_BYTES_HARD,
            max(1024 * 1024, int(artifact_max_bytes)),
        )
        self.document_circuit_failures = max(1, int(document_circuit_failures))
        self.document_circuit_seconds = max(0.1, float(document_circuit_seconds))
        self._background_tasks: dict[str, asyncio.Task[dict[str, Any]]] = {}
        self._scheduled_jobs: dict[str, _ShadowJob] = {}
        self._queued_snapshot_bytes: dict[str, int] = {}
        # A task may have more than one in-flight executor write (for example,
        # a retry racing a shutdown).  Tracking a set avoids waiting for only
        # the last future and lets a late writer observe the tombstone fence.
        self._artifact_writers: dict[str, set[asyncio.Future[Any]]] = {}
        self._artifact_lock = threading.RLock()
        self._writer_context = threading.local()
        self._deleted_tasks: set[str] = set()
        self._task_generations: dict[str, int] = {}
        self._calls = 0
        self._successes = 0
        self._failures = 0
        self._last_success_at = ""
        self._last_failure_at = ""
        self._last_error_type = ""
        self._parser_ready = False
        self._mapper_ready = False
        self._last_parser_probe_at = ""
        self._last_mapper_probe_at = ""
        self._last_probe_error_type = ""
        self._document_failures = 0
        self._last_document_failure_at = ""
        self._last_document_error_type = ""
        self._consecutive_document_system_failures = 0
        self._document_system_failures = 0
        self._last_document_system_failure_at = ""
        self._last_document_system_error_type = ""
        self._document_circuit_open_until = 0.0
        self._document_circuit_opened_at = ""
        self._document_circuit_half_open = False
        self._last_artifact = ""
        self._pruned_artifacts = 0
        self._completion_sink: (
            Callable[[str, dict[str, Any]], Awaitable[Any]] | None
        ) = None
        self._completion_pending: dict[str, dict[str, Any]] = {}
        self._completion_attempts: dict[str, int] = {}
        self._completion_retry_tasks: dict[str, asyncio.Task[None]] = {}
        self._completion_terminal_ids: set[str] = set()
        self._completion_failures = 0
        self._completion_successes = 0
        self._completion_terminal_failures = 0
        self._last_completion_error_type = ""
        self._completion_recovery_task: asyncio.Task[None] | None = None
        self._job_recovery_task: asyncio.Task[None] | None = None
        self._completion_inflight: set[str] = set()
        self._completion_locks: dict[str, asyncio.Lock] = {}
        self._completion_recovery_runs = 0
        self._last_completion_recovery_at = ""
        self._closing = False

    async def probe(self) -> dict[str, Any]:
        from .mineru import MinerUContractError

        self._last_parser_probe_at = self._timestamp()
        try:
            health = await self.client.probe()
            upstream_status = str(health.get("status") or "")
            version = str(health.get("version") or "")
            protocol = health.get("protocol_version")
            try:
                protocol_number = int(protocol)
            except (TypeError, ValueError):
                protocol_number = -1
            if (
                upstream_status != "healthy"
                or version != self.client.backend_version
                or protocol_number != 2
            ):
                raise MinerUContractError(
                    "unsupported MinerU health contract "
                    f"status={upstream_status} version={version} "
                    f"protocol={protocol}"
                )
        except Exception as exc:
            self._parser_ready = False
            self._last_probe_error_type = exc.__class__.__name__
            raise
        self._parser_ready = True

        self._last_mapper_probe_at = self._timestamp()
        candidate_owner = (
            self.instructor_service if self.authority_mode == "full" else self.mapper
        )
        if candidate_owner is None:
            raise RuntimeError("MinerU candidate service is not configured")
        try:
            mapper_probe = getattr(candidate_owner, "probe", None)
            if callable(mapper_probe):
                mapper_health = mapper_probe()
                if inspect.isawaitable(mapper_health):
                    mapper_health = await mapper_health
            else:
                mapper_status = getattr(candidate_owner, "status", None)
                mapper_health = mapper_status() if callable(mapper_status) else {}
            if not isinstance(mapper_health, dict):
                mapper_health = {}
            explicit_ready = mapper_health.get("ready")
            mapper_status_value = str(mapper_health.get("status") or "").casefold()
            if explicit_ready is False or mapper_status_value in {
                "failed",
                "unavailable",
                "unhealthy",
            }:
                raise RuntimeError("MinerU mapper is unavailable")
        except Exception as exc:
            self._mapper_ready = False
            self._last_probe_error_type = exc.__class__.__name__
            raise
        self._mapper_ready = True
        self._last_probe_error_type = ""
        self._record_document_health_success()
        result = dict(health)
        result["mapper"] = mapper_health
        runtime_status = self.status()
        result["ready"] = runtime_status["ready"]
        result["document_ready"] = runtime_status["document_ready"]
        return result

    def status(self) -> dict[str, Any]:
        circuit_open = self._document_circuit_is_open()
        document_ready = not circuit_open
        ready = (
            self._parser_ready
            and self._mapper_ready
            and (self.authority_mode != "full" or document_ready)
        )
        degraded = bool(not ready or self._consecutive_document_system_failures)
        client_status = getattr(self.client, "status", None)
        candidate_owner = (
            self.instructor_service if self.authority_mode == "full" else self.mapper
        )
        mapper_status = getattr(candidate_owner, "status", None)
        return {
            "enabled": True,
            "required": self.required,
            "authority_mode": self.authority_mode,
            "ready": ready,
            "degraded": degraded,
            "status": "degraded" if degraded else "ready",
            "parser_ready": self._parser_ready,
            "mapper_ready": self._mapper_ready,
            "document_ready": document_ready,
            "last_parser_probe_at": self._last_parser_probe_at or None,
            "last_mapper_probe_at": self._last_mapper_probe_at or None,
            "last_probe_error_type": self._last_probe_error_type or None,
            "calls": self._calls,
            "successes": self._successes,
            "failures": self._failures,
            "document_failures": self._document_failures,
            "last_document_failure_at": self._last_document_failure_at or None,
            "last_document_error_type": self._last_document_error_type or None,
            "document_system_failures": self._document_system_failures,
            "consecutive_document_system_failures": (
                self._consecutive_document_system_failures
            ),
            "last_document_system_failure_at": (
                self._last_document_system_failure_at or None
            ),
            "last_document_system_error_type": (
                self._last_document_system_error_type or None
            ),
            "document_circuit_open": circuit_open,
            "document_circuit_half_open": self._document_circuit_half_open,
            "document_circuit_failures": self.document_circuit_failures,
            "document_circuit_seconds": self.document_circuit_seconds,
            "document_circuit_opened_at": self._document_circuit_opened_at or None,
            "document_circuit_remaining_seconds": (
                round(max(0.0, self._document_circuit_open_until - time.monotonic()), 3)
                if circuit_open
                else 0.0
            ),
            "success_rate": (
                round(self._successes / self._calls, 6) if self._calls else None
            ),
            "in_flight": 1 if self._semaphore.locked() else 0,
            "pending": len(self._background_tasks),
            "max_pending": self.max_pending,
            "pending_bytes": sum(self._queued_snapshot_bytes.values()),
            "max_pending_bytes": self.max_queued_bytes,
            "artifact_retention_seconds": self.artifact_retention_seconds,
            "artifact_max_bytes": self.artifact_max_bytes,
            "pruned_artifacts": self._pruned_artifacts,
            "last_success_at": self._last_success_at or None,
            "last_failure_at": self._last_failure_at or None,
            "last_error_type": self._last_error_type or None,
            "last_artifact": self._last_artifact or None,
            "completion_pending": len(self._completion_pending),
            "completion_attempts": sum(self._completion_attempts.values()),
            "completion_failures": self._completion_failures,
            "completion_successes": self._completion_successes,
            "completion_terminal_failures": len(self._completion_terminal_ids),
            "completion_last_error_type": (self._last_completion_error_type or None),
            "completion_recovery_runs": self._completion_recovery_runs,
            "completion_last_recovery_at": (self._last_completion_recovery_at or None),
            "client": client_status() if callable(client_status) else {},
            "mapper": mapper_status() if callable(mapper_status) else {},
            "candidate_pipeline": (
                "mineru_instructor"
                if self.authority_mode == "full"
                else "mineru_business_mapper"
            ),
        }

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(UTC).isoformat()

    @staticmethod
    def _artifact_name(task_id: str) -> str:
        safe_task = re.sub(r"[^A-Za-z0-9._-]", "_", task_id)[:120] or "task"
        return f"{safe_task}.json"

    @staticmethod
    def _is_document_system_failure(exc: Exception) -> bool:
        # Invalid/corrupt user input is task-local.  Service, mapper, timeout,
        # renderer availability, and output-contract failures indicate that
        # full authority cannot currently be trusted for the next document.
        if isinstance(exc, (MinerUInputContractError, FileNotFoundError)):
            return False
        if isinstance(exc, _ArtifactDeleted):
            return False
        return not isinstance(exc, MinerUCADRendererRequired)

    def _document_circuit_is_open(self) -> bool:
        if self._document_circuit_open_until <= 0:
            return False
        if time.monotonic() < self._document_circuit_open_until:
            return True
        # The cooldown admits one normal request as a half-open probe. The
        # runner semaphore keeps full-authority inference serialized.
        self._document_circuit_open_until = 0.0
        self._document_circuit_half_open = True
        self._consecutive_document_system_failures = max(
            0,
            self.document_circuit_failures - 1,
        )
        return False

    def _record_document_health_success(self) -> None:
        self._consecutive_document_system_failures = 0
        self._last_document_system_error_type = ""
        self._document_circuit_open_until = 0.0
        self._document_circuit_opened_at = ""
        self._document_circuit_half_open = False

    def _record_document_health_failure(self, exc: Exception) -> None:
        if not self._is_document_system_failure(exc):
            return
        self._document_system_failures += 1
        self._consecutive_document_system_failures += 1
        self._last_document_system_failure_at = self._timestamp()
        self._last_document_system_error_type = exc.__class__.__name__
        if (
            self._consecutive_document_system_failures
            >= self.document_circuit_failures
        ):
            self._document_circuit_open_until = (
                time.monotonic() + self.document_circuit_seconds
            )
            self._document_circuit_opened_at = self._last_document_system_failure_at
            self._document_circuit_half_open = False

    async def delete_artifact(self, task_id: str) -> bool:
        """Remove a private candidate when its governed task is deleted."""

        # Mark the task before cancelling anything.  A writer already running
        # in an executor will see the tombstone before its final os.replace.
        with self._artifact_lock:
            self._deleted_tasks.add(task_id)
            self._task_generations[task_id] = self._task_generations.get(task_id, 0) + 1
        job = self._scheduled_jobs.get(task_id)
        retry = self._completion_retry_tasks.pop(task_id, None)
        if retry is not None and not retry.done():
            retry.cancel()
            await asyncio.gather(retry, return_exceptions=True)
        pending = self._background_tasks.get(task_id)
        if pending is not None and not pending.done():
            pending.cancel()
            await asyncio.gather(pending, return_exceptions=True)
        await self._wait_for_task_writers(task_id)
        delivery_lock = self._completion_locks.get(task_id)
        if delivery_lock is not None:
            async with delivery_lock:
                pass
        self._queued_snapshot_bytes.pop(task_id, None)
        self._scheduled_jobs.pop(task_id, None)
        self._completion_pending.pop(task_id, None)
        self._completion_attempts.pop(task_id, None)
        self._completion_terminal_ids.discard(task_id)
        self._completion_locks.pop(task_id, None)
        removed = await asyncio.to_thread(self._remove_task_files, task_id)
        if job is not None:
            removed = (
                await asyncio.to_thread(self._remove_snapshot_file, job.snapshot_path)
                or removed
            )
        return removed

    def _remove_task_files(self, task_id: str) -> bool:
        return any(
            (
                self._remove_artifact_files(task_id),
                self._remove_snapshot_files(task_id),
                self._remove_completion_file(task_id),
            )
        )

    def _remove_artifact_files(self, task_id: str) -> bool:
        target = self.output_dir / self._artifact_name(task_id)
        removed = False
        with self._artifact_lock:
            for path in (
                target,
                target.with_suffix(".json.tmp"),
                *target.parent.glob(f".{target.name}.*.tmp"),
            ):
                try:
                    path.unlink()
                    removed = True
                except FileNotFoundError:
                    continue
        return removed

    def schedule(self, **kwargs: Any) -> dict[str, Any]:
        """Queue one bounded candidate without delaying authoritative persistence."""

        task_id = str(kwargs.get("task_id") or "")
        file_type = str(kwargs.get("file_type") or "")
        if not task_id:
            return {
                "status": "skipped",
                "reason": "missing_task_id",
                "candidate_isolation": True,
            }
        if self._closing:
            return {
                "status": "skipped",
                "reason": "runner_closing",
                "task_id": task_id,
                "candidate_isolation": True,
            }
        if task_id in self._deleted_tasks:
            return {
                "status": "skipped",
                "reason": "task_deleted",
                "task_id": task_id,
                "candidate_isolation": True,
            }
        if file_type not in self.supported_file_types:
            return {
                "status": "skipped",
                "reason": "unsupported_file_type",
                "file_type": file_type,
                "candidate_isolation": True,
            }
        current = self._background_tasks.get(task_id)
        if current is not None and not current.done():
            return {
                "status": "queued",
                "reason": "already_queued",
                "task_id": task_id,
                "candidate_isolation": True,
                "pending": len(self._background_tasks),
            }
        if len(self._background_tasks) >= self.max_pending:
            return {
                "status": "skipped",
                "reason": "queue_full",
                "task_id": task_id,
                "candidate_isolation": True,
                "pending": len(self._background_tasks),
            }
        authoritative = kwargs.get("authoritative") or {}
        if not isinstance(authoritative, dict):
            return {
                "status": "skipped",
                "reason": "invalid_authoritative_snapshot",
                "task_id": task_id,
                "candidate_isolation": True,
            }
        snapshot_bytes = _bounded_json_size(authoritative, self.max_queued_bytes)
        if snapshot_bytes > self.max_queued_bytes:
            return {
                "status": "skipped",
                "reason": "authoritative_snapshot_too_large",
                "task_id": task_id,
                "candidate_isolation": True,
                "max_pending_bytes": self.max_queued_bytes,
            }
        pending_bytes = sum(self._queued_snapshot_bytes.values())
        if pending_bytes + snapshot_bytes > self.max_queued_bytes:
            return {
                "status": "skipped",
                "reason": "queue_bytes_full",
                "task_id": task_id,
                "candidate_isolation": True,
                "pending_bytes": pending_bytes,
                "max_pending_bytes": self.max_queued_bytes,
            }
        generation = self._next_generation(task_id)
        try:
            job = self._persist_job_snapshot(
                task_id=task_id,
                generation=generation,
                path=str(kwargs.get("path") or ""),
                original_filename=(
                    str(kwargs["original_filename"])
                    if kwargs.get("original_filename") is not None
                    else None
                ),
                file_type=file_type,
                authoritative=authoritative,
                document_type_hint=(
                    str(kwargs["document_type_hint"])
                    if kwargs.get("document_type_hint") is not None
                    else None
                ),
                document_subtype_hint=(
                    str(kwargs["document_subtype_hint"])
                    if kwargs.get("document_subtype_hint") is not None
                    else None
                ),
            )
        except _SnapshotTooLarge:
            return {
                "status": "skipped",
                "reason": "authoritative_snapshot_too_large",
                "task_id": task_id,
                "candidate_isolation": True,
                "max_pending_bytes": self.max_queued_bytes,
            }
        except _ArtifactDeleted:
            return {
                "status": "skipped",
                "reason": "task_deleted",
                "task_id": task_id,
                "candidate_isolation": True,
            }
        self._start_job(job)
        return {
            "status": "queued",
            "task_id": task_id,
            "candidate_isolation": True,
            "pending": len(self._background_tasks),
            "pending_bytes": sum(self._queued_snapshot_bytes.values()),
        }

    async def _execute_candidate(
        self,
        *,
        task_id: str,
        tenant_id: str = "default",
        routing_attempt: int = 0,
        path: str | Path,
        original_filename: str | None,
        file_type: str,
        authoritative: dict[str, Any],
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUCandidateRunResult:
        started = time.monotonic()
        if task_id in self._deleted_tasks:
            raise _ArtifactDeleted(task_id)
        async with self._semaphore:
            if task_id in self._deleted_tasks:
                raise _ArtifactDeleted(task_id)
            if self.authority_mode == "full":
                service = self.instructor_service
                if service is None:
                    raise RuntimeError("full MinerU authority service is unavailable")
                service_kwargs: dict[str, Any] = {
                    "original_filename": original_filename,
                }
                if document_type_hint is not None:
                    service_kwargs["document_type_hint"] = document_type_hint
                if document_subtype_hint is not None:
                    service_kwargs["document_subtype_hint"] = document_subtype_hint
                routing_kwargs = {
                    "tenant_id": tenant_id,
                    "task_id": task_id,
                    "source_kind": file_type,
                    "routing_attempt": routing_attempt,
                }
                if route_plan is not None:
                    routing_kwargs["route_plan"] = route_plan
                if semantic_execution is not None:
                    routing_kwargs["semantic_execution"] = semantic_execution
                try:
                    parameters = inspect.signature(service.run).parameters.values()
                except (TypeError, ValueError):
                    parameters = ()
                if not any(
                    parameter.kind is inspect.Parameter.VAR_KEYWORD
                    for parameter in parameters
                ):
                    accepted = {parameter.name for parameter in parameters}
                    routing_kwargs = {
                        key: value
                        for key, value in routing_kwargs.items()
                        if key in accepted
                    }
                service_result = await service.run(
                    path,
                    **service_kwargs,
                    **routing_kwargs,
                )
                if task_id in self._deleted_tasks:
                    raise _ArtifactDeleted(task_id)
                return self._instructor_full_result(
                    task_id=task_id,
                    authoritative=authoritative,
                    service_result=service_result,
                    started=started,
                )
            with self.input_normalizer.prepare(
                path,
                original_filename=original_filename,
                file_type=file_type,
            ) as normalized:
                if not normalized.ready or normalized.path is None:
                    raise MinerUInputContractError(
                        "MINERU_ARCHIVE_RECURSION_REQUIRED: ingest archive members "
                        "as child documents before MinerU mapping"
                    )
                parsed = await self.client.parse(
                    normalized.path,
                    original_filename=normalized.upload_filename,
                )
                parsed.evidence.raw["input_normalization"] = normalized.metadata
                self._parser_ready = True
                if task_id in self._deleted_tasks:
                    raise _ArtifactDeleted(task_id)
                if self.mapper is None:
                    raise RuntimeError("MinerU business mapper is unavailable")
                mapped = await map_mineru_candidate(
                    mapper=self.mapper,
                    path=path,
                    original_filename=original_filename,
                    evidence=parsed.evidence,
                    document_type_hint=document_type_hint,
                    document_subtype_hint=document_subtype_hint,
                    strict_record_regions=self.authority_mode == "full",
                )
                mapped.document = _bind_spreadsheet_source_refs(
                    mapped.document,
                    normalized.metadata,
                )
                mapped.document.extraction.setdefault("metadata", {})[
                    "mineru_input"
                ] = normalized.metadata
                self._mapper_ready = True
                if task_id in self._deleted_tasks:
                    raise _ArtifactDeleted(task_id)
        if task_id in self._deleted_tasks:
            raise _ArtifactDeleted(task_id)
        candidate = mapped.document.model_dump(mode="json")
        summary = sanitized_comparison(authoritative, candidate)
        total_elapsed_ms = round((time.monotonic() - started) * 1000.0, 3)
        summary.update(
            {
                "status": "completed",
                "task_id": task_id,
                "mineru_task_id": parsed.task_id,
                "backend": parsed.evidence.backend,
                "backend_version": parsed.evidence.backend_version,
                "model_revision": self.client.model_revision,
                "mineru_elapsed_ms": round(parsed.elapsed_ms, 3),
                "mapper_elapsed_ms": round(mapped.mapper_duration_seconds * 1000.0, 3),
                "total_elapsed_ms": total_elapsed_ms,
                "mapper_requests": int(mapped.mapper_usage.get("requests") or 0),
                "mapper_repaired_mappings": int(
                    mapped.mapper_usage.get("repaired_mappings") or 0
                ),
                # The legacy aliases represent final unresolved drops. Initial
                # drops remain visible separately when a bounded replan repairs
                # them completely.
                "mapper_initial_dropped_mappings": _mapper_usage_count(
                    mapped.mapper_usage,
                    "initial_dropped_mappings",
                    "dropped_mappings",
                ),
                "mapper_initial_dropped_tables": _mapper_usage_count(
                    mapped.mapper_usage,
                    "initial_dropped_tables",
                    "dropped_tables",
                ),
                "mapper_unresolved_dropped_mappings": _mapper_usage_count(
                    mapped.mapper_usage,
                    "unresolved_dropped_mappings",
                    "dropped_mappings",
                ),
                "mapper_unresolved_dropped_tables": _mapper_usage_count(
                    mapped.mapper_usage,
                    "unresolved_dropped_tables",
                    "dropped_tables",
                ),
                "mapper_dropped_mappings": _mapper_usage_count(
                    mapped.mapper_usage,
                    "unresolved_dropped_mappings",
                    "dropped_mappings",
                ),
                "mapper_dropped_tables": _mapper_usage_count(
                    mapped.mapper_usage,
                    "unresolved_dropped_tables",
                    "dropped_tables",
                ),
                "mapper_dropped_facts": int(
                    mapped.mapper_usage.get("dropped_facts") or 0
                ),
                "mapper_empty_facts": int(mapped.mapper_usage.get("empty_facts") or 0),
                "mapper_invalid_facts": int(
                    mapped.mapper_usage.get("invalid_facts") or 0
                ),
                "rejected_citations": mapped.rejected_citations,
                "input_normalization": normalized.metadata,
                "record_region_assessment": (
                    {
                        **mapped.record_region_assessment.model_dump(mode="json"),
                        "summary": mapped.record_region_assessment.summary(),
                        **mapped.record_region_bindings.summary(),
                    }
                    if mapped.record_region_assessment is not None
                    and mapped.record_region_bindings is not None
                    else None
                ),
            }
        )
        return MinerUCandidateRunResult(
            document=mapped.document,
            summary=summary,
            plan=mapped.plan,
        )

    def _instructor_full_result(
        self,
        *,
        task_id: str,
        authoritative: dict[str, Any],
        service_result: MinerUInstructorServiceResult,
        started: float,
    ) -> MinerUCandidateRunResult:
        document = service_result.document.model_copy(deep=True)
        input_normalization = service_result.payload.get("input_normalization")
        if not isinstance(input_normalization, dict):
            input_normalization = {}
        document.extraction.setdefault("metadata", {})["mineru_input"] = copy.deepcopy(
            input_normalization
        )
        candidate = document.model_dump(mode="json")
        summary = sanitized_comparison(authoritative, candidate)
        summary.update(copy.deepcopy(service_result.summary))
        summary.update(
            {
                "status": "completed",
                "task_id": task_id,
                "candidate_isolation": False,
                "model_revision": self.client.model_revision,
                "total_elapsed_ms": round((time.monotonic() - started) * 1000.0, 3),
                "input_normalization": copy.deepcopy(input_normalization),
                "source_reference_coverage": _source_reference_coverage(candidate),
            }
        )
        try:
            plan = MinerUBusinessPlan(
                document_type=document.document_type,
                document_subtype=document.document_subtype,
            )
        except Exception:  # noqa: BLE001 - invalid classification falls back to unknown
            plan = MinerUBusinessPlan()
        self._parser_ready = True
        self._mapper_ready = True
        return MinerUCandidateRunResult(
            document=document,
            summary=summary,
            plan=plan,
        )

    async def run_candidate(
        self,
        *,
        task_id: str,
        tenant_id: str = "default",
        routing_attempt: int = 0,
        path: str | Path,
        original_filename: str | None,
        file_type: str,
        authoritative: dict[str, Any],
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> MinerUCandidateRunResult:
        """Run one candidate inline for a guarded authority decision."""

        if task_id in self._deleted_tasks:
            raise _ArtifactDeleted(task_id)
        if file_type not in self.supported_file_types:
            raise ValueError(f"unsupported MinerU file type: {file_type}")
        self._calls += 1
        self._ensure_generation(task_id)
        timeout_seconds = float(getattr(self.client, "timeout_seconds", 240.0))
        if self.authority_mode == "full" and self.instructor_service is not None:
            timeout_seconds = float(
                getattr(
                    self.instructor_service,
                    "total_timeout_seconds",
                    timeout_seconds,
                )
            )
        try:
            result = await asyncio.wait_for(
                self._execute_candidate(
                    task_id=task_id,
                    tenant_id=tenant_id,
                    routing_attempt=routing_attempt,
                    path=path,
                    original_filename=original_filename,
                    file_type=file_type,
                    authoritative=authoritative,
                    document_type_hint=document_type_hint,
                    document_subtype_hint=document_subtype_hint,
                    route_plan=route_plan,
                    semantic_execution=semantic_execution,
                ),
                timeout=timeout_seconds,
            )
            self._successes += 1
            self._last_success_at = self._timestamp()
            self._last_error_type = ""
            self._last_document_error_type = ""
            self._record_document_health_success()
            return result
        except Exception as exc:
            self._failures += 1
            self._document_failures += 1
            self._last_failure_at = self._timestamp()
            self._last_error_type = exc.__class__.__name__
            self._last_document_failure_at = self._last_failure_at
            self._last_document_error_type = exc.__class__.__name__
            self._record_document_health_failure(exc)
            raise

    async def run(
        self,
        *,
        task_id: str,
        tenant_id: str = "default",
        routing_attempt: int = 0,
        path: str | Path,
        original_filename: str | None,
        file_type: str,
        authoritative: dict[str, Any],
        document_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        route_plan: DocumentRoutePlan | None = None,
        semantic_execution: SemanticExecutionSpec | None = None,
    ) -> dict[str, Any]:
        if task_id in self._deleted_tasks:
            return {
                "status": "skipped",
                "reason": "task_deleted",
                "task_id": task_id,
                "candidate_isolation": True,
            }
        if file_type not in self.supported_file_types:
            return {
                "status": "skipped",
                "reason": "unsupported_file_type",
                "file_type": file_type,
                "candidate_isolation": True,
            }
        self._calls += 1
        self._ensure_generation(task_id)
        try:
            result = await self._execute_candidate(
                task_id=task_id,
                tenant_id=tenant_id,
                routing_attempt=routing_attempt,
                path=path,
                original_filename=original_filename,
                file_type=file_type,
                authoritative=authoritative,
                document_type_hint=document_type_hint,
                document_subtype_hint=document_subtype_hint,
                route_plan=route_plan,
                semantic_execution=semantic_execution,
            )
            candidate = result.document.model_dump(mode="json")
            summary = result.summary
            artifact_candidate, comparison, artifact_truncated = (
                _bounded_artifact_parts(
                    authoritative,
                    candidate,
                    limit=self.artifact_max_bytes,
                )
            )
            if artifact_truncated:
                summary["artifact_truncated"] = True
            detailed = {
                "schema_version": "m1.mineru-shadow.v1",
                "created_at": self._timestamp(),
                "task_id": task_id,
                "source_sha256": authoritative.get("source", {}).get("sha256"),
                "summary": summary,
                "plan": result.plan.model_dump(mode="json"),
                "candidate": artifact_candidate,
                # The full comparison is intentionally confined to this private
                # artifact. Runtime document metadata receives only ``summary``.
                "comparison": comparison,
            }
            artifact = await self._write_artifact_async(task_id, detailed)
            summary["artifact"] = artifact.name
            self._last_artifact = artifact.name
            self._successes += 1
            self._last_success_at = self._timestamp()
            self._last_error_type = ""
            self._last_document_error_type = ""
            self._record_document_health_success()
            return summary
        except Exception as exc:
            self._failures += 1
            self._document_failures += 1
            self._last_failure_at = self._timestamp()
            self._last_error_type = exc.__class__.__name__
            self._last_document_failure_at = self._last_failure_at
            self._last_document_error_type = exc.__class__.__name__
            self._record_document_health_failure(exc)
            raise

    async def _write_artifact_async(
        self, task_id: str, payload: dict[str, Any]
    ) -> Path:
        """Track the executor future so deletion can wait for the real writer."""

        loop = asyncio.get_running_loop()
        generation = self._ensure_generation(task_id)

        def write() -> Path:
            self._writer_context.generation = generation
            try:
                return self._write_artifact(task_id, payload)
            finally:
                try:
                    del self._writer_context.generation
                except AttributeError:
                    pass

        writer = loop.run_in_executor(None, write)
        with self._artifact_lock:
            self._artifact_writers.setdefault(task_id, set()).add(writer)

        def finished(completed: asyncio.Future[Any]) -> None:
            with self._artifact_lock:
                writers = self._artifact_writers.get(task_id)
                if writers is None:
                    return
                writers.discard(completed)
                if not writers:
                    self._artifact_writers.pop(task_id, None)

        writer.add_done_callback(finished)
        return await asyncio.shield(writer)

    def _write_artifact(self, task_id: str, payload: dict[str, Any]) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.output_dir, 0o700)
        except OSError:
            pass
        target = self.output_dir / self._artifact_name(task_id)
        context_generation = getattr(self._writer_context, "generation", None)
        generation = int(
            context_generation
            if context_generation is not None
            else self._ensure_generation(task_id)
        )
        temporary = target.with_name(
            f".{target.name}.{generation}.{threading.get_ident()}.tmp"
        )
        committed = False
        try:
            encoder = json.JSONEncoder(
                ensure_ascii=False,
                indent=2,
                default=str,
            )
            total = 0
            with temporary.open("w", encoding="utf-8") as stream:
                for chunk in encoder.iterencode(payload):
                    total += len(chunk.encode("utf-8"))
                    if total > self.artifact_max_bytes:
                        raise ValueError(
                            "MinerU shadow artifact exceeds configured size quota"
                        )
                    stream.write(chunk)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.chmod(temporary, 0o600)
            except OSError:
                pass
            with self._artifact_lock:
                if not self._generation_is_current(task_id, generation):
                    raise _ArtifactDeleted(task_id)
                os.replace(temporary, target)
                self._pruned_artifacts += self._prune_artifacts(current=target)
                committed = True
                return target
        finally:
            if not committed:
                temporary.unlink(missing_ok=True)

    def _prune_artifacts(self, *, current: Path) -> int:
        cutoff = time.time() - self.artifact_retention_seconds
        retained: list[tuple[float, int, Path]] = []
        removed = 0
        temporary_files = (
            *self.output_dir.glob("*.json.tmp"),
            *self.output_dir.glob(".*.json.*.tmp"),
        )
        for temporary in temporary_files:
            try:
                stat = temporary.stat()
            except FileNotFoundError:
                continue
            if temporary.is_symlink() or stat.st_mtime < cutoff:
                temporary.unlink(missing_ok=True)
                removed += 1
        for artifact in self.output_dir.glob("*.json"):
            if artifact.is_symlink():
                artifact.unlink(missing_ok=True)
                removed += 1
                continue
            try:
                stat = artifact.stat()
            except FileNotFoundError:
                continue
            if artifact != current and stat.st_mtime < cutoff:
                artifact.unlink(missing_ok=True)
                removed += 1
                continue
            retained.append((stat.st_mtime, stat.st_size, artifact))
        total = sum(size for _mtime, size, _artifact in retained)
        for _mtime, size, artifact in sorted(retained):
            if total <= self.artifact_max_bytes:
                break
            if artifact == current:
                continue
            artifact.unlink(missing_ok=True)
            total -= size
            removed += 1
        return removed


def build_mineru_shadow_runner(
    settings: Any,
    *,
    field_semantic_router: Any | None = None,
    field_semantic_registry: Any | None = None,
) -> MinerUShadowRunner | None:
    if not bool(getattr(settings, "mineru_shadow_enabled", False)):
        return None
    base_url = str(getattr(settings, "mineru_base_url", "") or "").strip()
    mapper_base_url = str(getattr(settings, "mineru_mapper_base_url", "") or "").strip()
    mapper_model = str(getattr(settings, "mineru_mapper_model", "") or "").strip()
    if not base_url or not mapper_base_url or not mapper_model:
        raise ValueError(
            "enabled MinerU shadow requires base URL, mapper base URL, and mapper model"
        )
    authority_mode = str(getattr(settings, "mineru_authority_mode", "shadow"))
    normalized_authority_mode = authority_mode.strip().casefold()

    client = MinerUClient(
        base_url=base_url,
        backend=str(getattr(settings, "mineru_backend", "vlm-engine")),
        effort=str(getattr(settings, "mineru_effort", "high")),
        language=str(getattr(settings, "mineru_language", "ch")),
        image_analysis=bool(getattr(settings, "mineru_image_analysis", True)),
        timeout_seconds=float(getattr(settings, "mineru_timeout_seconds", 240.0)),
        poll_interval_seconds=float(
            getattr(settings, "mineru_poll_interval_seconds", 1.0)
        ),
        max_pages=int(getattr(settings, "mineru_max_pages", 200)),
        max_archive_bytes=int(
            getattr(settings, "mineru_max_archive_bytes", 64 * 1024 * 1024)
        ),
        max_uncompressed_bytes=int(
            getattr(settings, "mineru_max_uncompressed_bytes", 128 * 1024 * 1024)
        ),
        backend_version=str(getattr(settings, "mineru_version", "3.4.4")),
        model_revision=str(getattr(settings, "mineru_model_revision", "")),
    )
    normalizer = MinerUInputNormalizer()
    mapper: MinerUBusinessMapper | None = None
    instructor_service: MinerUInstructorService | None = None
    if normalized_authority_mode == "full":
        from .drawing_region_vlm import (
            DrawingRegionVLMConfig,
            DrawingRegionVLMExtractor,
        )
        from .mineru_instructor_poc import MinerUInstructorExtractor

        mapper_timeout = float(getattr(settings, "mineru_mapper_timeout_seconds", 60.0))
        instructor_max_input_chars = int(
            getattr(settings, "mineru_instructor_max_input_chars", 80_000)
        )
        instructor_segment_max_input_chars = int(
            getattr(
                settings,
                "mineru_instructor_segment_max_input_chars",
                80_000,
            )
        )
        extractor = MinerUInstructorExtractor.from_openai(
            base_url=mapper_base_url,
            api_key=str(getattr(settings, "mineru_mapper_api_key", "") or ""),
            model=mapper_model,
            timeout=mapper_timeout,
            temperature=0.0,
            max_tokens=int(getattr(settings, "mineru_mapper_max_tokens", 4096)),
            max_input_chars=instructor_max_input_chars,
            max_segment_input_chars=instructor_segment_max_input_chars,
            max_retries=int(getattr(settings, "mineru_instructor_max_retries", 2)),
            extra_body={},
            compact_intent=True,
            output_mode="prompted",
        )
        drawing_enabled = bool(
            getattr(settings, "mineru_drawing_region_vlm_enabled", True)
        )
        drawing_base_url = str(
            getattr(settings, "mineru_drawing_region_vlm_base_url", "") or ""
        ).strip()
        drawing_model = str(
            getattr(settings, "mineru_drawing_region_vlm_model", "") or ""
        ).strip()
        drawing_max_regions = int(
            getattr(settings, "mineru_drawing_region_vlm_max_regions", 16)
        )
        drawing_request_timeout = float(
            getattr(
                settings,
                "mineru_drawing_region_vlm_request_timeout_seconds",
                30.0,
            )
        )
        drawing_asset_timeout = float(
            getattr(
                settings,
                "mineru_drawing_region_vlm_asset_timeout_seconds",
                180.0,
            )
        )
        drawing_region = None
        if drawing_enabled:
            drawing_region = DrawingRegionVLMExtractor.from_openai(
                base_url=drawing_base_url,
                api_key=str(
                    getattr(settings, "mineru_drawing_region_vlm_api_key", "") or ""
                ),
                model=drawing_model,
                paddle_model_root=str(
                    getattr(
                        settings,
                        "paddleocr_vl_model_root",
                        "./data/paddlex",
                    )
                ),
                device=str(getattr(settings, "pp_structure_device", "cpu")),
                config=DrawingRegionVLMConfig(
                    max_candidates=drawing_max_regions,
                    request_timeout_seconds=drawing_request_timeout,
                ),
            )
        instructor_service = MinerUInstructorService(
            mineru=client,
            extractor=extractor,
            normalizer=normalizer,
            field_semantic_router=field_semantic_router,
            field_semantic_registry=field_semantic_registry,
            visual_assets_enabled=bool(
                getattr(settings, "mineru_visual_assets_enabled", True)
            ),
            visual_assets_max=int(getattr(settings, "mineru_visual_assets_max", 8)),
            visual_asset_max_bytes=int(
                getattr(settings, "mineru_visual_asset_max_bytes", 10 * 1024 * 1024)
            ),
            visual_asset_timeout_seconds=float(
                getattr(settings, "mineru_visual_asset_timeout_seconds", 180.0)
            ),
            drawing_region_vlm_enabled=drawing_enabled,
            drawing_region_vlm_extractor=drawing_region,
            drawing_region_vlm_max_regions=drawing_max_regions,
            drawing_region_vlm_timeout_seconds=drawing_asset_timeout,
            total_timeout_seconds=float(
                getattr(settings, "mineru_full_timeout_seconds", 600.0)
            ),
        )
    else:
        from ...structured_llm import StructuredModelClient

        model_client = StructuredModelClient(
            api_key=str(getattr(settings, "mineru_mapper_api_key", "") or ""),
            base_url=mapper_base_url,
            model=mapper_model,
            temperature=0.0,
            max_tokens=int(getattr(settings, "mineru_mapper_max_tokens", 4096)),
            enable_thinking=False,
            timeout=float(getattr(settings, "mineru_mapper_timeout_seconds", 60.0)),
            retries=1,
            output_mode="prompted",
            validation_retry_timeout_per_attempt=True,
        )
        mapper = MinerUBusinessMapper(
            client=model_client,
            model=mapper_model,
            max_input_chars=int(
                getattr(settings, "mineru_mapper_max_input_chars", 24_000)
            ),
        )
    return MinerUShadowRunner(
        client=client,
        mapper=mapper,
        instructor_service=instructor_service,
        input_normalizer=normalizer,
        output_dir=str(
            getattr(settings, "mineru_shadow_output_dir", "./data/mineru-shadow")
        ),
        required=bool(getattr(settings, "mineru_shadow_required", False)),
        authority_mode=authority_mode,
        max_concurrency=int(getattr(settings, "mineru_max_concurrency", 1)),
        max_pending=int(getattr(settings, "mineru_shadow_max_pending", 32)),
        artifact_retention_seconds=int(
            getattr(
                settings,
                "mineru_shadow_artifact_retention_seconds",
                7 * 24 * 60 * 60,
            )
        ),
        artifact_max_bytes=int(
            getattr(
                settings,
                "mineru_shadow_artifact_max_bytes",
                _MAX_ARTIFACT_BYTES_HARD,
            )
        ),
        document_circuit_failures=int(
            getattr(settings, "mineru_document_circuit_failures", 3)
        ),
        document_circuit_seconds=float(
            getattr(settings, "mineru_document_circuit_seconds", 300.0)
        ),
    )


__all__ = [
    "MinerUCandidateRunResult",
    "MinerUShadowRunner",
    "build_mineru_shadow_runner",
    "sanitized_comparison",
]
