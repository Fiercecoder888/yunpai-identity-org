"""Durable queue, completion, and restart lifecycle for MinerU shadow work."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import threading
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger

_COMPLETION_MAX_ATTEMPTS = 3
_COMPLETION_RETRY_DELAYS = (0.25, 0.5)
_COMPLETION_RECOVERY_INTERVAL_SECONDS = 30.0
_MAX_COMPLETION_BYTES = 1 * 1024 * 1024


class _ArtifactDeleted(RuntimeError):
    """The task was tombstoned while its private artifact was being written."""


class _SnapshotTooLarge(ValueError):
    """A queued authoritative snapshot exceeded the configured memory budget."""


@dataclass(frozen=True)
class _ShadowJob:
    """Small queue entry; the authoritative document lives in a bounded spool file."""

    task_id: str
    generation: int
    path: str
    original_filename: str | None
    file_type: str
    document_type_hint: str | None
    document_subtype_hint: str | None
    snapshot_path: Path
    snapshot_bytes: int


def _canonical_digest(value: Any) -> str:
    digest = hashlib.sha256()
    encoder = json.JSONEncoder(
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    for chunk in encoder.iterencode(value):
        digest.update(chunk.encode("utf-8"))
    return digest.hexdigest()


class MinerUShadowLifecycleMixin:
    """Internal durable lifecycle used by MinerUShadowRunner."""

    def set_completion_sink(
        self,
        sink: Callable[[str, dict[str, Any]], Awaitable[Any]],
    ) -> None:
        """Bind the task-state publisher after the runtime store is available."""

        self._completion_sink = sink
        # The workflow store is bound after construction.  Recover summaries
        # which were durably spooled by a prior process before accepting new
        # completions.  This is intentionally best-effort: the authoritative
        # task row remains queued until the sink acknowledges it.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        if (
            self._completion_recovery_task is None
            or self._completion_recovery_task.done()
        ):
            self._completion_recovery_task = loop.create_task(
                self._completion_recovery_loop(),
                name="m1-mineru-completion-recovery",
            )
        if self._job_recovery_task is None or self._job_recovery_task.done():
            self._job_recovery_task = loop.create_task(
                self._job_recovery_loop(),
                name="m1-mineru-job-recovery",
            )

    async def close(self) -> None:
        self._closing = True
        recovery_tasks = [
            task
            for task in (
                self._completion_recovery_task,
                self._job_recovery_task,
            )
            if task is not None and not task.done()
        ]
        self._completion_recovery_task = None
        self._job_recovery_task = None
        for task in recovery_tasks:
            task.cancel()
        if recovery_tasks:
            await asyncio.gather(*recovery_tasks, return_exceptions=True)
        retry_tasks = list(self._completion_retry_tasks.values())
        for task in retry_tasks:
            task.cancel()
        if retry_tasks:
            await asyncio.gather(*retry_tasks, return_exceptions=True)
        self._completion_retry_tasks.clear()

        pending = [
            (task_id, task)
            for task_id, task in self._background_tasks.items()
            if not task.done()
        ]
        for _task_id, task in pending:
            task.cancel()
        if pending:
            await asyncio.gather(
                *(task for _task_id, task in pending),
                return_exceptions=True,
            )
            for task_id, task in pending:
                if task.cancelled():
                    job = self._scheduled_jobs.get(task_id)
                    await self._publish_completion(
                        task_id,
                        {
                            "status": "queued",
                            "reason": "shutdown_interrupted",
                            "task_id": task_id,
                            "candidate_isolation": True,
                        },
                        generation=job.generation if job is not None else None,
                    )
        await self._wait_for_artifact_writers()
        self._background_tasks.clear()
        # Interrupted job snapshots intentionally remain on disk.  A new
        # process recovers them after the workflow store is rebound.
        self._scheduled_jobs.clear()
        self._queued_snapshot_bytes.clear()
        await self.client.close()
        closed: set[int] = set()
        for owner in (
            getattr(self, "instructor_service", None),
            getattr(self, "mapper", None),
        ):
            if owner is None or id(owner) in closed:
                continue
            closed.add(id(owner))
            close = getattr(owner, "close", None)
            if not callable(close):
                continue
            result = close()
            if inspect.isawaitable(result):
                await result

    async def _wait_for_artifact_writers(self) -> None:
        """Wait for executor writes before clients/store are torn down."""

        while True:
            with self._artifact_lock:
                writers = [
                    writer
                    for task_writers in self._artifact_writers.values()
                    for writer in task_writers
                    if not writer.done()
                ]
            if not writers:
                return
            await asyncio.gather(
                *(asyncio.shield(writer) for writer in writers),
                return_exceptions=True,
            )

    async def _wait_for_task_writers(self, task_id: str) -> None:
        while True:
            with self._artifact_lock:
                writers = [
                    writer
                    for writer in self._artifact_writers.get(task_id, set())
                    if not writer.done()
                ]
            if not writers:
                return
            await asyncio.gather(
                *(asyncio.shield(writer) for writer in writers),
                return_exceptions=True,
            )

    def _ensure_generation(self, task_id: str) -> int:
        with self._artifact_lock:
            generation = self._task_generations.get(task_id, 0)
            if generation <= 0:
                generation = 1
                self._task_generations[task_id] = generation
            return generation

    def _next_generation(self, task_id: str) -> int:
        with self._artifact_lock:
            generation = self._task_generations.get(task_id, 0) + 1
            self._task_generations[task_id] = generation
            return generation

    def _generation_is_current(self, task_id: str, generation: int) -> bool:
        return (
            task_id not in self._deleted_tasks
            and self._task_generations.get(task_id) == generation
        )

    def _snapshot_dir(self) -> Path:
        return self.output_dir / ".queue-pending"

    def _snapshot_path(self, task_id: str, generation: int) -> Path:
        safe = self._artifact_name(task_id).removesuffix(".json")
        suffix = hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:16]
        return self._snapshot_dir() / f"{safe}-{suffix}-{generation}.json"

    def _completion_dir(self) -> Path:
        return self.output_dir / ".completion-pending"

    def _completion_path(self, task_id: str) -> Path:
        # Include a digest so two task IDs which sanitize to the same filename
        # cannot overwrite one another.
        safe = self._artifact_name(task_id).removesuffix(".json")
        suffix = hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:16]
        return self._completion_dir() / f"{safe}-{suffix}.json"

    def _write_bounded_json_file(
        self,
        path: Path,
        value: Any,
        *,
        limit: int,
        indent: int | None = None,
        commit_guard: Callable[[], bool] | None = None,
    ) -> int:
        """Stream JSON to a private temp file and atomically replace it."""

        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(path.parent, 0o700)
        except OSError:
            pass
        temporary = path.with_name(
            f".{path.name}.{os.getpid()}.{threading.get_ident()}.{time.time_ns()}.tmp"
        )
        committed = False
        try:
            encoder = json.JSONEncoder(
                ensure_ascii=False,
                separators=(",", ":") if indent is None else None,
                indent=indent,
                default=str,
            )
            total = 0
            with temporary.open("w", encoding="utf-8") as stream:
                for chunk in encoder.iterencode(value):
                    total += len(chunk.encode("utf-8"))
                    if total > limit:
                        raise _SnapshotTooLarge(total)
                    stream.write(chunk)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.chmod(temporary, 0o600)
            except OSError:
                pass
            with self._artifact_lock:
                if commit_guard is not None and not commit_guard():
                    raise _ArtifactDeleted(str(path))
                os.replace(temporary, path)
            committed = True
            return total
        finally:
            if not committed:
                temporary.unlink(missing_ok=True)

    def _persist_job_snapshot(
        self,
        *,
        task_id: str,
        generation: int,
        path: str,
        original_filename: str | None,
        file_type: str,
        authoritative: dict[str, Any],
        document_type_hint: str | None,
        document_subtype_hint: str | None,
    ) -> _ShadowJob:
        snapshot_path = self._snapshot_path(task_id, generation)
        envelope = {
            "schema_version": "m1.mineru-shadow-job.v1",
            "task_id": task_id,
            "generation": generation,
            "path": path,
            "original_filename": original_filename,
            "file_type": file_type,
            "document_type_hint": document_type_hint,
            "document_subtype_hint": document_subtype_hint,
            "authoritative": authoritative,
        }
        snapshot_bytes = self._write_bounded_json_file(
            snapshot_path,
            envelope,
            limit=self.max_queued_bytes,
            commit_guard=lambda: self._generation_is_current(
                task_id, generation
            ),
        )
        return _ShadowJob(
            task_id=task_id,
            generation=generation,
            path=path,
            original_filename=original_filename,
            file_type=file_type,
            document_type_hint=document_type_hint,
            document_subtype_hint=document_subtype_hint,
            snapshot_path=snapshot_path,
            snapshot_bytes=snapshot_bytes,
        )

    def _read_snapshot_envelope(self, snapshot_path: Path) -> dict[str, Any]:
        if snapshot_path.is_symlink():
            raise ValueError("symlinked MinerU shadow job snapshot")
        if snapshot_path.stat().st_size > self.max_queued_bytes:
            raise _SnapshotTooLarge(snapshot_path.stat().st_size)
        envelope = json.loads(snapshot_path.read_text(encoding="utf-8"))
        if not isinstance(envelope, dict):
            raise ValueError("invalid MinerU shadow job snapshot")  # noqa: TRY004
        if envelope.get("schema_version") != "m1.mineru-shadow-job.v1":
            raise ValueError("unsupported MinerU shadow job snapshot")
        return envelope

    def _load_authoritative_snapshot(self, job: _ShadowJob) -> dict[str, Any]:
        envelope = self._read_snapshot_envelope(job.snapshot_path)
        if (
            str(envelope.get("task_id") or "") != job.task_id
            or int(envelope.get("generation") or 0) != job.generation
        ):
            raise ValueError("MinerU shadow job identity mismatch")
        authoritative = envelope.get("authoritative")
        if not isinstance(authoritative, dict):
            raise ValueError(  # noqa: TRY004
                "MinerU shadow job has no authoritative snapshot"
            )
        return authoritative

    def _job_from_snapshot(self, snapshot_path: Path) -> _ShadowJob:
        envelope = self._read_snapshot_envelope(snapshot_path)
        task_id = str(envelope.get("task_id") or "")
        path = str(envelope.get("path") or "")
        file_type = str(envelope.get("file_type") or "")
        generation = int(envelope.get("generation") or 0)
        if not task_id or not path or generation <= 0:
            raise ValueError("incomplete MinerU shadow job snapshot")
        if file_type not in self.supported_file_types:
            raise ValueError("unsupported file type in MinerU shadow job snapshot")
        original_filename = envelope.get("original_filename")
        document_type_hint = envelope.get("document_type_hint")
        document_subtype_hint = envelope.get("document_subtype_hint")
        return _ShadowJob(
            task_id=task_id,
            generation=generation,
            path=path,
            original_filename=(
                str(original_filename) if original_filename is not None else None
            ),
            file_type=file_type,
            document_type_hint=(
                str(document_type_hint) if document_type_hint is not None else None
            ),
            document_subtype_hint=(
                str(document_subtype_hint)
                if document_subtype_hint is not None
                else None
            ),
            snapshot_path=snapshot_path,
            snapshot_bytes=snapshot_path.stat().st_size,
        )

    @staticmethod
    def _remove_snapshot_file(snapshot_path: Path) -> bool:
        removed = False
        for path in (
            snapshot_path,
            *snapshot_path.parent.glob(f".{snapshot_path.name}.*.tmp"),
        ):
            try:
                path.unlink()
                removed = True
            except FileNotFoundError:
                continue
        return removed

    def _remove_snapshot_files(self, task_id: str) -> bool:
        safe = self._artifact_name(task_id).removesuffix(".json")
        suffix = hashlib.sha256(task_id.encode("utf-8")).hexdigest()[:16]
        removed = False
        directory = self._snapshot_dir()
        if not directory.is_dir():
            return False
        for path in (
            *directory.glob(f"{safe}-{suffix}-*.json"),
            *directory.glob(f".{safe}-{suffix}-*.json.*.tmp"),
        ):
            try:
                path.unlink()
                removed = True
            except FileNotFoundError:
                continue
        return removed

    def _persist_completion(
        self,
        task_id: str,
        summary: dict[str, Any],
        generation: int,
    ) -> None:
        """Persist a bounded completion envelope for process-restart recovery."""

        bounded = {
            "task_id": task_id,
            "summary": summary,
        }
        try:
            self._write_bounded_json_file(
                self._completion_path(task_id),
                bounded,
                limit=_MAX_COMPLETION_BYTES,
                commit_guard=lambda: self._generation_is_current(
                    task_id, generation
                ),
            )
        except _SnapshotTooLarge:
            # A completion summary must never become an unbounded retry record.
            fallback = {
                "task_id": task_id,
                "summary": {
                    "status": "degraded",
                    "task_id": task_id,
                    "candidate_isolation": True,
                    "reason": "completion_summary_too_large",
                    "summary_digest": _canonical_digest(summary),
                },
            }
            self._write_bounded_json_file(
                self._completion_path(task_id),
                fallback,
                limit=_MAX_COMPLETION_BYTES,
                commit_guard=lambda: self._generation_is_current(
                    task_id, generation
                ),
            )

    def _remove_completion_file(self, task_id: str) -> bool:
        target = self._completion_path(task_id)
        removed = False
        for path in (target, *target.parent.glob(f".{target.name}.*.tmp")):
            try:
                path.unlink()
                removed = True
            except FileNotFoundError:
                continue
        return removed

    def _read_completion_files(self) -> list[tuple[str, dict[str, Any]]]:
        pending: list[tuple[str, dict[str, Any]]] = []
        directory = self._completion_dir()
        if not directory.is_dir():
            return pending
        for path in directory.glob("*.json"):
            if path.is_symlink():
                path.unlink(missing_ok=True)
                continue
            try:
                if path.stat().st_size > _MAX_COMPLETION_BYTES:
                    path.unlink(missing_ok=True)
                    continue
                envelope = json.loads(path.read_text(encoding="utf-8"))
                task_id = str(envelope.get("task_id") or "")
                summary = envelope.get("summary")
                if task_id and isinstance(summary, dict):
                    pending.append((task_id, summary))
                else:
                    path.unlink(missing_ok=True)
            except (OSError, ValueError, TypeError):
                # A corrupt private spool entry cannot be safely replayed.
                path.unlink(missing_ok=True)
        return pending

    def _completion_blocks_job_recovery(self, task_id: str) -> bool:
        path = self._completion_path(task_id)
        if not path.is_file() or path.is_symlink():
            return False
        try:
            if path.stat().st_size > _MAX_COMPLETION_BYTES:
                return False
            envelope = json.loads(path.read_text(encoding="utf-8"))
            summary = envelope.get("summary") if isinstance(envelope, dict) else None
            if not isinstance(summary, dict):
                return False
            # A shutdown marker means the durable job still needs execution.
            # Completed/degraded/skipped summaries already represent a final
            # candidate attempt and only their status delivery should replay.
            return str(summary.get("status") or "") != "queued"
        except (OSError, ValueError, TypeError):
            return False

    async def _recover_snapshot_jobs_once(self) -> None:
        directory = self._snapshot_dir()
        if not directory.is_dir():
            return
        for snapshot_path in sorted(directory.glob("*.json")):
            if self._closing or len(self._background_tasks) >= self.max_pending:
                return
            try:
                job = await asyncio.to_thread(
                    self._job_from_snapshot, snapshot_path
                )
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                await asyncio.to_thread(self._remove_snapshot_file, snapshot_path)
                continue
            task_id = job.task_id
            if task_id in self._deleted_tasks:
                await asyncio.to_thread(self._remove_snapshot_file, snapshot_path)
                continue
            if await asyncio.to_thread(
                self._completion_blocks_job_recovery, task_id
            ):
                # Completion durability means the candidate already finished;
                # replay only the status update, never the expensive model job.
                await asyncio.to_thread(self._remove_snapshot_file, snapshot_path)
                continue
            current = self._background_tasks.get(task_id)
            if current is not None and not current.done():
                continue
            pending_bytes = sum(self._queued_snapshot_bytes.values())
            if pending_bytes + job.snapshot_bytes > self.max_queued_bytes:
                continue
            with self._artifact_lock:
                self._task_generations[task_id] = max(
                    self._task_generations.get(task_id, 0),
                    job.generation,
                )
            self._start_job(job)

    async def _job_recovery_loop(self) -> None:
        try:
            while not self._closing:
                await self._recover_snapshot_jobs_once()
                await asyncio.sleep(5.0)
        except asyncio.CancelledError:
            return

    async def _completion_recovery_loop(self) -> None:
        """Retry durable completion envelopes without blocking document work."""

        try:
            first_pass = True
            while not self._closing and self._completion_sink is not None:
                self._completion_recovery_runs += 1
                self._last_completion_recovery_at = self._timestamp()
                entries = await asyncio.to_thread(self._read_completion_files)
                for task_id, summary in entries:
                    if task_id in self._deleted_tasks:
                        await asyncio.to_thread(self._remove_completion_file, task_id)
                        continue
                    self._completion_pending[task_id] = dict(summary)
                    if (
                        task_id in self._completion_retry_tasks
                        or task_id in self._completion_inflight
                    ):
                        continue
                    delivered = await self._deliver_completion(
                        task_id,
                        summary,
                        budget=_COMPLETION_MAX_ATTEMPTS if first_pass else 1,
                    )
                    if not delivered and task_id not in self._completion_retry_tasks:
                        retry = asyncio.create_task(
                            self._retry_completion(task_id),
                            name=f"m1-mineru-completion-retry-{task_id}",
                        )
                        self._completion_retry_tasks[task_id] = retry
                first_pass = False
                await asyncio.sleep(_COMPLETION_RECOVERY_INTERVAL_SECONDS)
        except asyncio.CancelledError:
            return

    async def _deliver_completion(
        self,
        task_id: str,
        summary: dict[str, Any],
        *,
        budget: int,
    ) -> bool:
        """Attempt a completion delivery without dropping the summary."""

        if self._completion_sink is None:
            return False
        lock = self._completion_locks.setdefault(task_id, asyncio.Lock())
        async with lock:
            self._completion_inflight.add(task_id)
            try:
                for delay_index in range(max(1, budget)):
                    if task_id in self._deleted_tasks:
                        return False
                    self._completion_attempts[task_id] = (
                        self._completion_attempts.get(task_id, 0) + 1
                    )
                    try:
                        await asyncio.wait_for(
                            self._completion_sink(task_id, dict(summary)),
                            timeout=5.0,
                        )
                    except asyncio.CancelledError:
                        self._completion_pending[task_id] = dict(summary)
                        raise
                    except Exception as exc:  # noqa: BLE001 - bounded retry
                        self._completion_failures += 1
                        self._last_completion_error_type = exc.__class__.__name__
                        if delay_index + 1 < budget:
                            await asyncio.sleep(
                                _COMPLETION_RETRY_DELAYS[min(delay_index, 1)]
                            )
                        continue
                    self._completion_pending.pop(task_id, None)
                    self._completion_terminal_ids.discard(task_id)
                    self._completion_attempts.pop(task_id, None)
                    self._completion_successes += 1
                    self._last_completion_error_type = ""
                    await asyncio.to_thread(
                        self._remove_completion_file, task_id
                    )
                    return True

                # Keep the value in memory as a retry/dead-letter record.  The
                # task row remains queued until the sink acknowledges it.
                self._completion_pending[task_id] = dict(summary)
                self._completion_terminal_ids.add(task_id)
                return False
            finally:
                self._completion_inflight.discard(task_id)

    async def _retry_completion(self, task_id: str) -> None:
        """Retry a failed publish for a bounded interval, then retain it."""

        try:
            for delay in (1.0, 5.0, 15.0):
                await asyncio.sleep(delay)
                summary = self._completion_pending.get(task_id)
                if summary is None or task_id in self._deleted_tasks:
                    return
                if await self._deliver_completion(
                    task_id,
                    summary,
                    budget=_COMPLETION_MAX_ATTEMPTS,
                ):
                    return
        except asyncio.CancelledError:
            return
        finally:
            self._completion_retry_tasks.pop(task_id, None)

    async def _publish_completion(
        self,
        task_id: str,
        summary: dict[str, Any],
        *,
        generation: int | None = None,
    ) -> bool:
        """Durably publish a completion and report whether it is recoverable.

        The scheduled job owns a disk snapshot until this method has either
        written a completion spool entry or observed that the task was already
        tombstoned.  A persistence error must therefore return ``False`` so
        the caller keeps the job snapshot for restart recovery.
        """

        if task_id in self._deleted_tasks:
            # The delete path removes the snapshot and any completion files;
            # there is no work left for a restarted worker to recover.
            return True
        generation = generation or self._ensure_generation(task_id)
        self._completion_pending[task_id] = dict(summary)
        try:
            await asyncio.to_thread(
                self._persist_completion,
                task_id,
                summary,
                generation,
            )
        except _ArtifactDeleted:
            self._completion_pending.pop(task_id, None)
            return True
        except Exception as exc:  # noqa: BLE001 - delivery requires durability
            self._completion_failures += 1
            self._last_completion_error_type = exc.__class__.__name__
            self._completion_terminal_ids.add(task_id)
            logger.error(
                "MinerU shadow completion persistence failed task={} error_type={}",
                task_id,
                exc.__class__.__name__,
            )
            return False
        if self._completion_sink is None:
            # The spool is durable even when the workflow store has not been
            # bound yet; a later process will replay it after binding.
            return True
        delivered = await self._deliver_completion(
            task_id,
            summary,
            budget=_COMPLETION_MAX_ATTEMPTS,
        )
        if delivered or self._closing or task_id in self._completion_retry_tasks:
            if not delivered:
                logger.error(
                    "MinerU shadow task-state publish exhausted task={} error_type={}",
                    task_id,
                    self._last_completion_error_type or "unknown",
                )
            return True
        retry = asyncio.create_task(
            self._retry_completion(task_id),
            name=f"m1-mineru-completion-retry-{task_id}",
        )
        self._completion_retry_tasks[task_id] = retry
        # The completion file is already durable; retries only affect how soon
        # the task row reflects the result.
        return True

    async def _run_scheduled(self, job: _ShadowJob) -> dict[str, Any]:
        cleanup_snapshot = False
        try:
            authoritative = await asyncio.to_thread(
                self._load_authoritative_snapshot, job
            )
            summary = await self.run(
                task_id=job.task_id,
                path=job.path,
                original_filename=job.original_filename,
                file_type=job.file_type,
                authoritative=authoritative,
                document_type_hint=job.document_type_hint,
                document_subtype_hint=job.document_subtype_hint,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - authority remains unaffected
            summary = {
                "status": "degraded",
                "task_id": job.task_id,
                "candidate_isolation": True,
                "required": self.required,
                "error_type": exc.__class__.__name__,
            }
        try:
            cleanup_snapshot = await self._publish_completion(
                job.task_id,
                summary,
                generation=job.generation,
            )
            return summary
        finally:
            if cleanup_snapshot:
                await asyncio.to_thread(
                    self._remove_snapshot_file, job.snapshot_path
                )

    def _start_job(self, job: _ShadowJob) -> None:
        task = asyncio.create_task(
            self._run_scheduled(job),
            name=(
                "m1-mineru-shadow-"
                f"{self._artifact_name(job.task_id)[:-5]}-{job.generation}"
            ),
        )
        self._background_tasks[job.task_id] = task
        self._scheduled_jobs[job.task_id] = job
        self._queued_snapshot_bytes[job.task_id] = job.snapshot_bytes

        def finished(completed: asyncio.Task[dict[str, Any]]) -> None:
            if self._background_tasks.get(job.task_id) is completed:
                self._background_tasks.pop(job.task_id, None)
            if self._scheduled_jobs.get(job.task_id) is job:
                self._scheduled_jobs.pop(job.task_id, None)
            self._queued_snapshot_bytes.pop(job.task_id, None)
            if completed.cancelled():
                return
            try:
                completed.result()
            except Exception:  # noqa: BLE001, S110 - run records diagnostics
                # ``run`` records bounded diagnostics; authority is unaffected.
                pass

        task.add_done_callback(finished)


__all__ = ["MinerUShadowLifecycleMixin"]
