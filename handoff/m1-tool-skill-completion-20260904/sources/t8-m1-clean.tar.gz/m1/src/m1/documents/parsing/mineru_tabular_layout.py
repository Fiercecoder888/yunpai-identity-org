"""Apply governed tabular-layout profiles to MinerU full-authority results."""

from __future__ import annotations

import asyncio
import hashlib
import time
from pathlib import Path
from typing import Any

from loguru import logger

from ..models import DocumentRecord
from ..spreadsheets import parse_spreadsheet_envelope
from ..tabular_schema import TabularSchemaPlan, apply_plan, validate_plan
from .document_routing_status import DocumentRoutingDependencyError
from .tabular_layout_routing import (
    TabularLayoutExecutionObservation,
    TabularLayoutResolution,
    build_tabular_layout_probe,
)

_SPREADSHEET_KINDS = frozenset({"xlsx", "xlsm", "xls", "csv"})
_PARSER_REVISION = "m1.mineru-instructor-tabular-layout.v1"


def _task_reference_hash(tenant_id: str, task_id: str) -> str | None:
    normalized = str(task_id or "").strip()
    if not normalized:
        return None
    return hashlib.sha256(f"{tenant_id}\0{normalized}".encode()).hexdigest()


def _model_fingerprint(model: str) -> str:
    return hashlib.sha256(str(model or "").strip().encode()).hexdigest()


def _routing_metadata(
    resolution: TabularLayoutResolution | None,
    *,
    error: Exception | None = None,
) -> dict[str, Any]:
    if resolution is None:
        payload: dict[str, Any] = {
            "schema_version": "m1.tabular-layout-routing.v1",
            "status": "degraded" if error is not None else "skipped",
        }
    else:
        payload = {
            "schema_version": "m1.tabular-layout-routing.v1",
            "status": "resolved",
            "action": resolution.action,
            "reason": resolution.reason,
            "signature_fingerprint": resolution.signature_fingerprint,
            "profile_id": resolution.profile_id,
            "top_score": resolution.top_score,
            "top1_top2_margin": resolution.top1_top2_margin,
            "model_used": resolution.model_used,
            "review_required": resolution.review_required,
            "candidate_observation_required": (
                resolution.candidate_observation_required
            ),
        }
    if error is not None:
        payload["error_type"] = error.__class__.__name__
    return payload


def _attach_metadata(document: DocumentRecord, payload: dict[str, Any]) -> None:
    extraction = document.extraction
    if not isinstance(extraction, dict):
        extraction = {}
        document.extraction = extraction
    metadata = extraction.setdefault("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
        extraction["metadata"] = metadata
    metadata["tabular_layout_routing"] = payload


def _issue_codes(document: DocumentRecord) -> tuple[str, ...]:
    return tuple(
        dict.fromkeys(
            str(issue.code or "").strip().casefold()
            for issue in document.validation_issues
            if str(issue.code or "").strip()
        )
    )[:64]


async def _record_observation(
    router: Any,
    *,
    resolution: TabularLayoutResolution,
    tenant_id: str,
    task_id: str,
    outcome: str,
    applied: bool,
    validation_passed: bool,
    plan: TabularSchemaPlan | None,
    document: DocumentRecord,
    latency_ms: int,
    error_code: str = "",
) -> bool | None:
    if not resolution.profile_id:
        return None
    task_hash = _task_reference_hash(tenant_id, task_id)
    record = getattr(router, "record_execution_observation", None)
    if task_hash is None or not callable(record):
        return None
    mapped_fields = 0
    if plan is not None:
        mapped_fields = len(plan.header_fields) + sum(
            len(table.columns) + len(table.row_fields) for table in plan.tables
        )
    return bool(
        await record(
            TabularLayoutExecutionObservation(
                tenant_id=tenant_id,
                profile_id=resolution.profile_id,
                exact_fingerprint=resolution.signature_fingerprint,
                task_reference_hash=task_hash,
                outcome=outcome,
                parser_revision=_PARSER_REVISION,
                applied=applied,
                validation_passed=validation_passed,
                mapped_field_count=mapped_fields,
                mapped_record_count=len(document.lines),
                issue_codes=_issue_codes(document),
                latency_ms=max(0, latency_ms),
                error_code=error_code,
            )
        )
    )


async def apply_governed_tabular_layout(
    document: DocumentRecord,
    *,
    source: str | Path,
    original_filename: str | None,
    source_kind: str,
    tenant_id: str,
    task_id: str,
    document_type_hint: str | None,
    document_subtype_hint: str | None,
    model: str,
    router: Any | None,
) -> DocumentRecord:
    """Reuse an approved value-free layout without invoking a second parser LLM.

    MinerU Instructor remains authoritative for unseen layouts. An active layout
    profile can only re-read source cells through the existing deterministic
    plan compiler, so routed values retain coordinates and cannot be invented by
    the selector model.
    """

    normalized_kind = str(source_kind or "").strip().casefold()
    if router is None or normalized_kind not in _SPREADSHEET_KINDS:
        return document

    started = time.perf_counter()
    tenant = str(tenant_id or "default").strip() or "default"
    baseline = document.model_copy(deep=True)
    resolution: TabularLayoutResolution | None = None
    plan: TabularSchemaPlan | None = None
    try:
        envelope = await asyncio.to_thread(
            parse_spreadsheet_envelope,
            Path(source),
            original_filename,
        )
        probe = build_tabular_layout_probe(
            envelope,
            source_kind=normalized_kind,
            document_type_hint=(
                document_type_hint or str(document.document_type or "") or None
            ),
            document_subtype_hint=(
                document_subtype_hint or str(document.document_subtype or "") or None
            ),
            model_fingerprint=_model_fingerprint(model),
        )
        resolve = getattr(router, "resolve", None)
        if not callable(resolve):
            raise TypeError("tabular layout router has no resolve operation")
        resolution = TabularLayoutResolution.model_validate(
            await resolve(tenant_id=tenant, probe=probe),
            strict=True,
        )
        route_metadata = _routing_metadata(resolution)
        route_metadata["probe"] = {
            "source_kind": probe.source_kind,
            "table_count": len(probe.tables),
            "layout_tokens": list(probe.layout_tokens),
            "semantic_labels": list(probe.semantic_labels),
            "model_fingerprint": probe.model_fingerprint,
        }

        if resolution.action != "reuse":
            route_metadata["status"] = "advisory"
            route_metadata["authority"] = "mineru_instructor"
            if resolution.action == "propose":
                route_metadata["proposal_status"] = "awaiting_reviewed_plan"
            _attach_metadata(baseline, route_metadata)
            return baseline

        plan = validate_plan(
            envelope,
            TabularSchemaPlan.model_validate(resolution.plan, strict=True),
        )
        routed = apply_plan(
            envelope,
            baseline,
            plan,
            subtype_hint=document_subtype_hint,
        )
        route_metadata.update(
            {
                "status": "applied",
                "authority": "approved_layout_profile",
                "plan": plan.model_dump(mode="json"),
            }
        )
        observation = await _record_observation(
            router,
            resolution=resolution,
            tenant_id=tenant,
            task_id=task_id,
            outcome="success",
            applied=True,
            validation_passed=True,
            plan=plan,
            document=routed,
            latency_ms=int((time.perf_counter() - started) * 1000),
        )
        if observation is not None:
            route_metadata["observation_recorded"] = observation
        _attach_metadata(routed, route_metadata)
        return routed
    except Exception as exc:
        if resolution is not None and resolution.profile_id:
            try:
                await _record_observation(
                    router,
                    resolution=resolution,
                    tenant_id=tenant,
                    task_id=task_id,
                    outcome="failure",
                    applied=False,
                    validation_passed=False,
                    plan=plan,
                    document=baseline,
                    latency_ms=int((time.perf_counter() - started) * 1000),
                    error_code="tabular_layout_application_failed",
                )
            except Exception as observation_error:  # noqa: BLE001
                logger.warning(
                    "tabular layout observation degraded error_type={}",
                    observation_error.__class__.__name__,
                )
        if bool(getattr(router, "required", False)):
            if isinstance(exc, DocumentRoutingDependencyError):
                raise
            raise DocumentRoutingDependencyError(
                "tabular_layout", exc.__class__.__name__
            ) from exc
        logger.warning(
            "MinerU tabular layout routing degraded error_type={}",
            exc.__class__.__name__,
        )
        _attach_metadata(baseline, _routing_metadata(resolution, error=exc))
        return baseline


__all__ = ["apply_governed_tabular_layout"]
