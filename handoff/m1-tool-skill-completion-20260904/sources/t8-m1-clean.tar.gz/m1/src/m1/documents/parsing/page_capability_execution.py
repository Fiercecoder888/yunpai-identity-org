"""Execution boundary for governed page-level parser capability decisions.

The routing runtime sees only value-free probes.  This adapter deliberately
keeps backend execution outside the router so a stored profile can never name
an import, command, URL, or arbitrary capability implementation.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, Protocol

from .evidence import DocumentEvidence
from .region_capability_contracts import (
    ParsingCapability,
    RegionCapabilityProbe,
    RegionCapabilityRoutingDecision,
    RegionSourceKind,
)
from .region_capability_probe import build_page_capability_probe

PAGE_CAPABILITY_PAGE_BUDGET = 64
PAGE_CAPABILITY_SIGNATURE_BUDGET = 16


class PageCapabilityRouter(Protocol):
    """Narrow runtime contract consumed by ``DocumentParserService``."""

    async def resolve(
        self,
        *,
        tenant_id: str,
        probe: RegionCapabilityProbe,
    ) -> RegionCapabilityRoutingDecision: ...


@dataclass(frozen=True, slots=True)
class PDFPageCapabilityPlan:
    """Auditable decisions plus the only executable production page set."""

    paddleocr_vl_pages: frozenset[int]
    audit: dict[str, Any]


def _decision_payload(decision: Any) -> dict[str, Any]:
    dump = getattr(decision, "model_dump", None)
    if callable(dump):
        payload = dump(mode="json")
        if isinstance(payload, dict):
            return payload
    return {
        "action": str(getattr(decision, "action", "generic")),
        "reason": str(getattr(decision, "reason", "invalid_model_output")),
        "capability": (str(getattr(decision, "capability", "") or "") or None),
    }


def _positive_page_numbers(values: Iterable[int]) -> set[int]:
    result: set[int] = set()
    for value in values:
        try:
            page_number = int(value)
        except (TypeError, ValueError):
            continue
        if page_number > 0:
            result.add(page_number)
    return result


def _audit_schema(source_kind: RegionSourceKind) -> str:
    if source_kind is RegionSourceKind.IMAGE_REGION:
        return "m1.image-page-capability-routing.v1"
    return "m1.pdf-page-capability-routing.v1"


async def resolve_page_capabilities(
    evidence: DocumentEvidence,
    *,
    router: PageCapabilityRouter,
    tenant_id: str,
    page_numbers: Iterable[int],
    source_kind: RegionSourceKind,
    priority_page_numbers: Iterable[int] = (),
    page_budget: int = PAGE_CAPABILITY_PAGE_BUDGET,
    signature_budget: int = PAGE_CAPABILITY_SIGNATURE_BUDGET,
) -> PDFPageCapabilityPlan:
    """Resolve a bounded page set without exposing page content.

    Pages already identified by deterministic escalation take the finite page
    budget first. Structurally identical probes share one router decision, and
    the separate signature budget is an upper bound on database/vector/model
    calls. PaddleOCR-VL execution remains one later batched backend call.
    """

    if page_budget < 1:
        raise ValueError("page capability page budget must be positive")
    if signature_budget < 1:
        raise ValueError("page capability signature budget must be positive")
    normalized_tenant = str(tenant_id or "default").strip().casefold() or "default"
    requested = _positive_page_numbers(page_numbers)
    priority = _positive_page_numbers(priority_page_numbers) & requested
    ordered = [*sorted(priority), *sorted(requested - priority)]
    inspected = ordered[:page_budget]
    page_budget_skipped = ordered[page_budget:]
    by_number = {page.page_number: page for page in evidence.pages}
    executable: set[int] = set()
    decisions: dict[str, dict[str, Any]] = {}
    failures: dict[str, str] = {}
    signature_budget_skipped: list[int] = []
    groups: dict[str, tuple[RegionCapabilityProbe, list[int]]] = {}

    for page_number in inspected:
        page = by_number.get(page_number)
        if page is None:
            failures[str(page_number)] = "EvidencePageUnavailable"
            continue
        probe = build_page_capability_probe(
            page,
            source_kind=source_kind,
            attempted_capabilities=(ParsingCapability.PP_STRUCTURE_V3,),
        )
        fingerprint = probe.signature().exact_fingerprint()
        grouped = groups.get(fingerprint)
        if grouped is not None:
            grouped[1].append(page_number)
            continue
        if len(groups) >= signature_budget:
            signature_budget_skipped.append(page_number)
            continue
        groups[fingerprint] = (probe, [page_number])

    router_calls = 0
    deduplicated_pages: list[int] = []
    for probe, grouped_pages in groups.values():
        representative = grouped_pages[0]
        deduplicated_pages.extend(grouped_pages[1:])
        router_calls += 1
        try:
            decision = await router.resolve(
                tenant_id=normalized_tenant,
                probe=probe,
            )
        except Exception as exc:
            if bool(getattr(router, "required", False)):
                raise
            for page_number in grouped_pages:
                failures[str(page_number)] = exc.__class__.__name__
            continue
        payload = _decision_payload(decision)
        capability = getattr(decision, "capability", None)
        action = str(getattr(decision, "action", "generic"))
        executable_route = (
            action == "route" and capability is ParsingCapability.PADDLEOCR_VL
        )
        payload["execution_allowed"] = executable_route
        if action == "route" and not executable_route:
            payload["execution_rejection"] = "unsupported_production_capability"
        for page_number in grouped_pages:
            page_payload = dict(payload)
            if page_number != representative:
                page_payload["signature_reused_from_page"] = representative
            decisions[str(page_number)] = page_payload
            if executable_route:
                executable.add(page_number)

    status = "degraded" if failures else "completed"
    budget_limited = bool(page_budget_skipped or signature_budget_skipped)
    return PDFPageCapabilityPlan(
        paddleocr_vl_pages=frozenset(executable),
        audit={
            "schema_version": _audit_schema(source_kind),
            "status": status,
            "source_kind": source_kind.value,
            "source_capability": ParsingCapability.PP_STRUCTURE_V3.value,
            "executable_capabilities": [ParsingCapability.PADDLEOCR_VL.value],
            "requested_pages": sorted(requested),
            "priority_pages": sorted(priority),
            "inspected_pages": sorted(inspected),
            "routed_pages": sorted(executable),
            "page_budget": page_budget,
            "signature_budget": signature_budget,
            "page_budget_skipped_pages": sorted(page_budget_skipped),
            "signature_budget_skipped_pages": sorted(signature_budget_skipped),
            "budget_limited": budget_limited,
            "unique_signatures": len(groups),
            "router_calls": router_calls,
            "deduplicated_pages": sorted(deduplicated_pages),
            "decisions": decisions,
            "failures": failures,
        },
    )


async def resolve_pdf_page_capabilities(
    evidence: DocumentEvidence,
    *,
    router: PageCapabilityRouter,
    tenant_id: str,
    page_numbers: Iterable[int],
    priority_page_numbers: Iterable[int] = (),
    page_budget: int = PAGE_CAPABILITY_PAGE_BUDGET,
    signature_budget: int = PAGE_CAPABILITY_SIGNATURE_BUDGET,
) -> PDFPageCapabilityPlan:
    """Resolve PDF page capabilities using the shared bounded adapter."""

    return await resolve_page_capabilities(
        evidence,
        router=router,
        tenant_id=tenant_id,
        page_numbers=page_numbers,
        source_kind=RegionSourceKind.PDF_PAGE,
        priority_page_numbers=priority_page_numbers,
        page_budget=page_budget,
        signature_budget=signature_budget,
    )


def record_completed_capability(
    evidence: DocumentEvidence,
    capability: ParsingCapability,
    page_numbers: Iterable[int],
) -> None:
    """Record successful evidence production without replacing prior entries."""

    raw = evidence.raw.setdefault("completed_capabilities_by_page", {})
    if not isinstance(raw, dict):
        raw = {}
        evidence.raw["completed_capabilities_by_page"] = raw
    for page_number in sorted({int(value) for value in page_numbers if int(value) > 0}):
        key = str(page_number)
        current = raw.get(key)
        values = [str(value) for value in current] if isinstance(current, list) else []
        if capability.value not in values:
            values.append(capability.value)
        raw[key] = values


def completed_pages(
    evidence: DocumentEvidence,
    capability: ParsingCapability,
) -> set[int]:
    """Return pages for which a capability produced evidence successfully."""

    raw = evidence.raw.get("completed_capabilities_by_page")
    if not isinstance(raw, dict):
        return set()
    result: set[int] = set()
    for page_number, capabilities in raw.items():
        if not isinstance(capabilities, list) or capability.value not in capabilities:
            continue
        try:
            value = int(page_number)
        except (TypeError, ValueError):
            continue
        if value > 0:
            result.add(value)
    return result


__all__ = [
    "PAGE_CAPABILITY_PAGE_BUDGET",
    "PAGE_CAPABILITY_SIGNATURE_BUDGET",
    "PDFPageCapabilityPlan",
    "PageCapabilityRouter",
    "completed_pages",
    "record_completed_capability",
    "resolve_page_capabilities",
    "resolve_pdf_page_capabilities",
]
