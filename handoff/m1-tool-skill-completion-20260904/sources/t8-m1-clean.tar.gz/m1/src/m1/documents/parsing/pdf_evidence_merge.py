"""Reconcile native PDF tables with structured OCR table evidence."""

from __future__ import annotations

import copy
import unicodedata
from typing import Any


def _bbox(value: Any) -> list[float] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        result = [float(item) for item in value]
    except (TypeError, ValueError):
        return None
    return result if result[2] > result[0] and result[3] > result[1] else None


def _overlap_ratio(first: Any, second: Any) -> float:
    left, right = _bbox(first), _bbox(second)
    if left is None or right is None:
        return 0.0
    width = max(0.0, min(left[2], right[2]) - max(left[0], right[0]))
    height = max(0.0, min(left[3], right[3]) - max(left[1], right[1]))
    smaller = min(
        (left[2] - left[0]) * (left[3] - left[1]),
        (right[2] - right[0]) * (right[3] - right[1]),
    )
    return width * height / smaller if smaller > 0 else 0.0


def _key(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return "".join(character for character in text if character.isalnum())


def _rows(table: dict[str, Any], key: str = "rows_normalized") -> list[list[Any]]:
    raw = table.get(key) or []
    return [list(row) if isinstance(row, list) else [] for row in raw]


def _matrix_value(matrix: Any, row: int | None, column: int | None) -> Any:
    if row is None or column is None or not isinstance(matrix, list) or row >= len(matrix):
        return None
    values = matrix[row]
    return values[column] if isinstance(values, list) and column < len(values) else None


def _header_similarity(first: list[Any], second: list[Any]) -> float:
    left = {_key(value) for value in first if _key(value)}
    right = {_key(value) for value in second if _key(value)}
    denominator = min(len(left), len(right))
    return len(left & right) / denominator if denominator else 0.0


def _alignment_score(native: dict[str, Any], structured: dict[str, Any]) -> float | None:
    native_rows, structured_rows = _rows(native), _rows(structured)
    if not native_rows or not structured_rows:
        return None
    header_score = _header_similarity(native_rows[0], structured_rows[0])
    overlap = _overlap_ratio(native.get("bbox"), structured.get("bbox"))
    native_columns = max(map(len, native_rows), default=0)
    structured_columns = max(map(len, structured_rows), default=0)
    if header_score < 0.5 or overlap < 0.25 or abs(native_columns - structured_columns) > 2:
        return None
    return overlap * 4.0 + header_score * 3.0 - 0.1 * abs(
        len(native_rows) - len(structured_rows)
    )


def _row_identity(row: list[Any]) -> str:
    return next((_key(value) for value in row if _key(value)), "")


def _axis_alignment(
    source_keys: list[str],
    target_keys: list[str],
    *,
    positional_fallback: bool = True,
) -> list[int | None]:
    available = set(range(len(target_keys)))
    result: list[int | None] = []
    for index, source_key in enumerate(source_keys):
        matches = [
            target
            for target in available
            if source_key and target_keys[target] == source_key
        ]
        selected = matches[0] if len(matches) == 1 else None
        if selected is None and positional_fallback and index in available:
            selected = index
        if selected is not None:
            available.discard(selected)
        result.append(selected)
    return result


def _merged_row_order(
    native_count: int,
    structured_count: int,
    row_map: list[int | None],
) -> list[tuple[int | None, int | None]]:
    """Merge two row sequences without dropping rows unique to either source."""

    anchors: list[tuple[int, int]] = []
    last_structured = -1
    for native_index, structured_index in enumerate(row_map):
        if structured_index is None or structured_index <= last_structured:
            continue
        anchors.append((native_index, structured_index))
        last_structured = structured_index
    result: list[tuple[int | None, int | None]] = []
    native_cursor = 0
    structured_cursor = 0
    for native_index, structured_index in anchors:
        result.extend(
            (index, None) for index in range(native_cursor, native_index)
        )
        result.extend(
            (None, index)
            for index in range(structured_cursor, structured_index)
        )
        result.append((native_index, structured_index))
        native_cursor = native_index + 1
        structured_cursor = structured_index + 1
    result.extend((index, None) for index in range(native_cursor, native_count))
    result.extend(
        (None, index) for index in range(structured_cursor, structured_count)
    )
    return result


def _aligned_table(
    native: dict[str, Any], structured: dict[str, Any], native_list_index: int
) -> dict[str, Any]:
    native_rows = _rows(native)
    native_original = _rows(native, "rows_original") or copy.deepcopy(native_rows)
    structured_rows = _rows(structured)
    structured_original = _rows(structured, "rows_original") or copy.deepcopy(
        structured_rows
    )
    row_map = _axis_alignment(
        [_row_identity(row) for row in native_rows],
        [_row_identity(row) for row in structured_rows],
        positional_fallback=len(native_rows) == len(structured_rows),
    )
    column_map = _axis_alignment(
        [_key(value) for value in native_rows[0]],
        [_key(value) for value in structured_rows[0]],
    )
    column_count = max(
        max(map(len, native_rows), default=0),
        max(map(len, structured_rows), default=0),
    )
    structured_boxes = structured.get("cell_bbox_matrix")
    native_boxes = native.get("cell_bbox_matrix")
    structured_confidences = structured.get("cell_confidences")
    output_rows: list[list[Any]] = []
    output_original: list[list[Any]] = []
    bbox_matrix: list[list[list[float] | None]] = []
    structured_bbox_matrix: list[list[list[float] | None]] = []
    native_bbox_matrix: list[list[list[float] | None]] = []
    confidence_matrix: list[list[float]] = []
    source_matrix: list[list[str | None]] = []
    native_value_matrix: list[list[Any]] = []
    structured_value_matrix: list[list[Any]] = []
    output_native_rows: list[int | None] = []
    output_structured_rows: list[int | None] = []

    for native_row_index, structured_row_index in _merged_row_order(
        len(native_rows), len(structured_rows), row_map
    ):
        native_row = (
            native_rows[native_row_index] if native_row_index is not None else []
        )
        native_original_row = (
            native_original[native_row_index]
            if native_row_index is not None
            else []
        )
        present_native = {_key(value) for value in native_row if _key(value)}
        output_row: list[Any] = []
        original_row: list[Any] = []
        row_boxes: list[list[float] | None] = []
        row_structured_boxes: list[list[float] | None] = []
        row_native_boxes: list[list[float] | None] = []
        row_confidences: list[float] = []
        row_sources: list[str | None] = []
        row_native_values: list[Any] = []
        row_structured_values: list[Any] = []
        for native_column in range(column_count):
            structured_column = (
                column_map[native_column]
                if native_column < len(column_map)
                else native_column
            )
            native_value = (
                native_row[native_column]
                if native_column < len(native_row)
                else None
            )
            native_original_value = (
                native_original_row[native_column]
                if native_column < len(native_original_row)
                else native_value
            )
            structured_value = _matrix_value(
                structured_rows, structured_row_index, structured_column
            )
            structured_original_value = _matrix_value(
                structured_original, structured_row_index, structured_column
            )
            source = "native" if native_value not in (None, "") else None
            value = native_value
            original_value = native_original_value
            if source is None and structured_value not in (None, ""):
                structured_key = _key(structured_value)
                if not structured_key or structured_key not in present_native:
                    value = structured_value
                    original_value = structured_original_value
                    source = "structured"
            structured_box = _bbox(
                _matrix_value(
                    structured_boxes, structured_row_index, structured_column
                )
            )
            native_box = _bbox(
                _matrix_value(native_boxes, native_row_index, native_column)
            )
            output_row.append(value)
            original_row.append(original_value)
            row_boxes.append(structured_box or native_box)
            row_structured_boxes.append(structured_box)
            row_native_boxes.append(native_box)
            if source == "native":
                row_confidences.append(1.0)
            elif source == "structured":
                try:
                    row_confidences.append(
                        float(
                            _matrix_value(
                                structured_confidences,
                                structured_row_index,
                                structured_column,
                            )
                        )
                    )
                except (TypeError, ValueError):
                    row_confidences.append(0.65)
            else:
                row_confidences.append(0.0)
            row_sources.append(source)
            row_native_values.append(native_value)
            row_structured_values.append(structured_value)
        output_rows.append(output_row)
        output_original.append(original_row)
        bbox_matrix.append(row_boxes)
        structured_bbox_matrix.append(row_structured_boxes)
        native_bbox_matrix.append(row_native_boxes)
        confidence_matrix.append(row_confidences)
        source_matrix.append(row_sources)
        native_value_matrix.append(row_native_values)
        structured_value_matrix.append(row_structured_values)
        output_native_rows.append(native_row_index)
        output_structured_rows.append(structured_row_index)

    hybrid = copy.deepcopy(structured)
    hybrid.update(
        {
            "row_count": len(output_rows),
            "column_count": column_count,
            "rows_original": output_original,
            "rows_normalized": output_rows,
            "cell_bbox_matrix": bbox_matrix,
            "cell_bboxes": [box for row in bbox_matrix for box in row if box],
            "cell_confidences": confidence_matrix,
            "cell_value_sources": source_matrix,
            "native_cell_values": native_value_matrix,
            "structured_cell_values": structured_value_matrix,
            "structured_cell_bbox_matrix": structured_bbox_matrix,
            "native_aligned": True,
            "aligned_native_table_index": int(
                native.get("table_index", native_list_index)
            ),
            "aligned_native_row_indices": output_native_rows,
            "aligned_structured_row_indices": output_structured_rows,
            "aligned_structured_column_indices": [
                column_map[column]
                if column < len(column_map)
                else column
                for column in range(column_count)
            ],
            "native_cell_bbox_matrix": native_bbox_matrix,
            "native_coordinate_space": str(
                native.get("coordinate_space") or "pdf_points"
            ),
            "native_table_bbox": copy.deepcopy(native.get("bbox")),
        }
    )
    return hybrid


def _table_order_key(
    table: dict[str, Any], source_priority: int, source_index: int
) -> tuple[float, float, int, int]:
    bbox = _bbox(table.get("bbox"))
    if bbox is None:
        return (float("inf"), float("inf"), source_priority, source_index)
    return (bbox[1], bbox[0], source_priority, source_index)


def _table_fingerprint(table: dict[str, Any]) -> tuple[tuple[str, ...], ...]:
    return tuple(tuple(_key(value) for value in row) for row in _rows(table))


def _deduplicate_tables(
    entries: list[tuple[dict[str, Any], int, int]],
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    fingerprints: list[tuple[tuple[str, ...], ...]] = []
    for table, _, _ in sorted(
        entries, key=lambda item: _table_order_key(item[0], item[1], item[2])
    ):
        fingerprint = _table_fingerprint(table)
        duplicate = any(
            fingerprint
            and fingerprint == existing_fingerprint
            and _overlap_ratio(table.get("bbox"), existing.get("bbox")) >= 0.5
            for existing, existing_fingerprint in zip(
                result, fingerprints, strict=True
            )
        )
        if not duplicate:
            result.append(table)
            fingerprints.append(fingerprint)
    return result


def align_structured_order_tables(
    native_tables: list[dict[str, Any]], structured_tables: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Return the stable union of native, structured and matched hybrid tables."""

    available_native = {
        index
        for index, table in enumerate(native_tables)
        if isinstance(table, dict) and not table.get("ocr_derived")
    }
    entries: list[tuple[dict[str, Any], int, int]] = []
    matched_native: set[int] = set()
    for structured_index, structured in enumerate(structured_tables):
        candidates = [
            (score, index)
            for index in available_native
            if (score := _alignment_score(native_tables[index], structured)) is not None
        ]
        if not candidates:
            entries.append((structured, 2, structured_index))
            continue
        _, native_index = max(candidates)
        available_native.discard(native_index)
        matched_native.add(native_index)
        entries.append(
            (
                _aligned_table(
                    native_tables[native_index], structured, native_index
                ),
                0,
                native_index,
            )
        )
    entries.extend(
        (table, 1, native_index)
        for native_index, table in enumerate(native_tables)
        if native_index not in matched_native
    )
    return _deduplicate_tables(entries)


__all__ = ["align_structured_order_tables"]
