"""Native PDF text evidence and advisory reconciliation with MinerU OCR.

The existing PDF adapter already prefers PyMuPDF text for deterministic
business parsing, while MinerU exposes a broader layout and table view.  This
module gives the native text layer a stable evidence identity and compares it
with MinerU without mutating either source.  Reconciliation produces only
``fill_missing`` and ``correct_ocr`` candidates; it never adds, removes, or
reorders MinerU table rows or columns.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
from itertools import pairwise
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..adapters.pdf_native import _require_fitz, _text_blocks
from ..models import SourceReference
from .evidence import DocumentEvidence, EvidenceBBox, EvidenceBlock, EvidencePage

CandidateAction = Literal["fill_missing", "correct_ocr"]
TargetKind = Literal["block", "table_cell"]


class PdfTextLayerError(RuntimeError):
    """The source is not a readable, unencrypted PDF."""


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PdfTextLineEvidence(_StrictModel):
    """One non-empty native PDF text line with deterministic source identity."""

    source_id: str = Field(min_length=1, max_length=120)
    page_number: int = Field(ge=1)
    block_index: int = Field(ge=0)
    line_index: int = Field(ge=0)
    text_original: str = Field(min_length=1)
    text_normalized: str = Field(min_length=1)
    bbox: EvidenceBBox
    normalized_bbox: EvidenceBBox
    direction: tuple[float, float] = (1.0, 0.0)

    def source_reference(self) -> SourceReference:
        return SourceReference(
            page=self.page_number,
            part=self.source_id,
            bbox=self.bbox.as_list(),
            coordinate_space="pdf_points",
            normalized_bbox=self.normalized_bbox.as_list(),
            native_block_index=self.block_index,
            native_line_index=self.line_index,
            native_direction=list(self.direction),
        )


class PdfTextLayerPage(_StrictModel):
    page_number: int = Field(ge=1)
    width: float = Field(gt=0)
    height: float = Field(gt=0)
    rotation: int = 0
    lines: list[PdfTextLineEvidence] = Field(default_factory=list)

    @property
    def text(self) -> str:
        return "\n".join(line.text_normalized for line in self.lines)


class PdfTextLayerEvidence(_StrictModel):
    document_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    backend: str = "pymupdf-native-text"
    backend_version: str = "unknown"
    pages: list[PdfTextLayerPage] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)

    @property
    def line_count(self) -> int:
        return sum(len(page.lines) for page in self.pages)

    @property
    def text_char_count(self) -> int:
        return sum(
            len(_compact(line.text_normalized))
            for page in self.pages
            for line in page.lines
        )

    def line_index(self) -> dict[str, PdfTextLineEvidence]:
        return {
            line.source_id: line
            for page in self.pages
            for line in page.lines
        }


class PdfTextFusionCandidate(_StrictModel):
    """An auditable suggestion; applying it requires a later validation stage."""

    candidate_id: str = Field(min_length=1, max_length=100)
    action: CandidateAction
    page_number: int = Field(ge=1)
    proposed_text: str = Field(min_length=1)
    native_source_ids: list[str] = Field(min_length=1, max_length=3)
    source_refs: list[SourceReference] = Field(min_length=1, max_length=3)
    target_evidence_id: str | None = None
    target_kind: TargetKind | None = None
    observed_ocr_text: str | None = None
    similarity: float = Field(ge=0.0, le=1.0)
    spatial_overlap: float = Field(ge=0.0, le=1.0)
    reason: str
    advisory_only: Literal[True] = True
    table_structure_change_allowed: Literal[False] = False


class PdfTextFusionResult(_StrictModel):
    document_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    mineru_backend: str
    candidates: list[PdfTextFusionCandidate] = Field(default_factory=list)
    represented_source_ids: list[str] = Field(default_factory=list)
    skipped_source_ids: list[str] = Field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        actions: dict[str, int] = defaultdict(int)
        for candidate in self.candidates:
            actions[candidate.action] += 1
        return {
            "candidate_count": len(self.candidates),
            "actions": dict(sorted(actions.items())),
            "represented_source_count": len(self.represented_source_ids),
            "skipped_source_count": len(self.skipped_source_ids),
            "advisory_only": True,
            "table_structure_change_allowed": False,
        }


def _normalize(value: object) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).split())


def _compact(value: object) -> str:
    return "".join(_normalize(value).casefold().split())


def _usable_native_text(value: str) -> bool:
    compact = _compact(value)
    if not compact:
        return False
    suspicious = sum(
        character == "\ufffd"
        or unicodedata.category(character) in {"Co", "Cs"}
        or (unicodedata.category(character) == "Cc" and not character.isspace())
        for character in value
    )
    return suspicious / max(1, len(value)) <= 0.05


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _bbox(value: Any, *, coordinate_space: str) -> EvidenceBBox | None:
    if not isinstance(value, (list, tuple)) or len(value) < 4:
        return None
    try:
        x0, y0, x1, y1 = (float(value[index]) for index in range(4))
    except (TypeError, ValueError):
        return None
    if x1 <= x0 or y1 <= y0:
        return None
    return EvidenceBBox(
        x0=x0,
        y0=y0,
        x1=x1,
        y1=y1,
        coordinate_space=coordinate_space,
    )


def _normalized_bbox(box: EvidenceBBox, *, width: float, height: float) -> EvidenceBBox:
    return EvidenceBBox(
        x0=max(0.0, min(1.0, box.x0 / width)),
        y0=max(0.0, min(1.0, box.y0 / height)),
        x1=max(0.0, min(1.0, box.x1 / width)),
        y1=max(0.0, min(1.0, box.y1 / height)),
        coordinate_space="normalized",
    )


def _source_id(
    *,
    document_sha256: str,
    page_number: int,
    text: str,
    bbox: EvidenceBBox,
    direction: tuple[float, float],
) -> str:
    payload = json.dumps(
        {
            "page": page_number,
            "text": text,
            "bbox": [round(value, 3) for value in bbox.as_list()],
            "direction": [round(value, 4) for value in direction],
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    signature = hashlib.sha256(payload).hexdigest()[:20]
    return f"pdf-text/{document_sha256[:12]}/p{page_number}/{signature}"


def text_layer_evidence_from_native_pages(
    pages: list[dict[str, Any]],
    *,
    document_sha256: str,
    backend_version: str = "unknown",
) -> PdfTextLayerEvidence:
    """Build stable line evidence from the PDF adapter's existing page payload."""

    if not re.fullmatch(r"[0-9a-f]{64}", document_sha256):
        raise ValueError("document_sha256 must be 64 lowercase hexadecimal characters")
    output_pages: list[PdfTextLayerPage] = []
    warnings: list[str] = []
    for page_offset, page in enumerate(pages):
        page_number = int(page.get("page_number") or page_offset + 1)
        width = float(page.get("coordinate_width") or page.get("width") or 0.0)
        height = float(page.get("coordinate_height") or page.get("height") or 0.0)
        if width <= 0 or height <= 0:
            warnings.append(f"page:{page_number}:invalid_dimensions")
            continue
        lines: list[PdfTextLineEvidence] = []
        seen_source_ids: dict[str, int] = defaultdict(int)
        for fallback_block_index, block in enumerate(page.get("text_blocks") or []):
            if not isinstance(block, dict):
                continue
            block_index = int(block.get("block_index", fallback_block_index))
            for line_index, line in enumerate(block.get("lines") or []):
                if not isinstance(line, dict):
                    continue
                original = str(line.get("text_original") or "")
                normalized = _normalize(line.get("text_normalized") or original)
                box = _bbox(line.get("bbox"), coordinate_space="pdf_points")
                if not normalized or box is None:
                    continue
                raw_direction = line.get("direction") or (1.0, 0.0)
                try:
                    direction = (float(raw_direction[0]), float(raw_direction[1]))
                except (IndexError, TypeError, ValueError):
                    direction = (1.0, 0.0)
                base_source_id = _source_id(
                    document_sha256=document_sha256,
                    page_number=page_number,
                    text=normalized,
                    bbox=box,
                    direction=direction,
                )
                duplicate_index = seen_source_ids[base_source_id]
                seen_source_ids[base_source_id] += 1
                source_id = (
                    base_source_id
                    if duplicate_index == 0
                    else f"{base_source_id}/{duplicate_index}"
                )
                lines.append(
                    PdfTextLineEvidence(
                        source_id=source_id,
                        page_number=page_number,
                        block_index=block_index,
                        line_index=line_index,
                        text_original=original or normalized,
                        text_normalized=normalized,
                        bbox=box,
                        normalized_bbox=_normalized_bbox(
                            box,
                            width=width,
                            height=height,
                        ),
                        direction=direction,
                    )
                )
        output_pages.append(
            PdfTextLayerPage(
                page_number=page_number,
                width=width,
                height=height,
                rotation=int(page.get("rotation") or 0),
                lines=lines,
            )
        )
    return PdfTextLayerEvidence(
        document_sha256=document_sha256,
        backend_version=backend_version,
        pages=output_pages,
        warnings=warnings,
    )


def extract_pdf_text_layer(path: str | Path) -> PdfTextLayerEvidence:
    """Extract native PDF line text and geometry without rendering or OCR."""

    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    with source.open("rb") as stream:
        if stream.read(5) != b"%PDF-":
            raise PdfTextLayerError(f"Not a PDF by magic bytes: {source.name}")
    document_sha256 = _file_sha256(source)
    fitz = _require_fitz()
    try:
        document = fitz.open(str(source))
    except Exception as exc:
        raise PdfTextLayerError(f"Unable to open PDF {source.name}: {exc}") from exc
    pages: list[dict[str, Any]] = []
    try:
        if bool(getattr(document, "needs_pass", False)):
            raise PdfTextLayerError(f"Encrypted PDF requires a password: {source.name}")
        for page_index, page in enumerate(document):
            blocks, _ = _text_blocks(page)
            pages.append(
                {
                    "page_number": page_index + 1,
                    "coordinate_width": float(page.cropbox.width),
                    "coordinate_height": float(page.cropbox.height),
                    "rotation": int(page.rotation),
                    "text_blocks": blocks,
                }
            )
    finally:
        document.close()
    return text_layer_evidence_from_native_pages(
        pages,
        document_sha256=document_sha256,
        backend_version=str(getattr(fitz, "VersionBind", "unknown")),
    )


@dataclass(frozen=True, slots=True)
class _Target:
    evidence_id: str
    page_number: int
    kind: TargetKind
    text: str
    bbox: EvidenceBBox | None


@dataclass(frozen=True, slots=True)
class _NativeSequence:
    page_number: int
    source_ids: tuple[str, ...]
    text: str
    bbox: EvidenceBBox


def _target_bbox(box: EvidenceBBox | None, page: EvidencePage) -> EvidenceBBox | None:
    if box is None:
        return None
    if box.coordinate_space == "normalized":
        return box
    width = max(1.0, float(page.width))
    height = max(1.0, float(page.height))
    return EvidenceBBox(
        x0=max(0.0, min(1.0, box.x0 / width)),
        y0=max(0.0, min(1.0, box.y0 / height)),
        x1=max(0.0, min(1.0, box.x1 / width)),
        y1=max(0.0, min(1.0, box.y1 / height)),
        coordinate_space="normalized",
    )


def _targets(evidence: DocumentEvidence) -> list[_Target]:
    targets: list[_Target] = []
    for page in evidence.pages:
        for block in page.blocks:
            text = _normalize(block.text)
            if not text or block.kind.casefold() == "table":
                continue
            targets.append(
                _Target(
                    evidence_id=block.block_id,
                    page_number=page.page_number,
                    kind="block",
                    text=text,
                    bbox=_target_bbox(block.bbox, page),
                )
            )
        for table in page.tables:
            for cell in table.cells:
                text = _normalize(cell.text)
                if not text:
                    continue
                targets.append(
                    _Target(
                        evidence_id=f"{table.table_id}:r{cell.row}:c{cell.column}",
                        page_number=page.page_number,
                        kind="table_cell",
                        text=text,
                        bbox=_target_bbox(cell.bbox or table.bbox, page),
                    )
                )
    return targets


def _union_bbox(lines: list[PdfTextLineEvidence]) -> EvidenceBBox:
    return EvidenceBBox(
        x0=min(line.normalized_bbox.x0 for line in lines),
        y0=min(line.normalized_bbox.y0 for line in lines),
        x1=max(line.normalized_bbox.x1 for line in lines),
        y1=max(line.normalized_bbox.y1 for line in lines),
        coordinate_space="normalized",
    )


def _native_sequences(
    evidence: PdfTextLayerEvidence,
    *,
    max_compound_lines: int,
) -> tuple[list[_NativeSequence], list[PdfTextLineEvidence]]:
    lines = [line for page in evidence.pages for line in page.lines]
    sequences = [
        _NativeSequence(
            page_number=line.page_number,
            source_ids=(line.source_id,),
            text=line.text_normalized,
            bbox=line.normalized_bbox,
        )
        for line in lines
    ]
    grouped: dict[tuple[int, int], list[PdfTextLineEvidence]] = defaultdict(list)
    for line in lines:
        grouped[(line.page_number, line.block_index)].append(line)
    for block_lines in grouped.values():
        block_lines.sort(key=lambda value: value.line_index)
        for start in range(len(block_lines)):
            for size in range(2, min(max_compound_lines, len(block_lines) - start) + 1):
                selected = block_lines[start : start + size]
                if any(
                    right.line_index != left.line_index + 1
                    for left, right in pairwise(selected)
                ):
                    continue
                sequences.append(
                    _NativeSequence(
                        page_number=selected[0].page_number,
                        source_ids=tuple(line.source_id for line in selected),
                        text=" ".join(line.text_normalized for line in selected),
                        bbox=_union_bbox(selected),
                    )
                )
    return sequences, lines


def _overlap_ratio(first: EvidenceBBox, second: EvidenceBBox | None) -> float:
    if second is None:
        return 1.0
    width = max(0.0, min(first.x1, second.x1) - max(first.x0, second.x0))
    height = max(0.0, min(first.y1, second.y1) - max(first.y0, second.y0))
    smaller = min(first.area, second.area)
    return min(1.0, width * height / smaller) if smaller > 0 else 0.0


def _similarity(first: str, second: str) -> float:
    left, right = _compact(first), _compact(second)
    if not left or not right:
        return 0.0
    return SequenceMatcher(None, left, right, autojunk=False).ratio()


def _candidate_id(
    action: CandidateAction,
    *,
    page_number: int,
    source_ids: tuple[str, ...],
    target_evidence_id: str | None,
) -> str:
    payload = "\x1f".join(
        [action, str(page_number), *source_ids, target_evidence_id or ""]
    ).encode("utf-8")
    return f"pdf-text-candidate-{hashlib.sha256(payload).hexdigest()[:20]}"


def propose_pdf_text_layer_fusion(
    native: PdfTextLayerEvidence,
    mineru: DocumentEvidence,
    *,
    correction_similarity: float = 0.65,
    represented_similarity: float = 0.88,
    minimum_spatial_overlap: float = 0.5,
    minimum_correction_chars: int = 6,
    minimum_missing_chars: int = 4,
    max_compound_lines: int = 3,
) -> PdfTextFusionResult:
    """Return advisory text candidates while leaving MinerU evidence untouched."""

    if not 0.0 <= correction_similarity <= represented_similarity <= 1.0:
        raise ValueError("similarity thresholds must satisfy 0 <= correction <= represented <= 1")
    if not 0.0 <= minimum_spatial_overlap <= 1.0:
        raise ValueError("minimum_spatial_overlap must be between zero and one")
    max_compound_lines = max(1, min(3, int(max_compound_lines)))
    targets = _targets(mineru)
    sequences, lines = _native_sequences(
        native,
        max_compound_lines=max_compound_lines,
    )
    line_by_id = native.line_index()
    usable_ids = {
        line.source_id for line in lines if _usable_native_text(line.text_normalized)
    }
    skipped_ids = sorted(set(line_by_id) - usable_ids)

    represented: set[str] = set()
    for line in lines:
        if line.source_id not in usable_ids:
            continue
        native_key = _compact(line.text_normalized)
        for target in targets:
            if target.page_number != line.page_number:
                continue
            if _overlap_ratio(line.normalized_bbox, target.bbox) < minimum_spatial_overlap:
                continue
            target_key = _compact(target.text)
            if native_key and native_key in target_key:
                represented.add(line.source_id)
                break

    best_by_target: dict[str, tuple[_NativeSequence, float, float]] = {}
    best_by_sequence: dict[tuple[str, ...], tuple[_Target, float, float]] = {}
    for sequence in sequences:
        if any(source_id not in usable_ids for source_id in sequence.source_ids):
            continue
        if len(_compact(sequence.text)) < minimum_correction_chars:
            continue
        for target in targets:
            if target.page_number != sequence.page_number:
                continue
            if len(sequence.source_ids) > 1 and len(_compact(target.text)) < 24:
                # Compound evidence is useful for wrapped paragraphs and long
                # formulas.  It must not join a short value such as ``160mm``
                # with the next row's sequence number merely because table-level
                # geometry contains both lines.
                continue
            overlap = _overlap_ratio(sequence.bbox, target.bbox)
            if overlap < minimum_spatial_overlap:
                continue
            similarity = _similarity(sequence.text, target.text)
            previous_target = best_by_target.get(target.evidence_id)
            if previous_target is None or (similarity, overlap, len(sequence.text)) > (
                previous_target[1],
                previous_target[2],
                len(previous_target[0].text),
            ):
                best_by_target[target.evidence_id] = (sequence, similarity, overlap)
            previous_sequence = best_by_sequence.get(sequence.source_ids)
            if previous_sequence is None or (similarity, overlap, len(target.text)) > (
                previous_sequence[1],
                previous_sequence[2],
                len(previous_sequence[0].text),
            ):
                best_by_sequence[sequence.source_ids] = (target, similarity, overlap)

    target_by_id = {target.evidence_id: target for target in targets}
    candidates: list[PdfTextFusionCandidate] = []
    correction_source_ids: set[str] = set()
    for target_id, (sequence, similarity, overlap) in best_by_target.items():
        reciprocal = best_by_sequence.get(sequence.source_ids)
        target = target_by_id[target_id]
        if reciprocal is None or reciprocal[0].evidence_id != target_id:
            continue
        if similarity < correction_similarity:
            continue
        source_key = _compact(sequence.text)
        target_key = _compact(target.text)
        if source_key == target_key or source_key in target_key:
            represented.update(sequence.source_ids)
            continue
        candidates.append(
            PdfTextFusionCandidate(
                candidate_id=_candidate_id(
                    "correct_ocr",
                    page_number=sequence.page_number,
                    source_ids=sequence.source_ids,
                    target_evidence_id=target_id,
                ),
                action="correct_ocr",
                page_number=sequence.page_number,
                proposed_text=sequence.text,
                native_source_ids=list(sequence.source_ids),
                source_refs=[
                    line_by_id[source_id].source_reference()
                    for source_id in sequence.source_ids
                ],
                target_evidence_id=target_id,
                target_kind=target.kind,
                observed_ocr_text=target.text,
                similarity=round(similarity, 6),
                spatial_overlap=round(overlap, 6),
                reason="native_text_differs_from_spatially_aligned_ocr",
            )
        )
        correction_source_ids.update(sequence.source_ids)

    represented.update(correction_source_ids)
    for line in lines:
        if line.source_id not in usable_ids or line.source_id in represented:
            continue
        compact = _compact(line.text_normalized)
        if len(compact) < minimum_missing_chars:
            continue
        best_similarity = 0.0
        best_overlap = 0.0
        for target in targets:
            if target.page_number != line.page_number:
                continue
            overlap = _overlap_ratio(line.normalized_bbox, target.bbox)
            if overlap < minimum_spatial_overlap:
                continue
            similarity = _similarity(line.text_normalized, target.text)
            if similarity > best_similarity:
                best_similarity, best_overlap = similarity, overlap
        if best_similarity >= represented_similarity:
            represented.add(line.source_id)
            continue
        candidates.append(
            PdfTextFusionCandidate(
                candidate_id=_candidate_id(
                    "fill_missing",
                    page_number=line.page_number,
                    source_ids=(line.source_id,),
                    target_evidence_id=None,
                ),
                action="fill_missing",
                page_number=line.page_number,
                proposed_text=line.text_normalized,
                native_source_ids=[line.source_id],
                source_refs=[line.source_reference()],
                similarity=round(best_similarity, 6),
                spatial_overlap=round(best_overlap, 6),
                reason="native_text_absent_from_mineru_evidence",
            )
        )

    candidates.sort(
        key=lambda value: (
            value.page_number,
            0 if value.action == "correct_ocr" else 1,
            value.target_evidence_id or value.native_source_ids[0],
            value.candidate_id,
        )
    )
    return PdfTextFusionResult(
        document_sha256=native.document_sha256,
        mineru_backend=mineru.backend,
        candidates=candidates,
        represented_source_ids=sorted(represented),
        skipped_source_ids=skipped_ids,
    )


def apply_pdf_text_layer_fusion(
    native: PdfTextLayerEvidence,
    mineru: DocumentEvidence,
) -> tuple[DocumentEvidence, PdfTextFusionResult]:
    """Apply validated native text to a copy without changing table geometry."""

    fusion = propose_pdf_text_layer_fusion(native, mineru)
    merged = mineru.model_copy(deep=True)
    pages = {page.page_number: page for page in merged.pages}
    blocks = {
        block.block_id: block
        for page in merged.pages
        for block in page.blocks
    }
    cells: dict[str, tuple[Any, Any]] = {}
    for page in merged.pages:
        for table in page.tables:
            for cell in table.cells:
                cells[f"{table.table_id}:r{cell.row}:c{cell.column}"] = (
                    table,
                    cell,
                )

    applied = skipped = 0
    fill_candidates: list[PdfTextFusionCandidate] = []
    for candidate in fusion.candidates:
        if candidate.action == "fill_missing":
            fill_candidates.append(candidate)
            continue
        native_refs = [
            source_ref.model_dump(mode="json")
            for source_ref in candidate.source_refs
        ]
        if candidate.target_kind == "block":
            target = blocks.get(candidate.target_evidence_id or "")
            if target is None:
                skipped += 1
                continue
            original = target.text
            target.text = candidate.proposed_text
            target.source = "pymupdf-native-text+mineru"
            target.__pydantic_extra__ = {
                **(target.model_extra or {}),
                "ocr_text_original": original,
                "native_source_refs": native_refs,
                "text_fusion_candidate_id": candidate.candidate_id,
            }
            applied += 1
            continue
        target_pair = cells.get(candidate.target_evidence_id or "")
        if target_pair is None:
            skipped += 1
            continue
        table, cell = target_pair
        original = cell.text
        cell.text = candidate.proposed_text
        cell.__pydantic_extra__ = {
            **(cell.model_extra or {}),
            "ocr_text_original": original,
            "native_source_refs": native_refs,
            "text_fusion_candidate_id": candidate.candidate_id,
        }
        if cell.row < len(table.rows) and cell.column < len(table.rows[cell.row]):
            table.rows[cell.row][cell.column] = candidate.proposed_text
        applied += 1

    native_lines = native.line_index()
    grouped: dict[
        tuple[int, int],
        list[tuple[PdfTextLineEvidence, PdfTextFusionCandidate]],
    ] = defaultdict(list)
    for candidate in fill_candidates:
        line = native_lines.get(candidate.native_source_ids[0])
        if line is None:
            skipped += 1
            continue
        grouped[(line.page_number, line.block_index)].append((line, candidate))
    for (page_number, _block_index), values in sorted(grouped.items()):
        values.sort(key=lambda item: item[0].line_index)
        runs: list[list[tuple[PdfTextLineEvidence, PdfTextFusionCandidate]]] = []
        for value in values:
            if (
                not runs
                or value[0].line_index != runs[-1][-1][0].line_index + 1
            ):
                runs.append([value])
            else:
                runs[-1].append(value)
        page = pages.get(page_number)
        if page is None:
            skipped += sum(len(run) for run in runs)
            continue
        for run in runs:
            lines = [item[0] for item in run]
            candidates = [item[1] for item in run]
            source_ids = [line.source_id for line in lines]
            signature = hashlib.sha256(
                "\x1f".join(source_ids).encode("utf-8")
            ).hexdigest()[:20]
            native_refs = [
                line.source_reference().model_dump(mode="json")
                for line in lines
            ]
            page.blocks.append(
                EvidenceBlock(
                    block_id=f"native:pdf-text-block-{signature}",
                    kind="native_text",
                    text="\n".join(line.text_normalized for line in lines),
                    bbox=_union_bbox(lines),
                    confidence=1.0,
                    order=max(
                        (block.order for block in page.blocks),
                        default=-1,
                    )
                    + 1,
                    source="pymupdf-native-text",
                    source_ref_part=source_ids[0],
                    native_source_refs=native_refs,
                    text_fusion_candidate_ids=[
                        candidate.candidate_id for candidate in candidates
                    ],
                )
            )
            applied += len(run)

    merged.backend = f"{mineru.backend}+pymupdf-native-text"
    merged.model_fingerprints = {
        **merged.model_fingerprints,
        "pdf_native_sha256": native.document_sha256,
    }
    merged.raw = {
        **merged.raw,
        "pdf_text_layer": {
            "backend": native.backend,
            "backend_version": native.backend_version,
            "line_count": native.line_count,
            "text_char_count": native.text_char_count,
            "warnings": list(native.warnings),
            "fusion": fusion.summary(),
            "applied_candidate_count": applied,
            "skipped_candidate_count": skipped,
            "table_structure_changed": False,
        },
    }
    return merged, fusion


__all__ = [
    "PdfTextFusionCandidate",
    "PdfTextFusionResult",
    "PdfTextLayerError",
    "PdfTextLayerEvidence",
    "PdfTextLayerPage",
    "PdfTextLineEvidence",
    "apply_pdf_text_layer_fusion",
    "extract_pdf_text_layer",
    "propose_pdf_text_layer_fusion",
    "text_layer_evidence_from_native_pages",
]
