"""Closed, value-free contracts for page and region parser capability routing."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Sequence
from enum import StrEnum
from typing import Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

REGION_CAPABILITY_CONTRACT_REVISION = "m1.region-capability.v1"
_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")


class ParsingCapability(StrEnum):
    """Only parser capabilities registered in M1 may be selected."""

    NATIVE = "native"
    MINERU = "mineru"
    PP_STRUCTURE_V3 = "pp_structure_v3"
    PADDLEOCR_VL = "paddleocr_vl"
    DOCLING = "docling"
    OCR = "ocr"


class RegionSourceKind(StrEnum):
    PDF_PAGE = "pdf_page"
    IMAGE_REGION = "image_region"
    SPREADSHEET_REGION = "spreadsheet_region"
    WORD_REGION = "word_region"
    PRESENTATION_REGION = "presentation_region"
    HTML_REGION = "html_region"
    CAD_REGION = "cad_region"


class RegionScope(StrEnum):
    PAGE = "page"
    REGION = "region"


class RegionKind(StrEnum):
    UNKNOWN = "unknown"
    TEXT = "text"
    TABLE = "table"
    IMAGE = "image"
    FIGURE = "figure"
    CHART = "chart"
    SEAL = "seal"
    DRAWING = "drawing"
    MIXED = "mixed"


class TextPresence(StrEnum):
    NONE = "none"
    SPARSE = "sparse"
    SUBSTANTIAL = "substantial"


class ConfidenceBucket(StrEnum):
    UNKNOWN = "unknown"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class CoverageBucket(StrEnum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    DOMINANT = "dominant"


class TableState(StrEnum):
    NONE = "none"
    STRUCTURED = "structured"
    UNSTRUCTURED = "unstructured"
    COMPLEX = "complex"


class OrientationBucket(StrEnum):
    UNKNOWN = "unknown"
    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"
    SQUARE = "square"


class ComplexityBucket(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class RegionFeature(StrEnum):
    """Bounded structural facts; no source text or business values are admitted."""

    HAS_COORDINATES = "has_coordinates"
    HAS_ROTATION = "has_rotation"
    HAS_CELL_MATRIX = "has_cell_matrix"
    HAS_VECTOR_TEXT = "has_vector_text"
    HAS_RASTER = "has_raster"
    HAS_EMBEDDED_IMAGES = "has_embedded_images"
    MULTI_COLUMN = "multi_column"
    REPEATED_HEADERS = "repeated_headers"


class CapabilityProfileStatus(StrEnum):
    CANDIDATE = "candidate"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class RegionCapabilityProbe(BaseModel):
    """Value-free observations produced before an expensive parser is selected."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    contract_revision: Literal["m1.region-capability.v1"] = (
        REGION_CAPABILITY_CONTRACT_REVISION
    )
    producer_revision: str = Field(
        default="m1.region-probe.v1",
        min_length=1,
        max_length=128,
    )
    source_kind: RegionSourceKind
    scope: RegionScope
    region_kind: RegionKind = RegionKind.UNKNOWN
    text_presence: TextPresence = TextPresence.NONE
    text_confidence: ConfidenceBucket = ConfidenceBucket.UNKNOWN
    visual_coverage: CoverageBucket = CoverageBucket.NONE
    table_state: TableState = TableState.NONE
    orientation: OrientationBucket = OrientationBucket.UNKNOWN
    complexity: ComplexityBucket = ComplexityBucket.LOW
    features: tuple[RegionFeature, ...] = ()
    attempted_capabilities: tuple[ParsingCapability, ...] = ()

    @field_validator("producer_revision")
    @classmethod
    def validate_revision(cls, value: str) -> str:
        if value != value.strip() or _SAFE_ID.fullmatch(value.casefold()) is None:
            raise ValueError("producer revision must be a stable token")
        return value.casefold()

    @field_validator("features", "attempted_capabilities", mode="before")
    @classmethod
    def normalize_unique_sequence(cls, value: object) -> object:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("region capability collections must be sequences")
        if len(value) != len(set(value)):
            raise ValueError("region capability collections must be unique")
        return tuple(value)

    def signature(self) -> RegionCapabilitySignature:
        return RegionCapabilitySignature(**self.model_dump(mode="python"))


class RegionCapabilitySignature(BaseModel):
    """Persistable routing signature containing structure but no document values."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    contract_revision: Literal["m1.region-capability.v1"] = (
        REGION_CAPABILITY_CONTRACT_REVISION
    )
    producer_revision: str = Field(min_length=1, max_length=128)
    source_kind: RegionSourceKind
    scope: RegionScope
    region_kind: RegionKind
    text_presence: TextPresence
    text_confidence: ConfidenceBucket
    visual_coverage: CoverageBucket
    table_state: TableState
    orientation: OrientationBucket
    complexity: ComplexityBucket
    features: tuple[RegionFeature, ...] = ()
    attempted_capabilities: tuple[ParsingCapability, ...] = ()

    @field_validator("producer_revision")
    @classmethod
    def validate_revision(cls, value: str) -> str:
        if value != value.strip() or _SAFE_ID.fullmatch(value.casefold()) is None:
            raise ValueError("producer revision must be a stable token")
        return value.casefold()

    @field_validator("features", "attempted_capabilities", mode="before")
    @classmethod
    def normalize_unique_sequence(cls, value: object) -> object:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("region capability collections must be sequences")
        if len(value) != len(set(value)):
            raise ValueError("region capability collections must be unique")
        return tuple(value)

    def exact_fingerprint(self) -> str:
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def structural_tokens(self) -> frozenset[str]:
        tokens = {
            f"contract:{self.contract_revision}",
            f"producer:{self.producer_revision}",
            f"source:{self.source_kind.value}",
            f"scope:{self.scope.value}",
            f"region:{self.region_kind.value}",
            f"text:{self.text_presence.value}",
            f"confidence:{self.text_confidence.value}",
            f"visual:{self.visual_coverage.value}",
            f"table:{self.table_state.value}",
            f"orientation:{self.orientation.value}",
            f"complexity:{self.complexity.value}",
        }
        tokens.update(f"feature:{item.value}" for item in self.features)
        tokens.update(f"attempted:{item.value}" for item in self.attempted_capabilities)
        return frozenset(tokens)

    def embedding_text(self) -> str:
        return "\n".join(sorted(self.structural_tokens()))


class RegionCapabilityProfile(BaseModel):
    """Store-owned route profile; profile identity never reaches the model."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str = Field(min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    status: CapabilityProfileStatus
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: RegionCapabilitySignature
    capability: ParsingCapability
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=128)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)

    @field_validator("profile_id", "profile_key")
    @classmethod
    def validate_id(cls, value: str) -> str:
        if value != value.strip() or _SAFE_ID.fullmatch(value) is None:
            raise ValueError("profile identifiers must be stable opaque tokens")
        return value

    @field_validator("tenant_id")
    @classmethod
    def validate_tenant(cls, value: str) -> str:
        if value != value.strip():
            raise ValueError("tenant ID must already be normalized")
        return value

    @field_validator("embedding")
    @classmethod
    def validate_embedding(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        vector = tuple(float(item) for item in value)
        if not vector or not all(math.isfinite(item) for item in vector):
            raise ValueError("profile embedding must contain finite values")
        return vector

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("profile fingerprint does not match its signature")
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("profile observation counters are inconsistent")
        if self.status is CapabilityProfileStatus.ACTIVE and (
            self.success_count < 3 or self.failure_count
        ):
            raise ValueError("active capability profiles require three clean samples")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self

    @property
    def success_rate(self) -> float | None:
        if not self.observation_count:
            return None
        return round(self.success_count / self.observation_count, 6)


class RegionCapabilityProfileMatch(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile: RegionCapabilityProfile
    vector_similarity: float = Field(ge=0.0, le=1.0)


class RegionCapabilityCandidateProposal(BaseModel):
    """Inactive value-free proposal; the store owns profile identity."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    signature: RegionCapabilitySignature
    capability: ParsingCapability
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=128)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    created_by: str = Field(
        default="region-capability-router", min_length=1, max_length=256
    )

    @field_validator("tenant_id")
    @classmethod
    def validate_tenant(cls, value: str) -> str:
        if value != value.strip():
            raise ValueError("tenant ID must already be normalized")
        return value

    @field_validator("profile_key")
    @classmethod
    def validate_key(cls, value: str) -> str:
        if value != value.strip() or _SAFE_ID.fullmatch(value) is None:
            raise ValueError("candidate profile key must be a stable token")
        return value

    @field_validator("embedding")
    @classmethod
    def validate_embedding(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        vector = tuple(float(item) for item in value)
        if not vector or not all(math.isfinite(item) for item in vector):
            raise ValueError("candidate embedding must contain finite values")
        return vector

    @model_validator(mode="after")
    def validate_candidate(self) -> Self:
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self


class RegionCapabilityExecutionObservation(BaseModel):
    """Reviewed route sample containing only one-way source references."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    region_reference_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    outcome: Literal["success", "failure"]
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome == "success":
            if not self.validation_passed:
                raise ValueError("successful route samples must pass validation")
            if not self.reviewed_by.strip():
                raise ValueError("successful route samples require a reviewer")
            if re.fullmatch(r"[0-9a-f]{64}", self.review_note_sha256) is None:
                raise ValueError(
                    "successful route samples require a hashed review note"
                )
        elif not self.error_code.strip():
            raise ValueError("failed route samples require an error code")
        return self


class RegionCapabilityEmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class RegionCapabilityRouteStore(Protocol):
    async def get_active_region_capability_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        producer_revision: str,
    ) -> RegionCapabilityProfile | None: ...

    async def find_active_region_capability_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str,
        producer_revision: str,
        source_kind: RegionSourceKind | None = None,
        scope: RegionScope | None = None,
        limit: int,
    ) -> Sequence[RegionCapabilityProfileMatch]: ...

    async def create_region_capability_candidate(
        self, proposal: RegionCapabilityCandidateProposal
    ) -> RegionCapabilityProfile: ...

    async def record_region_capability_execution_observation(
        self, record: RegionCapabilityExecutionObservation
    ) -> object: ...


class RegionCapabilityRankedCandidate(BaseModel):
    """Internal candidate with an opaque profile ID."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str = Field(min_length=1, max_length=128)
    capability: ParsingCapability
    structural_similarity: float = Field(ge=0.0, le=1.0)
    vector_similarity: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)


class RegionCapabilitySelectionCandidate(BaseModel):
    """Model-visible candidate addressed only by its bounded index."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    candidate_index: int = Field(ge=0, le=4)
    capability: ParsingCapability
    structural_similarity: float = Field(ge=0.0, le=1.0)
    vector_similarity: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)


class RegionCapabilitySelectionRequest(BaseModel):
    """Complete selector payload; it has no tenant, TaskID, text, or profile IDs."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.region-capability-selection.v1"] = (
        "m1.region-capability-selection.v1"
    )
    signature: RegionCapabilitySignature
    candidates: tuple[RegionCapabilitySelectionCandidate, ...] = Field(
        default=(), max_length=5
    )
    available_capabilities: tuple[ParsingCapability, ...] = Field(
        min_length=1, max_length=6
    )

    @model_validator(mode="after")
    def validate_request(self) -> Self:
        indexes = [item.candidate_index for item in self.candidates]
        if indexes != list(range(len(indexes))):
            raise ValueError("candidate indexes must be contiguous and ordered")
        if len(self.available_capabilities) != len(set(self.available_capabilities)):
            raise ValueError("available capabilities must be unique")
        return self


CapabilityModelAction = Literal["reuse", "generic", "review", "new_candidate"]


class RegionCapabilityModelChoice(BaseModel):
    """Strict closed model output; no backend or profile string can be invented."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: CapabilityModelAction
    candidate_index: int | None = Field(default=None, ge=0, le=4)
    capability_index: int | None = Field(default=None, ge=0, le=5)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_choice(self) -> Self:
        if self.action == "reuse":
            if self.candidate_index is None or self.capability_index is not None:
                raise ValueError("reuse requires only a candidate index")
        elif self.action == "new_candidate":
            if self.capability_index is None or self.candidate_index is not None:
                raise ValueError("new_candidate requires only a capability index")
        elif self.candidate_index is not None or self.capability_index is not None:
            raise ValueError("generic and review cannot select an index")
        return self


class RegionCapabilitySelector(Protocol):
    async def select(
        self, request: RegionCapabilitySelectionRequest
    ) -> RegionCapabilityModelChoice | object: ...


class RegionCapabilityRoutingPolicy(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    structural_weight: float = Field(default=0.55, ge=0.0, le=1.0)
    vector_weight: float = Field(default=0.35, ge=0.0, le=1.0)
    success_weight: float = Field(default=0.10, ge=0.0, le=1.0)
    model_candidate_min_score: float = Field(default=0.65, ge=0.0, le=1.0)
    auto_reuse_min_score: float = Field(default=0.92, ge=0.0, le=1.0)
    model_reuse_min_score: float = Field(default=0.80, ge=0.0, le=1.0)
    model_reuse_min_confidence: float = Field(default=0.85, ge=0.0, le=1.0)
    model_new_candidate_min_confidence: float = Field(default=0.90, ge=0.0, le=1.0)
    min_margin: float = Field(default=0.08, ge=0.0, le=1.0)
    max_model_candidates: int = Field(default=5, ge=1, le=5)

    @model_validator(mode="after")
    def validate_policy(self) -> Self:
        numeric = (
            self.structural_weight,
            self.vector_weight,
            self.success_weight,
            self.model_candidate_min_score,
            self.auto_reuse_min_score,
            self.model_reuse_min_score,
            self.model_reuse_min_confidence,
            self.model_new_candidate_min_confidence,
            self.min_margin,
        )
        if not all(math.isfinite(item) for item in numeric):
            raise ValueError("routing weights and thresholds must be finite")
        if self.structural_weight + self.vector_weight + self.success_weight <= 0:
            raise ValueError("at least one routing weight must be positive")
        if self.auto_reuse_min_score < self.model_reuse_min_score:
            raise ValueError(
                "automatic reuse must be at least as strict as model reuse"
            )
        if self.model_reuse_min_score < self.model_candidate_min_score:
            raise ValueError("model reuse cannot be below candidate admission")
        return self


CapabilityRouteAction = Literal["route", "generic", "review", "new_candidate"]
CapabilityRouteReason = Literal[
    "exact_active_profile",
    "vector_auto_reuse",
    "model_reuse",
    "model_generic",
    "model_review",
    "model_new_candidate",
    "no_compatible_capabilities",
    "no_active_candidates",
    "exact_profile_incompatible",
    "active_profile_failed",
    "tenant_scope_violation",
    "embedding_unavailable",
    "embedding_failure",
    "embedding_circuit_open",
    "store_failure",
    "store_circuit_open",
    "selector_unavailable",
    "model_failure",
    "model_circuit_open",
    "invalid_model_output",
    "model_candidate_invalid",
    "model_candidate_not_top",
    "candidate_score_below_threshold",
    "candidate_margin_below_threshold",
    "model_confidence_below_threshold",
    "model_capability_invalid",
    "candidate_store_failure",
]


class RegionCapabilityRoutingDecision(BaseModel):
    """Auditable execution recommendation; it never contains or mutates evidence."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.region-capability-decision.v1"] = (
        "m1.region-capability-decision.v1"
    )
    action: CapabilityRouteAction
    reason: CapabilityRouteReason
    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    capability: ParsingCapability | None = None
    proposed_capability: ParsingCapability | None = None
    profile_id: str | None = Field(default=None, max_length=128)
    candidate_profile_id: str | None = Field(default=None, max_length=128)
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    top1_top2_margin: float = Field(default=0.0, ge=0.0, le=1.0)
    model_used: bool = False
    model_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    review_required: bool = False
    candidate_observation_required: bool = False

    @model_validator(mode="after")
    def validate_decision(self) -> Self:
        if self.action == "route":
            if self.capability is None or self.profile_id is None:
                raise ValueError("route requires an active profile and capability")
        elif self.capability is not None or self.profile_id is not None:
            raise ValueError("only route may expose an executable capability")
        if self.action == "new_candidate":
            if self.proposed_capability is None or self.candidate_profile_id is None:
                raise ValueError("new candidate requires a persisted inactive profile")
        elif (
            self.proposed_capability is not None
            or self.candidate_profile_id is not None
        ):
            raise ValueError("only new_candidate may expose a candidate profile")
        if self.review_required != (self.action == "review"):
            raise ValueError("review flag must match review action")
        if self.candidate_observation_required != (self.action == "new_candidate"):
            raise ValueError("candidate flag must match new_candidate action")
        return self


__all__ = [
    "REGION_CAPABILITY_CONTRACT_REVISION",
    "CapabilityProfileStatus",
    "CapabilityRouteAction",
    "CapabilityRouteReason",
    "ComplexityBucket",
    "ConfidenceBucket",
    "CoverageBucket",
    "OrientationBucket",
    "ParsingCapability",
    "RegionCapabilityCandidateProposal",
    "RegionCapabilityEmbeddingProvider",
    "RegionCapabilityExecutionObservation",
    "RegionCapabilityModelChoice",
    "RegionCapabilityProbe",
    "RegionCapabilityProfile",
    "RegionCapabilityProfileMatch",
    "RegionCapabilityRankedCandidate",
    "RegionCapabilityRouteStore",
    "RegionCapabilityRoutingDecision",
    "RegionCapabilityRoutingPolicy",
    "RegionCapabilitySelectionCandidate",
    "RegionCapabilitySelectionRequest",
    "RegionCapabilitySelector",
    "RegionCapabilitySignature",
    "RegionFeature",
    "RegionKind",
    "RegionScope",
    "RegionSourceKind",
    "TableState",
    "TextPresence",
]
