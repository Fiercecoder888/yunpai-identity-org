"""Value-free probe adapters for page and region capability routing."""

from __future__ import annotations

from collections.abc import Sequence

from .evidence import EvidencePage
from .region_capability_contracts import (
    ComplexityBucket,
    ConfidenceBucket,
    CoverageBucket,
    OrientationBucket,
    ParsingCapability,
    RegionCapabilityProbe,
    RegionFeature,
    RegionKind,
    RegionScope,
    RegionSourceKind,
    TableState,
    TextPresence,
)

_VISUAL_KINDS = frozenset({"image", "figure", "chart", "seal", "stamp", "drawing"})


def _text_presence(page: EvidencePage) -> TextPresence:
    count = len(page.text.strip())
    if count == 0:
        return TextPresence.NONE
    if count <= 64:
        return TextPresence.SPARSE
    return TextPresence.SUBSTANTIAL


def _confidence_bucket(page: EvidencePage) -> ConfidenceBucket:
    confidence = page.mean_text_confidence
    if confidence is None:
        return ConfidenceBucket.UNKNOWN
    if confidence < 0.75:
        return ConfidenceBucket.LOW
    if confidence < 0.90:
        return ConfidenceBucket.MEDIUM
    return ConfidenceBucket.HIGH


def _coverage_bucket(page: EvidencePage) -> CoverageBucket:
    coverage = page.visual_coverage_ratio
    if coverage <= 0:
        return CoverageBucket.NONE
    if coverage < 0.05:
        return CoverageBucket.LOW
    if coverage < 0.20:
        return CoverageBucket.MEDIUM
    if coverage < 0.50:
        return CoverageBucket.HIGH
    return CoverageBucket.DOMINANT


def _table_state(page: EvidencePage) -> TableState:
    if not page.tables:
        return TableState.NONE
    if page.dominant_complex_table:
        return TableState.COMPLEX
    if any(not table.rows and not table.cells for table in page.tables):
        return TableState.UNSTRUCTURED
    return TableState.STRUCTURED


def _orientation(page: EvidencePage) -> OrientationBucket:
    difference = abs(page.width - page.height) / max(page.width, page.height)
    if difference <= 0.10:
        return OrientationBucket.SQUARE
    if page.width > page.height:
        return OrientationBucket.LANDSCAPE
    return OrientationBucket.PORTRAIT


def _region_kind(page: EvidencePage) -> RegionKind:
    block_kinds = {str(block.kind or "").strip().casefold() for block in page.blocks}
    visual_kinds = block_kinds & _VISUAL_KINDS
    has_text = bool(page.text.strip())
    if page.tables and (visual_kinds or has_text):
        return RegionKind.MIXED
    if page.tables:
        return RegionKind.TABLE
    if visual_kinds:
        if has_text or len(visual_kinds) > 1:
            return RegionKind.MIXED
        kind = next(iter(visual_kinds))
        if kind == "chart":
            return RegionKind.CHART
        if kind in {"seal", "stamp"}:
            return RegionKind.SEAL
        if kind == "drawing":
            return RegionKind.DRAWING
        if kind == "figure":
            return RegionKind.FIGURE
        return RegionKind.IMAGE
    return RegionKind.TEXT if has_text else RegionKind.UNKNOWN


def _features(
    page: EvidencePage,
    *,
    source_kind: RegionSourceKind,
) -> tuple[RegionFeature, ...]:
    result: list[RegionFeature] = []
    if any(block.bbox is not None for block in page.blocks) or any(
        table.bbox is not None or any(cell.bbox is not None for cell in table.cells)
        for table in page.tables
    ):
        result.append(RegionFeature.HAS_COORDINATES)
    if page.rotation % 360:
        result.append(RegionFeature.HAS_ROTATION)
    if any(table.rows or table.cells for table in page.tables):
        result.append(RegionFeature.HAS_CELL_MATRIX)
    visual_blocks = any(
        str(block.kind or "").strip().casefold() in _VISUAL_KINDS
        for block in page.blocks
    )
    if source_kind is RegionSourceKind.IMAGE_REGION or visual_blocks:
        result.append(RegionFeature.HAS_RASTER)
    if visual_blocks:
        result.append(RegionFeature.HAS_EMBEDDED_IMAGES)
    return tuple(result)


def _complexity(
    page: EvidencePage,
    *,
    region_kind: RegionKind,
    table_state: TableState,
) -> ComplexityBucket:
    if (
        table_state is TableState.COMPLEX
        or len(page.tables) > 2
        or len(page.blocks) > 200
        or region_kind is RegionKind.MIXED
    ):
        return ComplexityBucket.HIGH
    if (
        page.tables
        or len(page.blocks) > 50
        or region_kind
        in {
            RegionKind.IMAGE,
            RegionKind.FIGURE,
            RegionKind.CHART,
            RegionKind.SEAL,
            RegionKind.DRAWING,
        }
    ):
        return ComplexityBucket.MEDIUM
    return ComplexityBucket.LOW


def build_page_capability_probe(
    page: EvidencePage,
    *,
    source_kind: RegionSourceKind,
    producer_revision: str = "m1.region-probe.v2",
    attempted_capabilities: Sequence[ParsingCapability] = (),
) -> RegionCapabilityProbe:
    """Reduce one evidence page to stable buckets without retaining its content."""

    region_kind = _region_kind(page)
    table_state = _table_state(page)
    return RegionCapabilityProbe(
        producer_revision=producer_revision,
        source_kind=source_kind,
        scope=RegionScope.PAGE,
        region_kind=region_kind,
        text_presence=_text_presence(page),
        text_confidence=_confidence_bucket(page),
        visual_coverage=_coverage_bucket(page),
        table_state=table_state,
        orientation=_orientation(page),
        complexity=_complexity(
            page,
            region_kind=region_kind,
            table_state=table_state,
        ),
        features=_features(page, source_kind=source_kind),
        attempted_capabilities=tuple(attempted_capabilities),
    )


__all__ = ["build_page_capability_probe"]
