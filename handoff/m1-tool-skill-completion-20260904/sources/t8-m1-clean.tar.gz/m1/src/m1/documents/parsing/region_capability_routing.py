"""Governed page and region parser-capability routing.

The service owns exact and vector lookup. The optional small model sees only
bounded candidate and capability indexes. A novel route is persisted as an
inactive candidate and is never executable for the current request.
"""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from typing import Protocol

from pydantic import ValidationError

from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .region_capability_contracts import (
    CapabilityProfileStatus,
    ParsingCapability,
    RegionCapabilityCandidateProposal,
    RegionCapabilityEmbeddingProvider,
    RegionCapabilityExecutionObservation,
    RegionCapabilityModelChoice,
    RegionCapabilityProbe,
    RegionCapabilityProfile,
    RegionCapabilityProfileMatch,
    RegionCapabilityRankedCandidate,
    RegionCapabilityRouteStore,
    RegionCapabilityRoutingDecision,
    RegionCapabilityRoutingPolicy,
    RegionCapabilitySelectionCandidate,
    RegionCapabilitySelectionRequest,
    RegionCapabilitySelector,
    RegionCapabilitySignature,
    RegionSourceKind,
)

_CAPABILITY_SOURCE_KINDS: Mapping[ParsingCapability, frozenset[RegionSourceKind]] = {
    ParsingCapability.NATIVE: frozenset(
        {
            RegionSourceKind.PDF_PAGE,
            RegionSourceKind.SPREADSHEET_REGION,
            RegionSourceKind.WORD_REGION,
            RegionSourceKind.PRESENTATION_REGION,
            RegionSourceKind.HTML_REGION,
            RegionSourceKind.CAD_REGION,
        }
    ),
    ParsingCapability.MINERU: frozenset(RegionSourceKind),
    ParsingCapability.PP_STRUCTURE_V3: frozenset(
        {RegionSourceKind.PDF_PAGE, RegionSourceKind.IMAGE_REGION}
    ),
    ParsingCapability.PADDLEOCR_VL: frozenset(
        {RegionSourceKind.PDF_PAGE, RegionSourceKind.IMAGE_REGION}
    ),
    ParsingCapability.DOCLING: frozenset(
        {
            RegionSourceKind.PDF_PAGE,
            RegionSourceKind.SPREADSHEET_REGION,
            RegionSourceKind.WORD_REGION,
            RegionSourceKind.PRESENTATION_REGION,
            RegionSourceKind.HTML_REGION,
        }
    ),
    ParsingCapability.OCR: frozenset(
        {RegionSourceKind.PDF_PAGE, RegionSourceKind.IMAGE_REGION}
    ),
}


class RegionCapabilityStructuredRun(Protocol):
    output: object


class RegionCapabilityStructuredClient(Protocol):
    async def run(
        self,
        output_type: type[RegionCapabilityModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> RegionCapabilityStructuredRun: ...


class PydanticRegionCapabilitySelector:
    """Prompted-output adapter for one closed candidate-index decision."""

    _INSTRUCTIONS = (
        "Choose a parser capability route using only the supplied value-free "
        "topology and closed indexes. Reuse may select only a candidate_index. "
        "new_candidate may select only a capability_index. Never invent a "
        "backend, profile ID, tenant, TaskID, document type, subtype, field, "
        "coordinate, source value, path, or executable instruction. Prefer "
        "generic or review whenever the supplied evidence is insufficient."
    )

    def __init__(self, client: RegionCapabilityStructuredClient) -> None:
        self._client = client

    async def select(
        self, request: RegionCapabilitySelectionRequest
    ) -> RegionCapabilityModelChoice:
        run = await self._client.run(
            RegionCapabilityModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=request.model_dump_json(),
            request_limit=1,
        )
        return RegionCapabilityModelChoice.model_validate(run.output, strict=True)


def capability_is_compatible(
    capability: ParsingCapability,
    signature: RegionCapabilitySignature,
    available_capabilities: Sequence[ParsingCapability],
) -> bool:
    """Apply the code-owned source and retry compatibility gates."""

    return bool(
        capability in available_capabilities
        and capability not in signature.attempted_capabilities
        and signature.source_kind in _CAPABILITY_SOURCE_KINDS[capability]
    )


def _profile_is_compatible(
    profile: RegionCapabilityProfile,
    signature: RegionCapabilitySignature,
    available_capabilities: Sequence[ParsingCapability],
) -> bool:
    return bool(
        profile.status is CapabilityProfileStatus.ACTIVE
        and profile.failure_count == 0
        and profile.signature.contract_revision == signature.contract_revision
        and profile.signature.producer_revision == signature.producer_revision
        and profile.signature.source_kind is signature.source_kind
        and profile.signature.scope is signature.scope
        and capability_is_compatible(
            profile.capability,
            signature,
            available_capabilities,
        )
    )


def _jaccard(left: frozenset[str], right: frozenset[str]) -> float:
    union = left | right
    if not union:
        return 1.0
    return len(left & right) / len(union)


class RegionCapabilityRoutingRuntime:
    """Resolve an active parser capability or observe an inactive candidate."""

    def __init__(
        self,
        *,
        store: RegionCapabilityRouteStore,
        embedding_provider: RegionCapabilityEmbeddingProvider | None = None,
        selector: RegionCapabilitySelector | None = None,
        policy: RegionCapabilityRoutingPolicy | None = None,
        available_capabilities: Sequence[ParsingCapability] = tuple(ParsingCapability),
        required: bool = False,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
    ) -> None:
        capabilities = tuple(available_capabilities)
        if not capabilities or len(capabilities) != len(set(capabilities)):
            raise ValueError("available capabilities must be nonempty and unique")
        if any(not isinstance(item, ParsingCapability) for item in capabilities):
            raise TypeError("available capabilities must use the closed enum")
        self.store = store
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.policy = policy or RegionCapabilityRoutingPolicy()
        self.available_capabilities = capabilities
        self.required = bool(required)
        self._status = DocumentRoutingStatus(
            circuit_failures=circuit_failures,
            circuit_seconds=circuit_seconds,
        )

    def status_snapshot(self) -> dict[str, object]:
        return self._status.snapshot()

    def _eligible_capabilities(
        self, signature: RegionCapabilitySignature
    ) -> tuple[ParsingCapability, ...]:
        return tuple(
            capability
            for capability in self.available_capabilities
            if capability_is_compatible(
                capability,
                signature,
                self.available_capabilities,
            )
        )

    @staticmethod
    def _metrics(
        ranked: Sequence[RegionCapabilityRankedCandidate],
    ) -> tuple[float, float]:
        if not ranked:
            return 0.0, 0.0
        top = ranked[0].fused_score
        second = ranked[1].fused_score if len(ranked) > 1 else 0.0
        return top, max(0.0, top - second)

    def _decision(
        self,
        *,
        signature: RegionCapabilitySignature,
        action: str,
        reason: str,
        capability: ParsingCapability | None = None,
        proposed_capability: ParsingCapability | None = None,
        profile_id: str | None = None,
        candidate_profile_id: str | None = None,
        ranked: Sequence[RegionCapabilityRankedCandidate] = (),
        model_used: bool = False,
        model_confidence: float | None = None,
    ) -> RegionCapabilityRoutingDecision:
        top_score, margin = self._metrics(ranked)
        return RegionCapabilityRoutingDecision(
            action=action,
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            capability=capability,
            proposed_capability=proposed_capability,
            profile_id=profile_id,
            candidate_profile_id=candidate_profile_id,
            top_score=top_score,
            top1_top2_margin=margin,
            model_used=model_used,
            model_confidence=model_confidence,
            review_required=action == "review",
            candidate_observation_required=action == "new_candidate",
        )

    async def _embed(
        self, signature: RegionCapabilitySignature
    ) -> tuple[tuple[float, ...], str, int]:
        provider = self.embedding_provider
        if provider is None:
            raise RuntimeError("embedding provider unavailable")
        model = str(provider.model).strip()
        dimensions = int(provider.dimensions)
        if not model or dimensions < 1:
            raise ValueError("embedding provider identity is invalid")
        values = await provider.embed_texts((signature.embedding_text(),))
        if len(values) != 1:
            raise ValueError("embedding provider returned an unexpected vector count")
        vector = tuple(float(item) for item in values[0])
        if len(vector) != dimensions or not all(math.isfinite(item) for item in vector):
            raise ValueError("embedding provider returned an invalid vector")
        return vector, model, dimensions

    def _rank(
        self,
        signature: RegionCapabilitySignature,
        match: RegionCapabilityProfileMatch,
    ) -> RegionCapabilityRankedCandidate:
        profile = match.profile
        structural = _jaccard(
            signature.structural_tokens(),
            profile.signature.structural_tokens(),
        )
        vector = max(0.0, min(1.0, float(match.vector_similarity)))
        success = profile.success_rate
        neutral_success = 0.5 if success is None else success
        total = (
            self.policy.structural_weight
            + self.policy.vector_weight
            + self.policy.success_weight
        )
        fused = (
            structural * self.policy.structural_weight
            + vector * self.policy.vector_weight
            + neutral_success * self.policy.success_weight
        ) / total
        return RegionCapabilityRankedCandidate(
            profile_id=profile.profile_id,
            capability=profile.capability,
            structural_similarity=max(0.0, min(1.0, structural)),
            vector_similarity=vector,
            fused_score=max(0.0, min(1.0, fused)),
            success_rate=success,
        )

    @staticmethod
    def _selector_candidates(
        ranked: Sequence[RegionCapabilityRankedCandidate],
    ) -> tuple[RegionCapabilitySelectionCandidate, ...]:
        return tuple(
            RegionCapabilitySelectionCandidate(
                candidate_index=index,
                capability=item.capability,
                structural_similarity=item.structural_similarity,
                vector_similarity=item.vector_similarity,
                fused_score=item.fused_score,
                success_rate=item.success_rate,
            )
            for index, item in enumerate(ranked)
        )

    async def _create_candidate(
        self,
        *,
        tenant_id: str,
        signature: RegionCapabilitySignature,
        capability: ParsingCapability,
        embedding: tuple[float, ...] | None,
        embedding_model: str,
        embedding_dimensions: int,
    ) -> RegionCapabilityProfile | None:
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return None
        if not capability_is_compatible(
            capability,
            signature,
            self.available_capabilities,
        ):
            return None
        proposal = RegionCapabilityCandidateProposal(
            tenant_id=tenant_id,
            profile_key=(
                f"region-capability:{signature.exact_fingerprint()[:20]}:"
                f"{capability.value}"
            ),
            signature=signature,
            capability=capability,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
        )
        try:
            candidate = await self.store.create_region_capability_candidate(proposal)
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - candidate state is non-authoritative
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return None
        if (
            candidate.status is not CapabilityProfileStatus.CANDIDATE
            or candidate.tenant_id != tenant_id
            or candidate.exact_fingerprint != signature.exact_fingerprint()
            or candidate.signature != signature
            or candidate.capability is not capability
        ):
            controlled = self._status.note_dependency_failure(
                "profile", ValueError("candidate store returned a mismatched profile")
            )
            if self.required:
                raise controlled from None
            return None
        return candidate

    async def _resolve(
        self,
        *,
        tenant_id: str,
        probe: RegionCapabilityProbe,
    ) -> RegionCapabilityRoutingDecision:
        if not tenant_id or tenant_id != tenant_id.strip():
            raise ValueError("tenant ID must be normalized and nonempty")
        signature = probe.signature()
        eligible = self._eligible_capabilities(signature)
        if not eligible:
            return self._decision(
                signature=signature,
                action="generic",
                reason="no_compatible_capabilities",
            )

        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            return self._decision(
                signature=signature,
                action="generic",
                reason="store_circuit_open",
            )
        try:
            exact = (
                await self.store.get_active_region_capability_profile_by_fingerprint(
                    tenant_id,
                    signature.exact_fingerprint(),
                    contract_revision=signature.contract_revision,
                    producer_revision=signature.producer_revision,
                )
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - routing is optional unless required
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self._decision(
                signature=signature,
                action="generic",
                reason="store_failure",
            )
        if exact is not None:
            if exact.tenant_id != tenant_id:
                return self._decision(
                    signature=signature,
                    action="review",
                    reason="tenant_scope_violation",
                )
            if (
                exact.exact_fingerprint != signature.exact_fingerprint()
                or exact.signature != signature
            ):
                return self._decision(
                    signature=signature,
                    action="review",
                    reason="exact_profile_incompatible",
                )
            if exact.failure_count:
                return self._decision(
                    signature=signature,
                    action="review",
                    reason="active_profile_failed",
                )
            if not _profile_is_compatible(exact, signature, eligible):
                return self._decision(
                    signature=signature,
                    action="review",
                    reason="exact_profile_incompatible",
                )
            ranked = (
                RegionCapabilityRankedCandidate(
                    profile_id=exact.profile_id,
                    capability=exact.capability,
                    structural_similarity=1.0,
                    vector_similarity=1.0,
                    fused_score=1.0,
                    success_rate=exact.success_rate,
                ),
            )
            return self._decision(
                signature=signature,
                action="route",
                reason="exact_active_profile",
                capability=exact.capability,
                profile_id=exact.profile_id,
                ranked=ranked,
            )

        if self.embedding_provider is None:
            if self.required:
                error = RuntimeError("embedding provider unavailable")
                raise self._status.note_dependency_failure("embedding", error) from None
            return self._decision(
                signature=signature,
                action="generic",
                reason="embedding_unavailable",
            )
        if self._status.circuit_open("embedding"):
            if self.required:
                raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
            return self._decision(
                signature=signature,
                action="generic",
                reason="embedding_circuit_open",
            )
        try:
            embedding, embedding_model, embedding_dimensions = await self._embed(
                signature
            )
            self._status.note_dependency_success("embedding")
        except Exception as exc:  # noqa: BLE001 - generic parser remains authoritative
            controlled = self._status.note_dependency_failure("embedding", exc)
            if self.required:
                raise controlled from None
            return self._decision(
                signature=signature,
                action="generic",
                reason=(
                    "embedding_circuit_open"
                    if self._status.circuit_open("embedding")
                    else "embedding_failure"
                ),
            )

        try:
            matches = await self.store.find_active_region_capability_profiles(
                tenant_id,
                embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                contract_revision=signature.contract_revision,
                producer_revision=signature.producer_revision,
                source_kind=signature.source_kind,
                scope=signature.scope,
                limit=min(100, self.policy.max_model_candidates * 4),
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - generic parser remains authoritative
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self._decision(
                signature=signature,
                action="generic",
                reason=(
                    "store_circuit_open"
                    if self._status.circuit_open("store")
                    else "store_failure"
                ),
            )

        profiles: dict[str, RegionCapabilityProfile] = {}
        ranked_by_id: dict[str, RegionCapabilityRankedCandidate] = {}
        for match in matches:
            profile = match.profile
            if (
                profile.tenant_id != tenant_id
                or profile.embedding_model != embedding_model
                or profile.embedding_dimensions != embedding_dimensions
                or not _profile_is_compatible(profile, signature, eligible)
            ):
                continue
            item = self._rank(signature, match)
            if item.fused_score < self.policy.model_candidate_min_score:
                continue
            profiles[profile.profile_id] = profile
            ranked_by_id[profile.profile_id] = item
        ranked = tuple(
            sorted(
                ranked_by_id.values(),
                key=lambda item: (-item.fused_score, item.profile_id),
            )[: self.policy.max_model_candidates]
        )
        top_score, margin = self._metrics(ranked)
        if (
            ranked
            and top_score >= self.policy.auto_reuse_min_score
            and margin >= self.policy.min_margin
        ):
            selected = ranked[0]
            profile = profiles[selected.profile_id]
            return self._decision(
                signature=signature,
                action="route",
                reason="vector_auto_reuse",
                capability=profile.capability,
                profile_id=profile.profile_id,
                ranked=ranked,
            )

        if self.selector is None:
            if self.required:
                error = RuntimeError("region capability selector unavailable")
                raise self._status.note_dependency_failure("model", error) from None
            return self._decision(
                signature=signature,
                action="generic",
                reason=("selector_unavailable" if ranked else "no_active_candidates"),
                ranked=ranked,
            )
        if self._status.circuit_open("model"):
            if self.required:
                raise DocumentRoutingDependencyError("model", "CircuitOpen")
            return self._decision(
                signature=signature,
                action="generic",
                reason="model_circuit_open",
                ranked=ranked,
            )
        request = RegionCapabilitySelectionRequest(
            signature=signature,
            candidates=self._selector_candidates(ranked),
            available_capabilities=eligible,
        )
        try:
            raw_choice = await self.selector.select(request)
            choice = RegionCapabilityModelChoice.model_validate(raw_choice, strict=True)
            self._status.note_dependency_success("model")
        except (TypeError, ValueError, ValidationError) as exc:
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            return self._decision(
                signature=signature,
                action="generic",
                reason=(
                    "model_circuit_open"
                    if self._status.circuit_open("model")
                    else "invalid_model_output"
                ),
                ranked=ranked,
                model_used=True,
            )
        except Exception as exc:  # noqa: BLE001 - generic parser remains authoritative
            controlled = self._status.note_dependency_failure("model", exc)
            if self.required:
                raise controlled from None
            return self._decision(
                signature=signature,
                action="generic",
                reason=(
                    "model_circuit_open"
                    if self._status.circuit_open("model")
                    else "model_failure"
                ),
                ranked=ranked,
                model_used=True,
            )

        common = {
            "signature": signature,
            "ranked": ranked,
            "model_used": True,
            "model_confidence": choice.confidence,
        }
        if choice.action == "generic":
            return self._decision(action="generic", reason="model_generic", **common)
        if choice.action == "review":
            return self._decision(action="review", reason="model_review", **common)
        if choice.action == "reuse":
            index = choice.candidate_index
            if index is None or index >= len(ranked):
                return self._decision(
                    action="review", reason="model_candidate_invalid", **common
                )
            if index != 0:
                return self._decision(
                    action="review", reason="model_candidate_not_top", **common
                )
            selected = ranked[index]
            if selected.fused_score < self.policy.model_reuse_min_score:
                return self._decision(
                    action="review",
                    reason="candidate_score_below_threshold",
                    **common,
                )
            if margin < self.policy.min_margin:
                return self._decision(
                    action="review",
                    reason="candidate_margin_below_threshold",
                    **common,
                )
            if choice.confidence < self.policy.model_reuse_min_confidence:
                return self._decision(
                    action="review",
                    reason="model_confidence_below_threshold",
                    **common,
                )
            profile = profiles[selected.profile_id]
            return self._decision(
                action="route",
                reason="model_reuse",
                capability=profile.capability,
                profile_id=profile.profile_id,
                **common,
            )

        capability_index = choice.capability_index
        if capability_index is None or capability_index >= len(eligible):
            return self._decision(
                action="review", reason="model_capability_invalid", **common
            )
        if choice.confidence < self.policy.model_new_candidate_min_confidence:
            return self._decision(
                action="review",
                reason="model_confidence_below_threshold",
                **common,
            )
        proposed_capability = eligible[capability_index]
        candidate = await self._create_candidate(
            tenant_id=tenant_id,
            signature=signature,
            capability=proposed_capability,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
        )
        if candidate is None:
            return self._decision(
                action="generic", reason="candidate_store_failure", **common
            )
        return self._decision(
            action="new_candidate",
            reason="model_new_candidate",
            proposed_capability=proposed_capability,
            candidate_profile_id=candidate.profile_id,
            **common,
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        probe: RegionCapabilityProbe,
    ) -> RegionCapabilityRoutingDecision:
        """Resolve without receiving or retaining a TaskID or source payload."""

        return await self._status.track_operation(
            self._resolve(tenant_id=tenant_id, probe=probe)
        )

    async def record_execution_observation(
        self,
        observation: RegionCapabilityExecutionObservation,
    ) -> bool:
        """Persist a reviewed page/region outcome through the governed store."""

        if observation.tenant_id.strip() != observation.tenant_id:
            raise ValueError("observation tenant_id must be normalized")
        record = getattr(
            self.store,
            "record_region_capability_execution_observation",
            None,
        )
        if not callable(record):
            return False
        await record(observation)
        return True

    async def observe_candidate(
        self,
        *,
        tenant_id: str,
        probe: RegionCapabilityProbe,
        capability: ParsingCapability,
    ) -> RegionCapabilityProfile:
        """Persist a validated inactive candidate without activating or executing it."""

        if not tenant_id or tenant_id != tenant_id.strip():
            raise ValueError("tenant ID must be normalized and nonempty")
        signature = probe.signature()
        if not capability_is_compatible(
            capability,
            signature,
            self.available_capabilities,
        ):
            raise ValueError("capability is not compatible with the region signature")
        embedding: tuple[float, ...] | None = None
        embedding_model = ""
        embedding_dimensions = 0
        if self.embedding_provider is not None:
            if self._status.circuit_open("embedding"):
                if self.required:
                    raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
            else:
                try:
                    (
                        embedding,
                        embedding_model,
                        embedding_dimensions,
                    ) = await self._embed(signature)
                    self._status.note_dependency_success("embedding")
                except Exception as exc:  # noqa: BLE001 - exact candidate is optional
                    controlled = self._status.note_dependency_failure("embedding", exc)
                    if self.required:
                        raise controlled from None
        elif self.required:
            error = RuntimeError("embedding provider unavailable")
            raise self._status.note_dependency_failure("embedding", error) from None
        candidate = await self._create_candidate(
            tenant_id=tenant_id,
            signature=signature,
            capability=capability,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
        )
        if candidate is None:
            raise RuntimeError("region capability candidate could not be persisted")
        return candidate


__all__ = [
    "PydanticRegionCapabilitySelector",
    "RegionCapabilityRoutingRuntime",
    "RegionCapabilityStructuredClient",
    "RegionCapabilityStructuredRun",
    "capability_is_compatible",
]
