"""Aggregate semantic enrichment without mutating the projected document.

The completion is deliberately separate from the benchmark runner.  It combines
existing replay-validated extraction evidence with additive semantic facts and
then assigns every evidence item exactly one auditable disposition.
"""

from __future__ import annotations

import math
import re
import unicodedata
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .docx_semantics import (
    extract_docx_process_facts,
    extract_filename_advisory_facts,
)
from .drawing_semantics import (
    DrawingAssetObservation,
    associate_drawing_assets,
    extract_drawing_semantics,
)
from .evidence import DocumentEvidence
from .mineru_instructor_poc import (
    EvidenceReference,
    ExtractedFact,
    MinerUInstructorResult,
    _redundant_consumed_block_ids,
    evidence_inventory,
)
from .semantic_facts import (
    EvidenceDisposition,
    SemanticFact,
    audit_evidence_dispositions,
    stable_fact_id,
)


class _StrictCompletionModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        strict=True,
        validate_assignment=True,
    )


class SemanticCompletionCounts(_StrictCompletionModel):
    evidence_total: int = Field(ge=0)
    source_evidence_total: int = Field(ge=0)
    supplemental_evidence_total: int = Field(ge=0)
    evidence_accounted: int = Field(ge=0)
    evidence_structured: int = Field(ge=0)
    evidence_schema: int = Field(ge=0)
    evidence_redundant: int = Field(ge=0)
    evidence_non_semantic: int = Field(ge=0)
    evidence_ambiguous: int = Field(ge=0)
    evidence_needs_review: int = Field(ge=0)
    evidence_verified: int = Field(ge=0)
    evidence_advisory: int = Field(ge=0)
    source_evidence_structured: int = Field(ge=0)
    source_evidence_schema: int = Field(ge=0)
    source_evidence_redundant: int = Field(ge=0)
    source_evidence_non_semantic: int = Field(ge=0)
    source_evidence_ambiguous: int = Field(ge=0)
    source_evidence_needs_review: int = Field(ge=0)
    source_evidence_verified: int = Field(ge=0)
    source_evidence_advisory: int = Field(ge=0)
    supplemental_evidence_structured: int = Field(ge=0)
    supplemental_evidence_schema: int = Field(ge=0)
    supplemental_evidence_redundant: int = Field(ge=0)
    supplemental_evidence_non_semantic: int = Field(ge=0)
    supplemental_evidence_ambiguous: int = Field(ge=0)
    supplemental_evidence_needs_review: int = Field(ge=0)
    supplemental_evidence_verified: int = Field(ge=0)
    supplemental_evidence_advisory: int = Field(ge=0)
    facts_total: int = Field(ge=0)
    facts_verified: int = Field(ge=0)
    facts_ambiguous: int = Field(ge=0)
    facts_advisory: int = Field(ge=0)
    source_facts_verified: int = Field(ge=0)
    source_facts_ambiguous: int = Field(ge=0)
    source_facts_advisory: int = Field(ge=0)
    supplemental_facts_verified: int = Field(ge=0)
    supplemental_facts_ambiguous: int = Field(ge=0)
    supplemental_facts_advisory: int = Field(ge=0)


class SemanticCompletionRatios(_StrictCompletionModel):
    audit_completeness: float = Field(ge=0.0, le=1.0)
    source_semantically_verified: float = Field(ge=0.0, le=1.0)
    source_structured: float = Field(ge=0.0, le=1.0)
    source_requiring_review: float = Field(ge=0.0, le=1.0)
    # Deprecated compatibility aliases. They are source-based and can no
    # longer be inflated by supplemental character or region evidence.
    evidence_accounting: float = Field(ge=0.0, le=1.0)
    audited_structured: float = Field(ge=0.0, le=1.0)
    audited_requiring_review: float = Field(ge=0.0, le=1.0)


class SemanticCompletion(_StrictCompletionModel):
    schema_version: Literal["m1.semantic-completion.v1"] = (
        "m1.semantic-completion.v1"
    )
    facts: list[SemanticFact] = Field(default_factory=list)
    dispositions: list[EvidenceDisposition] = Field(default_factory=list)
    counts: SemanticCompletionCounts
    ratios: SemanticCompletionRatios
    review_required: bool

    @model_validator(mode="after")
    def internally_consistent(self) -> SemanticCompletion:
        evidence_status_total = sum(
            (
                self.counts.evidence_structured,
                self.counts.evidence_schema,
                self.counts.evidence_redundant,
                self.counts.evidence_non_semantic,
                self.counts.evidence_ambiguous,
                self.counts.evidence_needs_review,
            )
        )
        fact_status_total = sum(
            (
                self.counts.facts_verified,
                self.counts.facts_ambiguous,
                self.counts.facts_advisory,
            )
        )
        if self.counts.evidence_total != len(self.dispositions):
            raise ValueError("evidence_total must equal disposition count")
        if self.counts.evidence_total != (
            self.counts.source_evidence_total
            + self.counts.supplemental_evidence_total
        ):
            raise ValueError("source and supplemental evidence totals are inconsistent")
        if self.counts.evidence_accounted != evidence_status_total:
            raise ValueError("evidence_accounted must equal status counts")
        if self.counts.evidence_total != evidence_status_total:
            raise ValueError("every evidence item must have one disposition")
        source_status_total = sum(
            (
                self.counts.source_evidence_structured,
                self.counts.source_evidence_schema,
                self.counts.source_evidence_redundant,
                self.counts.source_evidence_non_semantic,
                self.counts.source_evidence_ambiguous,
                self.counts.source_evidence_needs_review,
            )
        )
        supplemental_status_total = sum(
            (
                self.counts.supplemental_evidence_structured,
                self.counts.supplemental_evidence_schema,
                self.counts.supplemental_evidence_redundant,
                self.counts.supplemental_evidence_non_semantic,
                self.counts.supplemental_evidence_ambiguous,
                self.counts.supplemental_evidence_needs_review,
            )
        )
        if source_status_total != self.counts.source_evidence_total:
            raise ValueError("source evidence status counts are inconsistent")
        if supplemental_status_total != self.counts.supplemental_evidence_total:
            raise ValueError("supplemental evidence status counts are inconsistent")
        if self.counts.evidence_verified + self.counts.evidence_advisory != (
            self.counts.evidence_structured
        ):
            raise ValueError("verified and advisory evidence must partition structured")
        if (
            self.counts.source_evidence_verified
            + self.counts.source_evidence_advisory
            != self.counts.source_evidence_structured
        ):
            raise ValueError("source verified/advisory counts are inconsistent")
        if (
            self.counts.supplemental_evidence_verified
            + self.counts.supplemental_evidence_advisory
            != self.counts.supplemental_evidence_structured
        ):
            raise ValueError("supplemental verified/advisory counts are inconsistent")
        if self.counts.facts_total != len(self.facts):
            raise ValueError("facts_total must equal fact count")
        if self.counts.facts_total != fact_status_total:
            raise ValueError("every fact must have one status")
        source_fact_total = sum(
            (
                self.counts.source_facts_verified,
                self.counts.source_facts_ambiguous,
                self.counts.source_facts_advisory,
            )
        )
        supplemental_fact_total = sum(
            (
                self.counts.supplemental_facts_verified,
                self.counts.supplemental_facts_ambiguous,
                self.counts.supplemental_facts_advisory,
            )
        )
        if source_fact_total + supplemental_fact_total != self.counts.facts_total:
            raise ValueError("source and supplemental fact counts are inconsistent")
        if len({item.evidence_id for item in self.dispositions}) != len(
            self.dispositions
        ):
            raise ValueError("completion dispositions must have unique evidence IDs")
        if len({fact.fact_id for fact in self.facts}) != len(self.facts):
            raise ValueError("completion facts must have unique fact IDs")
        total = self.counts.evidence_total
        source_total = self.counts.source_evidence_total
        expected_accounting = (
            self.counts.evidence_accounted / total if total else 1.0
        )
        expected_verified = (
            self.counts.source_evidence_verified / source_total
            if source_total
            else 1.0
        )
        expected_review = (
            (
                self.counts.source_evidence_ambiguous
                + self.counts.source_evidence_needs_review
            )
            / source_total
            if source_total
            else 0.0
        )
        for actual, expected, label in (
            (self.ratios.audit_completeness, expected_accounting, "audit_completeness"),
            (
                self.ratios.source_semantically_verified,
                expected_verified,
                "source_semantically_verified",
            ),
            (self.ratios.source_structured, expected_verified, "source_structured"),
            (
                self.ratios.source_requiring_review,
                expected_review,
                "source_requiring_review",
            ),
            (self.ratios.evidence_accounting, expected_accounting, "accounting"),
            (self.ratios.audited_structured, expected_verified, "structured"),
            (
                self.ratios.audited_requiring_review,
                expected_review,
                "requiring_review",
            ),
        ):
            if abs(actual - expected) > 1e-12:
                raise ValueError(f"evidence {label} ratio is inconsistent")
        return self


def build_semantic_completion(
    evidence: DocumentEvidence,
    original_filename: str,
    extracted: MinerUInstructorResult,
    projected_record: Mapping[str, Any],
    *,
    additional_facts: Iterable[SemanticFact] = (),
) -> SemanticCompletion:
    """Build one complete semantic audit without changing any input object.

    ``additional_facts`` is the integration point for drawing/image semantic
    builders.  Keeping it injectable avoids a hard dependency while that
    optional implementation is still evolving.
    """

    inventory = evidence_inventory(evidence)
    filename_facts = extract_filename_advisory_facts(original_filename)
    built_in_facts = [
        *extract_docx_process_facts(evidence),
        *filename_facts,
        *_drawing_facts(inventory),
        *_drawing_asset_facts(
            inventory,
            projected_record=projected_record,
            filename_facts=filename_facts,
        ),
    ]
    combined_facts = _unique_facts(
        [
            *built_in_facts,
            *list(additional_facts),
        ]
    )
    facts, reconciled_redundant_facts = _reconcile_drawing_region_facts(
        combined_facts
    )
    facts = _unique_facts(facts)
    _validate_filename_fact_authority(facts)
    inventory_ids = list(inventory)
    if "source.filename" not in inventory_ids:
        inventory_ids.append("source.filename")
    source_evidence_ids = set(inventory_ids)
    _validate_and_extend_semantic_evidence(
        inventory_ids,
        facts,
        inventory,
        original_filename=original_filename,
        validation_only_facts=reconciled_redundant_facts,
    )

    structured_ids = _existing_structured_evidence_ids(extracted)
    structured_ids.update(
        _projected_structured_evidence_ids(projected_record, inventory)
    )
    schema_ids = _reference_ids(extracted.schema_evidence)
    # A replay-validated final projection is more specific than the mapper's
    # earlier table-schema classification. Keep every evidence item in exactly
    # one disposition after technical fields have been materialized.
    schema_ids.difference_update(structured_ids)
    redundant_ids = _reference_ids(extracted.redundant_evidence) | {
        reference.evidence_id
        for fact in reconciled_redundant_facts
        for reference in fact.evidence_refs
    }
    redundant_ids.update(
        _redundant_consumed_block_ids(inventory, structured_ids)
        - structured_ids
    )
    redundant_ids.difference_update(structured_ids)
    fact_evidence_ids = {
        reference.evidence_id
        for fact in facts
        for reference in fact.evidence_refs
    }
    nonsemantic_ids = (
        {"source.filename"} if "source.filename" not in fact_evidence_ids else set()
    )

    dispositions = audit_evidence_dispositions(
        inventory_ids,
        facts,
        structured_evidence_ids=structured_ids,
        schema_evidence_ids=schema_ids,
        redundant_evidence_ids=redundant_ids,
        nonsemantic_evidence_ids=nonsemantic_ids,
    )
    counts = _completion_counts(
        dispositions,
        facts,
        source_evidence_ids=source_evidence_ids,
        existing_structured_ids=structured_ids,
    )
    total = counts.evidence_total
    source_total = counts.source_evidence_total
    review_evidence = (
        counts.source_evidence_ambiguous + counts.source_evidence_needs_review
    )
    audit_completeness = counts.evidence_accounted / total if total else 1.0
    source_verified = (
        counts.source_evidence_verified / source_total if source_total else 1.0
    )
    source_review = review_evidence / source_total if source_total else 0.0
    ratios = SemanticCompletionRatios(
        audit_completeness=audit_completeness,
        source_semantically_verified=source_verified,
        source_structured=source_verified,
        source_requiring_review=source_review,
        evidence_accounting=audit_completeness,
        audited_structured=source_verified,
        audited_requiring_review=source_review,
    )
    # ``needs_review`` is a legacy aggregate that is rebuilt later from the
    # final record.  Feeding it back into this audit makes a stale projection
    # permanently self-blocking even when every evidence disposition is safe.
    review_required = bool(
        not extracted.complete
        or review_evidence
        or any(fact.status == "ambiguous" for fact in facts)
    )
    return SemanticCompletion(
        facts=facts,
        dispositions=dispositions,
        counts=counts,
        ratios=ratios,
        review_required=review_required,
    )


def _existing_structured_evidence_ids(
    extracted: MinerUInstructorResult,
) -> set[str]:
    facts: list[ExtractedFact] = [
        *extracted.document_facts,
        *(
            fact
            for segment in extracted.segments
            for fact in [
                *segment.facts,
                *(field for record in segment.records for field in record.fields),
            ]
        ),
    ]
    evidence_ids = {
        reference.evidence_id
        for fact in facts
        for reference in fact.evidence_refs
        if _authoritative_reference(reference)
    }
    evidence_ids.update(
        unit.evidence_id
        for unit in extracted.content_units
        if unit.binding_source == "model"
        and _authoritative_source_ref(unit.source_ref)
    )
    return evidence_ids


def _projected_structured_evidence_ids(
    projected_record: Mapping[str, Any],
    inventory: Mapping[str, Any],
) -> set[str]:
    """Replay non-generic projected field refs into the semantic audit."""

    metadata = projected_record.get("field_meta")
    if not isinstance(metadata, Mapping):
        return set()
    evidence_ids: set[str] = set()
    for path, value in metadata.items():
        if str(path).startswith("$.generic_facts[") or not isinstance(value, Mapping):
            continue
        references = value.get("source_refs")
        if not isinstance(references, list):
            continue
        for reference in references:
            if not isinstance(reference, Mapping):
                continue
            evidence_id = str(reference.get("evidence_id") or "").strip()
            if not evidence_id:
                part = str(reference.get("part") or "").strip()
                if part.startswith("mineru/"):
                    evidence_id = part.removeprefix("mineru/")
            quote = _normalize_quote(str(reference.get("evidence_quote") or ""))
            item = inventory.get(evidence_id)
            if item is None or not quote:
                continue
            if reference.get("authority") == "advisory" or reference.get(
                "asset_sha256"
            ):
                continue
            source_text = _normalize_quote(item.exact_text or item.text)
            if quote in source_text:
                evidence_ids.add(evidence_id)
    return evidence_ids


def _authoritative_reference(reference: EvidenceReference) -> bool:
    return _authoritative_source_ref(reference.source_ref)


def _authoritative_source_ref(source_ref: Any) -> bool:
    extras = source_ref.model_extra or {}
    return not (
        source_ref.part == "source.original_filename"
        or extras.get("authority") == "advisory"
        or extras.get("asset_sha256")
    )


def _reference_ids(references: Iterable[EvidenceReference]) -> set[str]:
    return {reference.evidence_id for reference in references}


def _unique_facts(facts: Iterable[SemanticFact]) -> list[SemanticFact]:
    result: list[SemanticFact] = []
    by_id: dict[str, SemanticFact] = {}
    for fact in facts:
        previous = by_id.get(fact.fact_id)
        if previous is None:
            by_id[fact.fact_id] = fact
            result.append(fact)
            continue
        if previous != fact:
            raise ValueError(f"conflicting semantic fact ID: {fact.fact_id}")
    return result


def _validate_filename_fact_authority(facts: Iterable[SemanticFact]) -> None:
    for fact in facts:
        for reference in fact.evidence_refs:
            if reference.evidence_id != "source.filename":
                continue
            extras = reference.source_ref.model_extra or {}
            if (
                fact.status != "advisory"
                or reference.source_ref.part != "source.original_filename"
                or extras.get("authority") != "advisory"
            ):
                raise ValueError(
                    "source.filename semantic facts must remain advisory"
                )


def _reconcile_drawing_region_facts(
    facts: list[SemanticFact],
) -> tuple[list[SemanticFact], list[SemanticFact]]:
    """Reconcile region callouts against advisory whole-image callouts.

    Region transcription has better localization but remains advisory. Exact
    duplicates suppress the flattened fact and retain its evidence as an audit
    ``redundant`` item. Conflicts keep the region fact and make the flattened
    interpretation explicitly ambiguous instead of presenting two ordinary
    advisory values.
    """

    regions_by_key: dict[tuple[str, str, str], list[SemanticFact]] = {}
    for fact in facts:
        if fact.extractor != "drawing_region_vlm.v1":
            continue
        key = _drawing_reconciliation_key(fact)
        if key is not None:
            regions_by_key.setdefault(key, []).append(fact)

    reconciled: list[SemanticFact] = []
    redundant: list[SemanticFact] = []
    for fact in facts:
        if not _is_whole_image_drawing_fact(fact):
            reconciled.append(fact)
            continue
        key = _drawing_reconciliation_key(fact)
        regions = regions_by_key.get(key, []) if key is not None else []
        if not regions:
            reconciled.append(fact)
            continue
        if all(_same_drawing_value(fact, region) for region in regions):
            redundant.append(fact)
            continue
        conflicting_ids = sorted(
            region.fact_id
            for region in regions
            if not _same_drawing_value(fact, region)
        )
        attributes = dict(fact.attributes)
        attributes.update(
            {
                "conflict_source": "drawing_region_vlm.v1",
                "conflicts_with": (
                    conflicting_ids[0]
                    if len(conflicting_ids) == 1
                    else conflicting_ids
                ),
            }
        )
        fact_id = stable_fact_id(
            name=fact.name,
            value=fact.value,
            unit=fact.unit,
            subject=fact.subject,
            relation=fact.relation,
            attributes=attributes,
            evidence_ids=(
                reference.evidence_id for reference in fact.evidence_refs
            ),
        )
        reconciled.append(
            fact.model_copy(
                update={
                    "fact_id": fact_id,
                    "attributes": attributes,
                    "status": "ambiguous",
                },
                deep=True,
            )
        )
    return reconciled, redundant


def _is_whole_image_drawing_fact(fact: SemanticFact) -> bool:
    return bool(
        fact.extractor == "drawing_semantics.v1"
        and fact.status == "advisory"
        and fact.attributes.get("localization") == "whole_image_flattened"
    )


def _drawing_reconciliation_key(
    fact: SemanticFact,
) -> tuple[str, str, str] | None:
    if not isinstance(fact.value, dict):
        return None
    nominal = fact.value.get("nominal")
    dimension_type = fact.attributes.get("dimension_type")
    asset_hashes = {
        str((reference.source_ref.model_extra or {}).get("asset_sha256") or "")
        .strip()
        .casefold()
        for reference in fact.evidence_refs
    }
    asset_hashes.discard("")
    if (
        not isinstance(nominal, str)
        or not nominal
        or not isinstance(dimension_type, str)
        or not dimension_type
        or len(asset_hashes) != 1
    ):
        return None
    asset_sha256 = next(iter(asset_hashes))
    if _SHA256_RE.fullmatch(asset_sha256) is None:
        return None
    return asset_sha256, dimension_type, nominal


def _same_drawing_value(left: SemanticFact, right: SemanticFact) -> bool:
    units_compatible = (
        left.unit == right.unit or left.unit is None or right.unit is None
    )
    return left.value == right.value and units_compatible


def _drawing_facts(inventory: Mapping[str, Any]) -> list[SemanticFact]:
    facts: list[SemanticFact] = []
    for item in inventory.values():
        extras = item.source_ref.model_extra or {}
        if not extras.get("asset_sha256"):
            continue
        text = item.exact_text or item.text
        if not text:
            continue
        result = extract_drawing_semantics(
            text,
            evidence_id=item.evidence_id,
            source_ref=item.source_ref,
            localization="whole_image_flattened",
        )
        facts.extend(result.facts)
    return facts


def _drawing_asset_facts(
    inventory: Mapping[str, Any],
    *,
    projected_record: Mapping[str, Any],
    filename_facts: Iterable[SemanticFact],
) -> list[SemanticFact]:
    observations = _drawing_asset_observations(
        inventory,
        projected_record=projected_record,
    )
    if not observations:
        return []
    lines = projected_record.get("lines")
    product_ids = (
        [f"line:{index}" for index, _line in enumerate(lines)]
        if isinstance(lines, list)
        else []
    )
    declared_colors: dict[str, str] = {}
    filename_colors = list(
        dict.fromkeys(
            str(fact.value)
            for fact in filename_facts
            if fact.name == "color" and isinstance(fact.value, str)
        )
    )
    if len(product_ids) == 1 and len(filename_colors) == 1:
        declared_colors[product_ids[0]] = filename_colors[0]
    result = associate_drawing_assets(
        observations,
        product_ids=product_ids,
        declared_colors=declared_colors,
    )
    return result.facts


def _drawing_asset_observations(
    inventory: Mapping[str, Any],
    *,
    projected_record: Mapping[str, Any],
) -> list[DrawingAssetObservation]:
    line_anchors = _projected_line_anchors(projected_record)
    groups: dict[str, list[Any]] = {}
    asset_ids_by_group: dict[str, set[str]] = {}
    for item in inventory.values():
        extras = item.source_ref.model_extra or {}
        asset_sha256 = str(extras.get("asset_sha256") or "").strip()
        asset_id = str(extras.get("asset_id") or "").strip()
        if not asset_sha256 and not asset_id:
            continue
        group_key = asset_sha256 or asset_id
        groups.setdefault(group_key, []).append(item)
        if asset_id:
            asset_ids_by_group.setdefault(group_key, set()).add(asset_id)

    observations: list[DrawingAssetObservation] = []
    for group_key, items in groups.items():
        explicit_ids = asset_ids_by_group.get(group_key, set())
        if len(explicit_ids) > 1:
            raise ValueError(
                f"one visual asset SHA maps to multiple asset IDs: {group_key}"
            )
        asset_id = next(iter(explicit_ids), f"asset:sha256:{group_key}")
        representative = max(
            items,
            key=lambda item: len(_raw_evidence_text(item)),
        )
        raw_description = _raw_evidence_text(representative)
        start, end = _trimmed_span(raw_description)
        description = raw_description[start:end]
        description_range = f"chars:{start}:{end}"
        description_ref = representative.source_ref.model_copy(deep=True)
        description_ref.range = description_range
        anchored_products = {
            line_anchors[anchor]
            for item in items
            for anchor in _visual_asset_row_anchors(item)
            if anchor in line_anchors
        }
        anchored_product_id = (
            next(iter(anchored_products))
            if len(anchored_products) == 1
            else None
        )
        observations.append(
            DrawingAssetObservation(
                asset_id=asset_id,
                evidence_id=(
                    f"{representative.evidence_id}/{description_range}"
                ),
                source_ref=description_ref,
                description=description,
                anchored_product_id=anchored_product_id,
                anchor_method=(
                    "spreadsheet_row_anchor" if anchored_product_id else None
                ),
            )
        )
    return observations


_LINE_FIELD_PATH_RE = re.compile(r"^\$\.lines\[(?P<index>\d+)\]\.")
_CELL_ROW_RE = re.compile(r"^\$?[A-Za-z]{1,4}\$?(?P<row>[1-9]\d*)$")


def _projected_line_anchors(
    projected_record: Mapping[str, Any],
) -> dict[tuple[str, int], str]:
    field_meta = projected_record.get("field_meta")
    if not isinstance(field_meta, Mapping):
        return {}
    candidates: dict[tuple[str, int], set[str]] = {}
    for path, metadata in field_meta.items():
        match = _LINE_FIELD_PATH_RE.match(str(path))
        if match is None or not isinstance(metadata, Mapping):
            continue
        product_id = f"line:{int(match.group('index'))}"
        references = metadata.get("source_refs")
        if not isinstance(references, list):
            continue
        for reference in references:
            anchor = _spreadsheet_row_anchor(reference)
            if anchor is not None:
                candidates.setdefault(anchor, set()).add(product_id)
    return {
        anchor: next(iter(product_ids))
        for anchor, product_ids in candidates.items()
        if len(product_ids) == 1
    }


def _visual_asset_row_anchors(item: Any) -> set[tuple[str, int]]:
    references = (item.source_ref.model_extra or {}).get("asset_source_refs")
    if not isinstance(references, list):
        return set()
    anchors: set[tuple[str, int]] = set()
    for reference in references:
        if not isinstance(reference, Mapping):
            continue
        source_ref = reference.get("source_ref")
        anchor = _spreadsheet_row_anchor(source_ref)
        if anchor is not None:
            anchors.add(anchor)
    return anchors


def _spreadsheet_row_anchor(value: Any) -> tuple[str, int] | None:
    if not isinstance(value, Mapping):
        return None
    sheet = str(value.get("sheet") or "").strip()
    if not sheet:
        return None
    row = value.get("source_row")
    if type(row) is int and row > 0:
        return sheet, row
    cell_match = _CELL_ROW_RE.fullmatch(str(value.get("cell") or "").strip())
    if cell_match is None:
        return None
    return sheet, int(cell_match.group("row"))


def _raw_evidence_text(item: Any) -> str:
    exact_text = item.exact_text
    return str(exact_text if exact_text is not None else item.text)


def _trimmed_span(value: str) -> tuple[int, int]:
    start = 0
    end = len(value)
    while start < end and value[start].isspace():
        start += 1
    while end > start and value[end - 1].isspace():
        end -= 1
    if start >= end:
        raise ValueError("visual asset description is empty after trimming")
    return start, end


_ATOMIC_EVIDENCE_RE = re.compile(
    r"^(?P<parent>.+)/chars:(?P<start>\d+):(?P<end>\d+)$"
)
_CHARS_RANGE_RE = re.compile(r"^chars:(?P<start>\d+):(?P<end>\d+)$")
_REGION_EVIDENCE_RE = re.compile(
    r"^(?P<parent>.+)/region:(?P<sha256>[0-9a-f]{64})$"
)
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_LOCATOR_FIELDS = ("page", "sheet", "cell", "part", "archive_path")
_EXPLICIT_QUOTE_NORMALIZATION = "nfkc_whitespace_v1"


def _validate_and_extend_semantic_evidence(
    inventory_ids: list[str],
    facts: Iterable[SemanticFact],
    inventory: Mapping[str, Any],
    *,
    original_filename: str,
    validation_only_facts: Iterable[SemanticFact] = (),
) -> None:
    """Validate every semantic citation and add only approved supplemental IDs."""

    known = set(inventory_ids)
    for fact in [*facts, *validation_only_facts]:
        region_reference_count = 0
        for reference in fact.evidence_refs:
            evidence_id = reference.evidence_id
            if evidence_id == "source.filename":
                _validate_filename_evidence(
                    fact,
                    reference,
                    original_filename=original_filename,
                )
                continue
            parent = inventory.get(evidence_id)
            if parent is not None:
                _validate_inventory_evidence(reference, parent)
                continue
            region_match = _REGION_EVIDENCE_RE.fullmatch(evidence_id)
            if region_match is not None:
                _validate_region_supplemental_evidence(
                    fact,
                    reference,
                    region_match=region_match,
                    inventory=inventory,
                )
                region_reference_count += 1
                if evidence_id not in known:
                    inventory_ids.append(evidence_id)
                    known.add(evidence_id)
                continue
            match = _ATOMIC_EVIDENCE_RE.fullmatch(evidence_id)
            if match is None:
                raise ValueError(
                    "semantic fact references unknown evidence ID: "
                    f"{evidence_id}"
                )
            parent_id = match.group("parent")
            parent = inventory.get(parent_id)
            if parent is None:
                raise ValueError(
                    "semantic fact references unknown evidence ID parent: "
                    f"{reference.evidence_id}"
                )
            _validate_character_replay(
                reference,
                parent_text=_raw_evidence_text(parent),
                start=int(match.group("start")),
                end=int(match.group("end")),
                label="semantic atomic evidence",
            )
            _validate_parent_locator(reference.source_ref, parent.source_ref)
            _validate_provenance_conflicts(reference.source_ref, parent.source_ref)
            if evidence_id not in known:
                inventory_ids.append(evidence_id)
                known.add(evidence_id)
        if fact.extractor == "drawing_region_vlm.v1" and (
            fact.status != "advisory"
            or region_reference_count != len(fact.evidence_refs)
        ):
            raise ValueError(
                "drawing_region_vlm.v1 facts must be advisory and cite only "
                "validated region supplemental evidence"
            )


def _validate_inventory_evidence(reference: Any, parent: Any) -> None:
    _validate_parent_locator(reference.source_ref, parent.source_ref)
    _validate_provenance_conflicts(reference.source_ref, parent.source_ref)
    parent_text = _raw_evidence_text(parent)
    range_match = _CHARS_RANGE_RE.fullmatch(reference.source_ref.range or "")
    if range_match is not None:
        _validate_character_replay(
            reference,
            parent_text=parent_text,
            start=int(range_match.group("start")),
            end=int(range_match.group("end")),
            label="semantic inventory evidence",
        )
        return
    if reference.source_ref.range != parent.source_ref.range:
        raise ValueError(
            f"semantic evidence range conflicts with inventory: {reference.evidence_id}"
        )
    if reference.quote == parent_text:
        return
    extras = reference.source_ref.model_extra or {}
    if (
        extras.get("quote_normalization") == _EXPLICIT_QUOTE_NORMALIZATION
        and reference.quote == _normalize_quote(parent_text)
    ):
        return
    raise ValueError(
        f"semantic evidence quote does not match inventory: {reference.evidence_id}"
    )


def _validate_character_replay(
    reference: Any,
    *,
    parent_text: str,
    start: int,
    end: int,
    label: str,
) -> None:
    expected_range = f"chars:{start}:{end}"
    if (
        start < 0
        or end <= start
        or end > len(parent_text)
        or reference.source_ref.range != expected_range
        or parent_text[start:end] != reference.quote
    ):
        raise ValueError(f"{label} is not replayable: {reference.evidence_id}")


def _validate_parent_locator(child: Any, parent: Any) -> None:
    conflicts = [
        field
        for field in _LOCATOR_FIELDS
        if getattr(child, field) != getattr(parent, field)
    ]
    if conflicts:
        raise ValueError(
            "semantic evidence locator conflicts with parent: "
            + ", ".join(conflicts)
        )


def _validate_provenance_conflicts(child: Any, parent: Any) -> None:
    child_extras = child.model_extra or {}
    parent_extras = parent.model_extra or {}
    child_bbox = child_extras.get("bbox")
    parent_bbox = parent_extras.get("bbox")
    if child_bbox is not None and parent_bbox is not None and child_bbox != parent_bbox:
        raise ValueError("semantic evidence bbox conflicts with parent")
    child_sha = child_extras.get("asset_sha256")
    parent_sha = parent_extras.get("asset_sha256")
    if (
        child_sha is not None
        and parent_sha is not None
        and str(child_sha).casefold() != str(parent_sha).casefold()
    ):
        raise ValueError("semantic evidence asset_sha256 conflicts with parent")
    if child_bbox is not None and parent_bbox is not None:
        child_space = child_extras.get("coordinate_space")
        parent_space = parent_extras.get("coordinate_space")
        if child_space != parent_space:
            raise ValueError("semantic evidence coordinate_space conflicts with parent")


def _normalize_quote(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).split())


def _validate_filename_evidence(
    fact: SemanticFact,
    reference: Any,
    *,
    original_filename: str,
) -> None:
    filename = re.split(r"[\\/]", str(original_filename or ""))[-1]
    stem = Path(filename).stem
    match = _CHARS_RANGE_RE.fullmatch(reference.source_ref.range or "")
    extras = reference.source_ref.model_extra or {}
    if (
        fact.status != "advisory"
        or reference.source_ref.part != "source.original_filename"
        or any(
            getattr(reference.source_ref, field) is not None
            for field in ("page", "sheet", "cell", "archive_path")
        )
        or extras.get("authority") != "advisory"
        or extras.get("inferred") is not True
        or extras.get("parent_evidence_id") != "source.filename"
        or match is None
    ):
        raise ValueError("source.filename semantic evidence contract is invalid")
    _validate_character_replay(
        reference,
        parent_text=stem,
        start=int(match.group("start")),
        end=int(match.group("end")),
        label="source.filename semantic evidence",
    )


def _validate_region_supplemental_evidence(
    fact: SemanticFact,
    reference: Any,
    *,
    region_match: re.Match[str],
    inventory: Mapping[str, Any],
) -> None:
    parent_id = region_match.group("parent")
    region_sha256 = region_match.group("sha256")
    parent = inventory.get(parent_id)
    if parent is None:
        raise ValueError(
            "drawing region evidence references unknown parent: "
            f"{reference.evidence_id}"
        )
    extras = reference.source_ref.model_extra or {}
    parent_extras = parent.source_ref.model_extra or {}
    parent_asset_sha = (
        str(parent_extras.get("asset_sha256") or "").strip().casefold()
    )
    asset_sha = str(extras.get("asset_sha256") or "")
    _validate_parent_locator(reference.source_ref, parent.source_ref)
    if reference.source_ref.range is not None:
        raise ValueError("drawing region evidence cannot claim a source text range")
    if (
        fact.extractor != "drawing_region_vlm.v1"
        or fact.status != "advisory"
        or fact.attributes.get("source_boundary") != "visual_region_advisory"
        or fact.attributes.get("ocr_text_trusted") is not False
        or fact.attributes.get("evidence_kind") != "model_transcription"
        or fact.attributes.get("model_transcription") is not True
    ):
        raise ValueError("drawing region fact authority contract is invalid")
    rotation = extras.get("region_rotation_degrees")
    if (
        not _SHA256_RE.fullmatch(parent_asset_sha)
        or asset_sha != parent_asset_sha
        or extras.get("parent_evidence_id") != parent_id
        or extras.get("region_sha256") != region_sha256
        or extras.get("coordinate_space") != "image_pixels"
        or extras.get("authority") != "advisory"
        or extras.get("inferred") is not True
        or extras.get("evidence_kind") != "model_transcription"
        or extras.get("model_transcription") is not True
        or type(rotation) is not int
        or rotation not in (0, 90)
        or fact.attributes.get("crop_rotation_degrees") != rotation
    ):
        raise ValueError("drawing region evidence provenance contract is invalid")
    width = extras.get("asset_width_pixels")
    height = extras.get("asset_height_pixels")
    bbox = extras.get("bbox")
    region_bbox = extras.get("region_bbox_pixels")
    crop_bbox = extras.get("region_crop_bbox_pixels")
    output_size = extras.get("region_output_size_pixels")
    if (
        type(width) is not int
        or type(height) is not int
        or width <= 0
        or height <= 0
        or not _valid_region_bbox(bbox, region_bbox, width=width, height=height)
        or not _valid_region_crop_transform(
            region_bbox,
            crop_bbox,
            output_size,
            width=width,
            height=height,
            rotation=rotation,
            upscale_factor=extras.get("region_upscale_factor"),
        )
    ):
        raise ValueError("drawing region evidence geometry contract is invalid")
    if (
        extras.get("region_transform_version") != "m1.region-crop.v1"
        or extras.get("region_resampling") != "lanczos"
        or extras.get("region_image_mode") != "RGB"
        or extras.get("region_encoding") != "PNG"
        or extras.get("region_encoding_options") != {"optimize": True}
        or not str(extras.get("region_encoder") or "").startswith("Pillow/")
        or extras.get("region_hash_basis") != "encoded_region_png_bytes"
    ):
        raise ValueError("drawing region evidence transform contract is invalid")
    parsed = extract_drawing_semantics(
        reference.quote,
        evidence_id=reference.evidence_id,
        source_ref=reference.source_ref,
        localization="region_bbox",
        subject=fact.subject,
        default_unit=fact.unit,
    )
    if (
        parsed.issues
        or len(parsed.facts) != 1
        or not _same_region_semantics(fact, parsed.facts[0])
    ):
        raise ValueError("drawing region fact is inconsistent with its transcription")
    expected_fact_id = stable_fact_id(
        name=fact.name,
        value=fact.value,
        unit=fact.unit,
        subject=fact.subject,
        relation=fact.relation,
        attributes=fact.attributes,
        evidence_ids=[item.evidence_id for item in fact.evidence_refs],
    )
    if fact.fact_id != expected_fact_id:
        raise ValueError("drawing region semantic fact ID is inconsistent")


def _valid_region_bbox(
    bbox: Any,
    region_bbox: Any,
    *,
    width: int,
    height: int,
) -> bool:
    if (
        not isinstance(bbox, list)
        or not isinstance(region_bbox, list)
        or len(bbox) != 4
        or len(region_bbox) != 4
        or any(type(value) is not int for value in region_bbox)
        or any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(float(value))
            for value in bbox
        )
        or [float(value) for value in bbox]
        != [float(value) for value in region_bbox]
    ):
        return False
    x0, y0, x1, y1 = region_bbox
    return 0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height


def _valid_region_crop_transform(
    region_bbox: Any,
    crop_bbox: Any,
    output_size: Any,
    *,
    width: int,
    height: int,
    rotation: int,
    upscale_factor: Any,
) -> bool:
    if (
        not isinstance(region_bbox, list)
        or not isinstance(crop_bbox, list)
        or not isinstance(output_size, list)
        or len(region_bbox) != 4
        or len(crop_bbox) != 4
        or len(output_size) != 2
        or type(upscale_factor) is not int
        or upscale_factor not in (3, 4)
    ):
        return False
    values = [*region_bbox, *crop_bbox, *output_size]
    if any(type(value) is not int for value in values):
        return False
    region_x0, region_y0, region_x1, region_y1 = region_bbox
    crop_x0, crop_y0, crop_x1, crop_y1 = crop_bbox
    if not (
        0 <= crop_x0 <= region_x0 < region_x1 <= crop_x1 <= width
        and 0 <= crop_y0 <= region_y0 < region_y1 <= crop_y1 <= height
    ):
        return False
    crop_width = crop_x1 - crop_x0
    crop_height = crop_y1 - crop_y0
    expected_size = (
        [crop_height * upscale_factor, crop_width * upscale_factor]
        if rotation == 90
        else [crop_width * upscale_factor, crop_height * upscale_factor]
    )
    return output_size == expected_size


def _same_region_semantics(fact: SemanticFact, parsed: SemanticFact) -> bool:
    return bool(
        fact.name == parsed.name
        and fact.value == parsed.value
        and fact.unit == parsed.unit
        and fact.subject == parsed.subject
        and fact.relation == parsed.relation
        and fact.attributes.get("dimension_type")
        == parsed.attributes.get("dimension_type")
        and fact.attributes.get("localization") == "region_bbox"
        and fact.attributes.get("tolerance_type")
        == parsed.attributes.get("tolerance_type")
    )


def _completion_counts(
    dispositions: list[EvidenceDisposition],
    facts: list[SemanticFact],
    *,
    source_evidence_ids: set[str],
    existing_structured_ids: set[str],
) -> SemanticCompletionCounts:
    statuses = (
        "structured",
        "schema",
        "redundant",
        "non_semantic",
        "ambiguous",
        "needs_review",
    )
    evidence_counts = {
        status: sum(item.status == status for item in dispositions)
        for status in statuses
    }
    source_counts = {
        status: sum(
            item.status == status and item.evidence_id in source_evidence_ids
            for item in dispositions
        )
        for status in statuses
    }
    supplemental_counts = {
        status: sum(
            item.status == status and item.evidence_id not in source_evidence_ids
            for item in dispositions
        )
        for status in statuses
    }
    fact_counts = {
        status: sum(fact.status == status for fact in facts)
        for status in ("verified", "ambiguous", "advisory")
    }
    fact_statuses_by_evidence: dict[str, set[str]] = {}
    for fact in facts:
        for reference in fact.evidence_refs:
            fact_statuses_by_evidence.setdefault(reference.evidence_id, set()).add(
                fact.status
            )

    def semantic_authority(disposition: EvidenceDisposition) -> str | None:
        if disposition.status != "structured":
            return None
        statuses_for_item = fact_statuses_by_evidence.get(
            disposition.evidence_id,
            set(),
        )
        if (
            disposition.evidence_id in existing_structured_ids
            or "verified" in statuses_for_item
        ):
            return "verified"
        return "advisory"

    authority_by_evidence = {
        disposition.evidence_id: semantic_authority(disposition)
        for disposition in dispositions
    }

    def evidence_authority_count(origin: str, authority: str) -> int:
        return sum(
            authority_by_evidence[disposition.evidence_id] == authority
            and (
                (disposition.evidence_id in source_evidence_ids)
                if origin == "source"
                else (disposition.evidence_id not in source_evidence_ids)
            )
            for disposition in dispositions
        )

    source_fact_counts = {
        status: sum(
            fact.status == status
            and all(
                reference.evidence_id in source_evidence_ids
                for reference in fact.evidence_refs
            )
            for fact in facts
        )
        for status in ("verified", "ambiguous", "advisory")
    }
    supplemental_fact_counts = {
        status: fact_counts[status] - source_fact_counts[status]
        for status in ("verified", "ambiguous", "advisory")
    }
    source_verified = evidence_authority_count("source", "verified")
    source_advisory = evidence_authority_count("source", "advisory")
    supplemental_verified = evidence_authority_count("supplemental", "verified")
    supplemental_advisory = evidence_authority_count("supplemental", "advisory")
    return SemanticCompletionCounts(
        evidence_total=len(dispositions),
        source_evidence_total=sum(
            item.evidence_id in source_evidence_ids for item in dispositions
        ),
        supplemental_evidence_total=sum(
            item.evidence_id not in source_evidence_ids for item in dispositions
        ),
        evidence_accounted=sum(evidence_counts.values()),
        evidence_structured=evidence_counts["structured"],
        evidence_schema=evidence_counts["schema"],
        evidence_redundant=evidence_counts["redundant"],
        evidence_non_semantic=evidence_counts["non_semantic"],
        evidence_ambiguous=evidence_counts["ambiguous"],
        evidence_needs_review=evidence_counts["needs_review"],
        evidence_verified=source_verified + supplemental_verified,
        evidence_advisory=source_advisory + supplemental_advisory,
        source_evidence_structured=source_counts["structured"],
        source_evidence_schema=source_counts["schema"],
        source_evidence_redundant=source_counts["redundant"],
        source_evidence_non_semantic=source_counts["non_semantic"],
        source_evidence_ambiguous=source_counts["ambiguous"],
        source_evidence_needs_review=source_counts["needs_review"],
        source_evidence_verified=source_verified,
        source_evidence_advisory=source_advisory,
        supplemental_evidence_structured=supplemental_counts["structured"],
        supplemental_evidence_schema=supplemental_counts["schema"],
        supplemental_evidence_redundant=supplemental_counts["redundant"],
        supplemental_evidence_non_semantic=supplemental_counts["non_semantic"],
        supplemental_evidence_ambiguous=supplemental_counts["ambiguous"],
        supplemental_evidence_needs_review=supplemental_counts["needs_review"],
        supplemental_evidence_verified=supplemental_verified,
        supplemental_evidence_advisory=supplemental_advisory,
        facts_total=len(facts),
        facts_verified=fact_counts["verified"],
        facts_ambiguous=fact_counts["ambiguous"],
        facts_advisory=fact_counts["advisory"],
        source_facts_verified=source_fact_counts["verified"],
        source_facts_ambiguous=source_fact_counts["ambiguous"],
        source_facts_advisory=source_fact_counts["advisory"],
        supplemental_facts_verified=supplemental_fact_counts["verified"],
        supplemental_facts_ambiguous=supplemental_fact_counts["ambiguous"],
        supplemental_facts_advisory=supplemental_fact_counts["advisory"],
    )


__all__ = [
    "SemanticCompletion",
    "SemanticCompletionCounts",
    "SemanticCompletionRatios",
    "build_semantic_completion",
]
