"""Runtime-neutral semantic facts and evidence accounting.

The models in this module describe model-assisted facts without coupling them to
an extraction provider.  Facts never replace source evidence: every fact cites
one or more evidence records, and the audit helper accounts for every supplied
evidence identifier exactly once.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping
from typing import Literal, cast

from pydantic import BaseModel, ConfigDict, Field, JsonValue, model_validator

from ..models import SourceReference

SemanticFactStatus = Literal["verified", "ambiguous", "advisory"]
EvidenceDispositionStatus = Literal[
    "structured",
    "schema",
    "redundant",
    "non_semantic",
    "ambiguous",
    "needs_review",
]


class StrictSemanticModel(BaseModel):
    """Base model for provider-independent semantic output."""

    model_config = ConfigDict(
        extra="forbid",
        strict=True,
        str_strip_whitespace=True,
        validate_assignment=True,
    )


class SemanticEvidence(StrictSemanticModel):
    """Exact source evidence supporting one semantic fact."""

    evidence_id: str = Field(min_length=1)
    quote: str = Field(min_length=1)
    source_ref: SourceReference


class SemanticFact(StrictSemanticModel):
    """A provider-neutral fact that remains subordinate to source evidence."""

    fact_id: str = Field(min_length=1)
    name: str = Field(min_length=1)
    value: JsonValue
    unit: str | None = None
    subject: str | None = None
    relation: str | None = None
    attributes: dict[str, JsonValue] = Field(default_factory=dict)
    evidence_refs: list[SemanticEvidence] = Field(min_length=1)
    extractor: str = Field(min_length=1)
    confidence: float = Field(ge=0.0, le=1.0)
    status: SemanticFactStatus

    @model_validator(mode="after")
    def reject_duplicate_evidence(self) -> SemanticFact:
        evidence_ids = [evidence.evidence_id for evidence in self.evidence_refs]
        if len(evidence_ids) != len(set(evidence_ids)):
            raise ValueError("a semantic fact cannot cite the same evidence twice")
        return self


class EvidenceDisposition(StrictSemanticModel):
    """The single semantic disposition assigned to one evidence record."""

    evidence_id: str = Field(min_length=1)
    status: EvidenceDispositionStatus
    fact_ids: list[str] = Field(default_factory=list)
    reason: str = Field(min_length=1)


def stable_fact_id(
    *,
    name: str,
    value: JsonValue,
    unit: str | None = None,
    subject: str | None = None,
    relation: str | None = None,
    attributes: Mapping[str, JsonValue] | None = None,
    evidence_ids: Iterable[str] = (),
) -> str:
    """Build a reproducible semantic fact ID from canonical fact content."""

    normalized_evidence_ids = sorted(set(evidence_ids))
    if any(not evidence_id.strip() for evidence_id in normalized_evidence_ids):
        raise ValueError("evidence IDs used for a fact ID must not be empty")
    payload = {
        "attributes": dict(attributes or {}),
        "evidence_ids": normalized_evidence_ids,
        "name": name,
        "relation": relation,
        "subject": subject,
        "unit": unit,
        "value": value,
    }
    encoded = json.dumps(
        payload,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return f"semantic_fact:{hashlib.sha256(encoded).hexdigest()}"


def audit_evidence_dispositions(
    all_evidence_ids: Iterable[str],
    facts: Iterable[SemanticFact],
    *,
    structured_evidence_ids: Iterable[str] = (),
    schema_evidence_ids: Iterable[str] = (),
    redundant_evidence_ids: Iterable[str] = (),
    nonsemantic_evidence_ids: Iterable[str] = (),
    ambiguous_evidence_ids: Iterable[str] = (),
) -> list[EvidenceDisposition]:
    """Assign every evidence ID exactly one semantic disposition.

    Evidence cited only by verified/advisory facts is ``structured``.  An
    ambiguous fact makes its evidence ``ambiguous`` even when another fact or
    an existing extraction also marks it structured.  Schema, redundant, and
    non-semantic classifications remain mutually exclusive with fact evidence.
    Anything not classified is retained as ``needs_review``.
    """

    ordered_ids = tuple(all_evidence_ids)
    _validate_evidence_ids(ordered_ids, label="all evidence")
    if len(ordered_ids) != len(set(ordered_ids)):
        raise ValueError("all evidence IDs must be unique")
    known_ids = set(ordered_ids)

    fact_ids_by_evidence: dict[str, list[str]] = {}
    fact_statuses_by_evidence: dict[str, set[SemanticFactStatus]] = {}
    for fact in facts:
        for evidence in fact.evidence_refs:
            if evidence.evidence_id not in known_ids:
                raise ValueError(
                    "semantic fact references unknown evidence ID: "
                    f"{evidence.evidence_id}"
                )
            fact_ids = fact_ids_by_evidence.setdefault(evidence.evidence_id, [])
            if fact.fact_id not in fact_ids:
                fact_ids.append(fact.fact_id)
            fact_statuses_by_evidence.setdefault(evidence.evidence_id, set()).add(
                fact.status
            )

    explicit = {
        "structured": set(structured_evidence_ids),
        "schema": set(schema_evidence_ids),
        "redundant": set(redundant_evidence_ids),
        "non_semantic": set(nonsemantic_evidence_ids),
        "ambiguous": set(ambiguous_evidence_ids),
    }
    for status, evidence_ids in explicit.items():
        _validate_evidence_ids(evidence_ids, label=status)
        unknown_ids = evidence_ids - known_ids
        if unknown_ids:
            rendered = ", ".join(sorted(unknown_ids))
            raise ValueError(f"{status} contains unknown evidence IDs: {rendered}")

    ambiguous_fact_evidence = {
        evidence_id
        for evidence_id, statuses in fact_statuses_by_evidence.items()
        if "ambiguous" in statuses
    }
    assignments: dict[str, set[str]] = {
        evidence_id: {
            "ambiguous" if evidence_id in ambiguous_fact_evidence else "structured"
        }
        for evidence_id in fact_ids_by_evidence
    }
    for evidence_id in explicit["structured"]:
        if assignments.get(evidence_id) == {"ambiguous"}:
            continue
        assignments.setdefault(evidence_id, set()).add("structured")
    for status in ("schema", "redundant", "non_semantic"):
        evidence_ids = explicit[status]
        for evidence_id in evidence_ids:
            assignments.setdefault(evidence_id, set()).add(status)
    for evidence_id in explicit["ambiguous"]:
        current = assignments.get(evidence_id)
        if current is None or current.issubset({"structured", "ambiguous"}):
            assignments[evidence_id] = {"ambiguous"}
        else:
            current.add("ambiguous")
    overlaps = {
        evidence_id: statuses
        for evidence_id, statuses in assignments.items()
        if len(statuses) > 1
    }
    if overlaps:
        rendered = "; ".join(
            f"{evidence_id}={','.join(sorted(statuses))}"
            for evidence_id, statuses in sorted(overlaps.items())
        )
        raise ValueError(f"evidence disposition overlap: {rendered}")

    reasons = {
        "structured": "referenced_by_semantic_fact",
        "schema": "schema_evidence",
        "redundant": "redundant_evidence",
        "non_semantic": "no_semantic_content",
        "ambiguous": "semantic_meaning_ambiguous",
        "needs_review": "semantic_disposition_missing",
    }
    dispositions: list[EvidenceDisposition] = []
    for evidence_id in ordered_ids:
        statuses = assignments.get(evidence_id)
        status = cast(
            EvidenceDispositionStatus,
            next(iter(statuses)) if statuses else "needs_review",
        )
        dispositions.append(
            EvidenceDisposition(
                evidence_id=evidence_id,
                status=status,
                fact_ids=list(fact_ids_by_evidence.get(evidence_id, [])),
                reason=(
                    "referenced_by_ambiguous_semantic_fact"
                    if status == "ambiguous"
                    and evidence_id in ambiguous_fact_evidence
                    else (
                    "referenced_by_semantic_fact"
                    if status == "structured" and evidence_id in fact_ids_by_evidence
                    else (
                        "existing_structured_evidence"
                        if status == "structured"
                        else reasons[status]
                    )
                    )
                ),
            )
        )
    return dispositions


def _validate_evidence_ids(evidence_ids: Iterable[str], *, label: str) -> None:
    for evidence_id in evidence_ids:
        if not isinstance(evidence_id, str) or not evidence_id.strip():
            raise ValueError(f"{label} evidence IDs must be non-empty strings")


__all__ = [
    "EvidenceDisposition",
    "EvidenceDispositionStatus",
    "SemanticEvidence",
    "SemanticFact",
    "SemanticFactStatus",
    "audit_evidence_dispositions",
    "stable_fact_id",
]
