"""Closed execution capabilities for governed semantic strategies.

The routing model selects only a :class:`SemanticStrategyDecision`.  That
decision is audit data until this module verifies every executable field
against the process-local registry and returns a :class:`SemanticExecutionSpec`.
Callers must pass the in-memory spec to a mapper; a dictionary recovered from
document metadata never acquires execution authority.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Literal

from pydantic import BaseModel, ConfigDict, PrivateAttr

from .document_route_policy import RouteDocumentType
from .evidence import DocumentEvidence
from .semantic_strategy_router import (
    SemanticBudget,
    SemanticMapperId,
    SemanticPromptId,
    SemanticSchemaId,
    SemanticStrategyDecision,
    SemanticStrategyId,
    registered_semantic_strategies,
)

SemanticMapperRole = Literal[
    "document_classification",
    "document_intent",
    "table_partition",
    "block_semantics",
    "record_field_mapping",
    "record_kind_mapping",
    "segment_extraction",
]
_CAPABILITY_ISSUER = object()


class SemanticExecutionSpec(BaseModel):
    """Value-free in-memory capability consumed by semantic mapper adapters."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["m1.semantic-execution.v1"] = "m1.semantic-execution.v1"
    strategy_id: SemanticStrategyId
    mapper_id: SemanticMapperId
    schema_id: SemanticSchemaId
    prompt_id: SemanticPromptId
    budget: SemanticBudget
    document_type_hint: RouteDocumentType | None = None
    _issuer: object | None = PrivateAttr(default=None)

    def value_free_dump(self) -> dict[str, object]:
        return self.model_dump(mode="json")


@dataclass(frozen=True, slots=True)
class _ExecutionRegistration:
    strategy_id: SemanticStrategyId
    mapper_id: SemanticMapperId
    schema_id: SemanticSchemaId
    prompt_id: SemanticPromptId
    document_type_hint: RouteDocumentType | None
    prompt_directive: str
    output_schemas: Mapping[SemanticMapperRole, str]


_OUTPUT_SCHEMAS: Mapping[SemanticMapperRole, str] = MappingProxyType(
    {
        "document_classification": "DocumentClassification",
        "document_intent": "DocumentIntent",
        "table_partition": "TablePartition",
        "block_semantics": "BlockSemantics",
        "record_field_mapping": "RecordFieldMapping",
        "record_kind_mapping": "RecordKindMapping",
        "segment_extraction": "SegmentExtraction",
    }
)


def _registration(
    strategy_id: SemanticStrategyId,
    *,
    document_type_hint: RouteDocumentType | None,
    directive: str,
) -> _ExecutionRegistration:
    strategy = registered_semantic_strategies()[strategy_id]
    return _ExecutionRegistration(
        strategy_id=strategy.strategy_id,
        mapper_id=strategy.mapper_id,
        schema_id=strategy.schema_id,
        prompt_id=strategy.prompt_id,
        document_type_hint=document_type_hint,
        prompt_directive=directive,
        output_schemas=_OUTPUT_SCHEMAS,
    )


_EXECUTION_REGISTRY: Mapping[SemanticStrategyId, _ExecutionRegistration] = (
    MappingProxyType(
        {
            SemanticStrategyId.GENERIC: _registration(
                SemanticStrategyId.GENERIC,
                document_type_hint=None,
                directive=(
                    "Map open-domain evidence conservatively. Keep unsupported values "
                    "as evidence and never infer a specialized business taxonomy."
                ),
            ),
            SemanticStrategyId.ORDER: _registration(
                SemanticStrategyId.ORDER,
                document_type_hint=RouteDocumentType.ORDER,
                directive=(
                    "Map order and contract evidence. Preserve order identifiers, parties, "
                    "dates, quantities, units, and repeated order lines with exact citations."
                ),
            ),
            SemanticStrategyId.INVENTORY: _registration(
                SemanticStrategyId.INVENTORY,
                document_type_hint=RouteDocumentType.INVENTORY,
                directive=(
                    "Map inventory evidence. Preserve every stock row, material identifier, "
                    "quantity, unit, warehouse, and status without order-specific inference."
                ),
            ),
            SemanticStrategyId.EQUIPMENT: _registration(
                SemanticStrategyId.EQUIPMENT,
                document_type_hint=RouteDocumentType.EQUIPMENT,
                directive=(
                    "Map equipment-register evidence. Preserve every equipment row, asset "
                    "identifier, model, location, capability, and status with citations."
                ),
            ),
            SemanticStrategyId.MOLD: _registration(
                SemanticStrategyId.MOLD,
                document_type_hint=RouteDocumentType.MOLD,
                directive=(
                    "Map mold evidence. Preserve each mold identifier and its exact product, "
                    "model, specification, quantity, and conflict evidence."
                ),
            ),
            SemanticStrategyId.PROCUREMENT: _registration(
                SemanticStrategyId.PROCUREMENT,
                document_type_hint=RouteDocumentType.PROCUREMENT,
                directive=(
                    "Map procurement-ledger evidence. Preserve every source row, document "
                    "identifier, material, quantity, price, party, and date with citations."
                ),
            ),
            SemanticStrategyId.TECHNICAL: _registration(
                SemanticStrategyId.TECHNICAL,
                document_type_hint=RouteDocumentType.TECHNICAL_DOCUMENT,
                directive=(
                    "Map technical-document evidence. Preserve title-block facts, revisions, "
                    "dimensions, tolerances, BOM rows, tests, and process requirements."
                ),
            ),
            SemanticStrategyId.ARCHIVE: _registration(
                SemanticStrategyId.ARCHIVE,
                document_type_hint=RouteDocumentType.ARCHIVE,
                directive=(
                    "Map archive inventory only. Preserve member identity, type, size, digest, "
                    "and hierarchy; do not merge facts across archive members."
                ),
            ),
            SemanticStrategyId.VISUAL_GENERIC: _registration(
                SemanticStrategyId.VISUAL_GENERIC,
                document_type_hint=None,
                directive=(
                    "Map visual open-domain evidence conservatively. Treat visual findings "
                    "as supplements and keep all uncertain taxonomy or values for review."
                ),
            ),
        }
    )
)


class SemanticStrategyExecutor:
    """Bind decisions to closed mapper, schema, prompt, and budget registrations."""

    @staticmethod
    def bind(decision: SemanticStrategyDecision) -> SemanticExecutionSpec:
        if not isinstance(decision, SemanticStrategyDecision):
            raise TypeError("semantic execution requires a live strategy decision")
        strategy = registered_semantic_strategies().get(decision.strategy_id)
        registration = _EXECUTION_REGISTRY.get(decision.strategy_id)
        if strategy is None or registration is None:
            raise ValueError("semantic strategy is not registered for execution")
        expected = (
            strategy.mapper_id,
            strategy.schema_id,
            strategy.prompt_id,
            strategy.budget,
        )
        actual = (
            decision.mapper_id,
            decision.schema_id,
            decision.prompt_id,
            decision.budget,
        )
        if actual != expected:
            raise ValueError(
                "semantic decision does not match its registered execution"
            )
        if (
            registration.mapper_id,
            registration.schema_id,
            registration.prompt_id,
        ) != expected[:3]:
            raise RuntimeError("semantic execution registry is internally inconsistent")
        spec = SemanticExecutionSpec(
            strategy_id=decision.strategy_id,
            mapper_id=decision.mapper_id,
            schema_id=decision.schema_id,
            prompt_id=decision.prompt_id,
            budget=decision.budget,
            document_type_hint=registration.document_type_hint,
        )
        spec._issuer = _CAPABILITY_ISSUER
        return spec

    @staticmethod
    def validate_capability(spec: SemanticExecutionSpec) -> None:
        if not isinstance(spec, SemanticExecutionSpec):
            raise TypeError(
                "semantic mapper requires an in-memory execution capability"
            )
        if spec._issuer is not _CAPABILITY_ISSUER:
            raise ValueError(
                "semantic execution capability was not issued by this process"
            )
        strategy = registered_semantic_strategies().get(spec.strategy_id)
        registration = _EXECUTION_REGISTRY.get(spec.strategy_id)
        if strategy is None or registration is None:
            raise ValueError("semantic execution capability is not registered")
        if (
            spec.mapper_id,
            spec.schema_id,
            spec.prompt_id,
            spec.budget,
            spec.document_type_hint,
        ) != (
            registration.mapper_id,
            registration.schema_id,
            registration.prompt_id,
            strategy.budget,
            registration.document_type_hint,
        ):
            raise ValueError(
                "semantic execution capability was not issued by the registry"
            )

    @classmethod
    def prompt_directive(
        cls,
        spec: SemanticExecutionSpec,
        *,
        role: SemanticMapperRole,
    ) -> str:
        cls.validate_capability(spec)
        registration = _EXECUTION_REGISTRY[spec.strategy_id]
        if role not in registration.output_schemas:
            raise ValueError(f"semantic mapper role is not registered: {role}")
        return registration.prompt_directive

    @classmethod
    def output_schema_name(
        cls,
        spec: SemanticExecutionSpec,
        *,
        role: SemanticMapperRole,
    ) -> str:
        cls.validate_capability(spec)
        try:
            return _EXECUTION_REGISTRY[spec.strategy_id].output_schemas[role]
        except KeyError as exc:
            raise ValueError(f"semantic mapper role is not registered: {role}") from exc

    @classmethod
    def validate_output_schema(
        cls,
        spec: SemanticExecutionSpec,
        *,
        role: SemanticMapperRole,
        output_type: type[object],
    ) -> None:
        """Reject an adapter that binds the strategy to another output model."""

        expected = cls.output_schema_name(spec, role=role)
        actual = str(getattr(output_type, "__name__", ""))
        if actual != expected:
            raise ValueError(
                f"semantic schema {spec.schema_id.value} requires {expected} "
                f"for {role}, got {actual or '<anonymous>'}"
            )

    @classmethod
    def effective_input_limit(
        cls,
        spec: SemanticExecutionSpec,
        configured_limit: int,
    ) -> int:
        cls.validate_capability(spec)
        return min(max(1, int(configured_limit)), spec.budget.max_input_chars)

    @classmethod
    def evidence_budget_excesses(
        cls,
        spec: SemanticExecutionSpec,
        evidence: DocumentEvidence,
    ) -> tuple[str, ...]:
        """Return closed review reasons instead of silently dropping evidence."""

        cls.validate_capability(spec)
        if not isinstance(evidence, DocumentEvidence):
            raise TypeError("semantic evidence budget requires DocumentEvidence")
        table_count = sum(len(page.tables) for page in evidence.pages)
        visual_count = sum(
            1
            for page in evidence.pages
            for block in page.blocks
            if block.kind.casefold() in {"image", "figure", "chart", "seal"}
        )
        reasons: list[str] = []
        if len(evidence.pages) > spec.budget.max_pages:
            reasons.append("semantic_budget_pages_exceeded")
        if table_count > spec.budget.max_tables:
            reasons.append("semantic_budget_tables_exceeded")
        if visual_count > spec.budget.max_visual_regions:
            reasons.append("semantic_budget_visual_regions_exceeded")
        return tuple(reasons)


__all__ = [
    "SemanticExecutionSpec",
    "SemanticMapperRole",
    "SemanticStrategyExecutor",
]
