"""Governed selection of closed semantic execution strategies.

This module is intentionally an integration-neutral layer between a resolved
document route and semantic executors.  It never stores data, calls a model
endpoint, or carries prompt text, document text, field values, tenant IDs, or
task IDs.  A caller may attach an optional small-model selector, but that
selector receives only an immutable list of already registered strategy IDs
and a value-free evidence topology.

The router does not replace :class:`RouteProfilePolicy`.  Route profiles remain
the authority for document family, table roles, verifier policy, visual policy,
and evidence authority.  This module turns that controlled context into one
registered mapper/schema/prompt/budget tuple for downstream execution.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from enum import StrEnum
from types import MappingProxyType
from typing import Any, Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .document_route_plan import DocumentRoutePlan
from .document_route_policy import (
    RouteAuthorityPolicy,
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTablePolicy,
    RouteTableRole,
    RouteVerifierPolicy,
    RouteVisualPolicy,
)
from .evidence import DocumentEvidence


class SemanticStrategyId(StrEnum):
    """Closed IDs that an executor integration may resolve."""

    GENERIC = "generic_evidence_v1"
    ORDER = "order_evidence_v1"
    INVENTORY = "inventory_evidence_v1"
    EQUIPMENT = "equipment_evidence_v1"
    MOLD = "mold_evidence_v1"
    PROCUREMENT = "procurement_evidence_v1"
    TECHNICAL = "technical_evidence_v1"
    ARCHIVE = "archive_evidence_v1"
    VISUAL_GENERIC = "visual_generic_evidence_v1"


class SemanticMapperId(StrEnum):
    GENERIC = "generic_evidence_mapper_v1"
    ORDER = "order_evidence_mapper_v1"
    INVENTORY = "inventory_evidence_mapper_v1"
    EQUIPMENT = "equipment_evidence_mapper_v1"
    MOLD = "mold_evidence_mapper_v1"
    PROCUREMENT = "procurement_evidence_mapper_v1"
    TECHNICAL = "technical_evidence_mapper_v1"
    ARCHIVE = "archive_evidence_mapper_v1"
    VISUAL_GENERIC = "visual_generic_evidence_mapper_v1"


class SemanticSchemaId(StrEnum):
    GENERIC = "m1.semantic.generic.v1"
    ORDER = "m1.semantic.order.v1"
    INVENTORY = "m1.semantic.inventory.v1"
    EQUIPMENT = "m1.semantic.equipment.v1"
    MOLD = "m1.semantic.mold.v1"
    PROCUREMENT = "m1.semantic.procurement.v1"
    TECHNICAL = "m1.semantic.technical.v1"
    ARCHIVE = "m1.semantic.archive.v1"
    VISUAL_GENERIC = "m1.semantic.visual-generic.v1"


class SemanticPromptId(StrEnum):
    """Prompt references only. Prompt text remains in the executor registry."""

    GENERIC = "m1.prompt.semantic.generic.v1"
    ORDER = "m1.prompt.semantic.order.v1"
    INVENTORY = "m1.prompt.semantic.inventory.v1"
    EQUIPMENT = "m1.prompt.semantic.equipment.v1"
    MOLD = "m1.prompt.semantic.mold.v1"
    PROCUREMENT = "m1.prompt.semantic.procurement.v1"
    TECHNICAL = "m1.prompt.semantic.technical.v1"
    ARCHIVE = "m1.prompt.semantic.archive.v1"
    VISUAL_GENERIC = "m1.prompt.semantic.visual-generic.v1"


class SemanticBudgetId(StrEnum):
    COMPACT = "compact"
    TABULAR = "tabular"
    VISUAL = "visual"
    ARCHIVE = "archive"


class SemanticBudget(BaseModel):
    """A bounded execution budget; strategies cannot request arbitrary limits."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    budget_id: SemanticBudgetId
    max_input_chars: int = Field(ge=1, le=120_000)
    max_pages: int = Field(ge=1, le=200)
    max_tables: int = Field(ge=0, le=512)
    max_visual_regions: int = Field(ge=0, le=64)
    max_model_requests: int = Field(ge=0, le=8)


class SemanticStrategy(BaseModel):
    """One registered and immutable semantic execution option."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    strategy_id: SemanticStrategyId
    mapper_id: SemanticMapperId
    schema_id: SemanticSchemaId
    prompt_id: SemanticPromptId
    budget: SemanticBudget
    verifier_policy: RouteVerifierPolicy
    visual_policy: RouteVisualPolicy


_COMPACT_BUDGET = SemanticBudget(
    budget_id=SemanticBudgetId.COMPACT,
    max_input_chars=12_000,
    max_pages=12,
    max_tables=12,
    max_visual_regions=0,
    max_model_requests=2,
)
_TABULAR_BUDGET = SemanticBudget(
    budget_id=SemanticBudgetId.TABULAR,
    max_input_chars=32_000,
    max_pages=32,
    max_tables=64,
    max_visual_regions=0,
    max_model_requests=3,
)
_VISUAL_BUDGET = SemanticBudget(
    budget_id=SemanticBudgetId.VISUAL,
    max_input_chars=24_000,
    max_pages=16,
    max_tables=24,
    max_visual_regions=16,
    max_model_requests=3,
)
_ARCHIVE_BUDGET = SemanticBudget(
    budget_id=SemanticBudgetId.ARCHIVE,
    max_input_chars=48_000,
    max_pages=80,
    max_tables=128,
    max_visual_regions=0,
    max_model_requests=2,
)


_REGISTERED_STRATEGIES: Mapping[SemanticStrategyId, SemanticStrategy] = (
    MappingProxyType(
        {
            SemanticStrategyId.GENERIC: SemanticStrategy(
                strategy_id=SemanticStrategyId.GENERIC,
                mapper_id=SemanticMapperId.GENERIC,
                schema_id=SemanticSchemaId.GENERIC,
                prompt_id=SemanticPromptId.GENERIC,
                budget=_COMPACT_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.ORDER: SemanticStrategy(
                strategy_id=SemanticStrategyId.ORDER,
                mapper_id=SemanticMapperId.ORDER,
                schema_id=SemanticSchemaId.ORDER,
                prompt_id=SemanticPromptId.ORDER,
                budget=_TABULAR_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.INVENTORY: SemanticStrategy(
                strategy_id=SemanticStrategyId.INVENTORY,
                mapper_id=SemanticMapperId.INVENTORY,
                schema_id=SemanticSchemaId.INVENTORY,
                prompt_id=SemanticPromptId.INVENTORY,
                budget=_TABULAR_BUDGET,
                verifier_policy=RouteVerifierPolicy.DISABLED,
                visual_policy="disabled",
            ),
            SemanticStrategyId.EQUIPMENT: SemanticStrategy(
                strategy_id=SemanticStrategyId.EQUIPMENT,
                mapper_id=SemanticMapperId.EQUIPMENT,
                schema_id=SemanticSchemaId.EQUIPMENT,
                prompt_id=SemanticPromptId.EQUIPMENT,
                budget=_TABULAR_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.MOLD: SemanticStrategy(
                strategy_id=SemanticStrategyId.MOLD,
                mapper_id=SemanticMapperId.MOLD,
                schema_id=SemanticSchemaId.MOLD,
                prompt_id=SemanticPromptId.MOLD,
                budget=_TABULAR_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.PROCUREMENT: SemanticStrategy(
                strategy_id=SemanticStrategyId.PROCUREMENT,
                mapper_id=SemanticMapperId.PROCUREMENT,
                schema_id=SemanticSchemaId.PROCUREMENT,
                prompt_id=SemanticPromptId.PROCUREMENT,
                budget=_TABULAR_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.TECHNICAL: SemanticStrategy(
                strategy_id=SemanticStrategyId.TECHNICAL,
                mapper_id=SemanticMapperId.TECHNICAL,
                schema_id=SemanticSchemaId.TECHNICAL,
                prompt_id=SemanticPromptId.TECHNICAL,
                budget=_VISUAL_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
            SemanticStrategyId.ARCHIVE: SemanticStrategy(
                strategy_id=SemanticStrategyId.ARCHIVE,
                mapper_id=SemanticMapperId.ARCHIVE,
                schema_id=SemanticSchemaId.ARCHIVE,
                prompt_id=SemanticPromptId.ARCHIVE,
                budget=_ARCHIVE_BUDGET,
                verifier_policy=RouteVerifierPolicy.DISABLED,
                visual_policy="disabled",
            ),
            SemanticStrategyId.VISUAL_GENERIC: SemanticStrategy(
                strategy_id=SemanticStrategyId.VISUAL_GENERIC,
                mapper_id=SemanticMapperId.VISUAL_GENERIC,
                schema_id=SemanticSchemaId.VISUAL_GENERIC,
                prompt_id=SemanticPromptId.VISUAL_GENERIC,
                budget=_VISUAL_BUDGET,
                verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
                visual_policy="on_uncertainty",
            ),
        }
    )
)


def registered_semantic_strategies() -> Mapping[SemanticStrategyId, SemanticStrategy]:
    """Return the immutable, process-local semantic strategy registry."""

    return _REGISTERED_STRATEGIES


class DocumentSemanticTopology(BaseModel):
    """Value-free evidence shape available to a strategy selector."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    page_count: int = Field(ge=0, le=10_000)
    block_count: int = Field(ge=0, le=1_000_000)
    table_count: int = Field(ge=0, le=100_000)
    table_cell_count: int = Field(ge=0, le=10_000_000)
    visual_page_count: int = Field(ge=0, le=10_000)
    uncertain_page_count: int = Field(ge=0, le=10_000)
    complex_table_page_count: int = Field(ge=0, le=10_000)
    table_without_cells_count: int = Field(ge=0, le=100_000)
    uncertainty_reasons: tuple[
        Literal[
            "empty_text",
            "low_text_confidence",
            "table_without_cells",
            "page_dominated_by_complex_table",
            "visual_region",
        ],
        ...,
    ] = ()

    @field_validator("uncertainty_reasons", mode="before")
    @classmethod
    def _ordered_distinct_reasons(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, str):
            value = (value,)
        if not isinstance(value, Sequence) or isinstance(value, (bytes, bytearray)):
            raise TypeError("uncertainty_reasons must be a sequence")
        allowed = {
            "empty_text",
            "low_text_confidence",
            "table_without_cells",
            "page_dominated_by_complex_table",
            "visual_region",
        }
        return tuple(
            sorted(
                {
                    reason
                    for item in value
                    if (reason := str(item).strip().casefold()) in allowed
                }
            )
        )


def build_document_semantic_topology(
    evidence: DocumentEvidence,
) -> DocumentSemanticTopology:
    """Summarize only count/geometry/quality signals from parser evidence."""

    block_count = 0
    table_count = 0
    table_cell_count = 0
    visual_page_count = 0
    uncertain_page_count = 0
    complex_table_page_count = 0
    table_without_cells_count = 0
    uncertainty_reasons: set[str] = set()
    for page in evidence.pages:
        block_count += len(page.blocks)
        table_count += len(page.tables)
        table_cell_count += sum(
            max(len(table.cells), sum(len(row) for row in table.rows))
            for table in page.tables
        )
        table_without_cells_count += sum(
            1 for table in page.tables if not table.rows and not table.cells
        )
        if page.visual_coverage_ratio > 0.20:
            visual_page_count += 1
        if page.dominant_complex_table:
            complex_table_page_count += 1
        uncertain, reasons = page.needs_vlm()
        if uncertain:
            uncertain_page_count += 1
            uncertainty_reasons.update(reasons)
    return DocumentSemanticTopology(
        page_count=len(evidence.pages),
        block_count=block_count,
        table_count=table_count,
        table_cell_count=table_cell_count,
        visual_page_count=visual_page_count,
        uncertain_page_count=uncertain_page_count,
        complex_table_page_count=complex_table_page_count,
        table_without_cells_count=table_without_cells_count,
        uncertainty_reasons=tuple(sorted(uncertainty_reasons)),
    )


class SemanticRouteContext(BaseModel):
    """The semantic subset of a route policy, with no parser or source values."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_family: RouteSchemaFamily = RouteSchemaFamily.GENERIC_LAYOUT
    document_type_hint: RouteDocumentType | None = None
    document_subtype_hint: RouteDocumentSubtype | None = None
    table_roles: tuple[RouteTablePolicy, ...] = ()
    verifier_policy: RouteVerifierPolicy = RouteVerifierPolicy.ON_UNCERTAINTY
    visual_policy: RouteVisualPolicy = "on_uncertainty"
    authority_policy: RouteAuthorityPolicy = RouteAuthorityPolicy.EVIDENCE_REQUIRED
    policy_applied: bool = False

    @classmethod
    def from_policy(
        cls,
        policy: RouteProfilePolicy,
        *,
        policy_applied: bool = True,
    ) -> SemanticRouteContext:
        return cls(
            schema_family=policy.schema_family,
            document_type_hint=policy.document_type_hint,
            document_subtype_hint=policy.document_subtype_hint,
            table_roles=policy.table_roles,
            verifier_policy=policy.verifier_policy,
            visual_policy=policy.visual_policy,
            authority_policy=policy.authority_policy,
            policy_applied=policy_applied,
        )

    @classmethod
    def from_plan(cls, plan: DocumentRoutePlan) -> SemanticRouteContext:
        return cls(
            schema_family=plan.schema_family,
            document_type_hint=plan.document_type_hint,
            document_subtype_hint=plan.document_subtype_hint,
            table_roles=plan.table_roles,
            verifier_policy=plan.verifier_policy,
            visual_policy=plan.visual_policy,
            authority_policy=plan.authority_policy,
            policy_applied=plan.policy_applied,
        )

    @model_validator(mode="after")
    def _semantic_hints_are_consistent(self) -> Self:
        RouteProfilePolicy(
            schema_family=self.schema_family,
            document_type_hint=self.document_type_hint,
            document_subtype_hint=self.document_subtype_hint,
            table_roles=self.table_roles,
            verifier_policy=self.verifier_policy,
            visual_policy=self.visual_policy,
            authority_policy=self.authority_policy,
        )
        return self


class SemanticStrategyCandidate(BaseModel):
    """A model-visible summary of a registered strategy, never prompt text."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    strategy_id: SemanticStrategyId
    mapper_id: SemanticMapperId
    schema_id: SemanticSchemaId
    prompt_id: SemanticPromptId
    budget_id: SemanticBudgetId
    verifier_policy: RouteVerifierPolicy
    visual_policy: RouteVisualPolicy

    @classmethod
    def from_strategy(
        cls,
        strategy: SemanticStrategy,
        *,
        verifier_policy: RouteVerifierPolicy,
        visual_policy: RouteVisualPolicy,
    ) -> SemanticStrategyCandidate:
        return cls(
            strategy_id=strategy.strategy_id,
            mapper_id=strategy.mapper_id,
            schema_id=strategy.schema_id,
            prompt_id=strategy.prompt_id,
            budget_id=strategy.budget.budget_id,
            verifier_policy=verifier_policy,
            visual_policy=visual_policy,
        )


class SemanticStrategySelectionRequest(BaseModel):
    """The complete bounded payload for an optional small-model selector."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["m1.semantic-strategy-selection.v1"] = (
        "m1.semantic-strategy-selection.v1"
    )
    route_context: SemanticRouteContext
    topology: DocumentSemanticTopology
    candidates: tuple[SemanticStrategyCandidate, ...] = Field(
        min_length=1, max_length=2
    )

    @model_validator(mode="after")
    def _distinct_candidates(self) -> Self:
        ids = [candidate.strategy_id for candidate in self.candidates]
        if len(ids) != len(set(ids)):
            raise ValueError("semantic strategy candidates must be unique")
        return self


class SemanticStrategyModelChoice(BaseModel):
    """A small model may choose only one supplied closed strategy ID."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    strategy_id: SemanticStrategyId
    confidence: float = Field(ge=0.0, le=1.0)


SemanticStrategyReason = Literal[
    "route_schema_family",
    "route_table_role",
    "visual_topology",
    "generic_fallback",
    "model_selected",
    "model_failure",
    "invalid_model_choice",
    "model_candidate_rejected",
    "model_confidence_below_threshold",
]


class SemanticStrategyDecision(BaseModel):
    """Safe result for a future semantic executor integration."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["m1.semantic-strategy-decision.v1"] = (
        "m1.semantic-strategy-decision.v1"
    )
    strategy_id: SemanticStrategyId
    mapper_id: SemanticMapperId
    schema_id: SemanticSchemaId
    prompt_id: SemanticPromptId
    budget: SemanticBudget
    verifier_policy: RouteVerifierPolicy
    visual_policy: RouteVisualPolicy
    authority_policy: RouteAuthorityPolicy
    route_context: SemanticRouteContext
    topology: DocumentSemanticTopology
    candidates: tuple[SemanticStrategyCandidate, ...]
    reason_codes: tuple[SemanticStrategyReason, ...] = Field(min_length=1, max_length=3)
    model_used: bool = False
    model_confidence: float | None = Field(default=None, ge=0.0, le=1.0)

    def value_free_dump(self) -> dict[str, object]:
        """Return audit metadata that cannot contain source text or prompt text."""

        return self.model_dump(mode="json")


class SemanticStrategySelector(Protocol):
    async def select(
        self,
        request: SemanticStrategySelectionRequest,
    ) -> SemanticStrategyModelChoice | Mapping[str, Any]: ...


class StructuredSemanticSelectionClient(Protocol):
    async def run(
        self,
        output_type: type[SemanticStrategyModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> Any: ...


class PydanticSemanticStrategySelector:
    """Use the existing small-model client for one closed candidate choice."""

    _INSTRUCTIONS = (
        "Select exactly one semantic strategy from the supplied candidates. "
        "The payload contains aggregate topology and registered policy IDs only. "
        "Never invent a strategy, mapper, schema, prompt, fact, field value, or "
        "document classification. Prefer the specialized candidate only when its "
        "registered route context and topology fit; otherwise choose the supplied "
        "generic candidate."
    )

    def __init__(self, client: StructuredSemanticSelectionClient) -> None:
        self._client = client

    async def select(
        self,
        request: SemanticStrategySelectionRequest,
    ) -> SemanticStrategyModelChoice:
        run = await self._client.run(
            SemanticStrategyModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=request.model_dump_json(),
            request_limit=1,
        )
        return SemanticStrategyModelChoice.model_validate(run.output, strict=True)


_FAMILY_STRATEGIES: Mapping[RouteSchemaFamily, SemanticStrategyId] = MappingProxyType(
    {
        RouteSchemaFamily.ORDER: SemanticStrategyId.ORDER,
        RouteSchemaFamily.INVENTORY: SemanticStrategyId.INVENTORY,
        RouteSchemaFamily.EQUIPMENT: SemanticStrategyId.EQUIPMENT,
        RouteSchemaFamily.MOLD: SemanticStrategyId.MOLD,
        RouteSchemaFamily.PROCUREMENT: SemanticStrategyId.PROCUREMENT,
        RouteSchemaFamily.TECHNICAL: SemanticStrategyId.TECHNICAL,
        RouteSchemaFamily.ARCHIVE: SemanticStrategyId.ARCHIVE,
    }
)
_TYPE_FAMILIES: Mapping[RouteDocumentType, RouteSchemaFamily] = MappingProxyType(
    {
        RouteDocumentType.ORDER: RouteSchemaFamily.ORDER,
        RouteDocumentType.INVENTORY: RouteSchemaFamily.INVENTORY,
        RouteDocumentType.EQUIPMENT: RouteSchemaFamily.EQUIPMENT,
        RouteDocumentType.MOLD: RouteSchemaFamily.MOLD,
        RouteDocumentType.PROCUREMENT: RouteSchemaFamily.PROCUREMENT,
        RouteDocumentType.TECHNICAL_DOCUMENT: RouteSchemaFamily.TECHNICAL,
        RouteDocumentType.ARCHIVE: RouteSchemaFamily.ARCHIVE,
    }
)
_TABLE_ROLE_STRATEGIES: Mapping[RouteTableRole, SemanticStrategyId] = MappingProxyType(
    {
        RouteTableRole.ORDER_LINES: SemanticStrategyId.ORDER,
        RouteTableRole.INVENTORY_LINES: SemanticStrategyId.INVENTORY,
        RouteTableRole.EQUIPMENT_LINES: SemanticStrategyId.EQUIPMENT,
        RouteTableRole.MOLD_MAPPING: SemanticStrategyId.MOLD,
    }
)


class SemanticStrategyRouter:
    """Choose a strategy from the static registry without source-value access."""

    def __init__(self, *, model_min_confidence: float = 0.80) -> None:
        if not 0.0 <= float(model_min_confidence) <= 1.0:
            raise ValueError("model_min_confidence must be in [0, 1]")
        self.model_min_confidence = float(model_min_confidence)

    @staticmethod
    def _context(
        *,
        route_policy: RouteProfilePolicy | None,
        route_plan: DocumentRoutePlan | None,
    ) -> SemanticRouteContext:
        from_policy = (
            SemanticRouteContext.from_policy(route_policy)
            if route_policy is not None
            else None
        )
        from_plan = (
            SemanticRouteContext.from_plan(route_plan)
            if route_plan is not None
            else None
        )
        if from_policy is not None and from_plan is not None:
            left = from_policy.model_dump(exclude={"policy_applied"})
            right = from_plan.model_dump(exclude={"policy_applied"})
            if left != right:
                raise ValueError(
                    "route policy and route plan semantic contexts conflict"
                )
            return from_policy.model_copy(
                update={"policy_applied": from_plan.policy_applied}
            )
        return from_policy or from_plan or SemanticRouteContext()

    @staticmethod
    def _primary_strategy(
        context: SemanticRouteContext,
        topology: DocumentSemanticTopology,
    ) -> tuple[SemanticStrategyId, SemanticStrategyReason]:
        strategy = _FAMILY_STRATEGIES.get(context.schema_family)
        if strategy is not None:
            return strategy, "route_schema_family"
        for table_policy in context.table_roles:
            strategy = _TABLE_ROLE_STRATEGIES.get(table_policy.role)
            if strategy is not None:
                return strategy, "route_table_role"
        if context.visual_policy != "disabled" and topology.visual_page_count:
            return SemanticStrategyId.VISUAL_GENERIC, "visual_topology"
        return SemanticStrategyId.GENERIC, "generic_fallback"

    @staticmethod
    def _effective_policies(
        context: SemanticRouteContext,
    ) -> tuple[RouteVerifierPolicy, RouteVisualPolicy]:
        """Profile settings override only with their own closed enum values."""

        return context.verifier_policy, context.visual_policy

    def selection_request(
        self,
        evidence: DocumentEvidence,
        *,
        route_policy: RouteProfilePolicy | None = None,
        route_plan: DocumentRoutePlan | None = None,
    ) -> tuple[SemanticStrategySelectionRequest, SemanticStrategyReason]:
        context = self._context(route_policy=route_policy, route_plan=route_plan)
        topology = build_document_semantic_topology(evidence)
        primary_id, basis = self._primary_strategy(context, topology)
        candidate_ids = [primary_id]
        if primary_id is not SemanticStrategyId.GENERIC:
            candidate_ids.append(SemanticStrategyId.GENERIC)
        candidates = tuple(
            SemanticStrategyCandidate.from_strategy(
                _REGISTERED_STRATEGIES[strategy_id],
                verifier_policy=self._effective_policies(context)[0],
                visual_policy=self._effective_policies(context)[1],
            )
            for strategy_id in candidate_ids
        )
        return (
            SemanticStrategySelectionRequest(
                route_context=context,
                topology=topology,
                candidates=candidates,
            ),
            basis,
        )

    @staticmethod
    def _decision(
        request: SemanticStrategySelectionRequest,
        *,
        strategy_id: SemanticStrategyId,
        reason_codes: tuple[SemanticStrategyReason, ...],
        model_used: bool = False,
        model_confidence: float | None = None,
    ) -> SemanticStrategyDecision:
        strategy = _REGISTERED_STRATEGIES[strategy_id]
        verifier_policy = request.route_context.verifier_policy
        visual_policy = request.route_context.visual_policy
        return SemanticStrategyDecision(
            strategy_id=strategy.strategy_id,
            mapper_id=strategy.mapper_id,
            schema_id=strategy.schema_id,
            prompt_id=strategy.prompt_id,
            budget=strategy.budget,
            verifier_policy=verifier_policy,
            visual_policy=visual_policy,
            authority_policy=request.route_context.authority_policy,
            route_context=request.route_context,
            topology=request.topology,
            candidates=request.candidates,
            reason_codes=reason_codes,
            model_used=model_used,
            model_confidence=model_confidence,
        )

    def resolve(
        self,
        evidence: DocumentEvidence,
        *,
        route_policy: RouteProfilePolicy | None = None,
        route_plan: DocumentRoutePlan | None = None,
        model_choice: SemanticStrategyModelChoice | Mapping[str, Any] | None = None,
    ) -> SemanticStrategyDecision:
        """Resolve a deterministic default or validate one bounded model choice."""

        request, basis = self.selection_request(
            evidence,
            route_policy=route_policy,
            route_plan=route_plan,
        )
        default_id = request.candidates[0].strategy_id
        if model_choice is None:
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis,),
            )
        try:
            choice = SemanticStrategyModelChoice.model_validate(model_choice)
        except Exception:  # noqa: BLE001 - advisory selector fails closed
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis, "invalid_model_choice"),
                model_used=True,
            )
        candidate_ids = {candidate.strategy_id for candidate in request.candidates}
        if choice.strategy_id not in candidate_ids:
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis, "model_candidate_rejected"),
                model_used=True,
                model_confidence=choice.confidence,
            )
        if choice.confidence < self.model_min_confidence:
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis, "model_confidence_below_threshold"),
                model_used=True,
                model_confidence=choice.confidence,
            )
        return self._decision(
            request,
            strategy_id=choice.strategy_id,
            reason_codes=(basis, "model_selected"),
            model_used=True,
            model_confidence=choice.confidence,
        )

    def resolve_for_taxonomy(
        self,
        evidence: DocumentEvidence,
        *,
        document_type: object,
        document_subtype: object = None,
        verifier_policy: RouteVerifierPolicy = RouteVerifierPolicy.ON_UNCERTAINTY,
        visual_policy: RouteVisualPolicy = "on_uncertainty",
        authority_policy: RouteAuthorityPolicy = RouteAuthorityPolicy.EVIDENCE_REQUIRED,
    ) -> SemanticStrategyDecision:
        """Issue a closed replay decision for one canonical taxonomy.

        This is deliberately deterministic.  A classification router may
        suggest a canonical type, but it cannot choose mapper/schema/prompt IDs
        independently or ask a model to invent an executable strategy.
        """

        try:
            canonical_type = RouteDocumentType(str(document_type).strip().casefold())
        except ValueError:
            return self.resolve(evidence)
        canonical_subtype: RouteDocumentSubtype | None = None
        raw_subtype = str(document_subtype or "").strip().casefold()
        if raw_subtype and raw_subtype != "unknown":
            try:
                canonical_subtype = RouteDocumentSubtype(raw_subtype)
            except ValueError:
                canonical_subtype = None
        try:
            policy = RouteProfilePolicy(
                schema_family=_TYPE_FAMILIES[canonical_type],
                document_type_hint=canonical_type,
                document_subtype_hint=canonical_subtype,
                verifier_policy=verifier_policy,
                visual_policy=visual_policy,
                authority_policy=authority_policy,
            )
        except ValueError:
            # A subtype/type mismatch must never route to the wrong mapper.
            policy = RouteProfilePolicy(
                schema_family=_TYPE_FAMILIES[canonical_type],
                document_type_hint=canonical_type,
                verifier_policy=verifier_policy,
                visual_policy=visual_policy,
                authority_policy=authority_policy,
            )
        return self.resolve(evidence, route_policy=policy)

    async def resolve_with_selector(
        self,
        evidence: DocumentEvidence,
        *,
        selector: SemanticStrategySelector | None,
        route_policy: RouteProfilePolicy | None = None,
        route_plan: DocumentRoutePlan | None = None,
    ) -> SemanticStrategyDecision:
        """Call an optional selector; failure remains on the deterministic path."""

        request, basis = self.selection_request(
            evidence,
            route_policy=route_policy,
            route_plan=route_plan,
        )
        default_id = request.candidates[0].strategy_id
        # A selector cannot add value when the registry exposes only the generic
        # default. More importantly, never call a model without a genuine closed
        # alternative already authorized by the server.
        if selector is None or len(request.candidates) < 2:
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis,),
            )
        try:
            choice = await selector.select(request)
        except Exception:  # noqa: BLE001 - advisory selector fails closed
            return self._decision(
                request,
                strategy_id=default_id,
                reason_codes=(basis, "model_failure"),
                model_used=True,
            )
        return self.resolve(
            evidence,
            route_policy=route_policy,
            route_plan=route_plan,
            model_choice=choice,
        )


__all__ = [
    "DocumentSemanticTopology",
    "PydanticSemanticStrategySelector",
    "SemanticBudget",
    "SemanticBudgetId",
    "SemanticMapperId",
    "SemanticPromptId",
    "SemanticRouteContext",
    "SemanticSchemaId",
    "SemanticStrategy",
    "SemanticStrategyCandidate",
    "SemanticStrategyDecision",
    "SemanticStrategyId",
    "SemanticStrategyModelChoice",
    "SemanticStrategyRouter",
    "SemanticStrategySelectionRequest",
    "SemanticStrategySelector",
    "StructuredSemanticSelectionClient",
    "build_document_semantic_topology",
    "registered_semantic_strategies",
]
