"""Parser orchestration, shadow comparison and business-contract adaptation."""

from __future__ import annotations

import asyncio
import copy
import time
import unicodedata
from collections.abc import Callable
from pathlib import Path
from typing import Any

from loguru import logger

from .base import DocumentParserBackend, PageInput
from .business_evidence import (
    _blocking_evidence_pages,
    _business_output_empty,
    _evidence_has_content,
    _has_blocking_evidence_issue,
    _has_deterministic_drawing_content,
    _merge_vlm_supplement,
    _record_vlm_failure,
    _record_vlm_unavailable,
    _safe_error,
)
from .comparison import compare_document_records
from .docling import DoclingBackend
from .document_routing_status import DocumentRoutingDependencyError
from .evidence import DocumentEvidence, EvidencePage
from .finalization import (
    apply_docling_evidence as _apply_docling_evidence,
)
from .finalization import (
    evidence_sections as _evidence_sections,
)
from .finalization import (
    metadata as _metadata,
)
from .finalization import (
    reproject_structured_technical_document as _reproject_structured_technical_document,
)
from .page_capability_execution import (
    PageCapabilityRouter,
    completed_pages,
    record_completed_capability,
    resolve_page_capabilities,
    resolve_pdf_page_capabilities,
)
from .pdf_evidence_merge import align_structured_order_tables
from .region_capability_contracts import ParsingCapability, RegionSourceKind
from .structured import (
    PaddleOCRVLBackend,
    PPStructureV3Backend,
    merge_evidence,
    record_supplement_timing,
)

_SHADOW_SUPPRESSIBLE_VLM_REASONS = {"page_dominated_by_complex_table"}


def _evidence_summary(evidence: DocumentEvidence) -> dict[str, Any]:
    """Expose primary, supplement and total timings on every parser path."""

    summary = evidence.summary()
    timing = evidence.raw.get("timing")
    if not isinstance(timing, dict):
        primary_elapsed_ms = round(float(evidence.elapsed_ms), 3)
        timing = {
            "primary_backend": evidence.backend,
            "primary_elapsed_ms": primary_elapsed_ms,
            "supplement_backends": [],
            "supplement_elapsed_ms": 0.0,
            "total_elapsed_ms": primary_elapsed_ms,
        }
    summary["timing"] = copy.deepcopy(timing)
    summary["elapsed_ms"] = timing.get("total_elapsed_ms", summary["elapsed_ms"])
    for key in (
        "region_capability_routing",
        "completed_capabilities_by_page",
    ):
        if key in evidence.raw:
            summary[key] = copy.deepcopy(evidence.raw[key])
    return summary


def _has_reliable_structured_page(
    page: EvidencePage,
    *,
    require_table_matrix: bool = False,
) -> bool:
    """Return whether PP evidence can safely stand alone in shadow mode."""

    _, reasons = page.needs_vlm()
    if not set(reasons).issubset(_SHADOW_SUPPRESSIBLE_VLM_REASONS):
        return False
    has_text = bool(page.text.strip())
    has_table_matrix = any(
        table.rows
        and any(any(str(cell or "").strip() for cell in row) for row in table.rows)
        for table in page.tables
    )
    if require_table_matrix:
        return has_table_matrix
    return has_text or has_table_matrix


def _reliable_structured_pages(
    evidence: DocumentEvidence,
    page_numbers: set[int],
    *,
    require_table_matrix: bool = False,
) -> bool:
    by_number = {page.page_number: page for page in evidence.pages}
    return bool(page_numbers) and all(
        page_number in by_number
        and _has_reliable_structured_page(
            by_number[page_number], require_table_matrix=require_table_matrix
        )
        for page_number in page_numbers
    )


def _page_inputs(document: dict[str, Any]) -> list[PageInput]:
    extraction = document.get("extraction")
    raw = extraction.get("raw_content") if isinstance(extraction, dict) else None
    pages = raw.get("pages") if isinstance(raw, dict) else None
    result: list[PageInput] = []
    if not isinstance(pages, list):
        return result
    for index, page in enumerate(pages):
        if not isinstance(page, dict):
            continue
        asset = Path(str(page.get("render_asset") or ""))
        if not asset.is_file():
            continue
        result.append(
            PageInput(
                path=asset,
                page_number=int(page.get("page_number") or index + 1),
                page_index=int(page.get("page_index") or index),
                coordinate_width=float(
                    page.get("coordinate_width") or page.get("width") or 1.0
                ),
                coordinate_height=float(
                    page.get("coordinate_height") or page.get("height") or 1.0
                ),
                rotation=int(page.get("rotation") or 0),
            )
        )
    return result


def _scaled_bbox(
    page: EvidencePage,
    bbox,
    *,
    target_width: float,
    target_height: float,
) -> list[float] | None:
    if bbox is None:
        return None
    return bbox.scale_to(
        source_width=page.width,
        source_height=page.height,
        target_width=target_width,
        target_height=target_height,
    )


def _table_payload(
    page: EvidencePage,
    table,
    *,
    table_index: int,
    target_width: float,
    target_height: float,
) -> dict[str, Any]:
    row_count = len(table.rows)
    column_count = max((len(row) for row in table.rows), default=0)
    confidence_matrix = [[0.0 for _ in range(column_count)] for _ in range(row_count)]
    bbox_matrix: list[list[list[float] | None]] = [
        [None for _ in range(column_count)] for _ in range(row_count)
    ]
    for cell in table.cells:
        if cell.row >= row_count or cell.column >= column_count:
            continue
        confidence_matrix[cell.row][cell.column] = (
            float(cell.confidence) if cell.confidence is not None else 0.65
        )
        bbox_matrix[cell.row][cell.column] = _scaled_bbox(
            page,
            cell.bbox,
            target_width=target_width,
            target_height=target_height,
        )
    flat = [box for row in bbox_matrix for box in row if box is not None]
    bbox = _scaled_bbox(
        page,
        table.bbox,
        target_width=target_width,
        target_height=target_height,
    )
    if bbox is None and flat:
        bbox = [
            min(box[0] for box in flat),
            min(box[1] for box in flat),
            max(box[2] for box in flat),
            max(box[3] for box in flat),
        ]
    return {
        "table_index": table_index,
        "bbox": bbox or [0.0, 0.0, target_width, target_height],
        "row_count": row_count,
        "column_count": column_count,
        "rows_original": copy.deepcopy(table.rows),
        "rows_normalized": copy.deepcopy(table.rows),
        "cell_bboxes": flat,
        "cell_bbox_matrix": bbox_matrix,
        "cell_confidences": confidence_matrix,
        "coordinate_space": "pdf_points",
        "ocr_derived": True,
        "source": (
            table.source
            or (
                page.model_extra.get("source", "structured-parser")
                if page.model_extra
                else "structured-parser"
            )
        ),
    }


def _preserve_authoritative_facts(
    baseline: dict[str, Any],
    candidate: dict[str, Any],
    *,
    doc_type_hint: str | None,
    document_subtype_hint: str | None,
) -> dict[str, Any]:
    baseline_header = (
        baseline.get("header") if isinstance(baseline.get("header"), dict) else {}
    )
    candidate_header = candidate.setdefault("header", {})
    baseline_meta = (
        baseline.get("field_meta")
        if isinstance(baseline.get("field_meta"), dict)
        else {}
    )
    candidate_meta = candidate.setdefault("field_meta", {})
    for field, value in baseline_header.items():
        path = f"$.header.{field}"
        meta = (
            baseline_meta.get(path) if isinstance(baseline_meta.get(path), dict) else {}
        )
        confidence = float(meta.get("confidence", 1.0)) if meta else 1.0
        if value not in (None, "", [], {}) and confidence >= 0.9:
            candidate_header[field] = copy.deepcopy(value)
            if path in baseline_meta:
                candidate_meta[path] = copy.deepcopy(baseline_meta[path])

    if baseline.get("lines") and not candidate.get("lines"):
        candidate["lines"] = copy.deepcopy(baseline["lines"])
        for path, value in baseline_meta.items():
            if str(path).startswith("$.lines["):
                candidate_meta[path] = copy.deepcopy(value)
        candidate.setdefault("validation_issues", []).append(
            {
                "code": "STRUCTURED_TABLE_FALLBACK",
                "severity": "info",
                "message": "结构化后端未形成有效明细表，已保留原生确定性表格。",
                "paths": ["$.lines"],
                "source_refs": [],
            }
        )
    if doc_type_hint:
        candidate["document_type"] = doc_type_hint
    if document_subtype_hint:
        candidate["document_subtype"] = document_subtype_hint
    return candidate


def _append_structured_review_issues(
    candidate: dict[str, Any], evidence: DocumentEvidence
) -> dict[str, Any]:
    issues = candidate.setdefault("validation_issues", [])
    if not isinstance(issues, list):
        issues = []
        candidate["validation_issues"] = issues

    failed_pages = sorted(
        {int(value) for value in evidence.raw.get("vlm_failed_pages", [])}
    )
    if failed_pages and not any(
        isinstance(issue, dict)
        and issue.get("code") == "PADDLEOCR_VL_ESCALATION_FAILED"
        for issue in issues
    ):
        issues.append(
            {
                "code": "PADDLEOCR_VL_ESCALATION_FAILED",
                "severity": "warning",
                "message": "页面需要视觉补充，但 PaddleOCR-VL 未在时限内形成可验证证据。",
                "paths": ["$.extraction.metadata.structured_parser"],
                "source_refs": [{"page": page} for page in failed_pages],
                "actual": {
                    str(page): evidence.raw.get("vlm_failure_types", {}).get(str(page))
                    for page in failed_pages
                },
                "suggestion": "已保留 PP-Structure 与原生证据，请人工复核缺失字段。",
            }
        )

    unavailable_pages = sorted(
        {int(value) for value in evidence.raw.get("vlm_unavailable_pages", [])}
    )
    if unavailable_pages and not any(
        isinstance(issue, dict)
        and issue.get("code") == "PADDLEOCR_VL_ESCALATION_UNAVAILABLE"
        for issue in issues
    ):
        issues.append(
            {
                "code": "PADDLEOCR_VL_ESCALATION_UNAVAILABLE",
                "severity": "warning",
                "message": "页面需要视觉补充，但 PaddleOCR-VL 后端或对应渲染页不可用。",
                "paths": ["$.extraction.metadata.structured_parser"],
                "source_refs": [{"page": page} for page in unavailable_pages],
                "actual": {
                    str(page): evidence.raw.get("vlm_unavailable_reasons", {}).get(
                        str(page)
                    )
                    for page in unavailable_pages
                },
                "suggestion": "已保留 PP-Structure 与原生证据，请人工复核缺失字段并检查 VLM 配置。",
            }
        )

    if (
        _evidence_has_content(evidence)
        and _business_output_empty(candidate)
        and not any(
            isinstance(issue, dict)
            and issue.get("code") == "STRUCTURED_BUSINESS_OUTPUT_EMPTY"
            for issue in issues
        )
    ):
        issues.append(
            {
                "code": "STRUCTURED_BUSINESS_OUTPUT_EMPTY",
                "severity": "error",
                "message": "结构化后端提取到内容，但未能映射到业务文档字段。",
                "paths": ["$.document_type", "$.header", "$.lines"],
                "source_refs": [{"page": page.page_number} for page in evidence.pages],
                "suggestion": "请人工确认文档类型，或补充对应的确定性业务适配器。",
            }
        )
    if any(
        isinstance(issue, dict)
        and str(issue.get("severity") or "").casefold() in {"warning", "error"}
        for issue in issues
    ):
        candidate["needs_review"] = True
    return candidate


def apply_evidence_to_pdf_document(
    baseline: dict[str, Any],
    evidence: DocumentEvidence,
    *,
    filename: str,
    doc_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
) -> dict[str, Any]:
    """Translate provider evidence to the existing PDF/business builder contract."""

    working = copy.deepcopy(baseline)
    extraction = working.get("extraction")
    raw = extraction.get("raw_content") if isinstance(extraction, dict) else None
    pages = raw.get("pages") if isinstance(raw, dict) else None
    if not isinstance(pages, list):
        raise TypeError("baseline PDF document has no page evidence")
    by_number = {
        int(page.get("page_number") or index + 1): page
        for index, page in enumerate(pages)
        if isinstance(page, dict)
    }
    for evidence_page in evidence.pages:
        page = by_number.get(evidence_page.page_number)
        if page is None:
            continue
        target_width = float(page.get("coordinate_width") or page.get("width") or 1.0)
        target_height = float(
            page.get("coordinate_height") or page.get("height") or 1.0
        )
        lines = []
        for block in evidence_page.blocks:
            if not block.text.strip():
                continue
            lines.append(
                {
                    "text_original": block.text,
                    "text_normalized": block.text,
                    "confidence": float(block.confidence)
                    if block.confidence is not None
                    else 0.65,
                    "bbox": _scaled_bbox(
                        evidence_page,
                        block.bbox,
                        target_width=target_width,
                        target_height=target_height,
                    ),
                    "coordinate_space": "pdf_points",
                    "source": block.source or evidence.backend,
                    "kind": block.kind,
                }
            )
        tables = [
            _table_payload(
                evidence_page,
                table,
                table_index=20_000 + evidence_page.page_number * 100 + index,
                target_width=target_width,
                target_height=target_height,
            )
            for index, table in enumerate(evidence_page.tables)
            if table.rows
        ]
        if tables and str(baseline.get("document_type") or "").casefold() == "order":
            tables = align_structured_order_tables(
                [
                    table
                    for table in page.get("tables") or []
                    if isinstance(table, dict)
                ],
                tables,
            )
        page["ocr_lines"] = lines
        page["ocr_text_original"] = "\n".join(item["text_original"] for item in lines)
        page["ocr_text_normalized"] = "\n".join(
            item["text_normalized"] for item in lines
        )
        page["ocr_tables"] = tables
        page["ocr_coordinate_space"] = "pdf_points"
        page["structured_parser_backend"] = evidence.backend
        # Order tables use the structured matrix as their primary row source.
        # Engineering drawings retain native tables because a page-spanning PP
        # table often mixes the BOM, title block and diagram into one matrix.
        if tables and str(baseline.get("document_type") or "").casefold() == "order":
            page["tables"] = []

    from ..adapters.pdf import rebuild_pdf_document_after_ocr

    candidate = rebuild_pdf_document_after_ocr(working, filename=filename)
    candidate = _preserve_authoritative_facts(
        baseline,
        candidate,
        doc_type_hint=doc_type_hint,
        document_subtype_hint=document_subtype_hint,
    )
    metadata = _metadata(candidate)
    metadata["structured_parser"] = _evidence_summary(evidence)
    metadata["structured_evidence"] = evidence.bounded_dump()
    return _append_structured_review_issues(candidate, evidence)


class DocumentParserService:
    """Coordinate optional parser plugins without changing public contracts."""

    def __init__(
        self,
        *,
        mode: str = "legacy",
        pp_structure: DocumentParserBackend | None = None,
        paddle_vl: DocumentParserBackend | None = None,
        docling: DocumentParserBackend | None = None,
        page_capability_router: PageCapabilityRouter | None = None,
        pp_timeout_seconds: float = 120.0,
        vl_timeout_seconds: float = 180.0,
        native_pdf_parser: Callable[..., Any] | None = None,
        native_docx_parser: Callable[..., Any] | None = None,
    ) -> None:
        normalized_mode = mode.strip().casefold()
        if normalized_mode not in {"legacy", "shadow", "structured"}:
            raise ValueError(
                "document parser mode must be legacy, shadow or structured"
            )
        self.mode = normalized_mode
        self.pp_structure = pp_structure
        self.paddle_vl = paddle_vl
        self.docling = docling
        self.page_capability_router = page_capability_router
        self.pp_timeout_seconds = pp_timeout_seconds
        self.vl_timeout_seconds = vl_timeout_seconds
        self._native_pdf_parser = native_pdf_parser
        self._native_docx_parser = native_docx_parser
        self._inference_lock = asyncio.Lock()
        self._active_inference: asyncio.Task[DocumentEvidence] | None = None
        self._inference_timed_out = False
        # A routed target includes its deterministic baseline as well as optional
        # GPU inference.  Track that whole operation so a timeout cannot launch
        # a native or GPU fallback alongside work that Python cannot cancel.
        self._route_operation_lock = asyncio.Lock()
        self._active_route_operation: asyncio.Task[Any] | None = None
        self._route_operation_timed_out = False

    def readiness(self) -> dict[str, Any]:
        backends: dict[str, dict[str, Any]] = {}
        for backend in (self.pp_structure, self.paddle_vl, self.docling):
            if backend is not None:
                backends[backend.name] = backend.readiness()
        required_names: list[str] = []
        missing_backends: list[str] = []
        ready = True
        if self.mode in {"shadow", "structured"}:
            required_names.append("pp-structure-v3")
            if self.pp_structure is None:
                missing_backends.append("pp-structure-v3")
                ready = False
            for backend in (self.pp_structure, self.paddle_vl, self.docling):
                if backend is None:
                    continue
                required_names.append(backend.name)
                if not bool(backends[backend.name].get("ready")):
                    ready = False
        active = self._active_inference
        inference_busy = active is not None and not active.done()
        active_route = self._active_route_operation
        route_busy = active_route is not None and not active_route.done()
        if inference_busy and self._inference_timed_out:
            ready = False
        if route_busy and self._route_operation_timed_out:
            ready = False
        return {
            "mode": self.mode,
            "ready": ready,
            "required_backends": sorted(set(required_names)),
            "missing_backends": missing_backends,
            "backends": backends,
            "inference": {
                "busy": inference_busy,
                "timed_out": bool(inference_busy and self._inference_timed_out),
            },
        }

    @staticmethod
    def _bounded_target_timeout(
        requested_timeout: float | None,
        configured_timeout: float,
    ) -> float:
        """A route profile may reduce, never enlarge, a backend's own cap."""

        configured = max(0.001, float(configured_timeout))
        if requested_timeout is None:
            return configured
        try:
            requested = float(requested_timeout)
        except (TypeError, ValueError):
            return configured
        if requested <= 0.0:
            return configured
        return min(configured, requested)

    async def _run_routed_operation(
        self,
        operation: Callable[[], Any],
        *,
        timeout: float,
    ) -> Any:
        """Run one whole routed target while keeping timed-out work visible."""

        async with self._route_operation_lock:
            active = self._active_route_operation
            if active is not None and not active.done():
                raise RuntimeError(
                    "parser route operation is still running after timeout"
                )
            if active is not None:
                try:
                    active.exception()
                except asyncio.CancelledError:
                    pass
                self._active_route_operation = None
                self._route_operation_timed_out = False

            task = asyncio.create_task(operation())
            self._active_route_operation = task
            self._route_operation_timed_out = False

            def consume_background_result(completed: asyncio.Task[Any]) -> None:
                try:
                    completed.exception()
                except asyncio.CancelledError:
                    pass
                if self._active_route_operation is completed:
                    self._active_route_operation = None
                    self._route_operation_timed_out = False

            try:
                return await asyncio.wait_for(
                    asyncio.shield(task), timeout=max(0.001, float(timeout))
                )
            except TimeoutError:
                # Native adapters and GPU predictors can keep executing in a
                # worker thread after their awaitable is timed out.  Do not let
                # a caller begin a fallback until this task has actually ended.
                self._route_operation_timed_out = True
                task.add_done_callback(consume_background_result)
                raise
            except asyncio.CancelledError:
                if not task.done():
                    self._route_operation_timed_out = True
                    task.add_done_callback(consume_background_result)
                raise
            finally:
                if task.done() and self._active_route_operation is task:
                    self._active_route_operation = None
                    self._route_operation_timed_out = False

    async def _run_backend(
        self,
        backend: DocumentParserBackend,
        path: str | Path,
        *,
        pages: list[PageInput] | None,
        timeout: float,
    ) -> DocumentEvidence:
        async with self._inference_lock:
            active = self._active_inference
            if active is not None and not active.done():
                raise RuntimeError("parser inference is still running after timeout")
            if active is not None:
                try:
                    active.exception()
                except asyncio.CancelledError:
                    pass
                self._active_inference = None
                self._inference_timed_out = False

            task = asyncio.create_task(
                asyncio.to_thread(backend.parse, path, pages=pages)
            )
            self._active_inference = task
            self._inference_timed_out = False

            def consume_background_result(
                completed: asyncio.Task[DocumentEvidence],
            ) -> None:
                try:
                    completed.exception()
                except asyncio.CancelledError:
                    pass
                if self._active_inference is completed:
                    self._active_inference = None
                    self._inference_timed_out = False

            try:
                return await asyncio.wait_for(asyncio.shield(task), timeout=timeout)
            except TimeoutError:
                # Python cannot stop a predictor already executing in a worker
                # thread. Keep its task visible so subsequent requests fail fast
                # instead of starting overlapping GPU work.
                self._inference_timed_out = True
                task.add_done_callback(consume_background_result)
                raise
            finally:
                if task.done() and self._active_inference is task:
                    self._active_inference = None
                    self._inference_timed_out = False

    async def _pdf_evidence(
        self,
        path: str | Path,
        document: dict[str, Any],
        *,
        tenant_id: str = "default",
    ) -> DocumentEvidence:
        if self.pp_structure is None:
            raise RuntimeError("PP-StructureV3 backend is disabled")
        pages = _page_inputs(document)
        evidence = await self._run_backend(
            self.pp_structure,
            path,
            pages=pages or None,
            timeout=self.pp_timeout_seconds,
        )
        record_completed_capability(
            evidence,
            ParsingCapability.PP_STRUCTURE_V3,
            (page.page_number for page in evidence.pages),
        )
        reasons_by_page: dict[str, list[str]] = {}
        selected_numbers: set[int] = set()
        suppressed_numbers: set[int] = set()
        deterministic_drawing = _has_deterministic_drawing_content(document)
        for page in evidence.pages:
            required, reasons = page.needs_vlm()
            if not required:
                continue
            reasons_by_page[str(page.page_number)] = reasons
            if (
                self.mode == "shadow"
                and deterministic_drawing
                and _has_reliable_structured_page(page)
            ):
                suppressed_numbers.add(page.page_number)
            else:
                selected_numbers.add(page.page_number)
        if reasons_by_page:
            evidence.raw["vlm_escalation_reasons_by_page"] = reasons_by_page
        if suppressed_numbers:
            evidence.raw["vlm_escalation_suppressed_pages"] = sorted(suppressed_numbers)
        routable_page_numbers = {page.page_number for page in evidence.pages}
        if self.page_capability_router is not None and routable_page_numbers:
            try:
                route_plan = await resolve_pdf_page_capabilities(
                    evidence,
                    router=self.page_capability_router,
                    tenant_id=tenant_id,
                    page_numbers=routable_page_numbers,
                    priority_page_numbers=(
                        int(page_number) for page_number in reasons_by_page
                    ),
                )
            except Exception as exc:
                if isinstance(exc, DocumentRoutingDependencyError):
                    raise
                evidence.raw["region_capability_routing"] = {
                    "schema_version": "m1.pdf-page-capability-routing.v1",
                    "status": "degraded",
                    "error_type": exc.__class__.__name__,
                    "requested_pages": sorted(routable_page_numbers),
                    "priority_pages": sorted(int(value) for value in reasons_by_page),
                    "routed_pages": [],
                }
            else:
                evidence.raw["region_capability_routing"] = route_plan.audit
                # An active, reviewed PaddleOCR-VL profile may override the legacy
                # shadow suppression. Other actions retain the existing needs_vlm
                # selection, so router/store/model failures never reduce coverage.
                selected_numbers.update(route_plan.paddleocr_vl_pages)
        if selected_numbers:
            if self.paddle_vl is None:
                _record_vlm_unavailable(
                    evidence,
                    selected_numbers,
                    reason="backend_disabled",
                )
            else:
                selected = [
                    page for page in pages if page.page_number in selected_numbers
                ]
                rendered_numbers = {page.page_number for page in selected}
                unavailable_numbers = selected_numbers - rendered_numbers
                if unavailable_numbers:
                    # PaddleOCR-VL is an escalation backend for rendered pages
                    # or regions. Passing the original PDF bypasses that contract
                    # and can spend the entire timeout in the PDF loader.
                    evidence.raw["vlm_escalation_skipped_pages"] = sorted(
                        unavailable_numbers
                    )
                    _record_vlm_unavailable(
                        evidence,
                        unavailable_numbers,
                        reason="rendered_page_unavailable",
                    )
                if selected:
                    supplement_started = time.perf_counter()
                    try:
                        supplement = await self._run_backend(
                            self.paddle_vl,
                            path,
                            pages=selected,
                            timeout=self.vl_timeout_seconds,
                        )
                    except Exception as exc:  # noqa: BLE001 - optional supplement
                        record_supplement_timing(
                            evidence,
                            backend=self.paddle_vl.name,
                            elapsed_ms=(time.perf_counter() - supplement_started)
                            * 1000.0,
                        )
                        _record_vlm_failure(evidence, rendered_numbers, exc)
                    else:
                        evidence = merge_evidence(evidence, supplement)
                        evidence.raw["vlm_escalated_pages"] = sorted(rendered_numbers)
                        produced_numbers = rendered_numbers & {
                            page.page_number for page in supplement.pages
                        }
                        record_completed_capability(
                            evidence,
                            ParsingCapability.PADDLEOCR_VL,
                            produced_numbers,
                        )
        return evidence

    async def parse_image(
        self,
        path: str | Path,
        *,
        tenant_id: str = "default",
    ) -> DocumentEvidence:
        """Parse one image through PP-Structure, escalating only when required."""

        if self.mode == "legacy":
            raise RuntimeError("structured image parsing is disabled in legacy mode")
        if self.pp_structure is None:
            raise RuntimeError("PP-StructureV3 backend is disabled")
        from PIL import Image

        source = Path(path)
        with Image.open(source) as image:
            width, height = image.size
        pages = [
            PageInput(
                path=source,
                page_number=1,
                page_index=0,
                coordinate_width=float(width),
                coordinate_height=float(height),
                rotation=0,
            )
        ]
        evidence = await self._run_backend(
            self.pp_structure,
            source,
            pages=pages,
            timeout=self.pp_timeout_seconds,
        )
        record_completed_capability(
            evidence,
            ParsingCapability.PP_STRUCTURE_V3,
            (page.page_number for page in evidence.pages),
        )
        reasons_by_page: dict[str, list[str]] = {}
        selected_numbers: set[int] = set()
        for page in evidence.pages:
            needs_supplement, reasons = page.needs_vlm()
            if needs_supplement:
                reasons_by_page[str(page.page_number)] = reasons
                selected_numbers.add(page.page_number)
        if reasons_by_page:
            evidence.raw["vlm_escalation_reasons_by_page"] = reasons_by_page
        routable_page_numbers = {page.page_number for page in evidence.pages}
        if self.page_capability_router is not None and routable_page_numbers:
            try:
                route_plan = await resolve_page_capabilities(
                    evidence,
                    router=self.page_capability_router,
                    tenant_id=tenant_id,
                    page_numbers=routable_page_numbers,
                    source_kind=RegionSourceKind.IMAGE_REGION,
                    priority_page_numbers=(
                        int(page_number) for page_number in reasons_by_page
                    ),
                )
            except Exception as exc:
                if isinstance(exc, DocumentRoutingDependencyError):
                    raise
                evidence.raw["region_capability_routing"] = {
                    "schema_version": "m1.image-page-capability-routing.v1",
                    "status": "degraded",
                    "source_kind": RegionSourceKind.IMAGE_REGION.value,
                    "error_type": exc.__class__.__name__,
                    "requested_pages": sorted(routable_page_numbers),
                    "priority_pages": sorted(int(value) for value in reasons_by_page),
                    "routed_pages": [],
                }
            else:
                evidence.raw["region_capability_routing"] = route_plan.audit
                selected_numbers.update(route_plan.paddleocr_vl_pages)
        if selected_numbers:
            if self.paddle_vl is None:
                _record_vlm_unavailable(
                    evidence,
                    selected_numbers,
                    reason="backend_disabled",
                )
            else:
                selected_pages = [
                    page for page in pages if page.page_number in selected_numbers
                ]
                rendered_numbers = {page.page_number for page in selected_pages}
                unavailable_numbers = selected_numbers - rendered_numbers
                if unavailable_numbers:
                    _record_vlm_unavailable(
                        evidence,
                        unavailable_numbers,
                        reason="rendered_page_unavailable",
                    )
                if not selected_pages:
                    return evidence
                supplement_started = time.perf_counter()
                try:
                    supplement = await self._run_backend(
                        self.paddle_vl,
                        source,
                        pages=selected_pages,
                        timeout=self.vl_timeout_seconds,
                    )
                except Exception as exc:  # noqa: BLE001 - keep PP evidence
                    record_supplement_timing(
                        evidence,
                        backend=self.paddle_vl.name,
                        elapsed_ms=(time.perf_counter() - supplement_started) * 1000.0,
                    )
                    _record_vlm_failure(evidence, rendered_numbers, exc)
                else:
                    evidence = merge_evidence(evidence, supplement)
                    evidence.raw["vlm_escalated_pages"] = sorted(rendered_numbers)
                    produced_numbers = rendered_numbers & {
                        page.page_number for page in supplement.pages
                    }
                    record_completed_capability(
                        evidence,
                        ParsingCapability.PADDLEOCR_VL,
                        produced_numbers,
                    )
        return evidence

    async def parse_image_target(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        backend: str,
        doc_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        timeout_seconds: float | None = None,
    ):
        """Run one explicitly selected image backend through the v2 contract.

        Unlike ``parse_image``, this method never performs an implicit PP/VL
        escalation.  The route plan names the sole backend, and the resulting
        evidence is converted through the same generic builder and technical
        projection used by the other structured targets.
        """

        normalized = str(backend or "").strip().casefold()
        if normalized not in {"pp_structure_v3", "paddleocr_vl"}:
            raise ValueError(f"unsupported routed image backend: {backend}")
        if self.mode == "legacy":
            raise RuntimeError("structured image routing is disabled in legacy mode")
        selected = (
            self.pp_structure if normalized == "pp_structure_v3" else self.paddle_vl
        )
        if selected is None:
            raise RuntimeError(f"{normalized} backend is disabled")
        configured_timeout = (
            self.pp_timeout_seconds
            if normalized == "pp_structure_v3"
            else self.vl_timeout_seconds
        )
        timeout = self._bounded_target_timeout(timeout_seconds, configured_timeout)

        async def operation():
            from PIL import Image

            source_path = Path(path)
            with Image.open(source_path) as image:
                width, height = image.size
            pages = [
                PageInput(
                    path=source_path,
                    page_number=1,
                    page_index=0,
                    coordinate_width=float(width),
                    coordinate_height=float(height),
                    rotation=0,
                )
            ]
            evidence = await self._run_backend(
                selected,
                source_path,
                pages=pages,
                timeout=timeout,
            )
            from ..adapters.common import (
                build_document_record,
                file_sha256,
                guessed_mime,
                source_payload,
            )
            from .mineru_domain import CANONICAL_SUBTYPE_TYPES

            subtype = document_subtype_hint or "image_document"
            document_type = doc_type_hint or CANONICAL_SUBTYPE_TYPES.get(
                subtype,
                "technical_document",
            )
            candidate = build_document_record(
                source=source_payload(
                    source_path,
                    original_filename=original_filename,
                    mime_type=guessed_mime(source_path, "application/octet-stream"),
                    sha256=file_sha256(source_path),
                ),
                document_type=document_type,
                document_subtype=subtype,
                sections=_evidence_sections(evidence),
                raw_content={
                    "text_original": evidence.text,
                    "text_normalized": unicodedata.normalize("NFKC", evidence.text),
                    "image_pages": [
                        page.model_dump(mode="json", exclude={"raw"})
                        for page in evidence.pages
                    ],
                },
                metadata={
                    "adapter": normalized,
                    "structured_parser": _evidence_summary(evidence),
                    "structured_evidence": evidence.bounded_dump(),
                },
            ).model_dump(mode="json")
            candidate = _reproject_structured_technical_document(
                candidate,
                filename=original_filename or source_path.name,
            )
            candidate = _append_structured_review_issues(candidate, evidence)
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(candidate)

        return await self._run_routed_operation(operation, timeout=timeout)

    async def parse_pdf_target(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        backend: str,
        doc_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        render_dir: str | Path | None = None,
        render_dpi: int = 150,
        timeout_seconds: float | None = None,
        tenant_id: str = "default",
    ):
        """Run one explicitly selected PDF backend under a route target.

        The normal ``parse_pdf`` path keeps its existing shadow/structured
        behaviour.  This opt-in method is intentionally narrow: a governed
        document route fixes the primary backend to PP-StructureV3 or
        PaddleOCR-VL.  A page-capability route may append PaddleOCR-VL only
        after an explicit PP primary; it can never replace that primary or
        execute another backend.  Native baseline, source-reference conversion,
        public record validation and the caller's timeout ceiling remain
        mandatory.
        """

        normalized = str(backend or "").strip().casefold()
        if normalized not in {"pp_structure_v3", "paddleocr_vl"}:
            raise ValueError(f"unsupported routed PDF backend: {backend}")
        selected = (
            self.pp_structure if normalized == "pp_structure_v3" else self.paddle_vl
        )
        if selected is None:
            raise RuntimeError(f"{normalized} backend is disabled")
        configured_timeout = (
            self.pp_timeout_seconds
            if normalized == "pp_structure_v3"
            else self.vl_timeout_seconds
        )
        timeout = self._bounded_target_timeout(timeout_seconds, configured_timeout)

        async def operation():
            if self._native_pdf_parser is None:
                from ..adapters.pdf import parse_pdf_document

                native_parser = parse_pdf_document
            else:
                native_parser = self._native_pdf_parser
            baseline_record = await asyncio.to_thread(
                native_parser,
                path,
                original_filename,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
                render_dir=render_dir,
                render_dpi=render_dpi,
            )
            baseline = baseline_record.model_dump(mode="json")
            pages = _page_inputs(baseline)
            if normalized == "paddleocr_vl" and not pages:
                raise RuntimeError("PaddleOCR-VL requires rendered PDF pages")
            evidence = await self._run_backend(
                selected,
                path,
                pages=pages or None,
                timeout=timeout,
            )
            if normalized == "pp_structure_v3":
                record_completed_capability(
                    evidence,
                    ParsingCapability.PP_STRUCTURE_V3,
                    (page.page_number for page in evidence.pages),
                )
                reasons_by_page: dict[str, list[str]] = {}
                for page in evidence.pages:
                    needs_supplement, reasons = page.needs_vlm()
                    if needs_supplement:
                        reasons_by_page[str(page.page_number)] = reasons
                if reasons_by_page:
                    evidence.raw["vlm_escalation_reasons_by_page"] = reasons_by_page
                routable_page_numbers = {page.page_number for page in evidence.pages}
                if self.page_capability_router is not None and routable_page_numbers:
                    route_plan = await resolve_pdf_page_capabilities(
                        evidence,
                        router=self.page_capability_router,
                        tenant_id=tenant_id,
                        page_numbers=routable_page_numbers,
                        priority_page_numbers=(
                            int(page_number) for page_number in reasons_by_page
                        ),
                    )
                    evidence.raw["region_capability_routing"] = route_plan.audit
                    routed_numbers = set(route_plan.paddleocr_vl_pages)
                    if routed_numbers:
                        if self.paddle_vl is None:
                            _record_vlm_unavailable(
                                evidence,
                                routed_numbers,
                                reason="backend_disabled",
                            )
                            if bool(
                                getattr(self.page_capability_router, "required", False)
                            ):
                                raise RuntimeError(
                                    "required PaddleOCR-VL route backend is disabled"
                                )
                        else:
                            selected_pages = [
                                page
                                for page in pages
                                if page.page_number in routed_numbers
                            ]
                            rendered_numbers = {
                                page.page_number for page in selected_pages
                            }
                            unavailable_numbers = routed_numbers - rendered_numbers
                            if unavailable_numbers:
                                _record_vlm_unavailable(
                                    evidence,
                                    unavailable_numbers,
                                    reason="rendered_page_unavailable",
                                )
                                if bool(
                                    getattr(
                                        self.page_capability_router,
                                        "required",
                                        False,
                                    )
                                ):
                                    raise RuntimeError(
                                        "required PaddleOCR-VL route has no rendered page"
                                    )
                            if selected_pages:
                                supplement_started = time.perf_counter()
                                try:
                                    supplement = await self._run_backend(
                                        self.paddle_vl,
                                        path,
                                        pages=selected_pages,
                                        timeout=min(self.vl_timeout_seconds, timeout),
                                    )
                                except Exception as exc:
                                    record_supplement_timing(
                                        evidence,
                                        backend=self.paddle_vl.name,
                                        elapsed_ms=(
                                            time.perf_counter() - supplement_started
                                        )
                                        * 1000.0,
                                    )
                                    _record_vlm_failure(
                                        evidence,
                                        rendered_numbers,
                                        exc,
                                    )
                                    if bool(
                                        getattr(
                                            self.page_capability_router,
                                            "required",
                                            False,
                                        )
                                    ):
                                        raise
                                else:
                                    evidence = merge_evidence(evidence, supplement)
                                    evidence.raw["vlm_escalated_pages"] = sorted(
                                        rendered_numbers
                                    )
                                    produced_numbers = rendered_numbers & {
                                        page.page_number for page in supplement.pages
                                    }
                                    record_completed_capability(
                                        evidence,
                                        ParsingCapability.PADDLEOCR_VL,
                                        produced_numbers,
                                    )
            else:
                record_completed_capability(
                    evidence,
                    ParsingCapability.PADDLEOCR_VL,
                    (page.page_number for page in evidence.pages),
                )
            candidate = apply_evidence_to_pdf_document(
                baseline,
                evidence,
                filename=original_filename or Path(path).name,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
            )
            candidate = _reproject_structured_technical_document(
                candidate,
                filename=original_filename or Path(path).name,
            )
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(candidate)

        return await self._run_routed_operation(operation, timeout=timeout)

    async def parse_docx_target(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        backend: str,
        assets_dir: str | Path | None = None,
        timeout_seconds: float | None = None,
    ):
        """Run the optional Docling path when an approved route selects it."""

        if str(backend or "").strip().casefold() != "docling":
            raise ValueError(f"unsupported routed DOCX backend: {backend}")
        if self.docling is None:
            raise RuntimeError("Docling backend is disabled")
        timeout = self._bounded_target_timeout(
            timeout_seconds,
            self.pp_timeout_seconds,
        )

        async def operation():
            if self._native_docx_parser is None:
                from ..adapters.docx import parse_docx_document

                native_parser = parse_docx_document
            else:
                native_parser = self._native_docx_parser
            baseline_record = await asyncio.to_thread(
                native_parser,
                path,
                original_filename,
                assets_dir=assets_dir,
            )
            baseline = baseline_record.model_dump(mode="json")
            evidence = await self._run_backend(
                self.docling,
                path,
                pages=None,
                timeout=timeout,
            )
            candidate = _apply_docling_evidence(baseline, evidence)
            candidate = _reproject_structured_technical_document(
                candidate,
                filename=original_filename or Path(path).name,
            )
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(candidate)

        return await self._run_routed_operation(operation, timeout=timeout)

    async def parse_docling_target(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        kind: str,
        timeout_seconds: float | None = None,
    ):
        """Build the generic PPTX/HTML public record through selected Docling."""

        if kind not in {"pptx", "html"}:
            raise ValueError(f"unsupported routed Docling type: {kind}")
        if self.docling is None:
            raise RuntimeError("Docling backend is disabled")
        timeout = self._bounded_target_timeout(
            timeout_seconds,
            self.pp_timeout_seconds,
        )

        async def operation():
            evidence = await self._run_backend(
                self.docling,
                path,
                pages=None,
                timeout=timeout,
            )
            from ..adapters.common import (
                build_document_record,
                file_sha256,
                source_payload,
            )

            source_path = Path(path)
            mime_type = (
                "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                if kind == "pptx"
                else "text/html"
            )
            subtype = "presentation" if kind == "pptx" else "web_document"
            return build_document_record(
                source=source_payload(
                    source_path,
                    original_filename=original_filename,
                    mime_type=mime_type,
                    sha256=file_sha256(source_path),
                ),
                document_type="technical_document",
                document_subtype=subtype,
                sections=_evidence_sections(evidence),
                raw_content={
                    "text_original": evidence.text,
                    "text_normalized": unicodedata.normalize("NFKC", evidence.text),
                    "docling_pages": [
                        page.model_dump(mode="json", exclude={"raw"})
                        for page in evidence.pages
                    ],
                },
                metadata={
                    "adapter": "docling",
                    "structured_parser": _evidence_summary(evidence),
                    "structured_evidence": evidence.bounded_dump(),
                },
            )

        return await self._run_routed_operation(operation, timeout=timeout)

    async def parse_pdf(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        doc_type_hint: str | None = None,
        document_subtype_hint: str | None = None,
        render_dir: str | Path | None = None,
        render_dpi: int = 150,
        tenant_id: str = "default",
    ):
        if self._native_pdf_parser is None:
            from ..adapters.pdf import parse_pdf_document

            native_parser = parse_pdf_document
        else:
            native_parser = self._native_pdf_parser
        baseline_record = await asyncio.to_thread(
            native_parser,
            path,
            original_filename,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            render_dir=render_dir,
            render_dpi=render_dpi,
        )
        if self.mode == "legacy":
            return baseline_record
        baseline = baseline_record.model_dump(mode="json")
        try:
            evidence = await self._pdf_evidence(
                path,
                baseline,
                tenant_id=tenant_id,
            )
            candidate = apply_evidence_to_pdf_document(
                baseline,
                evidence,
                filename=original_filename or Path(path).name,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
            )
            if _has_blocking_evidence_issue(candidate):
                page_inputs = _page_inputs(baseline)
                already_escalated = {
                    int(page_number)
                    for page_number in evidence.raw.get("vlm_escalated_pages", [])
                }
                already_escalated.update(
                    completed_pages(evidence, ParsingCapability.PADDLEOCR_VL)
                )
                already_failed = {
                    int(page_number)
                    for page_number in evidence.raw.get("vlm_failed_pages", [])
                }
                already_unavailable = {
                    int(page_number)
                    for page_number in evidence.raw.get("vlm_unavailable_pages", [])
                }
                blocking_pages = _blocking_evidence_pages(candidate)
                target_numbers = (
                    blocking_pages
                    or {page.page_number for page in page_inputs}
                    or {page.page_number for page in evidence.pages}
                )
                evidence.raw["vlm_escalation_reasons"] = sorted(
                    {
                        *(
                            str(value)
                            for value in evidence.raw.get("vlm_escalation_reasons", [])
                        ),
                        "business_evidence_blocker",
                    }
                )
                reasons_by_page = evidence.raw.setdefault(
                    "vlm_escalation_reasons_by_page", {}
                )
                for page_number in target_numbers:
                    page_reasons = {
                        str(value)
                        for value in reasons_by_page.get(str(page_number), [])
                    }
                    page_reasons.add("business_evidence_blocker")
                    reasons_by_page[str(page_number)] = sorted(page_reasons)
                shadow_suppressed: set[int] = set()
                if self.mode == "shadow" and _has_deterministic_drawing_content(
                    baseline
                ):
                    shadow_suppressed = {
                        page_number
                        for page_number in target_numbers
                        if _reliable_structured_pages(
                            evidence,
                            {page_number},
                            require_table_matrix=True,
                        )
                    }
                if shadow_suppressed:
                    previously_suppressed = {
                        int(page_number)
                        for page_number in evidence.raw.get(
                            "vlm_escalation_suppressed_pages", []
                        )
                    }
                    evidence.raw["vlm_escalation_suppressed_pages"] = sorted(
                        previously_suppressed | shadow_suppressed
                    )
                processed = (
                    already_escalated
                    | already_failed
                    | already_unavailable
                    | shadow_suppressed
                )
                pending_numbers = target_numbers - processed
                remaining = [
                    page for page in page_inputs if page.page_number in pending_numbers
                ]
                remaining_numbers = {page.page_number for page in remaining}
                if self.paddle_vl is None:
                    if pending_numbers:
                        _record_vlm_unavailable(
                            evidence,
                            pending_numbers,
                            reason="backend_disabled",
                        )
                    candidate = _append_structured_review_issues(candidate, evidence)
                    _metadata(candidate)["structured_parser"] = _evidence_summary(
                        evidence
                    )
                    _metadata(candidate)["structured_evidence"] = (
                        evidence.bounded_dump()
                    )
                else:
                    unavailable_numbers = pending_numbers - remaining_numbers
                    if unavailable_numbers:
                        _record_vlm_unavailable(
                            evidence,
                            unavailable_numbers,
                            reason="rendered_page_unavailable",
                        )
                    if not remaining:
                        candidate = _append_structured_review_issues(
                            candidate, evidence
                        )
                        _metadata(candidate)["structured_parser"] = _evidence_summary(
                            evidence
                        )
                        _metadata(candidate)["structured_evidence"] = (
                            evidence.bounded_dump()
                        )
                    else:
                        supplement_started = time.perf_counter()
                        try:
                            supplement = await self._run_backend(
                                self.paddle_vl,
                                path,
                                pages=remaining,
                                timeout=self.vl_timeout_seconds,
                            )
                        except Exception as exc:  # noqa: BLE001 - keep PP candidate
                            record_supplement_timing(
                                evidence,
                                backend=self.paddle_vl.name,
                                elapsed_ms=(time.perf_counter() - supplement_started)
                                * 1000.0,
                            )
                            _record_vlm_failure(evidence, remaining_numbers, exc)
                            candidate = _append_structured_review_issues(
                                candidate, evidence
                            )
                            _metadata(candidate)["structured_parser"] = (
                                _evidence_summary(evidence)
                            )
                            _metadata(candidate)["structured_evidence"] = (
                                evidence.bounded_dump()
                            )
                        else:
                            evidence = merge_evidence(evidence, supplement)
                            escalated = already_escalated | remaining_numbers
                            evidence.raw["vlm_escalated_pages"] = sorted(escalated)
                            supplemented = apply_evidence_to_pdf_document(
                                baseline,
                                evidence,
                                filename=original_filename or Path(path).name,
                                doc_type_hint=doc_type_hint,
                                document_subtype_hint=document_subtype_hint,
                            )
                            candidate = _merge_vlm_supplement(
                                candidate,
                                supplemented,
                                doc_type_hint=doc_type_hint,
                                document_subtype_hint=document_subtype_hint,
                            )
            candidate = _reproject_structured_technical_document(
                candidate,
                filename=original_filename or Path(path).name,
            )
            from ..models import DocumentRecord

            candidate_record = DocumentRecord.model_validate(candidate)
        except Exception as exc:
            if isinstance(exc, DocumentRoutingDependencyError):
                raise
            logger.warning(
                "structured parser fallback backend={} error_type={}",
                getattr(self.pp_structure, "name", "disabled"),
                _safe_error(exc),
            )
            metadata = _metadata(baseline)
            metadata["structured_parser"] = {
                "status": "fallback",
                "error_type": _safe_error(exc),
            }
            baseline.setdefault("validation_issues", []).append(
                {
                    "code": "STRUCTURED_PARSER_FALLBACK",
                    "severity": "info",
                    "message": "结构化解析后端不可用，已返回原生确定性结果。",
                    "paths": ["$.extraction.metadata.structured_parser"],
                    "source_refs": [],
                    "actual": _safe_error(exc),
                }
            )
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(baseline)
        if self.mode == "shadow":
            metadata = _metadata(baseline)
            metadata["structured_parser"] = _evidence_summary(evidence)
            metadata["structured_parser_shadow"] = compare_document_records(
                baseline, candidate_record.model_dump(mode="json")
            )
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(baseline)
        return candidate_record

    async def parse_docx(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        assets_dir: str | Path | None = None,
    ):
        if self._native_docx_parser is None:
            from ..adapters.docx import parse_docx_document

            native_parser = parse_docx_document
        else:
            native_parser = self._native_docx_parser
        baseline_record = await asyncio.to_thread(
            native_parser,
            path,
            original_filename,
            assets_dir=assets_dir,
        )
        if self.mode == "legacy" or self.docling is None:
            return baseline_record
        baseline = baseline_record.model_dump(mode="json")
        try:
            evidence = await self._run_backend(
                self.docling,
                path,
                pages=None,
                timeout=self.pp_timeout_seconds,
            )
            candidate = _apply_docling_evidence(baseline, evidence)
        except Exception as exc:  # noqa: BLE001
            _metadata(baseline)["structured_parser"] = {
                "status": "fallback",
                "error_type": _safe_error(exc),
            }
            from ..models import DocumentRecord

            return DocumentRecord.model_validate(baseline)
        candidate = _reproject_structured_technical_document(
            candidate,
            filename=original_filename or Path(path).name,
        )
        from ..models import DocumentRecord

        if self.mode == "shadow":
            metadata = _metadata(baseline)
            legacy_raw = baseline.get("extraction", {}).get("raw_content", {})
            metadata["structured_parser"] = _evidence_summary(evidence)
            metadata["structured_parser_shadow"] = {
                "legacy_text_chars": len(str(legacy_raw.get("text_original") or "")),
                "candidate_text_chars": len(evidence.text),
                "legacy_table_count": len(legacy_raw.get("tables") or []),
                "candidate_table_count": sum(
                    len(page.tables) for page in evidence.pages
                ),
            }
            return DocumentRecord.model_validate(baseline)
        return DocumentRecord.model_validate(candidate)

    async def parse_docling_document(
        self,
        path: str | Path,
        original_filename: str | None = None,
        *,
        kind: str,
    ):
        """Build the public generic record for PPTX/HTML through Docling."""

        if self.mode == "legacy" or self.docling is None:
            raise RuntimeError(f"Docling backend is required for {kind}")
        evidence = await self._run_backend(
            self.docling,
            path,
            pages=None,
            timeout=self.pp_timeout_seconds,
        )
        from ..adapters.common import (
            build_document_record,
            file_sha256,
            source_payload,
        )

        source_path = Path(path)
        mime_type = (
            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            if kind == "pptx"
            else "text/html"
        )
        subtype = "presentation" if kind == "pptx" else "web_document"
        return build_document_record(
            source=source_payload(
                source_path,
                original_filename=original_filename,
                mime_type=mime_type,
                sha256=file_sha256(source_path),
            ),
            document_type="technical_document",
            document_subtype=subtype,
            sections=_evidence_sections(evidence),
            raw_content={
                "text_original": evidence.text,
                "text_normalized": unicodedata.normalize("NFKC", evidence.text),
                "docling_pages": [
                    page.model_dump(mode="json", exclude={"raw"})
                    for page in evidence.pages
                ],
            },
            metadata={
                "adapter": "docling",
                "structured_parser": _evidence_summary(evidence),
                "structured_evidence": evidence.bounded_dump(),
            },
        )


def build_document_parser_service(settings: Any) -> DocumentParserService:
    """Build optional backends from application settings without importing them."""

    model_root = str(getattr(settings, "pp_structure_model_root", "") or "")
    runtime_downloads = bool(getattr(settings, "parser_runtime_downloads", False))
    device = str(getattr(settings, "pp_structure_device", "cpu") or "cpu")
    pp = (
        PPStructureV3Backend(
            device=device,
            model_root=model_root,
            runtime_downloads=runtime_downloads,
        )
        if bool(getattr(settings, "pp_structure_enabled", False))
        else None
    )
    vl = (
        PaddleOCRVLBackend(
            device=device,
            model_root=str(
                getattr(settings, "paddleocr_vl_model_root", "") or model_root
            ),
            runtime_downloads=runtime_downloads,
        )
        if bool(getattr(settings, "paddleocr_vl_enabled", False))
        else None
    )
    docling = (
        DoclingBackend() if bool(getattr(settings, "docling_enabled", False)) else None
    )
    return DocumentParserService(
        mode=str(getattr(settings, "document_parser_mode", "legacy")),
        pp_structure=pp,
        paddle_vl=vl,
        docling=docling,
        pp_timeout_seconds=float(
            getattr(settings, "pp_structure_timeout_seconds", 120.0)
        ),
        vl_timeout_seconds=float(
            getattr(settings, "paddleocr_vl_timeout_seconds", 180.0)
        ),
    )


__all__ = [
    "DocumentParserService",
    "apply_evidence_to_pdf_document",
    "build_document_parser_service",
]
