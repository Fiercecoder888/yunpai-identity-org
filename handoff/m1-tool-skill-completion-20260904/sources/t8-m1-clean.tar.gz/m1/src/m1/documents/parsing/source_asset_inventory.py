"""Read-only inventory of binary source assets embedded in documents.

The inventory deliberately stops before rendering, OCR or VLM inference.  It
records every bounded package asset by content hash, keeps every occurrence as
a source reference, and never writes an extracted payload to disk.
"""

from __future__ import annotations

import hashlib
import json
import mimetypes
import posixpath
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Literal
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile

import fitz
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..envelope import coordinate_from_row_col
from ..magic import sniff_file_type
from ..models import SourceReference
from ..ooxml import OOXMLPackageError, preflight_ooxml_package
from .docx_native_evidence import (
    DOCXNativeEvidenceError,
    parse_docx_native_evidence,
)

InventoryCoverage = Literal["complete", "partial", "unsupported"]
AssetCoverage = Literal["inventoried_referenced", "inventoried_unreferenced"]


class SourceAssetInventoryError(RuntimeError):
    """A supported source cannot be inventoried without losing provenance."""


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SourceAssetAnchor(_StrictModel):
    """Provider-neutral occurrence geometry without any extracted bytes."""

    kind: str = Field(min_length=1, max_length=80)
    bbox: list[float] | None = Field(default=None, min_length=4, max_length=4)
    coordinate_space: str | None = Field(default=None, max_length=40)
    from_cell: str | None = Field(default=None, max_length=40)
    to_cell: str | None = Field(default=None, max_length=40)
    from_column_offset: int | None = None
    from_row_offset: int | None = None
    to_column_offset: int | None = None
    to_row_offset: int | None = None
    position_x: int | None = None
    position_y: int | None = None
    extent_cx: int | None = None
    extent_cy: int | None = None


class SourceAssetReference(_StrictModel):
    """One document occurrence of a content-addressed asset."""

    source_ref: SourceReference
    relationship_id: str | None = Field(default=None, max_length=200)
    anchor: SourceAssetAnchor | None = None
    alt_text: list[str] = Field(default_factory=list, max_length=20)


class SourceAsset(_StrictModel):
    """Binary asset metadata; the payload itself is intentionally absent."""

    asset_id: str = Field(min_length=77, max_length=77)
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    mime_type: str = Field(min_length=1, max_length=200)
    byte_size: int = Field(ge=0)
    parts: list[str] = Field(min_length=1)
    source_refs: list[SourceAssetReference] = Field(default_factory=list)
    coverage_status: AssetCoverage

    @model_validator(mode="after")
    def validate_content_identity(self) -> SourceAsset:
        if self.asset_id != f"asset:sha256:{self.sha256}":
            raise ValueError("asset_id must be derived from sha256")
        if self.parts != sorted(set(self.parts)):
            raise ValueError("asset parts must be sorted and unique")
        return self


class SourceAssetRequirement(_StrictModel):
    """A visual operation required to cover non-raster source content."""

    requirement_id: str = Field(min_length=1, max_length=160)
    kind: Literal["pdf_page_render"] = "pdf_page_render"
    source_ref: SourceReference
    reason: str = Field(min_length=1, max_length=200)
    vector_drawing_count: int = Field(default=0, ge=0)
    coverage_status: Literal["required"] = "required"


class SourceAssetInventory(_StrictModel):
    """Stable source-level inventory, independent from business extraction."""

    schema_version: Literal["m1.source-asset-inventory.v1"] = (
        "m1.source-asset-inventory.v1"
    )
    source_kind: str = Field(min_length=1, max_length=40)
    source_name: str = Field(min_length=1, max_length=512)
    source_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    source_byte_size: int = Field(ge=0)
    assets: list[SourceAsset] = Field(default_factory=list)
    requirements: list[SourceAssetRequirement] = Field(default_factory=list)
    coverage_status: InventoryCoverage
    warnings: list[str] = Field(default_factory=list)

    @property
    def media_part_count(self) -> int:
        return sum(len(asset.parts) for asset in self.assets)

    @property
    def occurrence_count(self) -> int:
        return sum(len(asset.source_refs) for asset in self.assets)

    def summary(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "source_kind": self.source_kind,
            "source_sha256": self.source_sha256,
            "asset_count": len(self.assets),
            "media_part_count": self.media_part_count,
            "occurrence_count": self.occurrence_count,
            "requirement_count": len(self.requirements),
            "coverage_status": self.coverage_status,
            "warnings": list(self.warnings),
        }


@dataclass(slots=True)
class _AssetAccumulator:
    sha256: str
    byte_size: int
    mime_types: set[str] = field(default_factory=set)
    parts: set[str] = field(default_factory=set)
    source_refs: list[SourceAssetReference] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class _Relationship:
    relationship_id: str
    relationship_type: str
    source_part: str
    target_part: str | None
    external: bool


_COMMON_MIME_TYPES = {
    ".bmp": "image/bmp",
    ".emf": "image/emf",
    ".gif": "image/gif",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".jpx": "image/jp2",
    ".png": "image/png",
    ".svg": "image/svg+xml",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
    ".webp": "image/webp",
    ".wmf": "image/wmf",
}
_DISPIMG_RE = re.compile(r"DISPIMG\s*\(\s*[\"']([^\"']+)[\"']", re.IGNORECASE)


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _local_name(value: str) -> str:
    return value.rsplit("}", 1)[-1]


def _attribute(element: ET.Element | None, name: str) -> str | None:
    if element is None:
        return None
    return next(
        (value for key, value in element.attrib.items() if _local_name(key) == name),
        None,
    )


def _first_descendant(element: ET.Element, name: str) -> ET.Element | None:
    return next((item for item in element.iter() if _local_name(item.tag) == name), None)


def _xml(package: ZipFile, part: str, *, required: bool = True) -> ET.Element | None:
    try:
        payload = package.read(part)
    except KeyError:
        if not required:
            return None
        raise SourceAssetInventoryError(f"OOXML package is missing {part}") from None
    try:
        return ET.fromstring(payload)
    except ET.ParseError as exc:
        raise SourceAssetInventoryError(f"Malformed OOXML part {part}") from exc


def _relationship_part(part: str) -> str:
    directory, filename = posixpath.split(part)
    return posixpath.join(directory, "_rels", f"{filename}.rels")


def _source_part_for_relationship_part(part: str) -> str | None:
    directory, filename = posixpath.split(part)
    if posixpath.basename(directory) != "_rels" or not filename.endswith(".rels"):
        return None
    return posixpath.join(posixpath.dirname(directory), filename[: -len(".rels")])


def _safe_target(source_part: str, target: str) -> str:
    if (
        not target
        or "\x00" in target
        or "\\" in target
        or target.startswith("/")
    ):
        raise SourceAssetInventoryError(
            f"Unsafe OOXML relationship target: {target!r}"
        )
    resolved = posixpath.normpath(
        posixpath.join(posixpath.dirname(source_part), target)
    )
    parts = PurePosixPath(resolved).parts
    if resolved in {"", ".", ".."} or any(part == ".." for part in parts):
        raise SourceAssetInventoryError(
            f"OOXML relationship escapes the package: {target!r}"
        )
    return resolved


def _relationships(package: ZipFile, source_part: str) -> dict[str, _Relationship]:
    part = _relationship_part(source_part)
    root = _xml(package, part, required=False)
    if root is None:
        return {}
    result: dict[str, _Relationship] = {}
    for item in root:
        if _local_name(item.tag) != "Relationship":
            continue
        relationship_id = item.get("Id") or ""
        target = item.get("Target") or ""
        if not relationship_id or not target:
            continue
        if relationship_id in result:
            raise SourceAssetInventoryError(
                f"Duplicate OOXML relationship ID in {part}: {relationship_id}"
            )
        external = (item.get("TargetMode") or "").casefold() == "external"
        result[relationship_id] = _Relationship(
            relationship_id=relationship_id,
            relationship_type=item.get("Type") or "",
            source_part=source_part,
            target_part=None if external else _safe_target(source_part, target),
            external=external,
        )
    return result


def _all_relationships(package: ZipFile, prefix: str) -> list[_Relationship]:
    result: list[_Relationship] = []
    for part in sorted(package.namelist()):
        if not part.startswith(prefix) or "/_rels/" not in part or not part.endswith(".rels"):
            continue
        source_part = _source_part_for_relationship_part(part)
        if source_part is None:
            continue
        result.extend(_relationships(package, source_part).values())
    return result


def _content_types(package: ZipFile) -> tuple[dict[str, str], dict[str, str]]:
    root = _xml(package, "[Content_Types].xml")
    assert root is not None
    defaults: dict[str, str] = {}
    overrides: dict[str, str] = {}
    for item in root:
        kind = _local_name(item.tag)
        if kind == "Default":
            extension = (item.get("Extension") or "").casefold()
            content_type = item.get("ContentType") or ""
            if extension and content_type:
                defaults[extension] = content_type
        elif kind == "Override":
            part = (item.get("PartName") or "").lstrip("/")
            content_type = item.get("ContentType") or ""
            if part and content_type:
                overrides[part] = content_type
    return defaults, overrides


def _mime_for_part(
    part: str,
    defaults: dict[str, str],
    overrides: dict[str, str],
) -> str:
    if part in overrides:
        return overrides[part]
    suffix = PurePosixPath(part).suffix.casefold()
    extension = suffix.lstrip(".")
    if extension in defaults:
        return defaults[extension]
    return (
        _COMMON_MIME_TYPES.get(suffix)
        or mimetypes.guess_type(f"asset{suffix}")[0]
        or "application/octet-stream"
    )


def _reference_key(reference: SourceAssetReference) -> str:
    return json.dumps(
        reference.model_dump(mode="json", exclude_none=True),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _add_asset(
    accumulators: dict[str, _AssetAccumulator],
    *,
    payload: bytes,
    part: str,
    mime_type: str,
    source_refs: Iterable[SourceAssetReference] = (),
) -> str:
    digest = hashlib.sha256(payload).hexdigest()
    accumulator = accumulators.setdefault(
        digest,
        _AssetAccumulator(sha256=digest, byte_size=len(payload)),
    )
    if accumulator.byte_size != len(payload):
        raise SourceAssetInventoryError("SHA-256 collision with different byte sizes")
    accumulator.mime_types.add(mime_type or "application/octet-stream")
    accumulator.parts.add(part)
    accumulator.source_refs.extend(source_refs)
    return digest


def _finalize_assets(
    accumulators: dict[str, _AssetAccumulator],
    warnings: list[str],
) -> list[SourceAsset]:
    result: list[SourceAsset] = []
    for digest, accumulator in sorted(accumulators.items()):
        mime_types = sorted(accumulator.mime_types)
        if len(mime_types) > 1:
            warnings.append(
                f"asset_mime_conflict:{digest}:{','.join(mime_types)}"
            )
        references = {
            _reference_key(reference): reference
            for reference in accumulator.source_refs
        }
        ordered_references = [references[key] for key in sorted(references)]
        result.append(
            SourceAsset(
                asset_id=f"asset:sha256:{digest}",
                sha256=digest,
                mime_type=mime_types[0] if mime_types else "application/octet-stream",
                byte_size=accumulator.byte_size,
                parts=sorted(accumulator.parts),
                source_refs=ordered_references,
                coverage_status=(
                    "inventoried_referenced"
                    if ordered_references
                    else "inventoried_unreferenced"
                ),
            )
        )
    return result


def _base_inventory(
    source: Path,
    *,
    source_kind: str,
    assets: list[SourceAsset],
    requirements: list[SourceAssetRequirement] | None = None,
    coverage_status: InventoryCoverage = "complete",
    warnings: Iterable[str] = (),
) -> SourceAssetInventory:
    return SourceAssetInventory(
        source_kind=source_kind,
        source_name=source.name,
        source_sha256=_sha256_path(source),
        source_byte_size=source.stat().st_size,
        assets=assets,
        requirements=requirements or [],
        coverage_status=coverage_status,
        warnings=sorted(set(warnings)),
    )


def _pdf_inventory(source: Path) -> SourceAssetInventory:
    accumulators: dict[str, _AssetAccumulator] = {}
    warnings: list[str] = []
    requirements: list[SourceAssetRequirement] = []
    source_digest = _sha256_path(source)
    try:
        document = fitz.open(source)
    except Exception as exc:
        raise SourceAssetInventoryError("Invalid PDF source") from exc
    try:
        extracted: dict[int, tuple[bytes, str]] = {}
        for page_index, page in enumerate(document):
            page_number = page_index + 1
            drawing_count = len(page.get_drawings())
            if drawing_count:
                requirements.append(
                    SourceAssetRequirement(
                        requirement_id=(
                            "requirement:pdf-page-render:"
                            f"{source_digest}:p{page_number}"
                        ),
                        source_ref=SourceReference(
                            page=page_number,
                            part=f"pdf:page:{page_number}",
                        ),
                        reason="vector_drawings_present",
                        vector_drawing_count=drawing_count,
                    )
                )
            seen_xrefs: set[int] = set()
            for image in page.get_images(full=True):
                xref = int(image[0])
                if xref <= 0 or xref in seen_xrefs:
                    continue
                seen_xrefs.add(xref)
                if xref not in extracted:
                    try:
                        payload = document.extract_image(xref)
                    except Exception as exc:  # noqa: BLE001
                        warnings.append(
                            f"pdf_image_extract_failed:p{page_number}:xref{xref}:"
                            f"{exc.__class__.__name__}"
                        )
                        continue
                    data = payload.get("image")
                    if not isinstance(data, bytes):
                        warnings.append(
                            f"pdf_image_payload_missing:p{page_number}:xref{xref}"
                        )
                        continue
                    extension = str(payload.get("ext") or "").casefold()
                    mime_type = _COMMON_MIME_TYPES.get(
                        f".{extension}",
                        mimetypes.guess_type(f"asset.{extension}")[0]
                        or "application/octet-stream",
                    )
                    extracted[xref] = (data, mime_type)
                data, mime_type = extracted[xref]
                try:
                    rectangles = page.get_image_rects(xref)
                except Exception:  # noqa: BLE001 - page reference remains useful
                    rectangles = []
                if not rectangles:
                    rectangles = [None]
                references = []
                for rectangle in rectangles:
                    bbox = (
                        [
                            round(float(rectangle.x0), 4),
                            round(float(rectangle.y0), 4),
                            round(float(rectangle.x1), 4),
                            round(float(rectangle.y1), 4),
                        ]
                        if rectangle is not None
                        else None
                    )
                    references.append(
                        SourceAssetReference(
                            source_ref=SourceReference(
                                page=page_number,
                                part=f"pdf:xref:{xref}",
                            ),
                            anchor=SourceAssetAnchor(
                                kind="pdf_image",
                                bbox=bbox,
                                coordinate_space="pdf_points" if bbox else None,
                            ),
                        )
                    )
                _add_asset(
                    accumulators,
                    payload=data,
                    part=f"pdf:xref:{xref}",
                    mime_type=mime_type,
                    source_refs=references,
                )
    finally:
        document.close()
    assets = _finalize_assets(accumulators, warnings)
    status: InventoryCoverage = (
        "partial"
        if any(item.startswith("pdf_image_") for item in warnings)
        else "complete"
    )
    return _base_inventory(
        source,
        source_kind="pdf",
        assets=assets,
        requirements=sorted(
            requirements,
            key=lambda item: item.requirement_id,
        ),
        coverage_status=status,
        warnings=warnings,
    )


def _docx_inventory(source: Path) -> SourceAssetInventory:
    try:
        preflight_ooxml_package(source, expected_kind="document")
        native = parse_docx_native_evidence(source)
    except (OOXMLPackageError, DOCXNativeEvidenceError) as exc:
        raise SourceAssetInventoryError(str(exc)) from exc
    accumulators: dict[str, _AssetAccumulator] = {}
    warnings = list(native.warnings)
    try:
        package = ZipFile(source, "r")
    except BadZipFile as exc:
        raise SourceAssetInventoryError("Invalid DOCX ZIP package") from exc
    try:
        names = set(package.namelist())
        defaults, overrides = _content_types(package)
        for part in sorted(
            name
            for name in names
            if name.startswith("word/media/") and not name.endswith("/")
        ):
            _add_asset(
                accumulators,
                payload=package.read(part),
                part=part,
                mime_type=_mime_for_part(part, defaults, overrides),
            )

        precise_relationships: set[tuple[str, str]] = set()
        for image in native.raw.get("images") or []:
            if not isinstance(image, dict):
                continue
            part = str(image.get("target_part") or "")
            relationship_id = str(image.get("relationship_id") or "")
            if not part or part not in names:
                continue
            references: list[SourceAssetReference] = []
            for reference in image.get("references") or []:
                if not isinstance(reference, dict):
                    continue
                source_id = str(reference.get("source_id") or "word/document.xml")
                alt_text = [
                    str(item)
                    for item in reference.get("image_alt_text") or []
                    if str(item).strip()
                ]
                references.append(
                    SourceAssetReference(
                        source_ref=SourceReference(part=source_id),
                        relationship_id=relationship_id or None,
                        anchor=SourceAssetAnchor(kind="docx_relationship"),
                        alt_text=list(dict.fromkeys(alt_text)),
                    )
                )
            if references:
                precise_relationships.add(("word/document.xml", relationship_id))
            _add_asset(
                accumulators,
                payload=package.read(part),
                part=part,
                mime_type=str(image.get("content_type") or "")
                or _mime_for_part(part, defaults, overrides),
                source_refs=references,
            )

        for relation in _all_relationships(package, "word/"):
            if not relation.relationship_type.endswith("/image"):
                continue
            if relation.external:
                warnings.append(
                    f"external_image_relationship:{relation.source_part}:"
                    f"{relation.relationship_id}"
                )
                continue
            part = relation.target_part
            if not part or part not in names:
                warnings.append(
                    f"missing_image_part:{relation.source_part}:"
                    f"{relation.relationship_id}"
                )
                continue
            if (relation.source_part, relation.relationship_id) in precise_relationships:
                continue
            _add_asset(
                accumulators,
                payload=package.read(part),
                part=part,
                mime_type=_mime_for_part(part, defaults, overrides),
                source_refs=[
                    SourceAssetReference(
                        source_ref=SourceReference(part=relation.source_part),
                        relationship_id=relation.relationship_id,
                        anchor=SourceAssetAnchor(kind="docx_relationship"),
                    )
                ],
            )
    finally:
        package.close()
    assets = _finalize_assets(accumulators, warnings)
    status: InventoryCoverage = (
        "partial"
        if any(
            item.startswith(("missing_image_part:", "external_image_relationship:"))
            for item in warnings
        )
        else "complete"
    )
    return _base_inventory(
        source,
        source_kind="docx",
        assets=assets,
        coverage_status=status,
        warnings=warnings,
    )


def _marker(anchor: ET.Element, name: str) -> tuple[str | None, int, int]:
    node = next(
        (child for child in anchor if _local_name(child.tag) == name),
        None,
    )
    if node is None:
        return None, 0, 0
    values = {
        _local_name(child.tag): int(child.text or "0")
        for child in node
        if _local_name(child.tag) in {"col", "colOff", "row", "rowOff"}
    }
    cell = coordinate_from_row_col(values.get("row", 0) + 1, values.get("col", 0) + 1)
    return cell, values.get("colOff", 0), values.get("rowOff", 0)


def _anchor_extent(anchor: ET.Element, name: str) -> tuple[int | None, int | None]:
    node = next(
        (child for child in anchor if _local_name(child.tag) == name),
        None,
    )
    if node is None:
        return None, None
    x = _attribute(node, "x" if name == "pos" else "cx")
    y = _attribute(node, "y" if name == "pos" else "cy")
    return (
        int(x) if x is not None else None,
        int(y) if y is not None else None,
    )


def _xlsx_anchor(anchor: ET.Element) -> tuple[SourceAssetAnchor, str | None, str | None]:
    kind = _local_name(anchor.tag)
    if kind in {"oneCellAnchor", "twoCellAnchor"}:
        from_cell, from_col_off, from_row_off = _marker(anchor, "from")
        to_cell, to_col_off, to_row_off = _marker(anchor, "to")
        extent_cx, extent_cy = _anchor_extent(anchor, "ext")
        return (
            SourceAssetAnchor(
                kind=f"xlsx_{kind}",
                from_cell=from_cell,
                to_cell=to_cell,
                from_column_offset=from_col_off,
                from_row_offset=from_row_off,
                to_column_offset=to_col_off if to_cell else None,
                to_row_offset=to_row_off if to_cell else None,
                extent_cx=extent_cx,
                extent_cy=extent_cy,
            ),
            from_cell,
            to_cell,
        )
    position_x, position_y = _anchor_extent(anchor, "pos")
    extent_cx, extent_cy = _anchor_extent(anchor, "ext")
    return (
        SourceAssetAnchor(
            kind="xlsx_absoluteAnchor",
            position_x=position_x,
            position_y=position_y,
            extent_cx=extent_cx,
            extent_cy=extent_cy,
        ),
        None,
        None,
    )


def _sheet_records(package: ZipFile) -> list[tuple[str, str]]:
    workbook = _xml(package, "xl/workbook.xml")
    assert workbook is not None
    relationships = _relationships(package, "xl/workbook.xml")
    records: list[tuple[str, str]] = []
    for sheet in workbook.iter():
        if _local_name(sheet.tag) != "sheet":
            continue
        name = sheet.get("name") or f"Sheet{len(records) + 1}"
        relationship_id = _attribute(sheet, "id")
        relation = relationships.get(relationship_id or "")
        if relation is not None and relation.target_part:
            records.append((name, relation.target_part))
    return records


def _xlsx_drawing_references(
    package: ZipFile,
    *,
    names: set[str],
    defaults: dict[str, str],
    overrides: dict[str, str],
    accumulators: dict[str, _AssetAccumulator],
    warnings: list[str],
) -> set[tuple[str, str]]:
    precise_relationships: set[tuple[str, str]] = set()
    for sheet_name, sheet_part in _sheet_records(package):
        if sheet_part not in names:
            warnings.append(f"missing_worksheet_part:{sheet_name}:{sheet_part}")
            continue
        sheet_root = _xml(package, sheet_part)
        assert sheet_root is not None
        sheet_relationships = _relationships(package, sheet_part)
        for drawing in sheet_root.iter():
            if _local_name(drawing.tag) != "drawing":
                continue
            drawing_relationship_id = _attribute(drawing, "id") or ""
            drawing_relation = sheet_relationships.get(drawing_relationship_id)
            drawing_part = drawing_relation.target_part if drawing_relation else None
            if not drawing_part or drawing_part not in names:
                warnings.append(
                    f"missing_drawing_part:{sheet_name}:{drawing_relationship_id}"
                )
                continue
            drawing_root = _xml(package, drawing_part)
            assert drawing_root is not None
            drawing_relationships = _relationships(package, drawing_part)
            for anchor_element in drawing_root:
                if _local_name(anchor_element.tag) not in {
                    "oneCellAnchor",
                    "twoCellAnchor",
                    "absoluteAnchor",
                }:
                    continue
                anchor, from_cell, to_cell = _xlsx_anchor(anchor_element)
                properties = _first_descendant(anchor_element, "cNvPr")
                alt_text = list(
                    dict.fromkeys(
                        value
                        for value in (
                            _attribute(properties, "name"),
                            _attribute(properties, "descr"),
                            _attribute(properties, "title"),
                        )
                        if value
                    )
                )
                for blip in (
                    item
                    for item in anchor_element.iter()
                    if _local_name(item.tag) == "blip"
                ):
                    relationship_id = _attribute(blip, "embed") or ""
                    relation = drawing_relationships.get(relationship_id)
                    part = relation.target_part if relation else None
                    if not part or part not in names:
                        warnings.append(
                            f"missing_image_part:{drawing_part}:{relationship_id}"
                        )
                        continue
                    cell_range = (
                        f"{from_cell}:{to_cell}"
                        if from_cell and to_cell and from_cell != to_cell
                        else from_cell
                    )
                    precise_relationships.add((drawing_part, relationship_id))
                    _add_asset(
                        accumulators,
                        payload=package.read(part),
                        part=part,
                        mime_type=_mime_for_part(part, defaults, overrides),
                        source_refs=[
                            SourceAssetReference(
                                source_ref=SourceReference(
                                    sheet=sheet_name,
                                    cell=from_cell,
                                    range=cell_range,
                                    part=drawing_part,
                                ),
                                relationship_id=relationship_id,
                                anchor=anchor,
                                alt_text=alt_text,
                            )
                        ],
                    )
    return precise_relationships


def _xlsx_wps_cell_references(
    package: ZipFile,
    *,
    names: set[str],
    defaults: dict[str, str],
    overrides: dict[str, str],
    accumulators: dict[str, _AssetAccumulator],
    warnings: list[str],
) -> None:
    """Bind WPS cell-image package relationships back to business cells."""

    part = "xl/cellimages.xml"
    if part not in names:
        return
    root = _xml(package, part)
    assert root is not None
    relationships = _relationships(package, part)
    bindings: dict[str, list[tuple[str, str, list[str]]]] = {}
    for picture in (item for item in root.iter() if _local_name(item.tag) == "pic"):
        blip = _first_descendant(picture, "blip")
        relationship_id = _attribute(blip, "embed") or ""
        relation = relationships.get(relationship_id)
        target = relation.target_part if relation else None
        if not target or target not in names:
            warnings.append(f"missing_wps_cell_image_part:{relationship_id}")
            continue
        properties = _first_descendant(picture, "cNvPr")
        identifiers = {
            value.casefold()
            for item in picture.iter()
            for key, value in item.attrib.items()
            if _local_name(key) in {"id", "name", "descr", "title", "uniqueId"}
            and value.strip()
        }
        alt_text = list(
            dict.fromkeys(
                value
                for value in (
                    _attribute(properties, "name"),
                    _attribute(properties, "descr"),
                    _attribute(properties, "title"),
                )
                if value
            )
        )
        for identifier in identifiers:
            bindings.setdefault(identifier, []).append(
                (relationship_id, target, alt_text)
            )

    for sheet_name, sheet_part in _sheet_records(package):
        if sheet_name.casefold().startswith("wpsreserved_") or sheet_part not in names:
            continue
        with package.open(sheet_part) as stream:
            for _event, cell in ET.iterparse(stream, events=("end",)):
                local_name = _local_name(cell.tag)
                if local_name == "row":
                    cell.clear()
                    continue
                if local_name != "c":
                    continue
                coordinate = cell.get("r") or ""
                payload = " ".join(
                    item.text or ""
                    for item in cell.iter()
                    if _local_name(item.tag) in {"f", "v", "t"}
                )
                for identifier in dict.fromkeys(_DISPIMG_RE.findall(payload)):
                    candidates = bindings.get(identifier.casefold(), [])
                    if len(candidates) != 1:
                        warnings.append(
                            f"wps_cell_image_identifier_ambiguous:{sheet_name}:"
                            f"{coordinate}:{identifier}:{len(candidates)}"
                        )
                        continue
                    relationship_id, target, alt_text = candidates[0]
                    _add_asset(
                        accumulators,
                        payload=package.read(target),
                        part=target,
                        mime_type=_mime_for_part(target, defaults, overrides),
                        source_refs=[
                            SourceAssetReference(
                                source_ref=SourceReference(
                                    sheet=sheet_name,
                                    cell=coordinate or None,
                                    range=coordinate or None,
                                    part=sheet_part,
                                ),
                                relationship_id=relationship_id,
                                anchor=SourceAssetAnchor(
                                    kind="wps_cell_image",
                                    from_cell=coordinate or None,
                                    to_cell=coordinate or None,
                                ),
                                alt_text=alt_text,
                            )
                        ],
                    )
                cell.clear()


def _xlsx_inventory(source: Path, *, source_kind: str) -> SourceAssetInventory:
    try:
        preflight_ooxml_package(source, expected_kind="spreadsheet")
        package = ZipFile(source, "r")
    except (OOXMLPackageError, BadZipFile) as exc:
        raise SourceAssetInventoryError(str(exc)) from exc
    accumulators: dict[str, _AssetAccumulator] = {}
    warnings: list[str] = []
    try:
        names = set(package.namelist())
        defaults, overrides = _content_types(package)
        for part in sorted(
            name
            for name in names
            if name.startswith("xl/media/") and not name.endswith("/")
        ):
            _add_asset(
                accumulators,
                payload=package.read(part),
                part=part,
                mime_type=_mime_for_part(part, defaults, overrides),
            )
        precise_relationships = _xlsx_drawing_references(
            package,
            names=names,
            defaults=defaults,
            overrides=overrides,
            accumulators=accumulators,
            warnings=warnings,
        )
        _xlsx_wps_cell_references(
            package,
            names=names,
            defaults=defaults,
            overrides=overrides,
            accumulators=accumulators,
            warnings=warnings,
        )
        for relation in _all_relationships(package, "xl/"):
            if not relation.relationship_type.endswith("/image"):
                continue
            if relation.external:
                warnings.append(
                    f"external_image_relationship:{relation.source_part}:"
                    f"{relation.relationship_id}"
                )
                continue
            part = relation.target_part
            if not part or part not in names:
                warnings.append(
                    f"missing_image_part:{relation.source_part}:"
                    f"{relation.relationship_id}"
                )
                continue
            if (relation.source_part, relation.relationship_id) in precise_relationships:
                continue
            _add_asset(
                accumulators,
                payload=package.read(part),
                part=part,
                mime_type=_mime_for_part(part, defaults, overrides),
                source_refs=[
                    SourceAssetReference(
                        source_ref=SourceReference(part=relation.source_part),
                        relationship_id=relation.relationship_id,
                        anchor=SourceAssetAnchor(kind="ooxml_relationship"),
                    )
                ],
            )
    finally:
        package.close()
    assets = _finalize_assets(accumulators, warnings)
    status: InventoryCoverage = (
        "partial"
        if any(
            item.startswith(
                (
                    "missing_worksheet_part:",
                    "missing_drawing_part:",
                    "missing_image_part:",
                    "missing_wps_cell_image_part:",
                    "wps_cell_image_identifier_ambiguous:",
                    "external_image_relationship:",
                )
            )
            for item in warnings
        )
        else "complete"
    )
    return _base_inventory(
        source,
        source_kind=source_kind,
        assets=assets,
        coverage_status=status,
        warnings=warnings,
    )


def inventory_source_assets(path: str | Path) -> SourceAssetInventory:
    """Inventory supported embedded assets without network or filesystem writes."""

    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    detected = sniff_file_type(source)
    if detected.kind == "pdf":
        return _pdf_inventory(source)
    if detected.kind == "docx":
        return _docx_inventory(source)
    if detected.kind in {"xlsx", "xlsm"}:
        return _xlsx_inventory(source, source_kind=detected.kind)
    if detected.kind == "xls":
        return _base_inventory(
            source,
            source_kind="xls",
            assets=[],
            coverage_status="unsupported",
            warnings=["binary_xls_asset_inventory_unsupported"],
        )
    return _base_inventory(
        source,
        source_kind=detected.kind,
        assets=[],
        coverage_status="unsupported",
        warnings=[f"source_asset_inventory_unsupported:{detected.kind}"],
    )


__all__ = [
    "SourceAsset",
    "SourceAssetAnchor",
    "SourceAssetInventory",
    "SourceAssetInventoryError",
    "SourceAssetReference",
    "SourceAssetRequirement",
    "inventory_source_assets",
]
