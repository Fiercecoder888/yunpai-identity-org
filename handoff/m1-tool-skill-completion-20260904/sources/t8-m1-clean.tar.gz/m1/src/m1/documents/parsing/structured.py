"""Paddle PP-StructureV3 and PaddleOCR-VL evidence backends.

Imports and model construction are deliberately lazy.  The default production
configuration cannot download weights at runtime: a completed cache manifest is
required before either backend reports ready.
"""

from __future__ import annotations

import gc
import hashlib
import importlib.util
import json
import os
import threading
import time
from collections.abc import Callable, Iterable, Sequence
from functools import lru_cache
from html.parser import HTMLParser
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, ClassVar

from .base import PageInput, ParserBackendError, ParserBackendUnavailable
from .evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
    bbox_from_value,
)


def _plain(value: Any, *, depth: int = 0) -> Any:
    """Convert provider/NumPy objects to bounded JSON-compatible values."""

    if depth > 8:
        return "<max-depth>"
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _plain(item, depth=depth + 1) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item, depth=depth + 1) for item in value]
    tolist = getattr(value, "tolist", None)
    if callable(tolist):
        return _plain(tolist(), depth=depth + 1)
    if hasattr(value, "model_dump"):
        return _plain(value.model_dump(mode="json"), depth=depth + 1)
    return str(value)


def _result_payload(result: Any) -> dict[str, Any]:
    value = getattr(result, "json", result)
    if callable(value):
        value = value()
    value = _plain(value)
    if not isinstance(value, dict):
        return {}
    nested = value.get("res")
    return nested if isinstance(nested, dict) else value


class _TableHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.rows: list[list[str | None]] = []
        self._row: list[str | None] | None = None
        self._cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.casefold() == "tr":
            self._row = []
        elif tag.casefold() in {"td", "th"} and self._row is not None:
            self._cell = []

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            self._cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        folded = tag.casefold()
        if folded in {"td", "th"} and self._row is not None and self._cell is not None:
            text = " ".join("".join(self._cell).split())
            self._row.append(text or None)
            self._cell = None
        elif folded == "tr" and self._row is not None:
            self.rows.append(self._row)
            self._row = None


def _html_rows(value: Any) -> list[list[str | None]]:
    if not isinstance(value, str) or "<" not in value:
        return []
    parser = _TableHTMLParser()
    try:
        parser.feed(value)
    except Exception:  # noqa: BLE001 - malformed provider HTML has no table rows
        return []
    return parser.rows


def _score(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return max(0.0, min(1.0, number))


def _union_bbox(boxes: Iterable[EvidenceBBox | None]) -> EvidenceBBox | None:
    present = [box for box in boxes if box is not None]
    if not present:
        return None
    return EvidenceBBox(
        x0=min(box.x0 for box in present),
        y0=min(box.y0 for box in present),
        x1=max(box.x1 for box in present),
        y1=max(box.y1 for box in present),
        coordinate_space=present[0].coordinate_space,
    )


def _image_size(path: Path) -> tuple[float, float]:
    try:
        from PIL import Image

        with Image.open(path) as image:
            return float(image.width), float(image.height)
    except (OSError, ValueError):
        return 1.0, 1.0


def _image_nonempty(path: Path) -> bool:
    """Distinguish a blank rendered page from missed recognition."""

    try:
        from PIL import Image, ImageStat

        with Image.open(path) as image:
            grayscale = image.convert("L")
            extrema = grayscale.getextrema()
            deviation = float(ImageStat.Stat(grayscale).stddev[0])
        return bool(extrema[0] < 245 or deviation > 2.0)
    except (OSError, ValueError):
        # Direct PDF input and unsupported images are assumed non-empty so a
        # missed recognition result can still escalate to the VLM.
        return True


def _blocks(payload: dict[str, Any], *, source: str) -> list[EvidenceBlock]:
    result: list[EvidenceBlock] = []
    parsing = payload.get("parsing_res_list")
    if isinstance(parsing, list):
        for index, item in enumerate(parsing):
            if not isinstance(item, dict):
                continue
            text = str(
                item.get("block_content")
                or item.get("content")
                or item.get("text")
                or ""
            )
            result.append(
                EvidenceBlock(
                    block_id=str(item.get("block_id") or f"block-{index}"),
                    kind=str(item.get("block_label") or item.get("label") or "text"),
                    text=text,
                    bbox=bbox_from_value(
                        item.get("block_bbox") or item.get("bbox") or item.get("coordinate")
                    ),
                    confidence=_score(item.get("block_score") or item.get("score")),
                    order=int(item.get("block_order") or item.get("order") or index),
                    source=source,
                )
            )
    if result:
        return sorted(result, key=lambda block: block.order)

    ocr = payload.get("overall_ocr_res")
    if isinstance(ocr, dict):
        texts = _plain(ocr.get("rec_texts") or [])
        scores = _plain(ocr.get("rec_scores") or [])
        boxes = _plain(ocr.get("rec_boxes") or ocr.get("rec_polys") or [])
        if isinstance(texts, list):
            for index, text in enumerate(texts):
                result.append(
                    EvidenceBlock(
                        block_id=f"ocr-{index}",
                        text=str(text or ""),
                        bbox=bbox_from_value(boxes[index] if isinstance(boxes, list) and index < len(boxes) else None),
                        confidence=_score(scores[index] if isinstance(scores, list) and index < len(scores) else None),
                        order=index,
                        source=source,
                    )
                )
    if result:
        return result

    layout = payload.get("layout_det_res")
    candidates = layout.get("boxes") if isinstance(layout, dict) else None
    if isinstance(candidates, list):
        for index, item in enumerate(candidates):
            if not isinstance(item, dict):
                continue
            result.append(
                EvidenceBlock(
                    block_id=f"layout-{index}",
                    kind=str(item.get("label") or "unknown"),
                    bbox=bbox_from_value(item.get("coordinate") or item.get("bbox")),
                    confidence=_score(item.get("score")),
                    order=index,
                    source=source,
                )
            )
    return result


def _tables(payload: dict[str, Any], *, source: str) -> list[EvidenceTable]:
    candidates = payload.get("table_res_list")
    if not isinstance(candidates, list):
        candidates = []
    result: list[EvidenceTable] = []
    for table_index, item in enumerate(candidates):
        if not isinstance(item, dict):
            continue
        rows = item.get("rows") or item.get("rows_normalized")
        if not isinstance(rows, list):
            rows = _html_rows(item.get("pred_html") or item.get("html"))
        normalized_rows = [
            [None if cell is None else str(cell) for cell in row]
            for row in rows
            if isinstance(row, (list, tuple))
        ]
        boxes = _plain(item.get("cell_box_list") or item.get("cell_bboxes") or [])
        ocr = item.get("table_ocr_pred")
        scores = _plain(ocr.get("rec_scores") or []) if isinstance(ocr, dict) else []
        cells: list[EvidenceCell] = []
        flat_index = 0
        for row_index, row in enumerate(normalized_rows):
            for column_index, text in enumerate(row):
                cells.append(
                    EvidenceCell(
                        row=row_index,
                        column=column_index,
                        text=text,
                        bbox=bbox_from_value(
                            boxes[flat_index]
                            if isinstance(boxes, list) and flat_index < len(boxes)
                            else None
                        ),
                        confidence=_score(
                            scores[flat_index]
                            if isinstance(scores, list) and flat_index < len(scores)
                            else None
                        ),
                    )
                )
                flat_index += 1
        result.append(
            EvidenceTable(
                table_id=str(item.get("table_id") or f"table-{table_index}"),
                rows=normalized_rows,
                cells=cells,
                bbox=bbox_from_value(item.get("bbox")) or _union_bbox(cell.bbox for cell in cells),
                confidence=_score(item.get("score")),
                source=source,
            )
        )
    return result


def _markdown(result: Any, payload: dict[str, Any]) -> str:
    value = getattr(result, "markdown", None)
    if callable(value):
        value = value()
    value = _plain(value)
    if isinstance(value, dict):
        texts = value.get("markdown_texts") or value.get("text")
        if isinstance(texts, list):
            return "\n".join(str(item) for item in texts)
        if texts is not None:
            return str(texts)
    if isinstance(value, str):
        return value
    return str(payload.get("text") or payload.get("markdown") or "")


def _package_version() -> str:
    try:
        return version("paddleocr")
    except PackageNotFoundError:
        return "unknown"


def _device_available(device: str) -> tuple[bool, str | None]:
    """Validate an explicitly requested accelerator before readiness passes."""

    normalized = device.strip().casefold()
    if not normalized.startswith(("gpu", "cuda")):
        return True, None
    try:
        import paddle
    except ImportError:
        return False, "paddle_not_installed"
    if not paddle.is_compiled_with_cuda():
        return False, "paddle_cuda_runtime_unavailable"
    try:
        count = int(paddle.device.cuda.device_count())
    except Exception:  # noqa: BLE001 - readiness must remain side-effect free
        return False, "paddle_cuda_probe_failed"
    if count < 1:
        return False, "paddle_cuda_device_missing"
    return True, None


PARSER_MODEL_REQUIREMENTS: dict[str, frozenset[str]] = {
    "pp-structure-v3": frozenset(
        {
            "PP-LCNet_x1_0_doc_ori",
            "PP-LCNet_x1_0_textline_ori",
            "PP-DocBlockLayout",
            "PP-DocLayout_plus-L",
            "PP-OCRv5_server_det",
            "PP-OCRv5_server_rec",
            "PP-OCRv4_server_seal_det",
            "PP-LCNet_x1_0_table_cls",
            "SLANeXt_wired",
            "SLANet_plus",
            "RT-DETR-L_wired_table_cell_det",
            "RT-DETR-L_wireless_table_cell_det",
        }
    ),
    "paddleocr-vl-1.6": frozenset(
        {
            "PP-LCNet_x1_0_doc_ori",
            "PP-DocLayoutV3",
            # PaddleOCR's public model id is PaddleOCR-VL-1.6-0.9B, while
            # PaddleX 3.7.2 stores the verified snapshot under this directory.
            "PaddleOCR-VL-1.6",
        }
    ),
}


def _manifest_model_name(relative: Path) -> str:
    parts = relative.parts
    try:
        index = parts.index("official_models")
    except ValueError:
        return ""
    return parts[index + 1] if len(parts) > index + 1 else ""


@lru_cache(maxsize=16)
def _verified_cache_manifest(
    root_value: str,
    pipeline_name: str,
    manifest_mtime_ns: int,
    manifest_size: int,
) -> tuple[bool, dict[str, str], str | None]:
    # mtime/size are part of the cache key so replacing the signed inventory
    # forces a complete checksum pass.  Model files are immutable during one
    # process lifetime; readiness therefore does not hash GiBs every 15s.
    del manifest_mtime_ns, manifest_size
    root = Path(root_value)
    manifest_path = root / "document-parser-models.json"
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False, {}, "model_manifest_invalid"
    models = payload.get("models") if isinstance(payload, dict) else None
    pipelines = payload.get("pipelines") if isinstance(payload, dict) else None
    pipeline = pipelines.get(pipeline_name) if isinstance(pipelines, dict) else None
    if (
        not payload.get("complete")
        or not isinstance(models, list)
        or not models
        or not isinstance(pipeline, dict)
        or not pipeline.get("complete")
    ):
        return False, {}, "model_manifest_incomplete"
    expected = PARSER_MODEL_REQUIREMENTS.get(pipeline_name, frozenset())
    declared = {
        str(item)
        for item in (pipeline.get("models") or [])
        if str(item).strip()
    }
    missing = sorted(expected - declared)
    if missing:
        return False, {}, f"pipeline_models_missing:{missing[0]}"
    model_digests: dict[str, list[str]] = {name: [] for name in expected}
    for item in models:
        if not isinstance(item, dict):
            return False, {}, "model_manifest_invalid"
        name = str(item.get("name") or "")
        digest = str(item.get("sha256") or "")
        relative = str(item.get("path") or "")
        target = (root / relative).resolve()
        try:
            target.relative_to(root.resolve())
        except ValueError:
            return False, {}, f"model_path_escape:{name or relative}"
        model_name = _manifest_model_name(Path(relative))
        if model_name not in expected:
            continue
        if not name or len(digest) != 64 or not target.is_file():
            return False, {}, f"model_missing:{name or relative}"
        checksum = hashlib.sha256()
        with target.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                checksum.update(chunk)
        actual = checksum.hexdigest()
        if actual != digest:
            return False, {}, f"model_checksum_mismatch:{name}"
        model_digests[model_name].append(actual)
    for model_name, digests in model_digests.items():
        if not digests:
            return False, {}, f"model_artifacts_missing:{model_name}"
    fingerprints = {
        model_name: hashlib.sha256("".join(sorted(digests)).encode()).hexdigest()
        for model_name, digests in sorted(model_digests.items())
    }
    return True, fingerprints, None


def _cache_manifest(
    root: Path, pipeline_name: str
) -> tuple[bool, dict[str, str], str | None]:
    manifest_path = root / "document-parser-models.json"
    if not manifest_path.is_file():
        return False, {}, "model_manifest_missing"
    try:
        stat = manifest_path.stat()
    except OSError:
        return False, {}, "model_manifest_invalid"
    return _verified_cache_manifest(
        str(root.resolve()), pipeline_name, stat.st_mtime_ns, stat.st_size
    )


class _PaddleBackend:
    name = "paddle"
    _instances: ClassVar[dict[tuple[Any, ...], Any]] = {}
    _instances_lock = threading.Lock()
    _gpu_cleanup_failed_slots: ClassVar[set[str]] = set()
    # PP-Structure and PaddleOCR-VL share one GPU budget.  The lock is process
    # global (not service-instance local), which makes inference concurrency
    # exactly one even when tests or dependency injection build two services.
    _predict_lock = threading.Lock()

    def __init__(
        self,
        *,
        device: str = "cpu",
        model_root: str | Path = "",
        runtime_downloads: bool = False,
        model_factory: Callable[[], Any] | None = None,
    ) -> None:
        self.device = device
        self.model_root = Path(model_root).expanduser() if str(model_root).strip() else None
        self.runtime_downloads = runtime_downloads
        self._model_factory = model_factory
        self._fingerprints: dict[str, str] = {}

    def _key(self) -> tuple[Any, ...]:
        return (self.name, self.device, str(self.model_root or ""))

    @staticmethod
    def _gpu_slots(device: str) -> frozenset[str] | None:
        normalized = str(device or "").strip().casefold()
        if normalized in {"gpu", "cuda"}:
            return frozenset({"0"})
        for prefix in ("gpu:", "cuda:"):
            if normalized.startswith(prefix):
                value = normalized.removeprefix(prefix).strip()
                if not value:
                    return frozenset({"0"})
                slots = []
                for item in value.split(","):
                    item = item.strip()
                    slots.append(str(int(item)) if item.isdigit() else item)
                return frozenset(slots)
        return None

    @staticmethod
    def _release_cached_models(models: list[Any]) -> None:
        cleanup_errors: list[Exception] = []
        while models:
            model = models.pop()
            close = getattr(model, "close", None)
            if callable(close):
                try:
                    close()
                except Exception as exc:  # noqa: BLE001 - finish all teardown
                    cleanup_errors.append(exc)
            del close
            del model
        gc.collect()
        try:
            import paddle
        except ImportError:
            paddle = None

        if paddle is not None:
            try:
                if paddle.is_compiled_with_cuda():
                    paddle.device.cuda.empty_cache()
            except Exception as exc:  # noqa: BLE001 - fail before replacement
                cleanup_errors.append(exc)
        if cleanup_errors:
            raise ParserBackendError("Paddle GPU model cleanup failed") from cleanup_errors[0]

    def _ensure_cache(self) -> None:
        if self.runtime_downloads:
            if self.model_root is not None:
                self.model_root.mkdir(parents=True, exist_ok=True)
            return
        if self.model_root is None or not self.model_root.is_dir():
            raise ParserBackendUnavailable(
                f"{self.name} requires an existing offline model root"
            )
        ready, fingerprints, error = _cache_manifest(self.model_root, self.name)
        if not ready:
            raise ParserBackendUnavailable(f"{self.name} offline cache is not ready: {error}")
        self._fingerprints = fingerprints

    def _model(self) -> Any:
        if self._model_factory is not None:
            return self._model_factory()
        self._ensure_cache()
        key = self._key()
        with self._instances_lock:
            model = self._instances.get(key)
            if model is None:
                gpu_slots = self._gpu_slots(self.device)
                if (
                    gpu_slots is not None
                    and not gpu_slots.isdisjoint(self._gpu_cleanup_failed_slots)
                ):
                    raise ParserBackendError(
                        "Paddle GPU model cleanup failed; process restart required"
                    )
                stale_models: list[Any] = []
                stale_gpu_slots: set[str] = set()
                if gpu_slots is not None:
                    for cached_key in list(self._instances):
                        cached_slots = self._gpu_slots(str(cached_key[1]))
                        if (
                            cached_key != key
                            and cached_slots is not None
                            and not gpu_slots.isdisjoint(cached_slots)
                        ):
                            stale_models.append(self._instances.pop(cached_key))
                            stale_gpu_slots.update(cached_slots)
                if stale_models:
                    try:
                        self._release_cached_models(stale_models)
                    except ParserBackendError:
                        self._gpu_cleanup_failed_slots.update(stale_gpu_slots)
                        raise
                if self.model_root is not None:
                    # PaddleX 3.x resolves its official model cache from
                    # PADDLE_PDX_CACHE_HOME.  Keep PADDLEX_HOME as a
                    # compatibility alias for older releases, but never rely
                    # on it alone or the model can silently download into the
                    # user's global ~/.paddlex directory while readiness
                    # verifies a different root.
                    os.environ["PADDLE_PDX_CACHE_HOME"] = str(self.model_root)
                    os.environ["PADDLEX_HOME"] = str(self.model_root)
                model = self._create_model()
                self._instances[key] = model
            return model

    def _create_model(self) -> Any:  # pragma: no cover - implemented by subclasses
        raise NotImplementedError

    def readiness(self) -> dict[str, object]:
        installed = importlib.util.find_spec("paddleocr") is not None
        device_ready, device_error = _device_available(self.device)
        result: dict[str, object] = {
            "backend": self.name,
            "installed": installed,
            "device": self.device,
            "device_available": device_ready,
            "runtime_downloads": self.runtime_downloads,
            "model_root": str(self.model_root) if self.model_root else None,
        }
        if self._model_factory is not None:
            result["ready"] = True
            result["test_factory"] = True
            return result
        # Validate the offline model contract before optional runtime imports.
        # This keeps a bad or incomplete mounted bundle visible even in a
        # lightweight environment that intentionally omits Paddle.
        if not self.runtime_downloads:
            if self.model_root is None or not self.model_root.is_dir():
                result.update(ready=False, error="model_root_missing")
                return result
            cache_ready, fingerprints, cache_error = _cache_manifest(
                self.model_root, self.name
            )
            result.update(
                ready=False,
                model_fingerprints=fingerprints,
            )
            if cache_error:
                result["error"] = cache_error
                return result
            if not cache_ready:
                result["error"] = "model_manifest_incomplete"
                return result
        if not installed:
            result.update(ready=False, error="paddleocr_not_installed")
            return result
        if not device_ready:
            result.update(ready=False, error=device_error)
            return result
        if self.runtime_downloads:
            result["ready"] = True
            return result
        result["ready"] = True
        return result

    def _predict(self, input_path: Path) -> list[Any]:
        with self._predict_lock:
            # Model selection and inference share one process-global lock.  A
            # backend switch may evict the previous GPU pipeline, so it must
            # never race an in-flight prediction that still uses that model.
            model = self._model()
            try:
                return list(model.predict(str(input_path)))
            except Exception as exc:
                raise ParserBackendError(
                    f"{self.name} prediction failed: {exc.__class__.__name__}"
                ) from exc

    def _normalize_result(
        self,
        result: Any,
        *,
        page_number: int,
        page_index: int,
        width: float,
        height: float,
        rotation: int,
        nonempty: bool = True,
    ) -> EvidencePage:
        payload = _result_payload(result)
        return EvidencePage(
            page_number=page_number,
            page_index=page_index,
            width=max(1.0, width),
            height=max(1.0, height),
            rotation=rotation,
            blocks=_blocks(payload, source=self.name),
            tables=_tables(payload, source=self.name),
            markdown=_markdown(result, payload),
            raw={**payload, "nonempty": nonempty},
        )

    def parse(
        self,
        path: str | Path,
        *,
        pages: Sequence[PageInput] | None = None,
    ) -> DocumentEvidence:
        started = time.perf_counter()
        source = Path(path)
        normalized: list[EvidencePage] = []
        inputs = list(pages or [])
        if inputs:
            for page in inputs:
                width, height = _image_size(page.path)
                nonempty = _image_nonempty(page.path)
                results = self._predict(page.path)
                if not results:
                    normalized.append(
                        EvidencePage(
                            page_number=page.page_number,
                            page_index=page.page_index,
                            width=width,
                            height=height,
                            rotation=page.rotation,
                            raw={"empty_result": True, "nonempty": nonempty},
                        )
                    )
                    continue
                normalized.append(
                    self._normalize_result(
                        results[0],
                        page_number=page.page_number,
                        page_index=page.page_index,
                        width=width,
                        height=height,
                        rotation=page.rotation,
                        nonempty=nonempty,
                    )
                )
        else:
            results = self._predict(source)
            width, height = _image_size(source)
            for index, result in enumerate(results):
                payload = _result_payload(result)
                page_index = int(payload.get("page_index") or index)
                normalized.append(
                    self._normalize_result(
                        result,
                        page_number=page_index + 1,
                        page_index=page_index,
                        width=width,
                        height=height,
                        rotation=0,
                    )
                )
        return DocumentEvidence(
            backend=self.name,
            backend_version=_package_version(),
            model_fingerprints=dict(self._fingerprints),
            elapsed_ms=(time.perf_counter() - started) * 1000,
            pages=normalized,
        )


class PPStructureV3Backend(_PaddleBackend):
    name = "pp-structure-v3"

    def _create_model(self) -> Any:
        try:
            from paddleocr import PPStructureV3
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ParserBackendUnavailable("paddleocr is not installed") from exc
        return PPStructureV3(
            device=self.device,
            lang="ch",
            # Paddle 3.3's Windows CPU oneDNN executor cannot run the current
            # layout model's ArrayAttribute<Double> graph.  Disabling MKL-DNN
            # keeps the portable CPU fallback functional; GPU inference does
            # not use this optimization.
            enable_mkldnn=False,
            use_doc_orientation_classify=True,
            use_doc_unwarping=False,
            use_textline_orientation=False,
            use_seal_recognition=True,
            use_table_recognition=True,
            use_formula_recognition=False,
            use_chart_recognition=False,
        )


class PaddleOCRVLBackend(_PaddleBackend):
    name = "paddleocr-vl-1.6"

    def _create_model(self) -> Any:
        try:
            from paddleocr import PaddleOCRVL
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ParserBackendUnavailable("paddleocr is not installed") from exc
        return PaddleOCRVL(
            pipeline_version="v1.6",
            device=self.device,
            enable_mkldnn=False,
            vl_rec_backend="native",
            use_doc_orientation_classify=True,
            use_doc_unwarping=False,
            use_layout_detection=True,
            use_chart_recognition=False,
            use_queues=False,
            # PP-StructureV3 is the authority for seals.  The VLM is only a
            # targeted supplement, so loading a second seal recognizer wastes
            # memory and expands the offline cache without adding authority.
            use_seal_recognition=False,
            # PP-Structure already supplies deterministic OCR.  Enabling this
            # duplicates two PP-OCRv6 models inside the VLM pipeline.
            use_ocr_for_image_block=False,
        )


def record_supplement_timing(
    evidence: DocumentEvidence,
    *,
    backend: str,
    elapsed_ms: float,
) -> DocumentEvidence:
    """Accumulate successful or failed supplement wall time on evidence."""

    previous_timing = evidence.raw.get("timing")
    if isinstance(previous_timing, dict):
        primary_elapsed_ms = float(
            previous_timing.get("primary_elapsed_ms", evidence.elapsed_ms)
        )
        supplement_elapsed_ms = float(
            previous_timing.get("supplement_elapsed_ms", 0.0)
        )
        supplement_backends = [
            str(value)
            for value in previous_timing.get("supplement_backends", [])
            if str(value)
        ]
        primary_backend = str(
            previous_timing.get("primary_backend") or evidence.backend
        )
    else:
        primary_elapsed_ms = float(evidence.elapsed_ms)
        supplement_elapsed_ms = 0.0
        supplement_backends = []
        primary_backend = evidence.backend
    supplement_elapsed_ms += max(0.0, float(elapsed_ms))
    if backend and backend not in supplement_backends:
        supplement_backends.append(backend)
    total_elapsed_ms = primary_elapsed_ms + supplement_elapsed_ms
    evidence.elapsed_ms = total_elapsed_ms
    evidence.raw["timing"] = {
        "primary_backend": primary_backend,
        "primary_elapsed_ms": round(primary_elapsed_ms, 3),
        "supplement_backends": supplement_backends,
        "supplement_elapsed_ms": round(supplement_elapsed_ms, 3),
        "total_elapsed_ms": round(total_elapsed_ms, 3),
    }
    return evidence


def merge_evidence(primary: DocumentEvidence, supplement: DocumentEvidence) -> DocumentEvidence:
    """Add VLM evidence without replacing PP-Structure facts."""

    merged = primary.model_copy(deep=True)
    by_page = {page.page_number: page for page in merged.pages}

    def block_identity(block: EvidenceBlock) -> tuple[object, ...] | None:
        token = " ".join(block.text.split()).casefold()
        if not token:
            return None
        bbox = block.bbox
        coordinates = (
            None
            if bbox is None
            else (
                round(float(bbox.x0), 4),
                round(float(bbox.y0), 4),
                round(float(bbox.x1), 4),
                round(float(bbox.y1), 4),
                bbox.coordinate_space,
            )
        )
        return token, str(block.kind or "text").casefold(), coordinates

    for extra_page in supplement.pages:
        page = by_page.get(extra_page.page_number)
        if page is None:
            merged.pages.append(extra_page.model_copy(deep=True))
            continue
        known = {
            identity
            for block in page.blocks
            if (identity := block_identity(block)) is not None
        }
        for block in extra_page.blocks:
            identity = block_identity(block)
            if identity is not None and identity in known:
                continue
            clone = block.model_copy(deep=True)
            clone.source = supplement.backend
            clone.order = len(page.blocks) + clone.order
            page.blocks.append(clone)
            if identity is not None:
                known.add(identity)
        if not page.tables:
            page.tables = [table.model_copy(deep=True) for table in extra_page.tables]
        if extra_page.markdown:
            page.raw["vlm_markdown_supplement"] = extra_page.markdown
    merged.warnings.extend(supplement.warnings)
    merged.raw["supplement"] = supplement.summary()
    return record_supplement_timing(
        merged,
        backend=supplement.backend,
        elapsed_ms=supplement.elapsed_ms,
    )


__all__ = [
    "PPStructureV3Backend",
    "PaddleOCRVLBackend",
    "merge_evidence",
    "record_supplement_timing",
]
