"""Normalization for value-free, replayable tabular layout plans."""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from pydantic import BaseModel

from ..tabular_schema import TabularSchemaPlan
from .tabular_layout_signature import (
    _SAFE_FIELD,
    _SAFE_ID,
    _SAFE_TARGET_PATH,
    DocumentShape,
)

_PLAN_KEYS = frozenset(
    {
        "schema_version",
        "document_shape",
        "header_fields",
        "tables",
        "inspection_windows",
    }
)
_HEADER_KEYS = frozenset(
    {
        "field",
        "target_path",
        "strategy",
        "sheet",
        "region_id",
        "label_cells",
        "value_cells",
    }
)
_TABLE_KEYS = frozenset(
    {
        "sheet",
        "region_id",
        "orientation",
        "header_rows",
        "header_columns",
        "data_start_row",
        "data_end_row",
        "data_rows",
        "data_start_column",
        "data_end_column",
        "data_columns",
        "data_ranges",
        "columns",
        "row_fields",
    }
)
_COLUMN_KEYS = frozenset({"column", "field", "target_path", "label_cells"})
_ROW_KEYS = frozenset({"row", "field", "target_path", "label_cells"})
_RANGE_KEYS = frozenset({"start", "end", "step"})
_WINDOW_KEYS = frozenset(
    {"sheet", "start_row", "end_row", "start_column", "end_column", "reason"}
)
_FORBIDDEN_KEYS = frozenset(
    {
        "cached_value",
        "cell_value",
        "cell_values",
        "content",
        "display_filename",
        "file_name",
        "file_path",
        "filename",
        "formula",
        "normalized_value",
        "original_filename",
        "raw_text",
        "text",
        "value",
        "values",
    }
)
_COORDINATE = re.compile(r"^[A-Z]+[1-9]\d*$")


def _mapping(value: object, *, name: str) -> dict[str, Any]:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", exclude_none=False)
    if isinstance(value, Mapping):
        return dict(value)
    raise TypeError(f"tabular plan {name} must be an object")


def _sequence(value: object, *, name: str, limit: int) -> list[Any]:
    if not isinstance(value, list):
        raise TypeError(f"tabular plan {name} must be a list")
    if len(value) > limit:
        raise ValueError(f"tabular plan {name} exceeds its bounded limit")
    return value


def _keys(payload: Mapping[str, Any], allowed: frozenset[str], *, name: str) -> None:
    keys = {str(key) for key in payload}
    if keys & _FORBIDDEN_KEYS:
        raise ValueError(f"tabular plan {name} contains a forbidden value-bearing key")
    if keys - allowed:
        raise ValueError(f"tabular plan {name} contains an unsupported key")


def _bounded_text(value: object, *, name: str, maximum: int) -> str:
    if not isinstance(value, str) or not value or len(value) > maximum:
        raise ValueError(f"tabular plan {name} must be a bounded non-empty string")
    if any(character in value for character in ("\x00", "\r", "\n")):
        raise ValueError(f"tabular plan {name} contains an unsafe control character")
    return value


def _field(value: object, *, name: str) -> str:
    result = _bounded_text(value, name=name, maximum=160)
    if _SAFE_FIELD.fullmatch(result) is None:
        raise ValueError(f"tabular plan {name} must be a canonical field identifier")
    return result


def _target(value: object, *, name: str) -> str | None:
    if value is None:
        return None
    result = _bounded_text(value, name=name, maximum=200)
    if _SAFE_TARGET_PATH.fullmatch(result) is None:
        raise ValueError(f"tabular plan {name} must be a canonical target path")
    return result


def _region(value: object) -> str | None:
    if value is None:
        return None
    result = _bounded_text(value, name="region ID", maximum=80)
    if _SAFE_ID.fullmatch(result) is None:
        raise ValueError("tabular plan region ID must be a stable identifier")
    return result


def _coordinates(value: object, *, name: str) -> list[str]:
    coordinates = _sequence(value, name=name, limit=256)
    normalized = [
        _bounded_text(item, name=name, maximum=32).upper() for item in coordinates
    ]
    if any(_COORDINATE.fullmatch(item) is None for item in normalized):
        raise ValueError(f"tabular plan {name} must contain spreadsheet coordinates")
    return normalized


def _integer_list(value: object, *, name: str) -> list[int]:
    items = _sequence(value, name=name, limit=10_000)
    if any(
        isinstance(item, bool) or not isinstance(item, int) or item < 1
        for item in items
    ):
        raise ValueError(f"tabular plan {name} must contain positive integers")
    return list(items)


def _clean_header(value: object) -> dict[str, Any]:
    payload = _mapping(value, name="header mapping")
    _keys(payload, _HEADER_KEYS, name="header mapping")
    result = {
        "field": _field(payload.get("field"), name="header field"),
        "target_path": _target(payload.get("target_path"), name="header target path"),
        "strategy": payload.get("strategy"),
        "sheet": _bounded_text(payload.get("sheet"), name="sheet", maximum=128),
        "region_id": _region(payload.get("region_id")),
        "label_cells": _coordinates(payload.get("label_cells", []), name="label cells"),
        "value_cells": _coordinates(payload.get("value_cells", []), name="value cells"),
    }
    return result


def _clean_axis_mapping(value: object, *, row: bool) -> dict[str, Any]:
    name = "row mapping" if row else "column mapping"
    payload = _mapping(value, name=name)
    _keys(payload, _ROW_KEYS if row else _COLUMN_KEYS, name=name)
    axis = "row" if row else "column"
    result = {
        axis: payload.get(axis),
        "field": _field(payload.get("field"), name=f"{axis} field"),
        "target_path": _target(payload.get("target_path"), name=f"{axis} target path"),
        "label_cells": _coordinates(payload.get("label_cells", []), name="label cells"),
    }
    return result


def _clean_range(value: object) -> dict[str, int]:
    payload = _mapping(value, name="data range")
    _keys(payload, _RANGE_KEYS, name="data range")
    return {
        "start": payload.get("start"),
        "end": payload.get("end"),
        "step": payload.get("step", 1),
    }


def _clean_table(value: object) -> dict[str, Any]:
    payload = _mapping(value, name="table mapping")
    _keys(payload, _TABLE_KEYS, name="table mapping")
    return {
        "sheet": _bounded_text(payload.get("sheet"), name="sheet", maximum=128),
        "region_id": _region(payload.get("region_id")),
        "orientation": payload.get("orientation", "rows"),
        "header_rows": _integer_list(
            payload.get("header_rows", []), name="header rows"
        ),
        "header_columns": _integer_list(
            payload.get("header_columns", []), name="header columns"
        ),
        "data_start_row": payload.get("data_start_row"),
        "data_end_row": payload.get("data_end_row"),
        "data_rows": _integer_list(payload.get("data_rows", []), name="data rows"),
        "data_start_column": payload.get("data_start_column"),
        "data_end_column": payload.get("data_end_column"),
        "data_columns": _integer_list(
            payload.get("data_columns", []), name="data columns"
        ),
        "data_ranges": [
            _clean_range(item)
            for item in _sequence(
                payload.get("data_ranges", []), name="data ranges", limit=256
            )
        ],
        "columns": [
            _clean_axis_mapping(item, row=False)
            for item in _sequence(payload.get("columns", []), name="columns", limit=256)
        ],
        "row_fields": [
            _clean_axis_mapping(item, row=True)
            for item in _sequence(
                payload.get("row_fields", []), name="row fields", limit=256
            )
        ],
    }


def _clean_window(value: object) -> dict[str, Any]:
    payload = _mapping(value, name="inspection window")
    _keys(payload, _WINDOW_KEYS, name="inspection window")
    return {
        "sheet": _bounded_text(payload.get("sheet"), name="sheet", maximum=128),
        "start_row": payload.get("start_row"),
        "end_row": payload.get("end_row"),
        "start_column": payload.get("start_column", 1),
        "end_column": payload.get("end_column"),
    }


def normalize_tabular_layout_plan(value: object) -> dict[str, Any]:
    """Return a bounded plan containing mappings and coordinates, never values."""

    payload = _mapping(value, name="root")
    _keys(payload, _PLAN_KEYS, name="root")
    headers = _sequence(
        payload.get("header_fields", []), name="header fields", limit=256
    )
    tables = _sequence(payload.get("tables", []), name="tables", limit=64)
    windows = _sequence(
        payload.get("inspection_windows", []), name="inspection windows", limit=4
    )
    cleaned = {
        "schema_version": payload.get("schema_version", "v1"),
        "document_shape": payload.get("document_shape", "unknown"),
        "header_fields": [_clean_header(item) for item in headers],
        "tables": [_clean_table(item) for item in tables],
        "inspection_windows": [_clean_window(item) for item in windows],
    }
    validated = TabularSchemaPlan.model_validate(cleaned, strict=True)
    result = validated.model_dump(mode="json")
    for window in result["inspection_windows"]:
        window.pop("reason", None)
    return result


def _plan_summary(
    plan: Mapping[str, Any],
) -> tuple[DocumentShape, int, int, tuple[str, ...]]:
    document_shape = str(plan["document_shape"])
    tables = plan["tables"]
    orientations = tuple(
        sorted(
            {str(item["orientation"]) for item in tables if isinstance(item, Mapping)}
        )
    )
    return document_shape, len(plan["header_fields"]), len(tables), orientations


__all__ = ["normalize_tabular_layout_plan"]
