"""Backward-compatible facade for governed tabular-layout routing."""

from .tabular_layout_plan import normalize_tabular_layout_plan
from .tabular_layout_runtime import (
    PydanticTabularLayoutSelector,
    TabularLayoutCandidateProposal,
    TabularLayoutEmbeddingProvider,
    TabularLayoutExecutionObservation,
    TabularLayoutModelChoice,
    TabularLayoutProfile,
    TabularLayoutProfileMatch,
    TabularLayoutRankedCandidate,
    TabularLayoutResolution,
    TabularLayoutRouteStore,
    TabularLayoutRoutingPolicy,
    TabularLayoutRoutingRuntime,
    TabularLayoutSelectionCandidate,
    TabularLayoutSelectionRequest,
    TabularLayoutSelector,
)
from .tabular_layout_signature import (
    CountBucket,
    DocumentShape,
    ExecutionOutcome,
    ProfileStatus,
    RouteAction,
    RouteReason,
    TableOrientation,
    TabularLayoutProbe,
    TabularLayoutTableShape,
    TabularSourceKind,
    build_tabular_layout_probe,
    build_tabular_layout_signature,
)
from .tabular_layout_signature import (
    TabularLayoutSignature as TabularLayoutSignature,  # noqa: PLC0414
)

__all__ = [
    "CountBucket",
    "DocumentShape",
    "ExecutionOutcome",
    "ProfileStatus",
    "PydanticTabularLayoutSelector",
    "RouteAction",
    "RouteReason",
    "TableOrientation",
    "TabularLayoutCandidateProposal",
    "TabularLayoutEmbeddingProvider",
    "TabularLayoutExecutionObservation",
    "TabularLayoutModelChoice",
    "TabularLayoutProbe",
    "TabularLayoutProfile",
    "TabularLayoutProfileMatch",
    "TabularLayoutRankedCandidate",
    "TabularLayoutResolution",
    "TabularLayoutRouteStore",
    "TabularLayoutRoutingPolicy",
    "TabularLayoutRoutingRuntime",
    "TabularLayoutSelectionCandidate",
    "TabularLayoutSelectionRequest",
    "TabularLayoutSelector",
    "TabularLayoutTableShape",
    "TabularSourceKind",
    "build_tabular_layout_probe",
    "build_tabular_layout_signature",
    "normalize_tabular_layout_plan",
]
