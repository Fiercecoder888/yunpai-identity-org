"""Governed retrieval and selection runtime for reusable tabular layouts."""

from __future__ import annotations

import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Protocol, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .tabular_layout_plan import _plan_summary, normalize_tabular_layout_plan
from .tabular_layout_signature import (
    _SAFE_ID,
    DocumentShape,
    ExecutionOutcome,
    ProfileStatus,
    RouteAction,
    RouteReason,
    TabularLayoutProbe,
    TabularLayoutSignature,
    _bounded_score,
    build_tabular_layout_signature,
)


class TabularLayoutProfile(BaseModel):
    """A store-owned profile. IDs remain opaque to the small model."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str = Field(min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=256)
    profile_key: str = Field(min_length=1, max_length=128)
    status: ProfileStatus
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: TabularLayoutSignature
    plan: dict[str, Any]
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=128)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)

    @field_validator("profile_id", "profile_key")
    @classmethod
    def validate_id(cls, value: str) -> str:
        if _SAFE_ID.fullmatch(value) is None:
            raise ValueError("profile identifiers must be stable opaque identifiers")
        return value

    @field_validator("embedding")
    @classmethod
    def validate_embedding(
        cls, value: tuple[float, ...] | None
    ) -> tuple[float, ...] | None:
        if value is None:
            return None
        vector = tuple(float(item) for item in value)
        if not vector or not all(math.isfinite(item) for item in vector):
            raise ValueError("profile embedding must contain finite values")
        return vector

    @field_validator("plan", mode="before")
    @classmethod
    def validate_plan(cls, value: object) -> dict[str, Any]:
        return normalize_tabular_layout_plan(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("profile fingerprint does not match its signature")
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("profile observation counters are inconsistent")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self

    @property
    def success_rate(self) -> float | None:
        if not self.observation_count:
            return None
        return round(self.success_count / self.observation_count, 6)


class TabularLayoutProfileMatch(BaseModel):
    """One typed pgvector candidate returned by the injected store."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile: TabularLayoutProfile
    vector_similarity: float = Field(ge=0.0, le=1.0)


class TabularLayoutCandidateProposal(BaseModel):
    """An inactive value-free profile proposal; store assigns its profile ID."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=256)
    profile_key: str = Field(min_length=1, max_length=128)
    signature: TabularLayoutSignature
    plan: dict[str, Any]
    embedding: tuple[float, ...] | None = None
    embedding_model: str = Field(default="", max_length=128)
    embedding_dimensions: int = Field(default=0, ge=0, le=8192)

    @model_validator(mode="after")
    def validate_candidate(self) -> Self:
        if _SAFE_ID.fullmatch(self.profile_key) is None:
            raise ValueError("candidate profile key must be a stable opaque identifier")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding metadata requires an embedding")
        elif len(self.embedding) != self.embedding_dimensions:
            raise ValueError("embedding dimensions do not match the vector")
        return self

    @field_validator("plan", mode="before")
    @classmethod
    def validate_plan(cls, value: object) -> dict[str, Any]:
        return normalize_tabular_layout_plan(value)


class TabularLayoutExecutionObservation(BaseModel):
    """One value-free execution outcome tied to an opaque task hash."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=256)
    profile_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    outcome: ExecutionOutcome
    parser_revision: str = Field(min_length=1, max_length=128)
    applied: bool
    validation_passed: bool
    mapped_field_count: int = Field(default=0, ge=0, le=100_000)
    mapped_record_count: int = Field(default=0, ge=0, le=10_000_000)
    issue_codes: tuple[str, ...] = Field(default=(), max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)

    @field_validator("profile_id", "parser_revision", "error_code")
    @classmethod
    def validate_safe_identifier(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if normalized and _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("execution observation identifiers must be stable tokens")
        return normalized

    @field_validator("issue_codes", mode="before")
    @classmethod
    def validate_issue_codes(cls, value: object) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("issue_codes must be a sequence")
        normalized = tuple(
            dict.fromkeys(
                str(item).strip().casefold() for item in value if str(item).strip()
            )
        )
        if any(_SAFE_ID.fullmatch(item) is None for item in normalized):
            raise ValueError("issue codes must be stable tokens")
        return normalized

    @model_validator(mode="after")
    def validate_outcome(self) -> Self:
        if self.outcome == "success" and not (self.applied and self.validation_passed):
            raise ValueError(
                "successful observations require validation and application"
            )
        if self.outcome == "failure" and not self.error_code:
            raise ValueError("failed observations require an error code")
        return self


class TabularLayoutRouteStore(Protocol):
    """Persistence boundary for a future repository adapter."""

    async def get_active_tabular_layout_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        interpreter_revision: str,
    ) -> TabularLayoutProfile | None: ...

    async def find_active_tabular_layout_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        limit: int,
    ) -> Sequence[TabularLayoutProfileMatch]: ...

    async def create_tabular_layout_candidate(
        self, candidate: TabularLayoutCandidateProposal
    ) -> TabularLayoutProfile: ...

    async def record_tabular_layout_execution_observation(
        self, observation: TabularLayoutExecutionObservation
    ) -> Any: ...


class TabularLayoutEmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class TabularLayoutRankedCandidate(BaseModel):
    """Internal candidate score. ``profile_id`` never reaches the selector."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    profile_id: str
    structure_similarity: float = Field(ge=0.0, le=1.0)
    label_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)
    document_shape: DocumentShape
    header_mapping_count: int = Field(ge=0, le=256)
    table_mapping_count: int = Field(ge=0, le=64)
    table_orientations: tuple[str, ...] = ()
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)


class TabularLayoutSelectionCandidate(BaseModel):
    """Selector-safe candidate projection addressed only by its list index."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    candidate_index: int = Field(ge=0, le=4)
    structure_similarity: float = Field(ge=0.0, le=1.0)
    label_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)
    document_shape: DocumentShape
    header_mapping_count: int = Field(ge=0, le=256)
    table_mapping_count: int = Field(ge=0, le=64)
    table_orientations: tuple[str, ...] = ()
    success_rate: float | None = Field(default=None, ge=0.0, le=1.0)


class TabularLayoutSelectionRequest(BaseModel):
    """Bounded model input containing no tenant, profile ID, or table values."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    signature: TabularLayoutSignature
    candidates: tuple[TabularLayoutSelectionCandidate, ...] = ()


class TabularLayoutModelChoice(BaseModel):
    """Strict selector result. Only a candidate index may be reused."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: RouteAction
    candidate_index: int | None = Field(default=None, ge=0, le=4)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_choice(self) -> Self:
        if self.action == "reuse" and self.candidate_index is None:
            raise ValueError("reuse requires a candidate index")
        if self.action != "reuse" and self.candidate_index is not None:
            raise ValueError("only reuse may include a candidate index")
        return self


class TabularLayoutSelector(Protocol):
    async def select(
        self, request: TabularLayoutSelectionRequest
    ) -> TabularLayoutModelChoice | Mapping[str, Any]: ...


class TabularLayoutStructuredClient(Protocol):
    async def run(
        self,
        output_type: type[TabularLayoutModelChoice],
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> Any: ...


class PydanticTabularLayoutSelector:
    """Adapter for an existing prompted structured-output client."""

    _INSTRUCTIONS = (
        "Select only from the supplied value-free tabular-layout candidates. "
        "Use reuse only with a listed candidate_index. Use propose for a new "
        "reusable layout, generic for a one-off or uncertain layout, and review "
        "when a human must decide. Never emit values, fields, coordinates, IDs, "
        "or text not represented in the output schema."
    )

    def __init__(self, client: TabularLayoutStructuredClient) -> None:
        self._client = client

    async def select(
        self, request: TabularLayoutSelectionRequest
    ) -> TabularLayoutModelChoice:
        run = await self._client.run(
            TabularLayoutModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=json.dumps(
                request.model_dump(mode="json"),
                ensure_ascii=True,
                sort_keys=True,
                separators=(",", ":"),
            ),
            request_limit=1,
        )
        return TabularLayoutModelChoice.model_validate(run.output, strict=True)


@dataclass(frozen=True, slots=True)
class TabularLayoutRoutingPolicy:
    """Conservative gates for approximate reuse and proposal creation."""

    structure_weight: float = 0.50
    label_weight: float = 0.25
    vector_weight: float = 0.25
    model_candidate_min_score: float = 0.72
    model_reuse_min_score: float = 0.80
    model_reuse_min_confidence: float = 0.85
    model_selected_max_score_gap: float = 0.08
    model_proposal_min_confidence: float = 0.85
    max_model_candidates: int = 5

    def __post_init__(self) -> None:
        values = (
            self.structure_weight,
            self.label_weight,
            self.vector_weight,
            self.model_candidate_min_score,
            self.model_reuse_min_score,
            self.model_reuse_min_confidence,
            self.model_selected_max_score_gap,
            self.model_proposal_min_confidence,
        )
        if not all(math.isfinite(value) and 0.0 <= value <= 1.0 for value in values):
            raise ValueError("routing weights and thresholds must be finite in [0, 1]")
        if self.structure_weight + self.label_weight + self.vector_weight <= 0.0:
            raise ValueError("at least one route score weight must be positive")
        if self.model_reuse_min_score < self.model_candidate_min_score:
            raise ValueError(
                "reuse score threshold cannot be lower than candidate threshold"
            )
        if not 1 <= self.max_model_candidates <= 5:
            raise ValueError("max model candidates must be between one and five")


class TabularLayoutResolution(BaseModel):
    """Side-effect-aware route result for a future interpreter integration."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: RouteAction
    reason: RouteReason
    signature_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    profile_id: str | None = None
    plan: dict[str, Any] | None = None
    candidate_observation_required: bool = False
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    top1_top2_margin: float = Field(default=0.0, ge=0.0, le=1.0)
    candidates: tuple[TabularLayoutRankedCandidate, ...] = ()
    model_used: bool = False
    review_required: bool = False

    @model_validator(mode="after")
    def validate_resolution(self) -> Self:
        if self.action == "reuse" and self.profile_id is None:
            raise ValueError("reuse requires a profile ID")
        if self.action != "reuse" and self.profile_id is not None:
            raise ValueError("only reuse may return a profile ID")
        if self.action == "reuse" and self.plan is None:
            raise ValueError("reuse must return the approved tabular plan")
        if self.action != "reuse" and self.plan is not None:
            raise ValueError("only reuse may return a tabular plan")
        if self.candidate_observation_required != (self.action == "propose"):
            raise ValueError("candidate observation must match the propose action")
        if self.review_required != (self.action == "review"):
            raise ValueError("review_required must match the review action")
        return self

    @field_validator("plan", mode="before")
    @classmethod
    def validate_plan(cls, value: object) -> dict[str, Any] | None:
        if value is None:
            return None
        return normalize_tabular_layout_plan(value)


def _jaccard(
    first: Sequence[str], second: Sequence[str], *, both_empty: float | None
) -> float | None:
    left, right = set(first), set(second)
    if not left and not right:
        return both_empty
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def _profile_compatible(
    profile: TabularLayoutProfile, signature: TabularLayoutSignature
) -> bool:
    if profile.status != "active":
        return False
    if profile.signature.source_kind != signature.source_kind:
        return False
    if profile.signature.contract_revision != signature.contract_revision:
        return False
    if profile.signature.interpreter_revision != signature.interpreter_revision:
        return False
    if profile.signature.document_type_hint != signature.document_type_hint:
        return False
    if profile.signature.document_subtype_hint != signature.document_subtype_hint:
        return False
    if profile.signature.model_fingerprint != signature.model_fingerprint:
        return False
    if len(profile.signature.tables) != len(signature.tables):
        return False
    for reference, current in zip(
        profile.signature.tables, signature.tables, strict=True
    ):
        if reference.table_index != current.table_index:
            return False
        if (
            reference.column_count is not None
            and current.column_count is not None
            and reference.column_count != current.column_count
        ):
            return False
        if (
            reference.header_rows
            and current.header_rows
            and reference.header_rows != current.header_rows
        ):
            return False
        if (
            reference.orientation != "unknown"
            and current.orientation != "unknown"
            and reference.orientation != current.orientation
        ):
            return False
    return True


class TabularLayoutRoutingRuntime:
    """Retrieve approved profiles and apply candidate-index-only selection."""

    def __init__(
        self,
        *,
        store: TabularLayoutRouteStore,
        embedding_provider: TabularLayoutEmbeddingProvider | None = None,
        selector: TabularLayoutSelector | None = None,
        policy: TabularLayoutRoutingPolicy | None = None,
        required: bool = False,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
    ) -> None:
        self.store = store
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.policy = policy or TabularLayoutRoutingPolicy()
        self.required = bool(required)
        self._status = DocumentRoutingStatus(
            circuit_failures=circuit_failures,
            circuit_seconds=circuit_seconds,
        )

    def status_snapshot(self) -> dict[str, object]:
        """Return bounded dependency telemetry without document content."""

        return {
            **self._status.snapshot(),
            "required": self.required,
        }

    def _note_dependency_failure(
        self,
        dependency: str,
        error: BaseException,
    ) -> None:
        controlled = self._status.note_dependency_failure(dependency, error)
        if self.required:
            raise controlled from None

    def _circuit_resolution(
        self,
        *,
        dependency: str,
        signature: TabularLayoutSignature,
        candidates: Sequence[TabularLayoutRankedCandidate] = (),
        model_used: bool = False,
    ) -> TabularLayoutResolution:
        if self.required:
            raise DocumentRoutingDependencyError(dependency, "CircuitOpen")
        reason: RouteReason = {
            "store": "store_failure",
            "embedding": "embedding_failure",
            "model": "selector_failure",
        }[dependency]
        return self._resolution(
            action="generic",
            reason=reason,
            signature=signature,
            candidates=candidates,
            model_used=model_used,
        )

    async def _embed(
        self, signature: TabularLayoutSignature
    ) -> tuple[tuple[float, ...], str, int]:
        provider = self.embedding_provider
        if provider is None:
            raise RuntimeError("embedding provider unavailable")
        model = str(provider.model).strip()
        dimensions = int(provider.dimensions)
        if not model or dimensions < 1:
            raise ValueError("embedding provider has no valid identity")
        values = await provider.embed_texts((signature.embedding_text(),))
        if len(values) != 1:
            raise ValueError("embedding provider returned an unexpected vector count")
        vector = tuple(float(item) for item in values[0])
        if len(vector) != dimensions or not all(math.isfinite(item) for item in vector):
            raise ValueError("embedding provider returned an invalid vector")
        return vector, model, dimensions

    @staticmethod
    def _score(
        signature: TabularLayoutSignature,
        match: TabularLayoutProfileMatch,
        *,
        policy: TabularLayoutRoutingPolicy,
    ) -> TabularLayoutRankedCandidate:
        profile = match.profile
        structure = _jaccard(
            signature.structural_tokens(),
            profile.signature.structural_tokens(),
            both_empty=0.0,
        )
        labels = _jaccard(
            signature.all_semantic_labels(),
            profile.signature.all_semantic_labels(),
            both_empty=None,
        )
        components: list[tuple[float, float]] = [
            (float(structure or 0.0), policy.structure_weight),
            (float(match.vector_similarity), policy.vector_weight),
        ]
        if labels is not None:
            components.append((labels, policy.label_weight))
        total_weight = sum(weight for _value, weight in components)
        fused = sum(value * weight for value, weight in components) / total_weight
        document_shape, header_count, table_count, orientations = _plan_summary(
            profile.plan
        )
        return TabularLayoutRankedCandidate(
            profile_id=profile.profile_id,
            structure_similarity=_bounded_score(structure or 0.0),
            label_similarity=None if labels is None else _bounded_score(labels),
            vector_similarity=_bounded_score(match.vector_similarity),
            fused_score=_bounded_score(fused),
            document_shape=document_shape,
            header_mapping_count=header_count,
            table_mapping_count=table_count,
            table_orientations=orientations,
            success_rate=profile.success_rate,
        )

    @staticmethod
    def _top_metrics(
        candidates: Sequence[TabularLayoutRankedCandidate],
    ) -> tuple[float, float]:
        if not candidates:
            return 0.0, 0.0
        top_score = candidates[0].fused_score
        second_score = candidates[1].fused_score if len(candidates) > 1 else 0.0
        return top_score, _bounded_score(top_score - second_score)

    @staticmethod
    def _selector_candidates(
        candidates: Sequence[TabularLayoutRankedCandidate],
    ) -> tuple[TabularLayoutSelectionCandidate, ...]:
        return tuple(
            TabularLayoutSelectionCandidate(
                candidate_index=index,
                structure_similarity=candidate.structure_similarity,
                label_similarity=candidate.label_similarity,
                vector_similarity=candidate.vector_similarity,
                fused_score=candidate.fused_score,
                document_shape=candidate.document_shape,
                header_mapping_count=candidate.header_mapping_count,
                table_mapping_count=candidate.table_mapping_count,
                table_orientations=candidate.table_orientations,
                success_rate=candidate.success_rate,
            )
            for index, candidate in enumerate(candidates)
        )

    @staticmethod
    def _proposal_eligible(signature: TabularLayoutSignature) -> bool:
        return bool(
            signature.all_semantic_labels()
            or len(signature.tables) > 1
            or {"header_band", "key_value_prefix", "multiple_sections"}
            & set(signature.layout_tokens)
        )

    @staticmethod
    def _resolution(
        *,
        action: RouteAction,
        reason: RouteReason,
        signature: TabularLayoutSignature,
        candidates: Sequence[TabularLayoutRankedCandidate] = (),
        profile_id: str | None = None,
        plan: Mapping[str, Any] | None = None,
        model_used: bool = False,
    ) -> TabularLayoutResolution:
        top_score, margin = TabularLayoutRoutingRuntime._top_metrics(candidates)
        return TabularLayoutResolution(
            action=action,
            reason=reason,
            signature_fingerprint=signature.exact_fingerprint(),
            profile_id=profile_id,
            plan=plan,
            candidate_observation_required=action == "propose",
            top_score=top_score,
            top1_top2_margin=margin,
            candidates=tuple(candidates),
            model_used=model_used,
            review_required=action == "review",
        )

    async def _observe_candidate(
        self,
        *,
        tenant_id: str,
        probe: TabularLayoutProbe,
        validated_plan: Mapping[str, Any] | BaseModel,
    ) -> TabularLayoutProfile:
        """Persist only an inactive profile after the interpreter validated a plan.

        The caller must first run ``validate_plan(envelope, plan)``.  This
        routing layer revalidates that the payload is replayable and free of
        cell values or filenames, but it deliberately cannot validate evidence
        without the caller's envelope.
        """

        signature = build_tabular_layout_signature(probe)
        plan = normalize_tabular_layout_plan(validated_plan)
        embedding: tuple[float, ...] | None = None
        embedding_model = ""
        embedding_dimensions = 0
        if self.embedding_provider is None and self.required:
            self._note_dependency_failure(
                "embedding",
                RuntimeError("embedding provider unavailable"),
            )
        elif self.embedding_provider is not None:
            if self._status.circuit_open("embedding"):
                if self.required:
                    raise DocumentRoutingDependencyError("embedding", "CircuitOpen")
            else:
                try:
                    (
                        embedding,
                        embedding_model,
                        embedding_dimensions,
                    ) = await self._embed(signature)
                    self._status.note_dependency_success("embedding")
                except Exception as exc:  # noqa: BLE001 - optional exact candidate remains usable
                    self._note_dependency_failure("embedding", exc)
                    embedding = None
                    embedding_model = ""
                    embedding_dimensions = 0
        proposal = TabularLayoutCandidateProposal(
            tenant_id=tenant_id,
            profile_key=f"tabular-layout:{signature.exact_fingerprint()[:24]}",
            signature=signature,
            plan=plan,
            embedding=embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
        )
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            raise RuntimeError("tabular layout candidate store circuit is open")
        try:
            raw_candidate = await self.store.create_tabular_layout_candidate(proposal)
            candidate = TabularLayoutProfile.model_validate(raw_candidate, strict=True)
            if candidate.status != "candidate":
                raise ValueError("store returned a non-candidate layout profile")
            if candidate.tenant_id != tenant_id:
                raise ValueError("store returned a candidate in another tenant")
            if candidate.signature.exact_fingerprint() != signature.exact_fingerprint():
                raise ValueError("store returned a candidate for another signature")
            if candidate.plan != plan:
                raise ValueError("store returned a candidate with a different plan")
        except Exception as exc:
            self._note_dependency_failure("store", exc)
            raise
        self._status.note_dependency_success("store")
        return candidate

    async def observe_candidate(
        self,
        *,
        tenant_id: str,
        probe: TabularLayoutProbe,
        validated_plan: Mapping[str, Any] | BaseModel,
    ) -> TabularLayoutProfile:
        return await self._status.track_operation(
            self._observe_candidate(
                tenant_id=tenant_id,
                probe=probe,
                validated_plan=validated_plan,
            )
        )

    async def _record_execution_observation(
        self,
        observation: TabularLayoutExecutionObservation,
    ) -> bool:
        """Persist an advisory outcome when the injected store supports governance."""

        if observation.tenant_id.strip() != observation.tenant_id:
            raise ValueError("observation tenant_id must be normalized")
        if self._status.circuit_open("store"):
            if self.required:
                raise DocumentRoutingDependencyError("store", "CircuitOpen")
            raise RuntimeError("tabular layout observation store circuit is open")
        record = getattr(
            self.store,
            "record_tabular_layout_execution_observation",
            None,
        )
        if not callable(record):
            self._note_dependency_failure(
                "store",
                TypeError("tabular layout observation store method is unavailable"),
            )
            return False
        try:
            await record(observation)
        except Exception as exc:
            self._note_dependency_failure("store", exc)
            raise
        self._status.note_dependency_success("store")
        return True

    async def record_execution_observation(
        self,
        observation: TabularLayoutExecutionObservation,
    ) -> bool:
        return await self._status.track_operation(
            self._record_execution_observation(observation)
        )

    async def _resolve_exact_signature(
        self,
        *,
        tenant_id: str,
        signature: TabularLayoutSignature,
    ) -> TabularLayoutResolution:
        """Query the exact active fingerprint without embeddings or a selector."""

        if self._status.circuit_open("store"):
            return self._circuit_resolution(
                dependency="store",
                signature=signature,
            )
        try:
            raw_exact = (
                await self.store.get_active_tabular_layout_profile_by_fingerprint(
                    tenant_id,
                    signature.exact_fingerprint(),
                    contract_revision=signature.contract_revision,
                    interpreter_revision=signature.interpreter_revision,
                )
            )
            exact = (
                None
                if raw_exact is None
                else TabularLayoutProfile.model_validate(raw_exact, strict=True)
            )
        except Exception as exc:  # noqa: BLE001 - optional routing falls back safely
            self._note_dependency_failure("store", exc)
            return self._resolution(
                action="generic", reason="store_failure", signature=signature
            )
        if exact is None:
            self._status.note_dependency_success("store")
            return self._resolution(
                action="generic",
                reason="exact_profile_not_found",
                signature=signature,
            )
        if (
            exact.tenant_id == tenant_id
            and exact.exact_fingerprint == signature.exact_fingerprint()
            and _profile_compatible(exact, signature)
        ):
            self._status.note_dependency_success("store")
            return self._resolution(
                action="reuse",
                reason="exact_fingerprint",
                signature=signature,
                profile_id=exact.profile_id,
                plan=exact.plan,
            )
        self._note_dependency_failure(
            "store",
            ValueError("exact profile response violates the active tenant query"),
        )
        return self._resolution(
            action="generic",
            reason="exact_profile_incompatible",
            signature=signature,
        )

    async def resolve_exact(
        self,
        *,
        tenant_id: str,
        probe: TabularLayoutProbe,
    ) -> TabularLayoutResolution:
        """Resolve only an exact active profile, with no model-side work."""

        return await self._status.track_operation(
            self._resolve_exact_signature(
                tenant_id=tenant_id,
                signature=build_tabular_layout_signature(probe),
            )
        )

    async def _resolve(
        self,
        *,
        tenant_id: str,
        probe: TabularLayoutProbe,
    ) -> TabularLayoutResolution:
        """Return a governed route without creating an active profile automatically."""

        signature = build_tabular_layout_signature(probe)
        exact_resolution = await self._resolve_exact_signature(
            tenant_id=tenant_id,
            signature=signature,
        )
        if exact_resolution.reason != "exact_profile_not_found":
            return exact_resolution

        if self.embedding_provider is None:
            self._note_dependency_failure(
                "embedding",
                RuntimeError("embedding provider unavailable"),
            )
            return self._resolution(
                action="generic",
                reason="embedding_unavailable",
                signature=signature,
            )
        if self._status.circuit_open("embedding"):
            return self._circuit_resolution(
                dependency="embedding",
                signature=signature,
            )
        try:
            embedding, embedding_model, embedding_dimensions = await self._embed(
                signature
            )
            self._status.note_dependency_success("embedding")
        except Exception as exc:  # noqa: BLE001 - optional routing falls back safely
            self._note_dependency_failure("embedding", exc)
            return self._resolution(
                action="generic",
                reason="embedding_failure",
                signature=signature,
            )

        if self._status.circuit_open("store"):
            return self._circuit_resolution(
                dependency="store",
                signature=signature,
            )
        try:
            raw_matches = await self.store.find_active_tabular_layout_profiles(
                tenant_id,
                embedding,
                embedding_model=embedding_model,
                embedding_dimensions=embedding_dimensions,
                limit=min(100, self.policy.max_model_candidates * 4),
            )
            if isinstance(raw_matches, (str, bytes, bytearray)) or not isinstance(
                raw_matches, Sequence
            ):
                raise TypeError("profile store returned a non-sequence response")
            matches = tuple(
                TabularLayoutProfileMatch.model_validate(match, strict=True)
                for match in raw_matches
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - optional routing falls back safely
            self._note_dependency_failure("store", exc)
            return self._resolution(
                action="generic",
                reason="store_failure",
                signature=signature,
            )

        ranked_by_id: dict[str, TabularLayoutRankedCandidate] = {}
        profiles_by_id: dict[str, TabularLayoutProfile] = {}
        for match in matches:
            profile = match.profile
            if profile.tenant_id != tenant_id or not _profile_compatible(
                profile, signature
            ):
                continue
            if profile.embedding_model != embedding_model:
                continue
            if profile.embedding_dimensions != embedding_dimensions:
                continue
            ranked_by_id[profile.profile_id] = self._score(
                signature,
                match,
                policy=self.policy,
            )
            profiles_by_id[profile.profile_id] = profile
        ranked = tuple(
            sorted(
                ranked_by_id.values(),
                key=lambda item: (-item.fused_score, item.profile_id),
            )
        )
        usable = tuple(
            item
            for item in ranked
            if item.fused_score >= self.policy.model_candidate_min_score
        )[: self.policy.max_model_candidates]

        # With no compatible stored candidate there is nothing safe for a model
        # to select.  Let the generic interpreter build and validate a plan,
        # then persist it as an inactive candidate only after successful apply.
        if not usable:
            return self._resolution(
                action=("propose" if self._proposal_eligible(signature) else "generic"),
                reason="no_compatible_candidates",
                signature=signature,
            )

        if self.selector is None:
            self._note_dependency_failure(
                "model",
                RuntimeError("tabular layout selector unavailable"),
            )
            return self._resolution(
                action="generic",
                reason="selector_unavailable",
                signature=signature,
                candidates=usable,
            )
        if self._status.circuit_open("model"):
            return self._circuit_resolution(
                dependency="model",
                signature=signature,
                candidates=usable,
                model_used=True,
            )

        request = TabularLayoutSelectionRequest(
            signature_fingerprint=signature.exact_fingerprint(),
            signature=signature,
            candidates=self._selector_candidates(usable),
        )
        try:
            raw_choice = await self.selector.select(request)
            choice = TabularLayoutModelChoice.model_validate(raw_choice, strict=True)
            self._status.note_dependency_success("model")
        except (TypeError, ValueError, ValidationError) as exc:
            self._note_dependency_failure("model", exc)
            return self._resolution(
                action="generic",
                reason="invalid_model_output",
                signature=signature,
                candidates=usable,
                model_used=True,
            )
        except Exception as exc:  # noqa: BLE001 - optional routing falls back safely
            self._note_dependency_failure("model", exc)
            return self._resolution(
                action="generic",
                reason="selector_failure",
                signature=signature,
                candidates=usable,
                model_used=True,
            )

        if choice.action == "reuse":
            index = choice.candidate_index
            if index is None or index >= len(usable):
                self._note_dependency_failure(
                    "model",
                    ValueError("selector returned an unavailable candidate index"),
                )
                return self._resolution(
                    action="generic",
                    reason="model_candidate_invalid",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            selected = usable[index]
            top_score = usable[0].fused_score if usable else 0.0
            if (
                selected.fused_score < self.policy.model_reuse_min_score
                or top_score - selected.fused_score
                > self.policy.model_selected_max_score_gap
            ):
                return self._resolution(
                    action="generic",
                    reason="model_candidate_below_threshold",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            if choice.confidence < self.policy.model_reuse_min_confidence:
                return self._resolution(
                    action="generic",
                    reason="model_confidence_below_threshold",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            selected_profile = profiles_by_id.get(selected.profile_id)
            if selected_profile is None:
                self._note_dependency_failure(
                    "model",
                    ValueError("selector returned an unavailable candidate"),
                )
                return self._resolution(
                    action="generic",
                    reason="model_candidate_invalid",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            return self._resolution(
                action="reuse",
                reason="model_reuse",
                signature=signature,
                candidates=usable,
                profile_id=selected.profile_id,
                plan=selected_profile.plan,
                model_used=True,
            )

        if choice.action == "propose":
            if choice.confidence < self.policy.model_proposal_min_confidence:
                return self._resolution(
                    action="generic",
                    reason="model_confidence_below_threshold",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            if not self._proposal_eligible(signature):
                return self._resolution(
                    action="generic",
                    reason="proposal_not_eligible",
                    signature=signature,
                    candidates=usable,
                    model_used=True,
                )
            return self._resolution(
                action="propose",
                reason="model_propose",
                signature=signature,
                candidates=usable,
                model_used=True,
            )

        if choice.action == "review":
            return self._resolution(
                action="review",
                reason="model_review",
                signature=signature,
                candidates=usable,
                model_used=True,
            )
        return self._resolution(
            action="generic",
            reason="model_generic",
            signature=signature,
            candidates=usable,
            model_used=True,
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        probe: TabularLayoutProbe,
    ) -> TabularLayoutResolution:
        return await self._status.track_operation(
            self._resolve(tenant_id=tenant_id, probe=probe)
        )


__all__ = [
    "PydanticTabularLayoutSelector",
    "TabularLayoutCandidateProposal",
    "TabularLayoutEmbeddingProvider",
    "TabularLayoutExecutionObservation",
    "TabularLayoutModelChoice",
    "TabularLayoutProfile",
    "TabularLayoutProfileMatch",
    "TabularLayoutRankedCandidate",
    "TabularLayoutResolution",
    "TabularLayoutRouteStore",
    "TabularLayoutRoutingPolicy",
    "TabularLayoutRoutingRuntime",
    "TabularLayoutSelectionCandidate",
    "TabularLayoutSelectionRequest",
    "TabularLayoutSelector",
]
