"""Value-free signatures and bounded probes for tabular layout routing."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections.abc import Sequence
from itertools import pairwise
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

TabularSourceKind = Literal["csv", "spreadsheet", "html_table", "document_table"]
CountBucket = Literal["none", "single", "few", "many"]
TableOrientation = Literal[
    "records_by_row",
    "records_by_column",
    "key_value",
    "matrix",
    "unknown",
]
DocumentShape = Literal["single_order", "multi_order", "ledger", "other", "unknown"]
ProfileStatus = Literal["active", "candidate", "deprecated"]
ExecutionOutcome = Literal["success", "failure"]
RouteAction = Literal["reuse", "propose", "generic", "review"]
RouteReason = Literal[
    "exact_fingerprint",
    "exact_profile_not_found",
    "exact_profile_incompatible",
    "embedding_unavailable",
    "embedding_failure",
    "store_failure",
    "no_compatible_candidates",
    "selector_unavailable",
    "selector_failure",
    "invalid_model_output",
    "model_candidate_invalid",
    "model_candidate_below_threshold",
    "model_confidence_below_threshold",
    "model_reuse",
    "model_propose",
    "model_generic",
    "model_review",
    "proposal_not_eligible",
    "candidate_store_failure",
]

_SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
_SAFE_REVISION = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")
_SAFE_FIELD = re.compile(r"^[a-z][a-z0-9_]{0,159}$")
_SAFE_TARGET_PATH = re.compile(r"^\$\.[A-Za-z0-9_.*\[\]]{1,198}$")
_ALLOWED_LAYOUT_TOKENS = frozenset(
    {
        "blank_separators",
        "dense",
        "footer_totals",
        "formula_cells",
        "header_band",
        "key_value_prefix",
        "key_value_suffix",
        "merged_cells",
        "multiple_sections",
        "multi_sheet",
        "notes",
        "records",
        "sparse",
        "title_band",
    }
)
_ALLOWED_SEMANTIC_LABELS = frozenset(
    {
        "buyer",
        "contract_number",
        "currency",
        "customer",
        "delivery_date",
        "document_number",
        "drawing_number",
        "equipment_identifier",
        "inventory_quantity",
        "item_number",
        "line_number",
        "manufacturer",
        "material_id",
        "material_name",
        "model",
        "mold_identifier",
        "order_date",
        "order_number",
        "product_id",
        "product_name",
        "purchase_order_number",
        "quantity",
        "seller",
        "specification",
        "supplier",
        "total_amount",
        "unit",
        "unit_price",
        "warehouse",
    }
)


def _bounded_score(value: float) -> float:
    return round(max(0.0, min(1.0, float(value))), 6)


def _canonical_tokens(
    value: object,
    *,
    allowed: frozenset[str],
    label: str,
) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str) or not isinstance(value, Sequence):
        raise TypeError(f"{label} must be a sequence")
    normalized = tuple(
        sorted({str(item).strip().casefold() for item in value if str(item).strip()})
    )
    if len(normalized) > 64:
        raise ValueError(f"{label} accepts at most 64 tokens")
    if any(item not in allowed for item in normalized):
        raise ValueError(f"{label} must use the closed value-free vocabulary")
    return normalized


def _bucket(count: int) -> CountBucket:
    if count <= 0:
        return "none"
    if count == 1:
        return "single"
    if count <= 4:
        return "few"
    return "many"


class TabularLayoutTableShape(BaseModel):
    """A table's topology without headings, cells, coordinates, or values.

    The bucket fields keep approximate matching tolerant of harmless row-count
    changes.  The optional exact/topology fields are used for the fingerprint
    and compatibility gate so that two different regions are not accidentally
    treated as the same reusable layout.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    table_index: int = Field(ge=0, le=4095)
    row_bucket: CountBucket
    column_bucket: CountBucket
    row_count: int | None = Field(default=None, ge=1, le=100_000)
    column_count: int | None = Field(default=None, ge=1, le=4_096)
    orientation: TableOrientation = "unknown"
    header_band_rows: int = Field(default=0, ge=0, le=8)
    header_rows: tuple[int, ...] = Field(default=(), max_length=8)
    section_count: int = Field(default=1, ge=1, le=10_000)
    merged_range_count: int = Field(default=0, ge=0, le=10_000)
    layout_tokens: tuple[str, ...] = ()
    semantic_labels: tuple[str, ...] = ()

    @field_validator("header_rows", mode="before")
    @classmethod
    def validate_header_rows(cls, value: object) -> tuple[int, ...]:
        if value is None:
            return ()
        if isinstance(value, (str, bytes, bytearray)) or not isinstance(
            value, Sequence
        ):
            raise TypeError("header_rows must be a sequence")
        normalized = tuple(sorted({int(item) for item in value if int(item) >= 1}))[:8]
        return normalized

    @model_validator(mode="after")
    def validate_exact_shape(self) -> Self:
        if self.row_count is not None and _bucket(self.row_count) != self.row_bucket:
            raise ValueError("row_count does not match row_bucket")
        if (
            self.column_count is not None
            and _bucket(self.column_count) != self.column_bucket
        ):
            raise ValueError("column_count does not match column_bucket")
        if self.header_rows and self.header_band_rows < len(self.header_rows):
            raise ValueError("header_rows exceed header_band_rows")
        return self

    @field_validator("layout_tokens", mode="before")
    @classmethod
    def validate_layout_tokens(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_LAYOUT_TOKENS,
            label="table layout tokens",
        )

    @field_validator("semantic_labels", mode="before")
    @classmethod
    def validate_semantic_labels(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_SEMANTIC_LABELS,
            label="table semantic labels",
        )

    def structural_tokens(self) -> tuple[str, ...]:
        tokens = {
            f"table:{self.table_index}:rows:{self.row_bucket}",
            f"table:{self.table_index}:columns:{self.column_bucket}",
            f"table:{self.table_index}:orientation:{self.orientation}",
            f"table:{self.table_index}:header-band:{self.header_band_rows}",
            f"table:{self.table_index}:sections:{self.section_count}",
            f"table:{self.table_index}:merged:{self.merged_range_count}",
            *(
                f"table:{self.table_index}:layout:{token}"
                for token in self.layout_tokens
            ),
        }
        if self.row_count is not None:
            tokens.add(f"table:{self.table_index}:rows-exact:{self.row_count}")
        if self.column_count is not None:
            tokens.add(f"table:{self.table_index}:columns-exact:{self.column_count}")
        tokens.update(
            f"table:{self.table_index}:header-row:{row}" for row in self.header_rows
        )
        return tuple(sorted(tokens))


class TabularLayoutProbe(BaseModel):
    """Caller-supplied structural probe used to build a safe route signature."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source_kind: TabularSourceKind
    tables: tuple[TabularLayoutTableShape, ...] = ()
    layout_tokens: tuple[str, ...] = ()
    semantic_labels: tuple[str, ...] = ()
    document_type_hint: str | None = Field(default=None, max_length=64)
    document_subtype_hint: str | None = Field(default=None, max_length=64)
    model_fingerprint: str = Field(default="", max_length=64)
    contract_revision: str = Field(
        default="m1.document.v2", min_length=1, max_length=128
    )
    interpreter_revision: str = Field(
        default="m1.tabular-layout.v1", min_length=1, max_length=128
    )

    @field_validator("layout_tokens", mode="before")
    @classmethod
    def validate_layout_tokens(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_LAYOUT_TOKENS,
            label="layout tokens",
        )

    @field_validator("semantic_labels", mode="before")
    @classmethod
    def validate_semantic_labels(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_SEMANTIC_LABELS,
            label="semantic labels",
        )

    @field_validator("contract_revision", "interpreter_revision")
    @classmethod
    def validate_revision(cls, value: str) -> str:
        if _SAFE_REVISION.fullmatch(value) is None:
            raise ValueError("revision must be a stable non-value identifier")
        return value

    @field_validator("document_type_hint", "document_subtype_hint", "model_fingerprint")
    @classmethod
    def validate_route_context(cls, value: str | None) -> str | None:
        normalized = value.strip().casefold() if isinstance(value, str) else value
        if normalized and _SAFE_REVISION.fullmatch(normalized) is None:
            raise ValueError("route context must be a stable non-value identifier")
        return normalized

    @model_validator(mode="after")
    def validate_tables(self) -> Self:
        indexes = [item.table_index for item in self.tables]
        if len(indexes) != len(set(indexes)):
            raise ValueError("table indexes must be unique")
        if indexes != sorted(indexes):
            raise ValueError("tables must be ordered by table_index")
        return self


class TabularLayoutSignature(BaseModel):
    """Canonical, value-free representation that is safe to hash and embed."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    source_kind: TabularSourceKind
    table_count_bucket: CountBucket
    tables: tuple[TabularLayoutTableShape, ...] = ()
    layout_tokens: tuple[str, ...] = ()
    semantic_labels: tuple[str, ...] = ()
    document_type_hint: str | None = Field(default=None, max_length=64)
    document_subtype_hint: str | None = Field(default=None, max_length=64)
    model_fingerprint: str = Field(default="", max_length=64)
    contract_revision: str = Field(min_length=1, max_length=128)
    interpreter_revision: str = Field(min_length=1, max_length=128)

    @field_validator("layout_tokens", mode="before")
    @classmethod
    def validate_layout_tokens(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_LAYOUT_TOKENS,
            label="layout tokens",
        )

    @field_validator("semantic_labels", mode="before")
    @classmethod
    def validate_semantic_labels(cls, value: object) -> tuple[str, ...]:
        return _canonical_tokens(
            value,
            allowed=_ALLOWED_SEMANTIC_LABELS,
            label="semantic labels",
        )

    @field_validator("contract_revision", "interpreter_revision")
    @classmethod
    def validate_revision(cls, value: str) -> str:
        if _SAFE_REVISION.fullmatch(value) is None:
            raise ValueError("revision must be a stable non-value identifier")
        return value

    @field_validator("document_type_hint", "document_subtype_hint", "model_fingerprint")
    @classmethod
    def validate_route_context(cls, value: str | None) -> str | None:
        normalized = value.strip().casefold() if isinstance(value, str) else value
        if normalized and _SAFE_REVISION.fullmatch(normalized) is None:
            raise ValueError("route context must be a stable non-value identifier")
        return normalized

    @model_validator(mode="after")
    def validate_table_shape(self) -> Self:
        indexes = [item.table_index for item in self.tables]
        if indexes != sorted(indexes) or len(indexes) != len(set(indexes)):
            raise ValueError("signature table indexes must be unique and ordered")
        if _bucket(len(self.tables)) != self.table_count_bucket:
            raise ValueError("table count bucket does not match the table topology")
        return self

    def exact_fingerprint(self) -> str:
        payload = self.model_dump(mode="json")
        encoded = json.dumps(
            payload,
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    def structural_tokens(self) -> tuple[str, ...]:
        tokens = {
            f"source:{self.source_kind}",
            f"tables:{self.table_count_bucket}",
            *(f"layout:{token}" for token in self.layout_tokens),
        }
        for shape in self.tables:
            tokens.update(shape.structural_tokens())
        return tuple(sorted(tokens))

    def all_semantic_labels(self) -> tuple[str, ...]:
        labels = set(self.semantic_labels)
        for shape in self.tables:
            labels.update(shape.semantic_labels)
        return tuple(sorted(labels))

    def embedding_text(self) -> str:
        """Return a bounded text made solely of closed structural vocabulary."""

        parts = [
            "tabular-layout-v1",
            f"source={self.source_kind}",
            f"table_count={self.table_count_bucket}",
            f"layout={','.join(self.layout_tokens) or 'none'}",
            f"labels={','.join(self.all_semantic_labels()) or 'none'}",
            f"type={self.document_type_hint or 'unknown'}",
            f"subtype={self.document_subtype_hint or 'unknown'}",
            f"model={self.model_fingerprint or 'unknown'}",
        ]
        for shape in self.tables:
            parts.append(
                "table="
                f"{shape.table_index}:{shape.row_bucket}:{shape.column_bucket}:"
                f"{shape.row_count or 'bucket'}:{shape.column_count or 'bucket'}:"
                f"{shape.orientation}:header-{shape.header_band_rows}:"
                f"header-rows={','.join(map(str, shape.header_rows)) or 'unknown'}:"
                f"sections={shape.section_count}:merged={shape.merged_range_count}:"
                f"{','.join(shape.layout_tokens) or 'none'}:"
                f"{','.join(shape.semantic_labels) or 'none'}"
            )
        return ";".join(parts)


def build_tabular_layout_signature(probe: TabularLayoutProbe) -> TabularLayoutSignature:
    """Build a route signature without inspecting cell text or business values."""

    return TabularLayoutSignature(
        source_kind=probe.source_kind,
        table_count_bucket=_bucket(len(probe.tables)),
        tables=probe.tables,
        layout_tokens=probe.layout_tokens,
        semantic_labels=probe.semantic_labels,
        document_type_hint=probe.document_type_hint,
        document_subtype_hint=probe.document_subtype_hint,
        model_fingerprint=probe.model_fingerprint,
        contract_revision=probe.contract_revision,
        interpreter_revision=probe.interpreter_revision,
    )


# The probe intentionally maps source labels to a closed vocabulary.  It never
# stores the label spelling or any neighbouring cell value in a route profile.

_PROBE_LABEL_ALIASES: dict[str, tuple[str, ...]] = {
    "order_number": (
        "订单号",
        "订单编号",
        "采购单号",
        "采购订单号",
        "order number",
        "order no",
        "po number",
        "po no",
    ),
    "purchase_order_number": (
        "采购订单号",
        "采购单号",
        "purchase order number",
        "purchase order no",
    ),
    "contract_number": (
        "合同号",
        "合同编号",
        "合约编号",
        "contract number",
        "contract no",
    ),
    "order_date": (
        "下单日期",
        "订单日期",
        "制单日期",
        "签订日期",
        "order date",
        "issue date",
    ),
    "delivery_date": (
        "交货日期",
        "交货期",
        "交期",
        "交付日期",
        "要求交期",
        "到货日期",
        "delivery date",
        "due date",
    ),
    "buyer": ("甲方", "买方", "采购方", "需方", "客户", "购货方", "buyer", "customer"),
    "seller": (
        "乙方",
        "卖方",
        "销售方",
        "供方",
        "供货方",
        "供应商",
        "seller",
        "supplier",
        "vendor",
    ),
    "supplier": ("供应商", "供方", "供货方", "厂商", "supplier", "vendor"),
    "customer": ("客户", "客户名称", "customer"),
    "line_number": ("序", "序号", "行号", "line number", "line no", "item no"),
    "item_number": ("物料号", "物料编码", "料号", "项目号", "item number", "item code"),
    "product_id": (
        "产品编码",
        "产品编号",
        "产品id",
        "sku",
        "product id",
        "product code",
    ),
    "product_name": ("产品名称", "品名", "product name"),
    "material_id": ("物料号", "物料编码", "材料编号", "material id", "material code"),
    "material_name": ("物料名称", "材料名称", "material name"),
    "model": ("型号", "模号", "model", "part number"),
    "mold_identifier": ("模号", "模具编号", "mold number", "mold id"),
    "specification": ("规格", "规格型号", "技术规格", "specification", "spec"),
    "quantity": ("数量", "订购数量", "采购数量", "quantity", "qty"),
    "inventory_quantity": (
        "库存数量",
        "库存",
        "available quantity",
        "inventory quantity",
        "stock quantity",
    ),
    "unit": ("单位", "计量单位", "unit"),
    "unit_price": ("单价", "含税单价", "unit price", "price"),
    "total_amount": ("金额", "总金额", "合计金额", "total amount", "amount", "total"),
    "currency": ("币种", "货币", "结算币种", "currency"),
    "warehouse": ("仓库", "库位", "warehouse"),
    "drawing_number": ("图号", "图纸编号", "drawing number", "drawing no"),
    "equipment_identifier": ("设备编号", "机器编号", "equipment id", "machine id"),
    "manufacturer": ("制造商", "生产厂家", "厂商", "manufacturer"),
    "document_number": ("文件编号", "文档编号", "document number", "document no"),
}


def _probe_text(value: object) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip().casefold()


def _probe_compact(value: object) -> str:
    return re.sub(r"[\s:：;；,，._\-_/\\()\[\]{}]+", "", _probe_text(value))


_PROBE_ALIAS_INDEX = {
    _probe_compact(alias): label
    for label, aliases in _PROBE_LABEL_ALIASES.items()
    for alias in aliases
    if _probe_compact(alias)
}


def _probe_semantic_label(value: object) -> str | None:
    compact = _probe_compact(value)
    if not compact or len(compact) > 64:
        return None
    direct = _PROBE_ALIAS_INDEX.get(compact)
    if direct is not None:
        return direct
    for alias, label in _PROBE_ALIAS_INDEX.items():
        if len(alias) >= 2 and (compact.startswith(alias) or compact.endswith(alias)):
            remainder = (
                compact[len(alias) :]
                if compact.startswith(alias)
                else compact[: -len(alias)]
            )
            if len(remainder) <= 8 and not any(
                character.isdigit() for character in remainder
            ):
                return label
    return None


def _probe_bucket(count: int) -> CountBucket:
    return _bucket(max(0, int(count)))


def _probe_source_kind(envelope: Any, source_kind: str | None) -> TabularSourceKind:
    raw = str(
        source_kind or getattr(envelope, "file_kind", "spreadsheet") or "spreadsheet"
    ).casefold()
    if raw in {"csv", "tsv"}:
        return "csv"
    if raw in {"html", "html_table", "htm"}:
        return "html_table"
    if raw in {"document_table", "docx", "pdf"}:
        return "document_table"
    return "spreadsheet"


def build_tabular_layout_probe(
    envelope: Any,
    *,
    source_kind: str | None = None,
    contract_revision: str = "m1.document.v2",
    interpreter_revision: str = "m1.tabular-layout.v1",
    document_type_hint: str | None = None,
    document_subtype_hint: str | None = None,
    model_fingerprint: str = "",
) -> TabularLayoutProbe:
    """Build a bounded, value-free route probe from a parsed envelope."""

    tables: list[TabularLayoutTableShape] = []
    global_layout: set[str] = set()
    global_labels: set[str] = set()
    sheets = list(getattr(envelope, "sheets", ()) or ())[:64]
    for table_index, sheet in enumerate(sheets):
        table_layout: set[str] = set()
        cells = [
            cell
            for cell in (getattr(sheet, "cells", {}) or {}).values()
            if getattr(cell, "value", None) not in (None, "")
            and not bool(getattr(cell, "hidden_row", False))
            and not bool(getattr(cell, "hidden_column", False))
        ]
        max_row = max(
            int(getattr(sheet, "max_row", 0) or 0),
            max((int(getattr(cell, "row", 0) or 0) for cell in cells), default=0),
        )
        max_column = max(
            int(getattr(sheet, "max_column", 0) or 0),
            max((int(getattr(cell, "column", 0) or 0) for cell in cells), default=0),
        )
        max_row = max(1, min(max_row, 100_000))
        max_column = max(1, min(max_column, 4_096))
        by_row: dict[int, list[Any]] = {}
        labels: set[str] = set()
        label_rows: set[int] = set()
        for cell in cells[:100_000]:
            row = int(getattr(cell, "row", 0) or 0)
            by_row.setdefault(row, []).append(cell)
            label = (
                _probe_semantic_label(getattr(cell, "value", None))
                if row <= 64
                else None
            )
            if label is not None:
                labels.add(label)
                label_rows.add(row)
        header_rows = sorted(row for row in label_rows if row <= 64)
        header_band_rows = 0
        if header_rows:
            first = header_rows[0]
            header_band_rows = min(
                8, max(1, sum(1 for row in header_rows if row <= first + 2))
            )
            table_layout.add("header_band")
        occupancy = len(cells) / max(1, max_row * max_column)
        if occupancy >= 0.45:
            table_layout.add("dense")
        elif occupancy < 0.12:
            table_layout.add("sparse")
        if any(getattr(cell, "formula", None) for cell in cells[:20_000]):
            table_layout.add("formula_cells")
        merged_ranges = list(getattr(sheet, "merged_ranges", None) or ())[:10_000]
        if merged_ranges:
            table_layout.add("merged_cells")
        ordered_rows = sorted(by_row)
        if any(right - left > 1 for left, right in pairwise(ordered_rows)):
            table_layout.add("blank_separators")
        if (
            len(ordered_rows) > 1
            and sum(len(by_row[row]) for row in ordered_rows[:2]) <= 2
        ):
            table_layout.add("title_band")
        sections = 1 + sum(
            1 for left, right in pairwise(ordered_rows) if right - left > 1
        )
        if sections > 1:
            table_layout.add("multiple_sections")
        compact_labels = {
            _probe_compact(getattr(cell, "value", None)) for cell in cells[:2000]
        }
        if any(label in compact_labels for label in ("备注", "说明", "note", "notes")):
            table_layout.add("notes")

        if labels and max_column <= 4 and max_row >= max_column * 2:
            orientation: TableOrientation = "key_value"
            table_layout.add("key_value_prefix")
        elif max_row >= max_column * 2:
            orientation = "records_by_row"
            table_layout.add("records")
        elif max_column >= max_row * 2:
            orientation = "records_by_column"
            table_layout.add("records")
        elif max_row > 1 or max_column > 1:
            orientation = "matrix"
        else:
            orientation = "unknown"
        shape = TabularLayoutTableShape(
            table_index=table_index,
            row_bucket=_probe_bucket(max_row),
            column_bucket=_probe_bucket(max_column),
            row_count=max_row,
            column_count=max_column,
            orientation=orientation,
            header_band_rows=header_band_rows,
            header_rows=tuple(header_rows[:8]),
            section_count=min(sections, 10_000),
            merged_range_count=len(merged_ranges),
            layout_tokens=tuple(sorted(table_layout)),
            semantic_labels=tuple(sorted(labels)),
        )
        tables.append(shape)
        global_layout.update(table_layout)
        global_labels.update(labels)

    if len(tables) > 1:
        global_layout.add("multi_sheet")
    return TabularLayoutProbe(
        source_kind=_probe_source_kind(envelope, source_kind),
        tables=tuple(tables),
        layout_tokens=tuple(sorted(global_layout)),
        semantic_labels=tuple(sorted(global_labels)),
        document_type_hint=document_type_hint,
        document_subtype_hint=document_subtype_hint,
        model_fingerprint=model_fingerprint,
        contract_revision=contract_revision,
        interpreter_revision=interpreter_revision,
    )


__all__ = [
    "CountBucket",
    "DocumentShape",
    "ExecutionOutcome",
    "ProfileStatus",
    "RouteAction",
    "RouteReason",
    "TableOrientation",
    "TabularLayoutProbe",
    "TabularLayoutSignature",
    "TabularLayoutTableShape",
    "TabularSourceKind",
    "build_tabular_layout_probe",
    "build_tabular_layout_signature",
]
