"""Bounded visual evidence enrichment for embedded document assets.

The source asset inventory remains the authority for content identity and
occurrence provenance.  This module materializes one verified temporary file
per unique asset, delegates recognition to an injected async parser, and
merges the returned provider-neutral evidence without changing the source
document contract.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import mimetypes
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from math import ceil
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from time import monotonic
from typing import Any, Protocol
from zipfile import BadZipFile, ZipFile

import fitz

from .evidence import DocumentEvidence, EvidencePage
from .source_asset_inventory import SourceAsset, SourceAssetInventory


class VisualAssetEvidenceError(RuntimeError):
    """The inventory cannot safely be applied to the supplied source."""


class VisualAssetBatchContractError(VisualAssetEvidenceError):
    """A parser batch result cannot be mapped safely to the submitted assets."""


class AsyncAssetParser(Protocol):
    """Minimal parser contract shared by MinerU and test adapters."""

    async def parse(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> Any: ...


class AsyncBatchAssetParser(Protocol):
    """Optional vectorized parser contract used when a provider supports it."""

    async def parse_many(
        self,
        paths: Sequence[Path],
        *,
        original_filenames: Sequence[str | None] | None = None,
        concurrency: int = 1,
        timeout_seconds: float | None = None,
    ) -> Mapping[str | Path, Any] | Sequence[Any]: ...


@dataclass(slots=True)
class _AssetOutcome:
    asset: SourceAsset
    status: str
    reason: str | None = None
    failure_type: str | None = None
    elapsed_ms: float = 0.0
    evidence: DocumentEvidence | None = None


@dataclass(slots=True, frozen=True)
class _MaterializedAsset:
    asset: SourceAsset
    path: Path


_MIME_SUFFIXES = {
    "image/bmp": ".bmp",
    "image/emf": ".emf",
    "image/gif": ".gif",
    "image/jpeg": ".jpg",
    "image/jp2": ".jp2",
    "image/png": ".png",
    "image/svg+xml": ".svg",
    "image/tiff": ".tiff",
    "image/webp": ".webp",
    "image/wmf": ".wmf",
}
_SAFE_ASSET_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_SAFE_ASSET_SUFFIX = re.compile(r"\.[A-Za-z0-9]{1,10}\Z")
_CANCELLATION_GRACE_SECONDS = 5.0


def _consume_task_result(task: asyncio.Future[Any]) -> None:
    if not task.cancelled():
        task.exception()


async def _await_with_hard_deadline(value: Any, *, timeout_seconds: float) -> Any:
    """Bound both provider execution and cancellation cleanup."""

    cleanup_grace = min(
        _CANCELLATION_GRACE_SECONDS,
        max(timeout_seconds * 0.1, 0.01),
    )
    execution_timeout = max(timeout_seconds - cleanup_grace, 0.001)
    task = asyncio.ensure_future(value)
    try:
        done, _pending = await asyncio.wait({task}, timeout=execution_timeout)
    except asyncio.CancelledError:
        task.cancel()
        done, _pending = await asyncio.wait({task}, timeout=cleanup_grace)
        if task not in done:
            task.add_done_callback(_consume_task_result)
        raise
    if task in done:
        return task.result()

    task.cancel()
    done, _pending = await asyncio.wait({task}, timeout=cleanup_grace)
    if task in done:
        _consume_task_result(task)
    else:
        task.add_done_callback(_consume_task_result)
    raise TimeoutError("visual asset parser exceeded its hard deadline")


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_source(source: Path, inventory: SourceAssetInventory) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    if source.stat().st_size != inventory.source_byte_size:
        raise VisualAssetEvidenceError("source byte size does not match inventory")
    if _sha256_path(source) != inventory.source_sha256:
        raise VisualAssetEvidenceError("source SHA-256 does not match inventory")


def _safe_package_part(part: str, *, prefix: str) -> str:
    candidate = PurePosixPath(part)
    if (
        not part
        or "\x00" in part
        or "\\" in part
        or candidate.is_absolute()
        or ".." in candidate.parts
        or not part.startswith(prefix)
    ):
        raise VisualAssetEvidenceError(f"unsafe asset locator: {part!r}")
    return part


def _verify_payload(payload: bytes, asset: SourceAsset, *, part: str) -> None:
    if len(payload) != asset.byte_size:
        raise VisualAssetEvidenceError(
            f"asset byte size mismatch for locator {part!r}"
        )
    if hashlib.sha256(payload).hexdigest() != asset.sha256:
        raise VisualAssetEvidenceError(f"asset SHA-256 mismatch for locator {part!r}")


def _read_pdf_asset(source: Path, asset: SourceAsset) -> bytes:
    try:
        document = fitz.open(source)
    except Exception as exc:
        raise VisualAssetEvidenceError("invalid PDF source") from exc
    selected: bytes | None = None
    try:
        for part in asset.parts:
            prefix = "pdf:xref:"
            if not part.startswith(prefix):
                raise VisualAssetEvidenceError(f"invalid PDF asset locator: {part!r}")
            raw_xref = part[len(prefix) :]
            if not raw_xref.isdecimal() or int(raw_xref) <= 0:
                raise VisualAssetEvidenceError(f"invalid PDF xref locator: {part!r}")
            try:
                extracted = document.extract_image(int(raw_xref))
            except Exception as exc:
                raise VisualAssetEvidenceError(
                    f"failed to extract PDF asset locator {part!r}"
                ) from exc
            payload = extracted.get("image")
            if not isinstance(payload, bytes):
                raise VisualAssetEvidenceError(
                    f"PDF asset locator has no binary payload: {part!r}"
                )
            _verify_payload(payload, asset, part=part)
            if selected is None:
                selected = payload
    finally:
        document.close()
    if selected is None:
        raise VisualAssetEvidenceError("PDF asset has no locators")
    return selected


def _read_package_asset(
    source: Path,
    asset: SourceAsset,
    *,
    prefix: str,
) -> bytes:
    try:
        package = ZipFile(source, "r")
    except BadZipFile as exc:
        raise VisualAssetEvidenceError("invalid OOXML source") from exc
    selected: bytes | None = None
    try:
        names = package.namelist()
        for part in asset.parts:
            safe_part = _safe_package_part(part, prefix=prefix)
            if names.count(safe_part) != 1:
                raise VisualAssetEvidenceError(
                    f"asset locator is missing or duplicated: {safe_part!r}"
                )
            payload = package.read(safe_part)
            _verify_payload(payload, asset, part=safe_part)
            if selected is None:
                selected = payload
    finally:
        package.close()
    if selected is None:
        raise VisualAssetEvidenceError("OOXML asset has no locators")
    return selected


def _read_asset_payload(
    source: Path,
    inventory: SourceAssetInventory,
    asset: SourceAsset,
) -> bytes:
    if inventory.source_kind == "pdf":
        return _read_pdf_asset(source, asset)
    if inventory.source_kind == "docx":
        return _read_package_asset(source, asset, prefix="word/media/")
    if inventory.source_kind in {"xlsx", "xlsm"}:
        return _read_package_asset(source, asset, prefix="xl/media/")
    raise VisualAssetEvidenceError(
        f"visual asset materialization is unsupported for {inventory.source_kind}"
    )


def _asset_suffix(asset: SourceAsset) -> str:
    suffix = _MIME_SUFFIXES.get(asset.mime_type.casefold())
    if suffix and _SAFE_ASSET_SUFFIX.fullmatch(suffix):
        return suffix.casefold()
    guessed = mimetypes.guess_extension(asset.mime_type, strict=False)
    if guessed and _SAFE_ASSET_SUFFIX.fullmatch(guessed):
        return guessed.casefold()
    for part in asset.parts:
        candidate = PurePosixPath(part).suffix
        if candidate and _SAFE_ASSET_SUFFIX.fullmatch(candidate):
            return candidate.casefold()
    return ".bin"


def _materialize_asset(
    source: Path,
    inventory: SourceAssetInventory,
    asset: SourceAsset,
    *,
    temporary_root: Path,
) -> _MaterializedAsset:
    if not _SAFE_ASSET_SHA256.fullmatch(asset.sha256):
        raise VisualAssetEvidenceError("asset SHA-256 is not canonical")
    payload = _read_asset_payload(source, inventory, asset)
    temporary_path = (
        temporary_root / f"{asset.sha256}{_asset_suffix(asset)}"
    ).resolve()
    try:
        temporary_path.relative_to(temporary_root.resolve())
    except ValueError as exc:
        raise VisualAssetEvidenceError(
            "asset temporary path escaped the bounded directory"
        ) from exc
    temporary_path.write_bytes(payload)
    if temporary_path.stat().st_size != asset.byte_size:
        raise VisualAssetEvidenceError("materialized asset byte size changed")
    if _sha256_path(temporary_path) != asset.sha256:
        raise VisualAssetEvidenceError("materialized asset SHA-256 changed")
    return _MaterializedAsset(asset=asset, path=temporary_path)


def _coerce_evidence(value: Any) -> DocumentEvidence:
    if isinstance(value, DocumentEvidence):
        return value
    evidence = getattr(value, "evidence", None)
    if isinstance(evidence, DocumentEvidence):
        return evidence
    raise TypeError("asset parser must return DocumentEvidence or an evidence result")


def _asset_context(asset: SourceAsset) -> dict[str, Any]:
    return {
        "asset_id": asset.asset_id,
        "asset_sha256": asset.sha256,
        "asset_parts": list(asset.parts),
        "asset_source_refs": [
            reference.model_dump(mode="json", exclude_none=True)
            for reference in asset.source_refs
        ],
    }


def _annotated_page(
    page: EvidencePage,
    *,
    asset: SourceAsset,
    parser_evidence: DocumentEvidence,
    page_number: int,
    page_index: int,
) -> EvidencePage:
    context = _asset_context(asset)
    parser_page_number = page.page_number
    parser_page_index = page.page_index
    parser_context = {
        **context,
        "asset_parser_backend": parser_evidence.backend,
        "asset_parser_backend_version": parser_evidence.backend_version,
        "asset_parser_page_number": parser_page_number,
        "asset_parser_page_index": parser_page_index,
    }
    page_prefix = f"asset:{asset.sha256}/p{parser_page_index}"
    payload = page.model_dump(mode="python")
    blocks: list[dict[str, Any]] = []
    for block_index, block in enumerate(page.blocks):
        item = block.model_dump(mode="python")
        original_id = block.block_id or f"block:{block_index}"
        item.update(parser_context)
        item["asset_parser_block_id"] = original_id
        item["block_id"] = f"{page_prefix}/{original_id}"
        blocks.append(item)
    tables: list[dict[str, Any]] = []
    for table_index, table in enumerate(page.tables):
        item = table.model_dump(mode="python")
        original_id = table.table_id or f"table:{table_index}"
        table_id = f"{page_prefix}/{original_id}"
        cells: list[dict[str, Any]] = []
        for cell_index, cell in enumerate(table.cells):
            cell_payload = cell.model_dump(mode="python")
            cell_payload.update(parser_context)
            cell_payload["asset_cell_id"] = (
                f"{table_id}/cell:{cell.row}:{cell.column}:{cell_index}"
            )
            cells.append(cell_payload)
        item.update(parser_context)
        item["asset_parser_table_id"] = original_id
        item["table_id"] = table_id
        item["cells"] = cells
        tables.append(item)
    raw = dict(page.raw)
    raw["visual_asset"] = {
        **parser_context,
        "asset_page_id": page_prefix,
    }
    payload.update(parser_context)
    payload.update(
        {
            "asset_page_id": page_prefix,
            "page_number": page_number,
            "page_index": page_index,
            "blocks": blocks,
            "tables": tables,
            "raw": raw,
        }
    )
    return EvidencePage.model_validate(payload)


def _outcome_payload(outcome: _AssetOutcome) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "asset_id": outcome.asset.asset_id,
        "asset_sha256": outcome.asset.sha256,
        "asset_parts": list(outcome.asset.parts),
        "asset_source_refs": [
            reference.model_dump(mode="json", exclude_none=True)
            for reference in outcome.asset.source_refs
        ],
        "asset_byte_size": outcome.asset.byte_size,
        "source_reference_count": len(outcome.asset.source_refs),
        "status": outcome.status,
        "elapsed_ms": round(outcome.elapsed_ms, 3),
    }
    if outcome.reason is not None:
        payload["reason"] = outcome.reason
    if outcome.failure_type is not None:
        payload["failure_type"] = outcome.failure_type
    if outcome.evidence is not None:
        payload["parser"] = outcome.evidence.summary()
    return payload


async def _parse_materialized_asset(
    materialized: _MaterializedAsset,
    parser: AsyncAssetParser,
    *,
    timeout_seconds: float,
    semaphore: asyncio.Semaphore,
) -> _AssetOutcome:
    started = monotonic()
    asset = materialized.asset
    try:
        async with semaphore:
            parsed = await _await_with_hard_deadline(
                parser.parse(
                    materialized.path,
                    original_filename=materialized.path.name,
                ),
                timeout_seconds=timeout_seconds,
            )
        return _AssetOutcome(
            asset=asset,
            status="success",
            elapsed_ms=(monotonic() - started) * 1000,
            evidence=_coerce_evidence(parsed),
        )
    except TimeoutError:
        return _AssetOutcome(
            asset=asset,
            status="failed",
            reason="timeout",
            failure_type="TimeoutError",
            elapsed_ms=(monotonic() - started) * 1000,
        )
    except Exception as exc:  # noqa: BLE001 - isolate each external asset parse
        return _AssetOutcome(
            asset=asset,
            status="failed",
            reason="parser_or_locator_failure",
            failure_type=exc.__class__.__name__,
            elapsed_ms=(monotonic() - started) * 1000,
        )


def _batch_parser_method(parser: AsyncAssetParser) -> Any | None:
    for name in ("parse_many", "parse_batch"):
        candidate = getattr(parser, name, None)
        if callable(candidate):
            return candidate
    return None


def _accepts_keyword(method: Any, name: str) -> bool:
    try:
        parameters = inspect.signature(method).parameters.values()
    except (TypeError, ValueError):
        return False
    return any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD
        or (
            parameter.name == name
            and parameter.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.KEYWORD_ONLY,
            )
        )
        for parameter in parameters
    )


def _batch_key_path(key: Any, *, temporary_root: Path) -> Path:
    if not isinstance(key, (str, Path)):
        raise VisualAssetBatchContractError(
            "batch result keys must be filesystem paths"
        )
    candidate = Path(key)
    if not candidate.is_absolute():
        candidate = temporary_root / candidate
    resolved = candidate.resolve()
    try:
        resolved.relative_to(temporary_root.resolve())
    except ValueError as exc:
        raise VisualAssetBatchContractError(
            "batch result path escaped the temporary directory"
        ) from exc
    return resolved


def _normalize_batch_result(
    value: Any,
    materialized_assets: Sequence[_MaterializedAsset],
    *,
    temporary_root: Path,
) -> list[Any | None]:
    if isinstance(value, Mapping):
        expected = {item.path.resolve() for item in materialized_assets}
        normalized: dict[Path, Any] = {}
        for raw_key, item in value.items():
            key = _batch_key_path(raw_key, temporary_root=temporary_root)
            if key not in expected:
                raise VisualAssetBatchContractError(
                    "batch result contains an unknown input path"
                )
            if key in normalized:
                raise VisualAssetBatchContractError(
                    "batch result contains a duplicate input path"
                )
            normalized[key] = item
        return [normalized.get(item.path.resolve()) for item in materialized_assets]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        if len(value) > len(materialized_assets):
            raise VisualAssetBatchContractError(
                "batch result contains more entries than submitted assets"
            )
        return [
            value[index] if index < len(value) else None
            for index in range(len(materialized_assets))
        ]
    raise VisualAssetBatchContractError(
        "batch parser must return a path mapping or an ordered sequence"
    )


def _failed_batch_outcomes(
    materialized_assets: Sequence[_MaterializedAsset],
    *,
    reason: str,
    failure_type: str,
    elapsed_ms: float,
) -> list[_AssetOutcome]:
    return [
        _AssetOutcome(
            asset=item.asset,
            status="failed",
            reason=reason,
            failure_type=failure_type,
            elapsed_ms=elapsed_ms,
        )
        for item in materialized_assets
    ]


async def _parse_materialized_batch(
    materialized_assets: Sequence[_MaterializedAsset],
    parser: AsyncAssetParser,
    batch_method: Any,
    *,
    temporary_root: Path,
    timeout_seconds: float,
    concurrency: int,
) -> list[_AssetOutcome]:
    started = monotonic()
    paths = [item.path for item in materialized_assets]
    original_filenames = [item.path.name for item in materialized_assets]
    try:
        call_kwargs: dict[str, Any] = {"original_filenames": original_filenames}
        if _accepts_keyword(batch_method, "concurrency"):
            call_kwargs["concurrency"] = concurrency
        if _accepts_keyword(batch_method, "timeout_seconds"):
            cancellation_reserve = min(
                _CANCELLATION_GRACE_SECONDS,
                max(timeout_seconds * 0.1, 0.01),
            )
            provider_window = max(timeout_seconds - cancellation_reserve, 0.001)
            result_discovery_reserve = min(
                _CANCELLATION_GRACE_SECONDS,
                max(provider_window * 0.1, 0.01),
            )
            call_kwargs["timeout_seconds"] = max(
                provider_window - result_discovery_reserve,
                0.001,
            )
        pending = batch_method(paths, **call_kwargs)
        if not inspect.isawaitable(pending):
            raise VisualAssetBatchContractError(
                "batch parser method must return an awaitable"
            )
        raw_result = await _await_with_hard_deadline(
            pending,
            timeout_seconds=timeout_seconds,
        )
        values = _normalize_batch_result(
            raw_result,
            materialized_assets,
            temporary_root=temporary_root,
        )
    except TimeoutError:
        elapsed_ms = (monotonic() - started) * 1000
        return _failed_batch_outcomes(
            materialized_assets,
            reason="timeout",
            failure_type="TimeoutError",
            elapsed_ms=elapsed_ms,
        )
    except Exception as exc:  # noqa: BLE001 - isolate a failed provider batch
        elapsed_ms = (monotonic() - started) * 1000
        return _failed_batch_outcomes(
            materialized_assets,
            reason="batch_parser_failure",
            failure_type=exc.__class__.__name__,
            elapsed_ms=elapsed_ms,
        )

    elapsed_ms = (monotonic() - started) * 1000
    outcomes: list[_AssetOutcome] = []
    for materialized, value in zip(materialized_assets, values, strict=True):
        if value is None:
            outcomes.append(
                _AssetOutcome(
                    asset=materialized.asset,
                    status="failed",
                    reason="batch_result_missing",
                    failure_type="BatchResultMissingError",
                    elapsed_ms=elapsed_ms,
                )
            )
            continue
        if isinstance(value, Exception):
            outcomes.append(
                _AssetOutcome(
                    asset=materialized.asset,
                    status="failed",
                    reason="parser_or_locator_failure",
                    failure_type=value.__class__.__name__,
                    elapsed_ms=elapsed_ms,
                )
            )
            continue
        try:
            parsed_evidence = _coerce_evidence(value)
        except Exception as exc:  # noqa: BLE001 - isolate one malformed item
            outcomes.append(
                _AssetOutcome(
                    asset=materialized.asset,
                    status="failed",
                    reason="parser_or_locator_failure",
                    failure_type=exc.__class__.__name__,
                    elapsed_ms=elapsed_ms,
                )
            )
            continue
        outcomes.append(
            _AssetOutcome(
                asset=materialized.asset,
                status="success",
                elapsed_ms=elapsed_ms,
                evidence=parsed_evidence,
            )
        )
    return outcomes


async def enrich_visual_asset_evidence(
    source_path: str | Path,
    evidence: DocumentEvidence,
    inventory: SourceAssetInventory,
    parser: AsyncAssetParser,
    *,
    max_assets: int,
    max_asset_bytes: int,
    timeout_seconds: float,
    concurrency: int = 1,
) -> DocumentEvidence:
    """Parse verified embedded assets and append stable, attributed evidence.

    Limits are mandatory so callers cannot accidentally submit an unbounded
    workbook image set.  Failures are recorded per asset and never discard the
    base evidence or the complete inventory manifest.
    """

    if max_assets < 0:
        raise ValueError("max_assets must be greater than or equal to zero")
    if max_asset_bytes < 0:
        raise ValueError("max_asset_bytes must be greater than or equal to zero")
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be greater than zero")
    if concurrency < 1:
        raise ValueError("concurrency must be greater than or equal to one")

    source = Path(source_path)
    _validate_source(source, inventory)
    started = monotonic()
    selected_slots: list[tuple[int, SourceAsset]] = []
    outcomes: list[_AssetOutcome | None] = []
    seen_sha256: set[str] = set()
    unique_position = 0
    for asset in inventory.assets:
        if asset.sha256 in seen_sha256:
            outcomes.append(
                _AssetOutcome(
                    asset=asset,
                    status="skipped",
                    reason="duplicate_sha256",
                )
            )
            continue
        seen_sha256.add(asset.sha256)
        if unique_position >= max_assets:
            outcomes.append(
                _AssetOutcome(asset=asset, status="skipped", reason="max_assets")
            )
            unique_position += 1
            continue
        unique_position += 1
        if asset.byte_size > max_asset_bytes:
            outcomes.append(
                _AssetOutcome(
                    asset=asset,
                    status="skipped",
                    reason="max_asset_bytes",
                )
            )
            continue
        outcomes.append(None)
        selected_slots.append((len(outcomes) - 1, asset))

    with TemporaryDirectory(prefix="m1-visual-assets-") as temporary_directory:
        temporary_root = Path(temporary_directory).resolve()
        materialized_slots: list[tuple[int, _MaterializedAsset]] = []
        for slot, asset in selected_slots:
            materialization_started = monotonic()
            try:
                materialized = _materialize_asset(
                    source,
                    inventory,
                    asset,
                    temporary_root=temporary_root,
                )
            except Exception as exc:  # noqa: BLE001 - isolate unsafe asset locators
                outcomes[slot] = _AssetOutcome(
                    asset=asset,
                    status="failed",
                    reason="parser_or_locator_failure",
                    failure_type=exc.__class__.__name__,
                    elapsed_ms=(monotonic() - materialization_started) * 1000,
                )
                continue
            materialized_slots.append((slot, materialized))

        materialized_assets = [item for _slot, item in materialized_slots]
        batch_method = _batch_parser_method(parser)
        if materialized_assets and batch_method is not None:
            parsed_outcomes = await _parse_materialized_batch(
                materialized_assets,
                parser,
                batch_method,
                temporary_root=temporary_root,
                timeout_seconds=timeout_seconds,
                concurrency=concurrency,
            )
        else:
            semaphore = asyncio.Semaphore(concurrency)
            execution_rounds = ceil(len(materialized_assets) / concurrency)
            per_asset_timeout = timeout_seconds / max(execution_rounds, 1)
            parsed_outcomes = await asyncio.gather(
                *(
                    _parse_materialized_asset(
                        item,
                        parser,
                        timeout_seconds=per_asset_timeout,
                        semaphore=semaphore,
                    )
                    for item in materialized_assets
                )
            )
        for (slot, _materialized), outcome in zip(
            materialized_slots,
            parsed_outcomes,
            strict=True,
        ):
            outcomes[slot] = outcome

    if any(outcome is None for outcome in outcomes):
        raise VisualAssetEvidenceError("visual asset outcome accounting is incomplete")
    final_outcomes = [outcome for outcome in outcomes if outcome is not None]
    result = evidence.model_copy(deep=True)
    next_page_number = max((page.page_number for page in result.pages), default=0) + 1
    next_page_index = max((page.page_index for page in result.pages), default=-1) + 1
    for outcome in final_outcomes:
        if outcome.status != "success" or outcome.evidence is None:
            if outcome.status == "failed":
                result.warnings.append(
                    "visual_asset_enrichment_failed:"
                    f"{outcome.asset.sha256}:{outcome.reason}:"
                    f"{outcome.failure_type or 'UnknownError'}"
                )
            continue
        for parser_page in outcome.evidence.pages:
            result.pages.append(
                _annotated_page(
                    parser_page,
                    asset=outcome.asset,
                    parser_evidence=outcome.evidence,
                    page_number=next_page_number,
                    page_index=next_page_index,
                )
            )
            next_page_number += 1
            next_page_index += 1

    result.warnings = list(dict.fromkeys(result.warnings))
    status_payloads = [_outcome_payload(outcome) for outcome in final_outcomes]
    result.raw = dict(result.raw)
    result.raw["source_asset_inventory"] = inventory.model_dump(mode="json")
    result.raw["visual_asset_enrichment"] = {
        "schema_version": "m1.visual-asset-evidence.v1",
        "elapsed_ms": round((monotonic() - started) * 1000, 3),
        "max_assets": max_assets,
        "max_asset_bytes": max_asset_bytes,
        "timeout_seconds": timeout_seconds,
        "concurrency": concurrency,
        "asset_count": len(status_payloads),
        "success_count": sum(item["status"] == "success" for item in status_payloads),
        "failed_count": sum(item["status"] == "failed" for item in status_payloads),
        "skipped_count": sum(item["status"] == "skipped" for item in status_payloads),
        "assets": status_payloads,
    }
    return result


__all__ = [
    "AsyncAssetParser",
    "AsyncBatchAssetParser",
    "VisualAssetBatchContractError",
    "VisualAssetEvidenceError",
    "enrich_visual_asset_evidence",
]
