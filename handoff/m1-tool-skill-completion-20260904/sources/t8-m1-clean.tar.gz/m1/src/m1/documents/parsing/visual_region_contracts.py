"""Closed contracts shared by governed visual-region routing components."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Sequence
from enum import StrEnum
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

VISUAL_REGION_CONTRACT_REVISION = "m1.visual-region.v1"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _normalized_sha256(value: object) -> str:
    digest = str(value or "").strip().casefold()
    if _SHA256_RE.fullmatch(digest) is None:
        raise ValueError("visual asset identity must be a SHA-256 digest")
    return digest


class VisualRegionRole(StrEnum):
    """Closed visual-region roles understood by downstream M1 code."""

    PRODUCT = "product"
    DOCUMENT_HEADER = "document_header"
    DOCUMENT_FOOTER = "document_footer"
    ENGINEERING_DRAWING = "engineering_drawing"
    CHART = "chart"
    STAMP = "stamp"
    SIGNATURE = "signature"
    LOGO = "logo"
    DECORATIVE = "decorative"


class VisualRegionSourceKind(StrEnum):
    SPREADSHEET_ANCHOR = "spreadsheet_anchor"
    PDF_FIGURE = "pdf_figure"
    OFFICE_SHAPE = "office_shape"
    PARSER_REGION = "parser_region"


class VisualPositionBucket(StrEnum):
    START = "start"
    CENTER = "center"
    END = "end"
    SPANNING = "spanning"
    UNKNOWN = "unknown"


class VisualAreaBucket(StrEnum):
    TINY = "tiny"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    DOMINANT = "dominant"
    UNKNOWN = "unknown"


class VisualAspectBucket(StrEnum):
    PORTRAIT = "portrait"
    SQUARE = "square"
    LANDSCAPE = "landscape"
    WIDE = "wide"
    UNKNOWN = "unknown"


class VisualGeometryReason(StrEnum):
    TABLE_IMAGE_COLUMN = "table_image_column"
    TABLE_BODY = "table_body"
    BEFORE_TABLE_HEADER = "before_table_header"
    AFTER_TABLE_BODY = "after_table_body"
    NO_COMPATIBLE_REGION = "no_compatible_region"
    AMBIGUOUS_OVERLAP = "ambiguous_overlap"
    INSUFFICIENT_GEOMETRY = "insufficient_geometry"


class VisualGeometryAssessment(BaseModel):
    """Authoritative output of deterministic geometry classification."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    role: VisualRegionRole | None = None
    reason: VisualGeometryReason

    @property
    def resolved(self) -> bool:
        return self.role is not None


class VisualRegionTopology(BaseModel):
    """Value-free topology supplied to the optional small-model selector."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    contract_revision: Literal["m1.visual-region.v1"] = VISUAL_REGION_CONTRACT_REVISION
    source_kind: VisualRegionSourceKind
    horizontal_position: VisualPositionBucket = VisualPositionBucket.UNKNOWN
    vertical_position: VisualPositionBucket = VisualPositionBucket.UNKNOWN
    area_bucket: VisualAreaBucket = VisualAreaBucket.UNKNOWN
    aspect_bucket: VisualAspectBucket = VisualAspectBucket.UNKNOWN
    overlaps_table_body: bool = False
    overlaps_text_block: bool = False
    repeated_across_pages: bool = False
    has_nearby_identifier_slot: bool = False

    def exact_fingerprint(self) -> str:
        payload = json.dumps(
            self.model_dump(mode="json"),
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("ascii")).hexdigest()

    def embedding_text(self) -> str:
        """Return a closed, value-free representation for route retrieval."""

        values = self.model_dump(mode="json")
        return "visual_region " + " ".join(
            f"{key}={str(values[key]).casefold()}" for key in sorted(values)
        )


def visual_topology_similarity(
    first: VisualRegionTopology,
    second: VisualRegionTopology,
) -> float:
    """Compare only normalized geometry; incompatible sources score zero."""

    if first.source_kind is not second.source_kind:
        return 0.0
    weighted_fields: tuple[tuple[str, float], ...] = (
        ("horizontal_position", 0.15),
        ("vertical_position", 0.15),
        ("area_bucket", 0.15),
        ("aspect_bucket", 0.15),
        ("overlaps_table_body", 0.10),
        ("overlaps_text_block", 0.10),
        ("repeated_across_pages", 0.10),
        ("has_nearby_identifier_slot", 0.10),
    )
    return sum(
        weight
        for field_name, weight in weighted_fields
        if getattr(first, field_name) == getattr(second, field_name)
    )


class VisualRegionSimilarCase(BaseModel):
    """One server-side, reviewed case available for approximate reuse."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    case_id: str = Field(min_length=1, max_length=128)
    asset_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    role: VisualRegionRole
    source_kind: VisualRegionSourceKind
    active: bool = True
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    geometry_similarity: float = Field(ge=0.0, le=1.0)
    review_success_rate: float = Field(default=1.0, ge=0.0, le=1.0)

    @field_validator("asset_sha256", mode="before")
    @classmethod
    def normalize_asset_sha256(cls, value: object) -> str:
        return _normalized_sha256(value)


class VisualRegionExactCase(BaseModel):
    """One reviewed ACTIVE profile returned by the exact-fingerprint lookup."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    case_id: str = Field(min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-f]{64}$")
    asset_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    topology: VisualRegionTopology
    role: VisualRegionRole
    active: Literal[True] = True
    observation_count: int = Field(ge=3)
    success_count: int = Field(ge=3)
    failure_count: Literal[0] = 0
    review_success_rate: float = Field(ge=0.0, le=1.0)

    @field_validator("exact_fingerprint", "asset_sha256", mode="before")
    @classmethod
    def normalize_fingerprints(cls, value: object) -> str:
        return _normalized_sha256(value)

    @model_validator(mode="after")
    def validate_review_history(self) -> Self:
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("exact visual case has inconsistent review counters")
        if self.review_success_rate != 1.0:
            raise ValueError("exact visual case requires a clean review history")
        return self


class VisualRegionCandidateProposal(BaseModel):
    """Validated proposal that a store must persist as inactive."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    asset_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    topology: VisualRegionTopology
    role: VisualRegionRole
    embedding: tuple[float, ...]
    embedding_model: str = Field(min_length=1, max_length=256)
    embedding_dimensions: int = Field(ge=1)
    created_by: str = Field(min_length=1, max_length=256)

    @field_validator("asset_sha256", mode="before")
    @classmethod
    def normalize_asset_sha256(cls, value: object) -> str:
        return _normalized_sha256(value)

    @model_validator(mode="after")
    def validate_proposal(self) -> Self:
        if len(self.embedding) != self.embedding_dimensions:
            raise ValueError("visual candidate embedding dimensions do not match")
        if not all(math.isfinite(value) for value in self.embedding):
            raise ValueError("visual candidate embedding contains non-finite values")
        return self

    @classmethod
    def build(
        cls,
        *,
        tenant_id: str,
        asset_sha256: str,
        topology: VisualRegionTopology,
        role: VisualRegionRole,
        embedding: Sequence[float],
        embedding_model: str,
        embedding_dimensions: int,
        created_by: str,
    ) -> VisualRegionCandidateProposal:
        fingerprint = topology.exact_fingerprint()
        asset_digest = _normalized_sha256(asset_sha256)
        return cls(
            tenant_id=tenant_id,
            profile_key=(
                f"visual:{topology.source_kind.value}:{role.value}:"
                f"{asset_digest[:16]}:{fingerprint[:16]}"
            ),
            asset_sha256=asset_digest,
            topology=topology,
            role=role,
            embedding=tuple(float(value) for value in embedding),
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            created_by=created_by,
        )


class VisualRegionExecutionObservation(BaseModel):
    """Reviewed replay evidence used by explicit profile activation."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: Literal["success", "failure"]
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome == "success":
            if not self.validation_passed or not self.reviewed_by.strip():
                raise ValueError(
                    "successful visual samples require reviewed validation"
                )
            if len(self.review_note_sha256) != 64:
                raise ValueError("successful visual samples require a review-note hash")
        elif not self.error_code.strip():
            raise ValueError("failed visual samples require an error code")
        return self


class VisualRegionRankedCase(BaseModel):
    """Internal ranked case; the opaque case ID never reaches the model."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    case_id: str
    role: VisualRegionRole
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    geometry_similarity: float = Field(ge=0.0, le=1.0)
    review_success_rate: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class VisualRegionRoleOption(BaseModel):
    """One role explicitly authorized by the server for this region."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    role_index: int = Field(ge=0, le=8)
    role: VisualRegionRole


class VisualRegionCaseOption(BaseModel):
    """Selector-safe case projection addressed only by list index."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    candidate_index: int = Field(ge=0, le=4)
    role: VisualRegionRole
    vector_similarity: float | None = Field(default=None, ge=0.0, le=1.0)
    geometry_similarity: float = Field(ge=0.0, le=1.0)
    review_success_rate: float = Field(ge=0.0, le=1.0)
    fused_score: float = Field(ge=0.0, le=1.0)


class VisualRegionSelectionRequest(BaseModel):
    """Complete bounded model payload with no source content or identity."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.visual-region-selection.v1"] = (
        "m1.visual-region-selection.v1"
    )
    topology: VisualRegionTopology
    roles: tuple[VisualRegionRoleOption, ...] = Field(max_length=9)
    candidates: tuple[VisualRegionCaseOption, ...] = Field(max_length=5)

    @model_validator(mode="after")
    def validate_closed_options(self) -> Self:
        role_indices = [option.role_index for option in self.roles]
        if role_indices != list(range(len(role_indices))):
            raise ValueError("role indices must be consecutive from zero")
        roles = [option.role for option in self.roles]
        if len(roles) != len(set(roles)):
            raise ValueError("server-authorized roles must be unique")
        candidate_indices = [option.candidate_index for option in self.candidates]
        if candidate_indices != list(range(len(candidate_indices))):
            raise ValueError("candidate indices must be consecutive from zero")
        return self


VisualRegionModelAction = Literal[
    "select_role",
    "reuse_candidate",
    "review",
    "new_candidate",
]


class VisualRegionModelChoice(BaseModel):
    """Strict closed output; no free-form fact or role field is accepted."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: VisualRegionModelAction
    role_index: int | None = Field(default=None, ge=0, le=8)
    candidate_index: int | None = Field(default=None, ge=0, le=4)
    confidence: float = Field(ge=0.0, le=1.0)

    @model_validator(mode="after")
    def validate_choice(self) -> Self:
        if self.action == "select_role":
            if self.role_index is None or self.candidate_index is not None:
                raise ValueError("select_role requires only role_index")
        elif self.action == "reuse_candidate":
            if self.candidate_index is None or self.role_index is not None:
                raise ValueError("reuse_candidate requires only candidate_index")
        elif self.role_index is not None or self.candidate_index is not None:
            raise ValueError("review and new_candidate cannot include an index")
        return self


__all__ = [
    "VISUAL_REGION_CONTRACT_REVISION",
    "VisualAreaBucket",
    "VisualAspectBucket",
    "VisualGeometryAssessment",
    "VisualGeometryReason",
    "VisualPositionBucket",
    "VisualRegionCandidateProposal",
    "VisualRegionCaseOption",
    "VisualRegionExactCase",
    "VisualRegionExecutionObservation",
    "VisualRegionModelChoice",
    "VisualRegionRankedCase",
    "VisualRegionRole",
    "VisualRegionRoleOption",
    "VisualRegionSelectionRequest",
    "VisualRegionSimilarCase",
    "VisualRegionSourceKind",
    "VisualRegionTopology",
    "_normalized_sha256",
    "visual_topology_similarity",
]
