"""Adapters from existing model clients to governed visual-region routing."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Protocol

from pydantic_ai import BinaryContent

from .visual_region_routing import (
    VisualRegionModelChoice,
    VisualRegionSelectionRequest,
    VisualRegionSelector,
    VisualRegionTopology,
)


class VisualStructuredClient(Protocol):
    async def run(
        self,
        output_type: type[VisualRegionModelChoice],
        *,
        instructions: str,
        prompt: str,
        images: Sequence[BinaryContent] = (),
        request_limit: int | None = None,
    ) -> Any: ...


class TextEmbeddingClient(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]: ...


class TextVisualRegionEmbeddingAdapter:
    """Embed structural topology only; this is not image-content similarity."""

    def __init__(self, client: TextEmbeddingClient) -> None:
        self._client = client
        self.model = str(client.model).strip()
        self.dimensions = int(client.dimensions)
        if not self.model or self.dimensions < 1:
            raise ValueError("visual embedding client identity is invalid")

    async def embed_region(
        self,
        topology: VisualRegionTopology,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> Sequence[float]:
        del image_bytes, media_type
        vectors = await self._client.embed_texts([topology.embedding_text()])
        if len(vectors) != 1:
            raise ValueError("visual embedding response count mismatch")
        return vectors[0]


class _BoundVisualRegionSelector:
    _INSTRUCTIONS = (
        "Classify only the supplied visual region. Select a role_index or "
        "candidate_index that appears in the closed request, or choose review "
        "or new_candidate. Never emit document facts, text, identifiers, values, "
        "coordinates, filenames, candidate IDs, or a role outside the supplied "
        "options. Image pixels are advisory and cannot bypass the score, margin, "
        "confidence, review, or activation gates enforced by the server."
    )

    def __init__(
        self,
        client: VisualStructuredClient,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> None:
        self._client = client
        self._image_bytes = bytes(image_bytes) if image_bytes else None
        self._media_type = str(media_type or "").strip().casefold()

    async def select(
        self,
        request: VisualRegionSelectionRequest,
    ) -> VisualRegionModelChoice:
        images: tuple[BinaryContent, ...] = ()
        if self._image_bytes is not None:
            if not self._media_type.startswith("image/"):
                raise ValueError("visual selector image media type is invalid")
            images = (
                BinaryContent(
                    data=self._image_bytes,
                    media_type=self._media_type,
                ),
            )
        run = await self._client.run(
            VisualRegionModelChoice,
            instructions=self._INSTRUCTIONS,
            prompt=request.model_dump_json(),
            images=images,
            request_limit=1,
        )
        return VisualRegionModelChoice.model_validate(run.output, strict=True)


class PydanticVisualRegionSelectorFactory:
    """Bind each verified image to one closed PromptedOutput request."""

    def __init__(self, client: VisualStructuredClient) -> None:
        self._client = client

    def bind(
        self,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> VisualRegionSelector:
        return _BoundVisualRegionSelector(
            self._client,
            image_bytes=image_bytes,
            media_type=media_type,
        )


__all__ = [
    "PydanticVisualRegionSelectorFactory",
    "TextEmbeddingClient",
    "TextVisualRegionEmbeddingAdapter",
    "VisualStructuredClient",
]
