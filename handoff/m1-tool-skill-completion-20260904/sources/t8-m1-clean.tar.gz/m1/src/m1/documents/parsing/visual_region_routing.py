"""Governed routing for visual regions left unresolved by geometry.

The existing geometry classifier remains authoritative.  This module is a
value-free advisory layer for regions that classifier deliberately leaves
unresolved: it can reuse an active reviewed case, select one server-authorized
role, request review, or request observation of a new inactive candidate.

Pixels, filenames, source text, and extracted facts are intentionally absent
from every public model in this module.  A model response addresses closed
options by index and therefore cannot create a role, a candidate identifier,
or a document fact.
"""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping, Sequence
from typing import Any, Literal, Protocol, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .document_routing_status import (
    DocumentRoutingDependencyError,
    DocumentRoutingStatus,
)
from .visual_region_contracts import (
    VISUAL_REGION_CONTRACT_REVISION,
    VisualAreaBucket,
    VisualAspectBucket,
    VisualGeometryAssessment,
    VisualGeometryReason,
    VisualPositionBucket,
    VisualRegionCandidateProposal,
    VisualRegionCaseOption,
    VisualRegionExactCase,
    VisualRegionExecutionObservation,
    VisualRegionModelChoice,
    VisualRegionRankedCase,
    VisualRegionRole,
    VisualRegionRoleOption,
    VisualRegionSelectionRequest,
    VisualRegionSimilarCase,
    VisualRegionSourceKind,
    VisualRegionTopology,
    _normalized_sha256,
    visual_topology_similarity,
)


class VisualRegionSelector(Protocol):
    async def select(
        self,
        request: VisualRegionSelectionRequest,
    ) -> VisualRegionModelChoice | Mapping[str, Any]: ...


class VisualRegionSelectorFactory(Protocol):
    """Bind non-authoritative image bytes without adding them to the request."""

    def bind(
        self,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> VisualRegionSelector: ...


class VisualRegionEmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed_region(
        self,
        topology: VisualRegionTopology,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> Sequence[float]: ...


class VisualRegionRouteStore(Protocol):
    async def get_active_visual_region_case_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        source_kind: VisualRegionSourceKind,
        asset_sha256: str,
    ) -> VisualRegionExactCase | None: ...

    async def find_active_visual_region_cases(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        topology: VisualRegionTopology,
        asset_sha256: str,
        limit: int,
    ) -> Sequence[VisualRegionSimilarCase]: ...

    async def create_visual_region_candidate(
        self,
        proposal: VisualRegionCandidateProposal,
    ) -> Any: ...

    async def record_visual_region_execution_observation(
        self,
        observation: VisualRegionExecutionObservation,
    ) -> Any: ...


class VisualRegionRoutingPolicy(BaseModel):
    """Hard gates applied after, never delegated to, the model."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    vector_weight: float = Field(default=0.55, ge=0.0, le=1.0)
    geometry_weight: float = Field(default=0.35, ge=0.0, le=1.0)
    review_success_weight: float = Field(default=0.10, ge=0.0, le=1.0)
    candidate_request_min_score: float = Field(default=0.60, ge=0.0, le=1.0)
    candidate_reuse_min_score: float = Field(default=0.82, ge=0.0, le=1.0)
    candidate_reuse_min_margin: float = Field(default=0.08, ge=0.0, le=1.0)
    model_role_min_confidence: float = Field(default=0.90, ge=0.0, le=1.0)
    model_reuse_min_confidence: float = Field(default=0.85, ge=0.0, le=1.0)
    model_new_candidate_min_confidence: float = Field(default=0.85, ge=0.0, le=1.0)
    max_model_candidates: int = Field(default=5, ge=1, le=5)

    @model_validator(mode="after")
    def validate_policy(self) -> Self:
        numeric = (
            self.vector_weight,
            self.geometry_weight,
            self.review_success_weight,
            self.candidate_request_min_score,
            self.candidate_reuse_min_score,
            self.candidate_reuse_min_margin,
            self.model_role_min_confidence,
            self.model_reuse_min_confidence,
            self.model_new_candidate_min_confidence,
        )
        if not all(math.isfinite(value) for value in numeric):
            raise ValueError("visual routing weights and thresholds must be finite")
        if self.vector_weight + self.geometry_weight + self.review_success_weight <= 0:
            raise ValueError("at least one visual routing weight must be positive")
        if self.candidate_reuse_min_score < self.candidate_request_min_score:
            raise ValueError("reuse threshold cannot be lower than request threshold")
        return self


VisualRegionRouteAction = Literal["route", "review", "new_candidate"]
VisualRegionRouteReason = Literal[
    "deterministic_geometry",
    "exact_active_profile",
    "model_role_proposed_candidate",
    "model_candidate_selected",
    "model_requested_review",
    "model_requested_new_candidate",
    "no_closed_options",
    "selector_unavailable",
    "model_failure",
    "invalid_model_output",
    "model_role_confidence_below_threshold",
    "model_candidate_confidence_below_threshold",
    "model_new_candidate_confidence_below_threshold",
    "model_role_not_authorized",
    "model_candidate_not_authorized",
    "model_candidate_not_top",
    "candidate_score_below_threshold",
    "candidate_margin_below_threshold",
    "asset_identity_unavailable",
    "embedding_failure",
    "candidate_store_failure",
    "routing_circuit_open",
]


class VisualRegionRoutingDecision(BaseModel):
    """Auditable route decision; it never contains an extracted fact."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    schema_version: Literal["m1.visual-region-routing-decision.v1"] = (
        "m1.visual-region-routing-decision.v1"
    )
    action: VisualRegionRouteAction
    reason: VisualRegionRouteReason
    role: VisualRegionRole | None = None
    suggested_role: VisualRegionRole | None = None
    case_id: str | None = None
    profile_id: str | None = Field(default=None, max_length=128)
    candidate_profile_id: str | None = Field(default=None, max_length=128)
    geometry_reason: VisualGeometryReason
    top_score: float = Field(default=0.0, ge=0.0, le=1.0)
    top1_top2_margin: float = Field(default=0.0, ge=0.0, le=1.0)
    model_used: bool = False
    model_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    asset_identity: Literal["none", "sha256_exact"] = "none"
    review_required: bool = False
    candidate_observation_required: bool = False

    @model_validator(mode="after")
    def validate_decision(self) -> Self:
        if (self.action == "route") != (self.role is not None):
            raise ValueError("only a route decision may contain a role")
        active_profile_reasons = {
            "exact_active_profile",
            "model_candidate_selected",
        }
        if self.action == "route" and self.reason not in {
            "deterministic_geometry",
            *active_profile_reasons,
        }:
            raise ValueError(
                "only deterministic geometry or an active reviewed case may route"
            )
        if self.action == "route" and self.suggested_role is not None:
            raise ValueError("a routed active role cannot also be a suggestion")
        if self.case_id is not None and self.reason not in active_profile_reasons:
            raise ValueError("only candidate reuse may expose a case ID")
        if self.profile_id is not None and (
            self.reason not in active_profile_reasons or self.profile_id != self.case_id
        ):
            raise ValueError("active profile identity must match the selected case")
        if self.candidate_profile_id is not None and self.action != "new_candidate":
            raise ValueError("only a new inactive candidate may expose its profile ID")
        if self.reason in active_profile_reasons and (
            self.action != "route"
            or self.case_id is None
            or self.profile_id != self.case_id
            or self.asset_identity != "sha256_exact"
        ):
            raise ValueError(
                "active profile reuse requires exact asset and matching profile IDs"
            )
        if self.reason == "exact_active_profile" and self.model_used:
            raise ValueError("exact active profile reuse must not invoke the model")
        if self.reason == "deterministic_geometry" and self.action != "route":
            raise ValueError("deterministic geometry must produce a route")
        if self.reason == "model_role_proposed_candidate" and (
            self.action != "new_candidate" or self.suggested_role is None
        ):
            raise ValueError("a model role proposal requires an inactive candidate")
        if self.review_required != (self.action == "review"):
            raise ValueError("review_required must match the review action")
        if self.candidate_observation_required != (self.action == "new_candidate"):
            raise ValueError(
                "candidate observation must match the new_candidate action"
            )
        return self


class VisualRegionRouter:
    """Resolve one region without accessing files, pixels, text, or storage."""

    def __init__(self, policy: VisualRegionRoutingPolicy | None = None) -> None:
        self.policy = policy or VisualRegionRoutingPolicy()

    def rank_cases(
        self,
        topology: VisualRegionTopology,
        cases: Sequence[VisualRegionSimilarCase],
        *,
        asset_sha256: str | None = None,
    ) -> tuple[VisualRegionRankedCase, ...]:
        """Filter incompatible cases and calculate deterministic fused scores."""

        normalized_asset = (
            _normalized_sha256(asset_sha256) if asset_sha256 is not None else None
        )
        ranked: list[VisualRegionRankedCase] = []
        for case in cases:
            if (
                normalized_asset is None
                or case.asset_sha256 != normalized_asset
                or not case.active
                or case.source_kind is not topology.source_kind
            ):
                continue
            weighted = (
                self.policy.geometry_weight * case.geometry_similarity
                + self.policy.review_success_weight * case.review_success_rate
            )
            denominator = (
                self.policy.geometry_weight + self.policy.review_success_weight
            )
            if case.vector_similarity is not None:
                weighted += self.policy.vector_weight * case.vector_similarity
                denominator += self.policy.vector_weight
            fused_score = weighted / denominator if denominator else 0.0
            if fused_score < self.policy.candidate_request_min_score:
                continue
            ranked.append(
                VisualRegionRankedCase(
                    case_id=case.case_id,
                    role=case.role,
                    vector_similarity=case.vector_similarity,
                    geometry_similarity=case.geometry_similarity,
                    review_success_rate=case.review_success_rate,
                    fused_score=min(max(fused_score, 0.0), 1.0),
                )
            )
        ranked.sort(key=lambda item: (-item.fused_score, item.case_id))
        return tuple(ranked[: self.policy.max_model_candidates])

    def selection_request(
        self,
        *,
        geometry: VisualGeometryAssessment,
        topology: VisualRegionTopology,
        allowed_roles: Sequence[VisualRegionRole],
        similar_cases: Sequence[VisualRegionSimilarCase] = (),
        asset_sha256: str | None = None,
    ) -> tuple[VisualRegionSelectionRequest, tuple[VisualRegionRankedCase, ...]]:
        """Build the closed request; resolved geometry cannot reach a model."""

        if geometry.resolved:
            raise ValueError("resolved geometry must not enter visual model routing")
        roles = tuple(dict.fromkeys(allowed_roles))
        ranked = self.rank_cases(
            topology,
            similar_cases,
            asset_sha256=asset_sha256,
        )
        request = VisualRegionSelectionRequest(
            topology=topology,
            roles=tuple(
                VisualRegionRoleOption(role_index=index, role=role)
                for index, role in enumerate(roles)
            ),
            candidates=tuple(
                VisualRegionCaseOption(
                    candidate_index=index,
                    role=candidate.role,
                    vector_similarity=candidate.vector_similarity,
                    geometry_similarity=candidate.geometry_similarity,
                    review_success_rate=candidate.review_success_rate,
                    fused_score=candidate.fused_score,
                )
                for index, candidate in enumerate(ranked)
            ),
        )
        return request, ranked

    @staticmethod
    def _margin(cases: Sequence[VisualRegionRankedCase]) -> tuple[float, float]:
        if not cases:
            return 0.0, 0.0
        top = cases[0].fused_score
        second = cases[1].fused_score if len(cases) > 1 else 0.0
        return top, max(top - second, 0.0)

    @staticmethod
    def _decision(
        geometry: VisualGeometryAssessment,
        *,
        action: VisualRegionRouteAction,
        reason: VisualRegionRouteReason,
        role: VisualRegionRole | None = None,
        suggested_role: VisualRegionRole | None = None,
        case_id: str | None = None,
        candidate_profile_id: str | None = None,
        top_score: float = 0.0,
        margin: float = 0.0,
        model_used: bool = False,
        model_confidence: float | None = None,
        asset_identity: Literal["none", "sha256_exact"] = "none",
    ) -> VisualRegionRoutingDecision:
        return VisualRegionRoutingDecision(
            action=action,
            reason=reason,
            role=role,
            suggested_role=suggested_role,
            case_id=case_id,
            profile_id=(
                case_id
                if reason in {"exact_active_profile", "model_candidate_selected"}
                else None
            ),
            candidate_profile_id=candidate_profile_id,
            geometry_reason=geometry.reason,
            top_score=top_score,
            top1_top2_margin=margin,
            model_used=model_used,
            model_confidence=model_confidence,
            asset_identity=asset_identity,
            review_required=action == "review",
            candidate_observation_required=action == "new_candidate",
        )

    def resolve(
        self,
        *,
        geometry: VisualGeometryAssessment,
        topology: VisualRegionTopology,
        allowed_roles: Sequence[VisualRegionRole],
        similar_cases: Sequence[VisualRegionSimilarCase] = (),
        asset_sha256: str | None = None,
        model_choice: VisualRegionModelChoice | Mapping[str, Any] | None = None,
        model_used: bool = False,
    ) -> VisualRegionRoutingDecision:
        """Apply deterministic priority and validate a bounded model choice."""

        if geometry.role is not None:
            return self._decision(
                geometry,
                action="route",
                reason="deterministic_geometry",
                role=geometry.role,
            )
        request, ranked = self.selection_request(
            geometry=geometry,
            topology=topology,
            allowed_roles=allowed_roles,
            similar_cases=similar_cases,
            asset_sha256=asset_sha256,
        )
        top_score, margin = self._margin(ranked)
        if model_choice is None:
            reason: VisualRegionRouteReason = (
                "no_closed_options"
                if not request.roles and not request.candidates
                else "selector_unavailable"
            )
            return self._decision(
                geometry,
                action="review",
                reason=reason,
                top_score=top_score,
                margin=margin,
                model_used=model_used,
            )
        try:
            choice = VisualRegionModelChoice.model_validate(model_choice, strict=True)
        except Exception:  # noqa: BLE001 - advisory output always fails closed
            return self._decision(
                geometry,
                action="review",
                reason="invalid_model_output",
                top_score=top_score,
                margin=margin,
                model_used=True,
            )
        common = {
            "top_score": top_score,
            "margin": margin,
            "model_used": True,
            "model_confidence": choice.confidence,
        }
        if choice.action == "review":
            return self._decision(
                geometry,
                action="review",
                reason="model_requested_review",
                **common,
            )
        if choice.action == "new_candidate":
            if choice.confidence < self.policy.model_new_candidate_min_confidence:
                return self._decision(
                    geometry,
                    action="review",
                    reason="model_new_candidate_confidence_below_threshold",
                    **common,
                )
            return self._decision(
                geometry,
                action="new_candidate",
                reason="model_requested_new_candidate",
                **common,
            )
        if choice.action == "select_role":
            assert choice.role_index is not None
            if choice.role_index >= len(request.roles):
                return self._decision(
                    geometry,
                    action="review",
                    reason="model_role_not_authorized",
                    **common,
                )
            suggested_role = request.roles[choice.role_index].role
            if choice.confidence < self.policy.model_role_min_confidence:
                return self._decision(
                    geometry,
                    action="review",
                    reason="model_role_confidence_below_threshold",
                    suggested_role=suggested_role,
                    **common,
                )
            return self._decision(
                geometry,
                action="new_candidate",
                reason="model_role_proposed_candidate",
                suggested_role=suggested_role,
                **common,
            )

        assert choice.candidate_index is not None
        if choice.candidate_index >= len(ranked):
            return self._decision(
                geometry,
                action="review",
                reason="model_candidate_not_authorized",
                **common,
            )
        if choice.candidate_index != 0:
            return self._decision(
                geometry,
                action="review",
                reason="model_candidate_not_top",
                **common,
            )
        candidate = ranked[0]
        if choice.confidence < self.policy.model_reuse_min_confidence:
            return self._decision(
                geometry,
                action="review",
                reason="model_candidate_confidence_below_threshold",
                **common,
            )
        if candidate.fused_score < self.policy.candidate_reuse_min_score:
            return self._decision(
                geometry,
                action="review",
                reason="candidate_score_below_threshold",
                **common,
            )
        if margin < self.policy.candidate_reuse_min_margin:
            return self._decision(
                geometry,
                action="review",
                reason="candidate_margin_below_threshold",
                **common,
            )
        return self._decision(
            geometry,
            action="route",
            reason="model_candidate_selected",
            role=candidate.role,
            case_id=candidate.case_id,
            asset_identity="sha256_exact",
            **common,
        )

    async def resolve_with_selector(
        self,
        *,
        geometry: VisualGeometryAssessment,
        topology: VisualRegionTopology,
        allowed_roles: Sequence[VisualRegionRole],
        similar_cases: Sequence[VisualRegionSimilarCase] = (),
        asset_sha256: str | None = None,
        selector: VisualRegionSelector | None,
    ) -> VisualRegionRoutingDecision:
        """Call a selector only for unresolved geometry and fail safely."""

        if geometry.resolved:
            return self.resolve(
                geometry=geometry,
                topology=topology,
                allowed_roles=allowed_roles,
                similar_cases=similar_cases,
                asset_sha256=asset_sha256,
            )
        request, _ranked = self.selection_request(
            geometry=geometry,
            topology=topology,
            allowed_roles=allowed_roles,
            similar_cases=similar_cases,
            asset_sha256=asset_sha256,
        )
        if selector is None or (not request.roles and not request.candidates):
            return self.resolve(
                geometry=geometry,
                topology=topology,
                allowed_roles=allowed_roles,
                similar_cases=similar_cases,
            )
        try:
            choice = await selector.select(request)
        except DocumentRoutingDependencyError:
            raise
        except Exception:  # noqa: BLE001 - optional model cannot affect facts
            ranked = self.rank_cases(
                topology,
                similar_cases,
                asset_sha256=asset_sha256,
            )
            top_score, margin = self._margin(ranked)
            return self._decision(
                geometry,
                action="review",
                reason="model_failure",
                top_score=top_score,
                margin=margin,
                model_used=True,
            )
        return self.resolve(
            geometry=geometry,
            topology=topology,
            allowed_roles=allowed_roles,
            similar_cases=similar_cases,
            asset_sha256=asset_sha256,
            model_choice=choice,
            model_used=True,
        )


class _VisualRegionCircuitOpen(RuntimeError):
    """Internal control flow carrying a content-free review decision."""

    def __init__(self, decision: VisualRegionRoutingDecision) -> None:
        self.decision = decision
        super().__init__("visual region routing circuit is open")


class _ObservedVisualRegionSelector:
    """Validate selector output while recording only safe dependency telemetry."""

    def __init__(
        self,
        delegate: VisualRegionSelector,
        status: DocumentRoutingStatus,
        *,
        required: bool = False,
    ) -> None:
        self._delegate = delegate
        self._status = status
        self._required = bool(required)

    async def select(
        self,
        request: VisualRegionSelectionRequest,
    ) -> VisualRegionModelChoice:
        try:
            raw = await self._delegate.select(request)
            choice = VisualRegionModelChoice.model_validate(raw, strict=True)
        except Exception as exc:
            controlled = self._status.note_dependency_failure("model", exc)
            if self._required:
                raise controlled from None
            raise
        self._status.note_dependency_success("model")
        return choice


class GovernedVisualRegionRoutingRuntime:
    """Run pgvector recall and closed selection only after geometry is unresolved."""

    def __init__(
        self,
        *,
        store: VisualRegionRouteStore,
        embedding_provider: VisualRegionEmbeddingProvider,
        selector_factory: VisualRegionSelectorFactory | None,
        router: VisualRegionRouter | None = None,
        mode: Literal["shadow", "guarded"] = "guarded",
        max_regions_per_document: int = 32,
        required: bool = False,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
    ) -> None:
        if mode not in {"shadow", "guarded"}:
            raise ValueError("visual routing mode must be shadow or guarded")
        if not 1 <= int(max_regions_per_document) <= 64:
            raise ValueError("visual routing region limit must be in [1, 64]")
        self.store = store
        self.embedding_provider = embedding_provider
        self.selector_factory = selector_factory
        self.router = router or VisualRegionRouter()
        self.mode = mode
        self.max_regions_per_document = int(max_regions_per_document)
        self.required = bool(required)
        self._status = DocumentRoutingStatus(
            circuit_failures=circuit_failures,
            circuit_seconds=circuit_seconds,
        )

    def status_snapshot(self) -> dict[str, object]:
        """Return bounded telemetry without pixels, filenames, or model output."""

        return {
            **self._status.snapshot(),
            "mode": self.mode,
            "required": self.required,
            "embedding_semantics": "structural_topology_only",
        }

    def _open_dependency(self) -> str | None:
        return next(
            (
                dependency
                for dependency in ("embedding", "store", "model")
                if self._status.circuit_open(dependency)
            ),
            None,
        )

    @staticmethod
    def _verified_asset_sha256(
        image_bytes: bytes | None,
        asset_sha256: str | None,
    ) -> str | None:
        if not image_bytes or asset_sha256 is None:
            return None
        try:
            expected = _normalized_sha256(asset_sha256)
        except ValueError:
            return None
        actual = hashlib.sha256(image_bytes).hexdigest()
        return expected if actual == expected else None

    @staticmethod
    def _exact_case_role(
        case: VisualRegionExactCase,
        *,
        tenant_id: str,
        topology: VisualRegionTopology,
        asset_sha256: str,
        allowed_roles: Sequence[VisualRegionRole],
    ) -> VisualRegionRole | None:
        """Validate the repository boundary before reusing an exact profile."""

        if (
            case.tenant_id != tenant_id
            or not case.active
            or case.exact_fingerprint != topology.exact_fingerprint()
            or case.asset_sha256 != asset_sha256
            or case.topology != topology
            or case.topology.source_kind is not topology.source_kind
            or case.topology.contract_revision != topology.contract_revision
        ):
            raise ValueError("visual exact-profile store returned an incompatible case")
        authorized_roles = frozenset(VisualRegionRole(role) for role in allowed_roles)
        return case.role if case.role in authorized_roles else None

    async def _embedding(
        self,
        topology: VisualRegionTopology,
        *,
        image_bytes: bytes | None,
        media_type: str | None,
    ) -> tuple[float, ...]:
        raw = await self.embedding_provider.embed_region(
            topology,
            image_bytes=image_bytes,
            media_type=media_type,
        )
        vector = tuple(float(value) for value in raw)
        if len(vector) != self.embedding_provider.dimensions:
            raise ValueError("visual region embedding dimension mismatch")
        if not vector or not all(math.isfinite(value) for value in vector):
            raise ValueError("visual region embedding is invalid")
        return vector

    @staticmethod
    def _candidate_profile_id(
        profile: object,
        *,
        tenant_id: str,
        topology: VisualRegionTopology,
        asset_sha256: str,
        role: VisualRegionRole,
    ) -> str:
        profile_id = str(getattr(profile, "profile_id", "")).strip()
        if not profile_id:
            raise ValueError("visual candidate store returned no profile identity")
        if str(getattr(profile, "status", "")).strip().casefold() != "candidate":
            raise ValueError("visual candidate store returned a non-candidate profile")
        if str(getattr(profile, "tenant_id", tenant_id)).strip() != tenant_id:
            raise ValueError("visual candidate store crossed the tenant boundary")
        exact_fingerprint = str(
            getattr(profile, "exact_fingerprint", topology.exact_fingerprint())
        ).strip()
        if exact_fingerprint != topology.exact_fingerprint():
            raise ValueError("visual candidate store returned a different topology")
        returned_asset = (
            str(getattr(profile, "asset_sha256", asset_sha256)).strip().casefold()
        )
        if returned_asset != asset_sha256:
            raise ValueError(
                "visual candidate store returned a different asset identity"
            )
        if VisualRegionRole(str(getattr(profile, "role", role))) is not role:
            raise ValueError("visual candidate store returned a different role")
        return profile_id

    async def _create_candidate(
        self,
        *,
        tenant_id: str,
        topology: VisualRegionTopology,
        role: VisualRegionRole,
        embedding: Sequence[float],
        asset_sha256: str,
        created_by: str = "visual-region-router",
    ) -> tuple[object, str]:
        proposal = VisualRegionCandidateProposal.build(
            tenant_id=tenant_id,
            asset_sha256=asset_sha256,
            topology=topology,
            role=role,
            embedding=embedding,
            embedding_model=self.embedding_provider.model,
            embedding_dimensions=self.embedding_provider.dimensions,
            created_by=created_by,
        )
        profile = await self.store.create_visual_region_candidate(proposal)
        return profile, self._candidate_profile_id(
            profile,
            tenant_id=tenant_id,
            topology=topology,
            asset_sha256=asset_sha256,
            role=role,
        )

    async def _resolve(
        self,
        *,
        tenant_id: str,
        geometry: VisualGeometryAssessment,
        topology: VisualRegionTopology,
        allowed_roles: Sequence[VisualRegionRole],
        image_bytes: bytes | None = None,
        media_type: str | None = None,
        asset_sha256: str | None = None,
    ) -> VisualRegionRoutingDecision:
        if geometry.resolved:
            return self.router.resolve(
                geometry=geometry,
                topology=topology,
                allowed_roles=allowed_roles,
            )
        verified_asset_sha256 = self._verified_asset_sha256(
            image_bytes,
            asset_sha256,
        )
        if verified_asset_sha256 is None:
            return self.router._decision(
                geometry,
                action="review",
                reason="asset_identity_unavailable",
            )
        if self._status.circuit_open("exact_store"):
            if self.required:
                raise DocumentRoutingDependencyError("exact_store", "CircuitOpen")
            raise _VisualRegionCircuitOpen(
                self.router._decision(
                    geometry,
                    action="review",
                    reason="routing_circuit_open",
                )
            )
        try:
            exact_case = await self.store.get_active_visual_region_case_by_fingerprint(
                tenant_id,
                topology.exact_fingerprint(),
                contract_revision=topology.contract_revision,
                source_kind=topology.source_kind,
                asset_sha256=verified_asset_sha256,
            )
            self._status.note_dependency_success("exact_store")
            exact_role = (
                self._exact_case_role(
                    exact_case,
                    tenant_id=tenant_id,
                    topology=topology,
                    asset_sha256=verified_asset_sha256,
                    allowed_roles=allowed_roles,
                )
                if exact_case is not None
                else None
            )
        except Exception as exc:  # noqa: BLE001 - repository output fails closed
            controlled = self._status.note_dependency_failure("exact_store", exc)
            if self.required:
                raise controlled from None
            return self.router._decision(
                geometry,
                action="review",
                reason="candidate_store_failure",
            )
        if exact_case is not None and exact_role is not None:
            return self.router._decision(
                geometry,
                action="route",
                reason="exact_active_profile",
                role=exact_role,
                case_id=exact_case.case_id,
                top_score=1.0,
                margin=1.0,
                asset_identity="sha256_exact",
            )
        if (open_dependency := self._open_dependency()) is not None:
            if self.required:
                raise DocumentRoutingDependencyError(open_dependency, "CircuitOpen")
            raise _VisualRegionCircuitOpen(
                self.router._decision(
                    geometry,
                    action="review",
                    reason="routing_circuit_open",
                )
            )
        try:
            embedding = await self._embedding(
                topology,
                image_bytes=image_bytes,
                media_type=media_type,
            )
            self._status.note_dependency_success("embedding")
        except Exception as exc:  # noqa: BLE001 - optional retrieval reviews
            controlled = self._status.note_dependency_failure("embedding", exc)
            if self.required:
                raise controlled from None
            return self.router._decision(
                geometry,
                action="review",
                reason="embedding_failure",
            )
        try:
            cases = await self.store.find_active_visual_region_cases(
                tenant_id,
                embedding,
                embedding_model=self.embedding_provider.model,
                embedding_dimensions=self.embedding_provider.dimensions,
                topology=topology,
                asset_sha256=verified_asset_sha256,
                limit=self.router.policy.max_model_candidates,
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - optional store cannot route facts
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self.router._decision(
                geometry,
                action="review",
                reason="candidate_store_failure",
            )
        selector: VisualRegionSelector | None = None
        if self.selector_factory is not None:
            try:
                selector = _ObservedVisualRegionSelector(
                    self.selector_factory.bind(
                        image_bytes=image_bytes,
                        media_type=media_type,
                    ),
                    self._status,
                    required=self.required,
                )
            except Exception as exc:  # noqa: BLE001 - optional model binding reviews
                controlled = self._status.note_dependency_failure("model", exc)
                if self.required:
                    raise controlled from None
                return self.router._decision(
                    geometry,
                    action="review",
                    reason="model_failure",
                    model_used=True,
                )
        elif self.required and (allowed_roles or cases):
            error = RuntimeError("visual region selector unavailable")
            raise self._status.note_dependency_failure("model", error) from None
        decision = await self.router.resolve_with_selector(
            geometry=geometry,
            topology=topology,
            allowed_roles=allowed_roles,
            similar_cases=cases,
            asset_sha256=verified_asset_sha256,
            selector=selector,
        )
        if decision.action != "new_candidate" or decision.suggested_role is None:
            return decision
        try:
            _profile, candidate_profile_id = await self._create_candidate(
                tenant_id=tenant_id,
                topology=topology,
                role=decision.suggested_role,
                embedding=embedding,
                asset_sha256=verified_asset_sha256,
            )
            self._status.note_dependency_success("store")
        except Exception as exc:  # noqa: BLE001 - inactive proposal is optional
            controlled = self._status.note_dependency_failure("store", exc)
            if self.required:
                raise controlled from None
            return self.router._decision(
                geometry,
                action="review",
                reason="candidate_store_failure",
                suggested_role=decision.suggested_role,
                top_score=decision.top_score,
                margin=decision.top1_top2_margin,
                model_used=decision.model_used,
                model_confidence=decision.model_confidence,
            )
        return decision.model_copy(
            update={"candidate_profile_id": candidate_profile_id}
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        geometry: VisualGeometryAssessment,
        topology: VisualRegionTopology,
        allowed_roles: Sequence[VisualRegionRole],
        image_bytes: bytes | None = None,
        media_type: str | None = None,
        asset_sha256: str | None = None,
    ) -> VisualRegionRoutingDecision:
        try:
            return await self._status.track_operation(
                self._resolve(
                    tenant_id=tenant_id,
                    geometry=geometry,
                    topology=topology,
                    allowed_roles=allowed_roles,
                    image_bytes=image_bytes,
                    media_type=media_type,
                    asset_sha256=asset_sha256,
                )
            )
        except _VisualRegionCircuitOpen as exc:
            return exc.decision

    async def observe_candidate(
        self,
        *,
        decision: VisualRegionRoutingDecision,
        tenant_id: str,
        topology: VisualRegionTopology,
        validated_role: VisualRegionRole,
        task_reference_hash: str,
        reviewed_by: str,
        review_note_sha256: str,
        image_bytes: bytes | None = None,
        media_type: str | None = None,
        asset_sha256: str | None = None,
        created_by: str = "visual-region-router",
    ) -> Any:
        """Persist one reviewed candidate; activation remains a separate action."""

        if decision.action != "new_candidate":
            raise ValueError("only a new_candidate decision can be observed")
        verified_asset_sha256 = self._verified_asset_sha256(
            image_bytes,
            asset_sha256,
        )
        if verified_asset_sha256 is None:
            raise ValueError("reviewed visual candidates require exact asset identity")
        embedding = await self._embedding(
            topology,
            image_bytes=image_bytes,
            media_type=media_type,
        )
        profile, profile_id = await self._create_candidate(
            tenant_id=tenant_id,
            topology=topology,
            role=validated_role,
            embedding=embedding,
            asset_sha256=verified_asset_sha256,
            created_by=created_by,
        )
        exact_fingerprint = str(
            getattr(profile, "exact_fingerprint", topology.exact_fingerprint())
        ).strip()
        if decision.candidate_profile_id is not None and (
            decision.candidate_profile_id != profile_id
        ):
            raise ValueError("visual candidate observation references another profile")
        observation = VisualRegionExecutionObservation(
            tenant_id=tenant_id,
            profile_id=profile_id,
            exact_fingerprint=exact_fingerprint,
            task_reference_hash=task_reference_hash,
            outcome="success",
            validation_passed=True,
            reviewed_by=reviewed_by,
            review_note_sha256=review_note_sha256,
        )
        await self.store.record_visual_region_execution_observation(observation)
        return profile


__all__ = [
    "VISUAL_REGION_CONTRACT_REVISION",
    "GovernedVisualRegionRoutingRuntime",
    "VisualAreaBucket",
    "VisualAspectBucket",
    "VisualGeometryAssessment",
    "VisualGeometryReason",
    "VisualPositionBucket",
    "VisualRegionCandidateProposal",
    "VisualRegionCaseOption",
    "VisualRegionEmbeddingProvider",
    "VisualRegionExactCase",
    "VisualRegionExecutionObservation",
    "VisualRegionModelChoice",
    "VisualRegionRankedCase",
    "VisualRegionRole",
    "VisualRegionRoleOption",
    "VisualRegionRouteStore",
    "VisualRegionRouter",
    "VisualRegionRoutingDecision",
    "VisualRegionRoutingPolicy",
    "VisualRegionSelectionRequest",
    "VisualRegionSelector",
    "VisualRegionSelectorFactory",
    "VisualRegionSimilarCase",
    "VisualRegionSourceKind",
    "VisualRegionTopology",
    "visual_topology_similarity",
]
