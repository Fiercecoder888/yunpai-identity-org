"""Deterministic spreadsheet adapters.

OOXML is read directly so formula text, cached values, package relationships and
WPS cell images survive even when a convenience library ignores them.  When
``openpyxl`` is installed it is also opened in formula and data-only modes and
used as an additional typed-value reader.
"""
from __future__ import annotations

import csv
import hashlib
import io
import mimetypes
import posixpath
import re
import unicodedata
from collections.abc import Iterable
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from .envelope import (
    CellValue,
    DocumentEnvelope,
    ImageAnchor,
    MergedRange,
    SheetEnvelope,
    coordinate_from_row_col,
)
from .magic import FileTypeInfo, sniff_file_type

REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
OFFICE_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
STRICT_OFFICE_REL_NS = "http://purl.oclc.org/ooxml/officeDocument/relationships"
CELL_REF_RE = re.compile(r"^\$?([A-Z]{1,4})\$?(\d+)$", re.IGNORECASE)
DISPIMG_RE = re.compile(r"DISPIMG\s*\(\s*[\"']([^\"']+)[\"']", re.IGNORECASE)
_OPENPYXL_OVERLAY_MAX_WORKSHEET_XML_BYTES = 16 * 1024 * 1024


class UnsupportedSpreadsheetError(ValueError):
    pass


class SpreadsheetDependencyError(RuntimeError):
    pass


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _children(element: ET.Element | None, local_name: str) -> Iterable[ET.Element]:
    if element is None:
        return ()
    return (child for child in element if _local_name(child.tag) == local_name)


def _first_descendant(element: ET.Element, local_name: str) -> ET.Element | None:
    return next((node for node in element.iter() if _local_name(node.tag) == local_name), None)


def _relationship_id(element: ET.Element) -> str | None:
    return (
        element.attrib.get(f"{{{OFFICE_REL_NS}}}id")
        or element.attrib.get(f"{{{STRICT_OFFICE_REL_NS}}}id")
        or element.attrib.get("r:id")
    )


def _embedded_relationship_id(element: ET.Element) -> str | None:
    return (
        element.attrib.get(f"{{{OFFICE_REL_NS}}}embed")
        or element.attrib.get(f"{{{STRICT_OFFICE_REL_NS}}}embed")
        or element.attrib.get("r:embed")
    )


def _resolve_part(base_part: str, target: str) -> str:
    target = target.replace("\\", "/")
    if target.startswith("/"):
        return target.lstrip("/")
    return posixpath.normpath(posixpath.join(posixpath.dirname(base_part), target))


def _relationships_part(part: str) -> str:
    return posixpath.join(posixpath.dirname(part), "_rels", posixpath.basename(part) + ".rels")


def _read_relationships(archive: ZipFile, part: str) -> dict[str, tuple[str, str]]:
    rel_part = _relationships_part(part)
    try:
        root = ET.fromstring(archive.read(rel_part))
    except KeyError:
        return {}
    result: dict[str, tuple[str, str]] = {}
    for rel in root.iter():
        if _local_name(rel.tag) != "Relationship":
            continue
        rel_id = rel.attrib.get("Id")
        target = rel.attrib.get("Target")
        if rel_id and target:
            result[rel_id] = (_resolve_part(part, target), rel.attrib.get("Type", ""))
    return result


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _display_filename(filename: str) -> str:
    return unicodedata.normalize("NFKC", filename)


def _column_number(letters: str) -> int:
    value = 0
    for character in letters.upper():
        value = value * 26 + ord(character) - 64
    return value


def _row_col(reference: str) -> tuple[int, int]:
    match = CELL_REF_RE.match(reference)
    if not match:
        raise ValueError(f"Invalid spreadsheet coordinate: {reference}")
    return int(match.group(2)), _column_number(match.group(1))


def _range_bounds(reference: str) -> tuple[int, int, int, int]:
    first, _, last = reference.replace("$", "").partition(":")
    if not last:
        last = first
    min_row, min_col = _row_col(first)
    max_row, max_col = _row_col(last)
    return min_row, min_col, max_row, max_col


def _normalized_text(value: Any) -> str | None:
    if value is None:
        return None
    return unicodedata.normalize("NFKC", str(value))


def _number(value: str | None) -> int | Decimal | None:
    if value is None or value == "":
        return None
    try:
        number = Decimal(value)
    except InvalidOperation:
        return None
    if number == number.to_integral_value():
        return int(number)
    return number


def _excel_datetime(serial: int | Decimal, *, date_1904: bool) -> datetime:
    # Excel's 1900 calendar includes the non-existent 1900-02-29.
    # Spreadsheet cells carry no timezone; preserving a naive value matches OOXML.
    base = datetime(1904, 1, 1) if date_1904 else datetime(1899, 12, 30)  # noqa: DTZ001
    return base + timedelta(days=float(serial))


def _is_date_format(format_code: str) -> bool:
    cleaned = re.sub(r'"[^"]*"|\[[^]]*\]|\\.', "", format_code.lower())
    cleaned = re.sub(r"general|0+|#+|\?|_|\*|;.*$", "", cleaned)
    return bool(re.search(r"(?:^|[^a-z])[ymdhis]+(?:[^a-z]|$)", cleaned))


def _styles(archive: ZipFile) -> tuple[dict[int, str], dict[int, int]]:
    try:
        root = ET.fromstring(archive.read("xl/styles.xml"))
    except KeyError:
        return {}, {}
    custom_formats: dict[int, str] = {}
    style_formats: dict[int, int] = {}
    for node in root.iter():
        if _local_name(node.tag) == "numFmt":
            try:
                custom_formats[int(node.attrib["numFmtId"])] = node.attrib.get("formatCode", "")
            except (KeyError, ValueError):
                pass
    cell_xfs = next((node for node in root.iter() if _local_name(node.tag) == "cellXfs"), None)
    for index, xf in enumerate(_children(cell_xfs, "xf")):
        try:
            style_formats[index] = int(xf.attrib.get("numFmtId", "0"))
        except ValueError:
            style_formats[index] = 0
    return custom_formats, style_formats


BUILTIN_DATE_FORMATS = {
    14: "mm-dd-yy",
    15: "d-mmm-yy",
    16: "d-mmm",
    17: "mmm-yy",
    18: "h:mm AM/PM",
    19: "h:mm:ss AM/PM",
    20: "h:mm",
    21: "h:mm:ss",
    22: "m/d/yy h:mm",
    45: "mm:ss",
    46: "[h]:mm:ss",
    47: "mmss.0",
}


class XlsxDocumentAdapter:
    """Read XLSX/XLSM values, formulas, merges and image relationships."""

    def parse(self, path: str | Path, original_filename: str | None = None) -> DocumentEnvelope:
        source = Path(path)
        detected = sniff_file_type(source)
        if detected.kind not in {"xlsx", "xlsm"}:
            raise UnsupportedSpreadsheetError(f"Expected OOXML spreadsheet, got {detected.kind}")
        original = original_filename or source.name
        envelope = DocumentEnvelope(
            path=source,
            original_filename=original,
            display_filename=_display_filename(original),
            sha256=_sha256_path(source),
            mime_type=detected.mime_type,
            file_kind=detected.kind,
        )
        with ZipFile(source) as archive:
            shared_strings = self._shared_strings(archive)
            custom_formats, style_formats = _styles(archive)
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
            workbook_relationships = _read_relationships(archive, "xl/workbook.xml")
            workbook_properties = next(
                (node for node in workbook.iter() if _local_name(node.tag) == "workbookPr"), None
            )
            date_1904 = bool(
                workbook_properties is not None
                and workbook_properties.attrib.get("date1904", "0").lower() in {"1", "true"}
            )
            envelope.date_1904 = date_1904
            sheets_node = next((node for node in workbook.iter() if _local_name(node.tag) == "sheets"), None)
            for sheet_node in _children(sheets_node, "sheet"):
                sheet_name = sheet_node.attrib.get("name", f"Sheet{len(envelope.sheets) + 1}")
                sheet_state = sheet_node.attrib.get("state", "visible").casefold()
                if sheet_state in {"hidden", "veryhidden"} or sheet_name.casefold().startswith(
                    "wpsreserved_"
                ):
                    # WPS keeps cell-image manifests and stale helper tables in
                    # hidden worksheets.  They are evidence/resources, not
                    # business rows; retain an auditable warning but do not let
                    # them contaminate order totals or indexes.
                    envelope.warnings.append(f"hidden_sheet_skipped:{sheet_name}")
                    continue
                rel_id = _relationship_id(sheet_node)
                if not rel_id or rel_id not in workbook_relationships:
                    envelope.warnings.append(f"worksheet_relationship_missing:{sheet_name}")
                    continue
                sheet_part, _ = workbook_relationships[rel_id]
                sheet = self._read_sheet(
                    archive,
                    sheet_part,
                    sheet_name,
                    shared_strings,
                    custom_formats,
                    style_formats,
                    date_1904,
                    envelope.warnings,
                )
                envelope.sheets.append(sheet)
            self._attach_wps_cell_images(archive, envelope)
            large_worksheet_parts = [
                info.filename
                for info in archive.infolist()
                if info.filename.startswith("xl/worksheets/")
                and info.filename.casefold().endswith(".xml")
                and info.file_size > _OPENPYXL_OVERLAY_MAX_WORKSHEET_XML_BYTES
            ]
        if large_worksheet_parts:
            envelope.warnings.append(
                "openpyxl_overlay_skipped_large_worksheet_xml:"
                + ",".join(large_worksheet_parts[:8])
            )
        else:
            self._overlay_openpyxl_values(source, envelope)
        return envelope

    @staticmethod
    def _shared_strings(archive: ZipFile) -> list[str]:
        try:
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
        except KeyError:
            return []
        strings: list[str] = []
        for item in root:
            if _local_name(item.tag) != "si":
                continue
            strings.append("".join(node.text or "" for node in item.iter() if _local_name(node.tag) == "t"))
        return strings

    def _read_sheet(
        self,
        archive: ZipFile,
        part: str,
        name: str,
        shared_strings: list[str],
        custom_formats: dict[int, str],
        style_formats: dict[int, int],
        date_1904: bool,
        warnings: list[str],
    ) -> SheetEnvelope:
        sheet = SheetEnvelope(name=name)
        drawing_relationship_ids: list[str] = []
        current_row_number = 0
        with archive.open(part) as stream:
            for event, node in ET.iterparse(stream, events=("start", "end")):
                local_name = _local_name(node.tag)
                if event == "start":
                    if local_name == "row":
                        try:
                            current_row_number = int(node.attrib.get("r", "0"))
                        except ValueError:
                            current_row_number = 0
                        if current_row_number and node.attrib.get(
                            "hidden", "0"
                        ).lower() in {"1", "true"}:
                            sheet.hidden_rows.add(current_row_number)
                    continue

                if local_name == "col":
                    try:
                        first = int(node.attrib["min"])
                        last = int(node.attrib["max"])
                    except (KeyError, ValueError):
                        node.clear()
                        continue
                    hidden = node.attrib.get("hidden", "0").lower() in {
                        "1",
                        "true",
                    }
                    try:
                        width = float(node.attrib.get("width", "8.43"))
                    except ValueError:
                        width = 8.43
                    for column in range(first, last + 1):
                        if hidden:
                            sheet.hidden_columns.add(column)
                        if hidden or width < 1.0:
                            sheet.low_visibility_columns.add(column)
                    node.clear()
                    continue

                if local_name == "c":
                    cell_node = node
                    formula_node = next(_children(cell_node, "f"), None)
                    value_node = next(_children(cell_node, "v"), None)
                    inline_node = next(_children(cell_node, "is"), None)
                    # Style-only cells carry no source fact. Some spreadsheet
                    # writers emit millions of them, so do not materialize them.
                    has_inline_text = bool(
                        inline_node is not None
                        and any(
                            (child.text or "") != ""
                            for child in inline_node.iter()
                            if _local_name(child.tag) == "t"
                        )
                    )
                    if (
                        formula_node is None
                        and (value_node is None or value_node.text is None)
                        and not has_inline_text
                    ):
                        cell_node.clear()
                        continue
                    reference = cell_node.attrib.get("r")
                    if not reference:
                        cell_node.clear()
                        continue
                    try:
                        row, column = _row_col(reference)
                    except ValueError:
                        cell_node.clear()
                        continue
                    try:
                        style_id = int(cell_node.attrib.get("s", "0") or 0)
                    except ValueError:
                        style_id = 0
                    data_type = cell_node.attrib.get("t")
                    raw_value = value_node.text if value_node is not None else None
                    value = self._decode_value(
                        data_type,
                        raw_value,
                        inline_node,
                        shared_strings,
                        style_id,
                        custom_formats,
                        style_formats,
                        date_1904,
                    )
                    formula = formula_node.text if formula_node is not None else None
                    if formula is not None and raw_value is None:
                        warnings.append(f"formula_cache_missing:{name}!{reference}")
                    sheet.cells[(row, column)] = CellValue(
                        sheet=name,
                        coordinate=reference,
                        row=row,
                        column=column,
                        value=value,
                        normalized_value=_normalized_text(value),
                        formula=formula,
                        cached_value=value if formula is not None else None,
                        data_type=data_type,
                        style_id=style_id,
                        hidden_row=row in sheet.hidden_rows,
                        hidden_column=column in sheet.hidden_columns,
                        low_visibility_column=column in sheet.low_visibility_columns,
                    )
                    sheet.max_row = max(sheet.max_row, row)
                    sheet.max_column = max(sheet.max_column, column)
                    cell_node.clear()
                    continue

                if local_name == "mergeCell":
                    reference = node.attrib.get("ref")
                    if reference:
                        try:
                            min_row, min_col, max_row, max_col = _range_bounds(
                                reference
                            )
                        except ValueError:
                            pass
                        else:
                            sheet.merged_ranges.append(
                                MergedRange(
                                    reference,
                                    min_row,
                                    min_col,
                                    max_row,
                                    max_col,
                                )
                            )
                            sheet.max_row = max(sheet.max_row, max_row)
                            sheet.max_column = max(sheet.max_column, max_col)
                    node.clear()
                    continue

                if local_name == "drawing":
                    relationship_id = _relationship_id(node)
                    if relationship_id:
                        drawing_relationship_ids.append(relationship_id)
                    node.clear()
                    continue

                if local_name == "row":
                    current_row_number = 0
                    node.clear()

        for merged in sheet.merged_ranges:
            for row in range(merged.min_row, merged.max_row + 1):
                for column in range(merged.min_col, merged.max_col + 1):
                    existing = sheet.cells.get((row, column))
                    if existing is not None:
                        existing.merged_range = merged.ref

        sheet.images.extend(
            self._drawing_images(
                archive,
                part,
                drawing_relationship_ids,
                sheet,
            )
        )
        return sheet

    @staticmethod
    def _decode_value(
        data_type: str | None,
        raw_value: str | None,
        inline_node: ET.Element | None,
        shared_strings: list[str],
        style_id: int,
        custom_formats: dict[int, str],
        style_formats: dict[int, int],
        date_1904: bool,
    ) -> Any:
        if data_type == "s" and raw_value is not None:
            try:
                return shared_strings[int(raw_value)]
            except (IndexError, ValueError):
                return raw_value
        if data_type == "inlineStr" and inline_node is not None:
            return "".join(
                node.text or "" for node in inline_node.iter() if _local_name(node.tag) == "t"
            )
        if data_type == "b":
            return raw_value == "1"
        if data_type in {"str", "e"}:
            return raw_value
        if data_type == "d" and raw_value:
            try:
                return datetime.fromisoformat(raw_value)
            except ValueError:
                return raw_value
        value = _number(raw_value)
        if value is None:
            return raw_value
        num_fmt_id = style_formats.get(style_id, 0)
        format_code = custom_formats.get(num_fmt_id, BUILTIN_DATE_FORMATS.get(num_fmt_id, ""))
        if format_code and _is_date_format(format_code):
            return _excel_datetime(value, date_1904=date_1904)
        return value

    def _drawing_images(
        self,
        archive: ZipFile,
        sheet_part: str,
        drawing_relationship_ids: list[str],
        sheet: SheetEnvelope,
    ) -> list[ImageAnchor]:
        sheet_relationships = _read_relationships(archive, sheet_part)
        images: list[ImageAnchor] = []
        for rel_id in dict.fromkeys(drawing_relationship_ids):
            if not rel_id or rel_id not in sheet_relationships:
                continue
            drawing_part, _ = sheet_relationships[rel_id]
            try:
                drawing_root = ET.fromstring(archive.read(drawing_part))
            except KeyError:
                continue
            drawing_relationships = _read_relationships(archive, drawing_part)
            for anchor in drawing_root:
                if _local_name(anchor.tag) not in {"twoCellAnchor", "oneCellAnchor"}:
                    continue
                from_node = next(_children(anchor, "from"), None)
                if from_node is None:
                    continue
                from_row, from_col = self._anchor_position(from_node)
                to_node = next(_children(anchor, "to"), None)
                to_row, to_col = (
                    self._anchor_position(to_node) if to_node is not None else (from_row, from_col)
                )
                blip = _first_descendant(anchor, "blip")
                image_rel_id = _embedded_relationship_id(blip) if blip is not None else None
                if not image_rel_id or image_rel_id not in drawing_relationships:
                    continue
                image_part, _ = drawing_relationships[image_rel_id]
                try:
                    image_data = archive.read(image_part)
                except KeyError:
                    continue
                properties = _first_descendant(anchor, "cNvPr")
                merged = sheet.merge_at(from_row, from_col)
                images.append(
                    ImageAnchor(
                        image_id=f"{sheet.name}:image:{len(images) + 1}",
                        sheet=sheet.name,
                        part_name=image_part,
                        media_type=mimetypes.guess_type(image_part)[0] or "application/octet-stream",
                        sha256=hashlib.sha256(image_data).hexdigest(),
                        from_row=from_row,
                        from_col=from_col,
                        to_row=to_row,
                        to_col=to_col,
                        relationship_id=image_rel_id,
                        merged_range=merged.ref if merged else None,
                        display_name=(properties.attrib.get("name") if properties is not None else None),
                    )
                )
        return images

    @staticmethod
    def _anchor_position(node: ET.Element) -> tuple[int, int]:
        row_node = next(_children(node, "row"), None)
        col_node = next(_children(node, "col"), None)
        row = int(row_node.text or 0) + 1 if row_node is not None else 1
        column = int(col_node.text or 0) + 1 if col_node is not None else 1
        return row, column

    def _attach_wps_cell_images(self, archive: ZipFile, envelope: DocumentEnvelope) -> None:
        parts = [name for name in archive.namelist() if name.lower().endswith("cellimages.xml")]
        if not parts:
            return
        candidates: list[tuple[set[str], str, str, str, str | None]] = []
        for part in parts:
            try:
                root = ET.fromstring(archive.read(part))
            except (KeyError, ET.ParseError):
                continue
            relationships = _read_relationships(archive, part)
            for pic in (node for node in root.iter() if _local_name(node.tag) == "pic"):
                properties = _first_descendant(pic, "cNvPr")
                blip = _first_descendant(pic, "blip")
                rel_id = _embedded_relationship_id(blip) if blip is not None else None
                if not rel_id or rel_id not in relationships:
                    continue
                image_part, _ = relationships[rel_id]
                try:
                    data = archive.read(image_part)
                except KeyError:
                    continue
                identifiers = {rel_id}
                display_name = None
                if properties is not None:
                    display_name = properties.attrib.get("name") or properties.attrib.get("descr")
                    identifiers.update(
                        value
                        for value in (
                            properties.attrib.get("id"),
                            properties.attrib.get("name"),
                            properties.attrib.get("descr"),
                        )
                        if value
                    )
                candidates.append(
                    (
                        identifiers,
                        image_part,
                        hashlib.sha256(data).hexdigest(),
                        mimetypes.guess_type(image_part)[0] or "application/octet-stream",
                        display_name,
                    )
                )

        for sheet in envelope.sheets:
            formula_cells = [
                cell
                for cell in sheet.cells.values()
                if cell.formula and DISPIMG_RE.search(cell.formula)
            ]
            used: set[int] = set()
            for sequence, cell in enumerate(formula_cells):
                formula_match = DISPIMG_RE.search(cell.formula or "")
                formula_id = formula_match.group(1) if formula_match else ""
                candidate_index = next(
                    (index for index, item in enumerate(candidates) if formula_id in item[0] and index not in used),
                    None,
                )
                if candidate_index is None and sequence < len(candidates) and sequence not in used:
                    candidate_index = sequence
                if candidate_index is None:
                    envelope.warnings.append(f"wps_cell_image_unresolved:{sheet.name}!{cell.coordinate}")
                    continue
                used.add(candidate_index)
                _, image_part, digest, media_type, display_name = candidates[candidate_index]
                merged = sheet.merge_at(cell.row, cell.column)
                sheet.images.append(
                    ImageAnchor(
                        image_id=f"{sheet.name}:wps-image:{len(sheet.images) + 1}",
                        sheet=sheet.name,
                        part_name=image_part,
                        media_type=media_type,
                        sha256=digest,
                        from_row=cell.row,
                        from_col=cell.column,
                        to_row=merged.max_row if merged else cell.row,
                        to_col=merged.max_col if merged else cell.column,
                        merged_range=merged.ref if merged else None,
                        source_kind="wps_cell_image",
                        display_name=display_name,
                    )
                )

    @staticmethod
    def _overlay_openpyxl_values(path: Path, envelope: DocumentEnvelope) -> None:
        if not any(
            cell.formula
            for sheet in envelope.sheets
            for cell in sheet.cells.values()
        ):
            return
        try:
            from openpyxl import load_workbook  # type: ignore[import-not-found]
        except ImportError:
            return
        try:
            formula_book = load_workbook(path, data_only=False, read_only=False)
            value_book = load_workbook(path, data_only=True, read_only=False)
            for sheet in envelope.sheets:
                if sheet.name not in formula_book.sheetnames or sheet.name not in value_book.sheetnames:
                    continue
                formula_sheet = formula_book[sheet.name]
                value_sheet = value_book[sheet.name]
                for cell in sheet.cells.values():
                    formula_value = formula_sheet[cell.coordinate].value
                    cached_value = value_sheet[cell.coordinate].value
                    if isinstance(formula_value, str) and formula_value.startswith("="):
                        cell.formula = formula_value[1:]
                        if cached_value is not None:
                            cell.cached_value = cached_value
                            cell.value = cached_value
                            cell.normalized_value = _normalized_text(cached_value)
                    elif formula_value is not None and cell.value is None:
                        cell.value = formula_value
                        cell.normalized_value = _normalized_text(formula_value)
            formula_book.close()
            value_book.close()
        except Exception as exc:  # noqa: BLE001 - authoritative OOXML fallback
            envelope.warnings.append(f"openpyxl_dual_read_failed:{type(exc).__name__}")


class CsvDocumentAdapter:
    def parse(self, path: str | Path, original_filename: str | None = None) -> DocumentEnvelope:
        source = Path(path)
        detected = sniff_file_type(source)
        if detected.kind != "csv":
            raise UnsupportedSpreadsheetError(f"Expected delimited text, got {detected.kind}")
        data = source.read_bytes()
        text, encoding = self._decode(data)
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=",\t;|")
        except csv.Error:
            dialect = csv.excel_tab if detected.canonical_extension == ".tsv" else csv.excel
        sheet = SheetEnvelope(name="Sheet1")
        for row_number, row in enumerate(csv.reader(io.StringIO(text), dialect), start=1):
            for column, value in enumerate(row, start=1):
                sheet.cells[(row_number, column)] = CellValue(
                    sheet=sheet.name,
                    coordinate=coordinate_from_row_col(row_number, column),
                    row=row_number,
                    column=column,
                    value=value,
                    normalized_value=_normalized_text(value),
                    data_type="text",
                )
                sheet.max_column = max(sheet.max_column, column)
            sheet.max_row = row_number
        original = original_filename or source.name
        return DocumentEnvelope(
            path=source,
            original_filename=original,
            display_filename=_display_filename(original),
            sha256=_sha256_path(source),
            mime_type=f"{detected.mime_type}; charset={encoding}",
            file_kind="csv",
            sheets=[sheet],
        )

    @staticmethod
    def _decode(data: bytes) -> tuple[str, str]:
        for encoding in ("utf-8-sig", "gb18030"):
            try:
                return data.decode(encoding), encoding
            except UnicodeDecodeError:
                continue
        try:
            from charset_normalizer import from_bytes

            best = from_bytes(data).best()
            if best is not None:
                return str(best), best.encoding or "unknown"
        except ImportError:
            pass
        raise UnicodeDecodeError("utf-8", data, 0, min(1, len(data)), "unsupported CSV encoding")


class XlsDocumentAdapter:
    """Read legacy BIFF facts through xlrd when that optional dependency exists."""

    def parse(self, path: str | Path, original_filename: str | None = None) -> DocumentEnvelope:
        source = Path(path)
        detected = sniff_file_type(source)
        if detected.kind != "xls":
            raise UnsupportedSpreadsheetError(f"Expected BIFF workbook, got {detected.kind}")
        try:
            import xlrd  # type: ignore[import-not-found]
        except ImportError as exc:
            raise SpreadsheetDependencyError(
                "Legacy .xls parsing requires the optional 'xlrd>=2.0' dependency"
            ) from exc
        book = xlrd.open_workbook(source, formatting_info=True, on_demand=True)
        sheets: list[SheetEnvelope] = []
        warnings: list[str] = []
        for source_sheet in book.sheets():
            if getattr(source_sheet, "visibility", 0) != 0 or source_sheet.name.casefold().startswith(
                "wpsreserved_"
            ):
                warnings.append(f"hidden_sheet_skipped:{source_sheet.name}")
                book.unload_sheet(source_sheet.name)
                continue
            sheet = SheetEnvelope(name=source_sheet.name)
            for row_index in range(source_sheet.nrows):
                row_number = row_index + 1
                row_info = source_sheet.rowinfo_map.get(row_index)
                if row_info is not None and row_info.hidden:
                    sheet.hidden_rows.add(row_number)
                for col_index in range(source_sheet.ncols):
                    column = col_index + 1
                    col_info = source_sheet.colinfo_map.get(col_index)
                    if col_info is not None:
                        if col_info.hidden:
                            sheet.hidden_columns.add(column)
                        if col_info.hidden or col_info.width < 256:
                            sheet.low_visibility_columns.add(column)
                    source_cell = source_sheet.cell(row_index, col_index)
                    value: Any = source_cell.value
                    if source_cell.ctype == xlrd.XL_CELL_DATE:
                        value = xlrd.xldate.xldate_as_datetime(value, book.datemode)
                    elif source_cell.ctype == xlrd.XL_CELL_BOOLEAN:
                        value = bool(value)
                    elif source_cell.ctype == xlrd.XL_CELL_NUMBER and float(value).is_integer():
                        value = int(value)
                    sheet.cells[(row_number, column)] = CellValue(
                        sheet=sheet.name,
                        coordinate=coordinate_from_row_col(row_number, column),
                        row=row_number,
                        column=column,
                        value=value,
                        normalized_value=_normalized_text(value),
                        data_type=str(source_cell.ctype),
                        hidden_row=row_number in sheet.hidden_rows,
                        hidden_column=column in sheet.hidden_columns,
                        low_visibility_column=column in sheet.low_visibility_columns,
                    )
            for min_row, max_row, min_col, max_col in source_sheet.merged_cells:
                reference = (
                    f"{coordinate_from_row_col(min_row + 1, min_col + 1)}:"
                    f"{coordinate_from_row_col(max_row, max_col)}"
                )
                merged = MergedRange(
                    reference, min_row + 1, min_col + 1, max_row, max_col
                )
                sheet.merged_ranges.append(merged)
                for row in range(merged.min_row, merged.max_row + 1):
                    for column in range(merged.min_col, merged.max_col + 1):
                        existing = sheet.cells.get((row, column))
                        if existing is not None:
                            existing.merged_range = reference
            sheet.max_row = source_sheet.nrows
            sheet.max_column = source_sheet.ncols
            sheets.append(sheet)
            book.unload_sheet(source_sheet.name)
        book.release_resources()
        original = original_filename or source.name
        return DocumentEnvelope(
            path=source,
            original_filename=original,
            display_filename=_display_filename(original),
            sha256=_sha256_path(source),
            mime_type=detected.mime_type,
            file_kind="xls",
            date_1904=bool(book.datemode),
            sheets=sheets,
            warnings=warnings,
        )


def parse_spreadsheet_envelope(
    path: str | Path, original_filename: str | None = None
) -> DocumentEnvelope:
    detected: FileTypeInfo = sniff_file_type(path)
    if detected.kind in {"xlsx", "xlsm"}:
        return XlsxDocumentAdapter().parse(path, original_filename)
    if detected.kind == "xls":
        return XlsDocumentAdapter().parse(path, original_filename)
    if detected.kind == "csv":
        return CsvDocumentAdapter().parse(path, original_filename)
    raise UnsupportedSpreadsheetError(f"Unsupported spreadsheet content type: {detected.kind}")


__all__ = [
    "CsvDocumentAdapter",
    "SpreadsheetDependencyError",
    "UnsupportedSpreadsheetError",
    "XlsDocumentAdapter",
    "XlsxDocumentAdapter",
    "parse_spreadsheet_envelope",
]
