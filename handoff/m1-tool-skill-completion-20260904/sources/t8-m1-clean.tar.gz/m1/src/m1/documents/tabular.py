"""库存、设备、模具等结构化工作簿的通用区域解析。"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from .envelope import CellValue, DocumentEnvelope, SheetEnvelope
from .models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    DocumentTotals,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from .orders import attach_derived_line_evidence, enrich_order_line
from .tabular_semantics import supports_product_semantics

HEADER_ALIASES = {
    "序号": "line_no",
    "编号": "line_no",
    "物料代码": "product_code",
    "物料编码": "product_code",
    "物料编号": "product_code",
    "材料编码": "product_code",
    "材料编号": "product_code",
    "料号": "product_code",
    "产品编码": "product_code",
    "商品编码": "product_code",
    "货品编号": "product_code",
    "模号": "product_code",
    "物料名称": "name_raw",
    "材料名称": "name_raw",
    "原材料名称": "name_raw",
    "商品名称": "name_raw",
    "设备名称": "name_raw",
    "名称": "name_raw",
    "品名": "name_raw",
    "中文品名": "name_raw",
    "货物": "name_raw",
    "外模": "name_raw",
    "模型": "name_raw",
    "物料型号": "model",
    "设备型号": "model",
    "规格型号": "model",
    "型号": "model",
    "数量": "quantity",
    "实际用量": "quantity",
    "单位用量": "quantity",
    "即时库存数量": "quantity",
    "库存数量": "quantity",
    "应收数量": "quantity",
    "申请数量": "quantity",
    "未交数量": "quantity",
    "单位": "unit",
    "计量单位": "unit",
    "颜色": "color",
    "仓库名称": "warehouse",
    "客户料号": "customer_product_code",
    "BOM单号": "bom_number",
    "供应商名称": "supplier_name",
    "客户名称": "customer_name",
    "采购单号": "purchase_order_number",
    "订单单号": "order_number",
    "入库单号": "receipt_number",
    "供应商送货单号": "supplier_delivery_number",
    "系统单号": "system_document_number",
    "客户订单号": "customer_order_number",
    "单据日期": "document_date",
    "交货日期": "delivery_date",
    "建议日期": "suggested_date",
    "设备状况": "status",
    "设备状态": "status",
    "使用状态": "status",
    "用途": "usage",
    "备注": "remark",
    # ---- English column names (m3 inventory / production line CSV compat) ----
    "material_code": "product_code",
    "material_no": "product_code",
    "item_code": "product_code",
    "material_number": "product_code",
    "material_name": "name_raw",
    "item_name": "name_raw",
    "material_desc": "name_raw",
    "description": "name_raw",
    "uom": "unit",
    "unit": "unit",
    "measure_unit": "unit",
    "warehouse": "warehouse",
    "warehouse_name": "warehouse",
    "lot_no": "lot_no",
    "lot_number": "lot_no",
    "batch_no": "lot_no",
    "available_qty": "quantity",
    "available_quantity": "quantity",
    "on_hand_qty": "quantity",
    "stock_qty": "quantity",
    "inventory_qty": "quantity",
    "quantity": "quantity",
    "qty": "quantity",
    "locked_qty": "locked_qty",
    "locked_quantity": "locked_qty",
    "qc_status": "status",
    "quality_status": "status",
    "received_at": "received_at",
    "receive_date": "received_at",
    "base_stock_reserved": "base_stock_reserved",
    "model": "model",
    "model_no": "model",
    "color": "color",
    "book_qty": "book_qty",
    "availability_quality": "availability_quality",
    "source_record_id": "source_record_id",
}

SUBTYPE_TO_TYPE = {
    "inventory_snapshot": "inventory",
    "equipment_register": "equipment",
    "mold_mapping": "mold",
    "purchase_receipt_ledger": "procurement",
    "purchase_requisition_ledger": "procurement",
    "purchase_order_ledger": "procurement",
    "bill_of_materials": "technical_document",
}

_BOM_PURPOSE_RE = re.compile(
    r"(?:(?<![a-z0-9])bom(?![a-z0-9]|单号|编号|编码|版本)|"
    r"bill\s+of\s+materials?|"
    r"物料清单|材料清单|原材料清单|配料表)",
    re.IGNORECASE,
)
_BOM_HEADER_GROUPS = (
    frozenset({"物料代码", "物料编码", "物料编号", "材料编码", "材料编号", "料号"}),
    frozenset({"物料名称", "材料名称", "原材料名称"}),
    frozenset({"实际用量", "单位用量", "单耗", "用量"}),
    frozenset({"材料单价", "成本", "成本价格(元)", "成本总价"}),
)

@dataclass(slots=True)
class TabularRegion:
    sheet: SheetEnvelope
    header_row: int
    start_column: int
    end_column: int
    headers: dict[int, str]
    data_start_row: int
    data_end_row: int


@dataclass(frozen=True, slots=True)
class _TabularClassificationDecision:
    document_subtype: str | None
    authority: str
    confidence: float
    evidence: tuple[dict[str, Any], ...] = ()
    filename_advisory: tuple[dict[str, Any], ...] = ()


def _text(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip()


def _canonical_header(value: Any) -> str | None:
    text = re.sub(r"[\s\n\r：:()（）/\\_-]+", "", _text(value)).upper()
    for label, canonical in HEADER_ALIASES.items():
        normalized = re.sub(r"[\s\n\r：:()（）/\\_-]+", "", label).upper()
        if text == normalized:
            return canonical
    return None


def _skip_tabular_row(region: TabularRegion, row: int) -> bool:
    """Drop empty numbered placeholders and document-control footers only."""

    direct_cells = {
        column: region.sheet.cell(row, column)
        for column in range(region.start_column, region.end_column + 1)
    }
    row_text = " ".join(
        _text(cell.value)
        for cell in direct_cells.values()
        if cell is not None and cell.value not in (None, "")
    )
    if re.search(r"(?:制定|制表)(?:日期)?\s*[：:]", row_text):
        return True

    line_no_column = next(
        (column for column, name in region.headers.items() if name == "line_no"),
        None,
    )
    if line_no_column is None:
        return False
    line_no_cell = direct_cells.get(line_no_column)
    if line_no_cell is None or line_no_cell.value in (None, ""):
        return False
    identity_fields = {"model", "product_code", "name_raw", "quantity"}
    return not any(
        canonical in identity_fields
        and (cell := direct_cells.get(column)) is not None
        and cell.value not in (None, "")
        for column, canonical in region.headers.items()
    )


def _classification_signal(
    *,
    document_subtype: str,
    page_index: int,
    sheet: SheetEnvelope,
    cell: CellValue,
    text: str,
    marker: str,
    role: str,
) -> dict[str, Any]:
    return {
        "document_subtype": document_subtype,
        "role": role,
        "matched_marker": marker,
        "evidence_id": (
            f"spreadsheet:s{page_index}:r{cell.row}:c{cell.column}:classification"
        ),
        "quote": text[:500],
        "source_ref": {
            "sheet": sheet.name,
            "page": page_index + 1,
            "cell": cell.coordinate,
            "part": f"spreadsheet/{sheet.name}/{cell.coordinate}",
        },
    }


def _classification_filename_advisory(
    *, document_subtype: str, marker: str, filename: str
) -> dict[str, Any]:
    return {
        "document_subtype": document_subtype,
        "role": "filename_advisory",
        "matched_marker": marker,
        "quote": filename[:500],
        "source_ref": {
            "part": "source.original_filename",
            "authority": "advisory",
        },
    }


def _classification_decision(
    document_subtype: str | None,
    *,
    evidence: list[dict[str, Any]] | None = None,
    filename_advisory: list[dict[str, Any]] | None = None,
    authority: str | None = None,
) -> _TabularClassificationDecision:
    selected_evidence = tuple((evidence or [])[:12])
    selected_advisory = tuple((filename_advisory or [])[:12])
    effective_authority = authority or (
        "native_content"
        if selected_evidence
        else "advisory"
        if selected_advisory
        else "none"
    )
    confidence = 1.0 if len(selected_evidence) >= 2 else 0.95 if selected_evidence else 0.0
    return _TabularClassificationDecision(
        document_subtype=document_subtype,
        authority=effective_authority,
        confidence=confidence,
        evidence=selected_evidence,
        filename_advisory=selected_advisory,
    )


def _infer_tabular_classification(
    envelope: DocumentEnvelope, hint: str | None = None
) -> _TabularClassificationDecision:
    if hint in SUBTYPE_TO_TYPE:
        return _classification_decision(hint, authority="explicit_hint")

    all_cells: list[tuple[int, SheetEnvelope, CellValue, str]] = []
    sample_cells: list[tuple[int, SheetEnvelope, CellValue, str]] = []
    title_cells: list[tuple[int, SheetEnvelope, CellValue, str]] = []
    for page_index, sheet in enumerate(envelope.sheets):
        ordered = [
            (page_index, sheet, cell, _text(cell.value))
            for cell in sorted(
                sheet.cells.values(), key=lambda value: (value.row, value.column)
            )
            if cell.value not in (None, "") and _text(cell.value)
        ]
        all_cells.extend(ordered)
        sample_cells.extend(ordered[:300])
        title_cells.extend(item for item in ordered if item[2].row <= 5)

    filenames = list(
        dict.fromkeys(
            value
            for value in (envelope.display_filename, envelope.original_filename)
            if value
        )
    )
    sample = "\n".join([*filenames, *(item[3] for item in sample_cells)])
    content_sample = "\n".join(item[3] for item in sample_cells)
    compact_filename = re.sub(r"\s+", "", envelope.display_filename)
    business_title = re.sub(
        r"\s+", "", "\n".join([*filenames, *(item[3] for item in title_cells)])
    )

    def token_evidence(
        subtype: str,
        tokens: tuple[str, ...],
        *,
        entries: list[tuple[int, SheetEnvelope, CellValue, str]] = sample_cells,
        role: str = "header",
    ) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        seen_cells: set[tuple[str, str]] = set()
        for token in tokens:
            match = next((item for item in entries if token in item[3]), None)
            if match is None:
                continue
            page_index, sheet, cell, text = match
            key = (sheet.name, cell.coordinate)
            if key in seen_cells:
                continue
            seen_cells.add(key)
            result.append(
                _classification_signal(
                    document_subtype=subtype,
                    page_index=page_index,
                    sheet=sheet,
                    cell=cell,
                    text=text,
                    marker=token,
                    role=role,
                )
            )
        return result

    def filename_advisory(
        subtype: str, markers: tuple[str, ...]
    ) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for filename in filenames:
            for marker in markers:
                if marker.casefold() not in filename.casefold():
                    continue
                result.append(
                    _classification_filename_advisory(
                        document_subtype=subtype,
                        marker=marker,
                        filename=filename,
                    )
                )
        return result

    receipt_content = "入库单号" in content_sample and "应收数量" in content_sample
    if "采购入库" in compact_filename or receipt_content:
        subtype = "purchase_receipt_ledger"
        return _classification_decision(
            subtype,
            evidence=(
                token_evidence(subtype, ("入库单号", "应收数量"))
                if receipt_content
                else []
            ),
            filename_advisory=filename_advisory(subtype, ("采购入库",)),
        )

    requisition_content = (
        "申请数量" in content_sample and "系统单号" in content_sample
    )
    if "采购申请" in compact_filename or requisition_content:
        subtype = "purchase_requisition_ledger"
        return _classification_decision(
            subtype,
            evidence=(
                token_evidence(subtype, ("申请数量", "系统单号"))
                if requisition_content
                else []
            ),
            filename_advisory=filename_advisory(subtype, ("采购申请",)),
        )

    order_tokens = ("采购单号", "未交数量", "审核状态")
    if all(token in sample for token in order_tokens):
        subtype = "purchase_order_ledger"
        content_supported = all(token in content_sample for token in order_tokens)
        return _classification_decision(
            subtype,
            evidence=(token_evidence(subtype, order_tokens) if content_supported else []),
            filename_advisory=filename_advisory(subtype, order_tokens),
        )

    inventory_supported = (
        ("即时库存" in content_sample or "库存数量" in content_sample)
        and "物料" in content_sample
    )
    inventory_supported = inventory_supported or (
        "available_qty" in content_sample
        and ("material_code" in content_sample or "material_name" in content_sample)
    )
    if (
        ("即时库存" in sample or "库存数量" in sample) and "物料" in sample
    ) or (
        "available_qty" in sample
        and ("material_code" in sample or "material_name" in sample)
    ):
        subtype = "inventory_snapshot"
        return _classification_decision(
            subtype,
            evidence=(
                token_evidence(subtype, ("即时库存", "库存数量", "物料"))
                if inventory_supported
                else []
            ),
            filename_advisory=filename_advisory(
                subtype, ("即时库存", "库存数量", "物料")
            ),
        )

    equipment_headers = ("设备名称", "设备型号", "设备状况", "使用状态")
    equipment_supported = "设备" in content_sample and any(
        token in content_sample for token in equipment_headers
    )
    if "设备" in sample and any(token in sample for token in equipment_headers):
        subtype = "equipment_register"
        return _classification_decision(
            subtype,
            evidence=(
                token_evidence(subtype, ("设备", *equipment_headers))
                if equipment_supported
                else []
            ),
            filename_advisory=filename_advisory(
                subtype, ("设备", *equipment_headers)
            ),
        )

    # Commercial titles outrank incidental BOM or mold words in line-item text.
    if re.search(r"采购合同|采购订单|采购单|购销合同|销售订单|备货单", business_title):
        return _classification_decision(None)

    normalized_cell_entries: dict[
        str, list[tuple[int, SheetEnvelope, CellValue, str]]
    ] = {}
    for item in all_cells:
        normalized = re.sub(
            r"[\s\n\r：:()（）/\\_-]+", "", item[3]
        ).casefold()
        normalized_cell_entries.setdefault(normalized, []).append(item)
    bom_header_evidence: list[dict[str, Any]] = []
    for group in _BOM_HEADER_GROUPS:
        match: tuple[int, SheetEnvelope, CellValue, str] | None = None
        marker = ""
        for label in group:
            normalized = re.sub(
                r"[\s\n\r：:()（）/\\_-]+", "", label
            ).casefold()
            if normalized_cell_entries.get(normalized):
                match = normalized_cell_entries[normalized][0]
                marker = label
                break
        if match is None:
            continue
        page_index, sheet, cell, text = match
        bom_header_evidence.append(
            _classification_signal(
                document_subtype="bill_of_materials",
                page_index=page_index,
                sheet=sheet,
                cell=cell,
                text=text,
                marker=marker,
                role="header",
            )
        )
    purpose_title = next(
        (item for item in title_cells if _BOM_PURPOSE_RE.search(item[3])), None
    )
    purpose_any = next(
        (item for item in all_cells if _BOM_PURPOSE_RE.search(item[3])), None
    )
    bom_header_groups = len(bom_header_evidence)
    if (
        _BOM_PURPOSE_RE.search(business_title)
        or bom_header_groups == len(_BOM_HEADER_GROUPS)
        or (bom_header_groups >= 3 and purpose_any is not None)
    ):
        subtype = "bill_of_materials"
        evidence = list(bom_header_evidence)
        purpose = purpose_title or (
            purpose_any if bom_header_groups >= 3 else None
        )
        if purpose is not None:
            page_index, sheet, cell, text = purpose
            match = _BOM_PURPOSE_RE.search(text)
            evidence.insert(
                0,
                _classification_signal(
                    document_subtype=subtype,
                    page_index=page_index,
                    sheet=sheet,
                    cell=cell,
                    text=text,
                    marker=match.group(0) if match is not None else "BOM",
                    role="title" if cell.row <= 5 else "content_marker",
                ),
            )
        advisory: list[dict[str, Any]] = []
        for filename in filenames:
            match = _BOM_PURPOSE_RE.search(filename)
            if match is not None:
                advisory.append(
                    _classification_filename_advisory(
                        document_subtype=subtype,
                        marker=match.group(0),
                        filename=filename,
                    )
                )
        return _classification_decision(
            subtype,
            evidence=evidence,
            filename_advisory=advisory,
        )

    mold_tokens = ("模号", "模具", "外模类型")
    if any(token in sample for token in mold_tokens):
        subtype = "mold_mapping"
        content_tokens = tuple(token for token in mold_tokens if token in content_sample)
        return _classification_decision(
            subtype,
            evidence=token_evidence(subtype, content_tokens),
            filename_advisory=filename_advisory(subtype, mold_tokens),
        )
    return _classification_decision(None)


def infer_tabular_subtype(
    envelope: DocumentEnvelope, hint: str | None = None
) -> str | None:
    return _infer_tabular_classification(envelope, hint).document_subtype


def find_tabular_regions(sheet: SheetEnvelope) -> list[TabularRegion]:
    candidates: list[tuple[int, int, int, dict[int, str], int]] = []
    # Long ledgers can contain cover pages or instructions before the table.
    # Search the full sheet instead of binding detection to the first 80 rows.
    for row in range(1, sheet.max_row + 1):
        nonempty = [
            column
            for column in range(1, sheet.max_column + 1)
            if (cell := sheet.cell(row, column, inherit_merged=True)) is not None
            and cell.value not in (None, "")
        ]
        if not nonempty:
            continue
        runs: list[list[int]] = []
        for column in nonempty:
            if not runs or column - runs[-1][-1] > 1:
                runs.append([column])
            else:
                runs[-1].append(column)
        for run in runs:
            start, end = run[0], run[-1]
            headers: dict[int, str] = {}
            for column in range(start, end + 1):
                cell = sheet.cell(row, column, inherit_merged=True)
                canonical = _canonical_header(cell.value if cell else None)
                if canonical:
                    headers[column] = canonical
            distinct = len(set(headers.values()))
            if distinct >= 2 or (distinct == 1 and end - start + 1 <= 2):
                candidates.append((row, start, end, headers, distinct))

    # A single visual table may use one empty spacer column between two
    # one-column headers (for example ``模型 | <ratio> | 模号``).  Join only
    # complementary identity/name columns on the same header row; unrelated
    # side-by-side tables remain separate candidates.
    merged_candidates: list[tuple[int, int, int, dict[int, str], int]] = []
    consumed: set[int] = set()
    for index, candidate in enumerate(candidates):
        if index in consumed:
            continue
        row, start, end, headers, distinct = candidate
        merged = candidate
        if distinct == 1:
            for other_index in range(index + 1, len(candidates)):
                if other_index in consumed:
                    continue
                other_row, other_start, other_end, other_headers, other_distinct = (
                    candidates[other_index]
                )
                if (
                    other_row != row
                    or other_distinct != 1
                    or other_start - end != 2
                ):
                    continue
                combined_headers = {**headers, **other_headers}
                if not {"product_code", "name_raw"}.issubset(
                    set(combined_headers.values())
                ):
                    continue
                merged = (
                    row,
                    start,
                    other_end,
                    combined_headers,
                    len(set(combined_headers.values())),
                )
                consumed.add(other_index)
                break
        merged_candidates.append(merged)
    candidates = merged_candidates

    # 高分候选优先；同一列区间只保留最早的真实表头。
    candidates.sort(key=lambda item: (-item[4], item[0], item[1]))
    selected: list[tuple[int, int, int, dict[int, str], int]] = []
    for candidate in candidates:
        row, start, end, _, _ = candidate
        if any(
            not (end < other_start or start > other_end)
            and abs(row - other_row) <= 2
            for other_row, other_start, other_end, _, _ in selected
        ):
            continue
        selected.append(candidate)

    ordered_selected = sorted(selected)
    regions: list[TabularRegion] = []
    for header_row, start, end, headers, _ in ordered_selected:
        # 包含表头跨度内未命名列，确保原始内容不丢失。
        raw_headers: dict[int, str] = {}
        for column in range(start, end + 1):
            cell = sheet.cell(header_row, column, inherit_merged=True)
            raw_headers[column] = _text(cell.value if cell else None) or f"Column {column}"
        next_overlapping_header = min(
            (
                other_row
                for other_row, other_start, other_end, _, _ in ordered_selected
                if other_row > header_row
                and not (other_end < start or other_start > end)
            ),
            default=sheet.max_row + 1,
        )
        scan_end = min(sheet.max_row, next_overlapping_header - 1)
        data_end = header_row
        empty_streak = 0
        for row in range(header_row + 1, scan_end + 1):
            values = [
                sheet.cell(row, column, inherit_merged=True).value
                if sheet.cell(row, column, inherit_merged=True)
                else None
                for column in range(start, end + 1)
            ]
            if all(value in (None, "") for value in values):
                empty_streak += 1
                if empty_streak >= 2:
                    break
                continue
            empty_streak = 0
            text = " ".join(_text(value) for value in values)
            if re.search(r"^(合计|总计|制表|审核|签字|条款)", text):
                break
            data_end = row
        if data_end > header_row:
            # 用 raw header 暂存在 headers 的 extra 字段不合适，region 读取时再取。
            regions.append(
                TabularRegion(
                    sheet=sheet,
                    header_row=header_row,
                    start_column=start,
                    end_column=end,
                    headers=headers,
                    data_start_row=header_row + 1,
                    data_end_row=data_end,
                )
            )
    return regions


def build_tabular_document(
    envelope: DocumentEnvelope, subtype: str
) -> DocumentRecord:
    apply_product_semantics = supports_product_semantics(subtype)
    regions = [region for sheet in envelope.sheets for region in find_tabular_regions(sheet)]
    field_meta: dict[str, FieldMetadata] = {}
    issues: list[ValidationIssue] = []
    lines: list[OrderLine] = []
    title = _document_title(envelope)
    line_index = 0
    for region_index, region in enumerate(regions):
        raw_headers = {
            column: _text(
                (region.sheet.cell(region.header_row, column, inherit_merged=True) or CellValue("", "", 0, 0)).value
            )
            or f"Column {column}"
            for column in range(region.start_column, region.end_column + 1)
        }
        for row in range(region.data_start_row, region.data_end_row + 1):
            if _skip_tabular_row(region, row):
                continue
            cells = {
                column: region.sheet.cell(row, column, inherit_merged=True)
                for column in range(region.start_column, region.end_column + 1)
            }
            if all(cell is None or cell.value in (None, "") for cell in cells.values()):
                continue
            values: dict[str, Any] = {}
            custom: dict[str, Any] = {}
            raw_columns: dict[str, Any] = {}
            for column, cell in cells.items():
                raw_value = cell.value if cell else None
                raw_header = raw_headers[column]
                raw_columns[raw_header] = raw_value
                canonical = region.headers.get(column)
                if canonical:
                    values[canonical] = raw_value
                else:
                    custom[raw_header] = raw_value
            # 标准字段之外的映射仍保留在 custom_fields。
            for key in (
                "warehouse",
                "customer_product_code",
                "bom_number",
                "status",
                "usage",
                "supplier_name",
                "customer_name",
                "purchase_order_number",
                "order_number",
                "receipt_number",
                "supplier_delivery_number",
                "system_document_number",
                "customer_order_number",
                "document_date",
                "delivery_date",
                "suggested_date",
                # 库存/台账附加字段(inventory snapshot / ledgers)
                "lot_no",
                "received_at",
                "base_stock_reserved",
                "availability_quality",
                "source_record_id",
                "book_qty",
            ):
                if key in values:
                    custom[key] = values.pop(key)
            line_index += 1
            line = OrderLine(
                line_id=f"{region.sheet.name}:{row}:{region_index + 1}",
                line_no=values.get("line_no") or line_index,
                model=_string_or_none(values.get("model")),
                product_code=_string_or_none(values.get("product_code")),
                name_raw=_string_or_none(values.get("name_raw")),
                specification_raw=None,
                color=_string_or_none(values.get("color")),
                quantity=_numeric(values.get("quantity")),
                unit=_string_or_none(values.get("unit")),
                remark=_string_or_none(values.get("remark")),
                custom_fields=custom,
                raw_columns=raw_columns,
            )
            if line.name_raw and apply_product_semantics:
                issues.extend(enrich_order_line(line))
            elif apply_product_semantics and (line.model or line.product_code):
                # Ledgers often omit a product-name column while retaining the
                # exact material code and model.  Build a searchable display name
                # without pretending it came from a missing source-name cell.
                line.name_normalized = " ".join(
                    value for value in (line.product_code, line.model) if value
                )
                line.full_product_name = line.name_normalized
                line.product_category = "other"
            lines.append(line)
            for canonical in (
                "line_no", "model", "product_code", "name_raw", "quantity", "unit", "color", "remark"
            ):
                column = next((col for col, name in region.headers.items() if name == canonical), None)
                if column is None:
                    continue
                cell = cells.get(column)
                if cell is None:
                    continue
                field_meta[f"$.lines[{line_index - 1}].{canonical}"] = FieldMetadata(
                    source_refs=[_source_ref(cell)],
                    inherited_from_merge=bool(cell.inherited_from),
                )
            line_no_path = f"$.lines[{line_index - 1}].line_no"
            if line_no_path not in field_meta:
                row_anchor = next(
                    (
                        cell
                        for _, cell in sorted(cells.items())
                        if cell is not None and cell.value not in (None, "")
                    ),
                    None,
                )
                if row_anchor is not None:
                    field_meta[line_no_path] = FieldMetadata(
                        source_refs=[_source_ref(row_anchor)],
                        inherited_from_merge=bool(row_anchor.inherited_from),
                        inferred=True,
                        review_required=False,
                    )

    if apply_product_semantics:
        attach_derived_line_evidence(lines, field_meta)

    if subtype == "mold_mapping":
        seen_molds: dict[str, tuple[int, str | None]] = {}
        for index, line in enumerate(lines):
            code = _string_or_none(line.product_code)
            if (
                code
                and not re.search(r"\d", code)
                and not re.fullmatch(r"[A-Za-z][A-Za-z0-9._/+\-]{0,63}", code)
            ):
                source_path = f"$.lines[{index}].product_code"
                source_meta = field_meta.get(source_path)
                issues.append(
                    ValidationIssue(
                        code="MOLD_IDENTIFIER_AMBIGUOUS",
                        severity="warning",
                        message="模号列中的值更像自然语言说明，已原样保留并等待复核。",
                        paths=[source_path],
                        source_refs=(
                            list(source_meta.source_refs) if source_meta else []
                        ),
                        actual=code,
                        suggestion="请确认该值是合法模号、库位说明还是缺失编号。",
                    )
                )
            if not code:
                continue
            key = re.sub(r"\s+", "", code).casefold()
            prior = seen_molds.get(key)
            if prior is None:
                seen_molds[key] = (index, line.name_raw)
                continue
            prior_index, prior_name = prior
            if _text(prior_name).casefold() == _text(line.name_raw).casefold():
                continue
            paths = [
                f"$.lines[{prior_index}].product_code",
                f"$.lines[{index}].product_code",
            ]
            refs = []
            for path in paths:
                meta = field_meta.get(path)
                if meta is not None:
                    refs.extend(meta.source_refs)
            issues.append(
                ValidationIssue(
                    code="MOLD_IDENTIFIER_CONFLICT",
                    severity="warning",
                    message="同一模号对应多个不同描述，已保留全部来源记录。",
                    paths=paths,
                    source_refs=refs,
                    expected=prior_name,
                    actual=line.name_raw,
                    suggestion="请人工确认是重复记录、版本差异还是编号录入错误。",
                )
            )

    if not regions:
        issues.append(
            ValidationIssue(
                code="TABLE_REGION_NOT_FOUND",
                severity="error",
                message="未识别到结构化表格区域。",
                paths=["$.lines"],
            )
        )
    elif not lines:
        issues.append(
            ValidationIssue(
                code="TABLE_ROWS_EMPTY",
                severity="error",
                message="识别到表头，但没有有效数据行。",
                paths=["$.lines"],
            )
        )

    quantity = _sum(line.quantity for line in lines)
    quantity_by_unit: dict[str, int | Decimal] = {}
    if subtype == "inventory_snapshot":
        grouped: dict[str, list[int | Decimal | None]] = {}
        for line in lines:
            if line.quantity is None:
                continue
            grouped.setdefault(line.unit or "UNSPECIFIED", []).append(line.quantity)
        quantity_by_unit = {
            unit: subtotal
            for unit, values in grouped.items()
            if (subtotal := _sum(values)) is not None
        }
        if len(quantity_by_unit) > 1:
            quantity = None
    system_calculated: dict[str, Any] = {
        "quantity": quantity,
        "row_count": len(lines),
    }
    if len(quantity_by_unit) > 1:
        system_calculated["by_unit"] = quantity_by_unit
    totals = DocumentTotals(
        calculated_quantity=quantity,
        system_calculated=system_calculated,
    )
    from .adapters.archive import repair_display_filename

    display_filename = repair_display_filename(envelope.original_filename)
    source = DocumentSource(
        original_filename=envelope.original_filename,
        display_filename=display_filename,
        sha256=envelope.sha256,
        mime_type=envelope.mime_type,
        sheet=envelope.sheets[0].name if len(envelope.sheets) == 1 else None,
    )
    return DocumentRecord(
        source=source,
        document_type=SUBTYPE_TO_TYPE[subtype],
        document_subtype=subtype,
        header=DocumentHeader(title=title or _default_title(subtype), issuer=_document_issuer(envelope)),
        lines=lines,
        totals=totals,
        field_meta=field_meta,
        validation_issues=issues,
        extraction={
            "adapter": envelope.file_kind,
            "sheet_count": len(envelope.sheets),
            "table_regions": [
                {
                    "sheet": region.sheet.name,
                    "header_row": region.header_row,
                    "start_column": region.start_column,
                    "end_column": region.end_column,
                    "data_start_row": region.data_start_row,
                    "data_end_row": region.data_end_row,
                }
                for region in regions
            ],
        },
    )


def _source_ref(cell: CellValue) -> SourceReference:
    return SourceReference(sheet=cell.sheet, cell=cell.coordinate, range=cell.merged_range)


def _document_title(envelope: DocumentEnvelope) -> str | None:
    candidates: list[str] = []
    for sheet in envelope.sheets:
        for row in range(1, min(sheet.max_row, 10) + 1):
            values = [
                _text(cell.value)
                for column in range(1, sheet.max_column + 1)
                if (cell := sheet.cell(row, column, inherit_merged=True)) is not None
                and cell.value not in (None, "")
            ]
            if values and not all(_canonical_header(value) for value in values):
                candidates.extend(dict.fromkeys(values))
    return next(
        (
            value
            for value in candidates
            if re.search(r"一览表|库存|映射|明细|台账|清单", value)
        ),
        None,
    )


def _document_issuer(envelope: DocumentEnvelope) -> str | None:
    for sheet in envelope.sheets:
        for row in range(1, min(sheet.max_row, 5) + 1):
            for column in range(1, min(sheet.max_column, 8) + 1):
                cell = sheet.cell(row, column, inherit_merged=True)
                value = _text(cell.value) if cell else ""
                if value.endswith(("有限公司", "公司", "集团")):
                    return value
    return None


def _default_title(subtype: str) -> str:
    return {
        "inventory_snapshot": "库存快照",
        "equipment_register": "设备台账",
        "mold_mapping": "模具映射",
        "purchase_receipt_ledger": "采购入库台账",
        "purchase_requisition_ledger": "采购申请台账",
        "purchase_order_ledger": "采购订单台账",
        "bill_of_materials": "物料清单",
    }.get(subtype, "结构化数据表")


def _none_if_blank(value: Any) -> Any:
    return None if value in (None, "") else value


def _string_or_none(value: Any) -> str | None:
    if value in (None, ""):
        return None
    return _text(value)


def _numeric(value: Any) -> int | Decimal | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    try:
        number = Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None
    return int(number) if number == number.to_integral_value() else number


def _sum(values) -> int | Decimal | None:
    total = Decimal(0)
    found = False
    for value in values:
        if value is not None:
            total += Decimal(value)
            found = True
    if not found:
        return None
    return int(total) if total == total.to_integral_value() else total


__all__ = [
    "TabularRegion",
    "build_tabular_document",
    "find_tabular_regions",
    "infer_tabular_subtype",
]
