"""Compile validated tabular v1 evidence plans into DocumentRecord facts."""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any

from .envelope import CellValue, DocumentEnvelope, SheetEnvelope
from .models import (
    DocumentRecord,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from .tabular_schema import (
    _DATE_TARGETS,
    _NUMERIC_FIELDS,
    _RECOVERED_LINE_ISSUES,
    ColumnMapping,
    HeaderFieldMapping,
    RecordOrientation,
    RowMapping,
    TableMapping,
    TabularSchemaPlan,
    TabularSchemaSafetyError,
    _constant_column_cells,
    _constant_row_cells,
    _header_target,
    _inline_value,
    _line_target,
    _mapping_labels,
    _nonempty,
    _normalized,
    _number,
    _parse_date,
    _real_cell,
    _safe_custom_key,
    _semantic_field,
    _sheets,
    _table_cell,
    _table_record_indices,
    _text,
    _target_is_canonical,
    _validate_field_labels,
    validate_plan,
)


def _source_ref(cell: CellValue) -> SourceReference:
    return SourceReference(
        sheet=cell.sheet, cell=cell.coordinate, range=cell.merged_range
    )


def _line_value(field_name: str, value: Any) -> Any:
    if field_name in _NUMERIC_FIELDS:
        return _number(value)
    if field_name == "line_no":
        number = _number(value)
        return number if number is not None else _text(value) or None
    return _text(value) or None


def _can_replace(record: DocumentRecord, path: str, current: Any) -> bool:
    """Model-produced plans may fill gaps but never replace retained facts."""

    del record, path
    return current in (None, "")


def _table_region(plan: TabularSchemaPlan, table: TableMapping, index: int) -> str:
    if table.region_id:
        return table.region_id
    same_sheet = [item for item in plan.tables if item.sheet == table.sheet]
    return "" if len(same_sheet) == 1 else f"table-{index + 1}"


def _source_axis_name(
    sheet: SheetEnvelope,
    table: TableMapping,
    cell: CellValue,
) -> str:
    if table.orientation == "rows":
        parts = [
            _text(header.value)
            for row in table.header_rows
            if _nonempty(header := sheet.cell(row, cell.column, inherit_merged=True))
        ]
        fallback = f"Column {cell.column}"
    else:
        parts = [
            _text(header.value)
            for column in table.header_columns
            if _nonempty(header := sheet.cell(cell.row, column, inherit_merged=True))
        ]
        fallback = f"Row {cell.row}"
    return " / ".join(dict.fromkeys(part for part in parts if part)) or fallback


def _source_record_cells(
    sheet: SheetEnvelope,
    table: TableMapping,
    record_index: int,
    *,
    table_index: int,
    peer_mapping_axes: list[tuple[int, set[int]]],
    excluded_positions: set[tuple[int, int]],
) -> list[CellValue]:
    def belongs_to_region(cell: CellValue) -> bool:
        if len(peer_mapping_axes) <= 1:
            return True
        axis = cell.column if table.orientation == "rows" else cell.row
        distances = [
            (min(abs(axis - mapped_axis) for mapped_axis in mapped_axes), peer_index)
            for peer_index, mapped_axes in peer_mapping_axes
        ]
        nearest_distance = min(distance for distance, _peer_index in distances)
        owners = [
            peer_index
            for distance, peer_index in distances
            if distance == nearest_distance
        ]
        if len(owners) != 1:
            raise TabularSchemaSafetyError(
                "non-empty cell is ambiguous between table regions: "
                f"{sheet.name}!{cell.coordinate}"
            )
        return owners[0] == table_index

    by_coordinate = {
        cell.coordinate: cell
        for cell in sheet.cells.values()
        if _nonempty(cell)
        and (cell.row, cell.column) not in excluded_positions
        and (
            (table.orientation == "rows" and cell.row == record_index)
            or (table.orientation == "columns" and cell.column == record_index)
        )
        and belongs_to_region(cell)
    }
    for merged in sheet.merged_ranges:
        if (
            table.orientation == "rows"
            and merged.min_row <= record_index <= merged.max_row
        ):
            positions = (
                (record_index, column)
                for column in range(merged.min_col, merged.max_col + 1)
            )
        elif (
            table.orientation == "columns"
            and merged.min_col <= record_index <= merged.max_col
        ):
            positions = (
                (row, record_index) for row in range(merged.min_row, merged.max_row + 1)
            )
        else:
            continue
        for row, column in positions:
            cell = sheet.cell(row, column, inherit_merged=True)
            if (
                _nonempty(cell)
                and (cell.row, cell.column) not in excluded_positions
                and belongs_to_region(cell)
            ):
                by_coordinate.setdefault(cell.coordinate, cell)
    cells = list(by_coordinate.values())
    return sorted(
        cells,
        key=(
            (lambda cell: cell.column)
            if table.orientation == "rows"
            else (lambda cell: cell.row)
        ),
    )


def _preserve_raw_cell(
    line: OrderLine,
    sheet: SheetEnvelope,
    table: TableMapping,
    cell: CellValue,
) -> None:
    label = _source_axis_name(sheet, table, cell)
    key = label if label not in line.raw_columns else f"{label} [{cell.coordinate}]"
    line.raw_columns.setdefault(key, cell.value)


def _table_region_footprint(
    sheet: SheetEnvelope,
    table: TableMapping,
    record_indices: list[int],
) -> set[tuple[int, int]]:
    mappings: list[ColumnMapping | RowMapping] = (
        list(table.columns)
        if table.orientation == "rows"
        else list(table.row_fields)
    )
    labels = [
        cell
        for mapping in mappings
        for cell in _mapping_labels(sheet, table, mapping)
    ]
    if table.orientation == "rows":
        rows = {*table.header_rows, *record_indices, *(cell.row for cell in labels)}
        columns = {
            *(mapping.column for mapping in table.columns),
            *(cell.column for cell in labels),
        }
        if not rows or not columns:
            return set()
        return {
            (row, column)
            for row in rows
            for column in range(min(columns), max(columns) + 1)
        }
    rows = {
        *(mapping.row for mapping in table.row_fields),
        *(cell.row for cell in labels),
    }
    columns = {
        *table.header_columns,
        *record_indices,
        *(cell.column for cell in labels),
    }
    if not rows or not columns:
        return set()
    return {
        (row, column)
        for row in range(min(rows), max(rows) + 1)
        for column in columns
    }


def _line_id(
    sheet: str,
    orientation: RecordOrientation,
    record_index: int,
    region: str,
) -> str:
    if orientation == "rows" and not region:
        return f"schema:{sheet}:{record_index}"
    axis = "column" if orientation == "columns" else "row"
    region_part = f":{region}" if region else ""
    return f"schema:{sheet}{region_part}:{axis}:{record_index}"


def _existing_line(
    lines: list[OrderLine],
    sheet: str,
    orientation: RecordOrientation,
    record_index: int,
    region: str,
) -> OrderLine | None:
    axis = "column" if orientation == "columns" else "row"
    prefixes = [f"schema:{sheet}:{region}:{axis}:{record_index}"] if region else []
    if orientation == "rows" and not region:
        prefixes.extend([f"{sheet}:{record_index}", f"schema:{sheet}:{record_index}"])
    return next(
        (
            line
            for line in lines
            if any(
                line.line_id == prefix or line.line_id.startswith(prefix + ":")
                for prefix in prefixes
            )
        ),
        None,
    )


_LINE_IDENTITY_FIELDS = {
    "model",
    "product_code",
    "name_raw",
    "specification_raw",
}
_CELL_COORDINATE_RE = re.compile(r"^\$?([A-Z]+)\$?(\d+)$", re.I)


def _normalized_cell_coordinate(coordinate: str) -> str | None:
    match = _CELL_COORDINATE_RE.fullmatch(str(coordinate or "").strip())
    if match is None:
        return None
    return f"{match.group(1).upper()}{int(match.group(2))}"


def _normalized_cell_range(value: str | None) -> str | None:
    parts = str(value or "").strip().split(":")
    if len(parts) != 2:
        return None
    start, end = (_normalized_cell_coordinate(part) for part in parts)
    if start is None or end is None:
        return None
    return f"{start}:{end}"


def _same_record_axis(
    left: str,
    right: str,
    orientation: RecordOrientation,
) -> bool:
    left_match = _CELL_COORDINATE_RE.fullmatch(str(left or "").strip())
    right_match = _CELL_COORDINATE_RE.fullmatch(str(right or "").strip())
    if left_match is None or right_match is None:
        return False
    if orientation == "rows":
        return int(left_match.group(2)) == int(right_match.group(2))
    return left_match.group(1).casefold() == right_match.group(1).casefold()


def _identity_has_exact_source_cell(
    record: DocumentRecord,
    line_index: int,
    *,
    target: str,
    sheet: str,
    cell: CellValue,
    orientation: RecordOrientation,
) -> bool:
    field_name = target.removeprefix("$.lines[*].")
    metadata = record.field_meta.get(f"$.lines[{line_index}].{field_name}")
    expected_cell = _normalized_cell_coordinate(cell.coordinate)
    if metadata is None or expected_cell is None:
        return False
    mapped_range = _normalized_cell_range(cell.merged_range)
    for source_ref in metadata.source_refs:
        source_cell = _normalized_cell_coordinate(source_ref.cell or "")
        if source_ref.sheet != sheet or source_cell is None:
            continue
        if source_cell == expected_cell:
            return True
        # Merged cells share one physical source value. Treat inherited
        # coordinates as equivalent only within the current record axis; a
        # merge spanning multiple rows/columns must not collapse two records.
        if (
            mapped_range is not None
            and _normalized_cell_range(source_ref.range) == mapped_range
            and _same_record_axis(source_cell, expected_cell, orientation)
        ):
            return True
    return False


def _line_identity_value(line: OrderLine, target: str) -> Any:
    prefix = "$.lines[*]."
    if not target.startswith(prefix):
        return None
    field_name = target[len(prefix) :]
    if field_name not in _LINE_IDENTITY_FIELDS:
        return None
    return getattr(line, field_name, None)


def _matching_baseline_line(
    record: DocumentRecord,
    baseline_lines: list[OrderLine],
    claimed_baseline_ids: set[int],
    mapped_cells: dict[str, CellValue | None],
    *,
    sheet: str,
    orientation: RecordOrientation,
) -> OrderLine | None:
    """Reuse a deterministic row only with exact identity-cell evidence."""

    matches: list[OrderLine] = []
    for line_index, candidate in enumerate(baseline_lines):
        if id(candidate) in claimed_baseline_ids:
            continue
        identity_matches = 0
        identity_conflict = False
        for target, cell in mapped_cells.items():
            if not _nonempty(cell):
                continue
            current = _line_identity_value(candidate, target)
            if current in (None, ""):
                continue
            field_name = target.removeprefix("$.lines[*].")
            incoming = _line_value(field_name, cell.value)
            if incoming is None or _normalized(current) != _normalized(incoming):
                identity_conflict = True
                break
            if not _identity_has_exact_source_cell(
                record,
                line_index,
                target=target,
                sheet=sheet,
                cell=cell,
                orientation=orientation,
            ):
                identity_conflict = True
                break
            identity_matches += 1
        if identity_matches and not identity_conflict:
            matches.append(candidate)
    return matches[0] if len(matches) == 1 else None


def _metadata(cells: list[CellValue]) -> FieldMetadata:
    return FieldMetadata(
        source_refs=[_source_ref(cell) for cell in cells],
        confidence=0.82,
        inferred=True,
        inherited_from_merge=any(
            bool(cell.merged_range or cell.inherited_from) for cell in cells
        ),
    )


def _set_line_target(
    record: DocumentRecord,
    line: OrderLine,
    line_index: int,
    target: str,
    cell: CellValue,
) -> None:
    prefix = "$.lines[*]."
    if not target.startswith(prefix):
        raise TabularSchemaSafetyError(f"unsupported line target: {target}")
    path = target.replace("$.lines[*]", f"$.lines[{line_index}]", 1)
    parts = target[len(prefix) :].split(".")
    value: Any = cell.value
    if len(parts) == 1:
        field_name = parts[0]
        current = getattr(line, field_name)
        if not _can_replace(record, path, current):
            return
        value = _line_value(field_name, value)
        if value is None:
            return
        setattr(line, field_name, value)
    elif parts[0] == "custom_fields":
        key = parts[1]
        if not _can_replace(record, path, line.custom_fields.get(key)):
            return
        line.custom_fields[key] = value
    elif parts[:1] == ["name_attributes"] and len(parts) == 2:
        key = parts[1]
        if not _can_replace(record, path, getattr(line.name_attributes, key)):
            return
        setattr(line.name_attributes, key, _text(value) or None)
    elif parts[:2] == ["name_attributes", "custom"] and len(parts) == 3:
        key = parts[2]
        if not _can_replace(record, path, line.name_attributes.custom.get(key)):
            return
        line.name_attributes.custom[key] = value
    else:  # pragma: no cover - target validation makes this unreachable
        raise TabularSchemaSafetyError(f"unsupported line target: {target}")
    record.field_meta[path] = _metadata([cell])


@dataclass(slots=True)
class _AppliedTables:
    record_lines: dict[
        tuple[str, str, RecordOrientation, int], tuple[int, OrderLine]
    ] = field(default_factory=dict)
    region_lines: dict[tuple[str, str], list[tuple[int, OrderLine]]] = field(
        default_factory=lambda: defaultdict(list)
    )

    def line_for_cell(
        self, mapping: HeaderFieldMapping, cell: CellValue
    ) -> tuple[int, OrderLine] | None:
        region = mapping.region_id or ""
        candidates = [
            line
            for (
                candidate_region,
                sheet,
                orientation,
                index,
            ), line in self.record_lines.items()
            if sheet == mapping.sheet
            and (not region or candidate_region == region)
            and (
                (orientation == "rows" and index == cell.row)
                or (orientation == "columns" and index == cell.column)
            )
        ]
        return candidates[0] if len(candidates) == 1 else None


def _apply_tables(
    envelope: DocumentEnvelope, record: DocumentRecord, plan: TabularSchemaPlan
) -> _AppliedTables:
    applied = _AppliedTables()
    baseline_lines = list(record.lines)
    claimed_baseline_ids: set[int] = set()
    sheets = _sheets(envelope)
    record_indices_by_table = [
        _table_record_indices(sheets[planned_table.sheet], planned_table)
        for planned_table in plan.tables
    ]
    record_index_sets = [set(indices) for indices in record_indices_by_table]
    table_region_footprints = [
        _table_region_footprint(
            sheets[planned_table.sheet],
            planned_table,
            record_indices_by_table[index],
        )
        for index, planned_table in enumerate(plan.tables)
    ]
    for table_index, table in enumerate(plan.tables):
        sheet = sheets[table.sheet]
        region = _table_region(plan, table, table_index)
        mappings: list[ColumnMapping | RowMapping] = (
            list(table.columns)
            if table.orientation == "rows"
            else list(table.row_fields)
        )
        for mapping in mappings:
            labels = _mapping_labels(sheet, table, mapping)
            target = _line_target(mapping)
            if (
                ".custom_fields." in target
                and _semantic_field(target) not in {"order_number", "delivery_date"}
                and not _validate_field_labels(
                    _semantic_field(target),
                    labels,
                    reject_known_mismatch=False,
                )
            ):
                record.validation_issues.append(
                    ValidationIssue(
                        code="TABULAR_SCHEMA_LABEL_REVIEW",
                        severity="warning",
                        message=(
                            "A model mapped a previously unknown source label; the "
                            "coordinate-bound canonical or custom value requires review."
                        ),
                        paths=[target],
                        source_refs=[_source_ref(cell) for cell in labels],
                    )
                )
        for record_index in record_indices_by_table[table_index]:
            peer_mapping_axes: list[tuple[int, set[int]]] = []
            for peer_index, peer in enumerate(plan.tables):
                if (
                    peer.sheet != table.sheet
                    or peer.orientation != table.orientation
                    or record_index not in record_index_sets[peer_index]
                ):
                    continue
                peer_axes = (
                    {mapping.column for mapping in peer.columns}
                    if peer.orientation == "rows"
                    else {mapping.row for mapping in peer.row_fields}
                )
                if peer_axes:
                    peer_mapping_axes.append((peer_index, peer_axes))
            excluded_positions: set[tuple[int, int]] = set()
            for peer_index, peer in enumerate(plan.tables):
                if peer.sheet == table.sheet and peer.orientation != table.orientation:
                    excluded_positions.update(table_region_footprints[peer_index])
            mapped_cells = {
                _line_target(item): _table_cell(sheet, table, item, record_index)
                for item in mappings
            }
            if not any(_nonempty(cell) for cell in mapped_cells.values()):
                continue
            if any(
                _nonempty(cell)
                and (cell.row, cell.column) in excluded_positions
                for cell in mapped_cells.values()
            ):
                raise TabularSchemaSafetyError(
                    "table mapping overlaps another orientation region"
                )
            line = _existing_line(
                record.lines, sheet.name, table.orientation, record_index, region
            )
            if line is None and region:
                line = _matching_baseline_line(
                    record,
                    baseline_lines,
                    claimed_baseline_ids,
                    mapped_cells,
                    sheet=sheet.name,
                    orientation=table.orientation,
                )
            # Preserve the old single-table row-plan behavior, but never merge
            # multiple regions or transposed records by ordinal position. Those
            # layouts require a coordinate identity to avoid cross-record mixing.
            allow_legacy_sequential_reuse = (
                len(plan.tables) == 1
                and table.region_id is None
                and table.orientation == "rows"
            )
            if line is None and allow_legacy_sequential_reuse:
                line = next(
                    (
                        candidate
                        for candidate in baseline_lines
                        if id(candidate) not in claimed_baseline_ids
                    ),
                    None,
                )
            if line is None:
                line = OrderLine(
                    line_id=_line_id(
                        sheet.name, table.orientation, record_index, region
                    )
                )
                record.lines.append(line)
            elif any(line is candidate for candidate in baseline_lines):
                claimed_baseline_ids.add(id(line))
            line_index = record.lines.index(line)
            applied.record_lines[
                (region, sheet.name, table.orientation, record_index)
            ] = (line_index, line)
            applied.region_lines[(sheet.name, region)].append((line_index, line))
            preserved_coordinates: set[str] = set()
            for source_cell in _source_record_cells(
                sheet,
                table,
                record_index,
                table_index=table_index,
                peer_mapping_axes=peer_mapping_axes,
                excluded_positions=excluded_positions,
            ):
                _preserve_raw_cell(line, sheet, table, source_cell)
                preserved_coordinates.add(source_cell.coordinate)
            for mapping in mappings:
                target = _line_target(mapping)
                cell = mapped_cells[target]
                if not _nonempty(cell):
                    continue
                if cell.coordinate not in preserved_coordinates:
                    _preserve_raw_cell(line, sheet, table, cell)
                _set_line_target(record, line, line_index, target, cell)
    return applied


def _set_document_target(
    record: DocumentRecord,
    target: str,
    value: Any,
    cells: list[CellValue],
) -> None:
    value_text = _text(value)
    if not value_text:
        return
    parts = target[2:].split(".")
    if parts[0] == "header":
        field_name = parts[1]
        if target in _DATE_TARGETS:
            if field_name.startswith("delivery_date"):
                raw_name, standard_name = "delivery_date_raw", "delivery_date_standard"
            else:
                raw_name, standard_name = "date_raw", "date_standard"
            raw_path = f"$.header.{raw_name}"
            if _can_replace(record, raw_path, getattr(record.header, raw_name)):
                setattr(record.header, raw_name, value_text)
                record.field_meta[raw_path] = _metadata(cells)
            parsed = _parse_date(value)
            standard_path = f"$.header.{standard_name}"
            if parsed is not None and _can_replace(
                record, standard_path, getattr(record.header, standard_name)
            ):
                setattr(record.header, standard_name, parsed)
                record.field_meta[standard_path] = _metadata(cells)
            return
        current = getattr(record.header, field_name)
        if not _can_replace(record, target, current):
            return
        if field_name == "currency":
            value_text = {
                "人民币": "CNY",
                "CNY": "CNY",
                "RMB": "CNY",
                "美元": "USD",
                "USD": "USD",
                "欧元": "EUR",
                "EUR": "EUR",
            }.get(value_text.upper(), value_text.upper())
        setattr(record.header, field_name, value_text)
        record.field_meta[target] = _metadata(cells)
        return
    if parts[0] == "totals":
        if parts[1] == "source_declared":
            key = parts[2]
            if _can_replace(record, target, record.totals.source_declared.get(key)):
                record.totals.source_declared[key] = value
                record.field_meta[target] = _metadata(cells)
            return
        field_name = parts[1]
        if not _can_replace(record, target, getattr(record.totals, field_name)):
            return
        converted = (
            _number(value)
            if field_name.endswith(("quantity", "amount"))
            else value_text
        )
        if converted is not None:
            setattr(record.totals, field_name, converted)
            record.field_meta[target] = _metadata(cells)
        return
    key = parts[2]
    custom = record.extraction.setdefault("custom_fields", {})
    if not isinstance(custom, dict):
        custom = {}
        record.extraction["custom_fields"] = custom
    if _can_replace(record, target, custom.get(key)):
        custom[key] = value
        record.field_meta[target] = _metadata(cells)


def _apply_multi_order(
    record: DocumentRecord,
    mapping: HeaderFieldMapping,
    cells: list[CellValue],
    applied_tables: _AppliedTables,
) -> None:
    groups: dict[str, list[str]] = defaultdict(list)
    refs: list[SourceReference] = []
    for cell in cells:
        value = _text(cell.value)
        row_line = applied_tables.line_for_cell(mapping, cell)
        if row_line is None:
            continue
        index, line = row_line
        path = f"$.lines[{index}].custom_fields.order_number"
        current = line.custom_fields.get("order_number")
        metadata = record.field_meta.get(path)
        replace = current in (None, "") or (
            metadata is not None and metadata.confidence < 0.9
        )
        if replace:
            line.custom_fields["order_number"] = value
            record.field_meta[path] = _metadata([cell])
        else:
            preserved = _text(current)
            if preserved != value:
                record.validation_issues.append(
                    ValidationIssue(
                        code="TABULAR_SCHEMA_LINE_CONFLICT",
                        severity="warning",
                        message=(
                            "The planned row conflicted with a protected order number; "
                            "the existing fact was preserved."
                        ),
                        paths=[path],
                        source_refs=[_source_ref(cell)],
                        expected=preserved,
                        actual=value,
                    )
                )
            value = preserved
        line.raw_columns.setdefault("order_number", cell.value)
        groups[value].append(line.line_id)
        refs.append(_source_ref(cell))
    if not groups:
        return
    record.extraction["order_groups"] = [
        {"order_number": value, "line_ids": line_ids}
        for value, line_ids in sorted(groups.items())
    ]
    record.validation_issues.append(
        ValidationIssue(
            code="MULTI_ORDER_DOCUMENT",
            severity="warning",
            message="Multiple source order numbers were grouped by coordinate evidence.",
            paths=["$.header.order_number", "$.lines[*].custom_fields.order_number"],
            source_refs=refs,
            expected="one order number",
            actual=sorted(groups),
        )
    )


def _apply_region_context(
    record: DocumentRecord,
    mapping: HeaderFieldMapping,
    target: str,
    value: Any,
    cells: list[CellValue],
    applied_tables: _AppliedTables,
) -> None:
    if mapping.region_id is None:
        raise TabularSchemaSafetyError("region context has no region_id")
    lines = applied_tables.region_lines.get((mapping.sheet, mapping.region_id), [])
    if not lines:
        raise TabularSchemaSafetyError("region context has no applied records")
    key = _safe_custom_key(_semantic_field(target))
    for line_index, line in lines:
        path = f"$.lines[{line_index}].custom_fields.{key}"
        if _can_replace(record, path, line.custom_fields.get(key)):
            line.custom_fields[key] = value
            record.field_meta[path] = _metadata(cells)
    contexts = record.extraction.setdefault("tabular_region_contexts", [])
    if not isinstance(contexts, list):
        contexts = []
        record.extraction["tabular_region_contexts"] = contexts
    contexts.append(
        {
            "region_id": mapping.region_id,
            "target_path": target,
            "value": value,
            "line_ids": [line.line_id for _, line in lines],
            "source_refs": [
                _source_ref(cell).model_dump(mode="json") for cell in cells
            ],
        }
    )


def _refresh_order_groups(record: DocumentRecord) -> None:
    groups: dict[str, list[str]] = defaultdict(list)
    for line in record.lines:
        value = _text(line.custom_fields.get("order_number"))
        if value:
            groups[value].append(line.line_id)
    if not groups:
        return
    record.extraction["order_groups"] = [
        {"order_number": value, "line_ids": line_ids}
        for value, line_ids in sorted(groups.items())
    ]
    if len(groups) > 1 and not any(
        issue.code == "MULTI_ORDER_DOCUMENT" for issue in record.validation_issues
    ):
        record.validation_issues.append(
            ValidationIssue(
                code="MULTI_ORDER_DOCUMENT",
                severity="warning",
                message="Multiple coordinate-grounded order groups require review.",
                paths=[
                    "$.header.order_number",
                    "$.lines[*].custom_fields.order_number",
                ],
                actual=sorted(groups),
            )
        )


def _sum_line_values(values: list[Any]) -> int | Decimal | None:
    numbers: list[Decimal] = []
    for value in values:
        if value in (None, "") or isinstance(value, bool):
            continue
        try:
            numbers.append(Decimal(str(value)))
        except (InvalidOperation, ValueError):
            continue
    if not numbers:
        return None
    total = sum(numbers, Decimal("0"))
    return int(total) if total == total.to_integral_value() else total


_LINE_META_RE = re.compile(r"^\$\.lines\[(\d+)]\.(.+)$")


def _field_meta_value(record: DocumentRecord, path: str) -> tuple[bool, Any]:
    if path.startswith("$.header."):
        field_name = path.removeprefix("$.header.")
        return hasattr(record.header, field_name), getattr(
            record.header, field_name, None
        )
    if path.startswith("$.totals.source_declared."):
        key = path.removeprefix("$.totals.source_declared.")
        return True, record.totals.source_declared.get(key)
    if path.startswith("$.totals."):
        field_name = path.removeprefix("$.totals.")
        return hasattr(record.totals, field_name), getattr(
            record.totals, field_name, None
        )
    match = _LINE_META_RE.fullmatch(path)
    if match is None:
        return False, None
    index = int(match.group(1))
    if index >= len(record.lines):
        return True, None
    value: Any = record.lines[index]
    for part in match.group(2).split("."):
        if isinstance(value, dict):
            value = value.get(part)
        else:
            value = getattr(value, part, None)
    return True, value


def _prune_absent_field_meta(record: DocumentRecord) -> None:
    for path in list(record.field_meta):
        resolved, value = _field_meta_value(record, path)
        if resolved and value in (None, ""):
            record.field_meta.pop(path, None)


def _finalize(record: DocumentRecord) -> DocumentRecord:
    recovered_codes: set[str] = set()
    if record.lines:
        recovered_codes.update(_RECOVERED_LINE_ISSUES)
    if record.header.order_number or record.extraction.get("order_groups"):
        recovered_codes.add("ORDER_NUMBER_MISSING")
    record.validation_issues = [
        issue
        for issue in record.validation_issues
        if issue.code not in recovered_codes
        and issue.code != "TABULAR_SCHEMA_INTERPRETATION_REVIEW"
    ]
    calculated_quantity = _sum_line_values([line.quantity for line in record.lines])
    record.totals.calculated_quantity = calculated_quantity
    record.totals.system_calculated["quantity"] = calculated_quantity
    record.totals.system_calculated["row_count"] = len(record.lines)
    declared_quantity = record.totals.declared_quantity
    if declared_quantity is None or calculated_quantity is None:
        quantity_matches = None
    else:
        try:
            quantity_matches = Decimal(str(declared_quantity)) == Decimal(
                str(calculated_quantity)
            )
        except InvalidOperation:
            quantity_matches = None
    record.totals.quantity_matches = quantity_matches
    record.totals.matches["quantity"] = quantity_matches
    record.validation_issues.append(
        ValidationIssue(
            code="TABULAR_SCHEMA_INTERPRETATION_REVIEW",
            severity="warning",
            message=(
                "A model-assisted layout plan recovered tabular structure; all "
                "business values were read from source cells and require review."
            ),
            paths=["$.header", "$.lines", "$.field_meta"],
        )
    )
    payload = record.model_dump(mode="python")
    if record.document_type == "order":
        from .orders import revalidate_order_document

        payload = revalidate_order_document(payload)
    result = DocumentRecord.model_validate(payload)
    result.totals.system_calculated["row_count"] = len(result.lines)
    result = DocumentRecord.model_validate(result.model_dump(mode="python"))
    _prune_absent_field_meta(result)
    return result


def apply_plan(
    envelope: DocumentEnvelope,
    baseline: DocumentRecord,
    plan: TabularSchemaPlan,
    subtype_hint: str | None = None,
) -> DocumentRecord:
    """Apply a validated v1 plan using values read only from the envelope."""

    validated = validate_plan(envelope, plan)
    record = baseline.model_copy(deep=True)
    if subtype_hint:
        record.document_subtype = subtype_hint
    if not validated.header_fields and not validated.tables:
        return DocumentRecord.model_validate(record.model_dump(mode="python"))
    applied_tables = _apply_tables(envelope, record, validated)
    sheets = _sheets(envelope)
    for mapping in validated.header_fields:
        sheet = sheets[mapping.sheet]
        labels = [_real_cell(sheet, coordinate) for coordinate in mapping.label_cells]
        target = _header_target(mapping)
        if not _validate_field_labels(
            _semantic_field(target),
            labels,
            reject_known_mismatch=_target_is_canonical(target),
        ):
            record.validation_issues.append(
                ValidationIssue(
                    code="TABULAR_SCHEMA_LABEL_REVIEW",
                    severity="warning",
                    message=(
                        "A model mapped a previously unknown label to a canonical "
                        "field; the coordinate-bound value requires review."
                    ),
                    paths=[target],
                    source_refs=[_source_ref(cell) for cell in labels],
                )
            )
        if mapping.strategy in {"constant_column", "constant_row"}:
            cells = (
                _constant_column_cells(sheet, validated, mapping)
                if mapping.strategy == "constant_column"
                else _constant_row_cells(sheet, validated, mapping)
            )
            distinct = {_normalized(cell.value) for cell in cells}
            if len(distinct) == 1:
                if mapping.region_id:
                    _apply_region_context(
                        record,
                        mapping,
                        target,
                        cells[0].value,
                        cells,
                        applied_tables,
                    )
                else:
                    _set_document_target(record, target, cells[0].value, cells)
            elif _semantic_field(target) == "order_number":
                _apply_multi_order(record, mapping, cells, applied_tables)
            continue
        cells = [_real_cell(sheet, coordinate) for coordinate in mapping.value_cells]
        value = _inline_value(mapping, labels, cells[0])
        if mapping.region_id:
            _apply_region_context(record, mapping, target, value, cells, applied_tables)
        else:
            _set_document_target(record, target, value, cells)
    _refresh_order_groups(record)
    return _finalize(record)


__all__ = ["apply_plan"]
