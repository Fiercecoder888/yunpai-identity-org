"""Evidence-bound schema interpretation for tabular documents.

The language model may describe structure, but it is never an authority for
business values.  Every value applied here is read back from ``DocumentEnvelope``.
"""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from .envelope import CellValue, DocumentEnvelope, SheetEnvelope
from .models import (
    DocumentHeader,
    DocumentRecord,
    DocumentTotals,
    NameAttributes,
    OrderLine,
)
from .tabular_summary import (
    build_tabular_summary as build_tabular_summary,
    template_fingerprint as template_fingerprint,
)
from .tabular_schema_vocabulary import (
    _CRITICAL_LABEL_ALIASES,
    _DATE_TARGETS,
    _MUTUALLY_EXCLUSIVE_EVIDENCE,
    _NUMERIC_FIELDS,
    _PROTECTED_LINE_FIELDS,
    _RECOVERED_LINE_ISSUES,  # noqa: F401 -- compatibility export
    _SYSTEM_HEADER_FIELDS,
    _SYSTEM_TOTAL_FIELDS,
    _TABLE_BOUNDARY_RE,
)


DocumentShape = Literal["single_order", "multi_order", "ledger", "other", "unknown"]
# These aliases remain public for import compatibility. Runtime validation below
# derives canonical targets from DocumentRecord's current Pydantic schema instead
# of limiting the model to a hand-maintained enum.
HeaderField = str
ColumnField = str
HeaderStrategy = Literal[
    "inline",
    "horizontal",
    "vertical",
    "constant_column",
    "constant_row",
]
RecordOrientation = Literal["rows", "columns"]


class _StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class HeaderFieldMapping(_StrictModel):
    field: HeaderField = Field(min_length=1, max_length=160)
    target_path: str | None = Field(default=None, min_length=1, max_length=200)
    strategy: HeaderStrategy
    sheet: str
    region_id: str | None = Field(default=None, min_length=1, max_length=80)
    label_cells: list[str] = Field(default_factory=list)
    value_cells: list[str] = Field(default_factory=list)


class ColumnMapping(_StrictModel):
    column: int = Field(ge=1)
    field: ColumnField = Field(min_length=1, max_length=160)
    target_path: str | None = Field(default=None, min_length=1, max_length=200)
    label_cells: list[str] = Field(default_factory=list)


class RowMapping(_StrictModel):
    row: int = Field(ge=1)
    field: ColumnField = Field(min_length=1, max_length=160)
    target_path: str | None = Field(default=None, min_length=1, max_length=200)
    label_cells: list[str] = Field(default_factory=list)


class DataRange(_StrictModel):
    start: int = Field(ge=1)
    end: int = Field(ge=1)
    step: int = Field(default=1, ge=1, le=1_000)


class InspectionWindow(_StrictModel):
    sheet: str
    start_row: int = Field(ge=1)
    end_row: int = Field(ge=1)
    start_column: int = Field(default=1, ge=1)
    end_column: int | None = Field(default=None, ge=1)
    reason: str | None = Field(default=None, max_length=160)


class TableMapping(_StrictModel):
    sheet: str
    region_id: str | None = Field(default=None, min_length=1, max_length=80)
    orientation: RecordOrientation = "rows"
    header_rows: list[int] = Field(default_factory=list)
    header_columns: list[int] = Field(default_factory=list)
    data_start_row: int | None = Field(default=None, ge=1)
    data_end_row: int | None = Field(default=None, ge=1)
    data_rows: list[int] = Field(default_factory=list)
    data_start_column: int | None = Field(default=None, ge=1)
    data_end_column: int | None = Field(default=None, ge=1)
    data_columns: list[int] = Field(default_factory=list)
    data_ranges: list[DataRange] = Field(default_factory=list)
    columns: list[ColumnMapping] = Field(default_factory=list)
    row_fields: list[RowMapping] = Field(default_factory=list)


class TabularSchemaPlan(_StrictModel):
    schema_version: Literal["v1"] = "v1"
    document_shape: DocumentShape = "unknown"
    header_fields: list[HeaderFieldMapping] = Field(default_factory=list)
    tables: list[TableMapping] = Field(default_factory=list)
    inspection_windows: list[InspectionWindow] = Field(
        default_factory=list, max_length=4
    )


class TabularSchemaSafetyError(ValueError):
    """Raised when an interpretation plan is not fully grounded in the envelope."""


_CELL_RE = re.compile(r"^([A-Z]+)([1-9]\d*)$")
_MAX_INTERPRETED_TABLE_ROWS = 10_000
_SAFE_CUSTOM_KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,79}$")
_HEADER_MODEL_FIELDS = frozenset(DocumentHeader.model_fields)
_TOTAL_MODEL_FIELDS = frozenset(DocumentTotals.model_fields)
_LINE_MODEL_FIELDS = frozenset(OrderLine.model_fields)
_ATTRIBUTE_MODEL_FIELDS = frozenset(NameAttributes.model_fields)


def _safe_custom_key(value: str) -> str:
    key = _text(value)
    if not _SAFE_CUSTOM_KEY_RE.fullmatch(key) or key.startswith("__"):
        raise TabularSchemaSafetyError(f"invalid custom target key: {value!r}")
    return key


def _normalize_target_path(value: str) -> str:
    target = _text(value)
    if not target:
        raise TabularSchemaSafetyError("target path is empty")
    if target.startswith("$."):
        return target
    return "$." + target.lstrip(".")


def _header_target(mapping: HeaderFieldMapping) -> str:
    """Return a schema-derived document target for a header/value mapping."""

    explicit = mapping.target_path or mapping.field
    if mapping.target_path is None and not str(mapping.field).startswith(
        ("$.", "header.", "totals.", "extraction.")
    ):
        field_name = _text(mapping.field)
        if field_name == "order_date":
            return "$.header.date_raw"
        if field_name == "delivery_date":
            return "$.header.delivery_date_raw"
        if field_name in _HEADER_MODEL_FIELDS:
            if field_name in _SYSTEM_HEADER_FIELDS:
                raise TabularSchemaSafetyError(
                    f"header field is system-derived: {field_name}"
                )
            return f"$.header.{field_name}"
        if field_name in _TOTAL_MODEL_FIELDS:
            if field_name in _SYSTEM_TOTAL_FIELDS:
                raise TabularSchemaSafetyError(
                    f"totals field is system-derived: {field_name}"
                )
            return f"$.totals.{field_name}"
        return f"$.extraction.custom_fields.{_safe_custom_key(field_name)}"

    target = _normalize_target_path(explicit)
    parts = target[2:].split(".")
    if len(parts) == 2 and parts[0] == "header" and parts[1] in _HEADER_MODEL_FIELDS:
        if parts[1] == "candidate_numbers" or parts[1] in _SYSTEM_HEADER_FIELDS:
            raise TabularSchemaSafetyError(
                f"header field is not a source-writable scalar: {parts[1]}"
            )
        return target
    if len(parts) == 2 and parts[0] == "totals" and parts[1] in _TOTAL_MODEL_FIELDS:
        if parts[1] in _SYSTEM_TOTAL_FIELDS:
            raise TabularSchemaSafetyError(
                f"totals field is system-derived: {parts[1]}"
            )
        if parts[1] == "source_declared":
            raise TabularSchemaSafetyError(f"{target} requires a custom child key")
        return target
    if len(parts) == 3 and parts[:2] == ["totals", "source_declared"]:
        return f"$.totals.source_declared.{_safe_custom_key(parts[2])}"
    if len(parts) == 3 and parts[:2] == ["extraction", "custom_fields"]:
        return f"$.extraction.custom_fields.{_safe_custom_key(parts[2])}"
    raise TabularSchemaSafetyError(f"unsupported document target: {target}")


def _line_target(mapping: ColumnMapping | RowMapping) -> str:
    """Return a wildcard line target derived from OrderLine's current schema."""

    explicit = mapping.target_path or mapping.field
    if mapping.target_path is None and not str(mapping.field).startswith(
        ("$.", "lines")
    ):
        field_name = _text(mapping.field)
        if field_name in _PROTECTED_LINE_FIELDS:
            raise TabularSchemaSafetyError(
                f"line field is not source-writable: {field_name}"
            )
        if field_name in _LINE_MODEL_FIELDS:
            if field_name in {"custom_fields", "name_attributes"}:
                raise TabularSchemaSafetyError(f"{field_name} requires a child key")
            return f"$.lines[*].{field_name}"
        if field_name in {"order_number", "delivery_date"}:
            return f"$.lines[*].custom_fields.{field_name}"
        return f"$.lines[*].custom_fields.{_safe_custom_key(field_name)}"

    target = _normalize_target_path(explicit)
    match = re.fullmatch(r"\$\.lines(?:\[\*?\]|\.\*)(?:\.(.+))", target)
    if match is None:
        raise TabularSchemaSafetyError(f"unsupported line target: {target}")
    parts = match.group(1).split(".")
    if len(parts) == 1 and parts[0] in _LINE_MODEL_FIELDS - _PROTECTED_LINE_FIELDS:
        if parts[0] in {"custom_fields", "name_attributes"}:
            raise TabularSchemaSafetyError(f"{target} requires a child key")
        return f"$.lines[*].{parts[0]}"
    if len(parts) == 2 and parts[0] == "custom_fields":
        return f"$.lines[*].custom_fields.{_safe_custom_key(parts[1])}"
    if len(parts) == 2 and parts[0] == "name_attributes":
        if parts[1] not in _ATTRIBUTE_MODEL_FIELDS - {"custom"}:
            raise TabularSchemaSafetyError(f"unsupported name attribute: {parts[1]}")
        return f"$.lines[*].name_attributes.{parts[1]}"
    if len(parts) == 3 and parts[:2] == ["name_attributes", "custom"]:
        return f"$.lines[*].name_attributes.custom.{_safe_custom_key(parts[2])}"
    raise TabularSchemaSafetyError(f"unsupported line target: {target}")


def _semantic_field(target: str) -> str:
    leaf = target.rsplit(".", 1)[-1]
    return {
        "date_raw": "order_date",
        "date_standard": "order_date",
        "delivery_date_raw": "delivery_date",
        "delivery_date_standard": "delivery_date",
    }.get(leaf, leaf)


def _text(value: Any) -> str:
    if value is None:
        return ""
    return unicodedata.normalize("NFKC", str(value)).strip()


def _normalized(value: Any) -> str:
    return re.sub(r"\s+", " ", _text(value)).casefold()


def _nonempty(cell: CellValue | None) -> bool:
    return cell is not None and _text(cell.value) != ""


def _label_key(value: Any) -> str:
    text = re.split(r"[:\uff1a]", _text(value), maxsplit=1)[0]
    return re.sub(r"[\s\W_]+", "", text.casefold())


def _target_is_canonical(target: str) -> bool:
    if target.startswith("$.extraction.custom_fields."):
        return False
    if target.startswith("$.totals.source_declared."):
        return False
    if ".name_attributes.custom." in target:
        return False
    if ".custom_fields." in target:
        return _semantic_field(target) in {"order_number", "delivery_date"}
    return True


def _validate_field_labels(
    field: str,
    labels: list[CellValue],
    *,
    reject_known_mismatch: bool = True,
) -> bool:
    """Reject known contradictions while allowing genuinely novel vocabulary.

    The old implementation required a positive match in a fixed alias table. That
    made an otherwise correct model plan unusable for a customer-specific label.
    Aliases now act as hard negative evidence: a label known to mean a different,
    mutually exclusive field is rejected. Unknown labels pass with ``False`` and
    receive an explicit review issue when the plan is applied.
    """

    keys = [_label_key(cell.value) for cell in labels]
    keys.append(_label_key(" ".join(_text(cell.value) for cell in labels)))
    matches: set[str] = set()
    exact_matches: set[str] = set()
    for candidate, aliases in _CRITICAL_LABEL_ALIASES.items():
        normalized_aliases = [_label_key(alias) for alias in aliases]
        if any(alias and alias in key for key in keys for alias in normalized_aliases):
            matches.add(candidate)
        if any(alias and alias == key for key in keys for alias in normalized_aliases):
            exact_matches.add(candidate)
    if not matches:
        return False
    if field in matches:
        return True
    # Seller and supplier are two supported business roles for the same party-B
    # evidence in the current DocumentRecord contract.
    if field in {"seller", "supplier"} and matches <= {"seller", "supplier"}:
        return True
    # A loose substring may be a modifier in another legitimate label, such as
    # "customer product code". Only an exact known label is hard-negative
    # evidence for a different canonical target.
    if exact_matches and reject_known_mismatch:
        raise TabularSchemaSafetyError(
            f"label evidence means {sorted(exact_matches)}, not {field}"
        )
    return False


def _column_number(letters: str) -> int:
    result = 0
    for char in letters:
        result = result * 26 + ord(char) - 64
    return result


def _coordinate(value: str) -> tuple[int, int, str]:
    normalized = _text(value).upper()
    match = _CELL_RE.fullmatch(normalized)
    if match is None:
        raise TabularSchemaSafetyError(f"invalid cell coordinate: {value!r}")
    column = _column_number(match.group(1))
    row = int(match.group(2))
    return row, column, normalized


def _sheets(envelope: DocumentEnvelope) -> dict[str, SheetEnvelope]:
    return {sheet.name: sheet for sheet in envelope.sheets}


def _real_cell(sheet: SheetEnvelope, coordinate: str) -> CellValue:
    row, column, normalized = _coordinate(coordinate)
    cell = sheet.cell(row, column, inherit_merged=True)
    if not _nonempty(cell):
        raise TabularSchemaSafetyError(
            f"cell {sheet.name}!{normalized} does not exist or is empty"
        )
    return cell


def _table_region_id(table: TableMapping, index: int | None = None) -> str:
    if table.region_id:
        return table.region_id
    return "" if index is None else f"table-{index + 1}"


def _expand_data_ranges(ranges: list[DataRange], *, upper_bound: int) -> list[int]:
    values: list[int] = []
    for item in ranges:
        if item.end < item.start or item.end > upper_bound:
            raise TabularSchemaSafetyError("table data range is out of bounds")
        values.extend(range(item.start, item.end + 1, item.step))
        if len(values) > _MAX_INTERPRETED_TABLE_ROWS:
            raise TabularSchemaSafetyError("table data ranges exceed record limit")
    if len(values) != len(set(values)):
        raise TabularSchemaSafetyError("table data ranges overlap")
    return values


def _table_last_row(sheet: SheetEnvelope, table: TableMapping) -> int:
    if table.data_start_row is None:
        raise TabularSchemaSafetyError("row-oriented table has no data_start_row")
    mapped_columns = {item.column for item in table.columns}
    direct_rows: dict[int, list[CellValue]] = defaultdict(list)
    mapped_rows: set[int] = set()
    for cell in sheet.cells.values():
        if not _nonempty(cell):
            continue
        direct_rows[cell.row].append(cell)
        if cell.column in mapped_columns:
            mapped_rows.add(cell.row)
    for merged in sheet.merged_ranges:
        if not any(
            merged.min_col <= column <= merged.max_col for column in mapped_columns
        ):
            continue
        anchor = sheet.cells.get((merged.min_row, merged.min_col))
        if not _nonempty(anchor):
            continue
        if merged.max_row - merged.min_row + 1 > _MAX_INTERPRETED_TABLE_ROWS:
            raise TabularSchemaSafetyError("merged table region exceeds row limit")
        mapped_rows.update(range(merged.min_row, merged.max_row + 1))

    last_data_row = table.data_start_row - 1
    previous_mapped_row = table.data_start_row - 1
    boundary_rows = {
        row
        for row, cells in direct_rows.items()
        if cells
        and _TABLE_BOUNDARY_RE.match(
            _text(min(cells, key=lambda cell: cell.column).value)
        )
    }
    for row in sorted(mapped_rows | boundary_rows):
        if row < table.data_start_row:
            continue
        row_cells = sorted(direct_rows.get(row, []), key=lambda cell: cell.column)
        first_value = next(
            (_text(cell.value) for cell in row_cells if _nonempty(cell)),
            "",
        )
        if first_value and _TABLE_BOUNDARY_RE.match(first_value):
            break
        if row not in mapped_rows:
            continue
        if row - previous_mapped_row > 2:
            break
        previous_mapped_row = row
        last_data_row = row
        if last_data_row - table.data_start_row + 1 > _MAX_INTERPRETED_TABLE_ROWS:
            raise TabularSchemaSafetyError("table region exceeds row limit")
    return last_data_row


def _table_last_column(sheet: SheetEnvelope, table: TableMapping) -> int:
    if table.data_start_column is None:
        raise TabularSchemaSafetyError("column-oriented table has no data_start_column")
    mapped_rows = {item.row for item in table.row_fields}
    populated_columns = sorted(
        {
            cell.column
            for cell in sheet.cells.values()
            if cell.column >= table.data_start_column
            and cell.row in mapped_rows
            and _nonempty(cell)
        }
    )
    if not populated_columns:
        return table.data_start_column - 1
    last = table.data_start_column - 1
    previous = table.data_start_column - 1
    for column in populated_columns:
        if column - previous > 2:
            break
        previous = column
        last = column
        if last - table.data_start_column + 1 > _MAX_INTERPRETED_TABLE_ROWS:
            raise TabularSchemaSafetyError("table region exceeds record limit")
    return last


def _table_record_indices(sheet: SheetEnvelope, table: TableMapping) -> list[int]:
    upper_bound = sheet.max_row if table.orientation == "rows" else sheet.max_column
    explicit = table.data_rows if table.orientation == "rows" else table.data_columns
    values = list(explicit)
    values.extend(_expand_data_ranges(table.data_ranges, upper_bound=upper_bound))
    if values:
        if len(values) != len(set(values)):
            raise TabularSchemaSafetyError("duplicate explicit table record index")
        if any(value < 1 or value > upper_bound for value in values):
            raise TabularSchemaSafetyError("explicit table record is out of bounds")
        if len(values) > _MAX_INTERPRETED_TABLE_ROWS:
            raise TabularSchemaSafetyError("table record limit exceeded")
        return sorted(values)

    if table.orientation == "rows":
        start = table.data_start_row
        if start is None:
            raise TabularSchemaSafetyError("row-oriented table has no data axis")
        end = table.data_end_row
        if end is None:
            end = _table_last_row(sheet, table)
    else:
        start = table.data_start_column
        if start is None:
            raise TabularSchemaSafetyError("column-oriented table has no data axis")
        end = table.data_end_column
        if end is None:
            end = _table_last_column(sheet, table)
    if end < start or end > upper_bound:
        raise TabularSchemaSafetyError("table data axis is invalid")
    if end - start + 1 > _MAX_INTERPRETED_TABLE_ROWS:
        raise TabularSchemaSafetyError("table record limit exceeded")
    return list(range(start, end + 1))


def _mapping_labels(
    sheet: SheetEnvelope,
    table: TableMapping,
    mapping: ColumnMapping | RowMapping,
) -> list[CellValue]:
    coordinates = mapping.label_cells
    if coordinates:
        return [_real_cell(sheet, coordinate) for coordinate in coordinates]
    if isinstance(mapping, ColumnMapping):
        return [
            cell
            for row in table.header_rows
            if _nonempty(cell := sheet.cell(row, mapping.column, inherit_merged=True))
        ]
    return [
        cell
        for column in table.header_columns
        if _nonempty(cell := sheet.cell(mapping.row, column, inherit_merged=True))
    ]


def _table_cell(
    sheet: SheetEnvelope,
    table: TableMapping,
    mapping: ColumnMapping | RowMapping,
    record_index: int,
) -> CellValue | None:
    if table.orientation == "rows" and isinstance(mapping, ColumnMapping):
        return sheet.cell(record_index, mapping.column, inherit_merged=True)
    if table.orientation == "columns" and isinstance(mapping, RowMapping):
        return sheet.cell(mapping.row, record_index, inherit_merged=True)
    raise TabularSchemaSafetyError("table mapping does not match record orientation")


def _constant_column_cells(
    sheet: SheetEnvelope,
    plan: TabularSchemaPlan,
    mapping: HeaderFieldMapping,
) -> list[CellValue]:
    """Expand sampled constant-column evidence over the real table data region."""

    supplied = [_real_cell(sheet, coordinate) for coordinate in mapping.value_cells]
    columns = {cell.column for cell in supplied}
    if len(columns) != 1:
        raise TabularSchemaSafetyError("constant_column evidence spans columns")
    column = next(iter(columns))
    matching_tables = [
        table
        for table in plan.tables
        if table.sheet == mapping.sheet
        and table.orientation == "rows"
        and (mapping.region_id is None or table.region_id == mapping.region_id)
        and any(
            item.column == column
            and _semantic_field(_line_target(item))
            == _semantic_field(_header_target(mapping))
            for item in table.columns
        )
    ]
    if len(matching_tables) != 1:
        raise TabularSchemaSafetyError(
            "constant_column requires one matching table field mapping"
        )
    table = matching_tables[0]
    expanded_by_coordinate: dict[str, CellValue] = {}
    for row in _table_record_indices(sheet, table):
        cell = sheet.cell(row, column, inherit_merged=True)
        if _nonempty(cell):
            expanded_by_coordinate.setdefault(cell.coordinate, cell)
    expanded = list(expanded_by_coordinate.values())
    if not expanded:
        raise TabularSchemaSafetyError("constant_column has no grounded values")
    actual_coordinates = set(expanded_by_coordinate)
    supplied_coordinates = {cell.coordinate for cell in supplied}
    if not supplied_coordinates.issubset(actual_coordinates):
        raise TabularSchemaSafetyError(
            "constant_column sample evidence is outside the table data region"
        )
    return expanded


def _constant_row_cells(
    sheet: SheetEnvelope,
    plan: TabularSchemaPlan,
    mapping: HeaderFieldMapping,
) -> list[CellValue]:
    """Expand sampled constant-row evidence over a transposed table."""

    supplied = [_real_cell(sheet, coordinate) for coordinate in mapping.value_cells]
    rows = {cell.row for cell in supplied}
    if len(rows) != 1:
        raise TabularSchemaSafetyError("constant_row evidence spans rows")
    row = next(iter(rows))
    target = _semantic_field(_header_target(mapping))
    matching_tables = [
        table
        for table in plan.tables
        if table.sheet == mapping.sheet
        and table.orientation == "columns"
        and (mapping.region_id is None or table.region_id == mapping.region_id)
        and any(
            item.row == row and _semantic_field(_line_target(item)) == target
            for item in table.row_fields
        )
    ]
    if len(matching_tables) != 1:
        raise TabularSchemaSafetyError(
            "constant_row requires one matching transposed table field mapping"
        )
    table = matching_tables[0]
    expanded_by_coordinate: dict[str, CellValue] = {}
    for column in _table_record_indices(sheet, table):
        cell = sheet.cell(row, column, inherit_merged=True)
        if _nonempty(cell):
            expanded_by_coordinate.setdefault(cell.coordinate, cell)
    if not expanded_by_coordinate:
        raise TabularSchemaSafetyError("constant_row has no grounded values")
    supplied_coordinates = {cell.coordinate for cell in supplied}
    if not supplied_coordinates.issubset(expanded_by_coordinate):
        raise TabularSchemaSafetyError(
            "constant_row sample evidence is outside the table data region"
        )
    return list(expanded_by_coordinate.values())


def _target_requires_number(target: str) -> bool:
    leaf = target.rsplit(".", 1)[-1]
    return leaf in _NUMERIC_FIELDS or leaf in {
        "declared_quantity",
        "calculated_quantity",
        "declared_amount",
        "calculated_amount",
    }


def _validate_target_values(target: str, values: list[Any]) -> None:
    nonempty = [value for value in values if _text(value) != ""]
    if not nonempty:
        raise TabularSchemaSafetyError(f"{target} has no nonempty value evidence")
    if _target_requires_number(target) and any(
        _number(value) is None for value in nonempty
    ):
        raise TabularSchemaSafetyError(f"{target} has non-numeric value evidence")
    if target in _DATE_TARGETS and any(
        _parse_date(value) is None for value in nonempty
    ):
        raise TabularSchemaSafetyError(f"{target} has non-date value evidence")


def _add_semantic_evidence(
    semantic_evidence: dict[str, set[str]],
    target: str,
    sheet: str,
    cells: list[CellValue],
) -> None:
    semantic_evidence.setdefault(_semantic_field(target), set()).update(
        f"{sheet}!{cell.coordinate}" for cell in cells
    )


def validate_plan(
    envelope: DocumentEnvelope, plan: TabularSchemaPlan
) -> TabularSchemaPlan:
    """Validate every structural claim and evidence reference against the envelope."""

    try:
        payload = plan.model_dump() if isinstance(plan, BaseModel) else plan
        plan = TabularSchemaPlan.model_validate(payload)
    except Exception as exc:
        raise TabularSchemaSafetyError(f"invalid schema plan: {exc}") from exc

    sheets = _sheets(envelope)
    for window in plan.inspection_windows:
        sheet = sheets.get(window.sheet)
        if sheet is None:
            raise TabularSchemaSafetyError(
                f"unknown inspection sheet: {window.sheet!r}"
            )
        end_column = window.end_column or min(
            sheet.max_column, window.start_column + 79
        )
        if (
            window.end_row < window.start_row
            or window.end_row > sheet.max_row
            or end_column < window.start_column
            or end_column > sheet.max_column
            or window.end_row - window.start_row + 1 > 200
            or end_column - window.start_column + 1 > 80
        ):
            raise TabularSchemaSafetyError("inspection window is invalid or too large")

    explicit_regions = {
        (table.sheet, table.region_id)
        for table in plan.tables
        if table.region_id is not None
    }
    if len(explicit_regions) != sum(
        table.region_id is not None for table in plan.tables
    ):
        raise TabularSchemaSafetyError("duplicate table region_id")
    tables_per_sheet: dict[str, int] = defaultdict(int)
    for table in plan.tables:
        tables_per_sheet[table.sheet] += 1
    synthetic_regions = {
        (table.sheet, f"table-{index + 1}")
        for index, table in enumerate(plan.tables)
        if table.region_id is None and tables_per_sheet[table.sheet] > 1
    }
    if explicit_regions & synthetic_regions:
        raise TabularSchemaSafetyError(
            "explicit table region_id collides with an internal region id"
        )

    seen_header_targets: set[tuple[str, str, str]] = set()
    semantic_evidence: dict[str, set[str]] = {}
    for mapping in plan.header_fields:
        sheet = sheets.get(mapping.sheet)
        if sheet is None:
            raise TabularSchemaSafetyError(f"unknown sheet: {mapping.sheet!r}")
        if (
            mapping.region_id is not None
            and (
                mapping.sheet,
                mapping.region_id,
            )
            not in explicit_regions
        ):
            raise TabularSchemaSafetyError(
                f"header mapping references unknown region: {mapping.region_id}"
            )
        target = _header_target(mapping)
        identity = (mapping.sheet, mapping.region_id or "", target)
        if identity in seen_header_targets:
            raise TabularSchemaSafetyError(f"conflicting header target: {target}")
        seen_header_targets.add(identity)
        if not mapping.label_cells:
            raise TabularSchemaSafetyError(f"{target} has no label evidence")
        if not mapping.value_cells:
            raise TabularSchemaSafetyError(f"{target} has no value evidence")
        if len(set(mapping.label_cells)) != len(mapping.label_cells) or len(
            set(mapping.value_cells)
        ) != len(mapping.value_cells):
            raise TabularSchemaSafetyError(f"duplicate evidence for {target}")
        labels = [_real_cell(sheet, coordinate) for coordinate in mapping.label_cells]
        values = [_real_cell(sheet, coordinate) for coordinate in mapping.value_cells]
        _validate_field_labels(
            _semantic_field(target),
            labels,
            reject_known_mismatch=_target_is_canonical(target),
        )
        _add_semantic_evidence(
            semantic_evidence, target, mapping.sheet, labels + values
        )

        if mapping.strategy == "inline":
            if not (
                {cell.coordinate for cell in labels}
                & {cell.coordinate for cell in values}
            ):
                raise TabularSchemaSafetyError(
                    "inline label and value must share a cell"
                )
        elif mapping.strategy == "horizontal":
            if not any(
                label.row == value.row and 0 < value.column - label.column <= 12
                for label in labels
                for value in values
            ):
                raise TabularSchemaSafetyError(
                    "horizontal value is not right of its label"
                )
        elif mapping.strategy == "vertical":
            if not any(
                label.column == value.column and 0 < value.row - label.row <= 12
                for label in labels
                for value in values
            ):
                raise TabularSchemaSafetyError("vertical value is not below its label")
        elif mapping.strategy == "constant_column":
            expanded = _constant_column_cells(sheet, plan, mapping)
            column = expanded[0].column
            if not any(
                label.column == column and label.row < min(cell.row for cell in values)
                for label in labels
            ):
                raise TabularSchemaSafetyError(
                    "constant column label is not above its values"
                )
            values = expanded
        else:
            expanded = _constant_row_cells(sheet, plan, mapping)
            row = expanded[0].row
            if not any(
                label.row == row and label.column < min(cell.column for cell in values)
                for label in labels
            ):
                raise TabularSchemaSafetyError(
                    "constant row label is not left of its values"
                )
            values = expanded

        if mapping.strategy not in {"constant_column", "constant_row"}:
            resolved = [_inline_value(mapping, labels, cell) for cell in values]
            if len({_normalized(value) for value in resolved}) != 1:
                raise TabularSchemaSafetyError(f"conflicting values for {target}")
        else:
            resolved = [cell.value for cell in values]
            distinct = {_normalized(value) for value in resolved}
            if "" in distinct or (
                len(distinct) > 1 and _semantic_field(target) != "order_number"
            ):
                raise TabularSchemaSafetyError(
                    f"conflicting constant values for {target}"
                )
        _validate_target_values(target, resolved)

    seen_table_cells: set[tuple[str, int, int]] = set()
    for table_index, table in enumerate(plan.tables):
        sheet = sheets.get(table.sheet)
        if sheet is None:
            raise TabularSchemaSafetyError(f"unknown sheet: {table.sheet!r}")
        if table.orientation == "rows":
            if table.row_fields or not table.columns or not table.header_rows:
                raise TabularSchemaSafetyError(
                    "row-oriented table requires header_rows and columns"
                )
            if (
                table.header_columns
                or table.data_columns
                or table.data_start_column
                or table.data_end_column
            ):
                raise TabularSchemaSafetyError(
                    "row-oriented table contains column-axis controls"
                )
            if len(table.header_rows) != len(set(table.header_rows)) or any(
                row < 1 or row > sheet.max_row for row in table.header_rows
            ):
                raise TabularSchemaSafetyError("table header row is invalid")
            mappings: list[ColumnMapping | RowMapping] = list(table.columns)
            physical = [item.column for item in table.columns]
        else:
            if table.columns or not table.row_fields or not table.header_columns:
                raise TabularSchemaSafetyError(
                    "column-oriented table requires header_columns and row_fields"
                )
            if (
                table.header_rows
                or table.data_rows
                or table.data_start_row
                or table.data_end_row
            ):
                raise TabularSchemaSafetyError(
                    "column-oriented table contains row-axis controls"
                )
            if len(table.header_columns) != len(set(table.header_columns)) or any(
                column < 1 or column > sheet.max_column
                for column in table.header_columns
            ):
                raise TabularSchemaSafetyError("table header column is invalid")
            mappings = list(table.row_fields)
            physical = [item.row for item in table.row_fields]

        if len(physical) != len(set(physical)):
            raise TabularSchemaSafetyError("table physical mappings conflict")
        targets = [_line_target(item) for item in mappings]
        if len(targets) != len(set(targets)):
            raise TabularSchemaSafetyError("table target mappings conflict")
        record_indices = _table_record_indices(sheet, table)
        if table.orientation == "rows" and any(
            index in table.header_rows for index in record_indices
        ):
            raise TabularSchemaSafetyError("table data overlaps a header row")
        if table.orientation == "columns" and any(
            index in table.header_columns for index in record_indices
        ):
            raise TabularSchemaSafetyError("table data overlaps a header column")

        table_footprint: set[tuple[str, int, int]] = set()
        for mapping, target in zip(mappings, targets, strict=True):
            if isinstance(mapping, ColumnMapping) and mapping.column > sheet.max_column:
                raise TabularSchemaSafetyError(
                    f"column {mapping.column} is out of bounds"
                )
            if isinstance(mapping, RowMapping) and mapping.row > sheet.max_row:
                raise TabularSchemaSafetyError(f"row {mapping.row} is out of bounds")
            labels = _mapping_labels(sheet, table, mapping)
            if not labels:
                raise TabularSchemaSafetyError(f"{target} has no table label evidence")
            if len({cell.coordinate for cell in labels}) != len(labels):
                # Merged multi-row headers legitimately inherit one anchor into
                # several positions, so de-duplicate only for semantic evidence.
                labels = list({cell.coordinate: cell for cell in labels}.values())
            _validate_field_labels(
                _semantic_field(target),
                labels,
                reject_known_mismatch=_target_is_canonical(target),
            )
            value_cells = [
                cell
                for index in record_indices
                if _nonempty(cell := _table_cell(sheet, table, mapping, index))
            ]
            if not value_cells:
                raise TabularSchemaSafetyError(f"{target} has no table data")
            _validate_target_values(target, [cell.value for cell in value_cells])
            _add_semantic_evidence(
                semantic_evidence, target, table.sheet, labels + value_cells
            )
            for cell in value_cells:
                table_footprint.add((table.sheet, cell.row, cell.column))
        overlap = seen_table_cells & table_footprint
        if overlap:
            raise TabularSchemaSafetyError(
                f"table region {_table_region_id(table, table_index)} overlaps another region"
            )
        seen_table_cells.update(table_footprint)

    for left, right in _MUTUALLY_EXCLUSIVE_EVIDENCE:
        if semantic_evidence.get(left, set()) & semantic_evidence.get(right, set()):
            raise TabularSchemaSafetyError(
                f"mutually exclusive fields reuse evidence: {left}, {right}"
            )
    return plan


def _inline_value(
    mapping: HeaderFieldMapping, labels: list[CellValue], value_cell: CellValue
) -> Any:
    if mapping.strategy != "inline":
        return value_cell.value
    text = _text(value_cell.value)
    same_cell_labels = [
        label for label in labels if label.coordinate == value_cell.coordinate
    ]
    for label in same_cell_labels:
        label_text = _text(label.value)
        if label_text == text:
            match = re.search(r"[：:]\s*(.+)$", text)
            if match:
                return match.group(1).strip()
        elif text.startswith(label_text):
            return text[len(label_text) :].lstrip(" ：:").strip()
    match = re.search(r"[：:]\s*(.+)$", text)
    return match.group(1).strip() if match else ""


def _parse_date(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        try:
            serial = Decimal(str(value))
            if Decimal("1") <= serial <= Decimal("2958465"):
                return (datetime(1899, 12, 30) + timedelta(days=float(serial))).date()
        except (InvalidOperation, OverflowError, TypeError, ValueError):
            return None
    text = _text(value)
    if not text:
        return None
    normalized = unicodedata.normalize("NFKC", text)
    match = re.search(
        r"(?<!\d)(20\d{2}|19\d{2})[年./\-](\d{1,2})[月./\-](\d{1,2})日?", normalized
    )
    if match is None:
        match = re.fullmatch(r"(20\d{2}|19\d{2})(\d{2})(\d{2})", normalized)
    if match is None:
        return None
    try:
        return date(*(int(part) for part in match.groups()))
    except ValueError:
        return None


def _number(value: Any) -> int | Decimal | None:
    if value in (None, "") or isinstance(value, bool):
        return None
    try:
        number = Decimal(_text(value).replace(",", ""))
    except (InvalidOperation, ValueError):
        return None
    return int(number) if number == number.to_integral_value() else number


def apply_plan(
    envelope: DocumentEnvelope,
    baseline: DocumentRecord,
    plan: TabularSchemaPlan,
    subtype_hint: str | None = None,
) -> DocumentRecord:
    """Apply a validated plan using the v1 runtime compiler."""

    from .tabular_plan_runtime import apply_plan as compile_plan

    return compile_plan(
        envelope,
        baseline,
        plan,
        subtype_hint=subtype_hint,
    )
