"""Stable vocabulary shared by tabular schema validation and execution."""

from __future__ import annotations

import re


_NUMERIC_FIELDS = {
    "quantity",
    "unit_price_tax_included",
    "amount_tax_included",
    "unit_price_tax_excluded",
    "amount_tax_excluded",
    "package_quantity",
    "piece_count",
    "volume",
}
_TABLE_BOUNDARY_RE = re.compile(
    r"^(?:\u5408\u8ba1|\u603b\u8ba1|total|\u5907\u6ce8|\u7b7e\u5b57|"
    r"\u5ba1\u6838|\u6761\u6b3e)(?:$|[:\uff1a])",
    re.IGNORECASE,
)
_RECOVERED_LINE_ISSUES = {
    "ORDER_TABLE_NOT_FOUND",
    "ORDER_LINES_EMPTY",
    "TABLE_REGION_NOT_FOUND",
    "TABLE_ROWS_EMPTY",
}
_SYSTEM_HEADER_FIELDS = frozenset(
    {"date_standard", "date_inferred", "delivery_date_standard"}
)
_SYSTEM_TOTAL_FIELDS = frozenset(
    {
        "calculated_quantity",
        "quantity_matches",
        "calculated_amount",
        "amount_matches",
        "system_calculated",
        "matches",
    }
)
_PROTECTED_LINE_FIELDS = frozenset(
    {
        "line_id",
        "image_refs",
        "raw_columns",
        "name_normalized",
        "full_product_name",
        "product_category",
    }
)
_DATE_TARGETS = frozenset(
    {
        "$.header.date_raw",
        "$.header.date_standard",
        "$.header.delivery_date_raw",
        "$.header.delivery_date_standard",
    }
)
_CRITICAL_LABEL_ALIASES: dict[str, tuple[str, ...]] = {
    "order_number": (
        "\u8ba2\u5355\u53f7",
        "\u8ba2\u5355\u7f16\u53f7",
        "\u91c7\u8d2d\u5355\u53f7",
        "\u91c7\u8d2d\u8ba2\u5355\u53f7",
        "order number",
        "order no",
        "purchase order number",
        "po number",
        "po no",
    ),
    "delivery_date": (
        "\u4ea4\u8d27\u65e5\u671f",
        "\u4ea4\u8d27\u671f",
        "\u4ea4\u671f",
        "\u4ea4\u4ed8\u65e5\u671f",
        "\u8981\u6c42\u4ea4\u671f",
        "\u5230\u8d27\u65e5\u671f",
        "delivery date",
        "due date",
    ),
    "order_date": (
        "\u4e0b\u5355\u65e5\u671f",
        "\u8ba2\u5355\u65e5\u671f",
        "\u5236\u5355\u65e5\u671f",
        "\u7b7e\u8ba2\u65e5\u671f",
        "order date",
        "issue date",
    ),
    "contract_number": (
        "\u5408\u540c\u53f7",
        "\u5408\u540c\u7f16\u53f7",
        "\u5408\u7ea6\u7f16\u53f7",
        "contract number",
        "contract no",
    ),
    "buyer": (
        "\u7532\u65b9",
        "\u4e70\u65b9",
        "\u91c7\u8d2d\u65b9",
        "\u9700\u65b9",
        "\u5ba2\u6237",
        "\u8d2d\u8d27\u65b9",
        "buyer",
        "customer",
    ),
    "seller": (
        "\u4e59\u65b9",
        "\u5356\u65b9",
        "\u9500\u552e\u65b9",
        "\u4f9b\u65b9",
        "\u4f9b\u8d27\u65b9",
        "\u4f9b\u5e94\u5546",
        "seller",
        "supplier",
    ),
    "supplier": (
        "\u4e59\u65b9",
        "\u4f9b\u5e94\u5546",
        "\u4f9b\u65b9",
        "\u4f9b\u8d27\u65b9",
        "\u5382\u5546",
        "supplier",
        "vendor",
        "seller",
    ),
    "currency": (
        "\u5e01\u79cd",
        "\u8d27\u5e01",
        "\u7ed3\u7b97\u5e01\u79cd",
        "currency",
    ),
    "line_no": (
        "\u5e8f",
        "\u5e8f\u53f7",
        "\u884c\u53f7",
        "line number",
        "line no",
        "item no",
    ),
}
_MUTUALLY_EXCLUSIVE_EVIDENCE = (
    ("order_number", "contract_number"),
    ("order_date", "delivery_date"),
    ("buyer", "seller"),
    ("buyer", "supplier"),
)


__all__ = [
    "_CRITICAL_LABEL_ALIASES",
    "_DATE_TARGETS",
    "_MUTUALLY_EXCLUSIVE_EVIDENCE",
    "_NUMERIC_FIELDS",
    "_PROTECTED_LINE_FIELDS",
    "_RECOVERED_LINE_ISSUES",
    "_SYSTEM_HEADER_FIELDS",
    "_SYSTEM_TOTAL_FIELDS",
    "_TABLE_BOUNDARY_RE",
]
