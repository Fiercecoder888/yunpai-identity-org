"""Applicability policy for product semantics in generic tabular documents."""

from __future__ import annotations


_NON_PRODUCT_SUBTYPES = frozenset({"equipment_register", "mold_mapping"})


def supports_product_semantics(subtype: str) -> bool:
    """Return whether rows represent products rather than assets or molds."""

    return subtype not in _NON_PRODUCT_SUBTYPES


__all__ = ["supports_product_semantics"]
