"""Format-neutral evidence collection for deterministic technical documents.

The format adapters intentionally retain lossless native evidence.  This module
adds the business projection shared by DOCX and PDF: title-block identifiers,
product specifications, dimensions, process steps and tabular product/BOM rows.
Every projected value is either represented by ``field_meta`` or carries its
``source_refs`` alongside the value.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from m1.documents.models import SourceReference

_SPACE_RE = re.compile(r"[ \u3000]+")
_ALL_SPACE_RE = re.compile(r"\s+")
_PLACEHOLDERS = {"", "-", "--", "/", "n/a", "na", "none", "null"}
_COMPANY_RE = re.compile(
    r"([\u4e00-\u9fffA-Za-z0-9（）()·&\-]{2,}?(?:股份有限公司|有限责任公司|有限公司))"
)
_TECH_COMPANY_RE = re.compile(r"([\u4e00-\u9fff]{2,}?(?:电子科技|光电科技))")
_CHINESE_DATE_RE = re.compile(r"(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日")
_DATE_RE = re.compile(r"(?<!\d)(20\d{2})[./-](\d{1,2})[./-](\d{1,2})(?!\d)")
_NUMBERED_STEP_RE = re.compile(r"^\s*(\d+(?:\.\d+)*)[.、．]\s*(.+?)\s*$")
_SECTION_RE = re.compile(r"^\s*([一二三四五六七八九十]+)[、.．]\s*(.+?)\s*$")
_CODE_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:[A-Za-z0-9]+(?:[._/-][A-Za-z0-9]+)+|"
    r"(?=[A-Za-z0-9]{4,}(?![A-Za-z0-9]))(?=[A-Za-z0-9]*[A-Za-z])"
    r"(?=[A-Za-z0-9]*\d)[A-Za-z0-9]+)"
    r"(?![A-Za-z0-9])"
)

_LABELS: dict[str, tuple[str, ...]] = {
    "title": (
        "产品名称",
        "品名",
        "图名",
        "图纸名称",
        "drawing name",
        "product name",
        "part name",
        "name",
        "壳子镭雕",
    ),
    "drawing_number": (
        "图号",
        "文件编号",
        "drawing number",
        "drawing no",
        "dwg no",
        "document number",
    ),
    "product_numbers": (
        "产品编号",
        "产品料号",
        "product number",
        "product no",
    ),
    "material_number": (
        "物料编号",
        "物料编码",
        "料号",
        "零件号",
        "part number",
        "part no",
        "material number",
        "material no",
    ),
    "company": ("公司", "单位", "company", "manufacturer"),
    "unit": ("单位", "unit"),
    "scale": ("比例", "scale"),
    "version": ("版本", "版次", "revision", "version", "rev"),
    "drawn_by": ("拟制", "设计", "绘图", "drawn", "drawn by", "designed"),
    "checked_by": ("校对", "检查", "checked", "checked by"),
    "approved_by": ("审核", "批准", "approved", "approved by"),
    "color": ("颜色", "color"),
    "manufacture": ("制造", "表面处理", "manufacture"),
    "date": ("发布日期", "生效日期", "日期", "date"),
}

_SPEC_LABELS = {
    "产品编号",
    "产品名称",
    "产品描述",
    "外径尺寸",
    "内径尺寸",
    "下料尺寸",
    "结构尺寸",
    "完成外径",
    "长度",
    "宽度",
    "高度",
    "厚度",
    "公差",
    "接口类型",
    "支持协议",
    "带宽",
    "分辨率",
    "工作电压",
    "传输距离",
    "储存温度",
    "工作温度",
    "使用温度范围",
    "光缆规格",
    "芯线数",
    "导体",
    "构成",
    "材质",
    "绞向",
    "纹向",
    "erp料号",
    "地线",
    "屏蔽",
    "包带",
    "填充",
    "总屏蔽",
    "外被",
    "表面处理",
    "焊线规格",
    "版本",
    "拟制",
    "审核",
    "材料",
    "颜色",
    "制造",
    "环保测试",
    "电气特性",
    "机械特性",
    "技术要求",
    "备注",
    "interface type",
    "protocol",
    "bandwidth",
    "resolution",
    "voltage",
    "temperature",
    "material",
    "tolerance",
    "specification",
}
_DIMENSION_LABEL_TOKENS = (
    "尺寸",
    "长度",
    "宽度",
    "高度",
    "厚度",
    "外径",
    "内径",
    "孔径",
    "直径",
    "公差",
    "间距",
    "dimension",
    "length",
    "width",
    "height",
    "diameter",
    "tolerance",
)
_DIMENSION_PATTERNS = (
    re.compile(
        r"(?:[ΦφØ][ \t]*)?\d+(?:[.,]\d+)?"
        r"(?:[ \t]*(?:±|\+|-)[ \t]*\d+(?:[.,]\d+)?)?"
        r"[ \t]*(?:mm|cm|inch|in\b|m\b)",
        re.IGNORECASE,
    ),
    re.compile(
        r"\d+(?:[.,]\d+)?[ \t]*[×x*][ \t]*\d+(?:[.,]\d+)?"
        r"(?:[ \t]*(?:mm|cm|m\b))?",
        re.IGNORECASE,
    ),
    re.compile(r"[ΦφØ][ \t]*\d+(?:[.,]\d+)?", re.IGNORECASE),
    re.compile(
        r"\d+(?:[.,]\d+)?[ \t]*±[ \t]*\d+(?:[.,]\d+)?",
        re.IGNORECASE,
    ),
    re.compile(
        r"±[ \t]*\d+(?:[.,]\d+)?[ \t]*(?:mm|cm|m\b)?",
        re.IGNORECASE,
    ),
)


@dataclass(slots=True)
class _Evidence:
    text: str
    ref: SourceReference
    confidence: float
    kind: str
    order: int = 0


@dataclass(slots=True)
class _Cell:
    text: str
    ref: SourceReference
    confidence: float
    row: int
    column: int


@dataclass(slots=True)
class _Table:
    table_id: str
    rows: list[list[_Cell | None]]
    confidence: float


@dataclass(slots=True)
class _Candidate:
    value: str
    refs: list[SourceReference]
    confidence: float
    score: float


def _display(value: Any) -> str:
    lines = [
        _SPACE_RE.sub(" ", line).strip()
        for line in unicodedata.normalize("NFKC", str(value or "")).splitlines()
    ]
    return "\n".join(line for line in lines if line).strip()


def _source_display(value: Any) -> str:
    """Normalize Unicode while retaining tabs/repeated spaces as layout evidence."""

    lines = [
        line.strip("\r\n")
        for line in unicodedata.normalize("NFKC", str(value or "")).splitlines()
    ]
    return "\n".join(line for line in lines if line.strip()).strip()


def _text(value: Any) -> str:
    return _ALL_SPACE_RE.sub(" ", _display(value)).strip()


def _key(value: Any) -> str:
    return re.sub(r"[\s:：._/\\\-（）()]+", "", _text(value).casefold())


def _present(value: Any) -> bool:
    return _text(value).casefold() not in _PLACEHOLDERS


def _ref_key(ref: SourceReference) -> tuple[Any, ...]:
    extra = ref.model_extra or {}
    bbox = extra.get("bbox")
    return (
        ref.page,
        ref.part,
        ref.cell,
        ref.range,
        tuple(bbox) if isinstance(bbox, list) else None,
        extra.get("coordinate_space"),
    )


def _unique_refs(refs: Iterable[SourceReference | None]) -> list[SourceReference]:
    result: list[SourceReference] = []
    seen: set[tuple[Any, ...]] = set()
    for ref in refs:
        if ref is None:
            continue
        key = _ref_key(ref)
        if key in seen:
            continue
        seen.add(key)
        result.append(ref)
    return result


def _ref_payload(ref: SourceReference) -> dict[str, Any]:
    return ref.model_dump(mode="json", exclude_none=True)


def _source_ref(**payload: Any) -> SourceReference:
    return SourceReference.model_validate(
        {key: value for key, value in payload.items() if value is not None}
    )


def _bbox_ref(
    *,
    page: int,
    part: str,
    bbox: Any,
    coordinate_space: str,
    evidence_quote: str | None = None,
    **extra: Any,
) -> SourceReference:
    payload: dict[str, Any] = {"page": page, "part": part, **extra}
    if evidence_quote:
        payload["evidence_quote"] = evidence_quote
    if isinstance(bbox, Mapping):
        values = [bbox.get(name) for name in ("x0", "y0", "x1", "y1")]
        if all(value is not None for value in values):
            payload["bbox"] = [round(float(value), 4) for value in values]
            payload["coordinate_space"] = str(
                bbox.get("coordinate_space") or coordinate_space
            )
    elif (
        isinstance(bbox, Sequence)
        and not isinstance(bbox, (str, bytes))
        and len(bbox) >= 4
    ):
        payload["bbox"] = [round(float(value), 4) for value in bbox[:4]]
        payload["coordinate_space"] = coordinate_space
    return _source_ref(**payload)


def _bbox(ref: SourceReference) -> list[float] | None:
    value = (ref.model_extra or {}).get("bbox")
    if isinstance(value, list) and len(value) >= 4:
        return [float(item) for item in value[:4]]
    return None


def _canonical_label(value: Any) -> str | None:
    value_key = _key(value)
    for field, labels in _LABELS.items():
        if any(value_key == _key(label) for label in labels):
            return field
    return None


def _is_spec_label(value: Any) -> bool:
    value_key = _key(value)
    if not value_key or len(_text(value)) > 32:
        return False
    return (
        any(value_key == _key(label) for label in _SPEC_LABELS)
        or _canonical_label(value) is not None
    )


def _is_revision_history_table(table: _Table) -> bool:
    revision_tokens = {
        "no",
        "date",
        "revision",
        "reviser",
        "version",
        "rev",
        "change",
        "checker",
        "序号",
        "日期",
        "版本",
        "版次",
        "变更",
        "修改人",
    }
    return any(
        len({_key(cell.text) for cell in row if cell is not None} & revision_tokens)
        >= 3
        for row in table.rows[:3]
    )


def _docx_evidence(raw: Mapping[str, Any]) -> tuple[list[_Evidence], list[_Table]]:
    entries: list[_Evidence] = []
    for paragraph in raw.get("paragraphs") or []:
        text = _source_display(
            paragraph.get("text_original") or paragraph.get("text_normalized")
        )
        if not text:
            continue
        index = int(paragraph.get("paragraph_index") or 0)
        entries.append(
            _Evidence(
                text=text,
                ref=_source_ref(
                    part=f"word/document.xml#paragraph:{index}",
                    evidence_quote=text,
                ),
                confidence=0.99,
                kind="paragraph",
                order=index,
            )
        )

    # Native DOCX normalization exposes a virtual page so downstream components
    # can consume one format-neutral envelope.  Keep its OOXML source identities
    # instead of treating those blocks as PDF evidence merely because ``pages``
    # is present.
    native_pages = [
        page for page in raw.get("pages") or [] if isinstance(page, Mapping)
    ]
    if native_pages and not entries:
        for page_position, page in enumerate(native_pages):
            page_number = int(page.get("page_number") or page_position + 1)
            for block_position, block in enumerate(page.get("blocks") or []):
                if not isinstance(block, Mapping):
                    continue
                text = _source_display(
                    block.get("text_original")
                    or block.get("text_normalized")
                    or block.get("text")
                )
                if not text:
                    continue
                block_id = str(block.get("block_id") or "").strip()
                source_id = str(block.get("source_id") or "").strip()
                part = (
                    f"mineru/{block_id}"
                    if block_id
                    else source_id or f"word/document.xml#block:{block_position}"
                )
                entries.append(
                    _Evidence(
                        text=text,
                        ref=_bbox_ref(
                            page=page_number,
                            part=part,
                            bbox=block.get("bbox"),
                            coordinate_space=str(
                                block.get("coordinate_space")
                                or page.get("coordinate_space")
                                or "normalized"
                            ),
                            evidence_id=block_id or None,
                            evidence_quote=text,
                            native_part=source_id or None,
                        ),
                        confidence=max(
                            0.0,
                            min(float(block.get("confidence") or 0.99), 1.0),
                        ),
                        kind=str(block.get("kind") or "paragraph"),
                        order=int(block.get("order") or block_position),
                    )
                )
    paragraph_offset = len(entries) + 10_000
    for textbox in raw.get("textboxes") or []:
        text = _display(textbox.get("text_original") or textbox.get("text_normalized"))
        if not text:
            continue
        index = int(textbox.get("textbox_index") or 0)
        entries.append(
            _Evidence(
                text=text,
                ref=_source_ref(
                    part=f"word/document.xml#textbox:{index}",
                    evidence_quote=text,
                ),
                confidence=0.95,
                kind="textbox",
                order=paragraph_offset + index,
            )
        )

    tables: list[_Table] = []
    for table_position, table in enumerate(raw.get("tables") or []):
        table_index = int(table.get("table_index") or table_position)
        rows: list[list[_Cell | None]] = []
        for row_index, row in enumerate(table.get("rows") or []):
            cells: list[_Cell | None] = []
            for column_position, cell in enumerate(row or []):
                if not isinstance(cell, Mapping):
                    cells.append(None)
                    continue
                column = int(cell.get("column_index") or column_position)
                text = _display(
                    cell.get("text_original") or cell.get("text_normalized")
                )
                ref = _source_ref(
                    part="word/document.xml",
                    cell=f"table:{table_index}/R{row_index + 1}C{column + 1}",
                    evidence_quote=text or None,
                )
                cells.append(
                    _Cell(
                        text=text,
                        ref=ref,
                        confidence=0.99,
                        row=row_index,
                        column=column,
                    )
                )
                if text:
                    entries.append(
                        _Evidence(
                            text=text,
                            ref=ref,
                            confidence=0.99,
                            kind="table_cell",
                            order=20_000
                            + table_index * 1_000
                            + row_index * 100
                            + column,
                        )
                    )
            rows.append(cells)
        tables.append(
            _Table(table_id=f"docx:{table_index}", rows=rows, confidence=0.99)
        )

    if native_pages and not tables:
        for page_position, page in enumerate(native_pages):
            page_number = int(page.get("page_number") or page_position + 1)
            for table_position, table in enumerate(page.get("tables") or []):
                if not isinstance(table, Mapping):
                    continue
                table_id = str(table.get("table_id") or f"docx:t:{table_position}")
                confidence = max(
                    0.0,
                    min(float(table.get("confidence") or 0.99), 1.0),
                )
                evidence_cells = {
                    (int(cell.get("row")), int(cell.get("column"))): cell
                    for cell in table.get("cells") or []
                    if isinstance(cell, Mapping)
                    and cell.get("row") is not None
                    and cell.get("column") is not None
                }
                rows: list[list[_Cell | None]] = []
                for row_index, row in enumerate(table.get("rows") or []):
                    if not isinstance(row, Sequence) or isinstance(row, (str, bytes)):
                        continue
                    cells: list[_Cell | None] = []
                    for column, value in enumerate(row):
                        evidence_cell = evidence_cells.get((row_index, column), {})
                        text = _display(
                            evidence_cell.get("text")
                            if isinstance(evidence_cell, Mapping)
                            else value
                        )
                        if not text:
                            text = _display(value)
                        source_id = (
                            str(evidence_cell.get("source_id") or "").strip()
                            if isinstance(evidence_cell, Mapping)
                            else ""
                        )
                        cell_confidence = (
                            float(evidence_cell.get("confidence") or confidence)
                            if isinstance(evidence_cell, Mapping)
                            else confidence
                        )
                        evidence_id = f"{table_id}:r{row_index}:c{column}"
                        ref = _source_ref(
                            page=page_number,
                            part=f"mineru/{evidence_id}",
                            evidence_id=evidence_id,
                            evidence_quote=text or None,
                            native_part=(
                                source_id
                                or (
                                    "word/document.xml#"
                                    f"table:{table_position}/row:{row_index}/cell:{column}"
                                )
                            ),
                        )
                        cells.append(
                            _Cell(
                                text=text,
                                ref=ref,
                                confidence=max(0.0, min(cell_confidence, 1.0)),
                                row=row_index,
                                column=column,
                            )
                        )
                        if text:
                            entries.append(
                                _Evidence(
                                    text=text,
                                    ref=ref,
                                    confidence=max(
                                        0.0,
                                        min(cell_confidence, 1.0),
                                    ),
                                    kind="table_cell",
                                    order=(
                                        20_000
                                        + table_position * 1_000
                                        + row_index * 100
                                        + column
                                    ),
                                )
                            )
                    rows.append(cells)
                tables.append(
                    _Table(
                        table_id=table_id,
                        rows=rows,
                        confidence=confidence,
                    )
                )
    return entries, tables


def _localized_pdf_bbox(
    value: str, entries: list[_Evidence], *, page: int
) -> tuple[list[float] | None, str | None]:
    target = _text(value)
    candidates = [
        entry
        for entry in entries
        if entry.kind in {"native_block", "ocr_line"}
        and entry.ref.page == page
        and target
        and target in _text(entry.text)
        and _bbox(entry.ref) is not None
    ]
    if not candidates:
        return None, None
    selected = min(candidates, key=lambda entry: len(_text(entry.text)))
    return _bbox(selected.ref), str(
        (selected.ref.model_extra or {}).get("coordinate_space") or "pdf_points"
    )


def _structured_ocr_tokens(metadata: Mapping[str, Any]) -> list[_Evidence]:
    result: list[_Evidence] = []
    structured = metadata.get("structured_evidence")
    if not isinstance(structured, Mapping):
        return result
    for page_position, page in enumerate(structured.get("pages") or []):
        if not isinstance(page, Mapping):
            continue
        page_number = int(page.get("page_number") or page_position + 1)
        raw = page.get("raw") if isinstance(page.get("raw"), Mapping) else {}
        overall = raw.get("overall_ocr_res") if isinstance(raw, Mapping) else {}
        if not isinstance(overall, Mapping):
            continue
        texts = list(overall.get("rec_texts") or [])
        scores = list(overall.get("rec_scores") or [])
        polygons = list(overall.get("rec_polys") or overall.get("dt_polys") or [])
        for index, value in enumerate(texts):
            text = _display(value)
            if not text:
                continue
            polygon = polygons[index] if index < len(polygons) else None
            bbox: list[float] | None = None
            if isinstance(polygon, Sequence) and polygon:
                points = [
                    point
                    for point in polygon
                    if isinstance(point, Sequence) and len(point) >= 2
                ]
                if points:
                    xs = [float(point[0]) for point in points]
                    ys = [float(point[1]) for point in points]
                    bbox = [min(xs), min(ys), max(xs), max(ys)]
            confidence = float(scores[index]) if index < len(scores) else 0.65
            result.append(
                _Evidence(
                    text=text,
                    ref=_bbox_ref(
                        page=page_number,
                        part=f"ocr/token:{index}",
                        bbox=bbox,
                        coordinate_space=str(page.get("coordinate_space") or "pixels"),
                        evidence_quote=text,
                    ),
                    confidence=max(0.0, min(confidence, 1.0)),
                    kind="ocr_token",
                    order=100_000 + page_number * 10_000 + index,
                )
            )
    return result


def _pdf_evidence(
    raw: Mapping[str, Any], metadata: Mapping[str, Any]
) -> tuple[list[_Evidence], list[_Table]]:
    entries: list[_Evidence] = []
    pages = list(raw.get("pages") or [])
    for page_position, page in enumerate(pages):
        if not isinstance(page, Mapping):
            continue
        page_number = int(page.get("page_number") or page_position + 1)
        coordinate_space = str(page.get("coordinate_space") or "pdf_points")
        for key, kind, prefix, confidence in (
            ("text_blocks", "native_block", "native/text-block", 0.99),
            ("ocr_lines", "ocr_line", "ocr/line", 0.65),
            ("blocks", "structured_block", "evidence/block", 0.85),
        ):
            for index, block in enumerate(page.get(key) or []):
                if not isinstance(block, Mapping):
                    continue
                text = _display(
                    block.get("text_normalized")
                    or block.get("text_original")
                    or block.get("text")
                )
                if not text:
                    continue
                block_id = str(block.get("block_id") or "").strip()
                entries.append(
                    _Evidence(
                        text=text,
                        ref=_bbox_ref(
                            page=page_number,
                            part=(
                                f"mineru/{block_id}"
                                if block_id
                                else f"{prefix}:{index}"
                            ),
                            bbox=block.get("bbox"),
                            coordinate_space=str(
                                block.get("coordinate_space") or coordinate_space
                            ),
                            evidence_quote=text,
                        ),
                        confidence=float(block.get("confidence") or confidence),
                        kind=(
                            str(block.get("kind") or kind) if key == "blocks" else kind
                        ),
                        order=page_number * 10_000 + index,
                    )
                )

    base_entries = list(entries)
    tables: list[_Table] = []
    for page_position, page in enumerate(pages):
        if not isinstance(page, Mapping):
            continue
        page_number = int(page.get("page_number") or page_position + 1)
        coordinate_space = str(page.get("coordinate_space") or "pdf_points")
        for table_position, table in enumerate(page.get("tables") or []):
            if not isinstance(table, Mapping):
                continue
            table_index = int(table.get("table_index") or table_position)
            table_id = str(table.get("table_id") or f"pdf:{page_number}:{table_index}")
            rows_values = list(
                table.get("rows_normalized")
                or table.get("rows_original")
                or table.get("rows")
                or []
            )
            boxes = list(table.get("cell_bbox_matrix") or [])
            confidences = list(table.get("cell_confidences") or [])
            default_confidence = 0.75 if table.get("ocr_derived") else 0.99
            evidence_cells = {
                (int(cell.get("row")), int(cell.get("column"))): cell
                for cell in table.get("cells") or []
                if isinstance(cell, Mapping)
                and cell.get("row") is not None
                and cell.get("column") is not None
            }
            rows: list[list[_Cell | None]] = []
            for row_index, row in enumerate(rows_values):
                if not isinstance(row, list):
                    continue
                cells: list[_Cell | None] = []
                for column, value in enumerate(row):
                    text = _display(value)
                    evidence_cell = evidence_cells.get((row_index, column), {})
                    bbox = (
                        boxes[row_index][column]
                        if row_index < len(boxes)
                        and isinstance(boxes[row_index], list)
                        and column < len(boxes[row_index])
                        else None
                    )
                    if bbox is None and isinstance(evidence_cell, Mapping):
                        bbox = evidence_cell.get("bbox")
                    cell_space = coordinate_space
                    if bbox is None and text:
                        bbox, localized_space = _localized_pdf_bbox(
                            text, base_entries, page=page_number
                        )
                        cell_space = localized_space or coordinate_space
                    confidence = (
                        float(confidences[row_index][column])
                        if row_index < len(confidences)
                        and isinstance(confidences[row_index], list)
                        and column < len(confidences[row_index])
                        and confidences[row_index][column] is not None
                        else default_confidence
                    )
                    if (
                        isinstance(evidence_cell, Mapping)
                        and evidence_cell.get("confidence") is not None
                    ):
                        confidence = float(evidence_cell["confidence"])
                    ref = _bbox_ref(
                        page=page_number,
                        part=f"mineru/{table_id}:r{row_index}:c{column}",
                        bbox=bbox,
                        coordinate_space=cell_space,
                        evidence_quote=text or None,
                    )
                    cells.append(
                        _Cell(
                            text=text,
                            ref=ref,
                            confidence=confidence,
                            row=row_index,
                            column=column,
                        )
                    )
                    if text:
                        entries.append(
                            _Evidence(
                                text=text,
                                ref=ref,
                                confidence=confidence,
                                kind="table_cell",
                                order=50_000
                                + page_number * 10_000
                                + row_index * 100
                                + column,
                            )
                        )
                rows.append(cells)
            tables.append(
                _Table(
                    table_id=table_id,
                    rows=rows,
                    confidence=default_confidence,
                )
            )
    entries.extend(_structured_ocr_tokens(metadata))
    return entries, tables


def _table_label_candidates(tables: list[_Table]) -> dict[str, list[_Candidate]]:
    result: dict[str, list[_Candidate]] = {}
    for table in tables:
        if _is_revision_history_table(table):
            continue
        for row_index, row in enumerate(table.rows):
            canonical_label_count = sum(
                cell is not None
                and bool(cell.text)
                and _canonical_label(cell.text) is not None
                for cell in row
            )
            for column, cell in enumerate(row):
                if cell is None or not cell.text:
                    continue
                field = _canonical_label(cell.text)
                if field is None:
                    continue
                if row_index > 0 and canonical_label_count >= 2:
                    previous_row = table.rows[row_index - 1]
                    previous_cell = (
                        previous_row[column] if column < len(previous_row) else None
                    )
                    if previous_cell is not None and _valid_scalar(
                        field, previous_cell.text
                    ):
                        result.setdefault(field, []).append(
                            _Candidate(
                                value=previous_cell.text,
                                refs=[previous_cell.ref],
                                confidence=min(
                                    previous_cell.confidence,
                                    table.confidence,
                                ),
                                score=(
                                    140.0
                                    + min(previous_cell.confidence, table.confidence)
                                ),
                            )
                        )
                value_cell: _Cell | None = None
                right_peers = (
                    row[column + 1 : column + 2]
                    if field in {"drawn_by", "checked_by", "approved_by"}
                    else row[column + 1 :]
                )
                for peer in right_peers:
                    if peer is None or not peer.text:
                        continue
                    if _canonical_label(peer.text) is not None or _is_spec_label(
                        peer.text
                    ):
                        break
                    value_cell = peer
                    break
                if value_cell is None:
                    for next_row in table.rows[row_index + 1 : row_index + 4]:
                        if column >= len(next_row):
                            continue
                        peer = next_row[column]
                        if peer is None or not peer.text:
                            continue
                        if _canonical_label(peer.text) is not None:
                            break
                        value_cell = peer
                        break
                if value_cell is None or not _valid_scalar(field, value_cell.text):
                    continue
                result.setdefault(field, []).append(
                    _Candidate(
                        value=value_cell.text,
                        refs=[value_cell.ref],
                        confidence=min(value_cell.confidence, table.confidence),
                        score=105.0 + min(value_cell.confidence, table.confidence),
                    )
                )
    return result


def _valid_scalar(field: str, value: Any) -> bool:
    text = _text(value)
    if not _present(text) or _canonical_label(text) is not None:
        return False
    if field == "title":
        return 2 <= len(text) <= 180
    if field in {"drawing_number", "material_number", "product_numbers"}:
        compact = re.sub(r"\s+", "", text)
        return (
            3 <= len(compact) <= 96
            and bool(re.search(r"[A-Za-z0-9]", compact))
            and bool(re.search(r"\d|[._/-]", compact))
        )
    if field == "unit":
        return len(text) <= 16
    if field == "scale":
        return bool(re.fullmatch(r"(?:free|n/?a|\d+\s*:\s*\d+)", text, re.IGNORECASE))
    if field == "version":
        return len(text) <= 24 and bool(
            re.fullmatch(
                r"(?:[A-Za-z](?:[./-]\d+)?|(?:rev(?:ision)?\s*)?[A-Za-z]?\d+"
                r"(?:[./-][A-Za-z0-9]+)*)",
                text,
                re.IGNORECASE,
            )
            or ("版" in text and len(text) <= 12)
        )
    if field == "date":
        return bool(_DATE_RE.search(text) or _CHINESE_DATE_RE.search(text))
    if field in {"drawn_by", "checked_by", "approved_by"}:
        return (
            len(text) <= 64
            and not re.search(r"\d", text)
            and not any(separator in text for separator in ("|", "=", "：", ":"))
            and not re.fullmatch(r"[A-Z]{2,8}", text)
        )
    if field == "company":
        return len(text) <= 160
    return len(text) <= 240


def _inline_label_candidates(entries: list[_Evidence]) -> dict[str, list[_Candidate]]:
    result: dict[str, list[_Candidate]] = {}
    for entry in entries:
        if entry.kind in {"ocr_token", "filename"}:
            continue
        lines = [line for line in _display(entry.text).splitlines() if line]
        for field, labels in _LABELS.items():
            for label in sorted(labels, key=len, reverse=True):
                pattern = re.compile(
                    rf"(?:^|\n)\s*{re.escape(label)}\s*[:：]?\s*(.+?)(?=\n|$)",
                    re.IGNORECASE,
                )
                match = pattern.search(_display(entry.text))
                if match:
                    value = _display(match.group(1))
                    if _valid_scalar(field, value):
                        result.setdefault(field, []).append(
                            _Candidate(
                                value=value,
                                refs=[entry.ref],
                                confidence=entry.confidence,
                                score=92.0 + entry.confidence,
                            )
                        )
                    break
                for line_index, line in enumerate(lines[:-1]):
                    if _key(line) != _key(label):
                        continue
                    value = lines[line_index + 1]
                    if _valid_scalar(field, value):
                        result.setdefault(field, []).append(
                            _Candidate(
                                value=value,
                                refs=[entry.ref],
                                confidence=entry.confidence,
                                score=90.0 + entry.confidence,
                            )
                        )
                    break
    return result


def _spatial_label_candidates(entries: list[_Evidence]) -> dict[str, list[_Candidate]]:
    tokens = [
        entry for entry in entries if entry.kind == "ocr_token" and _bbox(entry.ref)
    ]
    result: dict[str, list[_Candidate]] = {}
    for label_entry in tokens:
        field = _canonical_label(label_entry.text)
        if field is None:
            continue
        label_box = _bbox(label_entry.ref)
        if label_box is None:
            continue
        lx0, ly0, lx1, ly1 = label_box
        lw = max(1.0, lx1 - lx0)
        lh = max(1.0, ly1 - ly0)
        lcx = (lx0 + lx1) / 2
        lcy = (ly0 + ly1) / 2
        ranked: list[tuple[float, _Evidence]] = []
        for candidate in tokens:
            if (
                candidate is label_entry
                or candidate.ref.page != label_entry.ref.page
                or not _valid_scalar(field, candidate.text)
            ):
                continue
            candidate_box = _bbox(candidate.ref)
            if candidate_box is None:
                continue
            x0, y0, x1, y1 = candidate_box
            cw = max(1.0, x1 - x0)
            ch = max(1.0, y1 - y0)
            cx = (x0 + x1) / 2
            cy = (y0 + y1) / 2
            y_overlap = max(0.0, min(ly1, y1) - max(ly0, y0))
            vertical_alignment = abs(cx - lcx) <= max(lw, cw) * 0.65
            horizontal_alignment = y_overlap / min(lh, ch) >= 0.35
            vertical_gap = min(abs(ly0 - y1), abs(y0 - ly1))
            horizontal_gap = min(abs(lx0 - x1), abs(x0 - lx1))
            score = -1.0
            if vertical_alignment and vertical_gap <= max(120.0, lh * 5.0):
                score = 30.0 - vertical_gap / max(lh, 1.0) - abs(cx - lcx) / max(lw, cw)
                if y1 <= ly0:
                    score += 4.0
            if (
                horizontal_alignment
                and x0 >= lx0
                and horizontal_gap <= max(320.0, lw * 5.0)
            ):
                horizontal_score = (
                    25.0 - horizontal_gap / max(lw, 1.0) - abs(cy - lcy) / max(lh, ch)
                )
                score = max(score, horizontal_score)
            if score >= 0:
                ranked.append((score + candidate.confidence, candidate))
        if not ranked:
            continue
        _, selected = max(ranked, key=lambda item: item[0])
        selected_box = _bbox(selected.ref)
        value_is_above_label = bool(selected_box is not None and selected_box[3] <= ly0)
        engineering_label = bool(
            re.fullmatch(r"[A-Za-z0-9 ._/-]+", _text(label_entry.text))
        )
        value_quality = (
            2.0
            if field == "version" and re.search(r"[A-Za-z/]", selected.text)
            else 0.0
        )
        result.setdefault(field, []).append(
            _Candidate(
                value=selected.text,
                refs=[selected.ref],
                confidence=selected.confidence,
                score=(115.0 if value_is_above_label and engineering_label else 100.0)
                + selected.confidence
                + value_quality,
            )
        )
    return result


def _merge_candidates(
    *groups: Mapping[str, list[_Candidate]],
) -> dict[str, list[_Candidate]]:
    result: dict[str, list[_Candidate]] = {}
    for group in groups:
        for field, values in group.items():
            result.setdefault(field, []).extend(values)
    return result


def _heading_candidates(entries: list[_Evidence]) -> list[_Candidate]:
    result: list[_Candidate] = []
    for entry in entries:
        if entry.kind not in {"paragraph", "textbox", "native_block", "ocr_line"}:
            continue
        for line in _display(entry.text).splitlines():
            text = _text(line)
            if not (2 <= len(text) <= 180):
                continue
            folded = text.casefold()
            score = 0.0
            if "图纸" in text or "drawing" in folded:
                score = 89.0
                match = re.search(r"图纸", text)
                if match:
                    text = text[: match.end()].strip()
            elif (
                any(token in text for token in ("规格书", "承认书"))
                or "specification" in folded
            ):
                score = 87.0
            elif ("流程" in text or "process" in folded) and len(text) <= 60:
                score = 85.0
            elif "镭雕" in text and (":" in text or "：" in text):
                score = 84.0
                parts = re.split(r"[:：]", text, maxsplit=1)
                if len(parts) == 2 and _present(parts[1]):
                    text = parts[1].strip()
            if score:
                score += 2.0 / (1.0 + max(entry.order, 0))
                result.append(
                    _Candidate(
                        value=text,
                        refs=[entry.ref],
                        confidence=entry.confidence,
                        score=score + entry.confidence,
                    )
                )
    return result


def _company_candidates(entries: list[_Evidence]) -> list[_Candidate]:
    result: list[_Candidate] = []
    for entry in entries:
        for line in _display(entry.text).splitlines():
            match = _COMPANY_RE.search(line)
            confidence = entry.confidence
            score = 88.0
            if match is None:
                match = _TECH_COMPANY_RE.search(line)
                score = 75.0
            if match is None:
                continue
            result.append(
                _Candidate(
                    value=_text(match.group(1)),
                    refs=[entry.ref],
                    confidence=confidence,
                    score=score + confidence,
                )
            )
    return result
