"""Evidence-gated projection of DOCX visual assets onto technical lines."""

from __future__ import annotations

import math
import re
import unicodedata
from collections.abc import Mapping
from pathlib import PurePosixPath
from typing import Any

from .models import FieldMetadata, OrderLine, SourceReference
from .technical_evidence import _unique_refs

_VERIFIED_ASSET_ID_RE = re.compile(r"^asset:sha256:[0-9a-f]{64}$")
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_PRODUCT_IMAGE_ASSOCIATION_METHODS = {
    "explicit_product_anchor",
    "single_product_document",
    "spreadsheet_row_anchor",
}
_PRODUCT_VISUAL_ROLES = {"engineering_drawing", "product"}
_UNSAFE_VISUAL_ROLES = {
    "ambiguous",
    "decorative",
    "document_footer",
    "document_header",
    "logo",
    "signature",
    "stamp",
    "unresolved",
}


def _present(value: Any) -> bool:
    return value is not None and str(value).strip() != ""


def _safe_inventory_part(value: Any) -> str | None:
    part = str(value or "").strip()
    if not part or "\x00" in part or "\\" in part or part.startswith("/"):
        return None
    normalized = PurePosixPath(part)
    if (
        any(segment in {"", ".", ".."} for segment in normalized.parts)
        or normalized.as_posix() != part
        or normalized.parts[:2] != ("word", "media")
    ):
        return None
    return normalized.as_posix()


def _source_reference(payload: Any) -> SourceReference | None:
    if not isinstance(payload, Mapping):
        return None
    nested = payload.get("source_ref")
    candidate = nested if isinstance(nested, Mapping) else payload
    try:
        reference = SourceReference.model_validate(candidate)
    except (TypeError, ValueError):
        return None
    if reference.part:
        source_part = reference.part.split("#", 1)[0]
        if (
            "\x00" in source_part
            or "\\" in source_part
            or source_part.startswith("/")
            or ".." in PurePosixPath(source_part).parts
        ):
            return None
    if not any(
        _present(getattr(reference, field, None))
        for field in ("sheet", "page", "cell", "range", "part", "archive_path")
    ):
        return None
    return reference


def _verified_docx_image_assets(
    raw_content: Mapping[str, Any],
) -> dict[str, list[SourceReference]]:
    inventory = raw_content.get("source_asset_inventory")
    if not isinstance(inventory, Mapping):
        return {}
    result: dict[str, list[SourceReference]] = {}
    for asset in inventory.get("assets") or []:
        if not isinstance(asset, Mapping):
            continue
        asset_id = str(asset.get("asset_id") or "").strip()
        asset_sha256 = str(asset.get("sha256") or "").strip().casefold()
        mime_type = str(asset.get("mime_type") or "").strip().casefold()
        if (
            _VERIFIED_ASSET_ID_RE.fullmatch(asset_id) is None
            or asset_id != f"asset:sha256:{asset_sha256}"
            or not mime_type.startswith("image/")
            or asset.get("coverage_status") != "inventoried_referenced"
        ):
            continue
        raw_parts = list(asset.get("parts") or [])
        parts = [
            safe_part
            for value in raw_parts
            if (safe_part := _safe_inventory_part(value)) is not None
        ]
        occurrence_refs = [
            reference
            for value in asset.get("source_refs") or []
            if (reference := _source_reference(value)) is not None
        ]
        if not parts or len(parts) != len(raw_parts) or not occurrence_refs:
            continue
        result[asset_id] = _unique_refs(
            [*(SourceReference(part=part) for part in parts), *occurrence_refs]
        )
    return result


def _visual_routing_decision(
    extraction: Mapping[str, Any],
    raw_content: Mapping[str, Any],
    asset_id: str,
) -> Mapping[str, Any] | None:
    metadata = extraction.get("metadata")
    candidates = (
        raw_content.get("visual_region_routing"),
        extraction.get("visual_region_routing"),
        metadata.get("visual_region_routing")
        if isinstance(metadata, Mapping)
        else None,
    )
    for audit in candidates:
        if not isinstance(audit, Mapping):
            continue
        decisions = audit.get("decisions")
        if isinstance(decisions, Mapping) and isinstance(
            decisions.get(asset_id), Mapping
        ):
            return decisions[asset_id]
    return None


def _association_role_is_safe(
    attributes: Mapping[str, Any],
    decision: Mapping[str, Any] | None,
) -> bool:
    def contains_unsafe_role(payload: Mapping[str, Any]) -> bool:
        for key, value in payload.items():
            if "role" in str(key).casefold():
                roles = value if isinstance(value, (list, tuple, set)) else [value]
                normalized = {str(role or "").strip().casefold() for role in roles}
                if normalized & _UNSAFE_VISUAL_ROLES:
                    return True
            if isinstance(value, Mapping) and contains_unsafe_role(value):
                return True
            if isinstance(value, (list, tuple)) and any(
                isinstance(item, Mapping) and contains_unsafe_role(item)
                for item in value
            ):
                return True
        return False

    if contains_unsafe_role(attributes):
        return False
    if decision is None:
        return True
    action = str(decision.get("action") or "").strip().casefold()
    role = str(decision.get("role") or "").strip().casefold()
    suggested_role = str(decision.get("suggested_role") or "").strip().casefold()
    if action != "route" or suggested_role in _UNSAFE_VISUAL_ROLES:
        return False
    return role in _PRODUCT_VISUAL_ROLES


def _audited_drawing_region_fact_ids(raw_content: Mapping[str, Any]) -> set[str]:
    sidecar = raw_content.get("drawing_region_vlm")
    if (
        not isinstance(sidecar, Mapping)
        or sidecar.get("schema_version")
        != "m1.drawing-region-vlm-sidecar.v1"
    ):
        return set()
    result: set[str] = set()
    for asset in sidecar.get("assets") or []:
        if not isinstance(asset, Mapping):
            continue
        for audit in asset.get("audit") or []:
            if not isinstance(audit, Mapping) or audit.get("disposition") != "fact":
                continue
            result.update(
                str(fact_id)
                for fact_id in audit.get("fact_ids") or []
                if str(fact_id).strip()
            )
    return result


def _normalized_dimension(value: Any) -> str:
    normalized = unicodedata.normalize("NFKC", str(value or "")).casefold()
    normalized = normalized.replace("+/-", "±").replace("+-", "±")
    normalized = re.sub(r"(?<=\d),(?=\d)", ".", normalized)
    return re.sub(r"\s+", "", normalized).strip(";,，；")


def _verified_region_reference(
    evidence: Any,
) -> tuple[SourceReference, str] | None:
    if not isinstance(evidence, Mapping):
        return None
    evidence_id = str(evidence.get("evidence_id") or "").strip()
    quote = str(evidence.get("quote") or "").strip()
    source_payload = evidence.get("source_ref")
    if not evidence_id or not quote or not isinstance(source_payload, Mapping):
        return None
    reference = _source_reference(source_payload)
    if reference is None:
        return None
    extras = reference.model_extra or {}
    parent_id = str(extras.get("parent_evidence_id") or "").strip()
    asset_sha256 = str(extras.get("asset_sha256") or "").strip().casefold()
    region_sha256 = str(extras.get("region_sha256") or "").strip().casefold()
    asset_id = str(extras.get("asset_id") or "").strip()
    bbox = extras.get("bbox")
    region_bbox = extras.get("region_bbox_pixels")
    asset_width = extras.get("asset_width_pixels")
    asset_height = extras.get("asset_height_pixels")
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        return None
    try:
        numeric_bbox = [float(value) for value in bbox]
    except (TypeError, ValueError):
        return None
    if (
        not parent_id
        or _SHA256_RE.fullmatch(asset_sha256) is None
        or _SHA256_RE.fullmatch(region_sha256) is None
        or asset_id != f"asset:sha256:{asset_sha256}"
        or evidence_id != f"{parent_id}/region:{region_sha256}"
        or extras.get("authority") != "advisory"
        or extras.get("evidence_kind") != "model_transcription"
        or extras.get("model_transcription") is not True
        or extras.get("coordinate_space") != "image_pixels"
        or type(asset_width) is not int
        or type(asset_height) is not int
        or asset_width <= 0
        or asset_height <= 0
        or reference.page is None
        or reference.page <= 0
        or not isinstance(region_bbox, list)
        or len(region_bbox) != 4
        or any(type(value) is not int for value in region_bbox)
        or len(numeric_bbox) != 4
        or any(not math.isfinite(value) for value in numeric_bbox)
        or numeric_bbox != [float(value) for value in region_bbox]
        or numeric_bbox[2] <= numeric_bbox[0]
        or numeric_bbox[3] <= numeric_bbox[1]
        or numeric_bbox[0] < 0
        or numeric_bbox[1] < 0
        or numeric_bbox[2] > asset_width
        or numeric_bbox[3] > asset_height
    ):
        return None
    payload = reference.model_dump(mode="python", exclude_none=True)
    payload.update({"evidence_id": evidence_id, "evidence_quote": quote})
    return SourceReference.model_validate(payload), parent_id


def _dimension_parent_evidence_ids(metadata: FieldMetadata | None) -> set[str]:
    if metadata is None:
        return set()
    return {
        str((reference.model_extra or {}).get("evidence_id") or "").strip()
        for reference in metadata.source_refs
        if str((reference.model_extra or {}).get("evidence_id") or "").strip()
    }


def _merge_visual_dimension_metadata(
    metadata: FieldMetadata,
    references: list[SourceReference],
    fact_ids: list[str],
) -> FieldMetadata:
    payload = metadata.model_dump(mode="python")
    payload["source_refs"] = _unique_refs([*metadata.source_refs, *references])
    previous_ids = payload.get("visual_fact_ids") or []
    if isinstance(previous_ids, str):
        previous_ids = [previous_ids]
    payload["visual_fact_ids"] = list(
        dict.fromkeys(
            [
                *(str(value) for value in previous_ids if str(value).strip()),
                *fact_ids,
            ]
        )
    )
    payload["visual_evidence_source"] = "drawing_region_vlm.v1"
    return FieldMetadata.model_validate(payload)


def link_verified_drawing_region_dimensions(
    dimensions: list[dict[str, Any]],
    extraction: dict[str, Any],
    field_meta: dict[str, FieldMetadata],
) -> None:
    """Attach audited region bboxes to existing, parent-matched dimensions."""

    raw_content = extraction.get("raw_content")
    if not dimensions or not isinstance(raw_content, Mapping):
        return
    audited_fact_ids = _audited_drawing_region_fact_ids(raw_content)
    if not audited_fact_ids:
        return

    candidates: list[tuple[str, str, SourceReference, str]] = []
    for fact in raw_content.get("semantic_facts") or []:
        if (
            not isinstance(fact, Mapping)
            or fact.get("extractor") != "drawing_region_vlm.v1"
            or fact.get("status") != "advisory"
        ):
            continue
        fact_id = str(fact.get("fact_id") or "").strip()
        attributes = fact.get("attributes")
        if (
            fact_id not in audited_fact_ids
            or not isinstance(attributes, Mapping)
            or attributes.get("localization") != "region_bbox"
            or attributes.get("evidence_kind") != "model_transcription"
            or attributes.get("model_transcription") is not True
        ):
            continue
        for evidence in fact.get("evidence_refs") or []:
            verified = _verified_region_reference(evidence)
            if verified is None:
                continue
            reference, parent_id = verified
            candidates.append(
                (
                    _normalized_dimension(evidence.get("quote")),
                    parent_id,
                    reference,
                    fact_id,
                )
            )

    for index, dimension in enumerate(dimensions):
        value_path = f"$.key_dimensions[{index}].value"
        value_metadata = field_meta.get(value_path)
        parent_ids = _dimension_parent_evidence_ids(value_metadata)
        if not parent_ids:
            continue
        values = {_normalized_dimension(dimension.get("value"))}
        if dimension.get("unit"):
            values.add(
                _normalized_dimension(
                    f"{dimension.get('value')}{dimension.get('unit')}"
                )
            )
        matches = [
            (reference, fact_id)
            for value, parent_id, reference, fact_id in candidates
            if value in values and parent_id in parent_ids
        ]
        if not matches:
            continue
        references = _unique_refs(reference for reference, _fact_id in matches)
        fact_ids = list(dict.fromkeys(fact_id for _reference, fact_id in matches))
        for suffix in ("name", "value", "unit"):
            path = f"$.key_dimensions[{index}].{suffix}"
            metadata = field_meta.get(path)
            if metadata is not None:
                field_meta[path] = _merge_visual_dimension_metadata(
                    metadata,
                    references,
                    fact_ids,
                )


def link_verified_docx_image_associations(
    lines: list[OrderLine],
    extraction: dict[str, Any],
    field_meta: dict[str, FieldMetadata],
) -> None:
    """Project only evidence-backed, non-ambiguous visual associations."""

    if not lines:
        return
    raw_content = extraction.get("raw_content")
    if not isinstance(raw_content, Mapping):
        return
    assets = _verified_docx_image_assets(raw_content)
    if not assets:
        return

    attachments: dict[
        int, list[tuple[str, str, str, float, list[SourceReference]]]
    ] = {}
    for fact in raw_content.get("semantic_facts") or []:
        if not isinstance(fact, Mapping) or fact.get("name") != (
            "product_image_association"
        ):
            continue
        status = str(fact.get("status") or "").strip().casefold()
        value = fact.get("value")
        attributes = fact.get("attributes")
        if (
            status not in {"advisory", "verified"}
            or not isinstance(value, Mapping)
            or not isinstance(attributes, Mapping)
        ):
            continue
        asset_id = str(value.get("asset_id") or "").strip()
        product_id = str(value.get("product_id") or "").strip()
        product_match = re.fullmatch(r"line:(\d+)", product_id)
        method = str(attributes.get("association_method") or "").strip()
        if (
            asset_id not in assets
            or product_match is None
            or method not in _PRODUCT_IMAGE_ASSOCIATION_METHODS
        ):
            continue
        line_index = int(product_match.group(1))
        if line_index >= len(lines) or (
            method == "single_product_document" and len(lines) != 1
        ):
            continue
        decision = _visual_routing_decision(extraction, raw_content, asset_id)
        if not _association_role_is_safe(attributes, decision):
            continue
        fact_refs = [
            reference
            for evidence in fact.get("evidence_refs") or []
            if (reference := _source_reference(evidence)) is not None
        ]
        if not fact_refs:
            continue
        try:
            confidence = max(0.0, min(float(fact.get("confidence")), 1.0))
        except (TypeError, ValueError):
            continue
        attachments.setdefault(line_index, []).append(
            (
                asset_id,
                method,
                status,
                confidence,
                _unique_refs([*fact_refs, *assets[asset_id]]),
            )
        )

    for line_index, associations in attachments.items():
        line = lines[line_index]
        attached_asset_ids = list(
            dict.fromkeys(asset_id for asset_id, *_rest in associations)
        )
        line.image_refs = list(
            dict.fromkeys([*line.image_refs, *attached_asset_ids])
        )

        path = f"$.lines[{line_index}].image_refs"
        previous = field_meta.get(path)
        previous_payload = (
            previous.model_dump(mode="python") if previous is not None else {}
        )
        previous_refs = list(previous.source_refs) if previous is not None else []
        previous_methods = previous_payload.get("association_methods") or []
        if isinstance(previous_methods, str):
            previous_methods = [previous_methods]
        previous_method = previous_payload.get("association_method")
        methods = list(
            dict.fromkeys(
                [
                    *(str(item) for item in previous_methods if _present(item)),
                    *([str(previous_method)] if _present(previous_method) else []),
                    *(method for _asset, method, *_rest in associations),
                ]
            )
        )
        previous_asset_ids = previous_payload.get("asset_ids") or []
        if isinstance(previous_asset_ids, str):
            previous_asset_ids = [previous_asset_ids]
        asset_ids = list(
            dict.fromkeys(
                [
                    *(str(item) for item in previous_asset_ids if _present(item)),
                    *attached_asset_ids,
                ]
            )
        )
        confidences = [item[3] for item in associations]
        if previous is not None:
            confidences.append(previous.confidence)
        previous_payload.update(
            {
                "source_refs": _unique_refs(
                    [
                        *previous_refs,
                        *(
                            reference
                            for *_prefix, references in associations
                            for reference in references
                        ),
                    ]
                ),
                "confidence": min(confidences),
                "inferred": True,
                "review_required": bool(
                    previous_payload.get("review_required")
                    or any(item[2] == "advisory" for item in associations)
                ),
                "association_method": (
                    methods[0]
                    if len(methods) == 1
                    else "multiple_verified_associations"
                ),
                "association_methods": methods,
                "asset_ids": asset_ids,
            }
        )
        field_meta[path] = FieldMetadata.model_validate(previous_payload)


__all__ = [
    "link_verified_docx_image_associations",
    "link_verified_drawing_region_dimensions",
]
