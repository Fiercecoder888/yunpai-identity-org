"""Business projection for evidence-backed technical documents."""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping
from datetime import date
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher
from itertools import pairwise
from pathlib import Path
from typing import Any

from m1.documents.models import (
    DocumentHeader,
    DocumentRecord,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)

from .technical_evidence import (
    _CHINESE_DATE_RE,
    _CODE_RE,
    _DATE_RE,
    _DIMENSION_LABEL_TOKENS,
    _DIMENSION_PATTERNS,
    _NUMBERED_STEP_RE,
    _SECTION_RE,
    _Candidate,
    _canonical_label,
    _Cell,
    _company_candidates,
    _display,
    _docx_evidence,
    _Evidence,
    _heading_candidates,
    _inline_label_candidates,
    _is_revision_history_table,
    _is_spec_label,
    _key,
    _merge_candidates,
    _pdf_evidence,
    _present,
    _ref_payload,
    _source_display,
    _source_ref,
    _spatial_label_candidates,
    _Table,
    _table_label_candidates,
    _text,
    _unique_refs,
    _valid_scalar,
)
from .technical_image_projection import (
    link_verified_docx_image_associations,
    link_verified_drawing_region_dimensions,
)


def _semantic_filename_stem(filename: str) -> str | None:
    stem = re.sub(r"^\d{1,3}_", "", Path(filename).stem).strip()
    compact = re.sub(r"[^A-Za-z0-9]", "", stem)
    if re.fullmatch(r"[0-9a-fA-F]{20,}", compact):
        return None
    if re.fullmatch(
        r"(?:img|image|scan|scanned|screenshot|page|photo|pic|dsc)[-_ ]*\d+",
        stem,
        flags=re.IGNORECASE,
    ):
        return None
    if re.fullmatch(
        r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-"
        r"[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}",
        stem,
    ):
        return None
    return stem or None


_INTERFACE_ONLY_IDENTIFIER_RE = re.compile(
    r"(?:HDMI(?:\d(?:\.\d+)?)?|HDTV(?:\d(?:\.\d+)?)?|"
    r"DISPLAYPORT(?:\d(?:\.\d+)?)?|DP(?:\d(?:\.\d+)?)?|"
    r"USB(?:\d(?:\.\d+)?)?|USBTYPEC|TYPEC|RJ\d+|8P8C)",
    re.IGNORECASE,
)


def _is_interface_only_identifier(value: Any) -> bool:
    compact = re.sub(r"[\s_/-]+", "", _text(value))
    return bool(compact and _INTERFACE_ONLY_IDENTIFIER_RE.fullmatch(compact))


def _candidate_has_document_evidence(candidate: _Candidate | None) -> bool:
    if candidate is None:
        return False
    return any(
        _key(ref.part) != _key("source.original_filename")
        for ref in candidate.refs
        if _present(ref.part)
    )


def _is_native_docx(
    metadata: Mapping[str, Any],
    raw: Mapping[str, Any],
    filename: str,
) -> bool:
    mineru_input = metadata.get("mineru_input")
    if isinstance(mineru_input, Mapping):
        source = mineru_input.get("source")
        normalized = mineru_input.get("normalized")
        source_type = (
            str(source.get("file_type") or "") if isinstance(source, Mapping) else ""
        )
        normalized_type = (
            str(normalized.get("file_type") or "")
            if isinstance(normalized, Mapping)
            else ""
        )
        conversion = (
            str(normalized.get("conversion") or "")
            if isinstance(normalized, Mapping)
            else ""
        )
        if "docx" in {source_type.casefold(), normalized_type.casefold()} and (
            not conversion or conversion.casefold() == "native"
        ):
            return True
    native_page = any(
        str(block.get("source") or "").casefold() == "docx-native-ooxml"
        for page in raw.get("pages") or []
        if isinstance(page, Mapping)
        for block in page.get("blocks") or []
        if isinstance(block, Mapping)
    )
    if native_page:
        return True
    return Path(filename).suffix.casefold() == ".docx" and (
        "pages" not in raw or any(key in raw for key in ("paragraphs", "textboxes"))
    )


def _subtype_hint_was_applied(metadata: Mapping[str, Any]) -> bool:
    for key in ("classification_normalization", "production_normalization"):
        value = metadata.get(key)
        if isinstance(value, Mapping) and bool(
            value.get("document_subtype_hint_applied")
        ):
            return True
    return False


def _trusted_native_docx_subtype(raw: Mapping[str, Any]) -> str | None:
    payload = raw.get("native_classification")
    if not isinstance(payload, Mapping):
        return None
    if payload.get("source") != "docx-native-classifier-v1":
        return None
    if payload.get("document_type") != "technical_document":
        return None
    subtype = str(payload.get("document_subtype") or "")
    if subtype not in {
        "approval_drawing",
        "engineering_drawing",
        "product_specification",
    }:
        return None
    return subtype


def _has_engineering_drawing_evidence(
    entries: list[_Evidence], tables: list[_Table]
) -> bool:
    drawing_text = any(
        entry.kind != "filename"
        and len(_text(entry.text)) <= 180
        and bool(
            re.search(
                r"(?:工程图(?:纸|样)?|图纸|装配图|尺寸图|\bengineering drawing\b|"
                r"\bdrawing\b)",
                _text(entry.text),
                re.IGNORECASE,
            )
        )
        for entry in entries
    )
    if not drawing_text:
        return False

    process_evidence = any(
        _key(entry.text) in {_key("工艺流程"), _key("process flow")}
        for entry in entries
    )
    dimension_label_count = len(
        {
            _key(cell.text)
            for table in tables
            for row in table.rows[:4]
            for cell in row
            if cell is not None
            and any(
                token in _text(cell.text).casefold()
                for token in _DIMENSION_LABEL_TOKENS
            )
        }
    )
    title_block_evidence = any(
        _canonical_label(cell.text) in {"drawing_number", "material_number", "scale"}
        for table in tables
        for row in table.rows
        for cell in row
        if cell is not None
    )
    structural_evidence = dimension_label_count >= 2 or title_block_evidence
    return structural_evidence and (process_evidence or title_block_evidence)


def _filename_code_candidates(
    filename: str, entries: list[_Evidence]
) -> list[_Candidate]:
    stem = _semantic_filename_stem(filename)
    if stem is None:
        return []
    filename_ref = _source_ref(part="source.original_filename")
    ocr_codes = [
        entry
        for entry in entries
        if entry.kind == "ocr_token"
        and len(re.sub(r"[^A-Za-z0-9]", "", entry.text)) >= 5
        and re.search(r"[A-Za-z]", entry.text)
        and re.search(r"\d", entry.text)
    ]
    result: list[_Candidate] = []
    for match in _CODE_RE.finditer(stem):
        value = match.group(0).strip("._/-")
        compact = re.sub(r"[^A-Za-z0-9]", "", value).upper()
        if (
            len(compact) < 4
            or not re.search(r"\d", compact)
            or _DATE_RE.fullmatch(value)
        ):
            continue
        if re.match(r"^(?:HDMI|DISPLAYPORT|DP\d|USB|TYPEC|RJ\d|8P8C)", compact):
            continue
        if len(compact) < 6 and not re.search(r"[._/-]", value):
            continue
        score = 35.0 + min(len(compact), 20) / 10.0
        refs: list[SourceReference] = [filename_ref]
        confidence = 0.72
        best_ratio = 0.0
        best_entry: _Evidence | None = None
        for entry in ocr_codes:
            other = re.sub(r"[^A-Za-z0-9]", "", entry.text).upper()
            ratio = SequenceMatcher(None, compact, other).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_entry = entry
        if best_entry is not None and best_ratio >= 0.78:
            score += 25.0 * best_ratio
            refs.append(best_entry.ref)
            confidence = min(0.94, (confidence + best_entry.confidence) / 2 + 0.08)
        result.append(
            _Candidate(
                value=value,
                refs=_unique_refs(refs),
                confidence=confidence,
                score=score,
            )
        )
    return result


def _link_images_to_single_line(
    lines: list[OrderLine],
    extraction: dict[str, Any],
    field_meta: dict[str, FieldMetadata],
) -> None:
    """Bind embedded visuals only when the document has one unambiguous item."""

    if len(lines) != 1 or lines[0].image_refs:
        return
    raw_content = extraction.get("raw_content")
    if not isinstance(raw_content, dict):
        return
    images = [
        item for item in raw_content.get("images") or [] if isinstance(item, dict)
    ]
    asset_paths = list(
        dict.fromkeys(
            str(item.get("asset_path") or "").strip()
            for item in images
            if str(item.get("asset_path") or "").strip()
        )
    )
    if not asset_paths:
        return
    lines[0].image_refs = asset_paths
    source_refs: list[SourceReference] = []
    for item in images:
        target_part = str(item.get("target_part") or "").strip()
        if target_part:
            source_refs.append(SourceReference(part=target_part))
        for occurrence in item.get("references") or []:
            if not isinstance(occurrence, dict):
                continue
            paragraph_index = occurrence.get("xml_paragraph_index")
            if paragraph_index is None:
                continue
            source_refs.append(
                SourceReference(
                    part=f"word/document.xml#paragraph:{int(paragraph_index)}"
                )
            )
    if source_refs:
        field_meta["$.lines[0].image_refs"] = FieldMetadata(
            source_refs=_unique_refs(source_refs),
            confidence=1.0,
            inferred=True,
            review_required=False,
            association_method="single_item_document",
        )
    metadata = extraction.setdefault("metadata", {})
    if isinstance(metadata, dict):
        metadata["technical_image_linking"] = {
            "strategy": "single_item_document",
            "image_count": len(asset_paths),
            "line_id": lines[0].line_id,
        }


def _title_code_candidates(entries: list[_Evidence]) -> list[_Candidate]:
    result: list[_Candidate] = []
    pattern = re.compile(
        r"^\s*([A-Za-z0-9][A-Za-z0-9._/-]{2,})\s*(?=[^\n]{0,40}(?:图纸|drawing))",
        re.IGNORECASE,
    )
    for entry in entries:
        if entry.kind in {"image", "natural_image", "text_image"}:
            continue
        match = pattern.search(_text(entry.text))
        if not match:
            continue
        value = match.group(1)
        if _is_interface_only_identifier(value) or not _valid_scalar(
            "drawing_number", value
        ):
            continue
        result.append(
            _Candidate(
                value=value,
                refs=[entry.ref],
                confidence=entry.confidence,
                score=80.0 + entry.confidence,
            )
        )
    return result


def _filename_title(filename: str) -> _Candidate | None:
    stem = _semantic_filename_stem(filename)
    if stem is None:
        return None
    stem = re.sub(r"(?:[-_（(]?20\d{2}[.-]\d{1,2}[.-]\d{1,2}[)）]?)$", "", stem).strip(
        " -_"
    )
    if not stem:
        return None
    return _Candidate(
        value=stem,
        refs=[_source_ref(part="source.original_filename")],
        confidence=0.7,
        score=30.0,
    )


def _date_value(value: str) -> date | None:
    match = _CHINESE_DATE_RE.search(value) or _DATE_RE.search(value)
    if not match:
        return None
    try:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return None


def _identifier_values(value: str) -> list[str]:
    lines = [_text(line) for line in _display(value).splitlines() if _present(line)]
    if len(lines) > 1:
        return list(dict.fromkeys(lines))
    matches = re.findall(
        r"[A-Za-z0-9]+(?:[._/-][A-Za-z0-9]+)+(?:\s+[A-Za-z]{1,8})?",
        _text(value),
    )
    return list(dict.fromkeys(matches or lines))


def _existing_candidate(
    record: DocumentRecord,
    path: str,
    value: Any,
    *,
    field: str,
) -> _Candidate | None:
    if not _present(value) or not _valid_scalar(field, value):
        return None
    meta = record.field_meta.get(path)
    refs = list(meta.source_refs) if meta is not None else []
    if field in {"drawn_by", "checked_by", "approved_by"} and not refs:
        return None
    return _Candidate(
        value=_display(value),
        refs=refs,
        confidence=float(meta.confidence) if meta is not None else 0.99,
        score=130.0,
    )


def _best(candidates: Iterable[_Candidate]) -> _Candidate | None:
    values = [candidate for candidate in candidates if _present(candidate.value)]
    if not values:
        return None
    return max(
        values,
        key=lambda candidate: (
            candidate.score,
            candidate.confidence,
            -len(candidate.value),
        ),
    )


def _reverse_label_matrix(table: _Table) -> bool:
    """Return true for title blocks whose values sit above dense label rows."""

    paired_rows = 0
    for row_index, row in enumerate(table.rows[1:], start=1):
        previous_row = table.rows[row_index - 1]
        pairs = 0
        for column, cell in enumerate(row):
            if cell is None or not _present(cell.text):
                continue
            field = _canonical_label(cell.text)
            if field is None or column >= len(previous_row):
                continue
            value_cell = previous_row[column]
            if value_cell is not None and _valid_scalar(field, value_cell.text):
                pairs += 1
        if pairs >= 2:
            paired_rows += 1
    return paired_rows >= 2


def _table_specifications(tables: list[_Table]) -> list[dict[str, Any]]:
    specs: list[dict[str, Any]] = []

    def add(
        name_cell: _Cell,
        value_cells: list[_Cell],
        *,
        row_index: int,
    ) -> None:
        values = [cell.text for cell in value_cells if _present(cell.text)]
        if not values:
            return
        value = " | ".join(dict.fromkeys(values))
        specs.append(
            {
                "name": _text(name_cell.text),
                "value": value,
                "row": row_index + 1,
                "source_refs": [
                    _ref_payload(ref)
                    for ref in _unique_refs(
                        [name_cell.ref, *(cell.ref for cell in value_cells)]
                    )
                ],
                "_name_refs": [name_cell.ref],
                "_value_refs": _unique_refs(cell.ref for cell in value_cells),
                "_confidence": min(
                    [name_cell.confidence, *(cell.confidence for cell in value_cells)]
                ),
            }
        )

    for table in tables:
        if _reverse_label_matrix(table) or _is_revision_history_table(table):
            continue
        leading_groups: dict[str, set[str]] = {}
        for row in table.rows:
            nonempty = [
                cell for cell in row if cell is not None and _present(cell.text)
            ]
            if len(nonempty) < 3:
                continue
            leading_groups.setdefault(_key(nonempty[0].text), set()).add(
                _key(nonempty[1].text)
            )
        repeated_group_labels = {
            label
            for label, child_labels in leading_groups.items()
            if label and len(child_labels) >= 2
        }

        # Conventional header row followed by one or more data rows.
        for row_index, row in enumerate(table.rows[:-1]):
            headers = [cell for cell in row if cell is not None and _present(cell.text)]
            spec_header_count = sum(_is_spec_label(cell.text) for cell in headers)
            if (
                len(headers) < 2
                or spec_header_count < 2
                or spec_header_count / len(headers) < 0.75
            ):
                continue
            for data_index in range(row_index + 1, min(row_index + 4, len(table.rows))):
                data_row = table.rows[data_index]
                if not any(
                    cell is not None and _present(cell.text) for cell in data_row
                ):
                    continue
                for header in headers:
                    if header.column >= len(data_row):
                        continue
                    value_cell = data_row[header.column]
                    if value_cell is None or not _present(value_cell.text):
                        continue
                    add(header, [value_cell], row_index=data_index)
                break
            break

        # Alternating label/value cells and compact specification rows.
        for row_index, row in enumerate(table.rows):
            nonempty = [
                cell for cell in row if cell is not None and _present(cell.text)
            ]
            if len(nonempty) < 2:
                continue
            consumed: set[int] = set()
            for position, cell in enumerate(row[:-1]):
                if (
                    cell is None
                    or not _present(cell.text)
                    or not _is_spec_label(cell.text)
                ):
                    continue
                value_cells: list[_Cell] = []
                for peer in row[position + 1 :]:
                    if peer is None or not _present(peer.text):
                        continue
                    if _is_spec_label(peer.text):
                        break
                    value_cells.append(peer)
                    break
                if value_cells:
                    add(cell, value_cells, row_index=row_index)
                    consumed.add(cell.column)
                    consumed.update(peer.column for peer in value_cells)

            first = nonempty[0]
            if first.column in consumed or len(nonempty) < 3:
                continue
            if _key(first.text) in repeated_group_labels:
                continue
            if sum(_is_spec_label(cell.text) for cell in nonempty) >= 2:
                continue
            if _is_spec_label(first.text) or (
                len(_text(first.text)) <= 12
                and any(
                    token in _text(first.text).casefold()
                    for token in (
                        "导体",
                        "绝缘",
                        "屏蔽",
                        "外被",
                        "构成",
                        "材质",
                        "规格",
                    )
                )
            ):
                add(first, nonempty[1:], row_index=row_index)

    deduped: dict[tuple[str, str], dict[str, Any]] = {}
    for spec in specs:
        key = (_key(spec["name"]), _key(spec["value"]))
        current = deduped.get(key)
        if current is None or spec["_confidence"] > current["_confidence"]:
            deduped[key] = spec
    return list(deduped.values())


def _inline_specifications(
    entries: list[_Evidence], *, document_subtype: str
) -> list[dict[str, Any]]:
    if document_subtype == "process_document":
        return []
    result: list[dict[str, Any]] = []
    section_names = {
        "环保测试",
        "电气特性",
        "机械特性",
        "技术要求",
        "electrical test",
        "mechanical",
        "environmental test",
        "technical requirements",
    }

    def section_label(value: str) -> bool:
        normalized = _text(value).rstrip(":：")
        folded = normalized.casefold()
        return (
            _is_spec_label(normalized)
            or folded in section_names
            or any(
                token in folded
                for token in (
                    "temperature",
                    "electrical",
                    "mechanical",
                    "environmental",
                    "测试",
                    "特性",
                    "要求",
                    "温度",
                )
            )
        )

    for entry in entries:
        if entry.kind not in {
            "paragraph",
            "list",
            "native_text",
            "textbox",
            "native_block",
            "ocr_line",
        }:
            continue
        lines = [line for line in _display(entry.text).splitlines() if line]
        if not lines:
            continue
        name = ""
        values: list[str] = []
        match = re.match(r"^([^:：]{1,40})[:：]\s*(.*)$", lines[0])
        if match:
            name = _text(match.group(1))
            values = [match.group(2), *lines[1:]]
        elif _text(lines[0]).casefold() in section_names:
            name = _text(lines[0])
            values = lines[1:]
        if not name or not any(_present(value) for value in values):
            continue
        if not (section_label(name) or any(token in name for token in ("镭雕",))):
            continue
        value = "\n".join(_display(item) for item in values if _present(item))
        result.append(
            {
                "name": name,
                "value": value,
                "source_refs": [_ref_payload(entry.ref)],
                "_name_refs": [entry.ref],
                "_value_refs": [entry.ref],
                "_confidence": entry.confidence,
            }
        )

    ordered = sorted(entries, key=lambda item: item.order)
    for index, entry in enumerate(ordered):
        if entry.kind not in {"title", "heading"}:
            continue
        name = _text(entry.text).rstrip(":：")
        if not section_label(name):
            continue
        values: list[_Evidence] = []
        for candidate in ordered[index + 1 :]:
            if candidate.ref.page != entry.ref.page:
                break
            if candidate.kind in {"title", "heading"}:
                break
            if candidate.order - entry.order > 3:
                break
            inline_section = re.match(
                r"^([^:：]{1,40})[:：]",
                _display(candidate.text),
            )
            if inline_section and section_label(inline_section.group(1)):
                break
            if candidate.kind in {
                "paragraph",
                "list",
                "native_text",
                "native_block",
                "ocr_line",
            } and _present(candidate.text):
                values.append(candidate)
        if not values:
            continue
        refs = _unique_refs([entry.ref, *(candidate.ref for candidate in values)])
        result.append(
            {
                "name": name,
                "value": "\n".join(_display(candidate.text) for candidate in values),
                "source_refs": [_ref_payload(ref) for ref in refs],
                "_name_refs": [entry.ref],
                "_value_refs": _unique_refs(candidate.ref for candidate in values),
                "_confidence": min(
                    [entry.confidence, *(candidate.confidence for candidate in values)]
                ),
            }
        )
    return result


def _dimension_matches(value: str) -> list[str]:
    found: list[tuple[int, int, str]] = []
    for pattern in _DIMENSION_PATTERNS:
        for match in pattern.finditer(_display(value)):
            raw_match = match.group(0)
            start = match.start() + len(raw_match) - len(raw_match.lstrip())
            end = match.end() - (len(raw_match) - len(raw_match.rstrip()))
            text = _text(raw_match).strip(".,;，；")
            if text:
                found.append((start, end, text))
    result: list[str] = []
    seen: set[str] = set()
    selected_ranges: list[tuple[int, int]] = []
    for start, end, dimension_value in sorted(
        found,
        key=lambda item: (item[0], -(item[1] - item[0])),
    ):
        key = _key(dimension_value)
        if key in seen or any(
            start >= left and end <= right for left, right in selected_ranges
        ):
            continue
        seen.add(key)
        selected_ranges.append((start, end))
        result.append(dimension_value)
    return result


def _dimensions(
    specifications: list[dict[str, Any]], entries: list[_Evidence]
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    def add(
        name: str, value: str, refs: list[SourceReference], confidence: float
    ) -> None:
        equivalent_value = re.sub(r"(?<=\d),(?=\d)", ".", value)
        key = (_key(name), _key(equivalent_value))
        if key in seen or not _present(value):
            return
        seen.add(key)
        unit_match = re.search(r"\b(mm|cm|inch|in|m)\b", value, re.IGNORECASE)
        item: dict[str, Any] = {
            "name": name,
            "value": value,
            "source_refs": [_ref_payload(ref) for ref in _unique_refs(refs)],
            "_name_refs": refs,
            "_value_refs": refs,
            "_confidence": confidence,
        }
        if unit_match:
            item["unit"] = unit_match.group(1)
        result.append(item)

    for spec in specifications:
        name = _text(spec["name"])
        value = _display(spec["value"])
        refs = list(spec.get("_value_refs") or [])
        confidence = float(spec.get("_confidence") or 0.75)
        if any(token in name.casefold() for token in _DIMENSION_LABEL_TOKENS):
            add(name, value, refs, confidence)
            continue
        for match in _dimension_matches(value):
            add(name, match, refs, confidence)

    # Spatial OCR tokens and short native blocks expose drawing annotations that
    # are not part of any table.
    for entry in entries:
        if entry.kind not in {"ocr_token", "native_block", "native_text", "image"}:
            continue
        text = _display(entry.text)
        if len(text) > 180:
            continue
        for match in _dimension_matches(text):
            if re.fullmatch(
                r"±[ \t]*\d+(?:[.,]\d+)?(?:[ \t]*(?:mm|cm|m))?",
                match,
                flags=re.IGNORECASE,
            ):
                continue
            add("尺寸", match, [entry.ref], entry.confidence)
    return result[:200]


_PROCESS_CONTEXT_RE = re.compile(
    r"工艺|流程|工序|步骤|作业|操作|process|procedure|instruction|operation",
    re.IGNORECASE,
)
_NON_PROCESS_FLOW_TOKEN_RE = re.compile(
    r"(?:图纸|承认书|规格书|产品名称|产品编号|图号|版本|日期|公司|"
    r"drawing|specification|revision)|"
    r"^(?:长度|宽度|高度|厚度|尺寸|外径|内径|孔径|直径|公差|间距)"
    r"\s*[：:]?\s*[-+ΦφØ\d]",
    re.IGNORECASE,
)


def _process_steps(
    entries: list[_Evidence], *, document_subtype: str
) -> list[dict[str, Any]]:
    paragraphs = sorted(
        [entry for entry in entries if entry.kind in {"paragraph", "textbox"}],
        key=lambda entry: entry.order,
    )
    result: list[dict[str, Any]] = []
    section: str | None = None
    for index, entry in enumerate(paragraphs):
        text = _text(entry.text)
        section_match = _SECTION_RE.match(text)
        if section_match:
            section = f"{section_match.group(1)}、{section_match.group(2)}"
            continue
        match = _NUMBERED_STEP_RE.match(text)
        if not match:
            continue
        if document_subtype != "process_document" and not (
            section and _PROCESS_CONTEXT_RE.search(section)
        ):
            continue
        item: dict[str, Any] = {
            "step_no": match.group(1),
            "name": match.group(2).strip(),
            "source_refs": [_ref_payload(entry.ref)],
            "_field_refs": {"step_no": [entry.ref], "name": [entry.ref]},
            "_confidence": entry.confidence,
        }
        if section:
            item["section"] = section
            item["_field_refs"]["section"] = [entry.ref]
        if index + 1 < len(paragraphs):
            next_entry = paragraphs[index + 1]
            next_text = _text(next_entry.text)
            if (
                next_entry.order - entry.order <= 3
                and not _NUMBERED_STEP_RE.match(next_text)
                and not _SECTION_RE.match(next_text)
                and len(next_text) >= 12
            ):
                item["description"] = next_text
                item["source_refs"].append(_ref_payload(next_entry.ref))
                item["_field_refs"]["description"] = [next_entry.ref]
        result.append(item)

    for index, entry in enumerate(paragraphs):
        if _key(entry.text) not in {_key("工艺流程"), _key("process flow")}:
            continue
        flow_entries = [
            candidate
            for candidate in paragraphs[index + 1 :]
            if 0 < candidate.order - entry.order <= 6
        ]
        step_no = 1
        flow_started = False
        previous_order = entry.order
        for candidate in flow_entries:
            if flow_started and candidate.order - previous_order > 2:
                break
            raw = _source_display(candidate.text)
            tokens = [
                _text(token)
                for token in re.split(r"(?:\t+| {2,}|[→➜➡]+)", raw)
                if _present(token)
            ]
            invalid_flow = (
                len(tokens) < 2
                or any(len(token) > 32 for token in tokens)
                or any(
                    _NON_PROCESS_FLOW_TOKEN_RE.search(token)
                    or _dimension_matches(token)
                    for token in tokens
                )
            )
            if invalid_flow:
                if flow_started:
                    break
                continue
            flow_started = True
            previous_order = candidate.order
            for token in tokens:
                result.append(
                    {
                        "step_no": str(step_no),
                        "name": token,
                        "source_refs": [_ref_payload(candidate.ref)],
                        "_field_refs": {
                            "step_no": [candidate.ref],
                            "name": [candidate.ref],
                        },
                        "_confidence": candidate.confidence,
                    }
                )
                step_no += 1

    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for item in result:
        key = (
            _key(item.get("section")),
            _key(item.get("step_no")),
            _key(item.get("name")),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


_HEADERLESS_LINE_NUMBER_RE = re.compile(r"^[1-9]\d{0,3}$")
_HEADERLESS_QUANTITY_RE = re.compile(
    r"^([+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+))\s*"
    r"([A-Za-z\u00b5\u03bc\u4e00-\u9fff]{1,12})$"
)
_MATERIAL_CODE_SUFFIX_RE = re.compile(r"\s*[\u25b3\u25b2\u25bd\u25bc]+\s*$")
_HEADERLESS_MIN_COLUMNS = 4
_HEADERLESS_MIN_DISTINCT_ORDINALS = 2
_HEADERLESS_MIN_ORDINAL_COVERAGE = 0.6
_HEADERLESS_MIN_DIRECTION_CONSISTENCY = 0.75
_HEADERLESS_PRODUCT_TITLE_RE = re.compile(
    r"(?:\b(?:cable|connector|assembly|adapter|wire|harness)\b|"
    r"\u7ebf\u7f06|\u7535\u7f06|\u8fde\u63a5\u5668|\u8f6c\u63a5\u7ebf|\u7ebf\u675f|"
    r"\u7ec4\u4ef6|\u603b\u6210)",
    re.IGNORECASE,
)


def _headerless_material_code(value: Any) -> str | None:
    code = _MATERIAL_CODE_SUFFIX_RE.sub("", _display(value)).strip()
    if (
        not code
        or _canonical_label(code) is not None
        or _is_interface_only_identifier(code)
        or _CODE_RE.fullmatch(code) is None
    ):
        return None
    return code


def _headerless_quantity(value: Any) -> tuple[Decimal, str] | None:
    match = _HEADERLESS_QUANTITY_RE.fullmatch(_text(value))
    if match is None:
        return None
    try:
        quantity = Decimal(match.group(1).replace(",", "."))
    except InvalidOperation:
        return None
    if not quantity.is_finite() or quantity < 0:
        return None
    return quantity, match.group(2)


def _headerless_material_rows(tables: list[_Table]) -> list[dict[str, Any]]:
    """Recover BOM-like rows whose column semantics are encoded in their values.

    Engineering PDFs often lose the visible header while retaining a stable
    ``ordinal, material code, quantity+unit, description`` shape.  Merged title
    blocks can inherit the last material row, so one physical identity is kept
    once and the resulting ordinal sequence must remain coherent.
    """

    result: list[dict[str, Any]] = []
    for table in tables:
        if _reverse_label_matrix(table) or _is_revision_history_table(table):
            continue
        candidates: list[dict[str, Any]] = []
        seen_identities: set[tuple[int, str, str, str]] = set()
        for row_index, row in enumerate(table.rows):
            if len(row) < _HEADERLESS_MIN_COLUMNS or any(
                row[index] is None for index in range(_HEADERLESS_MIN_COLUMNS)
            ):
                continue
            line_cell, code_cell, quantity_cell = row[:3]
            assert line_cell is not None
            assert code_cell is not None
            assert quantity_cell is not None
            line_text = _text(line_cell.text)
            if _HEADERLESS_LINE_NUMBER_RE.fullmatch(line_text) is None:
                continue
            code = _headerless_material_code(code_cell.text)
            quantity = _headerless_quantity(quantity_cell.text)
            description_cells = [
                cell
                for cell in row[3:]
                if cell is not None and _present(cell.text)
            ]
            if code is None or quantity is None or not description_cells:
                continue
            line_no = int(line_text)
            quantity_value, unit = quantity
            identity = (line_no, _key(code), str(quantity_value), unit.casefold())
            if identity in seen_identities:
                continue
            seen_identities.add(identity)
            description = " ".join(
                _display(cell.text) for cell in description_cells
            )
            raw_columns = {
                "line_no": _display(line_cell.text),
                "product_code": _display(code_cell.text),
                "quantity": _display(quantity_cell.text),
                "name_raw": description,
            }
            column_refs = {
                "line_no": [line_cell.ref],
                "product_code": [code_cell.ref],
                "quantity": [quantity_cell.ref],
                "name_raw": [cell.ref for cell in description_cells],
            }
            candidates.append(
                {
                    "table_id": table.table_id,
                    "row": row_index,
                    "line_no": line_no,
                    "line_ref": line_cell.ref,
                    "code": code,
                    "code_ref": code_cell.ref,
                    "quantity": quantity_value,
                    "unit": unit,
                    "quantity_ref": quantity_cell.ref,
                    "name": description,
                    "name_refs": [cell.ref for cell in description_cells],
                    "raw_columns": raw_columns,
                    "column_refs": column_refs,
                    "confidence": min(
                        cell.confidence
                        for cell in row
                        if cell is not None and _present(cell.text)
                    ),
                }
            )
        ordinals = [int(item["line_no"]) for item in candidates]
        distinct_ordinals = set(ordinals)
        if len(distinct_ordinals) < _HEADERLESS_MIN_DISTINCT_ORDINALS:
            continue
        ordinal_span = max(distinct_ordinals) - min(distinct_ordinals) + 1
        if (
            len(distinct_ordinals) / max(1, ordinal_span)
            < _HEADERLESS_MIN_ORDINAL_COVERAGE
        ):
            continue
        direction_steps = [
            right - left
            for left, right in pairwise(ordinals)
            if right != left
        ]
        if direction_steps:
            dominant = max(
                sum(step > 0 for step in direction_steps),
                sum(step < 0 for step in direction_steps),
            )
            if (
                dominant / len(direction_steps)
                < _HEADERLESS_MIN_DIRECTION_CONSISTENCY
            ):
                continue
        result.extend(sorted(candidates, key=lambda item: int(item["line_no"])))
    return result


def _headerless_material_title_candidates(
    tables: list[_Table], material_rows: list[dict[str, Any]]
) -> list[_Candidate]:
    """Recover a product title from merged tail rows without trusting labels."""

    identities_by_table: dict[str, set[tuple[int, str, str, str]]] = {}
    source_rows: dict[str, set[int]] = {}
    for item in material_rows:
        table_id = str(item["table_id"])
        identities_by_table.setdefault(table_id, set()).add(
            (
                int(item["line_no"]),
                _key(item["code"]),
                str(item["quantity"]),
                str(item["unit"]).casefold(),
            )
        )
        source_rows.setdefault(table_id, set()).add(int(item["row"]))

    candidates: list[_Candidate] = []
    for table in tables:
        identities = identities_by_table.get(table.table_id)
        if not identities:
            continue
        for row_index, row in enumerate(table.rows):
            if row_index in source_rows.get(table.table_id, set()) or len(row) < 4:
                continue
            if any(row[index] is None for index in range(4)):
                continue
            line_cell, code_cell, quantity_cell = row[:3]
            assert line_cell is not None
            assert code_cell is not None
            assert quantity_cell is not None
            line_text = _text(line_cell.text)
            code = _headerless_material_code(code_cell.text)
            quantity = _headerless_quantity(quantity_cell.text)
            if (
                _HEADERLESS_LINE_NUMBER_RE.fullmatch(line_text) is None
                or code is None
                or quantity is None
            ):
                continue
            quantity_value, unit = quantity
            identity = (int(line_text), _key(code), str(quantity_value), unit.casefold())
            if identity not in identities:
                continue
            description_cells = [
                cell
                for cell in row[3:]
                if cell is not None and _present(cell.text)
            ]
            if not description_cells or any(
                _canonical_label(cell.text) is not None for cell in description_cells
            ):
                continue
            title = " ".join(_display(cell.text) for cell in description_cells)
            if not (4 <= len(title) <= 180) or not _HEADERLESS_PRODUCT_TITLE_RE.search(
                title
            ):
                continue
            confidence = min(cell.confidence for cell in description_cells)
            candidates.append(
                _Candidate(
                    value=title,
                    refs=[cell.ref for cell in description_cells],
                    confidence=confidence,
                    score=96.0 + confidence,
                )
            )
    return candidates


def _table_product_rows(tables: list[_Table]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    name_aliases = {
        _key(value) for value in ("产品名称", "物料名称", "名称", "品名", "name")
    }
    code_aliases = {
        _key(value)
        for value in ("产品编号", "物料编码", "料号", "图号", "part no", "code")
    }
    model_aliases = {_key(value) for value in ("型号", "产品型号", "规格型号", "model")}
    for table in tables:
        if _reverse_label_matrix(table) or _is_revision_history_table(table):
            continue
        for header_index, header_row in enumerate(table.rows[:-1]):
            mapping: dict[str, int] = {}
            headers: dict[int, _Cell] = {}
            for column, cell in enumerate(header_row):
                if cell is None or not _present(cell.text):
                    continue
                headers[column] = cell
                key = _key(cell.text)
                if key in name_aliases:
                    mapping["name"] = column
                elif key in code_aliases:
                    mapping["code"] = column
                elif key in model_aliases:
                    mapping["model"] = column
            nonempty_headers = [
                cell for cell in header_row if cell is not None and _present(cell.text)
            ]
            recognized_headers = sum(
                _is_spec_label(cell.text) for cell in nonempty_headers
            )
            if (
                "name" not in mapping
                or len(nonempty_headers) < 2
                or recognized_headers / len(nonempty_headers) < 0.75
            ):
                continue
            for row_index in range(header_index + 1, len(table.rows)):
                data_row = table.rows[row_index]
                name_column = mapping["name"]
                if name_column >= len(data_row):
                    continue
                name_cell = data_row[name_column]
                if name_cell is None or not _present(name_cell.text):
                    continue
                raw_columns: dict[str, str] = {}
                refs_by_name: dict[str, SourceReference] = {}
                for column, header in headers.items():
                    if column >= len(data_row):
                        continue
                    value_cell = data_row[column]
                    if value_cell is None or not _present(value_cell.text):
                        continue
                    raw_columns[_text(header.text)] = _display(value_cell.text)
                    refs_by_name[_text(header.text)] = value_cell.ref
                if len(raw_columns) < 2:
                    continue
                code_cell = (
                    data_row[mapping["code"]]
                    if "code" in mapping and mapping["code"] < len(data_row)
                    else None
                )
                model_cell = (
                    data_row[mapping["model"]]
                    if "model" in mapping and mapping["model"] < len(data_row)
                    else None
                )
                rows.append(
                    {
                        "table_id": table.table_id,
                        "row": row_index,
                        "name": name_cell.text,
                        "name_ref": name_cell.ref,
                        "code": code_cell.text if code_cell is not None else None,
                        "code_ref": code_cell.ref if code_cell is not None else None,
                        "model": model_cell.text if model_cell is not None else None,
                        "model_ref": (
                            model_cell.ref if model_cell is not None else None
                        ),
                        "raw_columns": raw_columns,
                        "column_refs": refs_by_name,
                        "confidence": min(
                            cell.confidence
                            for cell in data_row
                            if cell is not None and _present(cell.text)
                        ),
                    }
                )
            break
    return rows


def _public_item(item: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in item.items() if not str(key).startswith("_")}


_LINE_NAME_KEYS = {
    _key(value)
    for value in (
        "name_raw",
        "name_normalized",
        "full_product_name",
        "产品名称",
        "物料名称",
        "名称",
        "品名",
        "name",
    )
}
_LINE_IDENTIFIER_KEYS = {
    _key(value)
    for value in (
        "model",
        "型号",
        "产品型号",
        "规格型号",
        "product_code",
        "产品编号",
        "产品料号",
        "物料编码",
        "物料编号",
        "料号",
        "图号",
        "part no",
        "code",
    )
}
_LINE_STANDARD_KEYS = {
    *(_key(value) for value in OrderLine.model_fields),
    *(
        _key(value)
        for value in (
            "序号",
            "行号",
            "数量",
            "单位",
            "单价",
            "金额",
            "含税单价",
            "含税金额",
            "未税单价",
            "未税金额",
            "箱数",
            "件数",
            "包装要求",
            "产地",
            "备注",
        )
    ),
}


def _spec_value_key(value: Any) -> str:
    normalized = _text(value).casefold().replace("×", "*")
    normalized = re.sub(r"(?<=\d)[xX](?=\d)", "*", normalized)
    return re.sub(r"\s+", "", normalized)


def _line_specifications(line: OrderLine) -> dict[str, tuple[str, str]]:
    result: dict[str, tuple[str, str]] = {}

    def add(name: Any, value: Any) -> None:
        display_name = _text(name)
        display_value = _display(value)
        key = _key(display_name)
        if (
            not key
            or not _present(display_value)
            or key in _LINE_NAME_KEYS
            or key in _LINE_IDENTIFIER_KEYS
            or key in _LINE_STANDARD_KEYS
            or display_name.casefold().startswith("field_")
            or isinstance(value, (Mapping, list, tuple, set))
        ):
            return
        current = result.get(key)
        if current is None or len(display_value) > len(current[1]):
            result[key] = (display_name, display_value)

    for raw_name, raw_value in dict(line.raw_columns or {}).items():
        add(raw_name, raw_value)

    custom_fields = dict(line.custom_fields or {})
    nested = custom_fields.get("specifications")
    if isinstance(nested, Mapping):
        for raw_name, raw_value in nested.items():
            add(raw_name, raw_value)
    for raw_name, raw_value in custom_fields.items():
        if _key(raw_name) != _key("specifications"):
            add(raw_name, raw_value)

    for raw_name, raw_value in (line.model_extra or {}).items():
        add(raw_name, raw_value)

    for fragment in re.split(r"[;；\n]+", _display(line.specification_raw)):
        match = re.match(r"^\s*([^=：:]{1,80})\s*[=：:]\s*(.+?)\s*$", fragment)
        if match:
            add(match.group(1), match.group(2))
    return result


def _source_identity(ref: SourceReference) -> str:
    extra = ref.model_extra or {}
    evidence_id = str(extra.get("evidence_id") or "").strip()
    if evidence_id:
        return evidence_id.removeprefix("mineru/").casefold()

    part = str(ref.part or "").strip()
    normalized_part = part.removeprefix("mineru/")
    if re.fullmatch(r".+:r\d+:c\d+", normalized_part, re.IGNORECASE):
        return normalized_part.casefold()
    if re.fullmatch(r"docx:(?:t:\d+:r\d+:c\d+|p:\d+)", normalized_part):
        return normalized_part.casefold()
    native_cell = re.search(
        r"word/document\.xml#table:(\d+)/row:(\d+)/cell:(\d+)",
        normalized_part,
        re.IGNORECASE,
    )
    if native_cell:
        return (
            f"docx:t:{native_cell.group(1)}:r{native_cell.group(2)}:"
            f"c{native_cell.group(3)}"
        ).casefold()
    legacy_cell = re.fullmatch(r"table:(\d+)/R(\d+)C(\d+)", str(ref.cell or ""))
    if legacy_cell:
        return (
            f"docx:t:{legacy_cell.group(1)}:r{int(legacy_cell.group(2)) - 1}:"
            f"c{int(legacy_cell.group(3)) - 1}"
        ).casefold()
    return "|".join(
        (
            str(ref.page or ""),
            normalized_part.casefold(),
            str(ref.cell or "").casefold(),
            str(ref.range or "").casefold(),
        )
    )


def _line_source_identities(
    field_meta: Mapping[str, FieldMetadata], line_index: int
) -> set[str]:
    prefix = f"$.lines[{line_index}]"
    return {
        _source_identity(ref)
        for path, metadata in field_meta.items()
        if path.startswith(prefix)
        for ref in metadata.source_refs
        if _source_identity(ref)
    }


def _line_source_anchors(source_ids: set[str]) -> set[str]:
    row_anchors = {
        match.group(1)
        for source_id in source_ids
        if (
            match := re.match(
                r"^(.+?:t(?::)?[^:]*:r\d+):c\d+$",
                source_id,
                re.IGNORECASE,
            )
        )
    }
    return row_anchors or source_ids


def _compatible_line_facts(left: OrderLine, right: OrderLine) -> bool:
    left_name = _key(left.name_raw or left.name_normalized or left.full_product_name)
    right_name = _key(
        right.name_raw or right.name_normalized or right.full_product_name
    )
    if not left_name or left_name != right_name:
        return False
    left_identifiers = {
        _key(value)
        for value in (left.model, left.product_code)
        if _present(value) and not _is_interface_only_identifier(value)
    }
    right_identifiers = {
        _key(value)
        for value in (right.model, right.product_code)
        if _present(value) and not _is_interface_only_identifier(value)
    }
    if (
        left_identifiers
        and right_identifiers
        and not (left_identifiers & right_identifiers)
    ):
        return False
    for field in (
        "quantity",
        "unit",
        "color",
        "body_printing",
        "product_category",
    ):
        left_value = getattr(left, field)
        right_value = getattr(right, field)
        if (
            _present(left_value)
            and _present(right_value)
            and _spec_value_key(left_value) != _spec_value_key(right_value)
        ):
            return False
    left_specs = _line_specifications(left)
    right_specs = _line_specifications(right)
    return all(
        _spec_value_key(left_specs[key][1]) == _spec_value_key(right_specs[key][1])
        for key in left_specs.keys() & right_specs.keys()
    )


def _missing_value(value: Any) -> bool:
    return value is None or value == "" or value == [] or value == {}


def _merge_payload_values(left: Any, right: Any) -> Any:
    if _missing_value(left):
        return right
    if _missing_value(right):
        return left
    if isinstance(left, Mapping) and isinstance(right, Mapping):
        merged = dict(left)
        for key, value in right.items():
            merged[key] = _merge_payload_values(merged.get(key), value)
        return merged
    if isinstance(left, list) and isinstance(right, list):
        return [*left, *(value for value in right if value not in left)]
    return left


def _merge_technical_line(left: OrderLine, right: OrderLine) -> OrderLine:
    payload = left.model_dump(mode="python")
    incoming = right.model_dump(mode="python")
    for key, value in incoming.items():
        if key in {"line_id", "line_no"}:
            continue
        payload[key] = _merge_payload_values(payload.get(key), value)

    specs = _line_specifications(OrderLine.model_validate(payload))
    if specs:
        custom_fields = dict(payload.get("custom_fields") or {})
        custom_fields["specifications"] = {
            name: value for name, value in specs.values()
        }
        payload["custom_fields"] = custom_fields
        payload["specification_raw"] = "; ".join(
            f"{name}={value}" for name, value in specs.values()
        )[:2_000]
    if not _present(payload.get("name_normalized")) and _present(
        payload.get("name_raw")
    ):
        payload["name_normalized"] = _text(payload["name_raw"])
    for field in ("model", "product_code"):
        if _is_interface_only_identifier(payload.get(field)):
            payload[field] = None
    return OrderLine.model_validate(payload)


def _merge_field_metadata(left: FieldMetadata, right: FieldMetadata) -> FieldMetadata:
    payload = _merge_payload_values(
        left.model_dump(mode="python"), right.model_dump(mode="python")
    )
    payload["source_refs"] = _unique_refs([*left.source_refs, *right.source_refs])
    payload["confidence"] = max(left.confidence, right.confidence)
    payload["inherited_from_merge"] = (
        left.inherited_from_merge or right.inherited_from_merge
    )
    payload["inferred"] = left.inferred and right.inferred
    return FieldMetadata.model_validate(payload)


def _reindex_line_metadata(
    field_meta: Mapping[str, FieldMetadata],
    index_map: Mapping[int, int],
    lines: list[OrderLine],
) -> dict[str, FieldMetadata]:
    result: dict[str, FieldMetadata] = {}
    line_path = re.compile(r"^\$\.lines\[(\d+)\](.*)$")
    for path, metadata in field_meta.items():
        match = line_path.match(path)
        if match is None:
            result[path] = metadata
            continue
        old_index = int(match.group(1))
        new_index = index_map.get(old_index)
        if new_index is None:
            continue
        suffix = match.group(2)
        if suffix in {".line_no", ".model", ".product_code"} and not _present(
            getattr(lines[new_index], suffix[1:])
        ):
            continue
        new_path = f"$.lines[{new_index}]{suffix}"
        current = result.get(new_path)
        result[new_path] = (
            metadata if current is None else _merge_field_metadata(current, metadata)
        )
    return result


_LINE_FIELD_PATH_RE = re.compile(r"^\$\.lines\[(\d+)\](.*)$")


def _line_table_ids(
    field_meta: Mapping[str, FieldMetadata], line_index: int
) -> set[str]:
    table_ids: set[str] = set()
    for source_id in _line_source_identities(field_meta, line_index):
        match = re.match(r"^(.+):r\d+:c\d+$", source_id, re.IGNORECASE)
        if match is not None:
            table_ids.add(match.group(1).casefold())
    return table_ids


def _remove_lines_from_tables(
    lines: list[OrderLine],
    field_meta: Mapping[str, FieldMetadata],
    issues: list[ValidationIssue],
    table_ids: set[str],
) -> tuple[
    list[OrderLine],
    dict[str, FieldMetadata],
    list[ValidationIssue],
    int,
    list[str],
]:
    normalized_tables = {table_id.casefold() for table_id in table_ids}
    removed = {
        index
        for index in range(len(lines))
        if _line_table_ids(field_meta, index) & normalized_tables
    }
    if not removed:
        return lines, dict(field_meta), issues, 0, []

    index_map: dict[int, int] = {}
    retained_lines: list[OrderLine] = []
    for old_index, line in enumerate(lines):
        if old_index in removed:
            continue
        index_map[old_index] = len(retained_lines)
        retained_lines.append(line)
    remapped_meta = _reindex_line_metadata(field_meta, index_map, retained_lines)

    def remap_path(path: str) -> str | None:
        match = _LINE_FIELD_PATH_RE.match(path)
        if match is None:
            return path
        new_index = index_map.get(int(match.group(1)))
        if new_index is None:
            return None
        return f"$.lines[{new_index}]{match.group(2)}"

    retained_issues: list[ValidationIssue] = []
    dropped_issue_codes: list[str] = []
    for issue in issues:
        remapped_paths = [
            remapped
            for path in issue.paths
            if (remapped := remap_path(str(path))) is not None
        ]
        if issue.paths and not remapped_paths:
            dropped_issue_codes.append(issue.code)
            continue
        payload = issue.model_dump(mode="python")
        payload["paths"] = list(dict.fromkeys(remapped_paths))
        retained_issues.append(ValidationIssue.model_validate(payload))
    return (
        retained_lines,
        remapped_meta,
        retained_issues,
        len(removed),
        list(dict.fromkeys(dropped_issue_codes)),
    )


def _merge_compatible_technical_lines(
    lines: list[OrderLine], field_meta: Mapping[str, FieldMetadata]
) -> tuple[list[OrderLine], dict[str, FieldMetadata]]:
    merged: list[OrderLine] = []
    merged_sources: list[set[str]] = []
    index_map: dict[int, int] = {}
    for old_index, source_line in enumerate(lines):
        line = _merge_technical_line(source_line, source_line)
        source_ids = _line_source_identities(field_meta, old_index)
        target_index: int | None = None
        for candidate_index, candidate in enumerate(merged):
            if _line_source_anchors(source_ids) & _line_source_anchors(
                merged_sources[candidate_index]
            ) and _compatible_line_facts(candidate, line):
                target_index = candidate_index
                break
        if target_index is None:
            index_map[old_index] = len(merged)
            merged.append(line)
            merged_sources.append(set(source_ids))
            continue
        index_map[old_index] = target_index
        merged[target_index] = _merge_technical_line(merged[target_index], line)
        merged_sources[target_index].update(source_ids)
    return merged, _reindex_line_metadata(field_meta, index_map, merged)


def _meta(
    field_meta: dict[str, FieldMetadata],
    path: str,
    refs: Iterable[SourceReference | None],
    confidence: float,
    *,
    replace: bool = False,
) -> None:
    source_refs = _unique_refs(refs)
    if not source_refs:
        return
    if path in field_meta and not replace:
        return
    field_meta[path] = FieldMetadata(
        source_refs=source_refs,
        confidence=max(0.0, min(float(confidence), 1.0)),
    )


def _line_specification_path(line_index: int, name: Any) -> str:
    specification_key = json.dumps("specifications", ensure_ascii=False)
    value_key = json.dumps(str(name), ensure_ascii=False)
    return f"$.lines[{line_index}].custom_fields[{specification_key}][{value_key}]"


def _line_raw_column_path(line_index: int, name: Any) -> str:
    value_key = json.dumps(str(name), ensure_ascii=False)
    return f"$.lines[{line_index}].raw_columns[{value_key}]"


def _mark_inferred(field_meta: dict[str, FieldMetadata], path: str) -> None:
    current = field_meta.get(path)
    if current is None or current.inferred:
        return
    payload = current.model_dump(mode="python")
    payload["inferred"] = True
    field_meta[path] = FieldMetadata.model_validate(payload)


def _derived_meta(
    field_meta: dict[str, FieldMetadata],
    path: str,
    refs: Iterable[SourceReference | None],
    confidence: float,
) -> None:
    if path in field_meta:
        return
    _meta(field_meta, path, refs, confidence)
    _mark_inferred(field_meta, path)


def _projected_values_match(left: Any, right: Any) -> bool:
    return _present(left) and _spec_value_key(left) == _spec_value_key(right)


def _bind_projected_product_row_metadata(
    field_meta: dict[str, FieldMetadata],
    *,
    line_index: int,
    line: OrderLine,
    item: Mapping[str, Any],
    specifications: Mapping[str, Any],
    confidence: float,
) -> None:
    expected_line_no = int(item["row"]) + 1
    if _projected_values_match(line.line_no, expected_line_no):
        _derived_meta(
            field_meta,
            f"$.lines[{line_index}].line_no",
            [item.get("name_ref") or item.get("code_ref")],
            confidence,
        )

    name_refs = [item.get("name_ref")]
    if _projected_values_match(line.name_raw, item.get("name")):
        _meta(field_meta, f"$.lines[{line_index}].name_raw", name_refs, confidence)
    if _present(line.name_normalized):
        _meta(
            field_meta,
            f"$.lines[{line_index}].name_normalized",
            name_refs,
            confidence,
        )
    for field, source_value, refs in (
        (
            "model",
            item.get("model") or item.get("code"),
            [item.get("model_ref") or item.get("code_ref")],
        ),
        ("product_code", item.get("code"), [item.get("code_ref")]),
    ):
        if _projected_values_match(getattr(line, field), source_value):
            _meta(
                field_meta,
                f"$.lines[{line_index}].{field}",
                refs,
                confidence,
            )

    specification_raw = "; ".join(
        f"{name}={value}" for name, value in specifications.items()
    )
    if _projected_values_match(line.specification_raw, specification_raw):
        _meta(
            field_meta,
            f"$.lines[{line_index}].specification_raw",
            (item.get("column_refs") or {}).values(),
            confidence,
        )

    line_specifications = _line_specifications(line)
    column_refs = item.get("column_refs") or {}
    for source_name, source_value in specifications.items():
        projected = line_specifications.get(_key(source_name))
        if projected is None or not _projected_values_match(
            projected[1], source_value
        ):
            continue
        _meta(
            field_meta,
            _line_specification_path(line_index, projected[0]),
            [column_refs.get(source_name)],
            confidence,
        )

    for actual_name, actual_value in dict(line.raw_columns or {}).items():
        source_name = next(
            (
                name
                for name, source_value in (item.get("raw_columns") or {}).items()
                if _key(name) == _key(actual_name)
                and _projected_values_match(actual_value, source_value)
            ),
            None,
        )
        if source_name is None:
            continue
        _meta(
            field_meta,
            _line_raw_column_path(line_index, actual_name),
            [column_refs.get(source_name)],
            confidence,
        )


def _mark_shape_inferred(
    field_meta: dict[str, FieldMetadata], path: str
) -> None:
    current = field_meta.get(path)
    if current is None:
        return
    payload = current.model_dump(mode="python")
    payload.update(
        {
            "inferred": True,
            "review_required": False,
            "mapping_source": "headerless_material_shape",
        }
    )
    field_meta[path] = FieldMetadata.model_validate(payload)


def project_technical_document(
    record: DocumentRecord,
    *,
    filename: str | None = None,
) -> DocumentRecord:
    """Return ``record`` enriched only from its retained source evidence."""

    if record.document_type != "technical_document":
        return record
    if record.document_subtype in {
        "bill_of_materials",
        "service_policy",
        "product_photo",
    }:
        return record
    extraction = dict(record.extraction or {})
    raw = extraction.get("raw_content")
    metadata = extraction.get("metadata")
    if not isinstance(raw, Mapping):
        return record
    if not isinstance(metadata, Mapping):
        metadata = {}
    effective_filename = filename or record.source.original_filename
    native_docx = _is_native_docx(metadata, raw, effective_filename)
    if native_docx:
        entries, tables = _docx_evidence(raw)
    elif "pages" in raw:
        entries, tables = _pdf_evidence(raw, metadata)
    else:
        entries, tables = _docx_evidence(raw)
    headerless_rows = _headerless_material_rows(tables)
    original_subtype = record.document_subtype
    effective_subtype = original_subtype
    native_subtype = _trusted_native_docx_subtype(raw) if native_docx else None
    if (
        native_docx
        and not _subtype_hint_was_applied(metadata)
        and native_subtype is not None
    ):
        effective_subtype = native_subtype
    elif (
        native_docx
        and original_subtype in {"unknown", "product_specification"}
        and not _subtype_hint_was_applied(metadata)
        and _has_engineering_drawing_evidence(entries, tables)
    ):
        effective_subtype = "engineering_drawing"
    effective_kind_label = record.document_kind_label
    if effective_subtype != original_subtype and effective_kind_label in {
        None,
        "",
        "unknown",
        original_subtype,
    }:
        effective_kind_label = effective_subtype
    filename_entry = _Evidence(
        text=effective_filename,
        ref=_source_ref(part="source.original_filename"),
        confidence=0.7,
        kind="filename",
        order=-1,
    )
    candidates = _merge_candidates(
        _table_label_candidates(tables),
        _inline_label_candidates(entries),
        _spatial_label_candidates(entries),
    )
    candidates.setdefault("title", []).extend(_heading_candidates(entries))
    candidates["title"].extend(
        _headerless_material_title_candidates(tables, headerless_rows)
    )
    filename_title = _filename_title(effective_filename)
    if filename_title is not None:
        candidates["title"].append(filename_title)
    candidates.setdefault("company", []).extend(_company_candidates(entries))
    candidates.setdefault("drawing_number", []).extend(_title_code_candidates(entries))
    filename_codes = _filename_code_candidates(effective_filename, entries)
    if effective_subtype == "product_specification":
        candidates.setdefault("product_numbers", []).extend(filename_codes)
    else:
        candidates["drawing_number"].extend(filename_codes)

    existing_header = record.header
    existing_values = {
        "title": existing_header.title,
        "company": existing_header.issuer,
        "drawing_number": getattr(existing_header, "drawing_number", None),
        "product_numbers": "\n".join(
            getattr(existing_header, "product_numbers", None) or []
        ),
        "material_number": getattr(existing_header, "material_number", None),
        "unit": getattr(existing_header, "unit", None),
        "scale": getattr(existing_header, "scale", None),
        "version": getattr(existing_header, "version", None),
        "drawn_by": getattr(existing_header, "drawn_by", None),
        "checked_by": getattr(existing_header, "checked_by", None),
        "approved_by": getattr(existing_header, "approved_by", None),
        "color": getattr(existing_header, "color", None),
        "manufacture": getattr(existing_header, "manufacture", None),
        "date": existing_header.date_raw,
    }
    existing_paths = {
        "title": "$.header.title",
        "company": "$.header.issuer",
        "drawing_number": "$.header.drawing_number",
        "product_numbers": "$.header.product_numbers",
        "material_number": "$.header.material_number",
        "unit": "$.header.unit",
        "scale": "$.header.scale",
        "version": "$.header.version",
        "drawn_by": "$.header.drawn_by",
        "checked_by": "$.header.checked_by",
        "approved_by": "$.header.approved_by",
        "color": "$.header.color",
        "manufacture": "$.header.manufacture",
        "date": "$.header.date_raw",
    }
    selected: dict[str, _Candidate | None] = {}
    for field, values in candidates.items():
        current = _existing_candidate(
            record,
            existing_paths.get(field, f"$.header.{field}"),
            existing_values.get(field),
            field=field,
        )
        if field == "title" and not _candidate_has_document_evidence(current):
            current = None
        selected[field] = _best([*(values or []), *([current] if current else [])])
        if field == "title" and not _candidate_has_document_evidence(selected[field]):
            selected[field] = None
    material_candidate = selected.get("material_number")
    if material_candidate is not None:
        cleaned_material = re.sub(
            r"[×*][A-Za-z]?-?\d+(?:\.\d+)?$", "", material_candidate.value
        ).strip()
        if cleaned_material:
            selected["material_number"] = _Candidate(
                value=cleaned_material,
                refs=material_candidate.refs,
                confidence=material_candidate.confidence,
                score=material_candidate.score,
            )

    header_payload = existing_header.model_dump(mode="python")
    mapping = {
        "title": "title",
        "company": "issuer",
        "drawing_number": "drawing_number",
        "material_number": "material_number",
        "unit": "unit",
        "scale": "scale",
        "version": "version",
        "drawn_by": "drawn_by",
        "checked_by": "checked_by",
        "approved_by": "approved_by",
        "color": "color",
        "manufacture": "manufacture",
    }
    field_meta = dict(record.field_meta)
    if effective_subtype != original_subtype:
        subtype_refs = [
            entry.ref
            for entry in entries
            if entry.kind != "filename"
            and re.search(
                r"(?:工程图(?:纸|样)?|图纸|装配图|尺寸图|\bengineering drawing\b|"
                r"\bdrawing\b)",
                _text(entry.text),
                re.IGNORECASE,
            )
        ]
        subtype_confidence = min(
            (entry.confidence for entry in entries if entry.ref in subtype_refs),
            default=0.95,
        )
        _meta(
            field_meta,
            "$.document_subtype",
            subtype_refs,
            subtype_confidence,
            replace=True,
        )
        if effective_kind_label == effective_subtype:
            _meta(
                field_meta,
                "$.document_kind_label",
                subtype_refs,
                subtype_confidence,
                replace=True,
            )
    for field, header_key in mapping.items():
        candidate = selected.get(field)
        if candidate is None:
            if _present(existing_values.get(field)) and not _valid_scalar(
                field,
                existing_values[field],
            ):
                header_payload[header_key] = None
            elif field in {"drawn_by", "checked_by", "approved_by"}:
                existing_meta = record.field_meta.get(existing_paths[field])
                if existing_meta is None or not existing_meta.source_refs:
                    header_payload[header_key] = None
            continue
        header_payload[header_key] = candidate.value
        _meta(
            field_meta,
            f"$.header.{header_key}",
            candidate.refs,
            candidate.confidence,
            replace=True,
        )
    product_candidate = selected.get("product_numbers")
    product_numbers = (
        _identifier_values(product_candidate.value)
        if product_candidate is not None
        else []
    )
    if product_numbers and product_candidate is not None:
        header_payload["product_numbers"] = product_numbers
        header_payload["product_number"] = product_numbers[0]
        for index, _ in enumerate(product_numbers):
            _meta(
                field_meta,
                f"$.header.product_numbers[{index}]",
                product_candidate.refs,
                product_candidate.confidence,
                replace=True,
            )
        _meta(
            field_meta,
            "$.header.product_number",
            product_candidate.refs,
            product_candidate.confidence,
            replace=True,
        )
    date_candidate = selected.get("date")
    if date_candidate is None:
        filename_date = _DATE_RE.search(Path(effective_filename).stem)
        if filename_date:
            date_candidate = _Candidate(
                value=filename_date.group(0),
                refs=[filename_entry.ref],
                confidence=0.7,
                score=25.0,
            )
    if date_candidate is not None:
        parsed_date = _date_value(date_candidate.value)
        header_payload["date_raw"] = date_candidate.value
        header_payload["date_standard"] = parsed_date
        _meta(
            field_meta,
            "$.header.date_raw",
            date_candidate.refs,
            date_candidate.confidence,
            replace=True,
        )
        if parsed_date is not None:
            _meta(
                field_meta,
                "$.header.date_standard",
                date_candidate.refs,
                date_candidate.confidence,
                replace=True,
            )
    header = DocumentHeader.model_validate(header_payload)

    specifications = _table_specifications(tables)
    specifications.extend(
        _inline_specifications(entries, document_subtype=effective_subtype)
    )
    spec_deduped: dict[tuple[str, str], dict[str, Any]] = {}
    for spec in specifications:
        key = (_key(spec["name"]), _key(spec["value"]))
        current = spec_deduped.get(key)
        if current is None or spec["_confidence"] > current["_confidence"]:
            spec_deduped[key] = spec
    specifications = list(spec_deduped.values())
    dimensions = _dimensions(specifications, entries)
    process_steps = _process_steps(entries, document_subtype=effective_subtype)

    for index, spec in enumerate(specifications):
        confidence = float(spec.get("_confidence") or 0.75)
        _meta(
            field_meta,
            f"$.specifications[{index}].name",
            spec.get("_name_refs") or [],
            confidence,
        )
        _meta(
            field_meta,
            f"$.specifications[{index}].value",
            spec.get("_value_refs") or [],
            confidence,
        )
    for index, dimension in enumerate(dimensions):
        confidence = float(dimension.get("_confidence") or 0.75)
        _meta(
            field_meta,
            f"$.key_dimensions[{index}].name",
            dimension.get("_name_refs") or [],
            confidence,
        )
        _meta(
            field_meta,
            f"$.key_dimensions[{index}].value",
            dimension.get("_value_refs") or [],
            confidence,
        )
        if dimension.get("unit"):
            _meta(
                field_meta,
                f"$.key_dimensions[{index}].unit",
                dimension.get("_value_refs") or [],
                confidence,
            )
    link_verified_drawing_region_dimensions(dimensions, extraction, field_meta)
    for index, step in enumerate(process_steps):
        confidence = float(step.get("_confidence") or 0.75)
        for field, refs in (step.get("_field_refs") or {}).items():
            _meta(field_meta, f"$.process_steps[{index}].{field}", refs, confidence)

    lines = list(record.lines)
    issues = list(record.validation_issues)
    headerless_table_ids = {
        str(item["table_id"]) for item in headerless_rows
    }
    (
        lines,
        field_meta,
        issues,
        replaced_model_line_count,
        replaced_issue_codes,
    ) = _remove_lines_from_tables(
        lines,
        field_meta,
        issues,
        headerless_table_ids,
    )
    for item in headerless_rows:
        line_index = len(lines)
        raw_columns = dict(item["raw_columns"])
        lines.append(
            OrderLine(
                line_id=(
                    f"technical:{item['table_id']}:material:{item['line_no']}"
                ),
                line_no=item["line_no"],
                product_code=item["code"],
                name_raw=item["name"],
                name_normalized=_text(item["name"]),
                quantity=item["quantity"],
                unit=item["unit"],
                raw_columns=raw_columns,
            )
        )
        confidence = float(item.get("confidence") or 0.75)
        field_sources = {
            "line_no": [item["line_ref"]],
            "product_code": [item["code_ref"]],
            "name_raw": item["name_refs"],
            "name_normalized": item["name_refs"],
            "quantity": [item["quantity_ref"]],
            "unit": [item["quantity_ref"]],
        }
        for field, refs in field_sources.items():
            path = f"$.lines[{line_index}].{field}"
            _meta(field_meta, path, refs, confidence, replace=True)
            _mark_shape_inferred(field_meta, path)
        for column_name, refs in item["column_refs"].items():
            path = f'$.lines[{line_index}].raw_columns["{column_name}"]'
            _meta(field_meta, path, refs, confidence, replace=True)
            _mark_shape_inferred(field_meta, path)

    known_line_keys: dict[tuple[str, str, str, str], list[int]] = {}
    for index, line in enumerate(lines):
        known_line_keys.setdefault(
            (
                _key(line.model),
                _key(line.product_code),
                _key(line.name_raw),
                _key(line.specification_raw),
            ),
            [],
        ).append(index)
    projected_rows = _table_product_rows(tables)
    for item in projected_rows:
        raw_columns = dict(item["raw_columns"])
        specs_for_line = {
            name: value
            for name, value in raw_columns.items()
            if _key(name)
            not in {_key("产品名称"), _key("物料名称"), _key("名称"), _key("品名")}
        }
        specification_raw = "; ".join(
            f"{key}={value}" for key, value in specs_for_line.items()
        )
        code = _display(item.get("code")) or None
        if _is_interface_only_identifier(code):
            code = None
        model = _display(item.get("model")) or code
        if _is_interface_only_identifier(model):
            model = None
        key = (
            _key(model),
            _key(code),
            _key(item["name"]),
            _key(specification_raw),
        )
        confidence = float(item.get("confidence") or 0.75)
        existing_indexes = known_line_keys.get(key) or []
        if existing_indexes:
            existing_index = existing_indexes[0]
            _bind_projected_product_row_metadata(
                field_meta,
                line_index=existing_index,
                line=lines[existing_index],
                item=item,
                specifications=specs_for_line,
                confidence=confidence,
            )
            continue
        line_index = len(lines)
        line = OrderLine(
            line_id=f"technical:{item['table_id']}:{int(item['row']) + 1}",
            line_no=int(item["row"]) + 1,
            model=model,
            product_code=code,
            name_raw=_display(item["name"]),
            name_normalized=_text(item["name"]),
            specification_raw=specification_raw or None,
            custom_fields={"specifications": specs_for_line},
            raw_columns=raw_columns,
        )
        lines.append(line)
        known_line_keys.setdefault(key, []).append(line_index)
        _bind_projected_product_row_metadata(
            field_meta,
            line_index=line_index,
            line=line,
            item=item,
            specifications=specs_for_line,
            confidence=confidence,
        )

    if (
        effective_subtype in {"product_specification", "engineering_drawing"}
        and not lines
    ):
        title_candidate = selected.get("title")
        code_candidate = selected.get("material_number") or selected.get(
            "drawing_number"
        )
        if not _candidate_has_document_evidence(code_candidate):
            code_candidate = None
        if (
            product_numbers
            and product_candidate is not None
            and _candidate_has_document_evidence(product_candidate)
        ):
            code_candidate = _Candidate(
                value=product_numbers[0],
                refs=product_candidate.refs,
                confidence=product_candidate.confidence,
                score=product_candidate.score,
            )
        if code_candidate is not None or specifications:
            line_specification_sources = {
                _text(spec["name"]): (
                    _display(spec["value"]),
                    spec.get("_value_refs") or [],
                    float(spec.get("_confidence") or 0.75),
                )
                for spec in specifications
            }
            summary = "; ".join(
                f"{spec['name']}={_text(spec['value'])}" for spec in specifications[:20]
            )[:2_000]
            line = OrderLine(
                line_id="technical:product:1",
                line_no=1,
                model=code_candidate.value if code_candidate else None,
                product_code=code_candidate.value if code_candidate else None,
                name_raw=title_candidate.value if title_candidate else None,
                name_normalized=_text(title_candidate.value)
                if title_candidate
                else None,
                specification_raw=summary or None,
                custom_fields={
                    "specifications": {
                        name: value
                        for name, (value, _refs, _confidence) in (
                            line_specification_sources.items()
                        )
                    }
                },
            )
            lines.append(line)
            line_anchor_refs = (
                code_candidate.refs
                if code_candidate is not None
                else title_candidate.refs
                if title_candidate is not None
                else [
                    ref
                    for _value, refs, _confidence in (
                        line_specification_sources.values()
                    )
                    for ref in refs
                ]
            )
            _derived_meta(
                field_meta,
                "$.lines[0].line_no",
                line_anchor_refs,
                code_candidate.confidence
                if code_candidate is not None
                else title_candidate.confidence
                if title_candidate is not None
                else min(
                    (
                        confidence
                        for _value, _refs, confidence in (
                            line_specification_sources.values()
                        )
                    ),
                    default=0.75,
                ),
            )
            if title_candidate:
                _meta(
                    field_meta,
                    "$.lines[0].name_raw",
                    title_candidate.refs,
                    title_candidate.confidence,
                )
                _meta(
                    field_meta,
                    "$.lines[0].name_normalized",
                    title_candidate.refs,
                    title_candidate.confidence,
                )
            if code_candidate:
                _meta(
                    field_meta,
                    "$.lines[0].model",
                    code_candidate.refs,
                    code_candidate.confidence,
                )
                _meta(
                    field_meta,
                    "$.lines[0].product_code",
                    code_candidate.refs,
                    code_candidate.confidence,
                )
            if summary:
                _meta(
                    field_meta,
                    "$.lines[0].specification_raw",
                    [
                        ref
                        for spec in specifications
                        for ref in spec.get("_value_refs") or []
                    ],
                    min(
                        (
                            float(spec.get("_confidence") or 0.75)
                            for spec in specifications
                        ),
                        default=0.75,
                    ),
                )
            for specification_name, (
                _value,
                specification_refs,
                specification_confidence,
            ) in line_specification_sources.items():
                _meta(
                    field_meta,
                    _line_specification_path(0, specification_name),
                    specification_refs,
                    specification_confidence,
                )

    lines, field_meta = _merge_compatible_technical_lines(lines, field_meta)
    if (
        len(lines) == 1
        and not _present(lines[0].model)
        and product_numbers
        and product_candidate is not None
        and _candidate_has_document_evidence(product_candidate)
        and not _is_interface_only_identifier(product_numbers[0])
    ):
        line_payload = lines[0].model_dump(mode="python")
        line_payload["model"] = product_numbers[0]
        lines[0] = OrderLine.model_validate(line_payload)
        _meta(
            field_meta,
            "$.lines[0].model",
            product_candidate.refs,
            product_candidate.confidence,
            replace=True,
        )

    if lines and headerless_rows:
        header_payload = header.model_dump(mode="python")
        header_payload["bom_line_count"] = len(lines)
        header = DocumentHeader.model_validate(header_payload)
        line_refs = [
            ref
            for index in range(len(lines))
            for field in ("line_no", "product_code", "name_raw")
            for meta_value in [field_meta.get(f"$.lines[{index}].{field}")]
            if meta_value is not None
            for ref in meta_value.source_refs
        ]
        _meta(
            field_meta,
            "$.header.bom_line_count",
            line_refs,
            min(
                (
                    field_meta[f"$.lines[{index}].name_raw"].confidence
                    for index in range(len(lines))
                    if f"$.lines[{index}].name_raw" in field_meta
                ),
                default=0.75,
            ),
            replace=True,
        )
        _mark_shape_inferred(field_meta, "$.header.bom_line_count")

    if native_docx and isinstance(raw.get("source_asset_inventory"), Mapping):
        link_verified_docx_image_associations(lines, extraction, field_meta)
    else:
        _link_images_to_single_line(lines, extraction, field_meta)

    title_block = dict(extraction.get("title_block") or {})
    projected_title_block = {
        "drawing_number": getattr(header, "drawing_number", None),
        "product_numbers": getattr(header, "product_numbers", None) or [],
        "drawing_name": header.title,
        "material_number": getattr(header, "material_number", None),
        "company": header.issuer,
        "unit": getattr(header, "unit", None),
        "scale": getattr(header, "scale", None),
        "version": getattr(header, "version", None),
        "design_by": getattr(header, "drawn_by", None),
        "check_by": getattr(header, "checked_by", None),
        "approve_by": getattr(header, "approved_by", None),
        "color": getattr(header, "color", None),
        "manufacture": getattr(header, "manufacture", None),
    }
    title_block.update(
        {
            key: value
            for key, value in projected_title_block.items()
            if value not in (None, "", [], {})
        }
    )
    public_specs = [_public_item(item) for item in specifications]
    public_dimensions = [_public_item(item) for item in dimensions]
    public_steps = [_public_item(item) for item in process_steps]
    extraction.update(
        {
            "title_block": title_block,
            "specifications": public_specs,
            "key_dimensions": public_dimensions,
            "process_steps": public_steps,
            "steps": public_steps,
            "bom": [line.model_dump(mode="json") for line in lines],
        }
    )
    metadata_payload = dict(metadata)
    metadata_payload["technical_projection"] = {
        "strategy": "evidence-projection",
        "specification_count": len(public_specs),
        "dimension_count": len(public_dimensions),
        "process_step_count": len(public_steps),
        "line_count": len(lines),
        "headerless_material_table_ids": sorted(headerless_table_ids),
        "headerless_material_row_count": len(headerless_rows),
        "replaced_model_line_count": replaced_model_line_count,
        "replaced_validation_issue_codes": replaced_issue_codes,
    }
    extraction["metadata"] = metadata_payload

    fields: list[dict[str, Any]] = []
    field_sources = {
        "title_block.drawing_name": (header.title, "$.header.title"),
        "title_block.company": (header.issuer, "$.header.issuer"),
        "title_block.drawing_number": (
            getattr(header, "drawing_number", None),
            "$.header.drawing_number",
        ),
        "title_block.material_number": (
            getattr(header, "material_number", None),
            "$.header.material_number",
        ),
        "title_block.unit": (getattr(header, "unit", None), "$.header.unit"),
        "title_block.scale": (getattr(header, "scale", None), "$.header.scale"),
        "title_block.version": (getattr(header, "version", None), "$.header.version"),
    }
    for name, (value, path) in field_sources.items():
        meta_value = field_meta.get(path)
        fields.append(
            {
                "name": name,
                "value": value,
                "source_refs": [
                    _ref_payload(ref)
                    for ref in (meta_value.source_refs if meta_value else [])
                ],
            }
        )
    if product_numbers and product_candidate is not None:
        fields.append(
            {
                "name": "product_numbers",
                "value": product_numbers,
                "source_refs": [_ref_payload(ref) for ref in product_candidate.refs],
            }
        )
    for index, spec in enumerate(public_specs):
        fields.append(
            {
                "name": f"specifications.{index}.{spec['name']}",
                "value": spec["value"],
                "source_refs": spec["source_refs"],
            }
        )

    resolved_missing_codes: set[str] = set()
    if header.title:
        resolved_missing_codes.add("DRAWING_NAME_MISSING")
    if getattr(header, "drawing_number", None):
        resolved_missing_codes.add("DRAWING_NUMBER_MISSING")
    if lines:
        resolved_missing_codes.add("DRAWING_BOM_EMPTY")
    issues = [issue for issue in issues if issue.code not in resolved_missing_codes]

    payload = record.model_dump(mode="python")
    payload.update(
        {
            "document_subtype": effective_subtype,
            "document_kind_label": effective_kind_label,
            "header": header,
            "lines": lines,
            "field_meta": field_meta,
            "validation_issues": issues,
            "extraction": extraction,
            "fields": fields,
            "title_block": title_block,
            "specifications": public_specs,
            "key_dimensions": public_dimensions,
            "process_steps": public_steps,
            "steps": public_steps,
        }
    )
    return DocumentRecord.model_validate(payload)


__all__ = ["project_technical_document"]
