"""Truthful, bounded probes for M1's optional enhanced capabilities.

``readiness`` is deliberately side-effect free: it may inspect installed
packages, configured objects and offline model manifests, but it never performs
OCR/model inference or a network request.  ``preflight`` is an explicit deploy
gate and exercises the real configured implementations with synthetic data.

The report is intentionally metadata-only.  It never serializes client objects,
credentials, endpoint URLs, model output, source text, or exception messages.
"""

from __future__ import annotations

import asyncio
import hashlib
import math
import mimetypes
import re
import tempfile
import time
from collections.abc import Awaitable, Callable, Iterable, Mapping
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field
from pydantic_ai import BinaryContent

from .documents.parsing.base import PageInput

PP_STRUCTURE = "pp_structure_v3"
PADDLEOCR_VL = "paddleocr_vl_triggered_page"
DOCLING = "docling"
VLM_IMAGE = "vlm_image"
EMBEDDING_1024 = "embedding_1024"
LIGHTRAG_HEALTH = "lightrag_health"
LIGHTRAG_LIFECYCLE = "lightrag_lifecycle"
MINERU_VLM_LLM = "mineru_vlm_llm"

PREFLIGHT_CAPABILITIES = frozenset(
    {
        PP_STRUCTURE,
        PADDLEOCR_VL,
        DOCLING,
        VLM_IMAGE,
        EMBEDDING_1024,
        LIGHTRAG_HEALTH,
        MINERU_VLM_LLM,
    }
)

_PROBE_TOKEN = "M1PROBE42"
_SAFE_ERROR = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")
_SENSITIVE_KEY_PARTS = (
    "api_key",
    "authorization",
    "credential",
    "password",
    "secret",
    "token",
)


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _normalize_probe_text(value: Any) -> str:
    return "".join(character for character in str(value).upper() if character.isalnum())


def _safe_value(value: Any, *, key: str = "", depth: int = 0) -> Any:
    """Return bounded JSON-safe diagnostic metadata without leaking secrets."""

    normalized_key = key.casefold()
    if any(part in normalized_key for part in _SENSITIVE_KEY_PARTS):
        return "<redacted>"
    if depth >= 5:
        return "<bounded>"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, Path):
        return value.name
    if isinstance(value, str):
        if normalized_key in {"error", "message", "detail", "exception"}:
            return value if _SAFE_ERROR.fullmatch(value) else "<redacted>"
        return value[:256]
    if isinstance(value, Mapping):
        return {
            str(child_key)[:128]: _safe_value(
                child_value,
                key=str(child_key),
                depth=depth + 1,
            )
            for child_key, child_value in list(value.items())[:100]
        }
    if isinstance(value, (list, tuple, set, frozenset)):
        return [
            _safe_value(item, key=key, depth=depth + 1) for item in list(value)[:100]
        ]
    return value.__class__.__name__


class CapabilityProbeResult(BaseModel):
    """One capability's safe readiness or real-preflight result."""

    model_config = ConfigDict(extra="forbid")

    capability: str
    required: bool
    configured: bool
    status: Literal["passed", "failed", "skipped"]
    exercised: bool
    duration_ms: float = 0.0
    details: dict[str, Any] = Field(default_factory=dict)
    error_type: str | None = None


class EnhancedProbeReport(BaseModel):
    """Metadata-only report suitable for a deployment gate."""

    model_config = ConfigDict(extra="forbid")

    mode: Literal["ready", "preflight"]
    ready: bool
    started_at: datetime
    finished_at: datetime
    duration_ms: float
    inference_executed: bool
    network_executed: bool
    lifecycle_side_effects_requested: bool
    last_preflight_finished_at: datetime | None = None
    last_preflight_ready: bool | None = None
    results: dict[str, CapabilityProbeResult]


class _ImageProbeOutput(BaseModel):
    observed_text: str


@dataclass(slots=True)
class EnhancedProbeDependencies:
    """Already-configured runtime objects used by explicit preflight.

    Objects are intentionally typed structurally.  Production passes the same
    instances used by the workflow, while tests can inject bounded fakes.
    """

    pp_structure: Any | None = None
    paddleocr_vl: Any | None = None
    docling: Any | None = None
    image_model: Any | None = None
    embedding_provider: Any | None = None
    lightrag: Any | None = None
    lightrag_lifecycle: Callable[[Any, float], Awaitable[dict[str, Any]]] | None = None
    mineru_shadow: Any | None = None


@dataclass(slots=True)
class _ProbeOutcome:
    passed: bool
    details: dict[str, Any] = field(default_factory=dict)


@contextmanager
def _probe_artifacts(
    image_path: str | Path | None,
    docling_path: str | Path | None,
    expected_image_text: str,
):
    """Create bounded synthetic artifacts only for an explicit preflight."""

    with tempfile.TemporaryDirectory(prefix="m1-enhanced-probe-") as raw_directory:
        directory = Path(raw_directory)
        resolved_image = Path(image_path) if image_path else directory / "probe.png"
        resolved_docling = (
            Path(docling_path) if docling_path else directory / "probe.html"
        )
        expected = expected_image_text.strip() or _PROBE_TOKEN
        if image_path is None:
            from PIL import Image, ImageDraw, ImageFont

            image = Image.new("RGB", (1200, 360), "white")
            draw = ImageDraw.Draw(image)
            try:
                # Pillow bundles this scalable font, so the slim runtime does
                # not depend on a distro font package such as fonts-dejavu-core.
                font = ImageFont.load_default(size=112)
            except TypeError:
                # Older Pillow only exposes a small bitmap default.  Scale its
                # rendered mask explicitly rather than silently feeding tiny
                # text to OCR and producing a false-negative deployment gate.
                font = None
            draw.rectangle((20, 20, 1180, 340), outline="black", width=6)
            if font is not None:
                draw.text((80, 110), expected, fill="black", font=font)
            else:
                bitmap_font = ImageFont.load_default()
                left, top, right, bottom = draw.textbbox(
                    (0, 0),
                    expected,
                    font=bitmap_font,
                )
                glyph = Image.new(
                    "L",
                    (max(1, right - left + 8), max(1, bottom - top + 8)),
                    "white",
                )
                ImageDraw.Draw(glyph).text(
                    (4 - left, 4 - top),
                    expected,
                    fill="black",
                    font=bitmap_font,
                )
                scale = max(
                    2,
                    min(16, 1000 // glyph.width, 180 // glyph.height),
                )
                resampling = getattr(Image, "Resampling", Image).NEAREST
                glyph = glyph.resize(
                    (glyph.width * scale, glyph.height * scale),
                    resample=resampling,
                )
                image.paste(glyph, (80, 90))
            image.save(resolved_image, format="PNG")
        if docling_path is None:
            resolved_docling.write_text(
                "<!doctype html><html><body><h1>M1 Docling Probe</h1>"
                "<p>M1DOCLING42</p></body></html>",
                encoding="utf-8",
            )
        mineru_document = directory / "mineru-purchase-order-probe.pdf"
        import fitz

        pdf = fitz.open()
        page = pdf.new_page(width=595, height=842)
        page.insert_text((72, 72), "PURCHASE ORDER", fontsize=20)
        page.insert_text(
            (72, 112),
            "Order No: M1-MINERU-PROBE-42",
            fontsize=13,
        )
        page.insert_text((72, 140), "Buyer: Yunpai Probe Company", fontsize=12)
        page.insert_text((72, 164), "Supplier: Test Cable Vendor", fontsize=12)
        page.insert_text((72, 188), "Delivery Date: 2026-07-31", fontsize=12)
        columns = (60, 100, 220, 370, 450, 510, 555)
        rows = (225, 257, 289)
        for y0, y1, values in (
            (
                rows[0],
                rows[1],
                ("Line", "Product Code", "Description", "Quantity", "Unit", "Note"),
            ),
            (
                rows[1],
                rows[2],
                ("1", "CABLE-PROBE-01", "Test cable", "12", "pcs", "probe"),
            ),
        ):
            for column, value in enumerate(values):
                rectangle = fitz.Rect(columns[column], y0, columns[column + 1], y1)
                page.draw_rect(rectangle, color=(0, 0, 0), width=1)
                page.insert_textbox(
                    rectangle + (3, 7, -3, -2),
                    value,
                    fontsize=7.5,
                    fontname="helv",
                )
        pdf.save(mineru_document)
        pdf.close()
        yield resolved_image, resolved_docling, mineru_document, expected


class EnhancedCapabilityProbe:
    """Side-effect-free readiness plus explicit real capability preflight."""

    def __init__(
        self,
        dependencies: EnhancedProbeDependencies,
        *,
        required_capabilities: Iterable[str] = (),
        image_path: str | Path | None = None,
        docling_path: str | Path | None = None,
        expected_image_text: str = "",
        timeout_seconds: float = 180.0,
        lightrag_lifecycle_timeout_seconds: float = 120.0,
    ) -> None:
        self.dependencies = dependencies
        self.required_capabilities = frozenset(required_capabilities)
        unknown = self.required_capabilities - (
            PREFLIGHT_CAPABILITIES | {LIGHTRAG_LIFECYCLE}
        )
        if unknown:
            raise ValueError(f"unknown enhanced probe capabilities: {sorted(unknown)}")
        self.image_path = Path(image_path) if image_path else None
        self.docling_path = Path(docling_path) if docling_path else None
        self.expected_image_text = expected_image_text
        self.timeout_seconds = max(1.0, float(timeout_seconds))
        self.lightrag_lifecycle_timeout_seconds = max(
            1.0,
            float(lightrag_lifecycle_timeout_seconds),
        )
        self._preflight_lock = asyncio.Lock()
        self._last_preflight: EnhancedProbeReport | None = None

    @property
    def preflight_running(self) -> bool:
        return self._preflight_lock.locked()

    @property
    def last_preflight(self) -> EnhancedProbeReport | None:
        return self._last_preflight

    def _dependency(self, capability: str) -> Any | None:
        mapping = {
            PP_STRUCTURE: self.dependencies.pp_structure,
            PADDLEOCR_VL: self.dependencies.paddleocr_vl,
            DOCLING: self.dependencies.docling,
            VLM_IMAGE: self.dependencies.image_model,
            EMBEDDING_1024: self.dependencies.embedding_provider,
            LIGHTRAG_HEALTH: self.dependencies.lightrag,
            LIGHTRAG_LIFECYCLE: self.dependencies.lightrag,
            MINERU_VLM_LLM: self.dependencies.mineru_shadow,
        }
        return mapping[capability]

    def _required(self, capability: str, extra_required: frozenset[str]) -> bool:
        return capability in self.required_capabilities or capability in extra_required

    def _readiness_details(self, capability: str, dependency: Any) -> _ProbeOutcome:
        if capability in {PP_STRUCTURE, PADDLEOCR_VL, DOCLING}:
            readiness = getattr(dependency, "readiness", None)
            if callable(readiness):
                details = _safe_value(readiness())
                return _ProbeOutcome(
                    passed=bool(details.get("ready")),
                    details={**details, "verification": "configuration_and_cache"},
                )
        if capability == EMBEDDING_1024:
            dimensions = int(getattr(dependency, "dimensions", 0) or 0)
            return _ProbeOutcome(
                passed=dimensions == 1024,
                details={
                    "dimensions": dimensions,
                    "model": str(getattr(dependency, "model", ""))[:256],
                    "verification": "configuration_only",
                },
            )
        if capability == VLM_IMAGE:
            return _ProbeOutcome(
                passed=callable(getattr(dependency, "run", None)),
                details={
                    "model": str(getattr(dependency, "model_name", ""))[:256],
                    "transport": dependency.__class__.__name__,
                    "verification": "configuration_only",
                },
            )
        if capability == LIGHTRAG_HEALTH:
            return _ProbeOutcome(
                passed=callable(getattr(dependency, "health", None)),
                details={
                    "workspace": str(getattr(dependency, "workspace", ""))[:128],
                    "verification": "configuration_only",
                },
            )
        if capability == MINERU_VLM_LLM:
            status = _safe_value(dependency.status())
            mapper = status.get("mapper") or {}
            return _ProbeOutcome(
                passed=bool(status.get("ready") and mapper.get("model")),
                details={
                    "backend_ready": bool(status.get("ready")),
                    "mapper_model": str(mapper.get("model") or "")[:256],
                    "verification": "configuration_and_health_contract",
                },
            )
        return _ProbeOutcome(
            passed=True, details={"verification": "configuration_only"}
        )

    def readiness(
        self,
        *,
        required_capabilities: Iterable[str] = (),
    ) -> EnhancedProbeReport:
        """Inspect configuration/cache only; never infer, call HTTP, or write."""

        started_at = _utc_now()
        started = time.perf_counter()
        extra_required = frozenset(required_capabilities)
        results: dict[str, CapabilityProbeResult] = {}
        for capability in sorted(PREFLIGHT_CAPABILITIES):
            dependency = self._dependency(capability)
            required = self._required(capability, extra_required)
            if dependency is None:
                results[capability] = CapabilityProbeResult(
                    capability=capability,
                    required=required,
                    configured=False,
                    status="failed" if required else "skipped",
                    exercised=False,
                    details={"verification": "not_configured"},
                    error_type="NotConfigured" if required else None,
                )
                continue
            try:
                outcome = self._readiness_details(capability, dependency)
                results[capability] = CapabilityProbeResult(
                    capability=capability,
                    required=required,
                    configured=True,
                    status="passed" if outcome.passed else "failed",
                    exercised=False,
                    details=_safe_value(outcome.details),
                    error_type=None if outcome.passed else "NotReady",
                )
            except Exception as exc:  # noqa: BLE001 - report type, never message
                results[capability] = CapabilityProbeResult(
                    capability=capability,
                    required=required,
                    configured=True,
                    status="failed",
                    exercised=False,
                    details={"verification": "configuration_only"},
                    error_type=exc.__class__.__name__,
                )
        finished_at = _utc_now()
        previous = self._last_preflight
        ready = all(
            item.status == "passed" for item in results.values() if item.required
        )
        return EnhancedProbeReport(
            mode="ready",
            ready=ready,
            started_at=started_at,
            finished_at=finished_at,
            duration_ms=round((time.perf_counter() - started) * 1000, 3),
            inference_executed=False,
            network_executed=False,
            lifecycle_side_effects_requested=False,
            last_preflight_finished_at=(
                previous.finished_at if previous is not None else None
            ),
            last_preflight_ready=(previous.ready if previous is not None else None),
            results=results,
        )

    async def _execute(
        self,
        capability: str,
        operation: Callable[[], Awaitable[_ProbeOutcome]],
        *,
        required: bool,
    ) -> CapabilityProbeResult:
        dependency = self._dependency(capability)
        if dependency is None:
            return CapabilityProbeResult(
                capability=capability,
                required=required,
                configured=False,
                status="failed" if required else "skipped",
                exercised=False,
                details={"verification": "not_configured"},
                error_type="NotConfigured" if required else None,
            )
        started = time.perf_counter()
        try:
            outcome = await asyncio.wait_for(operation(), timeout=self.timeout_seconds)
            return CapabilityProbeResult(
                capability=capability,
                required=required,
                configured=True,
                status="passed" if outcome.passed else "failed",
                exercised=True,
                duration_ms=round((time.perf_counter() - started) * 1000, 3),
                details=_safe_value(outcome.details),
                error_type=None if outcome.passed else "ProbeAssertionFailed",
            )
        except Exception as exc:  # noqa: BLE001 - never serialize exception text
            return CapabilityProbeResult(
                capability=capability,
                required=required,
                configured=True,
                status="failed",
                exercised=True,
                duration_ms=round((time.perf_counter() - started) * 1000, 3),
                details={"verification": "real_preflight"},
                error_type=exc.__class__.__name__,
            )

    async def preflight(
        self,
        *,
        include_lightrag_lifecycle: bool = False,
        required_capabilities: Iterable[str] = (),
    ) -> EnhancedProbeReport:
        """Run real probes once, explicitly, and never from ordinary readiness."""

        extra_required = frozenset(required_capabilities)
        unknown = extra_required - (PREFLIGHT_CAPABILITIES | {LIGHTRAG_LIFECYCLE})
        if unknown:
            raise ValueError(f"unknown enhanced probe capabilities: {sorted(unknown)}")
        if include_lightrag_lifecycle:
            extra_required = extra_required | {LIGHTRAG_LIFECYCLE}

        async with self._preflight_lock:
            started_at = _utc_now()
            started = time.perf_counter()
            results: dict[str, CapabilityProbeResult] = {}
            pp_evidence: Any | None = None

            with _probe_artifacts(
                self.image_path,
                self.docling_path,
                self.expected_image_text,
            ) as (
                image_path,
                docling_path,
                mineru_document_path,
                expected_image_text,
            ):

                async def pp_probe() -> _ProbeOutcome:
                    nonlocal pp_evidence
                    pp_evidence = await asyncio.to_thread(
                        self.dependencies.pp_structure.parse,
                        image_path,
                    )
                    page_count = len(getattr(pp_evidence, "pages", []))
                    block_count = sum(
                        len(getattr(page, "blocks", []))
                        for page in getattr(pp_evidence, "pages", [])
                    )
                    recognized = "\n".join(
                        str(value)
                        for page in getattr(pp_evidence, "pages", [])
                        for value in (
                            getattr(page, "text", ""),
                            getattr(page, "markdown", ""),
                        )
                    )
                    marker_matched = _normalize_probe_text(
                        expected_image_text
                    ) in _normalize_probe_text(recognized)
                    return _ProbeOutcome(
                        passed=page_count > 0 and block_count > 0 and marker_matched,
                        details={
                            "page_count": page_count,
                            "block_count": block_count,
                            "expected_marker_matched": marker_matched,
                            "backend": str(getattr(pp_evidence, "backend", "")),
                            "verification": "real_inference",
                        },
                    )

                results[PP_STRUCTURE] = await self._execute(
                    PP_STRUCTURE,
                    pp_probe,
                    required=self._required(PP_STRUCTURE, extra_required),
                )

                async def paddle_vl_probe() -> _ProbeOutcome:
                    selected: list[PageInput] = []
                    reasons: dict[str, list[str]] = {}
                    for page in (
                        getattr(pp_evidence, "pages", []) if pp_evidence else []
                    ):
                        should_escalate, page_reasons = page.needs_vlm()
                        if not should_escalate:
                            continue
                        reasons[str(page.page_number)] = page_reasons
                        selected.append(
                            PageInput(
                                path=image_path,
                                page_number=page.page_number,
                                page_index=page.page_index,
                                coordinate_width=page.width,
                                coordinate_height=page.height,
                                rotation=page.rotation,
                            )
                        )
                    forced = not selected
                    if forced:
                        reasons["1"] = ["explicit_preflight"]
                        selected = [
                            PageInput(
                                path=image_path,
                                page_number=1,
                                page_index=0,
                                coordinate_width=1.0,
                                coordinate_height=1.0,
                            )
                        ]
                    evidence = await asyncio.to_thread(
                        self.dependencies.paddleocr_vl.parse,
                        image_path,
                        pages=selected,
                    )
                    page_count = len(getattr(evidence, "pages", []))
                    recognized = "\n".join(
                        str(value)
                        for page in getattr(evidence, "pages", [])
                        for value in (
                            getattr(page, "text", ""),
                            getattr(page, "markdown", ""),
                        )
                    )
                    marker_matched = _normalize_probe_text(
                        expected_image_text
                    ) in _normalize_probe_text(recognized)
                    return _ProbeOutcome(
                        passed=(
                            page_count == len(selected)
                            and page_count > 0
                            and marker_matched
                        ),
                        details={
                            "triggered_page_count": len(selected),
                            "result_page_count": page_count,
                            "expected_marker_matched": marker_matched,
                            "trigger_reasons": reasons,
                            "explicit_preflight_trigger": forced,
                            "backend": str(getattr(evidence, "backend", "")),
                            "verification": "real_inference",
                        },
                    )

                results[PADDLEOCR_VL] = await self._execute(
                    PADDLEOCR_VL,
                    paddle_vl_probe,
                    required=self._required(PADDLEOCR_VL, extra_required),
                )

                async def docling_probe() -> _ProbeOutcome:
                    evidence = await asyncio.to_thread(
                        self.dependencies.docling.parse,
                        docling_path,
                    )
                    page_count = len(getattr(evidence, "pages", []))
                    recognized = "\n".join(
                        str(value)
                        for page in getattr(evidence, "pages", [])
                        for value in (
                            getattr(page, "text", ""),
                            getattr(page, "markdown", ""),
                        )
                    )
                    marker_matched = "M1DOCLING42" in _normalize_probe_text(recognized)
                    return _ProbeOutcome(
                        passed=page_count > 0 and marker_matched,
                        details={
                            "page_count": page_count,
                            "expected_marker_matched": marker_matched,
                            "backend": str(getattr(evidence, "backend", "")),
                            "verification": "real_conversion",
                        },
                    )

                results[DOCLING] = await self._execute(
                    DOCLING,
                    docling_probe,
                    required=self._required(DOCLING, extra_required),
                )

                async def vlm_image_probe() -> _ProbeOutcome:
                    media_type = mimetypes.guess_type(image_path.name)[0] or "image/png"
                    image = BinaryContent(
                        data=image_path.read_bytes(), media_type=media_type
                    )
                    run = await self.dependencies.image_model.run(
                        _ImageProbeOutput,
                        instructions=(
                            "Read the single uppercase marker in the supplied image. "
                            "Return only the typed output."
                        ),
                        prompt="Copy the marker exactly into observed_text.",
                        images=[image],
                    )
                    observed = str(run.output.observed_text)
                    matched = _normalize_probe_text(
                        expected_image_text
                    ) in _normalize_probe_text(observed)
                    return _ProbeOutcome(
                        passed=matched,
                        details={
                            "image_count": 1,
                            "expected_marker_matched": matched,
                            "output_schema_valid": True,
                            "verification": "real_model_image_input",
                        },
                    )

                results[VLM_IMAGE] = await self._execute(
                    VLM_IMAGE,
                    vlm_image_probe,
                    required=self._required(VLM_IMAGE, extra_required),
                )

                async def mineru_vlm_llm_probe() -> _ProbeOutcome:
                    runner = self.dependencies.mineru_shadow
                    expected_order = "M1-MINERU-PROBE-42"
                    authoritative = {
                        "schema_version": "m1.document.v2",
                        "source": {
                            "sha256": hashlib.sha256(
                                mineru_document_path.read_bytes()
                            ).hexdigest()
                        },
                        "document_type": "order",
                        "document_subtype": "supplier_purchase_order",
                        "header": {"order_number": expected_order},
                        "lines": [
                            {
                                "line_id": "probe-line-1",
                                "line_no": 1,
                                "product_code": "CABLE-PROBE-01",
                                "name_raw": "Test cable",
                                "quantity": "12",
                                "unit": "pcs",
                            }
                        ],
                        "field_meta": {},
                    }
                    # Deletion fences intentionally remember task IDs.  A unique
                    # probe ID keeps repeated deploy preflights from being
                    # mistaken for a replay of an already-deleted shadow job.
                    task_id = f"enhanced-preflight-mineru-{uuid4().hex}"
                    try:
                        summary = await runner.run(
                            task_id=task_id,
                            path=mineru_document_path,
                            original_filename=mineru_document_path.name,
                            file_type="pdf",
                            authoritative=authoritative,
                            document_type_hint="order",
                            document_subtype_hint="supplier_purchase_order",
                        )
                    finally:
                        await runner.delete_artifact(task_id)
                    order_number_match = bool(
                        (summary.get("header_field_matches") or {}).get("order_number")
                    )
                    mapper_model = str(
                        (runner.status().get("mapper") or {}).get("model") or ""
                    )
                    line_count = summary.get("line_count") or {}
                    critical_matches = summary.get("first_line_critical_matches") or {}
                    coverage = summary.get("source_reference_coverage") or {}
                    normalization = summary.get("production_normalization") or {}
                    typed_counts = normalization.get("typed_line_field_counts") or {}
                    passed = bool(
                        summary.get("status") == "completed"
                        and summary.get("classification_match") is True
                        and order_number_match
                        and int(summary.get("mapper_requests") or 0) >= 1
                        and int(summary.get("rejected_citations") or 0) == 0
                        and int(line_count.get("mineru") or 0) == 1
                        and all(
                            critical_matches.get(field) is True
                            for field in ("product_code", "quantity", "unit")
                        )
                        and float(coverage.get("ratio") or 0.0) == 1.0
                        and mapper_model
                    )
                    return _ProbeOutcome(
                        passed=passed,
                        details={
                            "classification_match": summary.get("classification_match"),
                            "order_number_match": order_number_match,
                            "mapper_requests": int(summary.get("mapper_requests") or 0),
                            "rejected_citations": int(
                                summary.get("rejected_citations") or 0
                            ),
                            "backend": str(summary.get("backend") or "")[:128],
                            "backend_version": str(
                                summary.get("backend_version") or ""
                            )[:64],
                            "mapper_model": mapper_model[:256],
                            "line_count_match": int(line_count.get("mineru") or 0) == 1,
                            "critical_line_fields_match": all(
                                critical_matches.get(field) is True
                                for field in ("product_code", "quantity", "unit")
                            ),
                            "source_reference_coverage": float(
                                coverage.get("ratio") or 0.0
                            ),
                            "classification_hints_applied": bool(
                                normalization.get("document_type_hint_applied")
                                and normalization.get("document_subtype_hint_applied")
                            ),
                            "canonical_subtype_type_applied": bool(
                                normalization.get("canonical_subtype_type_applied")
                            ),
                            "typed_line_field_counts": {
                                field: int(typed_counts.get(field) or 0)
                                for field in (
                                    "product_code",
                                    "name_raw",
                                    "quantity",
                                    "unit",
                                )
                            },
                            "positioned_order_number_candidate_count": int(
                                normalization.get(
                                    "positioned_order_number_candidate_count"
                                )
                                or 0
                            ),
                            "order_number_recovered": bool(
                                normalization.get("order_number_recovered")
                            ),
                            "order_number_conflict": bool(
                                normalization.get("order_number_conflict")
                            ),
                            "verification": "real_mineru_and_mapper_inference",
                        },
                    )

                results[MINERU_VLM_LLM] = await self._execute(
                    MINERU_VLM_LLM,
                    mineru_vlm_llm_probe,
                    required=self._required(MINERU_VLM_LLM, extra_required),
                )

                async def embedding_probe() -> _ProbeOutcome:
                    vectors = await self.dependencies.embedding_provider.embed_texts(
                        [
                            "M1 enhanced capability probe for an order document",
                            "M1 enhanced capability probe for a cable drawing",
                        ]
                    )
                    dimensions = [len(vector) for vector in vectors]
                    finite = len(vectors) == 2 and all(
                        vector and all(math.isfinite(float(value)) for value in vector)
                        for vector in vectors
                    )
                    nonzero = len(vectors) == 2 and all(
                        any(abs(float(value)) > 1e-12 for value in vector)
                        for vector in vectors
                    )
                    distinct = (
                        len(vectors) == 2
                        and dimensions == [1024, 1024]
                        and any(
                            abs(float(left) - float(right)) > 1e-8
                            for left, right in zip(vectors[0], vectors[1], strict=True)
                        )
                    )
                    return _ProbeOutcome(
                        passed=(
                            dimensions == [1024, 1024]
                            and finite
                            and nonzero
                            and distinct
                        ),
                        details={
                            "vector_count": len(vectors),
                            "dimensions": dimensions,
                            "finite": finite,
                            "nonzero": nonzero,
                            "distinct": distinct,
                            "verification": "real_embedding_call",
                        },
                    )

                results[EMBEDDING_1024] = await self._execute(
                    EMBEDDING_1024,
                    embedding_probe,
                    required=self._required(EMBEDDING_1024, extra_required),
                )

                async def lightrag_health_probe() -> _ProbeOutcome:
                    health = await self.dependencies.lightrag.health()
                    ready = bool(health.get("ready"))
                    return _ProbeOutcome(
                        passed=ready,
                        details={
                            "ready": ready,
                            "workspace": str(health.get("workspace") or "")[:128],
                            "error": health.get("error"),
                            "verification": "real_health_request",
                        },
                    )

                results[LIGHTRAG_HEALTH] = await self._execute(
                    LIGHTRAG_HEALTH,
                    lightrag_health_probe,
                    required=self._required(LIGHTRAG_HEALTH, extra_required),
                )

                if include_lightrag_lifecycle:

                    async def lightrag_lifecycle_probe() -> _ProbeOutcome:
                        lifecycle = self.dependencies.lightrag_lifecycle
                        if lifecycle is None:
                            from .benchmarks.lightrag_shadow import lifecycle_probe

                            async def lifecycle(client: Any, timeout: float):
                                return await lifecycle_probe(
                                    client,
                                    timeout_seconds=timeout,
                                )

                        result = await lifecycle(
                            self.dependencies.lightrag,
                            self.lightrag_lifecycle_timeout_seconds,
                        )
                        passed = bool(
                            result.get("duplicate_idempotent")
                            and result.get("deletion_consistent")
                        )
                        return _ProbeOutcome(
                            passed=passed,
                            details={
                                key: result.get(key)
                                for key in (
                                    "duplicate_idempotent",
                                    "repeat_write_document_count",
                                    "indexed_retrievable",
                                    "document_absent_after_delete",
                                    "query_absent_after_delete",
                                    "deletion_consistent",
                                    "latency_ms",
                                    "error",
                                )
                            },
                        )

                    results[LIGHTRAG_LIFECYCLE] = await self._execute(
                        LIGHTRAG_LIFECYCLE,
                        lightrag_lifecycle_probe,
                        required=True,
                    )

            finished_at = _utc_now()
            ready = all(
                item.status == "passed" for item in results.values() if item.required
            )
            report = EnhancedProbeReport(
                mode="preflight",
                ready=ready,
                started_at=started_at,
                finished_at=finished_at,
                duration_ms=round((time.perf_counter() - started) * 1000, 3),
                inference_executed=any(
                    results[name].exercised
                    for name in (
                        PP_STRUCTURE,
                        PADDLEOCR_VL,
                        DOCLING,
                        VLM_IMAGE,
                        EMBEDDING_1024,
                        MINERU_VLM_LLM,
                    )
                ),
                network_executed=any(
                    results[name].exercised
                    for name in (
                        VLM_IMAGE,
                        EMBEDDING_1024,
                        LIGHTRAG_HEALTH,
                        MINERU_VLM_LLM,
                    )
                ),
                lifecycle_side_effects_requested=include_lightrag_lifecycle,
                last_preflight_finished_at=finished_at,
                last_preflight_ready=ready,
                results=results,
            )
            self._last_preflight = report
            return report


def build_enhanced_probe_from_runtime(
    runtime: Any,
    settings: Any,
    *,
    image_path: str | Path | None = None,
    docling_path: str | Path | None = None,
    expected_image_text: str = "",
) -> EnhancedCapabilityProbe:
    """Bind a probe to the exact objects serving the current M1 process."""

    deps = getattr(getattr(runtime, "engine", None), "deps", None)
    parser = getattr(deps, "document_parser", None)
    vlm_agent = getattr(deps, "vlm_agent", None)
    image_model = getattr(vlm_agent, "client", None)
    if not callable(getattr(image_model, "run", None)):
        image_model = None
    knowledge = getattr(runtime, "knowledge_runtime", None)
    dependencies = EnhancedProbeDependencies(
        pp_structure=getattr(parser, "pp_structure", None),
        paddleocr_vl=getattr(parser, "paddle_vl", None),
        docling=getattr(parser, "docling", None),
        image_model=image_model,
        embedding_provider=getattr(knowledge, "embedding_provider", None),
        lightrag=getattr(knowledge, "lightrag_shadow", None),
        mineru_shadow=getattr(deps, "mineru_shadow_runner", None),
    )
    required: set[str] = set()
    if bool(getattr(settings, "pp_structure_enabled", False)):
        required.add(PP_STRUCTURE)
    if bool(getattr(settings, "paddleocr_vl_enabled", False)):
        required.add(PADDLEOCR_VL)
    if bool(getattr(settings, "docling_enabled", False)):
        required.add(DOCLING)
    if image_model is not None:
        required.add(VLM_IMAGE)
    if bool(getattr(settings, "knowledge_embeddings_enabled", False)):
        required.add(EMBEDDING_1024)
    if bool(getattr(settings, "lightrag_shadow_enabled", False)):
        required.add(LIGHTRAG_HEALTH)
    if bool(getattr(settings, "mineru_shadow_enabled", False)):
        required.add(MINERU_VLM_LLM)
    return EnhancedCapabilityProbe(
        dependencies,
        required_capabilities=required,
        image_path=image_path,
        docling_path=docling_path,
        expected_image_text=expected_image_text,
        timeout_seconds=max(
            float(getattr(settings, "paddleocr_vl_timeout_seconds", 180.0)),
            (
                float(getattr(settings, "mineru_timeout_seconds", 240.0))
                + float(getattr(settings, "mineru_mapper_timeout_seconds", 60.0))
                + 30.0
            ),
        ),
    )


__all__ = [
    "DOCLING",
    "EMBEDDING_1024",
    "LIGHTRAG_HEALTH",
    "LIGHTRAG_LIFECYCLE",
    "MINERU_VLM_LLM",
    "PADDLEOCR_VL",
    "PP_STRUCTURE",
    "PREFLIGHT_CAPABILITIES",
    "VLM_IMAGE",
    "EnhancedCapabilityProbe",
    "EnhancedProbeDependencies",
    "EnhancedProbeReport",
    "build_enhanced_probe_from_runtime",
]
