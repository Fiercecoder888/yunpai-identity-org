"""Container-local governance CLI for field-semantic extension routes.

Every mutation delegates to ``KnowledgeStore``.  Validation reads the final
task through ``TaskStore`` and accepts a sample only when the persisted document
explicitly references the candidate profile; labels, values, and raw TaskIDs
are never copied into route observations.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import sys
from collections.abc import Mapping, Sequence
from typing import Any

from .core.config import settings
from .documents.parsing.field_semantic_registry import (
    build_document_canonical_field_registry,
)
from .documents.parsing.field_semantic_routing import (
    FieldSemanticExecutionObservation,
)
from .knowledge.field_semantic_schema import FieldSemanticProfileStatus
from .knowledge.persistence import KnowledgeStore
from .state import TaskStatus
from .workflow.persistence import TaskStore

_SCHEMA_VERSION = "m1.field-extension-route-operation.v1"
_SAFE_ERROR_CODE = re.compile(r"^[A-Za-z][A-Za-z0-9_.:-]{0,127}$")


def _nonempty(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must not be empty")
    return normalized


def _error_code(value: str) -> str:
    normalized = value.strip()
    if _SAFE_ERROR_CODE.fullmatch(normalized) is None:
        raise argparse.ArgumentTypeError("error code must be a stable token")
    return normalized


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.extension_routes",
        description="Govern field-semantic extension routes inside the M1 container.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    list_command = commands.add_parser("list", help="List field route profiles.")
    list_command.add_argument("--tenant-id", required=True, type=_nonempty)
    list_command.add_argument(
        "--status",
        choices=tuple(status.value for status in FieldSemanticProfileStatus),
    )
    list_command.add_argument("--limit", type=int, default=100)

    validate = commands.add_parser(
        "validate",
        help="Record a reviewed success or failure against a completed final task.",
    )
    validate.add_argument("outcome", choices=("success", "failure"))
    validate.add_argument("--tenant-id", required=True, type=_nonempty)
    validate.add_argument("--profile-id", required=True, type=_nonempty)
    validate.add_argument("--task-id", required=True, type=_nonempty)
    validate.add_argument("--reviewed-by", required=True, type=_nonempty)
    validate.add_argument("--review-note", required=True, type=_nonempty)
    validate.add_argument(
        "--error-code",
        type=_error_code,
        default="manual_validation_failed",
    )

    approve = commands.add_parser("approve", help="Activate a validated candidate.")
    approve.add_argument("--tenant-id", required=True, type=_nonempty)
    approve.add_argument("--profile-id", required=True, type=_nonempty)
    approve.add_argument("--approved-by", required=True, type=_nonempty)
    approve.add_argument("--reviewed-by", required=True, type=_nonempty)
    approve.add_argument("--review-note", required=True, type=_nonempty)

    for command, help_text in (
        ("reject", "Reject a candidate field route."),
        ("deprecate", "Deprecate a candidate or active field route."),
    ):
        operation = commands.add_parser(command, help=help_text)
        operation.add_argument("--tenant-id", required=True, type=_nonempty)
        operation.add_argument("--profile-id", required=True, type=_nonempty)
        operation.add_argument("--reviewed-by", required=True, type=_nonempty)
        operation.add_argument("--review-note", required=True, type=_nonempty)
    return parser


def _status_value(value: object) -> str:
    return str(getattr(value, "value", value)).strip().casefold()


def _profile_payload(profile: Any) -> dict[str, Any]:
    return {
        "profile_id": profile.profile_id,
        "tenant_id": profile.tenant_id,
        "profile_key": profile.profile_key,
        "version": profile.version,
        "status": _status_value(profile.status),
        "exact_fingerprint": profile.exact_fingerprint,
        "canonical_field_id": profile.canonical_field_id,
        "contract_revision": profile.signature.contract_revision,
        "observation_count": profile.observation_count,
        "success_count": profile.success_count,
        "failure_count": profile.failure_count,
        "approved_by": profile.approved_by,
        "approved_at": profile.approved_at.isoformat() if profile.approved_at else None,
        "last_success_at": (
            profile.last_success_at.isoformat() if profile.last_success_at else None
        ),
        "last_failure_at": (
            profile.last_failure_at.isoformat() if profile.last_failure_at else None
        ),
    }


def _routing_containers(document: Mapping[str, Any]) -> tuple[Mapping[str, Any], ...]:
    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, Mapping) else None
    if not isinstance(metadata, Mapping):
        return ()
    containers: list[Mapping[str, Any]] = []
    direct = metadata.get("field_semantic_routing")
    if isinstance(direct, Mapping):
        containers.append(direct)
    interpreter = metadata.get("tabular_schema_interpreter")
    nested = (
        interpreter.get("field_semantic_routing")
        if isinstance(interpreter, Mapping)
        else None
    )
    if isinstance(nested, Mapping):
        containers.append(nested)
    return tuple(containers)


def _audit_references_candidate(document: Mapping[str, Any], profile_id: str) -> bool:
    for container in _routing_containers(document):
        decisions = container.get("decisions")
        if not isinstance(decisions, list):
            continue
        for decision in decisions:
            if (
                isinstance(decision, Mapping)
                and decision.get("candidate_profile_id") == profile_id
            ):
                return True
    return False


def _task_reference_hash(tenant_id: str, task_id: str) -> str:
    return hashlib.sha256(f"{tenant_id}\0{task_id}".encode()).hexdigest()


async def _list(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profiles = await store.list_field_semantic_profiles(
            args.tenant_id,
            status=args.status,
            limit=max(1, min(int(args.limit), 1000)),
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "list",
            "tenant_id": args.tenant_id,
            "profiles": [_profile_payload(profile) for profile in profiles],
        }
    finally:
        await store.close()


async def _validate(args: argparse.Namespace) -> dict[str, Any]:
    route_store = KnowledgeStore(settings.resolved_knowledge_database_url)
    task_store = TaskStore(settings.database_url)
    try:
        await route_store.init()
        profile = await route_store.get_field_semantic_profile(
            args.tenant_id, args.profile_id
        )
        if profile is None:
            raise LookupError("field semantic profile not found")
        status = _status_value(profile.status)
        if args.outcome == "success" and status != "candidate":
            raise ValueError("successful validation requires a candidate profile")
        if args.outcome == "failure" and status not in {"candidate", "active"}:
            raise ValueError("failed validation requires a candidate or active profile")

        state = await task_store.load(args.task_id)
        if state is None:
            raise LookupError("field route validation task not found")
        if str(state.tenant_id).strip() != args.tenant_id:
            raise ValueError("field route validation task belongs to another tenant")
        if state.status is not TaskStatus.DONE:
            raise ValueError("field route validation requires a completed task")
        if state.knowledge_sync_status != "synced" or not state.knowledge_version_id:
            raise ValueError(
                "field route validation requires a synced knowledge version"
            )
        if not isinstance(state.document, Mapping):
            raise TypeError("field route validation task has no final document")
        if not _audit_references_candidate(state.document, args.profile_id):
            raise ValueError("final document does not reference the candidate profile")

        success = args.outcome == "success"
        task_hash = _task_reference_hash(args.tenant_id, args.task_id)
        observation = FieldSemanticExecutionObservation(
            tenant_id=args.tenant_id,
            profile_id=args.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=task_hash,
            outcome=args.outcome,
            validation_passed=success,
            reviewed_by=args.reviewed_by,
            review_note_sha256=hashlib.sha256(args.review_note.encode()).hexdigest(),
            error_code="" if success else args.error_code,
        )
        persisted = await route_store.record_field_semantic_execution_observation(
            observation
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "validate",
            "tenant_id": args.tenant_id,
            "profile_id": args.profile_id,
            "outcome": args.outcome,
            "observation_id": persisted.observation_id,
            "task_reference_hash": task_hash,
            "knowledge_version_id": state.knowledge_version_id,
        }
    finally:
        await task_store.close()
        await route_store.close()


async def _approve(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.get_field_semantic_profile(
            args.tenant_id, args.profile_id
        )
        if profile is None:
            raise LookupError("field semantic profile not found")
        registry = build_document_canonical_field_registry()
        activated = await store.activate_field_semantic_profile(
            args.tenant_id,
            args.profile_id,
            approved_by=args.approved_by,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
            expected_observation_count=profile.observation_count,
            allowed_canonical_field_ids=registry.field_ids,
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": "approve",
            "profile": _profile_payload(activated),
        }
    finally:
        await store.close()


async def _review_state_change(
    args: argparse.Namespace,
    *,
    operation: str,
) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        method = getattr(store, f"{operation}_field_semantic_profile")
        profile = await method(
            args.tenant_id,
            args.profile_id,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": _SCHEMA_VERSION,
            "operation": operation,
            "profile": _profile_payload(profile),
        }
    finally:
        await store.close()


async def _run(args: argparse.Namespace) -> dict[str, Any]:
    if args.command == "list":
        return await _list(args)
    if args.command == "validate":
        return await _validate(args)
    if args.command == "approve":
        return await _approve(args)
    if args.command in {"reject", "deprecate"}:
        return await _review_state_change(args, operation=args.command)
    raise ValueError(f"unsupported field extension route operation: {args.command}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = asyncio.run(_run(args))
    except Exception as exc:  # noqa: BLE001 - bounded operator error
        print(
            json.dumps(
                {
                    "schema_version": _SCHEMA_VERSION,
                    "operation": str(getattr(args, "command", "unknown")),
                    "status": "failed",
                    "error_type": exc.__class__.__name__,
                },
                ensure_ascii=True,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised through main()
    raise SystemExit(main())


__all__ = ["main"]
