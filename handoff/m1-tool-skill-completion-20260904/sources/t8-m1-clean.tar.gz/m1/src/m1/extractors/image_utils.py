"""图像/文档编码工具: 把任意视觉文件转成 VLM 可接受的 base64 图片。

核心问题: VLM 的 image_url 只接受真实图片 (jpeg/png/...),
PDF/DXF 等非图片格式必须先渲染成图片, 否则 API 报 400 "not a valid image"。

本模块统一处理:
  - PDF → pymupdf 逐页渲染成 PNG
  - 普通图片 → 直接读取
  - 返回 (base64_str, mime_type)
"""
from __future__ import annotations

import base64
from pathlib import Path

from ..documents.magic import sniff_file_type

_IMAGE_MIME = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".png": "image/png", ".bmp": "image/bmp",
    ".webp": "image/webp", ".gif": "image/gif",
    ".tiff": "image/tiff", ".tif": "image/tiff",
}
_MAX_IMAGE_BYTES = 20 * 1024 * 1024


def encode_for_vlm(file_path: str | Path) -> tuple[str, str]:
    """把视觉文件编码为 VLM 可接受的 (base64, mime)。

    - PDF: 用 pymupdf 渲染第一页；多页调用方应使用 encode_many_for_vlm
    - 普通图片: 直接读字节
    - 其它格式直接拒绝，禁止把未知二进制伪装成 JPEG
    """
    p = Path(file_path)
    info = sniff_file_type(p)

    if info.kind == "pdf":
        return _render_pdf_pages(p, max_pages=1)[0]
    if info.kind == "image":
        if info.kind != "image":
            raise ValueError(
                f"图片魔数与扩展名不匹配，拒绝发送: {p.name}"
            )
        if p.stat().st_size > _MAX_IMAGE_BYTES:
            raise ValueError(f"图片超过 {_MAX_IMAGE_BYTES} 字节上限: {p.name}")
        with open(p, "rb") as f:
            return base64.b64encode(f.read()).decode("ascii"), info.mime_type
    raise ValueError(f"不是可发送给 VLM 的视觉文件: {p.suffix or '<无扩展名>'}")


def encode_many_for_vlm(
    file_path: str | Path, *, max_images: int = 8, pdf_dpi: int = 150
) -> list[tuple[str, str]]:
    """返回独立视觉输入，PDF 严格逐页，最多 ``max_images`` 张。"""
    p = Path(file_path)
    if max_images <= 0:
        return []
    if sniff_file_type(p).kind == "pdf":
        return _render_pdf_pages(p, dpi=pdf_dpi, max_pages=max_images)
    return [encode_for_vlm(p)]


def _render_pdf_pages(
    pdf_path: Path, dpi: int = 150, max_pages: int = 8
) -> list[tuple[str, str]]:
    """用 pymupdf 逐页渲染 PDF，不拼接成长图。"""
    try:
        import fitz  # pymupdf
    except ImportError as e:
        raise RuntimeError(
            "处理 PDF 需要安装 pymupdf: pip install pymupdf (或改用图片上传)"
        ) from e

    doc = fitz.open(str(pdf_path))
    try:
        pages: list[tuple[str, str]] = []
        for index, page in enumerate(doc):
            if index >= max_pages:
                break
            pix = page.get_pixmap(dpi=dpi)
            encoded = base64.b64encode(pix.tobytes("png")).decode("ascii")
            pages.append((encoded, "image/png"))
        if not pages:
            raise ValueError(f"PDF 没有可渲染页面: {pdf_path.name}")
        return pages
    finally:
        doc.close()
