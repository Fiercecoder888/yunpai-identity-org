"""工程图复刻说明书抽取器。

目标: 让 VLM 看工程图后, 输出一篇详细完整的结构化文字说明 (Markdown),
确保其他人只读文字就能复刻这张工程图。

独立于现有的结构化提取 (标题栏/BOM/修订履历), 那些是表格化字段;
本模块输出的是自由形式的"复刻说明书"文章, 侧重几何/尺寸/装配的可复现描述。

输出结构:
  1. 总体概述 (是什么、用途、整体结构)
  2. 各零件/部件详细描述 (形状、所有尺寸+公差、材料、位置)
  3. 装配关系 (谁套谁、连接方式、方向、引脚定义)
  4. 技术要求 (公差标准、表面处理、测试条件)
"""
from __future__ import annotations

from pathlib import Path
from loguru import logger
from openai import AsyncOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

REPLICATION_SYSTEM = """你是一个资深的机械/电子工程图纸解读专家。
你的任务: 仔细看这张工程图, 然后写出一篇**详细完整、可供他人复刻**的文字说明。

【核心要求 - 必须达到"可复刻"标准】
读者只看你的文字 (不看原图), 就应该能:
  - 知道这是什么产品、由哪些部件组成
  - 知道每个部件的精确形状和所有尺寸 (含公差)
  - 知道部件之间如何装配、连接关系
  - 知道材料和规格要求
  - 据此重新绘制或制造出基本相同的工件

【必须包含的内容】
1. **总体概述**: 产品名称、类型、功能用途、整体结构 (几个部件、什么连接方式)
2. **逐个部件详细描述** (这是重点):
   - 每个可见部件 (插头/外壳/内模/线材/PCB/屏蔽壳 等) 单独一段
   - 该部件的**几何形状**描述 (圆柱/方块/异形, 大致比例)
   - 该部件的**所有可见尺寸**, 必须带单位和公差 (如 "总长 152±15mm"、"接口宽 6.65±0.1mm")
   - **绝对不要省略任何尺寸标注**, 图上每一个带数值的标注都要写进说明
   - 该部件的**材料/规格** (如 "线材: 32#(7/0.08) 镀锡铜线"、"镀金 30U\"")
   - 该部件**与其他部件的位置关系** (如 "内模包覆在 PCB 外侧, 外模包覆整个插头组件")
3. **装配关系与连接**:
   - 装配顺序 (先装什么后装什么, 如果能从图推断)
   - 连接方式 (焊接/卡扣/胶接/压接)
   - 如有接线图/引脚定义, 完整列出每个引脚的信号和对应连接 (如 "A4=VBUS, B5=CC")
4. **技术要求**: 完整摘录所有技术要求、测试条件、公差标准、表面处理等

【写作要求】
- 用清晰的中文 Markdown, 分章节 (用 ## 标题)
- 尺寸必须精确到图上标注的原值, 不要四舍五入或省略
- 如果源图是照片、渲染图、概念图或宣传图, 而不是带尺寸标注/标题栏/BOM 的工程图纸, 必须先明确说明“源图不含可制造尺寸”。这种情况下严禁编造毫米尺寸、公差、材料牌号、BOM、热处理、功率、压力、温度、型号等工程参数；也不要写“约 2 米”“直径约 0.8 米”“M16”等带单位或规格的估算值。只能描述可见外观、相对比例、模块关系、颜色、标识和可观察结构, 例如“前端圆形接口约占整机高度的一半”。无法从图中读取的内容写“未标注/不可确认”。
- 只有当图中明确可见数字标注、标题栏、BOM 或文字参数时, 才能作为工程参数写入报告。
- 模糊处注明 "(原图此处模糊, 约 XX)"
- 不要写"如图所示"之类的话 (读者看不到图), 一切用文字描述
- 宁可啰嗦不可遗漏, 信息完整性优先于简洁

【输出格式】
直接输出 Markdown 文章, 不要加 ```markdown 代码块标记, 不要任何前言。从第一个 # 标题开始。"""


REPLICATION_USER = """请仔细审视这张工程图, 然后写出一篇可供他人复刻的详细完整文字说明。
记住: 读者看不到原图, 你必须用文字把所有几何、尺寸、装配、材料信息表达清楚。
现在请输出 Markdown 文章:"""


# 通用详细报告 prompt (订单/报价/采购/BOM/SOP 等非图纸类型)
GENERAL_REPORT_SYSTEM = """你是一个专业的文档分析师。仔细看这份文档, 然后写出一篇**详细完整的分析报告**。
读者看不到原图, 你必须用文字把文档的所有信息完整表达出来。

【必须包含的内容】
1. **文档概述**: 这是什么文档、用途、整体结构
2. **完整信息提取** (逐项详列, 不要遗漏):
   - 单据头信息 (编号/日期/买卖方/有效期等, 逐字精确)
   - 明细行 (每行完整列出: 编号/名称/数量/单价/金额, 带单位)
   - 金额合计 (分币种列示)
   - 条款 (付款/交货/其它, 完整摘录原文)
   - 如有表格, 完整转述表格内容
3. **数据校验**:
   - 明细行金额加总是否等于合计金额
   - 日期格式是否合理
   - 编号/数量/单位是否有异常
4. **质量评价**:
   - 文档清晰度、完整性
   - 需人工确认的疑点

【写作要求】
- 用清晰的中文 Markdown, 分章节 (## 标题)
- 数字精确到原文值, 不要四舍五入
- 模糊处注明 "(原文此处模糊, 约 XX)"
- 不要写"如图所示", 一切用文字
- 宁可啰嗦不可遗漏

直接输出 Markdown, 不要 ```markdown 包裹。从第一个 # 标题开始。"""

GENERAL_REPORT_USER = """请仔细审视这份文档, 写出详细完整的分析报告。
现在请输出 Markdown:"""

# doc_type → (system, user) prompt 映射
REPORT_PROMPTS: dict[str, tuple[str, str]] = {
    "drawing": (REPLICATION_SYSTEM, REPLICATION_USER),
}
DEFAULT_REPORT_PROMPT = (GENERAL_REPORT_SYSTEM, GENERAL_REPORT_USER)


def get_report_prompt(doc_type: str) -> tuple[str, str]:
    """按 doc_type 取详细报告 prompt; 非 drawing 走通用 prompt。"""
    return REPORT_PROMPTS.get(doc_type, DEFAULT_REPORT_PROMPT)


class ReplicationExtractor:
    """详细报告抽取器 (所有文档类型, 手动或自动触发)。

    独立于 VLMExtractor (那个输出结构化 JSON), 这个输出自由文本 Markdown。
    用法:
        ext = ReplicationExtractor(api_key, base_url, model)
        doc = await ext.extract("drawing.pdf")  # 返回 Markdown 字符串
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str = "qwen-vl-max",
        timeout: float = 300.0,
    ):
        self.client = AsyncOpenAI(
            api_key=api_key or "EMPTY",
            base_url=base_url,
            timeout=timeout,
            max_retries=0,
        )
        self.model = model

    async def close(self) -> None:
        """Release the per-report HTTP client."""

        await self.client.close()

    @retry(stop=stop_after_attempt(2), wait=wait_exponential(min=2, max=8))
    async def extract(self, file_path: str | Path, dpi: int = 130, doc_type: str = "drawing") -> str:
        """抽取详细报告 (所有文档类型)。

        doc_type 决定用哪套 prompt:
          - drawing: 工程图复刻说明书 (几何/尺寸/装配/材料)
          - 其它: 通用文档分析报告 (信息提取/数据校验/质量评价)

        dpi: PDF 渲染分辨率, 默认 130 (降低体积加快 VLM)。

        Returns:
            Markdown 格式的详细报告。
        """
        system_prompt, user_prompt = get_report_prompt(doc_type)
        # 用较低 dpi 渲染, 减少 base64 体积, 加快 VLM 推理
        image_b64, image_mime = self._encode_for_vlm(file_path, dpi)
        image_url = f"data:{image_mime};base64,{image_b64}"

        try:
            resp = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": [
                            {"type": "image_url", "image_url": {"url": image_url}},
                            {"type": "text", "text": user_prompt},
                        ],
                    },
                ],
                temperature=0.2,  # 略高于结构化抽取, 让描述更自然
                max_tokens=6000,  # 复刻说明较长, 但控制在 6000 避免超时
            )
        except Exception as e:
            logger.error(
                "replication VLM failed: type={} status={}",
                e.__class__.__name__,
                getattr(e, "status_code", None),
            )
            raise

        content = resp.choices[0].message.content or ""
        logger.info(f"复刻说明抽取完成: {len(content)} 字符")
        return content

    def _encode_for_vlm(self, file_path: str | Path, dpi: int = 130) -> tuple[str, str]:
        """编码图片, PDF 用指定 dpi 渲染 (复刻说明用较低 dpi 减少体积)。"""
        from pathlib import Path as P
        ext = P(file_path).suffix.lower()
        if ext == ".pdf":
            return self._render_pdf(file_path, dpi)
        from .image_utils import encode_for_vlm
        return encode_for_vlm(file_path)

    def _render_pdf(self, file_path, dpi: int) -> tuple[str, str]:
        """PDF → PNG base64 (指定 dpi)。"""
        import base64
        try:
            import fitz
        except ImportError as e:
            raise RuntimeError("需要 pymupdf: pip install pymupdf") from e
        doc = fitz.open(str(file_path))
        # 只取首页 (复刻说明针对主图纸; 多页工程图少见)
        pix = doc[0].get_pixmap(dpi=dpi)
        data = pix.tobytes("png")
        doc.close()
        return base64.b64encode(data).decode("ascii"), "image/png"
