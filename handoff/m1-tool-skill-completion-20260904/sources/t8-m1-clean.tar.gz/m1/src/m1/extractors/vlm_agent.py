﻿"""VLM 抽取器: 调用 DashScope (OpenAI 兼容) 的 Qwen2.5-VL。

特性:
  - 走 OpenAI 兼容接口, 可无缝切换 vLLM/其他云
  - 输出结构化 JSON, 解析为 MechanicalDrawing
  - 顺带抓取 logprobs (若 API 支持) 作为置信度信号
"""
from __future__ import annotations

import asyncio
import base64
import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from loguru import logger
from openai import AsyncOpenAI
from pydantic import BaseModel, Field, create_model
from pydantic_ai import BinaryContent
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential

from ..schemas import ExtractionResult, ExtractedField
from ..schemas.cad_drawing import MechanicalDrawing
from ..schemas.registry import get_schema_cls
from .prompts import get_prompt
from ..structured_llm import StructuredModelClient


def _retryable_vlm_error(exc: BaseException) -> bool:
    """Retry transient transport/rate-limit failures, never authentication errors."""

    status = getattr(exc, "status_code", None)
    if status in {429, 500, 502, 503, 504}:
        return True
    if isinstance(exc, (TimeoutError, asyncio.TimeoutError)):
        return True
    return exc.__class__.__name__ in {"APITimeoutError", "APIConnectionError"}


@lru_cache(maxsize=16)
def _structured_output_model(doc_type: str) -> type[BaseModel]:
    """Extend the selected business schema with the two shared VLM fields."""

    schema_cls = get_schema_cls(doc_type) or MechanicalDrawing
    return create_model(
        f"{schema_cls.__name__}VLMOutput",
        __base__=schema_cls,
        extra=(dict[str, Any] | None, None),
        field_confidences=(dict[str, Any], Field(default_factory=dict)),
    )


class VLMExtractor:
    """封装 VLM 调用, 输出结构化抽取结果。"""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str = "qwen-vl-max",
        timeout: float = 300.0,
        temperature: float = 0.0,
        max_tokens: int = 8192,
        max_images: int = 8,
        enable_thinking: bool = False,
        structured_backend: str = "pydantic_ai",
    ):
        # Replication/report extensions need the same endpoint configuration,
        # independent of whether ``client`` is AsyncOpenAI or PydanticAI.
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.structured_backend = structured_backend.strip().casefold()
        if self.structured_backend == "pydantic_ai":
            self.client = StructuredModelClient(
                api_key=api_key,
                base_url=self.base_url,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                enable_thinking=enable_thinking,
                timeout=timeout,
                retries=2,
            )
        elif self.structured_backend == "legacy":
            self.client = AsyncOpenAI(
                api_key=api_key or "EMPTY",
                base_url=self.base_url,
                timeout=timeout,
                max_retries=0,
            )
        else:
            raise ValueError("structured backend must be legacy or pydantic_ai")
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.max_images = max(0, min(max_images, 8))
        self.enable_thinking = enable_thinking

    async def close(self) -> None:
        """Release the underlying HTTP client for direct/library use."""

        await self.client.close()

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=1, max=10),
        retry=retry_if_exception(_retryable_vlm_error),
        reraise=True,
    )
    async def extract(
        self,
        file_path: str | Path,
        context: str = "",
        doc_type: str = "drawing",
    ) -> ExtractionResult:
        """
        抽取一份图片/文档的结构化字段。

        参数:
            file_path: 图片路径 (VLM 直接看图)
            context: 前置解析的辅助上下文 (如 DXF 文本)
            doc_type: 文档业务类型 (drawing/order/quotation/po/bom/sop);
                决定用哪套 prompt 和 schema。未知/unknown 回退 drawing。

        返回:
            ExtractionResult (字段列表 + 原始文本 + logprobs)
        """
        images = self._encode_images(file_path)
        # 按 doc_type 选 prompt; 未知类型回退 drawing
        system_prompt, user_template = get_prompt(doc_type)
        user_prompt = user_template.format(context=context or "(无)")
        if "thinking" in self.model.lower():
            user_prompt = "/no_think\n" + user_prompt
        try:
            if self.structured_backend == "pydantic_ai":
                binary_images = [
                    BinaryContent(
                        data=base64.b64decode(image_b64),
                        media_type=image_mime,
                    )
                    for image_b64, image_mime in images
                ]
                run = await self.client.run(
                    _structured_output_model(doc_type),
                    instructions=system_prompt,
                    prompt=user_prompt,
                    images=binary_images,
                )
                data = run.output.model_dump(mode="json")
                raw_text = json.dumps(data, ensure_ascii=False, default=str)
            else:
                visual_content = [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:{image_mime};base64,{image_b64}",
                            "detail": "high",
                        },
                    }
                    for image_b64, image_mime in images
                ]
                resp = await self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {
                            "role": "user",
                            "content": [
                                *visual_content,
                                {"type": "text", "text": user_prompt},
                            ],
                        },
                    ],
                    temperature=self.temperature,
                    max_tokens=self.max_tokens,
                    extra_body={"enable_thinking": self.enable_thinking},
                )
                choice = resp.choices[0]
                if str(choice.finish_reason or "") == "length":
                    raise ValueError("VLM response truncated by token limit")
                raw_text = choice.message.content or ""
                data = json.loads(raw_text)
        except Exception as e:
            logger.error(
                "VLM 调用失败: type={} status={}",
                e.__class__.__name__,
                getattr(e, "status_code", None),
            )
            raise

        return self._build_result(data, raw_text, doc_type)

    def _encode_image(self, file_path: str | Path) -> tuple[str, str]:
        """读取/渲染图片并 base64 编码。委托给 image_utils (PDF 自动转图)。"""
        from .image_utils import encode_for_vlm

        return encode_for_vlm(file_path)

    def _encode_images(self, file_path: str | Path) -> list[tuple[str, str]]:
        """PDF 逐页输入，避免纵向长图损失表格分辨率。"""
        from .image_utils import encode_many_for_vlm

        return encode_many_for_vlm(file_path, max_images=self.max_images)

    def _build_result(
        self,
        data: Any,
        raw_text: str,
        doc_type: str = "drawing",
    ) -> ExtractionResult:
        """把 VLM 输出的 JSON 解析为 ExtractionResult (扁平字段 + 完整明细)。

        按 doc_type 选 schema:
          - drawing: 走 MechanicalDrawing (标题栏 + bom + 修订履历)
          - 其它: 走 SCHEMA_REGISTRY, 用通用展平 + details 明细
          - 未知/解析失败: raw_fallback

        同时提取 VLM 自评的 field_confidences (字段名 → {self, clarity}),
        作为置信度融合的真实信号 (替代失效的 logprob/ocr)。

        extra: 大模型输出的 JSON 顶层 "extra" 对象 (混合 schema C: 字段骨架
               探测引导出的额外字段) 提取为 extra_fields。
        """
        if not isinstance(data, dict):
            return ExtractionResult(
                fields=[ExtractedField(name="raw_fallback", value=raw_text)],
                raw_text=raw_text,
            )
        data = dict(data)

        # 提取 extra (混合 schema: 字段骨架引导出的额外字段)
        extra_raw = data.pop("extra", None) if isinstance(data, dict) else None
        # 提取 VLM 自评置信度 (字段名 → {self, clarity})
        field_confidences = data.pop("field_confidences", None) if isinstance(data, dict) else None
        if not isinstance(field_confidences, dict):
            field_confidences = {}

        # 图纸走原有特化逻辑 (bom/key_dimensions 双明细)
        if doc_type == "drawing":
            return self._build_drawing_result(data, raw_text, field_confidences, extra_raw)

        # 其它类型走 registry 通用解析
        schema_cls = get_schema_cls(doc_type)
        if schema_cls is None:
            # 未知类型回退到图纸解析 (保底)
            logger.warning(f"未知 doc_type={doc_type}, 回退 drawing 解析")
            return self._build_drawing_result(data, raw_text, field_confidences, extra_raw)

        try:
            doc = schema_cls.model_validate(data)
        except Exception as e:
            logger.warning(
                "JSON 解析为 {} 失败: type={}",
                schema_cls.__name__,
                e.__class__.__name__,
            )
            return ExtractionResult(
                fields=[ExtractedField(name="raw_fallback", value=raw_text)],
                raw_text=raw_text,
            )

        # 通用展平 (各 schema 自带 to_flat_fields)
        fields: list[ExtractedField] = []
        for name, value in doc.to_flat_fields():
            fields.append(ExtractedField(name=name, value=value))

        # 明细行统一放 details (UI 通用渲染)
        detail_rows: list[dict] = []
        for attr in ("lines", "rows", "steps"):
            rows = getattr(doc, attr, None)
            if rows:
                detail_rows = [r.model_dump() for r in rows]
                break

        # extra 字段
        extra_fields = self._build_extra_fields(extra_raw)

        return ExtractionResult(
            fields=fields,
            extra_fields=extra_fields,
            raw_text=raw_text,
            bom=detail_rows,  # 非图纸类型: 复用 bom 字段存明细行 (UI 统一读)
            key_dimensions=[],
            field_confidences=field_confidences,
        )

    def _build_drawing_result(
        self,
        data: dict,
        raw_text: str,
        field_confidences: dict,
        extra_raw: Any,
    ) -> ExtractionResult:
        """图纸特化解析 (标题栏 + BOM + 修订履历; 尺寸已移除)。"""
        try:
            drawing = MechanicalDrawing.model_validate(data)
        except Exception as e:
            logger.warning(
                "JSON 解析为 MechanicalDrawing 失败: type={}",
                e.__class__.__name__,
            )
            return ExtractionResult(
                fields=[ExtractedField(name="raw_fallback", value=raw_text)],
                raw_text=raw_text,
            )

        fields: list[ExtractedField] = []
        for name, value in drawing.title_block.model_dump().items():
            fields.append(ExtractedField(name=f"title_block.{name}", value=value))
        fields.append(ExtractedField(name="bom.item_count", value=len(drawing.bom)))
        fields.append(
            ExtractedField(name="revision_history.item_count", value=len(drawing.revision_history))
        )
        fields.append(
            ExtractedField(name="technical_requirements", value=drawing.technical_requirements)
        )

        bom_list = [item.model_dump() for item in drawing.bom]
        # 修订履历作为明细放进 bom 字段 (UI 通用渲染: BOM 表 + 修订履历表)
        # 修订履历单独存一份, 便于 UI 区分展示
        revision_list = [rev.model_dump() for rev in drawing.revision_history]
        extra_fields = self._build_extra_fields(extra_raw)

        return ExtractionResult(
            fields=fields,
            extra_fields=extra_fields,
            raw_text=raw_text,
            bom=bom_list,
            # 复用 key_dimensions 字段存修订履历 (避免改 ScoredResult schema;
            # UI 层按 doc_type 渲染时区分: drawing 时 key_dimensions 渲染为修订履历表)
            key_dimensions=revision_list,
            field_confidences=field_confidences,
        )

    def _build_extra_fields(self, extra_raw: Any) -> list[ExtractedField]:
        """从大模型输出的 extra 对象提取动态补充字段。

        extra 形如 {"字段名": "值"}。非 dict 或空则返回 []。
        """
        if not isinstance(extra_raw, dict) or not extra_raw:
            return []
        result: list[ExtractedField] = []
        for name, value in extra_raw.items():
            result.append(ExtractedField(name=str(name), value=value))
        return result

