"""压缩包解压器 (含安全防护)。

支持 zip / tar / tar.gz / tgz。提供:
  - zip-slip 防护 (校验解压目标路径不逃逸出解压目录)
  - 解压总大小上限 (防 zip bomb)
  - 扩展名白名单过滤
  - 解压后返回内部文件列表 (相对路径)
"""
from __future__ import annotations

import logging
import tarfile
import zipfile
from pathlib import Path
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class ArchiveError(Exception):
    """解压相关错误 (格式不支持/安全违规/超限)。"""


@dataclass
class ArchiveConfig:
    """解压安全配置。"""

    max_total_uncompressed: int = 5 * 1024 * 1024 * 1024  # 5GB
    allowed_extensions: list[str] = None  # None = 不过滤

    def __post_init__(self):
        if self.allowed_extensions is not None:
            self.allowed_extensions = [e.lower().lstrip(".") for e in self.allowed_extensions]


def _check_path_safe(target: Path, base: Path) -> None:
    """防 zip-slip: 确保解压目标路径在 base 目录内。"""
    base_resolved = base.resolve()
    target_resolved = target.resolve()
    try:
        target_resolved.relative_to(base_resolved)
    except ValueError:
        raise ArchiveError(f"安全违规: 路径逃逸出解压目录: {target}")


def _is_allowed(name: str, config: ArchiveConfig) -> bool:
    """文件名是否在白名单内 (按扩展名)。"""
    if config.allowed_extensions is None:
        return True
    ext = Path(name).suffix.lower().lstrip(".")
    return ext in config.allowed_extensions


def extract_archive(
    archive_path: str | Path,
    dest_dir: str | Path,
    config: ArchiveConfig | None = None,
) -> list[Path]:
    """解压压缩包到 dest_dir, 返回解压出的文件路径列表。

    - 自动识别 zip / tar / tar.gz / tgz
    - 嵌套压缩包不解压 (只解一层; 内部压缩包作为普通文件保留, 由后续逻辑处理)
    - 跳过目录条目, 只返回文件
    - 安全校验失败或超限抛 ArchiveError
    """
    config = config or ArchiveConfig()
    archive_path = Path(archive_path)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    name = archive_path.name.lower()
    extracted: list[Path] = []
    total_size = 0

    if name.endswith(".zip"):
        extracted, total_size = _extract_zip(archive_path, dest_dir, config, total_size)
    elif name.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2")):
        extracted, total_size = _extract_tar(archive_path, dest_dir, config, total_size)
    else:
        raise ArchiveError(f"不支持的压缩包格式: {archive_path.name}")

    logger.info(
        f"解压完成: {archive_path.name} → {len(extracted)} 个文件, 总大小 {total_size} 字节"
    )
    return extracted


def _extract_zip(
    archive_path: Path, dest_dir: Path, config: ArchiveConfig, total_size: int
) -> tuple[list[Path], int]:
    extracted: list[Path] = []
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                if not _is_allowed(info.filename, config):
                    logger.debug(f"跳过白名单外文件: {info.filename}")
                    continue
                target = dest_dir / info.filename
                _check_path_safe(target, dest_dir)
                total_size += info.file_size
                if total_size > config.max_total_uncompressed:
                    raise ArchiveError(
                        f"解压总大小超限 ({total_size} > {config.max_total_uncompressed}), 疑似 zip bomb"
                    )
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                extracted.append(target)
    except zipfile.BadZipFile as e:
        raise ArchiveError(f"损坏的 zip 文件: {e}") from e
    return extracted, total_size


def _extract_tar(
    archive_path: Path, dest_dir: Path, config: ArchiveConfig, total_size: int
) -> tuple[list[Path], int]:
    extracted: list[Path] = []
    try:
        with tarfile.open(archive_path, "r:*") as tf:
            for member in tf.getmembers():
                if not member.isfile():
                    continue
                if not _is_allowed(member.name, config):
                    logger.debug(f"跳过白名单外文件: {member.name}")
                    continue
                target = dest_dir / member.name
                _check_path_safe(target, dest_dir)
                total_size += member.size
                if total_size > config.max_total_uncompressed:
                    raise ArchiveError(
                        f"解压总大小超限 ({total_size} > {config.max_total_uncompressed})"
                    )
                target.parent.mkdir(parents=True, exist_ok=True)
                src = tf.extractfile(member)
                if src is None:
                    continue
                with src, open(target, "wb") as dst:
                    dst.write(src.read())
                extracted.append(target)
    except tarfile.TarError as e:
        raise ArchiveError(f"损坏的 tar 文件: {e}") from e
    return extracted, total_size


def is_archive(filename: str) -> bool:
    """文件名是否是受支持的压缩包格式。"""
    name = filename.lower()
    return name.endswith((".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2"))
