"""批量上传 + 压缩包解压编排。

职责:
  - 多文件上传: 每个文件建一个子任务, 并发派生处理
  - 压缩包上传: 解压后内部每个文件建子任务
  - 父任务: 记录所有 child_ids, 聚合状态 (created→extracting→done)
  - 并发限流: asyncio.Semaphore(max_concurrent)

父子关系:
  父任务 TaskState.child_ids = [子 task_id, ...], parent_id=""
  子任务 TaskState.parent_id = 父 task_id
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import logging
import uuid
from collections.abc import Mapping
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from ..core.config import settings
from ..state import TaskState, TaskStatus
from .batch_finalization import BatchFinalizationMixin
from .batch_status import _BATCH_TERMINAL_STATUSES, _SUPPORTED_DOCUMENT_KINDS

logger = logging.getLogger(__name__)


class BatchOrchestrator(BatchFinalizationMixin):
    """批量任务编排器。

    依赖外部传入的 spawn_fn (创建子任务后台推进) 和 store (持久化)。
    spawn_fn 签名: async (state: TaskState) -> None, 内部会调 main._spawn。
    这样可复用 main.py 的后台推进, 且测试时可 mock。
    """

    def __init__(
        self,
        store,
        spawn_fn,
        semaphore: Optional[asyncio.Semaphore] = None,
        *,
        task_registry: Mapping[str, asyncio.Task[Any]] | None = None,
        child_wait_timeout: float = 60.0 * 60.0,
        poll_interval: float = 0.25,
    ):
        self.store = store
        self.spawn_fn = spawn_fn
        self.semaphore = semaphore or asyncio.Semaphore(settings.max_concurrent)
        # The batch layer receives the API-owned optimisation explicitly.  It
        # remains correct with an empty registry because persisted child state
        # is the source of truth; this avoids a reverse ingest -> API import.
        self.task_registry = task_registry if task_registry is not None else {}
        self.child_wait_timeout = max(float(child_wait_timeout), 0.001)
        self.poll_interval = max(float(poll_interval), 0.001)

    async def ingest_files(
        self,
        files: list[tuple[str, bytes]],
        parent_filename: str = "batch",
        *,
        doc_type_hint: str = "",
        document_subtype_hint: str = "",
        semantic_enrichment: bool = True,
        tenant_id: str = "default",
    ) -> TaskState:
        """处理一批已读入内存的文件 [(filename, content), ...]。

        压缩包会先解压, 内部文件逐个建子任务; 普通文件直接建子任务。
        立即返回父任务 state (不等子任务派生完成), 子任务后台并发处理。
        """
        parent_id = uuid.uuid4().hex[:12]
        parent_dir = settings.upload_path / parent_id
        parent_dir.mkdir(parents=True, exist_ok=True)

        # 先创建父任务并落库 (立即返回给调用方, 不阻塞)
        parent_state = TaskState(
            task_id=parent_id,
            tenant_id=tenant_id,
            file_path="",
            file_type="batch",
            original_filename=parent_filename,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            status=TaskStatus.EXTRACTING,
            folder_path=str(parent_dir),
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        await self.store.save(parent_state)

        # 后台异步完成: 解压 + 建子任务 + 派生 + 聚合 + 汇总 (不阻塞 ingest_files 返回)
        child_ids = await self._process_files_async(parent_state, parent_dir, files)
        parent_state.child_ids = child_ids
        parent_state.batch_fanout_complete = True
        await self.store.save(parent_state)
        self._last_finalize_task = asyncio.create_task(
            self._wait_children_and_finalize(parent_state, child_ids)
        )
        return parent_state

    async def ingest_archive_path(
        self,
        archive_path: str | Path,
        *,
        parent_filename: str,
        doc_type_hint: str = "",
        document_subtype_hint: str = "",
        semantic_enrichment: bool = True,
        tenant_id: str = "default",
    ) -> TaskState:
        """磁盘流式上传后的归档入口；立即返回，解压和子任务均在后台执行。"""
        parent_id = uuid.uuid4().hex[:12]
        parent_dir = settings.upload_path / parent_id
        parent_dir.mkdir(parents=True, exist_ok=True)
        parent_state = TaskState(
            task_id=parent_id,
            tenant_id=tenant_id,
            file_path=str(archive_path),
            file_type="batch",
            original_filename=parent_filename,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            status=TaskStatus.EXTRACTING,
            processing_stage="archive_queued",
            folder_path=str(parent_dir),
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        await self.store.save(parent_state)
        self._last_finalize_task = asyncio.create_task(
            self._process_archive_path_async(parent_state, parent_dir, Path(archive_path))
        )
        return parent_state

    async def ingest_paths(
        self,
        files: list[tuple[str, str | Path]],
        *,
        parent_filename: str = "batch_upload",
        doc_type_hint: str = "",
        document_subtype_hint: str = "",
        semantic_enrichment: bool = True,
        tenant_id: str = "default",
    ) -> TaskState:
        """Queue files already streamed to disk without loading them into memory."""

        parent_id = uuid.uuid4().hex[:12]
        parent_dir = settings.upload_path / parent_id
        parent_dir.mkdir(parents=True, exist_ok=True)
        parent_state = TaskState(
            task_id=parent_id,
            tenant_id=tenant_id,
            file_path="",
            file_type="batch",
            original_filename=parent_filename,
            doc_type_hint=doc_type_hint,
            document_subtype_hint=document_subtype_hint,
            semantic_enrichment=semantic_enrichment,
            status=TaskStatus.EXTRACTING,
            processing_stage="batch_queued",
            folder_path=str(parent_dir),
            batch_inputs=[
                {"filename": name, "path": str(path)} for name, path in files
            ],
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        await self.store.save(parent_state)
        normalized = [(name, Path(path)) for name, path in files]
        self._last_finalize_task = asyncio.create_task(
            self._process_paths_async(parent_state, parent_dir, normalized)
        )
        return parent_state

    def resume(self, parent_state: TaskState) -> asyncio.Task:
        """Resume a persisted queued/extracting parent after service restart."""

        # Recovery used to blindly repeat archive expansion whenever a parent
        # was found in a non-terminal state.  A process can crash after child
        # rows have been committed but before the parent row is updated; doing
        # the expansion again then created duplicate children.  First inspect
        # both the parent snapshot and persisted child rows and resume the
        # existing fan-in whenever either contains children.
        async def _resume_parent() -> None:
            persisted = await self._load_children(parent_state.task_id, parent_state.child_ids)
            persisted_ids = [child.task_id for child in persisted]
            child_ids = list(dict.fromkeys(parent_state.child_ids + persisted_ids))
            fanout_complete = (
                parent_state.batch_fanout_complete
                or bool(parent_state.child_ids)  # legacy parents predate the marker
                or (
                    parent_state.processing_stage
                    in {
                        "archive_children_running",
                        "batch_children_running",
                        "needs_review",
                        "completed",
                    }
                )
            )
            if parent_state.status in _BATCH_TERMINAL_STATUSES:
                if child_ids and parent_state.batch_summary_status in {"", "pending"}:
                    parent_state.child_ids = child_ids
                    children = await self._load_children(
                        parent_state.task_id, child_ids
                    )
                    # A previous process may have reached its inactivity
                    # deadline while children continued durably.  Recompute
                    # the parent from current child truth before regenerating
                    # the summary; genuine child failures remain failures.
                    await self._aggregate_parent(
                        parent_state, child_ids, children
                    )
                    await self._sync_parent_document_outcome(
                        parent_state, children
                    )
                    parent_state.batch_summary_status = "pending"
                    await self.store.save(parent_state)
                    await self._generate_summary_async(parent_state.task_id, child_ids)
                return
            if child_ids and fanout_complete:
                parent_state.child_ids = child_ids
                parent_state.batch_fanout_complete = True
                parent_state.processing_stage = (
                    "archive_children_running"
                    if parent_state.file_path
                    else "batch_children_running"
                )
                await self.store.save(parent_state)
                await self._wait_children_and_finalize(parent_state, child_ids)
                return

            parent_dir = Path(parent_state.folder_path)
            if parent_state.file_path:
                await self._process_archive_path_async(
                    parent_state, parent_dir, Path(parent_state.file_path)
                )
            elif parent_state.batch_inputs:
                files = [
                    (item.get("filename", "upload.bin"), Path(item.get("path", "")))
                    for item in parent_state.batch_inputs
                ]
                await self._process_paths_async(parent_state, parent_dir, files)
            else:
                parent_state.status = TaskStatus.FAILED
                parent_state.processing_stage = "failed"
                parent_state.error = "Batch recovery metadata is missing"
                await self.store.save(parent_state)

        task = asyncio.create_task(_resume_parent())
        self._last_finalize_task = task
        return task

    async def _process_paths_async(
        self,
        parent_state: TaskState,
        parent_dir: Path,
        files: list[tuple[str, Path]],
    ) -> None:
        """Extract disk-backed archives and dispatch leaf parsing in the background."""

        from ..documents.adapters.archive import (
            ArchiveLimits,
            extract_archive,
            looks_like_archive_name,
        )

        try:
            parent_state.processing_stage = "batch_expanding"
            await self.store.save(parent_state)
            limits = ArchiveLimits(
                max_archive_size=settings.max_archive_size,
                max_total_uncompressed=settings.max_total_uncompressed,
                max_single_file=settings.max_single_uncompressed,
                max_entries=settings.max_archive_entries,
                max_compression_ratio=settings.max_compression_ratio,
                max_recursion_depth=settings.max_archive_recursion,
            )
            child_files: list[tuple[str, Path, str, str]] = []
            failed_ids: list[str] = []
            for index, (filename, path) in enumerate(files):
                if not path.is_file():
                    failed_ids.append(
                        await self._record_failed_child(
                            path,
                            filename,
                            parent_state.task_id,
                            error="Uploaded batch file is missing from staging.",
                        )
                    )
                    continue
                kind = _detect_ingest_kind(path)
                if kind == "archive" or (
                    kind == "unknown" and looks_like_archive_name(filename)
                ):
                    try:
                        result = await asyncio.to_thread(
                            extract_archive,
                            path,
                            parent_dir / "contents" / f"archive_{index:04d}",
                            limits,
                        )
                    except Exception as exc:  # noqa: BLE001 - isolate batch members
                        failed_ids.append(
                            await self._record_failed_child(
                                path,
                                filename,
                                parent_state.task_id,
                                error=f"Archive expansion failed: {exc.__class__.__name__}",
                            )
                        )
                        continue
                    records = _archive_leaf_records(result, root_archive_name=filename)
                    child_files.extend(records)
                    supported = {record[1].resolve() for record in records}
                    for leaf in result.leaf_files:
                        if leaf.resolve() in supported:
                            continue
                        relative = leaf.relative_to(result.destination).as_posix()
                        failed_ids.append(
                            await self._record_failed_child(
                                leaf,
                                relative,
                                parent_state.task_id,
                                error="Unsupported archive member content.",
                                archive_path=f"{filename}!/{relative}",
                            )
                        )
                elif kind in _SUPPORTED_DOCUMENT_KINDS:
                    child_files.append((filename, path, filename, ""))
                else:
                    failed_ids.append(
                        await self._record_failed_child(
                            path,
                            filename,
                            parent_state.task_id,
                            error=f"Unsupported or damaged upload content ({kind}).",
                        )
                    )

            spawned_ids = failed_ids + [
                await self._spawn_child(
                    path,
                    filename,
                    parent_state.task_id,
                    display_filename=display_filename,
                    archive_path=archive_path,
                    doc_type_hint=parent_state.doc_type_hint,
                    document_subtype_hint=parent_state.document_subtype_hint,
                    semantic_enrichment=parent_state.semantic_enrichment,
                    start=False,
                )
                for filename, path, display_filename, archive_path in child_files
            ]
            persisted = await self._load_children(parent_state.task_id, parent_state.child_ids)
            child_ids = list(
                dict.fromkeys(
                    [child.task_id for child in persisted]
                    + list(parent_state.child_ids)
                    + spawned_ids
                )
            )
            parent_state.child_ids = child_ids
            parent_state.batch_fanout_complete = True
            parent_state.processing_stage = "batch_children_running"
            await self.store.save(parent_state)
            await self._start_prepared_children(child_ids)
            await self._wait_children_and_finalize(parent_state, child_ids)
        except Exception as exc:  # noqa: BLE001 - parent must reach an explicit terminal state
            parent_state.status = TaskStatus.FAILED
            parent_state.processing_stage = "failed"
            parent_state.error = f"{exc.__class__.__name__}: {exc}"
            await self.store.save(parent_state)
            logger.exception("Disk-backed batch %s failed", parent_state.task_id)

    async def _process_archive_path_async(
        self, parent_state: TaskState, parent_dir: Path, archive_path: Path
    ) -> None:
        from ..documents.adapters.archive import ArchiveLimits, extract_archive

        try:
            parent_state.processing_stage = "archive_extracting"
            await self.store.save(parent_state)
            limits = ArchiveLimits(
                max_archive_size=settings.max_archive_size,
                max_total_uncompressed=settings.max_total_uncompressed,
                max_single_file=settings.max_single_uncompressed,
                max_entries=settings.max_archive_entries,
                max_compression_ratio=settings.max_compression_ratio,
                max_recursion_depth=settings.max_archive_recursion,
            )
            result = await asyncio.to_thread(
                extract_archive, archive_path, parent_dir / "contents", limits
            )
            await self._persist_archive_parent_document(parent_state, result)
            spawned_ids: list[str] = []
            records = _archive_leaf_records(
                result, root_archive_name=parent_state.original_filename
            )
            for filename, path, display_filename, member_path in records:
                spawned_ids.append(
                    await self._spawn_child(
                        path,
                        filename,
                        parent_state.task_id,
                        display_filename=display_filename,
                        archive_path=member_path,
                        doc_type_hint=parent_state.doc_type_hint,
                        document_subtype_hint=parent_state.document_subtype_hint,
                        semantic_enrichment=parent_state.semantic_enrichment,
                        start=False,
                    )
                )
            supported = {record[1].resolve() for record in records}
            for leaf in result.leaf_files:
                if leaf.resolve() in supported:
                    continue
                relative = leaf.relative_to(result.destination).as_posix()
                spawned_ids.append(
                    await self._record_failed_child(
                        leaf,
                        relative,
                        parent_state.task_id,
                        error="Unsupported archive member content.",
                        archive_path=(
                            f"{parent_state.original_filename}!/{relative}"
                        ),
                    )
                )
            persisted = await self._load_children(parent_state.task_id, parent_state.child_ids)
            child_ids = list(
                dict.fromkeys(
                    [child.task_id for child in persisted]
                    + list(parent_state.child_ids)
                    + spawned_ids
                )
            )
            parent_state.child_ids = child_ids
            parent_state.batch_fanout_complete = True
            parent_state.processing_stage = "archive_children_running"
            await self.store.save(parent_state)
            await self._start_prepared_children(child_ids)
            await self._wait_children_and_finalize(parent_state, child_ids)
        except Exception as exc:  # noqa: BLE001 - 父任务必须有明确终态/原因
            parent_state.status = TaskStatus.FAILED
            parent_state.processing_stage = "failed"
            parent_state.error = f"{exc.__class__.__name__}: {exc}"
            await self.store.save(parent_state)
            logger.exception("归档任务 %s 失败", parent_state.task_id)

    async def _process_files_async(
        self,
        parent_state: TaskState,
        parent_dir: Path,
        files: list[tuple[str, bytes]],
    ) -> list[str]:
        """后台处理: 解压/落盘 → 建子任务 → 派生 → 聚合 → 汇总。"""
        from ..documents.adapters.archive import (
            ArchiveAdapterError,
            ArchiveLimits,
            extract_archive,
            looks_like_archive_name,
        )

        child_ids: list[str] = []

        # 第一阶段: 解压/落盘所有文件
        child_files: list[tuple[str, Path, str, str]] = []
        for filename, content in files:
            ext = Path(filename).suffix or ".bin"
            staged_path = parent_dir / f"{uuid.uuid4().hex[:12]}{ext}"
            with open(staged_path, "wb") as f:
                f.write(content)
            kind = _detect_ingest_kind(staged_path)
            if kind == "archive" or (
                kind == "unknown" and looks_like_archive_name(filename)
            ):
                limits = ArchiveLimits(
                    max_archive_size=settings.max_archive_size,
                    max_total_uncompressed=settings.max_total_uncompressed,
                    max_single_file=settings.max_single_uncompressed,
                    max_entries=settings.max_archive_entries,
                    max_compression_ratio=settings.max_compression_ratio,
                    max_recursion_depth=settings.max_archive_recursion,
                )
                try:
                    result = await asyncio.to_thread(
                        extract_archive, staged_path, parent_dir / "contents", limits
                    )
                    inner = _archive_leaf_records(
                        result,
                        root_archive_name=filename,
                    )
                except ArchiveAdapterError as e:
                    child_ids.append(
                        await self._record_failed_child(
                            staged_path,
                            filename,
                            parent_state.task_id,
                            error=f"Archive expansion failed: {e.__class__.__name__}",
                        )
                    )
                    continue
                child_files.extend(inner)
                supported = {record[1].resolve() for record in inner}
                for leaf in result.leaf_files:
                    if leaf.resolve() in supported:
                        continue
                    relative = leaf.relative_to(result.destination).as_posix()
                    child_ids.append(
                        await self._record_failed_child(
                            leaf,
                            relative,
                            parent_state.task_id,
                            error="Unsupported archive member content.",
                            archive_path=f"{filename}!/{relative}",
                        )
                    )
            elif kind in _SUPPORTED_DOCUMENT_KINDS:
                child_files.append((filename, staged_path, filename, ""))
            else:
                child_ids.append(
                    await self._record_failed_child(
                        staged_path,
                        filename,
                        parent_state.task_id,
                        error=f"Unsupported or damaged upload content ({kind}).",
                    )
                )

        # 第二阶段: 为每个子文件建任务 + 派生
        for filename, path, display_filename, archive_path in child_files:
            cid = await self._spawn_child(
                path,
                filename,
                parent_state.task_id,
                display_filename=display_filename,
                archive_path=archive_path,
                doc_type_hint=parent_state.doc_type_hint,
                document_subtype_hint=parent_state.document_subtype_hint,
                semantic_enrichment=parent_state.semantic_enrichment,
            )
            child_ids.append(cid)

        # 更新父任务的 child_ids
        return child_ids


    @property
    def last_finalize_task(self):
        """最近一次 ingest_files 启动的聚合任务 (测试用, 生产忽略)。"""
        return getattr(self, "_last_finalize_task", None)

    async def _spawn_child(
        self,
        save_path: Path,
        filename: str,
        parent_id: str,
        *,
        display_filename: str = "",
        archive_path: str = "",
        doc_type_hint: str = "",
        document_subtype_hint: str = "",
        semantic_enrichment: bool = True,
        start: bool = True,
    ) -> str:
        """创建子任务 state, 落库, 信号量限流后派生。返回 child task_id。"""
        cid = _child_task_id(parent_id, save_path)
        parent = await self.store.load(parent_id)
        tenant_id = getattr(parent, "tenant_id", "default") if parent else "default"
        state = await self.store.load(cid)
        if state is None:
            # Compatibility with parents created before stable child IDs were
            # introduced: reuse a persisted row that points at the same staged
            # file instead of creating a duplicate deterministic row.
            list_by_parent = getattr(self.store, "list_by_parent", None)
            if callable(list_by_parent):
                target_path = save_path.resolve()
                for candidate in await list_by_parent(parent_id):
                    try:
                        same_path = Path(candidate.file_path).resolve() == target_path
                    except (OSError, RuntimeError):
                        same_path = candidate.file_path == str(save_path)
                    if same_path:
                        state = candidate
                        cid = candidate.task_id
                        break
        if state is None:
            state = TaskState(
                task_id=cid,
                tenant_id=tenant_id,
                file_path=str(save_path),
                original_filename=filename,
                display_filename=display_filename or filename,
                archive_path=archive_path,
                doc_type_hint=doc_type_hint,
                document_subtype_hint=document_subtype_hint,
                semantic_enrichment=semantic_enrichment,
                parent_id=parent_id,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
            await self.store.save(state)
        elif state.status in _BATCH_TERMINAL_STATUSES:
            return cid
        else:
            # Preserve partial parser state/results, but refresh provenance in
            # case filename repair rules changed between process versions.
            state.file_path = str(save_path)
            state.tenant_id = tenant_id
            state.original_filename = filename
            state.display_filename = display_filename or filename
            state.archive_path = archive_path
            state.doc_type_hint = doc_type_hint
            state.document_subtype_hint = document_subtype_hint
            state.semantic_enrichment = semantic_enrichment
            state.parent_id = parent_id
            await self.store.save(state)
        if not start:
            return cid
        await self._dispatch_child(state)
        return cid

    async def _dispatch_child(self, state: TaskState) -> None:
        """Start a prepared child while keeping the real parse/VLM semaphore."""

        # 主 API 的 _spawn 接受 semaphore 并让它覆盖真实解析/VLM 生命周期；
        # 测试或第三方 spawn_fn 若没有该参数，则退回同步限流兼容路径。
        parameters = inspect.signature(self.spawn_fn).parameters
        if "semaphore" in parameters:
            spawned = self.spawn_fn(state, semaphore=self.semaphore)
            if asyncio.iscoroutine(spawned):
                await spawned
        else:
            async with self.semaphore:
                spawned = self.spawn_fn(state)
                if asyncio.iscoroutine(spawned):
                    await spawned

    async def _start_prepared_children(self, child_ids: list[str]) -> None:
        """Dispatch only after fan-out identities are durable on the parent."""

        for child_id in child_ids:
            state = await self.store.load(child_id)
            if state is None or state.status in _BATCH_TERMINAL_STATUSES:
                continue
            await self._dispatch_child(state)

    async def _record_failed_child(
        self,
        path: Path,
        filename: str,
        parent_id: str,
        *,
        error: str,
        archive_path: str = "",
    ) -> str:
        """Give every rejected batch input a durable, queryable terminal row."""

        child_id = _child_task_id(parent_id, path)
        parent = await self.store.load(parent_id)
        tenant_id = getattr(parent, "tenant_id", "default") if parent else "default"
        existing = await self.store.load(child_id)
        if existing is not None and existing.status in _BATCH_TERMINAL_STATUSES:
            return child_id
        state = existing or TaskState(
            task_id=child_id,
            tenant_id=tenant_id,
            file_path=str(path),
            original_filename=filename,
            display_filename=filename,
            archive_path=archive_path,
            parent_id=parent_id,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        state.file_type = _detect_ingest_kind(path) if path.is_file() else "unknown"
        state.tenant_id = tenant_id
        state.status = TaskStatus.FAILED
        state.processing_stage = "failed"
        state.error = error[:1000]
        await self.store.save(state)
        return child_id

async def refresh_parent_status(store: Any, parent_id: str) -> TaskState | None:
    """Recompute a batch parent after a child status changes (for example HITL).

    Child review happens outside the batch worker, so the worker's initial
    fan-in cannot observe the later ``needs_review -> done`` transition.  This
    helper updates the parent from persisted rows and regenerates the summary
    once all children are terminal.  It is intentionally idempotent and safe
    to call after every child review.
    """

    parent = await store.load(parent_id)
    if parent is None:
        return None
    list_by_parent = getattr(store, "list_by_parent", None)
    children = await list_by_parent(parent_id) if callable(list_by_parent) else []
    ids = list(
        dict.fromkeys(list(parent.child_ids) + [child.task_id for child in children])
    )
    if not ids:
        parent.status = TaskStatus.FAILED
        parent.processing_stage = "failed"
        parent.error = "Batch has no child tasks"
        await store.save(parent)
        return parent

    # Reuse the same aggregation and summary implementation as the worker.
    orchestrator = BatchOrchestrator(store, lambda *_args, **_kwargs: None)
    by_id = {child.task_id: child for child in children}
    for child_id in ids:
        if child_id not in by_id:
            child = await store.load(child_id)
            if child is not None:
                by_id[child_id] = child
    ordered = [by_id[child_id] for child_id in ids if child_id in by_id]
    if len(ordered) < len(ids) or not all(
        child.status in _BATCH_TERMINAL_STATUSES for child in ordered
    ):
        parent.child_ids = ids
        parent.status = TaskStatus.EXTRACTING
        parent.processing_stage = "batch_children_running"
        await store.save(parent)
        return parent

    parent.child_ids = ids
    await orchestrator._aggregate_parent(parent, ids, ordered)
    await orchestrator._sync_parent_document_outcome(parent, ordered)
    parent.batch_summary_status = "pending"
    await store.save(parent)
    await orchestrator._generate_summary_async(parent_id, ids)
    return await store.load(parent_id) or parent


def _archive_leaf_records(
    result: Any, *, root_archive_name: str = ""
) -> list[tuple[str, Path, str, str]]:
    """Join physical leaf paths back to raw/display/archive provenance."""

    entries = {
        str(entry.stored_relative_path): entry
        for entry in result.entries
        if entry.stored_relative_path and not entry.ignored and not entry.duplicate_of
    }
    records: list[tuple[str, Path, str, str]] = []
    for leaf in result.leaf_files:
        if _detect_ingest_kind(leaf) not in _SUPPORTED_DOCUMENT_KINDS:
            continue
        relative = leaf.relative_to(result.destination).as_posix()
        entry = entries.get(relative)
        root_label = root_archive_name or result.archive_path.name
        if entry is None:
            records.append((relative, leaf, relative, f"{root_label}!/{relative}"))
            continue
        entry_archive = str(entry.archive_path)
        physical_root = result.archive_path.name
        if root_archive_name and (
            entry_archive == physical_root
            or entry_archive.startswith(f"{physical_root}!/")
        ):
            entry_archive = root_archive_name + entry_archive[len(physical_root) :]
        archive_member = f"{entry_archive}!/{entry.raw_name}"
        records.append((entry.raw_name, leaf, entry.display_name, archive_member))
    return records


def _detect_ingest_kind(path: Path) -> str:
    """Classify staged content by magic before trusting a filename suffix.

    ParserRouter distinguishes ZIP-based OOXML documents from ordinary ZIP
    archives.  The archive adapter adds TAR detection, which does not have a
    fixed short signature.  A bogus ``.jpg`` therefore remains ``unknown`` and
    is never dispatched to an image decoder or VLM.
    """

    from ..documents.adapters.archive import is_archive
    from ..parsers.router import ParserRouter

    kind = ParserRouter().detect_type(path)
    if kind in _SUPPORTED_DOCUMENT_KINDS or kind == "archive":
        return kind
    if is_archive(path):
        return "archive"
    return "unknown"


def _child_task_id(parent_id: str, save_path: Path) -> str:
    """Stable child identity makes fan-out safe to replay after a restart."""

    identity = f"{parent_id}\0{save_path.resolve()}"
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()[:12]
