"""Durable fan-in and reporting stages for :class:`BatchOrchestrator`."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

from ..state import TaskState, TaskStatus
from .batch_status import _BATCH_TERMINAL_STATUSES

# Preserve the original log channel after moving implementation methods out of
# ``batch.py``; operational filters may key on this exact logger name.
logger = logging.getLogger(f"{__package__}.batch")


class BatchFinalizationMixin:
    """Behavior-preserving implementation split for batch parent finalization."""

    async def _persist_archive_parent_document(
        self, parent_state: TaskState, result: Any
    ) -> None:
        """Persist an auditable v2 manifest for an uploaded archive parent."""

        from ..documents import DocumentRecord
        from ..documents.adapters.common import build_document_record, source_payload

        archive_path = Path(parent_state.file_path)
        mime_type = {
            "zip": "application/zip",
            "tar": "application/x-tar",
            "rar": "application/vnd.rar",
            "7z": "application/x-7z-compressed",
        }.get(str(result.archive_type), "application/octet-stream")
        source = source_payload(
            archive_path,
            original_filename=parent_state.original_filename or archive_path.name,
            mime_type=mime_type,
        )
        sections = [
            {
                "kind": "archive_entry",
                "index": index,
                "source_ref": f"archive:{entry.archive_path}!/{entry.raw_name}",
                "content": asdict(entry),
            }
            for index, entry in enumerate(result.entries)
        ]
        record = build_document_record(
            source=source,
            document_type="archive",
            document_subtype="archive",
            sections=sections,
            raw_content=result.to_dict(),
            metadata={
                "adapter": f"archive-{result.archive_type}",
                "leaf_document_count": len(result.leaf_files),
                "total_entries": result.total_entries,
                "total_uncompressed": result.total_uncompressed,
                "duplicate_count": result.duplicate_count,
                "ignored_count": result.ignored_count,
                "deduplicated_by": "sha256",
            },
        )
        document = DocumentRecord.model_validate(record).model_dump(mode="json")
        parent_state.document = document
        parent_state.document_schema_version = "m1.document.v2"
        parent_state.doc_type = "archive"
        parent_state.document_subtype = "archive"
        parent_state.parsed_content = (
            f"Archive {parent_state.original_filename}: "
            f"{result.total_entries} entries, {len(result.leaf_files)} supported leaves"
        )
        await self.store.save_document(parent_state.task_id, document)
        await self.store.save(parent_state)

    async def _sync_parent_document_outcome(
        self, parent_state: TaskState, children: list[TaskState]
    ) -> None:
        """Reflect child failures or review requirements in the archive manifest."""

        if parent_state.document is None:
            return
        from ..documents import DocumentRecord

        document = dict(parent_state.document)
        issues = [
            issue
            for issue in list(document.get("validation_issues") or [])
            if issue.get("code")
            not in {
                "BATCH_CHILD_FAILED",
                "BATCH_CHILD_NEEDS_REVIEW",
                "BATCH_NO_SUPPORTED_CHILDREN",
            }
        ]
        failed = [
            child.task_id for child in children if child.status == TaskStatus.FAILED
        ]
        review = [
            child.task_id
            for child in children
            if child.status == TaskStatus.NEEDS_REVIEW
        ]
        if failed:
            issues.append(
                {
                    "code": "BATCH_CHILD_FAILED",
                    "severity": "error",
                    "message": "One or more archive members failed to parse.",
                    "paths": ["$.extraction.raw_content.entries"],
                    "actual": failed,
                    "suggestion": "Inspect the failed child tasks for per-file reasons.",
                }
            )
        if parent_state.status == TaskStatus.FAILED and not children:
            issues.append(
                {
                    "code": "BATCH_NO_SUPPORTED_CHILDREN",
                    "severity": "error",
                    "message": "The archive contains no supported document leaves.",
                    "paths": ["$.extraction.raw_content.entries"],
                    "suggestion": "Upload PDF, Office, image, CSV or CAD documents.",
                }
            )
        if review:
            issues.append(
                {
                    "code": "BATCH_CHILD_NEEDS_REVIEW",
                    "severity": "warning",
                    "message": "One or more archive members require review.",
                    "paths": ["$.extraction.raw_content.entries"],
                    "actual": review,
                    "suggestion": (
                        "Review the child documents, then refresh the batch status."
                    ),
                }
            )
        document["validation_issues"] = issues
        document["needs_review"] = bool(failed or review or not children)
        document = DocumentRecord.model_validate(document).model_dump(mode="json")
        parent_state.document = document
        await self.store.save_document(parent_state.task_id, document)

    async def _generate_summary_async(
        self, parent_id: str, child_ids: list[str]
    ) -> None:
        """后台生成跨文档汇总报告, 完成后回写父任务。best-effort。"""
        try:
            from ..reports import build_batch_report

            child_states = []
            for child_id in child_ids:
                state = await self.store.load(child_id)
                if state is not None:
                    child_states.append(state)

            if not child_states:
                logger.warning(f"父任务 {parent_id} 无子任务, 跳过汇总")
                parent = await self.store.load(parent_id)
                if parent:
                    parent.batch_summary_status = "failed"
                    await self.store.save(parent)
                return

            parent = await self.store.load(parent_id)
            if parent:
                report = build_batch_report(parent, child_states)
                parent.batch_summary = report
                parent.batch_summary_status = "done"
                await self.store.save(parent)
                logger.info(
                    f"父任务 {parent_id} 汇总报告生成完成: {len(report)} 字符"
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"父任务 {parent_id} 汇总报告生成失败: {exc}")
            parent = await self.store.load(parent_id)
            if parent:
                parent.batch_summary_status = "failed"
                await self.store.save(parent)

    async def _load_children(
        self, parent_id: str, child_ids: list[str] | None = None
    ) -> list[TaskState]:
        """Load children from the durable store, with a test-store fallback."""

        found: dict[str, TaskState] = {}
        list_by_parent = getattr(self.store, "list_by_parent", None)
        if callable(list_by_parent):
            try:
                for state in await list_by_parent(parent_id):
                    found[state.task_id] = state
            except Exception:  # pragma: no cover - defensive for custom stores
                logger.debug("batch child listing failed", exc_info=True)
        for child_id in child_ids or []:
            if child_id in found:
                continue
            state = await self.store.load(child_id)
            if state is not None:
                found[state.task_id] = state
        return list(found.values())

    async def _aggregate_parent(
        self,
        parent_state: TaskState,
        child_ids: list[str],
        children: list[TaskState],
    ) -> TaskStatus:
        """Compute and persist a parent status from durable child states."""

        expected = set(child_ids)
        observed = {child.task_id for child in children}
        if not child_ids or not expected.issubset(observed):
            status = TaskStatus.FAILED
            parent_state.error = "Batch child state is missing"
        elif any(child.status == TaskStatus.FAILED for child in children):
            status = TaskStatus.FAILED
            failed = [child for child in children if child.status == TaskStatus.FAILED]
            if len(failed) == len(children) and all(
                child.file_type == "unknown" for child in failed
            ):
                parent_state.error = "Batch contains no supported child documents"
            else:
                parent_state.error = f"{len(failed)} batch child task(s) failed"
        elif any(child.status == TaskStatus.NEEDS_REVIEW for child in children):
            status = TaskStatus.NEEDS_REVIEW
        elif all(child.status in _BATCH_TERMINAL_STATUSES for child in children):
            status = TaskStatus.DONE
        else:
            status = TaskStatus.EXTRACTING

        if status != TaskStatus.FAILED:
            parent_state.error = None
        parent_state.status = status
        parent_state.processing_stage = (
            "failed"
            if status == TaskStatus.FAILED
            else "needs_review"
            if status == TaskStatus.NEEDS_REVIEW
            else "completed"
            if status == TaskStatus.DONE
            else "batch_children_running"
        )
        await self.store.save(parent_state)
        return status

    async def _wait_children_and_finalize(
        self, parent_state: TaskState, child_ids: list[str]
    ) -> None:
        """Wait for durable child terminal states and aggregate the parent."""

        expected = list(dict.fromkeys(child_ids))
        parent_state.child_ids = expected
        if not expected:
            parent_state.status = TaskStatus.FAILED
            parent_state.processing_stage = "failed"
            parent_state.error = "Batch contains no supported child documents"
            await self._sync_parent_document_outcome(parent_state, [])
            await self.store.save(parent_state)
            return
        last_progress = time.monotonic()
        terminal_count = -1
        while True:
            children = await self._load_children(parent_state.task_id, expected)
            current_terminal_count = sum(
                child.status in _BATCH_TERMINAL_STATUSES for child in children
            )
            if current_terminal_count > terminal_count:
                terminal_count = current_terminal_count
                last_progress = time.monotonic()
            complete = (
                bool(expected)
                and len({child.task_id for child in children}) >= len(expected)
                and all(child.status in _BATCH_TERMINAL_STATUSES for child in children)
            )
            if complete:
                break

            pending = [
                task
                for child_id in expected
                if (task := self.task_registry.get(child_id)) is not None
                and not task.done()
            ]
            remaining = self.child_wait_timeout - (time.monotonic() - last_progress)
            if remaining <= 0:
                parent_state.status = TaskStatus.FAILED
                parent_state.processing_stage = "failed"
                parent_state.error = "Timed out waiting for persisted batch children"
                await self.store.save(parent_state)
                return
            wait_for = min(self.poll_interval, remaining)
            if pending:
                await asyncio.wait(pending, timeout=wait_for)
            else:
                await asyncio.sleep(wait_for)

        status = await self._aggregate_parent(parent_state, expected, children)
        await self._sync_parent_document_outcome(parent_state, children)
        parent_state.batch_summary_status = "pending"
        await self.store.save(parent_state)
        logger.info(
            "batch parent %s aggregated status=%s children=%d",
            parent_state.task_id,
            status.value,
            len(expected),
        )
        await self._generate_summary_async(parent_state.task_id, expected)
