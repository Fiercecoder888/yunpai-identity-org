"""Shared status and document-kind constants for batch ingestion."""

from ..state import TaskStatus


_BATCH_TERMINAL_STATUSES = {
    TaskStatus.DONE,
    TaskStatus.FAILED,
    TaskStatus.NEEDS_REVIEW,
}

_SUPPORTED_DOCUMENT_KINDS = {
    "image",
    "pdf",
    "xlsx",
    "xlsm",
    "xls",
    "csv",
    "docx",
    "pptx",
    "html",
    "dxf",
    "dwg",
}
