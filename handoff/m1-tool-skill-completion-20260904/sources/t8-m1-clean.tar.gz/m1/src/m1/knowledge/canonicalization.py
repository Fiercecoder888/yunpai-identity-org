"""Deterministic ``m1.document.v2`` to governed master-data candidates.

This module intentionally has no persistence dependency.  It translates one
parsed document into tenant-scoped entity, identity, alias and relationship
candidates that a caller may subsequently submit to :class:`KnowledgeStore`.

Only explicit codes can become active identities.  Names, unresolved
organisation-scoped codes, and values marked as inferred remain reviewable.
Relationships are structural claims backed by source locators; this layer never
creates causal (let alone confirmed-causal) assertions.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections.abc import Mapping
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from m1.documents.models import DocumentRecord, FieldMetadata, SourceReference

from .schema import (
    CanonicalEntityRecord,
    ClaimStatus,
    EntityAliasRecord,
    ExternalIdentityRecord,
    LifecycleStatus,
    RelationshipClaimRecord,
)


_CUSTOM_FIELD_NAMES: dict[str, tuple[str, ...]] = {
    "customer_code": (
        "customer_product_code",
        "customer_material_code",
        "customer_part_number",
        "customer_sku",
        "客户料号",
        "客户物料号",
        "客户产品编码",
        "客户产品代码",
    ),
    "supplier_code": (
        "supplier_product_code",
        "supplier_material_code",
        "supplier_part_number",
        "supplier_sku",
        "供应商料号",
        "供应商物料号",
        "供方料号",
        "供方物料号",
    ),
    "customer_name": ("customer_name", "customer", "客户名称", "客户"),
    "supplier_name": ("supplier_name", "supplier", "供应商名称", "供应商"),
}

_HEADER_PRODUCT_FIELDS: tuple[tuple[str, str], ...] = (
    ("product_code", "product"),
    ("part_number", "product"),
    ("model", "product"),
    ("material_code", "material"),
    ("equipment_code", "equipment"),
    ("mold_code", "mold"),
)

_CAUSAL_TOKEN = re.compile(r"CAUSE|CAUSAL|导致|致因|根因", re.IGNORECASE)


class CanonicalizationResult(BaseModel):
    """Storage-independent, deterministic master-data candidates for one source."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str
    source_record_id: str
    source_version: str = "unversioned"
    document_entity_id: str
    entities: list[CanonicalEntityRecord] = Field(default_factory=list)
    external_identities: list[ExternalIdentityRecord] = Field(default_factory=list)
    aliases: list[EntityAliasRecord] = Field(default_factory=list)
    relationships: list[RelationshipClaimRecord] = Field(default_factory=list)


def _plain(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", exclude_none=True)
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def _canonical_json(value: Any) -> str:
    return json.dumps(
        _plain(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )


def _stable_id(prefix: str, *parts: Any) -> str:
    payload = "\x1f".join(_canonical_json(part) for part in parts)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]
    return f"{prefix}_{digest}"


def _text(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip()


def _token(value: Any) -> str:
    """Canonical-key token that preserves useful punctuation and non-ASCII text."""

    normalized = re.sub(r"\s+", "", _text(value)).casefold()
    # Keys use ``:`` as a structural separator, so escape it (and the escape
    # character) without applying lossy transliteration to Chinese identifiers.
    normalized = normalized.replace("%", "%25").replace(":", "%3a")
    if len(normalized) <= 180:
        return normalized
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:24]
    return f"{normalized[:150]}~{digest}"


def _normalized_field_name(value: Any) -> str:
    return re.sub(r"[\s_\-—/\\:：()（）]+", "", _text(value)).casefold()


def _coerce_document(document: DocumentRecord | Mapping[str, Any] | BaseModel) -> DocumentRecord:
    if isinstance(document, DocumentRecord):
        return document
    if isinstance(document, BaseModel):
        document = document.model_dump(mode="python")
    if not isinstance(document, Mapping):
        raise TypeError("document must be a DocumentRecord or m1.document.v2 mapping")
    return DocumentRecord.model_validate(dict(document))


def _source_record_id(document: DocumentRecord, tenant_id: str) -> str:
    source = document.source
    if re.fullmatch(r"[0-9a-fA-F]{64}", source.sha256 or ""):
        return _stable_id("source", tenant_id, "sha256", source.sha256.lower())
    locator = source.archive_path or source.original_filename or source.display_filename
    return _stable_id("source", tenant_id, "locator", locator, source.mime_type)


def _nearest_metadata(document: DocumentRecord, path: str) -> FieldMetadata | None:
    metadata = document.field_meta.get(path)
    if metadata is not None:
        return metadata
    parents = [
        (candidate, item)
        for candidate, item in document.field_meta.items()
        if path.startswith(f"{candidate}.") or path.startswith(f"{candidate}[")
    ]
    return max(parents, key=lambda item: len(item[0]))[1] if parents else None


def _fallback_refs(document: DocumentRecord) -> list[SourceReference]:
    reference = SourceReference(
        sheet=document.source.sheet,
        page=document.source.page,
        archive_path=document.source.archive_path,
    )
    return [] if not reference.model_dump(exclude_none=True) else [reference]


class _Evidence:
    __slots__ = ("anchor_id", "confidence", "inferred", "path", "refs")

    def __init__(
        self,
        *,
        anchor_id: str,
        confidence: float,
        inferred: bool,
        path: str,
        refs: list[SourceReference],
    ) -> None:
        self.anchor_id = anchor_id
        self.confidence = confidence
        self.inferred = inferred
        self.path = path
        self.refs = refs


class _Canonicalizer:
    def __init__(
        self,
        document: DocumentRecord,
        tenant_id: str,
        source_record_id: str,
        source_version: str,
    ) -> None:
        self.document = document
        self.tenant_id = tenant_id
        self.source_record_id = source_record_id
        self.source_version = source_version
        self.entities: dict[tuple[str, str], CanonicalEntityRecord] = {}
        self.identities: dict[tuple[str, str, str], ExternalIdentityRecord] = {}
        self.aliases: dict[tuple[str, str, str], EntityAliasRecord] = {}
        self.relationships: dict[str, RelationshipClaimRecord] = {}

    def evidence(self, path: str, *, default_confidence: float = 0.9) -> _Evidence:
        metadata = _nearest_metadata(self.document, path)
        refs = list(metadata.source_refs) if metadata and metadata.source_refs else _fallback_refs(
            self.document
        )
        anchor_id = _stable_id(
            "anchor",
            self.tenant_id,
            self.source_record_id,
            path,
            [_plain(reference) for reference in refs],
        )
        return _Evidence(
            anchor_id=anchor_id,
            confidence=metadata.confidence if metadata else default_confidence,
            inferred=bool(metadata and metadata.inferred),
            path=path,
            refs=refs,
        )

    def entity(
        self,
        *,
        entity_type: str,
        canonical_key: str,
        label: str,
        exact: bool,
        evidence: _Evidence,
        attributes: Mapping[str, Any] | None = None,
    ) -> CanonicalEntityRecord:
        key = (entity_type, canonical_key)
        active = exact and not evidence.inferred
        lifecycle = LifecycleStatus.ACTIVE if active else LifecycleStatus.UNDER_REVIEW
        confidence = evidence.confidence if exact else min(evidence.confidence, 0.8)
        existing = self.entities.get(key)
        if existing is not None:
            merged_attributes = dict(existing.attributes)
            if attributes:
                for name, value in attributes.items():
                    if value not in (None, "", [], {}):
                        if name == "observed_roles":
                            existing_roles = merged_attributes.get(name) or []
                            if not isinstance(existing_roles, list):
                                existing_roles = [existing_roles]
                            new_roles = value if isinstance(value, list) else [value]
                            merged_attributes[name] = list(
                                dict.fromkeys(
                                    _text(role)
                                    for role in [*existing_roles, *new_roles]
                                    if _text(role)
                                )
                            )
                        else:
                            merged_attributes.setdefault(name, _plain(value))
            updates: dict[str, Any] = {"attributes": merged_attributes}
            if lifecycle == LifecycleStatus.ACTIVE and existing.lifecycle_status != lifecycle:
                updates.update(lifecycle_status=lifecycle, confidence=confidence)
            self.entities[key] = existing.model_copy(update=updates)
            return self.entities[key]

        entity = CanonicalEntityRecord(
            entity_id=_stable_id("entity", self.tenant_id, entity_type, canonical_key),
            tenant_id=self.tenant_id,
            entity_type=entity_type,
            canonical_key=canonical_key,
            canonical_label=label or canonical_key,
            attributes={
                "source_record_id": self.source_record_id,
                "source_path": evidence.path,
                **(_plain(attributes) if attributes else {}),
            },
            lifecycle_status=lifecycle,
            confidence=confidence,
        )
        self.entities[key] = entity
        return entity

    def identity(
        self,
        entity: CanonicalEntityRecord,
        *,
        source_system: str,
        external_id: str,
        mapping_rule: str,
        evidence: _Evidence,
        exact: bool = True,
    ) -> ExternalIdentityRecord | None:
        external_id = _text(external_id)
        # Malformed spreadsheet regions can place an entire terms paragraph in
        # a model/code column.  It remains preserved in the source document and
        # its review issues, but it is not a valid external identity and must
        # not abort a corpus backfill.
        if not external_id or len(external_id) > 512:
            return None
        status = (
            ClaimStatus.ACCEPTED
            if exact
            and not evidence.inferred
            and entity.lifecycle_status == LifecycleStatus.ACTIVE
            else ClaimStatus.CANDIDATE
        )
        key = (entity.entity_type, source_system, external_id)
        identity = ExternalIdentityRecord(
            identity_id=_stable_id(
                "identity", self.tenant_id, entity.entity_type, source_system, external_id
            ),
            tenant_id=self.tenant_id,
            entity_id=entity.entity_id,
            entity_type=entity.entity_type,
            source_system=source_system[:128],
            external_id=external_id,
            mapping_rule=mapping_rule,
            confidence=evidence.confidence if exact else min(evidence.confidence, 0.8),
            status=status,
            conflicts=[],
        )
        self.identities[key] = identity
        return identity

    def alias(
        self,
        entity: CanonicalEntityRecord,
        alias: Any,
        *,
        source_system: str,
        evidence: _Evidence,
        exact: bool = False,
    ) -> EntityAliasRecord | None:
        text = _text(alias)
        normalized = _text(alias).casefold()
        if not text or not normalized or len(text) > 1024 or len(normalized) > 1024:
            return None
        status = (
            ClaimStatus.ACCEPTED
            if exact
            and not evidence.inferred
            and entity.lifecycle_status == LifecycleStatus.ACTIVE
            else ClaimStatus.CANDIDATE
        )
        key = (entity.entity_id, normalized, source_system)
        record = EntityAliasRecord(
            alias_id=_stable_id("alias", self.tenant_id, *key),
            tenant_id=self.tenant_id,
            entity_id=entity.entity_id,
            alias=text,
            normalized_alias=normalized,
            source_system=source_system[:128],
            confidence=evidence.confidence if exact else min(evidence.confidence, 0.8),
            status=status,
        )
        self.aliases[key] = record
        return record

    def relationship(
        self,
        *,
        from_entity: CanonicalEntityRecord,
        relation_type: str,
        to_entity: CanonicalEntityRecord,
        evidence: _Evidence,
        exact: bool,
        discriminator: Any = None,
        additional_evidence: list[_Evidence] | None = None,
        properties: Mapping[str, Any] | None = None,
    ) -> RelationshipClaimRecord:
        normalized_relation = _text(relation_type).upper()
        if normalized_relation.startswith("CONFIRMED_") or _CAUSAL_TOKEN.search(
            normalized_relation
        ):
            raise ValueError("canonicalization cannot create confirmed or causal relationships")
        if from_entity.entity_id == to_entity.entity_id:
            raise ValueError("canonicalization cannot create a self relationship")
        relation_key = _stable_id(
            "relationship",
            self.tenant_id,
            self.source_record_id,
            self.source_version,
            from_entity.entity_id,
            normalized_relation,
            to_entity.entity_id,
            evidence.path,
            discriminator,
        )
        accepted = (
            exact
            and not evidence.inferred
            and from_entity.lifecycle_status == LifecycleStatus.ACTIVE
            and to_entity.lifecycle_status == LifecycleStatus.ACTIVE
        )
        extras = additional_evidence or []
        payload = {
            "source_record_id": self.source_record_id,
            "version": self.source_version,
            "source_path": evidence.path,
            "source_refs": [_plain(reference) for reference in evidence.refs],
            **(_plain(properties) if properties else {}),
        }
        record = RelationshipClaimRecord(
            relationship_id=relation_key,
            tenant_id=self.tenant_id,
            idempotency_key=relation_key,
            from_entity_id=from_entity.entity_id,
            relation_type=normalized_relation,
            to_entity_id=to_entity.entity_id,
            properties=payload,
            evidence_anchor_id=evidence.anchor_id,
            additional_evidence_anchor_ids=[item.anchor_id for item in extras],
            confidence=min([evidence.confidence, *(item.confidence for item in extras)]),
            status=ClaimStatus.ACCEPTED if accepted else ClaimStatus.CANDIDATE,
        )
        self.relationships[relation_key] = record
        return record


def _mapping_value(
    line: Any, category: str, line_index: int
) -> tuple[str | None, str | None]:
    wanted = {_normalized_field_name(item) for item in _CUSTOM_FIELD_NAMES[category]}
    for container_name in ("custom_fields", "raw_columns"):
        container = getattr(line, container_name, {})
        if not isinstance(container, Mapping):
            continue
        for key, value in container.items():
            if _normalized_field_name(key) in wanted and _text(value):
                encoded_key = json.dumps(str(key), ensure_ascii=False)
                return _text(value), f"$.lines[{line_index}].{container_name}[{encoded_key}]"
    return None, None


_ORGANIZATION_ROLE_PREFIX_RE = re.compile(
    r"^\s*(?:甲\s*方|乙\s*方|买\s*方|卖\s*方|供\s*方|采购\s*方|供应\s*商|"
    r"buyer|seller|supplier)\s*(?:[（(]\s*盖\s*章\s*[）)])?\s*[：:]\s*",
    re.I,
)


def _organization_name(value: Any) -> str:
    return _ORGANIZATION_ROLE_PREFIX_RE.sub("", _text(value), count=1).strip()


def _organization(
    builder: _Canonicalizer,
    name: Any,
    *,
    path: str,
    role: str,
) -> CanonicalEntityRecord | None:
    raw_label = _text(name)
    label = _organization_name(raw_label)
    if not label:
        return None
    evidence = builder.evidence(path, default_confidence=0.85)
    entity = builder.entity(
        entity_type="enterprise",
        canonical_key=f"enterprise:name:{_token(label)}",
        label=label,
        exact=False,
        evidence=evidence,
        attributes={"observed_roles": [role]},
    )
    builder.alias(entity, label, source_system=f"m1:{role}", evidence=evidence)
    if raw_label != label:
        builder.alias(
            entity,
            raw_label,
            source_system=f"m1:{role}:raw",
            evidence=evidence,
        )
    return entity


def _document_entity(builder: _Canonicalizer) -> CanonicalEntityRecord:
    document = builder.document
    sha256 = (document.source.sha256 or "").lower()
    has_hash = bool(re.fullmatch(r"[0-9a-f]{64}", sha256))
    locator = document.source.archive_path or document.source.original_filename
    canonical_key = (
        f"document:sha256:{sha256}"
        if has_hash
        else f"document:source:{_stable_id('locator', locator, document.source.mime_type)}"
    )
    label = _text(
        document.header.title
        or document.source.display_filename
        or document.source.original_filename
        or canonical_key
    )
    evidence = builder.evidence("$.source", default_confidence=1.0 if has_hash else 0.8)
    entity = builder.entity(
        entity_type="document",
        canonical_key=canonical_key,
        label=label,
        exact=has_hash,
        evidence=evidence,
        attributes={
            "document_type": document.document_type,
            "document_subtype": document.document_subtype,
            "sha256": sha256,
            "original_filename": document.source.original_filename,
            "display_filename": document.source.display_filename,
            "mime_type": document.source.mime_type,
            "archive_path": document.source.archive_path,
        },
    )
    if has_hash:
        builder.identity(
            entity,
            source_system="sha256",
            external_id=sha256,
            mapping_rule="exact_content_hash",
            evidence=evidence,
        )
    builder.alias(
        entity,
        document.source.original_filename,
        source_system="m1:filename",
        evidence=evidence,
    )
    if document.header.title:
        builder.alias(
            entity,
            document.header.title,
            source_system="m1:title",
            evidence=builder.evidence("$.header.title", default_confidence=0.85),
        )
    return entity


def _line_entity_type(document: DocumentRecord) -> str:
    if document.document_type == "equipment" or document.document_subtype == "equipment_register":
        return "equipment"
    if document.document_type == "mold" or document.document_subtype == "mold_mapping":
        return "mold"
    if document.document_type in {"inventory", "procurement"}:
        return "material"
    return "product"


def _line_entity(
    builder: _Canonicalizer,
    line: Any,
    index: int,
    *,
    entity_type: str,
    customer: CanonicalEntityRecord | None,
    supplier: CanonicalEntityRecord | None,
) -> tuple[CanonicalEntityRecord | None, _Evidence | None]:
    prefix = f"$.lines[{index}]"
    customer_code, customer_path = _mapping_value(line, "customer_code", index)
    supplier_code, supplier_path = _mapping_value(line, "supplier_code", index)
    candidates = (
        (line.product_code, f"{prefix}.product_code", "internal", None),
        (line.model, f"{prefix}.model", "model", None),
        (customer_code, customer_path, "customer", customer),
        (supplier_code, supplier_path, "supplier", supplier),
    )
    code = path = code_kind = None
    scoped_org: CanonicalEntityRecord | None = None
    for value, candidate_path, kind, organization in candidates:
        if _text(value):
            code, path, code_kind, scoped_org = _text(value), candidate_path, kind, organization
            break

    exact = code is not None
    if exact:
        if code_kind in {"customer", "supplier"}:
            scope = scoped_org.entity_id if scoped_org else f"unresolved:{builder.source_record_id}"
            canonical_key = f"{entity_type}:{code_kind}:{scope}:{_token(code)}"
            # A customer/supplier code without its owning organisation is not
            # globally unique and therefore cannot be auto-activated.
            exact = scoped_org is not None
        else:
            canonical_key = f"{entity_type}:{code_kind}:{_token(code)}"
        evidence = builder.evidence(path or prefix, default_confidence=0.95 if exact else 0.7)
    else:
        label_seed = line.name_raw or line.name_normalized or line.full_product_name
        if not _text(label_seed):
            return None, None
        path = f"{prefix}.name_raw" if line.name_raw else f"{prefix}.name_normalized"
        evidence = builder.evidence(path, default_confidence=0.75)
        canonical_key = f"{entity_type}:name:{_stable_id('name', _token(label_seed))}"

    label = _text(
        line.full_product_name
        or line.name_normalized
        or line.name_raw
        or code
        or canonical_key
    )
    entity = builder.entity(
        entity_type=entity_type,
        canonical_key=canonical_key,
        label=label,
        exact=exact,
        evidence=evidence,
        attributes={
            "product_code": line.product_code,
            "model": line.model,
            "name_raw": line.name_raw,
            "name_normalized": line.name_normalized,
            "product_category": line.product_category,
            "source_line_id": line.line_id,
            "source_line_no": line.line_no,
        },
    )

    if line.product_code:
        product_evidence = builder.evidence(f"{prefix}.product_code", default_confidence=0.95)
        builder.identity(
            entity,
            source_system="tenant:internal_product_code",
            external_id=line.product_code,
            mapping_rule="exact_internal_code",
            evidence=product_evidence,
        )
        builder.alias(
            entity,
            line.product_code,
            source_system="m1:product_code",
            evidence=product_evidence,
            exact=True,
        )
    if line.model:
        model_evidence = builder.evidence(f"{prefix}.model", default_confidence=0.95)
        builder.identity(
            entity,
            source_system=f"m1:{entity_type}_model",
            external_id=line.model,
            mapping_rule="exact_model_code",
            evidence=model_evidence,
        )
        builder.alias(
            entity,
            line.model,
            source_system="m1:model",
            evidence=model_evidence,
            exact=True,
        )

    scoped_codes = (
        ("customer", customer_code, customer_path, customer),
        ("supplier", supplier_code, supplier_path, supplier),
    )
    for scope_kind, scoped_code, scoped_path, organization in scoped_codes:
        if not scoped_code or not scoped_path:
            continue
        scoped_evidence = builder.evidence(scoped_path, default_confidence=0.95)
        scope = organization.entity_id if organization else f"unresolved:{builder.source_record_id}"
        builder.identity(
            entity,
            source_system=f"{scope_kind}:{scope}",
            external_id=scoped_code,
            mapping_rule=(
                f"exact_{scope_kind}_code_scoped"
                if organization
                else f"unresolved_{scope_kind}_scope"
            ),
            evidence=scoped_evidence,
            exact=organization is not None,
        )

    for alias_path, alias_value, source_system in (
        (f"{prefix}.name_raw", line.name_raw, "m1:name_raw"),
        (f"{prefix}.name_normalized", line.name_normalized, "m1:name_normalized"),
        (f"{prefix}.full_product_name", line.full_product_name, "m1:full_product_name"),
    ):
        if alias_value:
            builder.alias(
                entity,
                alias_value,
                source_system=source_system,
                evidence=builder.evidence(alias_path, default_confidence=0.75),
            )
    return entity, evidence


def _header_domain_entities(
    builder: _Canonicalizer, document_entity: CanonicalEntityRecord
) -> None:
    """Honor explicit typed header fields in technical/legacy v2 extensions."""

    extras = builder.document.header.model_extra or {}
    for field_name, entity_type in _HEADER_PRODUCT_FIELDS:
        value = extras.get(field_name)
        if not _text(value):
            continue
        path = f"$.header.{field_name}"
        evidence = builder.evidence(path, default_confidence=0.95)
        entity = builder.entity(
            entity_type=entity_type,
            canonical_key=f"{entity_type}:{field_name}:{_token(value)}",
            label=_text(value),
            exact=True,
            evidence=evidence,
            attributes={field_name: _text(value)},
        )
        builder.identity(
            entity,
            source_system=f"m1:header_{field_name}",
            external_id=_text(value),
            mapping_rule="exact_typed_header_code",
            evidence=evidence,
        )
        builder.relationship(
            from_entity=document_entity,
            relation_type="DESCRIBES",
            to_entity=entity,
            evidence=evidence,
            exact=True,
            discriminator=field_name,
            properties={"document_subtype": builder.document.document_subtype},
        )


def canonicalize_document(
    document: DocumentRecord | Mapping[str, Any] | BaseModel,
    *,
    tenant_id: str,
    source_record_id: str | None = None,
    source_version: str | None = None,
) -> CanonicalizationResult:
    """Create governed identity and relationship candidates without writing data.

    ``canonical_key`` values are logical keys whose uniqueness scope is the
    supplied tenant.  Every generated record ID additionally includes
    ``tenant_id``, so identical source data in two tenants never shares an ID.
    """

    if not _text(tenant_id):
        raise ValueError("tenant_id is required")
    doc = _coerce_document(document)
    resolved_source_id = source_record_id or _source_record_id(doc, tenant_id)
    resolved_source_version = str(source_version or "unversioned")
    builder = _Canonicalizer(
        doc,
        tenant_id,
        resolved_source_id,
        resolved_source_version,
    )
    document_entity = _document_entity(builder)

    parties: dict[str, CanonicalEntityRecord | None] = {
        "issuer": _organization(
            builder, doc.header.issuer, path="$.header.issuer", role="issuer"
        ),
        "buyer": _organization(builder, doc.header.buyer, path="$.header.buyer", role="buyer"),
        "seller": _organization(
            builder, doc.header.seller, path="$.header.seller", role="seller"
        ),
        "supplier": _organization(
            builder, doc.header.supplier, path="$.header.supplier", role="supplier"
        ),
    }

    for role, party in parties.items():
        if party is None:
            continue
        builder.relationship(
            from_entity=document_entity,
            relation_type=f"HAS_{role.upper()}",
            to_entity=party,
            evidence=builder.evidence(f"$.header.{role}", default_confidence=0.85),
            exact=False,
            discriminator=role,
        )

    order_entity: CanonicalEntityRecord | None = None
    if doc.document_type == "order" and _text(doc.header.order_number):
        order_number = _text(doc.header.order_number)
        number_evidence = builder.evidence("$.header.order_number", default_confidence=0.95)
        trading_parties = [
            item
            for item in (parties["buyer"], parties["seller"], parties["supplier"])
            if item is not None
        ]
        scope_entities = [parties["issuer"]] if parties["issuer"] else trading_parties
        scope_keys = sorted({item.canonical_key for item in scope_entities if item is not None})
        scope_resolved = bool(scope_keys)
        # Keep the issuer/trading-party identity visibly present in the logical
        # key (rather than hiding it behind an opaque hash).  ``_token`` caps
        # pathological lengths while retaining a digest of the complete scope.
        party_scope = (
            _token("|".join(scope_keys))
            if scope_keys
            else f"unresolved:{document_entity.entity_id}"
        )
        subtype = _token(doc.document_subtype or "order")
        order_key = f"order:{party_scope}:{subtype}:{_token(order_number)}"
        order_entity = builder.entity(
            entity_type="order",
            canonical_key=order_key,
            label=order_number,
            exact=scope_resolved,
            evidence=number_evidence,
            attributes={
                "order_number": order_number,
                "document_subtype": doc.document_subtype,
                "issuer_entity_id": parties["issuer"].entity_id if parties["issuer"] else None,
                "trading_party_entity_ids": [item.entity_id for item in trading_parties],
            },
        )
        source_system = (
            f"order:{scope_entities[0].entity_id}:{subtype}"
            if len(scope_entities) == 1 and scope_entities[0] is not None
            else f"order:{party_scope}:{subtype}"
        )
        builder.identity(
            order_entity,
            source_system=source_system,
            external_id=order_number,
            mapping_rule="exact_order_number_with_party_scope",
            evidence=number_evidence,
            exact=scope_resolved,
        )
        builder.relationship(
            from_entity=document_entity,
            relation_type="REPRESENTS_ORDER",
            to_entity=order_entity,
            evidence=number_evidence,
            exact=scope_resolved,
            discriminator=doc.document_subtype,
        )
        for role, party in parties.items():
            if party is None:
                continue
            builder.relationship(
                from_entity=order_entity,
                relation_type=f"HAS_{role.upper()}",
                to_entity=party,
                evidence=builder.evidence(f"$.header.{role}", default_confidence=0.85),
                exact=False,
                discriminator=role,
            )

    entity_type = _line_entity_type(doc)
    for index, line in enumerate(doc.lines):
        custom_customer_name, custom_customer_path = _mapping_value(line, "customer_name", index)
        custom_supplier_name, custom_supplier_path = _mapping_value(line, "supplier_name", index)
        customer = (
            _organization(
                builder,
                custom_customer_name,
                path=custom_customer_path or f"$.lines[{index}].custom_fields",
                role="customer",
            )
            if custom_customer_name
            else parties["buyer"]
        )
        supplier = (
            _organization(
                builder,
                custom_supplier_name,
                path=custom_supplier_path or f"$.lines[{index}].custom_fields",
                role="supplier",
            )
            if custom_supplier_name
            else (parties["supplier"] or parties["seller"])
        )
        target, target_evidence = _line_entity(
            builder,
            line,
            index,
            entity_type=entity_type,
            customer=customer,
            supplier=supplier,
        )
        if target is None or target_evidence is None:
            continue
        quantity_evidence = (
            [builder.evidence(f"$.lines[{index}].quantity", default_confidence=0.9)]
            if line.quantity is not None
            else []
        )
        source_entity = order_entity or document_entity
        relation_type = (
            "CONTAINS_PRODUCT"
            if order_entity and entity_type == "product"
            else "CONTAINS_MATERIAL"
            if order_entity and entity_type == "material"
            else "LISTS_MATERIAL"
            if entity_type == "material"
            else "LISTS_EQUIPMENT"
            if entity_type == "equipment"
            else "LISTS_MOLD"
            if entity_type == "mold"
            else "DESCRIBES_PRODUCT"
        )
        builder.relationship(
            from_entity=source_entity,
            relation_type=relation_type,
            to_entity=target,
            evidence=target_evidence,
            additional_evidence=quantity_evidence,
            exact=target.lifecycle_status == LifecycleStatus.ACTIVE,
            discriminator=line.line_id or line.line_no or index,
            properties={
                "line_id": line.line_id,
                "line_no": line.line_no,
                "quantity": line.quantity,
                "unit": line.unit,
            },
        )

    _header_domain_entities(builder, document_entity)

    return CanonicalizationResult(
        tenant_id=tenant_id,
        source_record_id=resolved_source_id,
        source_version=resolved_source_version,
        document_entity_id=document_entity.entity_id,
        entities=sorted(builder.entities.values(), key=lambda item: item.entity_id),
        external_identities=sorted(
            builder.identities.values(), key=lambda item: item.identity_id
        ),
        aliases=sorted(builder.aliases.values(), key=lambda item: item.alias_id),
        relationships=sorted(
            builder.relationships.values(), key=lambda item: item.relationship_id
        ),
    )


__all__ = ["CanonicalizationResult", "canonicalize_document"]
