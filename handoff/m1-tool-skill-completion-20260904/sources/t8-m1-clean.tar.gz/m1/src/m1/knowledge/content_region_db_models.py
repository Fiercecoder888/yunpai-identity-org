"""SQLAlchemy rows for governed content-region routing."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKeyConstraint,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import (
    KNOWLEDGE_EMBEDDING_TYPE,
    KnowledgeBase,
    TenantScopedMixin,
)


class ContentRegionProfileRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_content_region_profiles"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "profile_id", name="content_region_profile_tenant_identity"
        ),
        UniqueConstraint(
            "tenant_id", "profile_key", "version", name="content_region_profile_version"
        ),
        UniqueConstraint(
            "tenant_id",
            "supersedes_profile_id",
            name="content_region_profile_single_successor",
        ),
        CheckConstraint("version >= 1", name="version_positive"),
        CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')",
            name="status",
        ),
        CheckConstraint(
            "source_family IN ('mineru','pp_structure','paddleocr_vl','docling',"
            "'native','spreadsheet','other')",
            name="source_family",
        ),
        CheckConstraint(
            "region_kind IN ('title','section','paragraph','list','table','figure',"
            "'caption','header','footer','unknown')",
            name="region_kind",
        ),
        CheckConstraint(
            "(role IS NULL AND strategy_id IS NULL) OR "
            "(role IS NOT NULL AND strategy_id IS NOT NULL)",
            name="route_pair_atomic",
        ),
        CheckConstraint(
            "status <> 'active' OR (role IS NOT NULL AND strategy_id IS NOT NULL "
            "AND reviewed_by IS NOT NULL AND length(reviewed_by) > 0 "
            "AND reviewed_at IS NOT NULL AND length(review_note) > 0 "
            "AND approved_by IS NOT NULL AND length(approved_by) > 0 "
            "AND approved_at IS NOT NULL "
            "AND lower(reviewed_by) <> lower(approved_by) "
            "AND success_count >= 3 AND failure_count = 0)",
            name="active_governance",
        ),
        CheckConstraint(
            "observation_count >= 0 AND success_count >= 0 AND failure_count >= 0",
            name="counts_nonnegative",
        ),
        CheckConstraint(
            "success_count + failure_count = observation_count",
            name="counts_consistent",
        ),
        CheckConstraint(
            "embedding_dimensions >= 0", name="embedding_dimensions_nonnegative"
        ),
        CheckConstraint(
            "(embedding IS NULL AND embedding_model = '' AND embedding_dimensions = 0) "
            "OR (embedding IS NOT NULL AND length(embedding_model) > 0 "
            "AND embedding_dimensions > 0)",
            name="embedding_identity",
        ),
        CheckConstraint(
            "(version = 1 AND supersedes_profile_id IS NULL) OR "
            "(version > 1 AND supersedes_profile_id IS NOT NULL)",
            name="revision_predecessor",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "supersedes_profile_id"],
            [
                "knowledge_content_region_profiles.tenant_id",
                "knowledge_content_region_profiles.profile_id",
            ],
            name="fk_content_region_profile_supersedes_tenant",
            ondelete="RESTRICT",
        ),
        Index(
            "ix_content_region_profiles_lookup",
            "tenant_id",
            "status",
            "contract_revision",
            "embedding_space",
            "region_kind",
        ),
        Index(
            "ix_content_region_profiles_fingerprint",
            "tenant_id",
            "contract_id",
            "contract_revision",
            "embedding_space",
            "exact_fingerprint",
            "status",
        ),
        Index(
            "ix_content_region_profiles_embedding_space",
            "tenant_id",
            "status",
            "contract_id",
            "contract_revision",
            "embedding_space",
            "embedding_model",
            "embedding_dimensions",
            "region_kind",
        ),
        Index(
            "ux_content_region_profiles_active_key",
            "tenant_id",
            "profile_key",
            unique=True,
            sqlite_where=text("status = 'active'"),
            postgresql_where=text("status = 'active'"),
        ),
        Index(
            "ux_content_region_profiles_active_fingerprint",
            "tenant_id",
            "contract_id",
            "contract_revision",
            "embedding_space",
            "exact_fingerprint",
            unique=True,
            sqlite_where=text("status = 'active'"),
            postgresql_where=text("status = 'active'"),
        ),
    )

    profile_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    profile_key: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    supersedes_profile_id: Mapped[str | None] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    contract_id: Mapped[str] = mapped_column(String(128), nullable=False)
    contract_revision: Mapped[str] = mapped_column(String(128), nullable=False)
    embedding_space: Mapped[str] = mapped_column(String(256), nullable=False)
    exact_fingerprint: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True
    )
    source_family: Mapped[str] = mapped_column(String(40), nullable=False)
    region_kind: Mapped[str] = mapped_column(String(40), nullable=False)
    signature_json: Mapped[dict[str, Any]] = mapped_column(
        "signature", JSON, nullable=False
    )
    semantic_sketch_json: Mapped[dict[str, Any]] = mapped_column(
        "semantic_sketch", JSON, nullable=False
    )
    role: Mapped[str | None] = mapped_column(String(64))
    strategy_id: Mapped[str | None] = mapped_column(String(64))
    embedding: Mapped[list[float] | None] = mapped_column(
        KNOWLEDGE_EMBEDDING_TYPE, nullable=True
    )
    embedding_model: Mapped[str] = mapped_column(
        String(256), nullable=False, default=""
    )
    embedding_dimensions: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    created_by: Mapped[str] = mapped_column(String(256), nullable=False)
    reviewed_by: Mapped[str | None] = mapped_column(String(256))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str] = mapped_column(Text, nullable=False, default="")
    approved_by: Mapped[str | None] = mapped_column(String(256))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    observation_count: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    success_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    failure_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    last_observed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_failure_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class ContentRegionObservationRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_content_region_observations"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "idempotency_key",
            name="content_region_observation_idempotency",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "profile_id"],
            [
                "knowledge_content_region_profiles.tenant_id",
                "knowledge_content_region_profiles.profile_id",
            ],
            name="fk_content_region_observation_profile_tenant",
            ondelete="RESTRICT",
        ),
        CheckConstraint("outcome IN ('success','failure')", name="outcome"),
        CheckConstraint("latency_ms >= 0", name="latency_nonnegative"),
        CheckConstraint(
            "outcome <> 'success' OR (validation_passed = true "
            "AND length(reviewed_by) > 0 AND length(review_note_sha256) = 64)",
            name="success_reviewed",
        ),
        Index(
            "ix_content_region_observations_profile",
            "tenant_id",
            "profile_id",
            "observed_at",
        ),
        Index(
            "ix_content_region_observations_outcome",
            "tenant_id",
            "outcome",
            "observed_at",
        ),
    )

    observation_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    profile_id: Mapped[str] = mapped_column(String(128), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    exact_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    task_reference_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    outcome: Mapped[str] = mapped_column(String(32), nullable=False)
    validation_passed: Mapped[bool] = mapped_column(Boolean, nullable=False)
    reviewed_by: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    review_note_sha256: Mapped[str] = mapped_column(
        String(64), nullable=False, default=""
    )
    latency_ms: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    error_code: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    observed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


__all__ = ["ContentRegionObservationRow", "ContentRegionProfileRow"]
