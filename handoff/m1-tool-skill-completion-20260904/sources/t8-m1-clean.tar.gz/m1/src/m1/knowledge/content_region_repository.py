"""Tenant-safe persistence for governed content-region routing profiles."""

from __future__ import annotations

import inspect as pyinspect
import math
from collections.abc import Collection, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from m1.documents.parsing.content_region_contracts import (
    ContentRegionCandidateProposal,
    ContentRegionExecutionObservation,
    ContentRegionKind,
    ContentRegionProfile,
    ContentRegionProfileMatch,
    ContentRegionRole,
    ContentRegionSignature,
)
from m1.documents.parsing.semantic_strategy_router import SemanticStrategyId

from .content_region_db_models import (
    ContentRegionObservationRow,
    ContentRegionProfileRow,
)
from .content_region_schema import (
    ContentRegionObservationOutcome,
    ContentRegionObservationRecord,
    ContentRegionProfileRecord,
    ContentRegionProfileStatus,
)
from .db_document_models import TenantRow
from .db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    TenantBoundaryError,
)
from .persistence_helpers import _aware, _canonical_json
from .repository_base import KnowledgeRepositoryBase, _tenant_scoped_call
from .route_lifecycle import (
    record_route_lifecycle_event,
    require_separated_approval,
)
from .schema import utc_now

_MIN_ACTIVATION_DISTINCT_TASKS = 3


def _profile_record(row: ContentRegionProfileRow) -> ContentRegionProfileRecord:
    signature = ContentRegionSignature.model_validate(row.signature_json, strict=False)
    if row.contract_id != signature.contract_id or (
        row.contract_revision != signature.contract_revision
    ):
        raise ValueError("content-region profile contract does not match signature")
    if row.semantic_sketch_json != signature.semantic_sketch.model_dump(mode="json"):
        raise ValueError("content-region semantic sketch does not match signature")
    return ContentRegionProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        contract_id=row.contract_id,
        contract_revision=row.contract_revision,
        embedding_space=row.embedding_space,
        exact_fingerprint=row.exact_fingerprint,
        signature=signature,
        semantic_sketch=signature.semantic_sketch,
        role=row.role,
        strategy_id=row.strategy_id,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_note=row.review_note,
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at) or utc_now(),
        updated_at=_aware(row.updated_at) or utc_now(),
    )


def _observation_record(
    row: ContentRegionObservationRow,
) -> ContentRegionObservationRecord:
    return ContentRegionObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        task_reference_hash=row.task_reference_hash,
        outcome=row.outcome,
        validation_passed=row.validation_passed,
        reviewed_by=row.reviewed_by,
        review_note_sha256=row.review_note_sha256,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        observed_at=_aware(row.observed_at) or utc_now(),
    )


def _same_profile_definition(
    row: ContentRegionProfileRow,
    record: ContentRegionProfileRecord,
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.tenant_id == record.tenant_id
        and row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.contract_id == record.contract_id
        and row.contract_revision == record.contract_revision
        and row.embedding_space == record.embedding_space
        and row.exact_fingerprint == record.exact_fingerprint
        and row.source_family == record.signature.source_family.value
        and row.region_kind == record.signature.region_kind.value
        and _canonical_json(row.signature_json)
        == _canonical_json(record.signature.model_dump(mode="json"))
        and _canonical_json(row.semantic_sketch_json)
        == _canonical_json(record.semantic_sketch.model_dump(mode="json"))
        and row.role == (record.role.value if record.role is not None else None)
        and row.strategy_id
        == (record.strategy_id.value if record.strategy_id is not None else None)
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
    )


def _same_observation(
    row: ContentRegionObservationRow,
    record: ContentRegionObservationRecord,
) -> bool:
    return (
        row.tenant_id == record.tenant_id
        and row.profile_id == record.profile_id
        and row.idempotency_key == record.idempotency_key
        and row.exact_fingerprint == record.exact_fingerprint
        and row.task_reference_hash == record.task_reference_hash
        and row.outcome == record.outcome.value
        and row.validation_passed == record.validation_passed
        and row.reviewed_by == record.reviewed_by
        and row.review_note_sha256 == record.review_note_sha256
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    candidate = _aware(second) or utc_now()
    return max(normalized, candidate) if normalized is not None else candidate


def _fingerprint(value: str) -> str:
    normalized = value.strip().casefold()
    if len(normalized) != 64:
        raise ValueError("content-region fingerprints require 64 hexadecimal chars")
    try:
        int(normalized, 16)
    except ValueError as exc:
        raise ValueError(
            "content-region fingerprints require 64 hexadecimal chars"
        ) from exc
    return normalized


class KnowledgeContentRegionRouteMixin:
    """Repository mixin; automatic proposals always remain inactive."""

    async def _lock_content_region_tenant(
        self,
        session: AsyncSession,
        tenant_id: str,
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_content_region_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> ContentRegionProfileRow:
        statement = select(ContentRegionProfileRow).where(
            ContentRegionProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"content-region profile not found: {profile_id}")
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_content_region_profile(
        self,
        record: ContentRegionProfileRecord,
    ) -> ContentRegionProfileRecord:
        if record.status is not ContentRegionProfileStatus.CANDIDATE:
            raise ValueError("new content-region profiles must start as candidate")

        async def operation(session: AsyncSession) -> ContentRegionProfileRecord:
            await self._lock_content_region_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(ContentRegionProfileRow).where(
                        ContentRegionProfileRow.tenant_id == record.tenant_id,
                        or_(
                            ContentRegionProfileRow.profile_id == record.profile_id,
                            (
                                (
                                    ContentRegionProfileRow.profile_key
                                    == record.profile_key
                                )
                                & (ContentRegionProfileRow.version == record.version)
                            ),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if row.profile_key == record.profile_key
                        and row.version == record.version
                    ),
                    None,
                )
                if existing is not None and _same_profile_definition(existing, record):
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"content-region-profile:{record.profile_key}:{record.version}"
                )

            predecessor: ContentRegionProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_content_region_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError(
                        "a content-region revision changes its profile key"
                    )
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("a content-region revision changes its signature")
                if predecessor.contract_id != record.contract_id or (
                    predecessor.contract_revision != record.contract_revision
                    or predecessor.embedding_space != record.embedding_space
                ):
                    raise ValueError("a content-region revision changes its contract")
                if record.version != predecessor.version + 1:
                    raise ValueError("content-region revisions must be consecutive")
                if predecessor.status == ContentRegionProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active content-region profile must be deprecated before revision"
                    )

            dimensions = (
                len(record.embedding)
                if record.embedding is not None
                else record.embedding_dimensions
            )
            row = ContentRegionProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                contract_id=record.contract_id,
                contract_revision=record.contract_revision,
                embedding_space=record.embedding_space,
                exact_fingerprint=record.exact_fingerprint,
                source_family=record.signature.source_family.value,
                region_kind=record.signature.region_kind.value,
                signature_json=record.signature.model_dump(mode="json"),
                semantic_sketch_json=record.semantic_sketch.model_dump(mode="json"),
                role=(record.role.value if record.role is not None else None),
                strategy_id=(
                    record.strategy_id.value if record.strategy_id is not None else None
                ),
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=dimensions,
                created_by=record.created_by,
                reviewed_by=None,
                reviewed_at=None,
                review_note="",
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == ContentRegionProfileStatus.CANDIDATE.value
            ):
                predecessor.status = ContentRegionProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at, record.created_at
                )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=record.tenant_id,
                    route_kind="content_region",
                    profile_id=predecessor.profile_id,
                    event_type="superseded",
                    actor_id=record.created_by,
                    reason=f"superseded by profile {record.profile_id}",
                    observation_count=predecessor.observation_count,
                    occurred_at=record.created_at,
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def create_content_region_candidate(
        self,
        record: ContentRegionCandidateProposal,
    ) -> ContentRegionProfile:
        """Persist an automatic proposal and return the runtime-safe projection."""

        proposal = record
        profiles = await self.list_content_region_profiles(
            proposal.tenant_id,
            profile_key=proposal.profile_key,
            limit=1000,
        )
        for existing in profiles:
            if (
                existing.status is ContentRegionProfileStatus.CANDIDATE
                and existing.exact_fingerprint == proposal.signature.exact_fingerprint()
                and existing.role is proposal.suggested_role
                and existing.strategy_id is proposal.suggested_strategy_id
                and _canonical_json(existing.signature.model_dump(mode="json"))
                == _canonical_json(proposal.signature.model_dump(mode="json"))
            ):
                return existing.as_runtime_profile()

        latest = max(profiles, key=lambda item: item.version, default=None)
        if latest is not None and latest.status is ContentRegionProfileStatus.ACTIVE:
            raise IdempotencyConflictError(
                f"content-region-active:{proposal.tenant_id}:{proposal.profile_key}"
            )
        record = ContentRegionProfileRecord(
            tenant_id=proposal.tenant_id,
            profile_key=proposal.profile_key,
            version=(latest.version + 1 if latest is not None else 1),
            supersedes_profile_id=(latest.profile_id if latest is not None else None),
            exact_fingerprint=proposal.signature.exact_fingerprint(),
            signature=proposal.signature,
            semantic_sketch=proposal.signature.semantic_sketch,
            role=proposal.suggested_role,
            strategy_id=proposal.suggested_strategy_id,
            embedding=(
                list(proposal.embedding) if proposal.embedding is not None else None
            ),
            embedding_model=proposal.embedding_model,
            embedding_dimensions=proposal.embedding_dimensions,
            created_by=proposal.created_by,
        )
        created = await self.create_content_region_profile(record)
        return created.as_runtime_profile()

    async def get_content_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
    ) -> ContentRegionProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(ContentRegionProfileRow).where(
                    ContentRegionProfileRow.tenant_id == tenant_id,
                    ContentRegionProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row is not None else None

    async def list_content_region_profiles(
        self,
        tenant_id: str,
        *,
        status: ContentRegionProfileStatus | str | None = None,
        profile_key: str | None = None,
        exact_fingerprint: str | None = None,
        role: ContentRegionRole | str | None = None,
        limit: int = 200,
    ) -> list[ContentRegionProfileRecord]:
        if limit < 1:
            return []
        statement = select(ContentRegionProfileRow).where(
            ContentRegionProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            statement = statement.where(
                ContentRegionProfileRow.status
                == ContentRegionProfileStatus(str(status)).value
            )
        if profile_key is not None:
            statement = statement.where(
                ContentRegionProfileRow.profile_key == profile_key.strip().casefold()
            )
        if exact_fingerprint is not None:
            statement = statement.where(
                ContentRegionProfileRow.exact_fingerprint
                == _fingerprint(exact_fingerprint)
            )
        if role is not None:
            statement = statement.where(
                ContentRegionProfileRow.role == ContentRegionRole(str(role)).value
            )
        statement = statement.order_by(
            ContentRegionProfileRow.profile_key,
            ContentRegionProfileRow.version.desc(),
            ContentRegionProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def get_active_content_region_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
    ) -> ContentRegionProfile | None:
        row_filter = (
            ContentRegionProfileRow.tenant_id == tenant_id,
            ContentRegionProfileRow.status == ContentRegionProfileStatus.ACTIVE.value,
            ContentRegionProfileRow.contract_id == contract_id,
            ContentRegionProfileRow.contract_revision == contract_revision,
            ContentRegionProfileRow.embedding_space == embedding_space,
            ContentRegionProfileRow.exact_fingerprint
            == _fingerprint(exact_fingerprint),
        )
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(ContentRegionProfileRow).where(*row_filter)
            )
            return (
                _profile_record(row).as_runtime_profile() if row is not None else None
            )

    async def find_active_content_region_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
        embedding_model: str,
        embedding_dimensions: int,
        region_kind: ContentRegionKind,
        limit: int,
    ) -> list[ContentRegionProfileMatch]:
        """Return only compatible ACTIVE routes from pgvector or SQLite fallback."""

        if limit < 1:
            return []
        model = embedding_model.strip()
        if not model:
            raise ValueError("content-region embedding model identity is required")
        dimensions = int(embedding_dimensions)
        if dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "content-region embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {dimensions}"
            )
        vector = [float(value) for value in embedding]
        if len(vector) != dimensions or not all(
            math.isfinite(value) for value in vector
        ):
            raise ValueError("content-region query embedding is invalid")
        statement = select(ContentRegionProfileRow).where(
            ContentRegionProfileRow.tenant_id == tenant_id,
            ContentRegionProfileRow.status == ContentRegionProfileStatus.ACTIVE.value,
            ContentRegionProfileRow.contract_id == contract_id,
            ContentRegionProfileRow.contract_revision == contract_revision,
            ContentRegionProfileRow.embedding_space == embedding_space,
            ContentRegionProfileRow.embedding_model == model,
            ContentRegionProfileRow.embedding_dimensions == dimensions,
            ContentRegionProfileRow.region_kind == ContentRegionKind(region_kind).value,
            ContentRegionProfileRow.embedding.is_not(None),
        )
        async with self.sessionmaker() as session:
            if self.engine.url.get_backend_name() == "postgresql":
                distance = ContentRegionProfileRow.embedding.cosine_distance(vector)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .order_by(distance, ContentRegionProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    ContentRegionProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=max(-1.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]
            rows = (
                await session.scalars(
                    statement.order_by(
                        ContentRegionProfileRow.updated_at.desc(),
                        ContentRegionProfileRow.profile_id,
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in vector))
        matches: list[tuple[float, ContentRegionProfileMatch]] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != dimensions:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(left * right for left, right in zip(vector, stored, strict=True))
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(-1.0, min(1.0, similarity))
            match = ContentRegionProfileMatch(
                profile=_profile_record(row).as_runtime_profile(),
                vector_similarity=similarity,
            )
            matches.append((similarity, match))
        matches.sort(key=lambda item: (-item[0], item[1].profile.profile_id))
        return [item[1] for item in matches[: min(limit, 100)]]

    async def record_content_region_execution_observation(
        self,
        record: ContentRegionExecutionObservation,
    ) -> ContentRegionObservationRecord:
        observation = record
        record = ContentRegionObservationRecord(
            tenant_id=observation.tenant_id,
            profile_id=observation.profile_id,
            idempotency_key=(
                f"content-region:{observation.profile_id}:"
                f"{observation.task_reference_hash}"
            ),
            exact_fingerprint=observation.exact_fingerprint,
            task_reference_hash=observation.task_reference_hash,
            outcome=ContentRegionObservationOutcome(observation.outcome),
            validation_passed=observation.validation_passed,
            reviewed_by=observation.reviewed_by,
            review_note_sha256=observation.review_note_sha256,
            latency_ms=observation.latency_ms,
            error_code=observation.error_code,
        )
        return await self.record_content_region_observation(record)

    async def record_content_region_observation(
        self,
        record: ContentRegionObservationRecord,
    ) -> ContentRegionObservationRecord:
        async def operation(session: AsyncSession) -> ContentRegionObservationRecord:
            await self._lock_content_region_tenant(session, record.tenant_id)
            profile = await self._require_content_region_profile(
                session,
                record.tenant_id,
                record.profile_id,
                for_update=True,
            )
            existing = await session.scalar(
                select(ContentRegionObservationRow).where(
                    ContentRegionObservationRow.tenant_id == record.tenant_id,
                    ContentRegionObservationRow.idempotency_key
                    == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError(
                    "observation fingerprint does not match content-region profile"
                )
            row = ContentRegionObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                task_reference_hash=record.task_reference_hash,
                outcome=record.outcome.value,
                validation_passed=record.validation_passed,
                reviewed_by=record.reviewed_by,
                review_note_sha256=record.review_note_sha256,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at, record.observed_at
            )
            if record.outcome is ContentRegionObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at, record.observed_at
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at, record.observed_at
                )
                if profile.status == ContentRegionProfileStatus.ACTIVE.value:
                    profile.status = ContentRegionProfileStatus.DEPRECATED.value
                    await record_route_lifecycle_event(
                        session,
                        tenant_id=record.tenant_id,
                        route_kind="content_region",
                        profile_id=profile.profile_id,
                        event_type="auto_deprecated",
                        actor_id=record.reviewed_by or "content-region-observation",
                        reason=(
                            f"failed observation {record.observation_id}: "
                            f"{record.error_code or 'unspecified'}"
                        ),
                        observation_count=profile.observation_count,
                        occurred_at=record.observed_at,
                    )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def activate_content_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str,
        review_note: str,
        expected_observation_count: int,
        allowed_routes: Collection[
            tuple[ContentRegionRole | str, SemanticStrategyId | str]
        ],
        approved_at: datetime | None = None,
    ) -> ContentRegionProfileRecord:
        approver = approved_by.strip()
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not approver or not reviewer or not note:
            raise ValueError("approval, review, and review note are required")
        if expected_observation_count < _MIN_ACTIVATION_DISTINCT_TASKS:
            raise ValueError("at least three reviewed validation samples are required")
        route_registry = {
            (
                ContentRegionRole(str(role)).value,
                SemanticStrategyId(str(strategy)).value,
            )
            for role, strategy in allowed_routes
        }
        if not route_registry:
            raise ValueError("allowed_routes must be a non-empty code registry")
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> ContentRegionProfileRecord:
            await self._lock_content_region_tenant(session, tenant_id)
            row = await self._require_content_region_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if (
                row.role is None
                or row.strategy_id is None
                or (
                    row.role,
                    row.strategy_id,
                )
                not in route_registry
            ):
                raise ValueError("route pair is absent from the code-owned registry")
            if row.observation_count != expected_observation_count:
                raise IdempotencyConflictError(
                    f"content-region-approval-observations:{tenant_id}:{profile_id}"
                )
            if row.failure_count != 0 or row.success_count != row.observation_count:
                raise IdempotencyConflictError(
                    f"content-region-approval-failures:{tenant_id}:{profile_id}"
                )
            observations = (
                await session.scalars(
                    select(ContentRegionObservationRow).where(
                        ContentRegionObservationRow.tenant_id == tenant_id,
                        ContentRegionObservationRow.profile_id == profile_id,
                    )
                )
            ).all()
            task_hashes = {
                observation.task_reference_hash
                for observation in observations
                if observation.outcome == ContentRegionObservationOutcome.SUCCESS.value
                and observation.validation_passed
                and observation.reviewed_by.strip()
                and len(observation.review_note_sha256) == 64
            }
            if len(task_hashes) < _MIN_ACTIVATION_DISTINCT_TASKS:
                raise IdempotencyConflictError(
                    f"content-region-approval-distinct-tasks:{tenant_id}:{profile_id}"
                )
            require_separated_approval(
                approved_by=approver,
                reviewed_by=reviewer,
                sample_reviewers=(
                    observation.reviewed_by for observation in observations
                ),
            )
            if row.status == ContentRegionProfileStatus.ACTIVE.value:
                if not (
                    row.approved_by == approver
                    and row.reviewed_by == reviewer
                    and row.review_note == note
                    and (
                        approved_at is None
                        or _aware(row.approved_at) == _aware(approved_at)
                    )
                ):
                    raise IdempotencyConflictError(
                        f"content-region-activation:{tenant_id}:{profile_id}"
                    )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="content_region",
                    profile_id=profile_id,
                    event_type="activated",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=note,
                    observation_count=expected_observation_count,
                    occurred_at=_aware(row.approved_at) or now,
                )
                return _profile_record(row)
            if row.status != ContentRegionProfileStatus.CANDIDATE.value:
                raise ValueError(
                    "only candidate content-region profiles may be activated"
                )
            statement = select(ContentRegionProfileRow).where(
                ContentRegionProfileRow.tenant_id == tenant_id,
                ContentRegionProfileRow.profile_id != profile_id,
                ContentRegionProfileRow.status
                == ContentRegionProfileStatus.ACTIVE.value,
                or_(
                    ContentRegionProfileRow.profile_key == row.profile_key,
                    (
                        (ContentRegionProfileRow.contract_id == row.contract_id)
                        & (
                            ContentRegionProfileRow.contract_revision
                            == row.contract_revision
                        )
                        & (
                            ContentRegionProfileRow.embedding_space
                            == row.embedding_space
                        )
                        & (
                            ContentRegionProfileRow.exact_fingerprint
                            == row.exact_fingerprint
                        )
                    ),
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = ContentRegionProfileStatus.DEPRECATED.value
                previous.updated_at = now
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="content_region",
                    profile_id=previous.profile_id,
                    event_type="superseded",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=f"superseded by profile {profile_id}",
                    observation_count=previous.observation_count,
                    occurred_at=now,
                )
            row.status = ContentRegionProfileStatus.ACTIVE.value
            row.reviewed_by = reviewer
            row.reviewed_at = row.reviewed_at or now
            row.review_note = note
            row.approved_by = approver
            row.approved_at = now
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="content_region",
                profile_id=profile_id,
                event_type="activated",
                actor_id=approver,
                counterparty_id=reviewer,
                reason=note,
                observation_count=expected_observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def reject_content_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> ContentRegionProfileRecord:
        return await self._transition_content_region_profile(
            tenant_id,
            profile_id,
            target=ContentRegionProfileStatus.REJECTED,
            reviewed_by=reviewed_by,
            review_note=review_note,
            reviewed_at=reviewed_at,
        )

    async def deprecate_content_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> ContentRegionProfileRecord:
        return await self._transition_content_region_profile(
            tenant_id,
            profile_id,
            target=ContentRegionProfileStatus.DEPRECATED,
            reviewed_by=reviewed_by,
            review_note=review_note,
            reviewed_at=reviewed_at,
        )

    async def _transition_content_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        target: ContentRegionProfileStatus,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None,
    ) -> ContentRegionProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> ContentRegionProfileRecord:
            await self._lock_content_region_tenant(session, tenant_id)
            row = await self._require_content_region_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == target.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="content_region",
                    profile_id=profile_id,
                    event_type=(
                        "rejected"
                        if target is ContentRegionProfileStatus.REJECTED
                        else "deprecated"
                    ),
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=(
                        _aware(row.reviewed_at) or now
                        if target is ContentRegionProfileStatus.REJECTED
                        else now
                    ),
                )
                return _profile_record(row)
            if target is ContentRegionProfileStatus.REJECTED and (
                row.status != ContentRegionProfileStatus.CANDIDATE.value
            ):
                raise ValueError(
                    "only candidate content-region profiles may be rejected"
                )
            if target is ContentRegionProfileStatus.DEPRECATED and (
                row.status == ContentRegionProfileStatus.REJECTED.value
            ):
                raise ValueError(
                    "a rejected content-region profile cannot be deprecated"
                )
            row.status = target.value
            if target is ContentRegionProfileStatus.REJECTED:
                row.reviewed_by = reviewer
                row.reviewed_at = now
                row.review_note = note
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="content_region",
                profile_id=profile_id,
                event_type=(
                    "rejected"
                    if target is ContentRegionProfileStatus.REJECTED
                    else "deprecated"
                ),
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)


class ContentRegionRepository(
    KnowledgeContentRegionRouteMixin,
    KnowledgeRepositoryBase,
):
    """Standalone adapter until the main KnowledgeStore facade imports the mixin."""


for _method_name in dir(ContentRegionRepository):
    _method = getattr(ContentRegionRepository, _method_name)
    if (
        not _method_name.startswith("_")
        and pyinspect.iscoroutinefunction(_method)
        and {"tenant_id", "record"}.intersection(
            pyinspect.signature(_method).parameters
        )
    ):
        setattr(ContentRegionRepository, _method_name, _tenant_scoped_call(_method))


__all__ = ["ContentRegionRepository", "KnowledgeContentRegionRouteMixin"]
