"""Governance records for tenant-scoped content-region routing profiles."""

from __future__ import annotations

import math
import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Self

from pydantic import Field, field_validator, model_validator

from m1.documents.parsing.content_region_contracts import (
    CONTENT_REGION_CONTRACT_ID,
    CONTENT_REGION_CONTRACT_REVISION,
    CONTENT_REGION_EMBEDDING_SPACE,
    ContentRegionProfile,
    ContentRegionRole,
    ContentRegionSemanticSketch,
    ContentRegionSignature,
)
from m1.documents.parsing.semantic_strategy_router import SemanticStrategyId

from .db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from .schema import KnowledgeSchema, new_id, utc_now

_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,255}$")


class ContentRegionProfileStatus(StrEnum):
    CANDIDATE = "candidate"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class ContentRegionObservationOutcome(StrEnum):
    SUCCESS = "success"
    FAILURE = "failure"


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class ContentRegionProfileRecord(KnowledgeSchema):
    """Versioned route definition plus reviewed validation counters."""

    profile_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    version: int = Field(default=1, ge=1)
    supersedes_profile_id: str | None = Field(
        default=None, min_length=1, max_length=128
    )
    status: ContentRegionProfileStatus = ContentRegionProfileStatus.CANDIDATE
    contract_id: str = Field(default=CONTENT_REGION_CONTRACT_ID, max_length=128)
    contract_revision: str = Field(
        default=CONTENT_REGION_CONTRACT_REVISION, max_length=128
    )
    embedding_space: str = Field(
        default=CONTENT_REGION_EMBEDDING_SPACE, min_length=1, max_length=256
    )
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    signature: ContentRegionSignature
    semantic_sketch: ContentRegionSemanticSketch
    role: ContentRegionRole | None = None
    strategy_id: SemanticStrategyId | None = None
    embedding: list[float] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0)
    created_by: str = Field(min_length=1, max_length=256)
    reviewed_by: str | None = Field(default=None, min_length=1, max_length=256)
    reviewed_at: datetime | None = None
    review_note: str = Field(default="", max_length=4096)
    approved_by: str | None = Field(default=None, min_length=1, max_length=256)
    approved_at: datetime | None = None
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)
    last_observed_at: datetime | None = None
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("profile_id", "profile_key", "embedding_space")
    @classmethod
    def validate_tokens(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("content-region identities must be stable tokens")
        return normalized

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.strip().casefold()

    @field_validator("embedding")
    @classmethod
    def validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        if value is None:
            return None
        normalized = [float(item) for item in value]
        if len(normalized) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "content-region embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {len(normalized)}"
            )
        if not all(math.isfinite(item) for item in normalized):
            raise ValueError("content-region embedding contains non-finite values")
        return normalized

    @field_validator("embedding_model")
    @classmethod
    def normalize_embedding_model(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "reviewed_at",
        "approved_at",
        "last_observed_at",
        "last_success_at",
        "last_failure_at",
        "created_at",
        "updated_at",
    )
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _utc(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.version == 1 and self.supersedes_profile_id is not None:
            raise ValueError("a first content-region profile cannot supersede another")
        if self.version > 1 and self.supersedes_profile_id is None:
            raise ValueError("content-region revisions require a predecessor")
        if self.supersedes_profile_id == self.profile_id:
            raise ValueError("a content-region profile cannot supersede itself")
        if self.contract_id != self.signature.contract_id or (
            self.contract_revision != self.signature.contract_revision
        ):
            raise ValueError("profile and signature contracts do not match")
        if self.embedding_space != CONTENT_REGION_EMBEDDING_SPACE:
            raise ValueError("unsupported content-region embedding space")
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("fingerprint does not match content-region signature")
        if self.semantic_sketch != self.signature.semantic_sketch:
            raise ValueError("semantic sketch does not match content-region signature")
        if (self.role is None) != (self.strategy_id is None):
            raise ValueError("content role and semantic strategy are an atomic pair")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding identity requires an embedding")
        else:
            if not self.embedding_model:
                raise ValueError("content-region embeddings require a model identity")
            if self.embedding_dimensions not in {0, len(self.embedding)}:
                raise ValueError("embedding dimensions do not match the vector")
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("content-region observation counters are inconsistent")
        if self.status is ContentRegionProfileStatus.ACTIVE:
            if self.role is None or self.strategy_id is None:
                raise ValueError("active content-region profiles require a route pair")
            if (
                not self.reviewed_by
                or self.reviewed_at is None
                or not self.review_note.strip()
            ):
                raise ValueError(
                    "active content-region profiles require review metadata"
                )
            if not self.approved_by or self.approved_at is None:
                raise ValueError(
                    "active content-region profiles require approval metadata"
                )
            if self.reviewed_by.casefold() == self.approved_by.casefold():
                raise ValueError(
                    "active content-region profiles require independent approval"
                )
            if self.success_count < 3 or self.failure_count:
                raise ValueError(
                    "active content-region profiles require three clean samples"
                )
        return self

    def as_runtime_profile(self) -> ContentRegionProfile:
        return ContentRegionProfile(
            profile_id=self.profile_id,
            tenant_id=self.tenant_id,
            profile_key=self.profile_key,
            status=self.status.value,
            contract_id=self.contract_id,
            contract_revision=self.contract_revision,
            embedding_space=self.embedding_space,
            exact_fingerprint=self.exact_fingerprint,
            signature=self.signature,
            role=self.role,
            strategy_id=self.strategy_id,
            embedding=(tuple(self.embedding) if self.embedding is not None else None),
            embedding_model=self.embedding_model,
            embedding_dimensions=(
                len(self.embedding)
                if self.embedding is not None
                else self.embedding_dimensions
            ),
            reviewed=bool(self.reviewed_by and self.approved_by),
            observation_count=self.observation_count,
            success_count=self.success_count,
            failure_count=self.failure_count,
        )


class ContentRegionObservationRecord(KnowledgeSchema):
    observation_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: ContentRegionObservationOutcome
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)
    observed_at: datetime = Field(default_factory=utc_now)

    @field_validator("exact_fingerprint", "task_reference_hash", "review_note_sha256")
    @classmethod
    def normalize_hashes(cls, value: str) -> str:
        return value.strip().casefold()

    @field_validator("error_code")
    @classmethod
    def normalize_error(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if normalized and _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("content-region error_code must be a stable token")
        return normalized

    @field_validator("observed_at")
    @classmethod
    def normalize_observed_at(cls, value: datetime) -> datetime:
        return _utc(value) or utc_now()

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome is ContentRegionObservationOutcome.SUCCESS:
            if not self.validation_passed:
                raise ValueError(
                    "successful content-region samples must pass validation"
                )
            if not self.reviewed_by.strip():
                raise ValueError("successful content-region samples require a reviewer")
            if re.fullmatch(r"[0-9a-f]{64}", self.review_note_sha256) is None:
                raise ValueError(
                    "successful content-region samples require a review-note hash"
                )
        elif not self.error_code:
            raise ValueError("failed content-region samples require an error code")
        return self


__all__ = [
    "ContentRegionObservationOutcome",
    "ContentRegionObservationRecord",
    "ContentRegionProfileRecord",
    "ContentRegionProfileStatus",
]
