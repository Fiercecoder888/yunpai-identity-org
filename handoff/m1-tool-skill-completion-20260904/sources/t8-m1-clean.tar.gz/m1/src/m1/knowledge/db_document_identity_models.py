"""Tenant-safe persistence rows for governed document identity routing."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    CheckConstraint,
    DateTime,
    ForeignKeyConstraint,
    Index,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import KnowledgeBase, TenantScopedMixin


class DocumentIdentityBindingRow(TenantScopedMixin, KnowledgeBase):
    """One verified external or manually confirmed logical document identity."""

    __tablename__ = "knowledge_document_identity_bindings"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "identity_kind",
            "identity_namespace",
            "identity_value",
            name="document_identity_binding_key",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "document_id"],
            ["knowledge_documents.tenant_id", "knowledge_documents.document_id"],
            name="document_identity_binding_document",
            ondelete="RESTRICT",
        ),
        CheckConstraint(
            "identity_kind IN ('verified_external','manual_confirmed')",
            name="identity_kind",
        ),
        Index(
            "ix_document_identity_binding_document",
            "tenant_id",
            "document_id",
        ),
    )

    binding_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    document_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    identity_kind: Mapped[str] = mapped_column(String(32), nullable=False)
    identity_namespace: Mapped[str] = mapped_column(String(128), nullable=False)
    identity_value: Mapped[str] = mapped_column(String(512), nullable=False)
    approved_by: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class DocumentIdentityDecisionRow(TenantScopedMixin, KnowledgeBase):
    """One immutable identity decision for a source occurrence."""

    __tablename__ = "knowledge_document_identity_decisions"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "source_occurrence_id", name="document_identity_decision_occurrence"
        ),
        ForeignKeyConstraint(
            ["tenant_id", "source_asset_id"],
            ["knowledge_source_assets.tenant_id", "knowledge_source_assets.asset_id"],
            name="document_identity_decision_asset",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "source_occurrence_id"],
            [
                "knowledge_source_occurrences.tenant_id",
                "knowledge_source_occurrences.occurrence_id",
            ],
            name="document_identity_decision_occurrence_fk",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "document_id"],
            ["knowledge_documents.tenant_id", "knowledge_documents.document_id"],
            name="document_identity_decision_document",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "version_id"],
            [
                "knowledge_document_versions.tenant_id",
                "knowledge_document_versions.version_id",
            ],
            name="document_identity_decision_version",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "target_document_id"],
            ["knowledge_documents.tenant_id", "knowledge_documents.document_id"],
            name="document_identity_decision_target_document",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "target_version_id"],
            [
                "knowledge_document_versions.tenant_id",
                "knowledge_document_versions.version_id",
            ],
            name="document_identity_decision_target_version",
            ondelete="RESTRICT",
        ),
        CheckConstraint(
            "action IN ('exact_asset_replay','existing_document_new_version',"
            "'new_document','identity_candidate_review')",
            name="action",
        ),
        Index(
            "ix_document_identity_decision_target",
            "tenant_id",
            "target_document_id",
            "created_at",
        ),
    )

    decision_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    source_asset_id: Mapped[str] = mapped_column(String(128), nullable=False)
    source_occurrence_id: Mapped[str] = mapped_column(String(128), nullable=False)
    document_id: Mapped[str] = mapped_column(String(128), nullable=False)
    version_id: Mapped[str] = mapped_column(String(128), nullable=False)
    action: Mapped[str] = mapped_column(String(48), nullable=False)
    target_document_id: Mapped[str | None] = mapped_column(String(128))
    target_version_id: Mapped[str | None] = mapped_column(String(128))
    identity_kind: Mapped[str | None] = mapped_column(String(32))
    identity_namespace: Mapped[str | None] = mapped_column(String(128))
    identity_value: Mapped[str | None] = mapped_column(String(512))
    processing_revision: Mapped[str] = mapped_column(String(64), nullable=False)
    candidate_document_ids: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    candidate_methods: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    reason_codes: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


__all__ = ["DocumentIdentityBindingRow", "DocumentIdentityDecisionRow"]
