"""Authoritative document, entity, identity, and review row mappings."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import BitemporalMixin, KnowledgeBase, TenantScopedMixin


class TenantRow(KnowledgeBase):
    __tablename__ = "knowledge_tenants"
    __table_args__ = (
        UniqueConstraint("tenant_key", name="tenant_key"),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
    )

    tenant_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    tenant_key: Mapped[str] = mapped_column(String(128), nullable=False)
    display_name: Mapped[str] = mapped_column(String(256), nullable=False)
    lifecycle_status: Mapped[str] = mapped_column(String(32), nullable=False)
    default_acl: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class IngestionBatchRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_ingestion_batches"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="ingestion_batch_tenant_idempotency"
        ),
        CheckConstraint(
            "status IN ('staged','running','completed','partial','failed')",
            name="status",
        ),
    )

    batch_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    source_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    manifest: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    statistics: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class SourceAssetRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_source_assets"
    __table_args__ = (
        UniqueConstraint("tenant_id", "sha256", name="tenant_sha256"),
        UniqueConstraint("tenant_id", "asset_id", name="tenant_asset_id"),
        CheckConstraint("size_bytes >= 0", name="size_nonnegative"),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
    )

    asset_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    mime_type: Mapped[str] = mapped_column(String(256), nullable=False)
    object_uri: Mapped[str] = mapped_column(String(2048), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(1024), nullable=False)
    lifecycle_status: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class SourceOccurrenceRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_source_occurrences"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="source_occurrence_tenant_idempotency"
        ),
        UniqueConstraint("tenant_id", "occurrence_id", name="tenant_occurrence_id"),
    )

    occurrence_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    batch_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_ingestion_batches.batch_id", ondelete="RESTRICT"),
        index=True,
    )
    asset_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_source_assets.asset_id", ondelete="RESTRICT"),
        index=True,
    )
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    task_id: Mapped[str] = mapped_column(
        String(128), nullable=False, default="", index=True
    )
    source_system: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    source_uri: Mapped[str] = mapped_column(String(2048), nullable=False)
    archive_path: Mapped[str | None] = mapped_column(String(2048))
    display_filename: Mapped[str] = mapped_column(String(1024), nullable=False)
    source_modified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class KnowledgeDocumentRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_documents"
    __table_args__ = (
        UniqueConstraint("tenant_id", "canonical_key", name="tenant_canonical_key"),
        UniqueConstraint("tenant_id", "document_id", name="tenant_document_id"),
        CheckConstraint(
            "valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from",
            name="valid_window",
        ),
        CheckConstraint(
            "recorded_to IS NULL OR recorded_to > recorded_from",
            name="recorded_window",
        ),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
    )

    document_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    canonical_key: Mapped[str] = mapped_column(String(512), nullable=False)
    document_type: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    document_subtype: Mapped[str] = mapped_column(
        String(128), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(2048), nullable=False)
    lifecycle_status: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class DocumentVersionRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_document_versions"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "document_id", "version_number", name="document_version"
        ),
        UniqueConstraint(
            "tenant_id", "document_id", "content_hash", name="document_content"
        ),
        UniqueConstraint("tenant_id", "version_id", name="tenant_version_id"),
        ForeignKeyConstraint(
            ["tenant_id", "supersedes_version_id"],
            [
                "knowledge_document_versions.tenant_id",
                "knowledge_document_versions.version_id",
            ],
            name="tenant_version_supersedes",
            ondelete="RESTRICT",
        ),
        CheckConstraint("version_number >= 1", name="version_positive"),
        CheckConstraint(
            "valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from",
            name="valid_window",
        ),
        CheckConstraint(
            "recorded_to IS NULL OR recorded_to > recorded_from",
            name="recorded_window",
        ),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
    )

    version_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    document_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_documents.document_id", ondelete="RESTRICT"),
        index=True,
    )
    source_asset_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_source_assets.asset_id", ondelete="RESTRICT"),
        index=True,
    )
    source_occurrence_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_source_occurrences.occurrence_id", ondelete="RESTRICT"),
    )
    version_number: Mapped[int] = mapped_column(Integer, nullable=False)
    schema_version: Mapped[str] = mapped_column(String(64), nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    parser_version: Mapped[str] = mapped_column(String(128), nullable=False)
    processing_revision: Mapped[str] = mapped_column(
        String(64), nullable=False, default="legacy"
    )
    supersedes_version_id: Mapped[str | None] = mapped_column(String(128))
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    lifecycle_status: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class TaskLifecycleRow(TenantScopedMixin, KnowledgeBase):
    """Durable task epoch used to fence source-derived late writers."""

    __tablename__ = "knowledge_task_lifecycles"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "task_id", name="task_lifecycle_identity"
        ),
        CheckConstraint("epoch >= 0", name="epoch_nonnegative"),
        CheckConstraint(
            "status IN ('active','tombstoned')",
            name="status",
        ),
        Index(
            "ix_knowledge_task_lifecycle_lookup",
            "tenant_id",
            "task_id",
            "status",
        ),
    )

    lifecycle_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    task_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    epoch: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class TaskVersionBindingRow(TenantScopedMixin, KnowledgeBase):
    """Explicit provenance link between a legacy M1 task and a governed version.

    Several tasks may replay the same content-addressed version.  Keeping this
    link prevents deleting one occurrence from retiring data still referenced
    by another customer task.
    """

    __tablename__ = "knowledge_task_version_bindings"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "task_id",
            "version_id",
            name="task_version_binding_identity",
        ),
        CheckConstraint(
            "status IN ('active','tombstoned')",
            name="status",
        ),
        Index(
            "ix_knowledge_task_version_lookup",
            "tenant_id",
            "task_id",
            "status",
        ),
    )

    binding_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    task_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    version_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_document_versions.version_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    occurrence_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_source_occurrences.occurrence_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EntitySourceBindingRow(TenantScopedMixin, KnowledgeBase):
    """Version-scoped assertion that a canonical entity is still referenced."""

    __tablename__ = "knowledge_entity_source_bindings"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "entity_id",
            "version_id",
            name="entity_source_binding_identity",
        ),
        CheckConstraint(
            "status IN ('active','tombstoned')",
            name="status",
        ),
        Index(
            "ix_knowledge_entity_source_lookup",
            "tenant_id",
            "version_id",
            "status",
        ),
    )

    binding_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    version_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_document_versions.version_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    asserted_label: Mapped[str] = mapped_column(String(1024), nullable=False)
    asserted_attributes: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    asserted_lifecycle_status: Mapped[str] = mapped_column(String(32), nullable=False)
    asserted_confidence: Mapped[float] = mapped_column(Float, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EvidenceAnchorRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_evidence_anchors"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "document_version_id", "locator_hash", name="version_locator"
        ),
    )

    anchor_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    document_version_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_document_versions.version_id", ondelete="RESTRICT"),
        index=True,
    )
    anchor_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    locator: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    locator_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    excerpt: Mapped[str | None] = mapped_column(Text)
    excerpt_hash: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class FieldClaimRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_field_claims"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="field_claim_tenant_idempotency"
        ),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "status IN ('candidate','under_review','accepted','rejected','superseded')",
            name="status",
        ),
        Index(
            "ix_knowledge_field_claim_subject",
            "tenant_id",
            "subject_type",
            "subject_id",
        ),
        Index("ix_knowledge_field_claim_path", "tenant_id", "field_path"),
    )

    claim_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    subject_type: Mapped[str] = mapped_column(String(64), nullable=False)
    subject_id: Mapped[str] = mapped_column(String(128), nullable=False)
    field_path: Mapped[str] = mapped_column(String(1024), nullable=False)
    value: Mapped[Any] = mapped_column(JSON, nullable=True)
    normalized_value: Mapped[Any] = mapped_column(JSON, nullable=True)
    normalized_text: Mapped[str] = mapped_column(Text, nullable=False, default="")
    evidence_anchor_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_evidence_anchors.anchor_id", ondelete="RESTRICT"),
    )
    additional_evidence_anchor_ids: Mapped[list[str]] = mapped_column(
        JSON, nullable=False, default=list
    )
    extraction_method: Mapped[str] = mapped_column(String(64), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class CanonicalEntityRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_canonical_entities"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "entity_type", "canonical_key", name="entity_key"
        ),
        UniqueConstraint("tenant_id", "entity_id", name="tenant_entity_id"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
        Index(
            "ix_knowledge_entity_label", "tenant_id", "entity_type", "canonical_label"
        ),
    )

    entity_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    canonical_key: Mapped[str] = mapped_column(String(512), nullable=False)
    canonical_label: Mapped[str] = mapped_column(String(1024), nullable=False)
    attributes: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    lifecycle_status: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class ExternalIdentityRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_external_identities"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "entity_type",
            "source_system",
            "external_id",
            name="external_identity",
        ),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "status IN ('candidate','under_review','accepted','rejected','superseded')",
            name="status",
        ),
    )

    identity_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
        index=True,
    )
    entity_type: Mapped[str] = mapped_column(String(128), nullable=False)
    source_system: Mapped[str] = mapped_column(String(128), nullable=False)
    external_id: Mapped[str] = mapped_column(String(512), nullable=False, index=True)
    mapping_rule: Mapped[str] = mapped_column(String(256), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    conflicts: Mapped[list[dict[str, Any]]] = mapped_column(
        JSON, nullable=False, default=list
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class IdentitySourceBindingRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_identity_source_bindings"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "identity_id",
            "version_id",
            name="identity_source_binding_identity",
        ),
        CheckConstraint("status IN ('active','tombstoned')", name="status"),
        Index(
            "ix_knowledge_identity_source_lookup",
            "tenant_id",
            "version_id",
            "status",
        ),
    )

    binding_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    identity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_external_identities.identity_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    version_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_document_versions.version_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    asserted_status: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EntityAliasRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_entity_aliases"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "entity_id",
            "normalized_alias",
            "source_system",
            name="entity_alias",
        ),
        Index("ix_knowledge_alias_lookup", "tenant_id", "normalized_alias"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "status IN ('candidate','under_review','accepted','rejected','superseded')",
            name="status",
        ),
    )

    alias_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
        index=True,
    )
    alias: Mapped[str] = mapped_column(String(1024), nullable=False)
    normalized_alias: Mapped[str] = mapped_column(String(1024), nullable=False)
    language: Mapped[str] = mapped_column(String(16), nullable=False)
    source_system: Mapped[str] = mapped_column(String(128), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class AliasSourceBindingRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_alias_source_bindings"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "alias_id",
            "version_id",
            name="alias_source_binding_identity",
        ),
        CheckConstraint("status IN ('active','tombstoned')", name="status"),
        Index(
            "ix_knowledge_alias_source_lookup",
            "tenant_id",
            "version_id",
            "status",
        ),
    )

    binding_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    alias_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_entity_aliases.alias_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    version_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_document_versions.version_id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    asserted_status: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    tombstoned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EntityRevisionRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_entity_revisions"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "entity_id", "revision_number", name="entity_revision"
        ),
        CheckConstraint("revision_number >= 1", name="revision_positive"),
        CheckConstraint(
            "lifecycle_status IN ('raw','parsed','normalized','under_review','approved',"
            "'active','deprecated','rejected')",
            name="lifecycle_status",
        ),
    )

    revision_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
        index=True,
    )
    revision_number: Mapped[int] = mapped_column(Integer, nullable=False)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    based_on_revision_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_entity_revisions.revision_id", ondelete="RESTRICT"),
    )
    change_reason: Mapped[str] = mapped_column(String(2048), nullable=False)
    lifecycle_status: Mapped[str] = mapped_column(
        String(32), nullable=False, index=True
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class RelationshipClaimRow(TenantScopedMixin, BitemporalMixin, KnowledgeBase):
    __tablename__ = "knowledge_relationship_claims"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="relationship_tenant_idempotency"
        ),
        CheckConstraint("from_entity_id <> to_entity_id", name="different_endpoints"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "status IN ('candidate','under_review','accepted','rejected','superseded')",
            name="status",
        ),
        Index(
            "ix_knowledge_relationship_outgoing",
            "tenant_id",
            "from_entity_id",
            "relation_type",
            "status",
        ),
        Index(
            "ix_knowledge_relationship_incoming",
            "tenant_id",
            "to_entity_id",
            "relation_type",
            "status",
        ),
        Index(
            "ix_knowledge_relationship_source_version",
            "tenant_id",
            "source_record_id",
            "source_version",
            "status",
        ),
    )

    relationship_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    source_record_id: Mapped[str] = mapped_column(
        String(128), nullable=False, default="", index=True
    )
    source_version: Mapped[str] = mapped_column(
        String(128), nullable=False, default="", index=True
    )
    from_entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
    )
    relation_type: Mapped[str] = mapped_column(String(128), nullable=False)
    to_entity_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_canonical_entities.entity_id", ondelete="RESTRICT"),
    )
    properties: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    evidence_anchor_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_evidence_anchors.anchor_id", ondelete="RESTRICT"),
    )
    additional_evidence_anchor_ids: Mapped[list[str]] = mapped_column(
        JSON, nullable=False, default=list
    )
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class ReviewTaskRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_review_tasks"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="review_task_tenant_idempotency"
        ),
        CheckConstraint("priority >= 0 AND priority <= 100", name="priority_range"),
        CheckConstraint(
            "status IN ('open','in_review','resolved','cancelled')",
            name="status",
        ),
        Index(
            "ix_knowledge_review_queue", "tenant_id", "status", "priority", "created_at"
        ),
    )

    review_task_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    target_type: Mapped[str] = mapped_column(String(64), nullable=False)
    target_id: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    priority: Mapped[int] = mapped_column(Integer, nullable=False)
    reason_codes: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    summary: Mapped[str] = mapped_column(String(4096), nullable=False)
    assignee_id: Mapped[str | None] = mapped_column(String(256), index=True)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ReviewDecisionRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_review_decisions"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="review_decision_tenant_idempotency"
        ),
        CheckConstraint(
            "decision IN ('accept','reject','correct','merge','resolve','defer')",
            name="decision",
        ),
    )

    decision_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    review_task_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_review_tasks.review_task_id", ondelete="RESTRICT"),
        nullable=True,
    )
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    target_type: Mapped[str] = mapped_column(String(64), nullable=False)
    target_id: Mapped[str] = mapped_column(String(128), nullable=False)
    decision: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    reviewer_id: Mapped[str] = mapped_column(String(256), nullable=False, index=True)
    reason: Mapped[str] = mapped_column(String(4096), nullable=False)
    corrections: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    evidence_anchor_ids: Mapped[list[str]] = mapped_column(
        JSON, nullable=False, default=list
    )
    decided_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class ConflictRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_conflicts"
    __table_args__ = (
        CheckConstraint(
            "status IN ('open','resolved','accepted_risk','dismissed')",
            name="status",
        ),
        Index(
            "ix_knowledge_conflict_queue",
            "tenant_id",
            "status",
            "severity",
            "created_at",
        ),
    )

    conflict_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    subject_type: Mapped[str] = mapped_column(String(64), nullable=False)
    subject_id: Mapped[str] = mapped_column(String(128), nullable=False)
    field_path: Mapped[str] = mapped_column(String(1024), nullable=False)
    competing_claim_ids: Mapped[list[str]] = mapped_column(
        JSON, nullable=False, default=list
    )
    severity: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    resolution_decision_id: Mapped[str | None] = mapped_column(
        String(128),
        ForeignKey("knowledge_review_decisions.decision_id", ondelete="RESTRICT"),
    )
    details: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
