"""Tenant-scoped entity identity candidate and decision row mappings.

These tables are deliberately separate from the authoritative canonical entity
rows.  A vector match is only a candidate-generation aid; it must never alter
an entity's canonical label, external identities, lifecycle, or provenance.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    CheckConstraint,
    DateTime,
    ForeignKeyConstraint,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import KNOWLEDGE_EMBEDDING_TYPE, KnowledgeBase, TenantScopedMixin


class EntityRouteIndexRow(TenantScopedMixin, KnowledgeBase):
    """One current embedding-space projection for a canonical entity.

    The index stores only the normalized entity identity summary.  It never
    contains a source document, file name, task identifier, or prompt text.
    """

    __tablename__ = "knowledge_entity_route_index"
    __table_args__ = (
        ForeignKeyConstraint(
            ["tenant_id", "entity_id"],
            [
                "knowledge_canonical_entities.tenant_id",
                "knowledge_canonical_entities.entity_id",
            ],
            name="entity_route_index_tenant_entity",
            ondelete="RESTRICT",
        ),
        UniqueConstraint(
            "tenant_id",
            "entity_id",
            "embedding_model",
            "embedding_dimensions",
            name="entity_route_index_space",
        ),
        CheckConstraint("embedding_dimensions > 0", name="embedding_dimensions_positive"),
        Index(
            "ix_entity_route_index_lookup",
            "tenant_id",
            "entity_type",
            "embedding_model",
            "embedding_dimensions",
        ),
    )

    index_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    entity_id: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        index=True,
    )
    entity_type: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    normalized_text: Mapped[str] = mapped_column(Text, nullable=False)
    embedding: Mapped[list[float]] = mapped_column(
        KNOWLEDGE_EMBEDDING_TYPE, nullable=False
    )
    embedding_model: Mapped[str] = mapped_column(String(256), nullable=False)
    embedding_dimensions: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class EntityRouteDecisionRow(TenantScopedMixin, KnowledgeBase):
    """Auditable, non-authoritative entity identity routing decision."""

    __tablename__ = "knowledge_entity_route_decisions"
    __table_args__ = (
        ForeignKeyConstraint(
            ["tenant_id", "source_version_id"],
            [
                "knowledge_document_versions.tenant_id",
                "knowledge_document_versions.version_id",
            ],
            name="entity_route_decision_tenant_version",
            ondelete="RESTRICT",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "candidate_entity_id"],
            [
                "knowledge_canonical_entities.tenant_id",
                "knowledge_canonical_entities.entity_id",
            ],
            name="entity_route_decision_tenant_candidate",
            ondelete="RESTRICT",
        ),
        UniqueConstraint(
            "tenant_id",
            "source_version_id",
            "proposed_entity_id",
            name="entity_route_decision_source_proposal",
        ),
        CheckConstraint(
            "action IN ('link','new_candidate','review')", name="action"
        ),
        CheckConstraint(
            "candidate_score >= 0 AND candidate_score <= 1", name="candidate_score_range"
        ),
        CheckConstraint(
            "top1_top2_margin >= 0 AND top1_top2_margin <= 1", name="margin_range"
        ),
        CheckConstraint(
            "model_confidence >= 0 AND model_confidence <= 1", name="model_confidence_range"
        ),
        Index(
            "ix_entity_route_decisions_source",
            "tenant_id",
            "source_version_id",
            "created_at",
        ),
        Index(
            "ix_entity_route_decisions_candidate",
            "tenant_id",
            "candidate_entity_id",
            "created_at",
        ),
    )

    decision_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    source_version_id: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
        index=True,
    )
    proposed_entity_id: Mapped[str] = mapped_column(String(128), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    action: Mapped[str] = mapped_column(String(32), nullable=False)
    candidate_entity_id: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,
        index=True,
    )
    candidate_score: Mapped[float] = mapped_column(nullable=False, default=0.0)
    top1_top2_margin: Mapped[float] = mapped_column(nullable=False, default=0.0)
    model_confidence: Mapped[float] = mapped_column(nullable=False, default=0.0)
    reason_codes: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    model_name: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    model_revision: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


__all__ = ["EntityRouteDecisionRow", "EntityRouteIndexRow"]
