"""Compatibility exports for all governed knowledge SQLAlchemy rows."""

# Row imports are public compatibility exports for repositories and tests.
# ruff: noqa: F401
from .content_region_db_models import (
    ContentRegionObservationRow,
    ContentRegionProfileRow,
)
from .db_document_identity_models import (
    DocumentIdentityBindingRow,
    DocumentIdentityDecisionRow,
)
from .db_document_models import (
    AliasSourceBindingRow,
    CanonicalEntityRow,
    ConflictRow,
    DocumentVersionRow,
    EntityAliasRow,
    EntityRevisionRow,
    EntitySourceBindingRow,
    EvidenceAnchorRow,
    ExternalIdentityRow,
    FieldClaimRow,
    IdentitySourceBindingRow,
    IngestionBatchRow,
    KnowledgeDocumentRow,
    RelationshipClaimRow,
    ReviewDecisionRow,
    ReviewTaskRow,
    SourceAssetRow,
    SourceOccurrenceRow,
    TaskLifecycleRow,
    TaskVersionBindingRow,
    TenantRow,
)
from .db_entity_routing_models import EntityRouteDecisionRow, EntityRouteIndexRow
from .db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    KNOWLEDGE_EMBEDDING_TYPE,
    NAMING_CONVENTION,
    BitemporalMixin,
    IdempotencyConflictError,
    KnowledgeBase,
    PgVector,
    RecordNotFoundError,
    ReviewConflictError,
    TenantBoundaryError,
    TenantScopedMixin,
)
from .db_projection_models import (
    GraphGenerationRow,
    GraphProjectionSnapshotRow,
    KnowledgeChunkRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
)
from .db_routing_models import RouteObservationRow, RouteProfileRow
from .db_tabular_layout_models import (
    TabularLayoutObservationRow,
    TabularLayoutProfileRow,
)
from .field_semantic_db_models import (
    FieldSemanticObservationRow,
    FieldSemanticProfileRow,
)
from .region_capability_db_models import (
    RegionCapabilityObservationRow,
    RegionCapabilityProfileRow,
)
from .route_lifecycle_db_models import RouteLifecycleEventRow
from .visual_region_db_models import VisualRegionObservationRow, VisualRegionProfileRow
