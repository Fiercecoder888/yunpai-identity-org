"""Shared SQLAlchemy metadata, mixins, and repository exceptions."""

from __future__ import annotations

from datetime import datetime

try:
    from pgvector.sqlalchemy import Vector as PgVector
except (
    ImportError
):  # pragma: no cover - production knowledge extra is verified at startup
    PgVector = None
from sqlalchemy import JSON, DateTime, ForeignKey, MetaData, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from .schema import utc_now


KNOWLEDGE_EMBEDDING_DIMENSIONS = 1024
KNOWLEDGE_EMBEDDING_TYPE = (
    PgVector(KNOWLEDGE_EMBEDDING_DIMENSIONS).with_variant(
        JSON(none_as_null=True), "sqlite"
    )
    if PgVector is not None
    else JSON(none_as_null=True)
)


NAMING_CONVENTION = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class KnowledgeBase(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


class TenantScopedMixin:
    tenant_id: Mapped[str] = mapped_column(
        String(128),
        ForeignKey("knowledge_tenants.tenant_id", ondelete="RESTRICT"),
        index=True,
    )


class BitemporalMixin:
    valid_from: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    valid_to: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    recorded_from: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=utc_now, index=True
    )
    recorded_to: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )


class IdempotencyConflictError(ValueError):
    pass


class ReviewConflictError(ValueError):
    pass


class TenantBoundaryError(ValueError):
    pass


class RecordNotFoundError(LookupError):
    pass
