"""Search, graph projection, generation, and outbox row mappings."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    CheckConstraint,
    DateTime,
    Float,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import (
    KNOWLEDGE_EMBEDDING_TYPE,
    KnowledgeBase,
    TenantScopedMixin,
)


class KnowledgeChunkRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_chunks"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "source_record_id",
            "version",
            "chunk_id",
            name="source_version_chunk",
        ),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')", name="status"
        ),
        Index(
            "ix_knowledge_chunks_source_version",
            "tenant_id",
            "source_record_id",
            "version",
        ),
    )

    chunk_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    record_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    source_record_id: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[str] = mapped_column(String(128), nullable=False)
    chunk_kind: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    ordinal: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    content_sha256: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    field_paths: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    claim_ids: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    source_refs: Mapped[list[dict[str, Any]]] = mapped_column(
        JSON, nullable=False, default=list
    )
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class KnowledgeIndexRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_search_index"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "source_record_id",
            "version",
            "index_id",
            name="source_version_index",
        ),
        CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')", name="status"
        ),
        Index(
            "ix_knowledge_search_source_version",
            "tenant_id",
            "source_record_id",
            "version",
        ),
        Index(
            "ix_knowledge_search_scope",
            "tenant_id",
            "status",
            "document_type",
            "document_subtype",
        ),
    )

    index_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    record_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    source_record_id: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[str] = mapped_column(String(128), nullable=False)
    document_type: Mapped[str] = mapped_column(String(128), nullable=False)
    document_subtype: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    vector_text: Mapped[str] = mapped_column(Text, nullable=False)
    embedding: Mapped[list[float] | None] = mapped_column(
        KNOWLEDGE_EMBEDDING_TYPE, nullable=True
    )
    embedding_model: Mapped[str] = mapped_column(
        String(256), nullable=False, default=""
    )
    selected_fields: Mapped[dict[str, Any]] = mapped_column(
        JSON, nullable=False, default=dict
    )
    graph_keys: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    source_refs: Mapped[list[dict[str, Any]]] = mapped_column(
        JSON, nullable=False, default=list
    )
    metadata_json: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class GraphProjectionSnapshotRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_graph_snapshots"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "source_record_id", "version", name="source_version"
        ),
        CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')", name="status"
        ),
        CheckConstraint(
            "node_count >= 0 AND edge_count >= 0", name="counts_nonnegative"
        ),
        Index(
            "ix_knowledge_graph_source",
            "tenant_id",
            "source_record_id",
            "version",
            "status",
        ),
    )

    projection_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    source_record_id: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[str] = mapped_column(String(128), nullable=False)
    fingerprint: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    node_count: Mapped[int] = mapped_column(Integer, nullable=False)
    edge_count: Mapped[int] = mapped_column(Integer, nullable=False)
    projection_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    acl: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class GraphGenerationRow(TenantScopedMixin, KnowledgeBase):
    """Monotonic source generation used to reject stale Graph writers."""

    __tablename__ = "knowledge_graph_generations"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "source_record_id", name="graph_generation_source"
        ),
    )

    generation_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    source_record_id: Mapped[str] = mapped_column(String(128), nullable=False)
    generation: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class ProjectionOutboxRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_projection_outbox"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "projection_name",
            "idempotency_key",
            name="projection_idempotency",
        ),
        CheckConstraint("attempts >= 0", name="attempts_nonnegative"),
        CheckConstraint(
            "status IN ('pending','processing','delivered','failed')",
            name="status",
        ),
        Index(
            "ix_knowledge_outbox_delivery",
            "projection_name",
            "status",
            "available_at",
            "leased_until",
        ),
    )

    event_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    projection_name: Mapped[str] = mapped_column(String(128), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    aggregate_type: Mapped[str] = mapped_column(String(64), nullable=False)
    aggregate_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(128), nullable=False)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False)
    available_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    leased_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str] = mapped_column(Text, nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
