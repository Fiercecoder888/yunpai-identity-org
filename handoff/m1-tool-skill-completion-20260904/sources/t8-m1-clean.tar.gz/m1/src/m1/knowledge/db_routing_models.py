"""SQLAlchemy rows for governed reusable document routes."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKeyConstraint,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import (
    KNOWLEDGE_EMBEDDING_TYPE,
    KnowledgeBase,
    TenantScopedMixin,
)


class RouteProfileRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_route_profiles"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "profile_id", name="route_profile_tenant_identity"
        ),
        UniqueConstraint(
            "tenant_id", "profile_key", "version", name="route_profile_version"
        ),
        UniqueConstraint(
            "tenant_id",
            "supersedes_profile_id",
            name="route_profile_single_successor",
        ),
        UniqueConstraint(
            "tenant_id",
            "exact_fingerprint",
            "version",
            name="route_profile_fingerprint_version",
        ),
        CheckConstraint("version >= 1", name="version_positive"),
        CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')",
            name="status",
        ),
        CheckConstraint(
            "observation_count >= 0 AND success_count >= 0 AND failure_count >= 0",
            name="counts_nonnegative",
        ),
        CheckConstraint(
            "success_count + failure_count = observation_count",
            name="counts_consistent",
        ),
        CheckConstraint(
            "embedding_dimensions >= 0",
            name="embedding_dimensions_nonnegative",
        ),
        CheckConstraint(
            "(version = 1 AND supersedes_profile_id IS NULL) OR "
            "(version > 1 AND supersedes_profile_id IS NOT NULL)",
            name="revision_predecessor",
        ),
        ForeignKeyConstraint(
            ["tenant_id", "supersedes_profile_id"],
            [
                "knowledge_route_profiles.tenant_id",
                "knowledge_route_profiles.profile_id",
            ],
            name="fk_route_profile_supersedes_tenant",
            ondelete="RESTRICT",
        ),
        Index(
            "ix_route_profiles_lookup",
            "tenant_id",
            "status",
            "profile_key",
            "version",
        ),
        Index(
            "ix_route_profiles_fingerprint",
            "tenant_id",
            "exact_fingerprint",
            "status",
        ),
        Index(
            "ix_route_profiles_embedding_space",
            "tenant_id",
            "status",
            "embedding_model",
            "embedding_dimensions",
        ),
        Index(
            "ux_route_profiles_active_key",
            "tenant_id",
            "profile_key",
            unique=True,
            sqlite_where=text("status = 'active'"),
            postgresql_where=text("status = 'active'"),
        ),
        Index(
            "ux_route_profiles_active_fingerprint",
            "tenant_id",
            "exact_fingerprint",
            unique=True,
            sqlite_where=text("status = 'active'"),
            postgresql_where=text("status = 'active'"),
        ),
    )

    profile_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    profile_key: Mapped[str] = mapped_column(String(128), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    supersedes_profile_id: Mapped[str | None] = mapped_column(String(128))
    status: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    exact_fingerprint: Mapped[str] = mapped_column(
        String(64), nullable=False, index=True
    )
    signature_json: Mapped[dict[str, Any]] = mapped_column(
        "signature", JSON, nullable=False
    )
    embedding: Mapped[list[float] | None] = mapped_column(
        KNOWLEDGE_EMBEDDING_TYPE, nullable=True
    )
    embedding_model: Mapped[str] = mapped_column(
        String(256), nullable=False, default=""
    )
    embedding_dimensions: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0
    )
    policy_json: Mapped[dict[str, Any]] = mapped_column(
        "policy", JSON, nullable=False, default=dict
    )
    created_by: Mapped[str] = mapped_column(String(256), nullable=False)
    reviewed_by: Mapped[str | None] = mapped_column(String(256))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[str] = mapped_column(Text, nullable=False, default="")
    approved_by: Mapped[str | None] = mapped_column(String(256))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    observation_count: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    success_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    failure_count: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    last_observed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_failure_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


class RouteObservationRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_route_observations"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "idempotency_key", name="route_observation_idempotency"
        ),
        ForeignKeyConstraint(
            ["tenant_id", "profile_id"],
            [
                "knowledge_route_profiles.tenant_id",
                "knowledge_route_profiles.profile_id",
            ],
            name="fk_route_observation_profile_tenant",
            ondelete="RESTRICT",
        ),
        CheckConstraint("outcome IN ('success','failure')", name="outcome"),
        CheckConstraint("latency_ms >= 0", name="latency_nonnegative"),
        Index(
            "ix_route_observations_profile",
            "tenant_id",
            "profile_id",
            "observed_at",
        ),
        Index(
            "ix_route_observations_outcome",
            "tenant_id",
            "outcome",
            "observed_at",
        ),
    )

    observation_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    profile_id: Mapped[str] = mapped_column(String(128), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    exact_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    outcome: Mapped[str] = mapped_column(String(32), nullable=False)
    latency_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    error_code: Mapped[str] = mapped_column(String(128), nullable=False, default="")
    details_json: Mapped[dict[str, Any]] = mapped_column(
        "details", JSON, nullable=False, default=dict
    )
    observed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


__all__ = ["RouteObservationRow", "RouteProfileRow"]
