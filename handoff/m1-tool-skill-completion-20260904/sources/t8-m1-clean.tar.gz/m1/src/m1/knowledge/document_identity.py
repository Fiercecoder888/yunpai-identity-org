"""Safe document identity inputs and decisions.

Document parsing fields, filenames, and similarity are useful review signals,
but they are not document identity.  This module deliberately accepts only
source-owned identifiers and processing revisions as automatic routing inputs.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections.abc import Mapping, Sequence
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_IDENTITY_VALUE_MAX = 512
_IDENTITY_NAMESPACE_MAX = 128


class DocumentIdentityAction(StrEnum):
    """The only document identity outcomes admitted by the repository."""

    EXACT_ASSET_REPLAY = "exact_asset_replay"
    EXISTING_DOCUMENT_NEW_VERSION = "existing_document_new_version"
    NEW_DOCUMENT = "new_document"
    IDENTITY_CANDIDATE_REVIEW = "identity_candidate_review"


class DocumentIdentityHint(BaseModel):
    """A source-owned identity signal, never a parsed business field."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    kind: str = Field(min_length=1, max_length=32)
    namespace: str = Field(min_length=1, max_length=_IDENTITY_NAMESPACE_MAX)
    value: str = Field(min_length=1, max_length=_IDENTITY_VALUE_MAX)


class DocumentIdentityDecision(BaseModel):
    """Auditable identity routing result produced by server-side gates."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    action: DocumentIdentityAction
    processing_revision: str = Field(pattern=r"^[0-9a-f]{64}$")
    target_document_id: str | None = Field(default=None, max_length=128)
    target_version_id: str | None = Field(default=None, max_length=128)
    identity_hint: DocumentIdentityHint | None = None
    candidate_document_ids: tuple[str, ...] = Field(default=(), max_length=5)
    candidate_methods: tuple[str, ...] = Field(default=(), max_length=4)
    reason_codes: tuple[str, ...] = Field(default=(), max_length=8)

    @model_validator(mode="after")
    def _validate_action_shape(self) -> DocumentIdentityDecision:
        has_target = self.target_document_id is not None
        if self.action is DocumentIdentityAction.EXACT_ASSET_REPLAY:
            if not has_target or self.target_version_id is None:
                raise ValueError("exact asset replay requires a document and version")
        elif self.action is DocumentIdentityAction.EXISTING_DOCUMENT_NEW_VERSION:
            if not has_target or self.target_version_id is not None:
                raise ValueError("new version requires a document but no reused version")
            if self.identity_hint is None:
                raise ValueError("new version requires a verified or confirmed identity")
        elif self.action is DocumentIdentityAction.NEW_DOCUMENT:
            if has_target or self.target_version_id is not None:
                raise ValueError("new document must not target an existing document")
        elif self.action is DocumentIdentityAction.IDENTITY_CANDIDATE_REVIEW and (
            has_target or self.target_version_id is not None
        ):
            raise ValueError("identity candidate review must not target an existing document")
        return self


def _normalized_text(value: object, *, limit: int) -> str:
    normalized = unicodedata.normalize("NFKC", str(value or "")).strip()
    return normalized if len(normalized) <= limit else ""


def _metadata(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    extraction = payload.get("extraction")
    if not isinstance(extraction, Mapping):
        return {}
    metadata = extraction.get("metadata")
    return metadata if isinstance(metadata, Mapping) else {}


def _revision_values(value: object) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        values: Sequence[object] = (value,)
    elif isinstance(value, Mapping):
        values = tuple(value.values())
    elif isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
        values = value
    else:
        return ()
    return tuple(
        sorted(
            {
                normalized
                for item in values
                if (normalized := _normalized_text(item, limit=256))
            }
        )
    )


def processing_revision_from_payload(payload: Mapping[str, Any]) -> str:
    """Return a stable fingerprint of the parser/model contract used to parse.

    This is intentionally independent from extracted facts.  An unknown legacy
    record still receives a deterministic fingerprint, but cannot match the
    explicit revision metadata emitted by current routing code accidentally.
    """

    metadata = _metadata(payload)
    route_plan = metadata.get("route_plan")
    route_plan = route_plan if isinstance(route_plan, Mapping) else {}
    parser_targets = route_plan.get("backend_chain")
    target_revisions: list[str] = []
    if isinstance(parser_targets, Sequence) and not isinstance(
        parser_targets, (str, bytes, bytearray)
    ):
        for target in parser_targets:
            if isinstance(target, Mapping):
                revision = _normalized_text(target.get("revision"), limit=256)
                if revision:
                    target_revisions.append(revision)
    contract = _normalized_text(
        route_plan.get("contract_revision")
        or metadata.get("contract_revision")
        or payload.get("schema_version")
        or "m1.document.v2",
        limit=256,
    )
    parser = _normalized_text(
        route_plan.get("parser_revision")
        or metadata.get("parser_revision")
        or payload.get("parser_version")
        or "legacy",
        limit=256,
    )
    model_values = set(_revision_values(metadata.get("model_revision")))
    model_values.update(_revision_values(metadata.get("model_fingerprint")))
    model_values.update(_revision_values(metadata.get("model_fingerprints")))
    revision_payload = {
        "contract": contract,
        "parser": parser,
        "targets": sorted(set(target_revisions)),
        "models": sorted(model_values),
    }
    encoded = json.dumps(
        revision_payload,
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def source_sha256(payload: Mapping[str, Any], *, fallback: str) -> str:
    """Return the canonical source digest without accepting partial hashes."""

    source = payload.get("source")
    source = source if isinstance(source, Mapping) else {}
    candidate = _normalized_text(source.get("sha256"), limit=64).casefold()
    return candidate if _SHA256_RE.fullmatch(candidate) else fallback.casefold()


def has_complete_source_sha256(payload: Mapping[str, Any]) -> bool:
    """Whether the payload carries an actual source asset digest."""

    source = payload.get("source")
    source = source if isinstance(source, Mapping) else {}
    value = _normalized_text(source.get("sha256"), limit=64).casefold()
    return _SHA256_RE.fullmatch(value) is not None


def source_identity_hints(payload: Mapping[str, Any]) -> tuple[DocumentIdentityHint, ...]:
    """Return source metadata hints without trusting them as confirmations.

    ``verified_external_identity`` must be a source-owned mapping and include
    ``verified: true``.  ``logical_identity`` is intentionally only a review
    hint until an operator creates a manual confirmation binding.
    """

    source = payload.get("source")
    source = source if isinstance(source, Mapping) else {}
    hints: list[DocumentIdentityHint] = []
    external = source.get("verified_external_identity")
    if isinstance(external, Mapping) and external.get("verified") is True:
        namespace = _normalized_text(external.get("source_system"), limit=_IDENTITY_NAMESPACE_MAX)
        value = _normalized_text(external.get("external_id"), limit=_IDENTITY_VALUE_MAX)
        if namespace and value:
            hints.append(
                DocumentIdentityHint(
                    kind="verified_external",
                    namespace=namespace,
                    value=value,
                )
            )
    logical = source.get("logical_identity")
    if isinstance(logical, Mapping):
        namespace = _normalized_text(
            logical.get("namespace") or "manual", limit=_IDENTITY_NAMESPACE_MAX
        )
        value = _normalized_text(logical.get("value"), limit=_IDENTITY_VALUE_MAX)
        if namespace and value:
            hints.append(
                DocumentIdentityHint(
                    kind="manual_hint",
                    namespace=namespace,
                    value=value,
                )
            )
    return tuple(hints)


def safe_new_document_key(
    *,
    source_digest: str,
    source_occurrence_id: str,
    processing_revision: str,
    content_hash: str,
) -> str:
    """A non-merging key for documents with no verified identity binding.

    The occurrence token is deliberate.  A content hash inferred from an
    extracted payload is not proof that two uploads are one business document;
    only the separate exact-asset replay gate can reuse a version.
    """

    return (
        f"asset:{source_digest}:occurrence:{source_occurrence_id}:"
        f"revision:{processing_revision}:content:{content_hash}"
    )[:512]


__all__ = [
    "DocumentIdentityAction",
    "DocumentIdentityDecision",
    "DocumentIdentityHint",
    "has_complete_source_sha256",
    "processing_revision_from_payload",
    "safe_new_document_key",
    "source_identity_hints",
    "source_sha256",
]
