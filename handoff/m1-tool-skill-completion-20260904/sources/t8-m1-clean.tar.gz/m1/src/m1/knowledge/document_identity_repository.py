"""Repository helpers for safe document identity and immutable version lineage."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    DocumentIdentityBindingRow,
    DocumentIdentityDecisionRow,
    DocumentVersionRow,
    IdempotencyConflictError,
    KnowledgeDocumentRow,
    RecordNotFoundError,
    SourceAssetRow,
    SourceOccurrenceRow,
)
from .document_identity import (
    DocumentIdentityAction,
    DocumentIdentityDecision,
    DocumentIdentityHint,
    has_complete_source_sha256,
    processing_revision_from_payload,
    safe_new_document_key,
    source_identity_hints,
)
from .schema import LifecycleStatus, TaskTombstonedError, new_id, utc_now

_REPLAYABLE_VERSION_STATES = {
    LifecycleStatus.PARSED.value,
    LifecycleStatus.NORMALIZED.value,
    LifecycleStatus.APPROVED.value,
    LifecycleStatus.ACTIVE.value,
}
_TERMINAL_DOCUMENT_STATES = {
    LifecycleStatus.DEPRECATED.value,
    LifecycleStatus.REJECTED.value,
}


class KnowledgeDocumentIdentityMixin:
    """Resolve identity from trusted source metadata, never parsed business facts."""

    async def _existing_document_identity_decision_row_for_occurrence_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        source_occurrence_id: str,
    ) -> DocumentIdentityDecisionRow | None:
        """Replay an immutable decision for an idempotent source occurrence.

        The first ingest can legitimately decide ``new_document`` while the
        same bytes become an ``exact_asset_replay`` candidate after that
        transaction commits.  A retry must preserve the first audit decision,
        rather than record two actions for one occurrence or create another
        version.  The occurrence is already tenant-scoped and content-locked
        by the ingestion batch idempotency key before this helper is called.
        """

        return await session.scalar(
            select(DocumentIdentityDecisionRow)
            .where(
                DocumentIdentityDecisionRow.tenant_id == tenant_id,
                DocumentIdentityDecisionRow.source_occurrence_id
                == source_occurrence_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
    async def _find_document_identity_binding_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        identity_kind: str,
        namespace: str,
        value: str,
    ) -> DocumentIdentityBindingRow | None:
        return await session.scalar(
            select(DocumentIdentityBindingRow)
            .where(
                DocumentIdentityBindingRow.tenant_id == tenant_id,
                DocumentIdentityBindingRow.identity_kind == identity_kind,
                DocumentIdentityBindingRow.identity_namespace == namespace,
                DocumentIdentityBindingRow.identity_value == value,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )

    async def _document_for_identity_binding_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        binding: DocumentIdentityBindingRow,
    ) -> KnowledgeDocumentRow | None:
        document = await session.scalar(
            select(KnowledgeDocumentRow)
            .where(
                KnowledgeDocumentRow.tenant_id == tenant_id,
                KnowledgeDocumentRow.document_id == binding.document_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if document is None or document.lifecycle_status in _TERMINAL_DOCUMENT_STATES:
            return None
        return document

    @staticmethod
    def _replayable_version(row: DocumentVersionRow, payload: Mapping[str, Any]) -> bool:
        if row.lifecycle_status not in _REPLAYABLE_VERSION_STATES:
            return False
        source = payload.get("source")
        source = source if isinstance(source, Mapping) else {}
        stored_source = row.payload.get("source") if isinstance(row.payload, dict) else {}
        stored_source = stored_source if isinstance(stored_source, Mapping) else {}
        return (
            not bool(payload.get("needs_review"))
            and not bool((row.payload or {}).get("needs_review"))
            and str(source.get("sha256") or "").casefold()
            == str(stored_source.get("sha256") or "").casefold()
        )

    async def _resolve_document_identity_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        payload: Mapping[str, Any],
        source_asset: SourceAssetRow,
        content_hash: str,
    ) -> DocumentIdentityDecision:
        """Return the only allowed document identity decision for this ingest.

        Exact source bytes are replayable only when the processing revision and
        canonical payload match.  A verified external ID or a manually approved
        logical identity can select a version chain.  All other signals remain
        review-only and must never select an existing document automatically.
        """

        revision = processing_revision_from_payload(payload)
        replay_rows = []
        if has_complete_source_sha256(payload):
            replay_rows = (
                await session.scalars(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.source_asset_id == source_asset.asset_id,
                        DocumentVersionRow.processing_revision == revision,
                        DocumentVersionRow.content_hash == content_hash,
                    )
                    .order_by(
                        DocumentVersionRow.created_at.desc(),
                        DocumentVersionRow.version_id.desc(),
                    )
                )
            ).all()
        replayable_rows = [
            row for row in replay_rows if self._replayable_version(row, payload)
        ]
        if len(replayable_rows) == 1:
            row = replayable_rows[0]
            return DocumentIdentityDecision(
                action=DocumentIdentityAction.EXACT_ASSET_REPLAY,
                processing_revision=revision,
                target_document_id=row.document_id,
                target_version_id=row.version_id,
                reason_codes=("exact_source_sha256_and_processing_revision",),
            )
        if not replayable_rows:
            retired = next(
                (
                    row
                    for row in replay_rows
                    if row.lifecycle_status in _TERMINAL_DOCUMENT_STATES
                ),
                None,
            )
            if retired is not None:
                raise TaskTombstonedError(
                    "document version is retired and cannot be rebound: "
                    f"{retired.version_id}"
                )

        hints = source_identity_hints(payload)
        first_verified_hint: DocumentIdentityHint | None = None
        for hint in hints:
            if hint.kind == "verified_external":
                binding_kind = "verified_external"
                first_verified_hint = first_verified_hint or hint
            elif hint.kind == "manual_hint":
                binding_kind = "manual_confirmed"
            else:  # defensive closed vocabulary guard
                continue
            binding = await self._find_document_identity_binding_in_session(
                session,
                tenant_id=tenant_id,
                identity_kind=binding_kind,
                namespace=hint.namespace,
                value=hint.value,
            )
            if binding is None:
                continue
            target = await self._document_for_identity_binding_in_session(
                session, tenant_id=tenant_id, binding=binding
            )
            if target is None:
                continue
            return DocumentIdentityDecision(
                action=DocumentIdentityAction.EXISTING_DOCUMENT_NEW_VERSION,
                processing_revision=revision,
                target_document_id=target.document_id,
                identity_hint=DocumentIdentityHint(
                    kind=binding_kind,
                    namespace=hint.namespace,
                    value=hint.value,
                ),
                reason_codes=("verified_or_manually_confirmed_identity",),
            )

        # A previously unseen, verified source ID establishes a new logical
        # document. It is not a similarity decision and therefore does not need
        # a candidate-review merge gate.
        if first_verified_hint is not None:
            return DocumentIdentityDecision(
                action=DocumentIdentityAction.NEW_DOCUMENT,
                processing_revision=revision,
                identity_hint=first_verified_hint,
                reason_codes=("first_seen_verified_external_identity",),
            )

        asset_documents = (
            await session.scalars(
                select(DocumentVersionRow.document_id)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.source_asset_id == source_asset.asset_id,
                )
                .distinct()
                .limit(5)
            )
        ).all()
        candidate_ids = tuple(sorted({str(item) for item in asset_documents if item}))
        if hints or candidate_ids:
            return DocumentIdentityDecision(
                action=DocumentIdentityAction.IDENTITY_CANDIDATE_REVIEW,
                processing_revision=revision,
                identity_hint=hints[0] if hints else None,
                candidate_document_ids=candidate_ids,
                reason_codes=(
                    "unconfirmed_source_identity"
                    if hints
                    else "same_asset_changed_processing_or_payload"
                ,),
            )
        return DocumentIdentityDecision(
            action=DocumentIdentityAction.NEW_DOCUMENT,
            processing_revision=revision,
            reason_codes=("no_verified_or_confirmed_identity",),
        )

    async def _bind_document_identity_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        document_id: str,
        hint: DocumentIdentityHint,
        approved_by: str,
    ) -> DocumentIdentityBindingRow:
        if hint.kind not in {"verified_external", "manual_confirmed"}:
            raise ValueError("only verified or manually confirmed document identities bind")
        existing = await self._find_document_identity_binding_in_session(
            session,
            tenant_id=tenant_id,
            identity_kind=hint.kind,
            namespace=hint.namespace,
            value=hint.value,
        )
        if existing is not None:
            if existing.document_id != document_id:
                raise IdempotencyConflictError(
                    f"document-identity:{hint.kind}:{hint.namespace}:{hint.value}"
                )
            return existing
        row = DocumentIdentityBindingRow(
            binding_id=new_id(),
            tenant_id=tenant_id,
            document_id=document_id,
            identity_kind=hint.kind,
            identity_namespace=hint.namespace,
            identity_value=hint.value,
            approved_by=approved_by[:256],
            created_at=utc_now(),
        )
        session.add(row)
        await session.flush()
        return row

    async def confirm_document_logical_identity(
        self,
        tenant_id: str,
        *,
        document_id: str,
        namespace: str,
        value: str,
        approved_by: str,
    ) -> str:
        """Create the explicit manual confirmation required for future versions."""

        hint = DocumentIdentityHint(
            kind="manual_confirmed",
            namespace=namespace,
            value=value,
        )

        async def operation(session: AsyncSession) -> str:
            await self._require_tenant(session, tenant_id)
            document = await session.scalar(
                select(KnowledgeDocumentRow).where(
                    KnowledgeDocumentRow.tenant_id == tenant_id,
                    KnowledgeDocumentRow.document_id == document_id,
                )
            )
            if document is None:
                raise RecordNotFoundError(document_id)
            if document.lifecycle_status in _TERMINAL_DOCUMENT_STATES:
                raise ValueError("retired documents cannot receive identity confirmations")
            binding = await self._bind_document_identity_in_session(
                session,
                tenant_id=tenant_id,
                document_id=document_id,
                hint=hint,
                approved_by=approved_by,
            )
            return binding.binding_id

        return await self._write(operation)

    async def _record_document_identity_decision_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        source_asset_id: str,
        source_occurrence_id: str,
        document_id: str,
        version_id: str,
        decision: DocumentIdentityDecision,
    ) -> str:
        existing = await session.scalar(
            select(DocumentIdentityDecisionRow)
            .where(
                DocumentIdentityDecisionRow.tenant_id == tenant_id,
                DocumentIdentityDecisionRow.source_occurrence_id == source_occurrence_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        hint = decision.identity_hint
        if existing is not None:
            same = (
                existing.document_id == document_id
                and existing.version_id == version_id
                and existing.action == decision.action.value
                and existing.target_document_id == decision.target_document_id
                and existing.target_version_id == decision.target_version_id
                and existing.processing_revision == decision.processing_revision
                and existing.identity_kind == (hint.kind if hint else None)
                and existing.identity_namespace == (hint.namespace if hint else None)
                and existing.identity_value == (hint.value if hint else None)
                and tuple(existing.candidate_document_ids or ())
                == tuple(decision.candidate_document_ids)
                and tuple(existing.candidate_methods or ())
                == tuple(decision.candidate_methods)
                and tuple(existing.reason_codes or ()) == tuple(decision.reason_codes)
            )
            if not same:
                raise IdempotencyConflictError(
                    f"document-identity-decision:{source_occurrence_id}"
                )
            return existing.decision_id
        row = DocumentIdentityDecisionRow(
            decision_id=new_id(),
            tenant_id=tenant_id,
            source_asset_id=source_asset_id,
            source_occurrence_id=source_occurrence_id,
            document_id=document_id,
            version_id=version_id,
            action=decision.action.value,
            target_document_id=decision.target_document_id,
            target_version_id=decision.target_version_id,
            identity_kind=hint.kind if hint else None,
            identity_namespace=hint.namespace if hint else None,
            identity_value=hint.value if hint else None,
            processing_revision=decision.processing_revision,
            candidate_document_ids=list(decision.candidate_document_ids),
            candidate_methods=list(decision.candidate_methods),
            reason_codes=list(decision.reason_codes),
            created_at=utc_now(),
        )
        session.add(row)
        await session.flush()
        return row.decision_id

    @staticmethod
    def _new_document_key(
        *,
        source_asset: SourceAssetRow,
        source_occurrence: SourceOccurrenceRow,
        decision: DocumentIdentityDecision,
        content_hash: str,
    ) -> str:
        return safe_new_document_key(
            source_digest=source_asset.sha256,
            source_occurrence_id=source_occurrence.occurrence_id,
            processing_revision=decision.processing_revision,
            content_hash=content_hash,
        )


__all__ = ["KnowledgeDocumentIdentityMixin"]
