"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from typing import Any, TypeVar

from pydantic import BaseModel
from sqlalchemy import (
    func,
    select,
)
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    CanonicalEntityRow,
    DocumentVersionRow,
    EvidenceAnchorRow,
    FieldClaimRow,
    GraphGenerationRow,
    IdempotencyConflictError,
    IngestionBatchRow,
    KnowledgeDocumentRow,
    ProjectionOutboxRow,
    RecordNotFoundError,
    RelationshipClaimRow,
    ReviewTaskRow,
    SourceAssetRow,
    SourceOccurrenceRow,
)
from .document_identity import DocumentIdentityAction
from .graph_taxonomy import CANONICAL_ENTITY_GRAPH_LABELS, LOGICAL_GRAPH_RELATIONS
from .models import (
    GraphEdge,
    GraphNode,
    GraphProjection,
)
from .persistence_helpers import (
    _anchor_row,
    _asset_row,
    _batch_row,
    _canonical_json,
    _conflict_row,
    _document_row,
    _fallback_claim_paths,
    _field_claim_row,
    _normalize_text,
    _occurrence_row,
    _resolve_path,
    _review_task_row,
    _sha256_json,
    _version_record,
    _version_row,
)
from .schema import (
    AccessControl,
    BatchStatus,
    ClaimStatus,
    ConflictRecord,
    DocumentVersionRecord,
    EvidenceAnchorRecord,
    FieldClaimRecord,
    IngestDocumentResult,
    IngestionBatchRecord,
    KnowledgeDocumentRecord,
    LifecycleStatus,
    ProjectionEventRecord,
    ReviewTaskRecord,
    SourceAssetRecord,
    SourceOccurrenceRecord,
    TaskFenceToken,
    TaskTombstonedError,
    new_id,
    utc_now,
)

T = TypeVar("T")


class KnowledgeDocumentMixin:
    async def ingest_document(
        self,
        tenant_id: str,
        task_id: str,
        document: BaseModel | dict[str, Any],
        idempotency_key: str | None = None,
        fence: TaskFenceToken | None = None,
    ) -> IngestDocumentResult:
        """Atomically ingest one ``m1.document.v2`` into the governed Wiki.

        Existing M1 task/document rows are untouched.  Replaying identical
        content returns the original version and does not duplicate claims,
        evidence, review tasks, or projection events.
        """

        raw_payload = (
            document.model_dump(mode="json")
            if isinstance(document, BaseModel)
            else dict(document)
        )
        # SQLAlchemy's portable JSON type cannot serialize dates/Decimals from a
        # caller-provided plain dict.  Canonicalizing here makes hashing and
        # persistence use the exact same lossless JSON representation.
        payload = json.loads(_canonical_json(raw_payload))
        content_hash = _sha256_json(payload)
        source = (
            payload.get("source") if isinstance(payload.get("source"), dict) else {}
        )
        supplied_hash = str(source.get("sha256") or "").lower()
        source_hash = (
            supplied_hash
            if re.fullmatch(r"[0-9a-f]{64}", supplied_hash)
            else content_hash
        )
        operation_key = idempotency_key or f"m1:{task_id}:{content_hash}"

        async def operation(session: AsyncSession) -> IngestDocumentResult:
            if fence is not None:
                await self._assert_task_fence(
                    session,
                    fence,
                    tenant_id=tenant_id,
                    task_id=task_id,
                )
            tenant = await self._require_tenant(session, tenant_id)
            acl = AccessControl.model_validate(tenant.default_acl or {})

            batch = await session.scalar(
                select(IngestionBatchRow).where(
                    IngestionBatchRow.tenant_id == tenant_id,
                    IngestionBatchRow.idempotency_key == operation_key,
                )
            )
            if batch is None:
                batch_record = IngestionBatchRecord(
                    tenant_id=tenant_id,
                    idempotency_key=operation_key,
                    source_type="m1.document.v2",
                    status=BatchStatus.COMPLETED,
                    manifest={"task_id": task_id, "content_hash": content_hash},
                    statistics={"documents": 1},
                    acl=acl,
                    started_at=utc_now(),
                    completed_at=utc_now(),
                )
                batch = _batch_row(batch_record)
                session.add(batch)
                await session.flush()
            elif batch.manifest.get("content_hash") != content_hash:
                raise IdempotencyConflictError(operation_key)

            asset = await session.scalar(
                select(SourceAssetRow).where(
                    SourceAssetRow.tenant_id == tenant_id,
                    SourceAssetRow.sha256 == source_hash,
                )
            )
            if asset is None:
                asset_record = SourceAssetRecord(
                    tenant_id=tenant_id,
                    sha256=source_hash,
                    size_bytes=int(source.get("size_bytes") or 0),
                    mime_type=str(
                        source.get("mime_type") or "application/octet-stream"
                    ),
                    object_uri=str(source.get("object_uri") or f"m1-task://{task_id}"),
                    original_filename=str(source.get("original_filename") or ""),
                    lifecycle_status=LifecycleStatus.PARSED,
                    acl=acl,
                    metadata={"supplied_sha256": supplied_hash}
                    if supplied_hash != source_hash
                    else {},
                )
                asset = _asset_row(asset_record)
                session.add(asset)
                await session.flush()

            occurrence = await session.scalar(
                select(SourceOccurrenceRow).where(
                    SourceOccurrenceRow.tenant_id == tenant_id,
                    SourceOccurrenceRow.idempotency_key
                    == f"{operation_key}:occurrence",
                )
            )
            if occurrence is None:
                occurrence_record = SourceOccurrenceRecord(
                    tenant_id=tenant_id,
                    batch_id=batch.batch_id,
                    asset_id=asset.asset_id,
                    idempotency_key=f"{operation_key}:occurrence",
                    source_system="m1",
                    source_uri=str(source.get("source_uri") or f"m1-task://{task_id}"),
                    archive_path=source.get("archive_path"),
                    display_filename=str(
                        source.get("display_filename")
                        or source.get("original_filename")
                        or ""
                    ),
                    metadata={"task_id": task_id},
                )
                occurrence = _occurrence_row(occurrence_record)
                session.add(occurrence)
                await session.flush()

            prior_identity_decision = (
                await self._existing_document_identity_decision_row_for_occurrence_in_session(
                    session,
                    tenant_id=tenant_id,
                    source_occurrence_id=occurrence.occurrence_id,
                )
            )
            if prior_identity_decision is not None:
                if prior_identity_decision.source_asset_id != asset.asset_id:
                    raise ValueError("source occurrence identity decision asset mismatch")
                knowledge_document = await session.scalar(
                    select(KnowledgeDocumentRow).where(
                        KnowledgeDocumentRow.tenant_id == tenant_id,
                        KnowledgeDocumentRow.document_id
                        == prior_identity_decision.document_id,
                    )
                )
                existing_version = await session.scalar(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.version_id == prior_identity_decision.version_id,
                    )
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if knowledge_document is None or existing_version is None:
                    raise RecordNotFoundError("source occurrence identity replay target disappeared")
                if existing_version.document_id != knowledge_document.document_id:
                    raise ValueError("source occurrence identity replay lineage is inconsistent")
                if existing_version.lifecycle_status in {
                    LifecycleStatus.DEPRECATED.value,
                    LifecycleStatus.REJECTED.value,
                }:
                    raise TaskTombstonedError(
                        "document version is retired and cannot be rebound: "
                        f"{existing_version.version_id}"
                    )
                await self._lock_graph_generation_row(
                    session,
                    tenant_id=tenant_id,
                    source_record_id=knowledge_document.document_id,
                )
                await self._bind_task_version(
                    session,
                    tenant_id=tenant_id,
                    task_id=task_id,
                    version_id=existing_version.version_id,
                    occurrence_id=occurrence.occurrence_id,
                    reactivate=bool(fence and fence.reactivated),
                )
                return await self._existing_ingest_result(
                    session,
                    tenant_id,
                    task_id,
                    batch,
                    asset,
                    occurrence,
                    knowledge_document,
                    existing_version,
                )

            identity_decision = await self._resolve_document_identity_in_session(
                session,
                tenant_id=tenant_id,
                payload=payload,
                source_asset=asset,
                content_hash=content_hash,
            )
            if identity_decision.action is DocumentIdentityAction.EXACT_ASSET_REPLAY:
                knowledge_document = await session.scalar(
                    select(KnowledgeDocumentRow).where(
                        KnowledgeDocumentRow.tenant_id == tenant_id,
                        KnowledgeDocumentRow.document_id
                        == identity_decision.target_document_id,
                    )
                )
                existing_version = await session.scalar(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.version_id
                        == identity_decision.target_version_id,
                    )
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if knowledge_document is None or existing_version is None:
                    raise RecordNotFoundError("exact source replay target disappeared")
                if existing_version.document_id != knowledge_document.document_id:
                    raise ValueError("exact source replay target lineage is inconsistent")
                await self._lock_graph_generation_row(
                    session,
                    tenant_id=tenant_id,
                    source_record_id=knowledge_document.document_id,
                )
                await self._bind_task_version(
                    session,
                    tenant_id=tenant_id,
                    task_id=task_id,
                    version_id=existing_version.version_id,
                    occurrence_id=occurrence.occurrence_id,
                    reactivate=bool(fence and fence.reactivated),
                )
                await self._record_document_identity_decision_in_session(
                    session,
                    tenant_id=tenant_id,
                    source_asset_id=asset.asset_id,
                    source_occurrence_id=occurrence.occurrence_id,
                    document_id=knowledge_document.document_id,
                    version_id=existing_version.version_id,
                    decision=identity_decision,
                )
                return await self._existing_ingest_result(
                    session,
                    tenant_id,
                    task_id,
                    batch,
                    asset,
                    occurrence,
                    knowledge_document,
                    existing_version,
                )

            knowledge_document: KnowledgeDocumentRow | None = None
            if (
                identity_decision.action
                is DocumentIdentityAction.EXISTING_DOCUMENT_NEW_VERSION
            ):
                knowledge_document = await session.scalar(
                    select(KnowledgeDocumentRow)
                    .where(
                        KnowledgeDocumentRow.tenant_id == tenant_id,
                        KnowledgeDocumentRow.document_id
                        == identity_decision.target_document_id,
                    )
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if knowledge_document is None:
                    raise RecordNotFoundError("confirmed document identity target disappeared")
                if knowledge_document.lifecycle_status in {
                    LifecycleStatus.DEPRECATED.value,
                    LifecycleStatus.REJECTED.value,
                }:
                    raise TaskTombstonedError(
                        "confirmed document identity target is retired: "
                        f"{knowledge_document.document_id}"
                    )

            canonical_key = self._new_document_key(
                source_asset=asset,
                source_occurrence=occurrence,
                decision=identity_decision,
                content_hash=content_hash,
            )
            header = (
                payload.get("header") if isinstance(payload.get("header"), dict) else {}
            )
            if knowledge_document is None:
                document_record = KnowledgeDocumentRecord(
                    tenant_id=tenant_id,
                    canonical_key=canonical_key,
                    document_type=str(payload.get("document_type") or "unknown"),
                    document_subtype=str(payload.get("document_subtype") or "unknown"),
                    title=str(
                        header.get("title") or source.get("display_filename") or ""
                    ),
                    lifecycle_status=LifecycleStatus.PARSED,
                    acl=acl,
                    metadata={"first_m1_task_id": task_id},
                )
                knowledge_document = _document_row(document_record)
                session.add(knowledge_document)
                await session.flush()
                session.add(
                    GraphGenerationRow(
                        generation_id=new_id(),
                        source_record_id=knowledge_document.document_id,
                        tenant_id=tenant_id,
                        generation=0,
                        updated_at=utc_now(),
                    )
                )
                if (
                    identity_decision.identity_hint is not None
                    and identity_decision.identity_hint.kind == "verified_external"
                ):
                    await self._bind_document_identity_in_session(
                        session,
                        tenant_id=tenant_id,
                        document_id=knowledge_document.document_id,
                        hint=identity_decision.identity_hint,
                        approved_by="source-verified",
                    )

            existing_version = await session.scalar(
                select(DocumentVersionRow).where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == knowledge_document.document_id,
                    DocumentVersionRow.content_hash == content_hash,
                )
            )
            if existing_version:
                await self._lock_graph_generation_row(
                    session,
                    tenant_id=tenant_id,
                    source_record_id=knowledge_document.document_id,
                )
                existing_version = await session.scalar(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.version_id == existing_version.version_id,
                    )
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
                if existing_version is None:  # pragma: no cover - FK/lock invariant
                    raise RecordNotFoundError("document version disappeared")
                if existing_version.lifecycle_status in {
                    LifecycleStatus.DEPRECATED.value,
                    LifecycleStatus.REJECTED.value,
                }:
                    raise TaskTombstonedError(
                        "document version is retired and cannot be rebound: "
                        f"{existing_version.version_id}"
                    )
                await self._bind_task_version(
                    session,
                    tenant_id=tenant_id,
                    task_id=task_id,
                    version_id=existing_version.version_id,
                    occurrence_id=occurrence.occurrence_id,
                    reactivate=bool(fence and fence.reactivated),
                )
                await self._record_document_identity_decision_in_session(
                    session,
                    tenant_id=tenant_id,
                    source_asset_id=asset.asset_id,
                    source_occurrence_id=occurrence.occurrence_id,
                    document_id=knowledge_document.document_id,
                    version_id=existing_version.version_id,
                    decision=identity_decision,
                )
                return await self._existing_ingest_result(
                    session,
                    tenant_id,
                    task_id,
                    batch,
                    asset,
                    occurrence,
                    knowledge_document,
                    existing_version,
                )

            previous_version = await session.scalar(
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == knowledge_document.document_id,
                )
                .order_by(
                    DocumentVersionRow.version_number.desc(),
                    DocumentVersionRow.version_id.desc(),
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            identity_review_required = (
                identity_decision.action
                is DocumentIdentityAction.IDENTITY_CANDIDATE_REVIEW
            )
            version_record = DocumentVersionRecord(
                tenant_id=tenant_id,
                document_id=knowledge_document.document_id,
                source_asset_id=asset.asset_id,
                source_occurrence_id=occurrence.occurrence_id,
                version_number=int(previous_version.version_number if previous_version else 0)
                + 1,
                schema_version=str(payload.get("schema_version") or "m1.document.v2"),
                content_hash=content_hash,
                parser_version=str(payload.get("parser_version") or "m1"),
                processing_revision=identity_decision.processing_revision,
                supersedes_version_id=(
                    previous_version.version_id
                    if (
                        previous_version is not None
                        and identity_decision.action
                        is DocumentIdentityAction.EXISTING_DOCUMENT_NEW_VERSION
                    )
                    else None
                ),
                payload=payload,
                lifecycle_status=(
                    LifecycleStatus.UNDER_REVIEW
                    if payload.get("needs_review") or identity_review_required
                    else LifecycleStatus.PARSED
                ),
                acl=acl,
            )
            version = _version_row(version_record)
            session.add(version)
            await session.flush()
            await self._bind_task_version(
                session,
                tenant_id=tenant_id,
                task_id=task_id,
                version_id=version.version_id,
                occurrence_id=occurrence.occurrence_id,
                reactivate=bool(fence and fence.reactivated),
            )

            anchor_count, claim_count = await self._ingest_document_claims(
                session, tenant_id, version.version_id, payload, acl
            )

            issues = payload.get("validation_issues")
            issues = issues if isinstance(issues, list) else []
            review_task: ReviewTaskRow | None = None
            if payload.get("needs_review") or issues or identity_review_required:
                reason_codes = [
                    str(issue.get("code"))
                    for issue in issues
                    if isinstance(issue, dict) and issue.get("code")
                ] or ["document_needs_review"]
                if identity_review_required:
                    reason_codes = list(
                        dict.fromkeys(
                            [
                                *reason_codes,
                                "document_identity_candidate_review",
                                *identity_decision.reason_codes,
                            ]
                        )
                    )
                review_record = ReviewTaskRecord(
                    tenant_id=tenant_id,
                    idempotency_key=f"version:{version.version_id}:review",
                    target_type="document_version",
                    target_id=version.version_id,
                    priority=75
                    if any(
                        isinstance(issue, dict) and issue.get("severity") == "error"
                        for issue in issues
                    )
                    else 50,
                    reason_codes=reason_codes,
                    summary=f"Review document {knowledge_document.title or canonical_key}",
                    payload={"validation_issues": issues},
                )
                review_task = _review_task_row(review_record)
                session.add(review_task)
                for issue in issues:
                    if not isinstance(issue, dict) or issue.get("severity") not in {
                        "warning",
                        "error",
                    }:
                        continue
                    paths = (
                        issue.get("paths")
                        if isinstance(issue.get("paths"), list)
                        else []
                    )
                    session.add(
                        _conflict_row(
                            ConflictRecord(
                                tenant_id=tenant_id,
                                subject_type="document_version",
                                subject_id=version.version_id,
                                field_path=str(paths[0]) if paths else "",
                                severity=str(issue.get("severity") or "warning"),
                                details={"validation_issue": issue},
                            )
                        )
                    )

            event_record = ProjectionEventRecord(
                tenant_id=tenant_id,
                projection_name="knowledge",
                idempotency_key=f"version:{version.version_id}:created",
                aggregate_type="document_version",
                aggregate_id=version.version_id,
                event_type="document.version.created",
                payload={
                    "document_id": knowledge_document.document_id,
                    "document_type": knowledge_document.document_type,
                    "lifecycle_status": version.lifecycle_status,
                    "acl": version.acl,
                    "eligible_for_graph": version.lifecycle_status
                    in {LifecycleStatus.APPROVED.value, LifecycleStatus.ACTIVE.value},
                },
            )
            event_row = await self._enqueue_in_session(session, event_record)
            await self._record_document_identity_decision_in_session(
                session,
                tenant_id=tenant_id,
                source_asset_id=asset.asset_id,
                source_occurrence_id=occurrence.occurrence_id,
                document_id=knowledge_document.document_id,
                version_id=version.version_id,
                decision=identity_decision,
            )
            return IngestDocumentResult(
                tenant_id=tenant_id,
                task_id=task_id,
                batch_id=batch.batch_id,
                asset_id=asset.asset_id,
                occurrence_id=occurrence.occurrence_id,
                document_id=knowledge_document.document_id,
                version_id=version.version_id,
                version_number=version.version_number,
                created=True,
                evidence_anchor_count=anchor_count,
                field_claim_count=claim_count,
                review_task_id=review_task.review_task_id if review_task else None,
                projection_event_id=event_row.event_id,
            )

        return await self._write(operation)

    async def get_document_version(
        self,
        tenant_id: str,
        version_id: str,
    ) -> DocumentVersionRecord | None:
        """Return one governed version without disclosing cross-tenant IDs."""

        async with self.sessionmaker() as session:
            row = await session.get(DocumentVersionRow, version_id)
            if row is None or row.tenant_id != tenant_id:
                return None
            return _version_record(row)

    async def _ingest_document_claims(
        self,
        session: AsyncSession,
        tenant_id: str,
        version_id: str,
        payload: dict[str, Any],
        acl: AccessControl,
    ) -> tuple[int, int]:
        field_meta = (
            payload.get("field_meta")
            if isinstance(payload.get("field_meta"), dict)
            else {}
        )
        paths = list(field_meta) or _fallback_claim_paths(payload)
        anchor_count = 0
        claim_count = 0
        for path in paths:
            meta = (
                field_meta.get(path) if isinstance(field_meta.get(path), dict) else {}
            )
            value = _resolve_path(payload, path)
            source_refs = (
                meta.get("source_refs")
                if isinstance(meta.get("source_refs"), list)
                else []
            )
            anchor_ids: list[str] = []
            for source_ref in source_refs:
                if not isinstance(source_ref, dict):
                    continue
                locator = {"field_path": path, **source_ref}
                locator_hash = _sha256_json(locator)
                anchor = await session.scalar(
                    select(EvidenceAnchorRow).where(
                        EvidenceAnchorRow.tenant_id == tenant_id,
                        EvidenceAnchorRow.document_version_id == version_id,
                        EvidenceAnchorRow.locator_hash == locator_hash,
                    )
                )
                if anchor is None:
                    excerpt = _normalize_text(value)[:2000] or None
                    anchor_record = EvidenceAnchorRecord(
                        tenant_id=tenant_id,
                        document_version_id=version_id,
                        anchor_type=(
                            "cell"
                            if source_ref.get("cell") or source_ref.get("range")
                            else "page"
                            if source_ref.get("page") is not None
                            else "document"
                        ),
                        locator=locator,
                        excerpt=excerpt,
                        excerpt_hash=(
                            hashlib.sha256(excerpt.encode("utf-8")).hexdigest()
                            if excerpt
                            else None
                        ),
                    )
                    anchor = _anchor_row(anchor_record, locator_hash)
                    session.add(anchor)
                    await session.flush()
                    anchor_count += 1
                anchor_ids.append(anchor.anchor_id)
            claim_record = FieldClaimRecord(
                tenant_id=tenant_id,
                idempotency_key=f"version:{version_id}:field:{path}",
                subject_type="document_version",
                subject_id=version_id,
                field_path=path,
                value=value,
                normalized_value=(
                    unicodedata.normalize("NFKC", value)
                    if isinstance(value, str)
                    else value
                ),
                evidence_anchor_id=anchor_ids[0] if anchor_ids else None,
                additional_evidence_anchor_ids=anchor_ids[1:],
                extraction_method=(
                    "inferred" if meta.get("inferred") else "deterministic"
                ),
                confidence=float(meta.get("confidence", 1.0)),
                status=(
                    ClaimStatus.UNDER_REVIEW
                    if meta.get("inferred")
                    else ClaimStatus.ACCEPTED
                    if float(meta.get("confidence", 1.0)) >= 0.95
                    else ClaimStatus.CANDIDATE
                ),
                acl=acl,
            )
            session.add(_field_claim_row(claim_record))
            claim_count += 1
        await session.flush()
        return anchor_count, claim_count

    async def _existing_ingest_result(
        self,
        session: AsyncSession,
        tenant_id: str,
        task_id: str,
        batch: IngestionBatchRow,
        asset: SourceAssetRow,
        occurrence: SourceOccurrenceRow,
        document: KnowledgeDocumentRow,
        version: DocumentVersionRow,
    ) -> IngestDocumentResult:
        anchor_count = await session.scalar(
            select(func.count(EvidenceAnchorRow.anchor_id)).where(
                EvidenceAnchorRow.tenant_id == tenant_id,
                EvidenceAnchorRow.document_version_id == version.version_id,
            )
        )
        claim_count = await session.scalar(
            select(func.count(FieldClaimRow.claim_id)).where(
                FieldClaimRow.tenant_id == tenant_id,
                FieldClaimRow.subject_type == "document_version",
                FieldClaimRow.subject_id == version.version_id,
            )
        )
        review = await session.scalar(
            select(ReviewTaskRow).where(
                ReviewTaskRow.tenant_id == tenant_id,
                ReviewTaskRow.target_type == "document_version",
                ReviewTaskRow.target_id == version.version_id,
            )
        )
        event_row = await session.scalar(
            select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.tenant_id == tenant_id,
                ProjectionOutboxRow.projection_name == "knowledge",
                ProjectionOutboxRow.idempotency_key
                == f"version:{version.version_id}:created",
            )
        )
        if event_row is None:
            event_row = await self._enqueue_in_session(
                session,
                ProjectionEventRecord(
                    tenant_id=tenant_id,
                    projection_name="knowledge",
                    idempotency_key=f"version:{version.version_id}:created",
                    aggregate_type="document_version",
                    aggregate_id=version.version_id,
                    event_type="document.version.created",
                    payload={"document_id": document.document_id},
                ),
            )
        return IngestDocumentResult(
            tenant_id=tenant_id,
            task_id=task_id,
            batch_id=batch.batch_id,
            asset_id=asset.asset_id,
            occurrence_id=occurrence.occurrence_id,
            document_id=document.document_id,
            version_id=version.version_id,
            version_number=version.version_number,
            created=False,
            evidence_anchor_count=int(anchor_count or 0),
            field_claim_count=int(claim_count or 0),
            review_task_id=review.review_task_id if review else None,
            projection_event_id=event_row.event_id,
        )

    async def _merge_logical_relationships(
        self,
        session: AsyncSession,
        graph: GraphProjection,
        *,
        projection_status: str,
    ) -> GraphProjection:
        """Merge governed canonical assertions into one source projection."""

        accepted_claim_statuses = (
            {ClaimStatus.ACCEPTED.value}
            if projection_status == "active"
            else {
                ClaimStatus.ACCEPTED.value,
                ClaimStatus.CANDIDATE.value,
                ClaimStatus.UNDER_REVIEW.value,
            }
            if projection_status == "candidate"
            else set()
        )
        if not accepted_claim_statuses:
            return graph
        relationship_rows = (
            await session.scalars(
                select(RelationshipClaimRow).where(
                    RelationshipClaimRow.tenant_id == graph.tenant_id,
                    RelationshipClaimRow.source_record_id == graph.source_record_id,
                    RelationshipClaimRow.source_version == graph.version,
                    RelationshipClaimRow.status.in_(sorted(accepted_claim_statuses)),
                    RelationshipClaimRow.relation_type.in_(
                        sorted(LOGICAL_GRAPH_RELATIONS)
                    ),
                )
            )
        ).all()
        if not relationship_rows:
            return graph

        entity_ids = {
            entity_id
            for row in relationship_rows
            for entity_id in (row.from_entity_id, row.to_entity_id)
        }
        entity_rows = (
            await session.scalars(
                select(CanonicalEntityRow).where(
                    CanonicalEntityRow.tenant_id == graph.tenant_id,
                    CanonicalEntityRow.entity_id.in_(entity_ids),
                )
            )
        ).all()
        entities = {row.entity_id: row for row in entity_rows}
        nodes = {row.node_id: row for row in graph.nodes}
        edges = {row.edge_id: row for row in graph.edges}

        for relationship in relationship_rows:
            from_entity = entities.get(relationship.from_entity_id)
            to_entity = entities.get(relationship.to_entity_id)
            if from_entity is None or to_entity is None:
                continue
            labels = (
                CANONICAL_ENTITY_GRAPH_LABELS.get(from_entity.entity_type),
                CANONICAL_ENTITY_GRAPH_LABELS.get(to_entity.entity_type),
            )
            if not all(labels):
                continue
            for entity, label in (
                (from_entity, labels[0]),
                (to_entity, labels[1]),
            ):
                assert label is not None
                nodes[entity.entity_id] = GraphNode(
                    node_id=entity.entity_id,
                    labels=[label],
                    tenant_id=graph.tenant_id,
                    source_record_id=graph.source_record_id,
                    version=graph.version,
                    status=projection_status,
                    confidence=entity.confidence,
                    source_claim_ids=[],
                    properties={
                        "entity_id": entity.entity_id,
                        "entity_type": entity.entity_type,
                        "canonical_key": entity.canonical_key,
                        "canonical_label": entity.canonical_label,
                        "attributes": entity.attributes,
                        "lifecycle_status": entity.lifecycle_status,
                        "acl": entity.acl,
                        "projection_kind": "canonical_entity",
                    },
                )
            properties = dict(relationship.properties or {})
            source_refs = properties.pop("source_refs", [])
            edge = GraphEdge(
                edge_id=relationship.relationship_id,
                relation=relationship.relation_type,
                from_node=relationship.from_entity_id,
                to_node=relationship.to_entity_id,
                tenant_id=graph.tenant_id,
                source_record_id=graph.source_record_id,
                version=graph.version,
                status=projection_status,
                confidence=relationship.confidence,
                source_refs=(source_refs if isinstance(source_refs, list) else []),
                source_claim_ids=[relationship.relationship_id],
                properties={
                    **properties,
                    "claim_status": relationship.status,
                    "acl": relationship.acl,
                    "projection_kind": "logical_relationship",
                },
            )
            edges[edge.edge_id] = edge

        return graph.model_copy(
            update={
                "nodes": list(nodes.values()),
                "edges": list(edges.values()),
            }
        )
