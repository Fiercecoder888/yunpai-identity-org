"""Governed knowledge projection eligibility for persisted M1 documents."""

from __future__ import annotations

from typing import Any


def knowledge_sync_eligibility(document: dict[str, Any]) -> tuple[bool, str]:
    """Return whether a durable document may enter the governed knowledge store.

    A full-authority MinerU failure is deliberately retained in the M1 task store
    for operator review, but contains no verified business facts. It must never
    create an otherwise valid-looking knowledge version, graph projection, or
    outbox event. The marker is explicit so reprocessing can produce a fresh,
    eligible document without interpreting failure text or issue codes.
    """

    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    if not isinstance(metadata, dict):
        return True, ""
    if metadata.get("authority_mode") == "full" and metadata.get(
        "authority_selected"
    ) not in (True, "manual_review"):
        return False, str(
            metadata.get("knowledge_sync_block_reason")
            or "full_authority_not_selected"
        )
    if metadata.get("knowledge_sync_eligible") is not False:
        return True, ""
    reason = str(metadata.get("knowledge_sync_block_reason") or "not_eligible")
    return False, reason


__all__ = ["knowledge_sync_eligibility"]
