"""Production embedding provider used by the PostgreSQL pgvector index."""
from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Protocol


class EmbeddingProvider(Protocol):
    model: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]: ...

    async def close(self) -> None: ...


@dataclass(frozen=True, slots=True)
class EmbeddingSpaceIdentity:
    """Stable, non-secret identity for vectors that may be compared."""

    model: str
    dimensions: int

    @classmethod
    def from_provider(cls, provider: EmbeddingProvider) -> EmbeddingSpaceIdentity:
        model = str(provider.model).strip()
        if not model:
            raise ValueError("embedding model identity is required")
        dimensions = int(provider.dimensions)
        if dimensions < 1:
            raise ValueError("embedding dimensions must be positive")
        return cls(model=model, dimensions=dimensions)


class OpenAIEmbeddingProvider:
    """Bounded OpenAI-compatible embedding client with strict shape checks."""

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        model: str = "BAAI/bge-m3",
        dimensions: int = 1024,
        batch_size: int = 16,
        max_input_chars: int = 12000,
        client: Any | None = None,
    ) -> None:
        if dimensions < 1:
            raise ValueError("embedding dimensions must be positive")
        self.model = model.strip()
        self.dimensions = int(dimensions)
        self.batch_size = max(1, min(int(batch_size), 128))
        self.max_input_chars = max(256, int(max_input_chars))
        if client is None:
            from openai import AsyncOpenAI

            client = AsyncOpenAI(api_key=api_key or "EMPTY", base_url=base_url)
        self.client = client

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        prepared = [str(text or " ")[: self.max_input_chars] for text in texts]
        output: list[list[float]] = []
        for offset in range(0, len(prepared), self.batch_size):
            batch = prepared[offset : offset + self.batch_size]
            response = await self.client.embeddings.create(
                model=self.model,
                input=batch,
                encoding_format="float",
            )
            ordered = sorted(response.data, key=lambda item: int(item.index))
            if len(ordered) != len(batch):
                raise ValueError("embedding response count mismatch")
            for item in ordered:
                vector = [float(value) for value in item.embedding]
                if len(vector) != self.dimensions:
                    raise ValueError(
                        "embedding dimension mismatch: "
                        f"expected {self.dimensions}, received {len(vector)}"
                    )
                if not all(math.isfinite(value) for value in vector):
                    raise ValueError("embedding contains non-finite values")
                output.append(vector)
        return output

    async def close(self) -> None:
        close = getattr(self.client, "close", None)
        if close is not None:
            result = close()
            if hasattr(result, "__await__"):
                await result


__all__ = [
    "EmbeddingProvider",
    "EmbeddingSpaceIdentity",
    "OpenAIEmbeddingProvider",
]
