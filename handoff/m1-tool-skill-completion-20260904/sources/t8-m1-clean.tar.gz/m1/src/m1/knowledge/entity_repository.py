"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

from collections.abc import Iterable
from datetime import UTC, datetime
from typing import TypeVar

from sqlalchemy import (
    func,
    select,
)
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    AliasSourceBindingRow,
    CanonicalEntityRow,
    ConflictRow,
    DocumentVersionRow,
    EntityAliasRow,
    EntityRevisionRow,
    EntitySourceBindingRow,
    EvidenceAnchorRow,
    ExternalIdentityRow,
    IdempotencyConflictError,
    IdentitySourceBindingRow,
    RecordNotFoundError,
    RelationshipClaimRow,
    ReviewTaskRow,
    TaskVersionBindingRow,
)
from .persistence_helpers import (
    _alias_record,
    _alias_row,
    _aware,
    _conflict_record,
    _conflict_row,
    _entity_record,
    _entity_row,
    _enum,
    _identity_record,
    _identity_row,
    _json,
    _relationship_record,
    _relationship_row,
    _review_task_row,
    _revision_record,
    _revision_row,
    _strongest_claim_status,
)
from .schema import (
    AccessControl,
    CanonicalEntityRecord,
    ClaimStatus,
    ConflictRecord,
    ConflictStatus,
    EntityAliasRecord,
    EntityRevisionRecord,
    ExternalIdentityRecord,
    LifecycleStatus,
    ProjectionEventRecord,
    RelationshipClaimRecord,
    ReviewTaskRecord,
    ReviewTaskStatus,
    TaskFenceToken,
    TaskTombstonedError,
    new_id,
    utc_now,
)

T = TypeVar("T")


class KnowledgeEntityMixin:
    async def _put_entity_in_session(
        self,
        session: AsyncSession,
        record: CanonicalEntityRecord,
    ) -> CanonicalEntityRecord:
        await self._require_tenant(session, record.tenant_id)
        existing = await session.scalar(
            select(CanonicalEntityRow)
            .where(
                CanonicalEntityRow.tenant_id == record.tenant_id,
                CanonicalEntityRow.entity_type == record.entity_type,
                CanonicalEntityRow.canonical_key == record.canonical_key,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if existing:
            if existing.lifecycle_status in {
                LifecycleStatus.DEPRECATED.value,
                LifecycleStatus.REJECTED.value,
            }:
                restored_status = _enum(record.lifecycle_status)
                if existing.lifecycle_status == LifecycleStatus.REJECTED.value:
                    restored_status = LifecycleStatus.UNDER_REVIEW.value
                existing.lifecycle_status = restored_status
                existing.recorded_to = None
                existing.updated_at = utc_now()
                if restored_status == LifecycleStatus.UNDER_REVIEW.value:
                    review = await session.scalar(
                        select(ReviewTaskRow).where(
                            ReviewTaskRow.tenant_id == record.tenant_id,
                            ReviewTaskRow.target_type == "canonical_entity",
                            ReviewTaskRow.target_id == existing.entity_id,
                            ReviewTaskRow.status.in_(
                                [
                                    ReviewTaskStatus.OPEN.value,
                                    ReviewTaskStatus.IN_REVIEW.value,
                                ]
                            ),
                        )
                    )
                    if review is None:
                        session.add(
                            _review_task_row(
                                ReviewTaskRecord(
                                    tenant_id=record.tenant_id,
                                    idempotency_key=(
                                        f"entity:{existing.entity_id}:reactivated:"
                                        f"{existing.updated_at.isoformat()}"
                                    ),
                                    target_type="canonical_entity",
                                    target_id=existing.entity_id,
                                    reason_codes=["canonical_entity_reappeared"],
                                    summary=(
                                        f"Review reappeared {record.entity_type}: "
                                        f"{record.canonical_label}"
                                    ),
                                )
                            )
                        )
            return _entity_record(existing)
        session.add(_entity_row(record))
        await self._enqueue_in_session(
            session,
            ProjectionEventRecord(
                tenant_id=record.tenant_id,
                projection_name="knowledge",
                idempotency_key=f"entity:{record.entity_id}:created",
                aggregate_type="canonical_entity",
                aggregate_id=record.entity_id,
                event_type="entity.created",
                payload={
                    "entity_type": record.entity_type,
                    "status": _enum(record.lifecycle_status),
                    "acl": _json(record.acl),
                    "valid_from": (
                        record.valid_from.isoformat() if record.valid_from else None
                    ),
                    "valid_to": (
                        record.valid_to.isoformat() if record.valid_to else None
                    ),
                },
            ),
        )
        if record.lifecycle_status == LifecycleStatus.UNDER_REVIEW:
            session.add(
                _review_task_row(
                    ReviewTaskRecord(
                        tenant_id=record.tenant_id,
                        idempotency_key=f"entity:{record.entity_id}:review",
                        target_type="canonical_entity",
                        target_id=record.entity_id,
                        reason_codes=["new_canonical_entity"],
                        summary=(
                            f"Review new {record.entity_type}: {record.canonical_label}"
                        ),
                    )
                )
            )
        return record

    async def put_entity(self, record: CanonicalEntityRecord) -> CanonicalEntityRecord:
        return await self._write(
            lambda session: self._put_entity_in_session(session, record)
        )

    async def _bind_entity_source_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        entity_id: str,
        version_id: str,
        assertion: CanonicalEntityRecord,
    ) -> None:
        await self._assert_owned(session, CanonicalEntityRow, entity_id, tenant_id)
        await self._assert_owned(session, DocumentVersionRow, version_id, tenant_id)
        existing = await session.scalar(
            select(EntitySourceBindingRow).where(
                EntitySourceBindingRow.tenant_id == tenant_id,
                EntitySourceBindingRow.entity_id == entity_id,
                EntitySourceBindingRow.version_id == version_id,
            )
        )
        if existing is None:
            session.add(
                EntitySourceBindingRow(
                    binding_id=new_id(),
                    tenant_id=tenant_id,
                    entity_id=entity_id,
                    version_id=version_id,
                    status="active",
                    asserted_label=assertion.canonical_label,
                    asserted_attributes=assertion.attributes,
                    asserted_lifecycle_status=_enum(assertion.lifecycle_status),
                    asserted_confidence=assertion.confidence,
                    created_at=utc_now(),
                    tombstoned_at=None,
                )
            )
        else:
            existing.status = "active"
            existing.tombstoned_at = None
            existing.asserted_label = assertion.canonical_label
            existing.asserted_attributes = assertion.attributes
            existing.asserted_lifecycle_status = _enum(assertion.lifecycle_status)
            existing.asserted_confidence = assertion.confidence
        await session.flush()
        await self._recompute_entity_from_bindings(
            session,
            tenant_id=tenant_id,
            entity_id=entity_id,
            reason=f"source assertion bound to version {version_id}",
        )

    async def bind_entity_source(
        self,
        tenant_id: str,
        entity_id: str,
        version_id: str,
        assertion: CanonicalEntityRecord,
    ) -> None:
        async def operation(session: AsyncSession) -> None:
            await self._bind_entity_source_in_session(
                session,
                tenant_id=tenant_id,
                entity_id=entity_id,
                version_id=version_id,
                assertion=assertion,
            )

        await self._write(operation)

    async def bind_linked_entity_source_with_fence(
        self,
        tenant_id: str,
        *,
        entity_id: str,
        version_id: str,
        source_assertion: CanonicalEntityRecord,
        fence: TaskFenceToken,
    ) -> CanonicalEntityRecord:
        """Bind a routed source version without replacing target canonical facts.

        Entity routing has already established that ``entity_id`` is the
        authoritative existing entity.  The source still needs an entity-level
        lifecycle binding, but its unreviewed label and attributes must not
        replace the target's canonical state merely because a link was chosen.
        """

        async def operation(session: AsyncSession) -> CanonicalEntityRecord:
            await self._assert_fenced_version_binding(
                session,
                fence,
                tenant_id=tenant_id,
                version_id=version_id,
            )
            if source_assertion.tenant_id != tenant_id:
                raise ValueError("linked source assertion tenant does not match")
            target = await self._assert_owned(
                session,
                CanonicalEntityRow,
                entity_id,
                tenant_id,
            )
            if target.entity_type != source_assertion.entity_type:
                raise ValueError("linked source assertion entity type does not match")
            target_record = _entity_record(target)
            protected_assertion = source_assertion.model_copy(
                update={
                    "tenant_id": tenant_id,
                    "entity_id": target_record.entity_id,
                    "entity_type": target_record.entity_type,
                    "canonical_key": target_record.canonical_key,
                    "canonical_label": target_record.canonical_label,
                    "attributes": target_record.attributes,
                    "lifecycle_status": target_record.lifecycle_status,
                    "confidence": target_record.confidence,
                    "acl": target_record.acl,
                }
            )
            await self._bind_entity_source_in_session(
                session,
                tenant_id=tenant_id,
                entity_id=target_record.entity_id,
                version_id=version_id,
                assertion=protected_assertion,
            )
            return target_record

        return await self._write(operation)

    async def put_entity_with_source(
        self,
        record: CanonicalEntityRecord,
        version_id: str,
        fence: TaskFenceToken,
    ) -> CanonicalEntityRecord:
        """Create/reactivate an entity and bind its source atomically."""

        async def operation(session: AsyncSession) -> CanonicalEntityRecord:
            await self._assert_fenced_version_binding(
                session,
                fence,
                tenant_id=record.tenant_id,
                version_id=version_id,
            )
            persisted = await self._put_entity_in_session(session, record)
            await self._bind_entity_source_in_session(
                session,
                tenant_id=record.tenant_id,
                entity_id=persisted.entity_id,
                version_id=version_id,
                assertion=record,
            )
            return persisted

        return await self._write(operation)

    async def _recompute_entity_from_bindings(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        entity_id: str,
        reason: str,
    ) -> None:
        entity = await session.scalar(
            select(CanonicalEntityRow)
            .where(
                CanonicalEntityRow.tenant_id == tenant_id,
                CanonicalEntityRow.entity_id == entity_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if entity is None:
            raise RecordNotFoundError(entity_id)
        bindings = (
            await session.scalars(
                select(EntitySourceBindingRow).where(
                    EntitySourceBindingRow.tenant_id == tenant_id,
                    EntitySourceBindingRow.entity_id == entity_id,
                    EntitySourceBindingRow.status == "active",
                )
            )
        ).all()
        if not bindings:
            entity.lifecycle_status = LifecycleStatus.DEPRECATED.value
            entity.recorded_to = entity.recorded_to or utc_now()
            entity.updated_at = utc_now()
            return
        lifecycle_rank = {
            LifecycleStatus.ACTIVE.value: 4,
            LifecycleStatus.APPROVED.value: 3,
            LifecycleStatus.UNDER_REVIEW.value: 2,
            LifecycleStatus.NORMALIZED.value: 1,
            LifecycleStatus.PARSED.value: 0,
        }
        selected = max(
            bindings,
            key=lambda row: (
                row.asserted_confidence,
                lifecycle_rank.get(row.asserted_lifecycle_status, -1),
                _aware(row.created_at) or datetime.min.replace(tzinfo=UTC),
                row.binding_id,
            ),
        )
        next_status = (
            LifecycleStatus.APPROVED.value
            if entity.lifecycle_status == LifecycleStatus.APPROVED.value
            else selected.asserted_lifecycle_status
        )
        before = {
            "canonical_label": entity.canonical_label,
            "attributes": entity.attributes,
            "lifecycle_status": entity.lifecycle_status,
            "confidence": entity.confidence,
        }
        after = {
            "canonical_label": selected.asserted_label,
            "attributes": selected.asserted_attributes,
            "lifecycle_status": next_status,
            "confidence": selected.asserted_confidence,
        }
        if before == after:
            entity.recorded_to = None
            return
        latest_revision = await session.scalar(
            select(func.max(EntityRevisionRow.revision_number)).where(
                EntityRevisionRow.tenant_id == tenant_id,
                EntityRevisionRow.entity_id == entity_id,
            )
        )
        entity.canonical_label = selected.asserted_label
        entity.attributes = selected.asserted_attributes
        entity.lifecycle_status = next_status
        entity.confidence = selected.asserted_confidence
        entity.recorded_to = None
        entity.updated_at = utc_now()
        session.add(
            _revision_row(
                EntityRevisionRecord(
                    tenant_id=tenant_id,
                    entity_id=entity_id,
                    revision_number=int(latest_revision or 0) + 1,
                    payload={
                        "before": before,
                        "after": after,
                        "selected_version_id": selected.version_id,
                    },
                    change_reason=reason,
                    lifecycle_status=next_status,
                    acl=AccessControl.model_validate(entity.acl or {}),
                )
            )
        )

    async def get_entity(
        self, tenant_id: str, entity_id: str
    ) -> CanonicalEntityRecord | None:
        async with self.sessionmaker() as session:
            row = await session.get(CanonicalEntityRow, entity_id)
            if row is None or row.tenant_id != tenant_id:
                return None
            return _entity_record(row)

    async def list_entities(
        self,
        tenant_id: str,
        *,
        entity_type: str | None = None,
        lifecycle_status: LifecycleStatus | str | None = None,
        lifecycle_statuses: Iterable[LifecycleStatus | str] | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[CanonicalEntityRecord]:
        limit = max(1, min(limit, 1000))
        statement = select(CanonicalEntityRow).where(
            CanonicalEntityRow.tenant_id == tenant_id
        )
        if entity_type:
            statement = statement.where(CanonicalEntityRow.entity_type == entity_type)
        if lifecycle_status:
            statement = statement.where(
                CanonicalEntityRow.lifecycle_status == _enum(lifecycle_status)
            )
        if lifecycle_statuses is not None:
            accepted_statuses = sorted({_enum(item) for item in lifecycle_statuses})
            if not accepted_statuses:
                return []
            statement = statement.where(
                CanonicalEntityRow.lifecycle_status.in_(accepted_statuses)
            )
        statement = (
            statement.order_by(
                CanonicalEntityRow.created_at, CanonicalEntityRow.entity_id
            )
            .offset(offset)
            .limit(limit)
        )
        async with self.sessionmaker() as session:
            return [
                _entity_record(row) for row in (await session.scalars(statement)).all()
            ]

    async def _add_external_identity_in_session(
        self,
        session: AsyncSession,
        record: ExternalIdentityRecord,
    ) -> ExternalIdentityRecord:
        entity = await self._assert_owned(
            session, CanonicalEntityRow, record.entity_id, record.tenant_id
        )
        if entity.entity_type != record.entity_type:
            raise ValueError(
                f"identity type {record.entity_type!r} does not match entity type "
                f"{entity.entity_type!r}"
            )
        existing = await session.scalar(
            select(ExternalIdentityRow)
            .where(
                ExternalIdentityRow.tenant_id == record.tenant_id,
                ExternalIdentityRow.entity_type == record.entity_type,
                ExternalIdentityRow.source_system == record.source_system,
                ExternalIdentityRow.external_id == record.external_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if existing:
            if existing.entity_id != record.entity_id:
                raise IdempotencyConflictError(
                    f"external identity already maps to entity {existing.entity_id}"
                )
            if existing.status == ClaimStatus.SUPERSEDED.value:
                existing.status = _enum(record.status)
            return _identity_record(existing)
        session.add(_identity_row(record))
        return record

    async def add_external_identity(
        self, record: ExternalIdentityRecord
    ) -> ExternalIdentityRecord:
        async def operation(session: AsyncSession) -> ExternalIdentityRecord:
            return await self._add_external_identity_in_session(session, record)

        return await self._write(operation)

    async def find_external_identity(
        self,
        tenant_id: str,
        *,
        entity_type: str,
        source_system: str,
        external_id: str,
    ) -> ExternalIdentityRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(ExternalIdentityRow).where(
                    ExternalIdentityRow.tenant_id == tenant_id,
                    ExternalIdentityRow.entity_type == entity_type,
                    ExternalIdentityRow.source_system == source_system,
                    ExternalIdentityRow.external_id == external_id,
                )
            )
            return _identity_record(row) if row is not None else None

    async def _bind_identity_source_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        identity_id: str,
        version_id: str,
        asserted_status: ClaimStatus | str,
    ) -> None:
        identity = await self._assert_owned(
            session, ExternalIdentityRow, identity_id, tenant_id
        )
        await self._assert_owned(session, DocumentVersionRow, version_id, tenant_id)
        binding = await session.scalar(
            select(IdentitySourceBindingRow).where(
                IdentitySourceBindingRow.tenant_id == tenant_id,
                IdentitySourceBindingRow.identity_id == identity_id,
                IdentitySourceBindingRow.version_id == version_id,
            )
        )
        if binding is None:
            binding = IdentitySourceBindingRow(
                binding_id=new_id(),
                tenant_id=tenant_id,
                identity_id=identity_id,
                version_id=version_id,
                asserted_status=_enum(asserted_status),
                status="active",
                created_at=utc_now(),
                tombstoned_at=None,
            )
            session.add(binding)
        else:
            binding.asserted_status = _enum(asserted_status)
            binding.status = "active"
            binding.tombstoned_at = None
        await session.flush()
        await self._recompute_identity_from_bindings(
            session,
            tenant_id=tenant_id,
            identity_id=identity.identity_id,
        )

    async def bind_identity_source(
        self,
        tenant_id: str,
        identity_id: str,
        version_id: str,
        asserted_status: ClaimStatus | str,
    ) -> None:
        async def operation(session: AsyncSession) -> None:
            await self._bind_identity_source_in_session(
                session,
                tenant_id=tenant_id,
                identity_id=identity_id,
                version_id=version_id,
                asserted_status=asserted_status,
            )

        await self._write(operation)

    async def add_external_identity_with_source(
        self,
        record: ExternalIdentityRecord,
        version_id: str,
        fence: TaskFenceToken,
    ) -> ExternalIdentityRecord:
        """Create/reactivate an identity and bind its source atomically."""

        async def operation(session: AsyncSession) -> ExternalIdentityRecord:
            await self._assert_fenced_version_binding(
                session,
                fence,
                tenant_id=record.tenant_id,
                version_id=version_id,
            )
            persisted = await self._add_external_identity_in_session(session, record)
            await self._bind_identity_source_in_session(
                session,
                tenant_id=record.tenant_id,
                identity_id=persisted.identity_id,
                version_id=version_id,
                asserted_status=record.status,
            )
            return persisted

        return await self._write(operation)

    async def _recompute_identity_from_bindings(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        identity_id: str,
    ) -> None:
        identity = await session.scalar(
            select(ExternalIdentityRow)
            .where(
                ExternalIdentityRow.tenant_id == tenant_id,
                ExternalIdentityRow.identity_id == identity_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if identity is None:
            raise RecordNotFoundError(identity_id)
        bindings = (
            await session.scalars(
                select(IdentitySourceBindingRow).where(
                    IdentitySourceBindingRow.tenant_id == tenant_id,
                    IdentitySourceBindingRow.identity_id == identity_id,
                    IdentitySourceBindingRow.status == "active",
                )
            )
        ).all()
        identity.status = _strongest_claim_status(
            [row.asserted_status for row in bindings]
        )

    async def record_conflict(
        self,
        record: ConflictRecord,
        *,
        fence: TaskFenceToken | None = None,
        source_version_id: str = "",
    ) -> ConflictRecord:
        """Persist one deduplicated open conflict and its auditable review task."""

        async def operation(session: AsyncSession) -> ConflictRecord:
            if fence is not None:
                await self._assert_fenced_version_binding(
                    session,
                    fence,
                    tenant_id=record.tenant_id,
                    version_id=source_version_id,
                )
            await self._require_tenant(session, record.tenant_id)
            existing = await session.scalar(
                select(ConflictRow).where(
                    ConflictRow.tenant_id == record.tenant_id,
                    ConflictRow.subject_type == record.subject_type,
                    ConflictRow.subject_id == record.subject_id,
                    ConflictRow.field_path == record.field_path,
                    ConflictRow.status == ConflictStatus.OPEN.value,
                )
            )
            if existing is not None:
                return _conflict_record(existing)
            session.add(_conflict_row(record))
            session.add(
                _review_task_row(
                    ReviewTaskRecord(
                        tenant_id=record.tenant_id,
                        idempotency_key=f"conflict:{record.conflict_id}:review",
                        target_type=record.subject_type,
                        target_id=record.subject_id,
                        priority=90 if record.severity == "error" else 70,
                        reason_codes=["identity_conflict"],
                        summary=f"Review {record.subject_type} conflict",
                        payload={"conflict_id": record.conflict_id, **record.details},
                    )
                )
            )
            return record

        return await self._write(operation)

    async def _add_entity_alias_in_session(
        self,
        session: AsyncSession,
        record: EntityAliasRecord,
    ) -> EntityAliasRecord:
        await self._assert_owned(
            session, CanonicalEntityRow, record.entity_id, record.tenant_id
        )
        existing = await session.scalar(
            select(EntityAliasRow)
            .where(
                EntityAliasRow.tenant_id == record.tenant_id,
                EntityAliasRow.entity_id == record.entity_id,
                EntityAliasRow.normalized_alias == record.normalized_alias,
                EntityAliasRow.source_system == record.source_system,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if existing:
            if existing.status == ClaimStatus.SUPERSEDED.value:
                existing.status = _enum(record.status)
            return _alias_record(existing)
        session.add(_alias_row(record))
        return record

    async def add_entity_alias(self, record: EntityAliasRecord) -> EntityAliasRecord:
        async def operation(session: AsyncSession) -> EntityAliasRecord:
            return await self._add_entity_alias_in_session(session, record)

        return await self._write(operation)

    async def _bind_alias_source_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        alias_id: str,
        version_id: str,
        asserted_status: ClaimStatus | str,
    ) -> None:
        alias = await self._assert_owned(
            session, EntityAliasRow, alias_id, tenant_id
        )
        await self._assert_owned(session, DocumentVersionRow, version_id, tenant_id)
        binding = await session.scalar(
            select(AliasSourceBindingRow).where(
                AliasSourceBindingRow.tenant_id == tenant_id,
                AliasSourceBindingRow.alias_id == alias_id,
                AliasSourceBindingRow.version_id == version_id,
            )
        )
        if binding is None:
            binding = AliasSourceBindingRow(
                binding_id=new_id(),
                tenant_id=tenant_id,
                alias_id=alias_id,
                version_id=version_id,
                asserted_status=_enum(asserted_status),
                status="active",
                created_at=utc_now(),
                tombstoned_at=None,
            )
            session.add(binding)
        else:
            binding.asserted_status = _enum(asserted_status)
            binding.status = "active"
            binding.tombstoned_at = None
        await session.flush()
        await self._recompute_alias_from_bindings(
            session,
            tenant_id=tenant_id,
            alias_id=alias.alias_id,
        )

    async def bind_alias_source(
        self,
        tenant_id: str,
        alias_id: str,
        version_id: str,
        asserted_status: ClaimStatus | str,
    ) -> None:
        async def operation(session: AsyncSession) -> None:
            await self._bind_alias_source_in_session(
                session,
                tenant_id=tenant_id,
                alias_id=alias_id,
                version_id=version_id,
                asserted_status=asserted_status,
            )

        await self._write(operation)

    async def add_entity_alias_with_source(
        self,
        record: EntityAliasRecord,
        version_id: str,
        fence: TaskFenceToken,
    ) -> EntityAliasRecord:
        """Create/reactivate an alias and bind its source atomically."""

        async def operation(session: AsyncSession) -> EntityAliasRecord:
            await self._assert_fenced_version_binding(
                session,
                fence,
                tenant_id=record.tenant_id,
                version_id=version_id,
            )
            persisted = await self._add_entity_alias_in_session(session, record)
            await self._bind_alias_source_in_session(
                session,
                tenant_id=record.tenant_id,
                alias_id=persisted.alias_id,
                version_id=version_id,
                asserted_status=record.status,
            )
            return persisted

        return await self._write(operation)

    async def _recompute_alias_from_bindings(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        alias_id: str,
    ) -> None:
        alias = await session.scalar(
            select(EntityAliasRow)
            .where(
                EntityAliasRow.tenant_id == tenant_id,
                EntityAliasRow.alias_id == alias_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if alias is None:
            raise RecordNotFoundError(alias_id)
        bindings = (
            await session.scalars(
                select(AliasSourceBindingRow).where(
                    AliasSourceBindingRow.tenant_id == tenant_id,
                    AliasSourceBindingRow.alias_id == alias_id,
                    AliasSourceBindingRow.status == "active",
                )
            )
        ).all()
        alias.status = _strongest_claim_status(
            [row.asserted_status for row in bindings]
        )

    async def add_entity_revision(
        self, record: EntityRevisionRecord
    ) -> EntityRevisionRecord:
        async def operation(session: AsyncSession) -> EntityRevisionRecord:
            await self._assert_owned(
                session, CanonicalEntityRow, record.entity_id, record.tenant_id
            )
            if record.based_on_revision_id:
                await self._assert_owned(
                    session,
                    EntityRevisionRow,
                    record.based_on_revision_id,
                    record.tenant_id,
                )
            existing = await session.scalar(
                select(EntityRevisionRow).where(
                    EntityRevisionRow.tenant_id == record.tenant_id,
                    EntityRevisionRow.entity_id == record.entity_id,
                    EntityRevisionRow.revision_number == record.revision_number,
                )
            )
            if existing:
                return _revision_record(existing)
            session.add(_revision_row(record))
            return record

        return await self._write(operation)

    async def claim_relationship(
        self,
        record: RelationshipClaimRecord,
        *,
        fence: TaskFenceToken | None = None,
    ) -> RelationshipClaimRecord:
        async def operation(session: AsyncSession) -> RelationshipClaimRecord:
            if fence is not None:
                properties = record.properties or {}
                await self._assert_fenced_version_binding(
                    session,
                    fence,
                    tenant_id=record.tenant_id,
                    source_record_id=str(properties.get("source_record_id") or ""),
                    source_version=str(properties.get("version") or ""),
                )
            await self._assert_owned(
                session, CanonicalEntityRow, record.from_entity_id, record.tenant_id
            )
            await self._assert_owned(
                session, CanonicalEntityRow, record.to_entity_id, record.tenant_id
            )
            if record.evidence_anchor_id:
                await self._assert_owned(
                    session,
                    EvidenceAnchorRow,
                    record.evidence_anchor_id,
                    record.tenant_id,
                )
            for anchor_id in record.additional_evidence_anchor_ids:
                await self._assert_owned(
                    session, EvidenceAnchorRow, anchor_id, record.tenant_id
                )
            existing = await session.scalar(
                select(RelationshipClaimRow).where(
                    RelationshipClaimRow.tenant_id == record.tenant_id,
                    RelationshipClaimRow.idempotency_key == record.idempotency_key,
                )
            )
            if existing:
                endpoints = (
                    existing.from_entity_id,
                    existing.relation_type,
                    existing.to_entity_id,
                )
                requested = (
                    record.from_entity_id,
                    record.relation_type,
                    record.to_entity_id,
                )
                if endpoints != requested:
                    raise IdempotencyConflictError(record.idempotency_key)
                return _relationship_record(existing)
            session.add(_relationship_row(record))
            projection_name = (
                "graph" if record.status == ClaimStatus.ACCEPTED else "graph_staging"
            )
            await self._enqueue_in_session(
                session,
                ProjectionEventRecord(
                    tenant_id=record.tenant_id,
                    projection_name=projection_name,
                    idempotency_key=f"relationship:{record.relationship_id}:claimed",
                    aggregate_type="relationship_claim",
                    aggregate_id=record.relationship_id,
                    event_type="relationship.claimed",
                    payload={
                        "from_entity_id": record.from_entity_id,
                        "relation_type": record.relation_type,
                        "to_entity_id": record.to_entity_id,
                        "status": _enum(record.status),
                        "confidence": record.confidence,
                        "evidence_anchor_id": record.evidence_anchor_id,
                        "acl": _json(record.acl),
                        "valid_from": record.valid_from.isoformat()
                        if record.valid_from
                        else None,
                        "valid_to": record.valid_to.isoformat()
                        if record.valid_to
                        else None,
                        "source_record_id": record.properties.get("source_record_id"),
                        "version": record.properties.get("version"),
                    },
                ),
            )
            if record.status in {ClaimStatus.CANDIDATE, ClaimStatus.UNDER_REVIEW}:
                session.add(
                    _review_task_row(
                        ReviewTaskRecord(
                            tenant_id=record.tenant_id,
                            idempotency_key=f"relationship:{record.relationship_id}:review",
                            target_type="relationship_claim",
                            target_id=record.relationship_id,
                            reason_codes=["relationship_requires_review"],
                            summary=f"Review relationship {record.relation_type}",
                            payload={"confidence": record.confidence},
                        )
                    )
                )
            return record

        return await self._write(operation)

    async def _bind_task_version(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
        version_id: str,
        occurrence_id: str,
        reactivate: bool = False,
    ) -> TaskVersionBindingRow:
        binding = await session.scalar(
            select(TaskVersionBindingRow)
            .where(
                TaskVersionBindingRow.tenant_id == tenant_id,
                TaskVersionBindingRow.task_id == task_id,
                TaskVersionBindingRow.version_id == version_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        if binding is None:
            binding = TaskVersionBindingRow(
                binding_id=new_id(),
                tenant_id=tenant_id,
                task_id=task_id,
                version_id=version_id,
                occurrence_id=occurrence_id,
                status="active",
                created_at=utc_now(),
                tombstoned_at=None,
            )
            session.add(binding)
            await session.flush()
        elif binding.status == "tombstoned":
            if not reactivate:
                raise TaskTombstonedError(
                    f"task version binding is tombstoned: {task_id}"
                )
            binding.status = "active"
            binding.occurrence_id = occurrence_id
            binding.tombstoned_at = None
        return binding
