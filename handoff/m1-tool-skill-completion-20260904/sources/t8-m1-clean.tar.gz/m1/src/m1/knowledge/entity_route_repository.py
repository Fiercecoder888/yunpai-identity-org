"""Tenant-safe candidate retrieval and audit persistence for entity routing."""

from __future__ import annotations

import hashlib
import math
import unicodedata
from collections import defaultdict
from collections.abc import Iterable, Sequence
from datetime import datetime
from difflib import SequenceMatcher

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    CanonicalEntityRow,
    DocumentVersionRow,
    EntityAliasRow,
    EntityRouteDecisionRow,
    EntityRouteIndexRow,
    ExternalIdentityRow,
    IdempotencyConflictError,
    RecordNotFoundError,
)
from .entity_routing import (
    EntityRouteAction,
    EntityRouteCandidate,
    EntityRouteDecision,
)
from .persistence_helpers import _alias_record, _aware, _entity_record, _identity_record
from .schema import (
    CanonicalEntityRecord,
    EntityAliasRecord,
    ExternalIdentityRecord,
    LifecycleStatus,
    TaskFenceToken,
    new_id,
    utc_now,
)

_ROUTABLE_ENTITY_STATES = {
    LifecycleStatus.APPROVED.value,
    LifecycleStatus.ACTIVE.value,
}
_ACCEPTED_IDENTITY_STATES = {"accepted"}
_MAX_CANDIDATE_SCAN = 5_000


def _normalise(value: object) -> str:
    return " ".join(
        unicodedata.normalize("NFKC", str(value or "")).casefold().split()
    )


def _score_text(query: str, candidate: str) -> float:
    if not query or not candidate:
        return 0.0
    if query == candidate:
        return 1.0
    if query in candidate or candidate in query:
        shorter = min(len(query), len(candidate))
        longer = max(len(query), len(candidate))
        return max(0.75, shorter / longer)
    return SequenceMatcher(a=query, b=candidate).ratio()


def _cosine(left: Sequence[float], right: Sequence[float]) -> float:
    numerator = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if not left_norm or not right_norm:
        return 0.0
    return max(-1.0, min(1.0, numerator / (left_norm * right_norm)))


def _bounded_embedding(
    value: Sequence[float], *, dimensions: int
) -> list[float]:
    vector = [float(item) for item in value]
    if len(vector) != dimensions:
        raise ValueError(
            f"entity route embedding dimension mismatch: expected {dimensions}, got {len(vector)}"
        )
    if not all(math.isfinite(item) for item in vector):
        raise ValueError("entity route embedding must contain only finite values")
    return vector


def _stable_index_id(
    tenant_id: str,
    entity_id: str,
    embedding_model: str,
    dimensions: int,
) -> str:
    digest = hashlib.sha256(
        "\x1f".join((tenant_id, entity_id, embedding_model, str(dimensions))).encode(
            "utf-8"
        )
    ).hexdigest()[:32]
    return f"entity-route-index-{digest}"


def _decision_record(row: EntityRouteDecisionRow) -> EntityRouteDecision:
    return EntityRouteDecision(
        action=EntityRouteAction(row.action),
        candidate_entity_id=row.candidate_entity_id,
        candidate_score=float(row.candidate_score),
        top1_top2_margin=float(row.top1_top2_margin),
        model_confidence=float(row.model_confidence),
        reason_codes=tuple(str(item) for item in (row.reason_codes or ())),
        model_used=bool(row.model_name),
    )


class KnowledgeEntityRouteMixin:
    """Repository mixin used by the identity-routing runtime.

    All methods are tenant-scoped by ``KnowledgeStore``'s facade wrapper.
    Candidate rows are read-only projections; writes only refresh an entity's
    own sidecar vector or append an immutable decision record.
    """

    async def get_routable_entity_by_key(
        self,
        tenant_id: str,
        *,
        entity_type: str,
        canonical_key: str,
    ) -> EntityRouteCandidate | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(CanonicalEntityRow).where(
                    CanonicalEntityRow.tenant_id == tenant_id,
                    CanonicalEntityRow.entity_type == entity_type,
                    CanonicalEntityRow.canonical_key == canonical_key,
                    CanonicalEntityRow.lifecycle_status.in_(
                        sorted(_ROUTABLE_ENTITY_STATES)
                    ),
                )
            )
            if row is None:
                return None
            aliases, identities = await self._entity_identity_summaries(
                session, tenant_id=tenant_id, entity_ids=[row.entity_id]
            )
            return EntityRouteCandidate(
                tenant_id=tenant_id,
                entity_id=row.entity_id,
                entity_type=row.entity_type,
                canonical_label=row.canonical_label,
                accepted_aliases=aliases.get(row.entity_id, ()),
                accepted_external_ids=identities.get(row.entity_id, ()),
                lexical_score=1.0,
                fused_score=1.0,
                exact_alias=True,
            )

    async def find_entity_route_candidates(
        self,
        tenant_id: str,
        *,
        entity_type: str,
        normalized_label: str,
        query_embedding: Sequence[float] | None = None,
        embedding_model: str = "",
        embedding_dimensions: int = KNOWLEDGE_EMBEDDING_DIMENSIONS,
        limit: int = 5,
    ) -> list[EntityRouteCandidate]:
        """Return bounded lexical/vector candidates in one tenant/type scope."""

        query = _normalise(normalized_label)
        if not query:
            return []
        limit = max(1, min(int(limit), 5))
        vector = (
            _bounded_embedding(query_embedding, dimensions=embedding_dimensions)
            if query_embedding is not None
            else None
        )
        vector_scores: dict[str, float] = {}
        entities: dict[str, CanonicalEntityRow] = {}
        async with self.sessionmaker() as session:
            base = select(CanonicalEntityRow).where(
                CanonicalEntityRow.tenant_id == tenant_id,
                CanonicalEntityRow.entity_type == entity_type,
                CanonicalEntityRow.lifecycle_status.in_(sorted(_ROUTABLE_ENTITY_STATES)),
            )
            # SQL narrows obvious lexical candidates first.  The bounded
            # portable fallback below scores values consistently on SQLite.
            escaped_query = (
                query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like = f"%{escaped_query}%"
            lexical_rows = (
                await session.scalars(
                    base.outerjoin(
                        EntityAliasRow,
                        (EntityAliasRow.tenant_id == CanonicalEntityRow.tenant_id)
                        & (EntityAliasRow.entity_id == CanonicalEntityRow.entity_id),
                    )
                    .where(
                        or_(
                            CanonicalEntityRow.canonical_label.ilike(like, escape="\\"),
                            EntityAliasRow.normalized_alias.ilike(like, escape="\\"),
                        )
                    )
                    .limit(_MAX_CANDIDATE_SCAN)
                )
            ).unique().all()
            for row in lexical_rows:
                entities[row.entity_id] = row

            if vector is not None and embedding_model.strip():
                vector_base = (
                    select(EntityRouteIndexRow, CanonicalEntityRow)
                    .join(
                        CanonicalEntityRow,
                        (CanonicalEntityRow.entity_id == EntityRouteIndexRow.entity_id)
                        & (CanonicalEntityRow.tenant_id == EntityRouteIndexRow.tenant_id),
                    )
                    .where(
                        EntityRouteIndexRow.tenant_id == tenant_id,
                        EntityRouteIndexRow.entity_type == entity_type,
                        EntityRouteIndexRow.embedding_model == embedding_model,
                        EntityRouteIndexRow.embedding_dimensions == embedding_dimensions,
                        CanonicalEntityRow.lifecycle_status.in_(
                            sorted(_ROUTABLE_ENTITY_STATES)
                        ),
                    )
                )
                if self.engine.url.get_backend_name() == "postgresql":
                    distance = EntityRouteIndexRow.embedding.cosine_distance(vector)
                    rows = (
                        await session.execute(
                            vector_base.add_columns((1.0 - distance).label("score"))
                            .order_by(distance)
                            .limit(limit)
                        )
                    ).all()
                    for index_row, entity_row, score in rows:
                        entities[entity_row.entity_id] = entity_row
                        vector_scores[entity_row.entity_id] = max(
                            0.0, min(1.0, float(score))
                        )
                else:
                    rows = (
                        await session.execute(
                            vector_base.order_by(EntityRouteIndexRow.updated_at.desc())
                            .limit(_MAX_CANDIDATE_SCAN)
                        )
                    ).all()
                    for index_row, entity_row in rows:
                        stored = [float(item) for item in index_row.embedding]
                        if len(stored) != embedding_dimensions:
                            continue
                        entities[entity_row.entity_id] = entity_row
                        vector_scores[entity_row.entity_id] = max(
                            0.0, _cosine(vector, stored)
                        )

            if not entities:
                return []
            aliases, identities = await self._entity_identity_summaries(
                session,
                tenant_id=tenant_id,
                entity_ids=sorted(entities),
            )

        candidates: list[EntityRouteCandidate] = []
        for entity_id, row in entities.items():
            candidate_aliases = aliases.get(entity_id, ())
            texts = (_normalise(row.canonical_label), *map(_normalise, candidate_aliases))
            lexical_score = max((_score_text(query, text) for text in texts), default=0.0)
            vector_score = vector_scores.get(entity_id, 0.0)
            exact_alias = any(query == text for text in texts if text)
            fused_score = max(
                lexical_score,
                (0.60 * lexical_score) + (0.40 * vector_score),
            )
            if exact_alias:
                fused_score = max(fused_score, 0.98)
            candidates.append(
                EntityRouteCandidate(
                    tenant_id=tenant_id,
                    entity_id=entity_id,
                    entity_type=row.entity_type,
                    canonical_label=row.canonical_label,
                    accepted_aliases=candidate_aliases,
                    accepted_external_ids=identities.get(entity_id, ()),
                    lexical_score=lexical_score,
                    vector_score=vector_score,
                    fused_score=max(0.0, min(1.0, fused_score)),
                    exact_alias=exact_alias,
                )
            )
        return sorted(
            candidates,
            key=lambda candidate: (-candidate.fused_score, candidate.entity_id),
        )[:limit]

    async def _entity_identity_summaries(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        entity_ids: Iterable[str],
    ) -> tuple[dict[str, tuple[str, ...]], dict[str, tuple[str, ...]]]:
        ids = sorted({item for item in entity_ids if item})
        if not ids:
            return {}, {}
        alias_rows = (
            await session.scalars(
                select(EntityAliasRow).where(
                    EntityAliasRow.tenant_id == tenant_id,
                    EntityAliasRow.entity_id.in_(ids),
                    EntityAliasRow.status.in_(sorted(_ACCEPTED_IDENTITY_STATES)),
                )
            )
        ).all()
        identity_rows = (
            await session.scalars(
                select(ExternalIdentityRow).where(
                    ExternalIdentityRow.tenant_id == tenant_id,
                    ExternalIdentityRow.entity_id.in_(ids),
                    ExternalIdentityRow.status.in_(sorted(_ACCEPTED_IDENTITY_STATES)),
                )
            )
        ).all()
        aliases: defaultdict[str, list[str]] = defaultdict(list)
        identities: defaultdict[str, list[str]] = defaultdict(list)
        for row in alias_rows:
            aliases[row.entity_id].append(row.alias)
        for row in identity_rows:
            identities[row.entity_id].append(row.external_id)
        return (
            {
                entity_id: tuple(dict.fromkeys(values))[:8]
                for entity_id, values in aliases.items()
            },
            {
                entity_id: tuple(dict.fromkeys(values))[:8]
                for entity_id, values in identities.items()
            },
        )

    async def get_entity_route_index_material(
        self,
        tenant_id: str,
        *,
        entity_id: str,
    ) -> tuple[
        CanonicalEntityRecord,
        tuple[EntityAliasRecord, ...],
        tuple[ExternalIdentityRecord, ...],
    ] | None:
        """Load current accepted identity text for one routable target entity."""

        async with self.sessionmaker() as session:
            entity = await session.scalar(
                select(CanonicalEntityRow).where(
                    CanonicalEntityRow.tenant_id == tenant_id,
                    CanonicalEntityRow.entity_id == entity_id,
                    CanonicalEntityRow.lifecycle_status.in_(
                        sorted(_ROUTABLE_ENTITY_STATES)
                    ),
                )
            )
            if entity is None:
                return None
            aliases = (
                await session.scalars(
                    select(EntityAliasRow)
                    .where(
                        EntityAliasRow.tenant_id == tenant_id,
                        EntityAliasRow.entity_id == entity_id,
                        EntityAliasRow.status.in_(
                            sorted(_ACCEPTED_IDENTITY_STATES)
                        ),
                    )
                    .order_by(EntityAliasRow.created_at, EntityAliasRow.alias_id)
                )
            ).all()
            identities = (
                await session.scalars(
                    select(ExternalIdentityRow)
                    .where(
                        ExternalIdentityRow.tenant_id == tenant_id,
                        ExternalIdentityRow.entity_id == entity_id,
                        ExternalIdentityRow.status.in_(
                            sorted(_ACCEPTED_IDENTITY_STATES)
                        ),
                    )
                    .order_by(
                        ExternalIdentityRow.created_at,
                        ExternalIdentityRow.identity_id,
                    )
                )
            ).all()
            return (
                _entity_record(entity),
                tuple(_alias_record(alias) for alias in aliases),
                tuple(_identity_record(identity) for identity in identities),
            )

    async def upsert_entity_route_index(
        self,
        tenant_id: str,
        *,
        entity_id: str,
        entity_type: str,
        normalized_text: str,
        embedding: Sequence[float],
        embedding_model: str,
        embedding_dimensions: int = KNOWLEDGE_EMBEDDING_DIMENSIONS,
        updated_at: datetime | None = None,
    ) -> str:
        """Refresh one entity's vector sidecar without altering canonical facts."""

        model = embedding_model.strip()
        text = _normalise(normalized_text)
        if not model or not text:
            raise ValueError("entity route index requires model and normalized text")
        vector = _bounded_embedding(embedding, dimensions=embedding_dimensions)
        now = _aware(updated_at) or utc_now()

        async def operation(session: AsyncSession) -> str:
            await self._require_tenant(session, tenant_id)
            entity = await session.scalar(
                select(CanonicalEntityRow).where(
                    CanonicalEntityRow.tenant_id == tenant_id,
                    CanonicalEntityRow.entity_id == entity_id,
                )
            )
            if entity is None:
                raise RecordNotFoundError(entity_id)
            if entity.entity_type != entity_type:
                raise ValueError("entity route index entity type mismatch")
            if entity.lifecycle_status not in _ROUTABLE_ENTITY_STATES:
                raise ValueError("only approved or active entities may be indexed")
            existing = await session.scalar(
                select(EntityRouteIndexRow)
                .where(
                    EntityRouteIndexRow.tenant_id == tenant_id,
                    EntityRouteIndexRow.entity_id == entity_id,
                    EntityRouteIndexRow.embedding_model == model,
                    EntityRouteIndexRow.embedding_dimensions == embedding_dimensions,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            if existing is None:
                existing = EntityRouteIndexRow(
                    index_id=_stable_index_id(
                        tenant_id, entity_id, model, embedding_dimensions
                    ),
                    tenant_id=tenant_id,
                    entity_id=entity_id,
                    entity_type=entity_type,
                    normalized_text=text,
                    embedding=vector,
                    embedding_model=model,
                    embedding_dimensions=embedding_dimensions,
                    updated_at=now,
                )
                session.add(existing)
            else:
                existing.entity_type = entity_type
                existing.normalized_text = text
                existing.embedding = vector
                existing.updated_at = now
            await session.flush()
            return existing.index_id

        return await self._write(operation)

    async def record_entity_route_decision(
        self,
        tenant_id: str,
        *,
        source_version_id: str,
        proposed_entity_id: str,
        entity_type: str,
        decision: EntityRouteDecision,
        fence: TaskFenceToken,
        model_name: str = "",
        model_revision: str = "",
        created_at: datetime | None = None,
    ) -> str:
        """Append/replay one decision without exposing prompt or source text."""

        now = _aware(created_at) or utc_now()

        async def operation(session: AsyncSession) -> str:
            await self._assert_fenced_version_binding(
                session,
                fence,
                tenant_id=tenant_id,
                version_id=source_version_id,
            )
            source = await session.scalar(
                select(DocumentVersionRow).where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.version_id == source_version_id,
                )
            )
            if source is None:
                raise RecordNotFoundError(source_version_id)
            if decision.candidate_entity_id:
                candidate = await session.scalar(
                    select(CanonicalEntityRow).where(
                        CanonicalEntityRow.tenant_id == tenant_id,
                        CanonicalEntityRow.entity_id == decision.candidate_entity_id,
                        CanonicalEntityRow.entity_type == entity_type,
                    )
                )
                if candidate is None:
                    raise RecordNotFoundError(decision.candidate_entity_id)
                if (
                    decision.action is EntityRouteAction.LINK
                    and candidate.lifecycle_status not in _ROUTABLE_ENTITY_STATES
                ):
                    raise ValueError(
                        "entity route link target is no longer approved or active"
                    )
            existing = await session.scalar(
                select(EntityRouteDecisionRow)
                .where(
                    EntityRouteDecisionRow.tenant_id == tenant_id,
                    EntityRouteDecisionRow.source_version_id == source_version_id,
                    EntityRouteDecisionRow.proposed_entity_id == proposed_entity_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            if existing is not None:
                same = (
                    existing.entity_type == entity_type
                    and existing.action == decision.action.value
                    and existing.candidate_entity_id == decision.candidate_entity_id
                    and math.isclose(existing.candidate_score, decision.candidate_score)
                    and math.isclose(existing.top1_top2_margin, decision.top1_top2_margin)
                    and math.isclose(existing.model_confidence, decision.model_confidence)
                    and tuple(existing.reason_codes or ()) == tuple(decision.reason_codes)
                    and existing.model_name == model_name
                    and existing.model_revision == model_revision
                )
                if not same:
                    raise IdempotencyConflictError(
                        f"entity-route-decision:{source_version_id}:{proposed_entity_id}"
                    )
                return existing.decision_id
            row = EntityRouteDecisionRow(
                decision_id=new_id(),
                tenant_id=tenant_id,
                source_version_id=source_version_id,
                proposed_entity_id=proposed_entity_id,
                entity_type=entity_type,
                action=decision.action.value,
                candidate_entity_id=decision.candidate_entity_id,
                candidate_score=decision.candidate_score,
                top1_top2_margin=decision.top1_top2_margin,
                model_confidence=decision.model_confidence,
                reason_codes=list(decision.reason_codes),
                model_name=model_name[:256],
                model_revision=model_revision[:256],
                created_at=now,
            )
            session.add(row)
            await session.flush()
            return row.decision_id

        return await self._write(operation)

    async def get_entity_route_decision(
        self,
        tenant_id: str,
        *,
        source_version_id: str,
        proposed_entity_id: str,
        entity_type: str,
    ) -> EntityRouteDecision | None:
        """Load one immutable decision for deterministic source-version replay."""

        async with self.sessionmaker() as session:
            source = await session.scalar(
                select(DocumentVersionRow).where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.version_id == source_version_id,
                )
            )
            if source is None:
                return None
            row = await session.scalar(
                select(EntityRouteDecisionRow).where(
                    EntityRouteDecisionRow.tenant_id == tenant_id,
                    EntityRouteDecisionRow.source_version_id == source_version_id,
                    EntityRouteDecisionRow.proposed_entity_id == proposed_entity_id,
                    EntityRouteDecisionRow.entity_type == entity_type,
                )
            )
            if row is None:
                return None
            if row.candidate_entity_id:
                candidate = await session.scalar(
                    select(CanonicalEntityRow).where(
                        CanonicalEntityRow.tenant_id == tenant_id,
                        CanonicalEntityRow.entity_id == row.candidate_entity_id,
                        CanonicalEntityRow.entity_type == entity_type,
                    )
                )
                if (
                    candidate is None
                    or candidate.lifecycle_status not in _ROUTABLE_ENTITY_STATES
                ):
                    persisted = _decision_record(row)
                    reasons = tuple(
                        dict.fromkeys(
                            (*persisted.reason_codes, "link_target_not_routable")
                        )
                    )[:8]
                    return EntityRouteDecision(
                        action=EntityRouteAction.REVIEW,
                        candidate_score=persisted.candidate_score,
                        top1_top2_margin=persisted.top1_top2_margin,
                        model_confidence=persisted.model_confidence,
                        reason_codes=reasons,
                        model_used=persisted.model_used,
                    )
            return _decision_record(row)


__all__ = ["KnowledgeEntityRouteMixin"]
