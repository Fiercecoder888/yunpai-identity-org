"""Runtime bridge for safe entity identity candidate routing.

The runtime is deliberately invoked after deterministic canonicalization and
before any entity/identity/alias/relationship row is written.  A similarity
match may reuse a pre-existing entity ID only after all service-side gates pass;
otherwise the deterministic candidate continues through the normal review path.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..structured_llm import StructuredModelClient
from .canonicalization import CanonicalizationResult
from .db_models import IdempotencyConflictError
from .embeddings import EmbeddingProvider
from .entity_routing import (
    EntityRouteAction,
    EntityRouteCandidate,
    EntityRouteDecision,
    EntityRoutePolicy,
    EntityRouteRequest,
    EntityRouteSelector,
    PydanticEntityRouteSelector,
)
from .schema import (
    CanonicalEntityRecord,
    ClaimStatus,
    EntityAliasRecord,
    ExternalIdentityRecord,
    LifecycleStatus,
    RelationshipClaimRecord,
    TaskFenceToken,
    utc_now,
)

if TYPE_CHECKING:
    from .persistence import KnowledgeStore


logger = logging.getLogger(__name__)

_ROUTABLE_ENTITY_TYPES = frozenset(
    {"enterprise", "product", "material", "mold", "equipment"}
)
_ROUTABLE_ENTITY_STATES = frozenset(
    {LifecycleStatus.ACTIVE, LifecycleStatus.APPROVED}
)
_STABLE_EXACT_IDENTITY_RULES = frozenset(
    {
        "exact_internal_code",
        "exact_typed_header_code",
        "exact_customer_code_scoped",
        "exact_supplier_code_scoped",
        "exact_order_number_with_party_scope",
        "exact_content_hash",
    }
)
_MIN_TRUSTED_IDENTITY_CONFIDENCE = 0.95


@dataclass(frozen=True, slots=True)
class EntityRoutingResolution:
    canonical: CanonicalizationResult
    decisions: Mapping[str, EntityRouteDecision]
    linked_entity_ids: Mapping[str, str]
    linked_entity_assertions: Mapping[str, CanonicalEntityRecord] = field(
        default_factory=dict
    )


class EntityRoutingRuntime:
    """Tenant-safe candidate lookup plus bounded model adjudication."""

    def __init__(
        self,
        *,
        store: KnowledgeStore,
        embedding_provider: EmbeddingProvider | None,
        selector: EntityRouteSelector | None = None,
        policy: EntityRoutePolicy | None = None,
        model_name: str = "",
        required: bool = False,
        top_k: int = 5,
        circuit_failures: int = 3,
        circuit_seconds: float = 300.0,
        owned_model_client: StructuredModelClient | None = None,
    ) -> None:
        if top_k < 1 or top_k > 5:
            raise ValueError("entity router top_k must be in [1, 5]")
        if circuit_failures < 1 or circuit_seconds <= 0:
            raise ValueError("entity router circuit settings must be positive")
        self.store = store
        self.embedding_provider = embedding_provider
        self.selector = selector
        self.policy = policy or EntityRoutePolicy()
        self.model_name = model_name
        self.required = required
        self.top_k = top_k
        self.circuit_failures = circuit_failures
        self.circuit_seconds = circuit_seconds
        self._owned_model_client = owned_model_client
        self._failure_count = 0
        self._circuit_until = 0.0
        self._last_success_at = ""
        self._last_failure_at = ""

    @classmethod
    def from_settings(
        cls,
        settings,
        *,
        store: KnowledgeStore,
        embedding_provider: EmbeddingProvider | None,
    ) -> EntityRoutingRuntime:
        if not settings.entity_router_enabled:
            raise ValueError("ENTITY_ROUTER_ENABLED is false")
        client = StructuredModelClient(
            api_key=settings.entity_router_api_key,
            base_url=settings.entity_router_base_url,
            model=settings.entity_router_model,
            temperature=0.0,
            max_tokens=384,
            enable_thinking=False,
            timeout=settings.entity_router_timeout_seconds,
            retries=1,
            output_mode="prompted",
        )
        return cls(
            store=store,
            embedding_provider=embedding_provider,
            selector=PydanticEntityRouteSelector(client),
            policy=EntityRoutePolicy(
                auto_min_score=settings.entity_router_auto_min_score,
                min_margin=settings.entity_router_min_margin,
                model_min_confidence=settings.entity_router_model_min_confidence,
            ),
            model_name=settings.entity_router_model,
            required=settings.entity_router_required,
            top_k=settings.entity_router_top_k,
            circuit_failures=settings.entity_router_circuit_failures,
            circuit_seconds=settings.entity_router_circuit_seconds,
            owned_model_client=client,
        )

    async def close(self) -> None:
        if self._owned_model_client is not None:
            await self._owned_model_client.close()

    def status_snapshot(self) -> dict[str, object]:
        now = time.monotonic()
        return {
            "enabled": True,
            "model": self.model_name,
            "embedding_enabled": self.embedding_provider is not None,
            "circuit_open": now < self._circuit_until,
            "last_success_at": self._last_success_at or None,
            "last_failure_at": self._last_failure_at or None,
            "failure_count": self._failure_count,
        }

    async def _embed(self, text: str) -> list[float] | None:
        provider = self.embedding_provider
        if provider is None:
            return None
        vectors = await provider.embed_texts([text])
        if len(vectors) != 1:
            raise ValueError("entity route embedding response count mismatch")
        vector = [float(item) for item in vectors[0]]
        if len(vector) != provider.dimensions:
            raise ValueError("entity route embedding dimension mismatch")
        return vector

    @staticmethod
    def _identity_text(
        entity: CanonicalEntityRecord,
        aliases: Sequence[EntityAliasRecord] = (),
        identities: Sequence[ExternalIdentityRecord] = (),
    ) -> str:
        parts = [entity.canonical_label]
        parts.extend(alias.alias for alias in aliases if alias.status == ClaimStatus.ACCEPTED)
        parts.extend(
            identity.external_id
            for identity in identities
            if identity.status == ClaimStatus.ACCEPTED
        )
        return " | ".join(dict.fromkeys(part.strip() for part in parts if part.strip()))

    async def _model_choice(self, request: EntityRouteRequest):
        loop = asyncio.get_running_loop()
        if self.selector is None or loop.time() < self._circuit_until:
            return None
        try:
            choice = await self.selector.select(request)
        except Exception as exc:  # optional model failure always fails closed
            self._failure_count += 1
            self._last_failure_at = utc_now().isoformat()
            if self._failure_count >= self.circuit_failures:
                self._circuit_until = loop.time() + self.circuit_seconds
            if self.required:
                raise RuntimeError("entity router model call failed") from exc
            logger.warning("Entity routing model degraded error_type=%s", type(exc).__name__)
            return None
        self._failure_count = 0
        self._circuit_until = 0.0
        self._last_success_at = utc_now().isoformat()
        return choice

    async def _exact_identity_candidates(
        self,
        *,
        tenant_id: str,
        entity: CanonicalEntityRecord,
        identities: Sequence[ExternalIdentityRecord],
    ) -> tuple[list[EntityRouteCandidate], bool]:
        candidates: dict[str, EntityRouteCandidate] = {}
        blocking_conflict = False
        for identity in identities:
            if identity.entity_type != entity.entity_type:
                blocking_conflict = True
                continue
            trusted = self._is_trusted_stable_identity(identity)
            if identity.conflicts:
                blocking_conflict = True
                continue
            existing = await self.store.find_external_identity(
                tenant_id,
                entity_type=entity.entity_type,
                source_system=identity.source_system,
                external_id=identity.external_id,
            )
            if not trusted:
                if existing is not None and existing.status == ClaimStatus.ACCEPTED:
                    blocking_conflict = True
                continue
            if existing is None:
                continue
            if existing.status != ClaimStatus.ACCEPTED:
                blocking_conflict = True
                continue
            target = await self.store.get_entity(tenant_id, existing.entity_id)
            if target is None or target.lifecycle_status not in _ROUTABLE_ENTITY_STATES:
                blocking_conflict = True
                continue
            candidates[target.entity_id] = EntityRouteCandidate(
                tenant_id=tenant_id,
                entity_id=target.entity_id,
                entity_type=target.entity_type,
                canonical_label=target.canonical_label,
                accepted_external_ids=(identity.external_id,),
                lexical_score=1.0,
                vector_score=1.0,
                fused_score=1.0,
                exact_identity=True,
            )
        return list(candidates.values()), blocking_conflict

    @staticmethod
    def _is_trusted_stable_identity(identity: ExternalIdentityRecord) -> bool:
        """Allow only accepted, scoped, non-model identity evidence to bypass a model."""

        rule = str(identity.mapping_rule or "").strip().casefold()
        source = str(identity.source_system or "").strip().casefold()
        if (
            identity.status != ClaimStatus.ACCEPTED
            or identity.confidence < _MIN_TRUSTED_IDENTITY_CONFIDENCE
            or not identity.external_id.strip()
            or not source
            or rule not in _STABLE_EXACT_IDENTITY_RULES
        ):
            return False
        # Model numbers and name-like values are often reused across products.
        # They remain candidate evidence even if an upstream source labeled them
        # as exact; only stable identifiers may drive a direct link.
        if "model" in source or "name" in source:
            return False
        if rule in {"exact_customer_code_scoped", "exact_supplier_code_scoped"}:
            return ":unresolved:" not in source and source.startswith(
                ("customer:", "supplier:")
            )
        if rule == "exact_internal_code":
            return source == "tenant:internal_product_code"
        if rule == "exact_typed_header_code":
            return source.startswith("m1:header_")
        if rule == "exact_order_number_with_party_scope":
            return source.startswith("order:") and ":unresolved:" not in source
        return rule == "exact_content_hash" and source == "sha256"

    @staticmethod
    def _merge_candidates(
        *groups: Sequence[EntityRouteCandidate],
    ) -> list[EntityRouteCandidate]:
        merged: dict[str, EntityRouteCandidate] = {}
        for candidate in (item for group in groups for item in group):
            current = merged.get(candidate.entity_id)
            if current is None:
                merged[candidate.entity_id] = candidate
                continue
            merged[candidate.entity_id] = current.model_copy(
                update={
                    "accepted_aliases": tuple(
                        dict.fromkeys((*current.accepted_aliases, *candidate.accepted_aliases))
                    )[:8],
                    "accepted_external_ids": tuple(
                        dict.fromkeys(
                            (*current.accepted_external_ids, *candidate.accepted_external_ids)
                        )
                    )[:8],
                    "lexical_score": max(current.lexical_score, candidate.lexical_score),
                    "vector_score": max(current.vector_score, candidate.vector_score),
                    "fused_score": max(current.fused_score, candidate.fused_score),
                    "exact_identity": current.exact_identity or candidate.exact_identity,
                    "exact_alias": current.exact_alias or candidate.exact_alias,
                }
            )
        return sorted(
            merged.values(), key=lambda item: (-item.fused_score, item.entity_id)
        )[:5]

    async def _validate_link_target(
        self,
        *,
        tenant_id: str,
        entity_type: str,
        decision: EntityRouteDecision,
    ) -> EntityRouteDecision:
        """Recheck mutable target lifecycle before applying an immutable link."""

        if (
            decision.action is not EntityRouteAction.LINK
            or not decision.candidate_entity_id
        ):
            return decision
        target = await self.store.get_entity(
            tenant_id,
            decision.candidate_entity_id,
        )
        if (
            target is not None
            and target.entity_type == entity_type
            and target.lifecycle_status in _ROUTABLE_ENTITY_STATES
        ):
            return decision
        reasons = tuple(
            dict.fromkeys((*decision.reason_codes, "link_target_not_routable"))
        )[:8]
        return EntityRouteDecision(
            action=EntityRouteAction.REVIEW,
            candidate_score=decision.candidate_score,
            top1_top2_margin=decision.top1_top2_margin,
            model_confidence=decision.model_confidence,
            reason_codes=reasons,
            model_used=decision.model_used,
        )

    async def resolve(
        self,
        *,
        tenant_id: str,
        source_version_id: str,
        fence: TaskFenceToken,
        canonical: CanonicalizationResult,
    ) -> EntityRoutingResolution:
        """Return a remapped canonicalization result without writing facts."""

        aliases_by_entity: dict[str, list[EntityAliasRecord]] = defaultdict(list)
        identities_by_entity: dict[str, list[ExternalIdentityRecord]] = defaultdict(list)
        for alias in canonical.aliases:
            aliases_by_entity[alias.entity_id].append(alias)
        for identity in canonical.external_identities:
            identities_by_entity[identity.entity_id].append(identity)

        remap: dict[str, str] = {}
        review_entity_ids: set[str] = set()
        decisions: dict[str, EntityRouteDecision] = {}
        linked_assertions: dict[str, CanonicalEntityRecord] = {}
        for entity in canonical.entities:
            if entity.entity_type not in _ROUTABLE_ENTITY_TYPES:
                continue
            persisted_decision = await self.store.get_entity_route_decision(
                tenant_id,
                source_version_id=source_version_id,
                proposed_entity_id=entity.entity_id,
                entity_type=entity.entity_type,
            )
            if persisted_decision is not None:
                persisted_decision = await self._validate_link_target(
                    tenant_id=tenant_id,
                    entity_type=entity.entity_type,
                    decision=persisted_decision,
                )
                decisions[entity.entity_id] = persisted_decision
                if (
                    persisted_decision.action.value == "link"
                    and persisted_decision.candidate_entity_id
                ):
                    remap[entity.entity_id] = persisted_decision.candidate_entity_id
                    linked_assertions[entity.entity_id] = entity
                elif persisted_decision.action in {
                    EntityRouteAction.NEW_CANDIDATE,
                    EntityRouteAction.REVIEW,
                }:
                    review_entity_ids.add(entity.entity_id)
                continue
            entity_aliases = aliases_by_entity.get(entity.entity_id, [])
            entity_identities = identities_by_entity.get(entity.entity_id, [])
            exact_key = await self.store.get_routable_entity_by_key(
                tenant_id,
                entity_type=entity.entity_type,
                canonical_key=entity.canonical_key,
            )
            exact_candidates, blocking_conflict = await self._exact_identity_candidates(
                tenant_id=tenant_id,
                entity=entity,
                identities=entity_identities,
            )
            if exact_key is not None:
                # Canonical keys derived from names, models, or unresolved
                # scope are not proof of identity. They are merely a strong
                # candidate for the bounded model/review path.
                exact_candidates.append(exact_key)
            text = self._identity_text(entity, entity_aliases, entity_identities)
            try:
                embedding = await self._embed(text)
            except Exception as exc:
                if self.required:
                    raise RuntimeError("entity router embedding failed") from exc
                logger.warning("Entity routing embedding degraded error_type=%s", type(exc).__name__)
                embedding = None
            semantic_candidates = await self.store.find_entity_route_candidates(
                tenant_id,
                entity_type=entity.entity_type,
                normalized_label=entity.canonical_label,
                query_embedding=embedding,
                embedding_model=(self.embedding_provider.model if self.embedding_provider else ""),
                embedding_dimensions=(self.embedding_provider.dimensions if self.embedding_provider else 1024),
                limit=self.top_k,
            )
            candidates = self._merge_candidates(exact_candidates, semantic_candidates)
            request = EntityRouteRequest(
                tenant_id=tenant_id,
                proposed_entity_id=entity.entity_id,
                entity_type=entity.entity_type,
                normalized_label=entity.canonical_label,
                explicit_external_ids=tuple(
                    identity.external_id for identity in entity_identities
                ),
                candidates=tuple(candidates),
                blocking_conflict=blocking_conflict,
            )
            choice = await self._model_choice(request) if (
                not blocking_conflict
                and bool(candidates)
                and not any(candidate.exact_identity for candidate in candidates)
            ) else None
            decision = self.policy.decide(request, choice)
            decision = await self._validate_link_target(
                tenant_id=tenant_id,
                entity_type=entity.entity_type,
                decision=decision,
            )
            decisions[entity.entity_id] = decision
            try:
                await self.store.record_entity_route_decision(
                    tenant_id,
                    source_version_id=source_version_id,
                    proposed_entity_id=entity.entity_id,
                    entity_type=entity.entity_type,
                    decision=decision,
                    fence=fence,
                    model_name=self.model_name if decision.model_used else "",
                )
            except IdempotencyConflictError:
                replay = await self.store.get_entity_route_decision(
                    tenant_id,
                    source_version_id=source_version_id,
                    proposed_entity_id=entity.entity_id,
                    entity_type=entity.entity_type,
                )
                if replay is None:
                    raise
                decision = await self._validate_link_target(
                    tenant_id=tenant_id,
                    entity_type=entity.entity_type,
                    decision=replay,
                )
                decisions[entity.entity_id] = decision
            if decision.action.value == "link" and decision.candidate_entity_id:
                remap[entity.entity_id] = decision.candidate_entity_id
                linked_assertions[entity.entity_id] = entity
            elif decision.action in {
                EntityRouteAction.NEW_CANDIDATE,
                EntityRouteAction.REVIEW,
            }:
                review_entity_ids.add(entity.entity_id)

        if not remap and not review_entity_ids:
            return EntityRoutingResolution(
                canonical=canonical,
                decisions=decisions,
                linked_entity_ids=remap,
                linked_entity_assertions=linked_assertions,
            )
        entities = [
            (
                entity.model_copy(
                    update={"lifecycle_status": LifecycleStatus.UNDER_REVIEW}
                )
                if entity.entity_id in review_entity_ids
                else entity
            )
            for entity in canonical.entities
            if entity.entity_id not in remap
        ]
        aliases = [
            alias.model_copy(
                update={
                    "entity_id": remap.get(alias.entity_id, alias.entity_id),
                    # A newly observed alias must be reviewed even when the
                    # target entity itself was safely linked.
                    "status": (
                        ClaimStatus.CANDIDATE
                        if alias.entity_id in remap
                        or alias.entity_id in review_entity_ids
                        else alias.status
                    ),
                }
            )
            for alias in canonical.aliases
        ]
        identities = [
            identity.model_copy(
                update={
                    "entity_id": remap.get(identity.entity_id, identity.entity_id),
                    "status": (
                        ClaimStatus.CANDIDATE
                        if identity.entity_id in remap
                        or identity.entity_id in review_entity_ids
                        else identity.status
                    ),
                }
            )
            for identity in canonical.external_identities
        ]
        relationships: list[RelationshipClaimRecord] = []
        for relationship in canonical.relationships:
            from_id = remap.get(relationship.from_entity_id, relationship.from_entity_id)
            to_id = remap.get(relationship.to_entity_id, relationship.to_entity_id)
            # A relationship whose endpoints collapse to the same approved
            # entity carries no graph fact. Keeping it would violate the SQL
            # invariant, so leave its original evidence in the source document
            # and do not create a fabricated self-edge.
            if from_id == to_id:
                continue
            relationships.append(
                relationship.model_copy(
                    update={
                        "from_entity_id": from_id,
                        "to_entity_id": to_id,
                        "status": (
                            ClaimStatus.CANDIDATE
                            if relationship.from_entity_id in review_entity_ids
                            or relationship.to_entity_id in review_entity_ids
                            else relationship.status
                        ),
                    }
                )
            )
        return EntityRoutingResolution(
            canonical=canonical.model_copy(
                update={
                    "entities": entities,
                    "aliases": aliases,
                    "external_identities": identities,
                    "relationships": relationships,
                }
            ),
            decisions=decisions,
            linked_entity_ids=remap,
            linked_entity_assertions=linked_assertions,
        )

    async def index_entity(
        self,
        *,
        entity: CanonicalEntityRecord,
        aliases: Sequence[EntityAliasRecord] = (),
        identities: Sequence[ExternalIdentityRecord] = (),
    ) -> str | None:
        if entity.lifecycle_status not in _ROUTABLE_ENTITY_STATES:
            return None
        if self.embedding_provider is None:
            return None
        text = self._identity_text(entity, aliases, identities)
        try:
            vector = await self._embed(text)
            if vector is None:
                return None
            return await self.store.upsert_entity_route_index(
                entity.tenant_id,
                entity_id=entity.entity_id,
                entity_type=entity.entity_type,
                normalized_text=text,
                embedding=vector,
                embedding_model=self.embedding_provider.model,
                embedding_dimensions=self.embedding_provider.dimensions,
            )
        except Exception as exc:
            if self.required:
                raise RuntimeError("entity route index refresh failed") from exc
            logger.warning("Entity route index refresh degraded error_type=%s", type(exc).__name__)
            return None

    async def refresh_entity_index(
        self,
        *,
        tenant_id: str,
        entity_id: str,
    ) -> str | None:
        """Rebuild one target vector from its current accepted identities."""

        material = await self.store.get_entity_route_index_material(
            tenant_id,
            entity_id=entity_id,
        )
        if material is None:
            return None
        entity, aliases, identities = material
        return await self.index_entity(
            entity=entity,
            aliases=aliases,
            identities=identities,
        )


__all__ = ["EntityRoutingResolution", "EntityRoutingRuntime"]
