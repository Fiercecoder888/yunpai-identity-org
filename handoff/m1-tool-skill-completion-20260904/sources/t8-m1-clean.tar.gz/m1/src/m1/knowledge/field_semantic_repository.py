"""Tenant-safe persistence for governed field-semantic mappings."""

from __future__ import annotations

import inspect as pyinspect
import math
from collections.abc import Collection, Iterable, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from m1.documents.parsing.field_semantic_routing import (
    FieldSemanticCandidateProposal,
    FieldSemanticExecutionObservation,
    FieldSemanticProfile,
    FieldSemanticProfileMatch,
)

from .db_document_models import TenantRow
from .db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    TenantBoundaryError,
)
from .field_semantic_db_models import (
    FieldSemanticObservationRow,
    FieldSemanticProfileRow,
)
from .field_semantic_schema import (
    FieldSemanticObservationOutcome,
    FieldSemanticObservationRecord,
    FieldSemanticProfileRecord,
    FieldSemanticProfileStatus,
)
from .persistence_helpers import _aware, _canonical_json, _enum
from .repository_base import (
    KnowledgeRepositoryBase,
    _tenant_scoped_call,
)
from .route_lifecycle import (
    record_route_lifecycle_event,
    require_separated_approval,
)
from .schema import utc_now

_MIN_ACTIVATION_DISTINCT_TASKS = 3


def _profile_record(row: FieldSemanticProfileRow) -> FieldSemanticProfileRecord:
    return FieldSemanticProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        exact_fingerprint=row.exact_fingerprint,
        signature=row.signature_json,
        canonical_field_id=row.canonical_field_id,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_note=row.review_note,
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at) or utc_now(),
        updated_at=_aware(row.updated_at) or utc_now(),
    )


def _observation_record(
    row: FieldSemanticObservationRow,
) -> FieldSemanticObservationRecord:
    return FieldSemanticObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        task_reference_hash=row.task_reference_hash,
        outcome=row.outcome,
        validation_passed=row.validation_passed,
        reviewed_by=row.reviewed_by,
        review_note_sha256=row.review_note_sha256,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        observed_at=_aware(row.observed_at) or utc_now(),
    )


def _same_profile_definition(
    row: FieldSemanticProfileRow, record: FieldSemanticProfileRecord
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.tenant_id == record.tenant_id
        and row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and _canonical_json(row.signature_json)
        == _canonical_json(record.signature.model_dump(mode="json"))
        and row.canonical_field_id == record.canonical_field_id
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
    )


def _same_observation(
    row: FieldSemanticObservationRow, record: FieldSemanticObservationRecord
) -> bool:
    return (
        row.tenant_id == record.tenant_id
        and row.profile_id == record.profile_id
        and row.idempotency_key == record.idempotency_key
        and row.exact_fingerprint == record.exact_fingerprint
        and row.task_reference_hash == record.task_reference_hash
        and row.outcome == record.outcome.value
        and row.validation_passed == record.validation_passed
        and row.reviewed_by == record.reviewed_by
        and row.review_note_sha256 == record.review_note_sha256
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    candidate = _aware(second) or utc_now()
    return max(normalized, candidate) if normalized is not None else candidate


def _fingerprint(value: str) -> str:
    normalized = value.strip().casefold()
    if len(normalized) != 64:
        raise ValueError(
            "field semantic fingerprints must contain 64 hexadecimal chars"
        )
    try:
        int(normalized, 16)
    except ValueError as exc:
        raise ValueError(
            "field semantic fingerprints must contain 64 hexadecimal chars"
        ) from exc
    return normalized


def _canonical_ids(values: Collection[str]) -> frozenset[str]:
    if isinstance(values, (str, bytes, bytearray)):
        raise TypeError("allowed_canonical_field_ids must be a collection of IDs")
    normalized = frozenset(str(item).strip().casefold() for item in values)
    if not normalized or "" in normalized:
        raise ValueError("allowed_canonical_field_ids must be a non-empty registry")
    return normalized


class KnowledgeFieldSemanticRouteMixin:
    """Repository mixin; only reviewed candidate profiles can become active."""

    async def _lock_field_semantic_tenant(
        self, session: AsyncSession, tenant_id: str
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_field_semantic_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> FieldSemanticProfileRow:
        statement = select(FieldSemanticProfileRow).where(
            FieldSemanticProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"field semantic profile not found: {profile_id}")
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_field_semantic_profile(
        self, record: FieldSemanticProfileRecord
    ) -> FieldSemanticProfileRecord:
        """Create one candidate version; active rows cannot bypass governance."""

        if record.status is not FieldSemanticProfileStatus.CANDIDATE:
            raise ValueError("new field semantic profiles must start as candidate")

        async def operation(session: AsyncSession) -> FieldSemanticProfileRecord:
            await self._lock_field_semantic_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(FieldSemanticProfileRow).where(
                        FieldSemanticProfileRow.tenant_id == record.tenant_id,
                        or_(
                            FieldSemanticProfileRow.profile_id == record.profile_id,
                            (
                                (
                                    FieldSemanticProfileRow.profile_key
                                    == record.profile_key
                                )
                                & (FieldSemanticProfileRow.version == record.version)
                            ),
                            (
                                (
                                    FieldSemanticProfileRow.exact_fingerprint
                                    == record.exact_fingerprint
                                )
                                & (FieldSemanticProfileRow.version == record.version)
                            ),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if row.profile_key == record.profile_key
                        and row.version == record.version
                    ),
                    None,
                )
                if existing is not None and _same_profile_definition(existing, record):
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"field-semantic-profile:{record.profile_key}:{record.version}"
                )

            predecessor: FieldSemanticProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_field_semantic_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError("a field mapping revision changes its profile key")
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("a field mapping revision changes its fingerprint")
                if predecessor.contract_revision != record.signature.contract_revision:
                    raise ValueError("a field mapping revision changes its contract")
                if record.version != predecessor.version + 1:
                    raise ValueError("field mapping revisions must be consecutive")
                if predecessor.status == FieldSemanticProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active field mapping must be deprecated before revision"
                    )

            dimensions = (
                len(record.embedding)
                if record.embedding is not None
                else record.embedding_dimensions
            )
            row = FieldSemanticProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                exact_fingerprint=record.exact_fingerprint,
                signature_json=record.signature.model_dump(mode="json"),
                canonical_field_id=record.canonical_field_id,
                contract_revision=record.signature.contract_revision,
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=dimensions,
                created_by=record.created_by,
                reviewed_by=record.reviewed_by,
                reviewed_at=record.reviewed_at,
                review_note=record.review_note,
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == FieldSemanticProfileStatus.CANDIDATE.value
            ):
                predecessor.status = FieldSemanticProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at, record.created_at
                )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=record.tenant_id,
                    route_kind="field_semantic",
                    profile_id=predecessor.profile_id,
                    event_type="superseded",
                    actor_id=record.created_by,
                    reason=f"superseded by profile {record.profile_id}",
                    observation_count=predecessor.observation_count,
                    occurred_at=record.created_at,
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def create_field_semantic_candidate(
        self, record: FieldSemanticCandidateProposal
    ) -> FieldSemanticProfile:
        """Materialize an automatic proposal as an inactive version-one row."""

        candidate = FieldSemanticProfileRecord(
            tenant_id=record.tenant_id,
            profile_key=record.profile_key,
            version=1,
            exact_fingerprint=record.signature.exact_fingerprint(),
            signature=record.signature,
            canonical_field_id=record.canonical_field_id,
            embedding=(
                list(record.embedding) if record.embedding is not None else None
            ),
            embedding_model=record.embedding_model,
            embedding_dimensions=record.embedding_dimensions,
            created_by=record.created_by,
        )
        try:
            return (
                await self.create_field_semantic_profile(candidate)
            ).as_runtime_profile()
        except IdempotencyConflictError:
            profiles = await self.list_field_semantic_profiles(
                record.tenant_id,
                exact_fingerprint=record.signature.exact_fingerprint(),
                contract_revision=record.signature.contract_revision,
            )
            for existing in profiles:
                if (
                    existing.status is FieldSemanticProfileStatus.CANDIDATE
                    and existing.canonical_field_id == record.canonical_field_id
                    and _canonical_json(existing.signature.model_dump(mode="json"))
                    == _canonical_json(record.signature.model_dump(mode="json"))
                ):
                    return existing.as_runtime_profile()
            raise

    async def get_field_semantic_profile(
        self, tenant_id: str, profile_id: str
    ) -> FieldSemanticProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(FieldSemanticProfileRow).where(
                    FieldSemanticProfileRow.tenant_id == tenant_id,
                    FieldSemanticProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def list_field_semantic_profiles(
        self,
        tenant_id: str,
        *,
        status: FieldSemanticProfileStatus | str | None = None,
        exact_fingerprint: str | None = None,
        canonical_field_id: str | None = None,
        contract_revision: str | None = None,
        limit: int = 200,
    ) -> list[FieldSemanticProfileRecord]:
        if limit < 1:
            return []
        statement = select(FieldSemanticProfileRow).where(
            FieldSemanticProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            statement = statement.where(
                FieldSemanticProfileRow.status
                == FieldSemanticProfileStatus(_enum(status)).value
            )
        if exact_fingerprint is not None:
            statement = statement.where(
                FieldSemanticProfileRow.exact_fingerprint
                == _fingerprint(exact_fingerprint)
            )
        if canonical_field_id is not None:
            statement = statement.where(
                FieldSemanticProfileRow.canonical_field_id
                == canonical_field_id.strip().casefold()
            )
        if contract_revision is not None:
            statement = statement.where(
                FieldSemanticProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        statement = statement.order_by(
            FieldSemanticProfileRow.profile_key,
            FieldSemanticProfileRow.version.desc(),
            FieldSemanticProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def get_active_field_semantic_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
    ) -> FieldSemanticProfile | None:
        statement = select(FieldSemanticProfileRow).where(
            FieldSemanticProfileRow.tenant_id == tenant_id,
            FieldSemanticProfileRow.exact_fingerprint
            == _fingerprint(exact_fingerprint),
            FieldSemanticProfileRow.status == FieldSemanticProfileStatus.ACTIVE.value,
            FieldSemanticProfileRow.contract_revision
            == contract_revision.strip().casefold(),
        )
        async with self.sessionmaker() as session:
            row = await session.scalar(
                statement.order_by(
                    FieldSemanticProfileRow.version.desc(),
                    FieldSemanticProfileRow.profile_id,
                )
            )
            return _profile_record(row).as_runtime_profile() if row else None

    async def find_field_semantic_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses: Iterable[FieldSemanticProfileStatus | str] = (
            FieldSemanticProfileStatus.ACTIVE,
        ),
        contract_revision: str | None = None,
        min_similarity: float = -1.0,
        limit: int = 5,
    ) -> list[FieldSemanticProfileMatch]:
        if limit < 1:
            return []
        model = embedding_model.strip()
        if not model:
            raise ValueError("field semantic embedding model identity is required")
        dimensions = int(embedding_dimensions)
        if dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "field semantic embedding identity dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {dimensions}"
            )
        vector = [float(value) for value in embedding]
        if len(vector) != dimensions or not all(
            math.isfinite(value) for value in vector
        ):
            raise ValueError("field semantic query embedding is invalid")
        if not math.isfinite(min_similarity) or not -1.0 <= min_similarity <= 1.0:
            raise ValueError("min_similarity must be a finite value in [-1, 1]")
        accepted = {
            FieldSemanticProfileStatus(_enum(status)).value for status in statuses
        }
        if not accepted:
            return []

        statement = select(FieldSemanticProfileRow).where(
            FieldSemanticProfileRow.tenant_id == tenant_id,
            FieldSemanticProfileRow.status.in_(sorted(accepted)),
            FieldSemanticProfileRow.embedding.is_not(None),
            FieldSemanticProfileRow.embedding_model == model,
            FieldSemanticProfileRow.embedding_dimensions == dimensions,
        )
        if FieldSemanticProfileStatus.ACTIVE.value in accepted:
            statement = statement.where(
                or_(
                    FieldSemanticProfileRow.status
                    != FieldSemanticProfileStatus.ACTIVE.value,
                    FieldSemanticProfileRow.failure_count == 0,
                )
            )
        if contract_revision is not None:
            statement = statement.where(
                FieldSemanticProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        async with self.sessionmaker() as session:
            if self.engine.url.get_backend_name() == "postgresql":
                distance = FieldSemanticProfileRow.embedding.cosine_distance(vector)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .where((1.0 - distance) >= min_similarity)
                        .order_by(distance, FieldSemanticProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    FieldSemanticProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=max(-1.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]
            rows = (
                await session.scalars(
                    statement.order_by(
                        FieldSemanticProfileRow.updated_at.desc(),
                        FieldSemanticProfileRow.profile_id,
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in vector))
        matches: list[FieldSemanticProfileMatch] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != dimensions:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(left * right for left, right in zip(vector, stored, strict=True))
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(-1.0, min(1.0, similarity))
            if similarity >= min_similarity:
                matches.append(
                    FieldSemanticProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=similarity,
                    )
                )
        return sorted(
            matches,
            key=lambda item: (-item.vector_similarity, item.profile.profile_id),
        )[: min(limit, 100)]

    async def find_active_field_semantic_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str,
        limit: int,
    ) -> list[FieldSemanticProfileMatch]:
        return await self.find_field_semantic_profiles(
            tenant_id,
            embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            statuses=(FieldSemanticProfileStatus.ACTIVE,),
            contract_revision=contract_revision,
            limit=limit,
        )

    async def record_field_semantic_execution_observation(
        self, record: FieldSemanticExecutionObservation
    ) -> FieldSemanticObservationRecord:
        persisted = FieldSemanticObservationRecord(
            tenant_id=record.tenant_id,
            profile_id=record.profile_id,
            idempotency_key=(
                f"field-semantic:{record.profile_id}:{record.task_reference_hash}"
            ),
            exact_fingerprint=record.exact_fingerprint,
            task_reference_hash=record.task_reference_hash,
            outcome=FieldSemanticObservationOutcome(record.outcome),
            validation_passed=record.validation_passed,
            reviewed_by=record.reviewed_by,
            review_note_sha256=record.review_note_sha256,
            latency_ms=record.latency_ms,
            error_code=record.error_code,
        )
        return await self.record_field_semantic_observation(persisted)

    async def record_field_semantic_observation(
        self, record: FieldSemanticObservationRecord
    ) -> FieldSemanticObservationRecord:
        """Append one idempotent reviewed sample and update counters atomically."""

        async def operation(session: AsyncSession) -> FieldSemanticObservationRecord:
            await self._lock_field_semantic_tenant(session, record.tenant_id)
            profile = await self._require_field_semantic_profile(
                session, record.tenant_id, record.profile_id, for_update=True
            )
            existing = await session.scalar(
                select(FieldSemanticObservationRow).where(
                    FieldSemanticObservationRow.tenant_id == record.tenant_id,
                    FieldSemanticObservationRow.idempotency_key
                    == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError(
                    "observation fingerprint does not match field semantic profile"
                )

            row = FieldSemanticObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                task_reference_hash=record.task_reference_hash,
                outcome=record.outcome.value,
                validation_passed=record.validation_passed,
                reviewed_by=record.reviewed_by,
                review_note_sha256=record.review_note_sha256,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at, record.observed_at
            )
            if record.outcome is FieldSemanticObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at, record.observed_at
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at, record.observed_at
                )
                if profile.status == FieldSemanticProfileStatus.ACTIVE.value:
                    profile.status = FieldSemanticProfileStatus.DEPRECATED.value
                    await record_route_lifecycle_event(
                        session,
                        tenant_id=record.tenant_id,
                        route_kind="field_semantic",
                        profile_id=profile.profile_id,
                        event_type="auto_deprecated",
                        actor_id=record.reviewed_by or "field-semantic-observation",
                        reason=(
                            f"failed observation {record.observation_id}: "
                            f"{record.error_code or 'unspecified'}"
                        ),
                        observation_count=profile.observation_count,
                        occurred_at=record.observed_at,
                    )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def activate_field_semantic_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str,
        review_note: str,
        expected_observation_count: int,
        allowed_canonical_field_ids: Collection[str],
        approved_at: datetime | None = None,
    ) -> FieldSemanticProfileRecord:
        """Activate only a registry-backed mapping with three clean reviews."""

        approver = approved_by.strip()
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not approver:
            raise ValueError("approved_by is required")
        if not reviewer:
            raise ValueError("reviewed_by is required")
        if not note:
            raise ValueError("review_note is required")
        if expected_observation_count < _MIN_ACTIVATION_DISTINCT_TASKS:
            raise ValueError("at least three reviewed validation samples are required")
        allowed = _canonical_ids(allowed_canonical_field_ids)
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> FieldSemanticProfileRecord:
            await self._lock_field_semantic_tenant(session, tenant_id)
            row = await self._require_field_semantic_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.canonical_field_id not in allowed:
                raise ValueError(
                    "field mapping canonical ID is absent from the code-owned registry"
                )
            if row.observation_count != expected_observation_count:
                raise IdempotencyConflictError(
                    f"field-semantic-approval-observations:{tenant_id}:{profile_id}"
                )
            if row.failure_count != 0 or row.success_count != row.observation_count:
                raise IdempotencyConflictError(
                    f"field-semantic-approval-failures:{tenant_id}:{profile_id}"
                )

            observations = (
                await session.scalars(
                    select(FieldSemanticObservationRow).where(
                        FieldSemanticObservationRow.tenant_id == tenant_id,
                        FieldSemanticObservationRow.profile_id == profile_id,
                    )
                )
            ).all()
            if any(
                observation.outcome == FieldSemanticObservationOutcome.FAILURE.value
                for observation in observations
            ):
                raise IdempotencyConflictError(
                    f"field-semantic-approval-failures:{tenant_id}:{profile_id}"
                )
            task_hashes = {
                observation.task_reference_hash
                for observation in observations
                if observation.outcome == FieldSemanticObservationOutcome.SUCCESS.value
                and observation.validation_passed
                and observation.reviewed_by.strip()
                and len(observation.review_note_sha256) == 64
            }
            if len(task_hashes) < _MIN_ACTIVATION_DISTINCT_TASKS:
                raise IdempotencyConflictError(
                    f"field-semantic-approval-distinct-tasks:{tenant_id}:{profile_id}"
                )
            require_separated_approval(
                approved_by=approver,
                reviewed_by=reviewer,
                sample_reviewers=(
                    observation.reviewed_by for observation in observations
                ),
            )

            if row.status == FieldSemanticProfileStatus.ACTIVE.value:
                if not (
                    row.approved_by == approver
                    and row.reviewed_by == reviewer
                    and row.review_note == note
                    and (
                        approved_at is None
                        or _aware(row.approved_at) == _aware(approved_at)
                    )
                ):
                    raise IdempotencyConflictError(
                        f"field-semantic-activation:{tenant_id}:{profile_id}"
                    )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="field_semantic",
                    profile_id=profile_id,
                    event_type="activated",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=note,
                    observation_count=expected_observation_count,
                    occurred_at=_aware(row.approved_at) or now,
                )
                return _profile_record(row)
            if row.status != FieldSemanticProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate field mappings may be activated")

            statement = select(FieldSemanticProfileRow).where(
                FieldSemanticProfileRow.tenant_id == tenant_id,
                FieldSemanticProfileRow.profile_id != profile_id,
                FieldSemanticProfileRow.status
                == FieldSemanticProfileStatus.ACTIVE.value,
                or_(
                    FieldSemanticProfileRow.profile_key == row.profile_key,
                    FieldSemanticProfileRow.exact_fingerprint == row.exact_fingerprint,
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = FieldSemanticProfileStatus.DEPRECATED.value
                previous.updated_at = now
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="field_semantic",
                    profile_id=previous.profile_id,
                    event_type="superseded",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=f"superseded by profile {profile_id}",
                    observation_count=previous.observation_count,
                    occurred_at=now,
                )

            row.status = FieldSemanticProfileStatus.ACTIVE.value
            row.reviewed_by = reviewer
            row.reviewed_at = row.reviewed_at or now
            row.review_note = note
            row.approved_by = approver
            row.approved_at = now
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="field_semantic",
                profile_id=profile_id,
                event_type="activated",
                actor_id=approver,
                counterparty_id=reviewer,
                reason=note,
                observation_count=expected_observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def reject_field_semantic_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> FieldSemanticProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> FieldSemanticProfileRecord:
            await self._lock_field_semantic_tenant(session, tenant_id)
            row = await self._require_field_semantic_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == FieldSemanticProfileStatus.REJECTED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="field_semantic",
                    profile_id=profile_id,
                    event_type="rejected",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=_aware(row.reviewed_at) or now,
                )
                return _profile_record(row)
            if row.status != FieldSemanticProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate field mappings may be rejected")
            row.status = FieldSemanticProfileStatus.REJECTED.value
            row.reviewed_by = reviewer
            row.reviewed_at = now
            row.review_note = note
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="field_semantic",
                profile_id=profile_id,
                event_type="rejected",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def deprecate_field_semantic_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> FieldSemanticProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> FieldSemanticProfileRecord:
            await self._lock_field_semantic_tenant(session, tenant_id)
            row = await self._require_field_semantic_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == FieldSemanticProfileStatus.DEPRECATED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="field_semantic",
                    profile_id=profile_id,
                    event_type="deprecated",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=now,
                )
                return _profile_record(row)
            if row.status == FieldSemanticProfileStatus.REJECTED.value:
                raise ValueError("a rejected field mapping cannot be deprecated")
            row.status = FieldSemanticProfileStatus.DEPRECATED.value
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="field_semantic",
                profile_id=profile_id,
                event_type="deprecated",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def list_field_semantic_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        outcome: FieldSemanticObservationOutcome | str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[FieldSemanticObservationRecord]:
        if limit < 1:
            return []
        if offset < 0:
            raise ValueError("field semantic observation offset must not be negative")
        statement = select(FieldSemanticObservationRow).where(
            FieldSemanticObservationRow.tenant_id == tenant_id
        )
        if profile_id is not None:
            statement = statement.where(
                FieldSemanticObservationRow.profile_id == profile_id
            )
        if outcome is not None:
            statement = statement.where(
                FieldSemanticObservationRow.outcome
                == FieldSemanticObservationOutcome(_enum(outcome)).value
            )
        statement = (
            statement.order_by(
                FieldSemanticObservationRow.observed_at.desc(),
                FieldSemanticObservationRow.observation_id,
            )
            .offset(offset)
            .limit(min(limit, 1000))
        )
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_observation_record(row) for row in rows]


class FieldSemanticRepository(
    KnowledgeFieldSemanticRouteMixin,
    KnowledgeRepositoryBase,
):
    """Standalone adapter used until the main KnowledgeStore mixin is wired."""


# Match KnowledgeStore's audited PostgreSQL RLS context behavior.  Parent
# integration can instead add ``KnowledgeFieldSemanticRouteMixin`` to that
# facade; no second connection or schema owner is required.
for _method_name in dir(FieldSemanticRepository):
    _method = getattr(FieldSemanticRepository, _method_name)
    if (
        not _method_name.startswith("_")
        and pyinspect.iscoroutinefunction(_method)
        and {"tenant_id", "record"}.intersection(
            pyinspect.signature(_method).parameters
        )
    ):
        setattr(FieldSemanticRepository, _method_name, _tenant_scoped_call(_method))


__all__ = ["FieldSemanticRepository", "KnowledgeFieldSemanticRouteMixin"]
