"""Audited graph labels and logical relationship vocabulary for M1."""

from __future__ import annotations

import unicodedata

CANONICAL_ENTITY_GRAPH_LABELS: dict[str, str] = {
    "document": "Document",
    "order": "Order",
    "enterprise": "Organization",
    "product": "Product",
    "material": "Material",
    "equipment": "Equipment",
    "mold": "Mold",
}

# A document type is stored as a source fact and can originate from older
# imports, a guarded model proposal, or a future external adapter.  Cypher
# labels, however, must remain a finite reviewed vocabulary.  The projection
# therefore uses this alias table instead of converting arbitrary type strings
# into labels.  Unknown types retain their raw ``document_type`` property on
# the ``Document`` node and do not get a second label.
CANONICAL_DOCUMENT_GRAPH_LABELS: dict[str, str] = {
    "archive": "Archive",
    "commercial_document": "CommercialDocument",
    "quotation": "CommercialDocument",
    "equipment": "Equipment",
    "inventory": "Inventory",
    "inventory_report": "Inventory",
    "mold": "Mold",
    "order": "Order",
    "po": "Order",
    "procurement": "Procurement",
    "procurement_process": "Procurement",
    "purchase_order": "Order",
    "purchase_contract": "Order",
    "supplier_purchase_order": "Order",
    "customer_purchase_order": "Order",
    "stocking_order": "Order",
    "sample_request": "Order",
    "sales_order": "Order",
    "technical_document": "TechnicalDocument",
    "drawing": "TechnicalDocument",
    "bom": "TechnicalDocument",
    "sop": "TechnicalDocument",
    "approval_drawing": "TechnicalDocument",
    "engineering_drawing": "TechnicalDocument",
    "product_specification": "TechnicalDocument",
    "process_document": "TechnicalDocument",
    "service_policy": "TechnicalDocument",
    "product_photo": "TechnicalDocument",
    "presentation": "TechnicalDocument",
    "web_document": "TechnicalDocument",
    "image_document": "TechnicalDocument",
}


def canonical_document_graph_label(document_type: object) -> str | None:
    """Return the reviewed graph label for a source document type, if any."""

    normalized = unicodedata.normalize("NFKC", str(document_type or "")).strip().casefold()
    return CANONICAL_DOCUMENT_GRAPH_LABELS.get(normalized)

# Cypher relationship identifiers are generated only from this finite set.
# New business semantics must be reviewed and added here before projection.
LOGICAL_GRAPH_RELATIONS = frozenset(
    {
        "DESCRIBES",
        "DESCRIBES_PRODUCT",
        "REPRESENTS_ORDER",
        "HAS_ISSUER",
        "HAS_BUYER",
        "HAS_SELLER",
        "HAS_SUPPLIER",
        "CONTAINS_PRODUCT",
        "CONTAINS_MATERIAL",
        "LISTS_MATERIAL",
        "LISTS_EQUIPMENT",
        "LISTS_MOLD",
        "MADE_OF",
    }
)


__all__ = [
    "CANONICAL_DOCUMENT_GRAPH_LABELS",
    "CANONICAL_ENTITY_GRAPH_LABELS",
    "LOGICAL_GRAPH_RELATIONS",
    "canonical_document_graph_label",
]
