"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

from typing import Any, TypeVar

from sqlalchemy import (
    func,
    select,
    tuple_,
)
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    AliasSourceBindingRow,
    CanonicalEntityRow,
    ConflictRow,
    DocumentVersionRow,
    EntitySourceBindingRow,
    FieldClaimRow,
    GraphProjectionSnapshotRow,
    IdentitySourceBindingRow,
    KnowledgeChunkRow,
    KnowledgeDocumentRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    RelationshipClaimRow,
    ReviewTaskRow,
    SourceAssetRow,
    SourceOccurrenceRow,
    TaskVersionBindingRow,
)
from .models import (
    GraphProjection,
)
from .persistence_helpers import (
    _review_task_row,
)
from .schema import (
    ClaimStatus,
    ConflictStatus,
    LifecycleStatus,
    OutboxStatus,
    ProjectionEventRecord,
    ReviewTaskRecord,
    ReviewTaskStatus,
    utc_now,
)

T = TypeVar("T")


class KnowledgeLifecycleMixin:
    async def tombstone_task(
        self,
        tenant_id: str,
        task_id: str,
        *,
        include_lightrag: bool = False,
    ) -> dict[str, Any]:
        """Retire every governed artifact derived from one legacy M1 task.

        The source occurrence and immutable audit rows are retained, while all
        customer-visible projections become non-searchable in the same SQL
        transaction.  Active Graph deletion is emitted through the durable
        outbox so a Neo4j outage cannot leave an unaudited ghost projection.
        """

        async def operation(session: AsyncSession) -> dict[str, Any]:
            # Persist and lock the lifecycle marker before scanning any source
            # rows. Existing fenced writers finish before this transaction;
            # every later writer observes the tombstone or a stale epoch.
            await self._tombstone_task_fence_in_session(
                session,
                tenant_id=tenant_id,
                task_id=task_id,
            )
            now = utc_now()
            occurrences = (
                await session.scalars(
                    select(SourceOccurrenceRow).where(
                        SourceOccurrenceRow.tenant_id == tenant_id,
                        SourceOccurrenceRow.task_id == task_id,
                    )
                )
            ).all()
            if not occurrences:
                # Compatibility fallback for rows created before task_id was
                # promoted out of metadata.  This scans only unmigrated rows.
                legacy_occurrences = (
                    await session.scalars(
                        select(SourceOccurrenceRow).where(
                            SourceOccurrenceRow.tenant_id == tenant_id,
                            SourceOccurrenceRow.task_id == "",
                        )
                    )
                ).all()
                occurrences = [
                    row
                    for row in legacy_occurrences
                    if str((row.metadata_json or {}).get("task_id") or "") == task_id
                ]
            occurrence_ids = {row.occurrence_id for row in occurrences}
            occurrence_changed = any(
                not bool((row.metadata_json or {}).get("tombstoned"))
                for row in occurrences
            )
            for row in occurrences:
                metadata = dict(row.metadata_json or {})
                metadata.update(
                    {
                        "tombstoned": True,
                        "tombstoned_at": now.isoformat(),
                    }
                )
                row.metadata_json = metadata

            task_bindings = (
                await session.scalars(
                    select(TaskVersionBindingRow).where(
                        TaskVersionBindingRow.tenant_id == tenant_id,
                        TaskVersionBindingRow.task_id == task_id,
                    )
                )
            ).all()
            if not occurrences and not task_bindings:
                return {
                    "tenant_id": tenant_id,
                    "task_id": task_id,
                    "occurrence_count": 0,
                    "version_count": 0,
                    "source_record_ids": [],
                    "graph_events": [],
                    "graph_replacements": [],
                    "shadow_events": [],
                    "changed": False,
                }
            binding_changed = False
            if task_bindings:
                candidate_version_ids = {row.version_id for row in task_bindings}
                candidate_documents = (
                    await session.scalars(
                        select(DocumentVersionRow).where(
                            DocumentVersionRow.tenant_id == tenant_id,
                            DocumentVersionRow.version_id.in_(candidate_version_ids),
                        )
                    )
                ).all()
                for document_id in sorted(
                    {row.document_id for row in candidate_documents}
                ):
                    await self._lock_graph_generation_row(
                        session,
                        tenant_id=tenant_id,
                        source_record_id=document_id,
                    )
                candidates = (
                    await session.scalars(
                        select(DocumentVersionRow)
                        .where(
                            DocumentVersionRow.tenant_id == tenant_id,
                            DocumentVersionRow.version_id.in_(candidate_version_ids),
                        )
                        .order_by(DocumentVersionRow.version_id)
                        .with_for_update()
                        .execution_options(populate_existing=True)
                    )
                ).all()
                all_bindings = (
                    await session.scalars(
                        select(TaskVersionBindingRow)
                        .where(
                            TaskVersionBindingRow.tenant_id == tenant_id,
                            TaskVersionBindingRow.version_id.in_(candidate_version_ids),
                        )
                        .order_by(TaskVersionBindingRow.binding_id)
                        .with_for_update()
                        .execution_options(populate_existing=True)
                    )
                ).all()
                task_bindings = [
                    row for row in all_bindings if row.task_id == task_id
                ]
                for binding in task_bindings:
                    if binding.status == "active":
                        binding.status = "tombstoned"
                        binding.tombstoned_at = now
                        binding_changed = True
                still_referenced = {
                    row.version_id for row in all_bindings if row.status == "active"
                }
                versions = [
                    row for row in candidates if row.version_id not in still_referenced
                ]
            else:
                # Compatibility fallback for rows ingested before the binding
                # table existed. New ingests always take the explicit path.
                legacy_versions = (
                    await session.scalars(
                        select(DocumentVersionRow).where(
                            DocumentVersionRow.tenant_id == tenant_id,
                            DocumentVersionRow.source_occurrence_id.in_(occurrence_ids),
                        )
                    )
                ).all()
                for document_id in sorted(
                    {row.document_id for row in legacy_versions}
                ):
                    await self._lock_graph_generation_row(
                        session,
                        tenant_id=tenant_id,
                        source_record_id=document_id,
                    )
                legacy_version_ids = {row.version_id for row in legacy_versions}
                versions = (
                    (
                        await session.scalars(
                            select(DocumentVersionRow)
                            .where(
                                DocumentVersionRow.tenant_id == tenant_id,
                                DocumentVersionRow.version_id.in_(
                                    legacy_version_ids
                                ),
                            )
                            .order_by(DocumentVersionRow.version_id)
                            .with_for_update()
                            .execution_options(populate_existing=True)
                        )
                    ).all()
                    if legacy_version_ids
                    else []
                )
            version_ids = {row.version_id for row in versions}
            version_keys = {
                (row.document_id, str(row.version_number)) for row in versions
            }
            document_ids = {row.document_id for row in versions}
            for row in versions:
                row.lifecycle_status = LifecycleStatus.DEPRECATED.value
                row.recorded_to = row.recorded_to or now

            if version_ids:
                entity_bindings = (
                    await session.scalars(
                        select(EntitySourceBindingRow).where(
                            EntitySourceBindingRow.tenant_id == tenant_id,
                            EntitySourceBindingRow.version_id.in_(version_ids),
                            EntitySourceBindingRow.status == "active",
                        )
                    )
                ).all()
                for binding in entity_bindings:
                    binding.status = "tombstoned"
                    binding.tombstoned_at = now

                affected_entity_ids = {row.entity_id for row in entity_bindings}
                identity_bindings = (
                    await session.scalars(
                        select(IdentitySourceBindingRow).where(
                            IdentitySourceBindingRow.tenant_id == tenant_id,
                            IdentitySourceBindingRow.version_id.in_(version_ids),
                            IdentitySourceBindingRow.status == "active",
                        )
                    )
                ).all()
                for binding in identity_bindings:
                    binding.status = "tombstoned"
                    binding.tombstoned_at = now

                alias_bindings = (
                    await session.scalars(
                        select(AliasSourceBindingRow).where(
                            AliasSourceBindingRow.tenant_id == tenant_id,
                            AliasSourceBindingRow.version_id.in_(version_ids),
                            AliasSourceBindingRow.status == "active",
                        )
                    )
                ).all()
                for binding in alias_bindings:
                    binding.status = "tombstoned"
                    binding.tombstoned_at = now

                # Flush source tombstones before recomputing.  Every surviving
                # canonical value/status is selected only from still-live
                # assertions, so deleting the first writer cannot leak its
                # name, attributes, alias, or external identity.
                await session.flush()
                for entity_id in sorted(affected_entity_ids):
                    await self._recompute_entity_from_bindings(
                        session,
                        tenant_id=tenant_id,
                        entity_id=entity_id,
                        reason=f"source task {task_id} tombstoned",
                    )
                for identity_id in sorted(
                    {row.identity_id for row in identity_bindings}
                ):
                    await self._recompute_identity_from_bindings(
                        session,
                        tenant_id=tenant_id,
                        identity_id=identity_id,
                    )
                for alias_id in sorted({row.alias_id for row in alias_bindings}):
                    await self._recompute_alias_from_bindings(
                        session,
                        tenant_id=tenant_id,
                        alias_id=alias_id,
                    )

                if affected_entity_ids:
                    deprecated_entities = (
                        await session.scalars(
                            select(CanonicalEntityRow.entity_id).where(
                                CanonicalEntityRow.tenant_id == tenant_id,
                                CanonicalEntityRow.entity_id.in_(affected_entity_ids),
                                CanonicalEntityRow.lifecycle_status
                                == LifecycleStatus.DEPRECATED.value,
                            )
                        )
                    ).all()
                    deprecated_entity_ids = set(deprecated_entities)
                    if deprecated_entity_ids:
                        entity_reviews = (
                            await session.scalars(
                                select(ReviewTaskRow).where(
                                    ReviewTaskRow.tenant_id == tenant_id,
                                    ReviewTaskRow.target_type == "canonical_entity",
                                    ReviewTaskRow.target_id.in_(deprecated_entity_ids),
                                    ReviewTaskRow.status.in_(
                                        [
                                            ReviewTaskStatus.OPEN.value,
                                            ReviewTaskStatus.IN_REVIEW.value,
                                        ]
                                    ),
                                )
                            )
                        ).all()
                        for review in entity_reviews:
                            review.status = ReviewTaskStatus.CANCELLED.value
                            review.resolved_at = now
                            review.updated_at = now

            if version_ids:
                claims = (
                    await session.scalars(
                        select(FieldClaimRow).where(
                            FieldClaimRow.tenant_id == tenant_id,
                            FieldClaimRow.subject_type == "document_version",
                            FieldClaimRow.subject_id.in_(version_ids),
                            FieldClaimRow.status.in_(
                                [
                                    ClaimStatus.CANDIDATE.value,
                                    ClaimStatus.UNDER_REVIEW.value,
                                    ClaimStatus.ACCEPTED.value,
                                ]
                            ),
                        )
                    )
                ).all()
                for claim in claims:
                    claim.status = ClaimStatus.SUPERSEDED.value
                    claim.recorded_to = claim.recorded_to or now

            relationships = []
            if version_keys:
                relationships = (
                    await session.scalars(
                        select(RelationshipClaimRow).where(
                            RelationshipClaimRow.tenant_id == tenant_id,
                            tuple_(
                                RelationshipClaimRow.source_record_id,
                                RelationshipClaimRow.source_version,
                            ).in_(sorted(version_keys)),
                        )
                    )
                ).all()
            relationship_event_ids = {
                relationship.relationship_id for relationship in relationships
            }
            retired_relationship_ids: set[str] = set()
            for relationship in relationships:
                if relationship.status not in {
                    ClaimStatus.CANDIDATE.value,
                    ClaimStatus.UNDER_REVIEW.value,
                    ClaimStatus.ACCEPTED.value,
                }:
                    continue
                relationship.status = ClaimStatus.SUPERSEDED.value
                relationship.recorded_to = relationship.recorded_to or now
                retired_relationship_ids.add(relationship.relationship_id)

            if relationship_event_ids:
                relationship_events = (
                    await session.scalars(
                        select(ProjectionOutboxRow).where(
                            ProjectionOutboxRow.tenant_id == tenant_id,
                            ProjectionOutboxRow.aggregate_type == "relationship_claim",
                            ProjectionOutboxRow.aggregate_id.in_(
                                relationship_event_ids
                            ),
                            ProjectionOutboxRow.status.in_(
                                [
                                    OutboxStatus.PENDING.value,
                                    OutboxStatus.PROCESSING.value,
                                ]
                            ),
                        )
                    )
                ).all()
                for event_row in relationship_events:
                    event_row.status = OutboxStatus.FAILED.value
                    event_row.leased_until = None
                    event_row.last_error = f"source task tombstoned: {task_id}"

            review_targets = version_ids | retired_relationship_ids
            if review_targets:
                reviews = (
                    await session.scalars(
                        select(ReviewTaskRow).where(
                            ReviewTaskRow.tenant_id == tenant_id,
                            ReviewTaskRow.target_id.in_(review_targets),
                            ReviewTaskRow.status.in_(
                                [
                                    ReviewTaskStatus.OPEN.value,
                                    ReviewTaskStatus.IN_REVIEW.value,
                                ]
                            ),
                        )
                    )
                ).all()
                for review in reviews:
                    review.status = ReviewTaskStatus.CANCELLED.value
                    review.resolved_at = now
                    review.updated_at = now

                conflicts = (
                    await session.scalars(
                        select(ConflictRow).where(
                            ConflictRow.tenant_id == tenant_id,
                            ConflictRow.subject_id.in_(review_targets),
                            ConflictRow.status == ConflictStatus.OPEN.value,
                        )
                    )
                ).all()
                for conflict in conflicts:
                    conflict.status = ConflictStatus.DISMISSED.value
                    conflict.resolved_at = now

            graph_delete_sources: set[str] = set()
            if version_keys:
                for row_type in (KnowledgeChunkRow, KnowledgeIndexRow):
                    rows = (
                        await session.scalars(
                            select(row_type).where(
                                row_type.tenant_id == tenant_id,
                                tuple_(
                                    row_type.source_record_id,
                                    row_type.version,
                                ).in_(sorted(version_keys)),
                            )
                        )
                    ).all()
                    for row in rows:
                        row.status = "deprecated"

            snapshots = []
            if version_keys:
                snapshots = (
                    await session.scalars(
                        select(GraphProjectionSnapshotRow).where(
                            GraphProjectionSnapshotRow.tenant_id == tenant_id,
                            tuple_(
                                GraphProjectionSnapshotRow.source_record_id,
                                GraphProjectionSnapshotRow.version,
                            ).in_(sorted(version_keys)),
                        )
                    )
                ).all()
            for snapshot in snapshots:
                if snapshot.status == "active":
                    graph_delete_sources.add(snapshot.source_record_id)
                historical_graph = GraphProjection.model_validate(
                    snapshot.projection_json
                )
                snapshot.projection_json = historical_graph.model_copy(
                    update={
                        "nodes": [
                            node.model_copy(update={"status": "deprecated"})
                            for node in historical_graph.nodes
                        ],
                        "edges": [
                            edge.model_copy(update={"status": "deprecated"})
                            for edge in historical_graph.edges
                        ],
                    }
                ).model_dump(mode="json")
                snapshot.status = "deprecated"
                snapshot.updated_at = now

            # If another non-deleted task still references an older version,
            # restore the latest such projection. Deleting a correction must
            # not make the still-existing original task disappear from Wiki
            # and Graph.
            graph_replacements: list[dict[str, str]] = []
            for document_id in sorted(document_ids):
                document_versions = (
                    await session.scalars(
                        select(DocumentVersionRow).where(
                            DocumentVersionRow.tenant_id == tenant_id,
                            DocumentVersionRow.document_id == document_id,
                        )
                    )
                ).all()
                candidate_ids = {
                    row.version_id
                    for row in document_versions
                    if row.version_id not in version_ids
                    and row.lifecycle_status != LifecycleStatus.REJECTED.value
                }
                if not candidate_ids:
                    continue
                live_bindings = (
                    await session.scalars(
                        select(TaskVersionBindingRow).where(
                            TaskVersionBindingRow.tenant_id == tenant_id,
                            TaskVersionBindingRow.version_id.in_(candidate_ids),
                            TaskVersionBindingRow.status == "active",
                        )
                    )
                ).all()
                referenced_ids = {row.version_id for row in live_bindings}
                fallback_candidates = [
                    row for row in document_versions if row.version_id in referenced_ids
                ]
                if not fallback_candidates:
                    continue
                fallback = max(
                    fallback_candidates,
                    key=lambda row: row.version_number,
                )

                fallback_claims = (
                    await session.scalars(
                        select(FieldClaimRow).where(
                            FieldClaimRow.tenant_id == tenant_id,
                            FieldClaimRow.subject_type == "document_version",
                            FieldClaimRow.subject_id == fallback.version_id,
                            FieldClaimRow.status == ClaimStatus.SUPERSEDED.value,
                        )
                    )
                ).all()
                for claim in fallback_claims:
                    claim.status = (
                        ClaimStatus.UNDER_REVIEW.value
                        if claim.extraction_method == "inferred"
                        else ClaimStatus.ACCEPTED.value
                        if claim.confidence >= 0.95
                        else ClaimStatus.CANDIDATE.value
                    )
                    claim.recorded_to = None

                fallback_relationships = (
                    await session.scalars(
                        select(RelationshipClaimRow).where(
                            RelationshipClaimRow.tenant_id == tenant_id,
                            RelationshipClaimRow.source_record_id == document_id,
                            RelationshipClaimRow.source_version
                            == str(fallback.version_number),
                            RelationshipClaimRow.status == ClaimStatus.SUPERSEDED.value,
                        )
                    )
                ).all()
                restored_relationship_ids: set[str] = set()
                for relationship in fallback_relationships:
                    properties = dict(relationship.properties or {})
                    restored_status = str(properties.pop("_superseded_status", ""))
                    if restored_status not in {
                        ClaimStatus.CANDIDATE.value,
                        ClaimStatus.UNDER_REVIEW.value,
                        ClaimStatus.ACCEPTED.value,
                    }:
                        continue
                    relationship.properties = properties
                    relationship.status = restored_status
                    relationship.recorded_to = None
                    if restored_status in {
                        ClaimStatus.CANDIDATE.value,
                        ClaimStatus.UNDER_REVIEW.value,
                    }:
                        restored_relationship_ids.add(relationship.relationship_id)

                for relationship_id in restored_relationship_ids:
                    review_key = f"relationship:{relationship_id}:reactivated:{task_id}"
                    review = await session.scalar(
                        select(ReviewTaskRow).where(
                            ReviewTaskRow.tenant_id == tenant_id,
                            ReviewTaskRow.idempotency_key == review_key,
                        )
                    )
                    if review is None:
                        session.add(
                            _review_task_row(
                                ReviewTaskRecord(
                                    tenant_id=tenant_id,
                                    idempotency_key=review_key,
                                    target_type="relationship_claim",
                                    target_id=relationship_id,
                                    reason_codes=["relationship_reactivated"],
                                    summary="Review reactivated logical relationship",
                                )
                            )
                        )

                (
                    search_event_id,
                    graph_event_id,
                ) = await self._apply_document_projection_review_status(
                    session,
                    fallback,
                    status="active",
                    event_discriminator=f"fallback:{task_id}",
                )
                graph_delete_sources.discard(document_id)
                if graph_event_id:
                    graph_replacements.append(
                        {
                            "source_record_id": document_id,
                            "version": str(fallback.version_number),
                            "graph_event_id": graph_event_id,
                            "search_event_id": search_event_id or "",
                        }
                    )

            if version_ids:
                pending_events = (
                    await session.scalars(
                        select(ProjectionOutboxRow).where(
                            ProjectionOutboxRow.tenant_id == tenant_id,
                            ProjectionOutboxRow.aggregate_type == "document_projection",
                            ProjectionOutboxRow.aggregate_id.in_(document_ids),
                            ProjectionOutboxRow.status.in_(
                                [
                                    OutboxStatus.PENDING.value,
                                    OutboxStatus.PROCESSING.value,
                                ]
                            ),
                        )
                    )
                ).all()
                for event_row in pending_events:
                    payload = event_row.payload or {}
                    event_key = (
                        str(payload.get("source_record_id") or ""),
                        str(payload.get("version") or ""),
                    )
                    if event_key not in version_keys:
                        continue
                    if event_row.projection_name == "lightrag_shadow":
                        # Preserve the source FIFO. A processing event may
                        # already have committed externally and keeps its
                        # bounded lease; a backed-off pending event is made
                        # immediately eligible so tombstone converges within
                        # the same 120-second upper bound.
                        if event_row.status == OutboxStatus.PENDING.value:
                            event_row.available_at = now
                        continue
                    event_row.status = OutboxStatus.FAILED.value
                    event_row.leased_until = None
                    event_row.last_error = f"source task tombstoned: {task_id}"

            for document_id in document_ids:
                remaining = await session.scalar(
                    select(func.count(DocumentVersionRow.version_id)).where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.document_id == document_id,
                        DocumentVersionRow.lifecycle_status.notin_(
                            [
                                LifecycleStatus.DEPRECATED.value,
                                LifecycleStatus.REJECTED.value,
                            ]
                        ),
                    )
                )
                if int(remaining or 0) == 0:
                    document = await session.get(KnowledgeDocumentRow, document_id)
                    if document is not None and document.tenant_id == tenant_id:
                        document.lifecycle_status = LifecycleStatus.DEPRECATED.value
                        document.recorded_to = document.recorded_to or now
                        document.updated_at = now

            asset_ids = {row.asset_id for row in occurrences}
            if asset_ids:
                all_occurrences = (
                    await session.scalars(
                        select(SourceOccurrenceRow).where(
                            SourceOccurrenceRow.tenant_id == tenant_id,
                            SourceOccurrenceRow.asset_id.in_(asset_ids),
                        )
                    )
                ).all()
                for asset_id in asset_ids:
                    live_occurrence = any(
                        row.asset_id == asset_id
                        and not bool((row.metadata_json or {}).get("tombstoned"))
                        for row in all_occurrences
                    )
                    if not live_occurrence:
                        asset = await session.get(SourceAssetRow, asset_id)
                        if asset is not None and asset.tenant_id == tenant_id:
                            asset.lifecycle_status = LifecycleStatus.DEPRECATED.value

            graph_events: list[dict[str, str]] = []
            for source_record_id in sorted(graph_delete_sources):
                generation = await self._next_graph_generation(
                    session,
                    tenant_id=tenant_id,
                    source_record_id=source_record_id,
                )
                event = await self._enqueue_in_session(
                    session,
                    ProjectionEventRecord(
                        tenant_id=tenant_id,
                        projection_name="graph",
                        idempotency_key=f"task-tombstone:{task_id}:{source_record_id}",
                        aggregate_type="document_projection",
                        aggregate_id=source_record_id,
                        event_type="graph.projection.deleted",
                        payload={
                            "action": "delete",
                            "task_id": task_id,
                            "source_record_id": source_record_id,
                            "generation": generation,
                        },
                    ),
                )
                graph_events.append(
                    {
                        "source_record_id": source_record_id,
                        "event_id": event.event_id,
                        "generation": str(generation),
                    }
                )

            shadow_events: list[dict[str, str]] = []
            if include_lightrag:
                for item in graph_events:
                    source_record_id = item["source_record_id"]
                    event = await self._enqueue_in_session(
                        session,
                        ProjectionEventRecord(
                            tenant_id=tenant_id,
                            projection_name="lightrag_shadow",
                            idempotency_key=(
                                "lightrag-shadow:delete:"
                                f"{source_record_id}:tombstone:{task_id}"
                            ),
                            aggregate_type="document_projection",
                            aggregate_id=source_record_id,
                            event_type="lightrag.shadow.delete",
                            payload={
                                "action": "delete",
                                "reason": "tombstone",
                                "source_record_id": source_record_id,
                                "version": "tombstone",
                                "fingerprint": "",
                            },
                        ),
                    )
                    shadow_events.append(
                        {
                            "source_record_id": source_record_id,
                            "version": "tombstone",
                            "action": "delete",
                            "event_id": event.event_id,
                        }
                    )
                for item in graph_replacements:
                    source_record_id = item["source_record_id"]
                    version = item["version"]
                    event = await self._enqueue_in_session(
                        session,
                        ProjectionEventRecord(
                            tenant_id=tenant_id,
                            projection_name="lightrag_shadow",
                            idempotency_key=(
                                "lightrag-shadow:upsert:"
                                f"{source_record_id}:{version}:{task_id}"
                            ),
                            aggregate_type="document_projection",
                            aggregate_id=source_record_id,
                            event_type="lightrag.shadow.upsert",
                            payload={
                                "action": "upsert",
                                "reason": "tombstone_fallback",
                                "source_record_id": source_record_id,
                                "version": version,
                                "fingerprint": "",
                            },
                        ),
                    )
                    shadow_events.append(
                        {
                            "source_record_id": source_record_id,
                            "version": version,
                            "action": "upsert",
                            "event_id": event.event_id,
                        }
                    )

            return {
                "tenant_id": tenant_id,
                "task_id": task_id,
                "occurrence_count": len(occurrences),
                "version_count": len(versions),
                "source_record_ids": sorted(document_ids),
                "graph_events": graph_events,
                "graph_replacements": graph_replacements,
                "shadow_events": shadow_events,
                "changed": occurrence_changed or binding_changed or bool(versions),
            }

        return await self._write(operation)
