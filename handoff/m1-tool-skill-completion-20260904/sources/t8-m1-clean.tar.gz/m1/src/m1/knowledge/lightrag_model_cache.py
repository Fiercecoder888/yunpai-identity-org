"""Offline model-cache verification for the optional LightRAG shadow."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_lightrag_model(root: Path, lock_path: Path) -> dict[str, object]:
    """Verify every fixed-revision bge-m3 artifact before sidecar startup."""

    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    model = lock.get("model") if isinstance(lock, dict) else None
    files = model.get("files") if isinstance(model, dict) else None
    if not isinstance(files, list) or not files:
        raise ValueError("model lock contains no files")
    verified = []
    for item in files:
        if not isinstance(item, dict):
            raise ValueError("invalid model lock file entry")
        relative = Path(str(item.get("path") or ""))
        if not relative.parts or relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"unsafe model path in lock: {relative}")
        target = root / relative
        if not target.is_file():
            raise FileNotFoundError(target)
        expected_size = int(item.get("size") or -1)
        if target.stat().st_size != expected_size:
            raise ValueError(f"model size mismatch: {relative}")
        expected_hash = str(item.get("sha256") or "").casefold()
        if _sha256(target) != expected_hash:
            raise ValueError(f"model SHA-256 mismatch: {relative}")
        verified.append(relative.as_posix())
    return {
        "status": "verified",
        "model": str(model.get("name") or ""),
        "revision": str(model.get("revision") or ""),
        "root": str(root.resolve()),
        "files": verified,
    }


__all__ = ["verify_lightrag_model"]
