"""Fail-isolated REST client for the non-authoritative LightRAG shadow index.

Only governed, selected-index text is sent to LightRAG.  Source filenames,
tenant IDs and M1 record IDs never become LightRAG ``file_source`` values;
the adapter uses deterministic hashes so updates and deletes remain traceable
without exposing a host path or a customer identifier.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from pathlib import PurePath
from typing import Any, Literal

import httpx


class LightRAGShadowError(RuntimeError):
    """A classified LightRAG transport or protocol failure.

    Authentication and request-contract failures cannot heal through repeated
    delivery, so the outbox may terminate them immediately.  Transport,
    throttling, server and asynchronous lifecycle states remain retryable.
    """

    def __init__(
        self,
        code: str,
        *,
        retryable: bool = True,
        category: Literal[
            "retryable", "authentication", "contract", "lifecycle"
        ] = "retryable",
    ) -> None:
        super().__init__(code)
        self.code = code
        self.retryable = retryable
        self.category = category
        self.lifecycle_wait = category == "lifecycle"


@dataclass(frozen=True, slots=True)
class ShadowDocument:
    document_id: str
    file_source: str
    status: str


@dataclass(frozen=True, slots=True)
class ShadowWriteResult:
    action: Literal["inserted", "unchanged", "deleted"]
    file_source: str = ""
    document_ids: tuple[str, ...] = ()


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()


class LightRAGShadowClient:
    """Small async client for the official LightRAG Server REST API."""

    def __init__(
        self,
        base_url: str,
        *,
        api_key: str = "",
        workspace: str = "m1-shadow",
        timeout_seconds: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        normalized_workspace = "".join(
            character if character.isalnum() or character == "_" else "_"
            for character in workspace.strip()
        ).strip("_")
        if not normalized_workspace:
            raise ValueError("LightRAG workspace must not be empty")
        headers = {
            "Accept": "application/json",
            "LIGHTRAG-WORKSPACE": normalized_workspace,
        }
        if api_key.strip():
            headers["X-API-Key"] = api_key.strip()
        self.workspace = normalized_workspace
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/") + "/",
            headers=headers,
            timeout=httpx.Timeout(timeout_seconds),
            transport=transport,
        )
        # LightRAG deletion runs in one global background pipeline. Remember
        # submissions so polling an M1 outbox event does not enqueue the same
        # deletion again while that pipeline is still working.
        self._submitted_deletes: dict[tuple[str, str], frozenset[str]] = {}

    def source_prefix(self, tenant_id: str, source_record_id: str) -> str:
        identity = _sha256(f"{self.workspace}\0{tenant_id}\0{source_record_id}")
        return f"m1shadow-{identity[:40]}-"

    def file_source(
        self,
        tenant_id: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
    ) -> str:
        revision = _sha256(f"{version}\0{fingerprint}")[:20]
        value = f"{self.source_prefix(tenant_id, source_record_id)}{revision}.txt"
        # This is deliberately a basename, not a path.  Keep the invariant
        # explicit because LightRAG historically supported deleting uploads.
        if PurePath(value).name != value or any(
            part in value for part in ("/", "\\", "..")
        ):
            raise ValueError("generated LightRAG file_source is not a safe basename")
        return value

    def _content_identity_marker(
        self,
        tenant_id: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
    ) -> str:
        identity = _sha256(
            "m1-lightrag-shadow-content-v1\0"
            f"{self.workspace}\0{tenant_id}\0{source_record_id}\0{version}\0{fingerprint}"
        )
        return f"<!-- m1-shadow-identity:sha256:{identity} -->"

    async def _request(
        self,
        method: str,
        path: str,
        *,
        payload: Mapping[str, Any] | None = None,
        allow_conflict: bool = False,
    ) -> tuple[int, dict[str, Any]]:
        try:
            request_kwargs = {"json": payload} if payload is not None else {}
            response = await self._client.request(method, path, **request_kwargs)
        except httpx.HTTPError as exc:
            raise LightRAGShadowError(exc.__class__.__name__) from exc
        if allow_conflict and response.status_code == 409:
            return response.status_code, {}
        if response.is_error:
            status = response.status_code
            if status in {401, 403}:
                raise LightRAGShadowError(
                    f"HTTP_{status}", retryable=False, category="authentication"
                )
            if 400 <= status < 500 and status != 429:
                raise LightRAGShadowError(
                    f"HTTP_{status}", retryable=False, category="contract"
                )
            raise LightRAGShadowError(f"HTTP_{status}")
        try:
            body = response.json()
        except ValueError as exc:
            raise LightRAGShadowError(
                "invalid_json_response", retryable=False, category="contract"
            ) from exc
        if not isinstance(body, dict):
            raise LightRAGShadowError(
                "invalid_response_shape", retryable=False, category="contract"
            )
        return response.status_code, body

    async def list_documents(self) -> list[ShadowDocument]:
        """Read all document statuses through the official paginated endpoint."""

        documents: list[ShadowDocument] = []
        page = 1
        while True:
            _status, body = await self._request(
                "POST",
                "documents/paginated",
                payload={
                    "page": page,
                    "page_size": 200,
                    "sort_field": "updated_at",
                    "sort_direction": "desc",
                },
            )
            raw_documents = body.get("documents")
            pagination = body.get("pagination")
            if not isinstance(raw_documents, list) or not isinstance(pagination, dict):
                raise LightRAGShadowError("invalid_paginated_response")
            for item in raw_documents:
                if not isinstance(item, dict):
                    continue
                document_id = str(item.get("id") or "").strip()
                file_source = str(item.get("file_path") or "").strip()
                if document_id and file_source:
                    documents.append(
                        ShadowDocument(
                            document_id=document_id,
                            file_source=PurePath(file_source).name,
                            status=str(item.get("status") or "").casefold(),
                        )
                    )
            if not bool(pagination.get("has_next")):
                return documents
            page += 1
            if page > 10_000:
                raise LightRAGShadowError("pagination_limit_exceeded")

    async def _delete_ids(self, document_ids: Iterable[str]) -> tuple[str, ...]:
        unique = tuple(
            sorted({str(item).strip() for item in document_ids if str(item).strip()})
        )
        if not unique:
            return ()
        _status, body = await self._request(
            "DELETE",
            "documents/delete_document",
            payload={
                "doc_ids": list(unique),
                # The shadow adapter never creates or deletes a physical input
                # file.  This must remain false even on trusted deployments.
                "delete_file": False,
                "delete_llm_cache": False,
            },
        )
        result_status = str(body.get("status") or "").casefold()
        if result_status == "busy":
            raise LightRAGShadowError("delete_busy", category="lifecycle")
        if result_status in {"failure", "failed", "fail"}:
            raise LightRAGShadowError(f"delete_{result_status}")
        return unique

    async def _pipeline_busy(self) -> bool:
        _status, body = await self._request("GET", "documents/pipeline_status")
        busy = body.get("busy")
        if not isinstance(busy, bool):
            raise LightRAGShadowError(
                "invalid_pipeline_status", retryable=False, category="contract"
            )
        return busy

    async def _delete_documents_once(
        self,
        key: tuple[str, str],
        document_ids: Iterable[str],
    ) -> tuple[str, ...]:
        matches = tuple(
            sorted({str(item).strip() for item in document_ids if str(item).strip()})
        )
        if not matches:
            submitted = self._submitted_deletes.pop(key, frozenset())
            return tuple(sorted(submitted))

        submitted = self._submitted_deletes.get(key)
        pipeline_busy = await self._pipeline_busy()
        if submitted is not None and frozenset(matches).issubset(submitted):
            if pipeline_busy:
                raise LightRAGShadowError("delete_in_progress", category="lifecycle")
            # The background job ended but its status rows remain. Treat that
            # as a failed/partial submission and allow one fresh retry.
            self._submitted_deletes.pop(key, None)
        elif pipeline_busy:
            raise LightRAGShadowError("delete_busy", category="lifecycle")

        deleted = await self._delete_ids(matches)
        self._submitted_deletes[key] = frozenset(deleted)
        remaining_ids = {
            item.document_id
            for item in await self.list_documents()
            if item.document_id in set(deleted)
        }
        if remaining_ids:
            raise LightRAGShadowError("delete_in_progress", category="lifecycle")
        self._submitted_deletes.pop(key, None)
        return deleted

    async def delete_source(
        self,
        *,
        tenant_id: str,
        source_record_id: str,
    ) -> ShadowWriteResult:
        prefix = self.source_prefix(tenant_id, source_record_id)
        key = (tenant_id, source_record_id)
        matches = tuple(
            item.document_id
            for item in await self.list_documents()
            if item.file_source.startswith(prefix)
        )
        deleted = await self._delete_documents_once(key, matches)
        return ShadowWriteResult(action="deleted", document_ids=deleted)

    async def upsert_document(
        self,
        *,
        tenant_id: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
        texts: Iterable[str],
    ) -> ShadowWriteResult:
        normalized = [str(text).strip() for text in texts if str(text).strip()]
        if not normalized:
            return await self.delete_source(
                tenant_id=tenant_id,
                source_record_id=source_record_id,
            )
        content = "\n\n---\n\n".join(dict.fromkeys(normalized))
        effective_fingerprint = fingerprint.strip() or _sha256(content)
        indexed_content = "\n\n".join(
            (
                content,
                self._content_identity_marker(
                    tenant_id,
                    source_record_id,
                    version,
                    effective_fingerprint,
                ),
            )
        )
        file_source = self.file_source(
            tenant_id,
            source_record_id,
            version,
            effective_fingerprint,
        )
        prefix = self.source_prefix(tenant_id, source_record_id)
        documents = [
            item
            for item in await self.list_documents()
            if item.file_source.startswith(prefix)
        ]
        exact = [
            item
            for item in documents
            if item.file_source == file_source
            and item.status not in {"failed", "failure"}
        ]
        stale_ids = [
            item.document_id
            for item in documents
            if item.file_source != file_source or item.status in {"failed", "failure"}
        ]
        await self._delete_documents_once((tenant_id, source_record_id), stale_ids)
        if exact:
            return ShadowWriteResult(
                action="unchanged",
                file_source=file_source,
                document_ids=tuple(item.document_id for item in exact),
            )
        status, body = await self._request(
            "POST",
            "documents/text",
            payload={"text": indexed_content, "file_source": file_source},
            allow_conflict=True,
        )
        if status == 409:
            # A prior timed-out attempt may already have enqueued the same
            # stable basename.  Confirm it through the document API before
            # treating the conflict as an idempotent success.
            confirmed = [
                item
                for item in await self.list_documents()
                if item.file_source == file_source
            ]
            if not confirmed:
                raise LightRAGShadowError("insert_conflict_without_document")
            return ShadowWriteResult(
                action="unchanged",
                file_source=file_source,
                document_ids=tuple(item.document_id for item in confirmed),
            )
        insert_status = str(body.get("status") or "").casefold()
        if insert_status == "duplicated":
            confirmed = [
                item
                for item in await self.list_documents()
                if item.file_source == file_source
            ]
            if not confirmed:
                raise LightRAGShadowError("duplicate_without_document")
            return ShadowWriteResult(
                action="unchanged",
                file_source=file_source,
                document_ids=tuple(item.document_id for item in confirmed),
            )
        if insert_status not in {
            "success",
            "partial_success",
        }:
            raise LightRAGShadowError("insert_not_accepted")
        return ShadowWriteResult(action="inserted", file_source=file_source)

    async def query(
        self,
        query: str,
        *,
        mode: Literal["local", "global", "hybrid", "naive", "mix"] = "mix",
        top_k: int = 5,
    ) -> dict[str, Any]:
        _status, body = await self._request(
            "POST",
            "query",
            payload={
                "query": query,
                "mode": mode,
                "top_k": top_k,
                "chunk_top_k": top_k,
                "only_need_context": True,
            },
        )
        return body

    async def health(self) -> dict[str, Any]:
        try:
            _status, body = await self._request("GET", "health")
            return {
                "enabled": True,
                "ready": str(body.get("status") or "").casefold()
                in {"ok", "healthy", "ready"},
                "workspace": self.workspace,
                "error": None,
            }
        except Exception as exc:  # noqa: BLE001 - optional sidecar health
            return {
                "enabled": True,
                "ready": False,
                "workspace": self.workspace,
                "error": exc.__class__.__name__,
            }

    async def close(self) -> None:
        await self._client.aclose()


__all__ = [
    "LightRAGShadowClient",
    "LightRAGShadowError",
    "ShadowDocument",
    "ShadowWriteResult",
]
