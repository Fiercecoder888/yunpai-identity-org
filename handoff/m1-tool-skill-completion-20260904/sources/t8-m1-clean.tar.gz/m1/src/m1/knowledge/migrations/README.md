# M1 knowledge schema migrations

These Alembic revisions are the sole schema authority for the governed
`knowledge_*` Wiki/search/outbox tables. `KnowledgeStore.init()` upgrades to
`head` before the runtime accepts traffic.

An unversioned database which already contains `knowledge_*` tables is treated
as a legacy `create_all()` deployment: it is stamped at the static baseline
and then passed through the compatibility revision. Empty databases run every
revision normally.

Do not edit an applied revision. Add a new revision and a corresponding
upgrade test whenever the SQLAlchemy model changes.
