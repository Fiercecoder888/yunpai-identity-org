"""Versioned schema migrations for the M1 governed knowledge store."""
