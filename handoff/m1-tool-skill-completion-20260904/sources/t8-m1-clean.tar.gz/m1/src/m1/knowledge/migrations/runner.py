"""Programmatic Alembic runner used by the knowledge-store startup path."""

from __future__ import annotations

import argparse
import asyncio
import os
from collections.abc import Sequence
from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory
from alembic.script.revision import ResolutionError
from alembic.util import CommandError
from sqlalchemy import Connection, inspect, text
from sqlalchemy.ext.asyncio import create_async_engine

BASELINE_REVISION = "0001_knowledge_baseline"
# A stable signed 64-bit key serializes DDL across PostgreSQL API replicas.
POSTGRES_MIGRATION_LOCK = 0x4D31574B494D4947
ROLLBACK_COMPATIBLE_REVISIONS = frozenset(
    {
        "0007_route_profiles",
        "0008_entity_route_index",
        "0009_document_identity_routing",
        "0010_entity_route_tenant_fks",
        "0011_tabular_layout_profiles",
        "0012_field_semantic_routes",
        "0013_visual_region_routes",
        "0014_region_capability_routes",
        "0015_content_region_routes",
        "0016_unified_business_core",
        "0017_recalculation_ledger",
        "0018_finished_goods_output",
        "0019_quality_inspection",
        "0020_lot_traceability",
        "0021_receipt_flow",
        "0022_flow_request_persistence",
    }
)


class KnowledgeSchemaError(RuntimeError):
    """The database could not be proven compatible with the current models."""


def _config(connection: Connection | None = None) -> Config:
    script_location = Path(__file__).resolve().parent
    config = Config()
    config.set_main_option("script_location", str(script_location))
    config.set_main_option("prepend_sys_path", str(script_location.parents[2]))
    config.set_main_option("path_separator", "os")
    if connection is not None:
        config.attributes["connection"] = connection
    return config


def _is_unversioned_legacy(connection: Connection) -> bool:
    inspector = inspect(connection)
    names = set(inspector.get_table_names())
    return "alembic_version" not in names and any(
        name.startswith("knowledge_") for name in names
    )


def _validate_schema(connection: Connection) -> None:
    # Import lazily to keep Alembic's env loading order predictable.
    from m1.knowledge.persistence import KnowledgeBase

    inspector = inspect(connection)
    existing_tables = set(inspector.get_table_names())
    missing_tables = sorted(set(KnowledgeBase.metadata.tables) - existing_tables)
    missing_columns: list[str] = []
    for table_name, table in KnowledgeBase.metadata.tables.items():
        if table_name not in existing_tables:
            continue
        actual = {column["name"] for column in inspector.get_columns(table_name)}
        missing_columns.extend(
            f"{table_name}.{column.name}"
            for column in table.columns
            if column.name not in actual
        )
    if missing_tables or missing_columns:
        details = []
        if missing_tables:
            details.append("missing tables: " + ", ".join(missing_tables))
        if missing_columns:
            details.append("missing columns: " + ", ".join(missing_columns))
        raise KnowledgeSchemaError(
            "knowledge schema validation failed; " + "; ".join(details)
        )


def validate_knowledge_schema(connection: Connection) -> str:
    """Validate the current schema without performing DDL.

    A rollback bridge may encounter an unknown revision created by a newer,
    additive release. It may continue only when every table and column required
    by its own models is still present.
    """

    config = _config(connection)
    scripts = ScriptDirectory.from_config(config)
    head = scripts.get_current_head()
    if not head:
        raise KnowledgeSchemaError("knowledge migration head is missing")
    current = MigrationContext.configure(connection).get_current_revision()
    if current != head:
        try:
            scripts.get_revision(current)
        except (CommandError, ResolutionError):
            if current not in ROLLBACK_COMPATIBLE_REVISIONS:
                raise KnowledgeSchemaError(
                    f"knowledge schema revision {current!r} is not declared "
                    "rollback-compatible"
                ) from None
            _validate_schema(connection)
            return str(current or "")
        raise KnowledgeSchemaError(
            f"knowledge schema is at {current!r}, expected {head!r}"
        )
    _validate_schema(connection)
    return head


def upgrade_knowledge_schema(connection: Connection) -> str:
    """Upgrade one already-open SQLAlchemy connection to Alembic head.

    Passing the application's connection keeps in-memory SQLite usable and
    lets PostgreSQL hold one transaction-scoped advisory lock for stamp,
    upgrade, and validation.
    """

    if connection.dialect.name == "postgresql":
        connection.execute(
            text("SELECT pg_advisory_xact_lock(:lock_id)"),
            {"lock_id": POSTGRES_MIGRATION_LOCK},
        )

    config = _config(connection)
    scripts = ScriptDirectory.from_config(config)
    head = scripts.get_current_head()
    if not head:
        raise KnowledgeSchemaError("knowledge migration head is missing")

    current = MigrationContext.configure(connection).get_current_revision()
    if current and current != head:
        try:
            scripts.get_revision(current)
        except (CommandError, ResolutionError):
            if current not in ROLLBACK_COMPATIBLE_REVISIONS:
                raise KnowledgeSchemaError(
                    f"knowledge schema revision {current!r} is not declared "
                    "rollback-compatible"
                ) from None
            # Never rewrite migration history owned by a newer additive release.
            _validate_schema(connection)
            return current

    if _is_unversioned_legacy(connection):
        # Historical releases created these tables with metadata.create_all().
        # Stamping avoids replaying the static fresh-install baseline over
        # existing data; the compatibility revision performs the real upgrade.
        command.stamp(config, BASELINE_REVISION)

    command.upgrade(config, "head")
    current = MigrationContext.configure(connection).get_current_revision()
    if current != head:
        raise KnowledgeSchemaError(
            f"knowledge migration ended at {current!r}, expected {head!r}"
        )
    _validate_schema(connection)
    return head


async def upgrade_database(database_url: str) -> str:
    engine = create_async_engine(database_url)
    try:
        async with engine.begin() as connection:
            return await connection.run_sync(upgrade_knowledge_schema)
    finally:
        await engine.dispose()


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Upgrade the M1 knowledge schema")
    parser.add_argument(
        "--database-url",
        default=os.environ.get("KNOWLEDGE_DATABASE_URL", ""),
        help="SQLAlchemy async URL (for example postgresql+asyncpg://...)",
    )
    args = parser.parse_args(argv)
    if not args.database_url.strip():
        parser.error("--database-url or KNOWLEDGE_DATABASE_URL is required")
    revision = asyncio.run(upgrade_database(args.database_url))
    print(f"knowledge schema upgraded to {revision}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
