"""upgrade legacy provenance and graph schema

Revision ID: 0002_legacy_knowledge_upgrade
Revises: 0001_knowledge_baseline
Create Date: 2026-07-16 18:29:16.588619
"""
import hashlib
from collections.abc import Sequence
from datetime import UTC, datetime

import sqlalchemy as sa
from alembic import op

revision: str = '0002_legacy_knowledge_upgrade'
down_revision: str | None = '0001_knowledge_baseline'
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


_CURRENT_METADATA_PARENT_KEYS = (
    ("knowledge_source_assets", "tenant_asset_id", ("tenant_id", "asset_id")),
    (
        "knowledge_source_occurrences",
        "tenant_occurrence_id",
        ("tenant_id", "occurrence_id"),
    ),
    ("knowledge_documents", "tenant_document_id", ("tenant_id", "document_id")),
    (
        "knowledge_document_versions",
        "tenant_version_id",
        ("tenant_id", "version_id"),
    ),
    (
        "knowledge_canonical_entities",
        "tenant_entity_id",
        ("tenant_id", "entity_id"),
    ),
)


def _ensure_current_metadata_parent_keys(bind: sa.Connection) -> None:
    """Prepare legacy PostgreSQL parents for current composite foreign keys."""

    if bind.dialect.name != "postgresql":
        return
    inspector = sa.inspect(bind)
    for table, name, columns in _CURRENT_METADATA_PARENT_KEYS:
        if not inspector.has_table(table):
            continue
        constraints = inspector.get_unique_constraints(table)
        has_key = any(
            tuple(item.get("column_names") or ()) == columns
            for item in constraints
        )
        if not has_key:
            op.create_unique_constraint(name, table, list(columns))


def upgrade() -> None:
    """Reconcile databases created by the pre-Alembic development builds.

    Those builds used ``metadata.create_all``.  Depending on when a local or
    pilot database was created, it may contain only part of the governed
    schema and may lack the provenance columns promoted out of JSON.  This is
    the single compatibility bridge; all later changes use ordinary immutable
    Alembic revisions.
    """

    bind = op.get_bind()
    # This compatibility bridge creates the current metadata, which can
    # include vector columns introduced by later immutable revisions.  Ensure
    # the PostgreSQL type exists before SQLAlchemy emits those CREATE TABLEs.
    if bind.dialect.name == "postgresql":
        op.execute(sa.text("CREATE EXTENSION IF NOT EXISTS vector"))
    # The compatibility bridge creates current auxiliary tables before the
    # later migrations that normally add their tenant-scoped parent keys.
    # PostgreSQL requires those keys before it accepts the composite FKs.
    _ensure_current_metadata_parent_keys(bind)
    from m1.knowledge.persistence import KnowledgeBase

    # Create tables that did not exist in an earlier development snapshot.
    KnowledgeBase.metadata.create_all(bind=bind, checkfirst=True)

    def columns(table_name: str) -> set[str]:
        return {
            column["name"]
            for column in sa.inspect(bind).get_columns(table_name)
        }

    if "task_id" not in columns("knowledge_source_occurrences"):
        op.add_column(
            "knowledge_source_occurrences",
            sa.Column(
                "task_id",
                sa.String(length=128),
                nullable=False,
                server_default="",
            ),
        )
        if bind.dialect.name == "postgresql":
            op.execute(sa.text(
                "UPDATE knowledge_source_occurrences "
                "SET task_id = COALESCE(metadata ->> 'task_id', '')"
            ))
        elif bind.dialect.name == "sqlite":
            op.execute(sa.text(
                "UPDATE knowledge_source_occurrences "
                "SET task_id = COALESCE(json_extract(metadata, '$.task_id'), '')"
            ))

    relationship_columns = columns("knowledge_relationship_claims")
    if "source_record_id" not in relationship_columns:
        op.add_column(
            "knowledge_relationship_claims",
            sa.Column(
                "source_record_id",
                sa.String(length=128),
                nullable=False,
                server_default="",
            ),
        )
    if "source_version" not in relationship_columns:
        op.add_column(
            "knowledge_relationship_claims",
            sa.Column(
                "source_version",
                sa.String(length=128),
                nullable=False,
                server_default="",
            ),
        )
    if bind.dialect.name == "postgresql":
        op.execute(sa.text(
            "UPDATE knowledge_relationship_claims SET "
            "source_record_id = COALESCE(properties ->> 'source_record_id', ''), "
            "source_version = COALESCE(properties ->> 'version', '') "
            "WHERE source_record_id = '' OR source_version = ''"
        ))
    elif bind.dialect.name == "sqlite":
        op.execute(sa.text(
            "UPDATE knowledge_relationship_claims SET "
            "source_record_id = COALESCE(json_extract(properties, '$.source_record_id'), ''), "
            "source_version = COALESCE(json_extract(properties, '$.version'), '') "
            "WHERE source_record_id = '' OR source_version = ''"
        ))

    binding_columns = columns("knowledge_entity_source_bindings")
    binding_additions = (
        ("asserted_label", sa.String(length=1024), ""),
        ("asserted_attributes", sa.JSON(), "{}"),
        ("asserted_lifecycle_status", sa.String(length=32), "under_review"),
        ("asserted_confidence", sa.Float(), "0"),
    )
    for name, type_, default in binding_additions:
        if name not in binding_columns:
            op.add_column(
                "knowledge_entity_source_bindings",
                sa.Column(
                    name,
                    type_,
                    nullable=False,
                    server_default=sa.text(f"'{default}'"),
                ),
            )
    op.execute(sa.text(
        "UPDATE knowledge_entity_source_bindings SET "
        "asserted_label = COALESCE((SELECT canonical_label "
        "FROM knowledge_canonical_entities e WHERE e.entity_id = "
        "knowledge_entity_source_bindings.entity_id), asserted_label), "
        "asserted_attributes = COALESCE((SELECT attributes "
        "FROM knowledge_canonical_entities e WHERE e.entity_id = "
        "knowledge_entity_source_bindings.entity_id), asserted_attributes), "
        "asserted_lifecycle_status = COALESCE((SELECT lifecycle_status "
        "FROM knowledge_canonical_entities e WHERE e.entity_id = "
        "knowledge_entity_source_bindings.entity_id), asserted_lifecycle_status), "
        "asserted_confidence = COALESCE((SELECT confidence "
        "FROM knowledge_canonical_entities e WHERE e.entity_id = "
        "knowledge_entity_source_bindings.entity_id), asserted_confidence)"
    ))

    # An intermediate build keyed graph generations only by source_record_id,
    # which collided across tenants.  Rebuild this small counter table with a
    # tenant/source uniqueness constraint and an opaque primary key.
    generation_table = "knowledge_graph_generations"
    if "generation_id" not in columns(generation_table):
        legacy = sa.Table(generation_table, sa.MetaData(), autoload_with=bind)
        rows = [dict(row) for row in bind.execute(sa.select(legacy)).mappings()]
        legacy.drop(bind=bind)
        target = KnowledgeBase.metadata.tables[generation_table]
        target.create(bind=bind, checkfirst=False)
        now = datetime.now(UTC)
        for row in rows:
            tenant_id = str(row.get("tenant_id") or "default")
            source_record_id = str(row.get("source_record_id") or "")
            generation_id = hashlib.sha256(
                f"{tenant_id}:{source_record_id}".encode()
            ).hexdigest()
            bind.execute(target.insert().values(
                generation_id=generation_id,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
                generation=int(row.get("generation") or 0),
                updated_at=row.get("updated_at") or now,
            ))

    # ``create_all`` does not add indexes to pre-existing tables.  Build only
    # indexes whose columns exist at this point in the immutable migration
    # chain.  ``KnowledgeBase.metadata`` reflects newer revisions too, so
    # blindly creating every current index here would reference columns added
    # by a later migration (for example ``processing_revision`` in 0009).
    for table in KnowledgeBase.metadata.sorted_tables:
        physical_columns = columns(table.name)
        for index in table.indexes:
            if any(column.name not in physical_columns for column in index.columns):
                continue
            index.create(bind=bind, checkfirst=True)


def downgrade() -> None:
    pass
