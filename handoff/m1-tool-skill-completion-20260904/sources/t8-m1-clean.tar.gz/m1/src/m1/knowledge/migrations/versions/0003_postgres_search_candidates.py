"""add PostgreSQL server-side candidate search indexes

Revision ID: 0003_postgres_search_candidates
Revises: 0002_legacy_knowledge_upgrade
Create Date: 2026-07-17 09:00:00
"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0003_postgres_search_candidates"
down_revision: Union[str, None] = "0002_legacy_knowledge_upgrade"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    columns = {
        column["name"]
        for column in sa.inspect(bind).get_columns("knowledge_search_index")
    }
    if bind.dialect.name != "postgresql":
        if "embedding" not in columns:
            op.add_column(
                "knowledge_search_index",
                sa.Column("embedding", sa.JSON(), nullable=True),
            )
        if "embedding_model" not in columns:
            op.add_column(
                "knowledge_search_index",
                sa.Column(
                    "embedding_model",
                    sa.String(length=256),
                    nullable=False,
                    server_default="",
                ),
            )
        return

    # pg_trgm supports Chinese/identifier substring candidates without forcing
    # a language-specific tokenizer. Final BM25/vector/graph fusion remains in
    # the application over this bounded SQL result set.
    op.execute(sa.text("CREATE EXTENSION IF NOT EXISTS pg_trgm"))
    op.execute(sa.text("CREATE EXTENSION IF NOT EXISTS vector"))
    if "embedding" not in columns:
        op.execute(sa.text(
            "ALTER TABLE knowledge_search_index ADD COLUMN embedding vector(1024)"
        ))
    if "embedding_model" not in columns:
        op.add_column(
            "knowledge_search_index",
            sa.Column(
                "embedding_model",
                sa.String(length=256),
                nullable=False,
                server_default="",
            ),
        )
    op.execute(sa.text(
        "CREATE INDEX IF NOT EXISTS ix_knowledge_search_text_trgm "
        "ON knowledge_search_index USING gin (text gin_trgm_ops)"
    ))
    op.execute(sa.text(
        "CREATE INDEX IF NOT EXISTS ix_knowledge_search_vector_text_trgm "
        "ON knowledge_search_index USING gin (vector_text gin_trgm_ops)"
    ))
    op.execute(sa.text(
        "ALTER TABLE knowledge_search_index "
        "ALTER COLUMN selected_fields TYPE jsonb USING selected_fields::jsonb"
    ))
    op.execute(sa.text(
        "ALTER TABLE knowledge_search_index "
        "ALTER COLUMN graph_keys TYPE jsonb USING graph_keys::jsonb"
    ))
    op.execute(sa.text(
        "CREATE INDEX IF NOT EXISTS ix_knowledge_search_selected_fields_gin "
        "ON knowledge_search_index USING gin (selected_fields jsonb_path_ops)"
    ))
    op.execute(sa.text(
        "CREATE INDEX IF NOT EXISTS ix_knowledge_search_graph_keys_gin "
        "ON knowledge_search_index USING gin (graph_keys jsonb_path_ops)"
    ))
    op.execute(sa.text(
        "CREATE INDEX IF NOT EXISTS ix_knowledge_search_embedding_hnsw "
        "ON knowledge_search_index USING hnsw (embedding vector_cosine_ops) "
        "WHERE embedding IS NOT NULL"
    ))


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        with op.batch_alter_table("knowledge_search_index") as batch:
            batch.drop_column("embedding_model")
            batch.drop_column("embedding")
        return
    op.execute(sa.text("DROP INDEX IF EXISTS ix_knowledge_search_embedding_hnsw"))
    op.execute(sa.text("DROP INDEX IF EXISTS ix_knowledge_search_graph_keys_gin"))
    op.execute(sa.text("DROP INDEX IF EXISTS ix_knowledge_search_selected_fields_gin"))
    op.execute(sa.text("DROP INDEX IF EXISTS ix_knowledge_search_vector_text_trgm"))
    op.execute(sa.text("DROP INDEX IF EXISTS ix_knowledge_search_text_trgm"))
    op.execute(sa.text(
        "ALTER TABLE knowledge_search_index "
        "ALTER COLUMN graph_keys TYPE json USING graph_keys::json"
    ))
    op.execute(sa.text(
        "ALTER TABLE knowledge_search_index "
        "ALTER COLUMN selected_fields TYPE json USING selected_fields::json"
    ))
    op.drop_column("knowledge_search_index", "embedding_model")
    op.drop_column("knowledge_search_index", "embedding")
