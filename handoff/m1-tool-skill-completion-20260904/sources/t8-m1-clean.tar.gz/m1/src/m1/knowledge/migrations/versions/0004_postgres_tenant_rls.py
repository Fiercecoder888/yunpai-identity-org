"""enforce PostgreSQL tenant row-level security

Revision ID: 0004_postgres_tenant_rls
Revises: 0003_postgres_search_candidates
Create Date: 2026-07-17 11:00:00
"""
from __future__ import annotations

from typing import Sequence, Union

from alembic import op


revision: str = "0004_postgres_tenant_rls"
down_revision: Union[str, None] = "0003_postgres_search_candidates"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


TENANT_TABLES = (
    "knowledge_tenants",
    "knowledge_ingestion_batches",
    "knowledge_source_assets",
    "knowledge_source_occurrences",
    "knowledge_documents",
    "knowledge_document_versions",
    "knowledge_task_version_bindings",
    "knowledge_entity_source_bindings",
    "knowledge_evidence_anchors",
    "knowledge_field_claims",
    "knowledge_canonical_entities",
    "knowledge_external_identities",
    "knowledge_identity_source_bindings",
    "knowledge_entity_aliases",
    "knowledge_alias_source_bindings",
    "knowledge_entity_revisions",
    "knowledge_relationship_claims",
    "knowledge_review_tasks",
    "knowledge_review_decisions",
    "knowledge_conflicts",
    "knowledge_chunks",
    "knowledge_search_index",
    "knowledge_graph_snapshots",
    "knowledge_graph_generations",
    "knowledge_projection_outbox",
)


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    predicate = (
        "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
    )
    for table in TENANT_TABLES:
        policy = f"m1_tenant_isolation_{table.removeprefix('knowledge_')}"
        op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
        # FORCE also applies the policy to the table owner used by the local
        # Compose stack. PostgreSQL superusers/BYPASSRLS roles remain outside
        # RLS by design and must not be used by the application service.
        op.execute(f'ALTER TABLE "{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{policy}" ON "{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    for table in reversed(TENANT_TABLES):
        policy = f"m1_tenant_isolation_{table.removeprefix('knowledge_')}"
        op.execute(f'DROP POLICY IF EXISTS "{policy}" ON "{table}"')
        op.execute(f'ALTER TABLE "{table}" NO FORCE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
