"""add durable task lifecycle fence

Revision ID: 0005_task_lifecycle_fence
Revises: 0004_postgres_tenant_rls
Create Date: 2026-07-21 12:00:00
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0005_task_lifecycle_fence"
down_revision: Union[str, None] = "0004_postgres_tenant_rls"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

TABLE_NAME = "knowledge_task_lifecycles"
POLICY_NAME = "m1_tenant_isolation_task_lifecycles"


def _create_table() -> None:
    op.create_table(
        TABLE_NAME,
        sa.Column("lifecycle_id", sa.String(length=128), nullable=False),
        sa.Column("task_id", sa.String(length=128), nullable=False),
        sa.Column("epoch", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tombstoned_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint("epoch >= 0", name=op.f("ck_knowledge_task_lifecycles_epoch_nonnegative")),
        sa.CheckConstraint(
            "status IN ('active','tombstoned')",
            name=op.f("ck_knowledge_task_lifecycles_status"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f("fk_knowledge_task_lifecycles_tenant_id_knowledge_tenants"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "lifecycle_id", name=op.f("pk_knowledge_task_lifecycles")
        ),
        sa.UniqueConstraint(
            "tenant_id", "task_id", name="task_lifecycle_identity"
        ),
    )
    op.create_index(
        "ix_knowledge_task_lifecycle_lookup",
        TABLE_NAME,
        ["tenant_id", "task_id", "status"],
        unique=False,
    )
    op.create_index(
        op.f("ix_knowledge_task_lifecycles_status"),
        TABLE_NAME,
        ["status"],
        unique=False,
    )
    op.create_index(
        op.f("ix_knowledge_task_lifecycles_task_id"),
        TABLE_NAME,
        ["task_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_knowledge_task_lifecycles_tenant_id"),
        TABLE_NAME,
        ["tenant_id"],
        unique=False,
    )


def upgrade() -> None:
    bind = op.get_bind()
    # Revision 0002 intentionally calls current metadata.create_all() as a
    # compatibility bridge for unversioned development databases. It can
    # therefore materialize this future table before Alembic reaches 0005.
    if not sa.inspect(bind).has_table(TABLE_NAME):
        _create_table()
    if bind.dialect.name == "postgresql":
        predicate = "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
        op.execute(f'ALTER TABLE "{TABLE_NAME}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{TABLE_NAME}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{POLICY_NAME}" ON "{TABLE_NAME}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.execute(f'DROP POLICY IF EXISTS "{POLICY_NAME}" ON "{TABLE_NAME}"')
        op.execute(f'ALTER TABLE "{TABLE_NAME}" NO FORCE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{TABLE_NAME}" DISABLE ROW LEVEL SECURITY')

    op.drop_index(
        op.f("ix_knowledge_task_lifecycles_tenant_id"),
        table_name=TABLE_NAME,
    )
    op.drop_index(
        op.f("ix_knowledge_task_lifecycles_task_id"),
        table_name=TABLE_NAME,
    )
    op.drop_index(
        op.f("ix_knowledge_task_lifecycles_status"),
        table_name=TABLE_NAME,
    )
    op.drop_index("ix_knowledge_task_lifecycle_lookup", table_name=TABLE_NAME)
    op.drop_table(TABLE_NAME)
