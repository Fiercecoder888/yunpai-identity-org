"""bind review decisions to the exact review task

Revision ID: 0006_review_task_reference
Revises: 0005_task_lifecycle_fence
Create Date: 2026-07-21 13:00:00
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0006_review_task_reference"
down_revision: Union[str, None] = "0005_task_lifecycle_fence"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

TABLE_NAME = "knowledge_review_decisions"
COLUMN_NAME = "review_task_id"
INDEX_NAME = "ix_knowledge_review_decisions_review_task_id"
FOREIGN_KEY_NAME = (
    "fk_review_decisions_review_task"
)


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {column["name"] for column in inspector.get_columns(TABLE_NAME)}
    if COLUMN_NAME not in columns:
        with op.batch_alter_table(TABLE_NAME, schema=None) as batch_op:
            batch_op.add_column(
                sa.Column(COLUMN_NAME, sa.String(length=128), nullable=True)
            )
            batch_op.create_foreign_key(
                FOREIGN_KEY_NAME,
                "knowledge_review_tasks",
                [COLUMN_NAME],
                ["review_task_id"],
                ondelete="RESTRICT",
            )
    indexes = {index["name"] for index in sa.inspect(bind).get_indexes(TABLE_NAME)}
    if INDEX_NAME not in indexes:
        op.create_index(INDEX_NAME, TABLE_NAME, [COLUMN_NAME], unique=False)


def downgrade() -> None:
    bind = op.get_bind()
    columns = {column["name"] for column in sa.inspect(bind).get_columns(TABLE_NAME)}
    if COLUMN_NAME not in columns:
        return
    with op.batch_alter_table(TABLE_NAME, schema=None) as batch_op:
        batch_op.drop_constraint(FOREIGN_KEY_NAME, type_="foreignkey")
        batch_op.drop_index(INDEX_NAME)
        batch_op.drop_column(COLUMN_NAME)
