"""add tenant-scoped entity identity candidate routing index

Revision ID: 0008_entity_route_index
Revises: 0007_route_profiles
Create Date: 2026-07-27 16:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from m1.knowledge.db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    KNOWLEDGE_EMBEDDING_TYPE,
)

revision: str = "0008_entity_route_index"
down_revision: str | None = "0007_route_profiles"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

INDEX_TABLE = "knowledge_entity_route_index"
DECISION_TABLE = "knowledge_entity_route_decisions"
TENANT_TABLES = (INDEX_TABLE, DECISION_TABLE)
POLICY_NAMES = {
    INDEX_TABLE: "m1_tenant_isolation_entity_route_index",
    DECISION_TABLE: "m1_tenant_isolation_entity_route_decisions",
}
HNSW_INDEX = "ix_entity_route_index_embedding_hnsw"


def _create_index_table() -> None:
    op.create_table(
        INDEX_TABLE,
        sa.Column("index_id", sa.String(length=128), nullable=False),
        sa.Column("entity_id", sa.String(length=128), nullable=False),
        sa.Column("entity_type", sa.String(length=128), nullable=False),
        sa.Column("normalized_text", sa.Text(), nullable=False),
        sa.Column("embedding", KNOWLEDGE_EMBEDDING_TYPE, nullable=False),
        sa.Column("embedding_model", sa.String(length=256), nullable=False),
        sa.Column("embedding_dimensions", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "embedding_dimensions > 0",
            name=op.f("ck_knowledge_entity_route_index_embedding_dimensions_positive"),
        ),
        sa.ForeignKeyConstraint(
            ["entity_id"],
            ["knowledge_canonical_entities.entity_id"],
            name=op.f("fk_knowledge_entity_route_index_entity_id_knowledge_canonical_entities"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f("fk_knowledge_entity_route_index_tenant_id_knowledge_tenants"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("index_id", name=op.f("pk_knowledge_entity_route_index")),
        sa.UniqueConstraint(
            "tenant_id",
            "entity_id",
            "embedding_model",
            "embedding_dimensions",
            name="entity_route_index_space",
        ),
    )
    op.create_index(
        "ix_entity_route_index_lookup",
        INDEX_TABLE,
        ["tenant_id", "entity_type", "embedding_model", "embedding_dimensions"],
    )
    for column in ("tenant_id", "entity_id", "entity_type"):
        op.create_index(
            op.f(f"ix_{INDEX_TABLE}_{column}"), INDEX_TABLE, [column]
        )


def _create_decision_table() -> None:
    op.create_table(
        DECISION_TABLE,
        sa.Column("decision_id", sa.String(length=128), nullable=False),
        sa.Column("source_version_id", sa.String(length=128), nullable=False),
        sa.Column("proposed_entity_id", sa.String(length=128), nullable=False),
        sa.Column("entity_type", sa.String(length=128), nullable=False),
        sa.Column("action", sa.String(length=32), nullable=False),
        sa.Column("candidate_entity_id", sa.String(length=128), nullable=True),
        sa.Column("candidate_score", sa.Float(), nullable=False),
        sa.Column("top1_top2_margin", sa.Float(), nullable=False),
        sa.Column("model_confidence", sa.Float(), nullable=False),
        sa.Column("reason_codes", sa.JSON(), nullable=False),
        sa.Column("model_name", sa.String(length=256), nullable=False),
        sa.Column("model_revision", sa.String(length=256), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "action IN ('link','new_candidate','review')",
            name=op.f("ck_knowledge_entity_route_decisions_action"),
        ),
        sa.CheckConstraint(
            "candidate_score >= 0 AND candidate_score <= 1",
            name=op.f("ck_knowledge_entity_route_decisions_candidate_score_range"),
        ),
        sa.CheckConstraint(
            "top1_top2_margin >= 0 AND top1_top2_margin <= 1",
            name=op.f("ck_knowledge_entity_route_decisions_margin_range"),
        ),
        sa.CheckConstraint(
            "model_confidence >= 0 AND model_confidence <= 1",
            name=op.f("ck_knowledge_entity_route_decisions_model_confidence_range"),
        ),
        sa.ForeignKeyConstraint(
            ["source_version_id"],
            ["knowledge_document_versions.version_id"],
            name=op.f("fk_knowledge_entity_route_decisions_source_version_id_knowledge_document_versions"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["candidate_entity_id"],
            ["knowledge_canonical_entities.entity_id"],
            name=op.f("fk_knowledge_entity_route_decisions_candidate_entity_id_knowledge_canonical_entities"),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f("fk_knowledge_entity_route_decisions_tenant_id_knowledge_tenants"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "decision_id", name=op.f("pk_knowledge_entity_route_decisions")
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "source_version_id",
            "proposed_entity_id",
            name="entity_route_decision_source_proposal",
        ),
    )
    op.create_index(
        "ix_entity_route_decisions_source",
        DECISION_TABLE,
        ["tenant_id", "source_version_id", "created_at"],
    )
    op.create_index(
        "ix_entity_route_decisions_candidate",
        DECISION_TABLE,
        ["tenant_id", "candidate_entity_id", "created_at"],
    )
    for column in ("tenant_id", "source_version_id", "entity_type", "candidate_entity_id"):
        op.create_index(
            op.f(f"ix_{DECISION_TABLE}_{column}"), DECISION_TABLE, [column]
        )


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if not inspector.has_table(INDEX_TABLE):
        _create_index_table()
    if not sa.inspect(bind).has_table(DECISION_TABLE):
        _create_decision_table()

    if bind.dialect.name != "postgresql":
        return
    op.execute(
        f"CREATE INDEX IF NOT EXISTS {HNSW_INDEX} ON {INDEX_TABLE} "
        "USING hnsw (embedding vector_cosine_ops) "
        f"WHERE embedding_dimensions = {KNOWLEDGE_EMBEDDING_DIMENSIONS} "
        "AND embedding_model <> ''"
    )
    predicate = "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
    for table in TENANT_TABLES:
        op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" ON "{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in reversed(TENANT_TABLES):
            op.execute(f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{table}"')
            op.execute(f'ALTER TABLE "{table}" NO FORCE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
        op.execute(f"DROP INDEX IF EXISTS {HNSW_INDEX}")
    op.drop_table(DECISION_TABLE)
    op.drop_table(INDEX_TABLE)
