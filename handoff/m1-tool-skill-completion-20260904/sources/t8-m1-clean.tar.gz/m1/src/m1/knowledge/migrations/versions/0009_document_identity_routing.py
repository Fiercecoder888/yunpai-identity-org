"""add governed document identity bindings and version lineage

Revision ID: 0009_document_identity_routing
Revises: 0008_entity_route_index
Create Date: 2026-07-27 18:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0009_document_identity_routing"
down_revision: str | None = "0008_entity_route_index"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

ASSET_TABLE = "knowledge_source_assets"
OCCURRENCE_TABLE = "knowledge_source_occurrences"
DOCUMENT_TABLE = "knowledge_documents"
VERSION_TABLE = "knowledge_document_versions"
BINDING_TABLE = "knowledge_document_identity_bindings"
DECISION_TABLE = "knowledge_document_identity_decisions"
TENANT_TABLES = (BINDING_TABLE, DECISION_TABLE)
POLICY_NAMES = {
    BINDING_TABLE: "m1_tenant_isolation_document_identity_bindings",
    DECISION_TABLE: "m1_tenant_isolation_document_identity_decisions",
}
PROCESSING_REVISION_INDEX = "ix_document_versions_processing_revision"


def _unique_names(inspector: sa.Inspector, table: str) -> set[str]:
    return {
        str(item.get("name") or "")
        for item in inspector.get_unique_constraints(table)
        if item.get("name")
    }


def _foreign_key_names(inspector: sa.Inspector, table: str) -> set[str]:
    return {
        str(item.get("name") or "")
        for item in inspector.get_foreign_keys(table)
        if item.get("name")
    }


def _column_names(inspector: sa.Inspector, table: str) -> set[str]:
    return {str(item["name"]) for item in inspector.get_columns(table)}


def _ensure_parent_tenant_keys(bind: sa.Connection) -> None:
    inspector = sa.inspect(bind)
    requested = (
        (ASSET_TABLE, "tenant_asset_id", ("tenant_id", "asset_id")),
        (OCCURRENCE_TABLE, "tenant_occurrence_id", ("tenant_id", "occurrence_id")),
        (DOCUMENT_TABLE, "tenant_document_id", ("tenant_id", "document_id")),
        (VERSION_TABLE, "tenant_version_id", ("tenant_id", "version_id")),
    )
    if bind.dialect.name == "sqlite":
        for table, name, columns in requested:
            if name in _unique_names(sa.inspect(bind), table):
                continue
            with op.batch_alter_table(table) as batch:
                batch.create_unique_constraint(name, columns)
        return
    for table, name, columns in requested:
        if name not in _unique_names(inspector, table):
            op.create_unique_constraint(name, table, columns)


def _ensure_version_lineage(bind: sa.Connection) -> None:
    inspector = sa.inspect(bind)
    columns = _column_names(inspector, VERSION_TABLE)
    foreign_keys = _foreign_key_names(inspector, VERSION_TABLE)
    if bind.dialect.name == "sqlite":
        if "processing_revision" not in columns or "supersedes_version_id" not in columns or "tenant_version_supersedes" not in foreign_keys:
            with op.batch_alter_table(VERSION_TABLE) as batch:
                if "processing_revision" not in columns:
                    batch.add_column(
                        sa.Column(
                            "processing_revision",
                            sa.String(length=64),
                            nullable=False,
                            server_default="legacy",
                        )
                    )
                if "supersedes_version_id" not in columns:
                    batch.add_column(sa.Column("supersedes_version_id", sa.String(length=128)))
                if "tenant_version_supersedes" not in foreign_keys:
                    batch.create_foreign_key(
                        "tenant_version_supersedes",
                        VERSION_TABLE,
                        ["tenant_id", "supersedes_version_id"],
                        ["tenant_id", "version_id"],
                        ondelete="RESTRICT",
                    )
    else:
        if "processing_revision" not in columns:
            op.add_column(
                VERSION_TABLE,
                sa.Column(
                    "processing_revision",
                    sa.String(length=64),
                    nullable=False,
                    server_default="legacy",
                ),
            )
        if "supersedes_version_id" not in columns:
            op.add_column(VERSION_TABLE, sa.Column("supersedes_version_id", sa.String(length=128)))
        if "tenant_version_supersedes" not in foreign_keys:
            op.create_foreign_key(
                "tenant_version_supersedes",
                VERSION_TABLE,
                VERSION_TABLE,
                ["tenant_id", "supersedes_version_id"],
                ["tenant_id", "version_id"],
                ondelete="RESTRICT",
            )
    fresh = sa.inspect(bind)
    index_names = {str(item.get("name") or "") for item in fresh.get_indexes(VERSION_TABLE)}
    if PROCESSING_REVISION_INDEX not in index_names:
        op.create_index(PROCESSING_REVISION_INDEX, VERSION_TABLE, ["tenant_id", "processing_revision"])


def _create_binding_table() -> None:
    op.create_table(
        BINDING_TABLE,
        sa.Column("binding_id", sa.String(length=128), nullable=False),
        sa.Column("document_id", sa.String(length=128), nullable=False),
        sa.Column("identity_kind", sa.String(length=32), nullable=False),
        sa.Column("identity_namespace", sa.String(length=128), nullable=False),
        sa.Column("identity_value", sa.String(length=512), nullable=False),
        sa.Column("approved_by", sa.String(length=256), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "identity_kind IN ('verified_external','manual_confirmed')",
            name=op.f("ck_knowledge_document_identity_bindings_identity_kind"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "document_id"],
            [f"{DOCUMENT_TABLE}.tenant_id", f"{DOCUMENT_TABLE}.document_id"],
            name="document_identity_binding_document",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f("fk_knowledge_document_identity_bindings_tenant_id_knowledge_tenants"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("binding_id", name=op.f("pk_knowledge_document_identity_bindings")),
        sa.UniqueConstraint(
            "tenant_id",
            "identity_kind",
            "identity_namespace",
            "identity_value",
            name="document_identity_binding_key",
        ),
    )
    op.create_index(
        "ix_document_identity_binding_document",
        BINDING_TABLE,
        ["tenant_id", "document_id"],
    )


def _create_decision_table() -> None:
    op.create_table(
        DECISION_TABLE,
        sa.Column("decision_id", sa.String(length=128), nullable=False),
        sa.Column("source_asset_id", sa.String(length=128), nullable=False),
        sa.Column("source_occurrence_id", sa.String(length=128), nullable=False),
        sa.Column("document_id", sa.String(length=128), nullable=False),
        sa.Column("version_id", sa.String(length=128), nullable=False),
        sa.Column("action", sa.String(length=48), nullable=False),
        sa.Column("target_document_id", sa.String(length=128)),
        sa.Column("target_version_id", sa.String(length=128)),
        sa.Column("identity_kind", sa.String(length=32)),
        sa.Column("identity_namespace", sa.String(length=128)),
        sa.Column("identity_value", sa.String(length=512)),
        sa.Column("processing_revision", sa.String(length=64), nullable=False),
        sa.Column("candidate_document_ids", sa.JSON(), nullable=False),
        sa.Column("candidate_methods", sa.JSON(), nullable=False),
        sa.Column("reason_codes", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "action IN ('exact_asset_replay','existing_document_new_version',"
            "'new_document','identity_candidate_review')",
            name=op.f("ck_knowledge_document_identity_decisions_action"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "source_asset_id"],
            [f"{ASSET_TABLE}.tenant_id", f"{ASSET_TABLE}.asset_id"],
            name="document_identity_decision_asset",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "source_occurrence_id"],
            [f"{OCCURRENCE_TABLE}.tenant_id", f"{OCCURRENCE_TABLE}.occurrence_id"],
            name="document_identity_decision_occurrence_fk",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "document_id"],
            [f"{DOCUMENT_TABLE}.tenant_id", f"{DOCUMENT_TABLE}.document_id"],
            name="document_identity_decision_document",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "version_id"],
            [f"{VERSION_TABLE}.tenant_id", f"{VERSION_TABLE}.version_id"],
            name="document_identity_decision_version",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "target_document_id"],
            [f"{DOCUMENT_TABLE}.tenant_id", f"{DOCUMENT_TABLE}.document_id"],
            name="document_identity_decision_target_document",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "target_version_id"],
            [f"{VERSION_TABLE}.tenant_id", f"{VERSION_TABLE}.version_id"],
            name="document_identity_decision_target_version",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f("fk_knowledge_document_identity_decisions_tenant_id_knowledge_tenants"),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("decision_id", name=op.f("pk_knowledge_document_identity_decisions")),
        sa.UniqueConstraint(
            "tenant_id",
            "source_occurrence_id",
            name="document_identity_decision_occurrence",
        ),
    )
    op.create_index(
        "ix_document_identity_decision_target",
        DECISION_TABLE,
        ["tenant_id", "target_document_id", "created_at"],
    )


def upgrade() -> None:
    bind = op.get_bind()
    _ensure_parent_tenant_keys(bind)
    _ensure_version_lineage(bind)
    inspector = sa.inspect(bind)
    if not inspector.has_table(BINDING_TABLE):
        _create_binding_table()
    if not sa.inspect(bind).has_table(DECISION_TABLE):
        _create_decision_table()
    if bind.dialect.name != "postgresql":
        return
    predicate = "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
    for table in TENANT_TABLES:
        op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" ON "{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in reversed(TENANT_TABLES):
            op.execute(f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{table}"')
            op.execute(f'ALTER TABLE "{table}" NO FORCE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
    op.drop_table(DECISION_TABLE)
    op.drop_table(BINDING_TABLE)
    if bind.dialect.name == "sqlite":
        # SQLite batch-alter copies indexes from the old table to its temporary
        # replacement.  Remove this index before dropping its column, or the
        # copy phase tries to recreate it against a table with no such column.
        op.drop_index(PROCESSING_REVISION_INDEX, table_name=VERSION_TABLE)
        with op.batch_alter_table(VERSION_TABLE) as batch:
            batch.drop_constraint("tenant_version_supersedes", type_="foreignkey")
            batch.drop_column("supersedes_version_id")
            batch.drop_column("processing_revision")
        for table, name in (
            (VERSION_TABLE, "tenant_version_id"),
            (DOCUMENT_TABLE, "tenant_document_id"),
            (OCCURRENCE_TABLE, "tenant_occurrence_id"),
            (ASSET_TABLE, "tenant_asset_id"),
        ):
            with op.batch_alter_table(table) as batch:
                batch.drop_constraint(name, type_="unique")
    else:
        op.drop_index(PROCESSING_REVISION_INDEX, table_name=VERSION_TABLE)
        op.drop_constraint("tenant_version_supersedes", VERSION_TABLE, type_="foreignkey")
        op.drop_column(VERSION_TABLE, "supersedes_version_id")
        op.drop_column(VERSION_TABLE, "processing_revision")
        for table, name in (
            (VERSION_TABLE, "tenant_version_id"),
            (DOCUMENT_TABLE, "tenant_document_id"),
            (OCCURRENCE_TABLE, "tenant_occurrence_id"),
            (ASSET_TABLE, "tenant_asset_id"),
        ):
            op.drop_constraint(name, table, type_="unique")
