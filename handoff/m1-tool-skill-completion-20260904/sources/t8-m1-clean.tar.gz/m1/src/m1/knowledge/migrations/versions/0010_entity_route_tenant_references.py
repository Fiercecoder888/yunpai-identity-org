"""enforce tenant-scoped entity route references

Revision ID: 0010_entity_route_tenant_fks
Revises: 0009_document_identity_routing
Create Date: 2026-07-27 19:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0010_entity_route_tenant_fks"
down_revision: str | None = "0009_document_identity_routing"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

ENTITY_TABLE = "knowledge_canonical_entities"
VERSION_TABLE = "knowledge_document_versions"
INDEX_TABLE = "knowledge_entity_route_index"
DECISION_TABLE = "knowledge_entity_route_decisions"

ENTITY_TENANT_KEY = "tenant_entity_id"
INDEX_ENTITY_FK = "entity_route_index_tenant_entity"
DECISION_VERSION_FK = "entity_route_decision_tenant_version"
DECISION_CANDIDATE_FK = "entity_route_decision_tenant_candidate"

_SQLITE_NAMING_CONVENTION = {
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
}


def _column_tuple(item: object) -> tuple[str, ...]:
    if not isinstance(item, (list, tuple)):
        return ()
    return tuple(str(value) for value in item)


def _has_unique_columns(
    inspector: sa.Inspector,
    table: str,
    columns: tuple[str, ...],
) -> bool:
    for constraint in inspector.get_unique_constraints(table):
        if _column_tuple(constraint.get("column_names")) == columns:
            return True
    primary_key = getattr(inspector, "get_pk_constraint", lambda _table: {})(table)
    return _column_tuple(primary_key.get("constrained_columns")) == columns


def _matching_foreign_keys(
    inspector: sa.Inspector,
    table: str,
    *,
    constrained_columns: tuple[str, ...],
    referred_table: str,
    referred_columns: tuple[str, ...],
) -> list[dict[str, object]]:
    return [
        foreign_key
        for foreign_key in inspector.get_foreign_keys(table)
        if _column_tuple(foreign_key.get("constrained_columns")) == constrained_columns
        and str(foreign_key.get("referred_table") or "") == referred_table
        and _column_tuple(foreign_key.get("referred_columns")) == referred_columns
    ]


def _foreign_key_name(table: str, foreign_key: dict[str, object]) -> str:
    name = str(foreign_key.get("name") or "").strip()
    if name:
        return name
    columns = _column_tuple(foreign_key.get("constrained_columns"))
    referred = str(foreign_key.get("referred_table") or "").strip()
    if not columns or not referred:
        raise RuntimeError(f"cannot identify foreign key on {table}")
    # The batch naming convention assigns this name to an anonymous SQLite FK.
    return f"fk_{table}_{columns[0]}_{referred}"


def _ensure_entity_tenant_key(bind: sa.Connection) -> None:
    inspector = sa.inspect(bind)
    if _has_unique_columns(inspector, ENTITY_TABLE, ("tenant_id", "entity_id")):
        return
    if bind.dialect.name == "sqlite":
        with op.batch_alter_table(ENTITY_TABLE) as batch:
            batch.create_unique_constraint(
                ENTITY_TENANT_KEY,
                ["tenant_id", "entity_id"],
            )
        return
    op.create_unique_constraint(
        ENTITY_TENANT_KEY,
        ENTITY_TABLE,
        ["tenant_id", "entity_id"],
    )


def _replace_foreign_keys(
    bind: sa.Connection,
    *,
    table: str,
    legacy: tuple[tuple[tuple[str, ...], str, tuple[str, ...]], ...],
    target: tuple[tuple[str, tuple[str, ...], str, tuple[str, ...]], ...],
) -> None:
    inspector = sa.inspect(bind)
    legacy_foreign_keys = [
        foreign_key
        for constrained_columns, referred_table, referred_columns in legacy
        for foreign_key in _matching_foreign_keys(
            inspector,
            table,
            constrained_columns=constrained_columns,
            referred_table=referred_table,
            referred_columns=referred_columns,
        )
    ]
    missing_targets = [
        specification
        for specification in target
        if not _matching_foreign_keys(
            inspector,
            table,
            constrained_columns=specification[1],
            referred_table=specification[2],
            referred_columns=specification[3],
        )
    ]
    if not legacy_foreign_keys and not missing_targets:
        return

    if bind.dialect.name == "sqlite":
        with op.batch_alter_table(
            table,
            recreate="always",
            naming_convention=_SQLITE_NAMING_CONVENTION,
        ) as batch:
            for foreign_key in legacy_foreign_keys:
                batch.drop_constraint(
                    _foreign_key_name(table, foreign_key),
                    type_="foreignkey",
                )
            for name, constrained_columns, referred_table, referred_columns in missing_targets:
                batch.create_foreign_key(
                    name,
                    referred_table,
                    list(constrained_columns),
                    list(referred_columns),
                    ondelete="RESTRICT",
                )
        return

    for foreign_key in legacy_foreign_keys:
        op.drop_constraint(
            _foreign_key_name(table, foreign_key),
            table,
            type_="foreignkey",
        )
    for name, constrained_columns, referred_table, referred_columns in missing_targets:
        op.create_foreign_key(
            name,
            table,
            referred_table,
            list(constrained_columns),
            list(referred_columns),
            ondelete="RESTRICT",
        )


def _upgrade_foreign_keys(bind: sa.Connection) -> None:
    _replace_foreign_keys(
        bind,
        table=INDEX_TABLE,
        legacy=((("entity_id",), ENTITY_TABLE, ("entity_id",)),),
        target=(
            (
                INDEX_ENTITY_FK,
                ("tenant_id", "entity_id"),
                ENTITY_TABLE,
                ("tenant_id", "entity_id"),
            ),
        ),
    )
    _replace_foreign_keys(
        bind,
        table=DECISION_TABLE,
        legacy=(
            (("source_version_id",), VERSION_TABLE, ("version_id",)),
            (("candidate_entity_id",), ENTITY_TABLE, ("entity_id",)),
        ),
        target=(
            (
                DECISION_VERSION_FK,
                ("tenant_id", "source_version_id"),
                VERSION_TABLE,
                ("tenant_id", "version_id"),
            ),
            (
                DECISION_CANDIDATE_FK,
                ("tenant_id", "candidate_entity_id"),
                ENTITY_TABLE,
                ("tenant_id", "entity_id"),
            ),
        ),
    )


def _downgrade_foreign_keys(bind: sa.Connection) -> None:
    _replace_foreign_keys(
        bind,
        table=INDEX_TABLE,
        legacy=((("tenant_id", "entity_id"), ENTITY_TABLE, ("tenant_id", "entity_id")),),
        target=(
            (
                "entity_route_index_entity_fk",
                ("entity_id",),
                ENTITY_TABLE,
                ("entity_id",),
            ),
        ),
    )
    _replace_foreign_keys(
        bind,
        table=DECISION_TABLE,
        legacy=(
            (("tenant_id", "source_version_id"), VERSION_TABLE, ("tenant_id", "version_id")),
            (("tenant_id", "candidate_entity_id"), ENTITY_TABLE, ("tenant_id", "entity_id")),
        ),
        target=(
            (
                "entity_route_decision_version_fk",
                ("source_version_id",),
                VERSION_TABLE,
                ("version_id",),
            ),
            (
                "entity_route_decision_candidate_fk",
                ("candidate_entity_id",),
                ENTITY_TABLE,
                ("entity_id",),
            ),
        ),
    )


def upgrade() -> None:
    bind = op.get_bind()
    _ensure_entity_tenant_key(bind)
    _upgrade_foreign_keys(bind)


def downgrade() -> None:
    bind = op.get_bind()
    _downgrade_foreign_keys(bind)
    inspector = sa.inspect(bind)
    if not _has_unique_columns(inspector, ENTITY_TABLE, ("tenant_id", "entity_id")):
        return
    if bind.dialect.name == "sqlite":
        with op.batch_alter_table(ENTITY_TABLE) as batch:
            batch.drop_constraint(ENTITY_TENANT_KEY, type_="unique")
        return
    op.drop_constraint(ENTITY_TENANT_KEY, ENTITY_TABLE, type_="unique")
