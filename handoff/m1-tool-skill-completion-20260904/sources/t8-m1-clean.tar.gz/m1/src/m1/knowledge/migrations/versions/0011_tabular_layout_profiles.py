"""add governed reusable tabular layout profiles

Revision ID: 0011_tabular_layout_profiles
Revises: 0010_entity_route_tenant_fks
Create Date: 2026-07-28 10:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from m1.knowledge.db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    KNOWLEDGE_EMBEDDING_TYPE,
)

revision: str = "0011_tabular_layout_profiles"
down_revision: str | None = "0010_entity_route_tenant_fks"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

PROFILE_TABLE = "knowledge_tabular_layout_profiles"
OBSERVATION_TABLE = "knowledge_tabular_layout_observations"
TENANT_TABLES = (PROFILE_TABLE, OBSERVATION_TABLE)
POLICY_NAMES = {
    PROFILE_TABLE: "m1_tenant_isolation_tabular_layout_profiles",
    OBSERVATION_TABLE: "m1_tenant_isolation_tabular_layout_observations",
}
HNSW_INDEX = "ix_tabular_layout_profiles_embedding_hnsw"
EMBEDDING_SPACE_INDEX = "ix_tabular_layout_profiles_embedding_space"


def _create_profile_table() -> None:
    op.create_table(
        PROFILE_TABLE,
        sa.Column("profile_id", sa.String(length=128), nullable=False),
        sa.Column("profile_key", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("supersedes_profile_id", sa.String(length=128), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("exact_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("signature", sa.JSON(), nullable=False),
        sa.Column("plan", sa.JSON(), nullable=False),
        sa.Column("contract_revision", sa.String(length=128), nullable=False),
        sa.Column("interpreter_revision", sa.String(length=128), nullable=False),
        sa.Column("embedding", KNOWLEDGE_EMBEDDING_TYPE, nullable=True),
        sa.Column("embedding_model", sa.String(length=256), nullable=False),
        sa.Column("embedding_dimensions", sa.Integer(), nullable=False),
        sa.Column("created_by", sa.String(length=256), nullable=False),
        sa.Column("reviewed_by", sa.String(length=256), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("review_reason_codes", sa.JSON(), nullable=False),
        sa.Column("approved_by", sa.String(length=256), nullable=True),
        sa.Column("approved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("observation_count", sa.BigInteger(), nullable=False),
        sa.Column("success_count", sa.BigInteger(), nullable=False),
        sa.Column("failure_count", sa.BigInteger(), nullable=False),
        sa.Column("last_observed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_success_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_failure_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "version >= 1",
            name=op.f("ck_knowledge_tabular_layout_profiles_version_positive"),
        ),
        sa.CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')",
            name=op.f("ck_knowledge_tabular_layout_profiles_status"),
        ),
        sa.CheckConstraint(
            "observation_count >= 0 AND success_count >= 0 AND failure_count >= 0",
            name=op.f("ck_knowledge_tabular_layout_profiles_counts_nonnegative"),
        ),
        sa.CheckConstraint(
            "success_count + failure_count = observation_count",
            name=op.f("ck_knowledge_tabular_layout_profiles_counts_consistent"),
        ),
        sa.CheckConstraint(
            "embedding_dimensions >= 0",
            name=op.f(
                "ck_knowledge_tabular_layout_profiles_embedding_dimensions_nonnegative"
            ),
        ),
        sa.CheckConstraint(
            "(version = 1 AND supersedes_profile_id IS NULL) OR "
            "(version > 1 AND supersedes_profile_id IS NOT NULL)",
            name=op.f("ck_knowledge_tabular_layout_profiles_revision_predecessor"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f(
                "fk_knowledge_tabular_layout_profiles_tenant_id_knowledge_tenants"
            ),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "supersedes_profile_id"],
            [f"{PROFILE_TABLE}.tenant_id", f"{PROFILE_TABLE}.profile_id"],
            name="fk_tabular_layout_profile_supersedes_tenant",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "profile_id", name=op.f("pk_knowledge_tabular_layout_profiles")
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "profile_id",
            name="tabular_layout_profile_tenant_identity",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "profile_key",
            "version",
            name="tabular_layout_profile_version",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "supersedes_profile_id",
            name="tabular_layout_profile_single_successor",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "exact_fingerprint",
            "version",
            name="tabular_layout_profile_fingerprint_version",
        ),
    )
    op.create_index(
        "ix_tabular_layout_profiles_lookup",
        PROFILE_TABLE,
        ["tenant_id", "status", "profile_key", "version"],
    )
    op.create_index(
        "ix_tabular_layout_profiles_fingerprint",
        PROFILE_TABLE,
        ["tenant_id", "exact_fingerprint", "status"],
    )
    op.create_index(
        EMBEDDING_SPACE_INDEX,
        PROFILE_TABLE,
        ["tenant_id", "status", "embedding_model", "embedding_dimensions"],
    )
    op.create_index(
        "ux_tabular_layout_profiles_active_key",
        PROFILE_TABLE,
        ["tenant_id", "profile_key"],
        unique=True,
        sqlite_where=sa.text("status = 'active'"),
        postgresql_where=sa.text("status = 'active'"),
    )
    op.create_index(
        "ux_tabular_layout_profiles_active_fingerprint",
        PROFILE_TABLE,
        ["tenant_id", "exact_fingerprint"],
        unique=True,
        sqlite_where=sa.text("status = 'active'"),
        postgresql_where=sa.text("status = 'active'"),
    )
    for column in ("tenant_id", "status", "exact_fingerprint"):
        op.create_index(op.f(f"ix_{PROFILE_TABLE}_{column}"), PROFILE_TABLE, [column])


def _create_observation_table() -> None:
    op.create_table(
        OBSERVATION_TABLE,
        sa.Column("observation_id", sa.String(length=128), nullable=False),
        sa.Column("profile_id", sa.String(length=128), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("exact_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("outcome", sa.String(length=32), nullable=False),
        sa.Column("latency_ms", sa.Integer(), nullable=False),
        sa.Column("error_code", sa.String(length=128), nullable=False),
        sa.Column("summary", sa.JSON(), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "outcome IN ('success','failure')",
            name=op.f("ck_knowledge_tabular_layout_observations_outcome"),
        ),
        sa.CheckConstraint(
            "latency_ms >= 0",
            name=op.f("ck_knowledge_tabular_layout_observations_latency_nonnegative"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f(
                "fk_knowledge_tabular_layout_observations_tenant_id_knowledge_tenants"
            ),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "profile_id"],
            [f"{PROFILE_TABLE}.tenant_id", f"{PROFILE_TABLE}.profile_id"],
            name="fk_tabular_layout_observation_profile_tenant",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "observation_id", name=op.f("pk_knowledge_tabular_layout_observations")
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "idempotency_key",
            name="tabular_layout_observation_idempotency",
        ),
    )
    op.create_index(
        "ix_tabular_layout_observations_profile",
        OBSERVATION_TABLE,
        ["tenant_id", "profile_id", "observed_at"],
    )
    op.create_index(
        "ix_tabular_layout_observations_outcome",
        OBSERVATION_TABLE,
        ["tenant_id", "outcome", "observed_at"],
    )
    op.create_index(
        op.f(f"ix_{OBSERVATION_TABLE}_tenant_id"), OBSERVATION_TABLE, ["tenant_id"]
    )


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if not inspector.has_table(PROFILE_TABLE):
        _create_profile_table()
    if not sa.inspect(bind).has_table(OBSERVATION_TABLE):
        _create_observation_table()

    if bind.dialect.name != "postgresql":
        return
    op.execute(
        f"CREATE INDEX IF NOT EXISTS {HNSW_INDEX} ON {PROFILE_TABLE} "
        "USING hnsw (embedding vector_cosine_ops) "
        f"WHERE embedding IS NOT NULL AND embedding_dimensions = "
        f"{KNOWLEDGE_EMBEDDING_DIMENSIONS} AND embedding_model <> ''"
    )
    predicate = "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
    for table in TENANT_TABLES:
        op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" ON "{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in reversed(TENANT_TABLES):
            op.execute(f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{table}"')
            op.execute(f'ALTER TABLE "{table}" NO FORCE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
        op.execute(f"DROP INDEX IF EXISTS {HNSW_INDEX}")
    op.drop_table(OBSERVATION_TABLE)
    op.drop_table(PROFILE_TABLE)
