"""add governed field semantic routing profiles

Revision ID: 0012_field_semantic_routes
Revises: 0011_tabular_layout_profiles
Create Date: 2026-07-28 18:00:00
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from m1.knowledge.db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    KNOWLEDGE_EMBEDDING_TYPE,
)

revision: str = "0012_field_semantic_routes"
down_revision: str | None = "0011_tabular_layout_profiles"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

PROFILE_TABLE = "knowledge_field_semantic_profiles"
OBSERVATION_TABLE = "knowledge_field_semantic_observations"
LIFECYCLE_TABLE = "knowledge_route_lifecycle_events"
TENANT_TABLES = (PROFILE_TABLE, OBSERVATION_TABLE, LIFECYCLE_TABLE)
POLICY_NAMES = {
    PROFILE_TABLE: "m1_tenant_isolation_field_semantic_profiles",
    OBSERVATION_TABLE: "m1_tenant_isolation_field_semantic_observations",
    LIFECYCLE_TABLE: "m1_tenant_isolation_route_lifecycle_events",
}
HNSW_INDEX = "ix_field_semantic_profiles_embedding_hnsw"
EMBEDDING_SPACE_INDEX = "ix_field_semantic_profiles_embedding_space"


def _create_profile_table() -> None:
    op.create_table(
        PROFILE_TABLE,
        sa.Column("profile_id", sa.String(length=128), nullable=False),
        sa.Column("profile_key", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("supersedes_profile_id", sa.String(length=128), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("exact_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("signature", sa.JSON(), nullable=False),
        sa.Column("canonical_field_id", sa.String(length=128), nullable=True),
        sa.Column("contract_revision", sa.String(length=128), nullable=False),
        sa.Column("embedding", KNOWLEDGE_EMBEDDING_TYPE, nullable=True),
        sa.Column("embedding_model", sa.String(length=256), nullable=False),
        sa.Column("embedding_dimensions", sa.Integer(), nullable=False),
        sa.Column("created_by", sa.String(length=256), nullable=False),
        sa.Column("reviewed_by", sa.String(length=256), nullable=True),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("review_note", sa.Text(), nullable=False),
        sa.Column("approved_by", sa.String(length=256), nullable=True),
        sa.Column("approved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("observation_count", sa.BigInteger(), nullable=False),
        sa.Column("success_count", sa.BigInteger(), nullable=False),
        sa.Column("failure_count", sa.BigInteger(), nullable=False),
        sa.Column("last_observed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_success_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_failure_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "version >= 1",
            name=op.f("ck_knowledge_field_semantic_profiles_version_positive"),
        ),
        sa.CheckConstraint(
            "status IN ('candidate','active','deprecated','rejected')",
            name=op.f("ck_knowledge_field_semantic_profiles_status"),
        ),
        sa.CheckConstraint(
            "canonical_field_id IS NULL OR length(canonical_field_id) > 0",
            name=op.f("ck_knowledge_field_semantic_profiles_canonical_field_nonempty"),
        ),
        sa.CheckConstraint(
            "status <> 'active' OR (canonical_field_id IS NOT NULL "
            "AND reviewed_by IS NOT NULL AND length(reviewed_by) > 0 "
            "AND reviewed_at IS NOT NULL AND length(review_note) > 0 "
            "AND approved_by IS NOT NULL AND length(approved_by) > 0 "
            "AND approved_at IS NOT NULL "
            "AND lower(reviewed_by) <> lower(approved_by) "
            "AND success_count >= 3 AND failure_count = 0)",
            name=op.f("ck_knowledge_field_semantic_profiles_active_governance"),
        ),
        sa.CheckConstraint(
            "observation_count >= 0 AND success_count >= 0 AND failure_count >= 0",
            name=op.f("ck_knowledge_field_semantic_profiles_counts_nonnegative"),
        ),
        sa.CheckConstraint(
            "success_count + failure_count = observation_count",
            name=op.f("ck_knowledge_field_semantic_profiles_counts_consistent"),
        ),
        sa.CheckConstraint(
            "embedding_dimensions >= 0",
            name=op.f(
                "ck_knowledge_field_semantic_profiles_embedding_dimensions_nonnegative"
            ),
        ),
        sa.CheckConstraint(
            "(version = 1 AND supersedes_profile_id IS NULL) OR "
            "(version > 1 AND supersedes_profile_id IS NOT NULL)",
            name=op.f("ck_knowledge_field_semantic_profiles_revision_predecessor"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f(
                "fk_knowledge_field_semantic_profiles_tenant_id_knowledge_tenants"
            ),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "supersedes_profile_id"],
            [f"{PROFILE_TABLE}.tenant_id", f"{PROFILE_TABLE}.profile_id"],
            name="fk_field_semantic_profile_supersedes_tenant",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "profile_id", name=op.f("pk_knowledge_field_semantic_profiles")
        ),
        sa.UniqueConstraint(
            "tenant_id", "profile_id", name="field_semantic_profile_tenant_identity"
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "profile_key",
            "version",
            name="field_semantic_profile_version",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "supersedes_profile_id",
            name="field_semantic_profile_single_successor",
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "exact_fingerprint",
            "version",
            name="field_semantic_profile_fingerprint_version",
        ),
    )
    op.create_index(
        "ix_field_semantic_profiles_lookup",
        PROFILE_TABLE,
        ["tenant_id", "status", "profile_key", "version"],
    )
    op.create_index(
        "ix_field_semantic_profiles_fingerprint",
        PROFILE_TABLE,
        ["tenant_id", "exact_fingerprint", "status"],
    )
    op.create_index(
        EMBEDDING_SPACE_INDEX,
        PROFILE_TABLE,
        ["tenant_id", "status", "embedding_model", "embedding_dimensions"],
    )
    op.create_index(
        "ux_field_semantic_profiles_active_key",
        PROFILE_TABLE,
        ["tenant_id", "profile_key"],
        unique=True,
        sqlite_where=sa.text("status = 'active'"),
        postgresql_where=sa.text("status = 'active'"),
    )
    op.create_index(
        "ux_field_semantic_profiles_active_fingerprint",
        PROFILE_TABLE,
        ["tenant_id", "exact_fingerprint"],
        unique=True,
        sqlite_where=sa.text("status = 'active'"),
        postgresql_where=sa.text("status = 'active'"),
    )
    for column in ("tenant_id", "status", "exact_fingerprint"):
        op.create_index(op.f(f"ix_{PROFILE_TABLE}_{column}"), PROFILE_TABLE, [column])


def _create_observation_table() -> None:
    op.create_table(
        OBSERVATION_TABLE,
        sa.Column("observation_id", sa.String(length=128), nullable=False),
        sa.Column("profile_id", sa.String(length=128), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("exact_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("task_reference_hash", sa.String(length=64), nullable=False),
        sa.Column("outcome", sa.String(length=32), nullable=False),
        sa.Column("validation_passed", sa.Boolean(), nullable=False),
        sa.Column("reviewed_by", sa.String(length=256), nullable=False),
        sa.Column("review_note_sha256", sa.String(length=64), nullable=False),
        sa.Column("latency_ms", sa.Integer(), nullable=False),
        sa.Column("error_code", sa.String(length=128), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "outcome IN ('success','failure')",
            name=op.f("ck_knowledge_field_semantic_observations_outcome"),
        ),
        sa.CheckConstraint(
            "latency_ms >= 0",
            name=op.f("ck_knowledge_field_semantic_observations_latency_nonnegative"),
        ),
        sa.CheckConstraint(
            "outcome <> 'success' OR (validation_passed = true "
            "AND length(reviewed_by) > 0 AND length(review_note_sha256) = 64)",
            name=op.f("ck_knowledge_field_semantic_observations_success_reviewed"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f(
                "fk_knowledge_field_semantic_observations_tenant_id_knowledge_tenants"
            ),
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "profile_id"],
            [f"{PROFILE_TABLE}.tenant_id", f"{PROFILE_TABLE}.profile_id"],
            name="fk_field_semantic_observation_profile_tenant",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "observation_id", name=op.f("pk_knowledge_field_semantic_observations")
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "idempotency_key",
            name="field_semantic_observation_idempotency",
        ),
    )
    op.create_index(
        "ix_field_semantic_observations_profile",
        OBSERVATION_TABLE,
        ["tenant_id", "profile_id", "observed_at"],
    )
    op.create_index(
        "ix_field_semantic_observations_outcome",
        OBSERVATION_TABLE,
        ["tenant_id", "outcome", "observed_at"],
    )
    op.create_index(
        op.f(f"ix_{OBSERVATION_TABLE}_tenant_id"), OBSERVATION_TABLE, ["tenant_id"]
    )


def _create_lifecycle_table() -> None:
    op.create_table(
        LIFECYCLE_TABLE,
        sa.Column("event_id", sa.String(length=64), nullable=False),
        sa.Column("route_kind", sa.String(length=40), nullable=False),
        sa.Column("profile_id", sa.String(length=128), nullable=False),
        sa.Column("event_type", sa.String(length=32), nullable=False),
        sa.Column("actor_reference_sha256", sa.String(length=64), nullable=False),
        sa.Column(
            "counterparty_reference_sha256", sa.String(length=64), nullable=False
        ),
        sa.Column("reason_sha256", sa.String(length=64), nullable=False),
        sa.Column("observation_count", sa.BigInteger(), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.CheckConstraint(
            "route_kind IN ('field_semantic','visual_region',"
            "'region_capability','content_region')",
            name=op.f("ck_knowledge_route_lifecycle_events_route_kind"),
        ),
        sa.CheckConstraint(
            "event_type IN ('activated','rejected','deprecated',"
            "'superseded','auto_deprecated')",
            name=op.f("ck_knowledge_route_lifecycle_events_event_type"),
        ),
        sa.CheckConstraint(
            "length(actor_reference_sha256) = 64",
            name=op.f(
                "ck_knowledge_route_lifecycle_events_actor_reference_sha256_length"
            ),
        ),
        sa.CheckConstraint(
            "counterparty_reference_sha256 = '' OR "
            "length(counterparty_reference_sha256) = 64",
            name=op.f(
                "ck_knowledge_route_lifecycle_events_counterparty_reference_sha256_length"
            ),
        ),
        sa.CheckConstraint(
            "length(reason_sha256) = 64",
            name=op.f("ck_knowledge_route_lifecycle_events_reason_sha256_length"),
        ),
        sa.CheckConstraint(
            "observation_count >= 0",
            name=op.f("ck_knowledge_route_lifecycle_events_count_nonnegative"),
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name=op.f(
                "fk_knowledge_route_lifecycle_events_tenant_id_knowledge_tenants"
            ),
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "event_id", name=op.f("pk_knowledge_route_lifecycle_events")
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "idempotency_key",
            name="route_lifecycle_event_idempotency",
        ),
    )
    op.create_index(
        "ix_route_lifecycle_events_profile",
        LIFECYCLE_TABLE,
        ["tenant_id", "route_kind", "profile_id", "occurred_at"],
    )
    op.create_index(
        op.f(f"ix_{LIFECYCLE_TABLE}_tenant_id"), LIFECYCLE_TABLE, ["tenant_id"]
    )


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if not inspector.has_table(PROFILE_TABLE):
        _create_profile_table()
    if not sa.inspect(bind).has_table(OBSERVATION_TABLE):
        _create_observation_table()
    if not sa.inspect(bind).has_table(LIFECYCLE_TABLE):
        _create_lifecycle_table()

    if bind.dialect.name != "postgresql":
        return
    op.execute(
        f"CREATE INDEX IF NOT EXISTS {HNSW_INDEX} ON {PROFILE_TABLE} "
        "USING hnsw (embedding vector_cosine_ops) "
        f"WHERE embedding IS NOT NULL AND embedding_dimensions = "
        f"{KNOWLEDGE_EMBEDDING_DIMENSIONS} AND embedding_model <> ''"
    )
    predicate = "tenant_id = NULLIF(current_setting('m1.tenant_id', true), '')"
    for table in TENANT_TABLES:
        op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" ON "{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in reversed(TENANT_TABLES):
            op.execute(f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{table}"')
            op.execute(f'ALTER TABLE "{table}" NO FORCE ROW LEVEL SECURITY')
            op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
        op.execute(f"DROP INDEX IF EXISTS {HNSW_INDEX}")
    op.drop_table(LIFECYCLE_TABLE)
    op.drop_table(OBSERVATION_TABLE)
    op.drop_table(PROFILE_TABLE)
