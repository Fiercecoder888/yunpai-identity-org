"""add the governed cross-module business core schema

Revision ID: 0016_unified_business_core
Revises: 0015_content_region_routes
Create Date: 2026-08-04 16:00:00

The knowledge migrations remain executable against SQLite for local M1 tests.
The shared business core is deliberately PostgreSQL-only because it relies on
schemas, row-level security and cross-service transactional access.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0016_unified_business_core"
down_revision: str | None = "0015_content_region_routes"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"
TABLES = (
    "orders",
    "materials",
    "order_materials",
    "inventory_balances",
    "inventory_movements",
    "procurement_plans",
    "procurement_plan_lines",
    "purchase_orders",
    "schedule_versions",
    "business_flow_runs",
    "business_flow_steps",
    "integration_outbox",
)
POLICY_NAMES = {table: f"core_tenant_{table}" for table in TABLES}


def _timestamps() -> tuple[sa.Column, sa.Column]:
    return (
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
    )


def _tenant_identity(table: str, id_column: str) -> sa.UniqueConstraint:
    return sa.UniqueConstraint(
        "tenant_id",
        id_column,
        name=f"uq_core_{table}_tenant_id",
    )


def _create_tables() -> None:
    op.create_table(
        "orders",
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("order_number", sa.String(length=256), nullable=False),
        sa.Column("source_entity_id", sa.String(length=128), nullable=True),
        sa.Column("source_document_id", sa.String(length=128), nullable=True),
        sa.Column("source_version_id", sa.String(length=128), nullable=True),
        sa.Column("lifecycle_status", sa.String(length=32), nullable=False),
        sa.Column("currency", sa.String(length=16), nullable=True),
        sa.Column("required_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        *_timestamps(),
        sa.CheckConstraint("version >= 1", name="ck_core_orders_version"),
        sa.CheckConstraint(
            "lifecycle_status IN ('candidate','under_review','active','closed','cancelled','rejected')",
            name="ck_core_orders_status",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "order_id", name="pk_core_orders"),
        _tenant_identity("orders", "order_id"),
        sa.UniqueConstraint(
            "tenant_id", "order_number", name="uq_core_orders_number"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "materials",
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("material_code", sa.String(length=256), nullable=False),
        sa.Column("name", sa.String(length=512), nullable=False),
        sa.Column("unit", sa.String(length=32), nullable=False),
        sa.Column("lifecycle_status", sa.String(length=32), nullable=False),
        sa.Column("m1_entity_id", sa.String(length=128), nullable=True),
        sa.Column("m3_material_id", sa.String(length=128), nullable=True),
        sa.Column("m5_material_id", sa.String(length=128), nullable=True),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        *_timestamps(),
        sa.CheckConstraint("version >= 1", name="ck_core_materials_version"),
        sa.CheckConstraint(
            "lifecycle_status IN ('candidate','under_review','active','inactive','rejected')",
            name="ck_core_materials_status",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "material_id", name="pk_core_materials"),
        _tenant_identity("materials", "material_id"),
        sa.UniqueConstraint(
            "tenant_id", "material_code", name="uq_core_materials_code"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "order_materials",
        sa.Column("line_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("bom_version", sa.String(length=128), nullable=False),
        sa.Column("quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("unit", sa.String(length=32), nullable=False),
        sa.Column("source_module", sa.String(length=16), nullable=False),
        sa.Column("source_line_id", sa.String(length=128), nullable=True),
        sa.Column("evidence_ref", sa.String(length=512), nullable=True),
        sa.Column("lifecycle_status", sa.String(length=32), nullable=False),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        *_timestamps(),
        sa.CheckConstraint("quantity > 0", name="ck_core_order_material_qty"),
        sa.CheckConstraint(
            "lifecycle_status IN ('candidate','under_review','active','superseded','rejected')",
            name="ck_core_order_material_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_order_material_order",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_order_material_material",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "line_id", name="pk_core_order_materials"),
        _tenant_identity("order_materials", "line_id"),
        sa.UniqueConstraint(
            "tenant_id",
            "order_id",
            "bom_version",
            "material_id",
            "source_line_id",
            name="uq_core_order_material_source",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "inventory_balances",
        sa.Column("balance_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("location_id", sa.String(length=128), nullable=False),
        sa.Column("quantity_on_hand", sa.Numeric(20, 6), nullable=False),
        sa.Column("quantity_reserved", sa.Numeric(20, 6), nullable=False),
        sa.Column("quantity_available", sa.Numeric(20, 6), nullable=False),
        sa.Column("as_of_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("source_revision", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        *_timestamps(),
        sa.CheckConstraint(
            "quantity_on_hand >= 0 AND quantity_reserved >= 0 AND quantity_available >= 0",
            name="ck_core_inventory_nonnegative",
        ),
        sa.CheckConstraint(
            "quantity_available <= quantity_on_hand",
            name="ck_core_inventory_available",
        ),
        sa.CheckConstraint("version >= 1", name="ck_core_inventory_version"),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_inventory_material",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "balance_id", name="pk_core_inventory_balances"),
        _tenant_identity("inventory_balances", "balance_id"),
        sa.UniqueConstraint(
            "tenant_id",
            "material_id",
            "location_id",
            name="uq_core_inventory_location",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "inventory_movements",
        sa.Column("movement_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=True),
        sa.Column("movement_type", sa.String(length=32), nullable=False),
        sa.Column("quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("location_id", sa.String(length=128), nullable=False),
        sa.Column("source_module", sa.String(length=16), nullable=False),
        sa.Column("source_event_id", sa.String(length=128), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.CheckConstraint("quantity <> 0", name="ck_core_movement_quantity"),
        sa.CheckConstraint(
            "movement_type IN ('receipt','issue','reserve','release','adjustment','transfer')",
            name="ck_core_movement_type",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_movement_material",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_movement_order",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "movement_id", name="pk_core_inventory_movements"),
        _tenant_identity("inventory_movements", "movement_id"),
        sa.UniqueConstraint(
            "tenant_id", "source_module", "source_event_id", name="uq_core_movement_source"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "procurement_plans",
        sa.Column("plan_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("tracking_task_id", sa.String(length=128), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("calculated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("summary", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        *_timestamps(),
        sa.CheckConstraint("version >= 1", name="ck_core_plan_version"),
        sa.CheckConstraint(
            "status IN ('draft','calculated','approved','superseded','failed')",
            name="ck_core_plan_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_plan_order",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "plan_id", name="pk_core_procurement_plans"),
        _tenant_identity("procurement_plans", "plan_id"),
        sa.UniqueConstraint(
            "tenant_id", "idempotency_key", name="uq_core_plan_idempotency"
        ),
        sa.UniqueConstraint(
            "tenant_id", "order_id", "version", name="uq_core_plan_version"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "procurement_plan_lines",
        sa.Column("line_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("plan_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("demand_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("on_hand_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("open_po_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("shortage_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("recommended_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("required_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("calculation", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        *_timestamps(),
        sa.CheckConstraint(
            "demand_quantity >= 0 AND on_hand_quantity >= 0 AND open_po_quantity >= 0 "
            "AND shortage_quantity >= 0 AND recommended_quantity >= 0",
            name="ck_core_plan_line_nonnegative",
        ),
        sa.CheckConstraint(
            "status IN ('covered','shortage','ordered','cancelled')",
            name="ck_core_plan_line_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "plan_id"],
            [f"{SCHEMA}.procurement_plans.tenant_id", f"{SCHEMA}.procurement_plans.plan_id"],
            name="fk_core_plan_line_plan",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_plan_line_material",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "line_id", name="pk_core_procurement_plan_lines"),
        _tenant_identity("procurement_plan_lines", "line_id"),
        sa.UniqueConstraint(
            "tenant_id", "plan_id", "material_id", name="uq_core_plan_line_material"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "purchase_orders",
        sa.Column("purchase_order_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("purchase_order_number", sa.String(length=256), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("plan_line_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("supplier_id", sa.String(length=128), nullable=True),
        sa.Column("ordered_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("received_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("expected_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("source_module", sa.String(length=16), nullable=False),
        sa.Column("attributes", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        *_timestamps(),
        sa.CheckConstraint(
            "ordered_quantity > 0 AND received_quantity >= 0 "
            "AND received_quantity <= ordered_quantity",
            name="ck_core_purchase_order_qty",
        ),
        sa.CheckConstraint(
            "status IN ('draft','issued','confirmed','partial','received','cancelled','exception')",
            name="ck_core_purchase_order_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_purchase_order_order",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "plan_line_id"],
            [
                f"{SCHEMA}.procurement_plan_lines.tenant_id",
                f"{SCHEMA}.procurement_plan_lines.line_id",
            ],
            name="fk_core_purchase_order_plan_line",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_purchase_order_material",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "purchase_order_id", name="pk_core_purchase_orders"
        ),
        _tenant_identity("purchase_orders", "purchase_order_id"),
        sa.UniqueConstraint(
            "tenant_id",
            "purchase_order_number",
            "plan_line_id",
            name="uq_core_purchase_order_line",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "schedule_versions",
        sa.Column("schedule_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("tracking_task_id", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("scenario_type", sa.String(length=32), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("readiness_status", sa.String(length=32), nullable=False),
        sa.Column("source_schedule_id", sa.String(length=128), nullable=True),
        sa.Column("constraints_digest", sa.String(length=64), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("result_ref", sa.String(length=512), nullable=True),
        *_timestamps(),
        sa.CheckConstraint("version >= 1", name="ck_core_schedule_version"),
        sa.CheckConstraint(
            "scenario_type IN ('real','pressure_only')",
            name="ck_core_schedule_scenario",
        ),
        sa.CheckConstraint(
            "status IN ('blocked','draft','solved','released','superseded','failed')",
            name="ck_core_schedule_status",
        ),
        sa.CheckConstraint(
            "readiness_status IN ('unknown','not_ready','ready','exception')",
            name="ck_core_schedule_readiness",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_schedule_order",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "schedule_id", name="pk_core_schedule_versions"),
        _tenant_identity("schedule_versions", "schedule_id"),
        sa.UniqueConstraint(
            "tenant_id", "order_id", "version", name="uq_core_schedule_version"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "business_flow_runs",
        sa.Column("run_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("tracking_task_id", sa.String(length=128), nullable=False),
        sa.Column("requested_order_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("current_node", sa.String(length=64), nullable=False),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("request_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("input_ref", sa.String(length=512), nullable=True),
        sa.Column("result_summary", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("error", sa.JSON(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            "status IN ('queued','running','human_input_required','blocked','completed','failed')",
            name="ck_core_flow_run_status",
        ),
        sa.CheckConstraint(
            "mode IN ('real','pressure_only')", name="ck_core_flow_run_mode"
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_flow_run_order",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "run_id", name="pk_core_business_flow_runs"),
        _tenant_identity("business_flow_runs", "run_id"),
        sa.UniqueConstraint(
            "tenant_id", "tracking_task_id", name="uq_core_flow_tracking_task"
        ),
        sa.UniqueConstraint(
            "tenant_id", "request_fingerprint", name="uq_core_flow_fingerprint"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "business_flow_steps",
        sa.Column("step_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("run_id", sa.String(length=128), nullable=False),
        sa.Column("node_name", sa.String(length=64), nullable=False),
        sa.Column("attempt", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("input_ref", sa.String(length=512), nullable=True),
        sa.Column("output_ref", sa.String(length=512), nullable=True),
        sa.Column("output_summary", sa.JSON(), nullable=False, server_default=sa.text("'{}'")),
        sa.Column("error", sa.JSON(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        *_timestamps(),
        sa.CheckConstraint("attempt >= 1", name="ck_core_flow_step_attempt"),
        sa.CheckConstraint(
            "status IN ('running','completed','human_input_required','blocked','failed','skipped')",
            name="ck_core_flow_step_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "run_id"],
            [f"{SCHEMA}.business_flow_runs.tenant_id", f"{SCHEMA}.business_flow_runs.run_id"],
            name="fk_core_flow_step_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "step_id", name="pk_core_business_flow_steps"),
        _tenant_identity("business_flow_steps", "step_id"),
        sa.UniqueConstraint(
            "tenant_id", "run_id", "node_name", "attempt", name="uq_core_flow_step_attempt"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "integration_outbox",
        sa.Column("event_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("aggregate_type", sa.String(length=64), nullable=False),
        sa.Column("aggregate_id", sa.String(length=128), nullable=False),
        sa.Column("event_type", sa.String(length=128), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("available_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.CheckConstraint("attempts >= 0", name="ck_core_outbox_attempts"),
        sa.CheckConstraint(
            "status IN ('pending','publishing','published','failed')",
            name="ck_core_outbox_status",
        ),
        sa.PrimaryKeyConstraint("tenant_id", "event_id", name="pk_core_integration_outbox"),
        _tenant_identity("integration_outbox", "event_id"),
        sa.UniqueConstraint(
            "tenant_id", "idempotency_key", name="uq_core_outbox_idempotency"
        ),
        schema=SCHEMA,
    )

    for table, columns in {
        "orders": ("tenant_id", "lifecycle_status", "updated_at"),
        "materials": ("tenant_id", "lifecycle_status", "updated_at"),
        "order_materials": ("tenant_id", "order_id", "lifecycle_status"),
        "inventory_movements": ("tenant_id", "material_id", "occurred_at"),
        "procurement_plans": ("tenant_id", "order_id", "status"),
        "purchase_orders": ("tenant_id", "order_id", "status"),
        "schedule_versions": ("tenant_id", "order_id", "version"),
        "business_flow_runs": ("tenant_id", "status", "updated_at"),
        "business_flow_steps": ("tenant_id", "run_id", "started_at"),
        "integration_outbox": ("status", "available_at"),
    }.items():
        op.create_index(
            f"ix_core_{table}_lookup",
            table,
            list(columns),
            schema=SCHEMA,
        )


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    op.execute(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}"')
    inspector = sa.inspect(bind)
    if not inspector.has_table("orders", schema=SCHEMA):
        _create_tables()

    predicate = (
        "tenant_id = NULLIF(current_setting('yunpai.tenant_id', true), '')"
    )
    for table in TABLES:
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{SCHEMA}"."{table}"'
        )
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" '
            f'ON "{SCHEMA}"."{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    for table in reversed(TABLES):
        op.execute(
            f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" '
            f'ON "{SCHEMA}"."{table}"'
        )
        op.drop_table(table, schema=SCHEMA)
    op.execute(f'DROP SCHEMA IF EXISTS "{SCHEMA}"')
