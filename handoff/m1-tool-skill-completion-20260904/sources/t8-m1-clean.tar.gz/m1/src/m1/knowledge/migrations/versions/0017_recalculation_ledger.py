"""add immutable facts, qualified algorithms and recalculation ledgers

Revision ID: 0017_recalculation_ledger
Revises: 0016_unified_business_core
Create Date: 2026-08-05 10:30:00

The tables are PostgreSQL-only for the same reason as the unified business
core: tenant RLS, immutable audit triggers and cross-module transactions are
part of the contract. SQLite advances its Alembic revision without creating
these shared runtime tables.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0017_recalculation_ledger"
down_revision: str | None = "0016_unified_business_core"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"
TABLES = (
    "fact_versions",
    "algorithm_versions",
    "calculation_runs",
    "calculation_inputs",
    "validation_results",
    "supply_allocations",
    "recalculation_jobs",
    "recalculation_job_orders",
)
IMMUTABLE_TABLES = (
    "fact_versions",
    "algorithm_versions",
    "calculation_runs",
    "calculation_inputs",
    "validation_results",
    "supply_allocations",
)
POLICY_NAMES = {table: f"core_tenant_{table}" for table in TABLES}
IMMUTABLE_FUNCTION = "reject_immutable_ledger_mutation"


def _created_at() -> sa.Column:
    return sa.Column(
        "created_at",
        sa.DateTime(timezone=True),
        nullable=False,
        server_default=sa.text("CURRENT_TIMESTAMP"),
    )


def _timestamps() -> tuple[sa.Column, sa.Column]:
    return (
        _created_at(),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
    )


def _create_tables() -> None:
    op.create_table(
        "fact_versions",
        sa.Column("fact_version_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("fact_type", sa.String(length=32), nullable=False),
        sa.Column("aggregate_type", sa.String(length=64), nullable=False),
        sa.Column("aggregate_id", sa.String(length=128), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("source_module", sa.String(length=32), nullable=False),
        sa.Column("source_event_id", sa.String(length=256), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("effective_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("payload_digest", sa.String(length=64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("validation", sa.JSON(), nullable=False),
        sa.Column("supersedes_fact_version_id", sa.String(length=128), nullable=True),
        _created_at(),
        sa.CheckConstraint("version >= 1", name="ck_core_fact_version"),
        sa.CheckConstraint(
            "fact_type IN ('order','bom','inventory','procurement','consumption','business_request')",
            name="ck_core_fact_type",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "supersedes_fact_version_id"],
            [
                f"{SCHEMA}.fact_versions.tenant_id",
                f"{SCHEMA}.fact_versions.fact_version_id",
            ],
            name="fk_core_fact_supersedes",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "fact_version_id", name="pk_core_fact_versions"
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "aggregate_type",
            "aggregate_id",
            "version",
            name="uq_core_fact_aggregate_version",
        ),
        sa.UniqueConstraint(
            "tenant_id", "source_module", "source_event_id", name="uq_core_fact_source"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "algorithm_versions",
        sa.Column("algorithm_version_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("module", sa.String(length=32), nullable=False),
        sa.Column("algorithm_name", sa.String(length=128), nullable=False),
        sa.Column("semantic_version", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("code_digest", sa.String(length=64), nullable=False),
        sa.Column("specification_digest", sa.String(length=64), nullable=False),
        sa.Column("qualification_evidence", sa.JSON(), nullable=False),
        sa.Column("qualified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("valid_from", sa.DateTime(timezone=True), nullable=False),
        sa.Column("valid_to", sa.DateTime(timezone=True), nullable=True),
        _created_at(),
        sa.CheckConstraint(
            "status IN ('candidate','qualified','retired','rejected')",
            name="ck_core_algorithm_status",
        ),
        sa.CheckConstraint(
            "(status = 'qualified' AND qualified_at IS NOT NULL) OR status <> 'qualified'",
            name="ck_core_algorithm_qualified_at",
        ),
        sa.CheckConstraint(
            "valid_to IS NULL OR valid_to > valid_from",
            name="ck_core_algorithm_valid_range",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "algorithm_version_id", name="pk_core_algorithm_versions"
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "module",
            "algorithm_name",
            "semantic_version",
            name="uq_core_algorithm_semver",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "calculation_runs",
        sa.Column("calculation_run_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("calculation_type", sa.String(length=32), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=True),
        sa.Column("trigger_fact_version_id", sa.String(length=128), nullable=True),
        sa.Column("algorithm_version_id", sa.String(length=128), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("input_digest", sa.String(length=64), nullable=False),
        sa.Column("result_digest", sa.String(length=64), nullable=True),
        sa.Column("result", sa.JSON(), nullable=True),
        sa.Column("replay_of_run_id", sa.String(length=128), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            "calculation_type IN ('mrp','allocation','readiness','schedule')",
            name="ck_core_calculation_type",
        ),
        sa.CheckConstraint(
            "status IN ('queued','running','validated','published','rejected','failed')",
            name="ck_core_calculation_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_calculation_order",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "trigger_fact_version_id"],
            [
                f"{SCHEMA}.fact_versions.tenant_id",
                f"{SCHEMA}.fact_versions.fact_version_id",
            ],
            name="fk_core_calculation_trigger_fact",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "algorithm_version_id"],
            [
                f"{SCHEMA}.algorithm_versions.tenant_id",
                f"{SCHEMA}.algorithm_versions.algorithm_version_id",
            ],
            name="fk_core_calculation_algorithm",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "replay_of_run_id"],
            [
                f"{SCHEMA}.calculation_runs.tenant_id",
                f"{SCHEMA}.calculation_runs.calculation_run_id",
            ],
            name="fk_core_calculation_replay",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "calculation_run_id", name="pk_core_calculation_runs"
        ),
        sa.UniqueConstraint(
            "tenant_id", "idempotency_key", name="uq_core_calculation_idempotency"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "calculation_inputs",
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("calculation_run_id", sa.String(length=128), nullable=False),
        sa.Column("fact_version_id", sa.String(length=128), nullable=False),
        sa.Column("input_role", sa.String(length=64), nullable=False),
        _created_at(),
        sa.ForeignKeyConstraint(
            ["tenant_id", "calculation_run_id"],
            [
                f"{SCHEMA}.calculation_runs.tenant_id",
                f"{SCHEMA}.calculation_runs.calculation_run_id",
            ],
            name="fk_core_calculation_input_run",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "fact_version_id"],
            [
                f"{SCHEMA}.fact_versions.tenant_id",
                f"{SCHEMA}.fact_versions.fact_version_id",
            ],
            name="fk_core_calculation_input_fact",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id",
            "calculation_run_id",
            "fact_version_id",
            "input_role",
            name="pk_core_calculation_inputs",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "validation_results",
        sa.Column("validation_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("calculation_run_id", sa.String(length=128), nullable=False),
        sa.Column("validator_id", sa.String(length=128), nullable=False),
        sa.Column("validator_version", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("input_digest", sa.String(length=64), nullable=False),
        sa.Column("result_digest", sa.String(length=64), nullable=False),
        sa.Column("checks", sa.JSON(), nullable=False),
        sa.Column("validated_at", sa.DateTime(timezone=True), nullable=False),
        _created_at(),
        sa.CheckConstraint(
            "status IN ('passed','failed')", name="ck_core_validation_status"
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "calculation_run_id"],
            [
                f"{SCHEMA}.calculation_runs.tenant_id",
                f"{SCHEMA}.calculation_runs.calculation_run_id",
            ],
            name="fk_core_validation_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "validation_id", name="pk_core_validation_results"
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "calculation_run_id",
            "validator_id",
            "validator_version",
            name="uq_core_validation_once",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "supply_allocations",
        sa.Column("allocation_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("calculation_run_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("material_id", sa.String(length=128), nullable=False),
        sa.Column("supply_type", sa.String(length=32), nullable=False),
        sa.Column("supply_ref_id", sa.String(length=128), nullable=False),
        sa.Column("allocated_quantity", sa.Numeric(20, 6), nullable=False),
        sa.Column("required_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("allocation_status", sa.String(length=32), nullable=False),
        _created_at(),
        sa.CheckConstraint(
            "allocated_quantity > 0", name="ck_core_allocation_quantity"
        ),
        sa.CheckConstraint(
            "supply_type IN ('inventory','open_po')",
            name="ck_core_allocation_supply_type",
        ),
        sa.CheckConstraint(
            "allocation_status IN ('proposed','validated','published','released')",
            name="ck_core_allocation_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "calculation_run_id"],
            [
                f"{SCHEMA}.calculation_runs.tenant_id",
                f"{SCHEMA}.calculation_runs.calculation_run_id",
            ],
            name="fk_core_allocation_run",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_allocation_order",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "material_id"],
            [f"{SCHEMA}.materials.tenant_id", f"{SCHEMA}.materials.material_id"],
            name="fk_core_allocation_material",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "allocation_id", name="pk_core_supply_allocations"
        ),
        sa.UniqueConstraint(
            "tenant_id",
            "calculation_run_id",
            "order_id",
            "material_id",
            "supply_type",
            "supply_ref_id",
            name="uq_core_allocation_source",
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "recalculation_jobs",
        sa.Column("job_id", sa.String(length=128), nullable=False),
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("trigger_fact_version_id", sa.String(length=128), nullable=False),
        sa.Column("idempotency_key", sa.String(length=256), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("reason", sa.String(length=512), nullable=False),
        sa.Column("affected_order_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("completed_order_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("failed_order_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.JSON(), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            "status IN ('queued','running','completed','partial','failed')",
            name="ck_core_recalculation_status",
        ),
        sa.CheckConstraint(
            "affected_order_count >= 0 AND completed_order_count >= 0 AND failed_order_count >= 0",
            name="ck_core_recalculation_counts",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "trigger_fact_version_id"],
            [
                f"{SCHEMA}.fact_versions.tenant_id",
                f"{SCHEMA}.fact_versions.fact_version_id",
            ],
            name="fk_core_recalculation_trigger",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "job_id", name="pk_core_recalculation_jobs"
        ),
        sa.UniqueConstraint(
            "tenant_id", "idempotency_key", name="uq_core_recalculation_idempotency"
        ),
        schema=SCHEMA,
    )

    op.create_table(
        "recalculation_job_orders",
        sa.Column("tenant_id", sa.String(length=128), nullable=False),
        sa.Column("job_id", sa.String(length=128), nullable=False),
        sa.Column("order_id", sa.String(length=128), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("impact_path", sa.JSON(), nullable=False),
        sa.Column("calculation_run_id", sa.String(length=128), nullable=True),
        sa.Column("procurement_plan_id", sa.String(length=128), nullable=True),
        sa.Column("schedule_id", sa.String(length=128), nullable=True),
        sa.Column("error", sa.JSON(), nullable=True),
        *_timestamps(),
        sa.CheckConstraint(
            "status IN ('queued','running','completed','blocked','failed','skipped')",
            name="ck_core_recalculation_order_status",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "job_id"],
            [f"{SCHEMA}.recalculation_jobs.tenant_id", f"{SCHEMA}.recalculation_jobs.job_id"],
            name="fk_core_recalculation_order_job",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "order_id"],
            [f"{SCHEMA}.orders.tenant_id", f"{SCHEMA}.orders.order_id"],
            name="fk_core_recalculation_order",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "calculation_run_id"],
            [
                f"{SCHEMA}.calculation_runs.tenant_id",
                f"{SCHEMA}.calculation_runs.calculation_run_id",
            ],
            name="fk_core_recalculation_calculation",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "procurement_plan_id"],
            [f"{SCHEMA}.procurement_plans.tenant_id", f"{SCHEMA}.procurement_plans.plan_id"],
            name="fk_core_recalculation_plan",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["tenant_id", "schedule_id"],
            [f"{SCHEMA}.schedule_versions.tenant_id", f"{SCHEMA}.schedule_versions.schedule_id"],
            name="fk_core_recalculation_schedule",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint(
            "tenant_id", "job_id", "order_id", name="pk_core_recalculation_job_orders"
        ),
        schema=SCHEMA,
    )

    for table, columns in {
        "fact_versions": ("tenant_id", "fact_type", "aggregate_id", "version"),
        "algorithm_versions": ("tenant_id", "module", "algorithm_name", "status"),
        "calculation_runs": ("tenant_id", "order_id", "calculation_type", "created_at"),
        "calculation_inputs": ("tenant_id", "fact_version_id"),
        "validation_results": ("tenant_id", "calculation_run_id", "status"),
        "supply_allocations": ("tenant_id", "material_id", "order_id"),
        "recalculation_jobs": ("tenant_id", "status", "created_at"),
        "recalculation_job_orders": ("tenant_id", "order_id", "status"),
    }.items():
        op.create_index(
            f"ix_core_{table}_lookup", table, list(columns), schema=SCHEMA
        )


def _create_immutability_triggers() -> None:
    op.execute(
        f"""
        CREATE OR REPLACE FUNCTION "{SCHEMA}"."{IMMUTABLE_FUNCTION}"()
        RETURNS trigger
        LANGUAGE plpgsql
        AS $$
        BEGIN
            RAISE EXCEPTION 'immutable ledger table % cannot be updated or deleted', TG_TABLE_NAME
                USING ERRCODE = '55000';
        END;
        $$
        """
    )
    for table in IMMUTABLE_TABLES:
        op.execute(
            f'CREATE TRIGGER "trg_core_{table}_immutable" '
            f'BEFORE UPDATE OR DELETE ON "{SCHEMA}"."{table}" '
            f'FOR EACH ROW EXECUTE FUNCTION "{SCHEMA}"."{IMMUTABLE_FUNCTION}"()'
        )


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    inspector = sa.inspect(bind)
    if not inspector.has_table("fact_versions", schema=SCHEMA):
        _create_tables()
        _create_immutability_triggers()

    predicate = "tenant_id = NULLIF(current_setting('yunpai.tenant_id', true), '')"
    for table in TABLES:
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{SCHEMA}"."{table}"'
        )
        op.execute(
            f'CREATE POLICY "{POLICY_NAMES[table]}" '
            f'ON "{SCHEMA}"."{table}" '
            f"USING ({predicate}) WITH CHECK ({predicate})"
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    for table in reversed(TABLES):
        op.execute(
            f'DROP POLICY IF EXISTS "{POLICY_NAMES[table]}" ON "{SCHEMA}"."{table}"'
        )
        op.drop_table(table, schema=SCHEMA)
    op.execute(
        f'DROP FUNCTION IF EXISTS "{SCHEMA}"."{IMMUTABLE_FUNCTION}"()'
    )
