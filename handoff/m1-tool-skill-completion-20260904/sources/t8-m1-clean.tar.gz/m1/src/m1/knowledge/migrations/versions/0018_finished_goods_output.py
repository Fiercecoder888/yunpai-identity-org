"""add finished-goods product identity and production output fact support

Revision ID: 0018_finished_goods_output
Revises: 0017_recalculation_ledger
Create Date: 2026-08-05 15:00:00

PostgreSQL-only additive changes (same contract as 0016/0017):
- ``orders.product_id`` (nullable FK -> ``materials``): authoritative
  finished-product identity per order, so a ``production_output`` fact can be
  credited to the finished-goods inventory location of that order.
- ``inventory_movements.movement_type`` gains ``produced`` (完工入库), keeping
  the unified inventory ledger for raw/consumed/finished stocks.
- ``fact_versions.fact_type`` gains ``production_output`` (产出事实).

SQLite advances the Alembic revision without applying these DDL changes.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0018_finished_goods_output"
down_revision: str | None = "0017_recalculation_ledger"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"

PRODUCT_FK_NAME = "fk_core_orders_product"
MOVEMENT_TYPE_CHECK_NAME = "ck_core_movement_type"
FACT_TYPE_CHECK_NAME = "ck_core_fact_type"

MOVEMENT_TYPES_BASE = (
    "'receipt','issue','reserve','release','adjustment','transfer'"
)
FACT_TYPES_BASE = (
    "'order','bom','inventory','procurement','consumption','business_request'"
)


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    op.add_column(
        "orders",
        sa.Column("product_id", sa.String(length=128), nullable=True),
        schema=SCHEMA,
    )
    op.create_foreign_key(
        PRODUCT_FK_NAME,
        "orders",
        "materials",
        ["tenant_id", "product_id"],
        ["tenant_id", "material_id"],
        source_schema=SCHEMA,
        referent_schema=SCHEMA,
        ondelete="RESTRICT",
    )

    op.drop_constraint(
        MOVEMENT_TYPE_CHECK_NAME, "inventory_movements", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        f"movement_type IN ({MOVEMENT_TYPES_BASE},'produced')",
        schema=SCHEMA,
    )

    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE},'production_output')",
        schema=SCHEMA,
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE})",
        schema=SCHEMA,
    )

    op.drop_constraint(
        MOVEMENT_TYPE_CHECK_NAME, "inventory_movements", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        f"movement_type IN ({MOVEMENT_TYPES_BASE})",
        schema=SCHEMA,
    )

    op.drop_constraint(
        PRODUCT_FK_NAME, "orders", type_="foreignkey", schema=SCHEMA
    )
    op.drop_column("orders", "product_id", schema=SCHEMA)
