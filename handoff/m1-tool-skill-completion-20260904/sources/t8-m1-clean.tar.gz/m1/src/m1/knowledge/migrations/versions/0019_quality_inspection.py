"""add quality inspection fact support and blocked inventory quantity

Revision ID: 0019_quality_inspection
Revises: 0018_finished_goods_output
Create Date: 2026-08-05 18:00:00

PostgreSQL-only additive changes (same contract as 0016/0017/0018):
- ``fact_versions.fact_type`` gains ``inspection`` (质检事实): a finished
  output or purchase receipt enters inspection and only becomes available
  stock after a ``pass``; ``fail`` keeps the quantity blocked.
- ``inventory_balances.quantity_blocked`` (待检/冻结量): produced/received
  stock starts as blocked; ``available + blocked <= on_hand`` is enforced so
  quality-gated stock can never be consumed.
- ``inventory_movements.movement_type`` gains ``inspection`` for the
  inspection result ledger.

SQLite advances the Alembic revision without applying these DDL changes.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0019_quality_inspection"
down_revision: str | None = "0018_finished_goods_output"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"

FACT_TYPE_CHECK_NAME = "ck_core_fact_type"
MOVEMENT_TYPE_CHECK_NAME = "ck_core_movement_type"
INVENTORY_NONNEGATIVE_CHECK_NAME = "ck_core_inventory_nonnegative"
INVENTORY_AVAILABLE_CHECK_NAME = "ck_core_inventory_available"

FACT_TYPES_BASE = (
    "'order','bom','inventory','procurement','consumption',"
    "'business_request','production_output'"
)
MOVEMENT_TYPES_BASE = (
    "'receipt','issue','reserve','release','adjustment','transfer','produced'"
)


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    op.add_column(
        "inventory_balances",
        sa.Column(
            "quantity_blocked",
            sa.Numeric(20, 6),
            nullable=False,
            server_default="0",
        ),
        schema=SCHEMA,
    )
    op.drop_constraint(
        INVENTORY_NONNEGATIVE_CHECK_NAME,
        "inventory_balances",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        INVENTORY_NONNEGATIVE_CHECK_NAME,
        "inventory_balances",
        "quantity_on_hand >= 0 AND quantity_reserved >= 0 "
        "AND quantity_available >= 0 AND quantity_blocked >= 0",
        schema=SCHEMA,
    )
    op.drop_constraint(
        INVENTORY_AVAILABLE_CHECK_NAME,
        "inventory_balances",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        INVENTORY_AVAILABLE_CHECK_NAME,
        "inventory_balances",
        "quantity_available + quantity_blocked <= quantity_on_hand",
        schema=SCHEMA,
    )

    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE},'inspection')",
        schema=SCHEMA,
    )
    op.drop_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        f"movement_type IN ({MOVEMENT_TYPES_BASE},'inspection')",
        schema=SCHEMA,
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return

    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE})",
        schema=SCHEMA,
    )
    op.drop_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        MOVEMENT_TYPE_CHECK_NAME,
        "inventory_movements",
        f"movement_type IN ({MOVEMENT_TYPES_BASE})",
        schema=SCHEMA,
    )

    op.drop_constraint(
        INVENTORY_AVAILABLE_CHECK_NAME,
        "inventory_balances",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        INVENTORY_AVAILABLE_CHECK_NAME,
        "inventory_balances",
        "quantity_available <= quantity_on_hand",
        schema=SCHEMA,
    )
    op.drop_constraint(
        INVENTORY_NONNEGATIVE_CHECK_NAME,
        "inventory_balances",
        type_="check",
        schema=SCHEMA,
    )
    op.create_check_constraint(
        INVENTORY_NONNEGATIVE_CHECK_NAME,
        "inventory_balances",
        "quantity_on_hand >= 0 AND quantity_reserved >= 0 "
        "AND quantity_available >= 0",
        schema=SCHEMA,
    )
    op.drop_column("inventory_balances", "quantity_blocked", schema=SCHEMA)
