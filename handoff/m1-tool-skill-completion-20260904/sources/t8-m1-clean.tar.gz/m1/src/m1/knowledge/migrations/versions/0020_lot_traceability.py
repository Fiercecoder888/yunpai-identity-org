"""add lot/batch traceability to inventory movements

Revision ID: 0020_lot_traceability
Revises: 0019_quality_inspection
Create Date: 2026-08-05 19:00:00

PostgreSQL-only additive change: ``inventory_movements.lot_id`` (nullable)
carries the supplier/WMS lot for receipts and issues and the finished batch
for produced output. Lot-level balances are derived from movements (receipts
minus issues per lot) so there is a single auditable source of truth; the
material trace endpoint joins lots -> orders -> finished batches.

SQLite advances the Alembic revision without applying these DDL changes.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0020_lot_traceability"
down_revision: str | None = "0019_quality_inspection"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.add_column(
        "inventory_movements",
        sa.Column("lot_id", sa.String(length=128), nullable=True),
        schema=SCHEMA,
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.drop_column("inventory_movements", "lot_id", schema=SCHEMA)
