"""add purchase receipt fact support

Revision ID: 0021_receipt_flow
Revises: 0020_lot_traceability
Create Date: 2026-08-05 20:00:00

PostgreSQL-only additive change: ``fact_versions.fact_type`` gains
``receipt`` (采购收货). A receipt credits on-hand and blocked (待检) stock;
the existing inspection flow (source ``purchase_receipt``) then releases to
available. The ``receipt`` inventory movement type already exists in the base
constraint.

SQLite advances the Alembic revision without applying these DDL changes.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0021_receipt_flow"
down_revision: str | None = "0020_lot_traceability"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"
FACT_TYPE_CHECK_NAME = "ck_core_fact_type"
FACT_TYPES_BASE = (
    "'order','bom','inventory','procurement','consumption',"
    "'business_request','production_output','inspection'"
)


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE},'receipt')",
        schema=SCHEMA,
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.drop_constraint(
        FACT_TYPE_CHECK_NAME, "fact_versions", type_="check", schema=SCHEMA
    )
    op.create_check_constraint(
        FACT_TYPE_CHECK_NAME,
        "fact_versions",
        f"fact_type IN ({FACT_TYPES_BASE})",
        schema=SCHEMA,
    )
