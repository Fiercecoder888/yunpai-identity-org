"""persist business flow request payload for resume

Revision ID: 0022_flow_request_persistence
Revises: 0021_receipt_flow
Create Date: 2026-08-05 21:00:00

PostgreSQL-only additive change: ``business_flow_runs.request`` (JSONB, NULL)
stores the submitted flow request so a gated run (human_input_required /
blocked) can be resumed by re-driving the same run with its stored request
after the operator supplements module data (e.g. material matching).

SQLite advances the Alembic revision without applying these DDL changes.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0022_flow_request_persistence"
down_revision: str | None = "0021_receipt_flow"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "yunpai_core"


def upgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.add_column(
        "business_flow_runs",
        sa.Column("request", sa.JSON(), nullable=True),
        schema=SCHEMA,
    )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name != "postgresql":
        return
    op.drop_column("business_flow_runs", "request", schema=SCHEMA)
