"""Dependency-light contracts for M1 knowledge and graph projections.

These models are deliberately storage agnostic.  M1 owns extraction and evidence;
the Wiki/search/graph stores can persist these projections without becoming a
second source of truth.
"""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from m1.documents.models import SourceReference

KnowledgeStatus = Literal["candidate", "active", "deprecated", "rejected"]
ClaimOrigin = Literal[
    "source",
    "deterministic_inference",
    "deterministic_calculation",
    "semantic",
]


class KnowledgeModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class KnowledgeSource(KnowledgeModel):
    source_record_id: str
    original_filename: str
    display_filename: str | None = None
    sha256: str = ""
    mime_type: str = "application/octet-stream"
    archive_path: str | None = None


class FieldClaim(KnowledgeModel):
    """A versioned assertion with evidence, never an in-place field update."""

    claim_id: str
    tenant_id: str
    record_id: str
    source_record_id: str
    version: str
    path: str
    value: Any
    value_type: str
    origin: ClaimOrigin
    fact_locked: bool
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: KnowledgeStatus = "active"
    inferred: bool = False
    source_refs: list[SourceReference] = Field(default_factory=list)


class KnowledgeRecord(KnowledgeModel):
    record_id: str
    tenant_id: str
    record_type: Literal["document", "document_line"]
    document_type: str
    document_subtype: str
    canonical_key: str
    source_path: str
    source: KnowledgeSource
    version: str
    status: KnowledgeStatus
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    facts: dict[str, Any] = Field(default_factory=dict)
    semantic_annotations: dict[str, Any] = Field(default_factory=dict)
    claims: list[FieldClaim] = Field(default_factory=list)
    source_refs: list[SourceReference] = Field(default_factory=list)


class KnowledgeChunk(KnowledgeModel):
    chunk_id: str
    tenant_id: str
    record_id: str
    source_record_id: str
    version: str
    chunk_kind: Literal["header", "line", "generic_fact", "evidence", "page"]
    ordinal: int = 0
    text: str
    content_sha256: str
    field_paths: list[str] = Field(default_factory=list)
    claim_ids: list[str] = Field(default_factory=list)
    source_refs: list[SourceReference] = Field(default_factory=list)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: KnowledgeStatus = "active"
    metadata: dict[str, Any] = Field(default_factory=dict)


class FieldIndexDocument(KnowledgeModel):
    """Small allow-listed search projection, not a flattened copy of the JSON."""

    index_id: str
    tenant_id: str
    record_id: str
    source_record_id: str
    version: str
    document_type: str
    document_subtype: str
    status: KnowledgeStatus
    text: str
    vector_text: str
    selected_fields: dict[str, Any] = Field(default_factory=dict)
    graph_keys: list[str] = Field(default_factory=list)
    source_refs: list[SourceReference] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class GraphNode(KnowledgeModel):
    node_id: str
    labels: list[str]
    tenant_id: str
    source_record_id: str
    version: str
    status: KnowledgeStatus
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    source_refs: list[SourceReference] = Field(default_factory=list)
    source_claim_ids: list[str] = Field(default_factory=list)
    properties: dict[str, Any] = Field(default_factory=dict)


class GraphEdge(KnowledgeModel):
    edge_id: str
    relation: str
    from_node: str
    to_node: str
    tenant_id: str
    source_record_id: str
    version: str
    status: KnowledgeStatus
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    source_refs: list[SourceReference] = Field(default_factory=list)
    source_claim_ids: list[str] = Field(default_factory=list)
    properties: dict[str, Any] = Field(default_factory=dict)


class GraphProjection(KnowledgeModel):
    projection_id: str
    tenant_id: str
    source_record_id: str
    version: str
    generation: int = Field(default=0, ge=0)
    nodes: list[GraphNode] = Field(default_factory=list)
    edges: list[GraphEdge] = Field(default_factory=list)


class SearchHit(KnowledgeModel):
    index_id: str
    record_id: str
    score: float
    keyword_score: float
    vector_score: float
    graph_score: float
    match_reason: Literal["exact_identifier", "keyword", "vector", "graph"] = "keyword"
    document: FieldIndexDocument


class SemanticMergeResult(KnowledgeModel):
    document: dict[str, Any]
    applied_paths: list[str] = Field(default_factory=list)
    rejected_paths: list[str] = Field(default_factory=list)


__all__ = [
    "FieldClaim",
    "FieldIndexDocument",
    "GraphEdge",
    "GraphNode",
    "GraphProjection",
    "KnowledgeChunk",
    "KnowledgeRecord",
    "KnowledgeSource",
    "SearchHit",
    "SemanticMergeResult",
]
