"""Efficient, durable delivery for governed knowledge projection events."""

from __future__ import annotations

import asyncio
import logging
from collections import OrderedDict
from datetime import datetime, timedelta
from typing import Any

from pydantic import BaseModel, ConfigDict

from .outbox_repository import LIGHTRAG_MAX_LEASE_SECONDS
from .persistence import RecordNotFoundError
from .schema import ProjectionEventRecord, utc_now

LIFECYCLE_WAIT_DEADLINE_SECONDS = 30 * 60
LIFECYCLE_WAIT_RETRY_SECONDS = 15
GRAPH_MATERIALIZATION_WAIT_DEADLINE_SECONDS = 120
EXTERNAL_PROJECTION_LEASE_SECONDS = 5 * 60
LIGHTRAG_PROJECTION_LEASE_SECONDS = LIGHTRAG_MAX_LEASE_SECONDS
_LIFECYCLE_STARTED_PREFIX = "lifecycle_wait_since="
_ORDINARY_FAILURES_PREFIX = "ordinary_failures="
_PROJECTION_LEASE_CAPS = {
    "embedding": 1,
    "graph": 10,
    "lightrag_shadow": 1,
}
_PROJECTION_DRAIN_CAPS = {
    "embedding": 10,
    "graph": 10,
    "lightrag_shadow": 10,
}


class _GraphProjectionLifecycleWaitError(RuntimeError):
    """A relationship event committed before its graph snapshot is visible."""

    retryable = True
    lifecycle_wait = True
    lifecycle_deadline_seconds = GRAPH_MATERIALIZATION_WAIT_DEADLINE_SECONDS


class OutboxDrainResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tenant_id: str | None = None
    leased: int = 0
    delivered: int = 0
    retried: int = 0
    lifecycle_waits: int = 0
    terminal_failures: int = 0


_LOCAL_ACK_PROJECTIONS = {
    "knowledge",
    "search",
    "search_staging",
    "graph_staging",
}


def _relationship_event(event: ProjectionEventRecord) -> bool:
    return (
        event.aggregate_type == "relationship_claim"
        and event.event_type
        in {
            "relationship.claimed",
            "relationship.accepted",
        }
    )


def _relationship_key(event: ProjectionEventRecord) -> tuple[str, str, str]:
    source_record_id = str(event.payload.get("source_record_id") or "")
    version = str(event.payload.get("version") or "")
    if not source_record_id or not version:
        return event.tenant_id, f"missing:{event.event_id}", ""
    return event.tenant_id, source_record_id, version


def _graph_delivery_units(
    events: list[ProjectionEventRecord],
) -> list[list[ProjectionEventRecord]]:
    """Coalesce relationship notifications without crossing lifecycle barriers."""

    units: list[list[ProjectionEventRecord]] = []
    relationship_run: list[ProjectionEventRecord] = []

    def flush() -> None:
        if not relationship_run:
            return
        grouped: OrderedDict[tuple[str, str, str], list[ProjectionEventRecord]] = (
            OrderedDict()
        )
        for item in relationship_run:
            grouped.setdefault(_relationship_key(item), []).append(item)
        units.extend(grouped.values())
        relationship_run.clear()

    for event in events:
        if _relationship_event(event):
            relationship_run.append(event)
            continue
        flush()
        units.append([event])
    flush()
    return units


async def _ack_events(runtime: Any, events: list[ProjectionEventRecord]) -> int:
    by_tenant: dict[str, list[ProjectionEventRecord]] = {}
    for event in events:
        by_tenant.setdefault(event.tenant_id, []).append(event)
    delivered = 0
    for tenant_id, tenant_events in by_tenant.items():
        result = await runtime.store.mark_projection_events_delivered(
            [event.event_id for event in tenant_events],
            tenant_id=tenant_id,
            lease_attempts={event.event_id: event.attempts for event in tenant_events},
        )
        # Compatibility with test doubles and older repository adapters that
        # acknowledged successfully without returning a count.
        delivered += len(tenant_events) if result is None else int(result)
    return delivered


async def _fail_events(
    runtime: Any,
    events: list[ProjectionEventRecord],
    result: OutboxDrainResult,
    exc: Exception,
) -> None:
    missing_record = isinstance(exc, RecordNotFoundError)
    retryable = bool(getattr(exc, "retryable", True))
    lifecycle_wait = bool(getattr(exc, "lifecycle_wait", False))
    now = utc_now()
    for event in events:
        replay_marker = event.payload.get("_terminal_graph_replay")
        one_shot_graph_replay = bool(
            event.projection_name == "graph"
            and isinstance(replay_marker, dict)
            and replay_marker.get("mode") == "single_attempt"
        )
        max_attempts = max(1, int(getattr(runtime, "outbox_max_attempts", 10)))
        exception_deadline = getattr(exc, "lifecycle_deadline_seconds", None)
        lifecycle_deadline = (
            max(1, int(exception_deadline))
            if exception_deadline is not None
            else max(
                LIFECYCLE_WAIT_DEADLINE_SECONDS,
                int(
                    getattr(
                        runtime,
                        "outbox_lifecycle_wait_deadline_seconds",
                        LIFECYCLE_WAIT_DEADLINE_SECONDS,
                    )
                ),
            )
        )
        lifecycle_started_at = _lifecycle_started_at(event.last_error)
        ordinary_failures = _ordinary_failure_count(event.last_error)
        if not lifecycle_wait:
            ordinary_failures += 1
        lifecycle_expired = bool(
            lifecycle_wait
            and lifecycle_started_at is not None
            and max(0.0, (now - lifecycle_started_at).total_seconds())
            >= lifecycle_deadline
        )
        terminal = (
            one_shot_graph_replay
            or missing_record
            or not retryable
            or lifecycle_expired
            or (not lifecycle_wait and ordinary_failures >= max_attempts)
        )
        error = str(exc).strip() or exc.__class__.__name__
        if lifecycle_wait:
            lifecycle_started_at = lifecycle_started_at or now
        metadata = []
        if lifecycle_started_at is not None:
            metadata.append(
                f"{_LIFECYCLE_STARTED_PREFIX}{lifecycle_started_at.isoformat()}"
            )
        metadata.append(f"{_ORDINARY_FAILURES_PREFIX}{ordinary_failures}")
        error = " ".join([*metadata, error])
        updated = await runtime.store.fail_projection_event(
            event.event_id,
            tenant_id=event.tenant_id,
            error=error,
            retry_at=(
                None
                if terminal
                else now
                + timedelta(
                    seconds=(
                        LIFECYCLE_WAIT_RETRY_SECONDS
                        if lifecycle_wait
                        else min(300, 2**ordinary_failures)
                    )
                )
            ),
            terminal=terminal,
            lease_attempt=event.attempts,
        )
        if updated is False:
            continue
        if terminal:
            result.terminal_failures += 1
        elif lifecycle_wait:
            result.lifecycle_waits += 1
        else:
            result.retried += 1


async def fail_projection_events(
    runtime: Any,
    events: list[ProjectionEventRecord],
    exc: Exception,
) -> OutboxDrainResult:
    """Apply the shared durable retry policy outside the background drain."""

    tenant_ids = {event.tenant_id for event in events}
    result = OutboxDrainResult(
        tenant_id=next(iter(tenant_ids)) if len(tenant_ids) == 1 else None
    )
    await _fail_events(runtime, events, result, exc)
    return result


def _lifecycle_started_at(last_error: str) -> datetime | None:
    marker_at = str(last_error or "").find(_LIFECYCLE_STARTED_PREFIX)
    if marker_at < 0:
        return None
    raw = str(last_error)[marker_at + len(_LIFECYCLE_STARTED_PREFIX) :].split(
        maxsplit=1
    )[0]
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    return parsed if parsed.tzinfo is not None else None


def _ordinary_failure_count(last_error: str) -> int:
    marker_at = str(last_error or "").find(_ORDINARY_FAILURES_PREFIX)
    if marker_at < 0:
        # Existing rows predate the independent counter. Starting them at zero
        # may grant one fresh bounded retry window, but cannot prematurely
        # terminate a lifecycle event whose DB attempts were only polling.
        return 0
    raw = str(last_error)[marker_at + len(_ORDINARY_FAILURES_PREFIX) :].split(
        maxsplit=1
    )[0]
    try:
        return max(0, int(raw))
    except ValueError:
        return 0


async def _deliver_graph_unit(
    runtime: Any,
    events: list[ProjectionEventRecord],
) -> int:
    event = events[0]
    source_record_id = str(event.payload.get("source_record_id") or "")
    action = str(event.payload.get("action") or "")
    if action == "delete":
        if len(events) != 1 or not source_record_id:
            raise RecordNotFoundError("graph delete event is missing source_record_id")
        await asyncio.to_thread(
            runtime.graph_sink.delete_projection,
            event.tenant_id,
            source_record_id,
            generation=int(event.payload.get("generation") or 0),
        )
        return await _ack_events(runtime, events)

    version = str(event.payload.get("version") or "")
    if not source_record_id or not version:
        raise RecordNotFoundError("graph event is not linked to a document projection")
    if any(_relationship_key(item) != _relationship_key(event) for item in events):
        raise ValueError("relationship delivery unit spans multiple documents")

    graph = None
    for read_attempt in range(2):
        graph = await runtime.store.get_graph_projection(
            event.tenant_id, source_record_id, version
        )
        if graph is not None:
            break
        staged_graph = await runtime.store.get_graph_projection(
            event.tenant_id,
            source_record_id,
            version,
            include_candidate=True,
        )
        if staged_graph is not None:
            return await _ack_events(runtime, events)
        if read_attempt == 0 and _relationship_event(event):
            materialization_pending = (
                await runtime.store.graph_projection_materialization_pending(
                    event.tenant_id,
                    source_record_id,
                    version,
                )
            )
            if materialization_pending:
                raise _GraphProjectionLifecycleWaitError(
                    "graph snapshot is not materialized yet: "
                    f"{source_record_id}:{version}"
                )
            continue
        raise RecordNotFoundError(
            f"active or staging graph snapshot not found: {source_record_id}:{version}"
        )

    if graph is None:  # pragma: no cover - both loop exits assign or raise
        raise RecordNotFoundError(
            f"active graph snapshot not found: {source_record_id}:{version}"
        )

    tenant = await runtime.ensure_tenant(event.tenant_id)
    graph = runtime._graph_with_acl(graph, tenant.default_acl)
    await asyncio.to_thread(runtime.graph_sink.replace_projection, graph)

    if (
        runtime.lightrag_shadow is not None
        and event.event_type == "graph.projection.replaced"
    ):
        try:
            await runtime._enqueue_lightrag_projection(
                tenant_id=event.tenant_id,
                source_record_id=source_record_id,
                version=version,
                fingerprint=str(event.payload.get("fingerprint") or ""),
                action="upsert",
                reason="review_promotion",
            )
        except Exception as exc:  # noqa: BLE001 - optional shadow remains isolated
            logging.getLogger(__name__).warning(
                "LightRAG promotion enqueue failed error_type=%s",
                exc.__class__.__name__,
            )
    return await _ack_events(runtime, events)


async def _deliver_individual(
    runtime: Any,
    projection_name: str,
    event: ProjectionEventRecord,
) -> int:
    if projection_name == "lightrag_shadow":
        await runtime._deliver_lightrag_projection(event)
    elif projection_name == "embedding":
        source_record_id = str(event.payload.get("source_record_id") or "")
        version = str(event.payload.get("version") or "")
        if not source_record_id or not version:
            raise RecordNotFoundError(
                "embedding event is not linked to a document projection"
            )
        await runtime._embed_projection(
            tenant_id=event.tenant_id,
            source_record_id=source_record_id,
            version=version,
            fingerprint=str(event.payload.get("fingerprint") or ""),
        )
    return await _ack_events(runtime, [event])


async def _drain_projection_batch(
    runtime: Any,
    *,
    projection_name: str,
    tenant_id: str | None,
    limit: int,
    protect_fresh_seconds: float,
    result: OutboxDrainResult,
) -> int:
    if limit <= 0:
        return 0
    lease_kwargs: dict[str, Any] = {
        "tenant_id": tenant_id,
        "limit": limit,
        "protect_fresh_seconds": protect_fresh_seconds,
    }
    if projection_name == "lightrag_shadow":
        lease_kwargs["lease_seconds"] = LIGHTRAG_PROJECTION_LEASE_SECONDS
    elif projection_name in _PROJECTION_LEASE_CAPS:
        lease_kwargs["lease_seconds"] = EXTERNAL_PROJECTION_LEASE_SECONDS
    events = await runtime.store.lease_projection_events(
        projection_name,
        **lease_kwargs,
    )
    result.leased += len(events)
    if not events:
        return 0

    if projection_name in _LOCAL_ACK_PROJECTIONS:
        try:
            result.delivered += await _ack_events(runtime, events)
        except Exception as exc:  # noqa: BLE001 - durable retry below
            await _fail_events(runtime, events, result, exc)
        return len(events)

    units = (
        _graph_delivery_units(events)
        if projection_name == "graph"
        else [[event] for event in events]
    )
    for unit in units:
        try:
            if projection_name == "graph":
                delivered = await _deliver_graph_unit(runtime, unit)
            else:
                delivered = await _deliver_individual(runtime, projection_name, unit[0])
            result.delivered += delivered
        except Exception as exc:  # noqa: BLE001 - bounded durable retry
            await _fail_events(runtime, unit, result, exc)
    return len(events)


async def drain_projection_outbox(
    runtime: Any,
    *,
    tenant_id: str | None = None,
    limit: int = 100,
    protect_fresh_seconds: float = 0.0,
) -> OutboxDrainResult:
    """Deliver at most ``limit`` events with fair projection-level leasing."""

    result = OutboxDrainResult(tenant_id=tenant_id)
    projection_names = [
        "knowledge",
        "search",
        "search_staging",
        "embedding",
        "graph_staging",
        "graph",
    ]
    if runtime.lightrag_shadow is not None:
        projection_names.append("lightrag_shadow")

    total_budget = max(1, min(int(limit), 1000))
    remaining = total_budget
    drained_by_projection: dict[str, int] = {}
    cursor = int(getattr(runtime, "_outbox_projection_cursor", 0))
    cursor %= len(projection_names)
    active = projection_names[cursor:] + projection_names[:cursor]
    runtime._outbox_projection_cursor = (cursor + 1) % len(projection_names)

    while remaining > 0 and active:
        next_active: list[str] = []
        leased_this_round = 0
        fair_share = (remaining + len(active) - 1) // len(active)
        for projection_name in active:
            if remaining <= 0:
                break
            projection_cap = _PROJECTION_LEASE_CAPS.get(
                projection_name, fair_share
            )
            requested = min(remaining, fair_share, projection_cap)
            leased = await _drain_projection_batch(
                runtime,
                projection_name=projection_name,
                tenant_id=tenant_id,
                limit=requested,
                protect_fresh_seconds=protect_fresh_seconds,
                result=result,
            )
            remaining -= leased
            leased_this_round += leased
            drained_by_projection[projection_name] = (
                drained_by_projection.get(projection_name, 0) + leased
            )
            drain_cap = _PROJECTION_DRAIN_CAPS.get(projection_name)
            if (
                leased == requested
                and remaining > 0
                and (
                    drain_cap is None
                    or drained_by_projection[projection_name] < drain_cap
                )
            ):
                next_active.append(projection_name)
        if leased_this_round == 0:
            break
        active = next_active
    return result


__all__ = [
    "LIFECYCLE_WAIT_DEADLINE_SECONDS",
    "EXTERNAL_PROJECTION_LEASE_SECONDS",
    "LIGHTRAG_PROJECTION_LEASE_SECONDS",
    "OutboxDrainResult",
    "drain_projection_outbox",
    "fail_projection_events",
]
