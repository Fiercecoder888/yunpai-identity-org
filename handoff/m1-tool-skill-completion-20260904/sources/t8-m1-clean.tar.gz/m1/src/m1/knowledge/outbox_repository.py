"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

import hashlib
from datetime import datetime, timedelta
from typing import TypeVar

from sqlalchemy import (
    and_,
    func,
    or_,
    select,
    text,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import aliased, load_only

from .db_models import (
    DocumentVersionRow,
    GraphGenerationRow,
    GraphProjectionSnapshotRow,
    IdempotencyConflictError,
    KnowledgeBase,
    ProjectionOutboxRow,
    RecordNotFoundError,
    TenantBoundaryError,
)
from .models import GraphProjection
from .persistence_helpers import (
    _aware,
    _projection_record,
    _projection_row,
    _sha256_json,
)
from .schema import (
    LifecycleStatus,
    OutboxStatus,
    ProjectionEventRecord,
    TaskFenceToken,
    utc_now,
)

T = TypeVar("T")


LIGHTRAG_PROJECTION_NAME = "lightrag_shadow"
LIGHTRAG_MAX_LEASE_SECONDS = 120


class KnowledgeOutboxMixin:
    @staticmethod
    def _lightrag_source_head_predicate():
        """Only the oldest unfinished event for one shadow source is leaseable."""

        earlier = aliased(ProjectionOutboxRow)
        return ~(
            select(earlier.event_id)
            .where(
                earlier.tenant_id == ProjectionOutboxRow.tenant_id,
                earlier.projection_name == ProjectionOutboxRow.projection_name,
                earlier.aggregate_id == ProjectionOutboxRow.aggregate_id,
                earlier.status.in_(
                    [
                        OutboxStatus.PENDING.value,
                        OutboxStatus.PROCESSING.value,
                    ]
                ),
                or_(
                    earlier.created_at < ProjectionOutboxRow.created_at,
                    and_(
                        earlier.created_at == ProjectionOutboxRow.created_at,
                        earlier.event_id < ProjectionOutboxRow.event_id,
                    ),
                ),
            )
            .correlate(ProjectionOutboxRow)
            .exists()
        )

    async def _lock_lightrag_lease_sources(
        self,
        session: AsyncSession,
        rows: list[ProjectionOutboxRow],
        *,
        now: datetime,
    ) -> list[ProjectionOutboxRow]:
        """Serialize lease decisions and reject a second live source owner."""

        if not rows:
            return []
        is_postgresql = session.get_bind().dialect.name == "postgresql"
        accepted: list[ProjectionOutboxRow] = []
        for row in rows:
            # LightRAG events use aggregate_id as their source_record_id. The
            # transaction lock closes the window between candidate selection
            # and the committed processing lease across application processes.
            if is_postgresql:
                await session.execute(
                    text(
                        "SELECT pg_advisory_xact_lock("
                        "hashtextextended(:source_lock_key, 0))"
                    ),
                    {
                        "source_lock_key": (
                            f"m1:lightrag:{len(row.tenant_id)}:{row.tenant_id}:"
                            f"{len(row.aggregate_id)}:{row.aggregate_id}"
                        )
                    },
                )
            active_owner = await session.scalar(
                select(ProjectionOutboxRow.event_id)
                .where(
                    ProjectionOutboxRow.tenant_id == row.tenant_id,
                    ProjectionOutboxRow.projection_name
                    == LIGHTRAG_PROJECTION_NAME,
                    ProjectionOutboxRow.aggregate_id == row.aggregate_id,
                    ProjectionOutboxRow.event_id != row.event_id,
                    ProjectionOutboxRow.status == OutboxStatus.PROCESSING.value,
                    ProjectionOutboxRow.leased_until >= now,
                )
                .limit(1)
            )
            if active_owner is None:
                accepted.append(row)
        return accepted

    async def projection_outbox_health(
        self, tenant_id: str
    ) -> dict[str, object]:
        """Return bounded operational status without exposing event payloads."""

        now = utc_now()
        async with self.sessionmaker() as session:
            rows = (
                await session.execute(
                    select(
                        ProjectionOutboxRow.projection_name,
                        ProjectionOutboxRow.status,
                        func.count(ProjectionOutboxRow.event_id),
                        func.min(ProjectionOutboxRow.created_at),
                        func.max(ProjectionOutboxRow.attempts),
                    )
                    .where(ProjectionOutboxRow.tenant_id == tenant_id)
                    .group_by(
                        ProjectionOutboxRow.projection_name,
                        ProjectionOutboxRow.status,
                    )
                )
            ).all()
            terminal_failures = int(
                await session.scalar(
                    select(func.count(ProjectionOutboxRow.event_id)).where(
                        ProjectionOutboxRow.tenant_id == tenant_id,
                        ProjectionOutboxRow.status == OutboxStatus.FAILED.value,
                        ProjectionOutboxRow.last_error.not_like("superseded by %"),
                        ProjectionOutboxRow.last_error.not_like(
                            "source task tombstoned:%"
                        ),
                    )
                )
                or 0
            )
        by_projection: dict[str, dict[str, int]] = {}
        pending_total = 0
        oldest_pending_age = 0.0
        max_attempts = 0
        for projection, status, count, oldest, attempts in rows:
            by_projection.setdefault(str(projection), {})[str(status)] = int(count)
            max_attempts = max(max_attempts, int(attempts or 0))
            if str(status) in {
                OutboxStatus.PENDING.value,
                OutboxStatus.PROCESSING.value,
            }:
                pending_total += int(count)
                if oldest is not None:
                    oldest_pending_age = max(
                        oldest_pending_age,
                        max(0.0, (now - _aware(oldest)).total_seconds()),
                    )
        return {
            "pending": pending_total,
            "oldest_pending_age_seconds": round(oldest_pending_age, 3),
            "terminal_failures": terminal_failures,
            "max_attempts": max_attempts,
            "by_projection": by_projection,
        }

    async def enqueue_projection(
        self,
        record: ProjectionEventRecord,
        *,
        fence: TaskFenceToken | None = None,
    ) -> ProjectionEventRecord:
        async def operation(session: AsyncSession) -> ProjectionEventRecord:
            if fence is not None:
                source_record_id = str(record.payload.get("source_record_id") or "")
                source_version = str(record.payload.get("version") or "")
                if source_record_id and source_version:
                    await self._assert_fenced_version_binding(
                        session,
                        fence,
                        tenant_id=record.tenant_id,
                        source_record_id=source_record_id,
                        source_version=source_version,
                    )
                else:
                    await self._assert_task_fence(
                        session,
                        fence,
                        tenant_id=record.tenant_id,
                        task_id=fence.task_id,
                    )
            row = await self._enqueue_in_session(session, record)
            return _projection_record(row)

        return await self._write(operation)

    async def _enqueue_in_session(
        self, session: AsyncSession, record: ProjectionEventRecord
    ) -> ProjectionOutboxRow:
        existing = await session.scalar(
            select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.tenant_id == record.tenant_id,
                ProjectionOutboxRow.projection_name == record.projection_name,
                ProjectionOutboxRow.idempotency_key == record.idempotency_key,
            )
        )
        if existing:
            if (
                existing.aggregate_type != record.aggregate_type
                or existing.aggregate_id != record.aggregate_id
                or existing.event_type != record.event_type
            ):
                raise IdempotencyConflictError(record.idempotency_key)
            return existing
        row = _projection_row(record)
        session.add(row)
        await session.flush()
        return row

    async def lease_projection_events(
        self,
        projection_name: str,
        *,
        tenant_id: str | None = None,
        limit: int = 100,
        lease_seconds: int = 60,
        protect_fresh_seconds: float = 0.0,
        now: datetime | None = None,
    ) -> list[ProjectionEventRecord]:
        now = _aware(now) or utc_now()

        async def operation(session: AsyncSession) -> list[ProjectionEventRecord]:
            resolved_lease_seconds = lease_seconds
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.projection_name == projection_name,
                ProjectionOutboxRow.available_at <= now,
                or_(
                    ProjectionOutboxRow.status == OutboxStatus.PENDING.value,
                    and_(
                        ProjectionOutboxRow.status == OutboxStatus.PROCESSING.value,
                        ProjectionOutboxRow.leased_until < now,
                    ),
                ),
            )
            protection = max(0.0, float(protect_fresh_seconds))
            if protection:
                statement = statement.where(
                    or_(
                        ProjectionOutboxRow.attempts > 0,
                        ProjectionOutboxRow.last_error != "",
                        ProjectionOutboxRow.created_at
                        <= now - timedelta(seconds=protection),
                    )
                )
            if tenant_id:
                statement = statement.where(ProjectionOutboxRow.tenant_id == tenant_id)
            if projection_name == LIGHTRAG_PROJECTION_NAME:
                statement = statement.where(self._lightrag_source_head_predicate())
            statement = statement.order_by(
                ProjectionOutboxRow.created_at,
                ProjectionOutboxRow.event_id,
            ).limit(max(1, min(limit, 1000)))
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update(skip_locked=True)
            rows = (await session.scalars(statement)).all()
            if projection_name == LIGHTRAG_PROJECTION_NAME:
                rows = await self._lock_lightrag_lease_sources(
                    session,
                    list(rows),
                    now=now,
                )
                resolved_lease_seconds = min(
                    lease_seconds,
                    LIGHTRAG_MAX_LEASE_SECONDS,
                )
            for row in rows:
                row.status = OutboxStatus.PROCESSING.value
                row.attempts += 1
                row.leased_until = now + timedelta(
                    seconds=max(1, resolved_lease_seconds)
                )
            return [_projection_record(row) for row in rows]

        return await self._write(operation)

    async def lease_projection_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        lease_seconds: int = 60,
        now: datetime | None = None,
    ) -> ProjectionEventRecord | None:
        """Claim one known event for immediate delivery.

        Runtime fast paths use the same durable ownership rule as the outbox
        worker.  Exactly one caller can transition a pending (or expired)
        event to ``processing`` and receive its new attempt generation.
        """

        now = _aware(now) or utc_now()

        async def operation(session: AsyncSession) -> ProjectionEventRecord | None:
            resolved_lease_seconds = lease_seconds
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id == event_id,
                ProjectionOutboxRow.tenant_id == tenant_id,
                ProjectionOutboxRow.available_at <= now,
                or_(
                    ProjectionOutboxRow.status == OutboxStatus.PENDING.value,
                    and_(
                        ProjectionOutboxRow.status == OutboxStatus.PROCESSING.value,
                        ProjectionOutboxRow.leased_until < now,
                    ),
                ),
            )
            statement = statement.where(
                or_(
                    ProjectionOutboxRow.projection_name
                    != LIGHTRAG_PROJECTION_NAME,
                    self._lightrag_source_head_predicate(),
                )
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update(skip_locked=True)
            row = await session.scalar(statement)
            if row is None:
                return None
            if row.projection_name == LIGHTRAG_PROJECTION_NAME:
                accepted = await self._lock_lightrag_lease_sources(
                    session,
                    [row],
                    now=now,
                )
                if not accepted:
                    return None
                resolved_lease_seconds = min(
                    lease_seconds,
                    LIGHTRAG_MAX_LEASE_SECONDS,
                )
            row.status = OutboxStatus.PROCESSING.value
            row.attempts += 1
            row.leased_until = now + timedelta(
                seconds=max(1, resolved_lease_seconds)
            )
            await session.flush()
            return _projection_record(row)

        return await self._write(operation)

    async def mark_projection_delivered(
        self,
        event_id: str,
        *,
        tenant_id: str,
        delivered_at: datetime | None = None,
        lease_attempt: int | None = None,
    ) -> bool:
        delivered = await self.mark_projection_events_delivered(
            [event_id],
            tenant_id=tenant_id,
            delivered_at=delivered_at,
            lease_attempts=(
                {event_id: lease_attempt} if lease_attempt is not None else None
            ),
        )
        return delivered == 1

    async def mark_projection_events_delivered(
        self,
        event_ids: list[str],
        *,
        tenant_id: str,
        delivered_at: datetime | None = None,
        lease_attempts: dict[str, int] | None = None,
    ) -> int:
        """Acknowledge one leased projection batch in a single transaction."""

        unique_ids = list(dict.fromkeys(str(item) for item in event_ids if item))
        if not unique_ids:
            return 0
        if lease_attempts is not None and any(
            event_id not in lease_attempts for event_id in unique_ids
        ):
            raise ValueError("lease attempt is required for every acknowledged event")

        async def operation(session: AsyncSession) -> int:
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id.in_(unique_ids)
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            rows = (await session.scalars(statement)).all()
            by_id = {row.event_id: row for row in rows}
            missing = [event_id for event_id in unique_ids if event_id not in by_id]
            if missing:
                raise RecordNotFoundError(missing[0])
            timestamp = _aware(delivered_at) or utc_now()
            delivered = 0
            for event_id in unique_ids:
                row = by_id[event_id]
                if row.tenant_id != tenant_id:
                    raise TenantBoundaryError(event_id)
                if lease_attempts is not None and (
                    row.status != OutboxStatus.PROCESSING.value
                    or row.attempts != lease_attempts[event_id]
                ):
                    continue
                if row.status == OutboxStatus.FAILED.value:
                    raise ValueError(
                        f"projection event {event_id} is terminal and cannot be delivered"
                    )
                if row.status == OutboxStatus.DELIVERED.value:
                    delivered += 1
                    continue
                row.status = OutboxStatus.DELIVERED.value
                row.delivered_at = timestamp
                row.leased_until = None
                row.last_error = ""
                delivered += 1
            return delivered

        return await self._write(operation)

    async def fail_projection_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        error: str,
        retry_at: datetime | None = None,
        terminal: bool = False,
        lease_attempt: int | None = None,
    ) -> bool:
        async def operation(session: AsyncSession) -> bool:
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id == event_id
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            row = await session.scalar(statement)
            if row is None:
                raise RecordNotFoundError(event_id)
            if row.tenant_id != tenant_id:
                raise TenantBoundaryError(event_id)
            if row.status in {
                OutboxStatus.DELIVERED.value,
                OutboxStatus.FAILED.value,
            }:
                return False
            if lease_attempt is not None and (
                row.status != OutboxStatus.PROCESSING.value
                or row.attempts != lease_attempt
            ):
                return False
            row.status = (
                OutboxStatus.FAILED.value if terminal else OutboxStatus.PENDING.value
            )
            row.available_at = _aware(retry_at) or utc_now()
            row.leased_until = None
            row.last_error = error[:8192]
            return True

        return await self._write(operation)

    async def requeue_terminal_graph_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        expected_last_error_contains: str,
        now: datetime | None = None,
    ) -> ProjectionEventRecord:
        """Requeue one inspected terminal graph event without broad resurrection.

        The expected-error guard makes the operator acknowledge the failure
        that is being retried. Repeated calls are idempotent once another
        worker has requeued, leased, or delivered the same event. Lifecycle
        terminals remain governed by their supersede/tombstone workflows and
        cannot be replayed through this operational recovery path.
        """

        expected_error = str(expected_last_error_contains).strip()
        if not expected_error:
            raise ValueError("expected terminal graph error is required")
        replay_at = _aware(now) or utc_now()

        async def operation(session: AsyncSession) -> ProjectionEventRecord:
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id == event_id
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            row = await session.scalar(statement)
            if row is None:
                raise RecordNotFoundError(event_id)
            if row.tenant_id != tenant_id:
                raise TenantBoundaryError(event_id)
            if row.projection_name != "graph":
                raise ValueError(
                    f"projection event {event_id} is not a graph event"
                )
            expected_digest = hashlib.sha256(expected_error.encode("utf-8")).hexdigest()
            payload = dict(row.payload or {})
            replay_marker = payload.get("_terminal_graph_replay")
            if row.status != OutboxStatus.FAILED.value:
                if (
                    isinstance(replay_marker, dict)
                    and replay_marker.get("expected_error_sha256") == expected_digest
                ):
                    return _projection_record(row)
                raise ValueError(
                    f"projection event {event_id} is not a verified replay"
                )
            if isinstance(replay_marker, dict):
                raise ValueError(  # noqa: TRY004 - invalid persisted replay state
                    f"projection event {event_id} already used its one replay"
                )
            if row.event_type != "graph.projection.replaced":
                raise ValueError(
                    f"projection event {event_id} is lifecycle-terminal and cannot be replayed"
                )
            if expected_error not in row.last_error:
                raise ValueError(
                    f"projection event {event_id} terminal error did not match"
                )

            source_record_id = str(payload.get("source_record_id") or "")
            source_version = str(payload.get("version") or "")
            fingerprint = str(payload.get("fingerprint") or "")
            generation = payload.get("generation")
            if (
                not source_record_id
                or not source_version
                or not fingerprint
                or isinstance(generation, bool)
                or not isinstance(generation, int)
                or payload.get("status") != "active"
                or payload.get("eligible_for_active_projection") is not True
                or payload.get("action") == "delete"
            ):
                raise ValueError(
                    f"projection event {event_id} is not an active graph replacement"
                )

            snapshot_statement = select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant_id,
                GraphProjectionSnapshotRow.source_record_id == source_record_id,
                GraphProjectionSnapshotRow.status == "active",
            )
            generation_statement = select(GraphGenerationRow).where(
                GraphGenerationRow.tenant_id == tenant_id,
                GraphGenerationRow.source_record_id == source_record_id,
            )
            if self.engine.url.get_backend_name() != "sqlite":
                snapshot_statement = snapshot_statement.with_for_update(read=True)
                generation_statement = generation_statement.with_for_update(read=True)
            snapshots = (await session.scalars(snapshot_statement)).all()
            current_generation = await session.scalar(generation_statement)
            if (
                len(snapshots) != 1
                or snapshots[0].version != source_version
                or snapshots[0].fingerprint != fingerprint
                or current_generation is None
                or current_generation.generation != generation
            ):
                raise ValueError(
                    f"projection event {event_id} no longer matches the active graph"
                )

            original_error_sha256 = hashlib.sha256(
                row.last_error.encode("utf-8")
            ).hexdigest()
            payload["_terminal_graph_replay"] = {
                "mode": "single_attempt",
                "requested_at": replay_at.isoformat(),
                "expected_error_sha256": expected_digest,
                "original_error_sha256": original_error_sha256,
            }
            row.payload = payload
            row.status = OutboxStatus.PENDING.value
            row.available_at = replay_at
            row.leased_until = None
            row.delivered_at = None
            row.last_error = (
                "terminal_graph_replay_once=true "
                f"original_error_sha256={original_error_sha256}"
            )
            await session.flush()
            return _projection_record(row)

        return await self._write(operation)

    async def rebuild_terminal_graph_projection_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        expected_last_error_contains: str,
        now: datetime | None = None,
    ) -> ProjectionEventRecord:
        """Rebuild one current graph snapshot from its immutable source payload.

        This is deliberately narrower than ``requeue_terminal_graph_event``.
        It accepts only the failed delivery of the source's *current* active
        graph replacement, rebuilds that snapshot with the currently audited
        projection code, and emits a new event.  Historical lifecycle,
        tombstone, superseded, or already-replayed events remain terminal.
        """

        expected_error = str(expected_last_error_contains).strip()
        if not expected_error:
            raise ValueError("expected terminal graph error is required")
        recovery_at = _aware(now) or utc_now()
        expected_digest = hashlib.sha256(expected_error.encode("utf-8")).hexdigest()

        async def operation(session: AsyncSession) -> ProjectionEventRecord:
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id == event_id
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            row = await session.scalar(statement)
            if row is None:
                raise RecordNotFoundError(event_id)
            if row.tenant_id != tenant_id:
                raise TenantBoundaryError(event_id)
            if row.projection_name != "graph":
                raise ValueError(f"projection event {event_id} is not a graph event")
            if row.event_type != "graph.projection.replaced":
                raise ValueError(
                    f"projection event {event_id} is lifecycle-terminal and cannot be rebuilt"
                )
            if row.aggregate_type != "document_projection":
                raise ValueError(
                    f"projection event {event_id} is not a document projection"
                )
            if row.status != OutboxStatus.FAILED.value:
                raise ValueError(
                    f"projection event {event_id} is not a terminal graph failure"
                )

            payload = dict(row.payload or {})
            recovery_marker = payload.get("_terminal_graph_rebuild")
            if recovery_marker is not None:
                if not isinstance(recovery_marker, dict):
                    raise ValueError(
                        f"projection event {event_id} has an invalid rebuild marker"
                    )
                if recovery_marker.get("expected_error_sha256") != expected_digest:
                    raise ValueError(
                        f"projection event {event_id} was rebuilt for another error"
                    )
                replacement_event_id = str(
                    recovery_marker.get("replacement_event_id") or ""
                )
                if not replacement_event_id:
                    raise ValueError(
                        f"projection event {event_id} rebuild marker has no replacement"
                    )
                replacement = await session.scalar(
                    select(ProjectionOutboxRow).where(
                        ProjectionOutboxRow.event_id == replacement_event_id,
                        ProjectionOutboxRow.tenant_id == tenant_id,
                    )
                )
                if (
                    replacement is None
                    or replacement.projection_name != "graph"
                    or replacement.event_type != "graph.projection.replaced"
                ):
                    raise ValueError(
                        f"projection event {event_id} replacement is unavailable"
                    )
                return _projection_record(replacement)
            if payload.get("_terminal_graph_replay") is not None:
                raise ValueError(
                    f"projection event {event_id} already used its one replay"
                )
            if (
                row.last_error.startswith("superseded by ")
                or row.last_error.startswith("source task tombstoned:")
            ):
                raise ValueError(
                    f"projection event {event_id} is superseded or tombstoned"
                )
            if expected_error not in row.last_error:
                raise ValueError(
                    f"projection event {event_id} terminal error did not match"
                )

            source_record_id = str(payload.get("source_record_id") or "")
            source_version = str(payload.get("version") or "")
            fingerprint = str(payload.get("fingerprint") or "")
            generation = payload.get("generation")
            if (
                not source_record_id
                or not source_version
                or not fingerprint
                or isinstance(generation, bool)
                or not isinstance(generation, int)
                or payload.get("status") != "active"
                or payload.get("eligible_for_active_projection") is not True
                or payload.get("action") == "delete"
            ):
                raise ValueError(
                    f"projection event {event_id} is not an active graph replacement"
                )
            try:
                version_number = int(source_version)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"projection event {event_id} has an invalid source version"
                ) from exc
            if version_number < 1 or source_version != str(version_number):
                raise ValueError(
                    f"projection event {event_id} has a noncanonical source version"
                )

            # Match the normal replacement/review lock order: source generation
            # first, then its immutable version and active snapshot.
            generation_row = await self._lock_graph_generation_row(
                session,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
            )
            version_rows = (
                await session.scalars(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.document_id == source_record_id,
                        DocumentVersionRow.lifecycle_status
                        == LifecycleStatus.ACTIVE.value,
                    )
                    .order_by(DocumentVersionRow.version_id)
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
            ).all()
            if (
                len(version_rows) != 1
                or version_rows[0].version_number != version_number
                or not isinstance(version_rows[0].payload, dict)
            ):
                raise ValueError(
                    f"projection event {event_id} no longer has an active source version"
                )
            version = version_rows[0]

            snapshots = (
                await session.scalars(
                    select(GraphProjectionSnapshotRow)
                    .where(
                        GraphProjectionSnapshotRow.tenant_id == tenant_id,
                        GraphProjectionSnapshotRow.source_record_id == source_record_id,
                        GraphProjectionSnapshotRow.status == "active",
                    )
                    .order_by(GraphProjectionSnapshotRow.version)
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
            ).all()
            if (
                len(snapshots) != 1
                or snapshots[0].version != source_version
                or snapshots[0].fingerprint != fingerprint
                or snapshots[0].projection_id != row.aggregate_id
                or generation_row.generation != generation
            ):
                raise ValueError(
                    f"projection event {event_id} no longer matches the active graph"
                )
            snapshot = snapshots[0]
            try:
                persisted_graph = GraphProjection.model_validate(snapshot.projection_json)
            except ValueError as exc:
                raise ValueError(
                    f"projection event {event_id} active graph snapshot is invalid"
                ) from exc
            if (
                persisted_graph.projection_id != snapshot.projection_id
                or persisted_graph.tenant_id != tenant_id
                or persisted_graph.source_record_id != source_record_id
                or persisted_graph.version != source_version
                or persisted_graph.generation != generation
                or snapshot.node_count != len(persisted_graph.nodes)
                or snapshot.edge_count != len(persisted_graph.edges)
            ):
                raise ValueError(
                    f"projection event {event_id} active graph snapshot is inconsistent"
                )

            # Recalculate the combined projection fingerprint exactly as a
            # reviewed-version transition does, while leaving authoritative
            # chunks and search rows untouched by this graph-only repair.
            from .projection import (
                build_field_index_documents,
                build_graph_projection,
                build_knowledge_chunks,
            )

            graph = build_graph_projection(
                version.payload,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
                version=source_version,
            )
            rebuilt_chunks = build_knowledge_chunks(
                version.payload,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
                version=source_version,
            )
            rebuilt_indexes = build_field_index_documents(
                version.payload,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
                version=source_version,
            )
            if (
                graph.projection_id != snapshot.projection_id
                or graph.tenant_id != tenant_id
                or graph.source_record_id != source_record_id
                or graph.version != source_version
            ):
                raise ValueError(
                    f"projection event {event_id} rebuilt graph identity is inconsistent"
                )
            graph = graph.model_copy(
                update={
                    "nodes": [
                        node.model_copy(update={"status": "active"})
                        for node in graph.nodes
                    ],
                    "edges": [
                        edge.model_copy(update={"status": "active"})
                        for edge in graph.edges
                    ],
                }
            )
            rebuilt_chunks = [
                item.model_copy(update={"status": "active"})
                for item in rebuilt_chunks
            ]
            rebuilt_indexes = [
                item.model_copy(update={"status": "active"})
                for item in rebuilt_indexes
            ]
            graph = await self._merge_logical_relationships(
                session,
                graph,
                projection_status="active",
            )
            rebuilt_fingerprint = _sha256_json(
                {
                    "chunks": [item.model_dump(mode="json") for item in rebuilt_chunks],
                    "index": [item.model_dump(mode="json") for item in rebuilt_indexes],
                    "graph": graph.model_dump(mode="json"),
                }
            )
            graph = graph.model_copy(
                update={
                    "generation": await self._next_graph_generation(
                        session,
                        tenant_id=tenant_id,
                        source_record_id=source_record_id,
                    )
                }
            )
            snapshot.fingerprint = rebuilt_fingerprint
            snapshot.projection_json = graph.model_dump(mode="json")
            snapshot.node_count = len(graph.nodes)
            snapshot.edge_count = len(graph.edges)
            snapshot.updated_at = recovery_at
            await self._supersede_projection_events(
                session,
                tenant_id,
                snapshot.projection_id,
                rebuilt_fingerprint,
            )

            replacement = await self._enqueue_in_session(
                session,
                ProjectionEventRecord(
                    tenant_id=tenant_id,
                    projection_name="graph",
                    idempotency_key=(
                        f"terminal-graph-rebuild:{row.event_id}:{rebuilt_fingerprint}"
                    ),
                    aggregate_type="document_projection",
                    aggregate_id=snapshot.projection_id,
                    event_type="graph.projection.replaced",
                    payload={
                        "source_record_id": source_record_id,
                        "version": source_version,
                        "fingerprint": rebuilt_fingerprint,
                        "status": "active",
                        "eligible_for_active_projection": True,
                        "acl": snapshot.acl,
                        "generation": graph.generation,
                        "node_count": snapshot.node_count,
                        "edge_count": snapshot.edge_count,
                        "_terminal_graph_recovery": {
                            "mode": "rebuild_snapshot_and_replay",
                            "source_event_id": row.event_id,
                        },
                    },
                    available_at=recovery_at,
                ),
            )
            original_error_sha256 = hashlib.sha256(
                row.last_error.encode("utf-8")
            ).hexdigest()
            payload["_terminal_graph_rebuild"] = {
                "mode": "rebuild_snapshot_and_replay",
                "requested_at": recovery_at.isoformat(),
                "expected_error_sha256": expected_digest,
                "original_error_sha256": original_error_sha256,
                "replacement_event_id": replacement.event_id,
                "replacement_fingerprint": rebuilt_fingerprint,
                "replacement_generation": graph.generation,
            }
            row.payload = payload
            row.leased_until = None
            row.last_error = (
                "superseded by terminal graph rebuild "
                f"replacement_event_id={replacement.event_id} "
                f"original_error_sha256={original_error_sha256}"
            )
            await session.flush()
            return _projection_record(replacement)

        return await self._write(operation)

    async def retire_stale_terminal_graph_projection_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        expected_last_error_contains: str,
        now: datetime | None = None,
    ) -> ProjectionEventRecord:
        """Retire one verified graph failure whose source is no longer current.

        A terminal graph event is normally a release blocker. This operation is
        deliberately narrower than replay: it only marks the original failure
        as superseded after the locked source lifecycle proves that its version
        or graph snapshot has already been retired. The failed row remains as
        audit evidence and no new projection event is emitted.
        """

        expected_error = str(expected_last_error_contains).strip()
        if not expected_error:
            raise ValueError("expected terminal graph error is required")
        retired_at = _aware(now) or utc_now()
        expected_digest = hashlib.sha256(expected_error.encode("utf-8")).hexdigest()

        async def operation(session: AsyncSession) -> ProjectionEventRecord:
            statement = select(ProjectionOutboxRow).where(
                ProjectionOutboxRow.event_id == event_id
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            row = await session.scalar(statement)
            if row is None:
                raise RecordNotFoundError(event_id)
            if row.tenant_id != tenant_id:
                raise TenantBoundaryError(event_id)

            payload = dict(row.payload or {})
            retirement = payload.get("_terminal_graph_retirement")
            if retirement is not None:
                if (
                    not isinstance(retirement, dict)
                    or retirement.get("mode") != "retire_stale_terminal"
                    or retirement.get("expected_error_sha256") != expected_digest
                    or not isinstance(retirement.get("reason"), str)
                ):
                    raise ValueError(
                        f"projection event {event_id} was retired for another error"
                    )
                return _projection_record(row)

            if row.projection_name != "graph":
                raise ValueError(f"projection event {event_id} is not a graph event")
            if row.event_type != "graph.projection.replaced":
                raise ValueError(
                    f"projection event {event_id} is lifecycle-terminal and cannot be retired"
                )
            if row.aggregate_type != "document_projection":
                raise ValueError(
                    f"projection event {event_id} is not a document projection"
                )
            if row.status != OutboxStatus.FAILED.value:
                raise ValueError(
                    f"projection event {event_id} is not a terminal graph failure"
                )
            if payload.get("_terminal_graph_rebuild") is not None:
                raise ValueError(
                    f"projection event {event_id} already has a graph rebuild marker"
                )
            if payload.get("_terminal_graph_replay") is not None:
                raise ValueError(
                    f"projection event {event_id} already used its one replay"
                )
            if row.last_error.startswith("superseded by "):
                raise ValueError(
                    f"projection event {event_id} is already superseded without retirement evidence"
                )
            if expected_error not in row.last_error:
                raise ValueError(
                    f"projection event {event_id} terminal error did not match"
                )

            source_record_id = str(payload.get("source_record_id") or "")
            source_version = str(payload.get("version") or "")
            if not source_record_id:
                raise ValueError(
                    f"projection event {event_id} has no source record identity"
                )
            try:
                version_number = int(source_version)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"projection event {event_id} has an invalid source version"
                ) from exc
            if version_number < 1 or source_version != str(version_number):
                raise ValueError(
                    f"projection event {event_id} has a noncanonical source version"
                )

            # Serialize the lifecycle read with normal graph replacement.  A
            # row lock on the historical snapshot alone cannot prevent a new
            # active version from being created after this check on PostgreSQL.
            await self._lock_graph_generation_row(
                session,
                tenant_id=tenant_id,
                source_record_id=source_record_id,
            )
            version_statement = (
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == source_record_id,
                )
                .order_by(DocumentVersionRow.version_number)
            )
            snapshot_statement = (
                select(GraphProjectionSnapshotRow)
                .where(
                    GraphProjectionSnapshotRow.tenant_id == tenant_id,
                    GraphProjectionSnapshotRow.source_record_id == source_record_id,
                )
                .order_by(GraphProjectionSnapshotRow.version)
            )
            if self.engine.url.get_backend_name() != "sqlite":
                version_statement = version_statement.with_for_update()
                snapshot_statement = snapshot_statement.with_for_update()
            versions = (await session.scalars(version_statement)).all()
            snapshots = (await session.scalars(snapshot_statement)).all()
            historical_versions = [
                version
                for version in versions
                if version.version_number == version_number
            ]
            source_snapshots = [
                snapshot
                for snapshot in snapshots
                if snapshot.version == source_version
                and snapshot.projection_id == row.aggregate_id
            ]
            if len(historical_versions) != 1 or len(source_snapshots) != 1:
                raise ValueError(
                    f"projection event {event_id} lacks a complete historical source"
                )
            historical_version = historical_versions[0]
            source_snapshot = source_snapshots[0]
            if historical_version.lifecycle_status not in {
                LifecycleStatus.DEPRECATED.value,
                LifecycleStatus.REJECTED.value,
            }:
                raise ValueError(
                    f"projection event {event_id} source version is not retired"
                )
            if source_snapshot.status not in {"deprecated", "rejected"}:
                raise ValueError(
                    f"projection event {event_id} source snapshot is still current"
                )

            active_versions = [
                version
                for version in versions
                if version.lifecycle_status == LifecycleStatus.ACTIVE.value
            ]
            active_snapshots = [
                snapshot for snapshot in snapshots if snapshot.status == "active"
            ]
            if not active_versions:
                if active_snapshots:
                    raise ValueError(
                        f"projection event {event_id} has an inconsistent retired source"
                    )
                reason = "source_retired"
            else:
                if len(active_versions) != 1 or len(active_snapshots) != 1:
                    raise ValueError(
                        f"projection event {event_id} has an ambiguous active replacement"
                    )
                active_version = active_versions[0]
                active_snapshot = active_snapshots[0]
                if active_snapshot.version != str(active_version.version_number):
                    raise ValueError(
                        f"projection event {event_id} active replacement is inconsistent"
                    )
                if (
                    active_snapshot.projection_id == row.aggregate_id
                    and active_snapshot.version == source_version
                ):
                    raise ValueError(
                        f"projection event {event_id} active replacement is unchanged"
                    )
                reason = "active_projection_replaced"

            original_error_sha256 = hashlib.sha256(
                row.last_error.encode("utf-8")
            ).hexdigest()
            payload["_terminal_graph_retirement"] = {
                "mode": "retire_stale_terminal",
                "requested_at": retired_at.isoformat(),
                "expected_error_sha256": expected_digest,
                "original_error_sha256": original_error_sha256,
                "reason": reason,
            }
            row.payload = payload
            row.leased_until = None
            row.last_error = (
                "superseded by terminal graph retirement "
                f"reason={reason} original_error_sha256={original_error_sha256}"
            )
            await session.flush()
            return _projection_record(row)

        return await self._write(operation)

    async def _assert_owned(
        self,
        session: AsyncSession,
        row_type: type[KnowledgeBase],
        row_id: str,
        tenant_id: str,
    ) -> KnowledgeBase:
        # A document version contains the complete source payload. Ownership
        # checks run for every entity/identity/alias binding and only need its
        # primary key plus tenant_id, so do not repeatedly transfer and decode
        # a multi-MiB JSON payload.
        options = (
            [load_only(DocumentVersionRow.version_id, DocumentVersionRow.tenant_id)]
            if row_type is DocumentVersionRow
            else None
        )
        row = await session.get(row_type, row_id, options=options)
        if row is None:
            raise RecordNotFoundError(f"{row_type.__name__} not found: {row_id}")
        if getattr(row, "tenant_id", None) != tenant_id:
            raise TenantBoundaryError(row_id)
        return row
