"""Compatibility facade for M1's governed knowledge repositories.

Storage mappings, conversion helpers, and focused repository behavior live in
separate modules.  ``KnowledgeStore`` remains the stable public entry point,
and legacy row/helper imports are re-exported for migrations and tests.
"""

from __future__ import annotations

# Compatibility re-exports are intentionally imported into this facade.
# ruff: noqa: F401
import inspect

from .content_region_repository import KnowledgeContentRegionRouteMixin
from .db_models import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    KNOWLEDGE_EMBEDDING_TYPE,
    AliasSourceBindingRow,
    BitemporalMixin,
    CanonicalEntityRow,
    ConflictRow,
    ContentRegionObservationRow,
    ContentRegionProfileRow,
    DocumentVersionRow,
    EntityAliasRow,
    EntityRevisionRow,
    EntityRouteDecisionRow,
    EntityRouteIndexRow,
    EntitySourceBindingRow,
    EvidenceAnchorRow,
    ExternalIdentityRow,
    FieldClaimRow,
    FieldSemanticObservationRow,
    FieldSemanticProfileRow,
    GraphGenerationRow,
    GraphProjectionSnapshotRow,
    IdempotencyConflictError,
    IdentitySourceBindingRow,
    IngestionBatchRow,
    KnowledgeBase,
    KnowledgeChunkRow,
    KnowledgeDocumentRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    RecordNotFoundError,
    RegionCapabilityObservationRow,
    RegionCapabilityProfileRow,
    RelationshipClaimRow,
    ReviewConflictError,
    ReviewDecisionRow,
    ReviewTaskRow,
    RouteObservationRow,
    RouteProfileRow,
    SourceAssetRow,
    SourceOccurrenceRow,
    TabularLayoutObservationRow,
    TabularLayoutProfileRow,
    TaskLifecycleRow,
    TaskVersionBindingRow,
    TenantBoundaryError,
    TenantRow,
    TenantScopedMixin,
    VisualRegionObservationRow,
    VisualRegionProfileRow,
)
from .document_identity_repository import KnowledgeDocumentIdentityMixin
from .document_repository import KnowledgeDocumentMixin
from .entity_repository import KnowledgeEntityMixin
from .entity_route_repository import KnowledgeEntityRouteMixin
from .field_semantic_repository import KnowledgeFieldSemanticRouteMixin
from .lifecycle_repository import KnowledgeLifecycleMixin
from .outbox_repository import KnowledgeOutboxMixin
from .persistence_helpers import (
    _alias_record,
    _alias_row,
    _anchor_row,
    _asset_record,
    _asset_row,
    _aware,
    _batch_record,
    _batch_row,
    _canonical_json,
    _conflict_record,
    _conflict_row,
    _decision_record,
    _decision_row,
    _document_row,
    _entity_record,
    _entity_row,
    _enum,
    _fallback_claim_paths,
    _field_claim_row,
    _identity_record,
    _identity_row,
    _json,
    _knowledge_chunk_row,
    _knowledge_index_record,
    _knowledge_index_row,
    _normalize_text,
    _occurrence_record,
    _occurrence_row,
    _projection_record,
    _projection_row,
    _projection_status,
    _relationship_record,
    _relationship_row,
    _resolve_path,
    _review_task_record,
    _review_task_row,
    _revision_record,
    _revision_row,
    _sha256_json,
    _strongest_claim_status,
    _tenant_record,
    _version_record,
    _version_row,
)
from .projection_repository import KnowledgeProjectionMixin
from .region_capability_repository import KnowledgeRegionCapabilityRouteMixin
from .repository_base import (
    _POSTGRES_TENANT_CONTEXT,
    KnowledgeRepositoryBase,
    _tenant_scoped_call,
)
from .retrieval_store import KnowledgeSearchMixin
from .review_store import KnowledgeReviewMixin
from .route_profile_repository import KnowledgeRouteProfileMixin
from .stats_repository import KnowledgeStatsMixin
from .tabular_layout_repository import KnowledgeTabularLayoutProfileMixin
from .task_fence_repository import KnowledgeTaskFenceMixin
from .visual_region_repository import KnowledgeVisualRegionRouteMixin


class KnowledgeStore(
    KnowledgeContentRegionRouteMixin,
    KnowledgeRegionCapabilityRouteMixin,
    KnowledgeVisualRegionRouteMixin,
    KnowledgeFieldSemanticRouteMixin,
    KnowledgeTabularLayoutProfileMixin,
    KnowledgeRouteProfileMixin,
    KnowledgeEntityRouteMixin,
    KnowledgeTaskFenceMixin,
    KnowledgeReviewMixin,
    KnowledgeSearchMixin,
    KnowledgeOutboxMixin,
    KnowledgeStatsMixin,
    KnowledgeLifecycleMixin,
    KnowledgeProjectionMixin,
    KnowledgeDocumentIdentityMixin,
    KnowledgeDocumentMixin,
    KnowledgeEntityMixin,
    KnowledgeRepositoryBase,
):
    """Tenant-safe facade over the focused knowledge repositories."""


# Every public repository operation that accepts ``tenant_id`` or a tenant-
# owned ``record`` gets a transaction-local tenant GUC before SQL starts. The
# migration's forced RLS policies consume this value. Keeping this wrapping in
# one audited location prevents a newly added method from silently omitting
# the database security context.
for _method_name in dir(KnowledgeStore):
    _method = getattr(KnowledgeStore, _method_name)
    if (
        not _method_name.startswith("_")
        and inspect.iscoroutinefunction(_method)
        and {"tenant_id", "record"}.intersection(inspect.signature(_method).parameters)
    ):
        setattr(KnowledgeStore, _method_name, _tenant_scoped_call(_method))


__all__ = [
    "IdempotencyConflictError",
    "KnowledgeBase",
    "KnowledgeStore",
    "RecordNotFoundError",
    "ReviewConflictError",
    "TenantBoundaryError",
]
