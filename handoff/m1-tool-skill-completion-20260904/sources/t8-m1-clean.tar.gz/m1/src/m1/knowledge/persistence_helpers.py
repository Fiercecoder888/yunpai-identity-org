"""Pure mapping and normalization helpers for knowledge repositories."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel

from .db_models import (
    CanonicalEntityRow,
    ConflictRow,
    DocumentVersionRow,
    EntityAliasRow,
    EntityRevisionRow,
    EvidenceAnchorRow,
    ExternalIdentityRow,
    FieldClaimRow,
    IngestionBatchRow,
    KnowledgeChunkRow,
    KnowledgeDocumentRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    RelationshipClaimRow,
    ReviewDecisionRow,
    ReviewTaskRow,
    SourceAssetRow,
    SourceOccurrenceRow,
    TenantRow,
)
from .models import FieldIndexDocument, KnowledgeChunk
from .schema import (
    CanonicalEntityRecord,
    ClaimStatus,
    ConflictRecord,
    DocumentVersionRecord,
    EntityAliasRecord,
    EntityRevisionRecord,
    EvidenceAnchorRecord,
    ExternalIdentityRecord,
    FieldClaimRecord,
    IngestionBatchRecord,
    KnowledgeDocumentRecord,
    ProjectionEventRecord,
    RelationshipClaimRecord,
    ReviewDecisionRecord,
    ReviewTaskRecord,
    SourceAssetRecord,
    SourceOccurrenceRecord,
    TenantRecord,
)


def _json(value: BaseModel | dict[str, Any] | list[Any] | None) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    return value


def _enum(value: Any) -> str:
    return str(value.value if hasattr(value, "value") else value)


def _strongest_claim_status(statuses: Iterable[ClaimStatus | str]) -> str:
    """Return the strongest live assertion, or a durable tombstone status."""

    ranked = {
        ClaimStatus.REJECTED.value: 0,
        ClaimStatus.CANDIDATE.value: 1,
        ClaimStatus.UNDER_REVIEW.value: 2,
        ClaimStatus.ACCEPTED.value: 3,
    }
    normalized = [_enum(status) for status in statuses]
    if not normalized:
        return ClaimStatus.SUPERSEDED.value
    return max(normalized, key=lambda status: (ranked.get(status, -1), status))


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )


def _sha256_json(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _normalize_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return unicodedata.normalize("NFKC", value).strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    return _canonical_json(value)


_PATH_TOKEN = re.compile(r"(?:^|\.)([^.\[\]]+)|\[(\d+)\]")


def _resolve_path(payload: dict[str, Any], path: str) -> Any:
    current: Any = payload
    clean = path.strip()
    clean = clean.removeprefix("$")
    clean = clean.lstrip(".")
    if not clean:
        return payload
    for match in _PATH_TOKEN.finditer(clean):
        key, index = match.groups()
        if key is not None:
            if not isinstance(current, dict) or key not in current:
                return None
            current = current[key]
        else:
            if not isinstance(current, list) or int(index) >= len(current):
                return None
            current = current[int(index)]
    return current


def _fallback_claim_paths(payload: dict[str, Any]) -> list[str]:
    paths: list[str] = []
    header = payload.get("header")
    if isinstance(header, dict):
        for key in (
            "title",
            "issuer",
            "order_number",
            "contract_number",
            "date_raw",
            "date_standard",
            "delivery_date_raw",
            "delivery_date_standard",
            "buyer",
            "seller",
            "supplier",
            "currency",
        ):
            if header.get(key) not in (None, "", [], {}):
                paths.append(f"$.header.{key}")
    lines = payload.get("lines")
    if isinstance(lines, list):
        indexed = (
            "line_id",
            "line_no",
            "model",
            "product_code",
            "name_raw",
            "name_normalized",
            "full_product_name",
            "product_category",
            "specification_raw",
            "quantity",
            "unit",
            "unit_price_tax_included",
            "amount_tax_included",
            "remark",
        )
        for idx, line in enumerate(lines):
            if not isinstance(line, dict):
                continue
            for key in indexed:
                if line.get(key) not in (None, "", [], {}):
                    paths.append(f"$.lines[{idx}].{key}")
    totals = payload.get("totals")
    if isinstance(totals, dict):
        for key, value in totals.items():
            if value not in (None, "", [], {}):
                paths.append(f"$.totals.{key}")
    return paths


def _projection_status(statuses: Iterable[str]) -> str:
    values = set(statuses)
    for status in ("candidate", "rejected", "deprecated", "active"):
        if status in values:
            return status
    return "candidate"


def _tenant_record(row: TenantRow) -> TenantRecord:
    return TenantRecord(
        tenant_id=row.tenant_id,
        tenant_key=row.tenant_key,
        display_name=row.display_name,
        lifecycle_status=row.lifecycle_status,
        default_acl=row.default_acl,
        metadata=row.metadata_json,
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
    )


def _batch_row(record: IngestionBatchRecord) -> IngestionBatchRow:
    return IngestionBatchRow(
        batch_id=record.batch_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        source_type=record.source_type,
        status=_enum(record.status),
        manifest=record.manifest,
        statistics=record.statistics,
        acl=_json(record.acl),
        started_at=record.started_at,
        completed_at=record.completed_at,
        created_at=record.created_at,
        updated_at=record.updated_at,
    )


def _batch_record(row: IngestionBatchRow) -> IngestionBatchRecord:
    return IngestionBatchRecord(
        batch_id=row.batch_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        source_type=row.source_type,
        status=row.status,
        manifest=row.manifest,
        statistics=row.statistics,
        acl=row.acl,
        started_at=_aware(row.started_at),
        completed_at=_aware(row.completed_at),
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
    )


def _asset_row(record: SourceAssetRecord) -> SourceAssetRow:
    return SourceAssetRow(
        asset_id=record.asset_id,
        tenant_id=record.tenant_id,
        sha256=record.sha256,
        size_bytes=record.size_bytes,
        mime_type=record.mime_type,
        object_uri=record.object_uri,
        original_filename=record.original_filename,
        lifecycle_status=_enum(record.lifecycle_status),
        acl=_json(record.acl),
        metadata_json=record.metadata,
        created_at=record.created_at,
    )


def _asset_record(row: SourceAssetRow) -> SourceAssetRecord:
    return SourceAssetRecord(
        asset_id=row.asset_id,
        tenant_id=row.tenant_id,
        sha256=row.sha256,
        size_bytes=row.size_bytes,
        mime_type=row.mime_type,
        object_uri=row.object_uri,
        original_filename=row.original_filename,
        lifecycle_status=row.lifecycle_status,
        acl=row.acl,
        metadata=row.metadata_json,
        created_at=_aware(row.created_at),
    )


def _occurrence_row(record: SourceOccurrenceRecord) -> SourceOccurrenceRow:
    return SourceOccurrenceRow(
        occurrence_id=record.occurrence_id,
        tenant_id=record.tenant_id,
        batch_id=record.batch_id,
        asset_id=record.asset_id,
        idempotency_key=record.idempotency_key,
        task_id=str(record.metadata.get("task_id") or ""),
        source_system=record.source_system,
        source_uri=record.source_uri,
        archive_path=record.archive_path,
        display_filename=record.display_filename,
        source_modified_at=record.source_modified_at,
        metadata_json=record.metadata,
        created_at=record.created_at,
    )


def _occurrence_record(row: SourceOccurrenceRow) -> SourceOccurrenceRecord:
    return SourceOccurrenceRecord(
        occurrence_id=row.occurrence_id,
        tenant_id=row.tenant_id,
        batch_id=row.batch_id,
        asset_id=row.asset_id,
        idempotency_key=row.idempotency_key,
        source_system=row.source_system,
        source_uri=row.source_uri,
        archive_path=row.archive_path,
        display_filename=row.display_filename,
        source_modified_at=_aware(row.source_modified_at),
        metadata=row.metadata_json,
        created_at=_aware(row.created_at),
    )


def _document_row(record: KnowledgeDocumentRecord) -> KnowledgeDocumentRow:
    return KnowledgeDocumentRow(
        document_id=record.document_id,
        tenant_id=record.tenant_id,
        canonical_key=record.canonical_key,
        document_type=record.document_type,
        document_subtype=record.document_subtype,
        title=record.title,
        lifecycle_status=_enum(record.lifecycle_status),
        acl=_json(record.acl),
        metadata_json=record.metadata,
        created_at=record.created_at,
        updated_at=record.updated_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _version_row(record: DocumentVersionRecord) -> DocumentVersionRow:
    return DocumentVersionRow(
        version_id=record.version_id,
        tenant_id=record.tenant_id,
        document_id=record.document_id,
        source_asset_id=record.source_asset_id,
        source_occurrence_id=record.source_occurrence_id,
        version_number=record.version_number,
        schema_version=record.schema_version,
        content_hash=record.content_hash,
        parser_version=record.parser_version,
        processing_revision=record.processing_revision,
        supersedes_version_id=record.supersedes_version_id,
        payload=record.payload,
        lifecycle_status=_enum(record.lifecycle_status),
        acl=_json(record.acl),
        created_at=record.created_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _version_record(row: DocumentVersionRow) -> DocumentVersionRecord:
    return DocumentVersionRecord(
        version_id=row.version_id,
        tenant_id=row.tenant_id,
        document_id=row.document_id,
        source_asset_id=row.source_asset_id,
        source_occurrence_id=row.source_occurrence_id,
        version_number=row.version_number,
        schema_version=row.schema_version,
        content_hash=row.content_hash,
        parser_version=row.parser_version,
        processing_revision=row.processing_revision,
        supersedes_version_id=row.supersedes_version_id,
        payload=row.payload,
        lifecycle_status=row.lifecycle_status,
        acl=row.acl,
        created_at=_aware(row.created_at),
        valid_from=_aware(row.valid_from),
        valid_to=_aware(row.valid_to),
        recorded_from=_aware(row.recorded_from),
        recorded_to=_aware(row.recorded_to),
    )


def _anchor_row(
    record: EvidenceAnchorRecord, locator_hash: str | None = None
) -> EvidenceAnchorRow:
    return EvidenceAnchorRow(
        anchor_id=record.anchor_id,
        tenant_id=record.tenant_id,
        document_version_id=record.document_version_id,
        anchor_type=record.anchor_type,
        locator=record.locator,
        locator_hash=locator_hash or _sha256_json(record.locator),
        excerpt=record.excerpt,
        excerpt_hash=record.excerpt_hash,
        created_at=record.created_at,
    )


def _field_claim_row(record: FieldClaimRecord) -> FieldClaimRow:
    return FieldClaimRow(
        claim_id=record.claim_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        subject_type=record.subject_type,
        subject_id=record.subject_id,
        field_path=record.field_path,
        value=record.value,
        normalized_value=record.normalized_value,
        normalized_text=_normalize_text(record.normalized_value),
        evidence_anchor_id=record.evidence_anchor_id,
        additional_evidence_anchor_ids=record.additional_evidence_anchor_ids,
        extraction_method=record.extraction_method,
        confidence=record.confidence,
        status=_enum(record.status),
        acl=_json(record.acl),
        created_at=record.created_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _entity_row(record: CanonicalEntityRecord) -> CanonicalEntityRow:
    return CanonicalEntityRow(
        entity_id=record.entity_id,
        tenant_id=record.tenant_id,
        entity_type=record.entity_type,
        canonical_key=record.canonical_key,
        canonical_label=record.canonical_label,
        attributes=record.attributes,
        lifecycle_status=_enum(record.lifecycle_status),
        confidence=record.confidence,
        acl=_json(record.acl),
        created_at=record.created_at,
        updated_at=record.updated_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _entity_record(row: CanonicalEntityRow) -> CanonicalEntityRecord:
    return CanonicalEntityRecord(
        entity_id=row.entity_id,
        tenant_id=row.tenant_id,
        entity_type=row.entity_type,
        canonical_key=row.canonical_key,
        canonical_label=row.canonical_label,
        attributes=row.attributes,
        lifecycle_status=row.lifecycle_status,
        confidence=row.confidence,
        acl=row.acl,
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
        valid_from=_aware(row.valid_from),
        valid_to=_aware(row.valid_to),
        recorded_from=_aware(row.recorded_from),
        recorded_to=_aware(row.recorded_to),
    )


def _identity_row(record: ExternalIdentityRecord) -> ExternalIdentityRow:
    return ExternalIdentityRow(
        identity_id=record.identity_id,
        tenant_id=record.tenant_id,
        entity_id=record.entity_id,
        entity_type=record.entity_type,
        source_system=record.source_system,
        external_id=record.external_id,
        mapping_rule=record.mapping_rule,
        confidence=record.confidence,
        status=_enum(record.status),
        conflicts=record.conflicts,
        created_at=record.created_at,
    )


def _identity_record(row: ExternalIdentityRow) -> ExternalIdentityRecord:
    return ExternalIdentityRecord(
        identity_id=row.identity_id,
        tenant_id=row.tenant_id,
        entity_id=row.entity_id,
        entity_type=row.entity_type,
        source_system=row.source_system,
        external_id=row.external_id,
        mapping_rule=row.mapping_rule,
        confidence=row.confidence,
        status=row.status,
        conflicts=row.conflicts,
        created_at=_aware(row.created_at),
    )


def _alias_row(record: EntityAliasRecord) -> EntityAliasRow:
    return EntityAliasRow(
        alias_id=record.alias_id,
        tenant_id=record.tenant_id,
        entity_id=record.entity_id,
        alias=record.alias,
        normalized_alias=record.normalized_alias,
        language=record.language,
        source_system=record.source_system,
        confidence=record.confidence,
        status=_enum(record.status),
        created_at=record.created_at,
    )


def _alias_record(row: EntityAliasRow) -> EntityAliasRecord:
    return EntityAliasRecord(
        alias_id=row.alias_id,
        tenant_id=row.tenant_id,
        entity_id=row.entity_id,
        alias=row.alias,
        normalized_alias=row.normalized_alias,
        language=row.language,
        source_system=row.source_system,
        confidence=row.confidence,
        status=row.status,
        created_at=_aware(row.created_at),
    )


def _revision_row(record: EntityRevisionRecord) -> EntityRevisionRow:
    return EntityRevisionRow(
        revision_id=record.revision_id,
        tenant_id=record.tenant_id,
        entity_id=record.entity_id,
        revision_number=record.revision_number,
        payload=record.payload,
        based_on_revision_id=record.based_on_revision_id,
        change_reason=record.change_reason,
        lifecycle_status=_enum(record.lifecycle_status),
        acl=_json(record.acl),
        created_at=record.created_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _revision_record(row: EntityRevisionRow) -> EntityRevisionRecord:
    return EntityRevisionRecord(
        revision_id=row.revision_id,
        tenant_id=row.tenant_id,
        entity_id=row.entity_id,
        revision_number=row.revision_number,
        payload=row.payload,
        based_on_revision_id=row.based_on_revision_id,
        change_reason=row.change_reason,
        lifecycle_status=row.lifecycle_status,
        acl=row.acl,
        created_at=_aware(row.created_at),
        valid_from=_aware(row.valid_from),
        valid_to=_aware(row.valid_to),
        recorded_from=_aware(row.recorded_from),
        recorded_to=_aware(row.recorded_to),
    )


def _relationship_row(record: RelationshipClaimRecord) -> RelationshipClaimRow:
    properties = record.properties or {}
    return RelationshipClaimRow(
        relationship_id=record.relationship_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        source_record_id=str(properties.get("source_record_id") or ""),
        source_version=str(properties.get("version") or ""),
        from_entity_id=record.from_entity_id,
        relation_type=record.relation_type,
        to_entity_id=record.to_entity_id,
        properties=record.properties,
        evidence_anchor_id=record.evidence_anchor_id,
        additional_evidence_anchor_ids=record.additional_evidence_anchor_ids,
        confidence=record.confidence,
        status=_enum(record.status),
        acl=_json(record.acl),
        created_at=record.created_at,
        valid_from=record.valid_from,
        valid_to=record.valid_to,
        recorded_from=record.recorded_from,
        recorded_to=record.recorded_to,
    )


def _relationship_record(row: RelationshipClaimRow) -> RelationshipClaimRecord:
    return RelationshipClaimRecord(
        relationship_id=row.relationship_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        from_entity_id=row.from_entity_id,
        relation_type=row.relation_type,
        to_entity_id=row.to_entity_id,
        properties=row.properties,
        evidence_anchor_id=row.evidence_anchor_id,
        additional_evidence_anchor_ids=row.additional_evidence_anchor_ids,
        confidence=row.confidence,
        status=row.status,
        acl=row.acl,
        created_at=_aware(row.created_at),
        valid_from=_aware(row.valid_from),
        valid_to=_aware(row.valid_to),
        recorded_from=_aware(row.recorded_from),
        recorded_to=_aware(row.recorded_to),
    )


def _review_task_row(record: ReviewTaskRecord) -> ReviewTaskRow:
    return ReviewTaskRow(
        review_task_id=record.review_task_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        target_type=record.target_type,
        target_id=record.target_id,
        status=_enum(record.status),
        priority=record.priority,
        reason_codes=record.reason_codes,
        summary=record.summary,
        assignee_id=record.assignee_id,
        payload=record.payload,
        created_at=record.created_at,
        updated_at=record.updated_at,
        resolved_at=record.resolved_at,
    )


def _review_task_record(row: ReviewTaskRow) -> ReviewTaskRecord:
    return ReviewTaskRecord(
        review_task_id=row.review_task_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        target_type=row.target_type,
        target_id=row.target_id,
        status=row.status,
        priority=row.priority,
        reason_codes=row.reason_codes,
        summary=row.summary,
        assignee_id=row.assignee_id,
        payload=row.payload,
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
        resolved_at=_aware(row.resolved_at),
    )


def _decision_row(record: ReviewDecisionRecord) -> ReviewDecisionRow:
    return ReviewDecisionRow(
        decision_id=record.decision_id,
        review_task_id=record.review_task_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        target_type=record.target_type,
        target_id=record.target_id,
        decision=_enum(record.decision),
        reviewer_id=record.reviewer_id,
        reason=record.reason,
        corrections=record.corrections,
        evidence_anchor_ids=record.evidence_anchor_ids,
        decided_at=record.decided_at,
    )


def _decision_record(row: ReviewDecisionRow) -> ReviewDecisionRecord:
    return ReviewDecisionRecord(
        decision_id=row.decision_id,
        review_task_id=row.review_task_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        target_type=row.target_type,
        target_id=row.target_id,
        decision=row.decision,
        reviewer_id=row.reviewer_id,
        reason=row.reason,
        corrections=row.corrections,
        evidence_anchor_ids=row.evidence_anchor_ids,
        decided_at=_aware(row.decided_at),
    )


def _conflict_row(record: ConflictRecord) -> ConflictRow:
    return ConflictRow(
        conflict_id=record.conflict_id,
        tenant_id=record.tenant_id,
        subject_type=record.subject_type,
        subject_id=record.subject_id,
        field_path=record.field_path,
        competing_claim_ids=record.competing_claim_ids,
        severity=record.severity,
        status=_enum(record.status),
        resolution_decision_id=record.resolution_decision_id,
        details=record.details,
        created_at=record.created_at,
        resolved_at=record.resolved_at,
    )


def _conflict_record(row: ConflictRow) -> ConflictRecord:
    return ConflictRecord(
        conflict_id=row.conflict_id,
        tenant_id=row.tenant_id,
        subject_type=row.subject_type,
        subject_id=row.subject_id,
        field_path=row.field_path,
        competing_claim_ids=row.competing_claim_ids,
        severity=row.severity,
        status=row.status,
        resolution_decision_id=row.resolution_decision_id,
        details=row.details,
        created_at=_aware(row.created_at),
        resolved_at=_aware(row.resolved_at),
    )


def _projection_row(record: ProjectionEventRecord) -> ProjectionOutboxRow:
    return ProjectionOutboxRow(
        event_id=record.event_id,
        tenant_id=record.tenant_id,
        projection_name=record.projection_name,
        idempotency_key=record.idempotency_key,
        aggregate_type=record.aggregate_type,
        aggregate_id=record.aggregate_id,
        event_type=record.event_type,
        payload=record.payload,
        status=_enum(record.status),
        attempts=record.attempts,
        available_at=record.available_at,
        leased_until=record.leased_until,
        delivered_at=record.delivered_at,
        last_error=record.last_error,
        created_at=record.created_at,
    )


def _projection_record(row: ProjectionOutboxRow) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        event_id=row.event_id,
        tenant_id=row.tenant_id,
        projection_name=row.projection_name,
        idempotency_key=row.idempotency_key,
        aggregate_type=row.aggregate_type,
        aggregate_id=row.aggregate_id,
        event_type=row.event_type,
        payload=row.payload,
        status=row.status,
        attempts=row.attempts,
        available_at=_aware(row.available_at),
        leased_until=_aware(row.leased_until),
        delivered_at=_aware(row.delivered_at),
        last_error=row.last_error,
        created_at=_aware(row.created_at),
    )


def _knowledge_chunk_row(
    record: KnowledgeChunk,
    acl: dict[str, Any],
    created_at: datetime,
) -> KnowledgeChunkRow:
    return KnowledgeChunkRow(
        chunk_id=record.chunk_id,
        tenant_id=record.tenant_id,
        record_id=record.record_id,
        source_record_id=record.source_record_id,
        version=record.version,
        chunk_kind=record.chunk_kind,
        ordinal=record.ordinal,
        text=record.text,
        content_sha256=record.content_sha256,
        field_paths=record.field_paths,
        claim_ids=record.claim_ids,
        source_refs=[ref.model_dump(mode="json") for ref in record.source_refs],
        confidence=record.confidence,
        status=record.status,
        metadata_json=record.metadata,
        acl=acl,
        created_at=created_at,
    )


def _knowledge_index_row(
    record: FieldIndexDocument,
    acl: dict[str, Any],
    created_at: datetime,
) -> KnowledgeIndexRow:
    return KnowledgeIndexRow(
        index_id=record.index_id,
        tenant_id=record.tenant_id,
        record_id=record.record_id,
        source_record_id=record.source_record_id,
        version=record.version,
        document_type=record.document_type,
        document_subtype=record.document_subtype,
        status=record.status,
        text=record.text,
        vector_text=record.vector_text,
        selected_fields=record.selected_fields,
        graph_keys=record.graph_keys,
        source_refs=[ref.model_dump(mode="json") for ref in record.source_refs],
        metadata_json=record.metadata,
        acl=acl,
        created_at=created_at,
    )


def _knowledge_index_record(row: KnowledgeIndexRow) -> FieldIndexDocument:
    return FieldIndexDocument(
        index_id=row.index_id,
        tenant_id=row.tenant_id,
        record_id=row.record_id,
        source_record_id=row.source_record_id,
        version=row.version,
        document_type=row.document_type,
        document_subtype=row.document_subtype,
        status=row.status,
        text=row.text,
        vector_text=row.vector_text,
        selected_fields=row.selected_fields,
        graph_keys=row.graph_keys,
        source_refs=row.source_refs,
        metadata=row.metadata_json,
    )
