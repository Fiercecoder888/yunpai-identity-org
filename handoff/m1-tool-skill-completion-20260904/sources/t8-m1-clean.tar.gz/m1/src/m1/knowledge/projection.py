"""Deterministic Wiki, chunk, search-index and property-graph projections."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel

from m1.documents.models import DocumentRecord, FieldMetadata, SourceReference

from .graph_taxonomy import canonical_document_graph_label
from .models import (
    FieldClaim,
    FieldIndexDocument,
    GraphEdge,
    GraphNode,
    GraphProjection,
    KnowledgeChunk,
    KnowledgeRecord,
    KnowledgeSource,
    SemanticMergeResult,
)

# Only these fields may be supplied by a semantic model.  All other document.v2
# values are source facts or deterministic calculations and are write protected.
SEMANTIC_LINE_FIELDS = frozenset(
    {"name_normalized", "full_product_name", "product_category", "name_attributes"}
)

INDEXED_HEADER_FIELDS = (
    "title",
    "issuer",
    "order_number",
    "contract_number",
    "date_raw",
    "date_standard",
    "delivery_date_raw",
    "delivery_date_standard",
    "buyer",
    "seller",
    "supplier",
    "currency",
)
INDEXED_LINE_FIELDS = (
    "line_no",
    "model",
    "product_code",
    "name_raw",
    "name_normalized",
    "full_product_name",
    "product_category",
    "specification_raw",
    "body_printing",
    "color",
    "quantity",
    "unit",
    "packaging_requirements",
    "origin",
    "remark",
)

# Dynamic business columns are useful search evidence, but they are not a
# license to flatten an arbitrary document payload into the index. Keep this
# projection deliberately small and deterministic.
MAX_INDEXED_CUSTOM_FIELDS = 32
MAX_INDEXED_CUSTOM_KEY_CHARS = 80
MAX_INDEXED_CUSTOM_VALUE_CHARS = 256
MAX_INDEXED_CUSTOM_COLLECTION_ITEMS = 8
MAX_INDEXED_CUSTOM_DEPTH = 2
MAX_INDEXED_CUSTOM_TOTAL_CHARS = 2048

_NON_INDEXABLE_CUSTOM_KEYS = frozenset(
    {
        "base64",
        "binary",
        "blob",
        "bytes",
        "data_url",
        "image",
        "image_ref",
        "image_refs",
        "images",
        "raw_bytes",
        "thumbnail",
    }
)
_OMIT_CUSTOM_VALUE = object()


def _plain(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="python")
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return format(value, "f")
    return value


def _canonical_json(value: Any) -> str:
    return json.dumps(
        _plain(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )


def _stable_id(prefix: str, *parts: Any) -> str:
    payload = "\x1f".join(_canonical_json(part) for part in parts)
    return f"{prefix}_{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:32]}"


def _normalize_text(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip()


def _coerce_document(document: DocumentRecord | Mapping[str, Any] | BaseModel) -> DocumentRecord:
    if isinstance(document, DocumentRecord):
        return document
    if isinstance(document, BaseModel):
        document = document.model_dump(mode="python")
    if not isinstance(document, Mapping):
        raise TypeError("document must be a DocumentRecord or m1.document.v2 mapping")
    return DocumentRecord.model_validate(dict(document))


def _version_and_source_id(
    document: DocumentRecord, tenant_id: str, source_record_id: str | None, version: str | None
) -> tuple[str, str]:
    source = document.source
    logical_locator = source.archive_path or source.original_filename or source.sha256
    resolved_source_id = source_record_id or _stable_id(
        "src", tenant_id, logical_locator, source.mime_type
    )
    resolved_version = version or source.sha256 or _stable_id(
        "ver", document.model_dump(mode="json")
    )
    return resolved_source_id, resolved_version


def _source(document: DocumentRecord, source_record_id: str) -> KnowledgeSource:
    return KnowledgeSource(
        source_record_id=source_record_id,
        original_filename=document.source.original_filename,
        display_filename=document.source.display_filename,
        sha256=document.source.sha256,
        mime_type=document.source.mime_type,
        archive_path=document.source.archive_path,
    )


def _fallback_refs(document: DocumentRecord) -> list[SourceReference]:
    ref = SourceReference(
        sheet=document.source.sheet,
        page=document.source.page,
        archive_path=document.source.archive_path,
    )
    return [] if not any(ref.model_dump(exclude_none=True).values()) else [ref]


def _refs_for_path(
    document: DocumentRecord, path: str, fallback: list[SourceReference]
) -> tuple[list[SourceReference], FieldMetadata | None]:
    metadata = document.field_meta.get(path)
    if metadata is None:
        # A leaf in a nested semantic/factual object may inherit the evidence of
        # its nearest declared parent, but never of a sibling.
        candidates = [
            (meta_path, meta)
            for meta_path, meta in document.field_meta.items()
            if path.startswith((f"{meta_path}.", f"{meta_path}["))
        ]
        if candidates:
            _, metadata = max(candidates, key=lambda item: len(item[0]))
    return (list(metadata.source_refs) if metadata and metadata.source_refs else list(fallback)), metadata


def _join_path(base: str, key: str) -> str:
    return f"{base}.{key}" if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) else (
        f"{base}[{json.dumps(key, ensure_ascii=False)}]"
    )


def _leaves(value: Any, path: str) -> Iterable[tuple[str, Any]]:
    value = _plain(value)
    if isinstance(value, Mapping):
        for key in sorted(value):
            yield from _leaves(value[key], _join_path(path, str(key)))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from _leaves(item, f"{path}[{index}]")
    elif value not in (None, "", [], {}):
        yield path, value


def _value_type(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float, Decimal)):
        return "number"
    if isinstance(value, (date, datetime)):
        return "date"
    return "string" if isinstance(value, str) else type(value).__name__


def _claim_origin(path: str, metadata: FieldMetadata | None, semantic: bool) -> str:
    if semantic:
        return "semantic"
    if metadata and metadata.inferred:
        return "deterministic_inference"
    if path.startswith("$.totals.system_calculated") or ".calculated_" in path:
        return "deterministic_calculation"
    return "source"


def _make_claims(
    *,
    document: DocumentRecord,
    tenant_id: str,
    record_id: str,
    source_record_id: str,
    version: str,
    items: Iterable[tuple[str, Any, bool]],
    status: str,
    fallback_refs: list[SourceReference],
) -> list[FieldClaim]:
    claims: list[FieldClaim] = []
    for root_path, value, semantic in items:
        for path, leaf in _leaves(value, root_path):
            refs, metadata = _refs_for_path(document, path, fallback_refs)
            origin = _claim_origin(path, metadata, semantic)
            confidence = metadata.confidence if metadata else 1.0
            claims.append(
                FieldClaim(
                    claim_id=_stable_id(
                        "claim", tenant_id, record_id, version, path, leaf, origin
                    ),
                    tenant_id=tenant_id,
                    record_id=record_id,
                    source_record_id=source_record_id,
                    version=version,
                    path=path,
                    value=_plain(leaf),
                    value_type=_value_type(leaf),
                    origin=origin,
                    fact_locked=not semantic,
                    confidence=confidence,
                    status=status,
                    inferred=bool(metadata and metadata.inferred),
                    source_refs=refs,
                )
            )
    return claims


def _dedupe_refs(refs: Iterable[SourceReference]) -> list[SourceReference]:
    seen: set[str] = set()
    output: list[SourceReference] = []
    for ref in refs:
        key = _canonical_json(ref)
        if key not in seen:
            seen.add(key)
            output.append(ref)
    return output


def build_knowledge_records(
    document: DocumentRecord | Mapping[str, Any] | BaseModel,
    *,
    tenant_id: str = "default",
    source_record_id: str | None = None,
    version: str | None = None,
) -> list[KnowledgeRecord]:
    """Create the canonical, evidence-backed staging records for one document.

    The output is deterministic and append-friendly.  It does not resolve master
    identities; ``canonical_key`` is a stable candidate key for the Wiki layer.
    """

    doc = _coerce_document(document)
    source_record_id, version = _version_and_source_id(
        doc, tenant_id, source_record_id, version
    )
    source = _source(doc, source_record_id)
    status = "candidate" if doc.needs_review else "active"
    fallback_refs = _fallback_refs(doc)
    records: list[KnowledgeRecord] = []

    document_id = _stable_id("record", tenant_id, source_record_id, "document")
    header = doc.header.model_dump(mode="python")
    totals = doc.totals.model_dump(mode="python")
    indexed_generic_facts = [fact for fact in doc.generic_facts if not fact.sensitive]
    generic_fact_items = tuple(
        (
            f"$.generic_facts[{index}].value",
            fact.value,
            str((fact.model_extra or {}).get("authority") or "").casefold()
            == "advisory",
        )
        for index, fact in enumerate(doc.generic_facts)
        if not fact.sensitive
    )
    doc_claims = _make_claims(
        document=doc,
        tenant_id=tenant_id,
        record_id=document_id,
        source_record_id=source_record_id,
        version=version,
        items=(
            ("$.header", header, False),
            ("$.totals", totals, False),
            *generic_fact_items,
        ),
        status=status,
        fallback_refs=fallback_refs,
    )
    canonical_document_key = (
        doc.header.order_number
        or doc.header.contract_number
        or f"{doc.document_type}:{source_record_id}"
    )
    records.append(
        KnowledgeRecord(
            record_id=document_id,
            tenant_id=tenant_id,
            record_type="document",
            document_type=doc.document_type,
            document_subtype=doc.document_subtype,
            canonical_key=_normalize_text(canonical_document_key),
            source_path="$",
            source=source,
            version=version,
            status=status,
            confidence=min((claim.confidence for claim in doc_claims), default=1.0),
            facts={
                "header": _plain(header),
                "totals": _plain(totals),
                "generic_facts": [
                    _plain(fact.model_dump(mode="python"))
                    for fact in indexed_generic_facts
                ],
                "needs_review": doc.needs_review,
            },
            claims=doc_claims,
            source_refs=_dedupe_refs(ref for claim in doc_claims for ref in claim.source_refs),
        )
    )

    for index, line in enumerate(doc.lines):
        path = f"$.lines[{index}]"
        payload = line.model_dump(mode="python")
        semantic = {
            key: payload.pop(key)
            for key in tuple(payload)
            if key in SEMANTIC_LINE_FIELDS and payload.get(key) not in (None, "", {}, [])
        }
        line_identity = line.line_id or str(line.line_no or index + 1)
        record_id = _stable_id(
            "record", tenant_id, source_record_id, "line", line_identity
        )
        fact_items = [(path, payload, False)]
        semantic_items = [(_join_path(path, key), value, True) for key, value in semantic.items()]
        claims = _make_claims(
            document=doc,
            tenant_id=tenant_id,
            record_id=record_id,
            source_record_id=source_record_id,
            version=version,
            items=(*fact_items, *semantic_items),
            status=status,
            fallback_refs=fallback_refs,
        )
        canonical_key = line.product_code or line.model or line.name_raw or line_identity
        records.append(
            KnowledgeRecord(
                record_id=record_id,
                tenant_id=tenant_id,
                record_type="document_line",
                document_type=doc.document_type,
                document_subtype=doc.document_subtype,
                canonical_key=_normalize_text(canonical_key),
                source_path=path,
                source=source,
                version=version,
                status=status,
                confidence=min((claim.confidence for claim in claims), default=1.0),
                facts=_plain(payload),
                semantic_annotations=_plain(semantic),
                claims=claims,
                source_refs=_dedupe_refs(ref for claim in claims for ref in claim.source_refs),
            )
        )
    return records


def _display_value(value: Any) -> str:
    if isinstance(value, Mapping):
        return "; ".join(
            f"{key}={_display_value(item)}"
            for key, item in value.items()
            if item not in (None, "", {}, [])
        )
    if isinstance(value, list):
        return ", ".join(_display_value(item) for item in value)
    return _normalize_text(value)


def _selected(mapping: Mapping[str, Any], fields: Sequence[str]) -> dict[str, Any]:
    return {
        field: _plain(mapping[field])
        for field in fields
        if mapping.get(field) not in (None, "", {}, [])
    }


def _custom_key(value: Any) -> str | None:
    key = _normalize_text(value)
    if not key or len(key) > MAX_INDEXED_CUSTOM_KEY_CHARS:
        return None
    compact = re.sub(r"[\s._-]+", "_", key.casefold()).strip("_")
    if any(compact.endswith(blocked) for blocked in _NON_INDEXABLE_CUSTOM_KEYS):
        return None
    return key


def _bounded_custom_scalar(value: Any) -> Any:
    if isinstance(value, (bytes, bytearray, memoryview)):
        return _OMIT_CUSTOM_VALUE
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        rendered = str(value)
        return value if len(rendered) <= MAX_INDEXED_CUSTOM_VALUE_CHARS else (
            rendered[: MAX_INDEXED_CUSTOM_VALUE_CHARS - 3] + "..."
        )
    if isinstance(value, float):
        if not math.isfinite(value):
            return _OMIT_CUSTOM_VALUE
        rendered = str(value)
        return value if len(rendered) <= MAX_INDEXED_CUSTOM_VALUE_CHARS else (
            rendered[: MAX_INDEXED_CUSTOM_VALUE_CHARS - 3] + "..."
        )
    if isinstance(value, Decimal):
        if not value.is_finite():
            return _OMIT_CUSTOM_VALUE
        value = format(value, "f")
    elif isinstance(value, (date, datetime)):
        value = value.isoformat()
    if not isinstance(value, str):
        return _OMIT_CUSTOM_VALUE
    text = _normalize_text(value)
    if not text:
        return _OMIT_CUSTOM_VALUE
    lowered = text.casefold()
    if lowered.startswith("data:") and ";base64," in lowered[:256]:
        return _OMIT_CUSTOM_VALUE
    if len(text) > MAX_INDEXED_CUSTOM_VALUE_CHARS:
        text = text[: MAX_INDEXED_CUSTOM_VALUE_CHARS - 3].rstrip() + "..."
    return text


def _bounded_custom_value(value: Any, *, depth: int = 0) -> Any:
    if isinstance(value, BaseModel):
        value = value.model_dump(mode="python")
    if isinstance(value, Mapping):
        if depth >= MAX_INDEXED_CUSTOM_DEPTH:
            return _OMIT_CUSTOM_VALUE
        output: dict[str, Any] = {}
        ordered = sorted(
            value.items(),
            key=lambda item: (_normalize_text(item[0]).casefold(), _normalize_text(item[0])),
        )
        for raw_key, raw_value in ordered:
            key = _custom_key(raw_key)
            if key is None or key in output:
                continue
            bounded = _bounded_custom_value(raw_value, depth=depth + 1)
            if bounded is _OMIT_CUSTOM_VALUE:
                continue
            output[key] = bounded
            if len(output) >= MAX_INDEXED_CUSTOM_COLLECTION_ITEMS:
                break
        return output or _OMIT_CUSTOM_VALUE
    if isinstance(value, (list, tuple)):
        if depth >= MAX_INDEXED_CUSTOM_DEPTH:
            return _OMIT_CUSTOM_VALUE
        output_list: list[Any] = []
        for item in value:
            bounded = _bounded_custom_value(item, depth=depth + 1)
            if bounded is _OMIT_CUSTOM_VALUE:
                continue
            output_list.append(bounded)
            if len(output_list) >= MAX_INDEXED_CUSTOM_COLLECTION_ITEMS:
                break
        return output_list or _OMIT_CUSTOM_VALUE
    return _bounded_custom_scalar(value)


def _indexed_custom_fields(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {}
    output: dict[str, Any] = {}
    ordered = sorted(
        value.items(),
        key=lambda item: (_normalize_text(item[0]).casefold(), _normalize_text(item[0])),
    )
    for raw_key, raw_value in ordered:
        if len(output) >= MAX_INDEXED_CUSTOM_FIELDS:
            break
        key = _custom_key(raw_key)
        if key is None or key in output:
            continue
        bounded = _bounded_custom_value(raw_value)
        if bounded is _OMIT_CUSTOM_VALUE:
            continue
        candidate = {**output, key: bounded}
        if len(_canonical_json(candidate)) > MAX_INDEXED_CUSTOM_TOTAL_CHARS:
            continue
        output = candidate
    return output


def _render_fields(fields: Mapping[str, Any]) -> str:
    return "\n".join(f"{key}: {_display_value(value)}" for key, value in fields.items())


def _split_text(text: str, max_chars: int) -> list[str]:
    text = _normalize_text(text)
    if not text:
        return []
    if max_chars < 256:
        raise ValueError("max_chars must be at least 256")
    pieces: list[str] = []
    remaining = text
    while len(remaining) > max_chars:
        boundary = remaining.rfind("\n", 0, max_chars + 1)
        if boundary < max_chars // 2:
            boundary = remaining.rfind("。", 0, max_chars + 1)
            if boundary >= max_chars // 2:
                boundary += 1
        if boundary < max_chars // 2:
            boundary = max_chars
        pieces.append(remaining[:boundary].strip())
        remaining = remaining[boundary:].strip()
    if remaining:
        pieces.append(remaining)
    return pieces


def _extraction(document: DocumentRecord) -> dict[str, Any]:
    return document.extraction if isinstance(document.extraction, dict) else {}


def _section_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if not isinstance(content, Mapping):
        return ""
    for key in ("text_normalized", "text_original", "text"):
        if content.get(key):
            return _normalize_text(content[key])
    rows = content.get("rows") or content.get("rows_normalized")
    if isinstance(rows, list):
        rendered: list[str] = []
        for row in rows:
            if isinstance(row, list):
                rendered.append(" | ".join(_section_text(cell) or _display_value(cell) for cell in row))
        return "\n".join(rendered)
    return ""


def _section_ref(section: Mapping[str, Any], ordinal: int) -> SourceReference:
    page = section.get("page") or section.get("page_number")
    source_ref = str(section.get("source_ref") or "")
    part = source_ref or None
    if source_ref.startswith("page:"):
        try:
            page = int(source_ref.split(":", 1)[1])
            part = None
        except ValueError:
            pass
    return SourceReference(page=int(page) if page is not None else None, part=part)


def build_knowledge_chunks(
    document: DocumentRecord | Mapping[str, Any] | BaseModel,
    *,
    tenant_id: str = "default",
    source_record_id: str | None = None,
    version: str | None = None,
    max_chars: int = 4000,
) -> list[KnowledgeChunk]:
    """Split one document into deterministic header, line and evidence/page chunks."""

    doc = _coerce_document(document)
    records = build_knowledge_records(
        doc, tenant_id=tenant_id, source_record_id=source_record_id, version=version
    )
    root = records[0]
    chunks: list[KnowledgeChunk] = []

    def add(
        *,
        record: KnowledgeRecord,
        kind: str,
        locator: str,
        text: str,
        refs: list[SourceReference],
        paths: list[str],
        claims: list[str],
        ordinal: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        normalized = _normalize_text(text)
        if not normalized:
            return
        content_sha256 = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
        chunks.append(
            KnowledgeChunk(
                chunk_id=_stable_id(
                    "chunk",
                    tenant_id,
                    root.source.source_record_id,
                    root.version,
                    kind,
                    locator,
                    ordinal,
                    content_sha256,
                ),
                tenant_id=tenant_id,
                record_id=record.record_id,
                source_record_id=root.source.source_record_id,
                version=root.version,
                chunk_kind=kind,
                ordinal=ordinal,
                text=normalized,
                content_sha256=content_sha256,
                field_paths=paths,
                claim_ids=claims,
                source_refs=_dedupe_refs(refs),
                confidence=record.confidence,
                status=record.status,
                metadata=metadata or {},
            )
        )

    header_fields = _selected(root.facts.get("header", {}), INDEXED_HEADER_FIELDS)
    add(
        record=root,
        kind="header",
        locator="header",
        text=_render_fields(header_fields),
        refs=root.source_refs,
        paths=[claim.path for claim in root.claims if claim.path.startswith("$.header")],
        claims=[claim.claim_id for claim in root.claims if claim.path.startswith("$.header")],
        metadata={"selected_fields": header_fields},
    )

    for line_record in records[1:]:
        line_fields = _selected(line_record.facts, INDEXED_LINE_FIELDS)
        line_fields.update(_selected(line_record.semantic_annotations, INDEXED_LINE_FIELDS))
        if line_record.semantic_annotations.get("name_attributes"):
            line_fields["name_attributes"] = line_record.semantic_annotations["name_attributes"]
        custom_fields = _indexed_custom_fields(line_record.facts.get("custom_fields"))
        if custom_fields:
            line_fields["custom_fields"] = custom_fields
        add(
            record=line_record,
            kind="line",
            locator=line_record.source_path,
            text=_render_fields(line_fields),
            refs=line_record.source_refs,
            paths=[claim.path for claim in line_record.claims],
            claims=[claim.claim_id for claim in line_record.claims],
            metadata={"selected_fields": line_fields, "canonical_key": line_record.canonical_key},
        )

    for index, fact in enumerate(doc.generic_facts):
        if fact.sensitive:
            continue
        path = f"$.generic_facts[{index}].value"
        claims = [
            claim
            for claim in root.claims
            if claim.path == path
            or claim.path.startswith((f"{path}.", f"{path}["))
        ]
        selected_fields = {fact.name: _plain(fact.value)}
        for segment, piece in enumerate(
            _split_text(_render_fields(selected_fields), max_chars)
        ):
            add(
                record=root,
                kind="generic_fact",
                locator=f"generic_fact:{index}",
                text=piece,
                refs=list(fact.source_refs)
                or [ref for claim in claims for ref in claim.source_refs],
                paths=[claim.path for claim in claims],
                claims=[claim.claim_id for claim in claims],
                ordinal=segment,
                metadata={
                    "generic_fact_index": index,
                    "generic_fact_name": fact.name,
                    "selected_fields": selected_fields,
                    "segment": segment,
                },
            )

    extraction = _extraction(doc)
    raw_content = extraction.get("raw_content") if isinstance(extraction.get("raw_content"), dict) else {}
    pages = raw_content.get("pages") if isinstance(raw_content, dict) else None
    if isinstance(pages, list) and pages:
        for page_index, page in enumerate(pages):
            if not isinstance(page, Mapping):
                continue
            page_number = int(page.get("page_number") or page.get("page") or page_index + 1)
            text = _section_text(page)
            for segment, piece in enumerate(_split_text(text, max_chars)):
                ref = SourceReference(page=page_number, archive_path=doc.source.archive_path)
                add(
                    record=root,
                    kind="page",
                    locator=f"page:{page_number}",
                    text=piece,
                    refs=[ref],
                    paths=[],
                    claims=[],
                    ordinal=segment,
                    metadata={"page": page_number, "segment": segment},
                )
    else:
        sections = extraction.get("sections")
        if isinstance(sections, list):
            for section_index, section in enumerate(sections):
                if not isinstance(section, Mapping):
                    continue
                locator = str(section.get("source_ref") or f"section:{section_index}")
                text = _section_text(section.get("content", section))
                ref = _section_ref(section, section_index)
                for segment, piece in enumerate(_split_text(text, max_chars)):
                    add(
                        record=root,
                        kind="evidence",
                        locator=locator,
                        text=piece,
                        refs=[ref],
                        paths=[],
                        claims=[],
                        ordinal=segment,
                        metadata={"section": section_index, "segment": segment},
                    )
    return chunks


def build_field_index_documents(
    document: DocumentRecord | Mapping[str, Any] | BaseModel,
    *,
    tenant_id: str = "default",
    source_record_id: str | None = None,
    version: str | None = None,
    max_chunk_chars: int = 4000,
) -> list[FieldIndexDocument]:
    """Build allow-listed search documents without flattening raw JSON paths."""

    doc = _coerce_document(document)
    chunks = build_knowledge_chunks(
        doc,
        tenant_id=tenant_id,
        source_record_id=source_record_id,
        version=version,
        max_chars=max_chunk_chars,
    )
    output: list[FieldIndexDocument] = []
    for chunk in chunks:
        selected_fields = dict(chunk.metadata.get("selected_fields") or {})
        graph_keys = [
            _normalize_text(value)
            for key in ("order_number", "contract_number", "product_code", "model")
            if (value := selected_fields.get(key)) not in (None, "")
        ]
        output.append(
            FieldIndexDocument(
                index_id=chunk.chunk_id,
                tenant_id=chunk.tenant_id,
                record_id=chunk.record_id,
                source_record_id=chunk.source_record_id,
                version=chunk.version,
                document_type=doc.document_type,
                document_subtype=doc.document_subtype,
                status=chunk.status,
                text=chunk.text,
                vector_text=chunk.text,
                selected_fields=selected_fields,
                graph_keys=list(dict.fromkeys(graph_keys)),
                source_refs=chunk.source_refs,
                metadata={"chunk_kind": chunk.chunk_kind, **chunk.metadata},
            )
        )
    return output


def _knowledge_records(
    value: DocumentRecord | Mapping[str, Any] | BaseModel | Sequence[KnowledgeRecord | Mapping[str, Any]],
    *,
    tenant_id: str,
    source_record_id: str | None,
    version: str | None,
) -> list[KnowledgeRecord]:
    if isinstance(value, (DocumentRecord, BaseModel, Mapping)):
        # KnowledgeRecord mappings are accepted as a one-element canonical input.
        if isinstance(value, KnowledgeRecord):
            return [value]
        if isinstance(value, Mapping) and "record_type" in value and "record_id" in value:
            return [KnowledgeRecord.model_validate(value)]
        return build_knowledge_records(
            value, tenant_id=tenant_id, source_record_id=source_record_id, version=version
        )
    return [
        item if isinstance(item, KnowledgeRecord) else KnowledgeRecord.model_validate(item)
        for item in value
    ]


def _node_id(tenant_id: str, kind: str, canonical_key: str) -> str:
    return _stable_id("node", tenant_id, kind, _normalize_text(canonical_key).casefold())


def _edge(
    *,
    relation: str,
    from_node: str,
    to_node: str,
    record: KnowledgeRecord,
    properties: dict[str, Any] | None = None,
) -> GraphEdge:
    return GraphEdge(
        edge_id=_stable_id(
            "edge", record.tenant_id, relation, from_node, to_node, record.source.source_record_id, record.version
        ),
        relation=relation,
        from_node=from_node,
        to_node=to_node,
        tenant_id=record.tenant_id,
        source_record_id=record.source.source_record_id,
        version=record.version,
        status=record.status,
        confidence=record.confidence,
        source_refs=record.source_refs,
        source_claim_ids=[claim.claim_id for claim in record.claims],
        properties=properties or {},
    )


def build_graph_projection(
    value: DocumentRecord
    | Mapping[str, Any]
    | BaseModel
    | Sequence[KnowledgeRecord | Mapping[str, Any]],
    *,
    tenant_id: str = "default",
    source_record_id: str | None = None,
    version: str | None = None,
) -> GraphProjection:
    """Generate a replaceable property-graph projection from canonical records."""

    records = _knowledge_records(
        value,
        tenant_id=tenant_id,
        source_record_id=source_record_id,
        version=version,
    )
    if not records:
        raise ValueError("at least one knowledge record is required")
    document_records = [record for record in records if record.record_type == "document"]
    if len(document_records) != 1:
        raise ValueError("graph projection requires exactly one document knowledge record")
    root = document_records[0]
    for record in records:
        if record.tenant_id != root.tenant_id:
            raise ValueError("graph projection cannot cross tenant boundaries")
        if record.source.source_record_id != root.source.source_record_id:
            raise ValueError("graph projection cannot combine different source records")
        if record.version != root.version:
            raise ValueError("graph projection cannot combine different source versions")
    tenant_id = root.tenant_id
    document_node_id = _node_id(tenant_id, "document", root.record_id)
    header = root.facts.get("header", {})
    labels = ["Document"]
    document_label = canonical_document_graph_label(root.document_type)
    if document_label is not None:
        labels.append(document_label)
    document_claims = [claim.claim_id for claim in root.claims]
    nodes: dict[str, GraphNode] = {
        document_node_id: GraphNode(
            node_id=document_node_id,
            labels=labels,
            tenant_id=tenant_id,
            source_record_id=root.source.source_record_id,
            version=root.version,
            status=root.status,
            confidence=root.confidence,
            source_refs=root.source_refs,
            source_claim_ids=document_claims,
            properties={
                "record_id": root.record_id,
                "canonical_key": root.canonical_key,
                "document_type": root.document_type,
                "document_subtype": root.document_subtype,
                **_selected(header, INDEXED_HEADER_FIELDS),
            },
        )
    }
    edges: dict[str, GraphEdge] = {}

    organization_relations = {
        "issuer": "ISSUED_BY",
        "buyer": "HAS_BUYER",
        "seller": "HAS_SELLER",
        "supplier": "HAS_SUPPLIER",
    }
    for field, relation in organization_relations.items():
        name = header.get(field)
        if not name:
            continue
        org_id = _node_id(tenant_id, "organization", str(name))
        relevant = [claim for claim in root.claims if claim.path == f"$.header.{field}"]
        nodes[org_id] = GraphNode(
            node_id=org_id,
            labels=["Organization"],
            tenant_id=tenant_id,
            source_record_id=root.source.source_record_id,
            version=root.version,
            status=root.status,
            confidence=min((claim.confidence for claim in relevant), default=root.confidence),
            source_refs=_dedupe_refs(ref for claim in relevant for ref in claim.source_refs),
            source_claim_ids=[claim.claim_id for claim in relevant],
            properties={"name": name, "canonical_key": _normalize_text(name)},
        )
        relation_edge = _edge(
            relation=relation, from_node=document_node_id, to_node=org_id, record=root
        )
        edges[relation_edge.edge_id] = relation_edge

    for line_record in (record for record in records if record.record_type == "document_line"):
        line_id = _node_id(tenant_id, "document_line", line_record.record_id)
        line_label = {
            "order": "OrderLine",
            "inventory": "InventoryLine",
            "equipment": "EquipmentRecord",
            "mold": "MoldRecord",
        }.get(line_record.document_type, "DocumentLine")
        selected = _selected(line_record.facts, INDEXED_LINE_FIELDS)
        selected.update(_selected(line_record.semantic_annotations, INDEXED_LINE_FIELDS))
        nodes[line_id] = GraphNode(
            node_id=line_id,
            labels=[line_label],
            tenant_id=tenant_id,
            source_record_id=line_record.source.source_record_id,
            version=line_record.version,
            status=line_record.status,
            confidence=line_record.confidence,
            source_refs=line_record.source_refs,
            source_claim_ids=[claim.claim_id for claim in line_record.claims],
            properties={
                "record_id": line_record.record_id,
                "canonical_key": line_record.canonical_key,
                **selected,
            },
        )
        contains = _edge(
            relation="HAS_LINE",
            from_node=document_node_id,
            to_node=line_id,
            record=line_record,
            properties={"source_path": line_record.source_path},
        )
        edges[contains.edge_id] = contains

        product_key = (
            line_record.facts.get("product_code")
            or line_record.facts.get("model")
            or line_record.facts.get("name_raw")
        )
        if product_key:
            product_id = _node_id(tenant_id, "product", str(product_key))
            product_claims = [
                claim
                for claim in line_record.claims
                if any(
                    claim.path.endswith(f".{field}")
                    for field in ("product_code", "model", "name_raw")
                )
            ]
            nodes[product_id] = GraphNode(
                node_id=product_id,
                labels=["Product"],
                tenant_id=tenant_id,
                source_record_id=line_record.source.source_record_id,
                version=line_record.version,
                status=line_record.status,
                confidence=min(
                    (claim.confidence for claim in product_claims), default=line_record.confidence
                ),
                source_refs=_dedupe_refs(ref for claim in product_claims for ref in claim.source_refs),
                source_claim_ids=[claim.claim_id for claim in product_claims],
                properties={
                    "canonical_key": _normalize_text(product_key),
                    **_selected(
                        {**line_record.facts, **line_record.semantic_annotations},
                        ("product_code", "model", "name_raw", "name_normalized", "product_category"),
                    ),
                },
            )
            product_edge = _edge(
                relation="REFERS_TO_PRODUCT",
                from_node=line_id,
                to_node=product_id,
                record=line_record,
            )
            edges[product_edge.edge_id] = product_edge

    return GraphProjection(
        projection_id=_stable_id(
            "projection", tenant_id, root.source.source_record_id, root.version
        ),
        tenant_id=tenant_id,
        source_record_id=root.source.source_record_id,
        version=root.version,
        nodes=list(nodes.values()),
        edges=list(edges.values()),
    )


def apply_semantic_enrichment(
    document: DocumentRecord | Mapping[str, Any] | BaseModel,
    enrichment: Mapping[str, Any],
) -> SemanticMergeResult:
    """Apply only semantic line annotations and reject every attempted fact edit.

    ``line_id`` is used for matching when present; otherwise list position is
    used.  The input is copied, so neither a Pydantic model nor caller dictionary
    is mutated.
    """

    doc = _coerce_document(document)
    output = doc.model_dump(mode="python")
    applied: list[str] = []
    rejected: list[str] = []
    for key in enrichment:
        if key != "lines":
            rejected.append(f"$.{key}")
    incoming_lines = enrichment.get("lines", [])
    if not isinstance(incoming_lines, list):
        return SemanticMergeResult(
            document=_plain(output), applied_paths=[], rejected_paths=["$.lines"]
        )
    by_id = {
        str(line.get("line_id")): index
        for index, line in enumerate(output.get("lines", []))
        if isinstance(line, dict) and line.get("line_id") is not None
    }
    for incoming_index, patch in enumerate(incoming_lines):
        if not isinstance(patch, Mapping):
            rejected.append(f"$.lines[{incoming_index}]")
            continue
        target_index = by_id.get(str(patch.get("line_id")), incoming_index)
        if target_index >= len(output.get("lines", [])):
            rejected.append(f"$.lines[{incoming_index}]")
            continue
        target = output["lines"][target_index]
        for field, value in patch.items():
            path = f"$.lines[{target_index}].{field}"
            if field == "line_id":
                continue
            if field not in SEMANTIC_LINE_FIELDS:
                rejected.append(path)
                continue
            target[field] = copy.deepcopy(_plain(value))
            applied.append(path)
    # Revalidate to discard malformed semantic structures without ever weakening
    # the factual allow-list above.
    validated = DocumentRecord.model_validate(output)
    return SemanticMergeResult(
        document=validated.model_dump(mode="json"),
        applied_paths=applied,
        rejected_paths=rejected,
    )


__all__ = [
    "INDEXED_HEADER_FIELDS",
    "INDEXED_LINE_FIELDS",
    "SEMANTIC_LINE_FIELDS",
    "apply_semantic_enrichment",
    "build_field_index_documents",
    "build_graph_projection",
    "build_knowledge_chunks",
    "build_knowledge_records",
]
