"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any, TypeVar

from pydantic import BaseModel
from sqlalchemy import (
    delete,
    func,
    select,
)
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    ConflictRow,
    DocumentVersionRow,
    FieldClaimRow,
    GraphGenerationRow,
    GraphProjectionSnapshotRow,
    KnowledgeChunkRow,
    KnowledgeDocumentRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    RelationshipClaimRow,
    ReviewTaskRow,
    TenantBoundaryError,
)
from .models import (
    GraphProjection,
)
from .persistence_helpers import (
    _knowledge_chunk_row,
    _knowledge_index_row,
    _projection_status,
    _sha256_json,
)
from .schema import (
    ClaimStatus,
    ConflictStatus,
    LifecycleStatus,
    OutboxStatus,
    ProjectionEventRecord,
    ProjectionReplaceResult,
    ReviewTaskStatus,
    TaskFenceToken,
    new_id,
    utc_now,
)

T = TypeVar("T")


class KnowledgeProjectionMixin:
    async def _lock_graph_generation_row(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        source_record_id: str,
    ) -> GraphGenerationRow:
        statement = (
            select(GraphGenerationRow)
            .where(
                GraphGenerationRow.tenant_id == tenant_id,
                GraphGenerationRow.source_record_id == source_record_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        row = await session.scalar(statement)
        if row is not None:
            return row
        values = {
            "generation_id": new_id(),
            "source_record_id": source_record_id,
            "tenant_id": tenant_id,
            "generation": 0,
            "updated_at": utc_now(),
        }
        dialect = session.get_bind().dialect.name
        if dialect == "postgresql":
            insert = postgresql_insert(GraphGenerationRow).values(**values)
        elif dialect == "sqlite":
            insert = sqlite_insert(GraphGenerationRow).values(**values)
        else:  # pragma: no cover - supported stores are PostgreSQL/SQLite
            raise RuntimeError(f"unsupported graph generation database: {dialect}")
        await session.execute(
            insert.on_conflict_do_nothing(
                index_elements=[
                    GraphGenerationRow.tenant_id,
                    GraphGenerationRow.source_record_id,
                ]
            )
        )
        row = await session.scalar(statement)
        if row is None:  # pragma: no cover - insert/select share one transaction
            raise RuntimeError("graph generation row was not materialized")
        return row

    async def _next_graph_generation(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        source_record_id: str,
    ) -> int:
        row = await self._lock_graph_generation_row(
            session,
            tenant_id=tenant_id,
            source_record_id=source_record_id,
        )
        row.generation += 1
        row.updated_at = utc_now()
        await session.flush()
        return int(row.generation)

    async def replace_document_projections(
        self,
        tenant_id: str,
        document: BaseModel | Mapping[str, Any],
        source_record_id: str | None = None,
        version: str | None = None,
        status_override: str | None = None,
        fence: TaskFenceToken | None = None,
        lightrag_shadow_enabled: bool = False,
        embedding_model: str = "",
    ) -> ProjectionReplaceResult:
        """Atomically replace chunks, selected index, and graph snapshot.

        Projection builders are deterministic.  An identical replay is a
        no-op and reuses the original outbox events; changed content under the
        same source/version supersedes undelivered older events.  Candidate
        projections are routed to staging outboxes, never the active search or
        graph consumers.
        """

        # Imports remain local to keep the SQL schema usable by migration tools
        # without eagerly loading document adapters.
        from .projection import (
            build_field_index_documents,
            build_graph_projection,
            build_knowledge_chunks,
        )

        graph = build_graph_projection(
            document,
            tenant_id=tenant_id,
            source_record_id=source_record_id,
            version=version,
        )
        chunks = build_knowledge_chunks(
            document,
            tenant_id=tenant_id,
            source_record_id=graph.source_record_id,
            version=graph.version,
        )
        indexes = build_field_index_documents(
            document,
            tenant_id=tenant_id,
            source_record_id=graph.source_record_id,
            version=graph.version,
        )
        if status_override is not None:
            if status_override not in {"candidate", "active", "deprecated", "rejected"}:
                raise ValueError(
                    f"unsupported projection status override: {status_override}"
                )
            chunks = [
                item.model_copy(update={"status": status_override}) for item in chunks
            ]
            indexes = [
                item.model_copy(update={"status": status_override}) for item in indexes
            ]
            graph = graph.model_copy(
                update={
                    "nodes": [
                        item.model_copy(update={"status": status_override})
                        for item in graph.nodes
                    ],
                    "edges": [
                        item.model_copy(update={"status": status_override})
                        for item in graph.edges
                    ],
                }
            )
        for item in [*chunks, *indexes, *graph.nodes, *graph.edges]:
            if item.tenant_id != tenant_id:
                raise TenantBoundaryError(item.tenant_id)
            if (
                item.source_record_id != graph.source_record_id
                or item.version != graph.version
            ):
                raise ValueError(
                    "projection builders returned inconsistent source/version"
                )
        status = _projection_status(
            [item.status for item in [*indexes, *graph.nodes, *graph.edges]]
        )

        async def operation(session: AsyncSession) -> ProjectionReplaceResult:
            if fence is not None:
                await self._assert_task_fence(
                    session,
                    fence,
                    tenant_id=tenant_id,
                    task_id=fence.task_id,
                )
            tenant = await self._require_tenant(session, tenant_id)
            await self._lock_graph_generation_row(
                session,
                tenant_id=tenant_id,
                source_record_id=graph.source_record_id,
            )
            if fence is not None:
                await self._assert_fenced_version_binding(
                    session,
                    fence,
                    tenant_id=tenant_id,
                    source_record_id=graph.source_record_id,
                    source_version=graph.version,
                    fence_locked=True,
                )
            acl = tenant.default_acl or {}
            if status == "active":
                await self._activate_document_projection(
                    session,
                    tenant_id=tenant_id,
                    source_record_id=graph.source_record_id,
                    version=graph.version,
                )
            projected_graph = await self._merge_logical_relationships(
                session,
                graph,
                projection_status=status,
            )
            canonical_graph_payload = projected_graph.model_dump(mode="json")
            fingerprint = _sha256_json(
                {
                    "chunks": [item.model_dump(mode="json") for item in chunks],
                    "index": [item.model_dump(mode="json") for item in indexes],
                    "graph": canonical_graph_payload,
                }
            )
            existing = await session.scalar(
                select(GraphProjectionSnapshotRow).where(
                    GraphProjectionSnapshotRow.tenant_id == tenant_id,
                    GraphProjectionSnapshotRow.source_record_id
                    == graph.source_record_id,
                    GraphProjectionSnapshotRow.version == graph.version,
                )
            )
            existing_chunks = await session.scalar(
                select(func.count(KnowledgeChunkRow.chunk_id)).where(
                    KnowledgeChunkRow.tenant_id == tenant_id,
                    KnowledgeChunkRow.source_record_id == graph.source_record_id,
                    KnowledgeChunkRow.version == graph.version,
                )
            )
            existing_indexes = await session.scalar(
                select(func.count(KnowledgeIndexRow.index_id)).where(
                    KnowledgeIndexRow.tenant_id == tenant_id,
                    KnowledgeIndexRow.source_record_id == graph.source_record_id,
                    KnowledgeIndexRow.version == graph.version,
                )
            )
            unchanged = bool(
                existing
                and existing.fingerprint == fingerprint
                and int(existing_chunks or 0) == len(chunks)
                and int(existing_indexes or 0) == len(indexes)
            )
            persisted_graph = (
                GraphProjection.model_validate(existing.projection_json)
                if unchanged and existing is not None
                else projected_graph.model_copy(
                    update={
                        "generation": await self._next_graph_generation(
                            session,
                            tenant_id=tenant_id,
                            source_record_id=graph.source_record_id,
                        )
                    }
                )
            )
            graph_payload = persisted_graph.model_dump(mode="json")
            if not unchanged:
                await session.execute(
                    delete(KnowledgeChunkRow).where(
                        KnowledgeChunkRow.tenant_id == tenant_id,
                        KnowledgeChunkRow.source_record_id == graph.source_record_id,
                        KnowledgeChunkRow.version == graph.version,
                    )
                )
                await session.execute(
                    delete(KnowledgeIndexRow).where(
                        KnowledgeIndexRow.tenant_id == tenant_id,
                        KnowledgeIndexRow.source_record_id == graph.source_record_id,
                        KnowledgeIndexRow.version == graph.version,
                    )
                )
                await session.execute(
                    delete(GraphProjectionSnapshotRow).where(
                        GraphProjectionSnapshotRow.tenant_id == tenant_id,
                        GraphProjectionSnapshotRow.source_record_id
                        == graph.source_record_id,
                        GraphProjectionSnapshotRow.version == graph.version,
                    )
                )
                now = utc_now()
                session.add_all(
                    [_knowledge_chunk_row(item, acl, now) for item in chunks]
                )
                session.add_all(
                    [_knowledge_index_row(item, acl, now) for item in indexes]
                )
                session.add(
                    GraphProjectionSnapshotRow(
                        projection_id=persisted_graph.projection_id,
                        tenant_id=tenant_id,
                        source_record_id=graph.source_record_id,
                        version=graph.version,
                        fingerprint=fingerprint,
                        status=status,
                        node_count=len(persisted_graph.nodes),
                        edge_count=len(persisted_graph.edges),
                        projection_json=graph_payload,
                        acl=acl,
                        created_at=(existing.created_at if existing else now),
                        updated_at=now,
                    )
                )
                await self._supersede_projection_events(
                    session, tenant_id, persisted_graph.projection_id, fingerprint
                )
                await session.flush()

            active = status == "active"
            search_name = "search" if active else "search_staging"
            graph_name = "graph" if active else "graph_staging"
            common_payload = {
                "source_record_id": graph.source_record_id,
                "version": graph.version,
                "fingerprint": fingerprint,
                "status": status,
                "eligible_for_active_projection": active,
                "acl": acl,
                "generation": persisted_graph.generation,
            }
            search_event = await self._enqueue_in_session(
                session,
                ProjectionEventRecord(
                    tenant_id=tenant_id,
                    projection_name=search_name,
                    idempotency_key=f"document-projection:{graph.source_record_id}:{graph.version}:{fingerprint}",
                    aggregate_type="document_projection",
                    aggregate_id=persisted_graph.projection_id,
                    event_type="search.projection.replaced",
                    payload={
                        **common_payload,
                        "index_count": len(indexes),
                        "chunk_count": len(chunks),
                    },
                ),
            )
            graph_event = await self._enqueue_in_session(
                session,
                ProjectionEventRecord(
                    tenant_id=tenant_id,
                    projection_name=graph_name,
                    idempotency_key=f"document-projection:{graph.source_record_id}:{graph.version}:{fingerprint}",
                    aggregate_type="document_projection",
                    aggregate_id=persisted_graph.projection_id,
                    event_type="graph.projection.replaced",
                    payload={
                        **common_payload,
                        "node_count": len(persisted_graph.nodes),
                        "edge_count": len(persisted_graph.edges),
                    },
                ),
            )
            shadow_event = None
            if lightrag_shadow_enabled:
                shadow_action = "upsert" if status == "active" else "delete"
                shadow_event = await self._enqueue_in_session(
                    session,
                    ProjectionEventRecord(
                        tenant_id=tenant_id,
                        projection_name="lightrag_shadow",
                        idempotency_key=(
                            f"lightrag-shadow:{shadow_action}:"
                            f"{graph.source_record_id}:{graph.version}:{fingerprint}"
                        ),
                        aggregate_type="document_projection",
                        aggregate_id=graph.source_record_id,
                        event_type=f"lightrag.shadow.{shadow_action}",
                        payload={
                            "action": shadow_action,
                            "reason": (
                                "active" if shadow_action == "upsert" else "candidate"
                            ),
                            "source_record_id": graph.source_record_id,
                            "version": graph.version,
                            "fingerprint": fingerprint,
                        },
                    ),
                )
            embedding_event = None
            if embedding_model:
                embedding_event = await self._enqueue_in_session(
                    session,
                    ProjectionEventRecord(
                        tenant_id=tenant_id,
                        projection_name="embedding",
                        idempotency_key=(
                            f"embedding:{graph.source_record_id}:"
                            f"{graph.version}:{fingerprint}:{embedding_model}"
                        ),
                        aggregate_type="document_projection",
                        aggregate_id=graph.source_record_id,
                        event_type="embedding.projection.replaced",
                        payload={
                            "source_record_id": graph.source_record_id,
                            "version": graph.version,
                            "fingerprint": fingerprint,
                            "model": embedding_model,
                        },
                    ),
                )
            return ProjectionReplaceResult(
                tenant_id=tenant_id,
                source_record_id=graph.source_record_id,
                version=graph.version,
                fingerprint=fingerprint,
                status=status,
                chunk_count=len(chunks),
                index_count=len(indexes),
                node_count=len(persisted_graph.nodes),
                edge_count=len(persisted_graph.edges),
                changed=not unchanged,
                search_event_id=search_event.event_id,
                graph_event_id=graph_event.event_id,
                shadow_event_id=(shadow_event.event_id if shadow_event else ""),
                embedding_event_id=(
                    embedding_event.event_id if embedding_event else ""
                ),
            )

        return await self._write(operation)

    async def _activate_document_projection(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        source_record_id: str,
        version: str,
    ) -> None:
        """Make one source version current and retire every older projection.

        Candidate versions never call this method, so an approved version stays
        searchable while a replacement waits for review.  Activation and
        retirement share the projection transaction and cannot expose two
        current versions after commit.
        """

        now = utc_now()
        current_version: DocumentVersionRow | None = None
        try:
            version_number = int(version)
        except (TypeError, ValueError):
            version_number = -1
        knowledge_document = await session.scalar(
            select(KnowledgeDocumentRow)
            .where(
                KnowledgeDocumentRow.tenant_id == tenant_id,
                KnowledgeDocumentRow.document_id == source_record_id,
            )
            .with_for_update()
            .execution_options(populate_existing=True)
        )
        document_versions = (
            await session.scalars(
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == source_record_id,
                )
                .order_by(DocumentVersionRow.version_id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
        ).all()
        if knowledge_document is not None and knowledge_document.tenant_id == tenant_id:
            knowledge_document.lifecycle_status = LifecycleStatus.ACTIVE.value
            knowledge_document.updated_at = now
            current_version = next(
                (
                    row
                    for row in document_versions
                    if row.version_number == version_number
                ),
                None,
            )
            if current_version is not None:
                current_version.lifecycle_status = LifecycleStatus.ACTIVE.value
                current_version.recorded_to = None

        prior_versions = [
            row
            for row in document_versions
            if row.version_number != version_number
            and row.lifecycle_status
            not in {
                LifecycleStatus.DEPRECATED.value,
                LifecycleStatus.REJECTED.value,
            }
        ]
        prior_version_ids = {row.version_id for row in prior_versions}
        for row in prior_versions:
            row.lifecycle_status = LifecycleStatus.DEPRECATED.value
            row.recorded_to = row.recorded_to or now

        if prior_version_ids:
            claims = (
                await session.scalars(
                    select(FieldClaimRow).where(
                        FieldClaimRow.tenant_id == tenant_id,
                        FieldClaimRow.subject_type == "document_version",
                        FieldClaimRow.subject_id.in_(prior_version_ids),
                        FieldClaimRow.status.in_(
                            [
                                ClaimStatus.CANDIDATE.value,
                                ClaimStatus.UNDER_REVIEW.value,
                                ClaimStatus.ACCEPTED.value,
                            ]
                        ),
                    )
                )
            ).all()
            for claim in claims:
                claim.status = ClaimStatus.SUPERSEDED.value
                claim.recorded_to = claim.recorded_to or now

            reviews = (
                await session.scalars(
                    select(ReviewTaskRow).where(
                        ReviewTaskRow.tenant_id == tenant_id,
                        ReviewTaskRow.target_type == "document_version",
                        ReviewTaskRow.target_id.in_(prior_version_ids),
                        ReviewTaskRow.status.in_(
                            [
                                ReviewTaskStatus.OPEN.value,
                                ReviewTaskStatus.IN_REVIEW.value,
                            ]
                        ),
                    )
                )
            ).all()
            for review in reviews:
                review.status = ReviewTaskStatus.CANCELLED.value
                review.resolved_at = now
                review.updated_at = now

            conflicts = (
                await session.scalars(
                    select(ConflictRow).where(
                        ConflictRow.tenant_id == tenant_id,
                        ConflictRow.subject_type == "document_version",
                        ConflictRow.subject_id.in_(prior_version_ids),
                        ConflictRow.status == ConflictStatus.OPEN.value,
                    )
                )
            ).all()
            for conflict in conflicts:
                conflict.status = ConflictStatus.DISMISSED.value
                conflict.resolved_at = now

        # Canonical relationship claims carry the governed document/version in
        # their properties.  Retire source-specific claims from every prior
        # version; otherwise an obsolete candidate review can later reinsert a
        # stale logical edge into the active Graph.
        relationship_rows = (
            await session.scalars(
                select(RelationshipClaimRow).where(
                    RelationshipClaimRow.tenant_id == tenant_id,
                    RelationshipClaimRow.source_record_id == source_record_id,
                    RelationshipClaimRow.source_version != version,
                    RelationshipClaimRow.status.in_(
                        [
                            ClaimStatus.CANDIDATE.value,
                            ClaimStatus.UNDER_REVIEW.value,
                            ClaimStatus.ACCEPTED.value,
                        ]
                    ),
                )
            )
        ).all()
        retired_relationship_ids: set[str] = set()
        for relationship in relationship_rows:
            properties = relationship.properties or {}
            if "_superseded_status" not in properties:
                properties = {
                    **properties,
                    "_superseded_status": relationship.status,
                }
                relationship.properties = properties
            relationship.status = ClaimStatus.SUPERSEDED.value
            relationship.recorded_to = relationship.recorded_to or now
            retired_relationship_ids.add(relationship.relationship_id)
        if retired_relationship_ids:
            reviews = (
                await session.scalars(
                    select(ReviewTaskRow).where(
                        ReviewTaskRow.tenant_id == tenant_id,
                        ReviewTaskRow.target_type == "relationship_claim",
                        ReviewTaskRow.target_id.in_(retired_relationship_ids),
                        ReviewTaskRow.status.in_(
                            [
                                ReviewTaskStatus.OPEN.value,
                                ReviewTaskStatus.IN_REVIEW.value,
                            ]
                        ),
                    )
                )
            ).all()
            for review in reviews:
                review.status = ReviewTaskStatus.CANCELLED.value
                review.resolved_at = now
                review.updated_at = now
            relationship_events = (
                await session.scalars(
                    select(ProjectionOutboxRow).where(
                        ProjectionOutboxRow.tenant_id == tenant_id,
                        ProjectionOutboxRow.aggregate_type == "relationship_claim",
                        ProjectionOutboxRow.aggregate_id.in_(retired_relationship_ids),
                        ProjectionOutboxRow.status.in_(
                            [
                                OutboxStatus.PENDING.value,
                                OutboxStatus.PROCESSING.value,
                            ]
                        ),
                    )
                )
            ).all()
            for event_row in relationship_events:
                event_row.status = OutboxStatus.FAILED.value
                event_row.leased_until = None
                event_row.last_error = f"superseded by active version {version}"

        old_chunks = (
            await session.scalars(
                select(KnowledgeChunkRow).where(
                    KnowledgeChunkRow.tenant_id == tenant_id,
                    KnowledgeChunkRow.source_record_id == source_record_id,
                    KnowledgeChunkRow.version != version,
                    KnowledgeChunkRow.status.in_(["active", "candidate"]),
                )
            )
        ).all()
        for row in old_chunks:
            row.status = "deprecated"
        old_indexes = (
            await session.scalars(
                select(KnowledgeIndexRow).where(
                    KnowledgeIndexRow.tenant_id == tenant_id,
                    KnowledgeIndexRow.source_record_id == source_record_id,
                    KnowledgeIndexRow.version != version,
                    KnowledgeIndexRow.status.in_(["active", "candidate"]),
                )
            )
        ).all()
        for row in old_indexes:
            row.status = "deprecated"
        old_snapshots = (
            await session.scalars(
                select(GraphProjectionSnapshotRow).where(
                    GraphProjectionSnapshotRow.tenant_id == tenant_id,
                    GraphProjectionSnapshotRow.source_record_id == source_record_id,
                    GraphProjectionSnapshotRow.version != version,
                    GraphProjectionSnapshotRow.status.in_(["active", "candidate"]),
                )
            )
        ).all()
        for snapshot in old_snapshots:
            historical_graph = GraphProjection.model_validate(snapshot.projection_json)
            historical_graph = historical_graph.model_copy(
                update={
                    "nodes": [
                        node.model_copy(update={"status": "deprecated"})
                        for node in historical_graph.nodes
                    ],
                    "edges": [
                        edge.model_copy(update={"status": "deprecated"})
                        for edge in historical_graph.edges
                    ],
                }
            )
            snapshot.status = "deprecated"
            snapshot.projection_json = historical_graph.model_dump(mode="json")
            snapshot.updated_at = now

        pending_events = (
            await session.scalars(
                select(ProjectionOutboxRow).where(
                    ProjectionOutboxRow.tenant_id == tenant_id,
                    ProjectionOutboxRow.aggregate_type == "document_projection",
                    ProjectionOutboxRow.aggregate_id == source_record_id,
                    ProjectionOutboxRow.status.in_(
                        [
                            OutboxStatus.PENDING.value,
                            OutboxStatus.PROCESSING.value,
                        ]
                    ),
                )
            )
        ).all()
        for event_row in pending_events:
            if (
                str(event_row.payload.get("source_record_id") or "") == source_record_id
                and str(event_row.payload.get("version") or "") != version
            ):
                event_row.status = OutboxStatus.FAILED.value
                event_row.leased_until = None
                event_row.last_error = f"superseded by active version {version}"

    async def _supersede_projection_events(
        self,
        session: AsyncSession,
        tenant_id: str,
        projection_id: str,
        current_fingerprint: str,
    ) -> None:
        rows = (
            await session.scalars(
                select(ProjectionOutboxRow).where(
                    ProjectionOutboxRow.tenant_id == tenant_id,
                    ProjectionOutboxRow.aggregate_type == "document_projection",
                    ProjectionOutboxRow.aggregate_id == projection_id,
                    ProjectionOutboxRow.status.in_(
                        [OutboxStatus.PENDING.value, OutboxStatus.PROCESSING.value]
                    ),
                )
            )
        ).all()
        for row in rows:
            if row.payload.get("fingerprint") == current_fingerprint:
                continue
            row.status = OutboxStatus.FAILED.value
            row.leased_until = None
            row.last_error = (
                f"superseded by projection fingerprint {current_fingerprint}"
            )

    async def get_graph_projection(
        self,
        tenant_id: str,
        source_record_id: str,
        version: str | None = None,
        *,
        include_candidate: bool = False,
        actor_id: str = "",
        actor_roles: Iterable[str] | None = None,
    ) -> GraphProjection | None:
        statement = select(GraphProjectionSnapshotRow).where(
            GraphProjectionSnapshotRow.tenant_id == tenant_id,
            GraphProjectionSnapshotRow.source_record_id == source_record_id,
        )
        if version is not None:
            statement = statement.where(GraphProjectionSnapshotRow.version == version)
        if not include_candidate:
            statement = statement.where(GraphProjectionSnapshotRow.status == "active")
        statement = statement.order_by(
            GraphProjectionSnapshotRow.updated_at.desc(),
            GraphProjectionSnapshotRow.version.desc(),
        ).limit(1)
        async with self.sessionmaker() as session:
            row = await session.scalar(statement)
            if row is None or not self.acl_allows(
                row.acl, actor_id=actor_id, actor_roles=actor_roles
            ):
                return None
            return GraphProjection.model_validate(row.projection_json)

    async def graph_projection_materialization_pending(
        self,
        tenant_id: str,
        source_record_id: str,
        version: str,
    ) -> bool:
        """Return whether a governed version may still commit its first snapshot."""

        try:
            version_number = int(version)
        except (TypeError, ValueError):
            return False
        async with self.sessionmaker() as session:
            lifecycle_status = await session.scalar(
                select(DocumentVersionRow.lifecycle_status).where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == source_record_id,
                    DocumentVersionRow.version_number == version_number,
                )
            )
            graph_event_exists = bool(
                await session.scalar(
                    select(func.count(ProjectionOutboxRow.event_id)).where(
                        ProjectionOutboxRow.tenant_id == tenant_id,
                        ProjectionOutboxRow.projection_name.in_(
                            ["graph", "graph_staging"]
                        ),
                        ProjectionOutboxRow.aggregate_type == "document_projection",
                        ProjectionOutboxRow.event_type
                        == "graph.projection.replaced",
                        ProjectionOutboxRow.payload[
                            "source_record_id"
                        ].as_string()
                        == source_record_id,
                        ProjectionOutboxRow.payload["version"].as_string()
                        == version,
                    )
                )
            )
        return (
            str(lifecycle_status or "")
            in {
                LifecycleStatus.PARSED.value,
                LifecycleStatus.UNDER_REVIEW.value,
            }
            and not graph_event_exists
        )
