"""Internal release-gate recovery for one terminal graph projection event."""

from __future__ import annotations

from typing import Any

from ..core.config import Settings
from .persistence import KnowledgeStore


async def rebuild_terminal_graph_event(
    *,
    tenant_id: str,
    event_id: str,
    expected_error_contains: str,
) -> dict[str, Any]:
    """Recover the release-gate-selected terminal graph event.

    This module deliberately exposes no HTTP route or standalone CLI.  The
    release gate calls it only after bounded configuration has selected the
    exact failed event and the operator-supplied error fragment. A current
    source is rebuilt and replayed. A source whose version and graph snapshot
    are both provably retired is retained as superseded audit evidence instead.
    """

    settings = Settings()
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        try:
            event = await store.rebuild_terminal_graph_projection_event(
                event_id,
                tenant_id=tenant_id,
                expected_last_error_contains=expected_error_contains,
            )
            recovery_status = event.status.value
        except ValueError as rebuild_error:
            try:
                event = await store.retire_stale_terminal_graph_projection_event(
                    event_id,
                    tenant_id=tenant_id,
                    expected_last_error_contains=expected_error_contains,
                )
            except ValueError:
                raise rebuild_error from None
            recovery_status = "retired"
        return {
            "recovered_event_id": event_id,
            "event_id": event.event_id,
            "tenant_id": event.tenant_id,
            "projection_name": event.projection_name,
            "status": recovery_status,
            "attempts": event.attempts,
            "available_at": event.available_at.isoformat(),
        }
    finally:
        await store.close()
