"""Tenant-safe persistence for governed parser-capability routes."""

from __future__ import annotations

import hashlib
import inspect as pyinspect
import math
from collections.abc import Collection, Iterable, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from m1.documents.parsing.region_capability_contracts import (
    CapabilityProfileStatus,
    ParsingCapability,
    RegionCapabilityCandidateProposal,
    RegionCapabilityExecutionObservation,
    RegionCapabilityProfile,
    RegionCapabilityProfileMatch,
    RegionScope,
    RegionSourceKind,
)

from .db_document_models import TenantRow
from .db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    TenantBoundaryError,
)
from .persistence_helpers import _aware, _canonical_json, _enum
from .region_capability_db_models import (
    RegionCapabilityObservationRow,
    RegionCapabilityProfileRow,
)
from .region_capability_schema import (
    RegionCapabilityObservationOutcome,
    RegionCapabilityObservationRecord,
    RegionCapabilityProfileRecord,
)
from .repository_base import KnowledgeRepositoryBase, _tenant_scoped_call
from .route_lifecycle import (
    record_route_lifecycle_event,
    require_separated_approval,
)
from .schema import utc_now

_MIN_ACTIVATION_DISTINCT_TASKS = 3


def _profile_record(row: RegionCapabilityProfileRow) -> RegionCapabilityProfileRecord:
    return RegionCapabilityProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        exact_fingerprint=row.exact_fingerprint,
        signature=row.signature_json,
        capability=row.capability,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_note=row.review_note,
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at) or utc_now(),
        updated_at=_aware(row.updated_at) or utc_now(),
    )


def _observation_record(
    row: RegionCapabilityObservationRow,
) -> RegionCapabilityObservationRecord:
    return RegionCapabilityObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        task_reference_hash=row.task_reference_hash,
        region_reference_hash=row.region_reference_hash,
        outcome=row.outcome,
        validation_passed=row.validation_passed,
        reviewed_by=row.reviewed_by,
        review_note_sha256=row.review_note_sha256,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        observed_at=_aware(row.observed_at) or utc_now(),
    )


def _same_profile_definition(
    row: RegionCapabilityProfileRow, record: RegionCapabilityProfileRecord
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.tenant_id == record.tenant_id
        and row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and _canonical_json(row.signature_json)
        == _canonical_json(record.signature.model_dump(mode="json"))
        and row.capability == record.capability.value
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
    )


def _same_observation(
    row: RegionCapabilityObservationRow, record: RegionCapabilityObservationRecord
) -> bool:
    return (
        row.tenant_id == record.tenant_id
        and row.profile_id == record.profile_id
        and row.idempotency_key == record.idempotency_key
        and row.exact_fingerprint == record.exact_fingerprint
        and row.task_reference_hash == record.task_reference_hash
        and row.region_reference_hash == record.region_reference_hash
        and row.outcome == record.outcome.value
        and row.validation_passed == record.validation_passed
        and row.reviewed_by == record.reviewed_by
        and row.review_note_sha256 == record.review_note_sha256
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    candidate = _aware(second) or utc_now()
    return max(normalized, candidate) if normalized is not None else candidate


def _fingerprint(value: str) -> str:
    normalized = value.strip().casefold()
    if len(normalized) != 64:
        raise ValueError(
            "region capability fingerprints must contain 64 hexadecimal chars"
        )
    try:
        int(normalized, 16)
    except ValueError as exc:
        raise ValueError(
            "region capability fingerprints must contain 64 hexadecimal chars"
        ) from exc
    return normalized


def _observation_idempotency_key(record: RegionCapabilityExecutionObservation) -> str:
    identity = (
        f"{record.profile_id}\0{record.task_reference_hash}\0"
        f"{record.region_reference_hash}"
    )
    return f"region-capability:{hashlib.sha256(identity.encode()).hexdigest()}"


class KnowledgeRegionCapabilityRouteMixin:
    """Repository mixin; automatic proposals can only become candidates."""

    async def _lock_region_capability_tenant(
        self, session: AsyncSession, tenant_id: str
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_region_capability_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> RegionCapabilityProfileRow:
        statement = select(RegionCapabilityProfileRow).where(
            RegionCapabilityProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(
                f"region capability profile not found: {profile_id}"
            )
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_region_capability_profile(
        self, record: RegionCapabilityProfileRecord
    ) -> RegionCapabilityProfileRecord:
        """Create one candidate version without an activation shortcut."""

        if record.status is not CapabilityProfileStatus.CANDIDATE:
            raise ValueError("new region capability profiles must start as candidate")

        async def operation(session: AsyncSession) -> RegionCapabilityProfileRecord:
            await self._lock_region_capability_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(RegionCapabilityProfileRow).where(
                        RegionCapabilityProfileRow.tenant_id == record.tenant_id,
                        or_(
                            RegionCapabilityProfileRow.profile_id == record.profile_id,
                            (
                                RegionCapabilityProfileRow.profile_key
                                == record.profile_key
                            )
                            & (RegionCapabilityProfileRow.version == record.version),
                            (
                                RegionCapabilityProfileRow.exact_fingerprint
                                == record.exact_fingerprint
                            )
                            & (
                                RegionCapabilityProfileRow.capability
                                == record.capability.value
                            )
                            & (RegionCapabilityProfileRow.version == record.version),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if _same_profile_definition(row, record)
                    ),
                    None,
                )
                if existing is not None:
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"region-capability-profile:{record.profile_key}:{record.version}"
                )

            predecessor: RegionCapabilityProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_region_capability_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError("a capability revision changes its profile key")
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("a capability revision changes its fingerprint")
                if predecessor.capability != record.capability.value:
                    raise ValueError("a capability revision changes its backend")
                if record.version != predecessor.version + 1:
                    raise ValueError("capability revisions must be consecutive")
                if predecessor.status == CapabilityProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active capability profile must be deprecated before revision"
                    )

            signature = record.signature
            row = RegionCapabilityProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                exact_fingerprint=record.exact_fingerprint,
                signature_json=signature.model_dump(mode="json"),
                capability=record.capability.value,
                source_kind=signature.source_kind.value,
                scope=signature.scope.value,
                contract_revision=signature.contract_revision,
                producer_revision=signature.producer_revision,
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=record.embedding_dimensions,
                created_by=record.created_by,
                reviewed_by=record.reviewed_by,
                reviewed_at=record.reviewed_at,
                review_note=record.review_note,
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == CapabilityProfileStatus.CANDIDATE.value
            ):
                predecessor.status = CapabilityProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at, record.created_at
                )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=record.tenant_id,
                    route_kind="region_capability",
                    profile_id=predecessor.profile_id,
                    event_type="superseded",
                    actor_id=record.created_by,
                    reason=f"superseded by profile {record.profile_id}",
                    observation_count=predecessor.observation_count,
                    occurred_at=record.created_at,
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def create_region_capability_candidate(
        self, record: RegionCapabilityCandidateProposal
    ) -> RegionCapabilityProfile:
        candidate = RegionCapabilityProfileRecord(
            tenant_id=record.tenant_id,
            profile_key=record.profile_key,
            version=1,
            exact_fingerprint=record.signature.exact_fingerprint(),
            signature=record.signature,
            capability=record.capability,
            embedding=(
                list(record.embedding) if record.embedding is not None else None
            ),
            embedding_model=record.embedding_model,
            embedding_dimensions=record.embedding_dimensions,
            created_by=record.created_by,
        )
        try:
            return (
                await self.create_region_capability_profile(candidate)
            ).as_runtime_profile()
        except IdempotencyConflictError:
            profiles = await self.list_region_capability_profiles(
                record.tenant_id,
                exact_fingerprint=record.signature.exact_fingerprint(),
                capability=record.capability.value,
                contract_revision=record.signature.contract_revision,
                producer_revision=record.signature.producer_revision,
            )
            for existing in profiles:
                if (
                    existing.status is CapabilityProfileStatus.CANDIDATE
                    and existing.capability is record.capability
                    and existing.profile_key == record.profile_key
                    and existing.embedding
                    == (
                        list(record.embedding) if record.embedding is not None else None
                    )
                    and existing.embedding_model == record.embedding_model
                    and existing.embedding_dimensions == record.embedding_dimensions
                    and _canonical_json(existing.signature.model_dump(mode="json"))
                    == _canonical_json(record.signature.model_dump(mode="json"))
                ):
                    return existing.as_runtime_profile()
            raise

    async def get_region_capability_profile(
        self, tenant_id: str, profile_id: str
    ) -> RegionCapabilityProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(RegionCapabilityProfileRow).where(
                    RegionCapabilityProfileRow.tenant_id == tenant_id,
                    RegionCapabilityProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def list_region_capability_profiles(
        self,
        tenant_id: str,
        *,
        status: CapabilityProfileStatus | str | None = None,
        exact_fingerprint: str | None = None,
        capability: str | None = None,
        contract_revision: str | None = None,
        producer_revision: str | None = None,
        limit: int = 200,
    ) -> list[RegionCapabilityProfileRecord]:
        if limit < 1:
            return []
        statement = select(RegionCapabilityProfileRow).where(
            RegionCapabilityProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.status
                == CapabilityProfileStatus(_enum(status)).value
            )
        if exact_fingerprint is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.exact_fingerprint
                == _fingerprint(exact_fingerprint)
            )
        if capability is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.capability
                == str(capability).strip().casefold()
            )
        if contract_revision is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        if producer_revision is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.producer_revision
                == producer_revision.strip().casefold()
            )
        statement = statement.order_by(
            RegionCapabilityProfileRow.updated_at.desc(),
            RegionCapabilityProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def get_active_region_capability_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        producer_revision: str,
    ) -> RegionCapabilityProfile | None:
        statement = select(RegionCapabilityProfileRow).where(
            RegionCapabilityProfileRow.tenant_id == tenant_id,
            RegionCapabilityProfileRow.exact_fingerprint
            == _fingerprint(exact_fingerprint),
            RegionCapabilityProfileRow.status == CapabilityProfileStatus.ACTIVE.value,
            RegionCapabilityProfileRow.contract_revision
            == contract_revision.strip().casefold(),
            RegionCapabilityProfileRow.producer_revision
            == producer_revision.strip().casefold(),
        )
        async with self.sessionmaker() as session:
            row = await session.scalar(
                statement.order_by(
                    RegionCapabilityProfileRow.version.desc(),
                    RegionCapabilityProfileRow.profile_id,
                )
            )
            return _profile_record(row).as_runtime_profile() if row else None

    async def find_region_capability_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses: Iterable[CapabilityProfileStatus | str] = (
            CapabilityProfileStatus.ACTIVE,
        ),
        contract_revision: str | None = None,
        producer_revision: str | None = None,
        source_kind: RegionSourceKind | str | None = None,
        scope: RegionScope | str | None = None,
        min_similarity: float = 0.0,
        limit: int = 5,
    ) -> list[RegionCapabilityProfileMatch]:
        if limit < 1:
            return []
        model = embedding_model.strip()
        if not model:
            raise ValueError("region capability embedding model identity is required")
        dimensions = int(embedding_dimensions)
        if dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "region capability embedding identity dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {dimensions}"
            )
        vector = [float(value) for value in embedding]
        if len(vector) != dimensions or not all(
            math.isfinite(value) for value in vector
        ):
            raise ValueError("region capability query embedding is invalid")
        if not math.isfinite(min_similarity) or not 0.0 <= min_similarity <= 1.0:
            raise ValueError("min_similarity must be a finite value in [0, 1]")
        accepted = {CapabilityProfileStatus(_enum(status)).value for status in statuses}
        if not accepted:
            return []

        statement = select(RegionCapabilityProfileRow).where(
            RegionCapabilityProfileRow.tenant_id == tenant_id,
            RegionCapabilityProfileRow.status.in_(sorted(accepted)),
            RegionCapabilityProfileRow.embedding.is_not(None),
            RegionCapabilityProfileRow.embedding_model == model,
            RegionCapabilityProfileRow.embedding_dimensions == dimensions,
        )
        if CapabilityProfileStatus.ACTIVE.value in accepted:
            statement = statement.where(
                or_(
                    RegionCapabilityProfileRow.status
                    != CapabilityProfileStatus.ACTIVE.value,
                    RegionCapabilityProfileRow.failure_count == 0,
                )
            )
        if contract_revision is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        if producer_revision is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.producer_revision
                == producer_revision.strip().casefold()
            )
        if source_kind is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.source_kind
                == RegionSourceKind(_enum(source_kind)).value
            )
        if scope is not None:
            statement = statement.where(
                RegionCapabilityProfileRow.scope == RegionScope(_enum(scope)).value
            )

        async with self.sessionmaker() as session:
            if self.engine.url.get_backend_name() == "postgresql":
                distance = RegionCapabilityProfileRow.embedding.cosine_distance(vector)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .where((1.0 - distance) >= min_similarity)
                        .order_by(distance, RegionCapabilityProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    RegionCapabilityProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=max(0.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]
            rows = (
                await session.scalars(
                    statement.order_by(
                        RegionCapabilityProfileRow.updated_at.desc(),
                        RegionCapabilityProfileRow.profile_id,
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in vector))
        matches: list[RegionCapabilityProfileMatch] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != dimensions:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(left * right for left, right in zip(vector, stored, strict=True))
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(0.0, min(1.0, similarity))
            if similarity >= min_similarity:
                matches.append(
                    RegionCapabilityProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=similarity,
                    )
                )
        return sorted(
            matches,
            key=lambda item: (-item.vector_similarity, item.profile.profile_id),
        )[: min(limit, 100)]

    async def find_active_region_capability_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str,
        producer_revision: str,
        source_kind: RegionSourceKind | str | None = None,
        scope: RegionScope | str | None = None,
        limit: int,
    ) -> list[RegionCapabilityProfileMatch]:
        return await self.find_region_capability_profiles(
            tenant_id,
            embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            statuses=(CapabilityProfileStatus.ACTIVE,),
            contract_revision=contract_revision,
            producer_revision=producer_revision,
            source_kind=source_kind,
            scope=scope,
            limit=limit,
        )

    async def record_region_capability_execution_observation(
        self, record: RegionCapabilityExecutionObservation
    ) -> RegionCapabilityObservationRecord:
        persisted = RegionCapabilityObservationRecord(
            tenant_id=record.tenant_id,
            profile_id=record.profile_id,
            idempotency_key=_observation_idempotency_key(record),
            exact_fingerprint=record.exact_fingerprint,
            task_reference_hash=record.task_reference_hash,
            region_reference_hash=record.region_reference_hash,
            outcome=RegionCapabilityObservationOutcome(record.outcome),
            validation_passed=record.validation_passed,
            reviewed_by=record.reviewed_by,
            review_note_sha256=record.review_note_sha256,
            latency_ms=record.latency_ms,
            error_code=record.error_code,
        )
        return await self.record_region_capability_observation(persisted)

    async def record_region_capability_observation(
        self, record: RegionCapabilityObservationRecord
    ) -> RegionCapabilityObservationRecord:
        """Append one idempotent reviewed sample and update counters atomically."""

        async def operation(session: AsyncSession) -> RegionCapabilityObservationRecord:
            await self._lock_region_capability_tenant(session, record.tenant_id)
            profile = await self._require_region_capability_profile(
                session, record.tenant_id, record.profile_id, for_update=True
            )
            existing = await session.scalar(
                select(RegionCapabilityObservationRow).where(
                    RegionCapabilityObservationRow.tenant_id == record.tenant_id,
                    RegionCapabilityObservationRow.idempotency_key
                    == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError(
                    "observation fingerprint does not match capability profile"
                )

            row = RegionCapabilityObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                task_reference_hash=record.task_reference_hash,
                region_reference_hash=record.region_reference_hash,
                outcome=record.outcome.value,
                validation_passed=record.validation_passed,
                reviewed_by=record.reviewed_by,
                review_note_sha256=record.review_note_sha256,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at, record.observed_at
            )
            if record.outcome is RegionCapabilityObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at, record.observed_at
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at, record.observed_at
                )
                if profile.status == CapabilityProfileStatus.ACTIVE.value:
                    profile.status = CapabilityProfileStatus.DEPRECATED.value
                    await record_route_lifecycle_event(
                        session,
                        tenant_id=record.tenant_id,
                        route_kind="region_capability",
                        profile_id=profile.profile_id,
                        event_type="auto_deprecated",
                        actor_id=record.reviewed_by or "region-capability-observation",
                        reason=(
                            f"failed observation {record.observation_id}: "
                            f"{record.error_code or 'unspecified'}"
                        ),
                        observation_count=profile.observation_count,
                        occurred_at=record.observed_at,
                    )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def activate_region_capability_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str,
        review_note: str,
        expected_observation_count: int,
        allowed_capabilities: Collection[ParsingCapability | str] = (
            ParsingCapability.PADDLEOCR_VL,
        ),
        approved_at: datetime | None = None,
    ) -> RegionCapabilityProfileRecord:
        approver = approved_by.strip()
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not approver or not reviewer or not note:
            raise ValueError("approval, reviewer and review note are required")
        if expected_observation_count < _MIN_ACTIVATION_DISTINCT_TASKS:
            raise ValueError("activation requires at least three reviewed observations")
        capability_registry = {
            ParsingCapability(str(capability)).value
            for capability in allowed_capabilities
        }
        if not capability_registry:
            raise ValueError("allowed_capabilities must be a non-empty code registry")
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> RegionCapabilityProfileRecord:
            await self._lock_region_capability_tenant(session, tenant_id)
            row = await self._require_region_capability_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.capability not in capability_registry:
                raise ValueError(
                    "capability is absent from the currently executable registry"
                )
            observations = (
                await session.scalars(
                    select(RegionCapabilityObservationRow).where(
                        RegionCapabilityObservationRow.tenant_id == tenant_id,
                        RegionCapabilityObservationRow.profile_id == profile_id,
                    )
                )
            ).all()
            if (
                row.observation_count != expected_observation_count
                or len(observations) != expected_observation_count
            ):
                raise IdempotencyConflictError(
                    f"region-capability-approval-stale:{tenant_id}:{profile_id}"
                )
            if any(
                observation.outcome != RegionCapabilityObservationOutcome.SUCCESS.value
                or not observation.validation_passed
                for observation in observations
            ):
                raise IdempotencyConflictError(
                    f"region-capability-approval-failures:{tenant_id}:{profile_id}"
                )
            task_hashes = {
                observation.task_reference_hash
                for observation in observations
                if observation.reviewed_by.strip()
                and len(observation.review_note_sha256) == 64
            }
            if len(task_hashes) < _MIN_ACTIVATION_DISTINCT_TASKS:
                raise IdempotencyConflictError(
                    f"region-capability-approval-distinct-tasks:{tenant_id}:{profile_id}"
                )
            require_separated_approval(
                approved_by=approver,
                reviewed_by=reviewer,
                sample_reviewers=(
                    observation.reviewed_by for observation in observations
                ),
            )

            if row.status == CapabilityProfileStatus.ACTIVE.value:
                if not (
                    row.approved_by == approver
                    and row.reviewed_by == reviewer
                    and row.review_note == note
                    and (
                        approved_at is None
                        or _aware(row.approved_at) == _aware(approved_at)
                    )
                ):
                    raise IdempotencyConflictError(
                        f"region-capability-activation:{tenant_id}:{profile_id}"
                    )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="region_capability",
                    profile_id=profile_id,
                    event_type="activated",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=note,
                    observation_count=expected_observation_count,
                    occurred_at=_aware(row.approved_at) or now,
                )
                return _profile_record(row)
            if row.status != CapabilityProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate capability profiles may be activated")

            statement = select(RegionCapabilityProfileRow).where(
                RegionCapabilityProfileRow.tenant_id == tenant_id,
                RegionCapabilityProfileRow.profile_id != profile_id,
                RegionCapabilityProfileRow.status
                == CapabilityProfileStatus.ACTIVE.value,
                or_(
                    RegionCapabilityProfileRow.profile_key == row.profile_key,
                    RegionCapabilityProfileRow.exact_fingerprint
                    == row.exact_fingerprint,
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = CapabilityProfileStatus.DEPRECATED.value
                previous.updated_at = now
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="region_capability",
                    profile_id=previous.profile_id,
                    event_type="superseded",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=f"superseded by profile {profile_id}",
                    observation_count=previous.observation_count,
                    occurred_at=now,
                )

            row.status = CapabilityProfileStatus.ACTIVE.value
            row.reviewed_by = reviewer
            row.reviewed_at = row.reviewed_at or now
            row.review_note = note
            row.approved_by = approver
            row.approved_at = now
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="region_capability",
                profile_id=profile_id,
                event_type="activated",
                actor_id=approver,
                counterparty_id=reviewer,
                reason=note,
                observation_count=expected_observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def reject_region_capability_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> RegionCapabilityProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> RegionCapabilityProfileRecord:
            await self._lock_region_capability_tenant(session, tenant_id)
            row = await self._require_region_capability_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == CapabilityProfileStatus.REJECTED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="region_capability",
                    profile_id=profile_id,
                    event_type="rejected",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=_aware(row.reviewed_at) or now,
                )
                return _profile_record(row)
            if row.status != CapabilityProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate capability profiles may be rejected")
            row.status = CapabilityProfileStatus.REJECTED.value
            row.reviewed_by = reviewer
            row.reviewed_at = now
            row.review_note = note
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="region_capability",
                profile_id=profile_id,
                event_type="rejected",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def deprecate_region_capability_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> RegionCapabilityProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> RegionCapabilityProfileRecord:
            await self._lock_region_capability_tenant(session, tenant_id)
            row = await self._require_region_capability_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == CapabilityProfileStatus.DEPRECATED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="region_capability",
                    profile_id=profile_id,
                    event_type="deprecated",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=now,
                )
                return _profile_record(row)
            if row.status == CapabilityProfileStatus.REJECTED.value:
                raise ValueError("a rejected capability profile cannot be deprecated")
            row.status = CapabilityProfileStatus.DEPRECATED.value
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="region_capability",
                profile_id=profile_id,
                event_type="deprecated",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def list_region_capability_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        outcome: RegionCapabilityObservationOutcome | str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[RegionCapabilityObservationRecord]:
        if limit < 1:
            return []
        if offset < 0:
            raise ValueError(
                "region capability observation offset must not be negative"
            )
        statement = select(RegionCapabilityObservationRow).where(
            RegionCapabilityObservationRow.tenant_id == tenant_id
        )
        if profile_id is not None:
            statement = statement.where(
                RegionCapabilityObservationRow.profile_id == profile_id
            )
        if outcome is not None:
            statement = statement.where(
                RegionCapabilityObservationRow.outcome
                == RegionCapabilityObservationOutcome(_enum(outcome)).value
            )
        statement = (
            statement.order_by(
                RegionCapabilityObservationRow.observed_at.desc(),
                RegionCapabilityObservationRow.observation_id,
            )
            .offset(offset)
            .limit(min(limit, 1000))
        )
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_observation_record(row) for row in rows]


class RegionCapabilityRepository(
    KnowledgeRegionCapabilityRouteMixin,
    KnowledgeRepositoryBase,
):
    """Standalone adapter until the main KnowledgeStore mixin is wired."""


for _method_name in dir(RegionCapabilityRepository):
    _method = getattr(RegionCapabilityRepository, _method_name)
    if (
        not _method_name.startswith("_")
        and pyinspect.iscoroutinefunction(_method)
        and {"tenant_id", "record"}.intersection(
            pyinspect.signature(_method).parameters
        )
    ):
        setattr(
            RegionCapabilityRepository,
            _method_name,
            _tenant_scoped_call(_method),
        )


__all__ = ["KnowledgeRegionCapabilityRouteMixin", "RegionCapabilityRepository"]
