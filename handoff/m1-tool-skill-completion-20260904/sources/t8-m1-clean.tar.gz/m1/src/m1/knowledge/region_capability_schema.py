"""Governance records for tenant-scoped parser-capability routes."""

from __future__ import annotations

import math
import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Self

from pydantic import Field, field_validator, model_validator

from m1.documents.parsing.region_capability_contracts import (
    CapabilityProfileStatus,
    ParsingCapability,
    RegionCapabilityProfile,
    RegionCapabilitySignature,
)

from .db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from .schema import KnowledgeSchema, new_id, utc_now

_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")

RegionCapabilityProfileStatus = CapabilityProfileStatus


class RegionCapabilityObservationOutcome(StrEnum):
    SUCCESS = "success"
    FAILURE = "failure"


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class RegionCapabilityProfileRecord(KnowledgeSchema):
    """Immutable capability choice plus mutable reviewed sample statistics."""

    profile_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    version: int = Field(ge=1)
    supersedes_profile_id: str | None = Field(
        default=None, min_length=1, max_length=128
    )
    status: CapabilityProfileStatus = CapabilityProfileStatus.CANDIDATE
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    signature: RegionCapabilitySignature
    capability: ParsingCapability
    embedding: list[float] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0)
    created_by: str = Field(min_length=1, max_length=256)
    reviewed_by: str | None = Field(default=None, min_length=1, max_length=256)
    reviewed_at: datetime | None = None
    review_note: str = Field(default="", max_length=4096)
    approved_by: str | None = Field(default=None, min_length=1, max_length=256)
    approved_at: datetime | None = None
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)
    last_observed_at: datetime | None = None
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("profile_key")
    @classmethod
    def validate_profile_key(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("region capability identifiers must be stable tokens")
        return normalized

    @field_validator("signature", mode="before")
    @classmethod
    def parse_persisted_signature(cls, value: object) -> RegionCapabilitySignature:
        if isinstance(value, RegionCapabilitySignature):
            return value
        return RegionCapabilitySignature.model_validate(value, strict=False)

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.lower()

    @field_validator("embedding")
    @classmethod
    def validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        if value is None:
            return None
        normalized = [float(item) for item in value]
        if len(normalized) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "region capability embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {len(normalized)}"
            )
        if not all(math.isfinite(item) for item in normalized):
            raise ValueError("region capability embedding contains non-finite values")
        return normalized

    @field_validator("embedding_model")
    @classmethod
    def normalize_embedding_model(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "reviewed_at",
        "approved_at",
        "last_observed_at",
        "last_success_at",
        "last_failure_at",
        "created_at",
        "updated_at",
    )
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _utc(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.version == 1 and self.supersedes_profile_id is not None:
            raise ValueError(
                "a first region capability version cannot supersede another"
            )
        if self.version > 1 and self.supersedes_profile_id is None:
            raise ValueError("region capability revisions require a predecessor")
        if self.supersedes_profile_id == self.profile_id:
            raise ValueError("a region capability profile cannot supersede itself")
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("fingerprint does not match the region signature")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding identity requires an embedding")
        else:
            if not self.embedding_model:
                raise ValueError(
                    "region capability embeddings require a model identity"
                )
            if self.embedding_dimensions != len(self.embedding):
                raise ValueError(
                    "embedding identity dimensions do not match the vector"
                )
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("region capability observation counters are inconsistent")
        if self.status is CapabilityProfileStatus.ACTIVE:
            if (
                not self.reviewed_by
                or self.reviewed_at is None
                or not self.review_note.strip()
            ):
                raise ValueError("active capability profiles require review metadata")
            if not self.approved_by or self.approved_at is None:
                raise ValueError("active capability profiles require approval metadata")
            if self.reviewed_by.casefold() == self.approved_by.casefold():
                raise ValueError(
                    "active capability profiles require independent approval"
                )
            if self.success_count < 3 or self.failure_count:
                raise ValueError(
                    "active capability profiles require three clean samples"
                )
        return self

    def as_runtime_profile(self) -> RegionCapabilityProfile:
        return RegionCapabilityProfile(
            profile_id=self.profile_id,
            tenant_id=self.tenant_id,
            profile_key=self.profile_key,
            status=self.status,
            exact_fingerprint=self.exact_fingerprint,
            signature=self.signature,
            capability=self.capability,
            embedding=(tuple(self.embedding) if self.embedding is not None else None),
            embedding_model=self.embedding_model,
            embedding_dimensions=self.embedding_dimensions,
            observation_count=self.observation_count,
            success_count=self.success_count,
            failure_count=self.failure_count,
        )


class RegionCapabilityObservationRecord(KnowledgeSchema):
    observation_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    region_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: RegionCapabilityObservationOutcome
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)
    observed_at: datetime = Field(default_factory=utc_now)

    @field_validator(
        "exact_fingerprint",
        "task_reference_hash",
        "region_reference_hash",
        "review_note_sha256",
    )
    @classmethod
    def normalize_hashes(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("error_code")
    @classmethod
    def normalize_error(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if normalized and _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("error_code must be a stable token")
        return normalized

    @field_validator("observed_at")
    @classmethod
    def normalize_observed_at(cls, value: datetime) -> datetime:
        return _utc(value) or utc_now()

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome is RegionCapabilityObservationOutcome.SUCCESS:
            if not self.validation_passed:
                raise ValueError("successful route samples must pass validation")
            if not self.reviewed_by.strip():
                raise ValueError("successful route samples require a reviewer")
            if re.fullmatch(r"[0-9a-f]{64}", self.review_note_sha256) is None:
                raise ValueError("successful route samples require a review-note hash")
        elif not self.error_code:
            raise ValueError("failed route samples require an error code")
        return self


__all__ = [
    "RegionCapabilityObservationOutcome",
    "RegionCapabilityObservationRecord",
    "RegionCapabilityProfileRecord",
    "RegionCapabilityProfileStatus",
]
