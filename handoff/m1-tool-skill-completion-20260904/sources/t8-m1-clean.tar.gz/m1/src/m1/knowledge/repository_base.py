"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

import asyncio
import inspect
import os
from collections.abc import Awaitable, Callable, Iterable, Mapping
from contextvars import ContextVar
from functools import wraps
from typing import Any, TypeVar

from sqlalchemy import (
    event,
    select,
    text,
)
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from .db_models import (
    IdempotencyConflictError,
    IngestionBatchRow,
    PgVector,
    RecordNotFoundError,
    SourceAssetRow,
    SourceOccurrenceRow,
    TenantRow,
)
from .persistence_helpers import (
    _asset_record,
    _asset_row,
    _batch_record,
    _batch_row,
    _enum,
    _json,
    _occurrence_record,
    _occurrence_row,
    _tenant_record,
)
from .schema import (
    AccessControl,
    IngestionBatchRecord,
    SourceAssetRecord,
    SourceOccurrenceRecord,
    TenantRecord,
)

T = TypeVar("T")


_POSTGRES_TENANT_CONTEXT: ContextVar[str] = ContextVar(
    "m1_postgres_tenant_id", default=""
)


def _tenant_scoped_call(method):
    """Bind a public repository call to PostgreSQL's transaction-local GUC."""

    signature = inspect.signature(method)

    @wraps(method)
    async def wrapped(*args, **kwargs):
        bound = signature.bind_partial(*args, **kwargs)
        tenant_id = bound.arguments.get("tenant_id")
        if tenant_id is None:
            record = bound.arguments.get("record")
            tenant_id = getattr(record, "tenant_id", "")
        token = _POSTGRES_TENANT_CONTEXT.set(str(tenant_id or ""))
        try:
            return await method(*args, **kwargs)
        finally:
            _POSTGRES_TENANT_CONTEXT.reset(token)

    return wrapped


class KnowledgeRepositoryBase:
    def __init__(self, database_url: str):
        self.engine = create_async_engine(
            database_url,
            echo=False,
            pool_size=int(os.environ.get("M1_DB_POOL_SIZE", "10")),
            max_overflow=int(os.environ.get("M1_DB_MAX_OVERFLOW", "20")),
        )
        if self.engine.url.get_backend_name() == "postgresql" and PgVector is None:
            raise RuntimeError(
                "PostgreSQL knowledge search requires the 'knowledge' extra "
                "with pgvector support"
            )
        self.sessionmaker = async_sessionmaker(
            self.engine, class_=AsyncSession, expire_on_commit=False
        )
        self._sqlite_lock = (
            asyncio.Lock() if self.engine.url.get_backend_name() == "sqlite" else None
        )
        if self.engine.url.get_backend_name() == "sqlite":

            @event.listens_for(self.engine.sync_engine, "connect")
            def _set_sqlite_pragmas(dbapi_connection, _connection_record):
                cursor = dbapi_connection.cursor()
                try:
                    cursor.execute("PRAGMA foreign_keys=ON")
                    cursor.execute("PRAGMA busy_timeout=30000")
                finally:
                    cursor.close()
        elif self.engine.url.get_backend_name() == "postgresql":

            @event.listens_for(self.engine.sync_engine, "begin")
            def _set_postgres_tenant_context(connection):
                tenant_id = _POSTGRES_TENANT_CONTEXT.get()
                if tenant_id:
                    connection.execute(
                        text("SELECT set_config('m1.tenant_id', :tenant_id, true)"),
                        {"tenant_id": tenant_id},
                    )

    @staticmethod
    def acl_allows(
        acl: AccessControl | Mapping[str, Any] | None,
        *,
        actor_id: str = "",
        actor_roles: Iterable[str] | None = None,
    ) -> bool:
        """Evaluate the portable Wiki ACL after the tenant boundary is applied.

        ``tenant`` and ``public`` are readable inside the already selected
        tenant. ``private`` requires an owner/reader, while ``restricted`` also
        accepts a role named by ``security_labels`` (``role:quality`` and
        ``quality`` are equivalent). Tenant administrators retain read access.
        """

        parsed = (
            acl
            if isinstance(acl, AccessControl)
            else AccessControl.model_validate(dict(acl or {}))
        )
        roles = {
            str(role).strip().casefold().removeprefix("role:")
            for role in (actor_roles or [])
            if str(role).strip()
        }
        if "admin" in roles:
            return True
        visibility = _enum(parsed.visibility)
        if visibility in {"tenant", "public"}:
            return True
        principal = actor_id.strip()
        if principal and principal == (parsed.owner_principal or ""):
            return True
        if principal and principal in set(parsed.read_principals):
            return True
        if visibility == "restricted":
            allowed_roles = {
                label.casefold().removeprefix("role:")
                for label in parsed.security_labels
                if label
            }
            return bool(roles.intersection(allowed_roles))
        return False

    async def init(self, *, migrate_schema: bool | None = None) -> None:
        from .migrations.runner import (
            upgrade_knowledge_schema,
            validate_knowledge_schema,
        )

        backend_name = self.engine.url.get_backend_name()
        if migrate_schema is None:
            # Ephemeral/local SQLite repositories retain their convenient
            # bootstrap behavior. PostgreSQL always defaults to validate-only;
            # production DDL belongs to the one-shot migration service.
            migrate_schema = backend_name == "sqlite"
        async with self.engine.begin() as connection:
            schema_operation = (
                upgrade_knowledge_schema
                if migrate_schema
                else validate_knowledge_schema
            )
            await connection.run_sync(schema_operation)
            if backend_name == "postgresql":
                role = (
                    await connection.execute(
                        text(
                            "SELECT rolsuper, rolbypassrls "
                            "FROM pg_roles WHERE rolname = current_user"
                        )
                    )
                ).one()
                if bool(role.rolsuper) or bool(role.rolbypassrls):
                    raise RuntimeError(
                        "the PostgreSQL application role must be NOSUPERUSER "
                        "and NOBYPASSRLS for tenant isolation"
                    )

    async def close(self) -> None:
        await self.engine.dispose()

    async def _write(self, operation: Callable[[AsyncSession], Awaitable[T]]) -> T:
        async def run() -> T:
            async with self.sessionmaker.begin() as session:
                return await operation(session)

        if self._sqlite_lock is None:
            return await run()
        async with self._sqlite_lock:
            return await run()

    async def _require_tenant(self, session: AsyncSession, tenant_id: str) -> TenantRow:
        row = await session.get(TenantRow, tenant_id)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def create_tenant(self, record: TenantRecord) -> TenantRecord:
        async def operation(session: AsyncSession) -> TenantRecord:
            existing = await session.scalar(
                select(TenantRow).where(TenantRow.tenant_key == record.tenant_key)
            )
            if existing is not None:
                return _tenant_record(existing)
            session.add(
                TenantRow(
                    tenant_id=record.tenant_id,
                    tenant_key=record.tenant_key,
                    display_name=record.display_name,
                    lifecycle_status=_enum(record.lifecycle_status),
                    default_acl=_json(record.default_acl),
                    metadata_json=record.metadata,
                    created_at=record.created_at,
                    updated_at=record.updated_at,
                )
            )
            return record

        return await self._write(operation)

    async def get_tenant(self, tenant_id: str) -> TenantRecord | None:
        async with self.sessionmaker() as session:
            row = await session.get(TenantRow, tenant_id)
            return _tenant_record(row) if row else None

    async def create_ingestion_batch(
        self, record: IngestionBatchRecord
    ) -> IngestionBatchRecord:
        async def operation(session: AsyncSession) -> IngestionBatchRecord:
            await self._require_tenant(session, record.tenant_id)
            existing = await session.scalar(
                select(IngestionBatchRow).where(
                    IngestionBatchRow.tenant_id == record.tenant_id,
                    IngestionBatchRow.idempotency_key == record.idempotency_key,
                )
            )
            if existing:
                if existing.source_type != record.source_type:
                    raise IdempotencyConflictError(record.idempotency_key)
                return _batch_record(existing)
            session.add(_batch_row(record))
            return record

        return await self._write(operation)

    async def register_source_asset(
        self, record: SourceAssetRecord
    ) -> SourceAssetRecord:
        async def operation(session: AsyncSession) -> SourceAssetRecord:
            await self._require_tenant(session, record.tenant_id)
            existing = await session.scalar(
                select(SourceAssetRow).where(
                    SourceAssetRow.tenant_id == record.tenant_id,
                    SourceAssetRow.sha256 == record.sha256,
                )
            )
            if existing:
                if existing.size_bytes != record.size_bytes and record.size_bytes:
                    raise IdempotencyConflictError(
                        f"hash size mismatch: {record.sha256}"
                    )
                return _asset_record(existing)
            session.add(_asset_row(record))
            return record

        return await self._write(operation)

    async def add_source_occurrence(
        self, record: SourceOccurrenceRecord
    ) -> SourceOccurrenceRecord:
        async def operation(session: AsyncSession) -> SourceOccurrenceRecord:
            await self._require_tenant(session, record.tenant_id)
            await self._assert_owned(
                session, IngestionBatchRow, record.batch_id, record.tenant_id
            )
            await self._assert_owned(
                session, SourceAssetRow, record.asset_id, record.tenant_id
            )
            existing = await session.scalar(
                select(SourceOccurrenceRow).where(
                    SourceOccurrenceRow.tenant_id == record.tenant_id,
                    SourceOccurrenceRow.idempotency_key == record.idempotency_key,
                )
            )
            if existing:
                if existing.asset_id != record.asset_id:
                    raise IdempotencyConflictError(record.idempotency_key)
                return _occurrence_record(existing)
            session.add(_occurrence_row(record))
            return record

        return await self._write(operation)
