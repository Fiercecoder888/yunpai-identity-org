"""Requeue one inspected terminal M1 graph outbox event.

This is an internal recovery command. It uses the configured knowledge database
and deliberately exposes no broad failed-event replay or payload inspection.
Only the source's current active graph replacement can receive one additional
delivery attempt; the event payload keeps the replay audit marker.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Any

from ..core.config import Settings
from .persistence import KnowledgeStore, RecordNotFoundError, TenantBoundaryError


async def requeue_terminal_graph_event(
    *,
    tenant_id: str,
    event_id: str,
    expected_error_contains: str,
) -> dict[str, Any]:
    settings = Settings()
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        event = await store.requeue_terminal_graph_event(
            event_id,
            tenant_id=tenant_id,
            expected_last_error_contains=expected_error_contains,
        )
        return {
            "event_id": event.event_id,
            "tenant_id": event.tenant_id,
            "projection_name": event.projection_name,
            "status": event.status.value,
            "attempts": event.attempts,
            "available_at": event.available_at.isoformat(),
        }
    finally:
        await store.close()


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tenant-id", required=True)
    parser.add_argument("--event-id", required=True)
    parser.add_argument(
        "--expected-error-contains",
        required=True,
        help="Required fragment of the inspected terminal error.",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        result = asyncio.run(
            requeue_terminal_graph_event(
                tenant_id=args.tenant_id,
                event_id=args.event_id,
                expected_error_contains=args.expected_error_contains,
            )
        )
    except (RecordNotFoundError, TenantBoundaryError, ValueError) as exc:
        print(
            json.dumps(
                {
                    "status": "rejected",
                    "error_type": exc.__class__.__name__,
                    "message": str(exc),
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 2
    except Exception as exc:  # noqa: BLE001 - never expose connection secrets
        print(
            json.dumps(
                {"status": "error", "error_type": exc.__class__.__name__},
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
