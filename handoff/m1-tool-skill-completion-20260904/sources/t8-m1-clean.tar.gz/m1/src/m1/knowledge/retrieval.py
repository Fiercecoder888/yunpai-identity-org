"""Pure-Python hybrid ranking for M1 knowledge index documents."""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Literal

from .models import FieldIndexDocument, SearchHit


def _normalized(value: Any) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).casefold().strip()


def tokenize(value: str) -> list[str]:
    """Tokenize Latin identifiers and Chinese text without a tokenizer package."""

    text = _normalized(value)
    tokens: list[str] = []
    for segment in re.findall(r"[a-z0-9]+(?:[._+/-][a-z0-9]+)*|[\u3400-\u9fff]+", text):
        tokens.append(segment)
        if re.fullmatch(r"[\u3400-\u9fff]+", segment) and len(segment) > 1:
            tokens.extend(segment[index : index + 2] for index in range(len(segment) - 1))
    return tokens


def identifier_tokens(value: str) -> list[str]:
    """Return identifier-like query tokens that must match in precise mode."""

    normalized = _normalized(value)
    candidates = re.findall(r"[a-z0-9]+(?:[._+/-][a-z0-9]+)*", normalized)
    identifiers: list[str] = []
    for token in candidates:
        has_digit = any(character.isdigit() for character in token)
        if not has_digit:
            continue
        has_letter = any(character.isalpha() for character in token)
        has_separator = any(character in "._+/-" for character in token)
        # Compact ERP identifiers such as TX2699990001 and SKU123 are common.
        # Long numeric values cover numeric-only order/material numbers while
        # deliberately excluding years, quantities and other short numbers.
        if has_separator or (has_letter and len(token) >= 4) or len(token) >= 8:
            identifiers.append(token)
    return list(dict.fromkeys(identifiers))


def _contains_identifier(searchable: str, identifier: str) -> bool:
    """Match a normalized identifier without accepting a longer identifier."""

    return re.search(
        rf"(?<![a-z0-9._+/-]){re.escape(identifier)}(?![a-z0-9._+/-])",
        searchable,
    ) is not None


def _bounded_score(value: float | None) -> float:
    if value is None:
        return 0.0
    score = float(value)
    # Cosine similarity is commonly [-1, 1].  Preserve already-normalized
    # scores and map negative cosine values to the same [0, 1] rank domain.
    if score < 0:
        score = (score + 1.0) / 2.0
    return min(1.0, max(0.0, score))


def _matches_filter(document: FieldIndexDocument, key: str, expected: Any) -> bool:
    if hasattr(document, key):
        actual = getattr(document, key)
    elif key in document.selected_fields:
        actual = document.selected_fields[key]
    else:
        actual = document.metadata.get(key)
    if isinstance(expected, (set, tuple, list, frozenset)):
        return any(_normalized(actual) == _normalized(item) for item in expected)
    return _normalized(actual) == _normalized(expected)


class HybridSearchEngine:
    """BM25-style keyword ranking with optional vector and graph boosts.

    External stores only need to provide score mappings.  Keys may be an
    ``index_id``, ``record_id``, or one of the document's ``graph_keys``.
    """

    def __init__(
        self,
        documents: Iterable[FieldIndexDocument | Mapping[str, Any]] = (),
        *,
        rank_timestamps: Mapping[str, float] | None = None,
    ) -> None:
        self._documents: list[FieldIndexDocument] = []
        self._tokens: dict[str, list[str]] = {}
        self._document_frequency: Counter[str] = Counter()
        self._average_length = 1.0
        self._rank_timestamps = {
            str(index_id): float(timestamp)
            for index_id, timestamp in (rank_timestamps or {}).items()
        }
        self.replace(documents)

    @property
    def documents(self) -> tuple[FieldIndexDocument, ...]:
        return tuple(self._documents)

    def replace(
        self, documents: Iterable[FieldIndexDocument | Mapping[str, Any]]
    ) -> None:
        parsed = [
            item if isinstance(item, FieldIndexDocument) else FieldIndexDocument.model_validate(item)
            for item in documents
        ]
        token_map = {item.index_id: tokenize(item.text) for item in parsed}
        frequencies: Counter[str] = Counter()
        for tokens in token_map.values():
            frequencies.update(set(tokens))
        self._documents = parsed
        self._tokens = token_map
        self._document_frequency = frequencies
        self._average_length = (
            sum(len(tokens) for tokens in token_map.values()) / len(token_map)
            if token_map
            else 1.0
        )

    def add(self, documents: Iterable[FieldIndexDocument | Mapping[str, Any]]) -> None:
        by_id = {document.index_id: document for document in self._documents}
        for item in documents:
            parsed = (
                item if isinstance(item, FieldIndexDocument) else FieldIndexDocument.model_validate(item)
            )
            by_id[parsed.index_id] = parsed
        self.replace(by_id.values())

    def _keyword_score(self, document: FieldIndexDocument, query_tokens: Sequence[str]) -> float:
        tokens = self._tokens.get(document.index_id, [])
        if not tokens or not query_tokens:
            return 0.0
        counts = Counter(tokens)
        document_count = max(len(self._documents), 1)
        length = len(tokens)
        k1, b = 1.5, 0.75
        score = 0.0
        maximum = 0.0
        for token in dict.fromkeys(query_tokens):
            frequency = counts[token]
            df = self._document_frequency.get(token, 0)
            idf = math.log(1.0 + (document_count - df + 0.5) / (df + 0.5))
            denominator = frequency + k1 * (
                1.0 - b + b * length / max(self._average_length, 1.0)
            )
            if frequency:
                score += idf * frequency * (k1 + 1.0) / denominator
            maximum += idf * (k1 + 1.0) / (
                1.0 + k1 * (1.0 - b + b * length / max(self._average_length, 1.0))
            )
        normalized_bm25 = score / maximum if maximum else 0.0
        # Exact NFKC substring matches are especially valuable for order/model
        # identifiers and multi-character Chinese terms.
        exact = _normalized(" ".join(query_tokens)) in _normalized(document.text)
        return min(1.0, normalized_bm25 * 0.85 + (0.15 if exact else 0.0))

    @staticmethod
    def _external_score(
        document: FieldIndexDocument, scores: Mapping[str, float] | None
    ) -> float:
        if not scores:
            return 0.0
        candidates = [document.index_id, document.record_id, *document.graph_keys]
        return max((_bounded_score(scores.get(key)) for key in candidates), default=0.0)

    def search(
        self,
        query: str,
        *,
        vector_scores: Mapping[str, float] | None = None,
        graph_context: Mapping[str, float] | set[str] | None = None,
        filters: Mapping[str, Any] | None = None,
        tenant_id: str | None = None,
        statuses: set[str] | None = None,
        keyword_weight: float = 0.65,
        vector_weight: float = 0.25,
        graph_weight: float = 0.10,
        limit: int = 20,
        mode: str = "precise",
        min_score: float | None = None,
        max_hits_per_source: int = 2,
    ) -> list[SearchHit]:
        if limit < 1:
            return []
        if min(keyword_weight, vector_weight, graph_weight) < 0:
            raise ValueError("search weights cannot be negative")
        total_weight = keyword_weight + vector_weight + graph_weight
        if total_weight <= 0:
            raise ValueError("at least one search weight must be positive")
        normalized_mode = str(mode).strip().casefold()
        if normalized_mode not in {"precise", "broad"}:
            raise ValueError("search mode must be precise or broad")
        effective_min_score = (
            0.30
            if min_score is None and normalized_mode == "precise"
            else float(min_score or 0.0)
        )
        if not 0.0 <= effective_min_score <= 1.0:
            raise ValueError("min_score must be between 0 and 1")
        per_source_limit = max(1, int(max_hits_per_source))
        query_tokens = tokenize(query)
        identifiers = identifier_tokens(query)
        graph_scores: Mapping[str, float] | None
        if isinstance(graph_context, set):
            graph_scores = {key: 1.0 for key in graph_context}
        else:
            graph_scores = graph_context
        accepted_statuses = statuses or {"active", "candidate"}
        hits: list[SearchHit] = []
        for document in self._documents:
            if tenant_id is not None and document.tenant_id != tenant_id:
                continue
            if document.status not in accepted_statuses:
                continue
            if filters and not all(
                _matches_filter(document, key, expected) for key, expected in filters.items()
            ):
                continue
            keyword = self._keyword_score(document, query_tokens)
            vector = self._external_score(document, vector_scores)
            graph = self._external_score(document, graph_scores)
            searchable = _normalized(
                " ".join((document.text, str(document.selected_fields)))
            )
            exact_identifier_match = bool(identifiers) and all(
                _contains_identifier(searchable, identifier)
                for identifier in identifiers
            )
            if (
                normalized_mode == "precise"
                and identifiers
                and not exact_identifier_match
            ):
                continue
            score = (
                keyword * keyword_weight + vector * vector_weight + graph * graph_weight
            ) / total_weight
            # Do not dilute an external-channel candidate merely because the
            # caller kept the default hybrid weights. Precise-mode admission
            # still requires a strong vector score below.
            if keyword <= 0:
                score = max(score, vector, graph)
            if exact_identifier_match:
                score = max(score, 1.0)
            # Broad mode may use graph-only retrieval. Empty evidence from all
            # three channels is never a hit.
            if score <= 0 or score < effective_min_score:
                continue
            if (
                normalized_mode == "precise"
                and not identifiers
                and keyword <= 0
                and vector < 0.55
            ):
                continue
            match_reason: Literal["exact_identifier", "keyword", "vector", "graph"]
            if exact_identifier_match:
                match_reason = "exact_identifier"
            elif keyword > 0:
                match_reason = "keyword"
            elif vector >= graph:
                match_reason = "vector"
            else:
                match_reason = "graph"
            hits.append(
                SearchHit(
                    index_id=document.index_id,
                    record_id=document.record_id,
                    score=score,
                    keyword_score=keyword,
                    vector_score=vector,
                    graph_score=graph,
                    match_reason=match_reason,
                    document=document,
                )
            )
        hits.sort(
            key=lambda hit: (
                -hit.score,
                -self._rank_timestamps.get(hit.index_id, 0.0),
                hit.index_id,
            )
        )
        diversified: list[SearchHit] = []
        source_counts: Counter[str] = Counter()
        for hit in hits:
            source_id = hit.document.source_record_id
            if source_counts[source_id] >= per_source_limit:
                continue
            source_counts[source_id] += 1
            diversified.append(hit)
            if len(diversified) >= limit:
                break
        return diversified


def hybrid_search(
    documents: Iterable[FieldIndexDocument | Mapping[str, Any]],
    query: str,
    **kwargs: Any,
) -> list[SearchHit]:
    """One-shot functional facade for :class:`HybridSearchEngine`."""

    return HybridSearchEngine(documents).search(query, **kwargs)


__all__ = ["HybridSearchEngine", "hybrid_search", "identifier_tokens", "tokenize"]
