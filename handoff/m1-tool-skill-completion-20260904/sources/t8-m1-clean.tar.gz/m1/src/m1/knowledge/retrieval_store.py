"""Selected-field lexical/vector retrieval repository mixin.

Kept separate from the governed write repository so candidate generation,
embedding persistence, and ranking can evolve without expanding the core
claim/review transaction module.
"""
from __future__ import annotations

import math
import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from sqlalchemy import Text, case, cast, func, or_, select
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession

# Row mappings are independent of the facade, avoiding a repository cycle.
from .db_models import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    GraphProjectionSnapshotRow,
    KnowledgeIndexRow,
    RecordNotFoundError,
)
from .models import SearchHit


class KnowledgeSearchMixin:
    async def search_index(
        self,
        tenant_id: str,
        query: str,
        *,
        filters: Mapping[str, Any] | None = None,
        query_embedding: Sequence[float] | None = None,
        vector_scores: Mapping[str, float] | None = None,
        graph_context: Mapping[str, float] | set[str] | None = None,
        statuses: set[str] | None = None,
        include_candidate: bool = False,
        keyword_weight: float = 0.65,
        vector_weight: float = 0.25,
        graph_weight: float = 0.10,
        actor_id: str = "",
        actor_roles: Iterable[str] | None = None,
        limit: int = 20,
        candidate_pool_limit: int = 5000,
        mode: str = "precise",
        min_score: float | None = None,
        max_hits_per_source: int = 2,
    ) -> list[SearchHit]:
        """Search persisted allow-listed projections with SQL-side candidates.

        PostgreSQL narrows and orders candidates with trigram indexes before
        Python performs the final hybrid fusion. SQLite keeps the same
        semantics for local development with portable ``ILIKE`` predicates.
        The corpus size therefore no longer determines process memory use.
        """

        if limit < 1:
            return []
        accepted = set(statuses or {"active"})
        if include_candidate:
            accepted &= {"active", "candidate", "deprecated", "rejected"}
        else:
            # Merely passing ``statuses={'candidate'}`` must never bypass the
            # explicit governance gate.
            accepted &= {"active"}
        if not accepted:
            return []
        normalized_embedding: list[float] | None = None
        if query_embedding is not None:
            normalized_embedding = [float(value) for value in query_embedding]
            if len(normalized_embedding) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
                raise ValueError(
                    "query embedding dimension mismatch: "
                    f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, "
                    f"received {len(normalized_embedding)}"
                )
            if not all(math.isfinite(value) for value in normalized_embedding):
                raise ValueError("query embedding contains non-finite values")
        statement = select(KnowledgeIndexRow).where(
            KnowledgeIndexRow.tenant_id == tenant_id,
            KnowledgeIndexRow.status.in_(sorted(accepted)),
        )
        sql_filter_keys = {
            "source_record_id": KnowledgeIndexRow.source_record_id,
            "version": KnowledgeIndexRow.version,
            "document_type": KnowledgeIndexRow.document_type,
            "document_subtype": KnowledgeIndexRow.document_subtype,
            "status": KnowledgeIndexRow.status,
        }
        is_postgresql = self.engine.url.get_backend_name() == "postgresql"
        for key, value in (filters or {}).items():
            column = sql_filter_keys.get(key)
            if column is not None:
                if isinstance(value, (set, tuple, list, frozenset)):
                    statement = statement.where(
                        column.in_([str(item) for item in value])
                    )
                else:
                    statement = statement.where(column == str(value))
            else:
                if is_postgresql:
                    values = (
                        list(value)
                        if isinstance(value, (set, tuple, list, frozenset))
                        else [value]
                    )
                    statement = statement.where(or_(*[
                        cast(KnowledgeIndexRow.selected_fields, JSONB).contains(
                            {key: item}
                        )
                        for item in values
                    ]))
                else:
                    selected = KnowledgeIndexRow.selected_fields[key].as_string()
                    if isinstance(value, (set, tuple, list, frozenset)):
                        statement = statement.where(
                            selected.in_([str(item) for item in value])
                        )
                    else:
                        statement = statement.where(selected == str(value))
        scoped_statement = statement

        from .retrieval import HybridSearchEngine, tokenize

        def escaped_like(value: str) -> str:
            return (
                value.replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
            )

        normalized_query = unicodedata.normalize("NFKC", query).casefold().strip()
        query_terms = list(
            dict.fromkeys(
                item
                for item in [normalized_query, *tokenize(normalized_query)]
                if item
            )
        )[:32]
        text_clauses = [
            or_(
                KnowledgeIndexRow.text.ilike(
                    f"%{escaped_like(term)}%", escape="\\"
                ),
                KnowledgeIndexRow.vector_text.ilike(
                    f"%{escaped_like(term)}%", escape="\\"
                ),
            )
            for term in query_terms
        ]

        pool_limit = max(limit, min(candidate_pool_limit, 50000))
        database_vector_scores: dict[str, float] = {}
        if normalized_embedding is not None:
            async with self.sessionmaker() as session:
                vector_statement = scoped_statement.where(
                    KnowledgeIndexRow.embedding.is_not(None)
                )
                if is_postgresql:
                    distance = KnowledgeIndexRow.embedding.cosine_distance(
                        normalized_embedding
                    )
                    vector_rows = (
                        await session.execute(
                            vector_statement.add_columns(
                                (1.0 - distance).label("vector_score")
                            )
                            .order_by(distance)
                            .limit(pool_limit)
                        )
                    ).all()
                    database_vector_scores = {
                        row.index_id: max(-1.0, min(1.0, float(score)))
                        for row, score in vector_rows
                    }
                else:
                    # SQLite is a contract-test/local backend. Keep it bounded
                    # while production PostgreSQL performs indexed HNSW KNN.
                    rows = (
                        await session.scalars(
                            vector_statement.order_by(
                                KnowledgeIndexRow.created_at.desc(),
                                KnowledgeIndexRow.index_id,
                            ).limit(pool_limit)
                        )
                    ).all()
                    query_norm = math.sqrt(
                        sum(value * value for value in normalized_embedding)
                    )
                    for row in rows:
                        stored = [float(value) for value in (row.embedding or [])]
                        if len(stored) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
                            continue
                        stored_norm = math.sqrt(sum(value * value for value in stored))
                        if not query_norm or not stored_norm:
                            score = 0.0
                        else:
                            score = sum(
                                left * right
                                for left, right in zip(
                                    normalized_embedding, stored, strict=True
                                )
                            ) / (query_norm * stored_norm)
                        database_vector_scores[row.index_id] = score
                    database_vector_scores = dict(
                        sorted(
                            database_vector_scores.items(),
                            key=lambda item: item[1],
                            reverse=True,
                        )[:pool_limit]
                    )

        combined_vector_scores = dict(vector_scores or {})
        combined_vector_scores.update(database_vector_scores)
        effective_vector_scores = combined_vector_scores or None
        external_keys: list[str] = []
        graph_external_keys: list[str] = []
        if effective_vector_scores:
            external_keys.extend(
                key
                for key, _score in sorted(
                    effective_vector_scores.items(),
                    key=lambda item: item[1],
                    reverse=True,
                )[:candidate_pool_limit]
            )
        if isinstance(graph_context, Mapping):
            graph_external_keys.extend(
                key
                for key, _score in sorted(
                    graph_context.items(), key=lambda item: item[1], reverse=True
                )[:candidate_pool_limit]
            )
        elif isinstance(graph_context, set):
            graph_external_keys.extend(list(graph_context)[:candidate_pool_limit])
        external_keys.extend(graph_external_keys)
        graph_external_keys = list(
            dict.fromkeys(str(key) for key in graph_external_keys if key)
        )
        external_keys = list(dict.fromkeys(str(key) for key in external_keys if key))
        external_clause = None
        if external_keys:
            graph_key_clauses = (
                [
                    cast(KnowledgeIndexRow.graph_keys, JSONB).contains([key])
                    for key in graph_external_keys[:256]
                ]
                if is_postgresql
                else [
                    cast(KnowledgeIndexRow.graph_keys, Text).ilike(
                        f'%"{escaped_like(key)}"%', escape="\\"
                    )
                    for key in graph_external_keys[:64]
                ]
            )
            external_clause = or_(
                KnowledgeIndexRow.index_id.in_(external_keys),
                KnowledgeIndexRow.record_id.in_(external_keys),
                KnowledgeIndexRow.source_record_id.in_(external_keys),
                *graph_key_clauses,
            )
        candidate_clauses = list(text_clauses)
        if external_clause is not None:
            candidate_clauses.append(external_clause)
        if candidate_clauses:
            statement = statement.where(or_(*candidate_clauses))

        if normalized_query and is_postgresql:
            statement = statement.order_by(
                func.greatest(
                    func.similarity(KnowledgeIndexRow.text, normalized_query),
                    func.similarity(KnowledgeIndexRow.vector_text, normalized_query),
                ).desc(),
                KnowledgeIndexRow.created_at.desc(),
                KnowledgeIndexRow.index_id,
            )
        elif normalized_query:
            exact_pattern = f"%{escaped_like(normalized_query)}%"
            statement = statement.order_by(
                case(
                    (
                        KnowledgeIndexRow.text.ilike(
                            exact_pattern, escape="\\"
                        ),
                        0,
                    ),
                    else_=1,
                ),
                KnowledgeIndexRow.created_at.desc(),
                KnowledgeIndexRow.index_id,
            )
        else:
            statement = statement.order_by(
                KnowledgeIndexRow.created_at.desc(), KnowledgeIndexRow.index_id
            )
        statement = statement.limit(pool_limit)
        # Mapper is defined after KnowledgeStore in persistence; resolve it at
        # call time once that module has finished loading.
        from .persistence_helpers import _knowledge_index_record

        async with self.sessionmaker() as session:
            rows = [
                row
                for row in (await session.scalars(statement)).all()
                if self.acl_allows(
                    row.acl, actor_id=actor_id, actor_roles=actor_roles
                )
            ]
        documents = [_knowledge_index_record(row) for row in rows]
        rank_timestamps = {
            row.index_id: row.created_at.timestamp() for row in rows
        }
        return HybridSearchEngine(
            documents, rank_timestamps=rank_timestamps
        ).search(
            query,
            vector_scores=effective_vector_scores,
            graph_context=graph_context,
            filters=filters,
            tenant_id=tenant_id,
            statuses=accepted,
            keyword_weight=keyword_weight,
            vector_weight=vector_weight,
            graph_weight=graph_weight,
            limit=limit,
            mode=mode,
            min_score=min_score,
            max_hits_per_source=max_hits_per_source,
        )

    async def list_index_embedding_inputs(
        self,
        tenant_id: str,
        source_record_id: str,
        version: str,
        *,
        only_missing: bool = True,
    ) -> list[tuple[str, str]]:
        """Return stable selected-index text inputs for one source version."""

        statement = select(
            KnowledgeIndexRow.index_id, KnowledgeIndexRow.vector_text
        ).where(
            KnowledgeIndexRow.tenant_id == tenant_id,
            KnowledgeIndexRow.source_record_id == source_record_id,
            KnowledgeIndexRow.version == version,
            KnowledgeIndexRow.status.in_(["active", "candidate"]),
        )
        if only_missing:
            statement = statement.where(KnowledgeIndexRow.embedding.is_(None))
        statement = statement.order_by(KnowledgeIndexRow.index_id)
        async with self.sessionmaker() as session:
            return [
                (str(index_id), str(vector_text or " "))
                for index_id, vector_text in (await session.execute(statement)).all()
            ]

    async def set_index_embeddings(
        self,
        tenant_id: str,
        embeddings: Mapping[str, Sequence[float]],
        *,
        model: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
        dimensions: int = KNOWLEDGE_EMBEDDING_DIMENSIONS,
    ) -> int:
        """Persist validated embeddings without crossing a tenant boundary."""

        if dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "embedding schema dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {dimensions}"
            )
        normalized: dict[str, list[float]] = {}
        for index_id, values in embeddings.items():
            vector = [float(value) for value in values]
            if len(vector) != dimensions:
                raise ValueError(
                    f"embedding dimension mismatch for {index_id}: "
                    f"expected {dimensions}, received {len(vector)}"
                )
            if not all(math.isfinite(value) for value in vector):
                raise ValueError(f"embedding contains non-finite values: {index_id}")
            normalized[str(index_id)] = vector
        if not normalized:
            return 0

        async def operation(session: AsyncSession) -> int:
            snapshot = await session.scalar(
                select(GraphProjectionSnapshotRow)
                .where(
                    GraphProjectionSnapshotRow.tenant_id == tenant_id,
                    GraphProjectionSnapshotRow.source_record_id == source_record_id,
                    GraphProjectionSnapshotRow.version == version,
                )
                .with_for_update()
            )
            if (
                snapshot is None
                or snapshot.status not in {"active", "candidate"}
                or snapshot.fingerprint != fingerprint
            ):
                return 0
            rows = (
                await session.scalars(
                    select(KnowledgeIndexRow).where(
                        KnowledgeIndexRow.tenant_id == tenant_id,
                        KnowledgeIndexRow.index_id.in_(sorted(normalized)),
                        KnowledgeIndexRow.source_record_id == source_record_id,
                        KnowledgeIndexRow.version == version,
                        KnowledgeIndexRow.status.in_(["active", "candidate"]),
                    )
                )
            ).all()
            found = {row.index_id for row in rows}
            missing = sorted(set(normalized).difference(found))
            if missing:
                raise RecordNotFoundError(
                    "knowledge index rows not found in tenant: " + ", ".join(missing)
                )
            for row in rows:
                row.embedding = normalized[row.index_id]
                row.embedding_model = model.strip()
            return len(rows)

        return await self._write(operation)
