"""Governed review decisions, cascades, and projection activation mixin."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from .schema import (
    ClaimStatus,
    ConflictStatus,
    LifecycleStatus,
    ProjectionEventRecord,
    ReviewDecisionRecord,
    ReviewDecisionType,
    ReviewTaskRecord,
    ReviewTaskStatus,
    TaskLifecycleStatus,
    utc_now,
)
from .db_models import (
    AliasSourceBindingRow,
    CanonicalEntityRow,
    ConflictRow,
    DocumentVersionRow,
    EntitySourceBindingRow,
    EvidenceAnchorRow,
    FieldClaimRow,
    GraphProjectionSnapshotRow,
    IdentitySourceBindingRow,
    IdempotencyConflictError,
    KnowledgeChunkRow,
    KnowledgeIndexRow,
    RecordNotFoundError,
    RelationshipClaimRow,
    ReviewDecisionRow,
    ReviewConflictError,
    ReviewTaskRow,
    TaskVersionBindingRow,
    TenantBoundaryError,
)
from .persistence_helpers import (
    _aware,
    _enum,
    _sha256_json,
)


def _review_task_record(row: ReviewTaskRow) -> ReviewTaskRecord:
    return ReviewTaskRecord(
        review_task_id=row.review_task_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        target_type=row.target_type,
        target_id=row.target_id,
        status=row.status,
        priority=row.priority,
        reason_codes=row.reason_codes,
        summary=row.summary,
        assignee_id=row.assignee_id,
        payload=row.payload,
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
        resolved_at=_aware(row.resolved_at),
    )


def _decision_row(record: ReviewDecisionRecord) -> ReviewDecisionRow:
    return ReviewDecisionRow(
        decision_id=record.decision_id,
        review_task_id=record.review_task_id,
        tenant_id=record.tenant_id,
        idempotency_key=record.idempotency_key,
        target_type=record.target_type,
        target_id=record.target_id,
        decision=_enum(record.decision),
        reviewer_id=record.reviewer_id,
        reason=record.reason,
        corrections=record.corrections,
        evidence_anchor_ids=record.evidence_anchor_ids,
        decided_at=record.decided_at,
    )


def _decision_record(row: ReviewDecisionRow) -> ReviewDecisionRecord:
    return ReviewDecisionRecord(
        decision_id=row.decision_id,
        review_task_id=row.review_task_id,
        tenant_id=row.tenant_id,
        idempotency_key=row.idempotency_key,
        target_type=row.target_type,
        target_id=row.target_id,
        decision=row.decision,
        reviewer_id=row.reviewer_id,
        reason=row.reason,
        corrections=row.corrections,
        evidence_anchor_ids=row.evidence_anchor_ids,
        decided_at=_aware(row.decided_at),
    )


class KnowledgeReviewMixin:
    @staticmethod
    async def _lock_review_idempotency_key(
        session: AsyncSession,
        *,
        tenant_id: str,
        idempotency_key: str,
    ) -> None:
        if session.get_bind().dialect.name != "postgresql":
            return
        await session.execute(
            text(
                "SELECT pg_advisory_xact_lock("
                "hashtextextended(:review_lock_key, 0))"
            ),
            {"review_lock_key": _sha256_json([tenant_id, idempotency_key])},
        )

    @staticmethod
    async def _idempotent_review_decision(
        session: AsyncSession,
        existing: ReviewDecisionRow,
        *,
        review_task_id: str,
        decision: ReviewDecisionType,
        reviewer_id: str,
        reason: str,
        corrections: dict[str, Any],
        evidence_anchor_ids: list[str],
        idempotency_key: str,
    ) -> ReviewDecisionRecord:
        if (
            existing.decision != decision.value
            or existing.reviewer_id != reviewer_id
            or existing.reason != reason
            or dict(existing.corrections or {}) != corrections
            or list(existing.evidence_anchor_ids or []) != evidence_anchor_ids
        ):
            raise IdempotencyConflictError(idempotency_key)
        if existing.review_task_id is not None:
            if existing.review_task_id != review_task_id:
                raise IdempotencyConflictError(idempotency_key)
            return _decision_record(existing)

        # Decisions written before migration 0006 have no task reference. A
        # legacy replay may bind the durable decision when its target has one
        # task, or when the original decision timestamp uniquely identifies
        # the resolved/updated task among several tasks for the same target.
        # Ambiguous history stays unbound and fails closed.
        compatible_tasks = list(
            (
                await session.scalars(
                    select(ReviewTaskRow)
                    .where(
                        ReviewTaskRow.tenant_id == existing.tenant_id,
                        ReviewTaskRow.target_type == existing.target_type,
                        ReviewTaskRow.target_id == existing.target_id,
                    )
                    .order_by(ReviewTaskRow.review_task_id)
                    .with_for_update()
                )
            ).all()
        )
        requested_task = next(
            (
                task
                for task in compatible_tasks
                if task.review_task_id == review_task_id
            ),
            None,
        )
        if requested_task is None:
            raise IdempotencyConflictError(idempotency_key)
        if len(compatible_tasks) > 1:
            decided_at = _aware(existing.decided_at)
            timestamp_matches = [
                task.review_task_id
                for task in compatible_tasks
                if decided_at
                in {
                    _aware(task.updated_at),
                    _aware(task.resolved_at),
                }
            ]
            if timestamp_matches != [review_task_id]:
                raise IdempotencyConflictError(idempotency_key)
        existing.review_task_id = review_task_id
        await session.flush()
        return _decision_record(existing)

    async def _review_source_version_ids(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task: ReviewTaskRow,
    ) -> tuple[set[str], bool]:
        """Resolve source versions without taking locks; callers re-read later."""

        if task.target_type == "document_version":
            return {task.target_id}, True
        if task.target_type == "field_claim":
            claim = await session.get(FieldClaimRow, task.target_id)
            if claim is None or claim.tenant_id != tenant_id:
                raise ReviewConflictError("review field claim is unavailable")
            if claim.subject_type != "document_version":
                return set(), False
            return {claim.subject_id}, True
        if task.target_type == "relationship_claim":
            relationship = await session.get(RelationshipClaimRow, task.target_id)
            if relationship is None or relationship.tenant_id != tenant_id:
                raise ReviewConflictError("review relationship is unavailable")
            if not relationship.source_record_id or not relationship.source_version:
                return set(), False
            try:
                source_version = int(relationship.source_version)
            except (TypeError, ValueError) as exc:
                raise ReviewConflictError(
                    "review relationship source version is invalid"
                ) from exc
            version = await session.scalar(
                select(DocumentVersionRow).where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.document_id == relationship.source_record_id,
                    DocumentVersionRow.version_number == source_version,
                )
            )
            if version is None:
                raise ReviewConflictError("review relationship source is unavailable")
            return {version.version_id}, True
        if task.target_type == "canonical_entity":
            version_ids = set(
                (
                    await session.scalars(
                        select(EntitySourceBindingRow.version_id).where(
                            EntitySourceBindingRow.tenant_id == tenant_id,
                            EntitySourceBindingRow.entity_id == task.target_id,
                            EntitySourceBindingRow.status == "active",
                        )
                    )
                ).all()
            )
            return version_ids, bool(version_ids)
        if task.target_type == "external_identity":
            version = await session.get(DocumentVersionRow, task.target_id)
            if version is not None and version.tenant_id == tenant_id:
                return {version.version_id}, True
            version_ids = set(
                (
                    await session.scalars(
                        select(IdentitySourceBindingRow.version_id).where(
                            IdentitySourceBindingRow.tenant_id == tenant_id,
                            IdentitySourceBindingRow.identity_id == task.target_id,
                            IdentitySourceBindingRow.status == "active",
                        )
                    )
                ).all()
            )
            return version_ids, bool(version_ids)
        return set(), False

    async def _lock_review_source_lifecycles(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task: ReviewTaskRow,
    ) -> None:
        version_ids, source_scoped = await self._review_source_version_ids(
            session,
            tenant_id=tenant_id,
            task=task,
        )
        if not source_scoped:
            return
        bindings = (
            await session.scalars(
                select(TaskVersionBindingRow).where(
                    TaskVersionBindingRow.tenant_id == tenant_id,
                    TaskVersionBindingRow.version_id.in_(sorted(version_ids)),
                    TaskVersionBindingRow.status == "active",
                )
            )
        ).all()
        task_ids = sorted({binding.task_id for binding in bindings})
        if not task_ids:
            raise ReviewConflictError("review source has no active task binding")

        active_task_ids: set[str] = set()
        for source_task_id in task_ids:
            lifecycle = await session.scalar(
                self._task_lifecycle_lock_statement(
                    tenant_id,
                    source_task_id,
                    shared=True,
                )
            )
            if lifecycle is None:
                lifecycle = await self._ensure_task_lifecycle_locked(
                    session,
                    tenant_id=tenant_id,
                    task_id=source_task_id,
                    default=TaskLifecycleStatus.ACTIVE,
                )
            if lifecycle.status == TaskLifecycleStatus.ACTIVE.value:
                active_task_ids.add(source_task_id)

        source_versions = (
            await session.scalars(
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.version_id.in_(sorted(version_ids)),
                )
            )
        ).all()
        if {version.version_id for version in source_versions} != version_ids:
            raise ReviewConflictError("review source version is unavailable")
        for document_id in sorted({version.document_id for version in source_versions}):
            await self._lock_graph_generation_row(
                session,
                tenant_id=tenant_id,
                source_record_id=document_id,
            )
        locked_versions = (
            await session.scalars(
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.version_id.in_(sorted(version_ids)),
                )
                .order_by(DocumentVersionRow.version_id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
        ).all()
        if {version.version_id for version in locked_versions} != version_ids:
            raise ReviewConflictError("review source version is unavailable")
        locked_bindings = (
            await session.scalars(
                select(TaskVersionBindingRow)
                .where(
                    TaskVersionBindingRow.tenant_id == tenant_id,
                    TaskVersionBindingRow.version_id.in_(sorted(version_ids)),
                    TaskVersionBindingRow.task_id.in_(sorted(active_task_ids)),
                    TaskVersionBindingRow.status == "active",
                )
                .order_by(TaskVersionBindingRow.binding_id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
        ).all()
        if not locked_bindings:
            raise ReviewConflictError("review source is tombstoned or superseded")

    async def _lock_actionable_review_target(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task: ReviewTaskRow,
        decision: ReviewDecisionType,
    ) -> None:
        if task.target_type == "document_version":
            row = await session.scalar(
                select(DocumentVersionRow)
                .where(
                    DocumentVersionRow.tenant_id == tenant_id,
                    DocumentVersionRow.version_id == task.target_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            actionable = row is not None and row.lifecycle_status in {
                LifecycleStatus.UNDER_REVIEW.value,
            }
        elif task.target_type == "field_claim":
            row = await session.scalar(
                select(FieldClaimRow)
                .where(
                    FieldClaimRow.tenant_id == tenant_id,
                    FieldClaimRow.claim_id == task.target_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            actionable = row is not None and row.status in {
                ClaimStatus.CANDIDATE.value,
                ClaimStatus.UNDER_REVIEW.value,
            }
        elif task.target_type == "relationship_claim":
            row = await session.scalar(
                select(RelationshipClaimRow)
                .where(
                    RelationshipClaimRow.tenant_id == tenant_id,
                    RelationshipClaimRow.relationship_id == task.target_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            actionable = row is not None and row.status in {
                ClaimStatus.CANDIDATE.value,
                ClaimStatus.UNDER_REVIEW.value,
            }
            if actionable and decision == ReviewDecisionType.ACCEPT:
                endpoint_ids = sorted({row.from_entity_id, row.to_entity_id})
                endpoints = (
                    await session.scalars(
                        select(CanonicalEntityRow)
                        .where(
                            CanonicalEntityRow.tenant_id == tenant_id,
                            CanonicalEntityRow.entity_id.in_(endpoint_ids),
                        )
                        .order_by(CanonicalEntityRow.entity_id)
                        .with_for_update()
                        .execution_options(populate_existing=True)
                    )
                ).all()
                actionable = len(endpoints) == 2 and all(
                    endpoint.lifecycle_status
                    in {
                        LifecycleStatus.ACTIVE.value,
                        LifecycleStatus.APPROVED.value,
                    }
                    for endpoint in endpoints
                )
        elif task.target_type == "canonical_entity":
            row = await session.scalar(
                select(CanonicalEntityRow)
                .where(
                    CanonicalEntityRow.tenant_id == tenant_id,
                    CanonicalEntityRow.entity_id == task.target_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            actionable = row is not None and row.lifecycle_status in {
                LifecycleStatus.UNDER_REVIEW.value,
            }
        elif task.target_type == "external_identity":
            conflicts = (
                await session.scalars(
                    select(ConflictRow)
                    .where(
                        ConflictRow.tenant_id == tenant_id,
                        ConflictRow.subject_type == task.target_type,
                        ConflictRow.subject_id == task.target_id,
                        ConflictRow.status == ConflictStatus.OPEN.value,
                    )
                    .order_by(ConflictRow.conflict_id)
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
            ).all()
            actionable = bool(conflicts)
        else:
            raise ValueError(f"unsupported review target: {task.target_type}")
        if not actionable:
            raise ReviewConflictError(
                f"review target is not actionable: {task.target_type}"
            )

    async def list_review_tasks(
        self,
        tenant_id: str,
        *,
        status: ReviewTaskStatus | str = ReviewTaskStatus.OPEN,
        assignee_id: str | None = None,
        limit: int = 100,
    ) -> list[ReviewTaskRecord]:
        statement = select(ReviewTaskRow).where(
            ReviewTaskRow.tenant_id == tenant_id,
            ReviewTaskRow.status == _enum(status),
        )
        if assignee_id:
            statement = statement.where(ReviewTaskRow.assignee_id == assignee_id)
        statement = statement.order_by(ReviewTaskRow.priority.desc(), ReviewTaskRow.created_at).limit(
            max(1, min(limit, 1000))
        )
        async with self.sessionmaker() as session:
            return [_review_task_record(row) for row in (await session.scalars(statement)).all()]

    async def decide_review(
        self,
        *,
        tenant_id: str,
        review_task_id: str,
        decision: ReviewDecisionType | str,
        reviewer_id: str,
        reason: str = "",
        corrections: dict[str, Any] | None = None,
        evidence_anchor_ids: list[str] | None = None,
        idempotency_key: str | None = None,
    ) -> ReviewDecisionRecord:
        decision_value = ReviewDecisionType(_enum(decision))
        if decision_value not in {
            ReviewDecisionType.ACCEPT,
            ReviewDecisionType.REJECT,
            ReviewDecisionType.DEFER,
        }:
            raise ValueError(
                "correct/merge/resolve require an atomic revision workflow"
            )
        if corrections:
            raise ValueError("review corrections require an atomic revision workflow")
        key = idempotency_key or f"review:{review_task_id}:{decision_value.value}:{reviewer_id}"

        async def operation(session: AsyncSession) -> ReviewDecisionRecord:
            await self._require_tenant(session, tenant_id)
            await self._lock_review_idempotency_key(
                session,
                tenant_id=tenant_id,
                idempotency_key=key,
            )
            normalized_corrections = dict(corrections or {})
            normalized_anchor_ids = list(evidence_anchor_ids or [])
            existing = await session.scalar(
                select(ReviewDecisionRow).where(
                    ReviewDecisionRow.tenant_id == tenant_id,
                    ReviewDecisionRow.idempotency_key == key,
                )
            )
            if existing is not None:
                return await self._idempotent_review_decision(
                    session,
                    existing,
                    review_task_id=review_task_id,
                    decision=decision_value,
                    reviewer_id=reviewer_id,
                    reason=reason,
                    corrections=normalized_corrections,
                    evidence_anchor_ids=normalized_anchor_ids,
                    idempotency_key=key,
                )
            discovered_task = await session.get(ReviewTaskRow, review_task_id)
            if discovered_task is None:
                raise RecordNotFoundError(f"review task not found: {review_task_id}")
            if discovered_task.tenant_id != tenant_id:
                raise TenantBoundaryError(review_task_id)
            discovered_target = (
                discovered_task.target_type,
                discovered_task.target_id,
            )
            await self._lock_review_source_lifecycles(
                session,
                tenant_id=tenant_id,
                task=discovered_task,
            )
            task = await session.scalar(
                select(ReviewTaskRow)
                .where(
                    ReviewTaskRow.tenant_id == tenant_id,
                    ReviewTaskRow.review_task_id == review_task_id,
                )
                .with_for_update()
                .execution_options(populate_existing=True)
            )
            if task is None:
                raise RecordNotFoundError(f"review task not found: {review_task_id}")
            if (task.target_type, task.target_id) != discovered_target:
                raise ReviewConflictError("review task target changed concurrently")
            existing = await session.scalar(
                select(ReviewDecisionRow).where(
                    ReviewDecisionRow.tenant_id == tenant_id,
                    ReviewDecisionRow.idempotency_key == key,
                )
            )
            if existing is not None:
                return await self._idempotent_review_decision(
                    session,
                    existing,
                    review_task_id=review_task_id,
                    decision=decision_value,
                    reviewer_id=reviewer_id,
                    reason=reason,
                    corrections=normalized_corrections,
                    evidence_anchor_ids=normalized_anchor_ids,
                    idempotency_key=key,
                )
            if task.status not in {
                ReviewTaskStatus.OPEN.value,
                ReviewTaskStatus.IN_REVIEW.value,
            }:
                raise ReviewConflictError(
                    f"review task is not actionable: {task.status}"
                )
            await self._lock_actionable_review_target(
                session,
                tenant_id=tenant_id,
                task=task,
                decision=decision_value,
            )
            record = ReviewDecisionRecord(
                tenant_id=tenant_id,
                review_task_id=review_task_id,
                idempotency_key=key,
                target_type=task.target_type,
                target_id=task.target_id,
                decision=decision_value,
                reviewer_id=reviewer_id,
                reason=reason,
                corrections=normalized_corrections,
                evidence_anchor_ids=normalized_anchor_ids,
            )
            for anchor_id in record.evidence_anchor_ids:
                await self._assert_owned(session, EvidenceAnchorRow, anchor_id, tenant_id)
            row = _decision_row(record)
            session.add(row)
            if decision_value != ReviewDecisionType.DEFER:
                task.status = ReviewTaskStatus.RESOLVED.value
                task.resolved_at = record.decided_at
                conflicts = (await session.scalars(select(ConflictRow).where(
                    ConflictRow.tenant_id == tenant_id,
                    ConflictRow.subject_type == task.target_type,
                    ConflictRow.subject_id == task.target_id,
                    ConflictRow.status == ConflictStatus.OPEN.value,
                ))).all()
                resolved_status = {
                    ReviewDecisionType.ACCEPT: ConflictStatus.ACCEPTED_RISK.value,
                    ReviewDecisionType.REJECT: ConflictStatus.DISMISSED.value,
                }.get(decision_value, ConflictStatus.RESOLVED.value)
                for conflict in conflicts:
                    conflict.status = resolved_status
                    conflict.resolution_decision_id = record.decision_id
                    conflict.resolved_at = record.decided_at
            task.updated_at = record.decided_at
            await self._apply_review_status(
                session,
                task,
                decision_value,
                decision_id=record.decision_id,
                decided_at=record.decided_at,
            )
            if task.target_type == "relationship_claim":
                relationship = await session.get(RelationshipClaimRow, task.target_id)
                if relationship is not None and relationship.tenant_id == tenant_id:
                    source_record_id = str(
                        relationship.properties.get("source_record_id") or ""
                    )
                    projection_version = str(
                        relationship.properties.get("version") or ""
                    )
                    snapshot = await session.scalar(select(
                        GraphProjectionSnapshotRow
                    ).where(
                        GraphProjectionSnapshotRow.tenant_id == tenant_id,
                        GraphProjectionSnapshotRow.source_record_id
                        == source_record_id,
                        GraphProjectionSnapshotRow.version == projection_version,
                    ))
                    try:
                        version_number = int(projection_version)
                    except (TypeError, ValueError):
                        version_number = -1
                    version_row = await session.scalar(select(DocumentVersionRow).where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.document_id == source_record_id,
                        DocumentVersionRow.version_number == version_number,
                    ))
                    if snapshot is not None and version_row is not None:
                        await self._apply_document_projection_review_status(
                            session,
                            version_row,
                            status=snapshot.status,
                        )
                    elif decision_value == ReviewDecisionType.ACCEPT:
                        await self._enqueue_in_session(
                            session,
                            ProjectionEventRecord(
                                tenant_id=tenant_id,
                                projection_name="graph",
                                idempotency_key=(
                                    f"decision:{record.decision_id}:relationship"
                                ),
                                aggregate_type="relationship_claim",
                                aggregate_id=relationship.relationship_id,
                                event_type="relationship.accepted",
                                payload={
                                    "from_entity_id": relationship.from_entity_id,
                                    "relation_type": relationship.relation_type,
                                    "to_entity_id": relationship.to_entity_id,
                                    "status": ClaimStatus.ACCEPTED.value,
                                    "confidence": relationship.confidence,
                                    "source_record_id": source_record_id,
                                    "version": projection_version,
                                },
                            ),
                        )
            await self._enqueue_in_session(session, ProjectionEventRecord(
                tenant_id=tenant_id,
                projection_name="knowledge",
                idempotency_key=f"decision:{record.decision_id}",
                aggregate_type=task.target_type,
                aggregate_id=task.target_id,
                event_type="review.decided",
                payload={"decision_id": record.decision_id, "decision": decision_value.value},
            ))
            return record
        return await self._write(operation)

    async def _apply_review_status(
        self,
        session: AsyncSession,
        task: ReviewTaskRow,
        decision: ReviewDecisionType,
        *,
        decision_id: str = "",
        decided_at: datetime | None = None,
    ) -> None:
        if decision not in {ReviewDecisionType.ACCEPT, ReviewDecisionType.REJECT}:
            return
        accepted = decision == ReviewDecisionType.ACCEPT
        if task.target_type == "field_claim":
            row = await session.get(FieldClaimRow, task.target_id)
            if row and row.tenant_id == task.tenant_id:
                row.status = ClaimStatus.ACCEPTED.value if accepted else ClaimStatus.REJECTED.value
        elif task.target_type == "relationship_claim":
            row = await session.get(RelationshipClaimRow, task.target_id)
            if row and row.tenant_id == task.tenant_id:
                if accepted:
                    endpoints = (await session.scalars(select(
                        CanonicalEntityRow
                    ).where(
                        CanonicalEntityRow.tenant_id == task.tenant_id,
                        CanonicalEntityRow.entity_id.in_([
                            row.from_entity_id,
                            row.to_entity_id,
                        ]),
                    ))).all()
                    if len(endpoints) != 2 or any(
                        endpoint.lifecycle_status
                        not in {
                            LifecycleStatus.ACTIVE.value,
                            LifecycleStatus.APPROVED.value,
                        }
                        for endpoint in endpoints
                    ):
                        raise ValueError(
                            "relationship endpoints must be active/approved first"
                        )
                row.status = ClaimStatus.ACCEPTED.value if accepted else ClaimStatus.REJECTED.value
        elif task.target_type == "document_version":
            row = await session.get(DocumentVersionRow, task.target_id)
            if row and row.tenant_id == task.tenant_id:
                row.lifecycle_status = (
                    LifecycleStatus.APPROVED.value if accepted else LifecycleStatus.REJECTED.value
                )
                await self._cascade_document_review_status(
                    session,
                    row,
                    accepted=accepted,
                    decision_id=decision_id,
                    decided_at=decided_at or utc_now(),
                )
                await self._apply_document_projection_review_status(
                    session,
                    row,
                    status="active" if accepted else "rejected",
                )
        elif task.target_type == "canonical_entity":
            row = await session.get(CanonicalEntityRow, task.target_id)
            if row and row.tenant_id == task.tenant_id:
                row.lifecycle_status = (
                    LifecycleStatus.APPROVED.value if accepted else LifecycleStatus.REJECTED.value
                )

    async def _cascade_document_review_status(
        self,
        session: AsyncSession,
        version: DocumentVersionRow,
        *,
        accepted: bool,
        decision_id: str,
        decided_at: datetime,
    ) -> None:
        """Apply one document decision to its source-scoped derived claims.

        A reviewer approving an entire document should not then face one task
        per deterministic field/entity/relation.  Shared entities remain
        protected: their global review closes only after the recomputed entity
        is active/approved and no independent conflict remains open.
        """

        tenant_id = version.tenant_id
        claim_status = (
            ClaimStatus.ACCEPTED.value
            if accepted
            else ClaimStatus.REJECTED.value
        )
        lifecycle_status = (
            LifecycleStatus.APPROVED.value
            if accepted
            else LifecycleStatus.REJECTED.value
        )

        field_claims = (await session.scalars(select(FieldClaimRow).where(
            FieldClaimRow.tenant_id == tenant_id,
            FieldClaimRow.subject_type == "document_version",
            FieldClaimRow.subject_id == version.version_id,
            FieldClaimRow.status.in_([
                ClaimStatus.CANDIDATE.value,
                ClaimStatus.UNDER_REVIEW.value,
                ClaimStatus.ACCEPTED.value,
            ]),
        ))).all()
        for claim in field_claims:
            claim.status = claim_status

        entity_bindings = (await session.scalars(select(EntitySourceBindingRow).where(
            EntitySourceBindingRow.tenant_id == tenant_id,
            EntitySourceBindingRow.version_id == version.version_id,
            EntitySourceBindingRow.status == "active",
        ))).all()
        for binding in sorted(entity_bindings, key=lambda item: item.entity_id):
            binding.asserted_lifecycle_status = lifecycle_status
            await self._recompute_entity_from_bindings(
                session,
                tenant_id=tenant_id,
                entity_id=binding.entity_id,
                reason=(
                    f"document review {decision_id or version.version_id} "
                    f"{'accepted' if accepted else 'rejected'} source assertion"
                ),
            )

        identity_bindings = (await session.scalars(select(
            IdentitySourceBindingRow
        ).where(
            IdentitySourceBindingRow.tenant_id == tenant_id,
            IdentitySourceBindingRow.version_id == version.version_id,
            IdentitySourceBindingRow.status == "active",
        ))).all()
        for binding in sorted(identity_bindings, key=lambda item: item.identity_id):
            binding.asserted_status = claim_status
            await self._recompute_identity_from_bindings(
                session,
                tenant_id=tenant_id,
                identity_id=binding.identity_id,
            )

        alias_bindings = (await session.scalars(select(AliasSourceBindingRow).where(
            AliasSourceBindingRow.tenant_id == tenant_id,
            AliasSourceBindingRow.version_id == version.version_id,
            AliasSourceBindingRow.status == "active",
        ))).all()
        for binding in sorted(alias_bindings, key=lambda item: item.alias_id):
            binding.asserted_status = claim_status
            await self._recompute_alias_from_bindings(
                session,
                tenant_id=tenant_id,
                alias_id=binding.alias_id,
            )

        relationships = (await session.scalars(select(RelationshipClaimRow).where(
            RelationshipClaimRow.tenant_id == tenant_id,
            RelationshipClaimRow.source_record_id == version.document_id,
            RelationshipClaimRow.source_version == str(version.version_number),
            RelationshipClaimRow.status.in_([
                ClaimStatus.CANDIDATE.value,
                ClaimStatus.UNDER_REVIEW.value,
                ClaimStatus.ACCEPTED.value,
            ]),
        ))).all()
        if accepted and relationships:
            endpoint_ids = {
                endpoint
                for row in relationships
                for endpoint in (row.from_entity_id, row.to_entity_id)
            }
            endpoints = (await session.scalars(select(CanonicalEntityRow).where(
                CanonicalEntityRow.tenant_id == tenant_id,
                CanonicalEntityRow.entity_id.in_(endpoint_ids),
            ))).all()
            approved_endpoints = {
                row.entity_id
                for row in endpoints
                if row.lifecycle_status in {
                    LifecycleStatus.ACTIVE.value,
                    LifecycleStatus.APPROVED.value,
                }
            }
            for row in relationships:
                if {
                    row.from_entity_id,
                    row.to_entity_id,
                }.issubset(approved_endpoints):
                    row.status = ClaimStatus.ACCEPTED.value
        else:
            for row in relationships:
                row.status = ClaimStatus.REJECTED.value

        await self._resolve_derived_review_tasks(
            session,
            tenant_id=tenant_id,
            target_type="field_claim",
            target_ids={row.claim_id for row in field_claims},
            decision_id=decision_id,
            decided_at=decided_at,
        )
        await self._resolve_derived_review_tasks(
            session,
            tenant_id=tenant_id,
            target_type="relationship_claim",
            target_ids={
                row.relationship_id
                for row in relationships
                if row.status in {
                    ClaimStatus.ACCEPTED.value,
                    ClaimStatus.REJECTED.value,
                }
            },
            decision_id=decision_id,
            decided_at=decided_at,
        )

        entity_ids = {binding.entity_id for binding in entity_bindings}
        if entity_ids:
            resolved_entities = set((await session.scalars(select(
                CanonicalEntityRow.entity_id
            ).where(
                CanonicalEntityRow.tenant_id == tenant_id,
                CanonicalEntityRow.entity_id.in_(entity_ids),
                CanonicalEntityRow.lifecycle_status.in_([
                    LifecycleStatus.ACTIVE.value,
                    LifecycleStatus.APPROVED.value,
                    LifecycleStatus.REJECTED.value,
                ]),
            ))).all())
            conflicted_entities = set((await session.scalars(select(
                ConflictRow.subject_id
            ).where(
                ConflictRow.tenant_id == tenant_id,
                ConflictRow.subject_type == "canonical_entity",
                ConflictRow.subject_id.in_(resolved_entities),
                ConflictRow.status == ConflictStatus.OPEN.value,
            ))).all())
            await self._resolve_derived_review_tasks(
                session,
                tenant_id=tenant_id,
                target_type="canonical_entity",
                target_ids=resolved_entities - conflicted_entities,
                decision_id=decision_id,
                decided_at=decided_at,
            )

    async def _resolve_derived_review_tasks(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        target_type: str,
        target_ids: set[str],
        decision_id: str,
        decided_at: datetime,
    ) -> None:
        if not target_ids:
            return
        reviews = (await session.scalars(select(ReviewTaskRow).where(
            ReviewTaskRow.tenant_id == tenant_id,
            ReviewTaskRow.target_type == target_type,
            ReviewTaskRow.target_id.in_(target_ids),
            ReviewTaskRow.status.in_([
                ReviewTaskStatus.OPEN.value,
                ReviewTaskStatus.IN_REVIEW.value,
            ]),
        ))).all()
        for review in reviews:
            review.status = ReviewTaskStatus.RESOLVED.value
            review.resolved_at = decided_at
            review.updated_at = decided_at
            review.payload = {
                **dict(review.payload or {}),
                "resolved_by_document_decision_id": decision_id,
            }

    async def _apply_document_projection_review_status(
        self,
        session: AsyncSession,
        version: DocumentVersionRow,
        *,
        status: str,
        event_discriminator: str = "",
    ) -> tuple[str | None, str | None]:
        """Promote or reject the selected projections for a reviewed version.

        A document review is the governance gate between staging and the
        customer-visible search/graph projections.  Keeping this transition in
        the same transaction as the decision prevents a resolved review from
        leaving candidate rows searchable only through privileged staging APIs.
        """

        source_record_id = version.document_id
        projection_version = str(version.version_number)
        if status == "active":
            await self._activate_document_projection(
                session,
                tenant_id=version.tenant_id,
                source_record_id=source_record_id,
                version=projection_version,
            )
        chunks = (await session.scalars(select(KnowledgeChunkRow).where(
            KnowledgeChunkRow.tenant_id == version.tenant_id,
            KnowledgeChunkRow.source_record_id == source_record_id,
            KnowledgeChunkRow.version == projection_version,
        ))).all()
        indexes = (await session.scalars(select(KnowledgeIndexRow).where(
            KnowledgeIndexRow.tenant_id == version.tenant_id,
            KnowledgeIndexRow.source_record_id == source_record_id,
            KnowledgeIndexRow.version == projection_version,
        ))).all()
        snapshot = await session.scalar(select(GraphProjectionSnapshotRow).where(
            GraphProjectionSnapshotRow.tenant_id == version.tenant_id,
            GraphProjectionSnapshotRow.source_record_id == source_record_id,
            GraphProjectionSnapshotRow.version == projection_version,
        ))

        for row in chunks:
            row.status = status
        for row in indexes:
            row.status = status
        if snapshot is None:
            # Review can legally happen before projection/backfill.  The next
            # deterministic replay will build rows from the reviewed M1 source.
            return None, None

        # Rebuild from the immutable version payload so the promoted snapshot
        # gets the exact fingerprint a later deterministic Runtime replay will
        # calculate.  Merely mutating status while retaining the candidate
        # fingerprint would make an identical post-review replay look changed.
        from .projection import (
            build_field_index_documents,
            build_graph_projection,
            build_knowledge_chunks,
        )

        graph = build_graph_projection(
            version.payload,
            tenant_id=version.tenant_id,
            source_record_id=source_record_id,
            version=projection_version,
        )
        rebuilt_chunks = build_knowledge_chunks(
            version.payload,
            tenant_id=version.tenant_id,
            source_record_id=source_record_id,
            version=projection_version,
        )
        rebuilt_indexes = build_field_index_documents(
            version.payload,
            tenant_id=version.tenant_id,
            source_record_id=source_record_id,
            version=projection_version,
        )
        graph = graph.model_copy(
            update={
                "nodes": [node.model_copy(update={"status": status}) for node in graph.nodes],
                "edges": [edge.model_copy(update={"status": status}) for edge in graph.edges],
            }
        )
        rebuilt_chunks = [
            item.model_copy(update={"status": status}) for item in rebuilt_chunks
        ]
        rebuilt_indexes = [
            item.model_copy(update={"status": status}) for item in rebuilt_indexes
        ]
        graph = await self._merge_logical_relationships(
            session,
            graph,
            projection_status=status,
        )
        canonical_graph_payload = graph.model_dump(mode="json")
        fingerprint = _sha256_json({
            "chunks": [item.model_dump(mode="json") for item in rebuilt_chunks],
            "index": [item.model_dump(mode="json") for item in rebuilt_indexes],
            "graph": canonical_graph_payload,
        })
        graph = graph.model_copy(update={
            "generation": await self._next_graph_generation(
                session,
                tenant_id=version.tenant_id,
                source_record_id=source_record_id,
            )
        })
        snapshot.status = status
        snapshot.fingerprint = fingerprint
        snapshot.projection_json = graph.model_dump(mode="json")
        snapshot.node_count = len(graph.nodes)
        snapshot.edge_count = len(graph.edges)
        snapshot.updated_at = utc_now()
        await self._supersede_projection_events(
            session, version.tenant_id, snapshot.projection_id, fingerprint
        )

        if status != "active":
            return None, None
        payload = {
            "source_record_id": source_record_id,
            "version": projection_version,
            "fingerprint": fingerprint,
            "status": status,
            "eligible_for_active_projection": True,
            "acl": snapshot.acl,
            "generation": graph.generation,
        }
        review_key = (
            f"document-projection:{source_record_id}:"
            f"{projection_version}:{fingerprint}"
        )
        if event_discriminator:
            review_key = f"{review_key}:{event_discriminator}"
        search_event = await self._enqueue_in_session(session, ProjectionEventRecord(
            tenant_id=version.tenant_id,
            projection_name="search",
            idempotency_key=review_key,
            aggregate_type="document_projection",
            aggregate_id=snapshot.projection_id,
            event_type="search.projection.replaced",
            payload={
                **payload,
                "index_count": len(indexes),
                "chunk_count": len(chunks),
            },
        ))
        graph_event = await self._enqueue_in_session(session, ProjectionEventRecord(
            tenant_id=version.tenant_id,
            projection_name="graph",
            idempotency_key=review_key,
            aggregate_type="document_projection",
            aggregate_id=snapshot.projection_id,
            event_type="graph.projection.replaced",
            payload={
                **payload,
                "node_count": snapshot.node_count,
                "edge_count": snapshot.edge_count,
            },
        ))
        return search_event.event_id, graph_event.event_id

    async def claim_stats(self, tenant_id: str) -> dict[str, Any]:
        async with self.sessionmaker() as session:
            field_rows = (await session.execute(select(
                FieldClaimRow.status, func.count(FieldClaimRow.claim_id)
            ).where(FieldClaimRow.tenant_id == tenant_id).group_by(FieldClaimRow.status))).all()
            relation_rows = (await session.execute(select(
                RelationshipClaimRow.status, func.count(RelationshipClaimRow.relationship_id)
            ).where(RelationshipClaimRow.tenant_id == tenant_id).group_by(RelationshipClaimRow.status))).all()
            open_reviews = await session.scalar(select(func.count(ReviewTaskRow.review_task_id)).where(
                ReviewTaskRow.tenant_id == tenant_id,
                ReviewTaskRow.status == ReviewTaskStatus.OPEN.value,
            ))
            open_conflicts = await session.scalar(select(func.count(ConflictRow.conflict_id)).where(
                ConflictRow.tenant_id == tenant_id,
                ConflictRow.status == ConflictStatus.OPEN.value,
            ))
            return {
                "field_claims": {status: count for status, count in field_rows},
                "relationship_claims": {status: count for status, count in relation_rows},
                "open_review_tasks": int(open_reviews or 0),
                "open_conflicts": int(open_conflicts or 0),
            }
