"""Shared four-eyes and immutable lifecycle helpers for adaptive routes."""

from __future__ import annotations

import hashlib
from collections.abc import Iterable
from datetime import datetime
from typing import Literal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models_base import IdempotencyConflictError
from .route_lifecycle_db_models import RouteLifecycleEventRow

RouteKind = Literal[
    "field_semantic",
    "visual_region",
    "region_capability",
    "content_region",
]
LifecycleEventType = Literal[
    "activated",
    "rejected",
    "deprecated",
    "superseded",
    "auto_deprecated",
]


def require_separated_approval(
    *,
    approved_by: str,
    reviewed_by: str,
    sample_reviewers: Iterable[str],
) -> None:
    """Enforce four-eyes approval against the activation and sample reviewers."""

    approver = approved_by.strip().casefold()
    activation_reviewer = reviewed_by.strip().casefold()
    reviewers = {
        str(item).strip().casefold() for item in sample_reviewers if str(item).strip()
    }
    if not approver or not activation_reviewer:
        raise ValueError("approval and review identities are required")
    if approver == activation_reviewer or approver in reviewers:
        raise ValueError("approver must be independent from every reviewer")


def _identity_reference_sha256(tenant_id: str, identity: str) -> str:
    """Return a tenant-bound identity reference without retaining plaintext."""

    normalized = identity.strip().casefold()
    if not normalized:
        return ""
    return hashlib.sha256(f"{tenant_id}\0{normalized}".encode()).hexdigest()


async def record_route_lifecycle_event(
    session: AsyncSession,
    *,
    tenant_id: str,
    route_kind: RouteKind,
    profile_id: str,
    event_type: LifecycleEventType,
    actor_id: str,
    reason: str,
    observation_count: int,
    occurred_at: datetime,
    counterparty_id: str = "",
) -> RouteLifecycleEventRow:
    """Append one immutable lifecycle event or validate an exact replay."""

    actor = actor_id.strip()
    counterparty = counterparty_id.strip()
    note = reason.strip()
    if not actor or not note:
        raise ValueError("lifecycle actor and reason are required")
    if observation_count < 0:
        raise ValueError("lifecycle observation count must be non-negative")
    idempotency_key = f"route-lifecycle:{route_kind}:{profile_id}:{event_type}"
    actor_reference_sha256 = _identity_reference_sha256(tenant_id, actor)
    counterparty_reference_sha256 = _identity_reference_sha256(tenant_id, counterparty)
    reason_sha256 = hashlib.sha256(note.encode("utf-8")).hexdigest()
    existing = await session.scalar(
        select(RouteLifecycleEventRow).where(
            RouteLifecycleEventRow.tenant_id == tenant_id,
            RouteLifecycleEventRow.idempotency_key == idempotency_key,
        )
    )
    if existing is not None:
        if not (
            existing.route_kind == route_kind
            and existing.profile_id == profile_id
            and existing.event_type == event_type
            and existing.actor_reference_sha256 == actor_reference_sha256
            and existing.counterparty_reference_sha256 == counterparty_reference_sha256
            and existing.reason_sha256 == reason_sha256
            and existing.observation_count == observation_count
        ):
            raise IdempotencyConflictError(idempotency_key)
        return existing

    event_id = hashlib.sha256(f"{tenant_id}\0{idempotency_key}".encode()).hexdigest()
    row = RouteLifecycleEventRow(
        event_id=event_id,
        tenant_id=tenant_id,
        route_kind=route_kind,
        profile_id=profile_id,
        event_type=event_type,
        actor_reference_sha256=actor_reference_sha256,
        counterparty_reference_sha256=counterparty_reference_sha256,
        reason_sha256=reason_sha256,
        observation_count=observation_count,
        idempotency_key=idempotency_key,
        occurred_at=occurred_at,
    )
    session.add(row)
    return row


__all__ = [
    "LifecycleEventType",
    "RouteKind",
    "record_route_lifecycle_event",
    "require_separated_approval",
]
