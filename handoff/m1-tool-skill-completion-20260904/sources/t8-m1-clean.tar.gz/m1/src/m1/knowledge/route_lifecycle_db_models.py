"""Immutable lifecycle audit rows shared by governed adaptive routes."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    CheckConstraint,
    DateTime,
    ForeignKeyConstraint,
    Index,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .db_models_base import KnowledgeBase, TenantScopedMixin


class RouteLifecycleEventRow(TenantScopedMixin, KnowledgeBase):
    __tablename__ = "knowledge_route_lifecycle_events"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "idempotency_key",
            name="route_lifecycle_event_idempotency",
        ),
        ForeignKeyConstraint(
            ["tenant_id"],
            ["knowledge_tenants.tenant_id"],
            name="fk_route_lifecycle_events_tenant",
            ondelete="RESTRICT",
        ),
        CheckConstraint(
            "route_kind IN ('field_semantic','visual_region',"
            "'region_capability','content_region')",
            name="route_kind",
        ),
        CheckConstraint(
            "event_type IN ('activated','rejected','deprecated',"
            "'superseded','auto_deprecated')",
            name="event_type",
        ),
        CheckConstraint(
            "length(actor_reference_sha256) = 64",
            name="actor_reference_sha256_length",
        ),
        CheckConstraint(
            "counterparty_reference_sha256 = '' OR "
            "length(counterparty_reference_sha256) = 64",
            name="counterparty_reference_sha256_length",
        ),
        CheckConstraint("length(reason_sha256) = 64", name="reason_sha256_length"),
        CheckConstraint("observation_count >= 0", name="observation_count_nonnegative"),
        Index(
            "ix_route_lifecycle_events_profile",
            "tenant_id",
            "route_kind",
            "profile_id",
            "occurred_at",
        ),
    )

    event_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    route_kind: Mapped[str] = mapped_column(String(40), nullable=False)
    profile_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(32), nullable=False)
    actor_reference_sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    counterparty_reference_sha256: Mapped[str] = mapped_column(
        String(64), nullable=False, default=""
    )
    reason_sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    observation_count: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0
    )
    idempotency_key: Mapped[str] = mapped_column(String(256), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )


__all__ = ["RouteLifecycleEventRow"]
