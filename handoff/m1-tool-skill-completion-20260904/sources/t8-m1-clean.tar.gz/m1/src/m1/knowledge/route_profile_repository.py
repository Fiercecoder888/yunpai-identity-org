"""Tenant-safe persistence for reusable document-route profiles."""

from __future__ import annotations

import math
from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    RouteObservationRow,
    RouteProfileRow,
    TenantBoundaryError,
    TenantRow,
)
from .persistence_helpers import _aware, _canonical_json, _enum
from .routing_schema import (
    RouteObservationOutcome,
    RouteObservationRecord,
    RouteProfileMatch,
    RouteProfileRecord,
    RouteProfileStatus,
)
from .schema import utc_now

_CANDIDATE_VALIDATION_KIND = "candidate_policy_validation"
_MIN_ACTIVATION_DISTINCT_TASKS = 3


def _sha256_token(value: object) -> str | None:
    token = str(value or "").strip().casefold()
    if len(token) != 64:
        return None
    try:
        int(token, 16)
    except ValueError:
        return None
    return token


def _activation_validation_tasks(
    rows: Sequence[RouteObservationRow],
) -> tuple[set[str], set[str]]:
    """Return explicitly approved and failed task hashes for activation."""

    successful: set[str] = set()
    failed: set[str] = set()
    for row in rows:
        details = row.details_json
        if not isinstance(details, Mapping):
            continue
        if str(details.get("kind") or "") != _CANDIDATE_VALIDATION_KIND:
            continue
        task_ref = _sha256_token(details.get("task_ref"))
        if task_ref is None:
            continue
        if row.outcome == RouteObservationOutcome.FAILURE.value:
            failed.add(task_ref)
            continue
        if row.outcome != RouteObservationOutcome.SUCCESS.value:
            continue
        if str(details.get("decision") or "").strip().casefold() != "approve":
            continue
        if not str(details.get("reviewed_by") or "").strip():
            continue
        if _sha256_token(details.get("review_note_sha256")) is None:
            continue
        successful.add(task_ref)
    return successful, failed


def _profile_record(row: RouteProfileRow) -> RouteProfileRecord:
    return RouteProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        exact_fingerprint=row.exact_fingerprint,
        signature=row.signature_json,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        policy=row.policy_json,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_note=row.review_note,
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
    )


def _observation_record(row: RouteObservationRow) -> RouteObservationRecord:
    return RouteObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        outcome=row.outcome,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        details=row.details_json,
        observed_at=_aware(row.observed_at),
    )


def _same_profile_definition(
    row: RouteProfileRow, record: RouteProfileRecord
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and _canonical_json(row.signature_json)
        == _canonical_json(record.signature.model_dump(mode="json"))
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
        and _canonical_json(row.policy_json) == _canonical_json(record.policy)
        and row.created_by == record.created_by
    )


def _same_observation(
    row: RouteObservationRow, record: RouteObservationRecord
) -> bool:
    return (
        row.profile_id == record.profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and row.outcome == _enum(record.outcome)
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
        and _canonical_json(row.details_json) == _canonical_json(record.details)
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    return second if normalized is None or second > normalized else normalized


class KnowledgeRouteProfileMixin:
    async def _lock_route_tenant(
        self, session: AsyncSession, tenant_id: str
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_route_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> RouteProfileRow:
        statement = select(RouteProfileRow).where(
            RouteProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"route profile not found: {profile_id}")
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_route_profile(
        self, record: RouteProfileRecord
    ) -> RouteProfileRecord:
        """Create a candidate profile, idempotently keyed by profile/version."""

        if record.status is not RouteProfileStatus.CANDIDATE:
            raise ValueError("new route profiles must start as candidate")

        async def operation(session: AsyncSession) -> RouteProfileRecord:
            await self._lock_route_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(RouteProfileRow).where(
                        RouteProfileRow.tenant_id == record.tenant_id,
                        or_(
                            RouteProfileRow.profile_id == record.profile_id,
                            (
                                (RouteProfileRow.profile_key == record.profile_key)
                                & (RouteProfileRow.version == record.version)
                            ),
                            (
                                (
                                    RouteProfileRow.exact_fingerprint
                                    == record.exact_fingerprint
                                )
                                & (RouteProfileRow.version == record.version)
                            ),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if row.profile_key == record.profile_key
                        and row.version == record.version
                    ),
                    None,
                )
                if existing is not None and _same_profile_definition(existing, record):
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"route profile collision: {record.profile_key}:{record.version}"
                )

            predecessor: RouteProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_route_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError("route profile revision changes its profile key")
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("route profile revision changes its fingerprint")
                if record.version != predecessor.version + 1:
                    raise ValueError("route profile revisions must be consecutive")
                if predecessor.status == RouteProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active route profile must be deprecated before revision"
                    )

            row = RouteProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                exact_fingerprint=record.exact_fingerprint,
                signature_json=record.signature.model_dump(mode="json"),
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=record.embedding_dimensions,
                policy_json=record.policy,
                created_by=record.created_by,
                reviewed_by=record.reviewed_by,
                reviewed_at=record.reviewed_at,
                review_note=record.review_note,
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == RouteProfileStatus.CANDIDATE.value
            ):
                predecessor.status = RouteProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at, record.created_at
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def get_route_profile(
        self, tenant_id: str, profile_id: str
    ) -> RouteProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(RouteProfileRow).where(
                    RouteProfileRow.tenant_id == tenant_id,
                    RouteProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def list_route_profiles(
        self,
        tenant_id: str,
        *,
        status: RouteProfileStatus | str | None = None,
        profile_key: str | None = None,
        limit: int = 200,
    ) -> list[RouteProfileRecord]:
        if limit < 1:
            return []
        statement = select(RouteProfileRow).where(
            RouteProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            normalized_status = RouteProfileStatus(_enum(status)).value
            statement = statement.where(RouteProfileRow.status == normalized_status)
        if profile_key is not None:
            statement = statement.where(RouteProfileRow.profile_key == profile_key)
        statement = statement.order_by(
            RouteProfileRow.profile_key,
            RouteProfileRow.version.desc(),
            RouteProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def get_active_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None:
        normalized = exact_fingerprint.strip().lower()
        if len(normalized) != 64:
            raise ValueError("route fingerprint must contain 64 hexadecimal characters")
        try:
            int(normalized, 16)
        except ValueError as exc:
            raise ValueError(
                "route fingerprint must contain 64 hexadecimal characters"
            ) from exc
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(RouteProfileRow)
                .where(
                    RouteProfileRow.tenant_id == tenant_id,
                    RouteProfileRow.exact_fingerprint == normalized,
                    RouteProfileRow.status == RouteProfileStatus.ACTIVE.value,
                )
                .order_by(RouteProfileRow.version.desc())
            )
            return _profile_record(row) if row else None

    async def get_latest_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None:
        normalized = exact_fingerprint.strip().lower()
        if len(normalized) != 64:
            raise ValueError("route fingerprint must contain 64 hexadecimal characters")
        try:
            int(normalized, 16)
        except ValueError as exc:
            raise ValueError(
                "route fingerprint must contain 64 hexadecimal characters"
            ) from exc
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(RouteProfileRow)
                .where(
                    RouteProfileRow.tenant_id == tenant_id,
                    RouteProfileRow.exact_fingerprint == normalized,
                )
                .order_by(
                    RouteProfileRow.version.desc(), RouteProfileRow.profile_id
                )
            )
            return _profile_record(row) if row else None

    async def find_route_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses: Iterable[RouteProfileStatus | str] = (RouteProfileStatus.ACTIVE,),
        min_similarity: float = 0.0,
        limit: int = 5,
    ) -> list[RouteProfileMatch]:
        if limit < 1:
            return []
        normalized_model = embedding_model.strip()
        if not normalized_model:
            raise ValueError("route embedding model identity is required")
        normalized_dimensions = int(embedding_dimensions)
        if normalized_dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "route embedding identity dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, "
                f"received {normalized_dimensions}"
            )
        normalized = [float(value) for value in embedding]
        if len(normalized) != normalized_dimensions:
            raise ValueError(
                "route embedding dimension mismatch: "
                f"expected {normalized_dimensions}, received {len(normalized)}"
            )
        if not all(math.isfinite(value) for value in normalized):
            raise ValueError("route embedding contains non-finite values")
        if not math.isfinite(min_similarity) or not -1.0 <= min_similarity <= 1.0:
            raise ValueError("min_similarity must be a finite value in [-1, 1]")
        accepted = {RouteProfileStatus(_enum(status)).value for status in statuses}
        if not accepted:
            return []

        statement = select(RouteProfileRow).where(
            RouteProfileRow.tenant_id == tenant_id,
            RouteProfileRow.status.in_(sorted(accepted)),
            RouteProfileRow.embedding.is_not(None),
            RouteProfileRow.embedding_model == normalized_model,
            RouteProfileRow.embedding_dimensions == normalized_dimensions,
        )
        is_postgres = self.engine.url.get_backend_name() == "postgresql"
        async with self.sessionmaker() as session:
            if is_postgres:
                distance = RouteProfileRow.embedding.cosine_distance(normalized)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .where((1.0 - distance) >= min_similarity)
                        .order_by(distance, RouteProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    RouteProfileMatch(
                        profile=_profile_record(row),
                        similarity=max(-1.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]

            rows = (
                await session.scalars(
                    statement.order_by(
                        RouteProfileRow.updated_at.desc(), RouteProfileRow.profile_id
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in normalized))
        matches: list[RouteProfileMatch] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(
                    left * right
                    for left, right in zip(normalized, stored, strict=True)
                )
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(-1.0, min(1.0, similarity))
            if similarity >= min_similarity:
                matches.append(
                    RouteProfileMatch(
                        profile=_profile_record(row), similarity=similarity
                    )
                )
        return sorted(
            matches,
            key=lambda item: (-item.similarity, item.profile.profile_id),
        )[: min(limit, 100)]

    async def activate_route_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str | None = None,
        review_note: str = "",
        approved_at: datetime | None = None,
        expected_observation_count: int | None = None,
    ) -> RouteProfileRecord:
        actor = approved_by.strip()
        if not actor:
            raise ValueError("approved_by is required")
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> RouteProfileRecord:
            await self._lock_route_tenant(session, tenant_id)
            row = await self._require_route_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == RouteProfileStatus.ACTIVE.value:
                return _profile_record(row)
            if row.status != RouteProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate route profiles may be activated")
            reviewer = str(reviewed_by or "").strip()
            note = review_note.strip()
            if not reviewer or len(reviewer) > 256:
                raise ValueError("reviewed_by is required for route activation")
            if not note or len(note) > 4096:
                raise ValueError("review_note is required for route activation")
            if (
                expected_observation_count is not None
                and row.observation_count != expected_observation_count
            ):
                raise IdempotencyConflictError(
                    f"route-approval-observations:{tenant_id}:{profile_id}"
                )

            validation_rows = (
                await session.scalars(
                    select(RouteObservationRow).where(
                        RouteObservationRow.tenant_id == tenant_id,
                        RouteObservationRow.profile_id == profile_id,
                    )
                )
            ).all()
            successful_tasks, failed_tasks = _activation_validation_tasks(
                validation_rows
            )
            if failed_tasks:
                raise ValueError("route profile has failed explicit validation samples")
            if len(successful_tasks) < _MIN_ACTIVATION_DISTINCT_TASKS:
                raise ValueError(
                    "route profile requires at least three distinct explicitly "
                    "reviewed validation tasks"
                )

            statement = select(RouteProfileRow).where(
                RouteProfileRow.tenant_id == tenant_id,
                RouteProfileRow.profile_id != profile_id,
                RouteProfileRow.status == RouteProfileStatus.ACTIVE.value,
                or_(
                    RouteProfileRow.profile_key == row.profile_key,
                    RouteProfileRow.exact_fingerprint == row.exact_fingerprint,
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = RouteProfileStatus.DEPRECATED.value
                previous.updated_at = now

            row.status = RouteProfileStatus.ACTIVE.value
            row.reviewed_by = reviewer
            row.reviewed_at = row.reviewed_at or now
            row.review_note = note
            row.approved_by = actor
            row.approved_at = now
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def reject_route_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str = "",
        reviewed_at: datetime | None = None,
    ) -> RouteProfileRecord:
        actor = reviewed_by.strip()
        if not actor:
            raise ValueError("reviewed_by is required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> RouteProfileRecord:
            await self._lock_route_tenant(session, tenant_id)
            row = await self._require_route_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == RouteProfileStatus.REJECTED.value:
                return _profile_record(row)
            if row.status != RouteProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate route profiles may be rejected")
            row.status = RouteProfileStatus.REJECTED.value
            row.reviewed_by = actor
            row.reviewed_at = now
            row.review_note = review_note
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def deprecate_route_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str | None = None,
        review_note: str = "",
        reviewed_at: datetime | None = None,
    ) -> RouteProfileRecord:
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> RouteProfileRecord:
            await self._lock_route_tenant(session, tenant_id)
            row = await self._require_route_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == RouteProfileStatus.DEPRECATED.value:
                return _profile_record(row)
            if row.status == RouteProfileStatus.REJECTED.value:
                raise ValueError("a rejected route profile cannot be deprecated")
            row.status = RouteProfileStatus.DEPRECATED.value
            if reviewed_by:
                row.reviewed_by = reviewed_by.strip()
                row.reviewed_at = now
            if review_note:
                row.review_note = review_note
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def record_route_observation(
        self, record: RouteObservationRecord
    ) -> RouteObservationRecord:
        """Record one idempotent outcome and update profile counters atomically."""

        async def operation(session: AsyncSession) -> RouteObservationRecord:
            await self._lock_route_tenant(session, record.tenant_id)
            profile = await self._require_route_profile(
                session, record.tenant_id, record.profile_id, for_update=True
            )
            existing = await session.scalar(
                select(RouteObservationRow).where(
                    RouteObservationRow.tenant_id == record.tenant_id,
                    RouteObservationRow.idempotency_key == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError("observation fingerprint does not match route profile")

            row = RouteObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                outcome=record.outcome.value,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                details_json=record.details,
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at, record.observed_at
            )
            if record.outcome is RouteObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at, record.observed_at
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at, record.observed_at
                )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def list_route_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        outcome: RouteObservationOutcome | str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[RouteObservationRecord]:
        if limit < 1:
            return []
        if offset < 0:
            raise ValueError("route observation offset must not be negative")
        statement = select(RouteObservationRow).where(
            RouteObservationRow.tenant_id == tenant_id
        )
        if profile_id is not None:
            statement = statement.where(RouteObservationRow.profile_id == profile_id)
        if outcome is not None:
            normalized_outcome = RouteObservationOutcome(_enum(outcome)).value
            statement = statement.where(
                RouteObservationRow.outcome == normalized_outcome
            )
        statement = statement.order_by(
            RouteObservationRow.observed_at.desc(),
            RouteObservationRow.observation_id,
        ).offset(offset).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_observation_record(row) for row in rows]


__all__ = ["KnowledgeRouteProfileMixin"]
