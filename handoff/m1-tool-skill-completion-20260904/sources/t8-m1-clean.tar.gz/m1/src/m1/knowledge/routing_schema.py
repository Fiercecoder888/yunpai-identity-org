"""Governed persistence contracts for reusable document-route profiles."""

from __future__ import annotations

import math
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Self

from pydantic import Field, field_validator, model_validator

from m1.documents.parsing.adaptive_routing import (
    DocumentRouteCandidate,
    DocumentRouteSignature,
)

from .db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from .schema import KnowledgeSchema, new_id, utc_now


class RouteProfileStatus(StrEnum):
    CANDIDATE = "candidate"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class RouteObservationOutcome(StrEnum):
    SUCCESS = "success"
    FAILURE = "failure"


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class RouteProfileRecord(KnowledgeSchema):
    """One immutable route policy version plus mutable governance statistics."""

    profile_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    version: int = Field(ge=1)
    supersedes_profile_id: str | None = Field(
        default=None, min_length=1, max_length=128
    )
    status: RouteProfileStatus = RouteProfileStatus.CANDIDATE
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    signature: DocumentRouteSignature
    embedding: list[float] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0)
    policy: dict[str, Any] = Field(default_factory=dict)
    created_by: str = Field(min_length=1, max_length=256)
    reviewed_by: str | None = Field(default=None, min_length=1, max_length=256)
    reviewed_at: datetime | None = None
    review_note: str = Field(default="", max_length=4096)
    approved_by: str | None = Field(default=None, min_length=1, max_length=256)
    approved_at: datetime | None = None
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)
    last_observed_at: datetime | None = None
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.lower()

    @field_validator("embedding")
    @classmethod
    def validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        if value is None:
            return None
        normalized = [float(item) for item in value]
        if len(normalized) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "route embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {len(normalized)}"
            )
        if not all(math.isfinite(item) for item in normalized):
            raise ValueError("route embedding contains non-finite values")
        return normalized

    @field_validator("embedding_model")
    @classmethod
    def normalize_embedding_model(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "reviewed_at",
        "approved_at",
        "last_observed_at",
        "last_success_at",
        "last_failure_at",
        "created_at",
        "updated_at",
    )
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _utc(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.version == 1 and self.supersedes_profile_id is not None:
            raise ValueError("a first route profile version cannot supersede another")
        if self.version > 1 and self.supersedes_profile_id is None:
            raise ValueError("route profile revisions require a superseded profile")
        if self.supersedes_profile_id == self.profile_id:
            raise ValueError("a route profile cannot supersede itself")
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("exact_fingerprint does not match the route signature")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError(
                    "route embedding identity requires an embedding vector"
                )
        else:
            if not self.embedding_model:
                raise ValueError("route embeddings require a model identity")
            if self.embedding_dimensions not in {0, len(self.embedding)}:
                raise ValueError(
                    "route embedding identity dimensions do not match the vector"
                )
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("route observation counters are inconsistent")
        if self.status is RouteProfileStatus.ACTIVE and (
            not self.approved_by or self.approved_at is None
        ):
            raise ValueError("active route profiles require approval metadata")
        return self

    def as_candidate(self) -> DocumentRouteCandidate:
        return DocumentRouteCandidate(
            route_id=self.profile_id,
            signature=self.signature,
            signature_vector=(
                tuple(self.embedding) if self.embedding is not None else None
            ),
        )


class RouteObservationRecord(KnowledgeSchema):
    observation_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: RouteObservationOutcome
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)
    details: dict[str, Any] = Field(default_factory=dict)
    observed_at: datetime = Field(default_factory=utc_now)

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.lower()

    @field_validator("observed_at")
    @classmethod
    def normalize_time(cls, value: datetime) -> datetime:
        return _utc(value) or utc_now()


class RouteProfileMatch(KnowledgeSchema):
    profile: RouteProfileRecord
    similarity: float = Field(ge=-1.0, le=1.0)


__all__ = [
    "RouteObservationOutcome",
    "RouteObservationRecord",
    "RouteProfileMatch",
    "RouteProfileRecord",
    "RouteProfileStatus",
]
