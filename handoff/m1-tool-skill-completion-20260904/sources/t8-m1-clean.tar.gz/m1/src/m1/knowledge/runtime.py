"""Runtime bridge from the existing M1 task pipeline to Wiki and Graph.

The bridge is deliberately fail-isolated: M1 first commits its legacy task and
document rows, then calls this runtime.  Every projection is deterministic and
can be replayed from ``m1.document.v2`` when Postgres/Neo4j is unavailable.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import text

from .canonicalization import canonicalize_document
from .eligibility import knowledge_sync_eligibility
from .embeddings import EmbeddingProvider
from .lightrag_shadow import LightRAGShadowClient
from .outbox_delivery import (
    EXTERNAL_PROJECTION_LEASE_SECONDS,
    LIFECYCLE_WAIT_DEADLINE_SECONDS,
    LIGHTRAG_PROJECTION_LEASE_SECONDS,
    OutboxDrainResult,
    drain_projection_outbox,
    fail_projection_events,
)
from .persistence import (
    IdempotencyConflictError,
    KnowledgeStore,
    RecordNotFoundError,
)
from .schema import (
    CanonicalEntityRecord,
    ClaimStatus,
    ConflictRecord,
    IngestDocumentResult,
    OutboxStatus,
    ProjectionEventRecord,
    ProjectionReplaceResult,
    TaskFenceToken,
    TenantRecord,
    utc_now,
)
from .sinks import GraphSink

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from .entity_routing_runtime import EntityRoutingRuntime

LIGHTRAG_HEALTH_TIMEOUT_SECONDS = 0.5
LIGHTRAG_RECONCILE_ATTEMPTS = 3


class RuntimeModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class KnowledgeSyncOutcome(RuntimeModel):
    tenant_id: str
    task_id: str
    status: str
    document: IngestDocumentResult
    projection: ProjectionReplaceResult
    graph_synced: bool = False
    graph_error: str = ""
    embedding_synced: bool = False
    embedding_error: str = ""
    embedding_count: int = 0
    shadow_synced: bool = False
    shadow_error: str = ""
    canonical_entity_count: int = 0
    relationship_count: int = 0
    identity_conflict_count: int = 0


class KnowledgeTombstoneOutcome(RuntimeModel):
    tenant_id: str
    task_id: str
    status: str
    occurrence_count: int = 0
    version_count: int = 0
    source_record_ids: list[str] = Field(default_factory=list)
    graph_deleted: int = 0
    graph_replaced: int = 0
    graph_errors: list[str] = Field(default_factory=list)
    shadow_deleted: int = 0
    shadow_replaced: int = 0
    shadow_queued: int = 0
    shadow_errors: list[str] = Field(default_factory=list)
    changed: bool = False


class KnowledgeSyncIneligibleError(ValueError):
    """A retained task document has no governed facts to project."""


class KnowledgeRuntime:
    """Coordinates the governed store, selected index and Graph sink."""

    def __init__(
        self,
        store: KnowledgeStore,
        graph_sink: GraphSink,
        *,
        auto_project: bool = True,
        embedding_provider: EmbeddingProvider | None = None,
        lightrag_shadow: LightRAGShadowClient | None = None,
        outbox_max_attempts: int = 10,
        entity_routing_runtime: EntityRoutingRuntime | None = None,
    ) -> None:
        self.store = store
        self.graph_sink = graph_sink
        self.auto_project = auto_project
        self.embedding_provider = embedding_provider
        self.lightrag_shadow = lightrag_shadow
        self.entity_routing_runtime = entity_routing_runtime
        self.outbox_max_attempts = max(1, int(outbox_max_attempts))
        self.outbox_lifecycle_wait_deadline_seconds = LIFECYCLE_WAIT_DEADLINE_SECONDS
        self._lightrag_last_success_sync_at = ""
        self._lightrag_last_success_delete_at = ""
        self._health_probe_task: asyncio.Task[dict[str, Any]] | None = None
        self._initialized = False
        # One large inventory snapshot can contain thousands of independent
        # entities, identities and aliases.  Bound their database round-trips
        # across all concurrent documents so Postgres gains useful overlap
        # without an unbounded connection/task fan-out.
        self._canonical_write_semaphore = asyncio.Semaphore(16)
        # LightRAG replaces one source document at a time. Serial delivery
        # prevents an older in-flight version from completing after a newer
        # version and becoming the final shadow state.
        self._lightrag_delivery_lock = asyncio.Lock()

    def lightrag_status_snapshot(self) -> dict[str, Any]:
        """Return local LightRAG lifecycle state without probing the sidecar."""

        client = self.lightrag_shadow
        return {
            "enabled": client is not None,
            "configured": client is not None,
            "workspace": client.workspace if client is not None else "",
            "last_success_sync_at": self._lightrag_last_success_sync_at or None,
            "last_success_delete_at": self._lightrag_last_success_delete_at or None,
        }

    async def _embed_projection(
        self,
        *,
        tenant_id: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
    ) -> int:
        provider = self.embedding_provider
        if provider is None:
            raise RuntimeError("embedding provider is not configured")
        inputs = await self.store.list_index_embedding_inputs(
            tenant_id, source_record_id, version, only_missing=True
        )
        if not inputs:
            return 0
        vectors = await provider.embed_texts([text for _index_id, text in inputs])
        if len(vectors) != len(inputs):
            raise ValueError("embedding provider returned an incomplete batch")
        return await self.store.set_index_embeddings(
            tenant_id,
            {
                index_id: vector
                for (index_id, _text), vector in zip(inputs, vectors, strict=True)
            },
            model=provider.model,
            source_record_id=source_record_id,
            version=version,
            fingerprint=fingerprint,
            dimensions=provider.dimensions,
        )

    async def _enqueue_lightrag_projection(
        self,
        *,
        tenant_id: str,
        source_record_id: str,
        version: str,
        fingerprint: str,
        action: str,
        reason: str,
        discriminator: str = "",
        fence: TaskFenceToken | None = None,
    ) -> ProjectionEventRecord:
        if self.lightrag_shadow is None:
            raise RuntimeError("LightRAG shadow is not configured")
        suffix = discriminator or fingerprint or version
        return await self.store.enqueue_projection(
            ProjectionEventRecord(
                tenant_id=tenant_id,
                projection_name="lightrag_shadow",
                idempotency_key=(
                    f"lightrag-shadow:{action}:{source_record_id}:{version}:{suffix}"
                ),
                aggregate_type="document_projection",
                aggregate_id=source_record_id,
                event_type=f"lightrag.shadow.{action}",
                payload={
                    "action": action,
                    "reason": reason,
                    "source_record_id": source_record_id,
                    "version": version,
                    "fingerprint": fingerprint,
                },
            ),
            fence=fence,
        )

    async def _deliver_lightrag_projection_unlocked(
        self, event: ProjectionEventRecord
    ) -> None:
        client = self.lightrag_shadow
        if client is None:
            raise RuntimeError("LightRAG shadow is not configured")
        source_record_id = str(event.payload.get("source_record_id") or "")
        action = str(event.payload.get("action") or "")
        if not source_record_id:
            raise RecordNotFoundError("LightRAG event is missing source_record_id")
        if action not in {"upsert", "delete"}:
            raise RecordNotFoundError(f"unsupported LightRAG action: {action}")

        async def desired_state():
            latest = await self.store.get_graph_projection(
                event.tenant_id,
                source_record_id,
                include_candidate=True,
                actor_roles={"admin"},
            )
            active = await self.store.get_graph_projection(
                event.tenant_id,
                source_record_id,
                actor_roles={"admin"},
            )
            if latest is None or active is None or latest.version != active.version:
                return "delete", "", []
            inputs = await self.store.list_index_embedding_inputs(
                event.tenant_id,
                source_record_id,
                active.version,
                only_missing=False,
            )
            return "upsert", active.version, [text for _index_id, text in inputs]

        for _attempt in range(LIGHTRAG_RECONCILE_ATTEMPTS):
            desired_action, desired_version, texts = await desired_state()
            if desired_action == "upsert":
                await client.upsert_document(
                    tenant_id=event.tenant_id,
                    source_record_id=source_record_id,
                    version=desired_version,
                    fingerprint=(
                        str(event.payload.get("fingerprint") or "")
                        if desired_version == str(event.payload.get("version") or "")
                        else ""
                    ),
                    texts=texts,
                )
            else:
                await client.delete_source(
                    tenant_id=event.tenant_id,
                    source_record_id=source_record_id,
                )
            confirmed_action, confirmed_version, _texts = await desired_state()
            if (confirmed_action, confirmed_version) == (
                desired_action,
                desired_version,
            ):
                now = utc_now().isoformat()
                if desired_action == "upsert":
                    self._lightrag_last_success_sync_at = now
                else:
                    self._lightrag_last_success_delete_at = now
                return
        raise RuntimeError("LightRAG source changed during reconciliation")

    async def _deliver_lightrag_projection(self, event: ProjectionEventRecord) -> None:
        async with self._lightrag_delivery_lock:
            await self._deliver_lightrag_projection_unlocked(event)

    async def _try_lightrag_projection(
        self, event: ProjectionEventRecord
    ) -> tuple[bool, str]:
        if event.status == OutboxStatus.DELIVERED:
            return True, ""
        leased = await self.store.lease_projection_event(
            event.event_id,
            tenant_id=event.tenant_id,
            lease_seconds=LIGHTRAG_PROJECTION_LEASE_SECONDS,
        )
        if leased is None:
            return False, ""
        try:
            await self._deliver_lightrag_projection(leased)
            delivered = await self.store.mark_projection_delivered(
                leased.event_id,
                tenant_id=leased.tenant_id,
                lease_attempt=leased.attempts,
            )
            return delivered, ""
        except Exception as exc:  # noqa: BLE001 - durable optional retry
            error = str(exc).strip() or exc.__class__.__name__
            await fail_projection_events(self, [leased], exc)
            return False, error

    async def search_index(self, tenant_id: str, query: str, **kwargs: Any):
        """Embed a query when available and degrade safely to lexical search."""

        query_embedding = None
        if self.embedding_provider is not None:
            try:
                query_embedding = (await self.embedding_provider.embed_texts([query]))[
                    0
                ]
            except Exception as exc:  # noqa: BLE001 - lexical search remains available
                logging.getLogger(__name__).warning(
                    "Embedding query failed; using lexical search error_type=%s",
                    exc.__class__.__name__,
                )
        return await self.store.search_index(
            tenant_id,
            query,
            query_embedding=query_embedding,
            **kwargs,
        )

    async def _canonical_write(self, operation):
        async with self._canonical_write_semaphore:
            return await operation()

    @staticmethod
    def _graph_with_acl(graph, acl):
        acl_payload = (
            acl.model_dump(mode="json")
            if isinstance(acl, BaseModel)
            else dict(acl or {})
        )
        return graph.model_copy(
            update={
                "nodes": [
                    node.model_copy(
                        update={"properties": {**node.properties, "acl": acl_payload}}
                    )
                    for node in graph.nodes
                ],
                "edges": [
                    edge.model_copy(
                        update={"properties": {**edge.properties, "acl": acl_payload}}
                    )
                    for edge in graph.edges
                ],
            }
        )

    async def init(
        self,
        *,
        default_tenant_id: str = "default",
        default_tenant_name: str = "Default tenant",
        migrate_schema: bool | None = None,
    ) -> None:
        await self.store.init(migrate_schema=migrate_schema)
        initialize_graph = getattr(self.graph_sink, "initialize", None)
        if callable(initialize_graph):
            await asyncio.to_thread(initialize_graph)
        existing = await self.store.get_tenant(default_tenant_id)
        if existing is None:
            created = await self.store.create_tenant(
                TenantRecord(
                    tenant_id=default_tenant_id,
                    tenant_key=default_tenant_id,
                    display_name=default_tenant_name,
                )
            )
            if created.tenant_id != default_tenant_id:
                raise ValueError(
                    f"tenant key {default_tenant_id!r} already belongs to "
                    f"{created.tenant_id!r}"
                )
        self._initialized = True

    async def ensure_tenant(self, tenant_id: str) -> TenantRecord:
        tenant = await self.store.get_tenant(tenant_id)
        if tenant is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return tenant

    async def create_tenant(
        self,
        tenant_id: str,
        display_name: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> TenantRecord:
        return await self.store.create_tenant(
            TenantRecord(
                tenant_id=tenant_id,
                tenant_key=tenant_id,
                display_name=display_name,
                metadata=metadata or {},
            )
        )

    async def sync_document(
        self,
        *,
        tenant_id: str,
        task_id: str,
        document: dict[str, Any],
        reactivate: bool = False,
    ) -> KnowledgeSyncOutcome:
        if not self._initialized:
            raise RuntimeError("KnowledgeRuntime is not initialized")
        eligible, reason = knowledge_sync_eligibility(document)
        if not eligible:
            raise KnowledgeSyncIneligibleError(
                f"document is not eligible for governed knowledge projection: {reason}"
            )
        if reactivate:
            raise ValueError(
                "task reactivation requires an explicit governed restoration workflow"
            )
        tenant = await self.ensure_tenant(tenant_id)
        fence = await self.store.begin_task_fence(
            tenant_id,
            task_id,
            reactivate=reactivate,
        )
        ingested = await self.store.ingest_document(
            tenant_id,
            task_id,
            document,
            fence=fence,
        )
        canonical = canonicalize_document(
            document,
            tenant_id=tenant_id,
            source_record_id=ingested.document_id,
            source_version=str(ingested.version_number),
        )
        entity_router = self.entity_routing_runtime
        linked_entity_ids: dict[str, str] = {}
        linked_entity_assertions: dict[str, CanonicalEntityRecord] = {}
        if entity_router is not None:
            try:
                routed = await entity_router.resolve(
                    tenant_id=tenant_id,
                    source_version_id=ingested.version_id,
                    fence=fence,
                    canonical=canonical,
                )
                canonical = routed.canonical
                linked_entity_ids = dict(routed.linked_entity_ids)
                linked_entity_assertions = dict(routed.linked_entity_assertions)
            except Exception as exc:  # optional identity routing fails closed
                if getattr(entity_router, "required", False):
                    raise
                logger.warning(
                    "Entity identity routing degraded error_type=%s",
                    exc.__class__.__name__,
                )

        async def persist_entity(entity):
            # Canonicalization is storage agnostic and therefore starts with
            # the portable tenant-visible ACL.  The governed runtime is the
            # boundary that applies each customer's configured default ACL to
            # every persisted entity and relationship derived from a source.
            async def operation():
                return await self.store.put_entity_with_source(
                    entity.model_copy(update={"acl": tenant.default_acl}),
                    ingested.version_id,
                    fence,
                )

            return await self._canonical_write(operation)

        persisted_entities = await asyncio.gather(
            *(persist_entity(entity) for entity in canonical.entities)
        )

        async def persist_linked_entity_source(
            source_entity_id: str,
            target_entity_id: str,
        ) -> None:
            assertion = linked_entity_assertions.get(source_entity_id)
            if assertion is None:
                raise RuntimeError("linked entity route is missing its source assertion")

            async def operation() -> None:
                await self.store.bind_linked_entity_source_with_fence(
                    tenant_id,
                    entity_id=target_entity_id,
                    version_id=ingested.version_id,
                    source_assertion=assertion.model_copy(
                        update={"acl": tenant.default_acl}
                    ),
                    fence=fence,
                )

            await self._canonical_write(operation)

        await asyncio.gather(
            *(
                persist_linked_entity_source(source_entity_id, target_entity_id)
                for source_entity_id, target_entity_id in linked_entity_ids.items()
            )
        )

        async def persist_identity(identity) -> int:
            async def operation() -> int:
                try:
                    await self.store.add_external_identity_with_source(
                        identity,
                        ingested.version_id,
                        fence,
                    )
                    return 0
                except IdempotencyConflictError:
                    # Do not silently remap an existing source identity.  The
                    # original mapping remains authoritative and the count is
                    # surfaced for review/quality reporting.
                    existing = await self.store.find_external_identity(
                        tenant_id,
                        entity_type=identity.entity_type,
                        source_system=identity.source_system,
                        external_id=identity.external_id,
                    )
                    await self.store.record_conflict(
                        ConflictRecord(
                            tenant_id=tenant_id,
                            subject_type="external_identity",
                            # Scope the conflict to the immutable source
                            # version so tombstone can close its review task.
                            # The proposed identity remains explicit in the
                            # audit details below.
                            subject_id=ingested.version_id,
                            field_path="$.external_identity.entity_id",
                            competing_claim_ids=[
                                item
                                for item in (
                                    existing.identity_id if existing else "",
                                    identity.identity_id,
                                )
                                if item
                            ],
                            severity="error",
                            details={
                                "entity_type": identity.entity_type,
                                "source_system": identity.source_system,
                                "external_id": identity.external_id,
                                "proposed_identity_id": identity.identity_id,
                                "existing_entity_id": (
                                    existing.entity_id if existing else None
                                ),
                                "proposed_entity_id": identity.entity_id,
                            },
                        ),
                        fence=fence,
                        source_version_id=ingested.version_id,
                    )
                    return 1

            return await self._canonical_write(operation)

        identity_results = await asyncio.gather(
            *(persist_identity(identity) for identity in canonical.external_identities)
        )
        identity_conflicts = sum(identity_results)

        async def persist_alias(alias):
            async def operation():
                return await self.store.add_entity_alias_with_source(
                    alias,
                    ingested.version_id,
                    fence,
                )

            return await self._canonical_write(operation)

        await asyncio.gather(*(persist_alias(alias) for alias in canonical.aliases))

        if entity_router is not None:
            refresh_entity_ids = {
                *(entity.entity_id for entity in persisted_entities),
                *linked_entity_ids.values(),
            }
            for entity_id in sorted(refresh_entity_ids):
                await entity_router.refresh_entity_index(
                    tenant_id=tenant_id,
                    entity_id=entity_id,
                )

        async def persist_relationship(relationship):
            # Canonicalization keeps stable evidence candidates and exact
            # source locators.  SQL evidence anchors are version-specific UUIDs;
            # retain candidate IDs in properties until a reviewed anchor link
            # is resolved instead of forging a cross-version foreign key.
            persisted_relationship = relationship.model_copy(
                update={
                    # A deterministic relation is still only a candidate when
                    # its source document is awaiting review.  Routing it as
                    # accepted would create an active-Graph outbox event even
                    # though only a staging snapshot is governance-eligible.
                    "status": (
                        ClaimStatus.CANDIDATE
                        if document.get("needs_review")
                        else relationship.status
                    ),
                    "acl": tenant.default_acl,
                    "evidence_anchor_id": None,
                    "additional_evidence_anchor_ids": [],
                    "properties": {
                        **relationship.properties,
                        "source_record_id": ingested.document_id,
                        "version": str(ingested.version_number),
                        "evidence_anchor_candidates": [
                            relationship.evidence_anchor_id,
                            *relationship.additional_evidence_anchor_ids,
                        ],
                    },
                }
            )
            return await self._canonical_write(
                lambda: self.store.claim_relationship(
                    persisted_relationship,
                    fence=fence,
                )
            )

        await asyncio.gather(
            *(
                persist_relationship(relationship)
                for relationship in canonical.relationships
            )
        )
        governed_version = await self.store.get_document_version(
            tenant_id, ingested.version_id
        )
        projection_status_override = None
        if governed_version is not None:
            lifecycle = str(governed_version.lifecycle_status)
            if lifecycle in {"approved", "active"}:
                projection_status_override = "active"
            elif lifecycle == "rejected":
                projection_status_override = "rejected"
            elif lifecycle == "deprecated":
                projection_status_override = "deprecated"
        projection = await self.store.replace_document_projections(
            tenant_id,
            document,
            source_record_id=ingested.document_id,
            version=str(ingested.version_number),
            status_override=projection_status_override,
            fence=fence,
            lightrag_shadow_enabled=self.lightrag_shadow is not None,
            embedding_model=(
                self.embedding_provider.model
                if self.embedding_provider is not None
                else ""
            ),
        )
        await self.store.validate_task_fence(tenant_id, task_id, fence)

        # Wiki and selected search rows are already committed in the same DB
        # transactions, so their outbox acknowledgements are deterministic.
        await self.store.mark_projection_delivered(
            ingested.projection_event_id, tenant_id=tenant_id
        )
        await self.store.mark_projection_delivered(
            projection.search_event_id, tenant_id=tenant_id
        )

        shadow_synced = False
        shadow_error = ""
        if self.lightrag_shadow is not None:
            shadow_action = "upsert" if projection.status == "active" else "delete"
            shadow_event = await self._enqueue_lightrag_projection(
                tenant_id=tenant_id,
                source_record_id=projection.source_record_id,
                version=projection.version,
                fingerprint=projection.fingerprint,
                action=shadow_action,
                reason="active" if shadow_action == "upsert" else "candidate",
                fence=fence,
            )
            shadow_synced, shadow_error = await self._try_lightrag_projection(
                shadow_event
            )

        embedding_synced = False
        embedding_error = ""
        embedding_count = 0
        if self.embedding_provider is not None:
            embedding_event = await self.store.enqueue_projection(
                ProjectionEventRecord(
                    tenant_id=tenant_id,
                    projection_name="embedding",
                    idempotency_key=(
                        f"embedding:{projection.source_record_id}:"
                        f"{projection.version}:{projection.fingerprint}:"
                        f"{self.embedding_provider.model}"
                    ),
                    aggregate_type="document_projection",
                    aggregate_id=projection.source_record_id,
                    event_type="embedding.projection.replaced",
                    payload={
                        "source_record_id": projection.source_record_id,
                        "version": projection.version,
                        "fingerprint": projection.fingerprint,
                        "model": self.embedding_provider.model,
                    },
                ),
                fence=fence,
            )
            if embedding_event.status == OutboxStatus.DELIVERED:
                embedding_synced = True
            else:
                leased_embedding = await self.store.lease_projection_event(
                    embedding_event.event_id,
                    tenant_id=tenant_id,
                    lease_seconds=EXTERNAL_PROJECTION_LEASE_SECONDS,
                )
                if leased_embedding is not None:
                    try:
                        embedding_count = await self._embed_projection(
                            tenant_id=tenant_id,
                            source_record_id=projection.source_record_id,
                            version=projection.version,
                            fingerprint=projection.fingerprint,
                        )
                        embedding_synced = await self.store.mark_projection_delivered(
                            leased_embedding.event_id,
                            tenant_id=tenant_id,
                            lease_attempt=leased_embedding.attempts,
                        )
                    except Exception as exc:  # noqa: BLE001 - durable retry below
                        embedding_error = exc.__class__.__name__
                        await fail_projection_events(self, [leased_embedding], exc)

        graph_synced = False
        graph_error = ""
        if projection.status == "active" and self.auto_project:
            graph = await self.store.get_graph_projection(
                tenant_id,
                projection.source_record_id,
                projection.version,
            )
            if graph is not None:
                leased_graph = await self.store.lease_projection_event(
                    projection.graph_event_id,
                    tenant_id=tenant_id,
                    lease_seconds=EXTERNAL_PROJECTION_LEASE_SECONDS,
                )
                if leased_graph is not None:
                    try:
                        graph = self._graph_with_acl(graph, tenant.default_acl)
                        await asyncio.to_thread(
                            self.graph_sink.replace_projection, graph
                        )
                        graph_synced = await self.store.mark_projection_delivered(
                            leased_graph.event_id,
                            tenant_id=tenant_id,
                            lease_attempt=leased_graph.attempts,
                        )
                    except Exception as exc:  # noqa: BLE001 - durable retry below
                        graph_error = exc.__class__.__name__
                        await fail_projection_events(self, [leased_graph], exc)
        else:
            # Candidate graphs remain in the governed staging snapshot and are
            # never sent to the active Neo4j projection before approval.
            await self.store.mark_projection_delivered(
                projection.graph_event_id, tenant_id=tenant_id
            )

        # Report success only while this generation is still authoritative.
        # Graph generations and durable delete events protect external sinks;
        # this final check prevents a superseded caller from claiming success.
        await self.store.validate_task_fence(tenant_id, task_id, fence)
        return KnowledgeSyncOutcome(
            tenant_id=tenant_id,
            task_id=task_id,
            status=("synced" if not graph_error and not embedding_error else "partial"),
            document=ingested,
            projection=projection,
            graph_synced=graph_synced,
            graph_error=graph_error,
            embedding_synced=embedding_synced,
            embedding_error=embedding_error,
            embedding_count=embedding_count,
            shadow_synced=shadow_synced,
            shadow_error=shadow_error,
            canonical_entity_count=len(canonical.entities),
            relationship_count=len(canonical.relationships),
            identity_conflict_count=identity_conflicts,
        )

    async def tombstone_task(
        self,
        *,
        tenant_id: str,
        task_id: str,
    ) -> KnowledgeTombstoneOutcome:
        """Retire Wiki/search rows and durably delete active Graph projections."""

        if not self._initialized:
            raise RuntimeError("KnowledgeRuntime is not initialized")
        await self.ensure_tenant(tenant_id)
        result = await self.store.tombstone_task(
            tenant_id,
            task_id,
            include_lightrag=self.lightrag_shadow is not None,
        )
        deleted = 0
        replaced = 0
        errors: list[str] = []
        shadow_deleted = 0
        shadow_replaced = 0
        shadow_queued = 0
        shadow_errors: list[str] = []
        for item in result.get("graph_events", []):
            source_record_id = str(item.get("source_record_id") or "")
            event_id = str(item.get("event_id") or "")
            generation = int(item.get("generation") or 0)
            if not source_record_id or not event_id:
                continue
            leased_graph = await self.store.lease_projection_event(
                event_id,
                tenant_id=tenant_id,
                lease_seconds=EXTERNAL_PROJECTION_LEASE_SECONDS,
            )
            if leased_graph is None:
                continue
            try:
                await asyncio.to_thread(
                    self.graph_sink.delete_projection,
                    tenant_id,
                    source_record_id,
                    generation=generation,
                )
                delivered = await self.store.mark_projection_delivered(
                    leased_graph.event_id,
                    tenant_id=tenant_id,
                    lease_attempt=leased_graph.attempts,
                )
                deleted += int(delivered)
            except Exception as exc:  # noqa: BLE001 - durable outbox retry
                error = exc.__class__.__name__
                failure = await fail_projection_events(self, [leased_graph], exc)
                if (
                    failure.retried
                    or failure.lifecycle_waits
                    or failure.terminal_failures
                ):
                    errors.append(error)
        for item in result.get("graph_replacements", []):
            source_record_id = str(item.get("source_record_id") or "")
            version = str(item.get("version") or "")
            graph_event_id = str(item.get("graph_event_id") or "")
            search_event_id = str(item.get("search_event_id") or "")
            if search_event_id:
                await self.store.mark_projection_delivered(
                    search_event_id, tenant_id=tenant_id
                )
            if not source_record_id or not version or not graph_event_id:
                continue
            leased_graph = await self.store.lease_projection_event(
                graph_event_id,
                tenant_id=tenant_id,
                lease_seconds=EXTERNAL_PROJECTION_LEASE_SECONDS,
            )
            if leased_graph is None:
                continue
            try:
                graph = await self.store.get_graph_projection(
                    tenant_id,
                    source_record_id,
                    version,
                )
                if graph is None:
                    raise RecordNotFoundError(
                        f"fallback graph not found: {source_record_id}:{version}"
                    )
                tenant = await self.ensure_tenant(tenant_id)
                graph = self._graph_with_acl(graph, tenant.default_acl)
                await asyncio.to_thread(self.graph_sink.replace_projection, graph)
                delivered = await self.store.mark_projection_delivered(
                    leased_graph.event_id,
                    tenant_id=tenant_id,
                    lease_attempt=leased_graph.attempts,
                )
                replaced += int(delivered)
            except Exception as exc:  # noqa: BLE001 - durable outbox retry
                error = exc.__class__.__name__
                failure = await fail_projection_events(self, [leased_graph], exc)
                if (
                    failure.retried
                    or failure.lifecycle_waits
                    or failure.terminal_failures
                ):
                    errors.append(error)
        if self.lightrag_shadow is not None:
            shadow_queued = len(result.get("shadow_events", []))
        return KnowledgeTombstoneOutcome(
            tenant_id=tenant_id,
            task_id=task_id,
            status="tombstoned" if not errors else "partial",
            occurrence_count=int(result.get("occurrence_count") or 0),
            version_count=int(result.get("version_count") or 0),
            source_record_ids=list(result.get("source_record_ids") or []),
            graph_deleted=deleted,
            graph_replaced=replaced,
            graph_errors=errors,
            shadow_deleted=shadow_deleted,
            shadow_replaced=shadow_replaced,
            shadow_queued=shadow_queued,
            shadow_errors=shadow_errors,
            changed=bool(result.get("changed")),
        )

    async def drain_outbox(
        self,
        *,
        tenant_id: str | None = None,
        limit: int = 100,
        protect_fresh_seconds: float = 0.0,
    ) -> OutboxDrainResult:
        return await drain_projection_outbox(
            self,
            tenant_id=tenant_id,
            limit=limit,
            protect_fresh_seconds=protect_fresh_seconds,
        )

    async def requeue_terminal_graph_event(
        self,
        event_id: str,
        *,
        tenant_id: str,
        expected_last_error_contains: str,
    ) -> ProjectionEventRecord:
        """Requeue one verified terminal graph event for normal worker delivery."""

        return await self.store.requeue_terminal_graph_event(
            event_id,
            tenant_id=tenant_id,
            expected_last_error_contains=expected_last_error_contains,
        )

    async def _health_once(self) -> dict[str, Any]:
        try:
            async with self.store.engine.connect() as connection:
                await connection.execute(text("SELECT 1"))
            wiki_health = {
                "status": "ok",
                "backend": self.store.engine.url.get_backend_name(),
                "error": None,
            }
        except Exception as exc:  # noqa: BLE001 - report type without credentials
            wiki_health = {
                "status": "error",
                "backend": self.store.engine.url.get_backend_name(),
                "error": exc.__class__.__name__,
            }
        try:
            graph_health = await asyncio.to_thread(self.graph_sink.health)
        except Exception as exc:  # noqa: BLE001 - authoritative health is explicit
            graph_health = {
                "status": "error",
                "backend": self.graph_sink.__class__.__name__,
                "error": exc.__class__.__name__,
            }
        if self.lightrag_shadow is None:
            shadow_health = {
                "enabled": False,
                "ready": False,
                "workspace": "",
                "error": None,
            }
        else:
            try:
                shadow_health = await asyncio.wait_for(
                    self.lightrag_shadow.health(),
                    timeout=LIGHTRAG_HEALTH_TIMEOUT_SECONDS,
                )
            except Exception as exc:  # noqa: BLE001 - optional sidecar degrades
                shadow_health = {
                    "enabled": True,
                    "ready": False,
                    "workspace": self.lightrag_shadow.workspace,
                    "error": exc.__class__.__name__,
                }
        shadow_ready = bool(shadow_health.get("ready"))
        shadow_health.update(
            {
                "status": (
                    "disabled"
                    if not bool(shadow_health.get("enabled"))
                    else "ok"
                    if shadow_ready
                    else "degraded"
                ),
                "degraded": bool(shadow_health.get("enabled")) and not shadow_ready,
            }
        )
        shadow_health.update(self.lightrag_status_snapshot())
        authoritative_ready = (
            wiki_health.get("status") == "ok" and graph_health.get("status") == "ok"
        )
        return {
            "status": "ok" if authoritative_ready else "error",
            "wiki_backend": self.store.engine.url.get_backend_name(),
            "wiki": wiki_health,
            "embeddings": {
                "enabled": self.embedding_provider is not None,
                "model": (
                    self.embedding_provider.model
                    if self.embedding_provider is not None
                    else ""
                ),
            },
            "graph": graph_health,
            "lightrag_shadow": shadow_health,
        }

    async def health(self) -> dict[str, Any]:
        """Share one authoritative probe across concurrent or timed-out callers."""

        task = self._health_probe_task
        if task is None:
            task = asyncio.create_task(
                self._health_once(),
                name="m1-knowledge-health-probe",
            )
            self._health_probe_task = task
        try:
            # /ready has its own hard deadline. Shielding keeps a timed-out
            # to_thread Neo4j probe reusable instead of spawning another one.
            return await asyncio.shield(task)
        finally:
            if task.done() and self._health_probe_task is task:
                self._health_probe_task = None

    async def close(self) -> None:
        health_probe = self._health_probe_task
        self._health_probe_task = None
        if health_probe is not None and not health_probe.done():
            health_probe.cancel()
            await asyncio.gather(health_probe, return_exceptions=True)
        try:
            try:
                await asyncio.to_thread(self.graph_sink.close)
            finally:
                if self.embedding_provider is not None:
                    await self.embedding_provider.close()
                if self.lightrag_shadow is not None:
                    await self.lightrag_shadow.close()
        finally:
            await self.store.close()
            self._initialized = False


__all__ = [
    "KnowledgeRuntime",
    "KnowledgeSyncOutcome",
    "KnowledgeTombstoneOutcome",
    "OutboxDrainResult",
]
