"""Governed Wiki contracts used by :class:`m1.knowledge.KnowledgeStore`.

Kept separate from the extraction/search projection contracts in ``models`` so
the Wiki schema can evolve without coupling graph projections to SQL rows.
"""
from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def utc_now() -> datetime:
    return datetime.now(UTC)


def new_id() -> str:
    return str(uuid4())


class LifecycleStatus(StrEnum):
    RAW = "raw"
    PARSED = "parsed"
    NORMALIZED = "normalized"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class BatchStatus(StrEnum):
    STAGED = "staged"
    RUNNING = "running"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"


class ClaimStatus(StrEnum):
    CANDIDATE = "candidate"
    UNDER_REVIEW = "under_review"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"


class Visibility(StrEnum):
    PRIVATE = "private"
    TENANT = "tenant"
    RESTRICTED = "restricted"
    PUBLIC = "public"


class ReviewDecisionType(StrEnum):
    ACCEPT = "accept"
    REJECT = "reject"
    CORRECT = "correct"
    MERGE = "merge"
    RESOLVE = "resolve"
    DEFER = "defer"


class ReviewTaskStatus(StrEnum):
    OPEN = "open"
    IN_REVIEW = "in_review"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"


class ConflictStatus(StrEnum):
    OPEN = "open"
    RESOLVED = "resolved"
    ACCEPTED_RISK = "accepted_risk"
    DISMISSED = "dismissed"


class OutboxStatus(StrEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    DELIVERED = "delivered"
    FAILED = "failed"


class TaskLifecycleStatus(StrEnum):
    ACTIVE = "active"
    TOMBSTONED = "tombstoned"


class TaskFenceError(RuntimeError):
    """A task-scoped write cannot proceed under its lifecycle fence."""


class TaskTombstonedError(TaskFenceError):
    """The task has a durable tombstone and needs explicit reactivation."""


class StaleTaskFenceError(TaskFenceError):
    """A newer sync or tombstone superseded the caller's fence epoch."""


class KnowledgeSchema(BaseModel):
    model_config = ConfigDict(extra="forbid", from_attributes=True)


class AccessControl(KnowledgeSchema):
    visibility: Visibility = Visibility.TENANT
    owner_principal: str | None = None
    read_principals: list[str] = Field(default_factory=list)
    write_principals: list[str] = Field(default_factory=list)
    security_labels: list[str] = Field(default_factory=list)


class BitemporalRecord(KnowledgeSchema):
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    recorded_from: datetime = Field(default_factory=utc_now)
    recorded_to: datetime | None = None

    @field_validator("valid_from", "valid_to", "recorded_from", "recorded_to")
    @classmethod
    def normalize_timezone(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    @model_validator(mode="after")
    def valid_windows(self) -> BitemporalRecord:
        if self.valid_from and self.valid_to and self.valid_to <= self.valid_from:
            raise ValueError("valid_to must be later than valid_from")
        if self.recorded_to and self.recorded_to <= self.recorded_from:
            raise ValueError("recorded_to must be later than recorded_from")
        return self


class TenantRecord(KnowledgeSchema):
    tenant_id: str = Field(default_factory=new_id)
    tenant_key: str = Field(min_length=1, max_length=128)
    display_name: str = Field(min_length=1, max_length=256)
    lifecycle_status: LifecycleStatus = LifecycleStatus.ACTIVE
    default_acl: AccessControl = Field(default_factory=AccessControl)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class IngestionBatchRecord(KnowledgeSchema):
    batch_id: str = Field(default_factory=new_id)
    tenant_id: str
    idempotency_key: str = Field(min_length=1, max_length=256)
    source_type: str = Field(min_length=1, max_length=64)
    status: BatchStatus = BatchStatus.STAGED
    manifest: dict[str, Any] = Field(default_factory=dict)
    statistics: dict[str, Any] = Field(default_factory=dict)
    acl: AccessControl = Field(default_factory=AccessControl)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class SourceAssetRecord(KnowledgeSchema):
    asset_id: str = Field(default_factory=new_id)
    tenant_id: str
    sha256: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    size_bytes: int = Field(ge=0)
    mime_type: str = Field(default="application/octet-stream", max_length=256)
    object_uri: str = Field(min_length=1, max_length=2048)
    original_filename: str = Field(default="", max_length=1024)
    lifecycle_status: LifecycleStatus = LifecycleStatus.RAW
    acl: AccessControl = Field(default_factory=AccessControl)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)

    @field_validator("sha256")
    @classmethod
    def lower_hash(cls, value: str) -> str:
        return value.lower()


class SourceOccurrenceRecord(KnowledgeSchema):
    occurrence_id: str = Field(default_factory=new_id)
    tenant_id: str
    batch_id: str
    asset_id: str
    idempotency_key: str = Field(min_length=1, max_length=256)
    source_system: str = Field(default="file", max_length=128)
    source_uri: str = Field(default="", max_length=2048)
    archive_path: str | None = Field(default=None, max_length=2048)
    display_filename: str = Field(default="", max_length=1024)
    source_modified_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)


class TaskLifecycleRecord(KnowledgeSchema):
    lifecycle_id: str = Field(default_factory=new_id)
    tenant_id: str
    task_id: str = Field(min_length=1, max_length=128)
    epoch: int = Field(default=0, ge=0)
    status: TaskLifecycleStatus = TaskLifecycleStatus.ACTIVE
    updated_at: datetime = Field(default_factory=utc_now)
    tombstoned_at: datetime | None = None


class TaskFenceToken(KnowledgeSchema):
    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: str
    task_id: str = Field(min_length=1, max_length=128)
    epoch: int = Field(ge=1)
    reactivated: bool = False


class KnowledgeDocumentRecord(BitemporalRecord):
    document_id: str = Field(default_factory=new_id)
    tenant_id: str
    canonical_key: str = Field(min_length=1, max_length=512)
    document_type: str = Field(default="unknown", max_length=128)
    document_subtype: str = Field(default="unknown", max_length=128)
    title: str = Field(default="", max_length=2048)
    lifecycle_status: LifecycleStatus = LifecycleStatus.RAW
    acl: AccessControl = Field(default_factory=AccessControl)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class DocumentVersionRecord(BitemporalRecord):
    version_id: str = Field(default_factory=new_id)
    tenant_id: str
    document_id: str
    source_asset_id: str
    source_occurrence_id: str | None = None
    version_number: int = Field(ge=1)
    schema_version: str = Field(default="m1.document.v2", max_length=64)
    content_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    parser_version: str = Field(default="", max_length=128)
    processing_revision: str = Field(default="legacy", max_length=64)
    supersedes_version_id: str | None = Field(default=None, max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)
    lifecycle_status: LifecycleStatus = LifecycleStatus.PARSED
    acl: AccessControl = Field(default_factory=AccessControl)
    created_at: datetime = Field(default_factory=utc_now)

    @field_validator("content_hash")
    @classmethod
    def lower_hash(cls, value: str) -> str:
        return value.lower()


class EvidenceAnchorRecord(KnowledgeSchema):
    anchor_id: str = Field(default_factory=new_id)
    tenant_id: str
    document_version_id: str
    anchor_type: str = Field(max_length=64)
    locator: dict[str, Any] = Field(default_factory=dict)
    excerpt: str | None = None
    excerpt_hash: str | None = Field(default=None, max_length=64)
    created_at: datetime = Field(default_factory=utc_now)


class FieldClaimRecord(BitemporalRecord):
    claim_id: str = Field(default_factory=new_id)
    tenant_id: str
    idempotency_key: str = Field(min_length=1, max_length=256)
    subject_type: str = Field(max_length=64)
    subject_id: str = Field(max_length=128)
    field_path: str = Field(min_length=1, max_length=1024)
    value: Any = None
    normalized_value: Any = None
    evidence_anchor_id: str | None = None
    additional_evidence_anchor_ids: list[str] = Field(default_factory=list)
    extraction_method: str = Field(default="deterministic", max_length=64)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: ClaimStatus = ClaimStatus.CANDIDATE
    acl: AccessControl = Field(default_factory=AccessControl)
    created_at: datetime = Field(default_factory=utc_now)


class CanonicalEntityRecord(BitemporalRecord):
    entity_id: str = Field(default_factory=new_id)
    tenant_id: str
    entity_type: str = Field(min_length=1, max_length=128)
    canonical_key: str = Field(min_length=1, max_length=512)
    canonical_label: str = Field(min_length=1, max_length=1024)
    attributes: dict[str, Any] = Field(default_factory=dict)
    lifecycle_status: LifecycleStatus = LifecycleStatus.UNDER_REVIEW
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    acl: AccessControl = Field(default_factory=AccessControl)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class ExternalIdentityRecord(KnowledgeSchema):
    identity_id: str = Field(default_factory=new_id)
    tenant_id: str
    entity_id: str
    entity_type: str = Field(min_length=1, max_length=128)
    source_system: str = Field(min_length=1, max_length=128)
    external_id: str = Field(min_length=1, max_length=512)
    mapping_rule: str = Field(default="", max_length=256)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: ClaimStatus = ClaimStatus.CANDIDATE
    conflicts: list[dict[str, Any]] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utc_now)


class EntityAliasRecord(KnowledgeSchema):
    alias_id: str = Field(default_factory=new_id)
    tenant_id: str
    entity_id: str
    alias: str = Field(min_length=1, max_length=1024)
    normalized_alias: str = Field(min_length=1, max_length=1024)
    language: str = Field(default="und", max_length=16)
    source_system: str = Field(default="", max_length=128)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: ClaimStatus = ClaimStatus.CANDIDATE
    created_at: datetime = Field(default_factory=utc_now)


class EntityRevisionRecord(BitemporalRecord):
    revision_id: str = Field(default_factory=new_id)
    tenant_id: str
    entity_id: str
    revision_number: int = Field(ge=1)
    payload: dict[str, Any] = Field(default_factory=dict)
    based_on_revision_id: str | None = None
    change_reason: str = Field(default="", max_length=2048)
    lifecycle_status: LifecycleStatus = LifecycleStatus.UNDER_REVIEW
    acl: AccessControl = Field(default_factory=AccessControl)
    created_at: datetime = Field(default_factory=utc_now)


class RelationshipClaimRecord(BitemporalRecord):
    relationship_id: str = Field(default_factory=new_id)
    tenant_id: str
    idempotency_key: str = Field(min_length=1, max_length=256)
    from_entity_id: str
    relation_type: str = Field(min_length=1, max_length=128)
    to_entity_id: str
    properties: dict[str, Any] = Field(default_factory=dict)
    evidence_anchor_id: str | None = None
    additional_evidence_anchor_ids: list[str] = Field(default_factory=list)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    status: ClaimStatus = ClaimStatus.CANDIDATE
    acl: AccessControl = Field(default_factory=AccessControl)
    created_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def different_endpoints(self) -> RelationshipClaimRecord:
        if self.from_entity_id == self.to_entity_id:
            raise ValueError("from_entity_id and to_entity_id must differ")
        return self


class ReviewTaskRecord(KnowledgeSchema):
    review_task_id: str = Field(default_factory=new_id)
    tenant_id: str
    idempotency_key: str = Field(min_length=1, max_length=256)
    target_type: str = Field(max_length=64)
    target_id: str = Field(max_length=128)
    status: ReviewTaskStatus = ReviewTaskStatus.OPEN
    priority: int = Field(default=50, ge=0, le=100)
    reason_codes: list[str] = Field(default_factory=list)
    summary: str = Field(default="", max_length=4096)
    assignee_id: str | None = Field(default=None, max_length=256)
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    resolved_at: datetime | None = None


class ReviewDecisionRecord(KnowledgeSchema):
    decision_id: str = Field(default_factory=new_id)
    tenant_id: str
    review_task_id: str | None = Field(default=None, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    target_type: str = Field(max_length=64)
    target_id: str = Field(max_length=128)
    decision: ReviewDecisionType
    reviewer_id: str = Field(min_length=1, max_length=256)
    reason: str = Field(default="", max_length=4096)
    corrections: dict[str, Any] = Field(default_factory=dict)
    evidence_anchor_ids: list[str] = Field(default_factory=list)
    decided_at: datetime = Field(default_factory=utc_now)


class ConflictRecord(KnowledgeSchema):
    conflict_id: str = Field(default_factory=new_id)
    tenant_id: str
    subject_type: str = Field(max_length=64)
    subject_id: str = Field(max_length=128)
    field_path: str = Field(default="", max_length=1024)
    competing_claim_ids: list[str] = Field(default_factory=list)
    severity: str = Field(default="warning", max_length=32)
    status: ConflictStatus = ConflictStatus.OPEN
    resolution_decision_id: str | None = None
    details: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    resolved_at: datetime | None = None


class ProjectionEventRecord(KnowledgeSchema):
    event_id: str = Field(default_factory=new_id)
    tenant_id: str
    projection_name: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    aggregate_type: str = Field(min_length=1, max_length=64)
    aggregate_id: str = Field(min_length=1, max_length=128)
    event_type: str = Field(min_length=1, max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)
    status: OutboxStatus = OutboxStatus.PENDING
    attempts: int = Field(default=0, ge=0)
    available_at: datetime = Field(default_factory=utc_now)
    leased_until: datetime | None = None
    delivered_at: datetime | None = None
    last_error: str = ""
    created_at: datetime = Field(default_factory=utc_now)


class IngestDocumentResult(KnowledgeSchema):
    tenant_id: str
    task_id: str
    batch_id: str
    asset_id: str
    occurrence_id: str
    document_id: str
    version_id: str
    version_number: int
    created: bool
    evidence_anchor_count: int = 0
    field_claim_count: int = 0
    review_task_id: str | None = None
    projection_event_id: str


class KnowledgeSearchResult(KnowledgeSchema):
    record_type: str
    record_id: str
    label: str
    score: float = Field(default=1.0, ge=0.0)
    highlights: dict[str, Any] = Field(default_factory=dict)


class ProjectionReplaceResult(KnowledgeSchema):
    tenant_id: str
    source_record_id: str
    version: str
    fingerprint: str
    status: str
    chunk_count: int
    index_count: int
    node_count: int
    edge_count: int
    changed: bool
    search_event_id: str
    graph_event_id: str
    shadow_event_id: str = ""
    embedding_event_id: str = ""


__all__ = [name for name in globals() if name.endswith(("Record", "Status", "Type"))] + [
    "AccessControl", "BatchStatus", "ClaimStatus", "IngestDocumentResult",
    "KnowledgeSearchResult", "LifecycleStatus", "OutboxStatus", "ProjectionReplaceResult", "Visibility",
    "StaleTaskFenceError", "TaskFenceError", "TaskFenceToken",
    "TaskTombstonedError", "new_id", "utc_now",
]
