"""Graph persistence boundaries for local and Neo4j-backed execution."""
from __future__ import annotations

import json
import re
from collections import defaultdict
from collections.abc import Iterable, Mapping
from threading import RLock
from typing import Any, Protocol, runtime_checkable
from uuid import uuid4

from pydantic import BaseModel

from .graph_taxonomy import LOGICAL_GRAPH_RELATIONS
from .models import GraphEdge, GraphNode, GraphProjection

try:  # Neo4j is an optional production dependency.
    from neo4j import GraphDatabase
except ImportError:  # pragma: no cover - the absence is exercised through construction
    GraphDatabase = None  # type: ignore[assignment]


_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,63}$")

# Graph labels and relationship types cannot be Cypher parameters.  Every value
# interpolated into a query must therefore come from these audited mappings (or
# an explicitly supplied mapping that passes the same identifier validation).
DEFAULT_NEO4J_LABEL_MAP: dict[str, str] = {
    "Document": "M1Document",
    "Archive": "M1Archive",
    "Order": "M1Order",
    "Procurement": "M1Procurement",
    "Inventory": "M1Inventory",
    "Equipment": "M1Equipment",
    "Mold": "M1Mold",
    "TechnicalDocument": "M1TechnicalDocument",
    "CommercialDocument": "M1CommercialDocument",
    "OrderLine": "M1OrderLine",
    "InventoryLine": "M1InventoryLine",
    "EquipmentRecord": "M1EquipmentRecord",
    "MoldRecord": "M1MoldRecord",
    "DocumentLine": "M1DocumentLine",
    "Organization": "M1Organization",
    "Product": "M1Product",
    "Material": "M1Material",
}
DEFAULT_NEO4J_RELATION_MAP: dict[str, str] = {
    "ISSUED_BY": "M1_ISSUED_BY",
    "HAS_BUYER": "M1_HAS_BUYER",
    "HAS_SELLER": "M1_HAS_SELLER",
    "HAS_SUPPLIER": "M1_HAS_SUPPLIER",
    "HAS_LINE": "M1_HAS_LINE",
    "REFERS_TO_PRODUCT": "M1_REFERS_TO_PRODUCT",
    **{name: f"M1_{name}" for name in sorted(LOGICAL_GRAPH_RELATIONS)},
}


class Neo4jConfigurationError(RuntimeError):
    """Raised when a Neo4j sink cannot be configured safely."""


class Neo4jProjectionError(ValueError):
    """Raised before a transaction when projection invariants are invalid."""


@runtime_checkable
class GraphSink(Protocol):
    """A sink atomically replaces one source document's graph projection."""

    def replace_projection(self, projection: GraphProjection) -> None: ...

    def delete_projection(
        self,
        tenant_id: str,
        source_record_id: str,
        *,
        generation: int = 0,
    ) -> None: ...

    def health(self) -> dict[str, Any]: ...

    def close(self) -> None: ...


class InMemoryGraphSink:
    """Thread-safe reference sink used by tests and local execution.

    Projections are keyed by tenant and logical source rather than version.  A
    re-run therefore replaces stale nodes/edges instead of accumulating ghosts.
    """

    def __init__(self, projections: Iterable[GraphProjection] = ()) -> None:
        self._lock = RLock()
        self._projections: dict[tuple[str, str], GraphProjection] = {}
        self._generations: dict[tuple[str, str], int] = {}
        self._tombstoned: set[tuple[str, str]] = set()
        for projection in projections:
            self.replace_projection(projection)

    def replace_projection(self, projection: GraphProjection) -> None:
        parsed = (
            projection
            if isinstance(projection, GraphProjection)
            else GraphProjection.model_validate(projection)
        )
        with self._lock:
            key = (parsed.tenant_id, parsed.source_record_id)
            current = self._generations.get(key, -1)
            if parsed.generation < current or (
                parsed.generation == current and key in self._tombstoned
            ):
                return
            self._generations[key] = parsed.generation
            self._tombstoned.discard(key)
            self._projections[key] = parsed.model_copy(
                deep=True
            )

    def delete_projection(
        self,
        tenant_id: str,
        source_record_id: str,
        *,
        generation: int = 0,
    ) -> None:
        with self._lock:
            key = (tenant_id, source_record_id)
            current = self._generations.get(key, -1)
            if generation < current:
                return
            self._generations[key] = generation
            self._tombstoned.add(key)
            self._projections.pop(key, None)

    def get_projection(
        self, tenant_id: str, source_record_id: str
    ) -> GraphProjection | None:
        with self._lock:
            projection = self._projections.get((tenant_id, source_record_id))
            return projection.model_copy(deep=True) if projection else None

    @property
    def projections(self) -> tuple[GraphProjection, ...]:
        with self._lock:
            return tuple(
                projection.model_copy(deep=True)
                for _, projection in sorted(self._projections.items())
            )

    @property
    def nodes(self) -> dict[str, GraphNode]:
        with self._lock:
            return {
                node.node_id: node.model_copy(deep=True)
                for _, projection in sorted(self._projections.items())
                for node in projection.nodes
            }

    @property
    def edges(self) -> dict[str, GraphEdge]:
        with self._lock:
            return {
                edge.edge_id: edge.model_copy(deep=True)
                for _, projection in sorted(self._projections.items())
                for edge in projection.edges
            }

    def health(self) -> dict[str, Any]:
        return {"status": "ok", "backend": "memory", "projection_count": len(self.projections)}

    def close(self) -> None:
        """The in-memory sink owns no external resources."""


def _validated_mapping(
    defaults: Mapping[str, str], custom: Mapping[str, str] | None, kind: str
) -> dict[str, str]:
    output = dict(defaults)
    if custom:
        output.update(custom)
    for source_name, cypher_name in output.items():
        if not isinstance(source_name, str) or not _IDENTIFIER.fullmatch(source_name):
            raise Neo4jConfigurationError(f"invalid {kind} mapping key: {source_name!r}")
        if not isinstance(cypher_name, str) or not _IDENTIFIER.fullmatch(cypher_name):
            raise Neo4jConfigurationError(
                f"invalid Cypher {kind} identifier for {source_name!r}: {cypher_name!r}"
            )
    return output


def _jsonable(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_jsonable(item) for item in value]
    return value


def _json(value: Any) -> str:
    return json.dumps(
        _jsonable(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    )


def _string_list(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, (list, tuple, set, frozenset)):
        return list(dict.fromkeys(str(item) for item in value if item not in (None, "")))
    return [str(value)]


def _acl(properties: Mapping[str, Any]) -> dict[str, Any]:
    raw = properties.get("acl")
    acl = raw if isinstance(raw, Mapping) else {}
    visibility = (
        acl.get("visibility") or properties.get("acl_visibility") or "tenant"
    )
    roles = (
        acl.get("roles")
        or acl.get("allowed_roles")
        or acl.get("security_labels")
        or properties.get("acl_roles")
        or properties.get("allowed_roles")
    )
    principals = _string_list(
        acl.get("principals")
        or acl.get("allowed_principals")
        or acl.get("read_principals")
        or properties.get("acl_principals")
        or properties.get("allowed_principals")
    )
    owner = acl.get("owner_principal")
    if owner and str(owner) not in principals:
        principals.append(str(owner))
    return {
        "acl_visibility": str(visibility),
        "acl_roles": _string_list(roles),
        "acl_principals": principals,
    }


class Neo4jGraphSink:
    """Production property-graph sink using the official optional Neo4j driver.

    ``M1Entity`` is a fact-free canonical identity anchor.  Exact typed nodes,
    evidence and ACLs live in source-specific ``M1NodeDeclaration`` nodes, so
    updating one source cannot expose or erase another source's declaration of a
    shared product.  Projected relationships connect those declarations and are
    replaced by ``edge_id`` and source inside the same write transaction.
    """

    _CLEAN_RELATIONSHIPS = """
        MATCH (projection_lock:M1ProjectionLock {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id,
            operation_token: $operation_token
        })
        MATCH ()-[relationship]->()
        WHERE relationship.m1_managed = true
          AND relationship.tenant_id = $tenant_id
          AND relationship.source_record_id = $source_record_id
        DELETE relationship
    """
    _CLEAN_DECLARATIONS = """
        MATCH (projection_lock:M1ProjectionLock {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id,
            operation_token: $operation_token
        })
        MATCH (declaration:M1NodeDeclaration {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id
        })
        DETACH DELETE declaration
    """
    _REMOVE_SOURCE_MEMBERSHIP = """
        MATCH (projection_lock:M1ProjectionLock {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id,
            operation_token: $operation_token
        })
        MATCH (entity:M1Entity {tenant_id: $tenant_id})
        WHERE $source_record_id IN coalesce(entity.source_record_ids, [])
        SET entity.source_record_ids = [source_id IN entity.source_record_ids
                                        WHERE source_id <> $source_record_id]
    """
    _DELETE_ORPHAN_ENTITIES = """
        MATCH (projection_lock:M1ProjectionLock {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id,
            operation_token: $operation_token
        })
        MATCH (entity:M1Entity {tenant_id: $tenant_id})
        WHERE size(coalesce(entity.source_record_ids, [])) = 0
          AND NOT (entity)-[:M1_DECLARED_BY]->(:M1NodeDeclaration)
        DELETE entity
    """
    _LOCK_SOURCE = """
        MERGE (projection_lock:M1ProjectionLock {
            tenant_id: $tenant_id,
            source_record_id: $source_record_id
        })
        ON CREATE SET projection_lock.generation = -1,
                      projection_lock.tombstoned = false
        WITH projection_lock
        WHERE $generation > coalesce(projection_lock.generation, -1)
           OR ($generation = coalesce(projection_lock.generation, -1)
               AND (
                   $tombstoned = true
                   OR coalesce(projection_lock.tombstoned, false) = false
               ))
        SET projection_lock.version = $version,
            projection_lock.projection_id = $projection_id,
            projection_lock.operation_token = $operation_token,
            projection_lock.generation = $generation,
            projection_lock.tombstoned = $tombstoned
    """
    _SCHEMA_QUERIES = (
        """
        CREATE CONSTRAINT m1_entity_identity IF NOT EXISTS
        FOR (entity:M1Entity)
        REQUIRE (entity.tenant_id, entity.node_id) IS UNIQUE
        """,
        """
        CREATE CONSTRAINT m1_node_declaration_identity IF NOT EXISTS
        FOR (declaration:M1NodeDeclaration)
        REQUIRE (declaration.tenant_id, declaration.node_id,
                 declaration.source_record_id) IS UNIQUE
        """,
        """
        CREATE CONSTRAINT m1_projection_lock_identity IF NOT EXISTS
        FOR (projection_lock:M1ProjectionLock)
        REQUIRE (projection_lock.tenant_id,
                 projection_lock.source_record_id) IS UNIQUE
        """,
    )
    _SCHEMA_CONSTRAINT_NAMES = frozenset(
        {
            "m1_entity_identity",
            "m1_node_declaration_identity",
            "m1_projection_lock_identity",
        }
    )
    _SCHEMA_STATUS_QUERY = "SHOW CONSTRAINTS YIELD name RETURN name"

    def __init__(
        self,
        uri: str | None = None,
        *,
        auth: Any = None,
        database: str | None = None,
        driver: Any = None,
        driver_config: Mapping[str, Any] | None = None,
        label_map: Mapping[str, str] | None = None,
        relation_map: Mapping[str, str] | None = None,
        ensure_schema: bool = True,
    ) -> None:
        self._label_map = _validated_mapping(
            DEFAULT_NEO4J_LABEL_MAP, label_map, "label"
        )
        self._relation_map = _validated_mapping(
            DEFAULT_NEO4J_RELATION_MAP, relation_map, "relationship"
        )
        if driver is None:
            if GraphDatabase is None:
                raise Neo4jConfigurationError(
                    "Neo4j support requires the official `neo4j` Python package; "
                    "install `neo4j>=5` or inject a compatible driver"
                )
            if not uri:
                raise Neo4jConfigurationError("Neo4j `uri` is required when driver is not injected")
            driver = GraphDatabase.driver(uri, auth=auth, **dict(driver_config or {}))
        self._driver = driver
        self._database = database
        self._closed = False
        # Disabling this is only safe when operations has pre-created the exact
        # constraints in ``_SCHEMA_QUERIES``.  Without the lock-node uniqueness
        # constraint, cross-worker replacement cannot be linearized.
        self._auto_ensure_schema = ensure_schema
        self._schema_ready = False
        self._lock = RLock()

    def _ensure_open(self) -> None:
        if self._closed:
            raise Neo4jConfigurationError("Neo4j graph sink is closed")

    def _session(self) -> Any:
        self._ensure_open()
        return (
            self._driver.session(database=self._database)
            if self._database
            else self._driver.session()
        )

    @staticmethod
    def _consume(transaction: Any, query: str, **parameters: Any) -> None:
        result = transaction.run(query, **parameters)
        if hasattr(result, "consume"):
            result.consume()

    @staticmethod
    def _execute_write(session: Any, callback: Any) -> Any:
        if hasattr(session, "execute_write"):
            return session.execute_write(callback)
        if hasattr(session, "write_transaction"):  # Neo4j 4.x-compatible injected driver
            return session.write_transaction(callback)
        raise Neo4jConfigurationError("injected Neo4j session has no write transaction API")

    def ensure_schema(self) -> None:
        """Create the idempotent uniqueness constraints required for safe MERGE."""

        with self._lock:
            self._ensure_open()
            if self._schema_ready:
                return
            with self._session() as session:
                if not hasattr(session, "run"):
                    raise Neo4jConfigurationError(
                        "injected Neo4j session cannot execute schema statements"
                    )
                for query in self._SCHEMA_QUERIES:
                    result = session.run(query)
                    if hasattr(result, "consume"):
                        result.consume()
                self._schema_ready = self._required_constraints_exist(session)
            if not self._schema_ready:
                raise Neo4jConfigurationError(
                    "Neo4j is missing one or more required M1 constraints"
                )

    def _required_constraints_exist(self, session: Any) -> bool:
        result = session.run(self._SCHEMA_STATUS_QUERY)
        if not hasattr(result, "data"):
            raise Neo4jConfigurationError(
                "Neo4j constraint query returned an unsupported result"
            )
        rows = result.data()
        names = {str(row.get("name") or "") for row in rows if isinstance(row, Mapping)}
        return self._SCHEMA_CONSTRAINT_NAMES.issubset(names)

    def _refresh_schema_status(self) -> bool:
        with self._session() as session:
            self._schema_ready = self._required_constraints_exist(session)
        return self._schema_ready

    def _ensure_schema_if_configured(self) -> None:
        if self._auto_ensure_schema:
            self.ensure_schema()

    def initialize(self) -> None:
        """Prepare the authoritative graph contract before serving traffic."""

        self._ensure_schema_if_configured()
        if not self._schema_ready and not self._refresh_schema_status():
            raise Neo4jConfigurationError(
                "Neo4j is missing one or more required M1 constraints"
            )

    def _mapped_labels(self, labels: Iterable[str]) -> tuple[str, ...]:
        mapped: list[str] = []
        for label in labels:
            cypher_label = self._label_map.get(label)
            if cypher_label is None:
                raise Neo4jProjectionError(f"graph label is not whitelisted: {label!r}")
            if cypher_label not in mapped:
                mapped.append(cypher_label)
        if not mapped:
            raise Neo4jProjectionError("every graph node requires a whitelisted label")
        return tuple(sorted(mapped))

    def _mapped_relation(self, relation: str) -> str:
        mapped = self._relation_map.get(relation)
        if mapped is None:
            raise Neo4jProjectionError(
                f"graph relationship is not whitelisted: {relation!r}"
            )
        return mapped

    @staticmethod
    def _common_row(element: GraphNode | GraphEdge) -> dict[str, Any]:
        properties = element.properties if isinstance(element.properties, Mapping) else {}
        evidence = [reference.model_dump(mode="json") for reference in element.source_refs]
        return {
            "tenant_id": element.tenant_id,
            "source_record_id": element.source_record_id,
            "version": element.version,
            "status": element.status,
            "confidence": float(element.confidence),
            "evidence_json": _json(evidence),
            "source_claim_ids": list(element.source_claim_ids),
            "properties_json": _json(properties),
            **_acl(properties),
        }

    def _prepare(
        self, projection: GraphProjection
    ) -> tuple[GraphProjection, dict[tuple[str, ...], list[dict[str, Any]]], dict[str, list[dict[str, Any]]]]:
        parsed = (
            projection
            if isinstance(projection, GraphProjection)
            else GraphProjection.model_validate(projection)
        )
        if not parsed.tenant_id or not parsed.source_record_id or not parsed.version:
            raise Neo4jProjectionError("tenant_id, source_record_id and version are required")
        node_ids: set[str] = set()
        node_groups: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
        for node in parsed.nodes:
            if node.node_id in node_ids:
                raise Neo4jProjectionError(f"duplicate graph node_id: {node.node_id}")
            node_ids.add(node.node_id)
            if (
                node.tenant_id != parsed.tenant_id
                or node.source_record_id != parsed.source_record_id
                or node.version != parsed.version
            ):
                raise Neo4jProjectionError(
                    f"node {node.node_id!r} crosses projection tenant/source/version boundary"
                )
            labels = self._mapped_labels(node.labels)
            node_groups[labels].append(
                {"node_id": node.node_id, **self._common_row(node)}
            )

        edge_ids: set[str] = set()
        edge_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for edge in parsed.edges:
            if edge.edge_id in edge_ids:
                raise Neo4jProjectionError(f"duplicate graph edge_id: {edge.edge_id}")
            edge_ids.add(edge.edge_id)
            if edge.from_node not in node_ids or edge.to_node not in node_ids:
                raise Neo4jProjectionError(
                    f"edge {edge.edge_id!r} references a node outside this projection"
                )
            if (
                edge.tenant_id != parsed.tenant_id
                or edge.source_record_id != parsed.source_record_id
                or edge.version != parsed.version
            ):
                raise Neo4jProjectionError(
                    f"edge {edge.edge_id!r} crosses projection tenant/source/version boundary"
                )
            relation = self._mapped_relation(edge.relation)
            edge_groups[relation].append(
                {
                    "edge_id": edge.edge_id,
                    "from_node": edge.from_node,
                    "to_node": edge.to_node,
                    **self._common_row(edge),
                }
            )
        return parsed, dict(node_groups), dict(edge_groups)

    @staticmethod
    def _node_query(labels: tuple[str, ...]) -> str:
        safe_labels = ":".join(labels)
        return f"""
            MATCH (projection_lock:M1ProjectionLock {{
                tenant_id: $tenant_id,
                source_record_id: $source_record_id,
                operation_token: $operation_token
            }})
            UNWIND $rows AS row
            MERGE (entity:M1Entity {{tenant_id: row.tenant_id, node_id: row.node_id}})
            SET entity.source_record_ids = CASE
                    WHEN row.source_record_id IN coalesce(entity.source_record_ids, [])
                    THEN entity.source_record_ids
                    ELSE coalesce(entity.source_record_ids, []) + row.source_record_id
                END,
                entity.m1_identity_anchor = true
            MERGE (declaration:M1NodeDeclaration {{
                tenant_id: row.tenant_id,
                node_id: row.node_id,
                source_record_id: row.source_record_id
            }})
            SET declaration:{safe_labels}
            SET declaration.version = row.version,
                declaration.status = row.status,
                declaration.confidence = row.confidence,
                declaration.evidence_json = row.evidence_json,
                declaration.source_claim_ids = row.source_claim_ids,
                declaration.acl_visibility = row.acl_visibility,
                declaration.acl_roles = row.acl_roles,
                declaration.acl_principals = row.acl_principals,
                declaration.properties_json = row.properties_json
            MERGE (entity)-[declaration_link:M1_DECLARED_BY {{
                tenant_id: row.tenant_id,
                source_record_id: row.source_record_id
            }}]->(declaration)
            SET declaration_link.version = row.version,
                declaration_link.status = row.status,
                declaration_link.confidence = row.confidence,
                declaration_link.evidence_json = row.evidence_json,
                declaration_link.source_claim_ids = row.source_claim_ids,
                declaration_link.acl_visibility = row.acl_visibility,
                declaration_link.acl_roles = row.acl_roles,
                declaration_link.acl_principals = row.acl_principals
        """

    @staticmethod
    def _edge_query(relation: str) -> str:
        return f"""
            MATCH (projection_lock:M1ProjectionLock {{
                tenant_id: $tenant_id,
                source_record_id: $source_record_id,
                operation_token: $operation_token
            }})
            UNWIND $rows AS row
            MATCH (source:M1NodeDeclaration {{
                tenant_id: row.tenant_id,
                node_id: row.from_node,
                source_record_id: row.source_record_id
            }})
            MATCH (target:M1NodeDeclaration {{
                tenant_id: row.tenant_id,
                node_id: row.to_node,
                source_record_id: row.source_record_id
            }})
            MERGE (source)-[relationship:{relation} {{
                tenant_id: row.tenant_id,
                edge_id: row.edge_id,
                source_record_id: row.source_record_id
            }}]->(target)
            SET relationship.m1_managed = true,
                relationship.version = row.version,
                relationship.status = row.status,
                relationship.confidence = row.confidence,
                relationship.evidence_json = row.evidence_json,
                relationship.source_claim_ids = row.source_claim_ids,
                relationship.acl_visibility = row.acl_visibility,
                relationship.acl_roles = row.acl_roles,
                relationship.acl_principals = row.acl_principals,
                relationship.properties_json = row.properties_json
        """

    def _clean_source(self, transaction: Any, parameters: dict[str, Any]) -> None:
        self._consume(transaction, self._CLEAN_RELATIONSHIPS, **parameters)
        self._consume(transaction, self._CLEAN_DECLARATIONS, **parameters)
        self._consume(transaction, self._REMOVE_SOURCE_MEMBERSHIP, **parameters)
        self._consume(transaction, self._DELETE_ORPHAN_ENTITIES, **parameters)

    def replace_projection(self, projection: GraphProjection) -> None:
        parsed, node_groups, edge_groups = self._prepare(projection)
        parameters = {
            "tenant_id": parsed.tenant_id,
            "source_record_id": parsed.source_record_id,
            "version": parsed.version,
            "projection_id": parsed.projection_id,
            "operation_token": uuid4().hex,
            "generation": parsed.generation,
            "tombstoned": False,
        }

        def write(transaction: Any) -> None:
            # The constrained sentinel serializes replace/delete calls for the
            # same tenant+source across workers and processes.  At an equal
            # generation a delete wins over an active projection, while a
            # replace cannot resurrect an equal-generation tombstone.  This is
            # the same ordering implemented by InMemoryGraphSink.
            self._consume(transaction, self._LOCK_SOURCE, **parameters)
            self._clean_source(transaction, parameters)
            for labels, rows in sorted(node_groups.items()):
                self._consume(
                    transaction,
                    self._node_query(labels),
                    rows=rows,
                    **parameters,
                )
            for relation, rows in sorted(edge_groups.items()):
                self._consume(
                    transaction,
                    self._edge_query(relation),
                    rows=rows,
                    **parameters,
                )

        self._ensure_schema_if_configured()
        with self._lock, self._session() as session:
            self._execute_write(session, write)

    def delete_projection(
        self,
        tenant_id: str,
        source_record_id: str,
        *,
        generation: int = 0,
    ) -> None:
        if not tenant_id or not source_record_id:
            raise Neo4jProjectionError("tenant_id and source_record_id are required")
        parameters = {
            "tenant_id": tenant_id,
            "source_record_id": source_record_id,
            "version": "",
            "projection_id": "",
            "operation_token": uuid4().hex,
            "generation": generation,
            "tombstoned": True,
        }

        def write(transaction: Any) -> None:
            self._consume(transaction, self._LOCK_SOURCE, **parameters)
            self._clean_source(transaction, parameters)

        self._ensure_schema_if_configured()
        with self._lock, self._session() as session:
            self._execute_write(session, write)

    def health(self) -> dict[str, Any]:
        with self._lock:
            self._ensure_open()
            self._ensure_schema_if_configured()
            self._driver.verify_connectivity()
            schema_initialized = self._refresh_schema_status()
            return {
                "status": "ok" if schema_initialized else "error",
                "backend": "neo4j",
                "database": self._database,
                "schema_initialized": schema_initialized,
            }

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._driver.close()
            self._closed = True


__all__ = [
    "DEFAULT_NEO4J_LABEL_MAP",
    "DEFAULT_NEO4J_RELATION_MAP",
    "GraphSink",
    "InMemoryGraphSink",
    "Neo4jConfigurationError",
    "Neo4jGraphSink",
    "Neo4jProjectionError",
]
