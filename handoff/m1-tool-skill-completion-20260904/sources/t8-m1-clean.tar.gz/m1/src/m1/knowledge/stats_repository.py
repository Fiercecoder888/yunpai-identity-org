"""Behavior-preserving repository mixin extracted from persistence."""

from __future__ import annotations

from collections.abc import Iterable
import unicodedata
from typing import Any, TypeVar

from sqlalchemy import (
    func,
    or_,
    select,
)

from .db_models import (
    CanonicalEntityRow,
    DocumentVersionRow,
    EntityAliasRow,
    ExternalIdentityRow,
    FieldClaimRow,
    GraphProjectionSnapshotRow,
    IngestionBatchRow,
    KnowledgeChunkRow,
    KnowledgeDocumentRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    SourceAssetRow,
    SourceOccurrenceRow,
    TaskVersionBindingRow,
)
from .schema import (
    KnowledgeSearchResult,
)

T = TypeVar("T")


class KnowledgeStatsMixin:
    async def projection_stats(
        self,
        tenant_id: str,
        *,
        source_record_id: str | None = None,
        version: str | None = None,
    ) -> dict[str, Any]:
        def scope(statement, row_type):  # noqa: ANN001
            statement = statement.where(row_type.tenant_id == tenant_id)
            if source_record_id is not None:
                statement = statement.where(
                    row_type.source_record_id == source_record_id
                )
            if version is not None:
                statement = statement.where(row_type.version == version)
            return statement

        async with self.sessionmaker() as session:
            output: dict[str, Any] = {}
            for name, row_type, id_column in (
                ("chunks", KnowledgeChunkRow, KnowledgeChunkRow.chunk_id),
                ("index_documents", KnowledgeIndexRow, KnowledgeIndexRow.index_id),
                (
                    "graph_snapshots",
                    GraphProjectionSnapshotRow,
                    GraphProjectionSnapshotRow.projection_id,
                ),
            ):
                rows = (
                    await session.execute(
                        scope(
                            select(row_type.status, func.count(id_column)).group_by(
                                row_type.status
                            ),
                            row_type,
                        )
                    )
                ).all()
                by_status = {status: int(count) for status, count in rows}
                output[name] = {
                    "total": sum(by_status.values()),
                    "by_status": by_status,
                }
            outbox_rows = (
                await session.execute(
                    select(
                        ProjectionOutboxRow.projection_name,
                        ProjectionOutboxRow.status,
                        func.count(ProjectionOutboxRow.event_id),
                    )
                    .where(
                        ProjectionOutboxRow.tenant_id == tenant_id,
                        ProjectionOutboxRow.aggregate_type == "document_projection",
                    )
                    .group_by(
                        ProjectionOutboxRow.projection_name, ProjectionOutboxRow.status
                    )
                )
            ).all()
            output["outbox"] = {
                f"{projection}:{status}": int(count)
                for projection, status, count in outbox_rows
            }
            return output

    async def inventory_stats(self, tenant_id: str) -> dict[str, Any]:
        """Return tenant-scoped, operator-safe knowledge inventory counts.

        The projection counters above intentionally retain their historical
        document-projection-only outbox view for API compatibility.  A corpus
        acceptance run also needs to prove source/version bindings and account
        for relationship events, so this method exposes aggregate counts only;
        it never returns source filenames, payloads, claims, or ACL contents.
        """

        async with self.sessionmaker() as session:

            async def grouped(
                row_type: type[Any],
                id_column: Any,
                status_column: Any | None = None,
            ) -> dict[str, Any]:
                total = await session.scalar(
                    select(func.count(id_column)).where(row_type.tenant_id == tenant_id)
                )
                result: dict[str, Any] = {"total": int(total or 0)}
                if status_column is not None:
                    rows = (
                        await session.execute(
                            select(status_column, func.count(id_column))
                            .where(row_type.tenant_id == tenant_id)
                            .group_by(status_column)
                        )
                    ).all()
                    result["by_status"] = {
                        str(status): int(count) for status, count in rows
                    }
                return result

            output = {
                "ingestion_batches": await grouped(
                    IngestionBatchRow,
                    IngestionBatchRow.batch_id,
                    IngestionBatchRow.status,
                ),
                "source_assets": await grouped(
                    SourceAssetRow,
                    SourceAssetRow.asset_id,
                    SourceAssetRow.lifecycle_status,
                ),
                "source_occurrences": await grouped(
                    SourceOccurrenceRow,
                    SourceOccurrenceRow.occurrence_id,
                ),
                "documents": await grouped(
                    KnowledgeDocumentRow,
                    KnowledgeDocumentRow.document_id,
                    KnowledgeDocumentRow.lifecycle_status,
                ),
                "document_versions": await grouped(
                    DocumentVersionRow,
                    DocumentVersionRow.version_id,
                    DocumentVersionRow.lifecycle_status,
                ),
                "task_version_bindings": await grouped(
                    TaskVersionBindingRow,
                    TaskVersionBindingRow.binding_id,
                    TaskVersionBindingRow.status,
                ),
                "canonical_entities": await grouped(
                    CanonicalEntityRow,
                    CanonicalEntityRow.entity_id,
                    CanonicalEntityRow.lifecycle_status,
                ),
                "external_identities": await grouped(
                    ExternalIdentityRow,
                    ExternalIdentityRow.identity_id,
                    ExternalIdentityRow.status,
                ),
                "entity_aliases": await grouped(
                    EntityAliasRow,
                    EntityAliasRow.alias_id,
                    EntityAliasRow.status,
                ),
                "projection_outbox": await grouped(
                    ProjectionOutboxRow,
                    ProjectionOutboxRow.event_id,
                    ProjectionOutboxRow.status,
                ),
            }
            outbox_rows = (
                await session.execute(
                    select(
                        ProjectionOutboxRow.projection_name,
                        ProjectionOutboxRow.aggregate_type,
                        ProjectionOutboxRow.status,
                        func.count(ProjectionOutboxRow.event_id),
                    )
                    .where(ProjectionOutboxRow.tenant_id == tenant_id)
                    .group_by(
                        ProjectionOutboxRow.projection_name,
                        ProjectionOutboxRow.aggregate_type,
                        ProjectionOutboxRow.status,
                    )
                )
            ).all()
            output["projection_outbox"]["by_projection_aggregate_status"] = {
                f"{projection}:{aggregate}:{status}": int(count)
                for projection, aggregate, status, count in outbox_rows
            }
            return output

    async def search_records(
        self,
        tenant_id: str,
        query: str,
        *,
        record_types: Iterable[str] | None = None,
        limit: int = 50,
    ) -> list[KnowledgeSearchResult]:
        """Portable baseline search; production BM25/vector remain projections."""

        query = unicodedata.normalize("NFKC", query).strip()
        if not query:
            return []
        limit = max(1, min(limit, 200))
        requested = set(
            record_types
            or {
                "canonical_entity",
                "document",
                "field_claim",
                "alias",
                "external_identity",
            }
        )
        pattern = f"%{query.casefold()}%"
        results: list[KnowledgeSearchResult] = []
        async with self.sessionmaker() as session:
            if "canonical_entity" in requested:
                rows = (
                    await session.scalars(
                        select(CanonicalEntityRow)
                        .where(
                            CanonicalEntityRow.tenant_id == tenant_id,
                            or_(
                                func.lower(CanonicalEntityRow.canonical_label).like(
                                    pattern
                                ),
                                func.lower(CanonicalEntityRow.canonical_key).like(
                                    pattern
                                ),
                            ),
                        )
                        .limit(limit)
                    )
                ).all()
                results.extend(
                    KnowledgeSearchResult(
                        record_type="canonical_entity",
                        record_id=row.entity_id,
                        label=row.canonical_label,
                        highlights={
                            "entity_type": row.entity_type,
                            "canonical_key": row.canonical_key,
                        },
                    )
                    for row in rows
                )
            if "document" in requested and len(results) < limit:
                rows = (
                    await session.scalars(
                        select(KnowledgeDocumentRow)
                        .where(
                            KnowledgeDocumentRow.tenant_id == tenant_id,
                            or_(
                                func.lower(KnowledgeDocumentRow.title).like(pattern),
                                func.lower(KnowledgeDocumentRow.canonical_key).like(
                                    pattern
                                ),
                            ),
                        )
                        .limit(limit - len(results))
                    )
                ).all()
                results.extend(
                    KnowledgeSearchResult(
                        record_type="document",
                        record_id=row.document_id,
                        label=row.title or row.canonical_key,
                        highlights={
                            "document_type": row.document_type,
                            "canonical_key": row.canonical_key,
                        },
                    )
                    for row in rows
                )
            if "field_claim" in requested and len(results) < limit:
                rows = (
                    await session.scalars(
                        select(FieldClaimRow)
                        .where(
                            FieldClaimRow.tenant_id == tenant_id,
                            func.lower(FieldClaimRow.normalized_text).like(pattern),
                        )
                        .limit(limit - len(results))
                    )
                ).all()
                results.extend(
                    KnowledgeSearchResult(
                        record_type="field_claim",
                        record_id=row.claim_id,
                        label=f"{row.field_path}: {row.normalized_text[:160]}",
                        highlights={
                            "subject_type": row.subject_type,
                            "subject_id": row.subject_id,
                        },
                    )
                    for row in rows
                )
            if "alias" in requested and len(results) < limit:
                rows = (
                    await session.scalars(
                        select(EntityAliasRow)
                        .where(
                            EntityAliasRow.tenant_id == tenant_id,
                            func.lower(EntityAliasRow.normalized_alias).like(pattern),
                        )
                        .limit(limit - len(results))
                    )
                ).all()
                results.extend(
                    KnowledgeSearchResult(
                        record_type="alias",
                        record_id=row.alias_id,
                        label=row.alias,
                        highlights={"entity_id": row.entity_id},
                    )
                    for row in rows
                )
            if "external_identity" in requested and len(results) < limit:
                rows = (
                    await session.scalars(
                        select(ExternalIdentityRow)
                        .where(
                            ExternalIdentityRow.tenant_id == tenant_id,
                            func.lower(ExternalIdentityRow.external_id).like(pattern),
                        )
                        .limit(limit - len(results))
                    )
                ).all()
                results.extend(
                    KnowledgeSearchResult(
                        record_type="external_identity",
                        record_id=row.identity_id,
                        label=row.external_id,
                        highlights={
                            "entity_id": row.entity_id,
                            "source_system": row.source_system,
                        },
                    )
                    for row in rows
                )
        return results[:limit]
