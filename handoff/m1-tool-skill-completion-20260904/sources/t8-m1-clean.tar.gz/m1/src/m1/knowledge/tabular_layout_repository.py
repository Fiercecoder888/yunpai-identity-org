"""Tenant-safe persistence for reusable, evidence-validated table layouts."""

from __future__ import annotations

import math
from collections.abc import Iterable, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutCandidateProposal,
    TabularLayoutExecutionObservation,
)
from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutProfile as RuntimeTabularLayoutProfile,
)

from .db_models import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    TabularLayoutObservationRow,
    TabularLayoutProfileRow,
    TenantBoundaryError,
    TenantRow,
)
from .persistence_helpers import _aware, _canonical_json, _enum
from .schema import utc_now
from .tabular_layout_schema import (
    TabularLayoutObservationOutcome,
    TabularLayoutObservationRecord,
    TabularLayoutObservationSummary,
    TabularLayoutProfileMatch,
    TabularLayoutProfileRecord,
    TabularLayoutProfileStatus,
    TabularLayoutSignature,
)


def _profile_record(row: TabularLayoutProfileRow) -> TabularLayoutProfileRecord:
    return TabularLayoutProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        exact_fingerprint=row.exact_fingerprint,
        signature=TabularLayoutSignature.model_validate(
            row.signature_json, strict=False
        ),
        plan=row.plan_json,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_reason_codes=tuple(row.review_reason_codes_json or ()),
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at),
        updated_at=_aware(row.updated_at),
    )


def _observation_record(
    row: TabularLayoutObservationRow,
) -> TabularLayoutObservationRecord:
    return TabularLayoutObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        outcome=row.outcome,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        summary=TabularLayoutObservationSummary.model_validate(row.summary_json),
        observed_at=_aware(row.observed_at),
    )


def _same_profile_definition(
    row: TabularLayoutProfileRow, record: TabularLayoutProfileRecord
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and _canonical_json(row.signature_json)
        == _canonical_json(record.signature.model_dump(mode="json"))
        and _canonical_json(row.plan_json) == _canonical_json(record.plan)
        and row.contract_revision == record.signature.contract_revision
        and row.interpreter_revision == record.signature.interpreter_revision
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
        and row.created_by == record.created_by
    )


def _same_observation(
    row: TabularLayoutObservationRow, record: TabularLayoutObservationRecord
) -> bool:
    return (
        row.profile_id == record.profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and row.outcome == _enum(record.outcome)
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
        and _canonical_json(row.summary_json)
        == _canonical_json(record.summary.model_dump(mode="json"))
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    return second if normalized is None or second > normalized else normalized


def _validate_fingerprint(value: str) -> str:
    normalized = value.strip().lower()
    if len(normalized) != 64:
        raise ValueError(
            "tabular layout fingerprint must contain 64 hexadecimal characters"
        )
    try:
        int(normalized, 16)
    except ValueError as exc:
        raise ValueError(
            "tabular layout fingerprint must contain 64 hexadecimal characters"
        ) from exc
    return normalized


class KnowledgeTabularLayoutProfileMixin:
    """Persistence facade; profile activation is always explicit and reviewed."""

    async def _lock_tabular_layout_tenant(
        self, session: AsyncSession, tenant_id: str
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_tabular_layout_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> TabularLayoutProfileRow:
        statement = select(TabularLayoutProfileRow).where(
            TabularLayoutProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tabular layout profile not found: {profile_id}")
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_tabular_layout_profile(
        self, record: TabularLayoutProfileRecord
    ) -> TabularLayoutProfileRecord:
        """Persist one pre-validated candidate, idempotently by key/version."""

        if record.status is not TabularLayoutProfileStatus.CANDIDATE:
            raise ValueError("new tabular layout profiles must start as candidate")

        async def operation(session: AsyncSession) -> TabularLayoutProfileRecord:
            await self._lock_tabular_layout_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(TabularLayoutProfileRow).where(
                        TabularLayoutProfileRow.tenant_id == record.tenant_id,
                        or_(
                            TabularLayoutProfileRow.profile_id == record.profile_id,
                            (
                                (
                                    TabularLayoutProfileRow.profile_key
                                    == record.profile_key
                                )
                                & (TabularLayoutProfileRow.version == record.version)
                            ),
                            (
                                (
                                    TabularLayoutProfileRow.exact_fingerprint
                                    == record.exact_fingerprint
                                )
                                & (TabularLayoutProfileRow.version == record.version)
                            ),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if row.profile_key == record.profile_key
                        and row.version == record.version
                    ),
                    None,
                )
                if existing is not None and _same_profile_definition(existing, record):
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"tabular-layout-profile:{record.profile_key}:{record.version}"
                )

            predecessor: TabularLayoutProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_tabular_layout_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError("tabular layout revision changes its profile key")
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("tabular layout revision changes its fingerprint")
                if predecessor.contract_revision != record.signature.contract_revision:
                    raise ValueError("tabular layout revision changes its contract")
                if (
                    predecessor.interpreter_revision
                    != record.signature.interpreter_revision
                ):
                    raise ValueError("tabular layout revision changes its interpreter")
                if record.version != predecessor.version + 1:
                    raise ValueError("tabular layout revisions must be consecutive")
                if predecessor.status == TabularLayoutProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active tabular layout profile must be deprecated before revision"
                    )

            row = TabularLayoutProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                exact_fingerprint=record.exact_fingerprint,
                signature_json=record.signature.model_dump(mode="json"),
                plan_json=record.plan,
                contract_revision=record.signature.contract_revision,
                interpreter_revision=record.signature.interpreter_revision,
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=record.embedding_dimensions,
                created_by=record.created_by,
                reviewed_by=record.reviewed_by,
                reviewed_at=record.reviewed_at,
                review_reason_codes_json=list(record.review_reason_codes),
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == TabularLayoutProfileStatus.CANDIDATE.value
            ):
                predecessor.status = TabularLayoutProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at, record.created_at
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def create_tabular_layout_candidate(
        self, record: TabularLayoutCandidateProposal
    ) -> RuntimeTabularLayoutProfile:
        """Materialize a parser proposal as an inactive, versioned candidate."""

        candidate = record
        profile = TabularLayoutProfileRecord(
            tenant_id=candidate.tenant_id,
            profile_key=candidate.profile_key,
            version=1,
            exact_fingerprint=candidate.signature.exact_fingerprint(),
            signature=candidate.signature,
            plan=candidate.plan,
            embedding=(
                list(candidate.embedding) if candidate.embedding is not None else None
            ),
            embedding_model=candidate.embedding_model,
            embedding_dimensions=candidate.embedding_dimensions,
            created_by="tabular-layout-router",
        )
        try:
            return (
                await self.create_tabular_layout_profile(profile)
            ).as_runtime_profile()
        except IdempotencyConflictError:
            # ``observe_candidate`` can be replayed after a worker restart.
            # The proposal has no caller-owned profile ID, so a matching stored
            # candidate is the idempotent result even when its creator differs.
            existing_profiles = await self.list_tabular_layout_profiles(
                candidate.tenant_id,
                profile_key=candidate.profile_key,
                contract_revision=candidate.signature.contract_revision,
                interpreter_revision=candidate.signature.interpreter_revision,
            )
            for existing in existing_profiles:
                if (
                    existing.status is not TabularLayoutProfileStatus.REJECTED
                    and existing.exact_fingerprint
                    == candidate.signature.exact_fingerprint()
                    and _canonical_json(existing.plan) == _canonical_json(profile.plan)
                ):
                    return existing.as_runtime_profile()
            raise

    async def get_tabular_layout_profile(
        self, tenant_id: str, profile_id: str
    ) -> TabularLayoutProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(TabularLayoutProfileRow).where(
                    TabularLayoutProfileRow.tenant_id == tenant_id,
                    TabularLayoutProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def list_tabular_layout_profiles(
        self,
        tenant_id: str,
        *,
        status: TabularLayoutProfileStatus | str | None = None,
        profile_key: str | None = None,
        contract_revision: str | None = None,
        interpreter_revision: str | None = None,
        limit: int = 200,
    ) -> list[TabularLayoutProfileRecord]:
        if limit < 1:
            return []
        statement = select(TabularLayoutProfileRow).where(
            TabularLayoutProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            statement = statement.where(
                TabularLayoutProfileRow.status
                == TabularLayoutProfileStatus(_enum(status)).value
            )
        if profile_key is not None:
            statement = statement.where(
                TabularLayoutProfileRow.profile_key == profile_key.strip().casefold()
            )
        if contract_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        if interpreter_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.interpreter_revision
                == interpreter_revision.strip().casefold()
            )
        statement = statement.order_by(
            TabularLayoutProfileRow.profile_key,
            TabularLayoutProfileRow.version.desc(),
            TabularLayoutProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def get_active_tabular_layout_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str | None = None,
        interpreter_revision: str | None = None,
    ) -> RuntimeTabularLayoutProfile | None:
        fingerprint = _validate_fingerprint(exact_fingerprint)
        statement = select(TabularLayoutProfileRow).where(
            TabularLayoutProfileRow.tenant_id == tenant_id,
            TabularLayoutProfileRow.exact_fingerprint == fingerprint,
            TabularLayoutProfileRow.status == TabularLayoutProfileStatus.ACTIVE.value,
        )
        if contract_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        if interpreter_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.interpreter_revision
                == interpreter_revision.strip().casefold()
            )
        async with self.sessionmaker() as session:
            row = await session.scalar(
                statement.order_by(
                    TabularLayoutProfileRow.version.desc(),
                    TabularLayoutProfileRow.profile_id,
                )
            )
            return _profile_record(row).as_runtime_profile() if row else None

    async def get_latest_tabular_layout_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
    ) -> TabularLayoutProfileRecord | None:
        fingerprint = _validate_fingerprint(exact_fingerprint)
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(TabularLayoutProfileRow)
                .where(
                    TabularLayoutProfileRow.tenant_id == tenant_id,
                    TabularLayoutProfileRow.exact_fingerprint == fingerprint,
                )
                .order_by(
                    TabularLayoutProfileRow.version.desc(),
                    TabularLayoutProfileRow.profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def find_tabular_layout_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses: Iterable[TabularLayoutProfileStatus | str] = (
            TabularLayoutProfileStatus.ACTIVE,
        ),
        contract_revision: str | None = None,
        interpreter_revision: str | None = None,
        min_similarity: float = 0.0,
        limit: int = 5,
    ) -> list[TabularLayoutProfileMatch]:
        if limit < 1:
            return []
        normalized_model = embedding_model.strip()
        if not normalized_model:
            raise ValueError("tabular layout embedding model identity is required")
        normalized_dimensions = int(embedding_dimensions)
        if normalized_dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "tabular layout embedding identity dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, "
                f"received {normalized_dimensions}"
            )
        normalized = [float(value) for value in embedding]
        if len(normalized) != normalized_dimensions:
            raise ValueError(
                "tabular layout embedding dimension mismatch: "
                f"expected {normalized_dimensions}, received {len(normalized)}"
            )
        if not all(math.isfinite(value) for value in normalized):
            raise ValueError("tabular layout embedding contains non-finite values")
        if not math.isfinite(min_similarity) or not -1.0 <= min_similarity <= 1.0:
            raise ValueError("min_similarity must be a finite value in [-1, 1]")
        accepted = {
            TabularLayoutProfileStatus(_enum(status)).value for status in statuses
        }
        if not accepted:
            return []

        statement = select(TabularLayoutProfileRow).where(
            TabularLayoutProfileRow.tenant_id == tenant_id,
            TabularLayoutProfileRow.status.in_(sorted(accepted)),
            TabularLayoutProfileRow.embedding.is_not(None),
            TabularLayoutProfileRow.embedding_model == normalized_model,
            TabularLayoutProfileRow.embedding_dimensions == normalized_dimensions,
        )
        if contract_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.contract_revision
                == contract_revision.strip().casefold()
            )
        if interpreter_revision is not None:
            statement = statement.where(
                TabularLayoutProfileRow.interpreter_revision
                == interpreter_revision.strip().casefold()
            )
        is_postgres = self.engine.url.get_backend_name() == "postgresql"
        async with self.sessionmaker() as session:
            if is_postgres:
                distance = TabularLayoutProfileRow.embedding.cosine_distance(normalized)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .where((1.0 - distance) >= min_similarity)
                        .order_by(distance, TabularLayoutProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    TabularLayoutProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=max(0.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]
            rows = (
                await session.scalars(
                    statement.order_by(
                        TabularLayoutProfileRow.updated_at.desc(),
                        TabularLayoutProfileRow.profile_id,
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in normalized))
        matches: list[TabularLayoutProfileMatch] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(
                    left * right for left, right in zip(normalized, stored, strict=True)
                )
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(-1.0, min(1.0, similarity))
            if similarity >= min_similarity:
                matches.append(
                    TabularLayoutProfileMatch(
                        profile=_profile_record(row).as_runtime_profile(),
                        vector_similarity=max(0.0, similarity),
                    )
                )
        return sorted(
            matches,
            key=lambda item: (-item.vector_similarity, item.profile.profile_id),
        )[: min(limit, 100)]

    async def find_active_tabular_layout_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str | None = None,
        interpreter_revision: str | None = None,
        limit: int = 5,
    ) -> list[TabularLayoutProfileMatch]:
        return await self.find_tabular_layout_profiles(
            tenant_id,
            embedding,
            embedding_model=embedding_model,
            embedding_dimensions=embedding_dimensions,
            statuses=(TabularLayoutProfileStatus.ACTIVE,),
            contract_revision=contract_revision,
            interpreter_revision=interpreter_revision,
            limit=limit,
        )

    async def activate_tabular_layout_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        expected_observation_count: int,
        reviewed_by: str | None = None,
        review_reason_codes: Sequence[str] = (),
        approved_at: datetime | None = None,
    ) -> TabularLayoutProfileRecord:
        actor = approved_by.strip()
        if not actor:
            raise ValueError("approved_by is required")
        if expected_observation_count < 3:
            raise ValueError(
                "at least three successful observations from different tasks are required"
            )
        reason_codes = tuple(
            str(item).strip().casefold() for item in review_reason_codes
        )
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> TabularLayoutProfileRecord:
            await self._lock_tabular_layout_tenant(session, tenant_id)
            row = await self._require_tabular_layout_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == TabularLayoutProfileStatus.ACTIVE.value:
                if (
                    row.observation_count != expected_observation_count
                    or row.failure_count != 0
                ):
                    raise IdempotencyConflictError(
                        f"tabular-layout-approval-observations:{tenant_id}:{profile_id}"
                    )
                await self._assert_tabular_layout_activation_observations(
                    session, tenant_id, profile_id
                )
                return _profile_record(row)
            if row.status != TabularLayoutProfileStatus.CANDIDATE.value:
                raise ValueError(
                    "only candidate tabular layout profiles may be activated"
                )
            if row.observation_count != expected_observation_count:
                raise IdempotencyConflictError(
                    f"tabular-layout-approval-observations:{tenant_id}:{profile_id}"
                )
            if row.failure_count != 0 or row.success_count != row.observation_count:
                raise IdempotencyConflictError(
                    f"tabular-layout-approval-failures:{tenant_id}:{profile_id}"
                )
            await self._assert_tabular_layout_activation_observations(
                session, tenant_id, profile_id
            )

            statement = select(TabularLayoutProfileRow).where(
                TabularLayoutProfileRow.tenant_id == tenant_id,
                TabularLayoutProfileRow.profile_id != profile_id,
                TabularLayoutProfileRow.status
                == TabularLayoutProfileStatus.ACTIVE.value,
                or_(
                    TabularLayoutProfileRow.profile_key == row.profile_key,
                    TabularLayoutProfileRow.exact_fingerprint == row.exact_fingerprint,
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = TabularLayoutProfileStatus.DEPRECATED.value
                previous.updated_at = now

            row.status = TabularLayoutProfileStatus.ACTIVE.value
            row.reviewed_by = (reviewed_by or row.reviewed_by or actor).strip()
            row.reviewed_at = row.reviewed_at or now
            row.review_reason_codes_json = list(
                reason_codes or row.review_reason_codes_json
            )
            row.approved_by = actor
            row.approved_at = now
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def _assert_tabular_layout_activation_observations(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
    ) -> None:
        """Require three distinct successful task hashes with applied plans."""

        rows = (
            await session.scalars(
                select(TabularLayoutObservationRow).where(
                    TabularLayoutObservationRow.tenant_id == tenant_id,
                    TabularLayoutObservationRow.profile_id == profile_id,
                )
            )
        ).all()
        task_hashes: set[str] = set()
        for row in rows:
            if row.outcome != TabularLayoutObservationOutcome.SUCCESS.value:
                continue
            summary = row.summary_json if isinstance(row.summary_json, dict) else {}
            task_hash = str(summary.get("task_reference_hash") or "")
            if (
                len(task_hash) == 64
                and summary.get("applied") is True
                and summary.get("validation_passed") is True
            ):
                task_hashes.add(task_hash)
        if len(task_hashes) < 3:
            raise IdempotencyConflictError(
                f"tabular-layout-approval-distinct-tasks:{tenant_id}:{profile_id}"
            )

    async def record_tabular_layout_execution_observation(
        self, observation: TabularLayoutExecutionObservation
    ) -> TabularLayoutObservationRecord:
        """Adapt parser-side telemetry to the governed knowledge record."""

        key = (
            f"tabular-layout:{observation.profile_id}:{observation.task_reference_hash}"
        )
        record = TabularLayoutObservationRecord(
            tenant_id=observation.tenant_id,
            profile_id=observation.profile_id,
            idempotency_key=key,
            exact_fingerprint=observation.exact_fingerprint,
            outcome=TabularLayoutObservationOutcome(observation.outcome),
            latency_ms=observation.latency_ms,
            error_code=observation.error_code,
            summary=TabularLayoutObservationSummary(
                parser_revision=observation.parser_revision,
                applied=observation.applied,
                validation_passed=observation.validation_passed,
                mapped_field_count=observation.mapped_field_count,
                mapped_record_count=observation.mapped_record_count,
                issue_codes=observation.issue_codes,
                task_reference_hash=observation.task_reference_hash,
            ),
        )
        return await self.record_tabular_layout_observation(record)

    async def reject_tabular_layout_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_reason_codes: Sequence[str] = (),
        reviewed_at: datetime | None = None,
    ) -> TabularLayoutProfileRecord:
        actor = reviewed_by.strip()
        if not actor:
            raise ValueError("reviewed_by is required")
        reason_codes = tuple(
            str(item).strip().casefold() for item in review_reason_codes
        )
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> TabularLayoutProfileRecord:
            await self._lock_tabular_layout_tenant(session, tenant_id)
            row = await self._require_tabular_layout_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == TabularLayoutProfileStatus.REJECTED.value:
                return _profile_record(row)
            if row.status != TabularLayoutProfileStatus.CANDIDATE.value:
                raise ValueError(
                    "only candidate tabular layout profiles may be rejected"
                )
            row.status = TabularLayoutProfileStatus.REJECTED.value
            row.reviewed_by = actor
            row.reviewed_at = now
            row.review_reason_codes_json = list(reason_codes)
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def deprecate_tabular_layout_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str | None = None,
        review_reason_codes: Sequence[str] = (),
        reviewed_at: datetime | None = None,
    ) -> TabularLayoutProfileRecord:
        now = _aware(reviewed_at) or utc_now()
        reason_codes = tuple(
            str(item).strip().casefold() for item in review_reason_codes
        )

        async def operation(session: AsyncSession) -> TabularLayoutProfileRecord:
            await self._lock_tabular_layout_tenant(session, tenant_id)
            row = await self._require_tabular_layout_profile(
                session, tenant_id, profile_id, for_update=True
            )
            if row.status == TabularLayoutProfileStatus.DEPRECATED.value:
                return _profile_record(row)
            if row.status == TabularLayoutProfileStatus.REJECTED.value:
                raise ValueError(
                    "a rejected tabular layout profile cannot be deprecated"
                )
            row.status = TabularLayoutProfileStatus.DEPRECATED.value
            if reviewed_by:
                row.reviewed_by = reviewed_by.strip()
                row.reviewed_at = now
            if reason_codes:
                row.review_reason_codes_json = list(reason_codes)
            row.updated_at = now
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def record_tabular_layout_observation(
        self, record: TabularLayoutObservationRecord
    ) -> TabularLayoutObservationRecord:
        """Record one idempotent outcome and update profile counters atomically."""

        async def operation(session: AsyncSession) -> TabularLayoutObservationRecord:
            await self._lock_tabular_layout_tenant(session, record.tenant_id)
            profile = await self._require_tabular_layout_profile(
                session, record.tenant_id, record.profile_id, for_update=True
            )
            existing = await session.scalar(
                select(TabularLayoutObservationRow).where(
                    TabularLayoutObservationRow.tenant_id == record.tenant_id,
                    TabularLayoutObservationRow.idempotency_key
                    == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError(
                    "observation fingerprint does not match tabular layout profile"
                )

            row = TabularLayoutObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                outcome=record.outcome.value,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                summary_json=record.summary.model_dump(mode="json"),
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at, record.observed_at
            )
            if record.outcome is TabularLayoutObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at, record.observed_at
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at, record.observed_at
                )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def list_tabular_layout_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        outcome: TabularLayoutObservationOutcome | str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[TabularLayoutObservationRecord]:
        if limit < 1:
            return []
        if offset < 0:
            raise ValueError("tabular layout observation offset must not be negative")
        statement = select(TabularLayoutObservationRow).where(
            TabularLayoutObservationRow.tenant_id == tenant_id
        )
        if profile_id is not None:
            statement = statement.where(
                TabularLayoutObservationRow.profile_id == profile_id
            )
        if outcome is not None:
            statement = statement.where(
                TabularLayoutObservationRow.outcome
                == TabularLayoutObservationOutcome(_enum(outcome)).value
            )
        statement = (
            statement.order_by(
                TabularLayoutObservationRow.observed_at.desc(),
                TabularLayoutObservationRow.observation_id,
            )
            .offset(offset)
            .limit(min(limit, 1000))
        )
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_observation_record(row) for row in rows]


__all__ = ["KnowledgeTabularLayoutProfileMixin"]
