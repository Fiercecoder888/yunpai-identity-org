"""Governed persistence records for reusable tabular-layout routing.

The parser-side module owns the canonical value-free ``TabularLayoutSignature``
and plan normalizer.  This module adds versioning, tenant isolation, review
metadata, observations, and database-facing records without inventing a second
layout vocabulary.  The full plan JSON retains only replayable coordinates,
target paths, and mapping strategies; cell values, filenames, source text,
prompts, and task identifiers are rejected by the shared normalizer.
"""

from __future__ import annotations

import math
import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Self

from pydantic import Field, field_validator, model_validator

from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutProfile as RuntimeTabularLayoutProfile,
)
from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutProfileMatch,
    TabularLayoutSignature,
    TabularLayoutTableShape,
    normalize_tabular_layout_plan,
)

from .db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from .schema import KnowledgeSchema, new_id, utc_now

_TOKEN_RE = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")


class TabularLayoutProfileStatus(StrEnum):
    CANDIDATE = "candidate"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class TabularLayoutObservationOutcome(StrEnum):
    SUCCESS = "success"
    FAILURE = "failure"


class TabularLayoutObservationSummary(KnowledgeSchema):
    """Bounded operational facts; raw source content is deliberately excluded."""

    parser_revision: str = Field(min_length=1, max_length=128)
    applied: bool
    validation_passed: bool
    mapped_field_count: int = Field(ge=0, le=100_000)
    mapped_record_count: int = Field(ge=0, le=10_000_000)
    issue_codes: tuple[str, ...] = Field(default=(), max_length=64)
    # Only a one-way task reference is persisted.  The raw Tracking TaskID
    # never enters the knowledge profile, vector text, or model prompt.
    task_reference_hash: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")

    @field_validator("parser_revision", "issue_codes")
    @classmethod
    def validate_safe_tokens(cls, value):
        if isinstance(value, str):
            normalized = value.strip().casefold()
            if not _TOKEN_RE.fullmatch(normalized):
                raise ValueError("summary tokens must be structural codes")
            return normalized
        normalized = tuple(dict.fromkeys(item.strip().casefold() for item in value))
        if any(not _TOKEN_RE.fullmatch(item) for item in normalized):
            raise ValueError("summary issue codes must be structural codes")
        return normalized


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class TabularLayoutProfileRecord(KnowledgeSchema):
    """One immutable profile version plus mutable governance statistics."""

    profile_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    version: int = Field(ge=1)
    supersedes_profile_id: str | None = Field(
        default=None, min_length=1, max_length=128
    )
    status: TabularLayoutProfileStatus = TabularLayoutProfileStatus.CANDIDATE
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    signature: TabularLayoutSignature
    # ``normalize_tabular_layout_plan`` accepts validated TabularSchemaPlan
    # instances or mappings and strips non-replayable content before persistence.
    plan: dict[str, Any]
    embedding: list[float] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0)
    created_by: str = Field(min_length=1, max_length=256)
    reviewed_by: str | None = Field(default=None, min_length=1, max_length=256)
    reviewed_at: datetime | None = None
    review_reason_codes: tuple[str, ...] = Field(default=(), max_length=32)
    approved_by: str | None = Field(default=None, min_length=1, max_length=256)
    approved_at: datetime | None = None
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)
    last_observed_at: datetime | None = None
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("profile_key")
    @classmethod
    def validate_profile_key(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if not _TOKEN_RE.fullmatch(normalized):
            raise ValueError("profile_key must be a stable non-content identifier")
        return normalized

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.lower()

    @field_validator("plan", mode="before")
    @classmethod
    def normalize_plan(cls, value: object) -> dict[str, Any]:
        return normalize_tabular_layout_plan(value)

    @field_validator("embedding")
    @classmethod
    def validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        if value is None:
            return None
        normalized = [float(item) for item in value]
        if len(normalized) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "tabular layout embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {len(normalized)}"
            )
        if not all(math.isfinite(item) for item in normalized):
            raise ValueError("tabular layout embedding contains non-finite values")
        return normalized

    @field_validator("embedding_model")
    @classmethod
    def normalize_embedding_model(cls, value: str) -> str:
        return value.strip()

    @field_validator("review_reason_codes")
    @classmethod
    def validate_review_codes(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        normalized = tuple(dict.fromkeys(item.strip().casefold() for item in value))
        if any(not _TOKEN_RE.fullmatch(item) for item in normalized):
            raise ValueError("review reasons must be stable codes")
        return normalized

    @field_validator(
        "reviewed_at",
        "approved_at",
        "last_observed_at",
        "last_success_at",
        "last_failure_at",
        "created_at",
        "updated_at",
    )
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _utc(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.version == 1 and self.supersedes_profile_id is not None:
            raise ValueError("a first tabular layout version cannot supersede another")
        if self.version > 1 and self.supersedes_profile_id is None:
            raise ValueError("tabular layout revisions require a superseded profile")
        if self.supersedes_profile_id == self.profile_id:
            raise ValueError("a tabular layout profile cannot supersede itself")
        if self.exact_fingerprint != self.signature.exact_fingerprint():
            raise ValueError("exact_fingerprint does not match the tabular signature")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError(
                    "tabular layout embedding identity requires an embedding vector"
                )
        else:
            if not self.embedding_model:
                raise ValueError("tabular layout embeddings require a model identity")
            if self.embedding_dimensions not in {0, len(self.embedding)}:
                raise ValueError(
                    "tabular layout embedding identity dimensions do not match the vector"
                )
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("tabular layout observation counters are inconsistent")
        if self.status is TabularLayoutProfileStatus.ACTIVE and (
            not self.approved_by or self.approved_at is None
        ):
            raise ValueError("active tabular layout profiles require approval metadata")
        return self

    def as_runtime_profile(self) -> RuntimeTabularLayoutProfile:
        """Expose the narrow parser-side profile contract for active/candidate use."""

        if self.status is TabularLayoutProfileStatus.REJECTED:
            raise ValueError("a rejected tabular layout profile is not routable")
        return RuntimeTabularLayoutProfile(
            profile_id=self.profile_id,
            tenant_id=self.tenant_id,
            profile_key=self.profile_key,
            status=self.status.value,
            exact_fingerprint=self.exact_fingerprint,
            signature=self.signature,
            plan=self.plan,
            embedding=(tuple(self.embedding) if self.embedding is not None else None),
            embedding_model=self.embedding_model,
            embedding_dimensions=self.embedding_dimensions,
            observation_count=self.observation_count,
            success_count=self.success_count,
            failure_count=self.failure_count,
        )


class TabularLayoutObservationRecord(KnowledgeSchema):
    observation_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: TabularLayoutObservationOutcome
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)
    summary: TabularLayoutObservationSummary
    observed_at: datetime = Field(default_factory=utc_now)

    @field_validator("exact_fingerprint")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.lower()

    @field_validator("error_code")
    @classmethod
    def validate_error_code(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if normalized and not _TOKEN_RE.fullmatch(normalized):
            raise ValueError("error_code must be a stable code")
        return normalized

    @field_validator("observed_at")
    @classmethod
    def normalize_time(cls, value: datetime) -> datetime:
        return _utc(value) or utc_now()


__all__ = [
    "TabularLayoutObservationOutcome",
    "TabularLayoutObservationRecord",
    "TabularLayoutObservationSummary",
    "TabularLayoutProfileMatch",
    "TabularLayoutProfileRecord",
    "TabularLayoutProfileStatus",
    "TabularLayoutSignature",
    "TabularLayoutTableShape",
]
