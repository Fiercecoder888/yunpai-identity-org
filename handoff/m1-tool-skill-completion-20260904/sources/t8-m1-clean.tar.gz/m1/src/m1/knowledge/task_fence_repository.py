"""Durable task lifecycle fences for cross-process source writers."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.ext.asyncio import AsyncSession

from .db_models import (
    DocumentVersionRow,
    SourceOccurrenceRow,
    TaskLifecycleRow,
    TaskVersionBindingRow,
)
from .persistence_helpers import _aware
from .schema import (
    LifecycleStatus,
    StaleTaskFenceError,
    TaskFenceToken,
    TaskLifecycleRecord,
    TaskLifecycleStatus,
    TaskTombstonedError,
    new_id,
    utc_now,
)


def _task_lifecycle_record(row: TaskLifecycleRow) -> TaskLifecycleRecord:
    return TaskLifecycleRecord(
        lifecycle_id=row.lifecycle_id,
        tenant_id=row.tenant_id,
        task_id=row.task_id,
        epoch=int(row.epoch),
        status=row.status,
        updated_at=_aware(row.updated_at),
        tombstoned_at=_aware(row.tombstoned_at),
    )


class KnowledgeTaskFenceMixin:
    """Provide short transaction-scoped task fencing primitives.

    Source-derived writers call ``_assert_task_fence`` as their first query in
    the same transaction as the protected write. PostgreSQL writers take
    compatible ``FOR SHARE`` locks; begin/tombstone/reactivate take
    ``FOR UPDATE`` so they wait for already-started writes and invalidate all
    later writes carrying an older epoch.
    """

    @staticmethod
    def _task_lifecycle_lock_statement(
        tenant_id: str,
        task_id: str,
        *,
        shared: bool,
    ):
        return (
            select(TaskLifecycleRow)
            .where(
                TaskLifecycleRow.tenant_id == tenant_id,
                TaskLifecycleRow.task_id == task_id,
            )
            .with_for_update(read=shared)
        )

    async def _legacy_task_lifecycle_status(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
        default: TaskLifecycleStatus,
    ) -> TaskLifecycleStatus:
        binding_statuses = (
            await session.scalars(
                select(TaskVersionBindingRow.status).where(
                    TaskVersionBindingRow.tenant_id == tenant_id,
                    TaskVersionBindingRow.task_id == task_id,
                )
            )
        ).all()
        occurrence_metadata = (
            await session.scalars(
                select(SourceOccurrenceRow.metadata_json).where(
                    SourceOccurrenceRow.tenant_id == tenant_id,
                    SourceOccurrenceRow.task_id == task_id,
                )
            )
        ).all()
        if not occurrence_metadata:
            legacy_metadata = (
                await session.scalars(
                    select(SourceOccurrenceRow.metadata_json).where(
                        SourceOccurrenceRow.tenant_id == tenant_id,
                        SourceOccurrenceRow.task_id == "",
                    )
                )
            ).all()
            occurrence_metadata = [
                metadata
                for metadata in legacy_metadata
                if str((metadata or {}).get("task_id") or "") == task_id
            ]

        if "active" in binding_statuses or any(
            not bool((metadata or {}).get("tombstoned"))
            for metadata in occurrence_metadata
        ):
            return TaskLifecycleStatus.ACTIVE
        if binding_statuses or occurrence_metadata:
            return TaskLifecycleStatus.TOMBSTONED
        return default

    async def _insert_task_lifecycle_if_absent(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
        status: TaskLifecycleStatus,
    ) -> None:
        values = {
            "lifecycle_id": new_id(),
            "tenant_id": tenant_id,
            "task_id": task_id,
            "epoch": 0,
            "status": status.value,
            "updated_at": utc_now(),
            "tombstoned_at": None,
        }
        dialect = session.get_bind().dialect.name
        if dialect == "postgresql":
            statement = postgresql_insert(TaskLifecycleRow).values(**values)
        elif dialect == "sqlite":
            statement = sqlite_insert(TaskLifecycleRow).values(**values)
        else:  # pragma: no cover - M1 supports PostgreSQL and test SQLite only
            raise RuntimeError(f"unsupported task fence database: {dialect}")
        await session.execute(
            statement.on_conflict_do_nothing(
                index_elements=[
                    TaskLifecycleRow.tenant_id,
                    TaskLifecycleRow.task_id,
                ]
            )
        )

    async def _ensure_task_lifecycle_locked(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
        default: TaskLifecycleStatus,
    ) -> TaskLifecycleRow:
        row = await session.scalar(
            self._task_lifecycle_lock_statement(
                tenant_id,
                task_id,
                shared=False,
            )
        )
        if row is not None:
            return row

        legacy_status = await self._legacy_task_lifecycle_status(
            session,
            tenant_id=tenant_id,
            task_id=task_id,
            default=default,
        )
        await self._insert_task_lifecycle_if_absent(
            session,
            tenant_id=tenant_id,
            task_id=task_id,
            status=legacy_status,
        )
        row = await session.scalar(
            self._task_lifecycle_lock_statement(
                tenant_id,
                task_id,
                shared=False,
            )
        )
        if row is None:  # pragma: no cover - INSERT/SELECT is one transaction
            raise StaleTaskFenceError("task lifecycle row was not materialized")
        return row

    async def _begin_task_fence_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
        reactivate: bool,
    ) -> TaskFenceToken:
        await self._require_tenant(session, tenant_id)
        row = await self._ensure_task_lifecycle_locked(
            session,
            tenant_id=tenant_id,
            task_id=task_id,
            default=TaskLifecycleStatus.ACTIVE,
        )
        was_tombstoned = row.status == TaskLifecycleStatus.TOMBSTONED.value
        if was_tombstoned and not reactivate:
            raise TaskTombstonedError(f"task is tombstoned: {task_id}")
        now = utc_now()
        row.epoch = int(row.epoch) + 1
        row.status = TaskLifecycleStatus.ACTIVE.value
        row.updated_at = now
        row.tombstoned_at = None
        await session.flush()
        return TaskFenceToken(
            tenant_id=tenant_id,
            task_id=task_id,
            epoch=int(row.epoch),
            reactivated=was_tombstoned,
        )

    async def begin_task_fence(
        self,
        tenant_id: str,
        task_id: str,
        *,
        reactivate: bool = False,
    ) -> TaskFenceToken:
        """Start a new logical sync generation for one active task."""

        async def operation(session: AsyncSession) -> TaskFenceToken:
            return await self._begin_task_fence_in_session(
                session,
                tenant_id=tenant_id,
                task_id=task_id,
                reactivate=reactivate,
            )

        return await self._write(operation)

    async def reactivate_task_fence(
        self,
        tenant_id: str,
        task_id: str,
    ) -> TaskFenceToken:
        """Explicitly start a new generation even after a durable tombstone."""

        async def operation(session: AsyncSession) -> TaskFenceToken:
            return await self._begin_task_fence_in_session(
                session,
                tenant_id=tenant_id,
                task_id=task_id,
                reactivate=True,
            )

        return await self._write(operation)

    async def _assert_task_fence(
        self,
        session: AsyncSession,
        fence: TaskFenceToken,
        *,
        tenant_id: str,
        task_id: str,
    ) -> TaskLifecycleRow:
        """Hold a shared fence lock through the caller's current transaction."""

        if fence.tenant_id != tenant_id or fence.task_id != task_id:
            raise StaleTaskFenceError("task fence identity does not match the write")
        row = await session.scalar(
            self._task_lifecycle_lock_statement(
                tenant_id,
                task_id,
                shared=True,
            )
        )
        if row is None:
            raise StaleTaskFenceError("task lifecycle row is missing")
        if row.status == TaskLifecycleStatus.TOMBSTONED.value:
            raise TaskTombstonedError(f"task is tombstoned: {task_id}")
        if row.status != TaskLifecycleStatus.ACTIVE.value or int(row.epoch) != fence.epoch:
            raise StaleTaskFenceError(
                f"task fence epoch is stale: expected {fence.epoch}, current {row.epoch}"
            )
        return row

    async def validate_task_fence(
        self,
        tenant_id: str,
        task_id: str,
        fence: TaskFenceToken,
    ) -> TaskLifecycleRecord:
        """Validate a token; protected writes use ``_assert_task_fence`` directly."""

        async def operation(session: AsyncSession) -> TaskLifecycleRecord:
            row = await self._assert_task_fence(
                session,
                fence,
                tenant_id=tenant_id,
                task_id=task_id,
            )
            return _task_lifecycle_record(row)

        return await self._write(operation)

    async def _assert_fenced_version_binding(
        self,
        session: AsyncSession,
        fence: TaskFenceToken,
        *,
        tenant_id: str,
        version_id: str | None = None,
        source_record_id: str = "",
        source_version: str = "",
        fence_locked: bool = False,
    ) -> str:
        if not fence_locked:
            await self._assert_task_fence(
                session,
                fence,
                tenant_id=tenant_id,
                task_id=fence.task_id,
            )
        resolved_version_id = str(version_id or "")
        version_statement = select(DocumentVersionRow).where(
            DocumentVersionRow.tenant_id == tenant_id
        )
        if resolved_version_id:
            version_statement = version_statement.where(
                DocumentVersionRow.version_id == resolved_version_id
            )
        else:
            try:
                version_number = int(source_version)
            except (TypeError, ValueError) as exc:
                raise StaleTaskFenceError(
                    "source version is not a governed document version"
                ) from exc
            version_statement = version_statement.where(
                DocumentVersionRow.document_id == source_record_id,
                DocumentVersionRow.version_number == version_number,
            )
        version = await session.scalar(
            version_statement.with_for_update(read=True).execution_options(
                populate_existing=True
            )
        )
        if version is None:
            raise StaleTaskFenceError("source document version is unavailable")
        resolved_version_id = version.version_id
        if version.lifecycle_status in {
            LifecycleStatus.DEPRECATED.value,
            LifecycleStatus.REJECTED.value,
        }:
            raise TaskTombstonedError(
                f"source document version is retired: {resolved_version_id}"
            )
        binding = await session.scalar(
            select(TaskVersionBindingRow)
            .where(
                TaskVersionBindingRow.tenant_id == tenant_id,
                TaskVersionBindingRow.task_id == fence.task_id,
                TaskVersionBindingRow.version_id == resolved_version_id,
                TaskVersionBindingRow.status == "active",
            )
            .with_for_update(read=True)
            .execution_options(populate_existing=True)
        )
        if binding is None:
            raise TaskTombstonedError(
                f"task has no active binding for version: {fence.task_id}"
            )
        return resolved_version_id

    async def _tombstone_task_fence_in_session(
        self,
        session: AsyncSession,
        *,
        tenant_id: str,
        task_id: str,
    ) -> TaskLifecycleRecord:
        await self._require_tenant(session, tenant_id)
        row = await self._ensure_task_lifecycle_locked(
            session,
            tenant_id=tenant_id,
            task_id=task_id,
            default=TaskLifecycleStatus.TOMBSTONED,
        )
        if row.status != TaskLifecycleStatus.TOMBSTONED.value or int(row.epoch) == 0:
            now = utc_now()
            row.epoch = int(row.epoch) + 1
            row.status = TaskLifecycleStatus.TOMBSTONED.value
            row.updated_at = now
            row.tombstoned_at = now
            await session.flush()
        return _task_lifecycle_record(row)

    async def tombstone_task_fence(
        self,
        tenant_id: str,
        task_id: str,
    ) -> TaskLifecycleRecord:
        """Persist a tombstone even when the task has never been ingested."""

        async def operation(session: AsyncSession) -> TaskLifecycleRecord:
            return await self._tombstone_task_fence_in_session(
                session,
                tenant_id=tenant_id,
                task_id=task_id,
            )

        return await self._write(operation)

    async def get_task_lifecycle(
        self,
        tenant_id: str,
        task_id: str,
    ) -> TaskLifecycleRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(TaskLifecycleRow).where(
                    TaskLifecycleRow.tenant_id == tenant_id,
                    TaskLifecycleRow.task_id == task_id,
                )
            )
            return _task_lifecycle_record(row) if row is not None else None
