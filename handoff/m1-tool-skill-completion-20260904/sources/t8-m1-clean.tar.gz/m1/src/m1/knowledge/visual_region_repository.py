"""Tenant-safe persistence for governed visual-region routing profiles."""

from __future__ import annotations

import inspect as pyinspect
import math
from collections.abc import Collection, Sequence
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from m1.documents.parsing.visual_region_routing import (
    VisualRegionCandidateProposal,
    VisualRegionExactCase,
    VisualRegionExecutionObservation,
    VisualRegionRole,
    VisualRegionSimilarCase,
    VisualRegionSourceKind,
    VisualRegionTopology,
)

from .db_document_models import TenantRow
from .db_models_base import (
    KNOWLEDGE_EMBEDDING_DIMENSIONS,
    IdempotencyConflictError,
    RecordNotFoundError,
    TenantBoundaryError,
)
from .persistence_helpers import _aware, _canonical_json
from .repository_base import KnowledgeRepositoryBase, _tenant_scoped_call
from .route_lifecycle import (
    record_route_lifecycle_event,
    require_separated_approval,
)
from .schema import utc_now
from .visual_region_db_models import (
    VisualRegionObservationRow,
    VisualRegionProfileRow,
)
from .visual_region_schema import (
    VisualRegionObservationOutcome,
    VisualRegionObservationRecord,
    VisualRegionProfileRecord,
    VisualRegionProfileStatus,
)

_MIN_ACTIVATION_DISTINCT_TASKS = 3


def _profile_record(row: VisualRegionProfileRow) -> VisualRegionProfileRecord:
    topology = VisualRegionTopology.model_validate(
        row.topology_json,
        strict=False,
    )
    if row.contract_revision != topology.contract_revision:
        raise ValueError("visual profile contract revision does not match topology")
    return VisualRegionProfileRecord(
        profile_id=row.profile_id,
        tenant_id=row.tenant_id,
        profile_key=row.profile_key,
        version=row.version,
        supersedes_profile_id=row.supersedes_profile_id,
        status=row.status,
        exact_fingerprint=row.exact_fingerprint,
        asset_sha256=row.asset_sha256,
        topology=topology,
        role=row.role,
        embedding=(list(row.embedding) if row.embedding is not None else None),
        embedding_model=row.embedding_model,
        embedding_dimensions=row.embedding_dimensions,
        created_by=row.created_by,
        reviewed_by=row.reviewed_by,
        reviewed_at=_aware(row.reviewed_at),
        review_note=row.review_note,
        approved_by=row.approved_by,
        approved_at=_aware(row.approved_at),
        observation_count=row.observation_count,
        success_count=row.success_count,
        failure_count=row.failure_count,
        last_observed_at=_aware(row.last_observed_at),
        last_success_at=_aware(row.last_success_at),
        last_failure_at=_aware(row.last_failure_at),
        created_at=_aware(row.created_at) or utc_now(),
        updated_at=_aware(row.updated_at) or utc_now(),
    )


def _observation_record(
    row: VisualRegionObservationRow,
) -> VisualRegionObservationRecord:
    return VisualRegionObservationRecord(
        observation_id=row.observation_id,
        tenant_id=row.tenant_id,
        profile_id=row.profile_id,
        idempotency_key=row.idempotency_key,
        exact_fingerprint=row.exact_fingerprint,
        task_reference_hash=row.task_reference_hash,
        outcome=row.outcome,
        validation_passed=row.validation_passed,
        reviewed_by=row.reviewed_by,
        review_note_sha256=row.review_note_sha256,
        latency_ms=row.latency_ms,
        error_code=row.error_code,
        observed_at=_aware(row.observed_at) or utc_now(),
    )


def _same_profile_definition(
    row: VisualRegionProfileRow,
    record: VisualRegionProfileRecord,
) -> bool:
    stored_embedding = list(row.embedding) if row.embedding is not None else None
    return (
        row.tenant_id == record.tenant_id
        and row.profile_key == record.profile_key
        and row.version == record.version
        and row.supersedes_profile_id == record.supersedes_profile_id
        and row.exact_fingerprint == record.exact_fingerprint
        and row.asset_sha256 == record.asset_sha256
        and row.source_kind == record.topology.source_kind.value
        and row.contract_revision == record.topology.contract_revision
        and row.role == record.role.value
        and _canonical_json(row.topology_json)
        == _canonical_json(record.topology.model_dump(mode="json"))
        and stored_embedding == record.embedding
        and row.embedding_model == record.embedding_model
        and row.embedding_dimensions == record.embedding_dimensions
    )


def _same_observation(
    row: VisualRegionObservationRow,
    record: VisualRegionObservationRecord,
) -> bool:
    return (
        row.tenant_id == record.tenant_id
        and row.profile_id == record.profile_id
        and row.idempotency_key == record.idempotency_key
        and row.exact_fingerprint == record.exact_fingerprint
        and row.task_reference_hash == record.task_reference_hash
        and row.outcome == record.outcome.value
        and row.validation_passed == record.validation_passed
        and row.reviewed_by == record.reviewed_by
        and row.review_note_sha256 == record.review_note_sha256
        and row.latency_ms == record.latency_ms
        and row.error_code == record.error_code
    )


def _latest(first: datetime | None, second: datetime) -> datetime:
    normalized = _aware(first)
    candidate = _aware(second) or utc_now()
    return max(normalized, candidate) if normalized is not None else candidate


def _fingerprint(value: str) -> str:
    normalized = value.strip().casefold()
    if len(normalized) != 64:
        raise ValueError("visual fingerprints must contain 64 hexadecimal chars")
    try:
        int(normalized, 16)
    except ValueError as exc:
        raise ValueError(
            "visual fingerprints must contain 64 hexadecimal chars"
        ) from exc
    return normalized


class KnowledgeVisualRegionRouteMixin:
    """Repository mixin; only reviewed candidates can become active."""

    async def _lock_visual_region_tenant(
        self,
        session: AsyncSession,
        tenant_id: str,
    ) -> TenantRow:
        await self._require_tenant(session, tenant_id)
        statement = select(TenantRow).where(TenantRow.tenant_id == tenant_id)
        if self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"tenant not found: {tenant_id}")
        return row

    async def _require_visual_region_profile(
        self,
        session: AsyncSession,
        tenant_id: str,
        profile_id: str,
        *,
        for_update: bool = False,
    ) -> VisualRegionProfileRow:
        statement = select(VisualRegionProfileRow).where(
            VisualRegionProfileRow.profile_id == profile_id
        )
        if for_update and self.engine.url.get_backend_name() != "sqlite":
            statement = statement.with_for_update()
        row = await session.scalar(statement)
        if row is None:
            raise RecordNotFoundError(f"visual region profile not found: {profile_id}")
        if row.tenant_id != tenant_id:
            raise TenantBoundaryError(profile_id)
        return row

    async def create_visual_region_profile(
        self,
        record: VisualRegionProfileRecord,
    ) -> VisualRegionProfileRecord:
        if record.status is not VisualRegionProfileStatus.CANDIDATE:
            raise ValueError("new visual region profiles must start as candidate")

        async def operation(session: AsyncSession) -> VisualRegionProfileRecord:
            await self._lock_visual_region_tenant(session, record.tenant_id)
            collisions = (
                await session.scalars(
                    select(VisualRegionProfileRow).where(
                        VisualRegionProfileRow.tenant_id == record.tenant_id,
                        or_(
                            VisualRegionProfileRow.profile_id == record.profile_id,
                            (
                                (
                                    VisualRegionProfileRow.profile_key
                                    == record.profile_key
                                )
                                & (VisualRegionProfileRow.version == record.version)
                            ),
                        ),
                    )
                )
            ).all()
            if collisions:
                existing = next(
                    (
                        row
                        for row in collisions
                        if row.profile_key == record.profile_key
                        and row.version == record.version
                    ),
                    None,
                )
                if existing is not None and _same_profile_definition(existing, record):
                    return _profile_record(existing)
                raise IdempotencyConflictError(
                    f"visual-region-profile:{record.profile_key}:{record.version}"
                )

            predecessor: VisualRegionProfileRow | None = None
            if record.supersedes_profile_id is not None:
                predecessor = await self._require_visual_region_profile(
                    session,
                    record.tenant_id,
                    record.supersedes_profile_id,
                    for_update=True,
                )
                if predecessor.profile_key != record.profile_key:
                    raise ValueError("a visual revision changes its profile key")
                if predecessor.exact_fingerprint != record.exact_fingerprint:
                    raise ValueError("a visual revision changes its topology")
                if predecessor.asset_sha256 != record.asset_sha256:
                    raise ValueError("a visual revision changes its asset identity")
                if predecessor.contract_revision != record.topology.contract_revision:
                    raise ValueError("a visual revision changes its contract revision")
                if predecessor.role != record.role.value:
                    raise ValueError("a visual revision changes its governed role")
                if record.version != predecessor.version + 1:
                    raise ValueError("visual revisions must be consecutive")
                if predecessor.status == VisualRegionProfileStatus.ACTIVE.value:
                    raise ValueError(
                        "an active visual profile must be deprecated before revision"
                    )

            dimensions = (
                len(record.embedding)
                if record.embedding is not None
                else record.embedding_dimensions
            )
            row = VisualRegionProfileRow(
                profile_id=record.profile_id,
                tenant_id=record.tenant_id,
                profile_key=record.profile_key,
                version=record.version,
                supersedes_profile_id=record.supersedes_profile_id,
                status=record.status.value,
                exact_fingerprint=record.exact_fingerprint,
                asset_sha256=record.asset_sha256,
                source_kind=record.topology.source_kind.value,
                contract_revision=record.topology.contract_revision,
                role=record.role.value,
                topology_json=record.topology.model_dump(mode="json"),
                embedding=record.embedding,
                embedding_model=record.embedding_model,
                embedding_dimensions=dimensions,
                created_by=record.created_by,
                reviewed_by=record.reviewed_by,
                reviewed_at=record.reviewed_at,
                review_note=record.review_note,
                approved_by=None,
                approved_at=None,
                observation_count=0,
                success_count=0,
                failure_count=0,
                last_observed_at=None,
                last_success_at=None,
                last_failure_at=None,
                created_at=record.created_at,
                updated_at=record.updated_at,
            )
            session.add(row)
            if (
                predecessor is not None
                and predecessor.status == VisualRegionProfileStatus.CANDIDATE.value
            ):
                predecessor.status = VisualRegionProfileStatus.DEPRECATED.value
                predecessor.updated_at = _latest(
                    predecessor.updated_at,
                    record.created_at,
                )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=record.tenant_id,
                    route_kind="visual_region",
                    profile_id=predecessor.profile_id,
                    event_type="superseded",
                    actor_id=record.created_by,
                    reason=f"superseded by profile {record.profile_id}",
                    observation_count=predecessor.observation_count,
                    occurred_at=record.created_at,
                )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def create_visual_region_candidate(
        self,
        record: VisualRegionCandidateProposal,
    ) -> VisualRegionProfileRecord:
        """Persist an automatic proposal as an inactive version-one profile."""

        proposal = record
        candidate = VisualRegionProfileRecord(
            tenant_id=proposal.tenant_id,
            profile_key=proposal.profile_key,
            version=1,
            exact_fingerprint=proposal.topology.exact_fingerprint(),
            asset_sha256=proposal.asset_sha256,
            topology=proposal.topology,
            role=proposal.role,
            embedding=list(proposal.embedding),
            embedding_model=proposal.embedding_model,
            embedding_dimensions=proposal.embedding_dimensions,
            created_by=proposal.created_by,
        )
        try:
            return await self.create_visual_region_profile(candidate)
        except IdempotencyConflictError:
            profiles = await self.list_visual_region_profiles(
                proposal.tenant_id,
                profile_key=proposal.profile_key,
            )
            for existing in profiles:
                if (
                    existing.status is VisualRegionProfileStatus.CANDIDATE
                    and existing.role is proposal.role
                    and existing.asset_sha256 == proposal.asset_sha256
                    and _canonical_json(existing.topology.model_dump(mode="json"))
                    == _canonical_json(proposal.topology.model_dump(mode="json"))
                ):
                    return existing
            raise

    async def get_visual_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
    ) -> VisualRegionProfileRecord | None:
        async with self.sessionmaker() as session:
            row = await session.scalar(
                select(VisualRegionProfileRow).where(
                    VisualRegionProfileRow.tenant_id == tenant_id,
                    VisualRegionProfileRow.profile_id == profile_id,
                )
            )
            return _profile_record(row) if row else None

    async def list_visual_region_profiles(
        self,
        tenant_id: str,
        *,
        status: VisualRegionProfileStatus | str | None = None,
        profile_key: str | None = None,
        exact_fingerprint: str | None = None,
        role: VisualRegionRole | str | None = None,
        limit: int = 200,
    ) -> list[VisualRegionProfileRecord]:
        if limit < 1:
            return []
        statement = select(VisualRegionProfileRow).where(
            VisualRegionProfileRow.tenant_id == tenant_id
        )
        if status is not None:
            statement = statement.where(
                VisualRegionProfileRow.status
                == VisualRegionProfileStatus(str(status)).value
            )
        if profile_key is not None:
            statement = statement.where(
                VisualRegionProfileRow.profile_key == profile_key.strip().casefold()
            )
        if exact_fingerprint is not None:
            statement = statement.where(
                VisualRegionProfileRow.exact_fingerprint
                == _fingerprint(exact_fingerprint)
            )
        if role is not None:
            statement = statement.where(
                VisualRegionProfileRow.role == VisualRegionRole(str(role)).value
            )
        statement = statement.order_by(
            VisualRegionProfileRow.profile_key,
            VisualRegionProfileRow.version.desc(),
            VisualRegionProfileRow.profile_id,
        ).limit(min(limit, 1000))
        async with self.sessionmaker() as session:
            rows = (await session.scalars(statement)).all()
            return [_profile_record(row) for row in rows]

    async def find_active_visual_region_cases(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        topology: VisualRegionTopology,
        asset_sha256: str,
        limit: int,
    ) -> list[VisualRegionSimilarCase]:
        """Return only tenant/source/model-compatible active pgvector Top-K."""

        if limit < 1:
            return []
        model = embedding_model.strip()
        if not model:
            raise ValueError("visual embedding model identity is required")
        dimensions = int(embedding_dimensions)
        if dimensions != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "visual embedding identity dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {dimensions}"
            )
        vector = [float(value) for value in embedding]
        if len(vector) != dimensions or not all(
            math.isfinite(value) for value in vector
        ):
            raise ValueError("visual query embedding is invalid")
        asset_digest = _fingerprint(asset_sha256)

        statement = select(VisualRegionProfileRow).where(
            VisualRegionProfileRow.tenant_id == tenant_id,
            VisualRegionProfileRow.status == VisualRegionProfileStatus.ACTIVE.value,
            VisualRegionProfileRow.source_kind == topology.source_kind.value,
            VisualRegionProfileRow.contract_revision == topology.contract_revision,
            VisualRegionProfileRow.asset_sha256 == asset_digest,
            VisualRegionProfileRow.embedding.is_not(None),
            VisualRegionProfileRow.embedding_model == model,
            VisualRegionProfileRow.embedding_dimensions == dimensions,
        )
        async with self.sessionmaker() as session:
            if self.engine.url.get_backend_name() == "postgresql":
                distance = VisualRegionProfileRow.embedding.cosine_distance(vector)
                rows = (
                    await session.execute(
                        statement.add_columns((1.0 - distance).label("similarity"))
                        .order_by(distance, VisualRegionProfileRow.profile_id)
                        .limit(min(limit, 100))
                    )
                ).all()
                return [
                    _profile_record(row).as_similar_case(
                        query_topology=topology,
                        vector_similarity=max(0.0, min(1.0, float(similarity))),
                    )
                    for row, similarity in rows
                ]
            rows = (
                await session.scalars(
                    statement.order_by(
                        VisualRegionProfileRow.updated_at.desc(),
                        VisualRegionProfileRow.profile_id,
                    ).limit(5000)
                )
            ).all()

        query_norm = math.sqrt(sum(value * value for value in vector))
        matches: list[tuple[float, VisualRegionSimilarCase]] = []
        for row in rows:
            stored = [float(value) for value in (row.embedding or [])]
            if len(stored) != dimensions:
                continue
            stored_norm = math.sqrt(sum(value * value for value in stored))
            similarity = (
                sum(left * right for left, right in zip(vector, stored, strict=True))
                / (query_norm * stored_norm)
                if query_norm and stored_norm
                else 0.0
            )
            similarity = max(0.0, min(1.0, similarity))
            matches.append(
                (
                    similarity,
                    _profile_record(row).as_similar_case(
                        query_topology=topology,
                        vector_similarity=similarity,
                    ),
                )
            )
        matches.sort(key=lambda item: (-item[0], item[1].case_id))
        return [item[1] for item in matches[: min(limit, 100)]]

    async def get_active_visual_region_case_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        source_kind: VisualRegionSourceKind,
        asset_sha256: str,
    ) -> VisualRegionExactCase | None:
        """Return an exact ACTIVE case without requiring an embedding service."""

        revision = contract_revision.strip()
        if not revision:
            raise ValueError("visual region contract revision is required")
        statement = select(VisualRegionProfileRow).where(
            VisualRegionProfileRow.tenant_id == tenant_id,
            VisualRegionProfileRow.status == VisualRegionProfileStatus.ACTIVE.value,
            VisualRegionProfileRow.exact_fingerprint == _fingerprint(exact_fingerprint),
            VisualRegionProfileRow.asset_sha256 == _fingerprint(asset_sha256),
            VisualRegionProfileRow.source_kind
            == VisualRegionSourceKind(source_kind).value,
            VisualRegionProfileRow.contract_revision == revision,
        )
        async with self.sessionmaker() as session:
            row = await session.scalar(
                statement.order_by(
                    VisualRegionProfileRow.version.desc(),
                    VisualRegionProfileRow.profile_id,
                )
            )
            return _profile_record(row).as_exact_case() if row else None

    async def record_visual_region_execution_observation(
        self,
        record: VisualRegionExecutionObservation,
    ) -> VisualRegionObservationRecord:
        observation = record
        record = VisualRegionObservationRecord(
            tenant_id=observation.tenant_id,
            profile_id=observation.profile_id,
            idempotency_key=(
                f"visual-region:{observation.profile_id}:"
                f"{observation.task_reference_hash}"
            ),
            exact_fingerprint=observation.exact_fingerprint,
            task_reference_hash=observation.task_reference_hash,
            outcome=VisualRegionObservationOutcome(observation.outcome),
            validation_passed=observation.validation_passed,
            reviewed_by=observation.reviewed_by,
            review_note_sha256=observation.review_note_sha256,
            latency_ms=observation.latency_ms,
            error_code=observation.error_code,
        )
        return await self.record_visual_region_observation(record)

    async def record_visual_region_observation(
        self,
        record: VisualRegionObservationRecord,
    ) -> VisualRegionObservationRecord:
        async def operation(session: AsyncSession) -> VisualRegionObservationRecord:
            await self._lock_visual_region_tenant(session, record.tenant_id)
            profile = await self._require_visual_region_profile(
                session,
                record.tenant_id,
                record.profile_id,
                for_update=True,
            )
            existing = await session.scalar(
                select(VisualRegionObservationRow).where(
                    VisualRegionObservationRow.tenant_id == record.tenant_id,
                    VisualRegionObservationRow.idempotency_key
                    == record.idempotency_key,
                )
            )
            if existing is not None:
                if not _same_observation(existing, record):
                    raise IdempotencyConflictError(record.idempotency_key)
                return _observation_record(existing)
            if profile.exact_fingerprint != record.exact_fingerprint:
                raise ValueError(
                    "observation fingerprint does not match visual profile"
                )

            row = VisualRegionObservationRow(
                observation_id=record.observation_id,
                tenant_id=record.tenant_id,
                profile_id=record.profile_id,
                idempotency_key=record.idempotency_key,
                exact_fingerprint=record.exact_fingerprint,
                task_reference_hash=record.task_reference_hash,
                outcome=record.outcome.value,
                validation_passed=record.validation_passed,
                reviewed_by=record.reviewed_by,
                review_note_sha256=record.review_note_sha256,
                latency_ms=record.latency_ms,
                error_code=record.error_code,
                observed_at=record.observed_at,
            )
            session.add(row)
            profile.observation_count += 1
            profile.last_observed_at = _latest(
                profile.last_observed_at,
                record.observed_at,
            )
            if record.outcome is VisualRegionObservationOutcome.SUCCESS:
                profile.success_count += 1
                profile.last_success_at = _latest(
                    profile.last_success_at,
                    record.observed_at,
                )
            else:
                profile.failure_count += 1
                profile.last_failure_at = _latest(
                    profile.last_failure_at,
                    record.observed_at,
                )
                if profile.status == VisualRegionProfileStatus.ACTIVE.value:
                    profile.status = VisualRegionProfileStatus.DEPRECATED.value
                    await record_route_lifecycle_event(
                        session,
                        tenant_id=record.tenant_id,
                        route_kind="visual_region",
                        profile_id=profile.profile_id,
                        event_type="auto_deprecated",
                        actor_id=record.reviewed_by or "visual-region-observation",
                        reason=(
                            f"failed observation {record.observation_id}: "
                            f"{record.error_code or 'unspecified'}"
                        ),
                        observation_count=profile.observation_count,
                        occurred_at=record.observed_at,
                    )
            profile.updated_at = _latest(profile.updated_at, record.observed_at)
            await session.flush()
            return _observation_record(row)

        return await self._write(operation)

    async def activate_visual_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str,
        review_note: str,
        expected_observation_count: int,
        allowed_roles: Collection[VisualRegionRole | str],
        approved_at: datetime | None = None,
    ) -> VisualRegionProfileRecord:
        approver = approved_by.strip()
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not approver or not reviewer or not note:
            raise ValueError("approval, review, and review note are required")
        if expected_observation_count < _MIN_ACTIVATION_DISTINCT_TASKS:
            raise ValueError("at least three reviewed validation samples are required")
        role_registry = {VisualRegionRole(str(role)).value for role in allowed_roles}
        if not role_registry:
            raise ValueError("allowed_roles must be a non-empty code registry")
        now = _aware(approved_at) or utc_now()

        async def operation(session: AsyncSession) -> VisualRegionProfileRecord:
            await self._lock_visual_region_tenant(session, tenant_id)
            row = await self._require_visual_region_profile(
                session,
                tenant_id,
                profile_id,
                for_update=True,
            )
            if row.role not in role_registry:
                raise ValueError("visual role is absent from the code-owned registry")
            if row.observation_count != expected_observation_count:
                raise IdempotencyConflictError(
                    f"visual-region-approval-observations:{tenant_id}:{profile_id}"
                )
            if row.failure_count != 0 or row.success_count != row.observation_count:
                raise IdempotencyConflictError(
                    f"visual-region-approval-failures:{tenant_id}:{profile_id}"
                )
            observations = (
                await session.scalars(
                    select(VisualRegionObservationRow).where(
                        VisualRegionObservationRow.tenant_id == tenant_id,
                        VisualRegionObservationRow.profile_id == profile_id,
                    )
                )
            ).all()
            task_hashes = {
                observation.task_reference_hash
                for observation in observations
                if observation.outcome == VisualRegionObservationOutcome.SUCCESS.value
                and observation.validation_passed
                and observation.reviewed_by.strip()
                and len(observation.review_note_sha256) == 64
            }
            if len(task_hashes) < _MIN_ACTIVATION_DISTINCT_TASKS:
                raise IdempotencyConflictError(
                    f"visual-region-approval-distinct-tasks:{tenant_id}:{profile_id}"
                )
            require_separated_approval(
                approved_by=approver,
                reviewed_by=reviewer,
                sample_reviewers=(
                    observation.reviewed_by for observation in observations
                ),
            )
            if row.status == VisualRegionProfileStatus.ACTIVE.value:
                if not (
                    row.approved_by == approver
                    and row.reviewed_by == reviewer
                    and row.review_note == note
                    and (
                        approved_at is None
                        or _aware(row.approved_at) == _aware(approved_at)
                    )
                ):
                    raise IdempotencyConflictError(
                        f"visual-region-activation:{tenant_id}:{profile_id}"
                    )
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="visual_region",
                    profile_id=profile_id,
                    event_type="activated",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=note,
                    observation_count=expected_observation_count,
                    occurred_at=_aware(row.approved_at) or now,
                )
                return _profile_record(row)
            if row.status != VisualRegionProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate visual profiles may be activated")

            statement = select(VisualRegionProfileRow).where(
                VisualRegionProfileRow.tenant_id == tenant_id,
                VisualRegionProfileRow.profile_id != profile_id,
                VisualRegionProfileRow.status == VisualRegionProfileStatus.ACTIVE.value,
                or_(
                    VisualRegionProfileRow.profile_key == row.profile_key,
                    (
                        (
                            VisualRegionProfileRow.exact_fingerprint
                            == row.exact_fingerprint
                        )
                        & (VisualRegionProfileRow.asset_sha256 == row.asset_sha256)
                    ),
                ),
            )
            if self.engine.url.get_backend_name() != "sqlite":
                statement = statement.with_for_update()
            for previous in (await session.scalars(statement)).all():
                previous.status = VisualRegionProfileStatus.DEPRECATED.value
                previous.updated_at = now
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="visual_region",
                    profile_id=previous.profile_id,
                    event_type="superseded",
                    actor_id=approver,
                    counterparty_id=reviewer,
                    reason=f"superseded by profile {profile_id}",
                    observation_count=previous.observation_count,
                    occurred_at=now,
                )

            row.status = VisualRegionProfileStatus.ACTIVE.value
            row.reviewed_by = reviewer
            row.reviewed_at = row.reviewed_at or now
            row.review_note = note
            row.approved_by = approver
            row.approved_at = now
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="visual_region",
                profile_id=profile_id,
                event_type="activated",
                actor_id=approver,
                counterparty_id=reviewer,
                reason=note,
                observation_count=expected_observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def reject_visual_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> VisualRegionProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> VisualRegionProfileRecord:
            await self._lock_visual_region_tenant(session, tenant_id)
            row = await self._require_visual_region_profile(
                session,
                tenant_id,
                profile_id,
                for_update=True,
            )
            if row.status == VisualRegionProfileStatus.REJECTED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="visual_region",
                    profile_id=profile_id,
                    event_type="rejected",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=_aware(row.reviewed_at) or now,
                )
                return _profile_record(row)
            if row.status != VisualRegionProfileStatus.CANDIDATE.value:
                raise ValueError("only candidate visual profiles may be rejected")
            row.status = VisualRegionProfileStatus.REJECTED.value
            row.reviewed_by = reviewer
            row.reviewed_at = now
            row.review_note = note
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="visual_region",
                profile_id=profile_id,
                event_type="rejected",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)

    async def deprecate_visual_region_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        reviewed_by: str,
        review_note: str,
        reviewed_at: datetime | None = None,
    ) -> VisualRegionProfileRecord:
        reviewer = reviewed_by.strip()
        note = review_note.strip()
        if not reviewer or not note:
            raise ValueError("reviewed_by and review_note are required")
        now = _aware(reviewed_at) or utc_now()

        async def operation(session: AsyncSession) -> VisualRegionProfileRecord:
            await self._lock_visual_region_tenant(session, tenant_id)
            row = await self._require_visual_region_profile(
                session,
                tenant_id,
                profile_id,
                for_update=True,
            )
            if row.status == VisualRegionProfileStatus.DEPRECATED.value:
                await record_route_lifecycle_event(
                    session,
                    tenant_id=tenant_id,
                    route_kind="visual_region",
                    profile_id=profile_id,
                    event_type="deprecated",
                    actor_id=reviewer,
                    reason=note,
                    observation_count=row.observation_count,
                    occurred_at=now,
                )
                return _profile_record(row)
            if row.status == VisualRegionProfileStatus.REJECTED.value:
                raise ValueError("a rejected visual profile cannot be deprecated")
            row.status = VisualRegionProfileStatus.DEPRECATED.value
            row.updated_at = now
            await record_route_lifecycle_event(
                session,
                tenant_id=tenant_id,
                route_kind="visual_region",
                profile_id=profile_id,
                event_type="deprecated",
                actor_id=reviewer,
                reason=note,
                observation_count=row.observation_count,
                occurred_at=now,
            )
            await session.flush()
            return _profile_record(row)

        return await self._write(operation)


class VisualRegionRepository(
    KnowledgeVisualRegionRouteMixin,
    KnowledgeRepositoryBase,
):
    """Standalone adapter until the main KnowledgeStore facade imports the mixin."""


for _method_name in dir(VisualRegionRepository):
    _method = getattr(VisualRegionRepository, _method_name)
    if (
        not _method_name.startswith("_")
        and pyinspect.iscoroutinefunction(_method)
        and {"tenant_id", "record"}.intersection(
            pyinspect.signature(_method).parameters
        )
    ):
        setattr(VisualRegionRepository, _method_name, _tenant_scoped_call(_method))


__all__ = ["KnowledgeVisualRegionRouteMixin", "VisualRegionRepository"]
