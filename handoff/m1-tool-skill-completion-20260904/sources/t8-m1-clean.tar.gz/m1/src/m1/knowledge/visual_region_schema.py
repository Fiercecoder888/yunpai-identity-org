"""Governance records for tenant-scoped visual-region routing profiles."""

from __future__ import annotations

import math
import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Self

from pydantic import Field, field_validator, model_validator

from m1.documents.parsing.visual_region_routing import (
    VisualRegionExactCase,
    VisualRegionRole,
    VisualRegionSimilarCase,
    VisualRegionTopology,
    visual_topology_similarity,
)

from .db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from .schema import KnowledgeSchema, new_id, utc_now

_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9_.:-]{0,127}$")


class VisualRegionProfileStatus(StrEnum):
    CANDIDATE = "candidate"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    REJECTED = "rejected"


class VisualRegionObservationOutcome(StrEnum):
    SUCCESS = "success"
    FAILURE = "failure"


def _utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class VisualRegionProfileRecord(KnowledgeSchema):
    """Immutable role/topology version plus reviewed validation counters."""

    profile_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_key: str = Field(min_length=1, max_length=128)
    version: int = Field(default=1, ge=1)
    supersedes_profile_id: str | None = Field(
        default=None, min_length=1, max_length=128
    )
    status: VisualRegionProfileStatus = VisualRegionProfileStatus.CANDIDATE
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    asset_sha256: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    topology: VisualRegionTopology
    role: VisualRegionRole
    embedding: list[float] | None = None
    embedding_model: str = Field(default="", max_length=256)
    embedding_dimensions: int = Field(default=0, ge=0)
    created_by: str = Field(min_length=1, max_length=256)
    reviewed_by: str | None = Field(default=None, min_length=1, max_length=256)
    reviewed_at: datetime | None = None
    review_note: str = Field(default="", max_length=4096)
    approved_by: str | None = Field(default=None, min_length=1, max_length=256)
    approved_at: datetime | None = None
    observation_count: int = Field(default=0, ge=0)
    success_count: int = Field(default=0, ge=0)
    failure_count: int = Field(default=0, ge=0)
    last_observed_at: datetime | None = None
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("profile_key")
    @classmethod
    def validate_profile_key(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("visual profile keys must be stable tokens")
        return normalized

    @field_validator("exact_fingerprint", "asset_sha256")
    @classmethod
    def normalize_fingerprint(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("embedding")
    @classmethod
    def validate_embedding(cls, value: list[float] | None) -> list[float] | None:
        if value is None:
            return None
        normalized = [float(item) for item in value]
        if len(normalized) != KNOWLEDGE_EMBEDDING_DIMENSIONS:
            raise ValueError(
                "visual region embedding dimension mismatch: "
                f"expected {KNOWLEDGE_EMBEDDING_DIMENSIONS}, received {len(normalized)}"
            )
        if not all(math.isfinite(item) for item in normalized):
            raise ValueError("visual region embedding contains non-finite values")
        return normalized

    @field_validator("embedding_model")
    @classmethod
    def normalize_embedding_model(cls, value: str) -> str:
        return value.strip()

    @field_validator(
        "reviewed_at",
        "approved_at",
        "last_observed_at",
        "last_success_at",
        "last_failure_at",
        "created_at",
        "updated_at",
    )
    @classmethod
    def normalize_time(cls, value: datetime | None) -> datetime | None:
        return _utc(value)

    @model_validator(mode="after")
    def validate_profile(self) -> Self:
        if self.version == 1 and self.supersedes_profile_id is not None:
            raise ValueError("a first visual profile cannot supersede another")
        if self.version > 1 and self.supersedes_profile_id is None:
            raise ValueError("visual profile revisions require a predecessor")
        if self.supersedes_profile_id == self.profile_id:
            raise ValueError("a visual profile cannot supersede itself")
        if self.exact_fingerprint != self.topology.exact_fingerprint():
            raise ValueError("fingerprint does not match visual topology")
        if self.embedding is None:
            if self.embedding_model or self.embedding_dimensions:
                raise ValueError("embedding identity requires an embedding")
        else:
            if not self.embedding_model:
                raise ValueError("visual embeddings require a model identity")
            if self.embedding_dimensions not in {0, len(self.embedding)}:
                raise ValueError(
                    "embedding identity dimensions do not match the vector"
                )
        if self.success_count + self.failure_count != self.observation_count:
            raise ValueError("visual observation counters are inconsistent")
        if self.status is VisualRegionProfileStatus.ACTIVE:
            if (
                not self.reviewed_by
                or self.reviewed_at is None
                or not self.review_note.strip()
            ):
                raise ValueError("active visual profiles require review metadata")
            if not self.approved_by or self.approved_at is None:
                raise ValueError("active visual profiles require approval metadata")
            if self.reviewed_by.casefold() == self.approved_by.casefold():
                raise ValueError("active visual profiles require independent approval")
            if self.success_count < 3 or self.failure_count:
                raise ValueError("active visual profiles require three clean samples")
        return self

    def as_similar_case(
        self,
        *,
        query_topology: VisualRegionTopology,
        vector_similarity: float | None,
    ) -> VisualRegionSimilarCase:
        return VisualRegionSimilarCase(
            case_id=self.profile_id,
            asset_sha256=self.asset_sha256,
            role=self.role,
            source_kind=self.topology.source_kind,
            active=self.status is VisualRegionProfileStatus.ACTIVE,
            vector_similarity=vector_similarity,
            geometry_similarity=visual_topology_similarity(
                query_topology,
                self.topology,
            ),
            review_success_rate=(
                self.success_count / self.observation_count
                if self.observation_count
                else 0.0
            ),
        )

    def as_exact_case(self) -> VisualRegionExactCase:
        if self.status is not VisualRegionProfileStatus.ACTIVE:
            raise ValueError("only an active visual profile is an exact case")
        return VisualRegionExactCase(
            case_id=self.profile_id,
            tenant_id=self.tenant_id,
            exact_fingerprint=self.exact_fingerprint,
            asset_sha256=self.asset_sha256,
            topology=self.topology,
            role=self.role,
            active=True,
            observation_count=self.observation_count,
            success_count=self.success_count,
            failure_count=0,
            review_success_rate=(
                self.success_count / self.observation_count
                if self.observation_count
                else 0.0
            ),
        )


class VisualRegionObservationRecord(KnowledgeSchema):
    observation_id: str = Field(default_factory=new_id, min_length=1, max_length=128)
    tenant_id: str = Field(min_length=1, max_length=128)
    profile_id: str = Field(min_length=1, max_length=128)
    idempotency_key: str = Field(min_length=1, max_length=256)
    exact_fingerprint: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    task_reference_hash: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    outcome: VisualRegionObservationOutcome
    validation_passed: bool
    reviewed_by: str = Field(default="", max_length=256)
    review_note_sha256: str = Field(default="", max_length=64)
    latency_ms: int = Field(default=0, ge=0)
    error_code: str = Field(default="", max_length=128)
    observed_at: datetime = Field(default_factory=utc_now)

    @field_validator("exact_fingerprint", "task_reference_hash", "review_note_sha256")
    @classmethod
    def normalize_hashes(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("error_code")
    @classmethod
    def normalize_error(cls, value: str) -> str:
        normalized = value.strip().casefold()
        if normalized and _SAFE_ID.fullmatch(normalized) is None:
            raise ValueError("visual error_code must be a stable token")
        return normalized

    @field_validator("observed_at")
    @classmethod
    def normalize_observed_at(cls, value: datetime) -> datetime:
        return _utc(value) or utc_now()

    @model_validator(mode="after")
    def validate_observation(self) -> Self:
        if self.outcome is VisualRegionObservationOutcome.SUCCESS:
            if not self.validation_passed:
                raise ValueError("successful visual samples must pass validation")
            if not self.reviewed_by.strip():
                raise ValueError("successful visual samples require a reviewer")
            if re.fullmatch(r"[0-9a-f]{64}", self.review_note_sha256) is None:
                raise ValueError("successful visual samples require a review-note hash")
        elif not self.error_code:
            raise ValueError("failed visual samples require an error code")
        return self


__all__ = [
    "VisualRegionObservationOutcome",
    "VisualRegionObservationRecord",
    "VisualRegionProfileRecord",
    "VisualRegionProfileStatus",
]
