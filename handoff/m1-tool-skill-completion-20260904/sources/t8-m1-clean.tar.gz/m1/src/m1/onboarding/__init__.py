"""Read-only source discovery and onboarding preparation for M1."""

from .catalog import (
    CatalogManifest,
    CatalogOptions,
    CatalogRecord,
    scan_catalog,
    write_csv_manifest,
    write_json_manifest,
)

__all__ = [
    "CatalogManifest",
    "CatalogOptions",
    "CatalogRecord",
    "scan_catalog",
    "write_csv_manifest",
    "write_json_manifest",
]
