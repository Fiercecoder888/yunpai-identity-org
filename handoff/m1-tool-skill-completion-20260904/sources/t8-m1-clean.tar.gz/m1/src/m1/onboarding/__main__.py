"""Command line entry point for ``python -m m1.onboarding``."""

from .catalog import main

raise SystemExit(main())
