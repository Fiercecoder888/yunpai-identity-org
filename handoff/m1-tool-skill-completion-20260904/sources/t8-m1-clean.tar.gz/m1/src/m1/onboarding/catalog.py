"""Deterministic, read-only inventory for customer historical data.

The catalog is deliberately separate from ingestion.  It discovers source
assets, securely inspects archive members, selects representative references,
and emits manifests; it never submits a document to the M1 workflow and never
copies a production payload into the repository.

Privacy defaults are intentionally conservative:

* source paths are relative to the requested root;
* document contents and extracted text are never written to the manifest;
* ordinary files are streamed in chunks for SHA-256 and only a small prefix is
  used for type detection;
* archive members are expanded into an OS temporary directory solely to apply
  M1's existing security limits, calculate hashes, and detect types.  The
  temporary directory is removed before this function returns.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import tempfile
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Iterator, Sequence

from m1.documents.adapters.archive import (
    ArchiveLimits,
    UnsupportedArchiveError,
    detect_archive_type,
    extract_archive,
    repair_display_filename,
)
from m1.documents.magic import FileTypeInfo, sniff_file_type


CATALOG_SCHEMA_VERSION = "m1.data_catalog.v1"
_HASH_CHUNK_SIZE = 4 * 1024 * 1024
_COMPOUND_EXTENSIONS = (
    ".tar.gz",
    ".tar.bz2",
    ".tar.xz",
    ".tbz2",
    ".txz",
    ".tgz",
)
_EXTENSION_TYPES: dict[str, str] = {
    ".pdf": "pdf",
    ".xlsx": "xlsx",
    ".xlsm": "xlsm",
    ".xls": "xls",
    ".csv": "csv",
    ".tsv": "csv",
    ".docx": "docx",
    ".dxf": "dxf",
    ".dwg": "dwg",
    ".jpg": "image",
    ".jpeg": "image",
    ".png": "image",
    ".gif": "image",
    ".bmp": "image",
    ".tif": "image",
    ".tiff": "image",
    ".webp": "image",
    ".zip": "archive",
    ".tar": "archive",
    ".tar.gz": "archive",
    ".tar.bz2": "archive",
    ".tar.xz": "archive",
    ".tgz": "archive",
    ".tbz2": "archive",
    ".txz": "archive",
    ".rar": "archive",
    ".7z": "archive",
}
_ARCHIVE_MAGIC_TYPES = {"zip", "rar", "7z", "tar"}
_MIME_BY_KIND = {
    "archive": "application/octet-stream",
    "tar": "application/x-tar",
    "dxf": "image/vnd.dxf",
    "dwg": "image/vnd.dwg",
}


@dataclass(frozen=True, slots=True)
class CatalogOptions:
    """Resource and output policy for one catalog pass."""

    hash_files: bool = True
    include_archive_members: bool = True
    sample_per_type: int = 3
    hash_chunk_size: int = _HASH_CHUNK_SIZE
    archive_limits: ArchiveLimits = field(default_factory=ArchiveLimits)

    def __post_init__(self) -> None:
        if self.sample_per_type < 0:
            raise ValueError("sample_per_type cannot be negative")
        if self.hash_chunk_size <= 0:
            raise ValueError("hash_chunk_size must be positive")


@dataclass(slots=True)
class CatalogRecord:
    """One physical source, archive member, or auditable discovery issue."""

    record_id: str
    record_kind: str
    source_path: str
    archive_path: str | None
    original_name: str
    display_name: str
    extension: str
    extension_type: str
    magic_type: str
    effective_type: str
    type_basis: str
    type_match: str
    mime_type: str
    size_bytes: int | None
    compressed_size_bytes: int | None
    sha256: str | None
    depth: int
    status: str
    failure_code: str | None = None
    failure_reason: str | None = None
    duplicate_of: str | None = None
    is_duplicate: bool = False
    is_sample: bool = False
    sample_rank: int | None = None

    @property
    def logical_path(self) -> str:
        return self.archive_path or self.source_path

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CatalogManifest:
    """Stable catalog output; unchanged inputs produce byte-identical JSON."""

    catalog_id: str
    source_name: str
    scan_policy: dict[str, Any]
    statistics: dict[str, Any]
    samples: dict[str, list[dict[str, Any]]]
    records: list[CatalogRecord]
    schema_version: str = CATALOG_SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "catalog_id": self.catalog_id,
            "source_name": self.source_name,
            "scan_policy": self.scan_policy,
            "statistics": self.statistics,
            "samples": self.samples,
            "records": [record.to_dict() for record in self.records],
        }

    def to_json(self) -> str:
        return json.dumps(
            self.to_dict(),
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n"


@dataclass(frozen=True, slots=True)
class _WalkIssue:
    path: Path
    record_kind: str
    code: str
    reason: str


def _sha256_file(path: Path, chunk_size: int) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _extension(name: str) -> str:
    lowered = name.casefold()
    for suffix in _COMPOUND_EXTENSIONS:
        if lowered.endswith(suffix):
            return suffix
    return Path(PurePosixPath(name).name).suffix.casefold()


def _extension_type(extension: str) -> str:
    return _EXTENSION_TYPES.get(extension, "unknown")


def _normalize_magic_kind(kind: str) -> str:
    return "archive" if kind in _ARCHIVE_MAGIC_TYPES else kind


def _type_match(extension_kind: str, magic_kind: str) -> str:
    if extension_kind == "unknown" or magic_kind == "unknown":
        return "unverified"
    return "match" if extension_kind == _normalize_magic_kind(magic_kind) else "mismatch"


def _detect_file_type(path: Path) -> tuple[FileTypeInfo, bool]:
    """Return magic information and whether the payload is an archive."""

    detected = sniff_file_type(path)
    if detected.kind in _ARCHIVE_MAGIC_TYPES:
        return detected, True
    if detected.kind != "unknown":
        return detected, False

    # TAR does not have one fixed prefix.  The existing archive adapter performs
    # a bounded format probe and remains the source of truth for it.
    try:
        archive_kind = detect_archive_type(path)
    except UnsupportedArchiveError:
        # Unsupported magic is the normal result for non-archive files.  Decoder
        # and filesystem errors are re-raised so the manifest can report them.
        pass
    else:
        return FileTypeInfo(
            archive_kind,
            _MIME_BY_KIND.get(archive_kind, "application/octet-stream"),
            _extension(path.name) or None,
        ), True

    # M1's central magic helper intentionally focuses on production documents.
    # Add the two CAD signatures already supported by ParserRouter without
    # trusting an arbitrary binary extension.
    with path.open("rb") as stream:
        prefix = stream.read(64 * 1024)
    if prefix.startswith(b"AC10"):
        return FileTypeInfo("dwg", _MIME_BY_KIND["dwg"], ".dwg"), False
    if b"\x00" not in prefix:
        try:
            ascii_text = prefix.decode("ascii", errors="strict").upper()
        except UnicodeDecodeError:
            ascii_text = ""
        if "SECTION" in ascii_text and ("HEADER" in ascii_text or "ENTITIES" in ascii_text):
            return FileTypeInfo("dxf", _MIME_BY_KIND["dxf"], ".dxf"), False
    return detected, False


def _ignored_name(name: str, *, is_directory: bool) -> str | None:
    if is_directory and name == "__MACOSX":
        return "macos_metadata"
    if name == ".DS_Store" or name.startswith("._"):
        return "apple_metadata"
    return None


def _walk(root: Path, excluded: set[Path]) -> Iterator[Path | _WalkIssue]:
    """Walk without following links and preserve failures as catalog records."""

    if root.is_file():
        if root.resolve(strict=False) not in excluded:
            yield root
        return
    stack = [root]
    while stack:
        directory = stack.pop()
        try:
            with os.scandir(directory) as iterator:
                entries = sorted(list(iterator), key=lambda item: item.name.casefold())
        except OSError as exc:
            yield _WalkIssue(
                directory,
                "directory_issue",
                "directory_unreadable",
                f"{exc.__class__.__name__}: {exc}",
            )
            continue
        child_directories: list[Path] = []
        for entry in entries:
            path = Path(entry.path)
            if path.resolve(strict=False) in excluded:
                continue
            try:
                if entry.is_symlink():
                    yield _WalkIssue(
                        path,
                        "source_issue",
                        "symlink_skipped",
                        "Symbolic links are not followed during source discovery.",
                    )
                    continue
                is_directory = entry.is_dir(follow_symlinks=False)
                ignored = _ignored_name(entry.name, is_directory=is_directory)
                if ignored:
                    yield _WalkIssue(
                        path,
                        "directory_issue" if is_directory else "source_issue",
                        ignored,
                        "Platform metadata is excluded from ingestion candidates.",
                    )
                    continue
                if is_directory:
                    child_directories.append(path)
                elif entry.is_file(follow_symlinks=False):
                    yield path
                else:
                    yield _WalkIssue(
                        path,
                        "source_issue",
                        "non_regular_file",
                        "Only regular files are cataloged.",
                    )
            except OSError as exc:
                yield _WalkIssue(
                    path,
                    "source_issue",
                    "source_stat_failed",
                    f"{exc.__class__.__name__}: {exc}",
                )
        # Reverse push preserves ascending traversal order.
        stack.extend(reversed(child_directories))


def _relative_path(path: Path, root: Path) -> str:
    if root.is_file():
        return root.name
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.name


def _sanitize_failure(reason: object, root: Path, temporary: Path | None = None) -> str:
    text = str(reason).replace(str(root), "<source>")
    if temporary is not None:
        text = text.replace(str(temporary), "<temporary>")
    return text[:1000]


def _stable_record_id(logical_path: str, digest: str | None, size: int | None) -> str:
    identity = f"{logical_path}\0{digest or '-'}\0{size if size is not None else '-'}"
    return "rec_" + hashlib.sha256(identity.encode("utf-8", errors="surrogatepass")).hexdigest()[:24]


class _CatalogBuilder:
    def __init__(self, root: Path, options: CatalogOptions) -> None:
        self.root = root
        self.options = options
        self.records: list[CatalogRecord] = []
        self._content_first_seen: dict[str, str] = {}

    def add(self, record: CatalogRecord) -> None:
        if record.sha256:
            first = self._content_first_seen.get(record.sha256)
            if first is None:
                self._content_first_seen[record.sha256] = record.record_id
            else:
                record.is_duplicate = True
                record.duplicate_of = first
        self.records.append(record)

    def issue_record(self, issue: _WalkIssue) -> CatalogRecord:
        source_path = _relative_path(issue.path, self.root)
        return CatalogRecord(
            record_id=_stable_record_id(source_path, None, None),
            record_kind=issue.record_kind,
            source_path=source_path,
            archive_path=None,
            original_name=issue.path.name,
            display_name=issue.path.name,
            extension=_extension(issue.path.name),
            extension_type=_extension_type(_extension(issue.path.name)),
            magic_type="unknown",
            effective_type="unknown",
            type_basis="none",
            type_match="unverified",
            mime_type="application/octet-stream",
            size_bytes=None,
            compressed_size_bytes=None,
            sha256=None,
            depth=0,
            status="skipped" if issue.code in {
                "symlink_skipped",
                "macos_metadata",
                "apple_metadata",
                "non_regular_file",
            } else "failed",
            failure_code=issue.code,
            failure_reason=_sanitize_failure(issue.reason, self.root),
        )

    def source_record(self, path: Path) -> tuple[CatalogRecord, bool]:
        source_path = _relative_path(path, self.root)
        extension = _extension(path.name)
        extension_kind = _extension_type(extension)
        size: int | None = None
        digest: str | None = None
        detected = FileTypeInfo("unknown", "application/octet-stream")
        is_archive = False
        failures: list[tuple[str, str]] = []
        try:
            size = path.stat().st_size
        except OSError as exc:
            failures.append(("source_stat_failed", f"{exc.__class__.__name__}: {exc}"))
        if size is not None and self.options.hash_files:
            try:
                digest = _sha256_file(path, self.options.hash_chunk_size)
            except OSError as exc:
                failures.append(("source_hash_failed", f"{exc.__class__.__name__}: {exc}"))
        if size is not None:
            try:
                detected, is_archive = _detect_file_type(path)
            except Exception as exc:
                failures.append(("type_detection_failed", f"{exc.__class__.__name__}: {exc}"))
        magic_kind = detected.kind
        effective_kind = _normalize_magic_kind(magic_kind)
        type_basis = "magic"
        if effective_kind == "unknown":
            effective_kind = extension_kind
            type_basis = "extension" if extension_kind != "unknown" else "none"
        logical_path = source_path
        status = "ok" if not failures else ("partial" if size is not None else "failed")
        failure_code = failures[0][0] if failures else None
        failure_reason = "; ".join(reason for _, reason in failures) or None
        record = CatalogRecord(
            record_id=_stable_record_id(logical_path, digest, size),
            record_kind="source_archive" if is_archive else "source_file",
            source_path=source_path,
            archive_path=None,
            original_name=path.name,
            display_name=repair_display_filename(path.name),
            extension=extension,
            extension_type=extension_kind,
            magic_type=magic_kind,
            effective_type=effective_kind,
            type_basis=type_basis,
            type_match=_type_match(extension_kind, magic_kind),
            mime_type=detected.mime_type,
            size_bytes=size,
            compressed_size_bytes=None,
            sha256=digest,
            depth=0,
            status=status,
            failure_code=failure_code,
            failure_reason=(
                _sanitize_failure(failure_reason, self.root) if failure_reason else None
            ),
        )
        return record, is_archive

    def archive_records(self, source: Path, destination: Path, result: Any) -> None:
        source_path = _relative_path(source, self.root)
        source_parent = PurePosixPath(source_path).parent
        locator_occurrences: Counter[str] = Counter()
        for entry in result.entries:
            archive_label = str(entry.archive_path).replace("\\", "/")
            if source_parent != PurePosixPath("."):
                archive_label = (source_parent / archive_label).as_posix()
            normalized_entry_name = str(entry.raw_name).replace("\\", "/")
            logical_path = f"{archive_label}!/{normalized_entry_name}"
            locator_occurrences[logical_path] += 1
            if locator_occurrences[logical_path] > 1:
                logical_path = (
                    f"{logical_path}#occurrence={locator_occurrences[logical_path]}"
                )
            extension = _extension(entry.raw_name)
            extension_kind = _extension_type(extension)
            physical: Path | None = None
            if entry.stored_relative_path:
                physical = destination / entry.stored_relative_path
            elif entry.duplicate_of:
                physical = destination / entry.duplicate_of
            detected = FileTypeInfo("unknown", "application/octet-stream")
            detection_failure: str | None = None
            if physical is not None and physical.is_file():
                try:
                    detected, _ = _detect_file_type(physical)
                except Exception as exc:
                    detection_failure = f"{exc.__class__.__name__}: {exc}"
            magic_kind = detected.kind
            effective_kind = _normalize_magic_kind(magic_kind)
            type_basis = "magic"
            if effective_kind == "unknown":
                effective_kind = extension_kind
                type_basis = "extension" if extension_kind != "unknown" else "none"
            status = "ok"
            failure_code: str | None = None
            failure_reason: str | None = None
            if entry.ignored:
                status = "skipped"
                failure_code = entry.ignore_reason or "archive_member_ignored"
                failure_reason = "Archive metadata is excluded from ingestion candidates."
            elif detection_failure:
                status = "partial"
                failure_code = "type_detection_failed"
                failure_reason = _sanitize_failure(
                    detection_failure, self.root, temporary=destination
                )
            record_kind = "archive_container" if entry.nested_archive else "archive_member"
            digest = entry.sha256 if self.options.hash_files else None
            record = CatalogRecord(
                record_id=_stable_record_id(logical_path, digest, int(entry.size)),
                record_kind=record_kind,
                source_path=source_path,
                archive_path=logical_path,
                original_name=entry.raw_name,
                display_name=entry.display_name,
                extension=extension,
                extension_type=extension_kind,
                magic_type=magic_kind,
                effective_type=("archive" if entry.nested_archive else effective_kind),
                type_basis=type_basis,
                type_match=_type_match(extension_kind, magic_kind),
                mime_type=detected.mime_type,
                size_bytes=int(entry.size),
                compressed_size_bytes=(
                    int(entry.compressed_size)
                    if entry.compressed_size is not None
                    else None
                ),
                sha256=digest,
                depth=int(entry.depth) + 1,
                status=status,
                failure_code=failure_code,
                failure_reason=failure_reason,
            )
            self.add(record)


def _select_samples(records: list[CatalogRecord], sample_per_type: int) -> dict[str, list[dict[str, Any]]]:
    """Select stable size-stratified references without copying source files."""

    if sample_per_type <= 0:
        return {}
    candidates: dict[str, list[CatalogRecord]] = {}
    for record in records:
        if (
            record.status != "ok"
            or record.is_duplicate
            or record.effective_type in {"archive", "unknown"}
            or record.record_kind.endswith("issue")
        ):
            continue
        candidates.setdefault(record.effective_type, []).append(record)
    result: dict[str, list[dict[str, Any]]] = {}
    for kind in sorted(candidates):
        ordered = sorted(
            candidates[kind],
            key=lambda item: (item.size_bytes or 0, item.logical_path.casefold(), item.record_id),
        )
        take = min(sample_per_type, len(ordered))
        if take == len(ordered):
            indices = list(range(len(ordered)))
        elif take == 1:
            indices = [len(ordered) // 2]
        else:
            indices = [round(index * (len(ordered) - 1) / (take - 1)) for index in range(take)]
        selected: list[dict[str, Any]] = []
        for rank, index in enumerate(indices, start=1):
            record = ordered[index]
            record.is_sample = True
            record.sample_rank = rank
            selected.append(
                {
                    "record_id": record.record_id,
                    "source_path": record.source_path,
                    "archive_path": record.archive_path,
                    "size_bytes": record.size_bytes,
                    "sha256": record.sha256,
                    "sample_rank": rank,
                }
            )
        result[kind] = selected
    return result


def _statistics(records: Sequence[CatalogRecord]) -> dict[str, Any]:
    physical = [record for record in records if record.record_kind.startswith("source_")]
    digests = {record.sha256 for record in records if record.sha256}
    candidates = [
        record
        for record in records
        if record.status == "ok"
        and not record.is_duplicate
        and record.effective_type not in {"archive", "unknown"}
        and record.record_kind in {"source_file", "archive_member"}
    ]
    return {
        "record_count": len(records),
        "physical_source_count": sum(
            record.record_kind in {"source_file", "source_archive"} for record in records
        ),
        "archive_source_count": sum(record.record_kind == "source_archive" for record in records),
        "archive_container_count": sum(record.record_kind == "archive_container" for record in records),
        "archive_member_count": sum(record.record_kind == "archive_member" for record in records),
        "physical_source_bytes": sum(record.size_bytes or 0 for record in physical),
        "visible_member_bytes": sum(
            record.size_bytes or 0
            for record in records
            if record.record_kind in {"archive_member", "archive_container"}
        ),
        "unique_sha256_count": len(digests),
        "ingestion_candidate_count": len(candidates),
        "ingestion_candidate_type_counts": dict(
            sorted(Counter(record.effective_type for record in candidates).items())
        ),
        "duplicate_count": sum(record.is_duplicate for record in records),
        "sample_count": sum(record.is_sample for record in records),
        "type_mismatch_count": sum(record.type_match == "mismatch" for record in records),
        "failure_count": sum(record.status == "failed" for record in records),
        "partial_count": sum(record.status == "partial" for record in records),
        "skipped_count": sum(record.status == "skipped" for record in records),
        "status_counts": dict(sorted(Counter(record.status for record in records).items())),
        "extension_counts": dict(sorted(Counter(record.extension or "<none>" for record in records).items())),
        "magic_type_counts": dict(sorted(Counter(record.magic_type for record in records).items())),
        "effective_type_counts": dict(sorted(Counter(record.effective_type for record in records).items())),
        "failure_code_counts": dict(
            sorted(Counter(record.failure_code for record in records if record.failure_code).items())
        ),
    }


def _scan_policy(options: CatalogOptions, excluded_paths: Iterable[Path], root: Path) -> dict[str, Any]:
    excluded_relative = sorted(
        {
            _relative_path(path, root)
            for path in excluded_paths
            if root.is_dir() and path.resolve(strict=False).is_relative_to(root.resolve(strict=False))
        }
    )
    limits = options.archive_limits
    return {
        "hash_algorithm": "sha256" if options.hash_files else "disabled",
        "hash_chunk_size": options.hash_chunk_size if options.hash_files else None,
        "include_archive_members": options.include_archive_members,
        "sample_per_type": options.sample_per_type,
        "relative_paths_only": True,
        "source_mutation": "none",
        "content_retention": "none",
        "content_read_policy": (
            "stream_full_payload_only_for_sha256_or_archive_verification"
            if options.hash_files
            else "ordinary_file_type_prefix;archive_members_streamed_for_security_then_discarded"
        ),
        "excluded_output_paths": excluded_relative,
        "archive_limits": {
            "max_archive_size": limits.max_archive_size,
            "max_total_uncompressed": limits.max_total_uncompressed,
            "max_single_file": limits.max_single_file,
            "max_entries": limits.max_entries,
            "max_compression_ratio": limits.max_compression_ratio,
            "max_recursion_depth": limits.max_recursion_depth,
        },
    }


def scan_catalog(
    source: str | Path,
    *,
    options: CatalogOptions | None = None,
    exclude_paths: Iterable[str | Path] = (),
) -> CatalogManifest:
    """Catalog a file or directory without modifying or ingesting its contents."""

    root = Path(source).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(root)
    if not (root.is_file() or root.is_dir()):
        raise ValueError(f"Source must be a regular file or directory: {root}")
    active = options or CatalogOptions()
    excluded = {Path(path).expanduser().resolve(strict=False) for path in exclude_paths}
    builder = _CatalogBuilder(root, active)
    for item in _walk(root, excluded):
        if isinstance(item, _WalkIssue):
            builder.add(builder.issue_record(item))
            continue
        record, is_archive = builder.source_record(item)
        builder.add(record)
        if not (is_archive and active.include_archive_members):
            continue
        temporary_path: Path | None = None
        try:
            with tempfile.TemporaryDirectory(prefix="m1-data-catalog-") as temporary:
                temporary_path = Path(temporary)
                destination = temporary_path / "contents"
                result = extract_archive(item, destination, active.archive_limits)
                builder.archive_records(item, destination, result)
        except Exception as exc:
            record.status = "partial"
            record.failure_code = "archive_inventory_failed"
            record.failure_reason = _sanitize_failure(
                f"{exc.__class__.__name__}: {exc}", root, temporary=temporary_path
            )
    builder.records.sort(key=lambda item: (item.logical_path.casefold(), item.record_kind, item.record_id))
    samples = _select_samples(builder.records, active.sample_per_type)
    statistics = _statistics(builder.records)
    policy = _scan_policy(active, excluded, root)
    identity_payload = {
        "schema_version": CATALOG_SCHEMA_VERSION,
        "source_name": root.name,
        "scan_policy": policy,
        "records": [record.to_dict() for record in builder.records],
    }
    catalog_id = "cat_" + hashlib.sha256(
        json.dumps(identity_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:24]
    return CatalogManifest(
        catalog_id=catalog_id,
        source_name=root.name,
        scan_policy=policy,
        statistics=statistics,
        samples=samples,
        records=builder.records,
    )


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    try:
        temporary.write_text(content, encoding="utf-8", newline="")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write_json_manifest(manifest: CatalogManifest, path: str | Path) -> Path:
    destination = Path(path)
    _atomic_write(destination, manifest.to_json())
    return destination


_CSV_FIELDS = (
    "record_id",
    "record_kind",
    "source_path",
    "archive_path",
    "original_name",
    "display_name",
    "extension",
    "extension_type",
    "magic_type",
    "effective_type",
    "type_basis",
    "type_match",
    "mime_type",
    "size_bytes",
    "compressed_size_bytes",
    "sha256",
    "depth",
    "status",
    "failure_code",
    "failure_reason",
    "duplicate_of",
    "is_duplicate",
    "is_sample",
    "sample_rank",
)


def write_csv_manifest(manifest: CatalogManifest, path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.tmp")
    try:
        with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=_CSV_FIELDS, extrasaction="ignore")
            writer.writeheader()
            for record in manifest.records:
                writer.writerow(record.to_dict())
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.onboarding",
        description="Build a deterministic, read-only M1 customer data catalog.",
    )
    parser.add_argument("source", help="Source file or directory to inventory")
    parser.add_argument("--json", dest="json_path", help="Write the full JSON manifest")
    parser.add_argument("--csv", dest="csv_path", help="Write the flat CSV manifest")
    parser.add_argument("--sample-per-type", type=int, default=3)
    parser.add_argument(
        "--metadata-only",
        action="store_true",
        help="Skip SHA-256 calculation for a faster preliminary pass",
    )
    parser.add_argument(
        "--no-archive-members",
        action="store_true",
        help="Catalog archive containers without expanding visible members",
    )
    parser.add_argument("--max-archive-size", type=int, default=ArchiveLimits().max_archive_size)
    parser.add_argument(
        "--max-total-uncompressed",
        type=int,
        default=ArchiveLimits().max_total_uncompressed,
    )
    parser.add_argument("--max-single-file", type=int, default=ArchiveLimits().max_single_file)
    parser.add_argument("--max-entries", type=int, default=ArchiveLimits().max_entries)
    parser.add_argument(
        "--max-compression-ratio",
        type=float,
        default=ArchiveLimits().max_compression_ratio,
    )
    parser.add_argument(
        "--max-recursion-depth",
        type=int,
        default=ArchiveLimits().max_recursion_depth,
    )
    parser.add_argument(
        "--fail-on-errors",
        action="store_true",
        help="Return exit code 2 when failed or partial records exist",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    outputs = [Path(path) for path in (args.json_path, args.csv_path) if path]
    excluded_outputs = [
        candidate
        for output in outputs
        for candidate in (output, output.with_name(f".{output.name}.tmp"))
    ]
    limits = ArchiveLimits(
        max_archive_size=args.max_archive_size,
        max_total_uncompressed=args.max_total_uncompressed,
        max_single_file=args.max_single_file,
        max_entries=args.max_entries,
        max_compression_ratio=args.max_compression_ratio,
        max_recursion_depth=args.max_recursion_depth,
    )
    manifest = scan_catalog(
        args.source,
        options=CatalogOptions(
            hash_files=not args.metadata_only,
            include_archive_members=not args.no_archive_members,
            sample_per_type=args.sample_per_type,
            archive_limits=limits,
        ),
        exclude_paths=excluded_outputs,
    )
    if args.json_path:
        write_json_manifest(manifest, args.json_path)
    if args.csv_path:
        write_csv_manifest(manifest, args.csv_path)
    print(
        json.dumps(
            {
                "schema_version": manifest.schema_version,
                "catalog_id": manifest.catalog_id,
                "source_name": manifest.source_name,
                "statistics": manifest.statistics,
                "json_manifest": args.json_path,
                "csv_manifest": args.csv_path,
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    if args.fail_on_errors and (
        manifest.statistics["failure_count"] or manifest.statistics["partial_count"]
    ):
        return 2
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised through package CLI
    raise SystemExit(main())


__all__ = [
    "CATALOG_SCHEMA_VERSION",
    "CatalogManifest",
    "CatalogOptions",
    "CatalogRecord",
    "main",
    "scan_catalog",
    "write_csv_manifest",
    "write_json_manifest",
]
