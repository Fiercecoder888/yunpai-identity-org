"""m1.document.v2 标准订单 Excel 导出。

导出文件是面向业务审核的可读副本；原始文件和 document JSON 始终是事实来源。
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def export_order_workbook(document: dict[str, Any], destination: str | Path) -> Path:
    """将订单文档导出为四 Sheet 标准工作簿。"""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError as exc:  # pragma: no cover - 部署依赖检查
        raise RuntimeError("导出订单 Excel 需要安装 openpyxl") from exc

    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws_header = wb.active
    ws_header.title = "订单头"
    ws_lines = wb.create_sheet("产品明细")
    ws_issues = wb.create_sheet("校验问题")
    ws_evidence = wb.create_sheet("原始证据")

    navy = "1F4E78"
    blue = "D9EAF7"
    amber = "FFF2CC"
    red = "FCE4D6"
    white = "FFFFFF"
    light_border = Border(bottom=Side(style="thin", color="D9E2F3"))
    header_fill = PatternFill("solid", fgColor=navy)
    section_fill = PatternFill("solid", fgColor=blue)
    wrap = Alignment(vertical="top", wrap_text=True)

    def style_title(ws, title: str, end_col: int = 2) -> None:
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=end_col)
        cell = ws.cell(1, 1, title)
        cell.fill = header_fill
        cell.font = Font(color=white, bold=True, size=14)
        cell.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[1].height = 28
        ws.sheet_view.showGridLines = False

    def write_table_header(ws, row: int, columns: list[str]) -> None:
        for col, label in enumerate(columns, 1):
            cell = ws.cell(row, col, label)
            cell.fill = header_fill
            cell.font = Font(color=white, bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.row_dimensions[row].height = 30

    # ---- 订单头 ----
    style_title(ws_header, "标准化订单头")
    source = document.get("source") or {}
    header = document.get("header") or {}
    totals = document.get("totals") or {}
    header_rows: list[tuple[str, Any]] = [
        ("Schema", document.get("schema_version", "m1.document.v2")),
        ("文档类型", document.get("document_type")),
        ("文档子类型", document.get("document_subtype")),
        ("原始文件名", source.get("original_filename") or source.get("filename")),
        ("显示文件名", source.get("display_filename")),
        ("SHA-256", source.get("sha256") or source.get("content_hash")),
    ]
    for key, value in header.items():
        header_rows.append((_cell_value(str(key)), _cell_value(value)))
    for key, value in totals.items():
        header_rows.append((_cell_value(f"合计.{key}"), _cell_value(value)))
    for row, (label, value) in enumerate(header_rows, 3):
        ws_header.cell(row, 1, label).fill = section_fill
        ws_header.cell(row, 1).font = Font(bold=True)
        ws_header.cell(row, 2, _cell_value(value))
        ws_header.cell(row, 1).border = light_border
        ws_header.cell(row, 2).border = light_border
        ws_header.cell(row, 2).alignment = wrap
        ws_header.row_dimensions[row].height = 90 if label == "candidate_numbers" else 22
    ws_header.column_dimensions["A"].width = 26
    ws_header.column_dimensions["B"].width = 76
    ws_header.freeze_panes = "A3"

    # ---- 产品明细 ----
    line_columns = [
        "序号", "行ID", "型号", "产品编码", "原始名称", "标准名称", "完整产品名称", "产品类别",
        "规格", "线身印字", "颜色", "数量", "单位", "未税单价", "未税金额", "含税单价", "含税金额",
        "装箱数", "件数", "箱规", "体积", "包装要求", "产地", "备注", "图片引用", "名称属性",
        "自定义字段", "原始列", "行置信度",
    ]
    style_title(ws_lines, "完整产品订单表", len(line_columns))
    write_table_header(ws_lines, 2, line_columns)
    lines = document.get("lines") or []
    aliases = [
        ("line_no", "index"), ("line_id",), ("model",), ("product_code", "code"),
        ("name_raw", "name"), ("name_normalized",), ("full_product_name",), ("product_category",),
        ("specification_raw", "specification", "spec"), ("body_printing", "line_printing"), ("color",),
        ("quantity",), ("unit",), ("unit_price_tax_excluded", "unit_price_ex_tax", "unit_price"),
        ("amount_tax_excluded", "amount_ex_tax", "amount"),
        ("unit_price_tax_included",), ("amount_tax_included",),
        ("package_quantity", "packing_quantity", "carton_count"),
        ("piece_count", "pieces_per_carton"), ("carton_specification", "carton_spec"), ("volume",),
        ("packaging_requirements",),
        ("origin",), ("remark", "remarks"), ("image_refs",), ("name_attributes",), ("custom_fields",),
        ("raw_columns",), ("confidence", "line_confidence"),
    ]
    for row_index, line in enumerate(lines, 3):
        line = line if isinstance(line, dict) else {"raw": line}
        for col_index, keys in enumerate(aliases, 1):
            value = _first(line, *keys)
            cell = ws_lines.cell(row_index, col_index, _cell_value(value))
            cell.alignment = wrap
            cell.border = light_border
        # 长 JSON 仍完整保存在单元格中，但不让它把整行撑到数百像素。
        for col_index in (25, 26, 27, 28):
            ws_lines.cell(row_index, col_index).alignment = Alignment(
                vertical="top", wrap_text=False
            )
        ws_lines.row_dimensions[row_index].height = 72
        ws_lines.cell(row_index, 12).number_format = "#,##0.###"
        for col in (14, 15, 16, 17):
            ws_lines.cell(row_index, col).number_format = "#,##0.00"
    total_row = 3 + len(lines)
    ws_lines.cell(total_row, 1, "合计")
    ws_lines.cell(total_row, 1).font = Font(bold=True)
    if lines:
        ws_lines.cell(total_row, 12, f"=SUM(L3:L{total_row - 1})")
    else:
        ws_lines.cell(total_row, 12, 0)
    ws_lines.cell(total_row, 12).number_format = "#,##0.###"
    ws_lines.cell(total_row, 12).font = Font(bold=True)
    ws_lines.auto_filter.ref = f"A2:{get_column_letter(len(line_columns))}{max(total_row - 1, 2)}"
    ws_lines.freeze_panes = "E3"
    ws_lines.print_title_rows = "1:2"
    ws_lines.page_setup.orientation = "landscape"
    ws_lines.page_setup.fitToWidth = 1
    ws_lines.sheet_properties.pageSetUpPr.fitToPage = True
    widths = [8, 14, 16, 16, 40, 30, 52, 18, 18, 30, 14, 12, 10, 14, 14, 14, 14, 12, 10, 14, 12, 28, 14, 34, 30, 52, 42, 42, 12]
    for index, width in enumerate(widths, 1):
        ws_lines.column_dimensions[get_column_letter(index)].width = width

    # ---- 校验问题 ----
    issue_columns = ["代码", "严重度", "说明", "字段路径", "来源证据", "期望值", "实际值", "处理建议", "状态"]
    style_title(ws_issues, "校验问题", len(issue_columns))
    write_table_header(ws_issues, 2, issue_columns)
    issues = document.get("validation_issues") or []
    for row_index, issue in enumerate(issues, 3):
        issue = issue if isinstance(issue, dict) else {"message": str(issue)}
        values = [
            issue.get("code"), issue.get("severity"), issue.get("message"), issue.get("paths"),
            issue.get("source_refs"), issue.get("expected"), issue.get("actual"), issue.get("suggestion"),
            issue.get("status", "open"),
        ]
        for col_index, value in enumerate(values, 1):
            cell = ws_issues.cell(row_index, col_index, _cell_value(value))
            cell.alignment = wrap
            cell.border = light_border
        severity = str(issue.get("severity") or "").lower()
        if severity in {"error", "critical", "high"}:
            ws_issues.cell(row_index, 2).fill = PatternFill("solid", fgColor=red)
        elif severity in {"warning", "warn", "medium"}:
            ws_issues.cell(row_index, 2).fill = PatternFill("solid", fgColor=amber)
    ws_issues.freeze_panes = "A3"
    issue_widths = [22, 12, 50, 38, 46, 28, 28, 46, 12]
    for index, width in enumerate(issue_widths, 1):
        ws_issues.column_dimensions[get_column_letter(index)].width = width

    # ---- 原始证据 ----
    evidence_columns = ["JSONPath", "来源", "置信度", "合并继承", "推断", "原始值", "说明"]
    style_title(ws_evidence, "字段级原始证据", len(evidence_columns))
    write_table_header(ws_evidence, 2, evidence_columns)
    field_meta = document.get("field_meta") or {}
    if isinstance(field_meta, dict):
        evidence_items = list(field_meta.items())
    else:
        evidence_items = [(str(i), item) for i, item in enumerate(field_meta)]
    for row_index, (path, meta) in enumerate(evidence_items, 3):
        meta = meta if isinstance(meta, dict) else {"value": meta}
        values = [
            path, meta.get("source_refs") or meta.get("source_ref"), meta.get("confidence"),
            meta.get("inherited_from_merge") or meta.get("merged_inherited") or meta.get("is_merged_inherited", False),
            meta.get("inferred") or meta.get("is_inferred", False),
            meta.get("raw_value") or meta.get("value"), meta.get("note") or meta.get("reason"),
        ]
        for col_index, value in enumerate(values, 1):
            cell = ws_evidence.cell(row_index, col_index, _cell_value(value))
            cell.alignment = wrap
            cell.border = light_border
    ws_evidence.freeze_panes = "A3"
    for index, width in enumerate([42, 52, 12, 12, 10, 45, 50], 1):
        ws_evidence.column_dimensions[get_column_letter(index)].width = width

    # 文档元数据用于审计和消费者识别。
    wb.properties.title = "M1 标准化产品订单表"
    wb.properties.subject = str(document.get("document_subtype") or "order")
    wb.properties.creator = "M1 Document Intelligence"
    wb.save(destination)
    return destination


def _first(mapping: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        value = mapping.get(key)
        if value not in (None, ""):
            return value
    return None


def _cell_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    if isinstance(value, str):
        visible = value.lstrip(" \t\r\n")
        if visible.startswith(("=", "+", "-", "@")):
            # Source-controlled text must never become an executable workbook
            # formula.  Formulas generated by this exporter bypass _cell_value.
            return "'" + value
    return value
