"""CAD (DXF/DWG) parsing with a real DWG-to-DXF converter boundary.

抽取文本实体、标注实体、图框信息, 作为 VLM 的辅助上下文。
DWG is converted in an isolated temporary directory before ezdxf parsing.
"""
from __future__ import annotations

from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
from loguru import logger


def parse_dxf(file_path: str | Path) -> str:
    """
    用 ezdxf 解析 DXF, 提取关键信息。

    返回结构化文本, 包含:
      - 所有 TEXT/MTEXT 实体 (标题栏文字、技术要求等)
      - DIMENSION 实体的测量值
      - 图层统计
    """
    try:
        import ezdxf
    except ImportError:
        return f"[DXF: {Path(file_path).name}, ezdxf 未安装]"

    try:
        doc = ezdxf.readzip(str(file_path)) if str(file_path).endswith(".zip") else ezdxf.readfile(str(file_path))
    except Exception as e:
        logger.error(f"ezdxf 读取失败: {e}")
        return f"[DXF 解析失败: {e}]"

    msp = doc.modelspace()
    lines: list[str] = [f"# DXF 文件解析: {Path(file_path).name}"]

    # 1. 文本实体
    texts: list[str] = []
    for text in msp.query("TEXT MTEXT"):
        content = getattr(text.dxf, "text", None) or getattr(text, "text", "")
        if content:
            texts.append(content.strip())
    if texts:
        lines.append("\n## 文本内容:")
        lines.extend(f"- {t}" for t in texts[:200])  # 限 200 条防爆

    # 2. 标注实体
    dims: list[str] = []
    for dim in msp.query("DIMENSION"):
        try:
            measurement = dim.get_measurement() if hasattr(dim, "get_measurement") else None
            if measurement is not None:
                dims.append(f"{measurement:.3f}")
        except Exception:
            continue
    if dims:
        lines.append("\n## 尺寸标注值:")
        lines.extend(f"- {d}" for d in dims[:100])

    # 3. 图层
    layers = [layer.dxf.name for layer in doc.layers]
    if layers:
        lines.append(f"\n## 图层 ({len(layers)} 个): " + ", ".join(layers[:20]))

    return "\n".join(lines)


def _dwg_command(
    source: Path,
    output: Path,
    *,
    command_template: str = "",
) -> tuple[list[str], str]:
    """Resolve a converter without invoking a command shell."""

    if command_template.strip():
        values = {
            "input": str(source),
            "output": str(output),
            "input_dir": str(source.parent),
            "output_dir": str(output.parent),
        }
        try:
            command = [
                token.format_map(values) for token in shlex.split(command_template)
            ]
        except (KeyError, ValueError) as exc:
            raise ValueError("invalid DWG converter command template") from exc
        if not command:
            raise ValueError("DWG converter command is empty")
        return command, "configured"

    dwgread = shutil.which("dwgread")
    if dwgread:
        # GNU LibreDWG supports explicit format and output paths.
        return [dwgread, "-O", "DXF", "-o", str(output), str(source)], "dwgread"
    dwg2dxf = shutil.which("dwg2dxf")
    if dwg2dxf:
        # dwg2dxf writes <stem>.dxf in cwd; parse_dwg runs it in output.parent.
        return [dwg2dxf, "--overwrite", str(source)], "dwg2dxf"
    raise FileNotFoundError(
        "no DWG converter found; install GNU LibreDWG or configure "
        "DWG_CONVERTER_COMMAND"
    )


def parse_dwg(
    file_path: str | Path,
    *,
    command_template: str = "",
    timeout_seconds: float = 120.0,
) -> str:
    """Convert one DWG to DXF and return the same structured CAD context."""

    source = Path(file_path).resolve()
    if not source.is_file():
        return f"[DWG conversion failed: source file not found: {source.name}]"
    try:
        with tempfile.TemporaryDirectory(prefix="m1-dwg-") as temp_dir:
            output = Path(temp_dir) / f"{source.stem}.dxf"
            command, converter = _dwg_command(
                source,
                output,
                command_template=command_template,
            )
            completed = subprocess.run(
                command,
                cwd=temp_dir,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(1.0, float(timeout_seconds)),
                check=False,
            )
            if completed.returncode != 0:
                detail = (completed.stderr or completed.stdout or "").strip()
                detail = " ".join(detail.split())[:500]
                raise RuntimeError(
                    f"{converter} exited with {completed.returncode}"
                    + (f": {detail}" if detail else "")
                )
            if not output.is_file() and converter == "dwg2dxf":
                candidates = sorted(Path(temp_dir).glob("*.dxf"))
                if candidates:
                    output = candidates[0]
            if not output.is_file() or output.stat().st_size == 0:
                raise RuntimeError(f"{converter} did not produce a DXF file")
            parsed = parse_dxf(output)
            return (
                f"# DWG 转换: {source.name} -> DXF ({converter})\n" + parsed
            )
    except subprocess.TimeoutExpired:
        logger.warning("DWG conversion timed out file={}", source.name)
        return f"[DWG conversion failed: converter timeout for {source.name}]"
    except Exception as exc:  # noqa: BLE001 - safe degraded parser context
        logger.warning(
            "DWG conversion failed file={} error_type={}",
            source.name,
            exc.__class__.__name__,
        )
        return f"[DWG conversion failed: {exc}]"


__all__ = ["parse_dwg", "parse_dxf"]
