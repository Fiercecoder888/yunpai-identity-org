"""文件类型路由: 按扩展名/MIME 分发到对应解析器。"""
from __future__ import annotations

import zipfile
from pathlib import Path
from loguru import logger


class ParserRouter:
    """根据文件类型选择解析器。"""

    IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}
    PDF_EXTS = {".pdf"}
    CAD_EXTS = {".dxf", ".dwg"}
    SPREADSHEET_EXTS = {".xlsx", ".xlsm", ".xls", ".csv"}
    DOCUMENT_EXTS = {".docx", ".pptx", ".html", ".htm"}

    def detect_type(self, file_path: str | Path) -> str:
        """识别文件类型。"""
        path = Path(file_path)
        ext = path.suffix.lower()
        sniffed = self._sniff_magic(path)
        if sniffed:
            return sniffed
        if ext in self.IMAGE_EXTS:
            return "image"
        if ext in self.PDF_EXTS:
            return "pdf"
        if ext in self.CAD_EXTS:
            return ext.lstrip(".")  # dxf / dwg
        if ext in self.SPREADSHEET_EXTS:
            return ext.lstrip(".")
        if ext in self.DOCUMENT_EXTS:
            return ext.lstrip(".")
        return "unknown"

    def _sniff_magic(self, path: Path) -> str:
        """按内容识别常见格式；无法读取时才由扩展名兜底。

        对已经存在但签名不匹配的二进制文件返回 ``unknown``，避免攻击者
        仅通过 ``.jpg`` / ``.pdf`` 扩展名把任意载荷送入图像解码或 VLM。
        """
        try:
            from ..documents.magic import sniff_file_type

            detected = sniff_file_type(path).kind
            if detected in {"zip", "rar", "7z"}:
                return "archive"
            if detected != "unknown":
                return detected
        except OSError:
            pass
        try:
            with path.open("rb") as stream:
                head = stream.read(64 * 1024)
        except OSError:
            return ""
        if head.startswith(b"%PDF-"):
            return "pdf"
        if head.startswith((b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff", b"GIF87a", b"GIF89a", b"BM")):
            return "image"
        if (
            (head.startswith(b"RIFF") and head[8:12] == b"WEBP")
            or head.startswith((b"II*\x00", b"MM\x00*"))
        ):
            return "image"
        if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
            return "xls"
        if head.startswith(b"PK\x03\x04"):
            try:
                with zipfile.ZipFile(path) as archive:
                    names = set(archive.namelist())
                if "xl/workbook.xml" in names:
                    return "xlsm" if path.suffix.lower() == ".xlsm" else "xlsx"
                if "word/document.xml" in names:
                    return "docx"
                if "ppt/presentation.xml" in names:
                    return "pptx"
                return "archive"
            except (OSError, zipfile.BadZipFile):
                return "unknown"
        if head.startswith(b"7z\xbc\xaf\x27\x1c"):
            return "archive"
        if head.startswith(b"Rar!\x1a\x07"):
            return "archive"
        if head.startswith(b"AC10"):
            return "dwg"
        ext = path.suffix.lower()
        if ext == ".csv" and b"\x00" not in head:
            for encoding in ("utf-8-sig", "gb18030"):
                try:
                    head.decode(encoding)
                    return "csv"
                except UnicodeDecodeError:
                    continue
        if ext == ".dxf" and b"\x00" not in head:
            try:
                text = head.decode("ascii", errors="strict").upper()
            except UnicodeDecodeError:
                text = ""
            if "SECTION" in text or "EOF" in text:
                return "dxf"
        return "unknown"

    async def parse(self, file_path: str | Path) -> str:
        """
        解析文件为可喂给 VLM 的文本/描述。

        - image/pdf: 本身就是视觉输入, 这里仅做预处理描述 (尺寸/页数)
        - dxf: 用 ezdxf 提取文本/标注, 作为 VLM 的辅助上下文
        - dwg: 转 dxf 后再解析 (回退路径)
        """
        from pathlib import Path as P

        fp = P(file_path)
        ftype = self.detect_type(fp)

        if ftype in ("image", "pdf"):
            # 视觉文件: 由 VLM 直接看图, parser 仅返回元信息
            return await self._parse_visual(fp, ftype)

        if ftype == "dxf":
            from .cad import parse_dxf

            return parse_dxf(fp)

        if ftype == "dwg":
            import asyncio

            from ..core.config import settings
            from .cad import parse_dwg

            return await asyncio.to_thread(
                parse_dwg,
                fp,
                command_template=settings.dwg_converter_command,
                timeout_seconds=settings.dwg_converter_timeout_seconds,
            )

        if ftype in {"xlsx", "xlsm", "xls", "csv", "docx", "pptx", "html"}:
            return f"[{ftype.upper()} document: {fp.name}; deterministic adapter required]"

        raise ValueError(f"不支持的文件类型: {fp.suffix}")

    async def _parse_visual(self, fp, ftype: str) -> str:
        """视觉文件 (图片/PDF) 的预处理。"""
        try:
            from PIL import Image

            if ftype == "image":
                with Image.open(fp) as img:
                    w, h = img.size
                    return f"[Image: {fp.name}, {w}x{h}px]"
        except Exception as e:  # Pillow 不可用时降级
            logger.debug(f"Pillow 读取失败, 降级: {e}")
        return f"[{ftype}: {fp.name}]"
