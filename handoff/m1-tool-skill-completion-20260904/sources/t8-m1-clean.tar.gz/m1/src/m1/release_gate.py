"""Fail-closed M1 release gate for the generic Deb deployment controller.

The process executes the authenticated enhanced preflight at most once for an
immutable release.  It then remains alive so Docker health, rather than process
restart policy, exposes the terminal pass/fail result to the deployment
controller.  State is stored in the existing M1 data volume so a container
restart cannot repeat the LightRAG lifecycle probe.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import hmac
import json
import os
import re
import tempfile
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

from .benchmarks.enhanced_preflight import request_preflight, save_report
from .enhanced_probe import LIGHTRAG_LIFECYCLE, PREFLIGHT_CAPABILITIES

_STATE_SCHEMA_VERSION = 1
_TERMINAL_STATES = frozenset({"passed", "failed"})
_UNKNOWN_RELEASES = frozenset({"", "unknown", "unset"})
_MAX_GRAPH_RECOVERY_EVENTS = 5
_PreflightRequest = Callable[..., Awaitable[tuple[int, dict[str, Any]]]]
_ReadyProbe = Callable[["ReleaseGateSettings"], Awaitable[dict[str, Any]]]


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _float_env(environ: dict[str, str], name: str, default: str) -> float:
    raw = str(environ.get(name, default)).strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not value.is_integer():
        raise ValueError(f"{name} must be a whole number of seconds")
    return value


def _release_slug(release_version: str) -> str:
    readable = re.sub(r"[^A-Za-z0-9.+~-]+", "_", release_version).strip("_")
    readable = (readable or "release")[:80]
    digest = hashlib.sha256(release_version.encode("utf-8")).hexdigest()[:12]
    return f"{readable}-{digest}"


@dataclass(frozen=True, slots=True)
class GraphRecoveryEvent:
    """One reviewed graph event that may receive a single guarded replay."""

    tenant_id: str
    event_id: str
    expected_error_contains: str


_RecoveryRequest = Callable[[GraphRecoveryEvent], Awaitable[dict[str, Any]]]


def _legacy_recovery_event(values: Mapping[str, str]) -> GraphRecoveryEvent | None:
    tenant_id = str(
        values.get("M1_RELEASE_GATE_GRAPH_RECOVERY_TENANT_ID", "")
    ).strip()
    event_id = str(
        values.get("M1_RELEASE_GATE_GRAPH_RECOVERY_EVENT_ID", "")
    ).strip()
    expected_error_contains = str(
        values.get("M1_RELEASE_GATE_GRAPH_RECOVERY_EXPECTED_ERROR_CONTAINS", "")
    ).strip()
    configured = (tenant_id, event_id, expected_error_contains)
    if not any(configured):
        return None
    if not all(configured):
        raise ValueError("legacy M1 graph recovery requires tenant, event, and expected error")
    return GraphRecoveryEvent(
        tenant_id=tenant_id,
        event_id=event_id,
        expected_error_contains=expected_error_contains,
    )


def _recovery_events_from_environ(
    values: Mapping[str, str],
) -> tuple[GraphRecoveryEvent, ...]:
    """Read an explicit bounded recovery list without broad replay semantics."""

    legacy_event = _legacy_recovery_event(values)
    raw_events = str(
        values.get("M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON", "")
    ).strip()
    if legacy_event is not None and raw_events:
        raise ValueError("configure either legacy recovery variables or recovery JSON")
    if not raw_events:
        return (legacy_event,) if legacy_event is not None else ()
    try:
        payload = json.loads(raw_events)
    except json.JSONDecodeError as exc:
        raise ValueError("M1 graph recovery JSON is invalid") from exc
    if not isinstance(payload, list) or not payload:
        raise ValueError("M1 graph recovery JSON must be a non-empty array")
    if len(payload) > _MAX_GRAPH_RECOVERY_EVENTS:
        raise ValueError(
            f"M1 graph recovery JSON accepts at most {_MAX_GRAPH_RECOVERY_EVENTS} events"
        )

    events: list[GraphRecoveryEvent] = []
    identities: set[tuple[str, str]] = set()
    expected_keys = {"tenant_id", "event_id", "expected_error_contains"}
    for item in payload:
        if not isinstance(item, Mapping) or set(item) != expected_keys:
            raise ValueError("each M1 graph recovery event must have exact required fields")
        event = GraphRecoveryEvent(
            tenant_id=str(item["tenant_id"]).strip(),
            event_id=str(item["event_id"]).strip(),
            expected_error_contains=str(item["expected_error_contains"]).strip(),
        )
        if not all((event.tenant_id, event.event_id, event.expected_error_contains)):
            raise ValueError("M1 graph recovery event fields must be non-empty")
        identity = (event.tenant_id, event.event_id)
        if identity in identities:
            raise ValueError("M1 graph recovery event identities must be unique")
        identities.add(identity)
        events.append(event)
    return tuple(events)


@dataclass(frozen=True, slots=True)
class ReleaseGateSettings:
    """Validated runtime settings, with secrets excluded from representations."""

    base_url: str
    api_key: str
    preflight_key: str
    release_version: str
    state_root: Path
    ready_timeout_seconds: float
    preflight_timeout_seconds: float
    healthcheck_timeout_seconds: float
    controller_timeout_seconds: float
    recovery_timeout_seconds: float
    recovery_events: tuple[GraphRecoveryEvent, ...]
    knowledge_database_url: str
    release_manifest_path: Path
    image_reference: str
    recovery_legacy: bool = False
    require_all: bool = True
    include_lightrag_lifecycle: bool = True

    def __repr__(self) -> str:
        return (
            "ReleaseGateSettings("
            f"base_url={self.base_url!r}, release_version={self.release_version!r}, "
            f"state_root={self.state_root!r}, "
            f"ready_timeout_seconds={self.ready_timeout_seconds!r}, "
            f"preflight_timeout_seconds={self.preflight_timeout_seconds!r}, "
            f"healthcheck_timeout_seconds={self.healthcheck_timeout_seconds!r}, "
            f"controller_timeout_seconds={self.controller_timeout_seconds!r}, "
            f"recovery_timeout_seconds={self.recovery_timeout_seconds!r}, "
            f"recovery_event_ids={tuple(event.event_id for event in self.recovery_events)!r}, "
            f"release_manifest_path={self.release_manifest_path!r}, "
            f"image_reference={self.image_reference!r})"
        )

    @classmethod
    def from_environ(
        cls,
        environ: dict[str, str] | None = None,
    ) -> ReleaseGateSettings:
        values = dict(os.environ if environ is None else environ)
        return cls(
            base_url=str(
                values.get("M1_RELEASE_GATE_BASE_URL", "http://m1:8080")
            ).strip(),
            api_key=str(values.get("M1_API_KEY", "")),
            preflight_key=str(values.get("M1_ENHANCED_PREFLIGHT_KEY", "")),
            release_version=str(
                values.get("M1_RELEASE_GATE_RELEASE_VERSION", "")
            ).strip(),
            state_root=Path(
                values.get(
                    "M1_RELEASE_GATE_STATE_ROOT",
                    "/app/data/release-gate",
                )
            ),
            ready_timeout_seconds=_float_env(
                values,
                "M1_RELEASE_GATE_READY_TIMEOUT_SECONDS",
                "240",
            ),
            preflight_timeout_seconds=_float_env(
                values,
                "M1_ENHANCED_PREFLIGHT_TIMEOUT_SECONDS",
                "900",
            ),
            healthcheck_timeout_seconds=_float_env(
                values,
                "M1_RELEASE_GATE_HEALTHCHECK_TIMEOUT_SECONDS",
                "1150",
            ),
            controller_timeout_seconds=_float_env(
                values,
                "YUNPAI_HEALTH_TIMEOUT_SECONDS",
                "0",
            ),
            recovery_timeout_seconds=_float_env(
                values,
                "M1_RELEASE_GATE_RECOVERY_TIMEOUT_SECONDS",
                "120",
            ),
            recovery_events=_recovery_events_from_environ(values),
            knowledge_database_url=str(
                values.get("KNOWLEDGE_DATABASE_URL", "")
            ).strip(),
            release_manifest_path=Path(
                values.get(
                    "M1_RELEASE_GATE_RELEASE_MANIFEST",
                    "/app/release.json",
                )
            ),
            image_reference=str(
                values.get("M1_RELEASE_GATE_IMAGE_REFERENCE", "")
            ).strip(),
            recovery_legacy=_legacy_recovery_event(values) is not None,
            require_all=str(values.get("M1_RELEASE_GATE_REQUIRE_ALL", "true")).lower()
            not in {"0", "false", "no", "off"},
            include_lightrag_lifecycle=str(
                values.get("M1_RELEASE_GATE_INCLUDE_LIGHTRAG_LIFECYCLE", "true")
            ).lower()
            not in {"0", "false", "no", "off"},
        )

    @property
    def release_root(self) -> Path:
        return self.state_root / _release_slug(self.release_version)

    @property
    def state_path(self) -> Path:
        return self.release_root / "status.json"

    @property
    def report_path(self) -> Path:
        return self.release_root / "preflight-report.json"

    @property
    def recovery_configured(self) -> bool:
        return bool(self.recovery_events)

    def validate(self) -> None:
        if self.release_version.lower() in _UNKNOWN_RELEASES:
            raise ValueError("M1 release gate requires a concrete release version")
        if not self.preflight_key:
            raise ValueError("M1 enhanced preflight key is required")
        if not self.base_url.startswith(("http://", "https://")):
            raise ValueError("M1 release gate base URL must use HTTP or HTTPS")
        _release_identity(self)
        if self.ready_timeout_seconds < 1 or self.preflight_timeout_seconds < 1:
            raise ValueError("M1 release gate timeouts must be positive")
        if len(self.recovery_events) > _MAX_GRAPH_RECOVERY_EVENTS:
            raise ValueError(
                f"M1 graph recovery accepts at most {_MAX_GRAPH_RECOVERY_EVENTS} events"
            )
        identities: set[tuple[str, str]] = set()
        for event in self.recovery_events:
            if not all(
                (event.tenant_id, event.event_id, event.expected_error_contains)
            ):
                raise ValueError("M1 graph recovery event fields must be non-empty")
            identity = (event.tenant_id, event.event_id)
            if identity in identities:
                raise ValueError("M1 graph recovery event identities must be unique")
            identities.add(identity)
        if self.recovery_timeout_seconds < 1:
            raise ValueError("M1 projection drain timeout must be positive")
        if self.recovery_configured and not self.knowledge_database_url:
            raise ValueError("KNOWLEDGE_DATABASE_URL is required for M1 graph recovery")

        required_healthcheck = (
            self.ready_timeout_seconds
            + self.recovery_timeout_seconds
            + self.preflight_timeout_seconds
            + 5
        )
        if self.healthcheck_timeout_seconds < required_healthcheck:
            raise ValueError(
                "M1 release gate healthcheck timeout must cover readiness and "
                "preflight timeouts plus five seconds"
            )
        if self.controller_timeout_seconds < self.healthcheck_timeout_seconds + 30:
            raise ValueError(
                "YUNPAI_HEALTH_TIMEOUT_SECONDS must exceed the M1 release gate "
                "healthcheck timeout by at least 30 seconds"
            )


def _safe_state(
    settings: ReleaseGateSettings,
    *,
    state: str,
    started_at: str,
    error_type: str | None = None,
    report_sha256: str | None = None,
    recovery_events: list[dict[str, str]] | None = None,
    release_identity: dict[str, str] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schema_version": _STATE_SCHEMA_VERSION,
        "release_version": settings.release_version,
        "state": state,
        "started_at": started_at,
        "finished_at": _utc_now() if state in _TERMINAL_STATES else None,
        "report_path": str(settings.report_path),
    }
    if error_type:
        payload["error_type"] = error_type
    if report_sha256:
        payload["report_sha256"] = report_sha256
    if release_identity:
        payload["release_identity"] = release_identity
    if settings.recovery_configured:
        events = recovery_events or [
            {
                "tenant_id": event.tenant_id,
                "event_id": event.event_id,
                "status": "not_started",
            }
            for event in settings.recovery_events
        ]
        if settings.recovery_legacy:
            # Preserve the existing single-event state layout for deployments
            # that still use the legacy triplet configuration.
            payload["graph_recovery"] = events[0]
        else:
            payload["graph_recoveries"] = events
    return payload


def _write_state(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=path.name + ".",
        suffix=".tmp",
        delete=False,
    ) as stream:
        temporary = Path(stream.name)
        os.chmod(temporary, 0o600)
        json.dump(payload, stream, ensure_ascii=False, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def _claim(settings: ReleaseGateSettings, started_at: str) -> bool:
    """Claim this immutable release without permitting a second probe."""

    path = settings.state_path
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    payload = _safe_state(settings, state="pending", started_at=started_at)
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError:
        return False
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    return True


def _read_state(path: Path) -> dict[str, Any] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _release_identity(settings: ReleaseGateSettings) -> dict[str, str]:
    try:
        payload = json.loads(settings.release_manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError("M1 release manifest is unavailable or invalid") from exc
    if not isinstance(payload, dict):
        raise TypeError("M1 release manifest must be an object")
    if payload.get("version") != settings.release_version:
        raise ValueError("M1 release manifest version does not match")
    git_commit = payload.get("git_commit")
    if not isinstance(git_commit, str) or not re.fullmatch(r"[0-9a-f]{40}", git_commit):
        raise ValueError("M1 release manifest Git commit is invalid")
    if not re.fullmatch(r"\S+@sha256:[0-9a-f]{64}", settings.image_reference):
        raise ValueError("M1 release gate image reference is not immutable")
    return {
        "git_commit": git_commit,
        "manifest_sha256": _sha256_file(settings.release_manifest_path),
        "image_reference": settings.image_reference,
    }


def _parse_aware_timestamp(value: object, field: str) -> None:
    if not isinstance(value, str) or not value:
        raise ValueError(f"release gate state {field} is required")
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"release gate state {field} is invalid") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"release gate state {field} must include a timezone")


def _validate_preflight_report(
    report: object,
    *,
    require_all: bool = True,
    include_lightrag_lifecycle: bool = True,
) -> None:
    if not isinstance(report, dict):
        raise TypeError("release gate preflight report is invalid")
    if (
        report.get("mode") != "preflight"
        or report.get("ready") is not True
        or report.get("inference_executed") is not True
        or report.get("network_executed") is not True
        or report.get("lifecycle_side_effects_requested") is not include_lightrag_lifecycle
    ):
        raise ValueError("release gate preflight report is incomplete")
    fingerprint = report.get("configuration_fingerprint")
    if not isinstance(fingerprint, str) or not re.fullmatch(
        r"[0-9a-f]{64}", fingerprint
    ):
        raise ValueError("release gate configuration fingerprint is invalid")
    results = report.get("results")
    expected = set(PREFLIGHT_CAPABILITIES)
    if include_lightrag_lifecycle:
        expected |= {LIGHTRAG_LIFECYCLE}
    if not isinstance(results, dict) or set(results) != expected:
        raise ValueError("release gate preflight capability set is incomplete")
    for capability in expected:
        item = results.get(capability)
        if not isinstance(item, dict) or item.get("capability") != capability:
            raise ValueError(f"release gate capability record is invalid: {capability}")
        if require_all and item.get("required") is not True:
            raise ValueError(f"release gate capability did not pass: {capability}")
        if item.get("required") is not True:
            # Reduced builds (e.g. ARM64 without Paddle OCR) legitimately skip
            # capabilities the image cannot provide. Only enforce the ones the
            # preflight actually required and executed.
            continue
        if (
            item.get("status") != "passed"
            or item.get("exercised") is not True
        ):
            raise ValueError(f"release gate capability did not pass: {capability}")


def _validated_state(
    settings: ReleaseGateSettings,
    payload: dict[str, Any] | None,
) -> dict[str, Any]:
    if payload is None or payload.get("schema_version") != _STATE_SCHEMA_VERSION:
        raise ValueError("release gate state schema is invalid")
    if payload.get("release_version") != settings.release_version:
        raise ValueError("release gate state release does not match")
    state = payload.get("state")
    if state not in {*_TERMINAL_STATES, "pending"}:
        raise ValueError("release gate state value is invalid")
    _parse_aware_timestamp(payload.get("started_at"), "started_at")
    if payload.get("report_path") != str(settings.report_path):
        raise ValueError("release gate report path does not match")
    if state in _TERMINAL_STATES:
        _parse_aware_timestamp(payload.get("finished_at"), "finished_at")
    elif payload.get("finished_at") is not None:
        raise ValueError("pending release gate state cannot be finished")

    if state == "passed":
        if payload.get("release_identity") != _release_identity(settings):
            raise ValueError("passed release gate identity does not match")
        expected_digest = payload.get("report_sha256")
        if not isinstance(expected_digest, str) or not re.fullmatch(
            r"[0-9a-f]{64}", expected_digest
        ):
            raise ValueError("passed release gate state has no valid report digest")
        if not settings.report_path.is_file():
            raise ValueError("passed release gate report is missing")
        if not hmac.compare_digest(
            expected_digest,
            _sha256_file(settings.report_path),
        ):
            raise ValueError("passed release gate report digest does not match")
        report_payload = _read_state(settings.report_path)
        report = (report_payload or {}).get("report")
        _validate_preflight_report(
            report,
            require_all=settings.require_all,
            include_lightrag_lifecycle=settings.include_lightrag_lifecycle,
        )
        if settings.recovery_configured:
            recovered_events: object
            if settings.recovery_legacy:
                recovered_events = [payload.get("graph_recovery")]
            else:
                recovered_events = payload.get("graph_recoveries")
            if not isinstance(recovered_events, list):
                raise ValueError("passed release gate graph recovery state is invalid")
            if len(recovered_events) != len(settings.recovery_events):
                raise ValueError("passed release gate graph recovery count is invalid")
            for recovered, expected in zip(recovered_events, settings.recovery_events):
                if (
                    not isinstance(recovered, dict)
                    or recovered.get("tenant_id") != expected.tenant_id
                    or recovered.get("event_id") != expected.event_id
                    or recovered.get("status") not in {"delivered", "retired"}
                ):
                    raise ValueError("passed release gate graph recovery state is invalid")
    return payload


def _projection_counts(payload: dict[str, Any]) -> tuple[int, int]:
    knowledge = payload.get("knowledge")
    outbox = knowledge.get("outbox") if isinstance(knowledge, dict) else None
    terminal = outbox.get("terminal") if isinstance(outbox, dict) else None
    if not isinstance(outbox, dict) or outbox.get("health_complete") is not True:
        raise ValueError("M1 projection health is incomplete")
    count = terminal.get("count") if isinstance(terminal, dict) else None
    present = terminal.get("present") if isinstance(terminal, dict) else None
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise ValueError("M1 projection terminal count is invalid")
    if not isinstance(present, bool) or present is not (count > 0):
        raise ValueError("M1 projection terminal status is inconsistent")
    pending = outbox.get("pending")
    if isinstance(pending, bool) or not isinstance(pending, int) or pending < 0:
        raise ValueError("M1 projection pending count is invalid")
    return pending, count


def _assert_projection_clean(payload: dict[str, Any]) -> None:
    pending, terminal = _projection_counts(payload)
    if terminal > 0:
        raise RuntimeError("M1 readiness reports terminal projection failures")
    if pending > 0:
        raise RuntimeError("M1 readiness reports pending projection events")


async def _ready_payload(client: httpx.AsyncClient, ready_url: str) -> dict[str, Any]:
    response = await client.get(ready_url)
    if response.status_code != 200:
        raise RuntimeError(f"M1 readiness returned HTTP {response.status_code}")
    try:
        payload = response.json()
    except ValueError as exc:
        raise RuntimeError("M1 readiness returned non-JSON content") from exc
    if not isinstance(payload, dict):
        raise TypeError("M1 readiness returned a non-object response")
    return payload


def _assert_document_router_ready(payload: dict[str, Any]) -> None:
    """Require an enabled adaptive router to be healthy before release pass."""

    router = payload.get("document_router")
    if router is None:
        # Older CPU/rollback payloads may not expose the optional router field.
        return
    if not isinstance(router, dict):
        raise TypeError("M1 document router readiness payload is invalid")
    if router.get("enabled") is True and router.get("ready") is not True:
        raise RuntimeError("M1 document router is enabled but not ready")


def _assert_entity_router_ready(payload: dict[str, Any]) -> None:
    """Require an enabled entity router to be healthy before release pass."""

    router = payload.get("entity_router")
    if router is None:
        return
    if not isinstance(router, dict):
        raise TypeError("M1 entity router readiness payload is invalid")
    if router.get("enabled") is True and router.get("ready") is not True:
        raise RuntimeError("M1 entity router is enabled but not ready")


def _assert_extension_routers_ready(payload: dict[str, Any]) -> None:
    """Fail the release only for a required unhealthy routing extension."""

    for key, label in (
        ("tabular_layout_router", "tabular layout router"),
        ("field_semantic_router", "field semantic router"),
        ("visual_region_router", "visual region router"),
        ("region_capability_router", "region capability router"),
        ("content_region_router", "content region router"),
    ):
        router = payload.get(key)
        if router is None:
            # Rollback releases may predate an optional routing extension.
            continue
        if not isinstance(router, dict):
            raise TypeError(f"M1 {label} readiness payload is invalid")
        if router.get("required") is True and router.get("ready") is not True:
            raise RuntimeError(f"M1 required {label} is not ready")


async def _wait_until_ready(settings: ReleaseGateSettings) -> dict[str, Any]:
    deadline = time.monotonic() + settings.ready_timeout_seconds
    ready_url = settings.base_url.rstrip("/") + "/ready"
    async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as client:
        while True:
            try:
                payload = await _ready_payload(client, ready_url)
                _projection_counts(payload)
                _assert_document_router_ready(payload)
                _assert_entity_router_ready(payload)
                _assert_extension_routers_ready(payload)
                return payload
            except (httpx.HTTPError, RuntimeError, TypeError, ValueError):
                pass
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    "M1 did not become ready before release gate timeout"
                )
            await asyncio.sleep(2)


async def _wait_until_projection_clean(
    settings: ReleaseGateSettings,
) -> dict[str, Any]:
    deadline = time.monotonic() + settings.recovery_timeout_seconds
    ready_url = settings.base_url.rstrip("/") + "/ready"
    async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as client:
        while True:
            try:
                payload = await _ready_payload(client, ready_url)
                _assert_projection_clean(payload)
                _assert_document_router_ready(payload)
                _assert_entity_router_ready(payload)
                _assert_extension_routers_ready(payload)
                return payload
            except (httpx.HTTPError, RuntimeError, TypeError, ValueError):
                pass
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    "M1 projection terminal failures did not clear after recovery"
                )
            await asyncio.sleep(2)


async def _recover_terminal_graph_event(
    event: GraphRecoveryEvent,
) -> dict[str, Any]:
    from .knowledge.rebuild_terminal_graph_event import (
        rebuild_terminal_graph_event,
    )

    return await rebuild_terminal_graph_event(
        tenant_id=event.tenant_id,
        event_id=event.event_id,
        expected_error_contains=event.expected_error_contains,
    )


async def execute_release_gate_once(
    settings: ReleaseGateSettings,
    *,
    ready_probe: _ReadyProbe = _wait_until_ready,
    recovery_request: _RecoveryRequest = _recover_terminal_graph_event,
    recovery_wait_probe: _ReadyProbe = _wait_until_projection_clean,
    preflight_request: _PreflightRequest = request_preflight,
) -> dict[str, Any]:
    """Execute one claimed attempt and persist a secret-free terminal state."""

    started_at = _utc_now()
    if not _claim(settings, started_at):
        existing = _read_state(settings.state_path)
        try:
            validated = _validated_state(settings, existing)
        except (OSError, TypeError, ValueError):
            validated = None
        if validated and validated.get("state") in _TERMINAL_STATES:
            return validated
        failed = _safe_state(
            settings,
            state="failed",
            started_at=str((existing or {}).get("started_at") or started_at),
            error_type=(
                "InterruptedPreviousAttempt" if validated else "InvalidPreviousState"
            ),
        )
        _write_state(settings.state_path, failed)
        return failed

    recovery_events: list[dict[str, str]] | None = None
    release_identity: dict[str, str] | None = None
    try:
        settings.validate()
        release_identity = _release_identity(settings)
        ready_payload = await ready_probe(settings)
        pending, terminal_failures = _projection_counts(ready_payload)
        if settings.recovery_configured:
            recovery_events = []
            # The complete bounded batch and the one resulting drain share
            # one deadline. A rejected target stops the remainder before any
            # additional persisted recovery is attempted.
            async with asyncio.timeout(settings.recovery_timeout_seconds):
                for event in settings.recovery_events:
                    result = await recovery_request(event)
                    status = str(result.get("status") or "")
                    if (
                        result.get("tenant_id") != event.tenant_id
                        or result.get("event_id") != event.event_id
                        or status not in {"pending", "processing", "delivered", "retired"}
                    ):
                        raise RuntimeError(
                            "M1 terminal graph recovery was not accepted"
                        )
                    recovery_events.append(
                        {
                            "tenant_id": event.tenant_id,
                            "event_id": event.event_id,
                            "status": status,
                        }
                    )
                await recovery_wait_probe(settings)
            recovery_events = [
                {
                    "tenant_id": str(result["tenant_id"]),
                    "event_id": str(result["event_id"]),
                    "status": (
                        "retired" if result.get("status") == "retired" else "delivered"
                    ),
                }
                for result in recovery_events
            ]
        elif terminal_failures:
            _assert_projection_clean(ready_payload)
        elif pending:
            await recovery_wait_probe(settings)
        status, report = await preflight_request(
            base_url=settings.base_url,
            api_key=settings.api_key,
            preflight_key=settings.preflight_key,
            require_all=settings.require_all,
            include_lightrag_lifecycle=settings.include_lightrag_lifecycle,
            timeout_seconds=settings.preflight_timeout_seconds,
        )
        save_report(settings.report_path, report)
        passed = status == 200 and report.get("ready") is True
        if passed:
            _validate_preflight_report(
                report,
                require_all=settings.require_all,
                include_lightrag_lifecycle=settings.include_lightrag_lifecycle,
            )
            final_ready = await ready_probe(settings)
            _assert_projection_clean(final_ready)
            _assert_document_router_ready(final_ready)
            _assert_entity_router_ready(final_ready)
            _assert_extension_routers_ready(final_ready)
        terminal = _safe_state(
            settings,
            state="passed" if passed else "failed",
            started_at=started_at,
            error_type=None if passed else "PreflightRejected",
            report_sha256=_sha256_file(settings.report_path),
            recovery_events=recovery_events,
            release_identity=release_identity,
        )
    except Exception as exc:  # noqa: BLE001 - store type only, never secret text
        terminal = _safe_state(
            settings,
            state="failed",
            started_at=started_at,
            error_type=exc.__class__.__name__,
            recovery_events=recovery_events,
            release_identity=release_identity,
        )
    _write_state(settings.state_path, terminal)
    return terminal


def wait_for_gate_health(settings: ReleaseGateSettings) -> bool:
    """Wait for the single attempt while Docker keeps health at ``starting``."""

    try:
        settings.validate()
    except ValueError:
        return False
    deadline = time.monotonic() + settings.healthcheck_timeout_seconds - 5
    while time.monotonic() < deadline:
        state = _read_state(settings.state_path)
        if state is not None:
            try:
                state = _validated_state(settings, state)
            except (OSError, TypeError, ValueError):
                return False
            if state.get("state") == "passed":
                return True
            if state.get("state") == "failed":
                return False
        time.sleep(1)
    return False


def _live_projection_clean(settings: ReleaseGateSettings) -> bool:
    try:
        response = httpx.get(
            settings.base_url.rstrip("/") + "/ready",
            timeout=5.0,
        )
        if response.status_code != 200:
            return False
        payload = response.json()
        if not isinstance(payload, dict):
            return False
        _assert_projection_clean(payload)
    except (httpx.HTTPError, RuntimeError, TypeError, ValueError):
        return False
    return True


def _live_enhancement_configuration_matches(settings: ReleaseGateSettings) -> bool:
    report_payload = _read_state(settings.report_path)
    report = (report_payload or {}).get("report")
    expected = (
        report.get("configuration_fingerprint") if isinstance(report, dict) else None
    )
    if not isinstance(expected, str):
        return False
    try:
        headers = {"X-API-Key": settings.api_key} if settings.api_key else None
        response = httpx.get(
            settings.base_url.rstrip("/") + "/enhanced/ready",
            headers=headers,
            timeout=5.0,
        )
        if response.status_code != 200:
            return False
        payload = response.json()
        actual = (
            payload.get("configuration_fingerprint")
            if isinstance(payload, dict)
            else None
        )
        return isinstance(actual, str) and hmac.compare_digest(expected, actual)
    except (httpx.HTTPError, ValueError):
        return False


def _hold_terminal_state() -> None:
    while True:
        time.sleep(3600)


def _run_command() -> int:
    try:
        settings = ReleaseGateSettings.from_environ()
        terminal = asyncio.run(execute_release_gate_once(settings))
        print(
            json.dumps(
                {
                    "release_version": terminal.get("release_version"),
                    "state": terminal.get("state"),
                    "error_type": terminal.get("error_type"),
                    "report_path": terminal.get("report_path"),
                },
                ensure_ascii=True,
                sort_keys=True,
            ),
            flush=True,
        )
    except Exception as exc:  # noqa: BLE001 - stay alive/unhealthy on config failure
        print(
            json.dumps(
                {"state": "failed", "error_type": exc.__class__.__name__},
                sort_keys=True,
            ),
            flush=True,
        )
    try:
        _hold_terminal_state()
    except KeyboardInterrupt:
        return 0


def _check_command() -> int:
    try:
        settings = ReleaseGateSettings.from_environ()
    except (OSError, ValueError):
        return 1
    healthy = (
        wait_for_gate_health(settings)
        and _live_projection_clean(settings)
        and _live_enhancement_configuration_matches(settings)
    )
    return 0 if healthy else 1


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "check"))
    args = parser.parse_args()
    if args.command == "run":
        raise SystemExit(_run_command())
    raise SystemExit(_check_command())


if __name__ == "__main__":
    main()
