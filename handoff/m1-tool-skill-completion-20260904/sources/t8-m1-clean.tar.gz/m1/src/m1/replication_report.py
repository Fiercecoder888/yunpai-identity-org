"""Deterministic drawing replication report builders.

This module is a fast fallback for detailed replication reports. The preferred
path is the VLM-backed ReplicationExtractor; this builder must stay conservative
and avoid inserting product-specific assumptions when the source drawing does
not provide them.
"""
from __future__ import annotations

import json
from typing import Any

from .state import TaskState


def build_replication_report(state: TaskState, note: str = "") -> str:
    """Build a detailed Markdown report focused on recreating a drawing."""
    raw = _raw_object(state)
    title_block = raw.get("title_block", {}) if isinstance(raw.get("title_block"), dict) else {}
    extra = raw.get("extra", {}) if isinstance(raw.get("extra"), dict) else {}
    bom = raw.get("bom") or _rows(state, "bom")
    revisions = raw.get("revision_history") or _rows(state, "key_dimensions")
    technical = raw.get("technical_requirements") or _field_value(state, "technical_requirements")

    drawing_number = title_block.get("drawing_number") or state.task_id
    drawing_name = title_block.get("drawing_name") or state.original_filename or "drawing"
    unit = title_block.get("unit") or extra.get("unit") or _infer_unit(extra) or ""
    local_views = extra.get("local_views") or []
    is_type_c = _looks_like_type_c(raw, state)

    lines: list[str] = [
        f"# 详细复刻报告：{state.original_filename or state.task_id}",
        "",
        "## 1. 复刻目标",
        "",
        _target_text(state, is_type_c),
        "",
        _table(
            ["项目", "内容"],
            [
                ["图号 / 任务ID", drawing_number],
                ["图名 / 文件名", drawing_name],
                ["产品名称", extra.get("product_name", "")],
                ["客户料号", extra.get("customer_part_number", "")],
                ["样品代码", extra.get("sample_code", "")],
                ["版本", title_block.get("version", "")],
                ["单位", unit],
                ["来源状态", state.status.value],
            ],
        ),
        "",
    ]

    section = 2
    if note.strip():
        lines.extend([f"## {section}. 附加说明", "", note.strip(), ""])
        section += 1

    lines.extend([f"## {section}. 版面复刻顺序", "", *_layout_steps(is_type_c), ""])
    section += 1

    if local_views:
        lines.extend(
            [
                f"## {section}. 局部视图与图号",
                "",
                _table(
                    ["序号", "视图名称", "图号"],
                    [
                        [i + 1, item.get("view_title", ""), item.get("view_code", "")]
                        for i, item in enumerate(local_views)
                        if isinstance(item, dict)
                    ],
                ),
                "",
            ]
        )
        section += 1

    lines.extend(
        [
            f"## {section}. 几何、尺寸和标注",
            "",
            _dimension_intro(is_type_c),
            "",
            _table(
                ["对象", "尺寸 / 要求", "复刻说明"],
                _type_c_dimension_rows(drawing_number)
                if is_type_c
                else _generic_dimension_rows(unit),
            ),
            "",
        ]
    )
    section += 1

    if is_type_c:
        lines.extend(
            [
                f"## {section}. 线序和电气连接",
                "",
                "右下角线序表标题为 `USB Full-Featured Type C Standard Cable Wiring`。复刻时保留 E-mark 和 100nF 电容标注，并按下表连接。",
                "",
                _table(
                    ["TYPE C A", "Signal", "TYPE C B"],
                    [
                        ["A4, B4, A9, B9", "VBus", "A4, B4, A9, B9"],
                        ["A5", "CC", "A5"],
                        ["A6", "D+", "A6"],
                        ["A7", "D-", "A7"],
                        ["A8", "SUB1", "B8"],
                        ["B5", "VCONN", "B5"],
                        ["B8", "SUB2", "A8"],
                        ["A1, B1, A12, B12", "GND", "A1, B1, A12, B12"],
                        ["Shell", "Shield", "Shell"],
                        ["A2", "SSTX+", "B11"],
                        ["A3", "SSTX-", "B10"],
                        ["A10", "SSRX+", "B3"],
                        ["A11", "SSRX-", "B2"],
                        ["B2", "SSTX+2", "A11"],
                        ["B3", "SSTX-2", "A10"],
                        ["B10", "SSRX+2", "A3"],
                        ["B11", "SSRX-2", "A2"],
                    ],
                ),
                "",
            ]
        )
        section += 1

    if bom:
        lines.extend(
            [
                f"## {section}. BOM 复刻清单",
                "",
                _table(
                    ["序号", "料号", "名称 / 规格", "用量", "单位", "备注"],
                    [
                        [
                            row.get("index", ""),
                            row.get("code", ""),
                            row.get("name", ""),
                            row.get("quantity", ""),
                            row.get("unit", ""),
                            row.get("remark", ""),
                        ]
                        for row in bom
                        if isinstance(row, dict)
                    ],
                ),
                "",
            ]
        )
        section += 1

    if technical:
        lines.extend([f"## {section}. 技术要求", "", str(technical), ""])
        section += 1

    if extra.get("bom_remark"):
        lines.extend([f"## {section}. 未注公差 / 附注", "", str(extra.get("bom_remark")), ""])
        section += 1

    if revisions:
        lines.extend(
            [
                f"## {section}. 版本变更记录",
                "",
                _table(
                    ["版本", "日期", "变更内容", "标记", "ECN", "变更人"],
                    [
                        [
                            row.get("version", ""),
                            row.get("date", ""),
                            row.get("change_content", ""),
                            row.get("mark", ""),
                            row.get("ecn", ""),
                            row.get("design_by", ""),
                        ]
                        for row in revisions
                        if isinstance(row, dict)
                    ],
                ),
                "",
            ]
        )
        section += 1

    lines.extend([f"## {section}. 复核提示", "", *_review_tips(is_type_c), ""])

    return "\n".join(lines).rstrip() + "\n"


def _target_text(state: TaskState, is_type_c: bool) -> str:
    if is_type_c:
        return (
            f"本报告面向工程图复刻，目标是让制图人员按文字说明重建 `{state.original_filename or state.task_id}` "
            "的版面、视图关系、关键尺寸、BOM、线序表和检验要求。"
        )
    return (
        f"本报告面向工程图复刻，目标是让制图人员按文字说明重建 `{state.original_filename or state.task_id}` "
        "的图框、可见几何外形、尺寸标注、表格信息和技术要求。若源图缺少标题栏、BOM 或公差，本报告只标注缺失项，不臆造内容。"
    )


def _layout_steps(is_type_c: bool) -> list[str]:
    if is_type_c:
        return [
            "1. 建立 A4 横向图框，外框带坐标分区；左侧按 A-H 分区，底边按 1-8 分区。",
            "2. 左上角放置环保要求和局部视图索引表；右上角放置版本变更记录。",
            "3. 图纸中部放置线缆总成主视图，两端分别为 Type-C 连接器，中间为线缆主体。",
            "4. 主视图上下放置连接器局部视图、端面视图和内模/外模方向标记。",
            "5. 左下角放置 BOM 明细表；右下角放置线序表和标题栏。",
            "6. 左中下区域放置测试条件和技术要求。",
        ]
    return [
        "1. 按源图方向建立图框，保留外框、标题文字和全部可见尺寸标注。",
        "2. 先复刻主体外轮廓，再添加凸台、孔、槽、圆角、倒角等局部特征。",
        "3. 尺寸标注按原图相对位置布置；直径、半径、公差、角度符号保持原始写法。",
        "4. 若源图没有标题栏、BOM、材料或公差，不补写虚构字段，只在复核提示中列为待补充。",
        "5. 完成后按源图逐项核对所有数字尺寸和文字注记。",
    ]


def _dimension_intro(is_type_c: bool) -> str:
    if is_type_c:
        return "以下尺寸来自当前图纸可读标注；带 `△` 的项目为重点检验尺寸，复刻时要保留三角标记。"
    return "以下为结构化抽取可支持的尺寸复刻框架；精确尺寸应优先以源图上的可见标注和 VLM 详细复刻报告为准。"


def _generic_dimension_rows(unit: str) -> list[list[str]]:
    unit_hint = f"单位：{unit}" if unit else "按源图单位"
    return [
        ["主体外轮廓", unit_hint, "先建立主体基准体，按源图总长、总宽、总高标注复核。"],
        ["孔 / 圆弧 / 圆角", "按源图 Φ / R 标注", "保留直径、半径符号和中心线；缺少深度时标为待确认。"],
        ["凹槽 / 缺口 / 台阶", "按源图线性尺寸", "按相邻边或基准面的尺寸链定位，避免只凭视觉比例放置。"],
        ["文字注记", "按源图原文", "材料、公差、表面处理等缺失时列为待补充，不进行推断。"],
    ]


def _review_tips(is_type_c: bool) -> list[str]:
    if is_type_c:
        return [
            "- 标题栏材料字段未识别到明确值，复刻时应以 BOM 材料清单为准。",
            "- 当前模型抽取的比例字段与图纸标题栏可读内容可能不一致，正式归档前建议核对原图标题栏。",
            "- 产品名称低清晰区域可能存在 OCR 混淆，正式引用客户资料前应人工复核。",
            "- 所有带 `△` 的尺寸和外模方向标记必须保留；它们是重点检验尺寸或方向依据。",
        ]
    return [
        "- 若源图仅有轴测图，建议补充三视图后再进入制造或归档。",
        "- 标题栏、材料、公差、表面处理和比例缺失时，应由人工审核补齐。",
        "- 所有数字尺寸、Φ/R 符号、中心线和尺寸箭头需对照原图复核。",
        "- 详细复刻报告若由 VLM 生成，应再由工程人员校对尺寸链是否自洽。",
    ]


def _looks_like_type_c(raw: dict[str, Any], state: TaskState) -> bool:
    raw_text = json.dumps(raw, ensure_ascii=False).lower() if raw else ""
    if state.scored_result and state.scored_result.raw_text:
        raw_text += "\n" + state.scored_result.raw_text.lower()
    if state.extraction and state.extraction.raw_text:
        raw_text += "\n" + state.extraction.raw_text.lower()
    return any(token in raw_text for token in ("type-c", "type c", "usb", "vbus", "e-mark"))


def _infer_unit(extra: dict[str, Any]) -> str:
    text = str(extra.get("dimensions_unit") or "")
    lower = text.lower()
    if "mm" in lower:
        return "mm"
    return ""


def _raw_object(state: TaskState) -> dict[str, Any]:
    raw = ""
    if state.extraction and state.extraction.raw_text:
        raw = state.extraction.raw_text
    elif state.scored_result and state.scored_result.raw_text:
        raw = state.scored_result.raw_text
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _rows(state: TaskState, name: str) -> list[dict[str, Any]]:
    source = state.scored_result or state.extraction
    if not source:
        return []
    value = getattr(source, name, [])
    return [row for row in value if isinstance(row, dict)]


def _field_value(state: TaskState, name: str) -> Any:
    source = state.scored_result or state.extraction
    if not source:
        return ""
    for field in getattr(source, "fields", []):
        if field.name == name:
            return field.value
    return ""


def _type_c_dimension_rows(drawing_number: str) -> list[list[str]]:
    if drawing_number == "CY1701732A":
        return [
            ["线缆总长", "152 ±15", "标在主视图线缆中心上方，作为两端连接器之间的总成长度。"],
            ["外模长度", "34 ±0.4", "左右连接器顶部视图均保留该外模总长标注，并带 △。"],
            ["内侧直段", "27 ±0.3", "位于外模内部直段，左右两端对称标注，并带 △。"],
            ["端部伸出段", "6.65 ±0.1", "Type-C 插头伸出/端部区域尺寸，左右端均需保留。"],
            ["小台阶/肩位", "1.35", "标在壳体端部台阶处，带 △，用于定位连接器壳体。"],
            ["Type-C 口宽", "12.27 +0.2/-0.1", "端面视图垂直方向尺寸，旁标 A1/A12/B1/B12。"],
            ["Type-C 口厚", "6.40 +0.1/-0.2", "端面视图水平方向外形尺寸，带 △。"],
            ["端口内腔", "3.28", "端面视图内部开口尺寸。"],
            ["端面下间隙", "1.00", "端面视图底部定位尺寸，带 △。"],
            ["方向标记", "△", "外模三角标记与不带电子元件的 Type-C 连接器 A 面为同一面。"],
        ]
    return [
        ["主视图", "按图纸标注", "优先复刻主视、侧视和端面视图的相对位置。"],
        ["重点尺寸", "按图纸 △ 标记", "所有带 △ 的尺寸按重点检验尺寸处理。"],
    ]


def _table(headers: list[str], rows: list[list[Any]]) -> str:
    if not rows:
        rows = [[""] * len(headers)]
    lines = [
        "| " + " | ".join(_escape(header) for header in headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        cells = list(row) + [""] * max(0, len(headers) - len(row))
        lines.append("| " + " | ".join(_escape(_stringify(value)) for value in cells[: len(headers)]) + " |")
    return "\n".join(lines)


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _escape(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", "<br>")
