"""Markdown report builders for single tasks and batch tasks."""
from __future__ import annotations

import json
from typing import Any, Iterable

from .state import TaskState


def build_task_report(state: TaskState, note: str = "", heading_level: int = 1) -> str:
    """Build a deterministic comprehensive report for one processed document."""
    title = f"综合报告：{state.original_filename or state.task_id}"
    lines: list[str] = [_heading(heading_level, title), ""]

    lines.extend(_metadata_block(state))
    lines.append("")

    note = note.strip()
    if note:
        lines.extend([_heading(heading_level + 1, "附加说明"), "", note, ""])

    result = state.reviewed_result or state.scored_result
    extraction = state.extraction

    if result and result.fields:
        lines.extend([_heading(heading_level + 1, "结构化字段"), ""])
        lines.append(
            _table(
                [
                    {
                        "字段": field.name,
                        "值": field.value,
                        "置信度": f"{field.confidence:.3f}",
                        "状态": "待审核" if field.needs_review else "通过",
                    }
                    for field in result.fields
                ]
            )
        )
        lines.append("")
    elif extraction and extraction.fields:
        lines.extend([_heading(heading_level + 1, "结构化字段"), ""])
        lines.append(
            _table(
                [
                    {
                        "字段": field.name,
                        "值": field.value,
                        "OCR置信度": field.ocr_confidence,
                    }
                    for field in extraction.fields
                ]
            )
        )
        lines.append("")

    if result and result.extra_fields:
        lines.extend([_heading(heading_level + 1, "其他识别字段"), ""])
        lines.append(
            _table(
                [
                    {
                        "字段": field.name,
                        "值": field.value,
                        "置信度": f"{field.confidence:.3f}",
                        "状态": "待审核" if field.needs_review else "通过",
                    }
                    for field in result.extra_fields
                ]
            )
        )
        lines.append("")
    elif extraction and extraction.extra_fields:
        lines.extend([_heading(heading_level + 1, "其他识别字段"), ""])
        lines.append(
            _table(
                [
                    {
                        "字段": field.name,
                        "值": field.value,
                        "OCR置信度": field.ocr_confidence,
                    }
                    for field in extraction.extra_fields
                ]
            )
        )
        lines.append("")

    bom_rows = _first_non_empty(
        result.bom if result else None,
        extraction.bom if extraction else None,
    )
    if bom_rows:
        lines.extend([_heading(heading_level + 1, "明细表 / BOM"), ""])
        lines.append(_table(bom_rows))
        lines.append("")

    key_rows = _first_non_empty(
        result.key_dimensions if result else None,
        extraction.key_dimensions if extraction else None,
    )
    if key_rows:
        lines.extend([_heading(heading_level + 1, "关键尺寸 / 版本记录"), ""])
        lines.append(_table(key_rows))
        lines.append("")

    tech = _find_field_value(result, "technical_requirements")
    if tech:
        lines.extend([_heading(heading_level + 1, "技术要求"), "", str(tech), ""])

    if result:
        lines.extend([_heading(heading_level + 1, "置信度与审核"), ""])
        lines.append(
            _table(
                [
                    {
                        "综合置信度": f"{result.overall_confidence:.3f}",
                        "是否待审核": "是" if result.needs_review else "否",
                        "审核状态": result.review_status,
                        "审核人": state.reviewer or "",
                        "审核意见": state.review_comment or "",
                    }
                ]
            )
        )
        low_fields = [f.name for f in result.fields if f.needs_review]
        if low_fields:
            lines.extend(["", "**待复核字段：** " + "、".join(low_fields)])
        lines.append("")

    raw_text = ""
    if result and result.raw_text:
        raw_text = result.raw_text
    elif extraction and extraction.raw_text:
        raw_text = extraction.raw_text
    if raw_text:
        lines.extend([_heading(heading_level + 1, "原始模型输出"), ""])
        lines.append(_details("展开原始输出", _code_block(raw_text, "json")))
        lines.append("")

    if state.error:
        lines.extend([_heading(heading_level + 1, "错误信息"), "", str(state.error), ""])

    return "\n".join(lines).rstrip() + "\n"


def build_batch_report(parent: TaskState, children: list[TaskState], note: str = "") -> str:
    """Build a deterministic comprehensive report for an archive/batch parent."""
    lines: list[str] = [f"# 压缩包综合报告：{parent.original_filename or parent.task_id}", ""]

    lines.extend(_metadata_block(parent))
    lines.append("")

    note = note.strip()
    if note:
        lines.extend(["## 附加说明", "", note, ""])

    status_counts: dict[str, int] = {}
    type_counts: dict[str, int] = {}
    for child in children:
        status_counts[child.status.value] = status_counts.get(child.status.value, 0) + 1
        type_counts[child.doc_type or "unknown"] = type_counts.get(child.doc_type or "unknown", 0) + 1

    lines.extend(["## 批次概览", ""])
    lines.append(
        _table(
            [
                {
                    "子文档数": len(children),
                    "已完成/待审核/失败": _format_counts(status_counts),
                    "文档类型分布": _format_counts(type_counts),
                    "目录": parent.folder_path,
                }
            ]
        )
    )
    lines.append("")

    lines.extend(["## 子文档目录", ""])
    lines.append(
        _table(
            [
                {
                    "序号": i,
                    "任务ID": child.task_id,
                    "文件名": child.original_filename,
                    "状态": child.status.value,
                    "文档类型": child.doc_type,
                    "置信度": (
                        f"{child.scored_result.overall_confidence:.3f}"
                        if child.scored_result
                        else ""
                    ),
                    "待审核": "是" if child.is_paused() else "否",
                }
                for i, child in enumerate(children, 1)
            ]
        )
        if children
        else "无子文档。"
    )
    lines.append("")

    for i, child in enumerate(children, 1):
        lines.append(build_task_report(child, heading_level=2).replace("## 综合报告：", f"## 文档 {i}：", 1).rstrip())
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _metadata_block(state: TaskState) -> list[str]:
    return [
        _table(
            [
                {
                    "任务ID": state.task_id,
                    "文件名": state.original_filename,
                    "状态": state.status.value,
                    "文件类型": state.file_type,
                    "文档类型": state.doc_type,
                    "创建时间": state.created_at,
                    "更新时间": state.updated_at,
                }
            ]
        )
    ]


def _heading(level: int, title: str) -> str:
    level = max(1, min(level, 6))
    return f"{'#' * level} {title}"


def _table(rows: Iterable[dict[str, Any]]) -> str:
    rows = list(rows)
    if not rows:
        return "无。"
    columns: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                columns.append(key)
                seen.add(key)

    out = [
        "| " + " | ".join(_escape_cell(c) for c in columns) + " |",
        "| " + " | ".join("---" for _ in columns) + " |",
    ]
    for row in rows:
        out.append(
            "| "
            + " | ".join(_escape_cell(_stringify(row.get(c, ""))) for c in columns)
            + " |"
        )
    return "\n".join(out)


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _escape_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\r\n", "<br>").replace("\n", "<br>")


def _details(summary: str, body: str) -> str:
    return f"<details>\n<summary>{summary}</summary>\n\n{body}\n\n</details>"


def _code_block(text: str, lang: str = "") -> str:
    fence = "```"
    if "```" in text:
        fence = "````"
    return f"{fence}{lang}\n{text}\n{fence}"


def _find_field_value(result: Any, name: str) -> Any:
    if result is None:
        return None
    for field in getattr(result, "fields", []) or []:
        if field.name == name:
            return field.value
    return None


def _first_non_empty(*values: Any) -> list[dict[str, Any]]:
    for value in values:
        if value:
            return list(value)
    return []


def _format_counts(counts: dict[str, int]) -> str:
    if not counts:
        return "无"
    return "、".join(f"{key}: {value}" for key, value in sorted(counts.items()))
