"""Deterministic policy for deciding whether a document may auto-activate.

The policy deliberately ignores the legacy aggregate ``needs_review`` flag: old
versions of M1 derived that flag from empty compatibility fields.  It rebuilds
the decision from source validation issues and field provenance instead.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ReviewPolicyModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ReviewBlocker(ReviewPolicyModel):
    code: str
    path: str = "$"
    detail: str = ""


class ReviewAssessment(ReviewPolicyModel):
    requires_review: bool
    blockers: list[ReviewBlocker] = Field(default_factory=list)

    @property
    def reason_codes(self) -> list[str]:
        return list(dict.fromkeys(blocker.code for blocker in self.blockers))


_PATH_TOKEN = re.compile(r"\.([A-Za-z0-9_]+)|\[(\d+)\]")


def _resolve_path(payload: Any, path: str) -> Any:
    if not path.startswith("$"):
        return None
    current = payload
    for match in _PATH_TOKEN.finditer(path[1:]):
        key, index = match.groups()
        if key is not None:
            if not isinstance(current, dict):
                return None
            current = current.get(key)
        else:
            if not isinstance(current, list) or int(index) >= len(current):
                return None
            current = current[int(index)]
    return current


def _is_present(value: Any) -> bool:
    return value not in (None, "", [], {})


def _positive_number(value: Any) -> bool:
    try:
        return Decimal(str(value)) > 0
    except (InvalidOperation, TypeError, ValueError):
        return False


def _nonempty_text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _nested_value_is_present(value: Any) -> bool:
    """Return whether a structured value contains information, not just shape."""

    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, bool):
        return value
    if isinstance(value, dict):
        return any(_nested_value_is_present(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(_nested_value_is_present(item) for item in value)
    # A zero-valued compatibility counter (for example ``lines.item_count``)
    # is bookkeeping, not proof that technical content was structured.
    return value not in (None, 0)


def _section_has_source_content(section: Any) -> bool:
    if not isinstance(section, dict):
        return _nonempty_text(section)
    for key in ("text", "text_original", "text_normalized", "markdown"):
        if _nonempty_text(section.get(key)):
            return True
    content = section.get("content")
    if _nonempty_text(content):
        return True
    if isinstance(content, dict):
        for key in ("text", "text_original", "text_normalized", "markdown"):
            if _nonempty_text(content.get(key)):
                return True
        if any(content.get(key) for key in ("rows", "cells", "images")):
            return True
    return str(section.get("kind") or "").casefold() == "image" and bool(content)


def _technical_source_has_content(document: dict[str, Any]) -> bool:
    """Detect source evidence without treating parser metadata as document text."""

    extraction = document.get("extraction")
    if not isinstance(extraction, dict):
        extraction = {}
    raw_content = extraction.get("raw_content")
    if not isinstance(raw_content, dict):
        raw_content = document.get("raw_content")
    if not isinstance(raw_content, dict):
        raw_content = {}

    for key in ("text", "text_original", "text_normalized", "markdown"):
        if _nonempty_text(raw_content.get(key)):
            return True
    if any(raw_content.get(key) for key in ("images", "tables")):
        return True

    for page in raw_content.get("pages") or []:
        if not isinstance(page, dict):
            continue
        for key in ("text", "text_original", "text_normalized", "markdown"):
            if _nonempty_text(page.get(key)):
                return True
        if any(
            page.get(key) for key in ("images", "tables", "ocr_tables", "render_asset")
        ):
            return True
        if any(
            _section_has_source_content(block) for block in page.get("blocks") or []
        ):
            return True

    sections = extraction.get("sections")
    if not isinstance(sections, list):
        sections = document.get("sections")
    return isinstance(sections, list) and any(
        _section_has_source_content(section) for section in sections
    )


def _typed_field_has_value(field: Any) -> bool:
    if not isinstance(field, dict) or field.get("applicable") is False:
        return False
    name = str(field.get("name") or "").strip().casefold()
    # Compatibility projections expose validation messages as fields for the
    # old UI. They describe extraction failure; they are not extracted data.
    if name.startswith("validation.issue."):
        return False
    return _nested_value_is_present(field.get("value"))


def _technical_structure_is_present(document: dict[str, Any]) -> bool:
    """Detect any typed technical result using contract-level containers.

    This intentionally does not know document templates.  A title/identifier,
    evidence-backed field, detail row, BOM, key dimension or other typed result
    is enough to show that raw source content was actually structured.
    """

    field_meta = document.get("field_meta")
    if isinstance(field_meta, dict):
        for path, raw_meta in field_meta.items():
            if not isinstance(raw_meta, dict) or raw_meta.get("accepted") is False:
                continue
            if _nested_value_is_present(_resolve_path(document, str(path))):
                return True

    header = document.get("header")
    if isinstance(header, dict) and any(
        _nested_value_is_present(value)
        for key, value in header.items()
        if key not in {"candidate_numbers", "date_inferred"}
    ):
        return True

    for key in (
        "lines",
        "bom",
        "key_dimensions",
        "details",
        "title_block",
        "technical_requirements",
        "revision_history",
    ):
        if _nested_value_is_present(document.get(key)):
            return True

    fields = document.get("fields")
    if isinstance(fields, list) and any(
        _typed_field_has_value(field) for field in fields
    ):
        return True

    scored_result = document.get("scored_result")
    if isinstance(scored_result, dict):
        if any(
            _nested_value_is_present(scored_result.get(key))
            for key in ("bom", "key_dimensions")
        ):
            return True
        scored_fields = scored_result.get("fields")
        if isinstance(scored_fields, list) and any(
            _typed_field_has_value(field) for field in scored_fields
        ):
            return True
    return False


_IMAGE_IDENTITY_FIELDS = (
    "asset_id",
    "image_id",
    "asset_path",
    "target_part",
    "relationship_id",
    "sha256",
    "id",
    "ref",
    "part",
    "path",
)


def _normalized_image_ref(value: Any) -> str:
    return str(value or "").strip().replace("\\", "/").casefold()


_STABLE_VISUAL_ID_RE = re.compile(
    r"^(?:page[-_:]?\d+[-_:])?(?:image|img|rid|relationship)[-_:]?[a-z0-9]+$",
    re.IGNORECASE,
)


def _identity_aliases(value: Any) -> set[str]:
    normalized = _normalized_image_ref(value)
    if not normalized:
        return set()
    compact = re.sub(r"[^a-z0-9]+", "", normalized)
    aliases = {f"value:{normalized}"}
    # Compact aliases bridge punctuation differences only for explicit visual
    # IDs such as ``page-1:image-1``. Applying the transform to paths would
    # collapse distinct assets such as ``front-view.png``/``frontview.png`` or
    # ``正视图.png``/``侧视图.png`` and make the gate fail open.
    if compact and _STABLE_VISUAL_ID_RE.fullmatch(normalized):
        aliases.add(f"compact:{compact}")
    return aliases


def _image_ref_aliases(value: Any) -> set[str]:
    if isinstance(value, dict):
        aliases: set[str] = set()
        for field in _IMAGE_IDENTITY_FIELDS:
            aliases.update(_identity_aliases(value.get(field)))
        return aliases
    return _identity_aliases(value)


def _page_part_aliases(page_number: Any, part: Any) -> set[str]:
    if not _is_present(page_number) or not _is_present(part):
        return set()
    return _identity_aliases(f"page-{page_number}:{part}")


def _asset_aliases(
    image: dict[str, Any],
    *,
    page_number: Any = None,
    page_render: bool = False,
) -> set[str]:
    aliases = _image_ref_aliases(image)
    if page_render and _is_present(page_number):
        aliases.add(f"render-page:{page_number}")
        return aliases
    for field in _IMAGE_IDENTITY_FIELDS:
        aliases.update(_page_part_aliases(page_number, image.get(field)))
    return aliases


def _source_ref_aliases(value: Any) -> set[str]:
    if not isinstance(value, dict):
        return set()
    aliases = _image_ref_aliases(value)
    page_number = value.get("page")
    if _is_present(page_number):
        # A page locator identifies the retained full-page render. It does not
        # identify arbitrary embedded images unless ``part`` also matches them.
        aliases.add(f"render-page:{page_number}")
    for field in _IMAGE_IDENTITY_FIELDS:
        aliases.update(_page_part_aliases(page_number, value.get(field)))
    return aliases


def _technical_image_groups(document: dict[str, Any]) -> list[set[str]]:
    extraction = document.get("extraction")
    if not isinstance(extraction, dict):
        extraction = {}
    raw_content = extraction.get("raw_content")
    if not isinstance(raw_content, dict):
        raw_content = document.get("raw_content")
    if not isinstance(raw_content, dict):
        return []
    images: list[tuple[dict[str, Any], Any, bool]] = [
        (image, image.get("page"), False)
        for image in raw_content.get("images") or []
        if isinstance(image, dict)
    ]
    for page in raw_content.get("pages") or []:
        if isinstance(page, dict):
            page_number = page.get("page_number")
            images.extend(
                (image, page_number, False)
                for image in page.get("images") or []
                if isinstance(image, dict)
            )
            if _is_present(page.get("render_asset")):
                images.append(({"asset_path": page["render_asset"]}, page_number, True))

    # The same retained image may be represented in both the document-level
    # inventory and a page inventory. Merge entries sharing any stable alias.
    groups: list[set[str]] = []
    for image, page_number, page_render in images:
        aliases = _asset_aliases(
            image,
            page_number=page_number,
            page_render=page_render,
        )
        matching = [index for index, group in enumerate(groups) if group & aliases]
        if not matching:
            groups.append(aliases)
            continue
        combined = set(aliases)
        for index in reversed(matching):
            combined.update(groups.pop(index))
        groups.append(combined)
    return groups


def _technical_image_count(document: dict[str, Any]) -> int:
    return len(_technical_image_groups(document))


def _source_ref_is_locatable(value: Any) -> bool:
    return isinstance(value, dict) and any(
        _is_present(value.get(field))
        for field in ("sheet", "page", "cell", "range", "part", "archive_path")
    )


def clean_full_semantic_authority(document: dict[str, Any]) -> bool:
    """Return whether the final full-authority audit closed every evidence gap."""

    extraction = document.get("extraction")
    if not isinstance(extraction, dict):
        return False
    metadata = extraction.get("metadata")
    raw_content = extraction.get("raw_content")
    if not isinstance(metadata, dict) or not isinstance(raw_content, dict):
        return False
    try:
        unresolved_count = int(metadata.get("evidence_unresolved_count") or 0)
    except (TypeError, ValueError):
        return False
    if (
        str(metadata.get("authority_mode") or "").casefold() != "full"
        or metadata.get("authority_selected") is not True
        or metadata.get("evidence_complete") is not True
        or metadata.get("accounted_complete") is not True
        or metadata.get("retained_complete") is not True
        or unresolved_count != 0
    ):
        return False
    audit = raw_content.get("semantic_completeness_audit")
    if not isinstance(audit, dict) or (
        audit.get("schema_version") != "m1.semantic-completion.v1"
        or audit.get("review_required") is not False
    ):
        return False
    counts = audit.get("counts")
    if not isinstance(counts, dict):
        return False
    try:
        evidence_total = int(counts.get("evidence_total"))
        evidence_accounted = int(counts.get("evidence_accounted"))
        source_ambiguous = int(counts.get("source_evidence_ambiguous"))
        source_needs_review = int(counts.get("source_evidence_needs_review"))
    except (TypeError, ValueError):
        return False
    return bool(
        evidence_total >= 0
        and evidence_accounted == evidence_total
        and source_ambiguous == 0
        and source_needs_review == 0
    )


def _metadata_has_locatable_sources(metadata: dict[str, Any]) -> bool:
    source_refs = metadata.get("source_refs")
    return isinstance(source_refs, list) and any(
        _source_ref_is_locatable(source_ref) for source_ref in source_refs
    )


def _normalized_replay_text(value: Any) -> str:
    return " ".join(
        unicodedata.normalize("NFKC", str(value or "")).casefold().split()
    )


def _value_replays_in_source(value: Any, metadata: dict[str, Any]) -> bool:
    expected = _normalized_replay_text(value)
    if not expected or isinstance(value, (dict, list, tuple, set)):
        return False
    for source_ref in metadata.get("source_refs") or []:
        if not isinstance(source_ref, dict):
            continue
        quote = _normalized_replay_text(source_ref.get("evidence_quote"))
        if quote and expected in quote:
            return True
    return False


def _field_is_structural_label(document: dict[str, Any], path: str, value: Any) -> bool:
    if not path.endswith(".name"):
        return False
    parent = _resolve_path(document, path.removesuffix(".name"))
    return bool(
        isinstance(parent, dict)
        and parent.get("name") == value
        and _is_present(parent.get("value"))
    )


def _grounded_technical_inference_is_safe(
    *,
    document_type: str,
    metadata: dict[str, Any],
    clean_semantic_authority: bool,
) -> bool:
    return bool(
        document_type == "technical_document"
        and clean_semantic_authority
        and metadata.get("review_required") is not True
        and metadata.get("sensitive") is not True
        and _metadata_has_locatable_sources(metadata)
    )


def _grounded_low_confidence_technical_field_is_safe(
    *,
    document: dict[str, Any],
    document_type: str,
    path: str,
    value: Any,
    metadata: dict[str, Any],
    clean_semantic_authority: bool,
) -> bool:
    return bool(
        _grounded_technical_inference_is_safe(
            document_type=document_type,
            metadata=metadata,
            clean_semantic_authority=clean_semantic_authority,
        )
        and (
            _value_replays_in_source(value, metadata)
            or _field_is_structural_label(document, path, value)
        )
    )


def _verified_visual_image_groups(
    document: dict[str, Any], groups: list[set[str]]
) -> set[int]:
    extraction = document.get("extraction")
    if not isinstance(extraction, dict):
        return set()
    covered: set[int] = set()
    for fact in extraction.get("visual_facts") or []:
        if not isinstance(fact, dict):
            continue
        source_refs = fact.get("source_refs")
        if not isinstance(source_refs, list):
            continue
        replayable_sources = [
            _source_ref_aliases(source_ref)
            for source_ref in source_refs
            if _source_ref_is_locatable(source_ref)
        ]
        refs = fact.get("image_refs") or fact.get("visual_source_refs") or []
        if not isinstance(refs, list):
            refs = [refs]
        used_sources: set[int] = set()
        for ref in refs:
            referenced_aliases = _image_ref_aliases(ref)
            candidate_groups = [
                index
                for index, aliases in enumerate(groups)
                if aliases & referenced_aliases
            ]
            assignment = next(
                (
                    (group_index, source_index)
                    for group_index in candidate_groups
                    for source_index, source_aliases in enumerate(replayable_sources)
                    if source_index not in used_sources
                    and groups[group_index] & source_aliases
                ),
                None,
            )
            if assignment is None:
                continue
            group_index, source_index = assignment
            used_sources.add(source_index)
            covered.add(group_index)
    return covered


def _unverified_technical_image_count(document: dict[str, Any]) -> int:
    groups = _technical_image_groups(document)
    covered = _verified_visual_image_groups(document, groups)
    return sum(
        not aliases or index not in covered for index, aliases in enumerate(groups)
    )


def _technical_images_are_linked(document: dict[str, Any]) -> bool:
    """Require replayable visual evidence for every retained image."""

    return _unverified_technical_image_count(document) == 0


_APPROVAL_PERSON_FIELDS = {
    "checker": ("checked_by", "check_by", "checker"),
    "approver": ("approved_by", "approve_by", "approver"),
}
_APPROVAL_VERSION_FIELDS = (
    "version",
    "revision",
    "revision_code",
    "revision_number",
    "rev",
)
_APPROVAL_LABEL_RE = re.compile(
    r"(?:\u7ed8\u56fe|\u5236\u56fe|\u8bbe\u8ba1|\u65e5\u671f|\u5ba1\u6838|\u5ba1\u6279|\u6838\u51c6|\u6279\u51c6|\u6821\u5bf9|\u68c0\u67e5|\u62df\u5236|"
    r"\bdrawn(?:\s+by)?\b|\bdesign(?:ed|er)?\b|\bdate\b|"
    r"\bcheck(?:ed|er)?\b|\bapprov(?:al|e|ed|er)\b|\breview(?:ed|er)?\b)",
    re.IGNORECASE,
)
_DATE_LIKE_RE = re.compile(
    r"(?<!\d)(?:19|20)\d{2}\s*[./-]\s*\d{1,2}(?:\s*[./-]\s*\d{1,2})?(?!\d)"
)


def _approval_person_is_name_like(value: Any) -> bool:
    text = str(value or "").strip()
    if not text or len(text) > 64:
        return False
    if _APPROVAL_LABEL_RE.search(text) or _DATE_LIKE_RE.search(text):
        return False
    if text.casefold() in {"n/a", "na", "none", "null", "unknown", "tbd"}:
        return False
    return bool(re.search(r"[A-Za-z\u4e00-\u9fff]", text))


def _approval_source_is_dedicated(
    document: dict[str, Any], fields: tuple[str, ...], value: Any
) -> bool:
    field_meta = document.get("field_meta")
    if not isinstance(field_meta, dict):
        return False
    approval_fields = {
        *_APPROVAL_VERSION_FIELDS,
        *(field for aliases in _APPROVAL_PERSON_FIELDS.values() for field in aliases),
    }
    approval_metadata = {
        str(path): meta
        for path, meta in field_meta.items()
        if str(path).rsplit(".", 1)[-1] in approval_fields
    }
    if not approval_metadata:
        return False
    for path, meta in approval_metadata.items():
        if path.rsplit(".", 1)[-1] not in fields or not isinstance(meta, dict):
            continue
        if _resolve_path(document, path) != value:
            continue
        source_refs = meta.get("source_refs")
        if isinstance(source_refs, list) and any(
            _source_ref_is_locatable(source_ref) for source_ref in source_refs
        ):
            return True
    return False


def _approval_person_is_present(
    document: dict[str, Any],
    header: dict[str, Any],
    title_block: dict[str, Any],
    fields: tuple[str, ...],
) -> bool:
    for container in (header, title_block):
        for field in fields:
            value = container.get(field)
            if _approval_person_is_name_like(value) and _approval_source_is_dedicated(
                document, fields, value
            ):
                return True
    return False


def _approval_version_is_present(
    document: dict[str, Any],
    header: dict[str, Any],
    title_block: dict[str, Any],
) -> bool:
    for container in (header, title_block):
        for field in _APPROVAL_VERSION_FIELDS:
            value = container.get(field)
            if _is_present(value) and _approval_source_is_dedicated(
                document, _APPROVAL_VERSION_FIELDS, value
            ):
                return True
    return False


def _missing_approval_metadata(document: dict[str, Any]) -> list[str]:
    header = document.get("header") if isinstance(document.get("header"), dict) else {}
    title_block = (
        document.get("title_block")
        if isinstance(document.get("title_block"), dict)
        else {}
    )
    extraction = document.get("extraction")
    if isinstance(extraction, dict) and isinstance(extraction.get("title_block"), dict):
        title_block = {**extraction["title_block"], **title_block}

    missing: list[str] = []
    if not _approval_person_is_present(
        document, header, title_block, _APPROVAL_PERSON_FIELDS["checker"]
    ):
        missing.append("checker")
    if not _approval_person_is_present(
        document, header, title_block, _APPROVAL_PERSON_FIELDS["approver"]
    ):
        missing.append("approver")
    if not _approval_version_is_present(document, header, title_block):
        missing.append("version_or_revision")
    return missing


def _approval_metadata_is_present(document: dict[str, Any]) -> bool:
    return not _missing_approval_metadata(document)


def _normalized_identifier(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").casefold())


def _filename_identifier_candidates(document: dict[str, Any]) -> list[str]:
    source = document.get("source") if isinstance(document.get("source"), dict) else {}
    filename = str(source.get("original_filename") or "")
    stem = filename.rsplit(".", 1)[0]
    candidates = re.findall(
        r"[A-Za-z]{2,}[._-]?\d+(?:[._-]\d+)*|(?<!\d)\d{4,}(?:[._-]\d+)*",
        stem,
    )

    def is_calendar_value(value: str) -> bool:
        digits = re.sub(r"\D", "", value)
        if len(digits) == 4 and 1900 <= int(digits) <= 2100:
            return True
        if len(digits) != 8 or not digits.startswith(("19", "20")):
            return False
        try:
            date(int(digits[:4]), int(digits[4:6]), int(digits[6:8]))
        except ValueError:
            return False
        return True

    return list(
        dict.fromkeys(
            item
            for item in candidates
            if _normalized_identifier(item) and not is_calendar_value(item)
        )
    )


def _drawing_identifier_conflicts_with_filename(document: dict[str, Any]) -> bool:
    header = document.get("header") if isinstance(document.get("header"), dict) else {}
    drawing_number = _normalized_identifier(header.get("drawing_number"))
    candidates = {
        _normalized_identifier(item)
        for item in _filename_identifier_candidates(document)
    }
    if not drawing_number or not candidates:
        return False
    return not any(
        drawing_number == candidate
        or drawing_number in candidate
        or candidate in drawing_number
        for candidate in candidates
    )


def assess_document_review(
    document: dict[str, Any],
    *,
    confidence_threshold: float = 0.9,
    allow_inferred: bool = False,
) -> ReviewAssessment:
    """Rebuild the review decision from authoritative document evidence.

    Warning/error validation issues, low-confidence populated fields and
    inferred values remain human-review gates.  Empty optional fields and
    unapplied semantic suggestions do not block activation.
    """

    blockers: list[ReviewBlocker] = []
    document_type = str(document.get("document_type") or "unknown").strip().casefold()
    clean_semantic_authority = clean_full_semantic_authority(document)
    if document_type in {"", "unknown"}:
        blockers.append(
            ReviewBlocker(code="DOCUMENT_TYPE_UNKNOWN", path="$.document_type")
        )

    for index, issue in enumerate(document.get("validation_issues") or []):
        if not isinstance(issue, dict):
            continue
        status = str(issue.get("status") or "open").strip().casefold()
        severity = str(issue.get("severity") or "warning").strip().casefold()
        if status in {"resolved", "accepted", "ignored"} or severity == "info":
            continue
        paths = issue.get("paths") if isinstance(issue.get("paths"), list) else []
        blockers.append(
            ReviewBlocker(
                code=str(issue.get("code") or "VALIDATION_ISSUE"),
                path=str(paths[0]) if paths else f"$.validation_issues[{index}]",
                detail=str(issue.get("message") or "")[:500],
            )
        )

    field_meta = document.get("field_meta")
    if isinstance(field_meta, dict):
        for path, raw_meta in field_meta.items():
            if not isinstance(raw_meta, dict) or raw_meta.get("accepted") is False:
                continue
            value = _resolve_path(document, str(path))
            if not _is_present(value):
                continue
            confidence = float(raw_meta.get("confidence", 1.0))
            grounded_inference_is_safe = _grounded_technical_inference_is_safe(
                document_type=document_type,
                metadata=raw_meta,
                clean_semantic_authority=clean_semantic_authority,
            )
            if confidence < confidence_threshold and not (
                _grounded_low_confidence_technical_field_is_safe(
                    document=document,
                    document_type=document_type,
                    path=str(path),
                    value=value,
                    metadata=raw_meta,
                    clean_semantic_authority=clean_semantic_authority,
                )
            ):
                blockers.append(
                    ReviewBlocker(
                        code="LOW_CONFIDENCE_FIELD",
                        path=str(path),
                        detail=f"confidence={confidence:.4f}",
                    )
                )
            # Rule-derived compatibility fields retain ``inferred=True`` for
            # audit provenance, but may explicitly state that they add no new
            # document-level uncertainty.  Default to review for all existing
            # metadata so OCR, date and model inferences remain gated.
            if (
                raw_meta.get("inferred")
                and raw_meta.get("review_required") is not False
                and not allow_inferred
                and not grounded_inference_is_safe
            ):
                blockers.append(ReviewBlocker(code="INFERRED_FIELD", path=str(path)))

    if document_type == "order":
        header = document.get("header")
        if not isinstance(header, dict) or not any(
            _is_present(header.get(field))
            for field in ("order_number", "contract_number")
        ):
            blockers.append(
                ReviewBlocker(
                    code="ORDER_NUMBER_MISSING",
                    path="$.header.order_number",
                )
            )
        lines = document.get("lines")
        if not isinstance(lines, list) or not lines:
            blockers.append(ReviewBlocker(code="ORDER_LINES_EMPTY", path="$.lines"))
        else:
            for index, line in enumerate(lines):
                if not isinstance(line, dict):
                    blockers.append(
                        ReviewBlocker(
                            code="ORDER_LINE_INVALID", path=f"$.lines[{index}]"
                        )
                    )
                    continue
                if not any(
                    _is_present(line.get(field))
                    for field in ("model", "product_code", "name_raw")
                ):
                    blockers.append(
                        ReviewBlocker(
                            code="LINE_IDENTITY_MISSING",
                            path=f"$.lines[{index}]",
                        )
                    )
                if not _positive_number(line.get("quantity")):
                    blockers.append(
                        ReviewBlocker(
                            code="LINE_QUANTITY_INVALID",
                            path=f"$.lines[{index}].quantity",
                        )
                    )

    technical_source_has_content = bool(
        document_type == "technical_document"
        and _technical_source_has_content(document)
    )
    if technical_source_has_content and not _technical_structure_is_present(document):
        blockers.append(
            ReviewBlocker(
                code="TECHNICAL_STRUCTURE_MISSING",
                path="$.extraction",
                detail=(
                    "The source contains text, images, or tables, but no typed "
                    "technical content was extracted."
                ),
            )
        )

    document_subtype = (
        str(document.get("document_subtype") or "unknown").strip().casefold()
    )
    if document_type == "technical_document" and document_subtype == "approval_drawing":
        image_count = _technical_image_count(document)
        unverified_image_count = _unverified_technical_image_count(document)
        if not image_count:
            blockers.append(
                ReviewBlocker(
                    code="TECHNICAL_VISUAL_FACTS_UNVERIFIED",
                    path="$.extraction.raw_content.images",
                    detail=(
                        "No retained visual asset is available for replayable "
                        "approval-drawing verification."
                    ),
                )
            )
        elif unverified_image_count:
            blockers.append(
                ReviewBlocker(
                    code="TECHNICAL_VISUAL_FACTS_UNVERIFIED",
                    path="$.extraction.raw_content.images",
                    detail=(
                        f"{unverified_image_count} of {image_count} retained image(s) "
                        "have no replayable visual facts."
                    ),
                )
            )
        missing_approval_metadata = _missing_approval_metadata(document)
        if missing_approval_metadata:
            blockers.append(
                ReviewBlocker(
                    code="APPROVAL_METADATA_MISSING",
                    path="$.title_block",
                    detail=(
                        "Missing required approval evidence: "
                        + ", ".join(missing_approval_metadata)
                        + "."
                    ),
                )
            )
    if (
        document_type == "technical_document"
        and document_subtype in {"approval_drawing", "engineering_drawing"}
        and _drawing_identifier_conflicts_with_filename(document)
    ):
        blockers.append(
            ReviewBlocker(
                code="DRAWING_IDENTIFIER_CONFLICT",
                path="$.header.drawing_number",
                detail="The drawing identifier conflicts with filename evidence.",
            )
        )

    unique: dict[tuple[str, str], ReviewBlocker] = {}
    for blocker in blockers:
        unique.setdefault((blocker.code, blocker.path), blocker)
    result = list(unique.values())
    return ReviewAssessment(requires_review=bool(result), blockers=result)


__all__ = [
    "ReviewAssessment",
    "ReviewBlocker",
    "assess_document_review",
    "clean_full_semantic_authority",
]
