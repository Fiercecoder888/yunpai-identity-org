"""schemas 包入口。"""
from .base import ScoredField, ScoredResult, ExtractedField, ExtractionResult
from .cad_drawing import (
    MechanicalDrawing,
    TitleBlock,
    BomItem,
    DesignRevision,
    KEY_FIELDS,
)
from .commercial import (
    CommercialDocument,
    CommercialLine,
    Party,
    KEY_FIELDS_COMMERCIAL,
)
from .bom import BillOfMaterials, BomRow
from .sop import StandardOperatingProcedure, OperationStep
from .registry import (
    DocTypeSpec,
    get_spec,
    get_schema_cls,
    get_key_fields,
    supported_types,
    register,
)

__all__ = [
    # base
    "ScoredField",
    "ScoredResult",
    "ExtractedField",
    "ExtractionResult",
    # drawing
    "MechanicalDrawing",
    "TitleBlock",
    "BomItem",
    "DesignRevision",
    "KEY_FIELDS",
    # commercial (order/quotation/po)
    "CommercialDocument",
    "CommercialLine",
    "Party",
    "KEY_FIELDS_COMMERCIAL",
    # bom / sop
    "BillOfMaterials",
    "BomRow",
    "StandardOperatingProcedure",
    "OperationStep",
    # registry
    "DocTypeSpec",
    "get_spec",
    "get_schema_cls",
    "get_key_fields",
    "supported_types",
    "register",
]
