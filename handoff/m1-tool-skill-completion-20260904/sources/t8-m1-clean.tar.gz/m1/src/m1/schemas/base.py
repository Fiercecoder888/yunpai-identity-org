"""Schema 基类与置信度模型。

所有抽取结果都带置信度与 needs_review 标记,
置信度 < CONFIDENCE_THRESHOLD 的字段会触发人工审核。
"""
from __future__ import annotations

from typing import Any, Optional
from pydantic import BaseModel, Field


# ----------------------------------------------------------------------
# 通用置信度结构
# ----------------------------------------------------------------------
class ScoredField(BaseModel):
    """单个字段 + 其置信度。"""

    name: str
    value: Any
    # 综合置信度 [0, 1]
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    # 低于阈值则标 true, 触发人工审核
    needs_review: bool = False
    # 兼容投影会保留部分并不适用于当前模板的空字段。此类字段可继续在
    # 旧 UI 中展示，但不能以 ``confidence=0`` 人为触发整份文档审核。
    applicable: bool = True
    # 置信度分项 (调试/审计用)
    breakdown: dict[str, float] = Field(default_factory=dict)


class ScoredResult(BaseModel):
    """一份文档抽取的最终结果: 字段列表 + 整体是否需要审核。"""

    task_id: str
    fields: list[ScoredField] = Field(default_factory=list)
    # 动态补充字段 (本地小模型探测出、但未命中预定义模板的字段)
    # 不参与 overall_confidence 的强约束, 走弱规则, 在审核台单独渲染
    extra_fields: list[ScoredField] = Field(default_factory=list)
    # 模型原始输出 (debug/回溯)
    raw_text: str = ""
    # 完整明细 (供前端表格展示)
    bom: list[dict] = Field(default_factory=list)
    key_dimensions: list[dict] = Field(default_factory=list)
    # 整体综合置信度 (取所有字段最小值)
    overall_confidence: float = 0.0
    # 是否需要人工审核
    needs_review: bool = False
    # 审核状态: pending / approved / rejected / reviewed
    review_status: str = "auto_approved"

    def recompute_flags(self, threshold: float = 0.9) -> None:
        """根据阈值重算 needs_review 标记。"""
        applicable_fields = [field for field in self.fields if field.applicable]
        if not applicable_fields:
            self.overall_confidence = 0.0
        else:
            self.overall_confidence = min(
                field.confidence for field in applicable_fields
            )
        self.needs_review = any(
            field.confidence < threshold for field in applicable_fields
        )
        for field in self.fields:
            field.needs_review = (
                field.applicable and field.confidence < threshold
            )
        self.review_status = "needs_review" if self.needs_review else "auto_approved"


# ----------------------------------------------------------------------
# 抽取结果 (VLM 输出)
# ----------------------------------------------------------------------
class ExtractedField(BaseModel):
    """VLM 直接输出的单字段 (无置信度, 置信度由融合器后置计算)。"""

    name: str
    value: Any
    # 可选: 字段值在原文中的位置/检测框, 用于 OCR 置信度对齐
    bbox: Optional[list[float]] = None  # [x1, y1, x2, y2]
    # 可选: OCR 识别置信度 (若来源是 OCR)
    ocr_confidence: Optional[float] = None


class ExtractionResult(BaseModel):
    """VLM 结构化抽取的原始结果。"""

    fields: list[ExtractedField] = Field(default_factory=list)
    # 动态补充字段 (VLM 自动发现、未命中模板的字段, 走弱规则)
    extra_fields: list[ExtractedField] = Field(default_factory=list)
    raw_text: str = ""
    # 保留完整的明细表/尺寸列表 (供前端表格展示, 不只是计数)
    bom: list[dict] = Field(default_factory=list)
    key_dimensions: list[dict] = Field(default_factory=list)
    # VLM 自评置信度 (字段名 → {"self": float, "clarity": float})
    # 替代失效的 logprob 信号: VLM 对每个字段给出自己的把握度 self
    # 和视觉清晰度 clarity (替代硬编码的 ocr 信号)
    field_confidences: dict[str, dict[str, float]] = Field(default_factory=dict)
