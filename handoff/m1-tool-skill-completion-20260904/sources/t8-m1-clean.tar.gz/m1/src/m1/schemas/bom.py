"""独立 BOM (物料清单) Schema。

区别于机械图纸明细表 (cad_drawing.BomItem 是图纸内的零件列表),
这是独立的采购/装配物料清单文档: 多层级、含供应商/参考价格。
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class BomRow(BaseModel):
    """物料清单的一行。"""

    level: Optional[str] = Field(default=None, description="层级, 如 1 / 1.1 / 2")
    index: Optional[int] = Field(default=None, description="序号")
    code: Optional[str] = Field(default=None, description="物料编码/图号")
    name: Optional[str] = Field(default=None, description="物料名称 (含规格/型号)")
    quantity: Optional[int | float | str] = Field(default=None, description="数量")
    unit: Optional[str] = Field(default=None, description="单位")
    material: Optional[str] = Field(default=None, description="材质")
    supplier: Optional[str] = Field(default=None, description="供应商")
    reference_price: Optional[str] = Field(default=None, description="参考单价 (原文)")
    remark: Optional[str] = Field(default=None, description="备注")


class BillOfMaterials(BaseModel):
    """独立的物料清单文档。"""

    bom_number: Optional[str] = Field(default=None, description="BOM 编号")
    product_name: Optional[str] = Field(default=None, description="产品名称")
    version: Optional[str] = Field(default=None, description="版本")
    date: Optional[str] = Field(default=None, description="编制日期")
    company: Optional[str] = Field(default=None, description="编制单位")
    rows: list[BomRow] = Field(default_factory=list, description="物料行")
    remark: Optional[str] = Field(default=None, description="备注")

    def to_flat_fields(self) -> list[tuple[str, object]]:
        flat: list[tuple[str, object]] = []
        flat.append(("bom_number", self.bom_number))
        flat.append(("product_name", self.product_name))
        flat.append(("version", self.version))
        flat.append(("date", self.date))
        flat.append(("company", self.company))
        flat.append(("rows.item_count", len(self.rows)))
        return flat


KEY_FIELDS = [
    "bom_number",
    "product_name",
    "rows.item_count",
]
