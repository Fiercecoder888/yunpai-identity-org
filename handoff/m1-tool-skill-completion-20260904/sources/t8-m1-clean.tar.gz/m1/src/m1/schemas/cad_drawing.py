"""标准机械图纸 JSON Schema。

覆盖标题栏 + 明细表 + 设计修订履历 (完整设计信息表),
适配 90% 的机械加工/装配图纸。

注: 关键尺寸标注已移除 (按需求, 尺寸信息由 SVG 视图承载, 不做结构化抽取)。
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


# ----------------------------------------------------------------------
# 标题栏 (Title Block)
# ----------------------------------------------------------------------
class TitleBlock(BaseModel):
    """图纸右下角标题栏的标准字段。

    注: 实际图纸的标题栏千差万别, 并非所有字段都存在。
    material/design_by/check_by/approve_by 在很多图纸中压根没有对应格子,
    此时填 null 是正确的, 不应被当作"识别失败"扣分 (见 confidence/rules.py)。
    """

    drawing_number: Optional[str] = Field(
        default=None, description="图号, 如 DWG-2024-001"
    )
    drawing_name: Optional[str] = Field(
        default=None, description="图样名称, 如 传动轴"
    )
    scale: Optional[str] = Field(default=None, description="比例, 如 1:2")
    material: Optional[str] = Field(
        default=None, description="材料, 如 45钢 / Q235 (若标题栏无此格, 填 null)"
    )
    unit: Optional[str] = Field(default=None, description="计量单位, 如 mm")
    design_by: Optional[str] = Field(
        default=None, description="设计人 (若标题栏无此格, 填 null)"
    )
    check_by: Optional[str] = Field(
        default=None, description="校对人 (若标题栏无此格, 填 null)"
    )
    approve_by: Optional[str] = Field(
        default=None, description="审核人 (若标题栏无此格, 填 null)"
    )
    design_date: Optional[str] = Field(default=None, description="设计日期 (当前版本)")
    company: Optional[str] = Field(default=None, description="单位/公司名")
    version: Optional[str] = Field(default=None, description="当前版本号/版本标记")


# ----------------------------------------------------------------------
# 明细表 (Parts List / BOM)
# ----------------------------------------------------------------------
class BomItem(BaseModel):
    """明细表中的一行零件。

    注: 实际图纸的"数量"列往往**带单位** (如 "50mm", "2pcs"),
    不同零件单位可能不同 (铜箔按长度 mm, 端子按个数 pcs)。
    所以 quantity 用 str 保留原始写法, 同时拆出纯数值和单位。
    """

    index: Optional[int] = Field(default=None, description="序号")
    code: Optional[str] = Field(default=None, description="物料编码/代号")
    name: Optional[str] = Field(default=None, description="物料/零件名称 (含规格)")
    quantity: Optional[int | float | str] = Field(
        default=None,
        description="数量 (保留原始写法, 可能含单位, 如 50mm / 2pcs / 1)",
    )
    unit: Optional[str] = Field(
        default=None,
        description="单位 (如 mm/m 表示长度, pcs/个 表示数量)。若数量列已含单位, 提取出来填这里",
    )
    remark: Optional[str] = Field(default=None, description="备注")


# ----------------------------------------------------------------------
# 设计修订履历 (完整设计信息表)
# ----------------------------------------------------------------------
class DesignRevision(BaseModel):
    """图纸版本变更记录的一行 —— 完整设计信息表。

    对应图纸标题栏旁的"版本变更记录/修订履历"表格的每一行。
    每个版本独立记录其设计/校对/审核签字人与日期, 形成完整修订履历。
    """

    version: Optional[str] = Field(default=None, description="版本号, 如 A/B/C")
    date: Optional[str] = Field(default=None, description="该版本日期, 如 2019.05.07")
    change_content: Optional[str] = Field(
        default=None, description="变更内容描述, 如 '屏蔽壳变更为清洗后的料号'"
    )
    mark: Optional[str] = Field(
        default=None, description="变更标记/符号, 如 △ / 1 / 2 (图纸上的修订云线圈号)"
    )
    ecn: Optional[str] = Field(
        default=None, description="工程变更通知单号 (ECN), 若图纸上有"
    )
    # 该版本的签字人 (完整设计信息: 每版谁设计/校对/审核)
    design_by: Optional[str] = Field(default=None, description="该版本设计人签字")
    check_by: Optional[str] = Field(default=None, description="该版本校对人签字")
    approve_by: Optional[str] = Field(default=None, description="该版本审核人签字")
    remark: Optional[str] = Field(default=None, description="备注")


# ----------------------------------------------------------------------
# 完整图纸 Schema
# ----------------------------------------------------------------------
class MechanicalDrawing(BaseModel):
    """一张机械图纸的完整结构化结果。"""

    title_block: TitleBlock = Field(default_factory=TitleBlock)
    bom: list[BomItem] = Field(default_factory=list, description="明细表")
    # 设计修订履历: 完整设计信息表, 每版一行 (版本/日期/变更/ECN/签字人)
    revision_history: list[DesignRevision] = Field(
        default_factory=list, description="设计修订履历 (完整设计信息表)"
    )
    technical_requirements: Optional[str] = Field(
        default=None, description="技术要求文本"
    )

    def to_flat_fields(self) -> list[tuple[str, object]]:
        """展平为 (字段名, 值) 列表, 便于置信度计算。"""
        flat: list[tuple[str, object]] = []
        # 标题栏字段
        for name, value in self.title_block.model_dump().items():
            flat.append((f"title_block.{name}", value))
        # 明细表行数
        flat.append(("bom.item_count", len(self.bom)))
        # 修订履历行数
        flat.append(("revision_history.item_count", len(self.revision_history)))
        # 技术要求
        flat.append(("technical_requirements", self.technical_requirements))
        return flat


# 核心必填字段: 几乎所有图纸都有的字段, 缺失视为识别问题
# 注意: material/design_by/check_by/approve_by 不在此列 ——
#       它们在很多图纸标题栏中压根没有对应格子, 填 null 是正常的
KEY_FIELDS = [
    "title_block.drawing_number",
    "title_block.drawing_name",
    "title_block.scale",
    "title_block.unit",
    "title_block.company",
]
