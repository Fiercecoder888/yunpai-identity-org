"""商业单据通用 Schema (订单/报价单/采购单共用的基础结构)。

三类单据字段高度重叠 (单号/日期/买卖方/明细行/金额/付款条款),
抽出一个 CommercialDocument 基础结构, 各自 KEY_FIELDS 微调。
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Party(BaseModel):
    """交易一方 (买方/卖方)。"""

    name: Optional[str] = Field(default=None, description="公司/单位名称")
    contact: Optional[str] = Field(default=None, description="联系人")
    phone: Optional[str] = Field(default=None, description="电话")
    address: Optional[str] = Field(default=None, description="地址")


class CommercialLine(BaseModel):
    """商业单据中的一行明细。"""

    index: Optional[int] = Field(default=None, description="序号")
    code: Optional[str] = Field(default=None, description="物料/产品编码")
    name: Optional[str] = Field(default=None, description="物料/产品名称 (含规格)")
    quantity: Optional[int | float | str] = Field(
        default=None, description="数量 (保留原始写法, 可能含单位)"
    )
    unit: Optional[str] = Field(default=None, description="单位")
    unit_price: Optional[str] = Field(
        default=None, description="单价 (保留原文, 如 12.50 / $1.2)"
    )
    amount: Optional[str] = Field(default=None, description="金额 (小计)")


class CommercialDocument(BaseModel):
    """商业单据通用结构 (订单/报价/采购单共用)。"""

    # 单据头
    doc_number: Optional[str] = Field(default=None, description="单据编号")
    doc_date: Optional[str] = Field(default=None, description="单据日期")
    valid_until: Optional[str] = Field(default=None, description="有效期 (报价单常见)")
    buyer: Party = Field(default_factory=Party, description="买方")
    seller: Party = Field(default_factory=Party, description="卖方")

    # 明细
    lines: list[CommercialLine] = Field(default_factory=list, description="明细行")

    # 金额
    currency: Optional[str] = Field(default=None, description="币种, 如 CNY/USD/RMB")
    total_amount: Optional[str] = Field(
        default=None, description="合计金额 (保留原文)"
    )

    # 条款
    payment_terms: Optional[str] = Field(default=None, description="付款条款")
    delivery_terms: Optional[str] = Field(default=None, description="交货条款/交期")
    remark: Optional[str] = Field(default=None, description="备注")

    def to_flat_fields(self) -> list[tuple[str, object]]:
        """展平为 (字段名, 值) 列表。"""
        flat: list[tuple[str, object]] = []
        flat.append(("doc_number", self.doc_number))
        flat.append(("doc_date", self.doc_date))
        flat.append(("valid_until", self.valid_until))
        flat.append(("buyer.name", self.buyer.name))
        flat.append(("seller.name", self.seller.name))
        flat.append(("lines.item_count", len(self.lines)))
        flat.append(("currency", self.currency))
        flat.append(("total_amount", self.total_amount))
        flat.append(("payment_terms", self.payment_terms))
        flat.append(("delivery_terms", self.delivery_terms))
        return flat


# 各类型的核心必填字段 (用于置信度强校验)
# 三类共用主体字段, KEY_FIELDS 的差异体现在单据编号语义上 (统一用 doc_number)
KEY_FIELDS_COMMERCIAL = [
    "doc_number",
    "doc_date",
    "buyer.name",
    "seller.name",
    "total_amount",
]
