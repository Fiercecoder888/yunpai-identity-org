"""文档类型注册表: doc_type → (Schema 类, KEY_FIELDS, 展平函数, 明细字段名)。

混合 schema 路由核心:
  - classify 节点判定 doc_type
  - extract 按 doc_type 选 prompt + schema
  - score 按 doc_type 选 KEY_FIELDS
  - UI 按 doc_type 选渲染器

新增类型只需在此注册一处 (并写对应 schema 文件 + prompt)。
"""
from __future__ import annotations

from typing import Callable, Optional

from pydantic import BaseModel

from .cad_drawing import MechanicalDrawing
from .commercial import CommercialDocument, KEY_FIELDS_COMMERCIAL
from .bom import BillOfMaterials, KEY_FIELDS as BOM_KEY_FIELDS
from .sop import StandardOperatingProcedure, KEY_FIELDS as SOP_KEY_FIELDS

# 图纸的 KEY_FIELDS 和明细字段
from .cad_drawing import KEY_FIELDS as DRAWING_KEY_FIELDS


# 明细字段名: ScoredResult 里存放多行明细的 key (供 UI 渲染)
# drawing 用 bom/key_dimensions; 其他类型统一用 details
DETAIL_KEY = "details"


class DocTypeSpec:
    """单个文档类型的规格。"""

    def __init__(
        self,
        doc_type: str,
        schema_cls: type[BaseModel],
        key_fields: list[str],
        flatten: Callable[[BaseModel], list[tuple[str, object]]],
        detail_key: str = DETAIL_KEY,
    ):
        self.doc_type = doc_type
        self.schema_cls = schema_cls
        self.key_fields = key_fields
        self.flatten = flatten
        self.detail_key = detail_key


# ----------------------------------------------------------------------
# 注册表
# ----------------------------------------------------------------------
_REGISTRY: dict[str, DocTypeSpec] = {}


def register(spec: DocTypeSpec) -> None:
    _REGISTRY[spec.doc_type] = spec


def get_spec(doc_type: str) -> Optional[DocTypeSpec]:
    """取某类型的规格; 未知类型返回 None (调用方应降级到 drawing 或标 unknown)。"""
    return _REGISTRY.get(doc_type)


def get_schema_cls(doc_type: str) -> Optional[type[BaseModel]]:
    spec = _REGISTRY.get(doc_type)
    return spec.schema_cls if spec else None


def get_key_fields(doc_type: str) -> list[str]:
    """取某类型的必填字段白名单; 未知类型返回空 (走纯弱规则)。"""
    spec = _REGISTRY.get(doc_type)
    return spec.key_fields if spec else []


def supported_types() -> list[str]:
    """所有已注册类型。"""
    return list(_REGISTRY.keys())


# 图纸 (明细字段特殊: bom + key_dimensions 两个 key)
class _DrawingSpec(DocTypeSpec):
    def __init__(self):
        super().__init__(
            doc_type="drawing",
            schema_cls=MechanicalDrawing,
            key_fields=DRAWING_KEY_FIELDS,
            flatten=MechanicalDrawing.to_flat_fields,
            detail_key="bom",  # 图纸明细用 bom (UI 特殊渲染)
        )


register(_DrawingSpec())
register(DocTypeSpec("order", CommercialDocument, KEY_FIELDS_COMMERCIAL, CommercialDocument.to_flat_fields))
register(DocTypeSpec("quotation", CommercialDocument, KEY_FIELDS_COMMERCIAL, CommercialDocument.to_flat_fields))
register(DocTypeSpec("po", CommercialDocument, KEY_FIELDS_COMMERCIAL, CommercialDocument.to_flat_fields))
register(DocTypeSpec("bom", BillOfMaterials, BOM_KEY_FIELDS, BillOfMaterials.to_flat_fields))
register(DocTypeSpec("sop", StandardOperatingProcedure, SOP_KEY_FIELDS, StandardOperatingProcedure.to_flat_fields))
