"""SOP (标准作业指导书) Schema。

图文混排的工艺文档: 工序号/工序名/设备/参数/工时/质检要求/图示说明。
"""
from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class OperationStep(BaseModel):
    """SOP 中的一个工序步骤。"""

    step_no: Optional[str] = Field(default=None, description="工序号, 如 10/20 或 1.1")
    name: Optional[str] = Field(default=None, description="工序名称")
    equipment: Optional[str] = Field(default=None, description="设备/工装")
    params: Optional[str] = Field(default=None, description="工艺参数 (温度/压力/转速等)")
    work_time: Optional[str] = Field(default=None, description="工时 (保留原文)")
    quality_req: Optional[str] = Field(default=None, description="质检要求/标准")
    description: Optional[str] = Field(default=None, description="操作说明文本")


class StandardOperatingProcedure(BaseModel):
    """标准作业指导书。"""

    sop_number: Optional[str] = Field(default=None, description="SOP 编号")
    product_name: Optional[str] = Field(default=None, description="产品/零件名称")
    process: Optional[str] = Field(default=None, description="工序/工艺名称")
    version: Optional[str] = Field(default=None, description="版本")
    date: Optional[str] = Field(default=None, description="编制/生效日期")
    company: Optional[str] = Field(default=None, description="编制单位")
    steps: list[OperationStep] = Field(default_factory=list, description="工序步骤")
    safety_notes: Optional[str] = Field(default=None, description="安全注意事项")
    remark: Optional[str] = Field(default=None, description="备注")

    def to_flat_fields(self) -> list[tuple[str, object]]:
        flat: list[tuple[str, object]] = []
        flat.append(("sop_number", self.sop_number))
        flat.append(("product_name", self.product_name))
        flat.append(("process", self.process))
        flat.append(("version", self.version))
        flat.append(("date", self.date))
        flat.append(("company", self.company))
        flat.append(("steps.item_count", len(self.steps)))
        return flat


KEY_FIELDS = [
    "sop_number",
    "product_name",
    "steps.item_count",
]
