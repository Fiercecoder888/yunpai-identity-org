"""工作流状态定义。

一个 TaskState 贯穿整个文档处理生命周期:
  created -> parsing -> extracting -> scoring -> [needs_review] -> done
                                                          |
                                                          v
                                                     (暂停, 等待人工审核提交后恢复 -> done)
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from .schemas import ExtractionResult, ScoredResult


class TaskStatus(str, Enum):
    CREATED = "created"
    PARSING = "parsing"
    EXTRACTING = "extracting"
    SCORING = "scoring"
    NEEDS_REVIEW = "needs_review"  # 暂停点: 等待人工审核
    DONE = "done"
    FAILED = "failed"


class TaskState(BaseModel):
    """单个文档处理任务的全状态。会被持久化到 DB, 支持 HITL 暂停/恢复。"""

    task_id: str
    # 基础知识库租户边界。旧任务没有该字段时自动归入 default，保持存量
    # state_json 可直接加载；新上传及其归档子任务会完整继承该值。
    tenant_id: str = "default"
    # 输入
    file_path: str = ""
    file_type: str = ""  # image | pdf | dxf | dwg | archive
    original_filename: str = ""
    display_filename: str = ""
    archive_path: str = ""

    # 文档业务类型 (混合 schema 路由用): drawing | order | quotation | po | bom | sop | unknown
    # 由 classify 节点判定; 默认 drawing 保持图纸链路向后兼容
    doc_type: str = "drawing"
    # m1.document.v2 业务子类型；不改变旧 doc_type 路由语义。
    document_subtype: str = ""
    # 当前持久化流水线阶段。对外状态枚举保持兼容，细粒度进度放在这里。
    processing_stage: str = "created"

    # 上传时可选提示。提示只影响分类/语义增强，不得覆盖原文件中的确定性事实。
    doc_type_hint: str = ""
    document_subtype_hint: str = ""
    semantic_enrichment: bool = True

    # 批量任务父子关系: 压缩包解压出的父任务记录所有子任务 id;
    # 子任务记录 parent_id。单文件上传时两者皆为空。
    parent_id: str = ""
    child_ids: list[str] = Field(default_factory=list)
    batch_inputs: list[dict[str, str]] = Field(default_factory=list)
    # Set only after every input/archive leaf has a durable child identity.
    # Recovery uses this marker to distinguish fan-out completion from a crash
    # after only some child rows were committed.
    batch_fanout_complete: bool = False

    # 批次专用 (父任务): 解压目录 + 智能汇总报告
    folder_path: str = ""  # 解压目录绝对路径 (前端展示"批次内容"用)
    batch_summary: str = ""  # 跨文档智能汇总报告 (Markdown, 所有子任务完成后异步生成)
    batch_summary_status: str = ""  # "" | pending | done | failed

    # 中间产物
    parsed_content: str = ""  # MinerU/ezdxf 解析后的文本/markdown
    # 新统一文档结果。使用 JSON 形态持久化，读取 API 时再由 m1.documents
    # 的 Pydantic 模型校验，避免旧任务数据库因代码升级而无法加载。
    document: dict[str, Any] | None = None
    document_schema_version: str = ""
    export_path: str = ""
    # Wiki/Graph 是旁路可重放投影；失败不会改变原 M1 任务终态。
    knowledge_sync_status: str = ""  # "" | pending | synced | skipped | failed
    knowledge_document_id: str = ""
    knowledge_version_id: str = ""
    knowledge_sync_error: str = ""
    # Value-free status for the isolated MinerU candidate path. This belongs to
    # task lifecycle state and must never be embedded in DocumentRecord or the
    # governed knowledge projection.
    mineru_shadow: dict[str, Any] = Field(default_factory=dict)
    # Monotonic revision for background MinerU status writes. The main workflow
    # can still hold an older TaskState while the candidate finishes, so normal
    # saves must not overwrite a completed/degraded sidecar result with queued.
    mineru_shadow_revision: int = 0
    # Monotonic sidecar revision.  The legacy workflow may persist an older
    # in-memory TaskState after Wiki/Graph sync finishes; TaskStore uses this
    # counter to reject only those stale sidecar fields while retaining every
    # original M1 workflow field.
    knowledge_sync_revision: int = 0
    extraction: ExtractionResult | None = None
    scored_result: ScoredResult | None = None
    # 单文件综合报告缓存。字段名沿用旧 API, 前端和测试仍读取 replication_doc/status。
    replication_doc: str = ""
    replication_status: str = ""  # "" | pending | done | failed
    # 详细复刻报告缓存。与综合报告分开, 避免两个下载/生成路径互相覆盖。
    detailed_replication_doc: str = ""
    detailed_replication_status: str = ""  # "" | pending | done | failed

    # 人工审核回填
    reviewed_result: ScoredResult | None = None
    reviewer: str | None = None
    review_comment: str | None = None
    reviewed_at: str | None = None
    # Durable two-phase review handoff.  The corrected document is persisted
    # before HTTP returns; document indexes and knowledge projections then
    # finish asynchronously and may be resumed after a process restart.
    review_target_status: str = ""

    # 状态机
    status: TaskStatus = TaskStatus.CREATED
    error: str | None = None
    created_at: str = ""
    updated_at: str = ""

    def is_paused(self) -> bool:
        """是否处于 HITL 暂停态。"""
        return self.status == TaskStatus.NEEDS_REVIEW

    def is_terminal(self) -> bool:
        return self.status in (TaskStatus.DONE, TaskStatus.FAILED)


class TaskSummary(BaseModel):
    """Bounded task-list projection shared by HTTP and persistence layers."""

    task_id: str
    tenant_id: str = "default"
    filename: str = ""
    status: str
    needs_review: bool = False
    overall_confidence: float | None = None
    updated_at: str = ""
    file_type: str = ""
    doc_type: str = "drawing"
    document_subtype: str = ""
    semantic_enrichment: bool = True
    schema_version: str | None = None
    document_schema_version: str | None = None
    processing_stage: str = ""
    knowledge_sync_status: str | None = None
    error: str | None = None
    parent_id: str = ""
    child_ids: list[str] = Field(default_factory=list)

    @classmethod
    def from_state(cls, state: TaskState) -> "TaskSummary":
        schema_version = state.document_schema_version or None
        return cls(
            task_id=state.task_id,
            tenant_id=state.tenant_id,
            filename=state.original_filename,
            status=state.status.value,
            needs_review=state.is_paused(),
            overall_confidence=(
                state.scored_result.overall_confidence if state.scored_result else None
            ),
            updated_at=state.updated_at,
            file_type=state.file_type,
            doc_type=state.doc_type,
            document_subtype=state.document_subtype,
            semantic_enrichment=state.semantic_enrichment,
            schema_version=schema_version,
            document_schema_version=schema_version,
            processing_stage=state.processing_stage,
            knowledge_sync_status=state.knowledge_sync_status or None,
            error=state.error,
            parent_id=state.parent_id,
            child_ids=list(state.child_ids),
        )
