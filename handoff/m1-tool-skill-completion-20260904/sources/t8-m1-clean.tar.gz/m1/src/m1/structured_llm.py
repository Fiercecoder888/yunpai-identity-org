"""Shared PydanticAI transport for local/OpenAI-compatible structured models."""

from __future__ import annotations

import asyncio
import base64
import time
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Generic, Literal, TypeVar

import httpx
from openai import APITimeoutError, AsyncOpenAI
from pydantic_ai import (
    Agent,
    BinaryContent,
    NativeOutput,
    PromptedOutput,
    UnexpectedModelBehavior,
    UsageLimitExceeded,
    UsageLimits,
)
from pydantic_ai.models.openai import OpenAIChatModel, OpenAIChatModelSettings
from pydantic_ai.profiles.openai import OpenAIModelProfile
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.usage import RunUsage

OutputT = TypeVar("OutputT")


_PROMPTED_OUTPUT_TEMPLATE = (
    "Return exactly one JSON instance matching the schema below. Populate its "
    "fields with answers. Do not repeat or modify the schema, and do not emit "
    "schema keywords such as properties, required, type, or title. Return no "
    "prose and no Markdown. If a correction request follows, it means the prior "
    "answer failed STRUCTURED_OUTPUT_SCHEMA_INVALID validation; use the supplied "
    "validation details to correct that answer once.\nSchema:\n{schema}"
)

_OUTPUT_FAILURE_CODE = "STRUCTURED_OUTPUT_SCHEMA_INVALID"
_TIMEOUT_FAILURE_CODE = "STRUCTURED_REQUEST_TIMEOUT"
_BUDGET_FAILURE_CODE = "STRUCTURED_REQUEST_BUDGET_EXHAUSTED"
_MODEL_FAILURE_CODE = "STRUCTURED_MODEL_CALL_FAILED"
_TRANSPORT_TIMEOUTS = (TimeoutError, APITimeoutError, httpx.TimeoutException)


class StructuredModelUnavailableError(RuntimeError):
    """Raised when an endpoint is healthy but omits the configured model."""


def _safe_failure_reason(exc: Exception) -> str:
    if isinstance(exc, _TRANSPORT_TIMEOUTS):
        return "timeout"
    if isinstance(exc, UnexpectedModelBehavior):
        return "unexpected_model_output"
    if isinstance(exc, UsageLimitExceeded):
        return "request_budget_exhausted"
    return "model_call_failed"


def _safe_failure_diagnostics(exc: Exception, attempts: int) -> dict[str, Any]:
    """Return bounded diagnostics that never retain model or document text."""

    if isinstance(exc, _TRANSPORT_TIMEOUTS):
        code = _TIMEOUT_FAILURE_CODE
        stage = "transport"
    elif isinstance(exc, UnexpectedModelBehavior):
        code = _OUTPUT_FAILURE_CODE
        stage = "output_validation"
    elif isinstance(exc, UsageLimitExceeded):
        code = _BUDGET_FAILURE_CODE
        stage = "request_budget"
    else:
        code = _MODEL_FAILURE_CODE
        stage = "transport"
    return {
        "failure_code": code,
        "failure_stage": stage,
        "failure_reason": _safe_failure_reason(exc),
        # OpenAI transport retries are disabled. More than one real request can
        # therefore only be PydanticAI's schema-correction attempt, even when
        # that correction ends in a transport timeout.
        "correction_attempted": attempts > 1,
    }


@dataclass(slots=True)
class StructuredRun(Generic[OutputT]):
    output: OutputT
    duration_seconds: float
    usage: dict[str, int]
    finish_reason: str = ""


def binary_content_from_data_url(value: str) -> BinaryContent | None:
    """Convert a previously validated image data URL to PydanticAI input."""

    if not value.startswith("data:") or ";base64," not in value:
        return None
    header, encoded = value.split(",", 1)
    media_type = header[5:].split(";", 1)[0].casefold()
    if not media_type.startswith("image/"):
        return None
    try:
        data = base64.b64decode(encoded, validate=True)
    except (ValueError, UnicodeEncodeError):
        return None
    return BinaryContent(data=data, media_type=media_type)


class StructuredModelClient:
    """Typed PromptedOutput client with bounded validation retries.

    ``PromptedOutput`` is used intentionally: the deployed visual endpoints
    have historically hung when OpenAI ``response_format`` is supplied.
    """

    supports_request_limits = True

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        model: str,
        temperature: float = 0.0,
        max_tokens: int = 8192,
        enable_thinking: bool = False,
        timeout: float = 180.0,
        retries: int = 2,
        output_mode: Literal["prompted", "native"] = "prompted",
        validation_retry_timeout_per_attempt: bool = False,
        model_override: Any = None,
    ) -> None:
        self.model_name = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.enable_thinking = enable_thinking
        self.timeout = max(0.001, float(timeout))
        self.retries = max(0, int(retries))
        self.output_mode = output_mode
        self.validation_retry_timeout_per_attempt = bool(
            validation_retry_timeout_per_attempt
        )
        self._openai_client: AsyncOpenAI | None = None
        if model_override is not None:
            self.model = model_override
        else:
            self._openai_client = AsyncOpenAI(
                api_key=api_key or "EMPTY",
                base_url=base_url.rstrip("/"),
                timeout=self.timeout,
                max_retries=0,
            )
            provider = OpenAIProvider(openai_client=self._openai_client)
            # PromptedOutput adds its schema as a second instruction; strict
            # Qwen/vLLM chat templates require one leading system message.
            self.model = OpenAIChatModel(
                model,
                provider=provider,
                profile=OpenAIModelProfile(
                    openai_chat_supports_multiple_system_messages=False
                ),
            )

    async def close(self) -> None:
        if self._openai_client is not None:
            await self._openai_client.close()

    async def probe(self) -> dict[str, Any]:
        """Verify the configured OpenAI-compatible endpoint without inference."""

        if self._openai_client is None:
            # Test/model overrides do not have a remote endpoint to probe.
            return {"ready": True, "model": self.model_name, "configured": True}
        catalog = await asyncio.wait_for(
            self._openai_client.models.list(),
            timeout=self.timeout,
        )
        available_models = {
            str(model_id).strip()
            for item in getattr(catalog, "data", ())
            if (model_id := getattr(item, "id", None))
        }
        if self.model_name not in available_models:
            raise StructuredModelUnavailableError(
                f"configured model {self.model_name!r} is not served by the endpoint"
            )
        return {
            "ready": True,
            "model": self.model_name,
            "configured": True,
            "model_verified": True,
        }

    async def run(
        self,
        output_type: type[OutputT] | Any,
        *,
        instructions: str,
        prompt: str,
        images: Sequence[BinaryContent] = (),
        request_limit: int | None = None,
        retries: int | None = None,
        max_tokens: int | None = None,
    ) -> StructuredRun[OutputT]:
        if request_limit is not None and request_limit < 1:
            raise ValueError("request_limit must be at least 1")
        effective_max_tokens = (
            self.max_tokens
            if max_tokens is None
            else max(1, min(int(max_tokens), self.max_tokens))
        )
        output = (
            NativeOutput(output_type)
            if self.output_mode == "native"
            else PromptedOutput(
                output_type,
                template=_PROMPTED_OUTPUT_TEMPLATE,
            )
        )
        agent = Agent(
            self.model,
            output_type=output,
            instructions=instructions,
            retries=self.retries if retries is None else max(0, int(retries)),
        )
        user_content: list[Any] = [*images, prompt]
        settings = OpenAIChatModelSettings(
            temperature=self.temperature,
            max_tokens=effective_max_tokens,
            timeout=self.timeout,
            # vLLM applies Qwen's thinking switch through the chat template.
            # A top-level ``enable_thinking`` field is accepted but ignored,
            # which makes prompted JSON responses spend their budget on a
            # thinking preamble and then fail schema validation.
            extra_body={
                "chat_template_kwargs": {
                    "enable_thinking": self.enable_thinking,
                }
            },
        )
        started = time.monotonic()
        # Shared callers retain the historical total-wall-clock timeout. The
        # verifier opts into a per-attempt validation budget because it allows
        # exactly one schema-correction request. OpenAI transport retries remain
        # disabled, so a request timeout itself is never submitted again.
        total_timeout = self.timeout
        if self.validation_retry_timeout_per_attempt:
            processing_grace = min(1.0, self.timeout * 0.1)
            total_timeout = self.timeout * (self.retries + 1) + processing_grace
        run_usage = RunUsage()
        try:
            result = await asyncio.wait_for(
                agent.run(
                    user_content,
                    model_settings=settings,
                    usage_limits=(
                        UsageLimits(request_limit=request_limit)
                        if request_limit is not None
                        else None
                    ),
                    usage=run_usage,
                ),
                timeout=total_timeout,
            )
        except Exception as exc:
            # RunUsage remains available when PromptedOutput validation exhausts
            # its retry. Attach only bounded diagnostics; model output and error
            # text may contain document data and must not enter verifier metadata.
            attempts = max(1, int(run_usage.requests or 0))
            diagnostics = _safe_failure_diagnostics(exc, attempts)
            exc._m1_structured_attempts = attempts
            for key, value in diagnostics.items():
                setattr(exc, f"_m1_structured_{key}", value)
            raise
        duration = time.monotonic() - started
        usage_value = result.usage
        usage_obj = usage_value() if callable(usage_value) else usage_value
        input_tokens = int(getattr(usage_obj, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage_obj, "output_tokens", 0) or 0)
        usage = {
            "prompt_tokens": input_tokens,
            "completion_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "requests": int(getattr(usage_obj, "requests", 0) or 0),
        }
        finish_reason = ""
        messages = result.all_messages()
        if messages:
            finish_reason = str(getattr(messages[-1], "finish_reason", "") or "")
        return StructuredRun(
            output=result.output,
            duration_seconds=duration,
            usage=usage,
            finish_reason=finish_reason,
        )


__all__ = [
    "StructuredModelClient",
    "StructuredModelUnavailableError",
    "StructuredRun",
    "binary_content_from_data_url",
]
