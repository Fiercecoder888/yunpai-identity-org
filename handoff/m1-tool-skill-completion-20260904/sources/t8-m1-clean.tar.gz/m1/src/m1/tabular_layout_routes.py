"""Container-local governance CLI for tabular layout profiles.

The CLI deliberately delegates all state changes to ``KnowledgeStore``.  It
does not issue SQL or expose a public HTTP route, and approval can only succeed
when the repository observes three distinct successful task hashes with no
failure outcomes.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from collections.abc import Sequence
from typing import Any

from .core.config import settings
from .knowledge.persistence import KnowledgeStore
from .knowledge.tabular_layout_schema import TabularLayoutProfileStatus


def _nonempty(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must not be empty")
    return normalized


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.tabular_layout_routes",
        description="Govern reusable tabular-layout profiles inside the M1 container.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    list_command = commands.add_parser(
        "list", help="List profiles without mutating state."
    )
    list_command.add_argument("--tenant-id", required=True, type=_nonempty)
    list_command.add_argument(
        "--status",
        choices=tuple(status.value for status in TabularLayoutProfileStatus),
    )
    list_command.add_argument("--limit", type=int, default=100)

    approve = commands.add_parser(
        "approve",
        help="Activate one candidate after the repository's observation gate passes.",
    )
    approve.add_argument("--tenant-id", required=True, type=_nonempty)
    approve.add_argument("--profile-id", required=True, type=_nonempty)
    approve.add_argument("--approved-by", required=True, type=_nonempty)
    approve.add_argument("--reviewed-by", type=_nonempty)
    approve.add_argument("--review-note", action="append", default=[])

    reject = commands.add_parser("reject", help="Reject one candidate profile.")
    reject.add_argument("--tenant-id", required=True, type=_nonempty)
    reject.add_argument("--profile-id", required=True, type=_nonempty)
    reject.add_argument("--reviewed-by", required=True, type=_nonempty)
    reject.add_argument("--review-note", action="append", default=[])
    return parser


def _profile_payload(profile: Any) -> dict[str, Any]:
    signature = profile.signature
    return {
        "profile_id": profile.profile_id,
        "tenant_id": profile.tenant_id,
        "profile_key": profile.profile_key,
        "version": profile.version,
        "status": str(profile.status),
        "exact_fingerprint": profile.exact_fingerprint,
        "document_type_hint": signature.document_type_hint,
        "document_subtype_hint": signature.document_subtype_hint,
        "model_fingerprint": signature.model_fingerprint,
        "observation_count": profile.observation_count,
        "success_count": profile.success_count,
        "failure_count": profile.failure_count,
        "approved_by": profile.approved_by,
        "approved_at": profile.approved_at.isoformat() if profile.approved_at else None,
    }


async def _list(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profiles = await store.list_tabular_layout_profiles(
            args.tenant_id,
            status=args.status,
            limit=max(1, min(int(args.limit), 1000)),
        )
        return {
            "schema_version": "m1.tabular-layout-route-operation.v1",
            "operation": "list",
            "tenant_id": args.tenant_id,
            "profiles": [_profile_payload(profile) for profile in profiles],
        }
    finally:
        await store.close()


async def _approve(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.get_tabular_layout_profile(
            args.tenant_id, args.profile_id
        )
        if profile is None:
            raise LookupError("tabular layout profile not found")
        # Use the repository's observed count, never a caller-supplied count;
        # activation then enforces distinct task hashes and zero failures.
        activated = await store.activate_tabular_layout_profile(
            args.tenant_id,
            args.profile_id,
            approved_by=args.approved_by,
            reviewed_by=args.reviewed_by,
            review_reason_codes=tuple(args.review_note),
            expected_observation_count=profile.observation_count,
        )
        return {
            "schema_version": "m1.tabular-layout-route-operation.v1",
            "operation": "approve",
            "status": "active",
            "profile": _profile_payload(activated),
        }
    finally:
        await store.close()


async def _reject(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.reject_tabular_layout_profile(
            args.tenant_id,
            args.profile_id,
            reviewed_by=args.reviewed_by,
            review_reason_codes=tuple(args.review_note),
        )
        return {
            "schema_version": "m1.tabular-layout-route-operation.v1",
            "operation": "reject",
            "status": "rejected",
            "profile": _profile_payload(profile),
        }
    finally:
        await store.close()


async def _run(args: argparse.Namespace) -> dict[str, Any]:
    if args.command == "list":
        return await _list(args)
    if args.command == "approve":
        return await _approve(args)
    if args.command == "reject":
        return await _reject(args)
    raise ValueError(f"unsupported tabular layout operation: {args.command}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = asyncio.run(_run(args))
    except Exception as exc:  # noqa: BLE001 - bounded operator error
        print(
            json.dumps(
                {
                    "schema_version": "m1.tabular-layout-route-operation.v1",
                    "operation": str(getattr(args, "command", "unknown")),
                    "status": "failed",
                    "error_type": exc.__class__.__name__,
                },
                ensure_ascii=True,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised through main()
    raise SystemExit(main())


__all__ = ["main"]
