"""Container-local governance CLI for visual-region route profiles.

The CLI exposes no HTTP surface and delegates every state transition to the
tenant-scoped knowledge repository. Task references and review notes enter as
operator-provided clear text and are irreversibly hashed before persistence.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import re
import sys
from collections.abc import Mapping, Sequence
from typing import Any

from .core.config import settings
from .documents.parsing.visual_region_routing import (
    VisualRegionExecutionObservation,
    VisualRegionRole,
)
from .knowledge.persistence import KnowledgeStore
from .knowledge.visual_region_schema import VisualRegionProfileStatus
from .state import TaskStatus
from .workflow.persistence import TaskStore

_PREHASHED_REFERENCE = re.compile(
    r"(?:(?:md5|sha-?(?:1|224|256|384|512)|blake2[bs]?|hash|digest)[:=])?"
    r"(?:[0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{56}|[0-9a-f]{64}|"
    r"[0-9a-f]{96}|[0-9a-f]{128})",
    flags=re.IGNORECASE,
)


def _nonempty(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise argparse.ArgumentTypeError("value must not be empty")
    return normalized


def _raw_task_reference(value: str) -> str:
    normalized = _nonempty(value)
    if _PREHASHED_REFERENCE.fullmatch(normalized):
        raise argparse.ArgumentTypeError(
            "task reference must be the original task identifier, not a digest"
        )
    return normalized


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m m1.visual_region_routes",
        description="Govern reusable visual-region profiles inside the M1 container.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    list_command = commands.add_parser(
        "list", help="List tenant-scoped profiles without mutating state."
    )
    list_command.add_argument("--tenant-id", required=True, type=_nonempty)
    list_command.add_argument(
        "--status",
        choices=tuple(status.value for status in VisualRegionProfileStatus),
    )
    list_command.add_argument("--limit", type=int, default=100)

    get_command = commands.add_parser(
        "get", help="Read one tenant-scoped profile without mutating state."
    )
    get_command.add_argument("--tenant-id", required=True, type=_nonempty)
    get_command.add_argument("--profile-id", required=True, type=_nonempty)

    observe = commands.add_parser(
        "record-observation",
        help="Record one explicitly reviewed observation for an existing M1 task.",
    )
    observe.add_argument("--tenant-id", required=True, type=_nonempty)
    observe.add_argument("--profile-id", required=True, type=_nonempty)
    observe.add_argument("--task-id", required=True, type=_raw_task_reference)
    observe.add_argument("--outcome", required=True, choices=("success", "failure"))
    observe.add_argument("--reviewed-by", required=True, type=_nonempty)
    observe.add_argument("--review-note", required=True, type=_nonempty)
    observe.add_argument("--error-code", type=_nonempty)
    observe.add_argument("--latency-ms", type=int, default=0)

    activate = commands.add_parser(
        "activate",
        help="Activate a candidate after the repository's observation gate passes.",
    )
    activate.add_argument("--tenant-id", required=True, type=_nonempty)
    activate.add_argument("--profile-id", required=True, type=_nonempty)
    activate.add_argument("--approved-by", required=True, type=_nonempty)
    activate.add_argument("--reviewed-by", required=True, type=_nonempty)
    activate.add_argument("--review-note", required=True, type=_nonempty)

    reject = commands.add_parser("reject", help="Reject one candidate profile.")
    reject.add_argument("--tenant-id", required=True, type=_nonempty)
    reject.add_argument("--profile-id", required=True, type=_nonempty)
    reject.add_argument("--reviewed-by", required=True, type=_nonempty)
    reject.add_argument("--review-note", required=True, type=_nonempty)

    deprecate = commands.add_parser(
        "deprecate", help="Deprecate one non-rejected profile."
    )
    deprecate.add_argument("--tenant-id", required=True, type=_nonempty)
    deprecate.add_argument("--profile-id", required=True, type=_nonempty)
    deprecate.add_argument("--reviewed-by", required=True, type=_nonempty)
    deprecate.add_argument("--review-note", required=True, type=_nonempty)
    return parser


def _enum_value(value: Any) -> str:
    return str(getattr(value, "value", value))


def _profile_payload(profile: Any) -> dict[str, Any]:
    topology = profile.topology
    return {
        "profile_id": profile.profile_id,
        "tenant_id": profile.tenant_id,
        "profile_key": profile.profile_key,
        "version": profile.version,
        "supersedes_profile_id": profile.supersedes_profile_id,
        "status": _enum_value(profile.status),
        "exact_fingerprint": profile.exact_fingerprint,
        "asset_sha256": getattr(profile, "asset_sha256", None),
        "source_kind": _enum_value(topology.source_kind),
        "contract_revision": topology.contract_revision,
        "role": _enum_value(profile.role),
        "embedding_model": profile.embedding_model,
        "embedding_dimensions": profile.embedding_dimensions,
        "observation_count": profile.observation_count,
        "success_count": profile.success_count,
        "failure_count": profile.failure_count,
        "created_by": profile.created_by,
        "reviewed_by": profile.reviewed_by,
        "reviewed_at": profile.reviewed_at.isoformat() if profile.reviewed_at else None,
        "approved_by": profile.approved_by,
        "approved_at": profile.approved_at.isoformat() if profile.approved_at else None,
        "last_observed_at": (
            profile.last_observed_at.isoformat() if profile.last_observed_at else None
        ),
    }


async def _list(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profiles = await store.list_visual_region_profiles(
            args.tenant_id,
            status=args.status,
            limit=max(1, min(int(args.limit), 1000)),
        )
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "list",
            "tenant_id": args.tenant_id,
            "profiles": [_profile_payload(profile) for profile in profiles],
        }
    finally:
        await store.close()


async def _get(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.get_visual_region_profile(
            args.tenant_id,
            args.profile_id,
        )
        if profile is None:
            raise LookupError("visual region profile not found")
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "get",
            "tenant_id": args.tenant_id,
            "profile": _profile_payload(profile),
        }
    finally:
        await store.close()


def _sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _task_hash(tenant_id: str, task_id: str) -> str:
    """Return an opaque task reference scoped to one tenant."""

    return _sha256(f"{tenant_id}\0{task_id}")


def _visual_route_audit(document: Mapping[str, Any]) -> object:
    extraction = document.get("extraction")
    if not isinstance(extraction, Mapping):
        return None
    direct = extraction.get("visual_region_routing")
    if isinstance(direct, Mapping):
        return direct
    metadata = extraction.get("metadata")
    if isinstance(metadata, Mapping):
        return metadata.get("visual_region_routing")
    return None


def _audit_references_profile(value: object, profile_id: str) -> bool:
    if isinstance(value, Mapping):
        if any(
            value.get(key) == profile_id
            for key in ("candidate_profile_id", "profile_id")
        ):
            return True
        return any(
            _audit_references_profile(item, profile_id) for item in value.values()
        )
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return any(_audit_references_profile(item, profile_id) for item in value)
    return False


async def _record_observation(args: argparse.Namespace) -> dict[str, Any]:
    route_store = KnowledgeStore(settings.resolved_knowledge_database_url)
    task_store = TaskStore(settings.database_url)
    try:
        await route_store.init()
        task = await task_store.load(args.task_id)
        if task is None:
            raise LookupError("visual route observation task not found")
        if str(task.tenant_id).strip() != args.tenant_id:
            raise ValueError("visual route observation task belongs to another tenant")
        if task.status is not TaskStatus.DONE or not isinstance(task.document, dict):
            raise ValueError(
                "visual route observation requires a completed task "
                "with a final document"
            )
        profile = await route_store.get_visual_region_profile(
            args.tenant_id,
            args.profile_id,
        )
        if profile is None:
            raise LookupError("visual region profile not found")
        if args.outcome == "success" and not _audit_references_profile(
            _visual_route_audit(task.document),
            args.profile_id,
        ):
            raise ValueError(
                "successful visual validation requires a final document audit "
                "that references the candidate profile"
            )
        if args.outcome == "success" and args.error_code:
            raise ValueError("successful observations cannot include an error code")
        if args.outcome == "failure" and not args.error_code:
            raise ValueError("failed observations require an error code")
        if int(args.latency_ms) < 0:
            raise ValueError("latency_ms must be non-negative")

        observation = VisualRegionExecutionObservation(
            tenant_id=args.tenant_id,
            profile_id=args.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=_task_hash(args.tenant_id, args.task_id),
            outcome=args.outcome,
            validation_passed=args.outcome == "success",
            reviewed_by=args.reviewed_by,
            review_note_sha256=_sha256(args.review_note),
            latency_ms=int(args.latency_ms),
            error_code=args.error_code or "",
        )
        saved = await route_store.record_visual_region_execution_observation(
            observation
        )
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "record-observation",
            "tenant_id": saved.tenant_id,
            "profile_id": saved.profile_id,
            "task_reference_hash": saved.task_reference_hash,
            "outcome": _enum_value(saved.outcome),
            "validation_passed": saved.validation_passed,
            "reviewed_by": saved.reviewed_by,
            "latency_ms": saved.latency_ms,
            "error_code": saved.error_code,
        }
    finally:
        await task_store.close()
        await route_store.close()


async def _activate(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.get_visual_region_profile(
            args.tenant_id,
            args.profile_id,
        )
        if profile is None:
            raise LookupError("visual region profile not found")
        activated = await store.activate_visual_region_profile(
            args.tenant_id,
            args.profile_id,
            approved_by=args.approved_by,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
            expected_observation_count=profile.observation_count,
            allowed_roles=tuple(VisualRegionRole),
        )
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "activate",
            "status": "active",
            "profile": _profile_payload(activated),
        }
    finally:
        await store.close()


async def _reject(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.reject_visual_region_profile(
            args.tenant_id,
            args.profile_id,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "reject",
            "status": "rejected",
            "profile": _profile_payload(profile),
        }
    finally:
        await store.close()


async def _deprecate(args: argparse.Namespace) -> dict[str, Any]:
    store = KnowledgeStore(settings.resolved_knowledge_database_url)
    try:
        await store.init()
        profile = await store.deprecate_visual_region_profile(
            args.tenant_id,
            args.profile_id,
            reviewed_by=args.reviewed_by,
            review_note=args.review_note,
        )
        return {
            "schema_version": "m1.visual-region-route-operation.v1",
            "operation": "deprecate",
            "status": "deprecated",
            "profile": _profile_payload(profile),
        }
    finally:
        await store.close()


async def _run(args: argparse.Namespace) -> dict[str, Any]:
    handlers = {
        "list": _list,
        "get": _get,
        "record-observation": _record_observation,
        "activate": _activate,
        "reject": _reject,
        "deprecate": _deprecate,
    }
    handler = handlers.get(args.command)
    if handler is None:
        raise ValueError(f"unsupported visual region operation: {args.command}")
    return await handler(args)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = asyncio.run(_run(args))
    except Exception as exc:  # noqa: BLE001 - bounded operator error
        print(
            json.dumps(
                {
                    "schema_version": "m1.visual-region-route-operation.v1",
                    "operation": str(getattr(args, "command", "unknown")),
                    "status": "failed",
                    "error_type": exc.__class__.__name__,
                },
                ensure_ascii=True,
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised through main()
    raise SystemExit(main())


__all__ = ["main"]
