"""MinerU full-authority document workflow stages."""

from __future__ import annotations

import asyncio
import copy
import json
import logging

from ..state import TaskState, TaskStatus
from .support import safe_exception_message as _safe_exception_message

logger = logging.getLogger(__name__)


_MINERU_FULL_FILE_TYPES = frozenset(
    {
        "pdf",
        "image",
        "docx",
        "pptx",
        "xlsx",
        "xlsm",
        "xls",
        "csv",
        "html",
        "dxf",
        "dwg",
    }
)
_MINERU_ORDER_SUBTYPES = frozenset(
    {
        "supplier_purchase_order",
        "customer_purchase_order",
        "purchase_contract",
        "stocking_order",
        "sample_request",
    }
)


class _RouteTargetRejected(RuntimeError):
    """A selected backend produced no authority-safe replacement."""


class DocumentPipelineMixin:
    async def _run_document_pipeline(self, state: TaskState) -> None:
        """Run and always discard the one-invocation route capability."""

        try:
            await self._run_document_pipeline_inner(state)
        finally:
            self._discard_active_route_plan(state)

    async def _run_document_pipeline_inner(self, state: TaskState) -> None:
        """Resolve runtime capabilities, then run the full-authority workflow."""

        preparse_plan, preparse_summary = await self._preparse_document_route_stage(
            state
        )
        active_preparse_plan = self._active_route_plan_for_execution(
            state,
            preparse_plan,
            consume=False,
        )
        if preparse_plan is not None and active_preparse_plan is None:
            self._discard_active_route_plan(state)
        # A route may tune MinerU/Instructor capabilities, but it never selects
        # a separate authority path.  Non-MinerU recommendations are retained
        # as audited advice by ``_record_full_mineru_route_execution``.
        await self._run_mineru_full_pipeline(
            state,
            active_route_plan=active_preparse_plan,
            route_plan=(
                active_preparse_plan.value_free_dump()
                if active_preparse_plan is not None
                else None
            ),
            routing_summary=(
                preparse_summary if active_preparse_plan is not None else None
            ),
        )

    def _active_route_plan_registry(self) -> dict[int, object]:
        """Keep parser authority in-memory for one workflow invocation only."""

        registry = getattr(self, "_active_document_route_plans", None)
        if not isinstance(registry, dict):
            registry = {}
            self._active_document_route_plans = registry
        return registry

    def _active_semantic_execution_registry(self) -> dict[int, object]:
        """Keep semantic capabilities in memory for this invocation only."""

        registry = getattr(self, "_active_semantic_executions", None)
        if not isinstance(registry, dict):
            registry = {}
            self._active_semantic_executions = registry
        return registry

    def _activate_route_plan(self, state: TaskState, plan: object) -> None:
        """Register a route only after this runtime resolved an active profile."""

        from ..documents.parsing.document_route_plan import DocumentRoutePlan

        if not isinstance(plan, DocumentRoutePlan) or not plan.policy_applied:
            return
        self._active_route_plan_registry()[id(state)] = plan

    def _activate_semantic_execution(self, state: TaskState, spec: object) -> None:
        """Register only a live, registry-validated execution capability."""

        from ..documents.parsing.semantic_strategy_executor import (
            SemanticExecutionSpec,
            SemanticStrategyExecutor,
        )

        if not isinstance(spec, SemanticExecutionSpec):
            return
        SemanticStrategyExecutor.validate_capability(spec)
        self._active_semantic_execution_registry()[id(state)] = spec

    def _active_execution_capabilities(self, state: TaskState) -> tuple[object, object]:
        """Return live route/semantic objects; durable metadata is never consulted."""

        return (
            self._active_route_plan_registry().get(id(state)),
            self._active_semantic_execution_registry().get(id(state)),
        )

    def _active_route_plan_for_execution(
        self,
        state: TaskState,
        plan_payload: object,
        *,
        consume: bool,
    ):
        """Return an exact capability match, never a metadata-derived plan."""

        from ..documents.parsing.document_route_plan import DocumentRoutePlan

        registry = self._active_route_plan_registry()
        active = registry.get(id(state))
        if not isinstance(active, DocumentRoutePlan) or not isinstance(
            plan_payload, dict
        ):
            return None
        # Route plans are strict Pydantic models, so their JSON dump cannot be
        # model-validated back from string enum values. Compare only against the
        # exact current runtime serialization instead of re-parsing metadata.
        if plan_payload != active.value_free_dump():
            return None
        if consume:
            registry.pop(id(state), None)
        return active

    def _discard_active_route_plan(self, state: TaskState) -> None:
        self._active_route_plan_registry().pop(id(state), None)
        self._active_semantic_execution_registry().pop(id(state), None)

    @staticmethod
    def _mineru_source_document(state: TaskState) -> dict:
        """Build the source-only seed used by the full MinerU path.

        The seed is identity and explicit user intent only. It deliberately has no
        legacy parser facts, so a full-authority decision cannot silently inherit
        fields from the implementation being replaced.
        """

        from pathlib import Path

        from ..documents.adapters.common import (
            file_sha256,
            guessed_mime,
            source_payload,
        )

        path = Path(state.file_path)
        original = state.original_filename or path.name
        mime_type = guessed_mime(Path(original), "application/octet-stream")
        source = source_payload(
            path,
            original_filename=original,
            mime_type=mime_type,
            sha256=file_sha256(path),
            archive_path=state.archive_path or None,
        )
        if state.display_filename:
            source["display_filename"] = state.display_filename
        subtype = str(state.document_subtype_hint or "unknown")
        document_type = str(state.doc_type_hint or "unknown")
        if (
            document_type in {"", "unknown"}
            and subtype.casefold() in _MINERU_ORDER_SUBTYPES
        ):
            document_type = "order"
        return {
            "schema_version": "m1.document.v2",
            "source": source,
            "document_type": document_type or "unknown",
            "document_subtype": subtype or "unknown",
            "header": {},
            "lines": [],
            "totals": {},
            "field_meta": {},
            "validation_issues": [],
            "needs_review": False,
            "extraction": {
                "metadata": {
                    "adapter": "mineru_full_source_seed",
                    "authority_mode": "full",
                }
            },
        }

    @staticmethod
    def _mineru_full_failure_document(
        state: TaskState,
        *,
        seed: dict,
        code: str,
        message: str,
        actual: object,
    ) -> dict:
        """Return an inspectable, fail-closed v2 document without legacy facts."""

        document = copy.deepcopy(seed)
        document["needs_review"] = True
        document["validation_issues"] = [
            {
                "code": code,
                "severity": "error",
                "message": message,
                "paths": ["$"],
                "source_refs": [],
                "expected": {"authority_mode": "full", "status": "completed"},
                "actual": actual,
                "suggestion": "Review the source document or retry after the MinerU service recovers.",
            }
        ]
        extraction = document.setdefault("extraction", {})
        metadata = extraction.setdefault("metadata", {})
        metadata.update(
            {
                "adapter": "mineru_full_failed_closed",
                "authority_mode": "full",
                "authority_selected": False,
                "failure_code": code,
                "file_type": state.file_type,
                # Retain this source-only task result for operator review, but
                # prevent automatic or replayed knowledge projection until a
                # future MinerU run produces evidence-backed business facts.
                "knowledge_sync_eligible": False,
                "knowledge_sync_block_reason": code,
            }
        )
        return document

    async def _run_mineru_full_pipeline(
        self,
        state: TaskState,
        *,
        active_route_plan: object | None = None,
        route_plan: dict | None = None,
        routing_summary: dict | None = None,
    ) -> None:
        """Use MinerU evidence and its mapper as the only document fact source."""

        runner = getattr(getattr(self, "deps", None), "mineru_shadow_runner", None)
        runner_authority_mode = str(
            getattr(runner, "authority_mode", "") or ""
        ).strip().casefold()
        seed = self._mineru_source_document(state)
        state.status = TaskStatus.EXTRACTING
        state.processing_stage = "mineru_full_authority"
        await self._save(state)

        unsupported_input = state.file_type not in _MINERU_FULL_FILE_TYPES
        runner_contract_mismatch = bool(
            runner is not None and runner_authority_mode != "full"
        )
        if runner is None or unsupported_input or runner_contract_mismatch:
            code = (
                "MINERU_FULL_INPUT_UNSUPPORTED"
                if unsupported_input
                else (
                    "MINERU_FULL_AUTHORITY_CONTRACT_MISMATCH"
                    if runner_contract_mismatch
                    else "MINERU_FULL_AUTHORITY_UNAVAILABLE"
                )
            )
            reason = (
                "unsupported_file_type"
                if unsupported_input
                else (
                    "runner_contract_mismatch"
                    if runner_contract_mismatch
                    else "runner_unavailable"
                )
            )
            document = self._mineru_full_failure_document(
                state,
                seed=seed,
                code=code,
                message=(
                    "The source format has no configured MinerU normalization route."
                    if unsupported_input
                    else (
                        "The configured MinerU runner is not in full-authority mode."
                        if runner_contract_mismatch
                        else "The MinerU full-authority runner is unavailable."
                    )
                ),
                actual={
                    "file_type": state.file_type,
                    "runner_configured": runner is not None,
                    "runner_authority_mode": runner_authority_mode or None,
                },
            )
            state.mineru_shadow = {
                "status": "rejected",
                "reason": reason,
                "authority_mode": "full",
                "authority_selected": False,
                "candidate_persisted_for_review": False,
            }
            state.mineru_shadow_revision = (
                int(getattr(state, "mineru_shadow_revision", 0)) + 1
            )
            self._record_full_mineru_route_execution(
                document,
                route_plan=route_plan,
                routing_summary=routing_summary,
                accepted=False,
                error_type=(
                    "UnsupportedInput"
                    if unsupported_input
                    else (
                        "AuthorityModeMismatch"
                        if runner_contract_mismatch
                        else "RunnerUnavailable"
                    )
                ),
            )
            self._apply_semantic_enrichment_contract(
                state,
                document,
                authority_selected=False,
            )
            document = self._validation_stage(document, copy.deepcopy(document))
            await self._knowledge_sync_stage(state, document)
            return

        from ..documents.parsing.mineru_authority import (
            evaluate_mineru_authority,
            fail_closed_authority_payload,
            full_authority_rejection_is_reviewable,
            locally_accepted_candidate_payload,
            preserved_document_with_issue,
            selected_candidate_payload,
        )

        route_accepted = False
        route_error_type = ""
        try:
            _, semantic_execution = self._active_execution_capabilities(state)
            result = await runner.run_candidate(
                task_id=state.task_id,
                tenant_id=str(getattr(state, "tenant_id", "default") or "default"),
                routing_attempt=(
                    int(getattr(state, "mineru_shadow_revision", 0) or 0) + 1
                ),
                path=state.file_path,
                original_filename=state.original_filename or None,
                file_type=state.file_type,
                authoritative=seed,
                document_type_hint=state.doc_type_hint or None,
                document_subtype_hint=state.document_subtype_hint or None,
                route_plan=active_route_plan,
                semantic_execution=semantic_execution,
            )
            decision = evaluate_mineru_authority(
                result.document,
                result.summary,
                baseline=seed,
                document_type_hint=state.doc_type_hint or None,
                document_subtype_hint=state.document_subtype_hint or None,
                authority_mode="full",
            )
            gate_summary = decision.summary()
            if decision.accepted:
                document = selected_candidate_payload(
                    result.document,
                    authority_mode="full",
                )
                authority_metadata = self._document_metadata(document)
                authority_metadata["authority_selected"] = True
                authority_metadata["knowledge_sync_eligible"] = True
                authority_metadata.pop("knowledge_sync_block_reason", None)
            elif full_authority_rejection_is_reviewable(decision):
                # A reviewable decision may contain metadata/summary rows that
                # local acceptance can remove without losing a business fact.
                # Re-run the complete authority gate on that exact payload so
                # stale invalid-row reasons cannot block an otherwise complete
                # document.
                from ..documents.models import DocumentRecord

                locally_accepted = DocumentRecord.model_validate(
                    locally_accepted_candidate_payload(
                        result.document,
                        decision,
                        authority_mode="full",
                        preserve_candidate_contract=True,
                    )
                )
                decision = evaluate_mineru_authority(
                    locally_accepted,
                    result.summary,
                    baseline=seed,
                    document_type_hint=state.doc_type_hint or None,
                    document_subtype_hint=state.document_subtype_hint or None,
                    authority_mode="full",
                )
                gate_summary = decision.summary()
                if decision.accepted:
                    document = selected_candidate_payload(
                        locally_accepted,
                        authority_mode="full",
                    )
                    authority_metadata = self._document_metadata(document)
                    authority_metadata["authority_selected"] = True
                    authority_metadata["knowledge_sync_eligible"] = True
                    authority_metadata.pop("knowledge_sync_block_reason", None)
                elif full_authority_rejection_is_reviewable(decision):
                    # Preserve the candidate's evidence and mapped facts for a
                    # reviewer. Coverage gaps remain a hard block for automatic
                    # knowledge projection, but they must not erase useful output.
                    document = preserved_document_with_issue(
                        locally_accepted.model_dump(mode="json"),
                        code="MINERU_FULL_AUTHORITY_REQUIRES_REVIEW",
                        message=(
                            "MinerU produced a reviewable document, but the "
                            "full-authority evidence gate requires confirmation."
                        ),
                        gate=gate_summary,
                    )
                    authority_metadata = self._document_metadata(document)
                    authority_metadata.update(
                        {
                            "authority_mode": "full",
                            "authority_selected": False,
                            "authority_review_preserved": True,
                            "knowledge_sync_eligible": False,
                            "knowledge_sync_block_reason": (
                                "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW"
                            ),
                            "authority_failure": {
                                "code": "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW",
                                "reasons": list(gate_summary.get("reasons") or []),
                            },
                        }
                    )
                else:
                    document = fail_closed_authority_payload(
                        locally_accepted,
                        code="MINERU_FULL_AUTHORITY_REJECTED",
                        message=(
                            "MinerU produced evidence, but the full-authority gate "
                            "rejected one or more mapped facts."
                        ),
                        gate=gate_summary,
                    )
            else:
                document = fail_closed_authority_payload(
                    result.document,
                    code="MINERU_FULL_AUTHORITY_REJECTED",
                    message=(
                        "MinerU produced evidence, but the full-authority gate "
                        "rejected one or more mapped facts."
                    ),
                    gate=gate_summary,
                )
            summary = dict(result.summary)
            summary.update(
                {
                    "authority_mode": "full",
                    "authority_selected": decision.accepted,
                    "candidate_persisted_for_review": not decision.accepted,
                    "authority_review_preserved": (
                        not decision.accepted
                        and full_authority_rejection_is_reviewable(decision)
                    ),
                    "authority_gate": gate_summary,
                }
            )
            state.mineru_shadow = summary
            state.mineru_shadow_revision = (
                int(getattr(state, "mineru_shadow_revision", 0)) + 1
            )
            route_accepted = bool(decision.accepted)
            if not route_accepted:
                route_error_type = (
                    "AuthorityReviewRequired"
                    if full_authority_rejection_is_reviewable(decision)
                    else "AuthorityRejected"
                )
        except Exception as exc:  # noqa: BLE001 - full mode fails closed for review
            failure_stage = str(
                getattr(exc, "failure_stage", "candidate_execution")
                or "candidate_execution"
            )[:96]
            failure_reason = str(
                getattr(exc, "failure_reason", "unclassified_failure")
                or "unclassified_failure"
            )[:64]
            logger.warning(
                "MinerU full authority failed closed error_type=%s stage=%s reason=%s",
                exc.__class__.__name__,
                failure_stage,
                failure_reason,
            )
            gate = {
                "passed": False,
                "reasons": ["candidate_error"],
                "missing_source_paths": [],
                "invalid_line_paths": [],
                "lost_baseline_paths": [],
                "mismatched_baseline_paths": [],
            }
            document = self._mineru_full_failure_document(
                state,
                seed=seed,
                code="MINERU_FULL_AUTHORITY_FAILED",
                message="MinerU could not produce a validated authoritative document.",
                actual={
                    "error_type": exc.__class__.__name__,
                    "failure_stage": failure_stage,
                    "failure_reason": failure_reason,
                },
            )
            state.mineru_shadow = {
                "status": "degraded",
                "authority_mode": "full",
                "authority_selected": False,
                "candidate_persisted_for_review": False,
                "authority_gate": gate,
                "error_type": exc.__class__.__name__,
                "failure_stage": failure_stage,
                "failure_reason": failure_reason,
            }
            state.mineru_shadow_revision = (
                int(getattr(state, "mineru_shadow_revision", 0)) + 1
            )
            route_error_type = exc.__class__.__name__

        await self._save(state)
        if route_accepted and route_plan is None:
            # Preparse probing cannot see the final MinerU evidence topology.
            # Observe that topology after authority succeeds, but never let a
            # postparse hit execute a backend for the document already parsed.
            document = await self._document_route_stage(
                state,
                document,
                advisory_only=True,
            )
        if route_accepted:
            document = await self._classification_route_stage(state, document)
            document = await self._adaptive_postbuild_stage(state, document)
        # MinerU evidence plus its constrained mapper are the only model-derived
        # fact sources. There is no legacy verifier or semantic fallback.
        self._record_full_mineru_route_execution(
            document,
            route_plan=route_plan,
            routing_summary=routing_summary,
            accepted=route_accepted,
            error_type=route_error_type,
        )
        self._apply_semantic_enrichment_contract(
            state,
            document,
            authority_selected=route_accepted,
        )
        document = self._validation_stage(document, copy.deepcopy(document))
        await self._knowledge_sync_stage(state, document)

    def _apply_semantic_enrichment_contract(
        self,
        state: TaskState,
        document: dict,
        *,
        authority_selected: bool,
    ) -> None:
        """Apply the public optional order-line semantic projection switch."""

        metadata = self._document_metadata(document)
        requested = bool(state.semantic_enrichment)
        audit: dict[str, object] = {
            "schema_version": "m1.semantic-enrichment.v1",
            "requested": requested,
            "applied_paths": [],
            "suppressed_paths": [],
        }
        metadata["semantic_enrichment"] = audit
        if not authority_selected:
            audit["status"] = "authority_rejected"
            return
        if str(document.get("document_type") or "").casefold() != "order":
            audit["status"] = "not_applicable"
            return

        semantic_fields = (
            "name_normalized",
            "full_product_name",
            "product_category",
            "name_attributes",
        )
        field_meta = document.get("field_meta")
        field_meta = field_meta if isinstance(field_meta, dict) else {}
        document["field_meta"] = field_meta
        selected_paths: list[str] = []
        suppressed_paths: list[str] = []
        for line_index, line in enumerate(document.get("lines") or []):
            if not isinstance(line, dict):
                continue
            for field in semantic_fields:
                value = line.get(field)
                present = value not in (None, "", {}, [])
                path = f"$.lines[{line_index}].{field}"
                if requested:
                    if present:
                        selected_paths.append(path)
                    continue
                if present:
                    suppressed_paths.append(path)
                line[field] = {} if field == "name_attributes" else None
                for meta_path in list(field_meta):
                    if meta_path == path or meta_path.startswith(f"{path}."):
                        field_meta.pop(meta_path, None)
        audit["applied_paths"] = selected_paths
        audit["suppressed_paths"] = suppressed_paths
        audit["status"] = "applied" if requested else "disabled"

    async def _preparse_document_route_stage(
        self,
        state: TaskState,
    ) -> tuple[dict | None, dict | None]:
        """Resolve an approved parser route before an expensive parser runs.

        The probe is intentionally built from source/container structure only.
        It is safe to embed or send to the constrained selector because it does
        not include upload names, body text, cell values, task IDs or tenant
        identifiers.  Tenant/task values are still passed separately to the
        repository boundary for isolation and audit.
        """

        deps = getattr(self, "deps", None)
        runtime = getattr(deps, "document_routing_runtime", None)
        if runtime is None:
            return None, None
        from ..documents.parsing.document_route_probe import build_source_route_probe

        state.processing_stage = "document_route_probe"
        await self._save(state)
        try:
            probe_timeout = float(
                getattr(deps, "document_router_probe_timeout_seconds", 10.0)
            )
            probe = await asyncio.wait_for(
                asyncio.to_thread(
                    build_source_route_probe,
                    state.file_path,
                    declared_source_kind=state.file_type or None,
                ),
                timeout=max(0.1, probe_timeout),
            )
            resolution = await runtime.resolve(
                str(getattr(state, "tenant_id", "default") or "default"),
                state.task_id,
                probe.evidence,
                probe.source_kind,
                document_type_hint=state.doc_type_hint or None,
                document_subtype_hint=state.document_subtype_hint or None,
                contract_revision="m1.document.v2",
            )
            plan = resolution.to_route_plan()
            if not plan.policy_applied:
                return None, None
            semantic_strategy = await self._resolve_semantic_strategy(
                probe.evidence,
                plan,
                state=state,
            )
            self._activate_route_plan(state, plan)
            summary = {
                "schema_version": "m1.adaptive-routing.v1",
                "status": "resolved",
                "stage": "preparse",
                "mode": str(resolution.mode),
                "recommendation": str(resolution.recommendation),
                "reason": str(resolution.reason),
                "signature_fingerprint": str(resolution.signature_fingerprint),
                "recommended_profile_id": resolution.recommended_profile_id,
                "applied_profile_id": resolution.applied_profile_id,
                "candidate_profile_id": resolution.candidate_profile_id,
                "top_score": float(resolution.top_score),
                "top1_top2_margin": float(resolution.top1_top2_margin),
                "model_used": bool(resolution.model_used),
                "policy_applied": True,
                "source_probe": probe.summary(),
            }
            if semantic_strategy is not None:
                summary["semantic_strategy"] = semantic_strategy
            return plan.value_free_dump(), summary
        except Exception:
            if bool(getattr(runtime, "required", False)):
                raise
            return None, None

    async def _resolve_semantic_strategy(
        self,
        evidence: object,
        plan: object,
        *,
        state: TaskState | None = None,
    ) -> dict | None:
        """Resolve only among registered strategies using the route's model client."""

        deps = getattr(self, "deps", None)
        route_runtime = getattr(deps, "document_routing_runtime", None)
        required_route = bool(getattr(route_runtime, "required", False)) and bool(
            getattr(plan, "policy_applied", False)
        )
        try:
            from ..documents.parsing.semantic_strategy_executor import (
                SemanticStrategyExecutor,
            )
            from ..documents.parsing.semantic_strategy_router import (
                PydanticSemanticStrategySelector,
                SemanticStrategyRouter,
            )

            selector = getattr(deps, "semantic_strategy_selector", None)
            if selector is None:
                route_selector = getattr(route_runtime, "selector", None)
                client = getattr(route_selector, "_client", None)
                if client is not None:
                    selector = PydanticSemanticStrategySelector(client)
            decision = await SemanticStrategyRouter().resolve_with_selector(
                evidence,
                selector=selector,
                route_plan=plan,
            )
            if required_route and "model_failure" in decision.reason_codes:
                from ..documents.parsing.document_routing_status import (
                    DocumentRoutingDependencyError,
                )

                status = getattr(route_runtime, "_status", None)
                note_failure = getattr(status, "note_dependency_failure", None)
                if callable(note_failure):
                    raise note_failure(
                        "model", RuntimeError("semantic strategy selector failed")
                    ) from None
                raise DocumentRoutingDependencyError(
                    "model", "SemanticStrategyModelFailure"
                ) from None
            if state is not None and bool(getattr(plan, "policy_applied", False)):
                self._activate_semantic_execution(
                    state,
                    SemanticStrategyExecutor.bind(decision),
                )
            return decision.value_free_dump()
        except Exception as exc:
            if required_route:
                from ..documents.parsing.document_routing_status import (
                    DocumentRoutingDependencyError,
                )

                if isinstance(exc, DocumentRoutingDependencyError):
                    raise
                status = getattr(route_runtime, "_status", None)
                note_failure = getattr(status, "note_dependency_failure", None)
                if callable(note_failure):
                    raise note_failure("model", exc) from None
                raise DocumentRoutingDependencyError(
                    "model", exc.__class__.__name__
                ) from None
            logger.warning(
                "semantic strategy routing degraded error_type=%s",
                exc.__class__.__name__,
            )
            return None

    async def _document_route_stage(
        self,
        state: TaskState,
        document: dict,
        *,
        advisory_only: bool = False,
    ) -> dict:
        """Resolve one shared route plan after deterministic probe parsing.

        Full MinerU authority resolves inside its evidence pipeline. This stage
        covers native/structured entrypoints and only writes bounded plan
        metadata; it never lets a model replace deterministic business facts.
        ``advisory_only`` is used after a full-authority parse to learn a
        candidate from final evidence without granting that candidate execution
        authority for the current document.
        """

        deps = getattr(self, "deps", None)
        runtime = getattr(deps, "document_routing_runtime", None)
        if runtime is None:
            return document
        from ..documents.parsing.document_route_probe import (
            build_route_probe_evidence,
        )

        evidence = build_route_probe_evidence(
            document,
            state.file_type,
            document_type_hint=state.doc_type_hint or None,
            document_subtype_hint=state.document_subtype_hint or None,
        )
        state.processing_stage = "document_route_resolution"
        await self._save(state)
        try:
            resolution = await runtime.resolve(
                str(getattr(state, "tenant_id", "default") or "default"),
                state.task_id,
                evidence,
                state.file_type,
                document_type_hint=state.doc_type_hint or None,
                document_subtype_hint=state.document_subtype_hint or None,
                contract_revision="m1.document.v2",
            )
            plan = resolution.to_route_plan()
            effective_plan = (
                plan.model_copy(update={"policy_applied": False})
                if advisory_only and plan.policy_applied
                else plan
            )
            semantic_strategy = await self._resolve_semantic_strategy(
                evidence,
                effective_plan,
                state=state,
            )
            extraction = document.setdefault("extraction", {})
            if not isinstance(extraction, dict):
                extraction = {}
                document["extraction"] = extraction
            metadata = extraction.setdefault("metadata", {})
            if not isinstance(metadata, dict):
                metadata = {}
                extraction["metadata"] = metadata
            metadata["route_plan"] = effective_plan.value_free_dump()
            metadata["adaptive_routing"] = {
                "schema_version": "m1.adaptive-routing.v1",
                "status": "resolved",
                "stage": "postparse",
                "advisory_only": bool(advisory_only),
                "mode": str(resolution.mode),
                "recommendation": str(resolution.recommendation),
                "reason": str(resolution.reason),
                "signature_fingerprint": str(resolution.signature_fingerprint),
                "recommended_profile_id": resolution.recommended_profile_id,
                "applied_profile_id": (
                    None if advisory_only else resolution.applied_profile_id
                ),
                "observed_profile_id": (
                    resolution.applied_profile_id if advisory_only else None
                ),
                "candidate_profile_id": resolution.candidate_profile_id,
                "top_score": float(resolution.top_score),
                "top1_top2_margin": float(resolution.top1_top2_margin),
                "model_used": bool(resolution.model_used),
                "policy_applied": bool(
                    effective_plan.policy_applied and not advisory_only
                ),
            }
            if semantic_strategy is not None:
                metadata["semantic_strategy"] = semantic_strategy
            if effective_plan.policy_applied and not advisory_only:
                metadata["document_route_context"] = effective_plan.policy_context()
        except Exception as exc:
            if bool(getattr(runtime, "required", False)) and not advisory_only:
                raise
            extraction = document.setdefault("extraction", {})
            if not isinstance(extraction, dict):
                extraction = {}
                document["extraction"] = extraction
            metadata = extraction.setdefault("metadata", {})
            if not isinstance(metadata, dict):
                metadata = {}
                extraction["metadata"] = metadata
            metadata["adaptive_routing"] = {
                "schema_version": "m1.adaptive-routing.v1",
                "status": "degraded",
                "stage": "postparse",
                "advisory_only": bool(advisory_only),
                "error_type": exc.__class__.__name__,
                "policy_applied": False,
            }
        return document

    def _record_full_mineru_route_execution(
        self,
        document: dict,
        *,
        route_plan: dict | None,
        routing_summary: dict | None,
        accepted: bool,
        error_type: str,
    ) -> None:
        """Audit every active route while keeping MinerU as the sole authority."""

        if not isinstance(route_plan, dict):
            return
        targets = route_plan.get("backend_chain")
        primary = (
            str(targets[0].get("backend") or "").casefold()
            if isinstance(targets, list) and targets and isinstance(targets[0], dict)
            else ""
        )
        metadata = self._document_metadata(document)
        metadata["route_plan"] = copy.deepcopy(route_plan)
        if routing_summary is not None:
            metadata["adaptive_routing"] = copy.deepcopy(routing_summary)
            semantic_strategy = routing_summary.get("semantic_strategy")
            if isinstance(semantic_strategy, dict):
                metadata["semantic_strategy"] = copy.deepcopy(semantic_strategy)
        authority_attempt: dict[str, object] = {
            "backend": "mineru",
            "role": "authority",
            "status": "applied" if accepted else "failed",
        }
        if error_type:
            authority_attempt["error_type"] = error_type
        if primary != "mineru":
            metadata["route_authority_enforcement"] = {
                "policy": "mineru_full_only",
                "recommended_primary": primary or None,
                "authority_backend": "mineru",
                "recommendation_executed_as_authority": False,
            }
            metadata["route_execution"] = {
                "status": "authority_applied" if accepted else "authority_failed",
                "backend": "mineru" if accepted else "auto",
                "primary_backend": primary or None,
                "primary_attempted": False,
                "primary_applied": False,
                "fallback_applied": False,
                "outcome_code": "ROUTE_PRIMARY_ADVISORY_UNDER_FULL_AUTHORITY",
            }
            recommendation_attempt: dict[str, object] = {
                "backend": primary or "unknown",
                "role": "recommended_primary",
                "status": "not_executed",
                "reason": "mineru_full_authority",
            }
            metadata["route_execution_attempts"] = [
                recommendation_attempt,
                authority_attempt,
            ]
            return
        authority_attempt["role"] = "primary"
        metadata["route_execution"] = {
            "status": "applied" if accepted else "failed",
            "backend": "mineru" if accepted else "auto",
            "primary_backend": "mineru",
            "primary_attempted": True,
            "primary_applied": accepted,
            "fallback_applied": False,
            "outcome_code": "" if accepted else "ROUTE_PRIMARY_EXECUTION_FAILED",
        }
        metadata["route_execution_attempts"] = [copy.deepcopy(authority_attempt)]

    async def _adaptive_postbuild_stage(
        self,
        state: TaskState,
        document: dict,
    ) -> dict:
        """Run format-neutral governed routes once after authority is settled."""

        from ..documents.parsing.adaptive_postbuild import run_adaptive_postbuild

        deps = getattr(self, "deps", None)
        content_runtime = getattr(deps, "content_region_routing_runtime", None)
        field_runtime = getattr(deps, "field_semantic_routing_runtime", None)
        visual_runtime = getattr(deps, "visual_region_routing_runtime", None)
        if all(
            runtime is None
            for runtime in (content_runtime, field_runtime, visual_runtime)
        ):
            return document
        state.processing_stage = "adaptive_postbuild"
        await self._save(state)
        return await run_adaptive_postbuild(
            document,
            tenant_id=str(getattr(state, "tenant_id", "default") or "default"),
            source_path=state.file_path,
            source_kind=state.file_type,
            document_type_hint=state.doc_type_hint or None,
            document_subtype_hint=state.document_subtype_hint or None,
            content_runtime=content_runtime,
            field_runtime=field_runtime,
            field_registry=getattr(deps, "field_semantic_registry", None),
            visual_runtime=visual_runtime,
        )

    async def _classification_route_stage(
        self,
        state: TaskState,
        document: dict,
    ) -> dict:
        """Fill unknown taxonomy fields from governed active route profiles."""

        deps = getattr(self, "deps", None)
        runtime = getattr(deps, "document_classification_runtime", None)
        base_runtime = getattr(deps, "document_routing_runtime", None)
        if runtime is None and base_runtime is not None:
            try:
                from ..documents.parsing.document_classification_routing import (
                    DocumentClassificationRoutingRuntime,
                    PydanticDocumentClassificationSelector,
                )

                route_selector = getattr(base_runtime, "selector", None)
                client = getattr(route_selector, "_client", None)
                selector = (
                    PydanticDocumentClassificationSelector(client)
                    if client is not None
                    else None
                )
                runtime = (
                    DocumentClassificationRoutingRuntime.from_document_routing_runtime(
                        base_runtime,
                        selector=selector,
                    )
                )
                deps.document_classification_runtime = runtime
            except Exception as exc:
                if bool(getattr(base_runtime, "required", False)):
                    raise
                logger.warning(
                    "classification route construction degraded error_type=%s",
                    exc.__class__.__name__,
                )
                runtime = None
        if runtime is None:
            return document

        from ..documents.parsing.document_route_probe import (
            build_route_probe_evidence,
        )

        evidence = build_route_probe_evidence(
            document,
            state.file_type,
            document_type_hint=state.doc_type_hint or None,
            document_subtype_hint=state.document_subtype_hint or None,
        )
        state.processing_stage = "document_classification_routing"
        await self._save(state)
        try:
            decision = await runtime.resolve(
                str(getattr(state, "tenant_id", "default") or "default"),
                state.task_id,
                evidence,
                state.file_type,
                current_document_type=document.get("document_type"),
                current_document_subtype=document.get("document_subtype"),
                document_type_hint=state.doc_type_hint or None,
                document_subtype_hint=state.document_subtype_hint or None,
                contract_revision="m1.document.v2",
            )
            routed = runtime.apply(document, decision, evidence)
            return await self._replay_classification_mapper(
                state,
                original=document,
                routed=routed,
                evidence=evidence,
            )
        except Exception as exc:
            if bool(getattr(runtime, "required", False)) or bool(
                getattr(base_runtime, "required", False)
            ):
                raise
            logger.warning(
                "classification route stage degraded error_type=%s",
                exc.__class__.__name__,
            )
            fallback = copy.deepcopy(document)
            metadata = self._document_metadata(fallback)
            metadata["classification_routing"] = {
                "schema_version": "m1.document-classification-routing.v1",
                "action": "review",
                "reason": "runtime_failure",
                "status": "degraded",
                "error_type": exc.__class__.__name__,
                "applied_fields": [],
            }
            return fallback

    async def _replay_classification_mapper(
        self,
        state: TaskState,
        *,
        original: dict,
        routed: dict,
        evidence: object,
    ) -> dict:
        """Rebuild facts before admitting a routed taxonomy change.

        Classification runs after the business mapper.  Relabeling the existing
        payload would pair facts with a mapper that never produced them.  Only
        full MinerU authority can replay the source through a newly bound closed
        semantic strategy; every other path keeps the original facts and review
        issue produced by ``DocumentClassificationRoutingRuntime.apply``.
        """

        metadata = self._document_metadata(routed)
        routing = metadata.get("classification_routing")
        if (
            not isinstance(routing, dict)
            or routing.get("application_status") != "mapper_replay_required"
        ):
            return routed

        runner = getattr(getattr(self, "deps", None), "mineru_shadow_runner", None)
        if runner is None:
            routing["application_status"] = "mapper_replay_unavailable"
            return routed

        target_type = str(routing.get("document_type") or "").strip().casefold()
        target_subtype = str(routing.get("document_subtype") or "").strip().casefold()
        advisory_fields = routing.get("advisory_fields")
        advisory_fields = (
            [str(field) for field in advisory_fields]
            if isinstance(advisory_fields, list)
            else []
        )
        if "document_type" not in advisory_fields or not target_type:
            routing["application_status"] = "mapper_replay_invalid_target"
            return routed

        from ..documents.parsing.evidence import DocumentEvidence
        from ..documents.parsing.mineru_authority import (
            evaluate_mineru_authority,
            selected_candidate_payload,
        )
        from ..documents.parsing.semantic_strategy_executor import (
            SemanticStrategyExecutor,
        )
        from ..documents.parsing.semantic_strategy_router import SemanticStrategyRouter

        if not isinstance(evidence, DocumentEvidence):
            routing["application_status"] = "mapper_replay_invalid_evidence"
            return routed
        replay_decision = SemanticStrategyRouter().resolve_for_taxonomy(
            evidence,
            document_type=target_type,
            document_subtype=target_subtype or None,
        )
        execution = SemanticStrategyExecutor.bind(replay_decision)
        # A generic fallback cannot authorize a specialized relabel.
        if execution.document_type_hint is None or (
            execution.document_type_hint.value != target_type
        ):
            routing["application_status"] = "mapper_replay_unregistered_taxonomy"
            return routed

        state.processing_stage = "document_classification_mapper_replay"
        await self._save(state)
        baseline = self._mineru_source_document(state)
        try:
            result = await runner.run_candidate(
                task_id=state.task_id,
                tenant_id=str(getattr(state, "tenant_id", "default") or "default"),
                routing_attempt=(
                    int(getattr(state, "mineru_shadow_revision", 0) or 0) + 1
                ),
                path=state.file_path,
                original_filename=state.original_filename or None,
                file_type=state.file_type,
                authoritative=baseline,
                document_type_hint=target_type,
                document_subtype_hint=(
                    target_subtype
                    if target_subtype and target_subtype != "unknown"
                    else None
                ),
                route_plan=None,
                semantic_execution=execution,
            )
            gate = evaluate_mineru_authority(
                result.document,
                result.summary,
                baseline=baseline,
                document_type_hint=target_type,
                document_subtype_hint=(
                    target_subtype
                    if target_subtype and target_subtype != "unknown"
                    else None
                ),
                authority_mode="full",
            )
            candidate = selected_candidate_payload(
                result.document,
                authority_mode="full",
            )
            candidate_type = str(candidate.get("document_type") or "").casefold()
            candidate_subtype = str(candidate.get("document_subtype") or "").casefold()
            subtype_matches = (
                not target_subtype
                or target_subtype == "unknown"
                or candidate_subtype == target_subtype
            )
            if (
                not gate.accepted
                or candidate_type != target_type
                or not subtype_matches
            ):
                routing["application_status"] = "mapper_replay_rejected"
                routing["mapper_replay"] = {
                    "strategy_id": execution.strategy_id.value,
                    "accepted": False,
                    "authority_gate": gate.summary(),
                }
                return routed
        except Exception as exc:  # noqa: BLE001 - original authority remains reviewable
            logger.warning(
                "classification mapper replay degraded error_type=%s",
                exc.__class__.__name__,
            )
            routing["application_status"] = "mapper_replay_failed"
            routing["mapper_replay"] = {
                "strategy_id": execution.strategy_id.value,
                "accepted": False,
                "error_type": exc.__class__.__name__,
            }
            return routed

        candidate_metadata = self._document_metadata(candidate)
        replay_audit = copy.deepcopy(routing)
        replay_audit.update(
            {
                "application_status": "mapper_replayed",
                "applied_fields": advisory_fields,
                "advisory_fields": [],
                "mapper_replay": {
                    "strategy_id": execution.strategy_id.value,
                    "mapper_id": execution.mapper_id.value,
                    "schema_id": execution.schema_id.value,
                    "prompt_id": execution.prompt_id.value,
                    "budget_id": execution.budget.budget_id.value,
                    "accepted": True,
                    "authority_gate": gate.summary(),
                },
            }
        )
        candidate_metadata["classification_routing"] = replay_audit
        candidate_metadata["semantic_strategy"] = replay_decision.value_free_dump()
        candidate_metadata["semantic_execution"] = execution.value_free_dump()
        return candidate

    @staticmethod
    def _document_metadata(document: dict) -> dict:
        extraction = document.setdefault("extraction", {})
        if not isinstance(extraction, dict):
            extraction = {}
            document["extraction"] = extraction
        metadata = extraction.setdefault("metadata", {})
        if not isinstance(metadata, dict):
            metadata = {}
            extraction["metadata"] = metadata
        return metadata

    def _validation_stage(
        self,
        document: dict,
        native_document: dict,
    ) -> dict:
        """Validate the public schema and calculate the existing review policy."""

        from ..documents import DocumentRecord

        try:
            document = DocumentRecord.model_validate(document).model_dump(mode="json")
        except Exception as exc:  # noqa: BLE001
            safe_error = _safe_exception_message(exc)
            document = native_document
            document.setdefault("validation_issues", []).append(
                {
                    "code": "VLM_SCHEMA_INVALID",
                    "severity": "error",
                    "message": "语义模型结果未通过 m1.document.v2 校验，已回退原生事实。",
                    "paths": ["$"],
                    "source_refs": [],
                    "expected": "m1.document.v2",
                    "actual": safe_error,
                    "suggestion": "检查模型输出或人工复核名称语义。",
                }
            )
            document["needs_review"] = True

        from ..review_policy import assess_document_review

        review_assessment = assess_document_review(
            document,
            confidence_threshold=self.deps.confidence_threshold,
            allow_inferred=False,
        )
        document["review_assessment"] = review_assessment.model_dump(mode="json")
        document["needs_review"] = review_assessment.requires_review
        return document

    @staticmethod
    def _full_authority_review_is_conclusive(
        state: TaskState,
        document: dict,
    ) -> bool:
        """Return whether review policy may supersede the legacy score.

        The compatibility projection assigns synthetic confidence to fields
        that have no legacy confidence value.  That score must not reopen a
        document whose full-authority evidence gate and review policy both
        passed.  Incomplete citations or semantic dispositions remain
        conservative and continue through the legacy review path.
        """

        summary = getattr(state, "mineru_shadow", None)
        if not isinstance(summary, dict) or not bool(
            summary.get("authority_selected")
        ):
            return False
        gate = summary.get("authority_gate")
        if not isinstance(gate, dict) or gate.get("passed") is not True:
            return False
        if any(
            gate.get(key)
            for key in (
                "missing_source_paths",
                "invalid_line_paths",
                "lost_baseline_paths",
                "mismatched_baseline_paths",
            )
        ):
            return False

        coverage = summary.get("source_reference_coverage")
        if not isinstance(coverage, dict):
            return False
        try:
            located = int(coverage.get("located"))
            total = int(coverage.get("total"))
        except (TypeError, ValueError):
            return False
        if total <= 0 or located != total:
            return False

        from ..review_policy import clean_full_semantic_authority

        if not clean_full_semantic_authority(document):
            return False

        assessment = document.get("review_assessment")
        return isinstance(assessment, dict) and assessment.get(
            "requires_review"
        ) is False

    @staticmethod
    def _apply_review_decision_to_score(scored_result, needs_review: bool) -> None:
        """Keep the compatibility score and authoritative task state aligned."""

        scored_result.needs_review = needs_review
        scored_result.review_status = (
            "needs_review" if needs_review else "auto_approved"
        )
        if needs_review:
            return
        for field in (*scored_result.fields, *scored_result.extra_fields):
            field.needs_review = False

    async def _knowledge_sync_stage(
        self,
        state: TaskState,
        document: dict,
    ) -> None:
        """Persist compatibility projections and trigger the governed sink."""

        state.status = TaskStatus.SCORING
        state.processing_stage = "document_scoring"
        state.document = document
        state.document_schema_version = str(
            document.get("schema_version") or "m1.document.v2"
        )
        state.doc_type = str(
            document.get("document_type") or state.doc_type_hint or "unknown"
        )
        state.document_subtype = str(document.get("document_subtype") or "unknown")
        state.parsed_content = self._document_summary(document)
        state.extraction, state.scored_result = self._document_to_legacy(
            state,
            document,
        )

        policy_needs_review = bool(document.get("needs_review"))
        compatibility_needs_review = bool(state.scored_result.needs_review)
        full_authority_review_is_conclusive = (
            self._full_authority_review_is_conclusive(state, document)
        )
        needs_review = policy_needs_review or (
            compatibility_needs_review and not full_authority_review_is_conclusive
        )
        document["needs_review"] = needs_review
        self._apply_review_decision_to_score(state.scored_result, needs_review)
        if needs_review:
            state.status = TaskStatus.NEEDS_REVIEW
            state.processing_stage = "needs_review"
        else:
            state.status = TaskStatus.DONE
            state.processing_stage = "completed"

        native_extraction = document.get("extraction")
        if isinstance(native_extraction, dict) and native_extraction.get("adapter"):
            metadata = native_extraction.setdefault("metadata", {})
            if isinstance(metadata, dict):
                metadata.setdefault("adapter", native_extraction["adapter"])
        document["extraction"] = self._merge_compat_extraction(
            native_extraction,
            state.extraction.model_dump(mode="json"),
            projection_key="compatibility_result",
        )
        document["scored_result"] = state.scored_result.model_dump(mode="json")
        document["fields"] = document["scored_result"]["fields"]
        document["bom"] = list(document.get("lines") or [])
        self._finalize_mineru_authority(state, document)
        state.document = document
        state.processing_stage = (
            "document_indexing" if not needs_review else "needs_review"
        )
        await self.store.save_document(state.task_id, document)
        if not needs_review:
            state.processing_stage = "completed"
        await self._save(state)

    @staticmethod
    def _finalize_mineru_authority(state: TaskState, document: dict) -> None:
        if not bool(state.mineru_shadow.get("authority_selected")):
            return
        from ..documents.parsing.mineru_authority import finalize_authority_digest

        digest = finalize_authority_digest(document)
        state.mineru_shadow = dict(state.mineru_shadow)
        state.mineru_shadow["final_document_sha256"] = digest
        state.mineru_shadow_revision = (
            int(getattr(state, "mineru_shadow_revision", 0)) + 1
        )

    async def reassess_document_review(
        self,
        task_id: str,
        *,
        dry_run: bool = True,
    ) -> dict[str, object]:
        """Rebuild a historical review decision without rerunning OCR/VLM.

        This repairs documents that were held only because legacy compatibility
        fields were absent.  Substantive validation issues, inferred values and
        low-confidence evidence remain review blockers.  Applying the result
        rewrites the legacy indexes and idempotently replays the governed
        knowledge sink from the already persisted ``m1.document.v2`` payload.
        """

        state = await self.store.load(task_id)
        document = await self.store.get_document(task_id)
        if state is None or document is None:
            raise ValueError(f"task has no persisted document: {task_id}")

        from ..review_policy import assess_document_review

        assessment = assess_document_review(
            document,
            confidence_threshold=self.deps.confidence_threshold,
            allow_inferred=False,
        )
        before = bool(document.get("needs_review"))
        after = assessment.requires_review
        result: dict[str, object] = {
            "task_id": task_id,
            "before_needs_review": before,
            "after_needs_review": after,
            "changed": before != after,
            "dry_run": dry_run,
            "reason_codes": assessment.reason_codes,
            "blockers": [
                blocker.model_dump(mode="json") for blocker in assessment.blockers
            ],
        }
        if dry_run:
            return result

        document["review_assessment"] = assessment.model_dump(mode="json")
        document["needs_review"] = after
        state.document = document
        state.document_schema_version = str(
            document.get("schema_version") or "m1.document.v2"
        )
        state.extraction, state.scored_result = self._document_to_legacy(
            state, document
        )
        self._apply_review_decision_to_score(state.scored_result, after)
        document["extraction"] = self._merge_compat_extraction(
            document.get("extraction"),
            state.extraction.model_dump(mode="json"),
            projection_key="compatibility_result",
        )
        document["scored_result"] = state.scored_result.model_dump(mode="json")
        document["fields"] = document["scored_result"]["fields"]
        document["bom"] = list(document.get("lines") or [])
        if after:
            state.status = TaskStatus.NEEDS_REVIEW
            state.processing_stage = "needs_review"
        else:
            state.status = TaskStatus.DONE
            state.processing_stage = "completed"
        await self.store.save_document(task_id, document)
        await self._save(state)
        return result

    @staticmethod
    def _merge_compat_extraction(
        evidence, projection: dict, *, projection_key: str
    ) -> dict:
        """Keep adapter evidence while exposing the legacy compatibility shape."""

        merged = copy.deepcopy(evidence) if isinstance(evidence, dict) else {}
        merged[projection_key] = copy.deepcopy(projection)
        merged.update(projection)
        return merged

    @staticmethod
    def _document_summary(document: dict) -> str:
        source = document.get("source") or {}
        extraction = document.get("extraction") or {}
        raw_content = (
            extraction.get("raw_content") if isinstance(extraction, dict) else None
        )
        text = ""
        if isinstance(raw_content, dict):
            text = str(
                raw_content.get("text_normalized_combined")
                or raw_content.get("text_normalized")
                or raw_content.get("text_original")
                or ""
            )
        if text:
            return text[:20_000]
        return json.dumps(
            {
                "source": source.get("original_filename"),
                "document_type": document.get("document_type"),
                "document_subtype": document.get("document_subtype"),
                "header": document.get("header"),
                "line_count": len(document.get("lines") or []),
            },
            ensure_ascii=False,
            default=str,
        )

    def _document_to_legacy(self, state: TaskState, document: dict):
        from ..schemas import (
            ExtractedField,
            ExtractionResult,
            ScoredField,
            ScoredResult,
        )

        extracted_fields: list[ExtractedField] = []
        scored_fields: list[ScoredField] = []
        field_meta = document.get("field_meta") or {}

        def add(name: str, value, path: str, *, semantic: bool = False) -> None:
            extracted_fields.append(ExtractedField(name=name, value=value))
            meta = field_meta.get(path) if isinstance(field_meta, dict) else None
            applicable = value not in (None, "")
            confidence = None
            if isinstance(meta, dict):
                confidence = meta.get("confidence")
            if confidence is None:
                confidence = 0.0 if not applicable else (0.85 if semantic else 0.99)
            scored_fields.append(
                ScoredField(
                    name=name,
                    value=value,
                    confidence=max(0.0, min(float(confidence), 1.0)),
                    needs_review=(
                        applicable
                        and float(confidence) < self.deps.confidence_threshold
                    ),
                    applicable=applicable,
                    breakdown=(
                        {"deterministic": 0.0, "semantic": 0.0, "not_applicable": 1.0}
                        if not applicable
                        else {
                            "deterministic": 0.0 if semantic else 1.0,
                            "semantic": 1.0 if semantic else 0.0,
                        }
                    ),
                )
            )

        header = document.get("header") or {}
        header_aliases = {
            "doc_number": "order_number",
            "doc_date": "date_standard",
            "buyer.name": "buyer",
            "seller.name": "seller",
            "supplier": "supplier",
            "currency": "currency",
            "title_block.drawing_name": "title",
            "title_block.company": "issuer",
            "title_block.drawing_number": "drawing_number",
            "title_block.material_number": "material_number",
            "title_block.customer_material_number": "customer_material_number",
            "title_block.customer_code": "customer_code",
            "title_block.unit": "unit",
            "title_block.scale": "scale",
            "title_block.design_by": "drawn_by",
            "title_block.design_date": "drawing_date",
            "title_block.version": "version",
        }
        for legacy, key in header_aliases.items():
            add(legacy, header.get(key), f"$.header.{key}")
        if document.get("technical_requirements") not in (None, ""):
            add(
                "technical_requirements",
                document.get("technical_requirements"),
                "$.technical_requirements",
            )
        lines = list(document.get("lines") or [])
        add("lines.item_count", len(lines), "$.lines")
        for index, line in enumerate(lines):
            if not isinstance(line, dict):
                continue
            line_id = str(line.get("line_id") or line.get("line_no") or index + 1)
            for key in ("model", "product_code", "quantity", "unit", "name_raw"):
                add(f"lines.{line_id}.{key}", line.get(key), f"$.lines[{index}].{key}")
            for key in ("name_normalized", "full_product_name", "product_category"):
                add(
                    f"lines.{line_id}.{key}",
                    line.get(key),
                    f"$.lines[{index}].{key}",
                    semantic=True,
                )

        for issue_index, issue in enumerate(document.get("validation_issues") or []):
            if (
                not isinstance(issue, dict)
                or issue.get("severity") == "info"
                or str(issue.get("status") or "open").casefold()
                in {"resolved", "accepted", "ignored"}
            ):
                continue
            severity = str(issue.get("severity") or "warning")
            confidence = 0.35 if severity == "error" else 0.75
            scored_fields.append(
                ScoredField(
                    name=f"validation.issue.{issue_index}.{issue.get('code', 'UNKNOWN')}",
                    value=issue.get("message"),
                    confidence=confidence,
                    needs_review=True,
                    breakdown={"validation": confidence},
                )
            )

        extraction = ExtractionResult(
            fields=extracted_fields,
            raw_text="",
            bom=lines,
            field_confidences={},
        )
        scored = ScoredResult(
            task_id=state.task_id,
            fields=scored_fields,
            raw_text="",
            bom=lines,
        )
        scored.recompute_flags(self.deps.confidence_threshold)
        if document.get("needs_review"):
            scored.needs_review = True
            scored.review_status = "needs_review"
        return extraction, scored

    # ------------------------------------------------------------------
    # HITL 恢复: 人工提交审核结果后, 直接落 done (不重跑 graph)
    # ------------------------------------------------------------------
