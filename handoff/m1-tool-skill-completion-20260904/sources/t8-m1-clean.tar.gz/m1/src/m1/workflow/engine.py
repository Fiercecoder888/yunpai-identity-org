"""Public workflow coordinator for the MinerU full-authority pipeline."""

from __future__ import annotations

import copy

from loguru import logger

from ..deps import WorkflowDeps
from ..state import TaskState, TaskStatus
from .document_pipeline import DocumentPipelineMixin
from .persistence import TaskStore
from .review import ReviewWorkflowMixin
from .support import safe_exception_message as _safe_exception_message


class WorkflowEngine(
    DocumentPipelineMixin,
    ReviewWorkflowMixin,
):
    """Coordinate parsing, business projection, review, and persistence stages."""

    def __init__(self, deps: WorkflowDeps, store: TaskStore):
        self.deps = deps
        self.store = store
        mineru_runner = getattr(deps, "mineru_shadow_runner", None)
        bind_completion = getattr(mineru_runner, "set_completion_sink", None)
        if callable(bind_completion):
            bind_completion(store.update_mineru_shadow_status)

    # ------------------------------------------------------------------
    # 完整链路: created → done (遇 needs_review 则暂停)
    # ------------------------------------------------------------------

    async def run_to_completion(self, state: TaskState) -> TaskState:
        """Persist and run one source exclusively through full authority."""

        await self._save(state)
        try:
            state.processing_stage = "type_detection"
            state.status = TaskStatus.PARSING
            await self._save(state)
            detected = self.deps.parser_router.detect_type(state.file_path)
            # ``.htm`` and ``.html`` share one normalization route.
            state.file_type = "html" if detected == "htm" else detected
            await self._run_document_pipeline(state)
        except Exception as exc:  # noqa: BLE001 - persist a terminal workflow state
            safe_error = _safe_exception_message(exc)
            logger.error(
                "task={} full-authority workflow failed ({})",
                state.task_id,
                safe_error,
            )
            state.status = TaskStatus.FAILED
            state.processing_stage = "failed"
            state.error = safe_error
            await self._save(state)
        return state

    def _maybe_trigger_replication(self, state: TaskState) -> None:
        """保留旧扩展点；综合报告现在由 UI 显式触发。"""
        return

    async def _generate_replication_async(self, task_id: str) -> None:
        """后台生成复刻说明并回写 (best-effort, 失败标 failed 不影响主流程)。"""
        try:
            doc = await self.generate_replication(task_id)
            state = await self.store.load(task_id)
            if state is None:
                return
            state.replication_doc = doc
            state.replication_status = "done"
            await self.store.save(state)
            logger.info(f"task={task_id} 复刻说明生成完成 ({len(doc)} 字符)")
        except Exception as e:  # noqa: BLE001
            logger.warning(
                "task={} replication report failed ({})",
                task_id,
                _safe_exception_message(e),
            )
            state = await self.store.load(task_id)
            if state is not None:
                state.replication_status = "failed"
                await self.store.save(state)

    async def generate_replication(self, task_id: str) -> str:
        """为指定任务生成详细报告 (所有文档类型, Markdown)。

        从 deps 的 VLM client 构造 ReplicationExtractor, 复用同一 API 配置。
        doc_type 决定报告类型 (drawing→复刻说明书, 其它→通用分析报告)。
        """
        from ..extractors.replication import ReplicationExtractor

        state = await self.store.load(task_id)
        if state is None:
            raise ValueError(f"任务不存在: {task_id}")
        vlm = self.deps.vlm_agent
        extractor = ReplicationExtractor(
            api_key=vlm.api_key,
            base_url=vlm.base_url,
            model=vlm.model,
        )
        try:
            return await extractor.extract(state.file_path, doc_type=state.doc_type)
        finally:
            await extractor.close()

    async def replay_source_sha(
        self,
        source_sha256: str,
        *,
        tenant_id: str = "default",
        contract_revision: str = "m1.document.v2",
        parser_revision: str = "m1.route-parser.v1",
        model_revision: str | None = None,
    ) -> dict[str, object] | None:
        """Return an immutable-by-convention exact source replay candidate.

        The method is deliberately read-only: it does not create a task,
        rewrite projections, or rerun a parser.  If no document satisfies the
        strict TaskStore checks, ``None`` is returned and the caller may start
        a normal parse.  When no explicit model revision is supplied, use the
        configured MinerU client's pinned revision; an unavailable revision
        is represented by an empty string and therefore only matches rows that
        also have no model fingerprint.
        """

        if model_revision is None:
            runner = getattr(self.deps, "mineru_shadow_runner", None)
            client = getattr(runner, "client", None)
            model_revision = str(
                getattr(client, "model_revision", "")
                or getattr(runner, "model_revision", "")
                or ""
            ).strip()
        replay = await self.store.find_replayable_document(
            source_sha256,
            tenant_id=tenant_id,
            contract_revision=contract_revision,
            parser_revision=parser_revision,
            model_revision=model_revision,
        )
        # The store already decodes a fresh JSON object.  Make the boundary
        # explicit so future store implementations cannot return a mutable
        # shared cache object by accident.
        return copy.deepcopy(replay) if replay is not None else None

    async def _save(self, state: TaskState) -> None:
        await self.store.save(state)
