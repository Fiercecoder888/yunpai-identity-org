"""任务状态持久化 (HITL 核心)。

设计:
  - 每个 TaskState 完整序列化到 SQLite/Postgres
  - 运行到 needs_review 时暂停, 状态存盘
  - 外部审核提交后, 从 DB 恢复状态, 继续推进到 done

这样实现的好处:
  1. 不依赖 Pydantic Graph 未稳定的 HITL API
  2. 可单测 (mock persistence)
  3. 进程重启不丢任务
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from collections.abc import Awaitable, Callable, Iterable
from datetime import UTC, datetime
from typing import Any

from loguru import logger
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    Index,
    Integer,
    String,
    Text,
    delete,
    event,
    func,
    insert,
    or_,
    select,
)
from sqlalchemy.dialects.postgresql import insert as postgresql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from ..state import TaskState, TaskStatus, TaskSummary


class Base(DeclarativeBase):
    pass


class TaskStoreSchemaError(RuntimeError):
    """The task-store schema has not been migrated to the required shape."""


class TaskRow(Base):
    """tasks 表 ORM。state_json 存 TaskState 的完整 JSON。"""

    __tablename__ = "tasks"
    task_id = Column(String(64), primary_key=True)
    tenant_id = Column(String(64), index=True, nullable=False, default="default")
    status = Column(String(32), index=True)
    # 父任务 id (压缩包解压出的子任务指向父任务); 单文件任务为空
    parent_id = Column(String(64), index=True, default="")
    state_json = Column(Text)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )


class TaskSummaryRow(Base):
    """Compact projection used by high-volume task and review listings."""

    __tablename__ = "task_summary_rows"
    __table_args__ = (
        Index(
            "ix_task_summary_tenant_parent_updated",
            "tenant_id",
            "parent_id",
            "updated_at",
        ),
        Index(
            "ix_task_summary_tenant_status_updated",
            "tenant_id",
            "status",
            "is_batch_container",
            "updated_at",
        ),
    )

    task_id = Column(String(64), primary_key=True)
    tenant_id = Column(String(64), nullable=False, default="default")
    status = Column(String(32), nullable=False)
    parent_id = Column(String(64), nullable=False, default="")
    file_type = Column(String(32), nullable=False, default="")
    is_batch_container = Column(Boolean, nullable=False, default=False)
    updated_at = Column(DateTime(timezone=True), nullable=False)
    summary_json = Column(Text, nullable=False)


class DocumentRow(Base):
    """m1.document.v2 文档主记录；与旧 tasks.state_json 双写以便检索。"""

    __tablename__ = "document_records"
    task_id = Column(String(64), primary_key=True)
    tenant_id = Column(String(64), index=True, nullable=False, default="default")
    schema_version = Column(String(32), index=True, default="m1.document.v2")
    document_type = Column(String(64), index=True, default="")
    document_subtype = Column(String(64), index=True, default="")
    title = Column(Text, default="")
    order_number = Column(String(128), index=True, default="")
    normalized_date = Column(String(32), index=True, default="")
    filename = Column(Text, default="")
    content_hash = Column(String(128), index=True, default="")
    full_text = Column(Text, default="")
    document_json = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(UTC))
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
    )


class OrderLineRow(Base):
    """订单行倒排记录，支持订单号/型号/名称/类别/日期组合查询。"""

    __tablename__ = "order_line_records"
    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(64), index=True, nullable=False, default="default")
    task_id = Column(String(64), index=True, nullable=False)
    line_id = Column(String(128), index=True, default="")
    line_no = Column(String(64), index=True, default="")
    order_number = Column(String(128), index=True, default="")
    document_date = Column(String(32), index=True, default="")
    model = Column(String(256), index=True, default="")
    product_code = Column(String(256), index=True, default="")
    name_raw = Column(Text, default="")
    name_normalized = Column(Text, default="")
    full_product_name = Column(Text, default="")
    product_category = Column(String(256), index=True, default="")
    quantity = Column(Float, nullable=True)
    unit = Column(String(64), default="")
    line_json = Column(Text, nullable=False)


class FieldIndexRow(Base):
    """通用 JSONPath/标量索引，供 Agent 做任意字段检索。"""

    __tablename__ = "field_index_records"
    id = Column(Integer, primary_key=True, autoincrement=True)
    tenant_id = Column(String(64), index=True, nullable=False, default="default")
    task_id = Column(String(64), index=True, nullable=False)
    line_id = Column(String(128), index=True, default="")
    path = Column(String(512), index=True, nullable=False)
    value_text = Column(Text, default="")
    value_number = Column(Float, nullable=True)


class OutboxWorkerTenantRow(Base):
    """Durable tenant registry used by the RLS-aware outbox worker."""

    __tablename__ = "outbox_worker_tenants"

    tenant_id = Column(String(64), primary_key=True)
    first_seen_at = Column(DateTime(timezone=True), nullable=False)
    last_seen_at = Column(DateTime(timezone=True), nullable=False)


def _summary_row_timestamp(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except (AttributeError, ValueError):
        return datetime.now(UTC)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed


def _task_summary_row(
    state: TaskState, *, projection_updated_at: datetime | None = None
) -> TaskSummaryRow:
    summary = TaskSummary.from_state(state)
    return _task_summary_projection_row(
        summary,
        projection_updated_at=projection_updated_at,
    )


def _task_summary_projection_row(
    summary: TaskSummary, *, projection_updated_at: datetime | None = None
) -> TaskSummaryRow:
    return TaskSummaryRow(
        **_task_summary_projection_values(
            summary,
            projection_updated_at=projection_updated_at,
        )
    )


def _task_summary_projection_values(
    summary: TaskSummary, *, projection_updated_at: datetime | None = None
) -> dict[str, Any]:
    return {
        "task_id": summary.task_id,
        "tenant_id": summary.tenant_id,
        "status": summary.status,
        "parent_id": summary.parent_id or "",
        "file_type": summary.file_type,
        "is_batch_container": (summary.file_type == "batch" or bool(summary.child_ids)),
        "updated_at": (
            projection_updated_at
            if projection_updated_at is not None
            else _summary_row_timestamp(summary.updated_at)
        ),
        "summary_json": summary.model_dump_json(),
    }


def _task_summary_backfill_upsert_statement(
    dialect_name: str,
    summary: TaskSummary,
    *,
    projection_updated_at: datetime | None,
):
    values = _task_summary_projection_values(
        summary,
        projection_updated_at=projection_updated_at,
    )
    if dialect_name == "postgresql":
        statement = postgresql_insert(TaskSummaryRow).values(**values)
    elif dialect_name == "sqlite":
        statement = sqlite_insert(TaskSummaryRow).values(**values)
    else:
        raise RuntimeError(
            f"unsupported TaskStore backend for task summary: {dialect_name}"
        )
    return statement.on_conflict_do_update(
        index_elements=[TaskSummaryRow.task_id],
        set_={
            key: getattr(statement.excluded, key) for key in values if key != "task_id"
        },
        where=TaskSummaryRow.updated_at <= statement.excluded.updated_at,
    )


def _task_summary_from_persisted_payload(payload: str, *, row: TaskRow) -> TaskSummary:
    try:
        state = json.loads(payload)
    except (TypeError, json.JSONDecodeError):
        state = {}
    scored_result = state.get("scored_result")
    confidence = (
        scored_result.get("overall_confidence")
        if isinstance(scored_result, dict)
        else None
    )
    schema_version = str(state.get("document_schema_version") or "") or None
    status = str(row.status or state.get("status") or TaskStatus.CREATED.value)
    child_ids = state.get("child_ids")
    if not isinstance(child_ids, list):
        child_ids = []
    return TaskSummary(
        task_id=row.task_id,
        tenant_id=row.tenant_id or str(state.get("tenant_id") or "default"),
        filename=str(state.get("original_filename") or ""),
        status=status,
        needs_review=status == TaskStatus.NEEDS_REVIEW.value,
        overall_confidence=confidence,
        updated_at=str(
            state.get("updated_at")
            or (row.updated_at.isoformat() if row.updated_at else "")
        ),
        file_type=str(state.get("file_type") or ""),
        doc_type=str(state.get("doc_type") or "drawing"),
        document_subtype=str(state.get("document_subtype") or ""),
        semantic_enrichment=bool(state.get("semantic_enrichment", True)),
        schema_version=schema_version,
        document_schema_version=schema_version,
        processing_stage=str(state.get("processing_stage") or "created"),
        knowledge_sync_status=(str(state.get("knowledge_sync_status") or "") or None),
        error=str(state["error"]) if state.get("error") is not None else None,
        parent_id=row.parent_id or str(state.get("parent_id") or ""),
        child_ids=[str(item) for item in child_ids if str(item)],
    )


_TENANT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_SOURCE_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _normalize_outbox_tenant_id(value: str | None) -> str:
    """Apply the same stable tenant-key rules used at the HTTP boundary."""

    tenant_id = str(value or "default").strip().casefold()
    if not _TENANT_ID_RE.fullmatch(tenant_id):
        raise ValueError(
            "tenant_id must start with a letter or digit, contain only "
            "letters, digits, dots, underscores or hyphens, and be at most "
            "64 characters"
        )
    return tenant_id


def _normalize_source_sha256(value: str) -> str:
    """Require the canonical lower-case SHA-256 representation for replay.

    Replay is deliberately exact.  Accepting a prefix, an empty hash, or a
    non-hex value here would turn a cache lookup into an unsafe fuzzy match.
    """

    digest = str(value or "").strip().casefold()
    if not _SOURCE_SHA256_RE.fullmatch(digest):
        raise ValueError("source_sha256 must be a 64-character hexadecimal SHA-256")
    return digest


def _replay_revision_values(
    state: TaskState,
    document: dict[str, Any],
) -> tuple[frozenset[str], frozenset[str], frozenset[str]]:
    """Extract persisted contract/parser/model revisions without guessing.

    Older rows may not contain route metadata.  In that case the empty values
    are retained and the caller's strict comparison fails closed.  Model
    fingerprints can be emitted by either the route plan, parser metadata, or
    the isolated MinerU sidecar, so all of those locations are considered.
    """

    extraction = document.get("extraction")
    metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
    if not isinstance(metadata, dict):
        metadata = {}
    route_plan = metadata.get("route_plan")
    if not isinstance(route_plan, dict):
        route_plan = {}

    contract_values: set[str] = set()
    parser_values: set[str] = set()
    for source in (route_plan, metadata):
        if not isinstance(source, dict):
            continue
        for key, target in (
            ("contract_revision", contract_values),
            ("parser_revision", parser_values),
        ):
            value = source.get(key)
            if isinstance(value, str) and value.strip():
                target.add(value.strip())

    model_values: set[str] = set()
    sources: tuple[object, ...] = (
        route_plan,
        metadata,
        getattr(state, "mineru_shadow", {}),
    )
    for source in sources:
        if not isinstance(source, dict):
            continue
        for key in ("model_revision", "model_fingerprint"):
            value = source.get(key)
            if isinstance(value, str) and value.strip():
                model_values.add(value.strip())
        fingerprints = source.get("model_fingerprints")
        if isinstance(fingerprints, dict):
            for value in fingerprints.values():
                if isinstance(value, str) and value.strip():
                    model_values.add(value.strip())
    return frozenset(contract_values), frozenset(parser_values), frozenset(model_values)


def _outbox_tenant_upsert_statement(
    dialect_name: str,
    *,
    tenant_id: str,
    seen_at: datetime,
    update_last_seen: bool = True,
):
    """Build a concurrent-safe registry upsert for supported task backends."""

    values = {
        "tenant_id": tenant_id,
        "first_seen_at": seen_at,
        "last_seen_at": seen_at,
    }
    if dialect_name == "postgresql":
        statement = postgresql_insert(OutboxWorkerTenantRow).values(**values)
    elif dialect_name == "sqlite":
        statement = sqlite_insert(OutboxWorkerTenantRow).values(**values)
    else:
        raise RuntimeError(
            f"unsupported TaskStore backend for tenant registry: {dialect_name}"
        )
    if not update_last_seen:
        return statement.on_conflict_do_nothing(
            index_elements=[OutboxWorkerTenantRow.tenant_id]
        )
    return statement.on_conflict_do_update(
        index_elements=[OutboxWorkerTenantRow.tenant_id],
        set_={"last_seen_at": seen_at},
    )


# 存量 SQLite 迁移。Postgres 生产部署使用新 Schema；已有 SQLite 文件需
# 原位补齐租户列，且旧数据全部安全归入 default。
_MIGRATION_COLUMNS = {
    "tasks": {
        "parent_id": "VARCHAR(64) DEFAULT ''",
        "tenant_id": "VARCHAR(64) NOT NULL DEFAULT 'default'",
    },
    "document_records": {
        "tenant_id": "VARCHAR(64) NOT NULL DEFAULT 'default'",
    },
    "order_line_records": {
        "tenant_id": "VARCHAR(64) NOT NULL DEFAULT 'default'",
    },
    "field_index_records": {
        "tenant_id": "VARCHAR(64) NOT NULL DEFAULT 'default'",
    },
}


async def _ensure_columns(conn) -> None:
    """检测并补齐缺失列 (SQLite)。"""

    def _sync_migrate(sync_conn):
        for table, columns in _MIGRATION_COLUMNS.items():
            cur = sync_conn.exec_driver_sql(f"PRAGMA table_info({table})")
            existing = {row[1] for row in cur.fetchall()}
            if not existing:
                continue
            for col, ddl in columns.items():
                if col in existing:
                    continue
                sync_conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
                logger.info("迁移: 已给 {} 表补充列 {}", table, col)

    await conn.run_sync(_sync_migrate)


async def _ensure_postgres_timestamps(conn) -> None:
    """Upgrade legacy task timestamps to timezone-aware PostgreSQL columns."""

    def _sync_migrate(sync_conn):
        from sqlalchemy import inspect

        inspector = inspect(sync_conn)
        for table_name in ("tasks", "document_records"):
            columns = {
                column["name"]: column["type"]
                for column in inspector.get_columns(table_name)
            }
            for column_name in ("created_at", "updated_at"):
                column_type = columns.get(column_name)
                if column_type is None or bool(getattr(column_type, "timezone", False)):
                    continue
                sync_conn.exec_driver_sql(
                    f'ALTER TABLE "{table_name}" '
                    f'ALTER COLUMN "{column_name}" TYPE TIMESTAMP WITH TIME ZONE '
                    f"USING \"{column_name}\" AT TIME ZONE 'UTC'"
                )
                logger.info(
                    "Postgres migration: {}.{} upgraded to timestamptz",
                    table_name,
                    column_name,
                )

    await conn.run_sync(_sync_migrate)


async def _validate_task_store_schema(conn) -> None:
    """Validate the production task schema without issuing DDL."""

    def _sync_validate(sync_conn) -> None:
        from sqlalchemy import inspect

        inspector = inspect(sync_conn)
        existing_tables = set(inspector.get_table_names())
        required_tables = set(Base.metadata.tables)
        missing_tables = sorted(required_tables.difference(existing_tables))
        if missing_tables:
            raise TaskStoreSchemaError(
                "task store migration required; missing tables: "
                + ", ".join(missing_tables)
            )

        for table_name, table in Base.metadata.tables.items():
            existing_columns = {
                column["name"] for column in inspector.get_columns(table_name)
            }
            missing_columns = sorted(
                column.name
                for column in table.columns
                if column.name not in existing_columns
            )
            if missing_columns:
                raise TaskStoreSchemaError(
                    f"task store migration required; {table_name} missing columns: "
                    + ", ".join(missing_columns)
                )

        summary_indexes = {
            index["name"]
            for index in inspector.get_indexes(TaskSummaryRow.__tablename__)
        }
        required_summary_indexes = {
            index.name for index in TaskSummaryRow.__table__.indexes
        }
        missing_indexes = sorted(required_summary_indexes.difference(summary_indexes))
        if missing_indexes:
            raise TaskStoreSchemaError(
                "task store migration required; task_summary_rows missing indexes: "
                + ", ".join(missing_indexes)
            )

    await conn.run_sync(_sync_validate)


async def _ensure_task_summary_indexes(conn) -> None:
    """Repair additive summary indexes after an interrupted migration."""

    def _sync_ensure(sync_conn) -> None:
        for index in TaskSummaryRow.__table__.indexes:
            index.create(bind=sync_conn, checkfirst=True)

    await conn.run_sync(_sync_ensure)


class TaskStore:
    """任务持久化门面。封装 DB 引擎 + 读写。"""

    def __init__(
        self,
        database_url: str,
        *,
        document_sink: Callable[[str, dict[str, Any]], Awaitable[None]] | None = None,
    ):
        self.engine = create_async_engine(
            database_url,
            echo=False,
            pool_size=int(os.getenv("M1_DB_POOL_SIZE", "10")),
            max_overflow=int(os.getenv("M1_DB_MAX_OVERFLOW", "20")),
        )
        self.sessionmaker = async_sessionmaker(
            self.engine, class_=AsyncSession, expire_on_commit=False
        )
        self._sqlite_write_lock = (
            asyncio.Lock() if "sqlite" in str(self.engine.url) else None
        )
        self._document_sink = document_sink
        self._install_sqlite_pragmas()

    def set_document_sink(
        self,
        sink: Callable[[str, dict[str, Any]], Awaitable[None]] | None,
    ) -> None:
        """Attach an optional governed-knowledge projection after startup.

        The legacy task/document transaction remains authoritative for M1.  A
        projection failure is isolated and can be replayed from the durable
        ``document_records`` row, so Wiki/Graph outages never turn a successful
        document parse into a failed M1 task.
        """

        self._document_sink = sink

    def _install_sqlite_pragmas(self) -> None:
        """SQLite 连接建立时开 WAL + NORMAL 同步, 提升并发写稳定性。

        仅对 SQLite 生效; Postgres 等其他后端跳过。
        """
        if "sqlite" not in str(self.engine.url):
            return

        @event.listens_for(self.engine.sync_engine, "connect")
        def _set_pragma(dbapi_conn, _):
            cur = dbapi_conn.cursor()
            try:
                cur.execute("PRAGMA journal_mode=WAL")
                cur.execute("PRAGMA synchronous=NORMAL")
                cur.execute("PRAGMA foreign_keys=ON")
                cur.execute("PRAGMA busy_timeout=30000")
            finally:
                cur.close()

    async def init(self, *, migrate_schema: bool = True) -> None:
        """Initialize task persistence and reconcile the list projection."""

        async with self.engine.begin() as conn:
            if migrate_schema:
                await conn.run_sync(Base.metadata.create_all)
                await _ensure_task_summary_indexes(conn)
                # create_all does not ALTER existing tables.
                if "sqlite" in str(self.engine.url):
                    await _ensure_columns(conn)
                elif self.engine.url.get_backend_name() == "postgresql":
                    await _ensure_postgres_timestamps(conn)
            await _validate_task_store_schema(conn)
            # A worker registry introduced after the tasks table must retain
            # every historical tenant even if its tasks are later deleted.
            # Backfill in the same initialization transaction so the worker
            # never starts from a partially populated registry.
            tenant_ids = (
                await conn.execute(select(TaskRow.tenant_id).distinct())
            ).scalars()
            seen_at = datetime.now(UTC)
            for tenant_id in tenant_ids:
                normalized = _normalize_outbox_tenant_id(tenant_id)
                await conn.execute(
                    _outbox_tenant_upsert_statement(
                        conn.dialect.name,
                        tenant_id=normalized,
                        seen_at=seen_at,
                        update_last_seen=False,
                    )
                )
        # The one-shot migration performs the initial backfill. The API repeats
        # this DML-only reconciliation to close writes from the previous release
        # between migration completion and application recreation.
        await self._reconcile_task_summaries()
        # 数据库 URL 可能包含用户名、密码或云数据库访问令牌，日志只记录驱动类型。
        logger.info(
            "TaskStore 初始化完成: backend={} driver={}",
            self.engine.url.get_backend_name(),
            self.engine.url.get_driver_name(),
        )

    async def _reconcile_task_summaries(self) -> None:
        """Synchronize missing, stale, and orphaned task-summary projections."""

        synchronized = 0
        last_task_id = ""
        async with self.sessionmaker() as session:
            task_exists = select(TaskRow.task_id).where(
                TaskRow.task_id == TaskSummaryRow.task_id
            )
            orphan_result = await session.execute(
                delete(TaskSummaryRow).where(~task_exists.exists())
            )
            await session.commit()
            orphan_count = max(0, int(orphan_result.rowcount or 0))
            while True:
                rows = (
                    (
                        await session.execute(
                            select(TaskRow)
                            .outerjoin(
                                TaskSummaryRow,
                                TaskSummaryRow.task_id == TaskRow.task_id,
                            )
                            .where(
                                or_(
                                    TaskSummaryRow.task_id.is_(None),
                                    TaskSummaryRow.updated_at != TaskRow.updated_at,
                                ),
                                TaskRow.task_id > last_task_id,
                            )
                            .order_by(TaskRow.task_id)
                            .limit(100)
                        )
                    )
                    .scalars()
                    .all()
                )
                if not rows:
                    break
                for row in rows:
                    await session.execute(
                        _task_summary_backfill_upsert_statement(
                            session.bind.dialect.name,
                            _task_summary_from_persisted_payload(
                                row.state_json,
                                row=row,
                            ),
                            projection_updated_at=row.updated_at,
                        )
                    )
                await session.commit()
                synchronized += len(rows)
                last_task_id = rows[-1].task_id
        if synchronized or orphan_count:
            logger.info(
                "Task summary projection synchronized rows={} removed_orphans={}",
                synchronized,
                orphan_count,
            )

    async def save(self, state: TaskState) -> None:
        """Serialize SQLite writes; Postgres keeps its native concurrency."""

        await self._run_write(lambda: self._save_unlocked(state))

    async def _run_write(self, operation) -> None:
        """Serialize SQLite writes and retry bounded lock/busy contention."""

        if self._sqlite_write_lock is None:
            await operation()
            return
        async with self._sqlite_write_lock:
            for attempt in range(5):
                try:
                    await operation()
                    return
                except OperationalError as exc:
                    message = str(exc).lower()
                    retryable = "locked" in message or "busy" in message
                    if not retryable or attempt == 4:
                        raise
                    logger.warning(
                        "SQLite write contention; retrying transaction attempt={}",
                        attempt + 2,
                    )
                    await asyncio.sleep(min(0.25 * (2**attempt), 2.0))

    async def _save_unlocked(self, state: TaskState) -> None:
        """upsert 任务状态 (按 task_id 主键 merge)。"""
        now = datetime.now(UTC).isoformat()
        state.updated_at = now
        if not state.created_at:
            state.created_at = now
        async with self.sessionmaker() as session:
            # Knowledge projection runs beside the legacy workflow.  The
            # workflow may save an older in-memory TaskState immediately after
            # the sink recorded its outcome; preserve those monotonic fields
            # instead of accidentally erasing them during that final save.
            existing = await session.get(TaskRow, state.task_id)
            if existing is not None:
                persisted = TaskState.model_validate_json(existing.state_json)
                if state.tenant_id == "default" and persisted.tenant_id != "default":
                    state.tenant_id = persisted.tenant_id
                incoming_revision = state.knowledge_sync_revision
                persisted_revision = persisted.knowledge_sync_revision
                sidecar_is_stale = incoming_revision < persisted_revision
                legacy_blank_sidecar = (
                    incoming_revision == persisted_revision == 0
                    and not state.knowledge_sync_status
                    and bool(persisted.knowledge_sync_status)
                )
                if sidecar_is_stale or legacy_blank_sidecar:
                    for field in (
                        "knowledge_sync_status",
                        "knowledge_document_id",
                        "knowledge_version_id",
                        "knowledge_sync_error",
                        "knowledge_sync_revision",
                    ):
                        setattr(state, field, getattr(persisted, field))
                incoming_mineru_revision = state.mineru_shadow_revision
                persisted_mineru_revision = persisted.mineru_shadow_revision
                incoming_mineru_status = str(state.mineru_shadow.get("status") or "")
                persisted_mineru_status = str(
                    persisted.mineru_shadow.get("status") or ""
                )
                mineru_sidecar_is_stale = (
                    incoming_mineru_revision < persisted_mineru_revision
                    or (
                        incoming_mineru_revision == persisted_mineru_revision
                        and incoming_mineru_status == "queued"
                        and persisted_mineru_status in {"completed", "degraded"}
                    )
                )
                if mineru_sidecar_is_stale:
                    state.mineru_shadow = dict(persisted.mineru_shadow)
                    state.mineru_shadow_revision = persisted_mineru_revision
            # merge: 主键存在则更新, 不存在则插入 —— 即 upsert
            projection_updated_at = _summary_row_timestamp(state.updated_at)
            row = TaskRow(
                task_id=state.task_id,
                tenant_id=_normalize_outbox_tenant_id(state.tenant_id),
                status=state.status.value,
                parent_id=state.parent_id or "",
                state_json=state.model_dump_json(),
                updated_at=projection_updated_at,
            )
            state.tenant_id = row.tenant_id
            row.state_json = state.model_dump_json()
            await session.merge(row)
            await session.merge(
                _task_summary_row(
                    state,
                    projection_updated_at=projection_updated_at,
                )
            )
            await session.execute(
                _outbox_tenant_upsert_statement(
                    session.bind.dialect.name,
                    tenant_id=state.tenant_id,
                    seen_at=datetime.now(UTC),
                )
            )
            await session.commit()

    async def register_outbox_tenant(self, tenant_id: str) -> None:
        """Persist a configured/authenticated tenant for future worker drains."""

        normalized = _normalize_outbox_tenant_id(tenant_id)

        async def _register() -> None:
            async with self.sessionmaker() as session:
                await session.execute(
                    _outbox_tenant_upsert_statement(
                        session.bind.dialect.name,
                        tenant_id=normalized,
                        seen_at=datetime.now(UTC),
                    )
                )
                await session.commit()

        await self._run_write(_register)

    async def list_outbox_tenant_ids(self) -> list[str]:
        """Return every known worker tenant in deterministic order."""

        async with self.sessionmaker() as session:
            result = await session.execute(
                select(OutboxWorkerTenantRow.tenant_id).order_by(
                    OutboxWorkerTenantRow.tenant_id
                )
            )
            return list(result.scalars().all())

    async def update_knowledge_status(
        self,
        task_id: str,
        *,
        status: str,
        document_id: str = "",
        version_id: str = "",
        error: str = "",
    ) -> TaskState | None:
        """Atomically update the Wiki/Graph sidecar and clear resolved errors.

        The revision makes a later save from the legacy workflow harmless,
        while an explicit successful retry may intentionally replace a failed
        status and clear its old error string.
        """

        updated: TaskState | None = None

        async def _update() -> None:
            nonlocal updated
            async with self.sessionmaker() as session:
                row = await session.get(TaskRow, task_id)
                if row is None:
                    return
                state = TaskState.model_validate_json(row.state_json)
                state.knowledge_sync_status = status
                if document_id:
                    state.knowledge_document_id = document_id
                if version_id:
                    state.knowledge_version_id = version_id
                state.knowledge_sync_error = error[:256]
                state.knowledge_sync_revision += 1
                state.updated_at = datetime.now(UTC).isoformat()
                row.tenant_id = state.tenant_id
                row.status = state.status.value
                row.parent_id = state.parent_id or ""
                row.state_json = state.model_dump_json()
                projection_updated_at = _summary_row_timestamp(state.updated_at)
                row.updated_at = projection_updated_at
                await session.merge(
                    _task_summary_row(
                        state,
                        projection_updated_at=projection_updated_at,
                    )
                )
                await session.commit()
                updated = state

        await self._run_write(_update)
        return updated

    async def update_mineru_shadow_status(
        self,
        task_id: str,
        summary: dict[str, Any],
    ) -> TaskState | None:
        """Atomically publish a value-free result from the MinerU sidecar."""

        updated: TaskState | None = None

        async def _update() -> None:
            nonlocal updated
            async with self.sessionmaker() as session:
                row = await session.get(TaskRow, task_id)
                if row is None:
                    return
                state = TaskState.model_validate_json(row.state_json)
                state.mineru_shadow = dict(summary)
                state.mineru_shadow_revision += 1
                state.updated_at = datetime.now(UTC).isoformat()
                row.tenant_id = state.tenant_id
                row.status = state.status.value
                row.parent_id = state.parent_id or ""
                row.state_json = state.model_dump_json()
                projection_updated_at = _summary_row_timestamp(state.updated_at)
                row.updated_at = projection_updated_at
                await session.merge(
                    _task_summary_row(
                        state,
                        projection_updated_at=projection_updated_at,
                    )
                )
                await session.commit()
                updated = state

        await self._run_write(_update)
        return updated

    async def load(self, task_id: str) -> TaskState | None:
        """按 ID 加载任务状态。"""
        async with self.sessionmaker() as session:
            row = await session.get(TaskRow, task_id)
            if row is None:
                return None
            return TaskState.model_validate_json(row.state_json)

    async def delete(self, task_id: str) -> bool:
        deleted = False

        async def _delete() -> None:
            nonlocal deleted
            deleted = await self._delete_unlocked(task_id)

        await self._run_write(_delete)
        return deleted

    async def _delete_unlocked(self, task_id: str) -> bool:
        """删除任务记录。返回是否删除成功 (任务不存在返回 False)。"""
        async with self.sessionmaker() as session:
            row = await session.get(TaskRow, task_id)
            if row is None:
                return False
            await session.execute(
                delete(FieldIndexRow).where(FieldIndexRow.task_id == task_id)
            )
            await session.execute(
                delete(OrderLineRow).where(OrderLineRow.task_id == task_id)
            )
            await session.execute(
                delete(DocumentRow).where(DocumentRow.task_id == task_id)
            )
            await session.execute(
                delete(TaskSummaryRow).where(TaskSummaryRow.task_id == task_id)
            )
            await session.delete(row)
            await session.commit()
            return True

    async def save_document(self, task_id: str, document: dict[str, Any]) -> None:
        """Serialize the multi-table SQLite index transaction."""

        await self._run_write(lambda: self._save_document_unlocked(task_id, document))
        if self._document_sink is not None:
            try:
                await self._document_sink(task_id, document)
            except Exception as exc:  # noqa: BLE001 - legacy M1 must remain available
                logger.error(
                    "Knowledge projection failed task={} error_type={}",
                    task_id,
                    exc.__class__.__name__,
                )

    async def _save_document_unlocked(
        self, task_id: str, document: dict[str, Any]
    ) -> None:
        """原子替换文档、订单行和通用字段索引。审核修正后重复调用即可重建索引。"""
        header = document.get("header") or {}
        source = document.get("source") or {}
        order_number = _first_text(
            header,
            "order_number",
            "doc_number",
            "primary_order_number",
            "contract_number",
        )
        normalized_date = _first_text(
            header,
            "date_standard",
            "date_normalized",
            "normalized_date",
            "document_date",
            "order_date",
        )
        filename = _first_text(
            source, "display_filename", "original_filename", "filename"
        )
        content_hash = _first_text(source, "sha256", "content_hash")
        title = _first_text(header, "title", "document_title")
        lines = document.get("lines") or []
        serialized = json.dumps(document, ensure_ascii=False, default=str)
        # ``extraction.raw_content`` can contain every PDF span, bbox and table
        # cell.  It remains available in document_json as audit evidence, but
        # expanding it into one SQL row per scalar makes a corpus ingest spend
        # most of its time writing hundreds of thousands of non-business
        # index rows.  Materialize the bounded business-field view once and
        # reuse it for both field search and full-text search.
        indexed_values = list(_iter_document_index_values(document))

        async with self.sessionmaker() as session:
            task_row = await session.get(TaskRow, task_id)
            tenant_id = task_row.tenant_id if task_row is not None else "default"
            await session.execute(
                delete(FieldIndexRow).where(FieldIndexRow.task_id == task_id)
            )
            await session.execute(
                delete(OrderLineRow).where(OrderLineRow.task_id == task_id)
            )
            await session.merge(
                DocumentRow(
                    task_id=task_id,
                    tenant_id=tenant_id,
                    schema_version=str(
                        document.get("schema_version") or "m1.document.v2"
                    ),
                    document_type=str(document.get("document_type") or ""),
                    document_subtype=str(document.get("document_subtype") or ""),
                    title=title,
                    order_number=order_number,
                    normalized_date=normalized_date,
                    filename=filename,
                    content_hash=content_hash,
                    full_text=_collect_search_text(document, indexed_values),
                    document_json=serialized,
                )
            )

            if str(document.get("document_type") or "") == "order":
                for index, line in enumerate(lines):
                    if not isinstance(line, dict):
                        continue
                    line_id = str(
                        line.get("line_id") or line.get("line_no") or index + 1
                    )
                    session.add(
                        OrderLineRow(
                            tenant_id=tenant_id,
                            task_id=task_id,
                            line_id=line_id,
                            line_no=str(
                                line.get("line_no") or line.get("index") or index + 1
                            ),
                            order_number=order_number,
                            document_date=normalized_date,
                            model=_as_text(line.get("model")),
                            product_code=_as_text(
                                line.get("product_code") or line.get("code")
                            ),
                            name_raw=_as_text(line.get("name_raw") or line.get("name")),
                            name_normalized=_as_text(line.get("name_normalized")),
                            full_product_name=_as_text(line.get("full_product_name")),
                            product_category=_as_text(line.get("product_category")),
                            quantity=_as_number(line.get("quantity")),
                            unit=_as_text(line.get("unit")),
                            line_json=json.dumps(line, ensure_ascii=False, default=str),
                        )
                    )

            if indexed_values:
                # Executemany is materially faster on both SQLite and
                # PostgreSQL than constructing/flushing one ORM object for
                # every scalar value.
                await session.execute(
                    insert(FieldIndexRow),
                    [
                        {
                            "tenant_id": tenant_id,
                            "task_id": task_id,
                            "line_id": line_id,
                            "path": path,
                            "value_text": _as_text(value),
                            "value_number": _as_number(value),
                        }
                        for path, value, line_id in indexed_values
                    ],
                )
            await session.commit()

    async def get_document(self, task_id: str) -> dict[str, Any] | None:
        async with self.sessionmaker() as session:
            row = await session.get(DocumentRow, task_id)
            if row is None:
                return None
            return json.loads(row.document_json)

    async def find_replayable_document(
        self,
        source_sha256: str,
        *,
        tenant_id: str = "default",
        contract_revision: str = "m1.document.v2",
        parser_revision: str = "m1.route-parser.v1",
        model_revision: str = "",
    ) -> dict[str, Any] | None:
        """Return one exact, completed document suitable for source replay.

        This is intentionally narrower than document search.  A hit requires
        all of the following to agree: tenant, complete source SHA-256, a
        terminal ``DONE`` task, a document without review blockers, and the
        persisted contract/parser/model revisions supplied by the caller.
        Unknown revisions (including legacy rows without route metadata) never
        match a non-empty expected revision.  The returned JSON is freshly
        decoded from storage, so callers cannot mutate the persisted value.
        """

        digest = _normalize_source_sha256(source_sha256)
        tenant = _normalize_outbox_tenant_id(tenant_id)
        expected_contract = str(contract_revision or "").strip()
        expected_parser = str(parser_revision or "").strip()
        expected_model = str(model_revision or "").strip()
        if not expected_contract or not expected_parser:
            raise ValueError("contract_revision and parser_revision are required")

        async with self.sessionmaker() as session:
            statement = (
                select(TaskRow, DocumentRow)
                .join(DocumentRow, DocumentRow.task_id == TaskRow.task_id)
                .where(
                    TaskRow.tenant_id == tenant,
                    DocumentRow.tenant_id == tenant,
                    DocumentRow.content_hash == digest,
                    TaskRow.status == TaskStatus.DONE.value,
                )
                .order_by(DocumentRow.updated_at.desc(), TaskRow.task_id.desc())
            )
            rows = (await session.execute(statement)).all()

        for task_row, document_row in rows:
            try:
                state = TaskState.model_validate_json(task_row.state_json)
                document = json.loads(document_row.document_json)
            except (TypeError, ValueError):
                # A corrupt historical row must never become a replay source.
                continue
            if state.tenant_id != tenant or state.status != TaskStatus.DONE:
                continue
            if bool(document.get("needs_review")):
                continue
            source = document.get("source")
            if not isinstance(source, dict):
                continue
            persisted_digest = str(source.get("sha256") or "").strip().casefold()
            # Verify the JSON payload as well as the indexed column.  This
            # protects replay from a stale or manually repaired index row.
            if (
                persisted_digest != digest
                or str(document_row.content_hash).casefold() != digest
            ):
                continue
            stored_contracts, stored_parsers, stored_models = _replay_revision_values(
                state,
                document,
            )
            if stored_contracts != frozenset(
                {expected_contract}
            ) or stored_parsers != frozenset({expected_parser}):
                continue
            # An empty expected model revision means the current pipeline has
            # no pinned model.  It can only replay rows that likewise contain
            # no model fingerprint.  A pinned model must be the sole persisted
            # fingerprint; ambiguity fails closed.
            if expected_model:
                if stored_models != frozenset({expected_model}):
                    continue
            elif stored_models:
                continue
            return {
                "task_id": task_row.task_id,
                "tenant_id": tenant,
                "source_sha256": digest,
                "contract_revision": expected_contract,
                "parser_revision": expected_parser,
                "model_revision": next(iter(stored_models), ""),
                "document": document,
            }
        return None

    async def search_documents(
        self,
        *,
        tenant_id: str = "default",
        query: str = "",
        document_type: str = "",
        document_subtype: str = "",
        field_path: str = "",
        field_value: str = "",
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 200))
        offset = max(0, int(offset))
        async with self.sessionmaker() as session:
            stmt = select(DocumentRow).where(DocumentRow.tenant_id == tenant_id)
            if document_type:
                stmt = stmt.where(DocumentRow.document_type == document_type)
            if document_subtype:
                stmt = stmt.where(DocumentRow.document_subtype == document_subtype)
            if query:
                needle = f"%{query}%"
                stmt = stmt.where(
                    or_(
                        DocumentRow.full_text.ilike(needle),
                        DocumentRow.order_number.ilike(needle),
                        DocumentRow.filename.ilike(needle),
                    )
                )
            if field_path or field_value:
                sub = select(FieldIndexRow.task_id).where(
                    FieldIndexRow.tenant_id == tenant_id
                )
                if field_path:
                    if "*" in field_path:
                        sub = sub.where(
                            FieldIndexRow.path.like(
                                _jsonpath_like_pattern(field_path), escape="\\"
                            )
                        )
                    else:
                        sub = sub.where(FieldIndexRow.path == field_path)
                if field_value:
                    sub = sub.where(FieldIndexRow.value_text.ilike(f"%{field_value}%"))
                stmt = stmt.where(DocumentRow.task_id.in_(sub))
            rows = (
                (
                    await session.execute(
                        stmt.order_by(DocumentRow.updated_at.desc())
                        .offset(offset)
                        .limit(limit)
                    )
                )
                .scalars()
                .all()
            )
            return [
                {
                    "task_id": row.task_id,
                    "schema_version": row.schema_version,
                    "document_type": row.document_type,
                    "document_subtype": row.document_subtype,
                    "title": row.title,
                    "order_number": row.order_number,
                    "normalized_date": row.normalized_date,
                    "filename": row.filename,
                    "sha256": row.content_hash,
                }
                for row in rows
            ]

    async def search_orders(
        self,
        *,
        tenant_id: str = "default",
        order_number: str = "",
        model: str = "",
        name: str = "",
        category: str = "",
        date_from: str = "",
        date_to: str = "",
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 500))
        offset = max(0, int(offset))
        async with self.sessionmaker() as session:
            stmt = select(OrderLineRow).where(OrderLineRow.tenant_id == tenant_id)
            if order_number:
                stmt = stmt.where(OrderLineRow.order_number.ilike(f"%{order_number}%"))
            if model:
                stmt = stmt.where(OrderLineRow.model.ilike(f"%{model}%"))
            if name:
                needle = f"%{name}%"
                stmt = stmt.where(
                    or_(
                        OrderLineRow.name_raw.ilike(needle),
                        OrderLineRow.name_normalized.ilike(needle),
                        OrderLineRow.full_product_name.ilike(needle),
                    )
                )
            if category:
                stmt = stmt.where(OrderLineRow.product_category.ilike(f"%{category}%"))
            if date_from:
                stmt = stmt.where(OrderLineRow.document_date >= date_from)
            if date_to:
                stmt = stmt.where(OrderLineRow.document_date <= date_to)
            rows = (
                (
                    await session.execute(
                        stmt.order_by(
                            OrderLineRow.document_date.desc(), OrderLineRow.id
                        )
                        .offset(offset)
                        .limit(limit)
                    )
                )
                .scalars()
                .all()
            )
            return [
                {
                    "task_id": row.task_id,
                    "line_id": row.line_id,
                    "line_no": row.line_no,
                    "order_number": row.order_number,
                    "document_date": row.document_date,
                    "model": row.model,
                    "product_code": row.product_code,
                    "name_raw": row.name_raw,
                    "name_normalized": row.name_normalized,
                    "full_product_name": row.full_product_name,
                    "product_category": row.product_category,
                    "quantity": row.quantity,
                    "unit": row.unit,
                    "line": json.loads(row.line_json),
                }
                for row in rows
            ]

    async def list_task_summaries(
        self,
        *,
        tenant_id: str | None = None,
        status: str | None = None,
        root_only: bool = False,
        exclude_batch_parents: bool = False,
        limit: int | None = None,
        offset: int = 0,
    ) -> tuple[list[TaskSummary], int]:
        """Return task summaries without reading heavyweight workflow state."""

        if limit is not None:
            limit = max(1, min(int(limit), 200))
        offset = max(0, int(offset))
        filters = []
        if tenant_id is not None:
            filters.append(TaskSummaryRow.tenant_id == tenant_id)
        if status:
            filters.append(TaskSummaryRow.status == status)
        if root_only:
            filters.append(TaskSummaryRow.parent_id == "")
        if exclude_batch_parents:
            filters.append(TaskSummaryRow.is_batch_container.is_(False))

        async with self.sessionmaker() as session:
            total = int(
                (
                    await session.execute(
                        select(func.count()).select_from(TaskSummaryRow).where(*filters)
                    )
                ).scalar_one()
            )
            statement = (
                select(TaskSummaryRow.summary_json)
                .where(*filters)
                .order_by(
                    TaskSummaryRow.updated_at.asc(),
                    TaskSummaryRow.task_id.asc(),
                )
                .offset(offset)
            )
            if limit is not None:
                statement = statement.limit(limit)
            payloads = (await session.execute(statement)).scalars().all()
            return [
                TaskSummary.model_validate_json(payload) for payload in payloads
            ], total

    async def list_by_status(
        self, status: str, *, tenant_id: str | None = None
    ) -> list[TaskState]:
        """按状态列出任务 (用于审核 UI 取队列)。"""
        async with self.sessionmaker() as session:
            statement = select(TaskRow).where(TaskRow.status == status)
            if tenant_id is not None:
                statement = statement.where(TaskRow.tenant_id == tenant_id)
            result = await session.execute(statement.order_by(TaskRow.updated_at))
            rows = result.scalars().all()
            return [TaskState.model_validate_json(r.state_json) for r in rows]

    async def list_all(self, *, tenant_id: str | None = None) -> list[TaskState]:
        """列出全部任务 (单次查询, 不按状态枚举)。"""
        async with self.sessionmaker() as session:
            statement = select(TaskRow)
            if tenant_id is not None:
                statement = statement.where(TaskRow.tenant_id == tenant_id)
            result = await session.execute(statement.order_by(TaskRow.updated_at))
            rows = result.scalars().all()
            return [TaskState.model_validate_json(r.state_json) for r in rows]

    async def list_by_parent(
        self, parent_id: str, *, tenant_id: str | None = None
    ) -> list[TaskState]:
        """列出某父任务下的所有子任务 (压缩包解压出的文件)。"""
        async with self.sessionmaker() as session:
            statement = select(TaskRow).where(TaskRow.parent_id == parent_id)
            if tenant_id is not None:
                statement = statement.where(TaskRow.tenant_id == tenant_id)
            result = await session.execute(statement.order_by(TaskRow.created_at))
            rows = result.scalars().all()
            return [TaskState.model_validate_json(r.state_json) for r in rows]

    async def close(self) -> None:
        await self.engine.dispose()


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _as_number(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value).strip().replace(",", "")
        return float(text)
    except (TypeError, ValueError):
        return None


def _first_text(mapping: dict[str, Any], *keys: str) -> str:
    for key in keys:
        value = mapping.get(key)
        if value not in (None, "", []):
            return _as_text(value)
    return ""


_INDEXABLE_DOCUMENT_ROOTS = frozenset(
    {
        "source",
        "document_type",
        "document_subtype",
        "header",
        "lines",
        "totals",
        "validation_issues",
        "needs_review",
    }
)


def _iter_document_index_values(
    document: dict[str, Any],
) -> Iterable[tuple[str, Any, str]]:
    """Yield searchable business facts while retaining evidence in document_json.

    Compatibility projections (``fields``, ``bom`` and ``scored_result``) repeat
    the same order facts, while ``field_meta`` and ``extraction`` contain source
    evidence rather than customer query fields.  Excluding those roots keeps the
    generic index bounded without reducing m1.document.v2 fidelity.
    """

    for key in _INDEXABLE_DOCUMENT_ROOTS:
        if key not in document:
            continue
        yield from _flatten_index_values(document[key], f"$.{key}")


def _collect_search_text(
    document: dict[str, Any],
    indexed_values: Iterable[tuple[str, Any, str]] | None = None,
) -> str:
    values = []
    for _, value, _ in (
        indexed_values
        if indexed_values is not None
        else _iter_document_index_values(document)
    ):
        text = _as_text(value).strip()
        if text:
            values.append(text)
    # Preserve document-body full-text retrieval without exploding page/span
    # evidence into FieldIndexRow records.  Adapters expose one aggregate text
    # value for PDF/DOCX and other text-bearing formats.
    extraction = document.get("extraction")
    raw_content = (
        extraction.get("raw_content") if isinstance(extraction, dict) else None
    )
    if isinstance(raw_content, dict):
        body_text = raw_content.get("text_normalized") or raw_content.get(
            "text_original"
        )
        if isinstance(body_text, str) and body_text.strip():
            values.append(body_text.strip())
    return "\n".join(values)


def _jsonpath_like_pattern(path: str) -> str:
    """Translate JSONPath ``*`` to SQL LIKE while escaping LIKE metacharacters."""

    output: list[str] = []
    for character in path:
        if character == "*":
            output.append("%")
        elif character in {"%", "_", "\\"}:
            output.append("\\" + character)
        else:
            output.append(character)
    return "".join(output)


def _flatten_index_values(
    value: Any, path: str = "$", line_id: str = ""
) -> Iterable[tuple[str, Any, str]]:
    """展平标量，跳过大二进制/证据 payload；数组行保留 line_id。"""
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"data_url", "base64", "binary", "raw_bytes"}:
                continue
            child_line_id = line_id
            if path == "$.lines" or (path.startswith("$.lines[") and key == "line_id"):
                child_line_id = _as_text(value.get("line_id") or value.get("line_no"))
            yield from _flatten_index_values(child, f"{path}.{key}", child_line_id)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            item_line_id = line_id
            if path == "$.lines" and isinstance(child, dict):
                item_line_id = _as_text(
                    child.get("line_id") or child.get("line_no") or index + 1
                )
            yield from _flatten_index_values(child, f"{path}[{index}]", item_line_id)
    elif value is not None and len(path) <= 512:
        # PostgreSQL enforces FieldIndexRow.path's declared width.  Deep custom
        # evidence remains in document_json even when it cannot be addressed by
        # the bounded generic index.
        yield path, value, line_id
