"""Behavior-preserving workflow stage mixin.

This module is intentionally internal; :class:`WorkflowEngine` remains the public entry point.
"""
from __future__ import annotations

import copy
import re
from datetime import datetime, timezone

from loguru import logger

from ..state import TaskState, TaskStatus
from .support import manual_field_meta as _manual_field_meta


class ReviewWorkflowMixin:
    async def submit_review(
        self,
        task_id: str,
        corrected_fields: dict | None = None,
        header_corrections: dict | None = None,
        line_corrections: list[dict] | dict | None = None,
        issue_resolutions: list[dict] | dict | None = None,
        reviewer: str = "anonymous",
        comment: str = "",
        approve: bool = True,
    ) -> TaskState:
        """Apply, persist, index, and finalize a review in one internal call."""

        await self.prepare_review(
            task_id=task_id,
            corrected_fields=corrected_fields,
            header_corrections=header_corrections,
            line_corrections=line_corrections,
            issue_resolutions=issue_resolutions,
            reviewer=reviewer,
            comment=comment,
            approve=approve,
        )
        return await self.finalize_review(task_id)

    async def prepare_review(
        self,
        task_id: str,
        corrected_fields: dict | None = None,
        header_corrections: dict | None = None,
        line_corrections: list[dict] | dict | None = None,
        issue_resolutions: list[dict] | dict | None = None,
        reviewer: str = "anonymous",
        comment: str = "",
        approve: bool = True,
    ) -> TaskState:
        """人工审核提交: 用修正值覆盖字段, 标记完成。

        参数:
            corrected_fields: {字段名: 新值}; None 表示接受原值
            approve: True=通过(reviewed), False=驳回(rejected)
        """
        state = await self.store.load(task_id)
        if state is None:
            raise ValueError(f"任务不存在: {task_id}")
        if not state.is_paused():
            raise ValueError(
                f"任务状态非 needs_review, 当前: {state.status}"
            )

        scored = state.scored_result
        extraction_evidence = None
        if state.document is not None:
            current_evidence = state.document.get("extraction")
            if isinstance(current_evidence, dict):
                extraction_evidence = copy.deepcopy(current_evidence)
        if scored is None and state.document is None:
            raise RuntimeError(
                f"task={task_id} 状态异常: 处于 needs_review 但无可审核结果"
            )

        # 应用人工修正
        if corrected_fields and scored is not None:
            for field in scored.fields:
                if field.name in corrected_fields:
                    field.value = corrected_fields[field.name]
                    field.confidence = 1.0
                    field.needs_review = False
                    field.breakdown["manual_review"] = 1.0

        if state.document is not None:
            self._apply_document_review(
                state.document,
                corrected_fields=corrected_fields,
                header_corrections=header_corrections,
                line_corrections=line_corrections,
                issue_resolutions=issue_resolutions,
                reviewer=reviewer,
                comment=comment,
                approve=approve,
            )
            reviewed_evidence = state.document.get("extraction")
            if isinstance(reviewed_evidence, dict):
                extraction_evidence = copy.deepcopy(reviewed_evidence)
            # 旧明细别名同步，避免审核后 API 两份数据不一致。
            state.extraction, scored = self._document_to_legacy(state, state.document)
            state.scored_result = scored
            state.export_path = ""

        if scored is not None:
            document_review = (
                (state.document or {}).get("review", {})
                if state.document is not None
                else {}
            )
            review_status = str(document_review.get("status") or "")
            scored.review_status = review_status or ("reviewed" if approve else "rejected")
            scored.needs_review = bool(
                state.document is not None and state.document.get("needs_review")
            )
            scored.overall_confidence = min(
                (f.confidence for f in scored.fields), default=1.0
            )
            state.reviewed_result = scored
        if state.document is not None:
            lines = list(state.document.get("lines") or [])
            if state.extraction is not None:
                state.extraction.bom = lines
                review_projection = state.extraction.model_dump(mode="json")
                state.document["extraction"] = self._merge_compat_extraction(
                    extraction_evidence,
                    review_projection,
                    projection_key="review_projection",
                )
            if scored is not None:
                scored.bom = lines
                state.document["scored_result"] = scored.model_dump(mode="json")
                state.document["fields"] = state.document["scored_result"]["fields"]
            state.document["bom"] = lines
            from ..documents import DocumentRecord

            state.document = DocumentRecord.model_validate(state.document).model_dump(
                mode="json"
            )
        state.reviewer = reviewer
        state.review_comment = comment
        state.reviewed_at = datetime.now(timezone.utc).isoformat()
        target_status = (
            TaskStatus.NEEDS_REVIEW
            if (
                not approve
                or (
                    state.document is not None
                    and state.document.get("needs_review")
                )
            )
            else TaskStatus.DONE
        )
        state.review_target_status = target_status.value
        state.status = TaskStatus.SCORING
        state.processing_stage = "review_indexing"
        state.updated_at = datetime.now(timezone.utc).isoformat()

        await self._save(state)
        logger.info("task={} review corrections persisted; indexing queued", task_id)
        return state

    async def finalize_review(self, task_id: str) -> TaskState:
        """Rebuild durable indexes and publish the persisted review target state."""

        state = await self.store.load(task_id)
        if state is None:
            raise ValueError(f"任务不存在: {task_id}")
        if state.processing_stage != "review_indexing":
            raise ValueError(
                f"任务状态非 review_indexing, 当前: {state.processing_stage}"
            )
        if state.document is not None:
            await self.store.save_document(task_id, state.document)
        try:
            target_status = TaskStatus(
                state.review_target_status or TaskStatus.NEEDS_REVIEW.value
            )
        except ValueError:
            target_status = TaskStatus.NEEDS_REVIEW
        state.status = target_status
        state.processing_stage = (
            "needs_review" if target_status == TaskStatus.NEEDS_REVIEW else "completed"
        )
        state.review_target_status = ""
        state.updated_at = datetime.now(timezone.utc).isoformat()
        await self._save(state)
        logger.info("task={} review indexing completed status={}", task_id, target_status)
        return state

    def _apply_document_review(
        self,
        document: dict,
        *,
        corrected_fields: dict | None,
        header_corrections: dict | None,
        line_corrections: list[dict] | dict | None,
        issue_resolutions: list[dict] | dict | None,
        reviewer: str,
        comment: str,
        approve: bool,
    ) -> None:
        header = document.setdefault("header", {})
        field_meta = document.setdefault("field_meta", {})
        has_corrections = bool(corrected_fields or header_corrections or line_corrections)
        corrected_paths: set[str] = set()
        lines = document.setdefault("lines", [])
        review_issues: list[dict] = []
        preexisting_issue_ids = {
            id(issue)
            for issue in document.get("validation_issues", [])
            if isinstance(issue, dict)
        }
        legacy_line_corrections: dict[str, dict] = {}
        for key, value in (corrected_fields or {}).items():
            match = re.fullmatch(r"lines\.([^.]+)\.(.+)", str(key))
            if match and match.group(1) != "item_count":
                legacy_line_corrections.setdefault(match.group(1), {})[
                    match.group(2)
                ] = value
        # 旧 corrections 中的 header.x / 直接 header key 也继续支持。
        for key, value in (corrected_fields or {}).items():
            if re.fullmatch(r"lines\.([^.]+)\.(.+)", str(key)):
                continue
            if key.startswith("header."):
                header_key = key.removeprefix("header.")
                header[header_key] = value
                path = f"$.header.{header_key}"
                field_meta[path] = _manual_field_meta(reviewer)
                corrected_paths.add(path)
            elif key in header:
                header[key] = value
                path = f"$.header.{key}"
                field_meta[path] = _manual_field_meta(reviewer)
                corrected_paths.add(path)
        for key, value in (header_corrections or {}).items():
            header[key] = value
            path = f"$.header.{key}"
            field_meta[path] = _manual_field_meta(reviewer)
            corrected_paths.add(path)

        if isinstance(line_corrections, dict):
            corrections = [
                {"line_id": line_id, **(values if isinstance(values, dict) else {"value": values})}
                for line_id, values in line_corrections.items()
            ]
        else:
            corrections = line_corrections or []
        corrections = [
            *corrections,
            *(
                {"line_id": line_id, "corrections": values}
                for line_id, values in legacy_line_corrections.items()
            ),
        ]
        by_id = {
            str(line.get("line_id") or line.get("line_no") or index + 1): (index, line)
            for index, line in enumerate(lines)
            if isinstance(line, dict)
        }
        for correction in corrections:
            if not isinstance(correction, dict):
                continue
            line_id = str(correction.get("line_id") or correction.get("line_no") or "")
            matched = by_id.get(line_id)
            if matched is None:
                review_issues.append(
                    {
                        "code": "REVIEW_TARGET_NOT_FOUND",
                        "severity": "warning",
                        "message": f"审核修正未找到明细行 {line_id}，未应用该修正。",
                        "paths": ["$.lines"],
                        "source_refs": [{"part": f"review:{reviewer}"}],
                        "expected": line_id,
                        "actual": None,
                        "suggestion": "刷新文档后使用有效 line_id 重新提交。",
                    }
                )
                continue
            line_index, target = matched
            values = correction.get("fields")
            if not isinstance(values, dict):
                values = correction.get("corrections")
            if not isinstance(values, dict):
                values = {
                    key: value
                    for key, value in correction.items()
                    if key not in {"line_id", "line_no", "fields", "corrections"}
                }
            target.update(values)
            target["reviewed"] = True
            for key in values:
                path = f"$.lines[{line_index}].{key}"
                field_meta[path] = _manual_field_meta(reviewer)
                corrected_paths.add(path)

        if document.get("document_type") == "order" and has_corrections:
            from ..documents.orders import revalidate_order_document

            revalidate_order_document(document)

        issues = document.setdefault("validation_issues", [])
        issues.extend(review_issues)
        if approve and corrected_paths:
            for issue in issues:
                if not isinstance(issue, dict):
                    continue
                if id(issue) not in preexisting_issue_ids:
                    continue
                issue_paths = {
                    str(path) for path in (issue.get("paths") or []) if path
                }
                if not (issue_paths & corrected_paths):
                    continue
                if str(issue.get("status") or "open").casefold() in {
                    "resolved",
                    "accepted",
                    "ignored",
                }:
                    continue
                issue["status"] = "resolved"
                issue["resolution"] = "corrected and revalidated by manual review"
                issue["resolved_by"] = reviewer
        if isinstance(issue_resolutions, dict):
            resolutions = [
                {"code": code, **(value if isinstance(value, dict) else {"resolution": value})}
                for code, value in issue_resolutions.items()
            ]
        else:
            resolutions = issue_resolutions or []
        for resolution in resolutions:
            if not isinstance(resolution, dict):
                continue
            code = str(resolution.get("code") or "")
            target_paths = {
                str(path) for path in (resolution.get("paths") or []) if path
            }
            matched_resolution = False
            for issue in issues:
                issue_paths = {
                    str(path) for path in (issue.get("paths") or []) if path
                } if isinstance(issue, dict) else set()
                if (
                    isinstance(issue, dict)
                    and str(issue.get("code") or "") == code
                    and (not target_paths or bool(target_paths & issue_paths))
                ):
                    issue["status"] = resolution.get("status", "resolved")
                    issue["resolution"] = resolution.get("resolution") or resolution.get("comment")
                    issue["resolved_by"] = reviewer
                    matched_resolution = True
            if code and not matched_resolution:
                issues.append(
                    {
                        "code": "REVIEW_ISSUE_NOT_FOUND",
                        "severity": "warning",
                        "message": f"未找到待处置问题 {code}。",
                        "paths": sorted(target_paths) or ["$.validation_issues"],
                        "source_refs": [{"part": f"review:{reviewer}"}],
                        "expected": code,
                        "actual": None,
                        "suggestion": "刷新问题列表后重试。",
                    }
                )

        # A plain approval accepts the already-seen warnings.  If values were
        # changed, recalculated problems remain open until explicitly resolved.
        if approve and not has_corrections and issue_resolutions is None:
            for issue in issues:
                if (
                    isinstance(issue, dict)
                    and str(issue.get("severity") or "") in {"warning", "error"}
                    and str(issue.get("status") or "open").casefold()
                    not in {"resolved", "accepted", "ignored"}
                ):
                    issue["status"] = "accepted"
                    issue["resolution"] = "accepted by manual review"
                    issue["resolved_by"] = reviewer
        unresolved = any(
            isinstance(issue, dict)
            and str(issue.get("severity") or "") in {"warning", "error"}
            and str(issue.get("status") or "open").casefold()
            not in {"resolved", "accepted", "ignored"}
            for issue in issues
        )
        review_status = (
            "rejected" if not approve else ("needs_review" if unresolved else "reviewed")
        )
        document["needs_review"] = (not approve) or unresolved
        document["review"] = {
            "status": review_status,
            "reviewer": reviewer,
            "comment": comment,
            "reviewed_at": datetime.now(timezone.utc).isoformat(),
        }
        extraction = document.get("extraction")
        metadata = extraction.get("metadata") if isinstance(extraction, dict) else None
        if isinstance(metadata, dict) and metadata.get("authority_mode") == "full":
            if review_status == "reviewed":
                metadata["authority_selected"] = "manual_review"
                metadata["knowledge_sync_eligible"] = True
                metadata.pop("knowledge_sync_block_reason", None)
            else:
                metadata["authority_selected"] = False
                metadata["knowledge_sync_eligible"] = False
                metadata["knowledge_sync_block_reason"] = (
                    "MANUAL_REVIEW_NOT_APPROVED"
                )
