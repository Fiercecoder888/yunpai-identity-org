"""Small shared helpers for workflow stage modules."""
from __future__ import annotations


def safe_exception_message(exc: BaseException) -> str:
    """Return a log/API-safe exception summary without response bodies or secrets."""

    status = getattr(exc, "status_code", None)
    suffix = f" status={status}" if isinstance(status, int) else ""
    if exc.__class__.__name__ == "OperationalError":
        origin = str(getattr(exc, "orig", "")).lower()
        if "locked" in origin or "busy" in origin:
            suffix += " category=database_locked"
        elif "disk i/o" in origin:
            suffix += " category=storage_io"
        elif "unable to open" in origin:
            suffix += " category=database_unavailable"
    return f"{exc.__class__.__name__}{suffix}"


def manual_field_meta(reviewer: str) -> dict:
    return {
        "source_refs": [{"part": f"review:{reviewer}"}],
        "confidence": 1.0,
        "inferred": False,
        "inherited_from_merge": False,
    }
