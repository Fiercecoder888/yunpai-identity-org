"""One-shot schema migration entrypoint for the M1 task store."""

from __future__ import annotations

import asyncio

from loguru import logger

from ..core.config import settings
from .persistence import TaskStore


async def migrate_task_store(database_url: str | None = None) -> None:
    """Apply additive task-store schema changes and reconcile projections."""

    store = TaskStore(database_url or settings.database_url)
    try:
        await store.init(migrate_schema=True)
    finally:
        await store.close()


def main() -> None:
    asyncio.run(migrate_task_store())
    logger.info("M1 task-store migration completed")


if __name__ == "__main__":
    main()
