from __future__ import annotations

from types import SimpleNamespace

import pytest
from m1.documents.parsing.adaptive_routing import (
    AdaptiveDocumentRouter,
    DocumentRouteCandidate,
    DocumentRouteModelChoice,
    DocumentRoutePolicy,
    DocumentRouteSignature,
    PydanticDocumentRouteSelector,
    RouteTableShape,
    build_document_route_signature,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from pydantic import ValidationError


def _signature(
    *,
    labels: tuple[str, ...] = ("model", "quantity", "unit"),
    layout: tuple[str, ...] = ("title_then_table",),
    blocks: tuple[str, ...] = ("title", "table"),
    columns: int = 3,
    page_count: str = "single",
) -> DocumentRouteSignature:
    return DocumentRouteSignature(
        format_family="fixed_page",
        page_count_bucket=page_count,
        block_kinds=blocks,
        label_tokens=labels,
        layout_tokens=layout,
        table_shapes=(
            RouteTableShape(
                table_index=0,
                row_count_bucket="many",
                column_count=columns,
                header_row_count=1,
                orientation="records_by_row",
            ),
        ),
    )


class _Selector:
    def __init__(self, output=None, error: Exception | None = None) -> None:
        self.output = output
        self.error = error
        self.calls = 0
        self.requests = []

    async def select(self, request):
        self.calls += 1
        self.requests.append(request)
        if self.error is not None:
            raise self.error
        return self.output


def _evidence_with_business_values(
    *,
    order_number: str,
    company: str,
    email: str,
    phone: str,
) -> DocumentEvidence:
    rows = [
        ["订单号", "客户", "联系电话"],
        [order_number, company, phone],
        ["P-100", email, "1000"],
        ["P-200", "华南仓", "2000"],
    ]
    table = EvidenceTable(
        table_id=f"private-table-{order_number}",
        rows=rows,
        cells=[
            EvidenceCell(row=row_index, column=column_index, text=value)
            for row_index, row in enumerate(rows)
            for column_index, value in enumerate(row)
        ],
        orientation="rows",
        header_indices=[0],
        source=f"tenant/customer/{company}",
    )
    return DocumentEvidence(
        backend="fixture",
        source_kind=f"C:/private/{company}-{phone}.PDF",
        tenant_id=f"tenant-{company}",
        task_id=f"task-{order_number}",
        semantic_labels={
            "订单号": order_number,
            "$.header.delivery_date_raw": "2026-07-30",
            "product_code": "P-100",
            f"unknown_{company}_{phone}": email,
        },
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=800,
                rotation=90,
                raw={
                    "is_scanned": True,
                    "filename": f"{company}-{order_number}.pdf",
                    "contact": {"email": email, "phone": phone},
                },
                blocks=[
                    EvidenceBlock(
                        block_id=f"title-{order_number}",
                        kind="document_title",
                        text=f"{company} 订单 {order_number}",
                    ),
                    EvidenceBlock(
                        block_id=f"unknown-{phone}",
                        kind=f"customer_{company}_{phone}",
                        text=email,
                    ),
                    EvidenceBlock(
                        block_id=f"image-{order_number}",
                        kind="picture",
                        text=f"contact {phone}",
                        bbox=EvidenceBBox(x0=10, y0=10, x1=510, y1=410),
                    ),
                ],
                tables=[table],
            )
        ],
        raw={
            "original_filename": f"{company}-{order_number}.pdf",
            "tenant_id": f"tenant-{company}",
            "task_id": f"task-{order_number}",
            "email": email,
        },
    )


def _evidence_with_semantic_tables(
    headers: tuple[tuple[str, ...], ...],
    *,
    private_value: str,
) -> DocumentEvidence:
    tables = []
    for table_index, header in enumerate(headers):
        values = [
            f"{private_value}-t{table_index}-c{column_index}"
            for column_index in range(len(header))
        ]
        tables.append(
            EvidenceTable(
                table_id=f"private-{private_value}-{table_index}",
                rows=[list(header), values],
                orientation="rows",
                header_indices=[0],
            )
        )
    return DocumentEvidence(
        backend="fixture",
        source_kind=f"C:/private/{private_value}.pdf",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=800,
                tables=tables,
            )
        ],
        raw={"original_filename": f"{private_value}.pdf"},
    )


def test_signature_is_value_free_canonical_and_has_stable_exact_fingerprint() -> None:
    first = _signature(
        labels=("unit", "model", "quantity", "model"),
        layout=("title_then_table", "bordered"),
        blocks=("table", "title"),
    )
    second = _signature(
        labels=("quantity", "model", "unit"),
        layout=("bordered", "title_then_table"),
        blocks=("title", "table"),
    )

    assert first == second
    assert first.exact_fingerprint() == second.exact_fingerprint()
    assert len(first.exact_fingerprint()) == 64
    assert "SO-202607-001" not in first.embedding_text()
    assert set(first.embedding_text().splitlines()) >= {
        "label=model",
        "label=quantity",
        "structure=format:fixed_page",
    }
    assert first.exact_fingerprint() != _signature(columns=4).exact_fingerprint()

    with pytest.raises(ValidationError, match="extra_forbidden"):
        DocumentRouteSignature.model_validate(
            {
                **first.model_dump(mode="python"),
                "business_values": {"order_id": "SO-202607-001"},
            }
        )
    with pytest.raises(ValidationError, match="canonical non-value identifiers"):
        _signature(labels=("model", "customer name=Acme Corp"))


def test_builder_uses_only_allowlisted_semantics_and_structural_evidence() -> None:
    evidence = _evidence_with_business_values(
        order_number="SO-202607-001",
        company="示例客户甲有限公司",
        email="buyer@example.com",
        phone="13800138000",
    )

    signature = build_document_route_signature(evidence)

    assert signature.format_family == "fixed_page"
    assert signature.page_count_bucket == "single"
    assert signature.block_kinds == ("image", "table", "title")
    assert signature.label_tokens == (
        "customer",
        "delivery_date",
        "order_number",
        "product_id",
    )
    shape = signature.table_shapes[0]
    assert (
        shape.table_index,
        shape.row_count_bucket,
        shape.column_count,
        shape.header_row_count,
        shape.orientation,
    ) == (0, "few", 3, 1, "records_by_row")
    assert shape.semantic_label_positions == (
        "r0:c0:order_number",
        "r0:c1:customer",
    )
    assert shape.semantic_topology_digest is not None
    assert len(shape.semantic_topology_digest) == 64
    assert set(signature.layout_tokens) >= {
        "page_orientation:landscape",
        "rotation:90",
        "scan:scanned",
        "table:single",
        "visual:dominant",
        "visual:present",
    }


def test_heterogeneous_tables_keep_evidence_identity_when_signature_is_canonicalized() -> None:
    evidence = DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=800,
                tables=[
                    EvidenceTable(
                        table_id="first-record-table",
                        orientation="rows",
                        header_indices=[0],
                        rows=[
                            ["a", "b", "c", "d"],
                            ["1", "2", "3", "4"],
                            ["5", "6", "7", "8"],
                        ],
                    ),
                    EvidenceTable(
                        table_id="second-key-value-table",
                        orientation="columns",
                        header_indices=[0],
                        rows=[["key", "value"], ["x", "y"]],
                    ),
                ],
            )
        ],
    )

    signature = build_document_route_signature(evidence, "pdf")

    assert [
        (shape.table_index, shape.orientation, shape.column_count)
        for shape in signature.table_shapes
    ] == [
        (0, "records_by_row", 4),
        (1, "records_by_column", 2),
    ]
    rebuilt = DocumentRouteSignature(
        **{
            **signature.model_dump(mode="python"),
            "table_shapes": tuple(reversed(signature.table_shapes)),
        }
    )
    assert rebuilt == signature
    assert rebuilt.exact_fingerprint() == signature.exact_fingerprint()
    assert "structure=table:i0:records_by_row:few:c4:h1" in (
        signature.embedding_text()
    )
    assert "structure=table:i1:records_by_column:few:c2:h1" in (
        signature.embedding_text()
    )

    with pytest.raises(ValidationError, match="unique and contiguous"):
        DocumentRouteSignature(
            **{
                **signature.model_dump(mode="python"),
                "table_shapes": (
                    signature.table_shapes[0],
                    signature.table_shapes[1].model_copy(update={"table_index": 0}),
                ),
            }
        )


def test_same_structure_with_different_business_values_has_same_signature() -> None:
    first = build_document_route_signature(
        _evidence_with_business_values(
            order_number="SO-202607-001",
            company="示例客户甲有限公司",
            email="buyer@example.com",
            phone="13800138000",
        )
    )
    second = build_document_route_signature(
        _evidence_with_business_values(
            order_number="PO-999999-XYZ",
            company="Completely Different Customer Ltd",
            email="different.person@other.example",
            phone="18699998888",
        )
    )

    assert first == second
    assert first.exact_fingerprint() == second.exact_fingerprint()
    assert first.embedding_text() == second.embedding_text()


def test_semantic_topology_distinguishes_table_order_and_column_meaning() -> None:
    headers = (
        ("order_number", "quantity"),
        ("product_id", "unit"),
    )
    baseline = build_document_route_signature(
        _evidence_with_semantic_tables(headers, private_value="PRIVATE-A")
    )
    same_layout_new_values = build_document_route_signature(
        _evidence_with_semantic_tables(headers, private_value="PRIVATE-B")
    )
    columns_swapped = build_document_route_signature(
        _evidence_with_semantic_tables(
            (("quantity", "order_number"), headers[1]),
            private_value="PRIVATE-C",
        )
    )
    tables_swapped = build_document_route_signature(
        _evidence_with_semantic_tables(
            tuple(reversed(headers)),
            private_value="PRIVATE-D",
        )
    )

    assert baseline.label_tokens == columns_swapped.label_tokens
    assert baseline.label_tokens == tables_swapped.label_tokens
    assert baseline.exact_fingerprint() == same_layout_new_values.exact_fingerprint()
    assert baseline.embedding_text() == same_layout_new_values.embedding_text()
    assert baseline.exact_fingerprint() != columns_swapped.exact_fingerprint()
    assert baseline.exact_fingerprint() != tables_swapped.exact_fingerprint()
    assert baseline.embedding_text() != columns_swapped.embedding_text()
    assert baseline.embedding_text() != tables_swapped.embedding_text()

    ranked = AdaptiveDocumentRouter().rank_candidates(
        columns_swapped,
        [DocumentRouteCandidate(route_id="baseline", signature=baseline)],
    )
    assert ranked[0].exact_fingerprint is False
    assert ranked[0].structure_similarity < 1.0
    signatures = (
        baseline,
        same_layout_new_values,
        columns_swapped,
        tables_swapped,
    )
    for signature, private_value in zip(
        signatures,
        ("PRIVATE-A", "PRIVATE-B", "PRIVATE-C", "PRIVATE-D"),
        strict=True,
    ):
        assert private_value not in signature.model_dump_json()
        assert private_value not in signature.embedding_text()


def test_semantic_topology_digest_distinguishes_overflow_bucket_columns() -> None:
    first_header = ["private_header"] * 66
    first_header[64:66] = ["order_number", "quantity"]
    second_header = list(first_header)
    second_header[64:66] = ["quantity", "order_number"]

    first = build_document_route_signature(
        _evidence_with_semantic_tables(
            (tuple(first_header),),
            private_value="PRIVATE-WIDE-A",
        )
    )
    second = build_document_route_signature(
        _evidence_with_semantic_tables(
            (tuple(second_header),),
            private_value="PRIVATE-WIDE-B",
        )
    )

    assert first.label_tokens == second.label_tokens
    assert (
        first.table_shapes[0].semantic_label_positions
        == second.table_shapes[0].semantic_label_positions
    )
    assert (
        first.table_shapes[0].semantic_topology_digest
        != second.table_shapes[0].semantic_topology_digest
    )
    assert first.exact_fingerprint() != second.exact_fingerprint()
    assert first.embedding_text() != second.embedding_text()
    assert "PRIVATE-WIDE" not in first.model_dump_json()
    assert "PRIVATE-WIDE" not in first.embedding_text()


def test_builder_maps_only_allowlisted_structural_labels_from_cells() -> None:
    evidence = _evidence_with_business_values(
        order_number="SO-202607-001",
        company="Private Customer",
        email="private@example.com",
        phone="13800138000",
    )
    evidence.model_extra.pop("semantic_labels", None)

    signature = build_document_route_signature(evidence, source_kind="pdf")

    assert signature.label_tokens == ("customer", "order_number")
    assert "Private Customer" not in signature.model_dump_json()
    assert "private@example.com" not in signature.embedding_text()


def test_builder_never_exposes_filename_identifiers_or_pii() -> None:
    private_values = {
        "order": "PRIVATE-ORDER-50391",
        "company": "Secret Customer Incorporated",
        "email": "private.person@secret.example",
        "phone": "13912345678",
        "tenant": "tenant-Secret Customer Incorporated",
        "task": "task-PRIVATE-ORDER-50391",
    }
    signature = build_document_route_signature(
        _evidence_with_business_values(
            order_number=private_values["order"],
            company=private_values["company"],
            email=private_values["email"],
            phone=private_values["phone"],
        )
    )
    serialized = signature.model_dump_json()
    embedding_text = signature.embedding_text()

    for value in private_values.values():
        assert value.casefold() not in serialized.casefold()
        assert value.casefold() not in embedding_text.casefold()
    assert "unknown_secret" not in serialized.casefold()
    assert "filename" not in embedding_text.casefold()
    assert "tenant" not in embedding_text.casefold()
    assert "task" not in embedding_text.casefold()


@pytest.mark.parametrize(
    ("source_kind", "expected"),
    [
        ("application/pdf", "fixed_page"),
        ("C:/private/customer-13800138000.PDF", "fixed_page"),
        ("image/png", "image"),
        ("scan.TIFF", "image"),
        ("table", "spreadsheet"),
        ("application/vnd.ms-excel", "spreadsheet"),
        ("private-values.xlsx", "spreadsheet"),
        (
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "word_processing",
        ),
        ("private-document.docx", "word_processing"),
        ("private-deck.pptx", "presentation"),
        ("text/html; charset=utf-8", "web"),
        ("private-page.HTML", "web"),
        ("untrusted/customer/private-format", "unknown"),
    ],
)
def test_builder_maps_supported_source_kinds_without_copying_them(
    source_kind: str, expected: str
) -> None:
    signature = build_document_route_signature(
        DocumentEvidence(backend="fixture"),
        source_kind,
    )

    assert signature.format_family == expected
    assert "customer-13800138000" not in signature.embedding_text().casefold()
    assert "private-values" not in signature.embedding_text().casefold()
    assert "private-document" not in signature.embedding_text().casefold()
    assert "private-deck" not in signature.embedding_text().casefold()
    assert "private-page" not in signature.embedding_text().casefold()


def test_builder_drops_unknown_labels_and_ignores_mapping_values() -> None:
    signature = build_document_route_signature(
        DocumentEvidence(backend="fixture"),
        "xlsx",
        semantic_labels={
            "$.header.order_number": "SO-SECRET-001",
            "数量": "999999",
            "private.person@secret.example": "13912345678",
            "unknown_customer_field": "Secret Customer Incorporated",
        },
    )

    assert signature.label_tokens == ("order_number", "quantity")
    assert "secret" not in signature.embedding_text().casefold()
    assert "13912345678" not in signature.embedding_text()


@pytest.mark.asyncio
async def test_exact_fingerprint_reuses_without_calling_model() -> None:
    signature = _signature()
    selector = _Selector(
        DocumentRouteModelChoice(
            action="generic",
            candidate_route_id=None,
            confidence=1.0,
        )
    )
    router = AdaptiveDocumentRouter(selector=selector)

    decision = await router.decide(
        signature,
        [DocumentRouteCandidate(route_id="route-exact", signature=signature)],
    )

    assert decision.action == "reuse"
    assert decision.route_id == "route-exact"
    assert decision.reason == "exact_fingerprint"
    assert decision.top_score == 1.0
    assert selector.calls == 0


@pytest.mark.asyncio
async def test_ambiguous_exact_fingerprint_fails_closed() -> None:
    signature = _signature()
    selector = _Selector(
        {"action": "reuse", "candidate_route_id": "route-a", "confidence": 1.0}
    )
    router = AdaptiveDocumentRouter(selector=selector)

    decision = await router.decide(
        signature,
        [
            DocumentRouteCandidate(route_id="route-b", signature=signature),
            DocumentRouteCandidate(route_id="route-a", signature=signature),
        ],
    )

    assert decision.action == "generic"
    assert decision.reason == "ambiguous_exact_fingerprint"
    assert selector.calls == 0


def test_candidate_ranking_fuses_structure_labels_and_vector() -> None:
    signature = _signature()
    router = AdaptiveDocumentRouter()
    candidates = [
        DocumentRouteCandidate(
            route_id="route-near",
            signature=_signature(layout=("table_with_footer",)),
            signature_vector=(1.0, 0.0),
        ),
        DocumentRouteCandidate(
            route_id="route-far",
            signature=_signature(
                labels=("drawing_number", "revision"),
                layout=("drawing_title_block",),
                blocks=("figure", "text"),
                columns=2,
                page_count="few",
            ),
            signature_vector=(0.0, 1.0),
        ),
    ]

    ranked = router.rank_candidates(
        signature,
        candidates,
        signature_vector=(1.0, 0.0),
    )

    assert [item.route_id for item in ranked] == ["route-near", "route-far"]
    near, far = ranked
    assert near.structure_similarity > far.structure_similarity
    assert near.label_similarity == 1.0
    assert far.label_similarity == 0.0
    assert near.vector_similarity == 1.0
    assert far.vector_similarity == 0.0
    assert near.fused_score > far.fused_score


@pytest.mark.asyncio
async def test_approximate_reuse_requires_top_candidate_score_and_margin() -> None:
    signature = _signature()
    top = DocumentRouteCandidate(
        route_id="route-a-top",
        signature=_signature(layout=("table_with_footer",)),
        signature_vector=(1.0, 0.0),
    )
    second = DocumentRouteCandidate(
        route_id="route-second",
        signature=_signature(layout=("table_with_note",)),
        signature_vector=(1.0, 0.0),
    )
    selector = _Selector(
        {"action": "reuse", "candidate_route_id": "route-a-top", "confidence": 0.99}
    )
    router = AdaptiveDocumentRouter(
        selector=selector,
        policy=DocumentRoutePolicy(reuse_min_score=0.50, reuse_min_margin=0.05),
    )

    decision = await router.decide(
        signature,
        [top, second],
        signature_vector=(1.0, 0.0),
    )

    assert decision.action == "generic"
    assert decision.reason == "reuse_margin_below_threshold"
    assert decision.top1_top2_margin == 0.0
    assert selector.calls == 1


@pytest.mark.asyncio
async def test_approximate_reuse_passes_all_deterministic_gates() -> None:
    signature = _signature()
    selector = _Selector(
        {"action": "reuse", "candidate_route_id": "route-top", "confidence": 0.95}
    )
    router = AdaptiveDocumentRouter(
        selector=selector,
        policy=DocumentRoutePolicy(reuse_min_score=0.60, reuse_min_margin=0.10),
    )
    candidates = [
        DocumentRouteCandidate(
            route_id="route-top",
            signature=_signature(layout=("table_with_footer",)),
            signature_vector=(1.0, 0.0),
        ),
        DocumentRouteCandidate(
            route_id="route-far",
            signature=_signature(
                labels=("drawing_number",),
                layout=("drawing_title_block",),
                blocks=("figure",),
                columns=1,
                page_count="many",
            ),
            signature_vector=(0.0, 1.0),
        ),
    ]

    decision = await router.decide(
        signature,
        candidates,
        signature_vector=(1.0, 0.0),
    )

    assert decision.action == "reuse"
    assert decision.route_id == "route-top"
    assert decision.reason == "model_reuse"
    assert decision.model_used is True
    assert decision.model_choice == "reuse"
    assert decision.top_score >= 0.60
    assert decision.top1_top2_margin >= 0.10


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "selector,reason",
    [
        (None, "no_model"),
        (_Selector(error=TimeoutError()), "model_failure"),
        (
            _Selector(
                {
                    "action": "reuse",
                    "candidate_route_id": "route-top",
                    "confidence": 0.99,
                    "unexpected": True,
                }
            ),
            "invalid_model_output",
        ),
    ],
)
async def test_no_model_failure_and_invalid_output_fall_back_to_generic(
    selector, reason: str
) -> None:
    router = AdaptiveDocumentRouter(selector=selector)

    decision = await router.decide(
        _signature(),
        [
            DocumentRouteCandidate(
                route_id="route-top",
                signature=_signature(layout=("different",)),
            )
        ],
    )

    assert decision.action == "generic"
    assert decision.route_id is None
    assert decision.reason == reason


@pytest.mark.asyncio
async def test_model_can_choose_generic_or_propose_but_low_confidence_proposal_closes() -> None:
    signature = _signature()

    generic = await AdaptiveDocumentRouter(
        selector=_Selector(
            {"action": "generic", "candidate_route_id": None, "confidence": 0.2}
        )
    ).decide(signature, [])
    proposed = await AdaptiveDocumentRouter(
        selector=_Selector(
            {"action": "propose", "candidate_route_id": None, "confidence": 0.9}
        )
    ).decide(signature, [])
    rejected = await AdaptiveDocumentRouter(
        selector=_Selector(
            {"action": "propose", "candidate_route_id": None, "confidence": 0.6}
        )
    ).decide(signature, [])

    assert (generic.action, generic.reason) == ("generic", "model_generic")
    assert (proposed.action, proposed.reason) == ("propose", "model_propose")
    assert (rejected.action, rejected.reason) == (
        "generic",
        "proposal_confidence_below_threshold",
    )


@pytest.mark.asyncio
async def test_model_cannot_reuse_non_top_candidate_or_bypass_score_threshold() -> None:
    signature = _signature()
    candidates = [
        DocumentRouteCandidate(
            route_id="route-top",
            signature=_signature(layout=("near",)),
        ),
        DocumentRouteCandidate(
            route_id="route-second",
            signature=_signature(
                labels=("drawing_number",),
                layout=("far",),
                blocks=("figure",),
                columns=1,
            ),
        ),
    ]

    wrong_candidate = await AdaptiveDocumentRouter(
        selector=_Selector(
            {
                "action": "reuse",
                "candidate_route_id": "route-second",
                "confidence": 1.0,
            }
        ),
        policy=DocumentRoutePolicy(reuse_min_score=0.0, reuse_min_margin=0.0),
    ).decide(signature, candidates)
    below_score = await AdaptiveDocumentRouter(
        selector=_Selector(
            {"action": "reuse", "candidate_route_id": "route-top", "confidence": 1.0}
        ),
        policy=DocumentRoutePolicy(reuse_min_score=0.99, reuse_min_margin=0.0),
    ).decide(signature, candidates)

    assert wrong_candidate.reason == "reuse_candidate_not_top"
    assert wrong_candidate.action == "generic"
    assert below_score.reason == "reuse_score_below_threshold"
    assert below_score.action == "generic"


def test_strict_model_choice_rejects_extra_or_inconsistent_fields() -> None:
    with pytest.raises(ValidationError, match="candidate_route_id"):
        DocumentRouteModelChoice(
            action="reuse",
            candidate_route_id=None,
            confidence=0.9,
        )
    with pytest.raises(ValidationError, match="only reuse"):
        DocumentRouteModelChoice(
            action="generic",
            candidate_route_id="route-a",
            confidence=0.9,
        )
    with pytest.raises(ValidationError, match="extra_forbidden"):
        DocumentRouteModelChoice.model_validate(
            {
                "action": "generic",
                "candidate_route_id": None,
                "confidence": 0.9,
                "explanation": "unbounded model prose",
            },
            strict=True,
        )


@pytest.mark.asyncio
async def test_pydantic_selector_uses_one_strict_value_free_request() -> None:
    class Client:
        def __init__(self) -> None:
            self.calls = []

        async def run(self, output_type, **kwargs):
            self.calls.append((output_type, kwargs))
            return SimpleNamespace(
                output=DocumentRouteModelChoice(
                    action="propose",
                    candidate_route_id=None,
                    confidence=0.95,
                )
            )

    client = Client()
    selector = PydanticDocumentRouteSelector(client)
    signature = _signature()
    decision = await AdaptiveDocumentRouter(selector=selector).decide(signature, [])

    assert decision.action == "propose"
    assert len(client.calls) == 1
    output_type, kwargs = client.calls[0]
    assert output_type is DocumentRouteModelChoice
    assert kwargs["request_limit"] == 1
    assert "SO-202607-001" not in kwargs["prompt"]
    assert "business_values" not in kwargs["prompt"]
