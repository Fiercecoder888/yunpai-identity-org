from __future__ import annotations

import hashlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from m1.documents.models import (
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
)
from m1.documents.parsing.adaptive_postbuild import run_adaptive_postbuild
from m1.documents.parsing.content_region_contracts import (
    ContentRegionKind,
    ContentRegionProbe,
    ContentRegionRole,
    ContentRegionSemanticSketch,
    ContentRegionSignature,
    ContentRegionSourceFamily,
    semantic_label_sha256,
)
from m1.documents.parsing.content_region_routing import (
    ContentRegionRoutingDecision,
)
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.field_semantic_contracts import (
    FieldSemanticResolution,
    FieldSemanticResolvedInput,
)
from m1.documents.parsing.mineru_domain import mapping_path
from m1.documents.parsing.semantic_strategy_router import SemanticStrategyId
from m1.documents.parsing.visual_region_routing import (
    VisualAreaBucket,
    VisualAspectBucket,
    VisualPositionBucket,
    VisualRegionRole,
    VisualRegionRoutingDecision,
    VisualRegionSourceKind,
    VisualRegionTopology,
)
from m1.state import TaskState
from m1.workflow.engine import WorkflowEngine


class _ContentRuntime:
    required = False
    max_regions_per_document = 64

    def __init__(self, *, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[dict] = []

    async def resolve(self, **kwargs):
        self.calls.append(kwargs)
        if self.fail:
            raise RuntimeError("content route unavailable")
        return ContentRegionRoutingDecision(
            action="new_candidate",
            reason="selector_unavailable",
            candidate_profile_id="candidate-content",
        )


class _FieldRuntime:
    required = False
    mode = "guarded"

    def __init__(self, *, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[tuple] = []

    async def resolve_fields(self, *, tenant_id, fields, created_by):
        self.calls.append((tenant_id, fields, created_by))
        if self.fail:
            raise RuntimeError("field route unavailable")
        return tuple(
            FieldSemanticResolvedInput(
                source_ref=field.source_ref,
                resolution=FieldSemanticResolution(
                    action="mapped",
                    reason="exact_reviewed_active_profile",
                    canonical_field_id="line.product_code",
                    profile_id="field-profile-product-code",
                ),
            )
            for field in fields
        )


class _VisualRuntime:
    required = False
    max_regions_per_document = 8

    def __init__(self, *, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[dict] = []

    async def resolve(self, **kwargs):
        self.calls.append(kwargs)
        if self.fail:
            raise RuntimeError("visual route unavailable")
        return VisualRegionRoutingDecision(
            action="review",
            reason="selector_unavailable",
            geometry_reason=kwargs["geometry"].reason,
            asset_identity="sha256_exact",
            review_required=True,
        )


def _content_probe(source_ref: str, *, signature_number: int) -> ContentRegionProbe:
    return ContentRegionProbe(
        source_ref=source_ref,
        signature=ContentRegionSignature(
            source_family=ContentRegionSourceFamily.NATIVE,
            region_kind=ContentRegionKind.PARAGRAPH,
            semantic_sketch=ContentRegionSemanticSketch(
                semantic_label_hashes=(
                    semantic_label_sha256(f"synthetic-label-{signature_number}"),
                ),
                label_count=1,
            ),
        ),
    )


def _lossless_document(filename: str) -> DocumentRecord:
    first_path = mapping_path("$.lines[0]", "raw_columns", "Customer SKU")
    second_path = mapping_path("$.lines[1]", "raw_columns", "Customer SKU")
    return DocumentRecord(
        source=DocumentSource(original_filename=filename),
        document_type="order",
        document_subtype="purchase_contract",
        lines=[
            OrderLine(
                line_id="line-1",
                product_code="EXISTING-SKU",
                raw_columns={"Customer SKU": "MODEL-MUST-NOT-OVERWRITE"},
            ),
            OrderLine(
                line_id="line-2",
                raw_columns={"Customer SKU": "NEW-SKU"},
            ),
        ],
        field_meta={
            first_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            ),
            second_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A3")]
            ),
        },
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "source_kind",
    [
        "pdf",
        "image",
        "docx",
        "pptx",
        "html",
        "xlsx",
        "xlsm",
        "xls",
        "csv",
        "dxf",
        "dwg",
    ],
)
async def test_postbuild_routes_all_document_formats_losslessly(
    tmp_path: Path,
    source_kind: str,
) -> None:
    source = tmp_path / f"input.{source_kind}"
    source.write_bytes(b"postbuild-test-source")
    content = _ContentRuntime()
    field = _FieldRuntime()
    document = _lossless_document(source.name)

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind=source_kind,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
        content_runtime=content,
        field_runtime=field,
    )

    assert content.calls
    assert len(field.calls) == 1
    assert all(call["tenant_id"] == "tenant-a" for call in content.calls)
    assert field.calls[0][0] == "tenant-a"
    assert result["document_type"] == "order"
    assert result["document_subtype"] == "purchase_contract"
    assert result["lines"][0]["product_code"] == "EXISTING-SKU"
    assert result["lines"][1]["product_code"] == "NEW-SKU"
    assert result["lines"][0]["raw_columns"] == {
        "Customer SKU": "MODEL-MUST-NOT-OVERWRITE"
    }
    assert result["lines"][1]["raw_columns"] == {"Customer SKU": "NEW-SKU"}
    assert result["field_meta"]["$.lines[1].product_code"]["source_refs"] == [
        {
            "sheet": None,
            "page": 1,
            "cell": None,
            "range": None,
            "part": "table:1/cell:A3",
            "archive_path": None,
        }
    ]
    marker = result["extraction"]["metadata"]["adaptive_postbuild"]
    assert marker["invocation_count"] == 1
    assert marker["stages"]["content"]["status"] == "completed"
    assert marker["stages"]["field"]["lossless_source_preserved"] is True

    replay = await run_adaptive_postbuild(
        result,
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind=source_kind,
        content_runtime=content,
        field_runtime=field,
    )

    assert replay == result
    assert len(field.calls) == 1


@pytest.mark.asyncio
async def test_content_regions_are_grouped_bounded_and_expanded_by_source_ref(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "many-regions.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    probes = tuple(
        _content_probe(
            f"page:{signature_number + 1}/block:{copy_number}",
            signature_number=signature_number,
        )
        for signature_number in range(18)
        for copy_number in range(2)
    )
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild.build_content_region_probes",
        lambda _evidence: probes,
    )
    runtime = _ContentRuntime()
    document = _lossless_document(source.name)
    before = document.model_dump(mode="json")

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=runtime,
    )

    audit = result["extraction"]["metadata"]["content_region_routing"]
    assert len(runtime.calls) == 16
    assert (
        len({call["probe"].signature.exact_fingerprint() for call in runtime.calls})
        == 16
    )
    assert audit["status"] == "deferred"
    assert audit["region_count"] == 36
    assert audit["unique_signature_count"] == 18
    assert audit["processed_region_count"] == 32
    assert audit["processed_unique_signature_count"] == 16
    assert audit["routing_resolution_count"] == 16
    assert audit["model_call_upper_bound"] == 16
    assert audit["unique_signature_limit"] == 16
    assert audit["deduplicated_region_count"] == 18
    assert audit["reused_decision_region_count"] == 16
    assert audit["deferred_region_count"] == 4
    assert audit["deferred_unique_signature_count"] == 2
    assert audit["truncated_region_count"] == 4
    assert audit["truncation_reason"] == "unique_signature_limit"
    assert [item["source_ref"] for item in audit["decisions"]] == [
        probe.source_ref for probe in probes[:32]
    ]
    assert all(item["signature_group_size"] == 2 for item in audit["decisions"])
    assert sum(item["group_decision_reused"] for item in audit["decisions"]) == 16
    assert result["header"] == before["header"]
    assert result["lines"] == before["lines"]
    assert result["totals"] == before["totals"]
    assert result["field_meta"] == before["field_meta"]


@pytest.mark.asyncio
async def test_content_active_strategy_stays_audit_only_without_safe_executor(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "content-route.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild.build_content_region_probes",
        lambda _evidence: (_content_probe("page:1/block:1", signature_number=1),),
    )

    class ActiveRuntime(_ContentRuntime):
        async def resolve(self, **kwargs):
            self.calls.append(kwargs)
            return ContentRegionRoutingDecision(
                action="route",
                reason="exact_reviewed_active_profile",
                role=ContentRegionRole.BODY_TEXT,
                strategy_id=SemanticStrategyId.GENERIC,
                profile_id="active-content-profile",
            )

    document = _lossless_document(source.name)
    before = document.model_dump(mode="json")
    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=ActiveRuntime(),
    )

    audit = result["extraction"]["metadata"]["content_region_routing"]
    assert audit["routed_region_count"] == 1
    assert audit["strategy_execution"] == {
        "status": "audit_only",
        "reason": "no_region_scoped_fact_preserving_executor",
        "fact_mutation_allowed": False,
    }
    assert result["header"] == before["header"]
    assert result["lines"] == before["lines"]
    assert result["field_meta"] == before["field_meta"]


@pytest.mark.asyncio
async def test_field_routes_are_value_free_deduplicated_and_bounded(
    tmp_path: Path,
) -> None:
    source = tmp_path / "many-fields.csv"
    source.write_text("field,value\n", encoding="utf-8")
    document = _lossless_document(source.name)
    document.extraction = {
        "custom_fields": {
            f"Unknown field {chr(ord('A') + index)}": f"value-{index}"
            for index in range(20)
        }
    }
    runtime = _FieldRuntime()

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="csv",
        field_runtime=runtime,
    )

    assert len(runtime.calls) == 1
    assert len(runtime.calls[0][1]) == 16
    audit = result["extraction"]["metadata"]["field_semantic_routing"]
    assert audit["status"] == "deferred"
    assert audit["unique_signature_count"] == 21
    assert audit["processed_unique_signature_count"] == 16
    assert audit["deferred_unique_signature_count"] == 5
    assert audit["routing_resolution_count"] == 16
    assert audit["model_call_upper_bound"] == 16
    assert audit["unique_signature_limit"] == 16
    assert audit["truncation_reason"] == "unique_signature_limit"
    assert result["extraction"]["custom_fields"] == document.extraction["custom_fields"]


@pytest.mark.asyncio
async def test_visual_routes_are_bounded_by_value_free_topology_signature(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "many-images.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    payloads = [f"image-{index}".encode() for index in range(18)]
    assets = [
        SimpleNamespace(
            asset_id=f"asset-{index}",
            byte_size=len(payload),
            mime_type="image/png",
            sha256=hashlib.sha256(payload).hexdigest(),
            source_refs=(),
            signature_number=index,
        )
        for index, payload in enumerate(payloads)
    ]
    inventory = SimpleNamespace(
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        assets=assets,
    )
    monkeypatch.setattr(
        "m1.documents.parsing.source_asset_inventory.inventory_source_assets",
        lambda _path: inventory,
    )
    monkeypatch.setattr(
        "m1.documents.parsing.visual_asset_evidence._read_asset_payload",
        lambda _source, _inventory, asset: payloads[asset.signature_number],
    )
    positions = tuple(VisualPositionBucket)
    areas = tuple(VisualAreaBucket)
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild._inventory_topology",
        lambda asset, **_kwargs: VisualRegionTopology(
            source_kind=VisualRegionSourceKind.PDF_FIGURE,
            horizontal_position=positions[asset.signature_number % len(positions)],
            vertical_position=positions[
                (asset.signature_number // len(positions)) % len(positions)
            ],
            area_bucket=areas[
                (asset.signature_number // (len(positions) ** 2)) % len(areas)
            ],
            aspect_bucket=VisualAspectBucket.SQUARE,
        ),
    )
    runtime = _VisualRuntime()
    runtime.max_regions_per_document = 64

    result = await run_adaptive_postbuild(
        _lossless_document(source.name).model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        visual_runtime=runtime,
    )

    audit = result["extraction"]["metadata"]["visual_region_routing"]
    assert len(runtime.calls) == 16
    assert audit["status"] == "deferred"
    assert audit["asset_count"] == audit["unique_signature_count"] == 18
    assert audit["processed_unique_signature_count"] == 16
    assert audit["routing_resolution_count"] == 16
    assert audit["model_call_upper_bound"] == 16
    assert audit["deferred_asset_count"] == 2
    assert audit["deferred_unique_signature_count"] == 2
    assert set(audit["deferred"].values()) == {"unique_signature_limit"}


@pytest.mark.asyncio
async def test_visual_distinct_assets_with_same_topology_are_not_unsafely_reused(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "same-topology.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    payloads = (b"first-image", b"second-image")
    assets = [
        SimpleNamespace(
            asset_id=f"asset-{index}",
            byte_size=len(payload),
            mime_type="image/png",
            sha256=hashlib.sha256(payload).hexdigest(),
            source_refs=(),
            payload=payload,
        )
        for index, payload in enumerate(payloads)
    ]
    monkeypatch.setattr(
        "m1.documents.parsing.source_asset_inventory.inventory_source_assets",
        lambda _path: SimpleNamespace(
            source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            assets=assets,
        ),
    )
    monkeypatch.setattr(
        "m1.documents.parsing.visual_asset_evidence._read_asset_payload",
        lambda _source, _inventory, asset: asset.payload,
    )
    topology = VisualRegionTopology(
        source_kind=VisualRegionSourceKind.PDF_FIGURE,
        area_bucket=VisualAreaBucket.MEDIUM,
        aspect_bucket=VisualAspectBucket.SQUARE,
    )
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild._inventory_topology",
        lambda _asset, **_kwargs: topology,
    )
    runtime = _VisualRuntime()

    result = await run_adaptive_postbuild(
        _lossless_document(source.name).model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        visual_runtime=runtime,
    )

    audit = result["extraction"]["metadata"]["visual_region_routing"]
    assert len(runtime.calls) == 1
    assert audit["unique_signature_count"] == 1
    assert audit["deduplicated_asset_count"] == 1
    assert audit["routed_asset_count"] == 1
    assert audit["deferred"] == {"asset-1": "distinct_asset_same_value_free_signature"}


@pytest.mark.asyncio
async def test_optional_group_failure_is_called_once_and_expanded_for_audit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "duplicate-regions.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    probes = tuple(
        _content_probe(f"page:1/block:{index}", signature_number=1)
        for index in range(3)
    )
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild.build_content_region_probes",
        lambda _evidence: probes,
    )
    runtime = _ContentRuntime(fail=True)

    result = await run_adaptive_postbuild(
        _lossless_document(source.name).model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=runtime,
    )

    audit = result["extraction"]["metadata"]["content_region_routing"]
    assert len(runtime.calls) == 1
    assert audit["status"] == "degraded"
    assert audit["processed_unique_signature_count"] == 1
    assert audit["failed_unique_signature_count"] == 1
    assert audit["routing_resolution_count"] == 1
    assert audit["decisions"] == []
    assert [item["source_ref"] for item in audit["failures"]] == [
        probe.source_ref for probe in probes
    ]


@pytest.mark.asyncio
async def test_optional_dependency_decision_is_a_degraded_expanded_audit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "degraded-regions.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    probes = tuple(
        _content_probe(f"page:1/block:{index}", signature_number=1)
        for index in range(2)
    )
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild.build_content_region_probes",
        lambda _evidence: probes,
    )

    class DegradedRuntime(_ContentRuntime):
        async def resolve(self, **kwargs):
            self.calls.append(kwargs)
            return ContentRegionRoutingDecision(
                action="review",
                reason="model_failure",
                review_required=True,
            )

    runtime = DegradedRuntime()
    result = await run_adaptive_postbuild(
        _lossless_document(source.name).model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=runtime,
    )

    audit = result["extraction"]["metadata"]["content_region_routing"]
    assert len(runtime.calls) == 1
    assert audit["status"] == "degraded"
    assert audit["resolved_unique_signature_count"] == 1
    assert audit["degraded_unique_signature_count"] == 1
    assert [item["source_ref"] for item in audit["decisions"]] == [
        probe.source_ref for probe in probes
    ]
    assert {item["reason"] for item in audit["failures"]} == {"model_failure"}


@pytest.mark.asyncio
async def test_required_content_dependency_error_propagates_before_group_reuse(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "required-regions.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    probes = tuple(
        _content_probe(f"page:1/block:{index}", signature_number=1)
        for index in range(3)
    )
    monkeypatch.setattr(
        "m1.documents.parsing.adaptive_postbuild.build_content_region_probes",
        lambda _evidence: probes,
    )

    class RequiredRuntime(_ContentRuntime):
        required = True

        async def resolve(self, **kwargs):
            self.calls.append(kwargs)
            raise DocumentRoutingDependencyError("model", "TimeoutError")

    runtime = RequiredRuntime()
    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await run_adaptive_postbuild(
            _lossless_document(source.name).model_dump(mode="python"),
            tenant_id="tenant-a",
            source_path=str(source),
            source_kind="pdf",
            content_runtime=runtime,
        )

    assert caught.value.dependency == "model"
    assert len(runtime.calls) == 1


@pytest.mark.asyncio
async def test_full_mineru_evidence_routes_content_and_prevents_duplicate_field_call(
    tmp_path: Path,
) -> None:
    source = tmp_path / "mineru.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=595,
        height=842,
        blocks=[
            EvidenceBlock(
                block_id="title-1",
                kind="title",
                text="Purchase order",
                order=0,
                source="mineru",
            )
        ],
        tables=[
            EvidenceTable(
                table_id="table-1",
                rows=[["Product code", "Quantity"], ["SKU-1", "2"]],
                source="mineru",
            )
        ],
    )
    document = _lossless_document(source.name)
    document.extraction = {
        "metadata": {
            "adapter": "mineru_instructor",
            "field_semantic_routing": {
                "status": "completed",
                "observed_fields": 1,
                "mapped_fields": 0,
            },
        },
        "raw_content": {"pages": [page.model_dump(mode="json")]},
    }
    content = _ContentRuntime()
    field = _FieldRuntime()

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-mineru",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=content,
        field_runtime=field,
    )

    assert len(content.calls) == 2
    assert field.calls == []
    metadata = result["extraction"]["metadata"]
    assert metadata["content_region_routing"]["evidence_backend"] == (
        "mineru_instructor"
    )
    assert metadata["adaptive_postbuild"]["stages"]["field"] == {
        "schema_version": "m1.field-semantic-postbuild.v1",
        "status": "already_routed",
        "route_status": "completed",
        "duplicate_execution_prevented": True,
    }


@pytest.mark.asyncio
@pytest.mark.parametrize("source_kind", ["pptx", "html"])
async def test_docling_formats_route_retained_content_without_fake_visual_assets(
    tmp_path: Path,
    source_kind: str,
) -> None:
    source = tmp_path / f"docling.{source_kind}"
    source.write_bytes(b"docling-test-source")
    evidence = DocumentEvidence(
        backend="docling",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id="section-1",
                        kind="section",
                        text="Technical requirements",
                    )
                ],
            )
        ],
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename=source.name),
        document_type="technical_document",
        document_subtype=("presentation" if source_kind == "pptx" else "web_document"),
        extraction={
            "metadata": {"structured_evidence": evidence.model_dump(mode="json")}
        },
    )
    content = _ContentRuntime()
    visual = _VisualRuntime()

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-docling",
        source_path=str(source),
        source_kind=source_kind,
        content_runtime=content,
        visual_runtime=visual,
    )

    assert len(content.calls) == 1
    assert visual.calls == []
    metadata = result["extraction"]["metadata"]
    assert metadata["content_region_routing"]["evidence_backend"] == "docling"
    assert metadata["visual_region_routing"] == {
        "schema_version": "m1.visual-region-postbuild.v1",
        "status": "skipped",
        "reason": "no_verified_raster_asset",
        "routed_asset_count": 0,
        "fact_mutation_allowed": False,
    }


@pytest.mark.asyncio
async def test_optional_route_failure_is_degraded_but_required_failure_propagates(
    tmp_path: Path,
) -> None:
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    document = _lossless_document(source.name)
    optional = _ContentRuntime(fail=True)

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="pdf",
        content_runtime=optional,
    )

    audit = result["extraction"]["metadata"]["content_region_routing"]
    assert audit["status"] == "degraded"
    assert result["lines"][0]["product_code"] == "EXISTING-SKU"

    required = _ContentRuntime(fail=True)
    required.required = True
    with pytest.raises(RuntimeError, match="content route unavailable"):
        await run_adaptive_postbuild(
            document.model_dump(mode="python"),
            tenant_id="tenant-a",
            source_path=str(source),
            source_kind="pdf",
            content_runtime=required,
        )


@pytest.mark.asyncio
async def test_visual_route_uses_verified_source_image_without_mutating_facts(
    tmp_path: Path,
) -> None:
    from PIL import Image

    source = tmp_path / "input.png"
    Image.new("RGB", (8, 4), color=(255, 255, 255)).save(source)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    document = _lossless_document(source.name)
    document.source.sha256 = digest
    runtime = _VisualRuntime()

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="image",
        visual_runtime=runtime,
    )

    assert len(runtime.calls) == 1
    assert hashlib.sha256(runtime.calls[0]["image_bytes"]).hexdigest() == digest
    assert runtime.calls[0]["asset_sha256"] == digest
    assert result["lines"] == document.model_dump(mode="json")["lines"]
    visual = result["extraction"]["metadata"]["visual_region_routing"]
    assert visual["status"] == "completed"
    assert visual["fact_mutation_allowed"] is False

    required = _VisualRuntime(fail=True)
    required.required = True
    with pytest.raises(RuntimeError, match="visual route unavailable"):
        await run_adaptive_postbuild(
            document.model_dump(mode="python"),
            tenant_id="tenant-a",
            source_path=str(source),
            source_kind="image",
            visual_runtime=required,
        )


@pytest.mark.asyncio
async def test_visual_candidate_profile_id_is_persisted_in_final_document_audit(
    tmp_path: Path,
) -> None:
    from PIL import Image

    source = tmp_path / "candidate.png"
    Image.new("RGB", (8, 4), color=(255, 255, 255)).save(source)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    document = _lossless_document(source.name)
    document.source.sha256 = digest

    class CandidateRuntime:
        required = False
        max_regions_per_document = 8

        async def resolve(self, **kwargs):
            return VisualRegionRoutingDecision(
                action="new_candidate",
                reason="model_role_proposed_candidate",
                suggested_role=VisualRegionRole.PRODUCT,
                candidate_profile_id="visual-candidate-1",
                geometry_reason=kwargs["geometry"].reason,
                asset_identity="sha256_exact",
                model_used=True,
                model_confidence=0.99,
                candidate_observation_required=True,
            )

    result = await run_adaptive_postbuild(
        document.model_dump(mode="python"),
        tenant_id="tenant-a",
        source_path=str(source),
        source_kind="image",
        visual_runtime=CandidateRuntime(),
    )

    audit = result["extraction"]["metadata"]["visual_region_routing"]
    assert audit["candidate_profile_ids"] == ["visual-candidate-1"]
    assert next(iter(audit["decisions"].values()))["candidate_profile_id"] == (
        "visual-candidate-1"
    )


@pytest.mark.asyncio
async def test_required_field_runtime_cannot_hide_a_degraded_result(
    tmp_path: Path,
) -> None:
    source = tmp_path / "input.csv"
    source.write_text("sku\nA\n", encoding="utf-8")
    runtime = _FieldRuntime(fail=True)
    runtime.required = True

    with pytest.raises(RuntimeError, match="field route unavailable"):
        await run_adaptive_postbuild(
            _lossless_document(source.name).model_dump(mode="python"),
            tenant_id="tenant-a",
            source_path=str(source),
            source_kind="csv",
            field_runtime=runtime,
        )


@pytest.mark.asyncio
async def test_classification_route_propagates_required_runtime_failure(
    tmp_path: Path,
) -> None:
    source = tmp_path / "classification.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class Runtime:
        def __init__(self, *, required: bool) -> None:
            self.required = required

        async def resolve(self, *_args, **_kwargs):
            raise RuntimeError("classification store unavailable")

    state = TaskState(
        task_id="classification-required",
        tenant_id="tenant-a",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename=source.name)
    ).model_dump(mode="json")
    engine = object.__new__(WorkflowEngine)
    engine._save = AsyncMock()
    engine.deps = SimpleNamespace(
        document_classification_runtime=Runtime(required=False),
        document_routing_runtime=None,
    )

    degraded = await engine._classification_route_stage(state, document)

    assert (
        degraded["extraction"]["metadata"]["classification_routing"]["status"]
        == "degraded"
    )

    engine.deps.document_classification_runtime = Runtime(required=True)
    with pytest.raises(RuntimeError, match="classification store unavailable"):
        await engine._classification_route_stage(state, document)
