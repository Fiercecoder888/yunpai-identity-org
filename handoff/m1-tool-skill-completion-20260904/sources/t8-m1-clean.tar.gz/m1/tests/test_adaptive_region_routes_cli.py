from __future__ import annotations

import hashlib
from types import SimpleNamespace

import pytest
from m1.documents.parsing.region_capability_contracts import ParsingCapability
from m1.knowledge.persistence import KnowledgeBase, KnowledgeStore
from m1.state import TaskStatus

from m1 import adaptive_region_routes as cli


class _RouteStore:
    def __init__(self) -> None:
        self.observations: list[object] = []
        self.closed = False
        self.profile = SimpleNamespace(
            profile_id="candidate-1",
            exact_fingerprint="a" * 64,
            capability=ParsingCapability.PADDLEOCR_VL,
            observation_count=3,
        )

    async def activate_region_capability_profile(self, tenant_id, profile_id, **kwargs):
        self.activation = (tenant_id, profile_id, kwargs)
        return SimpleNamespace(status="active")

    async def get_region_capability_profile(self, _tenant_id, _profile_id):
        return self.profile

    async def get_content_region_profile(self, _tenant_id, _profile_id):
        return self.profile

    async def record_region_capability_execution_observation(self, observation):
        self.observations.append(observation)
        return SimpleNamespace(observation_id="region-observation-1")

    async def record_content_region_execution_observation(self, observation):
        self.observations.append(observation)
        return SimpleNamespace(observation_id="content-observation-1")

    async def close(self) -> None:
        self.closed = True


class _TaskStore:
    def __init__(self, document) -> None:
        self.document = document
        self.closed = False

    async def load(self, _task_id):
        return SimpleNamespace(
            tenant_id="tenant-a",
            status=TaskStatus.DONE,
            document=self.document,
        )

    async def close(self) -> None:
        self.closed = True


def _audit(kind: str) -> dict:
    decision = {"candidate_profile_id": "candidate-1", "action": "new_candidate"}
    if kind == "content":
        return {
            "extraction": {
                "metadata": {
                    "content_region_routing": {
                        "decisions": [{"source_ref": "page:1/table:0", **decision}]
                    }
                }
            }
        }
    return {
        "extraction": {
            "metadata": {
                "structured_evidence": {
                    "raw": {"region_capability_routing": {"decisions": {"1": decision}}}
                }
            }
        }
    }


@pytest.mark.parametrize(
    "task_reference",
    ("a" * 64, f"sha256:{'a' * 64}", f"SHA-256:{'a' * 64}"),
)
def test_cli_rejects_prehashed_task_references(task_reference: str) -> None:
    with pytest.raises(SystemExit):
        cli._parser().parse_args(
            [
                "--route-kind",
                "content",
                "record-observation",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "candidate-1",
                "--task-id",
                task_reference,
                "--outcome",
                "success",
                "--reviewed-by",
                "reviewer",
                "--review-note",
                "checked",
            ]
        )


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", ("capability", "content"))
async def test_observation_requires_route_specific_final_audit_and_hashes_task(
    monkeypatch,
    kind: str,
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(_audit(kind))

    async def open_store():
        return route_store

    monkeypatch.setattr(cli, "_open_store", open_store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    task_id = "M1-TASK-ROUTE-1001"
    args = cli._parser().parse_args(
        [
            "--route-kind",
            kind,
            "record-observation",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-1",
            "--task-id",
            task_id,
            "--outcome",
            "success",
            "--reviewed-by",
            "reviewer",
            "--review-note",
            "three samples checked",
        ]
    )

    result = await cli._run(args)

    observation = route_store.observations[0]
    expected = hashlib.sha256(f"tenant-a\0{task_id}".encode()).hexdigest()
    assert observation.task_reference_hash == expected
    assert result["task_reference_hash"] == expected
    assert task_id not in str(result)
    assert task_store.closed is True
    assert route_store.closed is True
    if kind == "capability":
        assert len(observation.region_reference_hash) == 64


@pytest.mark.asyncio
async def test_observation_rejects_candidate_from_another_route_layer(
    monkeypatch,
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(_audit("capability"))

    async def open_store():
        return route_store

    monkeypatch.setattr(cli, "_open_store", open_store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    args = cli._parser().parse_args(
        [
            "--route-kind",
            "content",
            "record-observation",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-1",
            "--task-id",
            "M1-TASK-WRONG-LAYER",
            "--outcome",
            "success",
            "--reviewed-by",
            "reviewer",
            "--review-note",
            "checked",
        ]
    )

    with pytest.raises(ValueError, match="does not reference"):
        await cli._run(args)
    assert route_store.observations == []


def test_knowledge_facade_registers_both_route_layers() -> None:
    assert {
        "knowledge_region_capability_profiles",
        "knowledge_region_capability_observations",
        "knowledge_content_region_profiles",
        "knowledge_content_region_observations",
    } <= set(KnowledgeBase.metadata.tables)
    for method in (
        "get_region_capability_profile",
        "create_region_capability_candidate",
        "get_content_region_profile",
        "create_content_region_candidate",
    ):
        assert callable(getattr(KnowledgeStore, method))


@pytest.mark.asyncio
async def test_capability_activation_allows_only_current_executor(monkeypatch) -> None:
    route_store = _RouteStore()

    async def open_store():
        return route_store

    monkeypatch.setattr(cli, "_open_store", open_store)
    monkeypatch.setattr(
        cli,
        "_profile_payload",
        lambda _kind, _profile: {"status": "active"},
    )
    args = cli._parser().parse_args(
        [
            "--route-kind",
            "capability",
            "activate",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-1",
            "--approved-by",
            "approver",
            "--reviewed-by",
            "reviewer",
            "--review-note",
            "validated",
        ]
    )

    await cli._activate(args)
    assert route_store.activation[2]["allowed_capabilities"] == (
        ParsingCapability.PADDLEOCR_VL,
    )

    route_store.profile.capability = ParsingCapability.DOCLING
    with pytest.raises(ValueError, match="paddleocr_vl"):
        await cli._activate(args)
