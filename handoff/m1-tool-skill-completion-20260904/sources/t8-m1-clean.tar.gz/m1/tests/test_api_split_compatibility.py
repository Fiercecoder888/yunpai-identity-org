"""Compatibility guards for the behavior-preserving API module split."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest
from fastapi import HTTPException
from m1.api import main as api_main
from m1.api import route_support
from m1.documents.ooxml import OOXMLPackageError, OOXMLPackageLimits

# Canonical SHA-256 of ``app.openapi()["paths"]`` after registering the two
# authenticated enhanced-capability diagnostics routes, governed knowledge
# search precision controls, task-list pagination, and asynchronous batch
# acceptance response. This covers every
# path, method, parameter, request body, response, description, and operation
# id without committing a large generated document.
_HEAD_PATHS_SHA256 = "bc6ff0e4c3be7177ecc2116d806a91347273c9c782bc201f42c20e786ee4ca5d"

_RESTORED_DESCRIPTIONS = {
    ("delete", "/tasks/{task_id}"): "删除任务记录 + 关联的上传文件。",
    ("get", "/batch/{parent_id}"): "查询父任务批次: 父状态 + 所有子任务状态。",
    ("get", "/files/{task_id}"): "返回任务对应的原图 (供审核 UI 预览)。",
    (
        "get",
        "/tasks/{task_id}/document",
    ): "返回经过 v2 Schema 校验的完整文档；旧任务无 v2 结果时返回 404。",
    (
        "get",
        "/tasks/{task_id}/download",
    ): "下载原始文档；批次父任务会打包所有子文档和报告。",
    (
        "get",
        "/tasks/{task_id}/exports/order",
    ): "Return a JSON-safe link which an Agent can hand to the caller.",
    (
        "get",
        "/tasks/{task_id}/replication-report/download",
    ): "下载 Markdown 详细复刻报告。",
    (
        "get",
        "/tasks/{task_id}/report/download",
    ): "下载 Markdown 综合报告；不存在时按当前数据即时生成。",
    (
        "post",
        "/ingest/archive",
    ): "单个压缩包上传, 自动解压, 内部文件各建子任务。",
    (
        "post",
        "/ingest/batch",
    ): "多文件批量上传。每个文件建子任务, 返回父任务 id。\n\n支持混合: 普通文件直接处理, 压缩包自动解压后内部文件各建子任务。",
    (
        "post",
        "/ingest/sync",
    ): "同步版 ingest: 上传 → 后台推进 → 等到 done/failed/needs_review → 返回 detail。\n\n"
    "与 /ingest 的区别: 阻塞等待终态。供中央 Agent 当工具调用 (避免轮询)。\n"
    "超时 220s (大文档/慢 VLM 时返回当前状态, 客户端可再查 /tasks/{id})。",
    (
        "post",
        "/tasks/{task_id}/replication-report",
    ): "生成面向工程图复刻的详细 Markdown 报告。",
    (
        "post",
        "/tasks/{task_id}/report",
    ): "生成包含当前已抽取内容的 Markdown 综合报告。\n\n"
    "单文件报告写入 replication_doc/replication_status。\n"
    "批次或压缩包父任务报告写入 batch_summary/batch_summary_status。",
}


def test_split_api_openapi_paths_match_head_snapshot() -> None:
    paths = api_main.app.openapi()["paths"]
    payload = json.dumps(
        paths,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    assert len(paths) == 38
    assert hashlib.sha256(payload).hexdigest() == _HEAD_PATHS_SHA256
    for (method, path), description in _RESTORED_DESCRIPTIONS.items():
        assert paths[path][method]["description"] == description


def test_api_main_keeps_private_helper_import_compatibility() -> None:
    expected = {
        "_attachment_headers": route_support.attachment_headers,
        "_build_batch_zip": route_support.build_batch_zip,
        "_classify_staged_upload": route_support.classify_staged_upload,
        "_media_type_for_path": route_support.media_type_for_path,
        "_safe_archive_name": route_support.safe_archive_name,
        "_safe_download_stem": route_support.safe_download_stem,
        "_save_upload_streaming": route_support.save_upload_streaming,
        "_state_detail": route_support.state_detail,
        "_state_summary": route_support.state_summary,
    }

    for name, implementation in expected.items():
        assert getattr(api_main, name) is implementation


def test_ooxml_default_allows_large_worksheets_within_total_budget() -> None:
    limits = OOXMLPackageLimits()

    assert limits.max_xml_part_size == 100 * 1024 * 1024
    assert limits.max_xml_part_size <= limits.max_part_size
    assert limits.max_xml_part_size < limits.max_total_uncompressed


@pytest.mark.asyncio
async def test_staged_ooxml_rejection_is_a_stable_422(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from m1.ingest import batch

    staged = tmp_path / "unsafe.xlsx"
    staged.write_bytes(b"PK\x03\x04")

    def reject(_path: Path) -> str:
        raise OOXMLPackageError("OOXML part exceeds its bounded limit")

    monkeypatch.setattr(batch, "_detect_ingest_kind", reject)

    with pytest.raises(HTTPException) as raised:
        await route_support.classify_staged_upload(staged)

    assert raised.value.status_code == 422
    assert raised.value.detail == {
        "code": "M1_OFFICE_PACKAGE_INVALID",
        "message": "Office package is malformed or exceeds a safe resource boundary.",
        "details": {"reason": "OOXML part exceeds its bounded limit"},
    }
    assert not staged.exists()
