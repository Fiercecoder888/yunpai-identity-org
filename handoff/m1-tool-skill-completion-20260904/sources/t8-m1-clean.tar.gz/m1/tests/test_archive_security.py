from __future__ import annotations

import io
import stat
import sys
import tarfile
import zipfile
from pathlib import Path
from types import SimpleNamespace

import m1.documents.adapters.archive as archive_adapter
import pytest
from m1.documents.adapters.archive import (
    ArchiveAdapterError,
    ArchiveDependencyError,
    ArchiveLimitError,
    ArchiveLimits,
    UnsafeArchiveError,
    UnsupportedArchiveError,
    detect_archive_type,
    extract_archive,
    parse_archive_document,
    repair_display_filename,
)


def _zip_bytes(files: dict[str, bytes]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for name, content in files.items():
            package.writestr(name, content)
    return output.getvalue()


def test_zip_extracts_unique_leaves_ignores_apple_metadata_and_repairs_display_name(
    tmp_path: Path,
) -> None:
    repaired = "测试订单.xlsx"
    mojibake = repaired.encode("gb18030").decode("cp437")
    assert repair_display_filename(mojibake) == repaired
    source = tmp_path / "orders.zip"
    with zipfile.ZipFile(source, "w", compression=zipfile.ZIP_DEFLATED) as package:
        package.writestr("a.txt", b"same")
        package.writestr("duplicate.txt", b"same")
        package.writestr(mojibake, b"workbook")
        package.writestr("__MACOSX/noise", b"ignored")
        package.writestr("folder/._a.txt", b"ignored")
        package.writestr(".DS_Store", b"ignored")

    result = extract_archive(source, tmp_path / "out")

    assert result.archive_type == "zip"
    assert len(result.leaf_files) == 2
    assert result.duplicate_count == 1
    assert result.ignored_count == 3
    assert all(path.is_file() for path in result.leaf_files)
    repaired_entry = next(entry for entry in result.entries if entry.raw_name == mojibake)
    assert repaired_entry.display_name == repaired
    assert repaired_entry.raw_name == mojibake


def test_nested_archives_are_recursed_and_terminal_files_returned(tmp_path: Path) -> None:
    inner = _zip_bytes({"inner/document.pdf": b"PDF placeholder"})
    source = tmp_path / "outer.zip"
    source.write_bytes(_zip_bytes({"nested.zip": inner, "root.docx": b"DOCX placeholder"}))

    result = extract_archive(source, tmp_path / "out")

    assert sorted(path.name for path in result.leaf_files) == ["document.pdf", "root.docx"]
    nested_entry = next(entry for entry in result.entries if entry.raw_name == "nested.zip")
    assert nested_entry.nested_archive is True
    assert any(entry.depth == 1 for entry in result.entries)


def test_unreadable_nested_archive_is_isolated_from_valid_siblings(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "mixed.zip"
    corrupt_rar = b"Rar!\x1a\x07\x00corrupt"
    source.write_bytes(
        _zip_bytes(
            {
                "orders/good.csv": b"model,quantity\nA,2\n",
                "nested/bad.rar": corrupt_rar,
            }
        )
    )

    def fail_nested_rar(path, root, stage_root, archive_label, depth, budget):
        partial = root / "partial.csv"
        partial.write_bytes(b"partial")
        budget.add_entry()
        budget.reserve_file(7, 7, "partial.csv")
        budget.hashes["partial"] = partial
        raise ArchiveAdapterError("decoder could not read nested member")

    monkeypatch.setitem(archive_adapter._EXTRACTORS, "rar", fail_nested_rar)

    result = extract_archive(source, tmp_path / "out")

    assert [path.name for path in result.leaf_files] == ["good.csv"]
    nested = next(entry for entry in result.entries if entry.raw_name == "nested/bad.rar")
    assert nested.nested_archive is True
    assert nested.ignored is True
    assert nested.ignore_reason == "nested_archive_unreadable:ArchiveAdapterError"
    assert result.total_entries == 2
    assert result.total_uncompressed == len(corrupt_rar) + len(b"model,quantity\nA,2\n")
    assert (tmp_path / "out" / "orders" / "good.csv").is_file()
    assert (tmp_path / "out" / "nested" / "bad.rar").is_file()
    assert not (tmp_path / "out" / "nested" / "bad__contents").exists()


def test_nested_archive_safety_failure_remains_atomic(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "unsafe-nested.zip"
    source.write_bytes(
        _zip_bytes(
            {
                "good.csv": b"model,quantity\nA,2\n",
                "unsafe.rar": b"Rar!\x1a\x07\x00unsafe",
            }
        )
    )

    def fail_unsafe(*_args, **_kwargs):
        raise UnsafeArchiveError("nested traversal")

    monkeypatch.setitem(archive_adapter._EXTRACTORS, "rar", fail_unsafe)

    destination = tmp_path / "out"
    with pytest.raises(UnsafeArchiveError, match="nested traversal"):
        extract_archive(source, destination)
    assert not destination.exists()


def test_zip_based_office_document_is_a_leaf_not_a_recursive_archive(tmp_path: Path) -> None:
    office = _zip_bytes(
        {
            "[Content_Types].xml": b"<Types />",
            "word/document.xml": b"<document />",
        }
    )
    source = tmp_path / "outer.zip"
    source.write_bytes(_zip_bytes({"payload.bin": office}))

    result = extract_archive(source, tmp_path / "out")

    # The enclosing archive member and both OOXML parts share one entry budget.
    assert result.total_entries == 3
    assert len(result.leaf_files) == 1
    assert result.leaf_files[0].name == "payload.bin"


def test_nested_ooxml_expansion_is_charged_to_archive_budget(tmp_path: Path) -> None:
    office = _zip_bytes(
        {
            "[Content_Types].xml": b"<Types />",
            "xl/workbook.xml": b"<workbook />",
            "xl/sharedStrings.xml": b"<sst>" + b"A" * (2 * 1024 * 1024) + b"</sst>",
        }
    )
    source = tmp_path / "outer.zip"
    source.write_bytes(_zip_bytes({"payload.bin": office}))
    destination = tmp_path / "out"

    with pytest.raises(ArchiveLimitError, match="Nested OOXML.*compression ratio"):
        extract_archive(source, destination, ArchiveLimits(max_compression_ratio=100))
    assert not destination.exists()


@pytest.mark.parametrize("member", ["../escape.txt", "folder/../../escape.txt", "..\\escape.txt", "C:/escape.txt"])
def test_zip_slip_is_rejected_atomically(tmp_path: Path, member: str) -> None:
    source = tmp_path / "unsafe.zip"
    source.write_bytes(_zip_bytes({member: b"owned", "safe.txt": b"safe"}))
    destination = tmp_path / "out"

    with pytest.raises(UnsafeArchiveError):
        extract_archive(source, destination)

    assert not (tmp_path / "escape.txt").exists()
    assert not destination.exists()


def test_zip_symlink_is_rejected(tmp_path: Path) -> None:
    source = tmp_path / "link.zip"
    info = zipfile.ZipInfo("link")
    info.create_system = 3
    info.external_attr = (stat.S_IFLNK | 0o777) << 16
    with zipfile.ZipFile(source, "w") as package:
        package.writestr(info, "target")

    with pytest.raises(UnsafeArchiveError, match="Links are forbidden"):
        extract_archive(source, tmp_path / "out")


def test_tar_symlink_is_rejected(tmp_path: Path) -> None:
    source = tmp_path / "link.tar"
    with tarfile.open(source, "w") as package:
        link = tarfile.TarInfo("link")
        link.type = tarfile.SYMTYPE
        link.linkname = "../outside"
        package.addfile(link)

    with pytest.raises(UnsafeArchiveError, match="Links are forbidden"):
        extract_archive(source, tmp_path / "out")


def test_tar_gzip_extracts_regular_file(tmp_path: Path) -> None:
    source = tmp_path / "documents.tar.gz"
    content = b"model,quantity\nA,3\n"
    with tarfile.open(source, "w:gz") as package:
        member = tarfile.TarInfo("nested/order.csv")
        member.size = len(content)
        package.addfile(member, io.BytesIO(content))

    result = extract_archive(source, tmp_path / "out")

    assert result.archive_type == "tar"
    assert len(result.leaf_files) == 1
    assert result.leaf_files[0].read_bytes() == content


def test_single_file_and_compression_ratio_limits(tmp_path: Path) -> None:
    source = tmp_path / "bomb.zip"
    source.write_bytes(_zip_bytes({"large.txt": b"0" * 10_000}))

    with pytest.raises(ArchiveLimitError, match="single-file limit"):
        extract_archive(
            source,
            tmp_path / "single",
            ArchiveLimits(max_single_file=1000),
        )
    with pytest.raises(ArchiveLimitError, match="compression ratio"):
        extract_archive(
            source,
            tmp_path / "ratio",
            ArchiveLimits(max_single_file=20_000, max_compression_ratio=2),
        )


def test_global_entry_and_total_budgets(tmp_path: Path) -> None:
    source = tmp_path / "many.zip"
    source.write_bytes(_zip_bytes({"a": b"1234", "b": b"5678", "c": b"90"}))
    with pytest.raises(ArchiveLimitError, match="entry count"):
        extract_archive(source, tmp_path / "entries", ArchiveLimits(max_entries=2))
    with pytest.raises(ArchiveLimitError, match="uncompressed total"):
        extract_archive(
            source,
            tmp_path / "total",
            ArchiveLimits(max_total_uncompressed=9),
        )


def test_recursive_depth_limit_is_global_and_atomic(tmp_path: Path) -> None:
    nested = _zip_bytes({"leaf.txt": b"leaf"})
    for level in range(3):
        nested = _zip_bytes({f"level-{level}.zip": nested})
    source = tmp_path / "deep.zip"
    source.write_bytes(nested)
    destination = tmp_path / "out"

    with pytest.raises(ArchiveLimitError, match="recursion exceeds depth 2"):
        extract_archive(source, destination)
    assert not destination.exists()


def test_magic_detection_does_not_trust_extension(tmp_path: Path) -> None:
    source = tmp_path / "fake.zip"
    source.write_bytes(b"not an archive")
    with pytest.raises(UnsupportedArchiveError):
        detect_archive_type(source)


@pytest.mark.parametrize(
    "module_name,loader",
    [("rarfile", archive_adapter._require_rarfile), ("py7zr", archive_adapter._require_py7zr)],
)
def test_optional_archive_decoder_reports_explicit_dependency_error(
    monkeypatch: pytest.MonkeyPatch, module_name: str, loader: object
) -> None:
    monkeypatch.setitem(sys.modules, module_name, None)
    with pytest.raises(ArchiveDependencyError):
        loader()  # type: ignore[operator]


def test_archive_facade_preserves_moved_private_symbols_and_monkeypatch_hooks(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    expected = {
        "_Bounded7zWriter",
        "_SevenZipWriterFactory",
        "_extract_rar",
        "_extract_7z",
    }
    assert all(hasattr(archive_adapter, name) for name in expected)
    assert archive_adapter._EXTRACTORS["rar"] is archive_adapter._extract_rar
    assert archive_adapter._EXTRACTORS["7z"] is archive_adapter._extract_7z

    sentinel = RuntimeError("facade loader hook")

    def fail_loader() -> object:
        raise sentinel

    monkeypatch.setattr(archive_adapter, "_require_rarfile", fail_loader)
    with pytest.raises(RuntimeError, match="facade loader hook") as caught:
        archive_adapter._extract_rar(
            tmp_path / "unused.rar",
            tmp_path,
            tmp_path,
            "unused.rar",
            0,
            object(),
        )
    assert caught.value is sentinel


def test_rar_stream_decoder_failure_is_converted_to_archive_error(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    class Info:
        filename = "order.xlsx"
        file_size = 10
        compress_size = 5

        @staticmethod
        def isdir() -> bool:
            return False

        @staticmethod
        def is_symlink() -> bool:
            return False

    class Package:
        @staticmethod
        def infolist() -> list[Info]:
            return [Info()]

        @staticmethod
        def open(_info: Info) -> io.BytesIO:
            return io.BytesIO(b"partial")

        @staticmethod
        def close() -> None:
            return None

    fake_rarfile = SimpleNamespace(RarFile=lambda _path: Package())
    monkeypatch.setattr(archive_adapter, "_require_rarfile", lambda: fake_rarfile)

    def fail_stream(*_args: object, **_kwargs: object) -> None:
        raise RuntimeError("decoder returned a truncated member")

    monkeypatch.setattr(archive_adapter, "_copy_stream", fail_stream)

    with pytest.raises(ArchiveAdapterError, match="RAR decoder could not read"):
        archive_adapter._extract_rar(
            tmp_path / "broken.rar",
            tmp_path / "output",
            tmp_path,
            "broken.rar",
            1,
            archive_adapter._Budget(ArchiveLimits()),
        )


def test_windows_tar_alias_uses_valid_bsdtar_argument_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeToolSetup:
        def __init__(self, setup: dict[str, object]) -> None:
            self.setup = setup

        def check(self) -> bool:
            return True

    config: dict[str, object] = {}
    initial_setup = FakeToolSetup(config)
    fake_rarfile = SimpleNamespace(
        BSDTAR_TOOL="bsdtar",
        BSDTAR_CONFIG=config,
        ToolSetup=FakeToolSetup,
        CURRENT_SETUP=initial_setup,
        tool_setup=lambda: initial_setup,
    )
    monkeypatch.setitem(sys.modules, "rarfile", fake_rarfile)
    monkeypatch.setattr(
        archive_adapter.shutil,
        "which",
        lambda name: None if name == "bsdtar" else "/windows/tar.exe",
    )
    monkeypatch.setattr(
        archive_adapter.subprocess,
        "run",
        lambda *args, **kwargs: SimpleNamespace(
            returncode=0, stdout="bsdtar 3.8.4", stderr=""
        ),
    )

    loaded = archive_adapter._require_rarfile()
    command = loaded.CURRENT_SETUP.open_cmdline(
        None, "sample.rar", "folder\\order.xlsx"
    )

    assert command == [
        "/windows/tar.exe",
        "-x",
        "--to-stdout",
        "-f",
        "sample.rar",
        "folder/order.xlsx",
    ]


def test_archive_document_record_contains_auditable_inventory(tmp_path: Path) -> None:
    source = tmp_path / "one.zip"
    source.write_bytes(_zip_bytes({"order.csv": b"model,quantity\nA,1\n"}))

    record = parse_archive_document(source, destination=tmp_path / "out")

    assert record.schema_version == "m1.document.v2"
    assert record.source.mime_type == "application/zip"
    assert record.document_subtype == "archive"
    assert record.extraction["metadata"]["deduplicated_by"] == "sha256"
    assert record.extraction["raw_content"]["leaf_files"][0].endswith("order.csv")


def test_7z_uses_optional_fixed_decoder_when_available(tmp_path: Path) -> None:
    py7zr = pytest.importorskip("py7zr")
    payload = tmp_path / "payload.txt"
    payload.write_bytes(b"seven zip")
    source = tmp_path / "sample.7z"
    with py7zr.SevenZipFile(source, mode="w") as package:
        package.write(payload, arcname="folder/payload.txt")

    result = extract_archive(source, tmp_path / "out")

    assert result.archive_type == "7z"
    assert len(result.leaf_files) == 1
    assert result.leaf_files[0].read_bytes() == b"seven zip"
