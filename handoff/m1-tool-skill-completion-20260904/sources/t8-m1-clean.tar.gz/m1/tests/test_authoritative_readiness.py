from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient
from m1.api import health_routes
from m1.api.health_routes import register_health_routes


class _Store:
    def __init__(self, *, terminal_failures: int = 0) -> None:
        self.terminal_failures = terminal_failures

    async def projection_outbox_health(self, _tenant_id: str) -> dict[str, object]:
        return {"pending": 0, "terminal_failures": self.terminal_failures}


class _AggregateStore:
    def __init__(self, health_by_tenant: dict[str, dict[str, object] | Exception]):
        self.health_by_tenant = health_by_tenant
        self.calls: list[str] = []

    async def projection_outbox_health(self, tenant_id: str) -> dict[str, object]:
        self.calls.append(tenant_id)
        result = self.health_by_tenant[tenant_id]
        if isinstance(result, Exception):
            raise result
        return dict(result)


class _SlowStore:
    async def projection_outbox_health(self, _tenant_id: str) -> dict[str, object]:
        await asyncio.sleep(1)
        return {"pending": 0, "terminal_failures": 0}


class _Knowledge:
    def __init__(
        self, backend: dict[str, object], *, terminal_failures: int = 0
    ) -> None:
        self.store = _Store(terminal_failures=terminal_failures)
        self._backend = backend

    async def health(self) -> dict[str, object]:
        return self._backend

    def lightrag_status_snapshot(self) -> dict[str, object]:
        return {
            "enabled": True,
            "configured": True,
            "workspace": "m1-shadow",
            "last_success_sync_at": "2026-07-21T08:00:00+00:00",
            "last_success_delete_at": "2026-07-21T08:01:00+00:00",
        }


class _HangingKnowledge(_Knowledge):
    async def health(self) -> dict[str, object]:
        await asyncio.Event().wait()


class _Verifier:
    def __init__(self, status: dict[str, object]) -> None:
        self._status = status

    def status(self) -> dict[str, object]:
        return dict(self._status)


class _Router(_Verifier):
    def status_snapshot(self) -> dict[str, object]:
        return self.status()


class _MinerURunner(_Verifier):
    authority_mode = "full"

    def status(self) -> dict[str, object]:
        return {
            "ready": True,
            "degraded": False,
            "candidate_pipeline": "mineru_instructor",
            **super().status(),
        }


class _Parser(_Verifier):
    def readiness(self) -> dict[str, object]:
        return self.status()


def _client(
    monkeypatch,
    backend: dict[str, object],
    *,
    terminal_failures: int = 0,
    router_status: dict[str, object] | None = None,
    router_init_status: dict[str, object] | None = None,
    router_required: bool = False,
    outbox_store: object | None = None,
    cached_outbox_health: dict[str, object] | None = None,
    outbox_worker_running: bool = True,
    knowledge_override: object | None = None,
    retained_stalled: bool = False,
    mineru_status: dict[str, object] | None = None,
    mineru_enabled: bool = True,
    parser_status: dict[str, object] | None = None,
) -> TestClient:
    monkeypatch.setattr(health_routes.settings, "document_parser_mode", "legacy")
    monkeypatch.setattr(
        health_routes.settings,
        "document_router_enabled",
        router_status is not None,
    )
    monkeypatch.setattr(
        health_routes.settings,
        "document_router_required",
        router_required,
    )
    monkeypatch.setattr(health_routes.settings, "knowledge_enabled", True)
    monkeypatch.setattr(health_routes.settings, "knowledge_required", True)
    monkeypatch.setattr(
        health_routes.settings,
        "mineru_shadow_enabled",
        mineru_enabled,
    )
    monkeypatch.setattr(health_routes.settings, "mineru_shadow_required", True)
    knowledge = knowledge_override or _Knowledge(
        backend, terminal_failures=terminal_failures
    )
    if outbox_store is not None:
        knowledge.store = outbox_store
    if cached_outbox_health is None:
        cached_outbox_health = {
            "pending": 0,
            "oldest_pending_age_seconds": 0.0,
            "terminal_failures": terminal_failures,
            "max_attempts": 0,
            "by_projection": {},
            "tenant_count": 1,
            "status_error_count": 0,
            "health_complete": True,
            "refreshed_at": datetime.now(UTC).isoformat(),
        }
    runtime = SimpleNamespace(
        engine=SimpleNamespace(
            deps=SimpleNamespace(
                mineru_shadow_runner=(
                    _MinerURunner(mineru_status or {}) if mineru_enabled else None
                ),
                document_parser=(
                    _Parser(parser_status) if parser_status is not None else None
                ),
            )
        ),
        knowledge_runtime=knowledge,
        knowledge_init_error="",
        document_routing_runtime=(
            _Router(router_status) if router_status is not None else None
        ),
        _document_routing_status_snapshot=(
            (lambda: dict(router_init_status))
            if router_init_status is not None
            else None
        ),
        _outbox_worker_status={
            "enabled": True,
            "running": outbox_worker_running,
            "retained_count": 1 if retained_stalled else 0,
            "retained_reserved": 200 if retained_stalled else 0,
            "oldest_retained_age_seconds": 61.0 if retained_stalled else 0.0,
            "retained_stalled": retained_stalled,
            "health": cached_outbox_health,
        },
        _OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS=0.01,
        _KNOWLEDGE_HEALTH_TIMEOUT_SECONDS=0.01,
    )
    app = FastAPI()
    register_health_routes(app, runtime)
    return TestClient(app)


def test_ready_fails_when_authoritative_postgres_is_unavailable(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "error",
            "wiki": {
                "status": "error",
                "backend": "postgresql",
                "error": "OSError",
            },
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
    )

    response = client.get("/ready")

    assert response.status_code == 503
    assert response.json()["knowledge"]["ready"] is False


def test_ready_times_out_a_hung_authoritative_health_probe(monkeypatch) -> None:
    backend = {
        "status": "ok",
        "wiki": {"status": "ok", "backend": "postgresql", "error": None},
        "graph": {"status": "ok", "backend": "neo4j"},
        "lightrag_shadow": {"enabled": False, "ready": True},
    }
    client = _client(
        monkeypatch,
        backend,
        knowledge_override=_HangingKnowledge(backend),
    )

    response = client.get("/ready")

    assert response.status_code == 503
    payload = response.json()
    assert payload["knowledge"]["ready"] is False
    assert payload["knowledge"]["error"] == "TimeoutError"


def test_retained_outbox_stall_degrades_readiness_without_tenant_details(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        retained_stalled=True,
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    outbox = payload["knowledge"]["outbox"]
    assert outbox["retained_count"] == 1
    assert outbox["retained_reserved"] == 200
    assert outbox["worker_stalled"] is True
    assert outbox["health_complete"] is False
    assert outbox["status_error"] == "OutboxWorkerRetainedTaskStalled"
    assert "projection_status_incomplete" in payload["degraded_reasons"]


def test_ready_stays_available_when_only_lightrag_is_degraded(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {
                "enabled": True,
                "ready": False,
                "error": "ConnectError",
            },
        },
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    assert payload["knowledge"]["backend"]["lightrag_shadow"]["ready"] is False
    assert payload["degraded"] is True
    assert payload["knowledge"]["degraded_reasons"] == ["lightrag_shadow_unavailable"]


def test_required_degraded_document_router_fails_readiness(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
        router_status={
            "ready": False,
            "degraded": True,
            "circuit_open": True,
            "last_error_type": "TimeoutError",
        },
        router_required=True,
    )

    response = client.get("/ready")

    assert response.status_code == 503
    payload = response.json()
    assert payload["status"] == "not_ready"
    assert payload["document_router"]["ready"] is False
    assert payload["degraded_reasons"] == ["document_router_degraded"]


def test_optional_degraded_document_router_is_visible_without_failing_ready(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
        router_status={
            "ready": False,
            "degraded": True,
            "last_error_type": "ConnectError",
        },
        router_required=False,
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "degraded"
    assert payload["document_router"]["last_error_type"] == "ConnectError"
    assert payload["degraded_reasons"] == ["document_router_degraded"]


def test_optional_router_probe_failure_is_not_hidden_by_empty_runtime_status(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
        router_status={
            "calls": 0,
            "ready": True,
            "degraded": False,
            "last_success_at": None,
            "last_error_type": "",
        },
        router_init_status={
            "enabled": True,
            "ready": False,
            "degraded": True,
            "error_type": "TimeoutError",
        },
        router_required=False,
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "degraded"
    assert payload["document_router"]["ready"] is False
    assert payload["document_router"]["error_type"] == "TimeoutError"
    assert payload["degraded_reasons"] == ["document_router_degraded"]


def test_health_exposes_local_lightrag_lifecycle_without_backend_probe(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
    )

    response = client.get("/health")

    assert response.status_code == 200
    shadow = response.json()["knowledge"]["lightrag_shadow"]
    assert shadow == {
        "enabled": True,
        "configured": True,
        "workspace": "m1-shadow",
        "last_success_sync_at": "2026-07-21T08:00:00+00:00",
        "last_success_delete_at": "2026-07-21T08:01:00+00:00",
    }


def test_ready_exposes_lifecycle_and_terminal_without_hiding_readiness(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {
                "status": "ok",
                "backend": "neo4j",
                "schema_initialized": True,
            },
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
        terminal_failures=2,
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    outbox = payload["knowledge"]["outbox"]
    assert outbox["lifecycle"] == {
        "waiting_last_drain": 0,
        "deadline_seconds": 1800,
        "graph_materialization_deadline_seconds": 120,
    }
    assert outbox["terminal"] == {"count": 2, "present": True}
    assert payload["degraded"] is True
    assert "projection_terminal_failures" in payload["knowledge"]["degraded_reasons"]


def test_ready_fails_when_authoritative_neo4j_schema_initialization_fails(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "error",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {
                "status": "error",
                "backend": "neo4j",
                "error": "Neo4jConfigurationError",
                "schema_initialized": False,
            },
            "lightrag_shadow": {"enabled": True, "ready": True},
        },
    )

    response = client.get("/ready")

    assert response.status_code == 503
    assert response.json()["knowledge"]["ready"] is False


def test_health_aggregates_all_tenants_without_exposing_identifiers(
    monkeypatch,
) -> None:
    store = _AggregateStore(
        {
            "default": RuntimeError("health route must use worker cache"),
        }
    )
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        outbox_store=store,
        cached_outbox_health={
            "pending": 7,
            "oldest_pending_age_seconds": 91.25,
            "terminal_failures": 2,
            "max_attempts": 7,
            "by_projection": {
                "graph": {"pending": 5, "failed": 1},
                "knowledge": {"pending": 2},
            },
            "tenant_count": 2,
            "status_error_count": 0,
            "health_complete": True,
            "refreshed_at": datetime.now(UTC).isoformat(),
        },
    )

    response = client.get("/health")

    assert response.status_code == 200
    outbox = response.json()["knowledge"]["outbox"]
    assert outbox["tenant_count"] == 2
    assert outbox["pending"] == 7
    assert outbox["oldest_pending_age_seconds"] == 91.25
    assert outbox["terminal"] == {"count": 2, "present": True}
    assert outbox["max_attempts"] == 7
    assert outbox["by_projection"] == {
        "graph": {"pending": 5, "failed": 1},
        "knowledge": {"pending": 2},
    }
    assert store.calls == []
    assert "tenant-private" not in response.text


def test_health_isolates_one_tenant_status_failure(monkeypatch) -> None:
    store = _AggregateStore(
        {
            "default": RuntimeError("health route must use worker cache"),
        }
    )
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        outbox_store=store,
        cached_outbox_health={
            "pending": 3,
            "oldest_pending_age_seconds": 5.0,
            "terminal_failures": 0,
            "max_attempts": 0,
            "by_projection": {},
            "tenant_count": 2,
            "status_error_count": 1,
            "status_error": "RuntimeError",
            "health_complete": False,
            "refreshed_at": datetime.now(UTC).isoformat(),
        },
    )

    response = client.get("/health")

    assert response.status_code == 200
    outbox = response.json()["knowledge"]["outbox"]
    assert outbox["tenant_count"] == 2
    assert outbox["pending"] == 3
    assert outbox["status_error_count"] == 1
    assert outbox["status_error"] == "RuntimeError"
    assert store.calls == []
    assert "tenant-private" not in response.text
    assert "must not be exposed" not in response.text


def test_health_without_worker_cache_queries_only_default_tenant(monkeypatch) -> None:
    store = _AggregateStore(
        {
            "default": {
                "pending": 4,
                "oldest_pending_age_seconds": 8.0,
                "terminal_failures": 0,
            },
            "tenant-private": RuntimeError("must not be queried"),
        }
    )
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        outbox_store=store,
        cached_outbox_health={},
    )

    response = client.get("/health")

    assert response.status_code == 200
    assert store.calls == ["default"]
    outbox = response.json()["knowledge"]["outbox"]
    assert outbox["pending"] == 4
    assert outbox["health_complete"] is False


def test_stale_worker_cache_is_fail_closed_and_degraded(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        cached_outbox_health={
            "pending": 0,
            "oldest_pending_age_seconds": 0.0,
            "terminal_failures": 0,
            "max_attempts": 0,
            "by_projection": {},
            "tenant_count": 1,
            "status_error_count": 0,
            "health_complete": True,
            "refreshed_at": "2000-01-01T00:00:00+00:00",
        },
    )

    response = client.get("/ready")

    assert response.status_code == 200
    payload = response.json()
    assert payload["knowledge"]["outbox"]["health_complete"] is False
    assert payload["knowledge"]["outbox"]["health_stale"] is True
    assert "projection_status_incomplete" in payload["degraded_reasons"]


def test_health_fallback_probe_has_a_hard_timeout(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        outbox_store=_SlowStore(),
        cached_outbox_health={},
    )

    response = client.get("/health")

    assert response.status_code == 200
    outbox = response.json()["knowledge"]["outbox"]
    assert outbox["health_complete"] is False
    assert outbox["status_error_count"] == 1
    assert outbox["status_error"] == "TimeoutError"


def test_fresh_cache_cannot_hide_a_stopped_worker(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok", "backend": "postgresql", "error": None},
            "graph": {"status": "ok", "backend": "neo4j"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        outbox_worker_running=False,
    )

    payload = client.get("/health").json()

    assert payload["knowledge"]["outbox"]["worker_stalled"] is True
    assert payload["knowledge"]["outbox"]["health_complete"] is False
    assert "projection_status_incomplete" in payload["degraded_reasons"]


def test_full_authority_mineru_is_an_unconditional_readiness_dependency(
    monkeypatch,
) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok"},
            "graph": {"status": "ok"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        mineru_enabled=False,
    )

    response = client.get("/ready")

    assert response.status_code == 503
    status = response.json()["mineru_shadow"]
    assert status["required"] is True
    assert status["ready"] is False
    assert status["error"] == "not_enabled"


def test_full_authority_readiness_rejects_wrong_candidate_pipeline(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok"},
            "graph": {"status": "ok"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        mineru_status={"candidate_pipeline": "mineru_business_mapper"},
    )

    response = client.get("/ready")

    assert response.status_code == 503
    status = response.json()["mineru_shadow"]
    assert status["authority_contract_ready"] is False
    assert status["error"] == "authority_contract_mismatch"


def test_optional_parser_diagnostics_do_not_gate_full_authority(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok"},
            "graph": {"status": "ok"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        parser_status={"mode": "structured", "ready": False, "backends": {}},
    )

    response = client.get("/ready")

    assert response.status_code == 200
    assert response.json()["document_parser"]["ready"] is False


def test_single_document_failure_degrades_without_removing_traffic(monkeypatch) -> None:
    client = _client(
        monkeypatch,
        {
            "status": "ok",
            "wiki": {"status": "ok"},
            "graph": {"status": "ok"},
            "lightrag_shadow": {"enabled": False, "ready": True},
        },
        mineru_status={
            "ready": True,
            "degraded": True,
            "consecutive_document_system_failures": 1,
            "document_circuit_open": False,
        },
    )

    response = client.get("/ready")

    assert response.status_code == 200
    assert response.json()["status"] == "degraded"
    assert response.json()["mineru_shadow"]["ready"] is True
