from __future__ import annotations

import json
import re
from pathlib import Path


EVIDENCE = (
    Path(__file__).resolve().parents[1]
    / "docs"
    / "evidence"
    / "base-data-acceptance-20260717.json"
)


def test_base_data_acceptance_snapshot_is_private_and_internally_consistent() -> None:
    payload = json.loads(EVIDENCE.read_text(encoding="utf-8"))

    assert payload["schema_version"] == "m1.base_data.acceptance.v1"
    assert payload["scope"] == [2, 4, 5, 6]
    assert payload["privacy"] == {
        "aggregate_only": True,
        "production_filenames_included": False,
        "production_content_included": False,
        "api_keys_included": False,
    }

    catalog = payload["task_2_catalog"]
    assert sum(catalog["candidate_types"].values()) == 304
    assert sum(catalog["document_types"].values()) == 304
    assert catalog["failure_count"] == 0
    assert catalog["sample_count"] == 12

    governance = payload["task_4_governance"]
    assert governance["document_schema"] == "m1.document.v2"
    assert governance["tenant_isolation"] is True
    assert governance["credential_bound_roles"] is True
    assert governance["candidate_review_isolation"] is True

    knowledge = payload["task_5_clean_backfill"]
    assert knowledge["active_task_version_bindings"] == 304
    assert knowledge["document_versions"] == 304
    assert knowledge["candidate_chunks"] == knowledge["candidate_search_documents"]
    assert knowledge["candidate_graph_snapshots"] == 304
    assert knowledge["outbox"]["pending_or_processing"] == 0
    assert knowledge["outbox"]["failed"] == 0
    assert knowledge["candidate_search_probe_hits"] > 0
    assert knowledge["active_search_probe_hits"] == 0
    assert knowledge["neo4j_business_nodes"] == 0
    assert knowledge["neo4j_business_relationships"] == 0

    corpus = payload["task_6_quality"]["deterministic_full_corpus"]
    assert corpus["documents"] == 304
    assert corpus["successful_terminal_documents"] == corpus["documents"]
    assert corpus["schema_v2_documents"] == corpus["documents"]
    assert corpus["documents_with_sha256"] == corpus["documents"]
    assert corpus["documents_with_adapter"] == corpus["documents"]
    assert corpus["failures"] == 0

    semantic = payload["task_6_quality"]["real_semantic_corpus"]
    assert semantic["model"] == "Qwen/Qwen3.6-27B"
    assert semantic["requests"] > 0
    assert semantic["schema_retries"] == 0
    assert semantic["degradations"] == 0

    assert all(
        re.fullmatch(r"[0-9a-f]{64}", digest)
        for digest in payload["artifact_sha256"].values()
    )
    serialized = json.dumps(payload, ensure_ascii=False)
    assert "sk-app" not in serialized
    assert "Authorization" not in serialized
