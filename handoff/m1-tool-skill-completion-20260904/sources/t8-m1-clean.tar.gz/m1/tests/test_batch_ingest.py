from __future__ import annotations

import asyncio
import zipfile
from pathlib import Path

import pytest

from m1.core.config import settings
from m1.ingest.batch import BatchOrchestrator, _child_task_id, refresh_parent_status
from m1.state import TaskState, TaskStatus


class _MemoryStore:
    def __init__(self) -> None:
        self.states: dict[str, TaskState] = {}
        self.documents: dict[str, dict] = {}

    async def save(self, state: TaskState) -> None:
        self.states[state.task_id] = state

    async def load(self, task_id: str) -> TaskState | None:
        return self.states.get(task_id)

    async def list_by_parent(self, parent_id: str) -> list[TaskState]:
        return [state for state in self.states.values() if state.parent_id == parent_id]

    async def save_document(self, task_id: str, document: dict) -> None:
        self.documents[task_id] = document


@pytest.mark.asyncio
@pytest.mark.parametrize("upload_name", ["orders.zip", "orders.bin"])
async def test_disk_backed_batch_expands_archive_without_bytes_payload(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, upload_name: str
) -> None:
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path / "uploads"))
    source = tmp_path / "orders.zip"
    with zipfile.ZipFile(source, "w", compression=zipfile.ZIP_DEFLATED) as package:
        package.writestr("orders/order.csv", "model,quantity\nM-1,2\n")

    store = _MemoryStore()
    spawned: list[TaskState] = []

    async def spawn(state: TaskState, semaphore=None) -> None:
        spawned.append(state)
        state.status = TaskStatus.DONE
        await store.save(state)

    orchestrator = BatchOrchestrator(store, spawn)

    async def finalize(parent: TaskState, child_ids: list[str]) -> None:
        parent.status = TaskStatus.DONE
        parent.processing_stage = "completed"
        await store.save(parent)

    monkeypatch.setattr(orchestrator, "_wait_children_and_finalize", finalize)

    parent = await orchestrator.ingest_paths(
        [(upload_name, source)], parent_filename="production"
    )
    await orchestrator.last_finalize_task

    assert parent.status == TaskStatus.DONE
    assert len(parent.child_ids) == 1
    assert len(spawned) == 1
    assert spawned[0].original_filename == "orders/order.csv"
    assert spawned[0].display_filename == "orders/order.csv"
    assert spawned[0].archive_path == f"{upload_name}!/orders/order.csv"
    assert Path(spawned[0].file_path).read_text(encoding="utf-8").endswith("M-1,2\n")


@pytest.mark.asyncio
async def test_batch_keeps_misnamed_ooxml_as_document_not_archive(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path / "uploads"))
    source = tmp_path / "workbook.bin"
    with zipfile.ZipFile(source, "w") as package:
        package.writestr("[Content_Types].xml", "<Types/>")
        package.writestr("xl/workbook.xml", "<workbook/>")

    store = _MemoryStore()
    spawned: list[TaskState] = []

    async def spawn(state: TaskState, semaphore=None) -> None:
        spawned.append(state)
        state.status = TaskStatus.DONE
        await store.save(state)

    orchestrator = BatchOrchestrator(store, spawn)

    async def finalize(parent: TaskState, child_ids: list[str]) -> None:
        parent.status = TaskStatus.DONE
        await store.save(parent)

    monkeypatch.setattr(orchestrator, "_wait_children_and_finalize", finalize)
    parent = await orchestrator.ingest_paths([("workbook.bin", source)])
    await orchestrator.last_finalize_task

    assert parent.status == TaskStatus.DONE
    assert len(spawned) == 1
    assert spawned[0].original_filename == "workbook.bin"
    assert spawned[0].archive_path == ""


@pytest.mark.asyncio
async def test_batch_rejects_binary_disguised_as_image(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path / "uploads"))
    source = tmp_path / "payload.jpg"
    source.write_bytes(b"not an image")
    store = _MemoryStore()
    spawned: list[TaskState] = []

    async def spawn(state: TaskState, semaphore=None) -> None:
        spawned.append(state)

    orchestrator = BatchOrchestrator(store, spawn)
    parent = await orchestrator.ingest_paths([("payload.jpg", source)])
    await orchestrator.last_finalize_task

    assert spawned == []
    assert parent.status == TaskStatus.FAILED
    assert parent.error == "Batch contains no supported child documents"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("child_statuses", "expected_parent"),
    [
        ([TaskStatus.DONE, TaskStatus.NEEDS_REVIEW], TaskStatus.NEEDS_REVIEW),
        ([TaskStatus.DONE, TaskStatus.FAILED], TaskStatus.FAILED),
    ],
)
async def test_batch_parent_aggregates_review_and_failure_states(
    child_statuses: list[TaskStatus], expected_parent: TaskStatus
) -> None:
    store = _MemoryStore()
    parent = TaskState(task_id="parent", file_type="batch", status=TaskStatus.EXTRACTING)
    await store.save(parent)
    child_ids: list[str] = []
    for index, status in enumerate(child_statuses, 1):
        child = TaskState(
            task_id=f"child-{index}",
            parent_id=parent.task_id,
            original_filename=f"{index}.csv",
            status=status,
        )
        child_ids.append(child.task_id)
        await store.save(child)

    orchestrator = BatchOrchestrator(store, lambda *_args, **_kwargs: None)
    summaries: list[tuple[str, list[str]]] = []

    async def summary(parent_id: str, ids: list[str]) -> None:
        summaries.append((parent_id, ids))

    orchestrator._generate_summary_async = summary  # type: ignore[method-assign]
    await orchestrator._wait_children_and_finalize(parent, child_ids)

    assert parent.status == expected_parent
    assert parent.batch_summary_status == "pending"
    assert summaries == [("parent", child_ids)]


@pytest.mark.asyncio
async def test_batch_parent_deadline_is_not_bypassed_by_hung_registry_task() -> None:
    store = _MemoryStore()
    parent = TaskState(
        task_id="timeout-parent",
        file_type="batch",
        status=TaskStatus.EXTRACTING,
    )
    child = TaskState(
        task_id="hung-child",
        parent_id=parent.task_id,
        status=TaskStatus.EXTRACTING,
    )
    await store.save(parent)
    await store.save(child)
    hung = asyncio.create_task(asyncio.Event().wait())
    try:
        orchestrator = BatchOrchestrator(
            store,
            lambda *_args, **_kwargs: None,
            task_registry={child.task_id: hung},
            child_wait_timeout=0.02,
            poll_interval=0.005,
        )
        await orchestrator._wait_children_and_finalize(parent, [child.task_id])
        assert parent.status == TaskStatus.FAILED
        assert parent.error == "Timed out waiting for persisted batch children"
    finally:
        hung.cancel()
        await asyncio.gather(hung, return_exceptions=True)


@pytest.mark.asyncio
async def test_batch_resume_reuses_persisted_children_without_duplicate_spawn() -> None:
    store = _MemoryStore()
    parent = TaskState(
        task_id="resume-parent",
        file_type="batch",
        status=TaskStatus.EXTRACTING,
        folder_path="",
        batch_inputs=[{"filename": "would-be-duplicate.csv", "path": "missing"}],
    )
    child = TaskState(
        task_id="existing-child",
        parent_id=parent.task_id,
        original_filename="existing.csv",
        status=TaskStatus.DONE,
    )
    parent.child_ids = [child.task_id]
    await store.save(parent)
    await store.save(child)
    spawned: list[TaskState] = []

    async def spawn(state: TaskState, semaphore=None) -> None:
        spawned.append(state)

    orchestrator = BatchOrchestrator(store, spawn)
    summaries: list[str] = []

    async def summary(parent_id: str, ids: list[str]) -> None:
        summaries.append(parent_id)

    orchestrator._generate_summary_async = summary  # type: ignore[method-assign]
    await orchestrator.resume(parent)

    assert spawned == []
    assert parent.child_ids == ["existing-child"]
    assert parent.status == TaskStatus.DONE
    assert summaries == ["resume-parent"]


@pytest.mark.asyncio
async def test_batch_resume_replays_incomplete_fanout_without_duplicates(
    tmp_path: Path,
) -> None:
    first = tmp_path / "first.csv"
    second = tmp_path / "second.csv"
    first.write_text("model,quantity\nA,1\n", encoding="utf-8")
    second.write_text("model,quantity\nB,2\n", encoding="utf-8")
    store = _MemoryStore()
    parent = TaskState(
        task_id="partial-parent",
        file_type="batch",
        status=TaskStatus.EXTRACTING,
        processing_stage="batch_expanding",
        folder_path=str(tmp_path / "parent"),
        batch_inputs=[
            {"filename": "first.csv", "path": str(first)},
            {"filename": "second.csv", "path": str(second)},
        ],
        batch_fanout_complete=False,
    )
    first_id = _child_task_id(parent.task_id, first)
    existing = TaskState(
        task_id=first_id,
        parent_id=parent.task_id,
        file_path=str(first),
        original_filename="first.csv",
        status=TaskStatus.DONE,
    )
    await store.save(parent)
    await store.save(existing)
    spawned: list[str] = []

    async def spawn(state: TaskState, semaphore=None) -> None:
        spawned.append(state.original_filename)
        state.status = TaskStatus.DONE
        await store.save(state)

    orchestrator = BatchOrchestrator(store, spawn)

    async def no_summary(parent_id: str, ids: list[str]) -> None:
        return None

    orchestrator._generate_summary_async = no_summary  # type: ignore[method-assign]
    await orchestrator.resume(parent)

    assert spawned == ["second.csv"]
    assert len(parent.child_ids) == 2
    assert first_id in parent.child_ids
    assert parent.batch_fanout_complete is True
    assert parent.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_terminal_batch_resume_finishes_pending_summary() -> None:
    store = _MemoryStore()
    parent = TaskState(
        task_id="summary-parent",
        file_type="batch",
        status=TaskStatus.DONE,
        batch_fanout_complete=True,
        batch_summary_status="pending",
        child_ids=["summary-child"],
    )
    child = TaskState(
        task_id="summary-child",
        parent_id=parent.task_id,
        status=TaskStatus.DONE,
    )
    await store.save(parent)
    await store.save(child)
    orchestrator = BatchOrchestrator(store, lambda *_args, **_kwargs: None)
    summarized: list[list[str]] = []

    async def summary(parent_id: str, ids: list[str]) -> None:
        summarized.append(ids)

    orchestrator._generate_summary_async = summary  # type: ignore[method-assign]
    await orchestrator.resume(parent)

    assert summarized == [["summary-child"]]
    assert parent.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_terminal_timeout_parent_is_reaggregated_from_successful_children() -> None:
    store = _MemoryStore()
    parent = TaskState(
        task_id="stale-timeout-parent",
        file_type="batch",
        status=TaskStatus.FAILED,
        processing_stage="failed",
        error="Timed out waiting for persisted batch children",
        batch_fanout_complete=True,
        batch_summary_status="pending",
        child_ids=["review-child"],
    )
    child = TaskState(
        task_id="review-child",
        parent_id=parent.task_id,
        original_filename="review.csv",
        status=TaskStatus.NEEDS_REVIEW,
    )
    await store.save(parent)
    await store.save(child)
    orchestrator = BatchOrchestrator(store, lambda *_args, **_kwargs: None)

    async def summary(parent_id: str, ids: list[str]) -> None:
        return None

    orchestrator._generate_summary_async = summary  # type: ignore[method-assign]
    await orchestrator.resume(parent)

    assert parent.status == TaskStatus.NEEDS_REVIEW
    assert parent.processing_stage == "needs_review"
    assert parent.error is None


@pytest.mark.asyncio
async def test_refresh_parent_status_after_child_review(monkeypatch: pytest.MonkeyPatch) -> None:
    store = _MemoryStore()
    parent = TaskState(task_id="review-parent", file_type="batch", status=TaskStatus.EXTRACTING)
    child = TaskState(
        task_id="review-child",
        parent_id=parent.task_id,
        original_filename="review.csv",
        status=TaskStatus.NEEDS_REVIEW,
    )
    parent.child_ids = [child.task_id]
    await store.save(parent)
    await store.save(child)

    async def no_summary(self, parent_id: str, child_ids: list[str]) -> None:
        return None

    monkeypatch.setattr(BatchOrchestrator, "_generate_summary_async", no_summary)
    refreshed = await refresh_parent_status(store, parent.task_id)
    assert refreshed is not None
    assert refreshed.status == TaskStatus.NEEDS_REVIEW

    child.status = TaskStatus.DONE
    await store.save(child)
    refreshed = await refresh_parent_status(store, parent.task_id)
    assert refreshed is not None
    assert refreshed.status == TaskStatus.DONE


@pytest.mark.asyncio
async def test_refresh_parent_unions_persisted_children(monkeypatch: pytest.MonkeyPatch) -> None:
    store = _MemoryStore()
    parent = TaskState(
        task_id="union-parent",
        file_type="batch",
        status=TaskStatus.EXTRACTING,
        child_ids=["known-child"],
    )
    known = TaskState(
        task_id="known-child",
        parent_id=parent.task_id,
        status=TaskStatus.DONE,
    )
    late = TaskState(
        task_id="late-child",
        parent_id=parent.task_id,
        status=TaskStatus.FAILED,
    )
    for state in (parent, known, late):
        await store.save(state)

    async def no_summary(self, parent_id: str, child_ids: list[str]) -> None:
        return None

    monkeypatch.setattr(BatchOrchestrator, "_generate_summary_async", no_summary)
    refreshed = await refresh_parent_status(store, parent.task_id)
    assert refreshed is not None
    assert refreshed.child_ids == ["known-child", "late-child"]
    assert refreshed.status == TaskStatus.FAILED


@pytest.mark.asyncio
async def test_batch_orchestrator_preserves_inherited_private_monkeypatch_hooks(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[str, list[str]]] = []

    async def replacement(self, parent_id: str, child_ids: list[str]) -> None:
        calls.append((parent_id, child_ids))

    assert hasattr(BatchOrchestrator, "_generate_summary_async")
    monkeypatch.setattr(BatchOrchestrator, "_generate_summary_async", replacement)
    orchestrator = object.__new__(BatchOrchestrator)
    await orchestrator._generate_summary_async("parent", ["child"])
    assert calls == [("parent", ["child"])]
