from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

SCRIPT_PATH = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "benchmark_document_extractor.py"
)
SPEC = importlib.util.spec_from_file_location(
    "benchmark_document_extractor_semantic_gold_tests",
    SCRIPT_PATH,
)
assert SPEC is not None and SPEC.loader is not None
benchmark = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = benchmark
SPEC.loader.exec_module(benchmark)


def test_files_excludes_generated_m1_assets_but_keeps_source_images(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source.docx"
    source.write_bytes(b"source")
    source_image = tmp_path / "source.png"
    source_image.write_bytes(b"source image")
    generated = tmp_path / ".m1_assets" / "docx-images" / "derived.png"
    generated.parent.mkdir(parents=True)
    generated.write_bytes(b"derived image")

    discovered = list(benchmark._files(tmp_path))

    assert discovered == [source, source_image]
    assert generated not in discovered


def test_no_default_samples_selects_only_explicit_samples(tmp_path: Path) -> None:
    explicit = tmp_path / "explicit.xlsx"
    explicit.write_bytes(b"explicit")
    empty_root = tmp_path / "empty"
    empty_root.mkdir()
    args = benchmark._parser().parse_args(
        [
            "--no-default-samples",
            "--sample",
            str(explicit),
            "--production-root",
            str(empty_root),
            "--expanded-root",
            str(empty_root),
            "--limit",
            "1",
        ]
    )

    cases, issues, discovered = benchmark._discover(args)

    assert [case.path for case in cases] == [explicit.resolve()]
    assert [case.source_kind for case in cases] == ["named"]
    assert issues == []
    assert discovered == 1


def test_candidate_replay_validates_source_and_uses_reported_timing(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source.pdf"
    source.write_bytes(b"source")
    sha256 = benchmark._digest(source)
    case = benchmark.Case(
        id=f"pdf-{sha256[:12]}",
        path=source,
        sha256=sha256,
        category="pdf",
        source_kind="production",
        size_bytes=source.stat().st_size,
    )
    replay = tmp_path / "replay"
    replay.mkdir()
    payload = {
        "record": {
            "source": {"sha256": sha256},
            "header": {},
            "lines": [],
        },
        "timing": {"total_ms": 123.456},
    }
    replay_path = replay / f"{case.id}.json"
    replay_path.write_text(json.dumps(payload), encoding="utf-8")

    output, status = benchmark._run_candidate(
        case,
        SimpleNamespace(candidate_replay_dir=replay),
        tmp_path,
    )

    assert output is not None
    assert output.record["source"]["sha256"] == sha256
    assert status == {
        "status": "completed",
        "output_source": "replay",
        "elapsed_ms": 123.456,
    }

    payload["record"]["source"]["sha256"] = "0" * 64
    replay_path.write_text(json.dumps(payload), encoding="utf-8")
    rejected, rejected_status = benchmark._run_candidate(
        case,
        SimpleNamespace(candidate_replay_dir=replay),
        tmp_path,
    )
    assert rejected is None
    assert rejected_status["error_type"] == "CandidateReplayInvalid:ValueError"


def _candidate() -> tuple[dict, dict]:
    record = {
        "header": {
            "contract_number": "PO-1",
            "field_supplier": "Acme Cable",
        },
        "lines": [
            {"field_name": "Cable A", "field_quantity": "10"},
            {"field_name": "Cable B", "field_quantity": "20"},
        ],
        "field_meta": {
            "$.header.contract_number": {
                "source_refs": [{"page": 1, "part": "p1:b0"}]
            },
            "$.header.field_supplier": {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "spreadsheet/Sheet1/A1",
                        "sheet": "Sheet1",
                        "cell": "A1",
                    }
                ]
            },
            "$.lines[0].field_name": {
                "source_refs": [{"sheet": "Sheet1", "cell": "A2"}]
            },
            "$.lines[0].field_quantity": {
                "source_refs": [{"sheet": "Sheet1", "cell": "B2"}]
            },
            "$.lines[1].field_name": {
                "source_refs": [{"sheet": "Sheet1", "cell": "A3"}]
            },
            "$.lines[1].field_quantity": {
                "source_refs": [{"sheet": "Sheet1", "cell": "B3"}]
            },
        },
        "extraction": {
            "metadata": {"document_intent": "purchase_contract"},
            "raw_content": {
                "evidence_dispositions": {
                    "raw_content": [
                        {"quote": "raw text must not count as a semantic match"}
                    ],
                    "content_model_bound": [],
                }
            },
        },
    }
    payload = {
        "record": record,
        "projection": {
            "field_names": {
                "$.header.contract_number": "contract_number",
                "$.header.field_supplier": "supplier",
                "$.lines[0].field_name": "产品名称",
                "$.lines[0].field_quantity": "数量",
                "$.lines[1].field_name": "产品名称",
                "$.lines[1].field_quantity": "数量",
            }
        },
        "result": {
            "document_intent": "purchase_contract",
            "content_units": [
                {
                    "evidence_id": "docx:p:1",
                    "content_kind": "manufacturing_process",
                    "label": "process_steps",
                    "exact_text": "素材 -> 切割 -> 包装 -> 出货",
                    "binding_source": "model",
                },
                {
                    "evidence_id": "pdf:p1:clause:1",
                    "content_kind": "contract_clause",
                    "label": "clause_1",
                    "exact_text": "一、质量要求",
                    "binding_source": "model",
                },
                {
                    "evidence_id": "pdf:p1:clause:2",
                    "content_kind": "contract_clause",
                    "label": "clause_2",
                    "exact_text": "二、交付要求",
                    "binding_source": "model",
                },
            ],
        },
    }
    return record, payload


def _provisional_gold() -> dict:
    rows = [
        {"产品名称": "Cable A", "数量": 10},
        {"产品名称": "Cable B", "数量": 20},
    ]
    return {
        "expected": {
            "intent_family": "purchase_order",
            "document_subtype": "purchase_contract",
            "record_count": 2,
            "record_count_semantics": "two source-backed detail rows",
            "key_values": {
                "contract_number": "PO-1",
                "delivery_date": None,
            },
            "header_fields": {
                "supplier": {
                    "value": "Acme Cable",
                    "source_cell": "Sheet1!A1",
                }
            },
            "detail_columns": ["产品名称", "数量"],
            "field_names": ["产品名称", "数量"],
            "records": rows,
            "line_items": rows,
            "process_sequence": ["素材", "切割", "包装", "出货"],
            "purchase_contract_clause_count": 2,
        }
    }


def _semantic_completeness_audit() -> dict:
    return {
        "schema_version": "m1.semantic-completion.v1",
        "counts": {
            "evidence_total": 10,
            "source_evidence_total": 8,
            "supplemental_evidence_total": 2,
            "evidence_accounted": 10,
            "evidence_structured": 6,
            "evidence_schema": 1,
            "evidence_redundant": 1,
            "evidence_non_semantic": 0,
            "evidence_ambiguous": 1,
            "evidence_needs_review": 1,
            "evidence_verified": 3,
            "evidence_advisory": 3,
            "source_evidence_structured": 4,
            "source_evidence_schema": 1,
            "source_evidence_redundant": 1,
            "source_evidence_non_semantic": 0,
            "source_evidence_ambiguous": 1,
            "source_evidence_needs_review": 1,
            "source_evidence_verified": 3,
            "source_evidence_advisory": 1,
            "supplemental_evidence_structured": 2,
            "supplemental_evidence_schema": 0,
            "supplemental_evidence_redundant": 0,
            "supplemental_evidence_non_semantic": 0,
            "supplemental_evidence_ambiguous": 0,
            "supplemental_evidence_needs_review": 0,
            "supplemental_evidence_verified": 0,
            "supplemental_evidence_advisory": 2,
            "facts_total": 3,
            "facts_verified": 1,
            "facts_ambiguous": 1,
            "facts_advisory": 1,
            "source_facts_verified": 1,
            "source_facts_ambiguous": 1,
            "source_facts_advisory": 1,
            "supplemental_facts_verified": 0,
            "supplemental_facts_ambiguous": 0,
            "supplemental_facts_advisory": 0,
        },
        "ratios": {
            "audit_completeness": 1.0,
            "source_semantically_verified": 0.375,
            "source_structured": 0.375,
            "source_requiring_review": 0.25,
            "evidence_accounting": 1.0,
            "audited_structured": 0.375,
            "audited_requiring_review": 0.25,
        },
        "review_required": True,
    }


def test_provisional_semantic_gold_consumes_and_scores_every_supported_key() -> None:
    record, payload = _candidate()

    score = benchmark._score_gold(record, _provisional_gold(), payload=payload)

    semantic = score["semantic_gold"]
    assert score["status"] == "labeled"
    assert semantic["matched"] == semantic["total"]
    assert semantic["accuracy"] == 1.0
    assert semantic["unmatched_annotations"] == []
    assert semantic["unconsumed_annotation_keys"] == []
    assert semantic["annotation_errors"] == []
    assert set(semantic["consumed_annotation_keys"]) == {
        "detail_columns",
        "document_subtype",
        "field_names",
        "header_fields",
        "intent_family",
        "key_values",
        "line_items",
        "process_sequence",
        "purchase_contract_clause_count",
        "record_count",
        "record_count_semantics",
        "records",
    }
    assert score["fields"]["total"] == 0

    aggregate = benchmark._aggregate(
        [
            {
                "category": "pdf",
                "candidate": {"status": "completed", "elapsed_ms": 1.0},
                "source_coverage": {},
                "candidate_overview": {},
                "gold": score,
            }
        ]
    )
    assert aggregate["gold_semantic"]["accuracy"] == 1.0
    assert aggregate["gold_semantic"]["scored_cases"] == 1
    assert aggregate["gold_semantic"]["unconsumed_annotation_keys"] == {}


def test_semantic_completion_is_metrics_only_and_does_not_change_gold() -> None:
    record, payload = _candidate()
    record["extraction"]["raw_content"]["pages"] = []
    legacy_record = copy.deepcopy(record)
    baseline_score = benchmark._score_gold(
        record,
        _provisional_gold(),
        payload=payload,
    )
    baseline_overview = benchmark._overview(legacy_record)
    advisory_bogus_order_number = {
        "fact_id": "semantic_fact:" + "f" * 64,
        "name": "order_number",
        "value": "WRONG-ORDER-NUMBER",
        "unit": None,
        "subject": None,
        "relation": None,
        "attributes": {"source": "filename"},
        "evidence_refs": [
            {
                "evidence_id": "source.filename",
                "quote": "WRONG-ORDER-NUMBER.pdf",
                "source_ref": {"part": "source/filename"},
            }
        ],
        "extractor": "filename_token_candidates",
        "confidence": 0.5,
        "status": "advisory",
    }
    raw = record["extraction"]["raw_content"]
    raw["semantic_facts"] = [advisory_bogus_order_number]
    raw["semantic_evidence_dispositions"] = []
    raw["semantic_completeness_audit"] = _semantic_completeness_audit()
    payload["result"]["semantic_facts"] = [advisory_bogus_order_number]
    payload["result"]["semantic_completeness_audit"] = (
        _semantic_completeness_audit()
    )

    enriched_score = benchmark._score_gold(
        record,
        _provisional_gold(),
        payload=payload,
    )

    assert enriched_score == baseline_score
    overview = benchmark._overview(record)
    assert overview["semantic_completion_available"] is True
    assert overview["semantic_completion_schema_version"] == (
        "m1.semantic-completion.v1"
    )
    assert overview["semantic_completion_review_required"] is True
    assert overview["semantic_completion_evidence_total"] == 10
    assert overview["semantic_completion_source_evidence_total"] == 8
    assert overview["semantic_completion_supplemental_evidence_total"] == 2
    assert overview["semantic_completion_source_evidence_verified"] == 3
    assert overview["semantic_completion_source_evidence_advisory"] == 1
    assert overview["semantic_completion_supplemental_evidence_verified"] == 0
    assert overview["semantic_completion_supplemental_evidence_advisory"] == 2
    assert overview["semantic_completion_source_facts_verified"] == 1
    assert overview["semantic_completion_supplemental_facts_advisory"] == 0
    assert overview["semantic_completion_facts_advisory"] == 1
    assert overview["semantic_completion_audit_completeness_ratio"] == 1.0
    assert overview["semantic_completion_source_semantically_verified_ratio"] == (
        0.375
    )
    assert overview["semantic_completion_source_structured_ratio"] == 0.375
    assert overview["semantic_completion_source_requiring_review_ratio"] == 0.25
    assert overview["semantic_completion_audited_structured_ratio"] == 0.375
    assert overview["semantic_completion_audited_requiring_review_ratio"] == 0.25

    baseline_aggregate = benchmark._aggregate(
        [
            {
                "category": "pdf",
                "candidate": {"status": "completed", "elapsed_ms": 1.0},
                "source_coverage": {},
                "candidate_overview": baseline_overview,
                "gold": baseline_score,
            }
        ]
    )
    enriched_aggregate = benchmark._aggregate(
        [
            {
                "category": "pdf",
                "candidate": {"status": "completed", "elapsed_ms": 1.0},
                "source_coverage": {},
                "candidate_overview": overview,
                "gold": enriched_score,
            }
        ]
    )
    assert enriched_aggregate["gold_semantic"] == baseline_aggregate[
        "gold_semantic"
    ]
    assert enriched_aggregate["raw_evidence"] == baseline_aggregate[
        "raw_evidence"
    ]
    assert enriched_aggregate["content_semantics"] == baseline_aggregate[
        "content_semantics"
    ]
    assert enriched_aggregate["semantic_completion"] == {
        "available_cases": 1,
        "review_required_cases": 1,
        "evidence_total": 10,
        "source_evidence_total": 8,
        "supplemental_evidence_total": 2,
        "evidence_accounted": 10,
        "evidence_structured": 6,
        "evidence_schema": 1,
        "evidence_redundant": 1,
        "evidence_non_semantic": 0,
        "evidence_ambiguous": 1,
        "evidence_needs_review": 1,
        "evidence_verified": 3,
        "evidence_advisory": 3,
        "source_evidence_structured": 4,
        "source_evidence_schema": 1,
        "source_evidence_redundant": 1,
        "source_evidence_non_semantic": 0,
        "source_evidence_ambiguous": 1,
        "source_evidence_needs_review": 1,
        "source_evidence_verified": 3,
        "source_evidence_advisory": 1,
        "supplemental_evidence_structured": 2,
        "supplemental_evidence_schema": 0,
        "supplemental_evidence_redundant": 0,
        "supplemental_evidence_non_semantic": 0,
        "supplemental_evidence_ambiguous": 0,
        "supplemental_evidence_needs_review": 0,
        "supplemental_evidence_verified": 0,
        "supplemental_evidence_advisory": 2,
        "facts_total": 3,
        "facts_verified": 1,
        "facts_ambiguous": 1,
        "facts_advisory": 1,
        "source_facts_verified": 1,
        "source_facts_ambiguous": 1,
        "source_facts_advisory": 1,
        "supplemental_facts_verified": 0,
        "supplemental_facts_ambiguous": 0,
        "supplemental_facts_advisory": 0,
        "accounted_complete_cases": 1,
        "unavailable_cases": 0,
        "audit_completeness_ratio": 1.0,
        "source_semantically_verified_ratio": 0.375,
        "source_structured_ratio": 0.375,
        "source_requiring_review_ratio": 0.25,
        "fact_status_verified_ratio": pytest.approx(1 / 3),
        "semantic_fact_accuracy_evaluated": False,
        "semantic_fact_accuracy": None,
        "semantic_fact_accuracy_evaluation_reason": (
            "semantic_facts_not_annotated_in_gold"
        ),
        "deprecated_compatibility_fields": {
            "evidence_accounting_ratio": "audit_completeness_ratio",
            "evidence_structured_ratio": "source_structured_ratio",
            "evidence_requiring_review_ratio": "source_requiring_review_ratio",
            "fact_verified_ratio": "fact_status_verified_ratio",
        },
        "evidence_accounting_ratio": 1.0,
        "evidence_structured_ratio": 0.375,
        "evidence_requiring_review_ratio": 0.25,
        "fact_verified_ratio": pytest.approx(1 / 3),
    }


def test_raw_and_fallback_content_cannot_satisfy_semantic_gold() -> None:
    record = {
        "header": {},
        "lines": [],
        "field_meta": {},
        "extraction": {
            "metadata": {"document_intent": "technical_document"},
            "raw_content": {
                "evidence_dispositions": {
                    "raw_content": [
                        {"quote": "素材 切割 包装 出货 一、质量要求"}
                    ],
                    "content_local_fallback": [
                        {
                            "evidence_id": "docx:p:1",
                            "content_kind": "manufacturing_process",
                            "label": "process_steps",
                            "exact_text": "素材 切割 包装 出货",
                            "binding_source": "local_fallback",
                        }
                    ],
                }
            },
        },
    }
    payload = {
        "record": record,
        "result": {
            "document_intent": "technical_document",
            "content_units": [
                {
                    "evidence_id": "docx:p:1",
                    "content_kind": "manufacturing_process",
                    "label": "process_steps",
                    "exact_text": "素材 切割 包装 出货",
                    "binding_source": "local_fallback",
                }
            ],
        },
    }
    gold = {
        "expected": {
            "process_sequence": ["素材", "切割", "包装", "出货"],
            "purchase_contract_clause_count": 1,
        }
    }

    semantic = benchmark._score_gold(record, gold, payload=payload)[
        "semantic_gold"
    ]

    assert semantic["matched"] == 0
    assert semantic["total"] == 2
    assert semantic["unmatched_annotations"] == [
        "process_sequence",
        "purchase_contract_clause_count",
    ]


def test_line_field_order_survives_sorted_json_object_keys() -> None:
    record, payload = _candidate()
    record["extraction"]["line_field_order"] = ["数量", "产品名称"]
    payload["record"] = record
    sorted_payload = json.loads(
        json.dumps(payload, ensure_ascii=False, sort_keys=True)
    )
    sorted_record = sorted_payload["record"]
    gold = {"expected": {"field_names": ["数量", "产品名称"]}}

    semantic = benchmark._score_gold(
        sorted_record,
        gold,
        payload=sorted_payload,
    )["semantic_gold"]

    assert semantic["matched"] == semantic["total"] == 3


def test_explicit_line_field_order_keeps_source_backed_schema_only_column() -> None:
    record = {
        "lines": [{"sequence": "1", "model": "A-100"}],
        "field_meta": {
            "$.lines[0].sequence": {
                "source_refs": [{"sheet": "Sheet1", "cell": "A2"}]
            },
            "$.lines[0].model": {
                "source_refs": [{"sheet": "Sheet1", "cell": "C2"}]
            },
        },
        "extraction": {
            "line_field_order": ["序号", "产品图片", "型号"],
            "raw_content": {
                "evidence_dispositions": {
                    "schema_label": [
                        {
                            "quote": "产品图片",
                            "source_ref": {"sheet": "Sheet1", "cell": "B1"},
                        }
                    ]
                }
            },
        },
    }
    payload = {
        "record": record,
        "projection": {
            "field_names": {
                "$.lines[0].sequence": "序号",
                "$.lines[0].model": "型号",
            }
        },
    }
    gold = {"expected": {"detail_columns": ["序号", "产品图片", "型号"]}}

    semantic = benchmark._score_gold(record, gold, payload=payload)["semantic_gold"]

    assert semantic["matched"] == semantic["total"] == 4


def test_record_set_schema_only_column_still_requires_actual_occurrence() -> None:
    record = {
        "lines": [{"sequence": "1", "model": "A-100"}],
        "extraction": {
            "record_sets": [
                {
                    "role": "primary_business_records",
                    "records": [
                        {
                            "fields": [
                                {"name": "序号", "value": "1"},
                                {"name": "产品图片", "value": None},
                                {"name": "型号", "value": "A-100"},
                            ]
                        }
                    ],
                }
            ],
            "raw_content": {
                "evidence_dispositions": {
                    "schema_label": [{"quote": "产品图片"}]
                }
            },
        },
    }
    payload = {
        "record": record,
        "projection": {
            "field_names": {
                "$.lines[0].sequence": "序号",
                "$.lines[0].model": "型号",
            }
        },
    }
    gold = {"expected": {"detail_columns": ["序号", "产品图片", "型号"]}}

    semantic = benchmark._score_gold(record, gold, payload=payload)["semantic_gold"]

    assert semantic["matched"] == 2
    assert semantic["total"] == 4
    assert semantic["unmatched_annotations"] == [
        "detail_columns[1]",
        "detail_columns.__order__",
    ]


def test_legacy_line_field_order_uses_source_column_coordinates() -> None:
    occurrences = [
        benchmark._SemanticOccurrence(
            name="内径尺寸",
            value="18mm",
            path="$.lines[0].a_inner",
            scope="line",
            source_refs=({"part": "mineru/docx:t:0/r1/c2"},),
        ),
        benchmark._SemanticOccurrence(
            name="产品名称",
            value="铝壳",
            path="$.lines[0].z_name",
            scope="line",
            source_refs=({"part": "mineru/docx:t:0/r1/c0"},),
        ),
        benchmark._SemanticOccurrence(
            name="外径尺寸",
            value="20mm",
            path="$.lines[0].m_outer",
            scope="line",
            source_refs=({"part": "mineru/docx:t:0/r1/c1"},),
        ),
    ]

    assert benchmark._line_semantic_names(occurrences, {}) == [
        "产品名称",
        "外径尺寸",
        "内径尺寸",
    ]


def test_unknown_and_nested_annotation_keys_are_reported_unconsumed() -> None:
    record, payload = _candidate()
    gold = {
        "expected": {
            "header_fields": {
                "supplier": {
                    "value": "Acme Cable",
                    "source_cell": "Sheet1!A1",
                    "unsupported_hint": "must not be ignored",
                }
            },
            "future_annotation": {"enabled": True},
        }
    }

    semantic = benchmark._score_gold(record, gold, payload=payload)[
        "semantic_gold"
    ]

    assert semantic["unconsumed_annotation_keys"] == [
        "future_annotation",
        "header_fields.supplier.unsupported_hint",
    ]


def test_json_path_key_values_remain_legacy_field_assertions() -> None:
    record, payload = _candidate()

    score = benchmark._score_gold(
        record,
        {"expected": {"key_values": {"$.header.contract_number": "PO-1"}}},
        payload=payload,
    )

    assert score["fields"] == {
        "matched": 1,
        "total": 1,
        "accuracy": 1.0,
        "unmatched_paths": [],
    }
    assert score["semantic_gold"]["total"] == 0
    assert score["semantic_gold"]["unconsumed_annotation_keys"] == []


def test_strict_gold_requires_loaded_sha_matched_and_consumed_cases() -> None:
    record, payload = _candidate()
    gold_case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        **_provisional_gold(),
    }
    score = benchmark._score_gold(record, gold_case, payload=payload)
    score["matched_by"] = "sha256"
    case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        "candidate": {"status": "completed"},
        "gold": score,
    }

    passed = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": [gold_case]},
        cases=[case],
    )

    assert passed == {
        "enabled": True,
        "passed": True,
        "failure_count": 0,
        "failures": [],
    }

    not_configured = benchmark._strict_gold_summary(
        enabled=True,
        configured=False,
        gold=None,
        cases=[],
    )
    assert [failure["code"] for failure in not_configured["failures"]] == [
        "GOLD_NOT_CONFIGURED"
    ]

    not_loaded = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold=None,
        cases=[],
    )
    assert [failure["code"] for failure in not_loaded["failures"]] == [
        "GOLD_NOT_LOADED"
    ]

    missing = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": []},
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {"status": "completed"},
                "gold": {
                    "status": "no_matching_gold",
                    "matched_by": None,
                },
            }
        ],
    )
    assert {failure["code"] for failure in missing["failures"]} == {
        "GOLD_CASES_EMPTY",
        "SELECTED_CASE_MISSING_GOLD"
    }

    unconsumed_score = benchmark._score_gold(
        record,
        {"expected": {"future_annotation": True}},
        payload=payload,
    )
    unconsumed_score["matched_by"] = "sha256"
    unconsumed = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={
            "cases": [
                {
                    "id": "pdf-a",
                    "sha256": "a" * 64,
                    "expected": {"future_annotation": True},
                }
            ]
        },
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {"status": "completed"},
                "gold": unconsumed_score,
            }
        ],
    )
    assert {failure["code"] for failure in unconsumed["failures"]} == {
        "GOLD_ANNOTATION_KEYS_UNCONSUMED",
        "GOLD_CASE_WITHOUT_ASSERTIONS",
    }


def test_strict_gold_rejects_any_semantic_mismatch_with_actionable_details() -> None:
    record, payload = _candidate()
    gold_case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        "expected": {
            "intent_family": "technical_document",
            "record_count": 2,
        },
    }
    score = benchmark._score_gold(record, gold_case, payload=payload)
    score["matched_by"] = "sha256"

    strict = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": [gold_case]},
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {"status": "completed"},
                "gold": score,
            }
        ],
    )

    assert strict["passed"] is False
    assert strict["failures"] == [
        {
            "code": "SEMANTIC_GOLD_MISMATCH",
            "case_id": "pdf-a",
            "matched": 1,
            "total": 2,
            "unmatched_annotations": ["intent_family"],
        }
    ]


def test_strict_gold_rejects_failed_candidate_even_when_score_matches() -> None:
    record, payload = _candidate()
    gold_case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        **_provisional_gold(),
    }
    score = benchmark._score_gold(record, gold_case, payload=payload)
    score["matched_by"] = "sha256"

    strict = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": [gold_case]},
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {
                    "status": "error",
                    "error_type": "CandidateProcessError",
                },
                "gold": score,
            }
        ],
    )

    assert strict["passed"] is False
    assert strict["failures"] == [
        {
            "code": "CANDIDATE_NOT_COMPLETED",
            "case_id": "pdf-a",
            "candidate_status": "error",
            "error_type": "CandidateProcessError",
        }
    ]


def test_strict_gold_cli_writes_report_then_exits_nonzero(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    report_path = tmp_path / "strict-report.json"
    report = {
        "discovery": {"selected_case_count": 0},
        "candidate": {"configured": False},
        "gold": {
            "strict": {
                "enabled": True,
                "passed": False,
                "failure_count": 1,
                "failures": [{"code": "GOLD_NOT_CONFIGURED"}],
            }
        },
    }
    monkeypatch.setattr(benchmark, "_run", lambda _args: report)
    monkeypatch.setattr(
        benchmark.sys,
        "argv",
        [
            str(SCRIPT_PATH),
            "--strict-gold",
            "--report",
            str(report_path),
        ],
    )

    with pytest.raises(SystemExit, match="GOLD_NOT_CONFIGURED"):
        benchmark.main()

    assert json.loads(report_path.read_text(encoding="utf-8")) == report
    assert benchmark._parser().parse_args(["--strict-gold"]).strict_gold is True


def test_strict_gold_does_not_run_candidate_when_gold_is_unavailable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "sample.pdf"
    source.write_bytes(b"fixture")
    case = benchmark.Case(
        id="pdf-a",
        path=source,
        sha256="a" * 64,
        category="pdf",
        source_kind="named",
        size_bytes=source.stat().st_size,
    )
    monkeypatch.setattr(
        benchmark,
        "_discover",
        lambda _args: ([case], [], 1),
    )

    def candidate_must_not_run(*_args, **_kwargs):
        raise AssertionError("candidate must not run without strict gold")

    monkeypatch.setattr(benchmark, "_run_candidate", candidate_must_not_run)
    args = benchmark._parser().parse_args(
        [
            "--strict-gold",
            "--candidate-command",
            "candidate {input}",
        ]
    )

    report = benchmark._run(args)

    assert report["cases"][0]["candidate"] == {
        "status": "not_run",
        "reason": "strict_gold_unavailable",
    }
    assert report["gold"]["strict"]["passed"] is False
    assert report["gold"]["strict"]["failures"] == [
        {"code": "GOLD_NOT_CONFIGURED"}
    ]
    assert report["cases"][0]["key_gold_status"] == "not_scored"
    assert report["cases"][0]["key_gold_passed"] is None
    assert report["cases"][0]["full_evidence_status"] == "not_available"
    assert report["cases"][0]["full_evidence_passed"] is None
    assert report["quality_gates"] == {
        "key_gold": {
            "status": "not_available",
            "passed": None,
            "passed_cases": 0,
            "failed_cases": 0,
            "not_available_cases": 1,
        },
        "full_evidence": {
            "status": "not_available",
            "passed": None,
            "passed_cases": 0,
            "failed_cases": 0,
            "not_available_cases": 1,
        },
    }


def test_semantic_header_rejects_conflicting_duplicate_values() -> None:
    record, payload = _candidate()
    record["header"]["contract_number_copy"] = "WRONG-PO"
    record["field_meta"]["$.header.contract_number_copy"] = {
        "source_refs": [{"page": 1, "part": "p1:b1"}]
    }
    payload["projection"]["field_names"][
        "$.header.contract_number_copy"
    ] = "contract_number"

    semantic = benchmark._score_gold(
        record,
        {
            "expected": {
                "key_values": {"contract_number": "PO-1"},
                "header_fields": {"contract_number": "PO-1"},
            }
        },
        payload=payload,
    )["semantic_gold"]

    assert semantic["matched"] == 0
    assert semantic["unmatched_annotations"] == [
        "key_values.contract_number",
        "header_fields.contract_number",
    ]


def test_semantic_header_allows_same_duplicate_only_with_locatable_evidence() -> None:
    record, payload = _candidate()
    record["header"]["contract_number_copy"] = "PO-1"
    record["field_meta"]["$.header.contract_number_copy"] = {
        "source_refs": [{"page": 1, "bbox": [1, 2, 3, 4]}]
    }
    payload["projection"]["field_names"][
        "$.header.contract_number_copy"
    ] = "contract_number"
    gold = {"expected": {"key_values": {"contract_number": "PO-1"}}}

    semantic = benchmark._score_gold(record, gold, payload=payload)["semantic_gold"]
    assert semantic["matched"] == semantic["total"] == 1

    record["field_meta"]["$.header.contract_number"] = {"source_refs": []}
    record["field_meta"]["$.header.contract_number_copy"] = {
        "source_refs": [{"unlocatable": True}]
    }
    semantic = benchmark._score_gold(record, gold, payload=payload)["semantic_gold"]
    assert semantic["matched"] == 0
    assert semantic["unmatched_annotations"] == ["key_values.contract_number"]


def test_line_gold_rejects_conflicts_per_row_without_rejecting_other_rows() -> None:
    record, payload = _candidate()
    payload["projection"]["field_names"]["$.lines[0].field_name"] = "product_name"
    payload["projection"]["field_names"]["$.lines[1].field_name"] = "product_name"
    record["lines"][0]["field_name_copy"] = "Wrong"
    payload["projection"]["field_names"][
        "$.lines[0].field_name_copy"
    ] = "product_name"
    record["lines"][1]["field_name"] = "Cable A"
    gold = {
        "expected": {
            "records": [
                {"product_name": "Cable A"},
                {"product_name": "Cable A"},
            ]
        }
    }

    semantic = benchmark._score_gold(record, gold, payload=payload)["semantic_gold"]

    checks = {item["annotation"]: item["matched"] for item in semantic["checks"]}
    assert checks == {
        "records[0].product_name": False,
        "records[1].product_name": True,
    }


def test_strict_gold_requires_legacy_fields_table_rows_and_cells() -> None:
    record, payload = _candidate()
    gold_case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        "expected": {
            "fields": {"$.header.contract_number": "WRONG"},
            "tables": [
                {
                    "id": "details",
                    "record_path": "$.lines",
                    "row_count": 1,
                    "rows": [{"field_name": "Cable A", "field_quantity": 999}],
                }
            ],
        },
    }
    score = benchmark._score_gold(record, gold_case, payload=payload)
    score["matched_by"] = "sha256"

    strict = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": [gold_case]},
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {"status": "completed"},
                "gold": score,
            }
        ],
    )

    assert strict["passed"] is False
    assert {failure["code"] for failure in strict["failures"]} == {
        "LEGACY_GOLD_FIELD_MISMATCH",
        "GOLD_TABLE_ROW_COUNT_MISMATCH",
        "GOLD_TABLE_CELL_MISMATCH",
    }
    evaluation = benchmark._key_gold_evaluation(score)
    assert evaluation["status"] == "failed"
    assert evaluation["assertion_count"] == 4


def test_strict_gold_rejects_case_without_effective_assertions() -> None:
    record, payload = _candidate()
    gold_case = {
        "id": "pdf-a",
        "sha256": "a" * 64,
        "expected": {"record_count_semantics": "description only"},
    }
    score = benchmark._score_gold(record, gold_case, payload=payload)
    score["matched_by"] = "sha256"

    strict = benchmark._strict_gold_summary(
        enabled=True,
        configured=True,
        gold={"cases": [gold_case]},
        cases=[
            {
                "id": "pdf-a",
                "sha256": "a" * 64,
                "candidate": {"status": "completed"},
                "gold": score,
            }
        ],
    )

    assert strict["failures"] == [
        {"code": "GOLD_CASE_WITHOUT_ASSERTIONS", "case_id": "pdf-a"}
    ]
    assert benchmark._key_gold_evaluation(score) == {
        "status": "failed",
        "passed": False,
        "assertion_count": 0,
        "failures": ["no_effective_assertions"],
    }


def test_full_evidence_gate_is_independent_from_key_gold() -> None:
    complete = {
        "accounted_complete": True,
        "retained_complete": True,
        "content_accounted_complete": True,
        "evidence_unresolved_count": 0,
        "evidence_total_count": 10,
        "evidence_mapped_count": 5,
        "evidence_schema_count": 2,
        "evidence_redundant_count": 1,
        "evidence_raw_content_count": 2,
        "evidence_retained_count": 10,
        "content_evidence_count": 3,
        "content_unit_count": 3,
        "source_asset_inventory_status": "complete",
        "source_asset_count": 2,
        "source_asset_requirement_count": 1,
        "source_asset_analyzed_count": 3,
        "source_asset_analyzed_asset_count": 2,
        "source_asset_fulfilled_requirement_count": 1,
    }
    assert benchmark._full_evidence_evaluation(complete) == {
        "status": "passed",
        "passed": True,
        "failures": [],
    }

    incomplete = {**complete, "evidence_unresolved_count": 1}
    evaluation = benchmark._full_evidence_evaluation(incomplete)
    assert evaluation["status"] == "failed"
    assert evaluation["passed"] is False
    assert evaluation["failures"] == ["terminal_unresolved_evidence"]
