from __future__ import annotations

from pathlib import Path
import shutil
import subprocess

import pytest

from m1.parsers.cad import parse_dwg


def _write_dxf(path: Path, text: str) -> None:
    ezdxf = pytest.importorskip("ezdxf")
    document = ezdxf.new("R2010")
    document.modelspace().add_text(text)
    document.saveas(path)


def test_parse_dwg_runs_configured_argv_and_parses_generated_dxf(
    tmp_path, monkeypatch
):
    source = tmp_path / "drawing with spaces.dwg"
    source.write_bytes(b"AC1027\x00test")
    fixture = tmp_path / "fixture.dxf"
    _write_dxf(fixture, "DWG-CONVERTED-001")
    observed: dict[str, object] = {}

    def fake_run(command, **kwargs):  # noqa: ANN001
        observed["command"] = command
        observed["kwargs"] = kwargs
        shutil.copyfile(fixture, Path(command[2]))
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(subprocess, "run", fake_run)

    parsed = parse_dwg(
        source,
        command_template='converter "{input}" "{output}"',
    )

    assert observed["command"][0] == "converter"
    assert observed["command"][1] == str(source.resolve())
    assert observed["kwargs"]["check"] is False
    assert "shell" not in observed["kwargs"]
    assert "DWG-CONVERTED-001" in parsed
    assert "DWG 转换" in parsed


def test_parse_dwg_reports_missing_converter_without_claiming_success(
    tmp_path, monkeypatch
):
    source = tmp_path / "drawing.dwg"
    source.write_bytes(b"AC1027\x00test")
    monkeypatch.setattr(shutil, "which", lambda _name: None)

    parsed = parse_dwg(source)

    assert parsed.startswith("[DWG conversion failed:")
    assert "DWG_CONVERTER_COMMAND" in parsed


def test_parse_dwg_timeout_is_bounded(tmp_path, monkeypatch):
    source = tmp_path / "drawing.dwg"
    source.write_bytes(b"AC1027\x00test")

    def timeout(*_args, **_kwargs):  # noqa: ANN002, ANN003
        raise subprocess.TimeoutExpired("converter", 1)

    monkeypatch.setattr(subprocess, "run", timeout)

    parsed = parse_dwg(
        source,
        command_template="converter {input} {output}",
        timeout_seconds=1,
    )

    assert "converter timeout" in parsed
