from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest
from alembic import command
from m1.documents.parsing.content_region_contracts import (
    CONTENT_REGION_CONTRACT_ID,
    CONTENT_REGION_CONTRACT_REVISION,
    CONTENT_REGION_EMBEDDING_SPACE,
    ContentAreaBucket,
    ContentLengthBucket,
    ContentPagePosition,
    ContentRegionCandidateProposal,
    ContentRegionExecutionObservation,
    ContentRegionKind,
    ContentRegionRole,
    ContentRegionSemanticSketch,
    ContentRegionSemanticTag,
    ContentRegionSignature,
    ContentRegionSourceFamily,
    ContentVerticalPosition,
    semantic_label_sha256,
)
from m1.documents.parsing.content_region_probes import build_content_region_probes
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.semantic_strategy_router import SemanticStrategyId
from m1.knowledge.content_region_repository import ContentRegionRepository
from m1.knowledge.content_region_schema import ContentRegionProfileStatus
from m1.knowledge.db_models_base import (
    IdempotencyConflictError,
    TenantBoundaryError,
)
from m1.knowledge.migrations.runner import _config
from m1.knowledge.schema import TenantRecord
from sqlalchemy import create_engine, inspect


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _signature(
    *,
    tags: tuple[ContentRegionSemanticTag, ...] = (
        ContentRegionSemanticTag.PRODUCT_IDENTIFIER,
        ContentRegionSemanticTag.QUANTITY,
        ContentRegionSemanticTag.UNIT,
    ),
    source: ContentRegionSourceFamily = ContentRegionSourceFamily.MINERU,
) -> ContentRegionSignature:
    hashes = tuple(semantic_label_sha256(tag.value) for tag in tags)
    return ContentRegionSignature(
        source_family=source,
        region_kind=ContentRegionKind.TABLE,
        page_position=ContentPagePosition.FIRST,
        vertical_position=ContentVerticalPosition.MIDDLE,
        area_bucket=ContentAreaBucket.LARGE,
        text_length=ContentLengthBucket.MEDIUM,
        semantic_sketch=ContentRegionSemanticSketch(
            semantic_tags=tags,
            semantic_label_hashes=hashes,
            label_count=len(hashes),
        ),
        has_coordinates=True,
    )


def _proposal(
    tenant_id: str,
    *,
    signature: ContentRegionSignature | None = None,
    vector: list[float] | None = None,
) -> ContentRegionCandidateProposal:
    signature = signature or _signature()
    return ContentRegionCandidateProposal(
        tenant_id=tenant_id,
        profile_key=f"content-region:{signature.exact_fingerprint()[:20]}:line-items",
        embedding_space=CONTENT_REGION_EMBEDDING_SPACE,
        signature=signature,
        suggested_role=ContentRegionRole.LINE_ITEM_TABLE,
        suggested_strategy_id=SemanticStrategyId.ORDER,
        embedding=tuple(vector or [1.0, *([0.0] * 1023)]),
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        created_by="test-suite",
    )


async def _seed_successes(store, profile) -> None:
    for index in range(3):
        await store.record_content_region_execution_observation(
            ContentRegionExecutionObservation(
                tenant_id=profile.tenant_id,
                profile_id=profile.profile_id,
                exact_fingerprint=profile.exact_fingerprint,
                task_reference_hash=_hash(f"task-{index}"),
                outcome="success",
                validation_passed=True,
                reviewed_by=f"reviewer-{index}",
                review_note_sha256=_hash(f"note-{index}"),
            )
        )


@pytest.fixture
async def content_store(tmp_path: Path):
    store = ContentRegionRepository(
        f"sqlite+aiosqlite:///{(tmp_path / 'content-routes.db').as_posix()}"
    )
    await store.init()
    first = TenantRecord(tenant_key="tenant-a", display_name="Tenant A")
    second = TenantRecord(tenant_key="tenant-b", display_name="Tenant B")
    await store.create_tenant(first)
    await store.create_tenant(second)
    try:
        yield store, first, second
    finally:
        await store.close()


def test_semantic_sketch_redacts_business_values_from_every_routing_payload() -> None:
    evidence = DocumentEvidence(
        backend="mineru-3.4.4",
        backend_version="3.4.4",
        elapsed_ms=1.0,
        pages=[
            EvidencePage(
                page_index=0,
                page_number=1,
                width=1000,
                height=1000,
                blocks=[
                    EvidenceBlock(
                        block_id="title",
                        kind="title",
                        text=(
                            "采购订单 PO-SECRET-1001 广西桐曦电子科技有限公司 "
                            "2099-01-01 13800138000"
                        ),
                        bbox=EvidenceBBox(x0=0, y0=0, x1=900, y1=100),
                        order=0,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="items",
                        rows=[
                            ["物料号", "品名", "数量", "单位", "交货日期"],
                            [
                                "SECRET-SKU-9001",
                                "秘密产品",
                                "100",
                                "pcs",
                                "2099-01-01",
                            ],
                        ],
                        bbox=EvidenceBBox(x0=0, y0=120, x1=900, y1=800),
                    )
                ],
            )
        ],
    )
    probes = build_content_region_probes(evidence)
    payloads = [
        json.dumps(
            [probe.model_dump(mode="json") for probe in probes],
            ensure_ascii=False,
        ),
        "\n".join(probe.signature.embedding_text() for probe in probes),
        json.dumps(
            [
                probe.signature.model_sketch().model_dump(mode="json")
                for probe in probes
            ],
            ensure_ascii=False,
        ),
    ]

    for payload in payloads:
        for secret in (
            "PO-SECRET-1001",
            "广西桐曦电子科技有限公司",
            "2099-01-01",
            "13800138000",
            "SECRET-SKU-9001",
            "秘密产品",
        ):
            assert secret not in payload
    table = next(
        probe
        for probe in probes
        if probe.signature.region_kind is ContentRegionKind.TABLE
    )
    assert set(table.signature.semantic_sketch.semantic_tags) >= {
        ContentRegionSemanticTag.PRODUCT_IDENTIFIER,
        ContentRegionSemanticTag.PRODUCT_NAME,
        ContentRegionSemanticTag.QUANTITY,
        ContentRegionSemanticTag.UNIT,
        ContentRegionSemanticTag.DELIVERY_DATE,
    }
    assert "semantic_label_hashes" not in table.signature.model_sketch().model_dump()


@pytest.mark.asyncio
async def test_candidate_is_idempotent_and_inactive(content_store) -> None:
    store, tenant, _other = content_store
    proposal = _proposal(tenant.tenant_id)

    created = await store.create_content_region_candidate(proposal)
    replay = await store.create_content_region_candidate(proposal)
    active = await store.get_active_content_region_profile_by_fingerprint(
        tenant.tenant_id,
        proposal.signature.exact_fingerprint(),
        contract_id=CONTENT_REGION_CONTRACT_ID,
        contract_revision=CONTENT_REGION_CONTRACT_REVISION,
        embedding_space=CONTENT_REGION_EMBEDDING_SPACE,
    )

    assert created.status == "candidate"
    assert replay.profile_id == created.profile_id
    assert active is None


@pytest.mark.asyncio
async def test_reviewed_activation_enables_exact_and_vector_reuse(
    content_store,
) -> None:
    store, tenant, _other = content_store
    proposal = _proposal(tenant.tenant_id)
    candidate = await store.create_content_region_candidate(proposal)
    await _seed_successes(store, candidate)
    activated = await store.activate_content_region_profile(
        tenant.tenant_id,
        candidate.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="three clean samples",
        expected_observation_count=3,
        allowed_routes={(ContentRegionRole.LINE_ITEM_TABLE, SemanticStrategyId.ORDER)},
    )

    exact = await store.get_active_content_region_profile_by_fingerprint(
        tenant.tenant_id,
        proposal.signature.exact_fingerprint(),
        contract_id=CONTENT_REGION_CONTRACT_ID,
        contract_revision=CONTENT_REGION_CONTRACT_REVISION,
        embedding_space=CONTENT_REGION_EMBEDDING_SPACE,
    )
    vector = await store.find_active_content_region_profiles(
        tenant.tenant_id,
        proposal.embedding or (),
        contract_id=CONTENT_REGION_CONTRACT_ID,
        contract_revision=CONTENT_REGION_CONTRACT_REVISION,
        embedding_space=CONTENT_REGION_EMBEDDING_SPACE,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        region_kind=ContentRegionKind.TABLE,
        limit=5,
    )

    assert activated.status is ContentRegionProfileStatus.ACTIVE
    assert exact is not None and exact.profile_id == candidate.profile_id
    assert [match.profile.profile_id for match in vector] == [candidate.profile_id]
    assert vector[0].vector_similarity == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_observation_idempotency_and_tenant_boundary(content_store) -> None:
    store, tenant, other = content_store
    candidate = await store.create_content_region_candidate(_proposal(tenant.tenant_id))
    observation = ContentRegionExecutionObservation(
        tenant_id=tenant.tenant_id,
        profile_id=candidate.profile_id,
        exact_fingerprint=candidate.exact_fingerprint,
        task_reference_hash=_hash("same-task"),
        outcome="success",
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256=_hash("same-note"),
    )
    first = await store.record_content_region_execution_observation(observation)
    replay = await store.record_content_region_execution_observation(observation)
    assert replay.observation_id == first.observation_id

    with pytest.raises(IdempotencyConflictError):
        await store.record_content_region_execution_observation(
            observation.model_copy(update={"latency_ms": 9})
        )
    with pytest.raises(TenantBoundaryError):
        await store.reject_content_region_profile(
            other.tenant_id,
            candidate.profile_id,
            reviewed_by="reviewer",
            review_note="cross tenant",
        )


@pytest.mark.asyncio
async def test_reject_and_deprecate_remove_profiles_from_active_lookup(
    content_store,
) -> None:
    store, tenant, _other = content_store
    rejected_candidate = await store.create_content_region_candidate(
        _proposal(tenant.tenant_id)
    )
    rejected = await store.reject_content_region_profile(
        tenant.tenant_id,
        rejected_candidate.profile_id,
        reviewed_by="reviewer",
        review_note="wrong semantic route",
    )
    assert rejected.status is ContentRegionProfileStatus.REJECTED

    next_proposal = _proposal(
        tenant.tenant_id,
        signature=_signature(
            tags=(
                ContentRegionSemanticTag.SPECIFICATION,
                ContentRegionSemanticTag.TECHNICAL_PARAMETER,
            )
        ),
    )
    candidate = await store.create_content_region_candidate(next_proposal)
    await _seed_successes(store, candidate)
    await store.activate_content_region_profile(
        tenant.tenant_id,
        candidate.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="validated specification table",
        expected_observation_count=3,
        allowed_routes={(ContentRegionRole.LINE_ITEM_TABLE, SemanticStrategyId.ORDER)},
    )
    deprecated = await store.deprecate_content_region_profile(
        tenant.tenant_id,
        candidate.profile_id,
        reviewed_by="reviewer",
        review_note="retired route",
    )
    assert deprecated.status is ContentRegionProfileStatus.DEPRECATED
    assert (
        await store.get_active_content_region_profile_by_fingerprint(
            tenant.tenant_id,
            candidate.exact_fingerprint,
            contract_id=CONTENT_REGION_CONTRACT_ID,
            contract_revision=CONTENT_REGION_CONTRACT_REVISION,
            embedding_space=CONTENT_REGION_EMBEDDING_SPACE,
        )
        is None
    )


def test_0015_migration_upgrades_and_downgrades_after_0014(tmp_path: Path) -> None:
    database_path = tmp_path / "content-region-migration.db"
    database_url = f"sqlite:///{database_path.as_posix()}"
    engine = create_engine(database_url)
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, "0014_region_capability_routes")
            command.upgrade(config, "0015_content_region_routes")
        inspector = inspect(engine)
        assert inspector.has_table("knowledge_content_region_profiles")
        assert inspector.has_table("knowledge_content_region_observations")
        indexes = {
            item["name"]
            for item in inspector.get_indexes("knowledge_content_region_profiles")
        }
        assert "ux_content_region_profiles_active_fingerprint" in indexes
        assert "ix_content_region_profiles_embedding_space" in indexes
    finally:
        engine.dispose()

    engine = create_engine(database_url)
    try:
        with engine.begin() as connection:
            command.downgrade(_config(connection), "0014_region_capability_routes")
        inspector = inspect(engine)
        assert not inspector.has_table("knowledge_content_region_profiles")
        assert inspector.has_table("knowledge_region_capability_profiles")
    finally:
        engine.dispose()


def test_0015_migration_declares_forced_rls_and_hnsw() -> None:
    migration = (
        Path(__file__).parents[1]
        / "src"
        / "m1"
        / "knowledge"
        / "migrations"
        / "versions"
        / "0015_content_region_routes.py"
    ).read_text(encoding="utf-8")

    assert "FORCE ROW LEVEL SECURITY" in migration
    assert "current_setting('m1.tenant_id', true)" in migration
    assert "USING hnsw (embedding vector_cosine_ops)" in migration
    assert 'down_revision: str | None = "0014_region_capability_routes"' in migration
