from __future__ import annotations

import json
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

import pytest
from m1.documents.parsing.content_region_contracts import (
    CONTENT_REGION_CONTRACT_ID,
    CONTENT_REGION_CONTRACT_REVISION,
    CONTENT_REGION_EMBEDDING_SPACE,
    ContentAreaBucket,
    ContentLengthBucket,
    ContentPagePosition,
    ContentRegionCandidateProposal,
    ContentRegionKind,
    ContentRegionModelChoice,
    ContentRegionProbe,
    ContentRegionProfile,
    ContentRegionProfileMatch,
    ContentRegionRole,
    ContentRegionSelectionRequest,
    ContentRegionSemanticSketch,
    ContentRegionSemanticTag,
    ContentRegionSignature,
    ContentRegionSourceFamily,
    ContentVerticalPosition,
    semantic_anchor_sha256,
)
from m1.documents.parsing.content_region_probes import build_content_region_probes
from m1.documents.parsing.content_region_routing import (
    ContentRegionRoutingPolicy,
    ContentRegionRoutingRuntime,
    content_region_topology_similarity,
)
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru import adapt_content_list_v2
from m1.documents.parsing.semantic_strategy_router import SemanticStrategyId
from pydantic import ValidationError


def _signature(
    *,
    kind: ContentRegionKind = ContentRegionKind.TABLE,
    source: ContentRegionSourceFamily = ContentRegionSourceFamily.MINERU,
    anchor: str | None = "物料号|数量|单位",
) -> ContentRegionSignature:
    sketch = ContentRegionSemanticSketch(
        semantic_tags=(
            (ContentRegionSemanticTag.PRODUCT_IDENTIFIER,) if anchor else ()
        ),
        semantic_label_hashes=(semantic_anchor_sha256(anchor),) if anchor else (),
        label_count=1 if anchor else 0,
    )
    return ContentRegionSignature(
        source_family=source,
        region_kind=kind,
        page_position=ContentPagePosition.FIRST,
        vertical_position=ContentVerticalPosition.MIDDLE,
        area_bucket=ContentAreaBucket.LARGE,
        text_length=ContentLengthBucket.MEDIUM,
        semantic_sketch=sketch,
        has_coordinates=True,
    )


def _profile(
    signature: ContentRegionSignature,
    *,
    profile_id: str = "content-profile-1",
    tenant_id: str = "tenant-a",
    status: str = "active",
    role: ContentRegionRole | None = ContentRegionRole.LINE_ITEM_TABLE,
    strategy_id: SemanticStrategyId | None = SemanticStrategyId.ORDER,
    embedding: tuple[float, ...] | None = None,
    embedding_space: str = CONTENT_REGION_EMBEDDING_SPACE,
    reviewed: bool = True,
    success_count: int = 3,
    failure_count: int = 0,
) -> ContentRegionProfile:
    observations = success_count + failure_count
    effective_status = "deprecated" if status == "active" and failure_count else status
    return ContentRegionProfile(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=f"content-region:{profile_id}",
        status=effective_status,
        embedding_space=embedding_space,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        role=role,
        strategy_id=strategy_id,
        embedding=embedding,
        embedding_model="test-embedding" if embedding is not None else "",
        embedding_dimensions=len(embedding) if embedding is not None else 0,
        reviewed=reviewed,
        observation_count=observations,
        success_count=success_count,
        failure_count=failure_count,
    )


class _Store:
    def __init__(
        self,
        *,
        exact: ContentRegionProfile | None = None,
        matches: Sequence[ContentRegionProfileMatch] = (),
    ) -> None:
        self.exact = exact
        self.matches = tuple(matches)
        self.exact_queries: list[dict[str, object]] = []
        self.vector_queries: list[dict[str, object]] = []
        self.proposals: list[ContentRegionCandidateProposal] = []

    async def get_active_content_region_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
    ) -> ContentRegionProfile | None:
        self.exact_queries.append(
            {
                "tenant_id": tenant_id,
                "exact_fingerprint": exact_fingerprint,
                "contract_id": contract_id,
                "contract_revision": contract_revision,
                "embedding_space": embedding_space,
            }
        )
        return self.exact

    async def find_active_content_region_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        contract_id: str,
        contract_revision: str,
        embedding_space: str,
        embedding_model: str,
        embedding_dimensions: int,
        region_kind: ContentRegionKind,
        limit: int,
    ) -> Sequence[ContentRegionProfileMatch]:
        self.vector_queries.append(
            {
                "tenant_id": tenant_id,
                "embedding": tuple(embedding),
                "contract_id": contract_id,
                "contract_revision": contract_revision,
                "embedding_space": embedding_space,
                "embedding_model": embedding_model,
                "embedding_dimensions": embedding_dimensions,
                "region_kind": region_kind,
                "limit": limit,
            }
        )
        return self.matches

    async def create_content_region_candidate(
        self, proposal: ContentRegionCandidateProposal
    ) -> ContentRegionProfile:
        self.proposals.append(proposal)
        return ContentRegionProfile(
            profile_id=f"candidate-{len(self.proposals)}",
            tenant_id=proposal.tenant_id,
            profile_key=proposal.profile_key,
            status="candidate",
            embedding_space=proposal.embedding_space,
            exact_fingerprint=proposal.signature.exact_fingerprint(),
            signature=proposal.signature,
            role=proposal.suggested_role,
            strategy_id=proposal.suggested_strategy_id,
            embedding=proposal.embedding,
            embedding_model=proposal.embedding_model,
            embedding_dimensions=proposal.embedding_dimensions,
        )


class _Embedding:
    space = CONTENT_REGION_EMBEDDING_SPACE
    model = "test-embedding"
    dimensions = 4

    def __init__(self) -> None:
        self.inputs: list[str] = []

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        self.inputs.extend(texts)
        return ((1.0, 0.0, 0.0, 0.0),)


SelectorOutput = Mapping[str, Any] | Callable[[ContentRegionSelectionRequest], Any]


class _Selector:
    def __init__(self, output: SelectorOutput) -> None:
        self.output = output
        self.requests: list[ContentRegionSelectionRequest] = []

    async def select(self, request: ContentRegionSelectionRequest) -> Any:
        self.requests.append(request)
        return self.output(request) if callable(self.output) else self.output


def _sample_evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="mineru-3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1000,
                coordinate_space="pixels",
                blocks=[
                    EvidenceBlock(
                        block_id="title-1",
                        kind="title",
                        text="采购订单 PO-SECRET-1001",
                        bbox=EvidenceBBox(x0=50, y0=30, x1=950, y1=100),
                        order=0,
                    ),
                    EvidenceBlock(
                        block_id="paragraph-1",
                        kind="paragraph",
                        text="甲方：秘密客户有限公司\n交货日期：2099-01-01",
                        bbox=EvidenceBBox(x0=50, y0=120, x1=950, y1=220),
                        order=1,
                    ),
                    EvidenceBlock(
                        block_id="table-duplicate",
                        kind="table",
                        text="物料号 | 数量",
                        bbox=EvidenceBBox(x0=50, y0=250, x1=950, y1=700),
                        order=2,
                    ),
                    EvidenceBlock(
                        block_id="figure-1",
                        kind="image",
                        text="产品图 SECRET-PART",
                        bbox=EvidenceBBox(x0=700, y0=730, x1=940, y1=940),
                        order=3,
                    ),
                ],
                tables=[
                    EvidenceTable(
                        table_id="table-1",
                        rows=[
                            ["物料号", "品名", "数量", "单位"],
                            ["SECRET-SKU", "秘密产品", "100", "pcs"],
                        ],
                        bbox=EvidenceBBox(x0=50, y0=250, x1=950, y1=700),
                        mineru_item_index=2,
                    )
                ],
            )
        ],
    )


def test_probe_builder_covers_mineru_regions_without_retaining_values() -> None:
    probes = build_content_region_probes(_sample_evidence())

    assert [probe.signature.region_kind for probe in probes] == [
        ContentRegionKind.TITLE,
        ContentRegionKind.PARAGRAPH,
        ContentRegionKind.TABLE,
        ContentRegionKind.FIGURE,
    ]
    assert len({probe.source_ref for probe in probes}) == 4
    assert probes[1].signature.has_key_value_shape is True
    assert len(probes[1].signature.semantic_sketch.semantic_label_hashes) == 2
    assert len(probes[2].signature.semantic_sketch.semantic_label_hashes) == 4

    payload = json.dumps(
        [probe.model_dump(mode="json") for probe in probes],
        ensure_ascii=False,
    )
    for secret in (
        "PO-SECRET-1001",
        "秘密客户有限公司",
        "2099-01-01",
        "SECRET-SKU",
        "秘密产品",
        "SECRET-PART",
    ):
        assert secret not in payload


def test_real_mineru_v2_adapter_exposes_each_region_once() -> None:
    fixture = (
        Path(__file__).parent
        / "fixtures"
        / "mineru"
        / "3.4.4"
        / "sample_order_content_list_v2.json"
    )
    payload = json.loads(fixture.read_text(encoding="utf-8"))
    evidence = adapt_content_list_v2(
        payload,
        backend="mineru",
        backend_version="3.4.4",
        model_revision="pinned-test",
        elapsed_ms=1.0,
    )

    probes = build_content_region_probes(evidence)

    assert [probe.signature.region_kind for probe in probes] == [
        ContentRegionKind.TITLE,
        ContentRegionKind.PARAGRAPH,
        ContentRegionKind.TABLE,
        ContentRegionKind.FIGURE,
    ]
    assert (
        len([probe for probe in probes if probe.signature.region_kind == "table"]) == 1
    )


def test_signature_embedding_is_value_free_and_omits_anchor_digests() -> None:
    signature = _signature(anchor="客户机密表头")
    embedding_text = signature.embedding_text()

    assert "客户机密表头" not in signature.model_dump_json()
    assert "客户机密表头" not in embedding_text
    assert signature.semantic_sketch.semantic_label_hashes[0] not in embedding_text
    assert "semantic_label_count=1" in embedding_text
    assert "semantic_tags=product_identifier" in embedding_text


def test_topology_similarity_requires_same_contract_and_region_kind() -> None:
    table = _signature()
    paragraph = _signature(kind=ContentRegionKind.PARAGRAPH)
    docling_table = _signature(source=ContentRegionSourceFamily.DOCLING)

    assert content_region_topology_similarity(table, paragraph) == 0.0
    assert 0.0 < content_region_topology_similarity(table, docling_table) < 1.0


@pytest.mark.asyncio
async def test_exact_reviewed_active_profile_routes_with_full_isolation_query() -> None:
    signature = _signature()
    store = _Store(exact=_profile(signature))
    selector = _Selector(
        {"action": "review", "candidate_index": None, "confidence": 1.0}
    )

    decision = await ContentRegionRoutingRuntime(
        store=store,
        selector=selector,
    ).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(source_ref="page:1/table:t1", signature=signature),
        allowed_strategy_ids=(SemanticStrategyId.ORDER,),
    )

    assert decision.action == "route"
    assert decision.reason == "exact_reviewed_active_profile"
    assert decision.profile_id == "content-profile-1"
    assert decision.role is ContentRegionRole.LINE_ITEM_TABLE
    assert decision.strategy_id is SemanticStrategyId.ORDER
    assert selector.requests == []
    assert store.exact_queries == [
        {
            "tenant_id": "tenant-a",
            "exact_fingerprint": signature.exact_fingerprint(),
            "contract_id": CONTENT_REGION_CONTRACT_ID,
            "contract_revision": CONTENT_REGION_CONTRACT_REVISION,
            "embedding_space": CONTENT_REGION_EMBEDDING_SPACE,
        }
    ]


@pytest.mark.asyncio
async def test_unanchored_exact_shape_never_routes_automatically() -> None:
    signature = _signature(kind=ContentRegionKind.PARAGRAPH, anchor=None)
    exact = _profile(
        signature,
        role=ContentRegionRole.BODY_TEXT,
        strategy_id=SemanticStrategyId.GENERIC,
    )
    store = _Store(exact=exact)

    decision = await ContentRegionRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(source_ref="page:1/block:b1", signature=signature),
    )

    assert decision.action == "new_candidate"
    assert decision.reason == "no_stable_exact_anchor"
    assert decision.profile_id is None
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].suggested_role is None


@pytest.mark.asyncio
async def test_exact_store_result_is_revalidated_before_execution() -> None:
    probe_signature = _signature(anchor="当前表头")
    wrong_exact = _profile(_signature(anchor="另一张表"))
    store = _Store(exact=wrong_exact)

    decision = await ContentRegionRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(
            source_ref="page:1/table:current", signature=probe_signature
        ),
    )

    assert decision.action == "new_candidate"
    assert decision.reason == "active_profile_not_reusable"
    assert decision.profile_id is None
    assert decision.candidate_profile_id == "candidate-1"


@pytest.mark.asyncio
async def test_vector_reuse_filters_tenant_space_and_failed_profiles() -> None:
    probe_signature = _signature(anchor="客户订单明细")
    stored_signature = _signature(
        source=ContentRegionSourceFamily.DOCLING,
        anchor="供应商订单明细",
    )
    vector = (1.0, 0.0, 0.0, 0.0)
    good = _profile(stored_signature, profile_id="approved-route", embedding=vector)
    wrong_tenant = _profile(
        stored_signature,
        profile_id="other-tenant-route",
        tenant_id="tenant-b",
        embedding=vector,
    )
    wrong_space = _profile(
        stored_signature,
        profile_id="wrong-space-route",
        embedding=vector,
        embedding_space="another-space",
    )
    failed = _profile(
        stored_signature,
        profile_id="failed-route",
        embedding=vector,
        success_count=1,
        failure_count=1,
    )
    store = _Store(
        matches=tuple(
            ContentRegionProfileMatch(profile=profile, vector_similarity=0.99)
            for profile in (wrong_tenant, wrong_space, failed, good)
        )
    )
    embedding = _Embedding()
    selector = _Selector(
        {"action": "reuse_active", "candidate_index": 0, "confidence": 0.98}
    )

    decision = await ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector=selector,
    ).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(
            source_ref="page:1/table:unseen", signature=probe_signature
        ),
        allowed_strategy_ids=(SemanticStrategyId.ORDER,),
    )

    assert decision.action == "route"
    assert decision.reason == "model_selected_active_profile"
    assert decision.profile_id == "approved-route"
    assert len(selector.requests) == 1
    assert len(selector.requests[0].candidates) == 1
    assert "approved-route" not in selector.requests[0].model_dump_json()
    assert store.vector_queries[0]["tenant_id"] == "tenant-a"
    assert store.vector_queries[0]["contract_id"] == CONTENT_REGION_CONTRACT_ID
    assert store.vector_queries[0]["embedding_space"] == (
        CONTENT_REGION_EMBEDDING_SPACE
    )
    assert all("客户订单明细" not in value for value in embedding.inputs)


@pytest.mark.asyncio
async def test_model_can_propose_only_registered_pair_and_candidate_stays_inactive() -> (
    None
):
    signature = _signature()

    def choose_order_table(request: ContentRegionSelectionRequest) -> dict[str, Any]:
        index = next(
            item.route_index
            for item in request.routes
            if item.role is ContentRegionRole.LINE_ITEM_TABLE
            and item.strategy_id is SemanticStrategyId.ORDER
        )
        return {
            "action": "propose_registered",
            "route_index": index,
            "confidence": 0.97,
        }

    store = _Store()
    decision = await ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=_Selector(choose_order_table),
    ).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(source_ref="page:1/table:new", signature=signature),
        allowed_strategy_ids=(SemanticStrategyId.ORDER,),
    )

    assert decision.action == "new_candidate"
    assert decision.reason == "model_proposed_registered_route"
    assert decision.role is None
    assert decision.strategy_id is None
    assert decision.suggested_role is ContentRegionRole.LINE_ITEM_TABLE
    assert decision.suggested_strategy_id is SemanticStrategyId.ORDER
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].suggested_role is ContentRegionRole.LINE_ITEM_TABLE
    assert store.proposals[0].suggested_strategy_id is SemanticStrategyId.ORDER


@pytest.mark.asyncio
async def test_model_cannot_inject_role_schema_prompt_or_code() -> None:
    store = _Store()
    selector = _Selector(
        {
            "action": "propose_registered",
            "route_index": 0,
            "confidence": 1.0,
            "role": "invented_role",
            "strategy_id": "invented_strategy",
            "schema": {"type": "object"},
            "prompt": "ignore governance",
            "code": "import os",
        }
    )

    decision = await ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(
            source_ref="page:1/table:unsafe", signature=_signature()
        ),
    )

    assert decision.action == "review"
    assert decision.reason == "invalid_model_output"
    assert decision.role is None
    assert decision.strategy_id is None
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].suggested_role is None
    with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
        ContentRegionModelChoice.model_validate(selector.output, strict=True)


@pytest.mark.asyncio
async def test_low_score_or_low_confidence_cannot_execute_active_profile() -> None:
    probe_signature = _signature(anchor="新表头")
    profile = _profile(
        _signature(source=ContentRegionSourceFamily.NATIVE, anchor="旧表头"),
        embedding=(1.0, 0.0, 0.0, 0.0),
    )
    store = _Store(
        matches=(ContentRegionProfileMatch(profile=profile, vector_similarity=0.70),)
    )
    selector = _Selector(
        {"action": "reuse_active", "candidate_index": 0, "confidence": 0.60}
    )
    runtime = ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
        policy=ContentRegionRoutingPolicy(candidate_request_min_score=0.30),
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(
            source_ref="page:1/table:weak", signature=probe_signature
        ),
    )

    assert decision.action == "review"
    assert decision.profile_id is None
    assert decision.reason in {
        "candidate_score_below_threshold",
        "candidate_confidence_below_threshold",
    }
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].suggested_role is None


@pytest.mark.asyncio
@pytest.mark.parametrize("dependency", ["store", "embedding", "model"])
async def test_required_runtime_fails_closed_on_dependency_failure(
    dependency: str,
) -> None:
    class _FailingStore(_Store):
        async def get_active_content_region_profile_by_fingerprint(
            self, *args, **kwargs
        ):
            if dependency == "store":
                raise TimeoutError("private store detail")
            return await super().get_active_content_region_profile_by_fingerprint(
                *args, **kwargs
            )

    class _FailingEmbedding(_Embedding):
        async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
            if dependency == "embedding":
                raise TimeoutError("private embedding detail")
            return await super().embed_texts(texts)

    class _FailingSelector(_Selector):
        async def select(self, request: ContentRegionSelectionRequest) -> Any:
            if dependency == "model":
                raise TimeoutError("private model detail")
            return await super().select(request)

    runtime = ContentRegionRoutingRuntime(
        store=_FailingStore(),
        embedding_provider=_FailingEmbedding(),
        selector=_FailingSelector(
            {"action": "review", "candidate_index": None, "confidence": 1.0}
        ),
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            tenant_id="tenant-a",
            probe=ContentRegionProbe(
                source_ref="page:1/table:required", signature=_signature()
            ),
        )

    assert caught.value.dependency == dependency
    assert "private" not in str(caught.value)


@pytest.mark.asyncio
async def test_required_runtime_allows_normal_new_candidate() -> None:
    store = _Store()
    runtime = ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=_Selector(
            {"action": "new_candidate", "candidate_index": None, "confidence": 0.99}
        ),
        required=True,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        probe=ContentRegionProbe(
            source_ref="page:1/table:novel", signature=_signature()
        ),
    )

    assert decision.action == "new_candidate"
    assert decision.reason == "model_requested_new_candidate"
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].suggested_role is None


@pytest.mark.asyncio
async def test_required_runtime_fails_closed_when_embedding_is_missing() -> None:
    runtime = ContentRegionRoutingRuntime(
        store=_Store(),
        selector=_Selector(
            {"action": "review", "candidate_index": None, "confidence": 1.0}
        ),
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            tenant_id="tenant-a",
            probe=ContentRegionProbe(
                source_ref="page:1/table:required", signature=_signature()
            ),
        )

    assert caught.value.dependency == "embedding"


@pytest.mark.asyncio
async def test_required_runtime_fails_closed_after_store_circuit_opens() -> None:
    class _FailingStore(_Store):
        def __init__(self) -> None:
            super().__init__()
            self.calls = 0

        async def get_active_content_region_profile_by_fingerprint(
            self, *args, **kwargs
        ):
            del args, kwargs
            self.calls += 1
            raise TimeoutError("private store detail")

    store = _FailingStore()
    runtime = ContentRegionRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=_Selector(
            {"action": "review", "candidate_index": None, "confidence": 1.0}
        ),
        required=True,
        circuit_failures=3,
    )
    for index in range(3):
        with pytest.raises(DocumentRoutingDependencyError):
            await runtime.resolve(
                tenant_id="tenant-a",
                probe=ContentRegionProbe(
                    source_ref=f"page:1/table:failure-{index}",
                    signature=_signature(anchor=f"failure-{index}"),
                ),
            )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            tenant_id="tenant-a",
            probe=ContentRegionProbe(
                source_ref="page:1/table:circuit", signature=_signature()
            ),
        )

    assert caught.value.dependency == "store"
    assert caught.value.error_type == "CircuitOpen"
    assert store.calls == 3


def test_active_profile_requires_reviewed_success_and_atomic_closed_pair() -> None:
    signature = _signature()
    common = {
        "profile_id": "invalid-active",
        "tenant_id": "tenant-a",
        "profile_key": "content-region:invalid-active",
        "status": "active",
        "embedding_space": CONTENT_REGION_EMBEDDING_SPACE,
        "exact_fingerprint": signature.exact_fingerprint(),
        "signature": signature,
        "role": ContentRegionRole.LINE_ITEM_TABLE,
        "strategy_id": SemanticStrategyId.ORDER,
    }

    with pytest.raises(ValidationError, match="reviewed success evidence"):
        ContentRegionProfile(**common)
    with pytest.raises(ValidationError, match="atomic pair"):
        ContentRegionProfile(
            **{
                **common,
                "status": "candidate",
                "role": ContentRegionRole.LINE_ITEM_TABLE,
                "strategy_id": None,
            }
        )
