from __future__ import annotations

import csv
import hashlib
import io
import json
import zipfile
from pathlib import Path

from m1.documents.adapters.archive import ArchiveLimits
from m1.onboarding.catalog import (
    CatalogOptions,
    main,
    scan_catalog,
    write_csv_manifest,
    write_json_manifest,
)


def _zip_bytes(files: dict[str, bytes]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for name, payload in files.items():
            package.writestr(name, payload)
    return output.getvalue()


def test_catalog_records_magic_hash_duplicates_and_private_relative_paths(
    tmp_path: Path,
) -> None:
    source = tmp_path / "customer-history"
    source.mkdir()
    secret = "SECRET-CONTENT-MUST-NOT-BE-CATALOGED"
    csv_payload = f"model,quantity\n{secret},1\n".encode()
    (source / "one.csv").write_bytes(csv_payload)
    (source / "duplicate.csv").write_bytes(csv_payload)
    (source / "misnamed.jpg").write_bytes(b"%PDF-1.4\n%%EOF")
    (source / ".DS_Store").write_bytes(b"metadata")

    manifest = scan_catalog(source, options=CatalogOptions(sample_per_type=2))

    assert manifest.schema_version == "m1.data_catalog.v1"
    assert manifest.statistics["physical_source_count"] == 3
    assert manifest.statistics["duplicate_count"] == 1
    assert manifest.statistics["type_mismatch_count"] == 1
    assert manifest.statistics["skipped_count"] == 1
    assert manifest.statistics["ingestion_candidate_count"] == 2
    assert manifest.statistics["ingestion_candidate_type_counts"] == {"csv": 1, "pdf": 1}
    rows = {row.source_path: row for row in manifest.records}
    assert rows["one.csv"].sha256 == hashlib.sha256(csv_payload).hexdigest()
    assert sum(rows[name].is_duplicate for name in ("one.csv", "duplicate.csv")) == 1
    assert rows["misnamed.jpg"].magic_type == "pdf"
    assert rows["misnamed.jpg"].extension_type == "image"
    assert rows["misnamed.jpg"].effective_type == "pdf"
    assert rows["misnamed.jpg"].type_match == "mismatch"
    serialized = manifest.to_json()
    assert str(source.resolve()) not in serialized
    assert secret not in serialized


def test_catalog_recursively_lists_nested_archive_members_and_member_failures(
    tmp_path: Path,
) -> None:
    source = tmp_path / "corpus"
    source.mkdir()
    nested = _zip_bytes({"deep/order.csv": b"model,quantity\nA,2\n"})
    (source / "bundle.zip").write_bytes(
        _zip_bytes(
            {
                "nested.zip": nested,
                "drawing.pdf": b"%PDF-1.4\n%%EOF",
                "__MACOSX/noise": b"ignored",
            }
        )
    )

    manifest = scan_catalog(source)

    assert manifest.statistics["archive_source_count"] == 1
    assert manifest.statistics["archive_container_count"] == 1
    assert manifest.statistics["archive_member_count"] == 3
    locators = {record.archive_path: record for record in manifest.records if record.archive_path}
    assert "bundle.zip!/nested.zip" in locators
    assert "bundle.zip!/nested.zip!/deep/order.csv" in locators
    assert locators["bundle.zip!/drawing.pdf"].magic_type == "pdf"
    assert locators["bundle.zip!/nested.zip!/deep/order.csv"].sha256
    ignored = locators["bundle.zip!/__MACOSX/noise"]
    assert ignored.status == "skipped"
    assert ignored.failure_code == "macos_metadata"
    assert not list(tmp_path.glob("m1-data-catalog-*"))


def test_archive_limit_is_auditable_partial_result(tmp_path: Path) -> None:
    source = tmp_path / "bomb.zip"
    source.write_bytes(_zip_bytes({"large.txt": b"0" * 10_000}))
    limits = ArchiveLimits(max_single_file=20_000, max_compression_ratio=2)

    manifest = scan_catalog(
        source,
        options=CatalogOptions(archive_limits=limits),
    )

    assert len(manifest.records) == 1
    record = manifest.records[0]
    assert record.record_kind == "source_archive"
    assert record.status == "partial"
    assert record.failure_code == "archive_inventory_failed"
    assert "compression ratio" in (record.failure_reason or "")
    assert manifest.statistics["partial_count"] == 1


def test_sample_selection_is_deterministic_and_size_stratified(tmp_path: Path) -> None:
    source = tmp_path / "samples"
    source.mkdir()
    for index, padding in enumerate((1, 5, 10, 20, 40)):
        (source / f"order-{index}.csv").write_text(
            "model,quantity\n" + ("A" * padding) + ",1\n",
            encoding="utf-8",
        )

    first = scan_catalog(source, options=CatalogOptions(sample_per_type=3))
    second = scan_catalog(source, options=CatalogOptions(sample_per_type=3))

    assert first.to_json() == second.to_json()
    assert first.catalog_id == second.catalog_id
    selected = first.samples["csv"]
    assert [row["sample_rank"] for row in selected] == [1, 2, 3]
    selected_sizes = [row["size_bytes"] for row in selected]
    all_sizes = sorted(record.size_bytes for record in first.records if record.status == "ok")
    assert selected_sizes == [all_sizes[0], all_sizes[2], all_sizes[-1]]


def test_json_csv_writers_and_cli_exclude_their_outputs_for_idempotency(
    tmp_path: Path,
    capsys: object,
) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "order.csv").write_text("model,quantity\nA,1\n", encoding="utf-8")
    json_path = source / "catalog.json"
    csv_path = source / "catalog.csv"
    arguments = [
        str(source),
        "--json",
        str(json_path),
        "--csv",
        str(csv_path),
        "--sample-per-type",
        "1",
    ]

    assert main(arguments) == 0
    first_json = json_path.read_bytes()
    first_csv = csv_path.read_bytes()
    assert main(arguments) == 0
    assert json_path.read_bytes() == first_json
    assert csv_path.read_bytes() == first_csv
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    assert payload["statistics"]["physical_source_count"] == 1
    with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 1
    assert rows[0]["source_path"] == "order.csv"


def test_library_writers_are_stable_and_metadata_only_is_explicit(tmp_path: Path) -> None:
    source = tmp_path / "source.csv"
    source.write_text("model,quantity\nA,1\n", encoding="utf-8")
    manifest = scan_catalog(
        source,
        options=CatalogOptions(hash_files=False, sample_per_type=0),
    )
    json_path = tmp_path / "manifest.json"
    csv_path = tmp_path / "manifest.csv"

    assert manifest.records[0].sha256 is None
    assert manifest.scan_policy["hash_algorithm"] == "disabled"
    write_json_manifest(manifest, json_path)
    write_csv_manifest(manifest, csv_path)
    before = (json_path.read_bytes(), csv_path.read_bytes())
    write_json_manifest(manifest, json_path)
    write_csv_manifest(manifest, csv_path)
    assert (json_path.read_bytes(), csv_path.read_bytes()) == before
