from __future__ import annotations

import sys
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from pathlib import Path

import pytest
from m1.documents.adapters.docx import DOCXAdapterError, parse_docx_document
from m1.documents.adapters.pdf import (
    PDFAdapterError,
    _classify_pdf,
    _extract_pdf_header,
    _extract_pdf_lines,
    parse_pdf_document,
)
from m1.documents.adapters.pdf import _tables as pdf_tables
from m1.documents.adapters.pdf_drawing import build_pdf_drawing_record
from m1.documents.adapters.pdf_header_evidence import (
    PdfHeaderEvidenceIndex,
    positioned_labeled_value,
)
from m1.documents.adapters.pdf_order import _contextual_price_mapping
from m1.documents.models import DocumentRecord, DocumentTotals, OrderLine
from m1.documents.orders import enrich_order_line


def test_pdf_native_blocks_coordinates_and_independent_page_renders(tmp_path: Path) -> None:
    fitz = pytest.importorskip("fitz")
    source = tmp_path / "native.pdf"
    document = fitz.open()
    first = document.new_page(width=300, height=200)
    first.insert_text((30, 50), "DP FULLWIDTH TEST")
    second = document.new_page(width=400, height=250)
    second.insert_text((40, 70), "SECOND PAGE")
    document.save(source)
    document.close()

    record = parse_pdf_document(source, render_dir=tmp_path / "pages")

    assert isinstance(record, DocumentRecord)
    assert record.schema_version == "m1.document.v2"
    assert record.document_type == "unknown"
    assert record.document_subtype == "unknown"
    assert record.source.mime_type == "application/pdf"
    assert len(record.source.sha256) == 64
    extraction = record.extraction
    assert extraction["metadata"]["page_count"] == 2
    pages = extraction["raw_content"]["pages"]
    assert [page["page_number"] for page in pages] == [1, 2]
    assert "DP FULLWIDTH TEST" in pages[0]["text_original"]
    assert "SECOND PAGE" in pages[1]["text_original"]
    assert pages[0]["text_blocks"][0]["bbox"] != [0.0, 0.0, 0.0, 0.0]
    render_assets = [Path(page["render_asset"]) for page in pages]
    assert [asset.name for asset in render_assets] == ["page-0001.png", "page-0002.png"]
    assert all(asset.is_file() for asset in render_assets)
    assert render_assets[0] != render_assets[1]


def test_pdf_rejects_extension_only_masquerade(tmp_path: Path) -> None:
    source = tmp_path / "fake.pdf"
    source.write_bytes(b"not actually a pdf")
    with pytest.raises(PDFAdapterError, match="magic bytes"):
        parse_pdf_document(source)


def test_pdf_table_probe_restores_process_streams_under_concurrency() -> None:
    class TableResult:
        tables: list[object] = []

    class SlowPage:
        def __init__(self, delay: float) -> None:
            self.delay = delay

        def find_tables(self) -> TableResult:
            time.sleep(self.delay)
            return TableResult()

    original_stdout = sys.stdout
    original_stderr = sys.stderr
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(pdf_tables, SlowPage(0.05))
            time.sleep(0.01)
            second = pool.submit(pdf_tables, SlowPage(0.10))
            assert first.result() == []
            assert second.result() == []
        assert sys.stdout is original_stdout
        assert sys.stderr is original_stderr
    finally:
        # Preserve pytest's capture streams even if a regression reintroduces the
        # process-global redirect race and the assertions fail.
        sys.stdout = original_stdout
        sys.stderr = original_stderr


def _make_native_order_pdf(path: Path, *, title: str = "SUPPLIER PURCHASE ORDER") -> None:
    fitz = pytest.importorskip("fitz")
    document = fitz.open()
    page = document.new_page(width=620, height=420)
    page.insert_text((190, 35), title, fontsize=14)
    page.insert_text((40, 62), "ORDER NO: PO202607150001", fontsize=9)
    page.insert_text((250, 62), "ORDER DATE: 2026-07-15", fontsize=9)
    page.insert_text((40, 78), "SUPPLIER: ACME LIMITED", fontsize=9)
    page.insert_text((250, 78), "CURRENCY: USD", fontsize=9)

    x_positions = [35, 70, 155, 280, 335, 390, 470, 555, 605]
    top = 105
    row_height = 28
    rows = [
        ["No", "Model", "SPEC", "QTY", "UNIT", "Unit Price", "Amount", "Batch"],
        ["1", "DP-001", "DP 2.1 8K 2M", "10", "PCS", "2.50", "25.00", "A"],
        ["2", "HDMI-02", "HDMI 2.1 8K 3M", "5", "PCS", "3.00", "15.00", "B"],
        ["TOTAL", "", "", "15", "", "", "40.00", ""],
    ]
    bottom = top + len(rows) * row_height
    for x in x_positions:
        page.draw_line((x, top), (x, bottom), color=(0, 0, 0), width=0.7)
    for row_index in range(len(rows) + 1):
        y = top + row_index * row_height
        page.draw_line((x_positions[0], y), (x_positions[-1], y), color=(0, 0, 0), width=0.7)
    for row_index, row in enumerate(rows):
        baseline = top + row_index * row_height + 18
        for column, value in enumerate(row):
            page.insert_text((x_positions[column] + 3, baseline), value, fontsize=7)
    document.save(path)
    document.close()


def test_pdf_purchase_order_native_table_populates_v2_order(tmp_path: Path) -> None:
    source = tmp_path / "PO202607150001.pdf"
    _make_native_order_pdf(source)

    record = parse_pdf_document(source, render_pages=False)

    assert record.document_type == "order"
    assert record.document_subtype == "supplier_purchase_order"
    assert record.header.order_number == "PO202607150001"
    assert record.header.date_standard.isoformat() == "2026-07-15"
    assert record.header.supplier == "ACME LIMITED"
    assert record.header.currency == "USD"
    assert [line.model for line in record.lines] == ["DP-001", "HDMI-02"]
    assert [line.quantity for line in record.lines] == [10, 5]
    assert [line.amount_tax_excluded for line in record.lines] == [25, 15]
    assert all(line.name_normalized for line in record.lines)
    assert [line.custom_fields["Batch"] for line in record.lines] == ["A", "B"]
    assert record.totals.declared_quantity == 15
    assert record.totals.calculated_quantity == 15
    assert record.totals.quantity_matches is True
    assert record.totals.declared_amount == 40
    assert record.totals.calculated_amount == 40
    assert record.totals.amount_matches is True
    assert record.bom == [line.model_dump(mode="json") for line in record.lines]
    quantity_meta = record.field_meta["$.lines[0].quantity"]
    assert quantity_meta.source_refs[0].page == 1
    assert "table:0/row:1" in (quantity_meta.source_refs[0].part or "")
    assert not any(issue.severity == "error" for issue in record.validation_issues)


def test_pdf_public_adapter_is_deterministic_under_concurrency(tmp_path: Path) -> None:
    source = tmp_path / "PO202607150001.pdf"
    _make_native_order_pdf(source)

    def parse_payload() -> dict:
        return parse_pdf_document(source, render_pages=False).model_dump(mode="json")

    with ThreadPoolExecutor(max_workers=3) as pool:
        payloads = list(pool.map(lambda _: parse_payload(), range(3)))

    assert payloads[0] == payloads[1] == payloads[2]
    assert len(payloads[0]["lines"]) == 2


def test_pdf_facade_preserves_private_symbols_and_monkeypatch_hooks(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import m1.documents.adapters.pdf as pdf_adapter

    historical_symbols = {
        "PDFAdapterError",
        "PDFDependencyError",
        "_require_fitz",
        "_rect_list",
        "_span_payload",
        "_text_blocks",
        "_tables",
        "_page_images",
        "_rect_union_area",
        "_coverage_ratio",
        "_ocr_recommendation",
        "_asset_dir",
        "_header_key",
        "_match_order_header",
        "_table_header_mapping",
        "_has_order_table",
        "_classify_pdf",
        "_classification_hint",
        "_resolve_pdf_classification",
        "_pdf_ref",
        "_clean",
        "_number",
        "_set_line_value",
        "_sum_numbers",
        "_first_page_containing",
        "_is_known_header_boundary",
        "_is_identifier_candidate",
        "_is_date_candidate",
        "_is_non_label_candidate",
        "_clean_party_value",
        "_labeled_value",
        "_year_from_identifier",
        "_date_value",
        "_extract_pdf_header",
        "_extract_pdf_lines",
        "_validate_pdf_lines",
        "_build_pdf_order_record",
        "rebuild_pdf_document_after_ocr",
        "_parse_pdf_document_unlocked",
        "parse_pdf_document",
        "render_pdf_pages_for_ocr",
        "PDFDocumentAdapter",
    }
    assert historical_symbols <= set(vars(pdf_adapter))

    fitz = pytest.importorskip("fitz")
    source = tmp_path / "compatibility.pdf"
    document = fitz.open()
    document.new_page()
    document.save(source)
    document.close()

    monkeypatch.setattr(
        pdf_adapter,
        "_text_blocks",
        lambda _page: ([], "COMPATIBILITY MARKER"),
    )
    monkeypatch.setattr(
        pdf_adapter,
        "_classify_pdf",
        lambda _filename, _text, _pages=None: ("order", "customer_purchase_order"),
    )
    monkeypatch.setattr(
        pdf_adapter,
        "_extract_pdf_header",
        lambda _filename, _pages, _subtype, _field_meta, _issues: (
            pdf_adapter.DocumentHeader(order_number="MONKEYPATCHED")
        ),
    )
    monkeypatch.setattr(
        pdf_adapter,
        "_extract_pdf_lines",
        lambda _pages, _field_meta, _issues: ([], {}, {}),
    )

    record = pdf_adapter.parse_pdf_document(source, render_pages=False)

    assert record.header.order_number == "MONKEYPATCHED"
    assert (
        record.extraction["raw_content"]["pages"][0]["text_original"]
        == "COMPATIBILITY MARKER"
    )


def test_pdf_split_contract_label_becomes_order_identifier_and_date() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "采购合同\n合同编号\nPOORD009650\n2026/7/1",
            "tables": [],
        }
    ]
    field_meta = {}
    issues = []

    header = _extract_pdf_header(
        "采购合同.pdf",
        pages,
        "supplier_purchase_order",
        field_meta,
        issues,
    )

    assert header.contract_number == "POORD009650"
    assert header.order_number == "POORD009650"
    assert header.candidate_numbers[0].kind == "contract_number"
    assert header.date_standard is None
    assert field_meta["$.header.order_number"].inferred is True
    assert "ORDER_NUMBER_MISSING" not in {issue.code for issue in issues}


def test_pdf_identifier_semantics_and_po_ocr_variant_do_not_create_conflict() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "\n".join(
                [
                    "采购合同",
                    "合同编号",
                    "POORD000123",
                    "摘要:",
                    "PO-20990101-001",
                    "MODELO:MHD-4023",
                    "Y00000000001",
                    "结构化阅读顺序摘要:P020990101-001",
                ]
            ),
            "native_text_normalized": "\n".join(
                [
                    "采购合同",
                    "合同编号",
                    "POORD000123",
                    "摘要:",
                    "PO-20990101-001",
                ]
            ),
            "tables": [],
        }
    ]
    field_meta = {}
    issues = []

    header = _extract_pdf_header(
        "采购合同.pdf",
        pages,
        "purchase_contract",
        field_meta,
        issues,
    )

    assert header.order_number == "POORD000123"
    assert header.contract_number == "POORD000123"
    assert {
        candidate.value: candidate.kind for candidate in header.candidate_numbers
    } == {
        "PO-20990101-001": "order_number",
        "P020990101-001": "order_number",
        "POORD000123": "contract_number",
        "Y00000000001": "product_identifier",
    }
    assert sum(candidate.selected for candidate in header.candidate_numbers) == 1
    assert "ORDER_NUMBER_CONFLICT" not in {issue.code for issue in issues}


def test_pdf_grouped_party_labels_pair_values_without_role_reversal() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "采购合同",
            "tables": [
                {
                    "table_index": 0,
                    "rows_normalized": [
                        [
                            "甲方",
                            "乙方",
                            "甲方示例科技有限公司",
                            "乙方示例制造有限公司",
                        ]
                    ],
                }
            ],
        }
    ]

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", {}, []
    )

    assert header.buyer == "甲方示例科技有限公司"
    assert header.seller == "乙方示例制造有限公司"
    assert header.supplier == "乙方示例制造有限公司"


def test_pdf_positioned_line_splits_two_inline_party_roles() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "采购合同",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 2,
                    "lines": [
                        {
                            "text_normalized": (
                                "甲方：甲方示例科技有限公司"
                                "乙方：乙方示例制造有限公司"
                            ),
                            "bbox": [20.0, 40.0, 560.0, 62.0],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.buyer == "甲方示例科技有限公司"
    assert header.seller == "乙方示例制造有限公司"
    assert header.supplier == "乙方示例制造有限公司"
    assert field_meta["$.header.buyer"].source_refs[0].model_extra["bbox"] == [
        20.0,
        40.0,
        560.0,
        62.0,
    ]


def test_pdf_party_roles_follow_visual_columns_not_block_membership() -> None:
    def block(index: int, lines: list[tuple[str, list[float]]]) -> dict:
        return {
            "block_index": index,
            "lines": [
                {
                    "text_normalized": text,
                    "bbox": bbox,
                    "spans": [{"text_normalized": text, "bbox": bbox}],
                }
                for text, bbox in lines
            ],
        }

    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": "采购合同",
            "tables": [],
            "text_blocks": [
                block(4, [("乙方:", [321.0, 124.8, 366.0, 136.0])]),
                block(
                    5,
                    [
                        (
                            "甲方示例电子有限公司",
                            [92.25, 130.0, 227.25, 141.3],
                        )
                    ],
                ),
                block(
                    6,
                    [
                        ("甲方:", [44.25, 130.0, 89.25, 141.3]),
                        (
                            "乙方示例线缆有限公司",
                            [387.0, 124.8, 499.5, 136.0],
                        ),
                    ],
                ),
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.buyer == "甲方示例电子有限公司"
    assert header.seller == "乙方示例线缆有限公司"
    assert header.supplier == "乙方示例线缆有限公司"
    assert field_meta["$.header.buyer"].source_refs[0].model_extra["bbox"] == [
        92.25,
        130.0,
        227.25,
        141.3,
    ]
    assert field_meta["$.header.seller"].source_refs[0].model_extra["bbox"] == [
        387.0,
        124.8,
        499.5,
        136.0,
    ]


def test_pdf_party_name_split_across_spans_is_reassembled() -> None:
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": "采购合同\n甲方: 甲方示例电子科技有限公司",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": "甲方:",
                            "bbox": [10.0, 10.0, 180.0, 20.0],
                            "spans": [
                                {"text_normalized": "甲方:", "bbox": [10, 10, 40, 20]},
                                {
                                    "text_normalized": "甲方示例",
                                    "bbox": [42, 10, 90, 20],
                                },
                                {
                                    "text_normalized": "电子科技有限公司",
                                    "bbox": [91, 10, 180, 20],
                                },
                            ],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.buyer == "甲方示例电子科技有限公司"
    assert field_meta["$.header.buyer"].confidence == 1.0


def test_pdf_company_candidate_outranks_nearby_contact_name() -> None:
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": "采购合同",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": "甲方:",
                            "bbox": [10, 10, 40, 20],
                            "spans": [{"text_normalized": "甲方:", "bbox": [10, 10, 40, 20]}],
                        },
                        {
                            "text_normalized": "张三",
                            "bbox": [42, 10, 60, 20],
                            "spans": [{"text_normalized": "张三", "bbox": [42, 10, 60, 20]}],
                        },
                        {
                            "text_normalized": "甲方示例电子有限公司",
                            "bbox": [100, 10, 220, 20],
                            "spans": [
                                {
                                    "text_normalized": "甲方示例电子有限公司",
                                    "bbox": [100, 10, 220, 20],
                                }
                            ],
                        },
                    ],
                }
            ],
        }
    ]

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", {}, []
    )

    assert header.buyer == "甲方示例电子有限公司"


def test_pdf_supplier_before_order_number_is_clean_and_aliased_to_seller() -> None:
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": (
                "采购合同\n供应商:供应商示例电子有限公司    "
                "订单号码:PO-20990101-002"
            ),
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 3,
                    "lines": [
                        {
                            "text_normalized": (
                                "供应商:供应商示例电子有限公司    "
                                "订单号码:PO-20990101-002"
                            ),
                            "bbox": [19.5, 94.1, 328.6, 102.9],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "定制单.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.order_number == "PO-20990101-002"
    assert header.supplier == "供应商示例电子有限公司"
    assert header.seller == "供应商示例电子有限公司"
    assert field_meta["$.header.supplier"].source_refs
    assert field_meta["$.header.seller"].source_refs
    assert field_meta["$.header.seller"].inferred is True


def test_pdf_ambiguous_flat_party_order_fails_closed() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "\n".join(
                [
                    "采购合同",
                    "甲方:",
                    "乙方:",
                    "乙方示例制造有限公司",
                    "甲方示例科技有限公司",
                ]
            ),
            "tables": [],
        }
    ]

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", {}, []
    )

    assert header.buyer is None
    assert header.seller is None
    assert header.supplier is None


def test_pdf_delivery_date_label_is_not_reused_as_order_date() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "采购合同\n交货日期：2026-08-01",
            "tables": [],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.date_raw is None
    assert header.date_standard is None
    assert header.delivery_date_raw == "2026-08-01"
    assert header.delivery_date_standard.isoformat() == "2026-08-01"
    assert "$.header.date_raw" not in field_meta
    assert field_meta["$.header.delivery_date_raw"].source_refs


@pytest.mark.parametrize(
    ("label", "expected_delivery"),
    [
        ("DELIVERY DATE", True),
        ("DELIVERY-DATE", True),
        ("SHIP DATE", True),
        ("SHIP-DATE", True),
        ("DUE-DATE", True),
        ("EST.DATE", False),
    ],
)
def test_pdf_qualified_english_date_is_not_reused_as_order_date(
    label: str, expected_delivery: bool
) -> None:
    line = f"{label}: 2026-08-01"
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": f"PURCHASE ORDER\n{line}",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": line,
                            "bbox": [20.0, 30.0, 220.0, 42.0],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "purchase-order.pdf", pages, "supplier_purchase_order", field_meta, []
    )

    assert header.date_raw is None
    assert header.date_standard is None
    assert "$.header.date_raw" not in field_meta
    if expected_delivery:
        assert header.delivery_date_raw == "2026-08-01"
    else:
        assert header.delivery_date_raw is None


def test_pdf_standalone_english_date_is_the_order_date() -> None:
    line = "DATE: 2026-08-01"
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": f"PURCHASE ORDER\n{line}",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": line,
                            "bbox": [20.0, 30.0, 220.0, 42.0],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "purchase-order.pdf", pages, "supplier_purchase_order", field_meta, []
    )

    assert header.date_raw == "2026-08-01"
    assert header.date_standard.isoformat() == "2026-08-01"
    assert header.delivery_date_raw is None
    assert field_meta["$.header.date_raw"].source_refs
    assert "$.header.delivery_date_raw" not in field_meta


@pytest.mark.parametrize("order_number", ["PO-123", "AB-12-CD"])
def test_pdf_positioned_explicit_order_number_accepts_short_segmented_values(
    order_number: str,
) -> None:
    line = f"PO NO: {order_number}"
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_normalized": f"PURCHASE ORDER\n{line}",
            "tables": [],
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": line,
                            "bbox": [20.0, 30.0, 180.0, 42.0],
                        }
                    ],
                }
            ],
        }
    ]
    field_meta = {}
    issues = []

    header = _extract_pdf_header(
        "purchase-order.pdf",
        pages,
        "supplier_purchase_order",
        field_meta,
        issues,
    )

    assert header.order_number == order_number
    selected = [candidate for candidate in header.candidate_numbers if candidate.selected]
    assert [candidate.value for candidate in selected] == [order_number]
    assert selected[0].kind == "order_number"
    assert field_meta["$.header.order_number"].source_refs[0].model_extra["bbox"] == [
        20.0,
        30.0,
        180.0,
        42.0,
    ]
    assert "ORDER_NUMBER_MISSING" not in {issue.code for issue in issues}


def test_pdf_scalar_headers_follow_visual_pairs_and_keep_bbox_evidence() -> None:
    def block(index: int, text: str, bbox: list[float]) -> dict:
        return {
            "block_index": index,
            "lines": [
                {
                    "text_normalized": text,
                    "bbox": bbox,
                    "spans": [{"text_normalized": text, "bbox": bbox}],
                }
            ],
        }

    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            # The flat stream groups labels before values and cannot safely
            # express which identifier/date belongs to which label.
            "text_normalized": "\n".join(
                [
                    "采购订单",
                    "合同编号:",
                    "订单编号:",
                    "下单日期:",
                    "交货日期:",
                    "PO-20990101-003",
                    "2026-07-22",
                    "POORD000789",
                    "2026-08-05",
                ]
            ),
            "tables": [],
            "text_blocks": [
                block(1, "合同编号:", [20.0, 20.0, 80.0, 30.0]),
                block(2, "POORD000789", [90.0, 20.0, 180.0, 30.0]),
                block(3, "订单编号:", [280.0, 20.0, 340.0, 30.0]),
                block(4, "PO-20990101-003", [350.0, 20.0, 470.0, 30.0]),
                block(5, "下单日期:", [20.0, 45.0, 80.0, 55.0]),
                block(6, "2026-07-22", [90.0, 45.0, 170.0, 55.0]),
                block(7, "交货日期:", [280.0, 45.0, 340.0, 55.0]),
                block(8, "2026-08-05", [350.0, 45.0, 430.0, 55.0]),
            ],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购订单.pdf", pages, "supplier_purchase_order", field_meta, []
    )

    assert header.contract_number == "POORD000789"
    assert header.order_number == "PO-20990101-003"
    assert header.date_raw == "2026-07-22"
    assert header.delivery_date_raw == "2026-08-05"
    expected_value_boxes = {
        "$.header.contract_number": [90.0, 20.0, 180.0, 30.0],
        "$.header.order_number": [350.0, 20.0, 470.0, 30.0],
        "$.header.date_raw": [90.0, 45.0, 170.0, 55.0],
        "$.header.date_standard": [90.0, 45.0, 170.0, 55.0],
        "$.header.delivery_date_raw": [350.0, 45.0, 430.0, 55.0],
        "$.header.delivery_date_standard": [350.0, 45.0, 430.0, 55.0],
    }
    for path, bbox in expected_value_boxes.items():
        value_ref = field_meta[path].source_refs[0]
        assert value_ref.model_extra["bbox"] == bbox
        assert value_ref.model_extra["coordinate_space"] == "pdf_points"


def test_pdf_positioned_value_does_not_pair_across_coordinate_spaces() -> None:
    pages = [
        {
            "page_number": 1,
            "coordinate_space": "pdf_points",
            "text_blocks": [
                {
                    "block_index": 0,
                    "lines": [
                        {
                            "text_normalized": "ORDER NO:",
                            "bbox": [20.0, 100.0, 80.0, 110.0],
                        },
                        {
                            "text_normalized": "CORRECT-123",
                            "bbox": [260.0, 100.0, 340.0, 110.0],
                        },
                    ],
                }
            ],
            "ocr_lines": [
                {
                    "text_normalized": "WRONG-999",
                    "bbox": [81.0, 100.0, 150.0, 110.0],
                    "coordinate_space": "image_pixels",
                }
            ],
        }
    ]

    result = positioned_labeled_value(
        PdfHeaderEvidenceIndex.from_pages(pages),
        r"ORDER\s*NO",
    )

    assert result is not None
    value, refs, _ = result
    assert value == "CORRECT-123"
    assert {ref.model_extra["coordinate_space"] for ref in refs} == {"pdf_points"}


def test_pdf_scalar_headers_keep_flat_reading_order_fallback() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "\n".join(
                [
                    "采购订单",
                    "合同编号:",
                    "POORD000789",
                    "订单编号:",
                    "PO-20990101-003",
                    "下单日期:",
                    "2026-07-22",
                    "交货日期:",
                    "2026-08-05",
                ]
            ),
            "tables": [],
        }
    ]
    field_meta = {}

    header = _extract_pdf_header(
        "采购订单.pdf", pages, "supplier_purchase_order", field_meta, []
    )

    assert header.contract_number == "POORD000789"
    assert header.order_number == "PO-20990101-003"
    assert header.date_raw == "2026-07-22"
    assert header.delivery_date_raw == "2026-08-05"
    for path in (
        "$.header.contract_number",
        "$.header.order_number",
        "$.header.date_raw",
        "$.header.delivery_date_raw",
    ):
        assert field_meta[path].source_refs
        assert field_meta[path].source_refs[0].page == 1
        assert field_meta[path].source_refs[0].part.endswith("/reading_order")


def test_derived_order_name_preserves_complete_observed_description() -> None:
    observed = (
        "DP2.1光纤线8K 60Hz 黑色铝合金外壳，支持HDR和多声道音频，"
        "零售彩盒包装并附带安装说明"
    )
    line = OrderLine(
        line_id="line:1",
        model="W-H999",
        name_raw=observed,
        specification_raw="3M",
    )

    enrich_order_line(line)

    assert line.name_raw == observed
    normalized_observed = observed.replace("，", ",")
    assert normalized_observed in (line.name_normalized or "")
    assert normalized_observed in (line.full_product_name or "")
    assert "3M" in (line.name_normalized or "")


def test_document_totals_match_aliases_cannot_disagree() -> None:
    totals = DocumentTotals(
        amount_matches=False,
        matches={"amount": True, "quantity": True},
    )

    assert totals.amount_matches is False
    assert totals.matches["amount"] is False
    assert totals.quantity_matches is True


def test_pdf_blank_contract_fields_do_not_absorb_following_labels() -> None:
    pages = [
        {
            "page_number": 1,
            "text_normalized": "\n".join(
                [
                    "采购合同",
                    "合同编号",
                    "下单日期",
                    "乙  方:",
                    "甲  方:广西桐曦电子科技有限公司",
                    "交货日期",
                    "序",
                    "号",
                    "物料编码",
                    "付款方式:",
                    "此单价含税率:",
                ]
            ),
            "tables": [],
        }
    ]
    field_meta = {}
    issues = []

    header = _extract_pdf_header(
        "采购函.pdf",
        pages,
        "purchase_contract",
        field_meta,
        issues,
    )

    assert header.contract_number is None
    assert header.order_number is None
    assert header.date_raw is None
    assert header.delivery_date_raw is None
    assert header.buyer == "广西桐曦电子科技有限公司"
    assert header.issuer == "广西桐曦电子科技有限公司"
    assert header.seller is None
    assert header.supplier is None
    assert header.settlement_method is None
    assert "ORDER_NUMBER_MISSING" in {issue.code for issue in issues}


def test_pdf_ambiguous_price_columns_follow_explicit_tax_context() -> None:
    mapping = {
        "unit_price_tax_excluded": (4, "单价"),
        "amount_tax_excluded": (5, "金额"),
    }

    included = _contextual_price_mapping(
        [{"text_normalized": "采购合同\n此单价含税率：10%"}],
        mapping,
    )
    ambiguous = _contextual_price_mapping(
        [{"text_normalized": "采购合同\n税率：10%"}],
        mapping,
    )

    assert set(included) == {
        "unit_price_tax_included",
        "amount_tax_included",
    }
    assert ambiguous == mapping


def test_pdf_purchase_contract_has_distinct_subtype() -> None:
    assert _classify_pdf("采购函.pdf", "采购合同") == (
        "order",
        "purchase_contract",
    )


def test_pdf_explicit_subtype_hint_overrides_detected_order_subtype(
    tmp_path: Path,
) -> None:
    source = tmp_path / "PO202607150001.pdf"
    _make_native_order_pdf(source)

    record = parse_pdf_document(
        source,
        document_subtype_hint="purchase_contract",
        render_pages=False,
    )

    assert record.document_type == "order"
    assert record.document_subtype == "purchase_contract"
    classification = record.extraction["metadata"]["classification"]
    assert classification["detected_document_subtype"] == "supplier_purchase_order"
    assert classification["hinted_document_subtype"] == "purchase_contract"
    assert classification["resolved_document_subtype"] == "purchase_contract"
    assert "DOCUMENT_SUBTYPE_HINT_CONFLICT" in {
        issue.code for issue in record.validation_issues
    }


def test_pdf_merged_total_row_is_not_promoted_to_product_line() -> None:
    rows = [
        ["序号", "物料编码", "物料名称", "规格型号", "单位", "数量", "单价", "合计金额", "备注"],
        ["1", "YA.G.05.194", "DP 光纤彩盒", "MCB-8005", "PCS", "1200", "1.85", "2,220.00", ""],
        ["2", "YA.G.05.195", "DP 光纤彩盒", "MCB-8015", "PCS", "2304", "1.85", "4,262.40", ""],
        ["合 计 金 额:", None, "￥6,482.40", None, None, None, None, None, None],
    ]
    pages = [
        {
            "page_number": 1,
            "tables": [{"table_index": 0, "rows_normalized": rows}],
        }
    ]
    field_meta = {}
    issues = []

    lines, declared, declared_refs = _extract_pdf_lines(pages, field_meta, issues)

    assert len(lines) == 2
    assert [line.product_code for line in lines] == ["YA.G.05.194", "YA.G.05.195"]
    assert declared["amount"] == Decimal("6482.40")
    assert declared_refs["amount"].part == "table:0/row:3/column:2"
    assert not issues


@pytest.mark.parametrize(
    ("content", "expected_subtype"),
    [
        ("PRODUCT SPECIFICATION", "product_specification"),
        ("APPROVAL DRAWING", "approval_drawing"),
        ("PROCESS DOCUMENT", "process_document"),
    ],
)
def test_pdf_native_text_classifies_non_order_technical_documents(
    tmp_path: Path, content: str, expected_subtype: str
) -> None:
    fitz = pytest.importorskip("fitz")
    source = tmp_path / f"{expected_subtype}.pdf"
    document = fitz.open()
    page = document.new_page()
    page.insert_text((50, 70), content)
    document.save(source)
    document.close()

    record = parse_pdf_document(source, render_pages=False)

    assert record.document_type == "technical_document"
    assert record.document_subtype == expected_subtype
    assert record.lines == []


def test_pdf_laser_marking_layout_classifies_as_approval_drawing() -> None:
    from m1.documents.adapters.pdf import _classify_pdf

    assert _classify_pdf(
        "HAM-H919.pdf",
        "壳子镭雕：DP 2.1 视频高清线\n正面\n反面\n示图",
    ) == ("technical_document", "approval_drawing")


def test_pdf_engineering_title_block_classifies_without_drawing_filename() -> None:
    text = """
    USB TYPE-C CABLE ASSEMBLY
    DRAWING NUMBER DWG-CBL-001
    DRAWN BY TEST
    REVISION HISTORY
    ITEM | PART NUMBER | QTY | SPECIFICATION DESCRIPTION
    GENERAL TOLERANCE
    """

    assert _classify_pdf("cable.pdf", text) == (
        "technical_document",
        "approval_drawing",
    )
    assert _classify_pdf(
        "ordinary.pdf", "Version A / Unit mm / Date 2026-07-19"
    ) == ("unknown", "unknown")


def test_pdf_drawing_builder_projects_title_bom_requirements_and_sources() -> None:
    def block(index: int, text: str) -> dict:
        return {
            "text_original": text,
            "bbox": [10.0 + index, 20.0, 200.0 + index, 60.0],
            "coordinate_space": "pdf_points",
        }

    rows = [
        ["DRAWING NUMBER DWG-CBL-001", "PRODUCT NAME USB TYPE-C CABLE ASSEMBLY"],
        ["PART NUMBER CBL-001", "CUSTOMER P/N CUST-001"],
        ["CUSTOMER CODE EXAMPLE-01", "REVISION A"],
        ["UNIT", "mm"],
        ["PAGE", "1 of 1"],
    ]
    pages = [
        {
            "page_number": 1,
            "page_index": 0,
            "text_original": "\n".join(value for row in rows for value in row),
            "text_normalized": "\n".join(value for row in rows for value in row),
            "text_blocks": [
                block(0, "Example Cable Co., Ltd."),
                block(1, "DRAWN BY TEST DATE 2026-07-19"),
                block(2, "1\nRAW-001\n160mm\nCable bulk material"),
                block(3, "2\nCONN-002\n2pcs\nType-C connector"),
                block(4, "TEST REQUIREMENTS: 100% continuity test"),
            ],
            "tables": [
                {
                    "table_index": 0,
                    "rows_normalized": rows,
                    "cell_bbox_matrix": [
                        [[0.0, row * 20.0, 100.0, row * 20.0 + 20.0],
                         [100.0, row * 20.0, 300.0, row * 20.0 + 20.0]]
                        for row in range(len(rows))
                    ],
                }
            ],
        }
    ]
    record = build_pdf_drawing_record(
        source={
            "original_filename": "cable.pdf",
            "display_filename": "cable.pdf",
            "sha256": "a" * 64,
            "mime_type": "application/pdf",
        },
        pages=pages,
        sections=[],
        original_text=pages[0]["text_original"],
        metadata={"adapter": "synthetic"},
    )

    assert record.document_type == "technical_document"
    assert record.document_subtype == "approval_drawing"
    assert record.header.title == "USB TYPE-C CABLE ASSEMBLY"
    assert record.header.drawing_number == "DWG-CBL-001"
    assert record.header.material_number == "CBL-001"
    assert record.header.customer_material_number == "CUST-001"
    assert record.header.customer_code == "EXAMPLE-01"
    assert record.header.issuer == "Example Cable Co., Ltd."
    assert [(line.product_code, line.quantity, line.unit) for line in record.lines] == [
        ("RAW-001", 160, "mm"),
        ("CONN-002", 2, "pcs"),
    ]
    assert record.technical_requirements == "TEST REQUIREMENTS: 100% continuity test"
    assert record.needs_review is False
    assert record.validation_issues == []
    title_ref = record.field_meta["$.header.title"].source_refs[0]
    line_ref = record.field_meta["$.lines[0].product_code"].source_refs[0]
    assert title_ref.page == line_ref.page == 1
    assert title_ref.model_extra["bbox"] != [0.0, 0.0, 0.0, 0.0]
    assert line_ref.model_extra["bbox"] != [0.0, 0.0, 0.0, 0.0]

    rows[0][0] = "DRAWING NUMBER /"
    pages[0]["ocr_lines"] = [
        {
            "text_original": "<table><td>DRAWING NUMBER /</td><td>ITEM</td></table>",
            "bbox": [0.0, 0.0, 300.0, 100.0],
        }
    ]
    placeholder = build_pdf_drawing_record(
        source=record.source.model_dump(mode="json"),
        pages=pages,
        sections=[],
        original_text=pages[0]["text_original"],
        metadata={"adapter": "synthetic"},
    )
    assert placeholder.header.drawing_number is None
    assert "DRAWING_NUMBER_MISSING" in {
        issue.code for issue in placeholder.validation_issues
    }


def test_pdf_drawing_table_bom_keeps_field_specific_cell_sources() -> None:
    rows = [
        ["DRAWING NUMBER DWG-002", "PRODUCT NAME USB cable", None, None],
        ["ITEM", "PART NUMBER", "QTY", "DESCRIPTION"],
        ["1", "RAW-001", "160mm", "Cable bulk material"],
    ]
    pages = [
        {
            "page_number": 1,
            "text_blocks": [],
            "tables": [
                {
                    "table_index": 7,
                    "rows_normalized": rows,
                    "cell_bbox_matrix": [
                        [
                            [column * 100.0, row * 20.0, (column + 1) * 100.0, (row + 1) * 20.0]
                            for column in range(4)
                        ]
                        for row in range(3)
                    ],
                }
            ],
        }
    ]
    record = build_pdf_drawing_record(
        source={
            "original_filename": "drawing.pdf",
            "sha256": "b" * 64,
            "mime_type": "application/pdf",
        },
        pages=pages,
        sections=[],
        original_text="\n".join(value or "" for row in rows for value in row),
        metadata={"adapter": "synthetic-table"},
    )

    code_ref = record.field_meta["$.lines[0].product_code"].source_refs[0]
    quantity_ref = record.field_meta["$.lines[0].quantity"].source_refs[0]
    description_ref = record.field_meta["$.lines[0].name_raw"].source_refs[0]
    assert code_ref.part == "table:7/row:2/column:1"
    assert quantity_ref.part == "table:7/row:2/column:2"
    assert description_ref.part == "table:7/row:2/column:3"
    assert len(
        {
            tuple(code_ref.model_extra["bbox"]),
            tuple(quantity_ref.model_extra["bbox"]),
            tuple(description_ref.model_extra["bbox"]),
        }
    ) == 3


def _make_docx(path: Path, image_path: Path) -> None:
    docx = pytest.importorskip("docx")
    from docx.oxml import parse_xml

    document = docx.Document()
    document.add_heading("产品承认书", level=1)
    document.add_paragraph("正文 DP ８Ｋ")
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "型号"
    table.cell(0, 1).text = "数量"
    table.cell(1, 0).text = "DP-001"
    table.cell(1, 1).text = "１２"
    document.add_picture(str(image_path))
    textbox = parse_xml(
        """
        <w:p xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
             xmlns:v="urn:schemas-microsoft-com:vml">
          <w:r><w:pict><v:shape><v:textbox><w:txbxContent>
            <w:p><w:r><w:t>文本框工艺要求</w:t></w:r></w:p>
          </w:txbxContent></v:textbox></v:shape></w:pict></w:r>
        </w:p>
        """
    )
    document._body._element.append(textbox)
    document.save(path)


def test_docx_extracts_ordered_body_tables_textboxes_and_images(tmp_path: Path) -> None:
    image_module = pytest.importorskip("PIL.Image")
    image_path = tmp_path / "product.png"
    image_module.new("RGB", (8, 8), "red").save(image_path)
    source = tmp_path / "产品承认书.docx"
    _make_docx(source, image_path)

    record = parse_docx_document(source, assets_dir=tmp_path / "images")

    assert isinstance(record, DocumentRecord)
    assert record.document_subtype == "approval_drawing"
    raw = record.extraction["raw_content"]
    assert "正文 DP 8K" in raw["text_normalized"]
    assert raw["tables"][0]["rows"][1][0]["text_original"] == "DP-001"
    assert raw["tables"][0]["rows"][1][1]["text_normalized"] == "12"
    assert raw["textboxes"][0]["text_original"] == "文本框工艺要求"
    assert len(raw["images"]) == 1
    assert Path(raw["images"][0]["asset_path"]).is_file()
    assert raw["images"][0]["relationship_id"].startswith("rId")
    kinds = [section["kind"] for section in record.extraction["sections"]]
    assert "paragraph" in kinds and "table" in kinds
    assert record.extraction["metadata"]["adapter"] == "python-docx+ooxml"


def test_docx_rejects_generic_zip(tmp_path: Path) -> None:
    source = tmp_path / "fake.docx"
    with zipfile.ZipFile(source, "w") as package:
        package.writestr("hello.txt", "hello")
    with pytest.raises(DOCXAdapterError, match="not a Word document"):
        parse_docx_document(source)
