from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

import pytest
from m1.documents.parsing.document_classification_routing import (
    DocumentClassificationModelChoice,
    DocumentClassificationRoutingRuntime,
)
from m1.documents.parsing.document_route_lifecycle import default_signature_builder
from m1.documents.parsing.document_route_policy import (
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidencePage,
)
from m1.knowledge.db_models_base import KNOWLEDGE_EMBEDDING_DIMENSIONS
from m1.knowledge.routing_schema import (
    RouteProfileMatch,
    RouteProfileRecord,
    RouteProfileStatus,
)


def _evidence(*, labels: tuple[str, ...] = ("order_number", "quantity")):
    return DocumentEvidence(
        backend="test",
        backend_version="v1",
        semantic_labels=labels,
        raw={"filename": "secret-order.pdf", "body": "SECRET-SO-1001"},
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id="title-1",
                        kind="title",
                        text="SECRET-SO-1001",
                    )
                ],
            )
        ],
    )


def _policy() -> RouteProfilePolicy:
    return RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        document_subtype_hint=RouteDocumentSubtype.PURCHASE_CONTRACT,
    )


def _profile(
    tenant_id: str,
    evidence: DocumentEvidence,
    *,
    embedding: list[float] | None = None,
) -> RouteProfileRecord:
    signature = default_signature_builder(evidence, "pdf")
    now = datetime.now(UTC)
    return RouteProfileRecord(
        profile_id=f"profile-{tenant_id}",
        tenant_id=tenant_id,
        profile_key=f"key-{tenant_id}",
        version=1,
        status=RouteProfileStatus.ACTIVE,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        embedding=embedding,
        embedding_model="test-embedding" if embedding is not None else "",
        embedding_dimensions=(len(embedding) if embedding is not None else 0),
        policy=_policy().model_dump(mode="json"),
        created_by="test",
        approved_by="reviewer",
        approved_at=now,
    )


class Store:
    def __init__(self, *, exact=None, matches=None):
        self.exact = exact
        self.matches = list(matches or [])
        self.tenants: list[str] = []

    async def get_active_route_profile_by_fingerprint(self, tenant_id, _fingerprint):
        self.tenants.append(tenant_id)
        return self.exact

    async def find_route_profiles(self, tenant_id, _embedding, **_kwargs):
        self.tenants.append(tenant_id)
        return list(self.matches)


class Observer:
    def __init__(self):
        self.calls: list[dict[str, Any]] = []

    async def observe_candidate(self, **kwargs):
        self.calls.append(kwargs)
        signature = kwargs["signature"]
        policy = kwargs["policy"]
        embedding = kwargs.get("embedding")
        return RouteProfileRecord(
            profile_id="new-inactive-candidate",
            tenant_id=kwargs["tenant_id"],
            profile_key="new-inactive-key",
            version=1,
            status=RouteProfileStatus.CANDIDATE,
            exact_fingerprint=signature.exact_fingerprint(),
            signature=signature,
            embedding=embedding,
            embedding_model="test-embedding" if embedding is not None else "",
            embedding_dimensions=(len(embedding) if embedding is not None else 0),
            policy=policy.model_dump(mode="json"),
            created_by="test",
        )


class Embeddings:
    model = "test-embedding"
    dimensions = KNOWLEDGE_EMBEDDING_DIMENSIONS

    def __init__(self):
        self.inputs: list[str] = []

    async def embed_texts(self, texts):
        self.inputs.extend(texts)
        vector = [0.0] * self.dimensions
        vector[0] = 1.0
        return [vector for _ in texts]


class Selector:
    def __init__(self, choice=None, *, failure: bool = False):
        self.choice = choice or DocumentClassificationModelChoice(
            action="candidate",
            candidate_index=0,
            confidence=0.95,
        )
        self.failure = failure
        self.requests = []

    async def select(self, request):
        self.requests.append(request)
        if self.failure:
            raise TimeoutError("model timeout")
        return self.choice


@pytest.mark.asyncio
async def test_no_candidate_creates_only_inactive_generic_profile() -> None:
    store = Store()
    observer = Observer()
    selector = Selector()
    runtime = DocumentClassificationRoutingRuntime(
        store=store,
        observer=observer,
        embedding_provider=None,
        selector=selector,
    )

    decision = await runtime.resolve(
        "tenant-a",
        "task-a",
        _evidence(),
        "pdf",
        current_document_type="unknown",
        current_document_subtype="unknown",
    )

    assert decision.action == "new_candidate"
    assert decision.candidate_profile_id == "new-inactive-candidate"
    assert selector.requests == []
    assert observer.calls[0]["tenant_id"] == "tenant-a"
    assert observer.calls[0]["policy"].schema_family is RouteSchemaFamily.GENERIC_LAYOUT


@pytest.mark.asyncio
async def test_exact_active_profile_is_advisory_until_mapper_replay() -> None:
    evidence = _evidence()
    profile = _profile("tenant-a", evidence)
    store = Store(exact=profile)
    selector = Selector()
    runtime = DocumentClassificationRoutingRuntime(
        store=store,
        observer=Observer(),
        embedding_provider=None,
        selector=selector,
    )

    decision = await runtime.resolve("tenant-a", "task-a", evidence, "pdf")
    result = runtime.apply(
        {
            "document_type": "unknown",
            "document_subtype": "unknown",
            "field_meta": {},
            "extraction": {"metadata": {}},
        },
        decision,
        evidence,
    )

    assert decision.action == "candidate"
    assert decision.reason == "exact_active_profile"
    assert selector.requests == []
    assert store.tenants == ["tenant-a"]
    assert result["document_type"] == "unknown"
    assert result["document_subtype"] == "unknown"
    routing = result["extraction"]["metadata"]["classification_routing"]
    assert routing["application_status"] == "mapper_replay_required"
    assert routing["applied_fields"] == []
    assert routing["advisory_fields"] == ["document_type", "document_subtype"]
    assert result["validation_issues"][0]["code"] == (
        "DOCUMENT_CLASSIFICATION_ROUTE_REMAP_REQUIRED"
    )
    assert result["needs_review"] is True


@pytest.mark.asyncio
async def test_explicit_subtype_hint_overrides_parser_and_never_queries_store() -> None:
    store = Store()
    runtime = DocumentClassificationRoutingRuntime(
        store=store,
        observer=Observer(),
        embedding_provider=None,
        selector=Selector(),
    )
    evidence = _evidence()

    decision = await runtime.resolve(
        "tenant-a",
        "task-a",
        evidence,
        "pdf",
        current_document_type="technical_document",
        current_document_subtype="approval_drawing",
        document_subtype_hint="purchase_contract",
    )
    result = runtime.apply(
        {
            "document_type": "technical_document",
            "document_subtype": "approval_drawing",
        },
        decision,
        evidence,
    )

    assert decision.action == "explicit_hint"
    assert result["document_type"] == "order"
    assert result["document_subtype"] == "purchase_contract"
    assert result["field_meta"]["$.document_type"]["manual_locked"] is True
    assert store.tenants == []


@pytest.mark.asyncio
async def test_ambiguous_active_candidate_uses_value_free_closed_selector() -> None:
    evidence = _evidence()
    vector = [0.0] * KNOWLEDGE_EMBEDDING_DIMENSIONS
    vector[0] = 1.0
    similar = _profile(
        "tenant-a",
        _evidence(labels=("order_number", "quantity", "unit")),
        embedding=vector,
    )
    store = Store(matches=[RouteProfileMatch(profile=similar, similarity=1.0)])
    selector = Selector()
    embeddings = Embeddings()
    runtime = DocumentClassificationRoutingRuntime(
        store=store,
        observer=Observer(),
        embedding_provider=embeddings,
        selector=selector,
        auto_min_score=0.95,
        model_min_score=0.70,
        min_margin=0.05,
    )

    decision = await runtime.resolve("tenant-a", "task-a", evidence, "pdf")

    assert decision.action == "candidate"
    assert decision.model_used is True
    payload = json.dumps(selector.requests[0].model_dump(mode="json"))
    assert "tenant-a" not in payload
    assert "task-a" not in payload
    assert "secret-order.pdf" not in payload
    assert "SECRET-SO-1001" not in payload
    assert "profile-tenant-a" not in payload


@pytest.mark.asyncio
async def test_model_failure_returns_review_without_mutating_known_fact() -> None:
    evidence = _evidence()
    vector = [0.0] * KNOWLEDGE_EMBEDDING_DIMENSIONS
    vector[0] = 1.0
    similar = _profile(
        "tenant-a",
        _evidence(labels=("order_number", "quantity", "unit")),
        embedding=vector,
    )
    runtime = DocumentClassificationRoutingRuntime(
        store=Store(matches=[RouteProfileMatch(profile=similar, similarity=1.0)]),
        observer=Observer(),
        embedding_provider=Embeddings(),
        selector=Selector(failure=True),
        auto_min_score=0.95,
        model_min_score=0.70,
    )

    decision = await runtime.resolve(
        "tenant-a",
        "task-a",
        evidence,
        "pdf",
        current_document_type="order",
        current_document_subtype="unknown",
    )
    result = runtime.apply(
        {"document_type": "order", "document_subtype": "unknown"},
        decision,
        evidence,
    )

    assert decision.action == "review"
    assert decision.reason == "model_failure"
    assert result["document_type"] == "order"
    assert result["document_subtype"] == "unknown"
    assert result["needs_review"] is True
