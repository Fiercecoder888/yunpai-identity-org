from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest
from m1.knowledge import KnowledgeStore, TenantRecord
from m1.knowledge.db_models import DocumentIdentityDecisionRow
from m1.knowledge.schema import LifecycleStatus
from sqlalchemy import select


def _document(
    digest: str,
    *,
    filename: str = "order.xlsx",
    order_number: str = "SO-1001",
    source_extra: dict | None = None,
    parser_revision: str | None = None,
) -> dict:
    source = {
        "original_filename": filename,
        "display_filename": filename,
        "sha256": digest,
        "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "size_bytes": 1024,
    }
    if source_extra:
        source.update(source_extra)
    metadata: dict = {}
    if parser_revision:
        metadata["route_plan"] = {
            "contract_revision": "m1.document.v2",
            "parser_revision": parser_revision,
        }
    return {
        "schema_version": "m1.document.v2",
        "source": source,
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "header": {
            "title": "Customer Order",
            "order_number": order_number,
            "supplier": "Example Supplier",
        },
        "lines": [],
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
        "extraction": {"metadata": metadata},
    }


@pytest.fixture
async def store(tmp_path: Path):
    value = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'identity.db'}")
    await value.init()
    tenant = await value.create_tenant(
        TenantRecord(tenant_key="identity-a", display_name="Identity A")
    )
    try:
        yield value, tenant
    finally:
        await value.close()


async def _decisions(store: KnowledgeStore, tenant_id: str):
    async with store.sessionmaker() as session:
        return (
            await session.scalars(
                select(DocumentIdentityDecisionRow)
                .where(DocumentIdentityDecisionRow.tenant_id == tenant_id)
                .order_by(DocumentIdentityDecisionRow.created_at)
            )
        ).all()


@pytest.mark.asyncio
async def test_parsed_order_fields_and_filename_never_select_an_existing_document(store):
    knowledge, tenant = store
    first = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-one",
        _document("a" * 64, filename="same.xlsx", order_number="SO-SAME"),
    )
    second = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-two",
        _document("b" * 64, filename="same.xlsx", order_number="SO-SAME"),
    )

    assert first.document_id != second.document_id
    assert first.version_number == second.version_number == 1
    decisions = await _decisions(knowledge, tenant.tenant_id)
    assert [item.action for item in decisions] == ["new_document", "new_document"]


@pytest.mark.asyncio
async def test_exact_asset_replay_requires_same_source_sha_and_processing_revision(store):
    knowledge, tenant = store
    payload = _document("c" * 64, parser_revision="parser-r1")
    first = await knowledge.ingest_document(tenant.tenant_id, "task-first", payload)
    replay = await knowledge.ingest_document(
        tenant.tenant_id, "task-replay", deepcopy(payload)
    )
    changed_revision = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-revision-change",
        _document("c" * 64, parser_revision="parser-r2"),
    )

    assert (replay.document_id, replay.version_id) == (first.document_id, first.version_id)
    assert changed_revision.document_id != first.document_id
    changed = await knowledge.get_document_version(tenant.tenant_id, changed_revision.version_id)
    assert changed is not None
    assert changed.lifecycle_status == LifecycleStatus.UNDER_REVIEW
    decisions = await _decisions(knowledge, tenant.tenant_id)
    assert [item.action for item in decisions] == [
        "new_document",
        "exact_asset_replay",
        "identity_candidate_review",
    ]


@pytest.mark.asyncio
async def test_verified_external_source_identity_creates_an_explicit_version_chain(store):
    knowledge, tenant = store
    source_identity = {
        "verified_external_identity": {
            "verified": True,
            "source_system": "erp",
            "external_id": "ERP-SO-9001",
        }
    }
    first = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-external-one",
        _document("d" * 64, source_extra=source_identity),
    )
    second = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-external-two",
        _document("e" * 64, source_extra=source_identity),
    )

    assert second.document_id == first.document_id
    assert second.version_number == 2
    second_version = await knowledge.get_document_version(tenant.tenant_id, second.version_id)
    assert second_version is not None
    assert second_version.supersedes_version_id == first.version_id
    decisions = await _decisions(knowledge, tenant.tenant_id)
    assert [item.action for item in decisions] == [
        "new_document",
        "existing_document_new_version",
    ]


@pytest.mark.asyncio
async def test_verified_identity_changed_processing_revision_creates_new_version(
    store,
):
    """A parser/model revision change is a new immutable version, not a replay."""

    knowledge, tenant = store
    source_identity = {
        "verified_external_identity": {
            "verified": True,
            "source_system": "erp",
            "external_id": "ERP-SO-REVISION-1",
        }
    }
    first = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-revision-one",
        _document(
            "e" * 64,
            source_extra=source_identity,
            parser_revision="parser-r1",
        ),
    )
    second = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-revision-two",
        _document(
            "e" * 64,
            source_extra=source_identity,
            parser_revision="parser-r2",
        ),
    )

    first_version = await knowledge.get_document_version(
        tenant.tenant_id, first.version_id
    )
    second_version = await knowledge.get_document_version(
        tenant.tenant_id, second.version_id
    )
    assert first.document_id == second.document_id
    assert first.asset_id == second.asset_id
    assert second.version_number == 2
    assert first_version is not None and second_version is not None
    assert first_version.content_hash != second_version.content_hash
    assert first_version.processing_revision != second_version.processing_revision
    assert second_version.supersedes_version_id == first.version_id


@pytest.mark.asyncio
async def test_unconfirmed_logical_identity_is_review_only_until_manually_confirmed(store):
    knowledge, tenant = store
    hint = {"logical_identity": {"namespace": "orders", "value": "customer-so-9"}}
    first = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-hint-one",
        _document("f" * 64, source_extra=hint),
    )
    second = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-hint-two",
        _document("0" * 64, source_extra=hint),
    )

    assert first.document_id != second.document_id
    first_version = await knowledge.get_document_version(tenant.tenant_id, first.version_id)
    second_version = await knowledge.get_document_version(tenant.tenant_id, second.version_id)
    assert first_version is not None and second_version is not None
    assert first_version.lifecycle_status == LifecycleStatus.UNDER_REVIEW
    assert second_version.lifecycle_status == LifecycleStatus.UNDER_REVIEW

    await knowledge.confirm_document_logical_identity(
        tenant.tenant_id,
        document_id=first.document_id,
        namespace="orders",
        value="customer-so-9",
        approved_by="reviewer-1",
    )
    third = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-hint-three",
        _document("1" * 64, source_extra=hint),
    )

    assert third.document_id == first.document_id
    assert third.version_number == 2
    version = await knowledge.get_document_version(tenant.tenant_id, third.version_id)
    assert version is not None
    assert version.supersedes_version_id == first.version_id


@pytest.mark.asyncio
async def test_identity_binding_is_tenant_scoped(store):
    knowledge, tenant = store
    source_identity = {
        "verified_external_identity": {
            "verified": True,
            "source_system": "erp",
            "external_id": "ERP-ONLY-A",
        }
    }
    first = await knowledge.ingest_document(
        tenant.tenant_id,
        "task-tenant-a",
        _document("2" * 64, source_extra=source_identity),
    )
    other = await knowledge.create_tenant(
        TenantRecord(tenant_key="identity-b", display_name="Identity B")
    )
    second = await knowledge.ingest_document(
        other.tenant_id,
        "task-tenant-b",
        _document("3" * 64, source_extra=source_identity),
    )

    assert first.document_id != second.document_id
    assert second.version_number == 1
