from __future__ import annotations

import json
from pathlib import Path

from m1.benchmarks.document_parsers import compare_runs


def _run_payload(*, elapsed_ms: float) -> dict:
    record = {
        "document_type": "order",
        "document_subtype": "purchase_contract",
        "header": {"contract_number": "HT-1", "buyer": "Buyer Co"},
        "lines": [{"line_id": "1", "name_raw": "Cable", "quantity": 2}],
        "field_meta": {
            "$.header.contract_number": {
                "source_refs": [{"page": 1, "part": "native/text"}]
            },
            "$.header.buyer": {
                "source_refs": [{"page": 1, "part": "ocr/block:1"}]
            },
            "$.lines[0].name_raw": {
                "source_refs": [{"page": 1, "part": "ocr/table:20100/row:1/column:1"}]
            },
            "$.lines[0].quantity": {
                "source_refs": [{"page": 1, "part": "ocr/table:20100/row:1/column:2"}]
            },
        },
        "extraction": {
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "width": 600,
                        "height": 800,
                        "coordinate_width": 600,
                        "coordinate_height": 800,
                        "text_blocks": [
                            {
                                "text_original": "Contract HT-1 Buyer Co",
                                "bbox": [10, 10, 300, 50],
                            }
                        ],
                        "ocr_lines": [
                            {"text_original": "Contract", "bbox": [10, 10, 100, 30]},
                            {"text_original": "Buyer Co", "bbox": [100, 10, 200, 30]},
                        ],
                        "ocr_tables": [
                            {
                                "table_index": 20100,
                                "column_count": 3,
                                "cell_bbox_matrix": [
                                    [[0, 100, 100, 140]] * 3,
                                    [
                                        [0, 140, 100, 180],
                                        [100, 140, 200, 180],
                                        [200, 140, 300, 180],
                                    ],
                                ],
                            }
                        ],
                    }
                ]
            }
        },
    }
    return {
        "schema_version": "m1.parser-benchmark.v1",
        "cases": [{"id": "case-1", "elapsed_ms": elapsed_ms, "record": record}],
    }


def test_parser_comparison_reports_accuracy_evidence_and_performance(tmp_path: Path):
    baseline = tmp_path / "baseline.json"
    candidate = tmp_path / "candidate.json"
    output = tmp_path / "comparison.json"
    baseline.write_text(json.dumps(_run_payload(elapsed_ms=100)), encoding="utf-8")
    candidate_payload = _run_payload(elapsed_ms=200)
    candidate_payload["cases"][0]["record"]["lines"][0]["line_id"] = "generated-again"
    candidate.write_text(json.dumps(candidate_payload), encoding="utf-8")

    result = compare_runs(baseline, candidate, output)

    metrics = result["metrics"]
    assert metrics["classification_exact"] == {"matched": 1, "total": 1}
    assert metrics["critical_header_exact"]["accuracy"] == 1.0
    assert metrics["nonempty_line_field_accuracy"]["accuracy"] == 1.0
    assert metrics["source_reference_coverage"]["ratio"] == 1.0
    assert metrics["performance"]["candidate_to_baseline_ratio"] == 2.0
    assert metrics["gates"]["p95_lte_legacy_1_5x"] is False
    assert json.loads(output.read_text(encoding="utf-8"))["metrics"] == metrics


def test_example_manifest_does_not_force_test_cable_classification() -> None:
    manifest_path = (
        Path(__file__).resolve().parents[1]
        / "benchmarks"
        / "golden-manifest.example.json"
    )
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    case = next(
        item
        for item in manifest["cases"]
        if item["id"] == "repository-test-cable"
    )

    hints = case.get("hints", {})
    assert "document_type" not in hints
    assert "document_subtype" not in hints
