from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
from m1.deps import WorkflowDeps
from m1.documents import parse_spreadsheet_document
from m1.order_export import export_order_workbook
from m1.parsers import ParserRouter
from m1.state import TaskState, TaskStatus
from m1.workflow.engine import WorkflowEngine
from m1.workflow.persistence import TaskStore


def test_inventory_csv_routes_to_generic_contract(tmp_path: Path) -> None:
    source = tmp_path / "inventory.csv"
    source.write_text(
        "仓库名称,物料代码,物料名称,物料型号,单位,即时库存数量\n"
        "成品仓,WX.01,DP1.4 8K线,V-1,PCS,10\n"
        "成品仓,WX.02,HDMI2.1 8K线,H-1,PCS,20\n",
        encoding="utf-8",
    )
    document = parse_spreadsheet_document(source)
    assert document.document_type == "inventory"
    assert document.document_subtype == "inventory_snapshot"
    assert len(document.lines) == 2
    assert [line.product_code for line in document.lines] == ["WX.01", "WX.02"]
    assert document.totals.calculated_quantity == 30
    assert document.lines[0].custom_fields["warehouse"] == "成品仓"


def test_standard_order_export_has_four_sheets_and_formula(tmp_path: Path) -> None:
    pytest.importorskip("openpyxl")
    from openpyxl import load_workbook

    source = tmp_path / "order.csv"
    source.write_text(
        "序号,型号,名称,规格,数量,单位\n1,M-1,中性DP1.4 8K60Hz,1M,2,PCS\n",
        encoding="utf-8",
    )
    document = parse_spreadsheet_document(source).model_dump(mode="json")
    document["header"]["title"] = '=HYPERLINK("https://example.invalid","x")'
    document["header"]["=MALICIOUS_LABEL"] = "safe"
    target = export_order_workbook(document, tmp_path / "standard.xlsx")
    workbook = load_workbook(target, data_only=False)
    assert workbook.sheetnames == ["订单头", "产品明细", "校验问题", "原始证据"]
    assert workbook["产品明细"]["C3"].value == "M-1"
    assert workbook["产品明细"]["L4"].value == "=SUM(L3:L3)"
    header_sheet = workbook["订单头"]
    title_row = next(
        row
        for row in range(3, header_sheet.max_row + 1)
        if header_sheet.cell(row, 1).value == "title"
    )
    assert header_sheet.cell(title_row, 2).value.startswith("'=")
    assert header_sheet.cell(title_row, 2).data_type == "s"
    malicious_label_row = next(
        row
        for row in range(3, header_sheet.max_row + 1)
        if str(header_sheet.cell(row, 1).value).endswith("MALICIOUS_LABEL")
    )
    assert header_sheet.cell(malicious_label_row, 1).value.startswith("'=")
    assert header_sheet.cell(malicious_label_row, 1).data_type == "s"


def _semantic_order_source(*, line_count: int = 1) -> dict:
    lines = [
        {
            "line_id": str(index + 1),
            "model": f"M-{index + 1}",
            "product_code": f"P-{index + 1:03d}",
            "name_raw": "DP线",
            "specification_raw": "1M",
            "quantity": index + 1,
            "unit": "PCS",
        }
        for index in range(line_count)
    ]
    return {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "semantic.xlsx"},
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {},
        "lines": lines,
        "totals": {"calculated_quantity": sum(line["quantity"] for line in lines)},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
    }


def test_legacy_projection_ignores_absent_optional_fields_for_review() -> None:
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(confidence_threshold=0.9)
    state = TaskState(task_id="optional-fields")
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "order.csv"},
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "header": {"order_number": "PO-100"},
        "lines": [
            {
                "line_id": "1",
                "model": "M-1",
                "quantity": 2,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 2},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
    }

    _extraction, scored = engine._document_to_legacy(state, document)

    assert scored.needs_review is False
    assert scored.review_status == "auto_approved"
    absent = {field.name: field for field in scored.fields if not field.applicable}
    assert "supplier" in absent
    assert "lines.1.name_normalized" in absent
    assert all(field.needs_review is False for field in absent.values())


def test_drawing_document_projects_title_block_into_legacy_contract() -> None:
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(confidence_threshold=0.9)
    state = TaskState(task_id="drawing-projection")
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "cable.pdf"},
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {
            "title": "USB Type-C cable",
            "issuer": "Example Cable Co., Ltd.",
            "drawing_number": "DWG-001",
            "material_number": "CBL-001",
            "unit": "mm",
            "version": "A",
        },
        "lines": [
            {
                "line_id": "drawing:1:1:RAW-001",
                "line_no": 1,
                "product_code": "RAW-001",
                "quantity": 160,
                "unit": "mm",
                "name_raw": "Cable bulk material",
            }
        ],
        "technical_requirements": "100% continuity test",
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
    }

    extraction, scored = engine._document_to_legacy(state, document)

    values = {field.name: field.value for field in extraction.fields}
    assert values["title_block.drawing_name"] == "USB Type-C cable"
    assert values["title_block.company"] == "Example Cable Co., Ltd."
    assert values["title_block.drawing_number"] == "DWG-001"
    assert values["title_block.material_number"] == "CBL-001"
    assert values["technical_requirements"] == "100% continuity test"
    assert extraction.bom[0]["product_code"] == "RAW-001"
    assert scored.needs_review is False


@pytest.mark.asyncio
async def test_historical_false_review_can_be_reassessed_without_models(
    tmp_path: Path,
) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'reassess.db').as_posix()}")
    await store.init()
    state = TaskState(
        task_id="historical-false-review",
        status=TaskStatus.NEEDS_REVIEW,
        processing_stage="needs_review",
        original_filename="order.csv",
    )
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "order.csv", "sha256": "a" * 64},
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "header": {"order_number": "PO-100"},
        "lines": [
            {
                "line_id": "1",
                "model": "M-1",
                "quantity": 2,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 2},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": True,
        "scored_result": {
            "task_id": state.task_id,
            "fields": [
                {
                    "name": "supplier",
                    "value": None,
                    "confidence": 0.0,
                    "needs_review": True,
                }
            ],
            "needs_review": True,
            "review_status": "needs_review",
        },
    }
    state.document = document
    await store.save(state)
    await store.save_document(state.task_id, document)
    engine = WorkflowEngine(
        WorkflowDeps(
            parser_router=ParserRouter(),
            vlm_agent=SimpleNamespace(),
            confidence_threshold=0.9,
        ),
        store,
    )

    preview = await engine.reassess_document_review(state.task_id, dry_run=True)
    assert preview["changed"] is True
    assert (await store.load(state.task_id)).status == TaskStatus.NEEDS_REVIEW

    applied = await engine.reassess_document_review(state.task_id, dry_run=False)
    persisted_state = await store.load(state.task_id)
    persisted_document = await store.get_document(state.task_id)

    assert applied["after_needs_review"] is False
    assert persisted_state is not None
    assert persisted_state.status == TaskStatus.DONE
    assert persisted_state.scored_result.review_status == "auto_approved"
    assert persisted_document is not None
    assert persisted_document["needs_review"] is False
    assert persisted_document["review_assessment"]["blockers"] == []
    await store.close()


def test_schema_shaped_line_review_applies_nested_corrections() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "header": {},
        "lines": [{"line_id": "1", "model": "M-1", "quantity": 2}],
        "validation_issues": [],
        "needs_review": True,
    }

    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=[
            {"line_id": "1", "corrections": {"quantity": 7, "unit": "PCS"}}
        ],
        issue_resolutions=None,
        reviewer="tester",
        comment="",
        approve=True,
    )

    assert document["lines"][0]["quantity"] == 7
    assert document["lines"][0]["unit"] == "PCS"
    assert "corrections" not in document["lines"][0]


def test_legacy_flat_review_payload_updates_order_line() -> None:
    from m1.api.main import ReviewRequest

    request = ReviewRequest.model_validate({"lines.1.quantity": 9})
    assert request.corrections == {"lines.1.quantity": 9}

    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "order",
        "header": {},
        "lines": [{"line_id": "1", "model": "M-1", "quantity": 2, "unit": "PCS"}],
        "totals": {"declared_quantity": 9, "calculated_quantity": 2},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": True,
    }
    engine._apply_document_review(
        document,
        corrected_fields=request.corrections,
        header_corrections=None,
        line_corrections=None,
        issue_resolutions=None,
        reviewer="legacy-ui",
        comment="",
        approve=True,
    )
    assert document["lines"][0]["quantity"] == 9
    assert document["totals"]["calculated_quantity"] == 9


def test_partial_issue_resolution_does_not_accept_unmentioned_issues() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "order",
        "header": {},
        "lines": [],
        "field_meta": {},
        "validation_issues": [
            {"code": "A", "severity": "warning", "message": "a", "paths": ["$.a"]},
            {"code": "B", "severity": "warning", "message": "b", "paths": ["$.b"]},
        ],
        "needs_review": True,
    }
    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=None,
        issue_resolutions=[{"code": "A", "paths": ["$.a"], "status": "resolved"}],
        reviewer="tester",
        comment="",
        approve=True,
    )
    by_code = {issue["code"]: issue for issue in document["validation_issues"]}
    assert by_code["A"]["status"] == "resolved"
    assert by_code["B"].get("status", "open") == "open"
    assert document["needs_review"] is True


def test_review_recalculates_totals_and_does_not_hide_new_mismatch() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "order",
        "header": {},
        "lines": [
            {"line_id": "1", "line_no": 1, "model": "M-1", "quantity": 2, "unit": "PCS"}
        ],
        "totals": {"declared_quantity": 2, "calculated_quantity": 2},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": True,
    }

    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=[{"line_id": "1", "corrections": {"quantity": 7}}],
        issue_resolutions=None,
        reviewer="tester",
        comment="",
        approve=True,
    )

    assert document["totals"]["calculated_quantity"] == 7
    assert document["totals"]["quantity_matches"] is False
    assert document["needs_review"] is True
    assert document["review"]["status"] == "needs_review"
    assert "TOTAL_QUANTITY_MISMATCH" in {
        issue["code"] for issue in document["validation_issues"]
    }


def test_review_correction_resolves_the_issue_on_the_corrected_path() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "order",
        "header": {},
        "lines": [
            {"line_id": "line-a", "line_no": 1, "model": "M-1", "quantity": None}
        ],
        "totals": {},
        "field_meta": {},
        "validation_issues": [
            {
                "code": "SOURCE_QUANTITY_UNCERTAIN",
                "severity": "warning",
                "message": "quantity needs review",
                "paths": ["$.lines[0].quantity"],
            }
        ],
        "needs_review": True,
    }

    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=[
            {"line_id": "line-a", "corrections": {"quantity": 7, "unit": "PCS"}}
        ],
        issue_resolutions=None,
        reviewer="tester",
        comment="verified from source",
        approve=True,
    )

    issue = next(
        item
        for item in document["validation_issues"]
        if item["code"] == "SOURCE_QUANTITY_UNCERTAIN"
    )
    assert issue["status"] == "resolved"
    assert document["needs_review"] is False
    assert document["review"]["status"] == "reviewed"


def test_review_keeps_new_revalidation_issue_open() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "order",
        "header": {},
        "lines": [
            {
                "line_id": "line-a",
                "line_no": 1,
                "model": "M-1",
                "quantity": 2,
                "unit_price_tax_excluded": 5,
                "amount_tax_excluded": 10,
            }
        ],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
    }

    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=[
            {"line_id": "line-a", "corrections": {"amount_tax_excluded": 11}}
        ],
        issue_resolutions=None,
        reviewer="tester",
        comment="source says 11",
        approve=True,
    )

    issue = next(
        item
        for item in document["validation_issues"]
        if item["code"] == "LINE_AMOUNT_MISMATCH"
    )
    assert issue.get("status", "open") == "open"
    assert document["needs_review"] is True
    assert document["review"]["status"] == "needs_review"


@pytest.mark.asyncio
async def test_review_is_persisted_before_indexing_and_final_status(tmp_path: Path) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'review.db').as_posix()}")
    await store.init()
    state = TaskState(
        task_id="review-two-phase",
        status=TaskStatus.NEEDS_REVIEW,
        processing_stage="needs_review",
        original_filename="order.xlsx",
    )
    document = _semantic_order_source()
    document["needs_review"] = True
    document["validation_issues"] = [
        {
            "code": "SOURCE_QUANTITY_UNCERTAIN",
            "severity": "warning",
            "message": "quantity needs review",
            "paths": ["$.lines[0].quantity"],
        }
    ]
    state.document = document
    await store.save(state)
    engine = WorkflowEngine(
        WorkflowDeps(
            parser_router=ParserRouter(),
            vlm_agent=SimpleNamespace(),
            confidence_threshold=0.9,
        ),
        store,
    )

    prepared = await engine.prepare_review(
        state.task_id,
        line_corrections=[
            {"line_id": "1", "corrections": {"quantity": 7, "unit": "PCS"}}
        ],
        reviewer="tester",
        approve=True,
    )
    durable = await store.load(state.task_id)

    assert prepared.task_id == state.task_id
    assert durable is not None
    assert durable.status == TaskStatus.SCORING
    assert durable.processing_stage == "review_indexing"
    assert durable.review_target_status == TaskStatus.DONE.value
    assert durable.document["lines"][0]["quantity"] == 7

    completed = await engine.finalize_review(state.task_id)
    indexed = await store.get_document(state.task_id)

    assert completed.task_id == state.task_id
    assert completed.status == TaskStatus.DONE
    assert completed.processing_stage == "completed"
    assert completed.review_target_status == ""
    assert indexed is not None
    assert indexed["lines"][0]["quantity"] == 7
    await store.close()
