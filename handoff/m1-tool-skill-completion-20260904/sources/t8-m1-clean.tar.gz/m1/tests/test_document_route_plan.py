from __future__ import annotations

from types import SimpleNamespace

import pytest
from m1.documents.parsing.document_route_lifecycle import profile_matches_signature
from m1.documents.parsing.document_route_plan import (
    RouteBackend,
)
from m1.documents.parsing.document_route_policy import (
    DocumentRoutingResolution,
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
)
from m1.documents.parsing.document_route_signature import (
    build_document_route_signature,
)
from m1.documents.parsing.document_routing_status import DocumentRoutingStatus
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidencePage,
)
from m1.documents.parsing.mineru_instructor_service import (
    run_candidate,
)
from m1.workflow.document_pipeline import DocumentPipelineMixin


def _evidence(*, version: str = "3.4.4") -> DocumentEvidence:
    return DocumentEvidence(
        backend="mineru:vlm-engine",
        backend_version=version,
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[EvidenceBlock(block_id="p1:b0", text="private-value")],
            )
        ],
    )


def _resolution(policy: RouteProfilePolicy) -> DocumentRoutingResolution:
    return DocumentRoutingResolution(
        mode="guarded",
        recommendation="reuse",
        reason="exact_fingerprint",
        signature_fingerprint="a" * 64,
        recommended_profile_id="route-a",
        applied_profile_id="route-a",
        applied_policy=policy,
        top_score=1.0,
        top1_top2_margin=1.0,
    )


def test_route_plan_converts_backend_chain_and_visual_policy() -> None:
    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        document_subtype_hint=RouteDocumentSubtype.PURCHASE_CONTRACT,
        backend_chain=("mineru", "native"),
        visual_policy="disabled",
        parser_revision="mineru-3.4.4",
    )

    plan = _resolution(policy).to_route_plan()

    assert [target.backend for target in plan.backend_chain] == [
        RouteBackend.MINERU,
        RouteBackend.NATIVE,
    ]
    assert [target.role for target in plan.backend_chain] == ["primary", "fallback"]
    assert all(target.revision == "mineru-3.4.4" for target in plan.backend_chain)
    assert plan.document_subtype_hint is RouteDocumentSubtype.PURCHASE_CONTRACT
    assert plan.visual_enabled(configured=True, uncertain=True) is False


def test_signature_includes_hints_and_backend_revision_without_business_values() -> (
    None
):
    first = build_document_route_signature(
        _evidence(version="3.4.4"),
        "pdf",
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )
    second = build_document_route_signature(
        _evidence(version="3.5.0"),
        "pdf",
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert first.exact_fingerprint() != second.exact_fingerprint()
    serialized = first.embedding_text()
    assert "compat:type_hint:order" in serialized
    assert "compat:subtype_hint:purchase_contract" in serialized
    assert "private-value" not in serialized


def test_profile_compatibility_rejects_backend_revision_drift() -> None:
    profile_signature = build_document_route_signature(
        _evidence(version="3.4.4"),
        "pdf",
        document_type_hint="order",
    )
    current_signature = build_document_route_signature(
        _evidence(version="3.5.0"),
        "pdf",
        document_type_hint="order",
    )
    policy = RouteProfilePolicy(backend_chain=("mineru", "native"))

    assert not profile_matches_signature(
        profile_signature,
        current_signature,
        policy,
    )


def test_route_dependency_circuit_opens_and_is_visible() -> None:
    status = DocumentRoutingStatus(circuit_failures=2, circuit_seconds=300)
    status.note_dependency_failure("model", TimeoutError())
    assert status.circuit_open("model") is False
    status.note_dependency_failure("model", TimeoutError())
    snapshot = status.snapshot()

    assert status.circuit_open("model") is True
    assert snapshot["circuit_open"] is True
    assert snapshot["dependencies"]["model"]["circuit_open"] is True


@pytest.mark.asyncio
async def test_serialized_route_plan_cannot_become_mineru_execution_capability(
    tmp_path,
) -> None:
    policy = RouteProfilePolicy(backend_chain=("docling", "mineru"))
    plan = _resolution(policy).to_route_plan()
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    with pytest.raises(TypeError, match="in-memory DocumentRoutePlan"):
        await run_candidate(
            source,
            mineru=None,  # type: ignore[arg-type]
            extractor=None,  # type: ignore[arg-type]
            route_plan=plan.value_free_dump(),  # type: ignore[arg-type]
        )


@pytest.mark.asyncio
async def test_native_pipeline_persists_the_same_route_plan_contract() -> None:
    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        backend_chain=("auto",),
    )

    class Runtime:
        required = True

        async def resolve(self, *_args, **_kwargs):
            return _resolution(policy)

    class Pipeline(DocumentPipelineMixin):
        deps = SimpleNamespace(document_routing_runtime=Runtime())

        async def _save(self, _state):
            return None

    state = SimpleNamespace(
        file_type="xlsx",
        task_id="task-a",
        tenant_id="tenant-a",
        doc_type_hint="order",
        document_subtype_hint="",
        processing_stage="",
    )
    document = {
        "source": {"sha256": "a" * 64},
        "document_type": "order",
        "document_subtype": "unknown",
        "header": {"order_number": None},
        "lines": [{"product_code": None, "quantity": None}],
        "field_meta": {"$.header.order_number": {}},
    }

    result = await Pipeline()._document_route_stage(state, document)
    metadata = result["extraction"]["metadata"]

    assert metadata["route_plan"]["schema_version"] == "m1.route-plan.v1"
    assert metadata["route_plan"]["schema_family"] == "order"
    assert metadata["document_route_context"]["schema_family"] == "order"
    assert metadata["adaptive_routing"]["policy_applied"] is True
