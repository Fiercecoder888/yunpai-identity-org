"""Configuration contract for governed adaptive document routing."""

from pathlib import Path

import pytest
import yaml
from m1.core.config import Settings
from pydantic import ValidationError

_REPOSITORY = Path(__file__).resolve().parents[2]
_ROUTER_VARIABLES = {
    "DOCUMENT_ROUTER_ENABLED",
    "DOCUMENT_ROUTER_REQUIRED",
    "DOCUMENT_ROUTER_MODE",
    "DOCUMENT_ROUTER_BASE_URL",
    "DOCUMENT_ROUTER_API_KEY",
    "DOCUMENT_ROUTER_MODEL",
    "DOCUMENT_ROUTER_TIMEOUT_SECONDS",
    "DOCUMENT_ROUTER_TOP_K",
    "DOCUMENT_ROUTER_AUTO_MIN_SCORE",
    "DOCUMENT_ROUTER_MODEL_MIN_SCORE",
    "DOCUMENT_ROUTER_MIN_MARGIN",
    "DOCUMENT_ROUTER_MIN_ACTIVATION_SAMPLES",
}


def _compose_environment(relative_path: str) -> dict[str, str]:
    compose = yaml.safe_load((_REPOSITORY / relative_path).read_text(encoding="utf-8"))
    values = compose["services"]["m1"]["environment"]
    if isinstance(values, dict):
        return values
    return dict(value.split("=", 1) for value in values)


def _settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "document_router_enabled": False,
        "document_router_required": False,
        "document_router_mode": "shadow",
        "document_router_base_url": "",
        "document_router_api_key": "",
        "document_router_model": "",
        "document_router_timeout_seconds": 30,
        "document_router_top_k": 3,
        "document_router_auto_min_score": 0.90,
        "document_router_model_min_score": 0.75,
        "document_router_min_margin": 0.08,
        "document_router_min_activation_samples": 3,
    }
    values.update(overrides)
    return Settings(**values)


def test_document_router_defaults_are_disabled_and_fail_safe() -> None:
    settings = _settings()

    assert settings.document_router_enabled is False
    assert settings.document_router_required is False
    assert settings.document_router_mode == "shadow"
    assert settings.document_router_top_k == 3
    assert settings.document_router_auto_min_score == 0.90
    assert settings.document_router_model_min_score == 0.75
    assert settings.document_router_min_margin == 0.08
    assert settings.document_router_min_activation_samples == 3


def test_required_document_router_must_be_enabled() -> None:
    with pytest.raises(
        ValidationError,
        match="DOCUMENT_ROUTER_REQUIRED requires DOCUMENT_ROUTER_ENABLED",
    ):
        _settings(document_router_required=True)


@pytest.mark.parametrize(
    ("missing_field", "message"),
    [
        ("document_router_base_url", "DOCUMENT_ROUTER_BASE_URL is required"),
        ("document_router_api_key", "DOCUMENT_ROUTER_API_KEY is required"),
        ("document_router_model", "DOCUMENT_ROUTER_MODEL is required"),
    ],
)
def test_enabled_document_router_requires_complete_model_contract(
    missing_field: str,
    message: str,
) -> None:
    values: dict[str, object] = {
        "document_router_enabled": True,
        "document_router_base_url": "http://router.invalid/v1",
        "document_router_api_key": "test-only-secret",
        "document_router_model": "small-router",
    }
    values[missing_field] = ""

    with pytest.raises(ValidationError, match=message) as error:
        _settings(**values)
    assert "test-only-secret" not in str(error.value)


def test_document_router_thresholds_are_ordered() -> None:
    with pytest.raises(
        ValidationError,
        match=(
            "DOCUMENT_ROUTER_MODEL_MIN_SCORE must not exceed "
            "DOCUMENT_ROUTER_AUTO_MIN_SCORE"
        ),
    ):
        _settings(
            document_router_auto_min_score=0.70,
            document_router_model_min_score=0.75,
        )


def test_document_router_secret_is_not_in_settings_repr() -> None:
    settings = _settings(
        document_router_enabled=True,
        document_router_base_url="http://router.invalid/v1",
        document_router_api_key="test-only-secret",
        document_router_model="small-router",
    )

    assert "test-only-secret" not in repr(settings)


def test_document_router_runtime_and_dev_contracts_are_complete_and_off() -> None:
    runtime = _compose_environment("m1/deploy/compose.runtime.yml")
    development = _compose_environment("m1/deploy/compose.dev.yml")

    assert _ROUTER_VARIABLES <= set(runtime)
    assert _ROUTER_VARIABLES <= set(development)
    assert runtime["DOCUMENT_ROUTER_ENABLED"].endswith(":-false}")
    assert runtime["DOCUMENT_ROUTER_REQUIRED"].endswith(":-false}")
    assert runtime["DOCUMENT_ROUTER_API_KEY"] == "${M1_DOCUMENT_ROUTER_API_KEY:-}"
    assert development["DOCUMENT_ROUTER_ENABLED"].endswith(":-false}")
    assert development["DOCUMENT_ROUTER_REQUIRED"].endswith(":-false}")
    assert development["DOCUMENT_ROUTER_API_KEY"] == ("${DOCUMENT_ROUTER_API_KEY:-}")


def test_document_router_safe_environment_example_documents_all_variables() -> None:
    lines = set(
        (_REPOSITORY / "m1/.env.example").read_text(encoding="utf-8").splitlines()
    )

    for name in _ROUTER_VARIABLES:
        assert any(line.startswith(f"{name}=") for line in lines)
        assert any(line.startswith(f"M1_{name}=") for line in lines)
    assert "DOCUMENT_ROUTER_ENABLED=false" in lines
    assert "M1_DOCUMENT_ROUTER_ENABLED=false" in lines
    assert "DOCUMENT_ROUTER_API_KEY=" in lines
    assert "M1_DOCUMENT_ROUTER_API_KEY=" in lines
