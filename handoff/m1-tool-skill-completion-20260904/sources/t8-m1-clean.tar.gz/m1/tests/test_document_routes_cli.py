from __future__ import annotations

from types import SimpleNamespace

import pytest

from m1 import document_routes


def test_route_approval_cli_requires_explicit_operator_identity() -> None:
    parser = document_routes._parser()

    with pytest.raises(SystemExit):
        parser.parse_args(
            [
                "approve",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "route-a",
                "--approved-by",
                "operator-a",
            ]
        )


def test_route_validation_cli_requires_task_decision_and_review_note() -> None:
    parser = document_routes._parser()

    with pytest.raises(SystemExit):
        parser.parse_args(
            [
                "validate",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "route-a",
                "--task-id",
                "task-a",
                "--decision",
                "approve",
                "--reviewed-by",
                "reviewer-a",
            ]
        )


@pytest.mark.asyncio
async def test_route_approval_cli_calls_governed_runtime(monkeypatch) -> None:
    events: list[tuple[str, object]] = []

    class Store:
        def __init__(self, database_url: str) -> None:
            events.append(("database_url", database_url))

        async def init(self) -> None:
            events.append(("store_init", True))

        async def close(self) -> None:
            events.append(("store_close", True))

    class Runtime:
        def __init__(self, **kwargs) -> None:
            events.append(("runtime_init", kwargs))

        async def approve_candidate(self, **kwargs):
            events.append(("approve", kwargs))
            return SimpleNamespace(
                tenant_id="tenant-a",
                profile_id="route-a",
                profile_key="layout-a",
                version=3,
                status="active",
                approved_by="operator-a",
                reviewed_by="reviewer-a",
            )

        async def close(self) -> None:
            events.append(("runtime_close", True))

    monkeypatch.setattr(document_routes, "KnowledgeStore", Store)
    monkeypatch.setattr(document_routes, "DocumentRoutingRuntime", Runtime)
    monkeypatch.setattr(
        document_routes,
        "settings",
        SimpleNamespace(
            resolved_knowledge_database_url="postgresql+asyncpg://knowledge",
            document_router_mode="guarded",
            document_router_min_activation_samples=5,
        ),
    )
    args = document_routes._parser().parse_args(
        [
            "approve",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "route-a",
            "--approved-by",
            "operator-a",
            "--reviewed-by",
            "reviewer-a",
            "--review-note",
            "five validated samples",
        ]
    )

    result = await document_routes._approve(args)

    assert result == {
        "schema_version": "m1.document-route-operation.v1",
        "operation": "approve",
        "tenant_id": "tenant-a",
        "profile_id": "route-a",
        "profile_key": "layout-a",
        "version": 3,
        "status": "active",
        "approved_by": "operator-a",
        "reviewed_by": "reviewer-a",
    }
    approve = dict(events)["approve"]
    assert approve == {
        "tenant_id": "tenant-a",
        "profile_id": "route-a",
        "review_approved": True,
        "approved_by": "operator-a",
        "reviewed_by": "reviewer-a",
        "review_note": "five validated samples",
    }
    assert events[-2:] == [("runtime_close", True), ("store_close", True)]


@pytest.mark.asyncio
async def test_route_validation_cli_loads_final_task_and_returns_bounded_report(
    monkeypatch,
) -> None:
    events: list[tuple[str, object]] = []
    secret = "PRIVATE DOCUMENT VALUE SO-9001"

    class RouteStore:
        def __init__(self, database_url: str) -> None:
            events.append(("route_database_url", database_url))

        async def init(self) -> None:
            events.append(("route_store_init", True))

        async def close(self) -> None:
            events.append(("route_store_close", True))

    class Tasks:
        def __init__(self, database_url: str) -> None:
            events.append(("task_database_url", database_url))

        async def init(self) -> None:
            events.append(("task_store_init", True))

        async def load(self, task_id: str):
            events.append(("task_load", task_id))
            return SimpleNamespace(
                tenant_id="tenant-a",
                document={"schema_version": "m1.document.v2", "secret": secret},
                status=document_routes.TaskStatus.DONE,
                knowledge_sync_status="synced",
                knowledge_version_id="knowledge-version-a",
            )

        async def close(self) -> None:
            events.append(("task_store_close", True))

    class Runtime:
        def __init__(self, **kwargs) -> None:
            events.append(("runtime_init", kwargs))

        async def record_candidate_validation(self, **kwargs):
            events.append(("validate", kwargs))
            return SimpleNamespace(
                tenant_id="tenant-a",
                profile_id="route-a",
                outcome="success",
                error_code="",
                details={
                    "task_ref": "a" * 64,
                    "policy_digest": "b" * 64,
                    "document_digest": "c" * 64,
                    "knowledge_version_id": "knowledge-version-a",
                    "validator_version": "m1.route-policy-preflight.v1",
                    "reviewed_by": "reviewer-a",
                    "check_codes": ["ROUTE_POLICY_PREFLIGHT_PASSED"],
                },
            )

        async def close(self) -> None:
            events.append(("runtime_close", True))

    monkeypatch.setattr(document_routes, "KnowledgeStore", RouteStore)
    monkeypatch.setattr(document_routes, "TaskStore", Tasks)
    monkeypatch.setattr(document_routes, "DocumentRoutingRuntime", Runtime)
    monkeypatch.setattr(
        document_routes,
        "settings",
        SimpleNamespace(
            resolved_knowledge_database_url="postgresql+asyncpg://knowledge",
            database_url="sqlite+aiosqlite:///tasks.db",
            document_router_mode="guarded",
            document_router_min_activation_samples=2,
        ),
    )
    args = document_routes._parser().parse_args(
        [
            "validate",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "route-a",
            "--task-id",
            "task-a",
            "--decision",
            "approve",
            "--reviewed-by",
            "reviewer-a",
            "--review-note",
            "checked against the final record",
        ]
    )

    result = await document_routes._validate(args)

    assert result == {
        "schema_version": "m1.document-route-operation.v1",
        "operation": "validate",
        "tenant_id": "tenant-a",
        "profile_id": "route-a",
        "task_ref": "a" * 64,
        "outcome": "success",
        "error_code": "",
        "policy_digest": "b" * 64,
        "document_digest": "c" * 64,
        "knowledge_version_id": "knowledge-version-a",
        "validator_version": "m1.route-policy-preflight.v1",
        "reviewed_by": "reviewer-a",
        "check_codes": ["ROUTE_POLICY_PREFLIGHT_PASSED"],
    }
    validate = dict(events)["validate"]
    assert validate["document"]["secret"] == secret
    assert validate["knowledge_version_id"] == "knowledge-version-a"
    assert secret not in str(result)
    assert events[-3:] == [
        ("runtime_close", True),
        ("task_store_close", True),
        ("route_store_close", True),
    ]
