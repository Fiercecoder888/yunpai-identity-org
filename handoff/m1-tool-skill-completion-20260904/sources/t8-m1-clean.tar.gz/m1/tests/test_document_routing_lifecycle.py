from __future__ import annotations

from types import SimpleNamespace

import pytest
from m1.api import main
from m1.documents.parsing.document_routing_runtime import DocumentRoutingRuntime
from m1.documents.parsing.mineru_instructor_service import MinerUInstructorService


class _ProbeClient:
    def __init__(self, error: Exception | None = None) -> None:
        self.error = error

    async def probe(self) -> dict[str, object]:
        if self.error is not None:
            raise self.error
        return {"ready": True, "model": "router-model"}


class _Runtime:
    mode = "guarded"

    def __init__(self, probe_error: Exception | None = None) -> None:
        self._owned_model_client = _ProbeClient(probe_error)
        self.closed = False

    async def close(self) -> None:
        self.closed = True


def _settings(*, enabled: bool, required: bool = False):
    return SimpleNamespace(
        document_router_enabled=enabled,
        document_router_required=required,
        document_router_mode="guarded",
    )


@pytest.fixture(autouse=True)
def _restore_runtime_globals(monkeypatch):
    monkeypatch.setattr(main, "document_routing_runtime", None)
    monkeypatch.setattr(main, "knowledge_runtime", None)
    monkeypatch.setattr(
        main,
        "document_routing_status",
        {
            "enabled": False,
            "mode": "shadow",
            "ready": True,
            "degraded": False,
            "error_type": None,
        },
    )


@pytest.mark.asyncio
async def test_disabled_router_does_not_construct_runtime(monkeypatch) -> None:
    calls = 0

    def forbidden(*_args, **_kwargs):
        nonlocal calls
        calls += 1
        raise AssertionError("disabled router must not be constructed")

    monkeypatch.setattr(DocumentRoutingRuntime, "from_settings", forbidden)

    await main._init_document_routing(_settings(enabled=False))

    assert calls == 0
    assert main.document_routing_runtime is None
    assert main.document_routing_status == {
        "enabled": False,
        "mode": "guarded",
        "ready": True,
        "degraded": False,
        "error_type": None,
    }


@pytest.mark.asyncio
async def test_router_reuses_knowledge_store_and_embedding_then_closes(
    monkeypatch,
) -> None:
    store = object()
    embedding = object()
    runtime = _Runtime()
    captured = {}

    def build(settings_obj, *, store, embedding_provider):
        captured.update(
            settings=settings_obj,
            store=store,
            embedding=embedding_provider,
        )
        return runtime

    monkeypatch.setattr(DocumentRoutingRuntime, "from_settings", build)
    main.knowledge_runtime = SimpleNamespace(
        store=store,
        embedding_provider=embedding,
    )
    settings_obj = _settings(enabled=True)

    await main._init_document_routing(settings_obj)

    assert captured == {
        "settings": settings_obj,
        "store": store,
        "embedding": embedding,
    }
    assert main.document_routing_runtime is runtime
    assert main.document_routing_status["ready"] is True
    assert main.document_routing_status["degraded"] is False

    await main._close_document_routing_runtime()
    assert runtime.closed is True
    assert main.document_routing_runtime is None


@pytest.mark.asyncio
async def test_optional_probe_failure_is_degraded_but_required_fails_startup(
    monkeypatch,
) -> None:
    optional_runtime = _Runtime(TimeoutError())
    main.knowledge_runtime = SimpleNamespace(
        store=object(),
        embedding_provider=object(),
    )
    monkeypatch.setattr(
        DocumentRoutingRuntime,
        "from_settings",
        lambda *_args, **_kwargs: optional_runtime,
    )

    await main._init_document_routing(_settings(enabled=True, required=False))

    assert main.document_routing_runtime is optional_runtime
    assert main.document_routing_status == {
        "enabled": True,
        "mode": "guarded",
        "ready": False,
        "degraded": True,
        "error_type": "TimeoutError",
    }

    required_runtime = _Runtime(TimeoutError())
    monkeypatch.setattr(
        DocumentRoutingRuntime,
        "from_settings",
        lambda *_args, **_kwargs: required_runtime,
    )
    with pytest.raises(TimeoutError):
        await main._init_document_routing(_settings(enabled=True, required=True))
    assert required_runtime.closed is True
    assert main.document_routing_runtime is None


class _FinalStore:
    def __init__(self, state) -> None:
        self.state = state
        self.statuses: list[dict[str, object]] = []

    async def load(self, task_id: str):
        assert task_id == "task-final"
        return self.state

    async def update_knowledge_status(self, task_id: str, **kwargs) -> None:
        assert task_id == "task-final"
        self.statuses.append(kwargs)


class _FinalKnowledgeRuntime:
    async def sync_document(self, *, tenant_id: str, task_id: str, document: dict):
        assert (tenant_id, task_id) == ("tenant-a", "task-final")
        assert document["schema_version"] == "m1.document.v2"
        return SimpleNamespace(
            status="indexed",
            document=SimpleNamespace(document_id="doc-a", version_id="version-a"),
            graph_error="",
            embedding_error="",
        )


class _FinalRouteRuntime:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []
        self.unique_keys: set[tuple[object, ...]] = set()

    async def approve_candidate(self, **_kwargs) -> None:
        raise AssertionError("ordinary document review must not approve a route profile")

    async def record_outcome(self, **kwargs):
        self.calls.append(kwargs)
        self.unique_keys.add(
            (
                kwargs["tenant_id"],
                kwargs["task_id"],
                kwargs["profile_id"],
                kwargs["attempt"],
            )
        )


def _routed_document(
    *,
    needs_review: bool,
    review_status: str = "",
    applied: bool = False,
) -> dict:
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "route.pdf"},
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "header": {},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": needs_review,
        "extraction": {
            "metadata": {
                "adaptive_routing": {
                    "status": "resolved",
                    "recommended_profile_id": "route-a",
                    "candidate_profile_id": "route-a",
                    "applied_profile_id": "route-a" if applied else None,
                    "policy_applied": applied,
                    "processing_attempt": 7,
                }
            }
        },
    }
    if applied:
        document["extraction"]["metadata"]["route_execution"] = {
            "status": "applied",
            "backend": "mineru",
            "primary_backend": "mineru",
            "primary_attempted": True,
            "primary_applied": True,
            "fallback_applied": False,
            "outcome_code": "",
        }
    if review_status:
        document["review"] = {
            "status": review_status,
            "reviewer": "document-reviewer",
        }
    return document


def _configure_final_sink(monkeypatch, *, authority_selected: bool):
    state = SimpleNamespace(
        tenant_id="tenant-a",
        mineru_shadow={"authority_selected": authority_selected},
    )
    route_runtime = _FinalRouteRuntime()
    monkeypatch.setattr(main, "store", _FinalStore(state))
    monkeypatch.setattr(main, "knowledge_runtime", _FinalKnowledgeRuntime())
    monkeypatch.setattr(main, "document_routing_runtime", route_runtime)
    return route_runtime


@pytest.mark.asyncio
async def test_candidate_or_recommended_route_never_records_automatic_success(
    monkeypatch,
) -> None:
    runtime = _configure_final_sink(monkeypatch, authority_selected=False)
    document = _routed_document(needs_review=False, review_status="reviewed")

    await main._sync_document_to_knowledge("task-final", document)

    assert runtime.calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("needs_review", "review_status"),
    [(True, ""), (False, "rejected"), (False, "")],
)
async def test_nonfinal_or_rejected_document_never_records_route_success(
    monkeypatch,
    needs_review: bool,
    review_status: str,
) -> None:
    runtime = _configure_final_sink(monkeypatch, authority_selected=False)

    await main._sync_document_to_knowledge(
        "task-final",
        _routed_document(needs_review=needs_review, review_status=review_status),
    )

    assert runtime.calls == []


@pytest.mark.asyncio
async def test_final_route_success_is_idempotent_per_task_and_profile(monkeypatch) -> None:
    runtime = _configure_final_sink(monkeypatch, authority_selected=True)
    document = _routed_document(needs_review=False, applied=True)

    await main._sync_document_to_knowledge("task-final", document)
    await main._sync_document_to_knowledge("task-final", document)

    assert len(runtime.calls) == 2
    assert runtime.calls[0]["task_id"] == runtime.calls[1]["task_id"]
    assert runtime.calls[0]["attempt"] == runtime.calls[1]["attempt"] == 0
    assert len(runtime.unique_keys) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("needs_review", "review_status", "authority_selected", "error_code"),
    [
        (True, "", True, "DOCUMENT_REQUIRES_REVIEW"),
        (False, "rejected", True, "DOCUMENT_REVIEW_NOT_APPROVED"),
        (False, "", False, "DOCUMENT_AUTHORITY_NOT_SELECTED"),
    ],
)
async def test_applied_route_records_deterministic_final_failure(
    monkeypatch,
    needs_review: bool,
    review_status: str,
    authority_selected: bool,
    error_code: str,
) -> None:
    runtime = _configure_final_sink(
        monkeypatch,
        authority_selected=authority_selected,
    )

    await main._sync_document_to_knowledge(
        "task-final",
        _routed_document(
            needs_review=needs_review,
            review_status=review_status,
            applied=True,
        ),
    )

    assert len(runtime.calls) == 1
    assert runtime.calls[0]["success"] is False
    assert runtime.calls[0]["error_code"] == error_code


@pytest.mark.asyncio
async def test_primary_fallback_records_a_route_failure_not_a_success(monkeypatch) -> None:
    runtime = _configure_final_sink(monkeypatch, authority_selected=True)
    document = _routed_document(needs_review=False, applied=True)
    document["extraction"]["metadata"]["route_execution"] = {
        "status": "fallback_applied",
        "backend": "native",
        "primary_backend": "pp_structure_v3",
        "primary_attempted": True,
        "primary_applied": False,
        "fallback_applied": True,
        "outcome_code": "ROUTE_PRIMARY_FALLBACK_APPLIED",
    }

    await main._sync_document_to_knowledge("task-final", document)

    assert len(runtime.calls) == 1
    assert runtime.calls[0]["success"] is False
    assert runtime.calls[0]["error_code"] == "ROUTE_PRIMARY_FALLBACK_APPLIED"


@pytest.mark.asyncio
async def test_mineru_service_does_not_record_route_outcome_before_final_sink() -> None:
    class EarlyRuntime:
        async def record_outcome(self, **_kwargs) -> None:
            raise AssertionError("MinerU service must not record final route outcomes")

    service = object.__new__(MinerUInstructorService)
    service.document_routing_runtime = EarlyRuntime()
    expected = SimpleNamespace(document={"needs_review": False})

    async def run_inner(*_args, **_kwargs):
        return expected

    service._run_pipeline_inner = run_inner

    result = await service._run_pipeline(
        "source.pdf",
        tenant_id="tenant-a",
        task_id="task-a",
        routing_attempt=9,
    )

    assert result is expected
