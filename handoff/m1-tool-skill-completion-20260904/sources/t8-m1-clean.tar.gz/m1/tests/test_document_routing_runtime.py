from __future__ import annotations

import math
from datetime import UTC, datetime
from types import SimpleNamespace
from typing import Any

import pytest
from m1.documents.parsing.adaptive_routing import (
    DocumentRouteModelChoice,
    DocumentRouteSelectionRequest,
    DocumentRouteSignature,
    build_document_route_signature,
)
from m1.documents.parsing.document_routing_runtime import (
    DocumentRoutePolicyProposal,
    DocumentRoutingDependencyError,
    DocumentRoutingRuntime,
    PydanticDocumentRoutePolicyProposer,
    RouteAuthorityPolicy,
    RouteDocumentSubtype,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTablePolicy,
    RouteTableRole,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidencePage,
    EvidenceTable,
)
from m1.knowledge.db_models_base import IdempotencyConflictError
from m1.knowledge.routing_schema import (
    RouteObservationOutcome,
    RouteObservationRecord,
    RouteProfileMatch,
    RouteProfileRecord,
    RouteProfileStatus,
)

VECTOR_SIZE = 1024


def _unit_vector(index: int = 0) -> list[float]:
    vector = [0.0] * VECTOR_SIZE
    vector[index] = 1.0
    return vector


def _cosine(left: list[float], right: list[float]) -> float:
    numerator = sum(a * b for a, b in zip(left, right, strict=True))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    return numerator / (left_norm * right_norm) if left_norm and right_norm else 0.0


def _evidence(
    *,
    labels: tuple[str, ...] = ("order_number", "quantity"),
    secret: str = "示例客户甲有限公司 SO-SECRET-9001",
) -> DocumentEvidence:
    return DocumentEvidence(
        backend="test",
        semantic_labels=labels,
        raw={
            "filename": "客户机密采购单.pdf",
            "customer": "示例客户甲有限公司",
        },
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1400,
                blocks=[
                    EvidenceBlock(block_id="b1", kind="title", text=secret, order=0),
                    EvidenceBlock(
                        block_id="b2",
                        kind="text",
                        text="收货地址：南宁市机密园区 18 号",
                        order=1,
                    ),
                ],
                tables=[
                    EvidenceTable(
                        table_id="t1",
                        rows=[
                            ["订单号", "数量", "客户"],
                            ["SO-SECRET-9001", "1000", "示例客户甲有限公司"],
                        ],
                    )
                ],
            )
        ],
    )


def _order_policy() -> RouteProfilePolicy:
    return RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        document_subtype_hint=RouteDocumentSubtype.PURCHASE_CONTRACT,
        authority_policy=RouteAuthorityPolicy.CORE_STRICT,
    )


def _candidate_document(
    profile: RouteProfileRecord,
    *,
    document_type: str = "order",
    document_subtype: str = "purchase_contract",
    needs_review: bool = False,
    primary_table_ids: tuple[str, ...] = ("t1",),
) -> dict[str, Any]:
    return {
        "schema_version": "m1.document.v2",
        "document_type": document_type,
        "document_subtype": document_subtype,
        "needs_review": needs_review,
        "extraction": {
            "metadata": {
                "evidence_complete": True,
                "accounted_complete": True,
                "retained_complete": True,
                "primary_record_table_ids": list(primary_table_ids),
                "adaptive_routing": {
                    "status": "resolved",
                    "signature_fingerprint": profile.exact_fingerprint,
                    "candidate_profile_id": profile.profile_id,
                    "applied_profile_id": None,
                    "policy_applied": False,
                },
            },
            "raw_content": {
                "pages": [{"tables": [{"table_id": "t1"}]}],
            },
        },
    }


def _topology_only_evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1400,
                blocks=[
                    EvidenceBlock(block_id="opaque", kind="text", text="opaque payload")
                ],
                tables=[
                    EvidenceTable(
                        table_id="t1",
                        rows=[["column_a", "column_b"], ["value_a", "value_b"]],
                    )
                ],
            )
        ],
    )


def _heterogeneous_table_evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1400,
                tables=[
                    EvidenceTable(
                        table_id="records-first",
                        orientation="rows",
                        rows=[
                            ["a", "b", "c", "d"],
                            ["1", "2", "3", "4"],
                        ],
                    ),
                    EvidenceTable(
                        table_id="key-values-second",
                        orientation="columns",
                        rows=[["key", "value"], ["x", "y"]],
                    ),
                ],
            )
        ],
    )


def _active_profile(
    tenant_id: str,
    profile_id: str,
    signature: DocumentRouteSignature,
    *,
    policy: RouteProfilePolicy | None = None,
    embedding: list[float] | None = None,
    embedding_model: str = "test-embedding",
    embedding_dimensions: int = VECTOR_SIZE,
) -> RouteProfileRecord:
    now = datetime.now(UTC)
    return RouteProfileRecord(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=f"key-{profile_id}",
        version=1,
        status=RouteProfileStatus.ACTIVE,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        embedding=embedding,
        embedding_model=embedding_model if embedding is not None else "",
        embedding_dimensions=embedding_dimensions if embedding is not None else 0,
        policy=(policy or _order_policy()).model_dump(mode="json"),
        created_by="test",
        reviewed_by="reviewer",
        reviewed_at=now,
        approved_by="approver",
        approved_at=now,
    )


class FakeEmbeddingProvider:
    model = "test-embedding"
    dimensions = VECTOR_SIZE

    def __init__(self, vector: list[float] | None = None, *, failure: bool = False):
        self.vector = vector or _unit_vector()
        self.failure = failure
        self.inputs: list[str] = []

    async def embed_texts(self, texts) -> list[list[float]]:
        self.inputs.extend(str(text) for text in texts)
        if self.failure:
            raise TimeoutError("provider output must not escape")
        return [list(self.vector) for _text in texts]

    async def close(self) -> None:
        return None


class FakeSelector:
    def __init__(
        self,
        choice: DocumentRouteModelChoice | dict[str, Any] | None = None,
        *,
        failure: bool = False,
    ) -> None:
        self.choice = choice
        self.failure = failure
        self.requests: list[DocumentRouteSelectionRequest] = []

    async def select(self, request: DocumentRouteSelectionRequest):
        self.requests.append(request)
        if self.failure:
            raise RuntimeError("model output must not escape")
        return self.choice or DocumentRouteModelChoice(action="generic", confidence=0.9)


class FakePolicyProposer:
    def __init__(self, output=None, *, failure: bool = False) -> None:
        self.output = output
        self.failure = failure
        self.signatures: list[DocumentRouteSignature] = []

    async def propose(self, signature: DocumentRouteSignature):
        self.signatures.append(signature)
        if self.failure:
            raise RuntimeError("policy model output must not escape")
        return self.output


class FakeStructuredPolicyClient:
    def __init__(self, output: DocumentRoutePolicyProposal) -> None:
        self.output = output
        self.calls: list[dict[str, Any]] = []

    async def run(
        self,
        output_type,
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ):
        self.calls.append(
            {
                "output_type": output_type,
                "instructions": instructions,
                "prompt": prompt,
                "request_limit": request_limit,
            }
        )
        return SimpleNamespace(output=self.output)


class FakeRouteStore:
    def __init__(self) -> None:
        self.profiles: dict[tuple[str, str], RouteProfileRecord] = {}
        self.observations: dict[tuple[str, str], RouteObservationRecord] = {}
        self.embedding_queries: list[tuple[str, int]] = []

    def add(self, profile: RouteProfileRecord) -> None:
        self.profiles[(profile.tenant_id, profile.profile_id)] = profile

    async def get_active_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None:
        return next(
            (
                profile
                for (scope, _profile_id), profile in self.profiles.items()
                if scope == tenant_id
                and profile.status is RouteProfileStatus.ACTIVE
                and profile.exact_fingerprint == exact_fingerprint
            ),
            None,
        )

    async def get_latest_route_profile_by_fingerprint(
        self, tenant_id: str, exact_fingerprint: str
    ) -> RouteProfileRecord | None:
        matches = [
            profile
            for (scope, _profile_id), profile in self.profiles.items()
            if scope == tenant_id and profile.exact_fingerprint == exact_fingerprint
        ]
        return max(matches, key=lambda item: item.version, default=None)

    async def find_route_profiles(
        self,
        tenant_id: str,
        embedding,
        *,
        embedding_model: str,
        embedding_dimensions: int,
        statuses=(RouteProfileStatus.ACTIVE,),
        min_similarity: float = 0.0,
        limit: int = 5,
    ) -> list[RouteProfileMatch]:
        accepted = {RouteProfileStatus(status) for status in statuses}
        query = [float(value) for value in embedding]
        self.embedding_queries.append((embedding_model, embedding_dimensions))
        matches = []
        for (scope, _profile_id), profile in self.profiles.items():
            if (
                scope != tenant_id
                or profile.status not in accepted
                or profile.embedding is None
                or profile.embedding_model != embedding_model
                or profile.embedding_dimensions != embedding_dimensions
            ):
                continue
            similarity = _cosine(query, profile.embedding)
            if similarity >= min_similarity:
                matches.append(
                    RouteProfileMatch(profile=profile, similarity=similarity)
                )
        return sorted(
            matches,
            key=lambda item: (-item.similarity, item.profile.profile_id),
        )[:limit]

    async def create_route_profile(
        self, record: RouteProfileRecord
    ) -> RouteProfileRecord:
        key = (record.tenant_id, record.profile_id)
        existing = self.profiles.get(key)
        if existing is not None:
            return existing
        assert record.status is RouteProfileStatus.CANDIDATE
        if record.supersedes_profile_id is not None:
            previous_key = (record.tenant_id, record.supersedes_profile_id)
            previous = self.profiles[previous_key]
            assert previous.profile_key == record.profile_key
            assert previous.exact_fingerprint == record.exact_fingerprint
            assert previous.version + 1 == record.version
            if previous.status is RouteProfileStatus.CANDIDATE:
                self.profiles[previous_key] = previous.model_copy(
                    update={"status": RouteProfileStatus.DEPRECATED}
                )
        self.profiles[key] = record
        return record

    async def get_route_profile(
        self, tenant_id: str, profile_id: str
    ) -> RouteProfileRecord | None:
        return self.profiles.get((tenant_id, profile_id))

    async def record_route_observation(
        self, record: RouteObservationRecord
    ) -> RouteObservationRecord:
        key = (record.tenant_id, record.idempotency_key)
        existing = self.observations.get(key)
        if existing is not None:
            if (
                existing.profile_id != record.profile_id
                or existing.exact_fingerprint != record.exact_fingerprint
                or existing.outcome != record.outcome
                or existing.latency_ms != record.latency_ms
                or existing.error_code != record.error_code
                or existing.details != record.details
            ):
                raise IdempotencyConflictError(record.idempotency_key)
            return existing
        profile_key = (record.tenant_id, record.profile_id)
        profile = self.profiles[profile_key]
        success = record.outcome is RouteObservationOutcome.SUCCESS
        self.profiles[profile_key] = profile.model_copy(
            update={
                "observation_count": profile.observation_count + 1,
                "success_count": profile.success_count + int(success),
                "failure_count": profile.failure_count + int(not success),
                "last_observed_at": record.observed_at,
                "last_success_at": record.observed_at
                if success
                else profile.last_success_at,
                "last_failure_at": (
                    record.observed_at if not success else profile.last_failure_at
                ),
                "updated_at": record.observed_at,
            }
        )
        self.observations[key] = record
        return record

    async def list_route_observations(
        self,
        tenant_id: str,
        *,
        profile_id: str | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[RouteObservationRecord]:
        values = [
            record
            for (scope, _key), record in self.observations.items()
            if scope == tenant_id
            and (profile_id is None or record.profile_id == profile_id)
        ]
        return values[offset : offset + limit]

    async def activate_route_profile(
        self,
        tenant_id: str,
        profile_id: str,
        *,
        approved_by: str,
        reviewed_by: str | None = None,
        review_note: str = "",
        approved_at: datetime | None = None,
        expected_observation_count: int | None = None,
    ) -> RouteProfileRecord:
        key = (tenant_id, profile_id)
        profile = self.profiles[key]
        if (
            expected_observation_count is not None
            and profile.observation_count != expected_observation_count
        ):
            raise IdempotencyConflictError("route approval observation conflict")
        now = approved_at or datetime.now(UTC)
        assert profile.status is RouteProfileStatus.CANDIDATE
        for other_key, other in list(self.profiles.items()):
            if (
                other_key != key
                and other.tenant_id == tenant_id
                and other.status is RouteProfileStatus.ACTIVE
                and (
                    other.profile_key == profile.profile_key
                    or other.exact_fingerprint == profile.exact_fingerprint
                )
            ):
                self.profiles[other_key] = other.model_copy(
                    update={"status": RouteProfileStatus.DEPRECATED}
                )
        active = profile.model_copy(
            update={
                "status": RouteProfileStatus.ACTIVE,
                "approved_by": approved_by,
                "approved_at": now,
                "reviewed_by": reviewed_by or approved_by,
                "reviewed_at": now,
                "review_note": review_note,
                "updated_at": now,
            }
        )
        self.profiles[key] = active
        return active


@pytest.mark.asyncio
async def test_exact_reuse_is_applied_only_in_guarded_mode() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    store = FakeRouteStore()
    store.add(_active_profile("tenant-a", "route-exact", signature))
    embedding = FakeEmbeddingProvider()

    guarded = DocumentRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        mode="guarded",
    )
    applied = await guarded.resolve(
        "tenant-a", "task-exact", evidence, "application/pdf"
    )
    assert applied.reason == "exact_fingerprint"
    assert applied.recommended_profile_id == "route-exact"
    assert applied.applied_profile_id == "route-exact"
    assert applied.applied_policy == _order_policy()

    shadow = DocumentRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        mode="shadow",
    )
    advisory = await shadow.resolve(
        "tenant-a", "task-shadow", evidence, "application/pdf"
    )
    assert advisory.recommended_profile_id == "route-exact"
    assert advisory.applied_profile_id is None
    assert advisory.applied_policy is None
    assert embedding.inputs == []


@pytest.mark.asyncio
async def test_exact_fingerprint_reuse_is_independent_of_embedding_space() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-exact-old-space",
            signature,
            embedding=_unit_vector(),
            embedding_model="retired-embedding",
        )
    )
    embedding = FakeEmbeddingProvider()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        mode="guarded",
    )

    resolved = await runtime.resolve(
        "tenant-a", "task-exact-old-space", evidence, "application/pdf"
    )

    assert resolved.reason == "exact_fingerprint"
    assert resolved.applied_profile_id == "route-exact-old-space"
    assert embedding.inputs == []
    assert store.embedding_queries == []


@pytest.mark.asyncio
async def test_topology_only_exact_match_requires_model_unless_policy_is_generic() -> (
    None
):
    evidence = _topology_only_evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    assert signature.label_tokens == ()
    store = FakeRouteStore()
    store.add(_active_profile("tenant-a", "route-order", signature))
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        mode="guarded",
    )

    blocked = await runtime.resolve(
        "tenant-a", "task-topology", evidence, "application/pdf"
    )
    assert blocked.recommendation == "generic"
    assert blocked.reason == "exact_requires_model"
    assert blocked.applied_profile_id is None

    generic = _active_profile(
        "tenant-b",
        "route-generic",
        signature,
        policy=RouteProfilePolicy(schema_family=RouteSchemaFamily.GENERIC_LAYOUT),
    )
    store.add(generic)
    allowed = await runtime.resolve(
        "tenant-b", "task-topology", evidence, "application/pdf"
    )
    assert allowed.reason == "exact_fingerprint"
    assert allowed.applied_profile_id == "route-generic"


@pytest.mark.asyncio
async def test_high_vector_match_reuses_without_calling_model() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    candidate_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "vendor_layout")}
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-vector",
            candidate_signature,
            embedding=_unit_vector(),
        )
    )
    selector = FakeSelector(failure=True)
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=selector,
        mode="guarded",
        auto_min_score=0.85,
    )

    resolved = await runtime.resolve(
        "tenant-a", "task-vector", evidence, "application/pdf"
    )
    assert resolved.reason == "vector_auto_reuse"
    assert resolved.applied_profile_id == "route-vector"
    assert resolved.top_score >= 0.85
    assert selector.requests == []
    assert store.embedding_queries == [("test-embedding", VECTOR_SIZE)]


@pytest.mark.asyncio
async def test_vector_reuse_excludes_profiles_from_other_embedding_spaces() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    candidate_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "old-space-layout")}
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-old-space",
            candidate_signature,
            embedding=_unit_vector(),
            embedding_model="retired-embedding",
        )
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        mode="guarded",
    )

    resolved = await runtime.resolve(
        "tenant-a", "task-new-space", evidence, "application/pdf"
    )

    assert resolved.reason == "no_active_profiles"
    assert resolved.applied_profile_id is None
    assert store.embedding_queries == [("test-embedding", VECTOR_SIZE)]
    candidate = await store.get_route_profile(
        "tenant-a", resolved.candidate_profile_id or ""
    )
    assert candidate is not None
    assert (candidate.embedding_model, candidate.embedding_dimensions) == (
        "test-embedding",
        VECTOR_SIZE,
    )


@pytest.mark.asyncio
async def test_model_can_choose_any_eligible_top_three_candidate() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    store = FakeRouteStore()
    for profile_id, token in (("route-a", "layout_a"), ("route-b", "layout_b")):
        candidate_signature = signature.model_copy(
            update={"layout_tokens": (*signature.layout_tokens, token)}
        )
        store.add(
            _active_profile(
                "tenant-a",
                profile_id,
                candidate_signature,
                embedding=_unit_vector(),
            )
        )
    selector = FakeSelector(
        DocumentRouteModelChoice(
            action="reuse",
            candidate_route_id="route-b",
            confidence=0.96,
        )
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=selector,
        mode="guarded",
        auto_min_score=0.99,
        model_min_score=0.70,
    )

    resolved = await runtime.resolve(
        "tenant-a", "task-model", evidence, "application/pdf"
    )
    assert resolved.reason == "model_reuse"
    assert resolved.applied_profile_id == "route-b"
    assert resolved.model_used is True
    assert len(selector.requests) == 1
    assert [item.route_id for item in selector.requests[0].candidates] == [
        "route-a",
        "route-b",
    ]
    contexts = [item.context for item in selector.requests[0].candidates]
    assert all(context is not None for context in contexts)
    assert contexts[0].schema_family == "order"
    assert contexts[0].backend_chain == ("auto",)
    assert contexts[0].table_roles == ()
    assert contexts[0].table_role_count == 0
    assert contexts[0].observation_count == 0
    assert contexts[0].success_rate is None
    # Candidate context is policy-only; source values never reach the selector.
    assert "SO-SECRET-9001" not in selector.requests[0].model_dump_json()


@pytest.mark.asyncio
async def test_model_propose_runs_policy_proposer_before_creating_candidate() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    nearby_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "nearby-layout")}
    )
    policy = _order_policy().model_copy(
        update={
            "table_roles": (
                RouteTablePolicy(table_index=0, role=RouteTableRole.ORDER_LINES),
            )
        }
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-nearby",
            nearby_signature,
            embedding=_unit_vector(),
        )
    )
    selector = FakeSelector(
        DocumentRouteModelChoice(action="propose", confidence=0.99)
    )
    proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=policy, confidence=0.99)
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=selector,
        policy_proposer=proposer,
        mode="guarded",
        auto_min_score=1.0,
        model_min_score=0.0,
    )

    resolution = await runtime.resolve(
        "tenant-a", "task-model-propose", evidence, "application/pdf"
    )

    assert resolution.reason == "model_propose"
    assert resolution.proposal_applied is True
    assert resolution.candidate_profile_id is not None
    candidate = await store.get_route_profile(
        "tenant-a", resolution.candidate_profile_id
    )
    assert candidate is not None
    assert RouteProfilePolicy.model_validate(candidate.policy) == policy
    assert len(proposer.signatures) == 1


@pytest.mark.asyncio
async def test_store_success_does_not_clear_a_failed_model_dependency() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    nearby_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "nearby-layout")}
    )
    store = FakeRouteStore()
    profile = _active_profile(
        "tenant-a", "route-nearby", nearby_signature, embedding=_unit_vector()
    )
    store.add(profile)
    selector = FakeSelector(failure=True)
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=selector,
        mode="guarded",
        auto_min_score=1.0,
        model_min_score=0.0,
    )

    first = await runtime.resolve(
        "tenant-a", "task-model-failure-latch", evidence, "application/pdf"
    )
    assert first.reason == "model_failure"
    assert runtime.status_snapshot()["dependencies"]["model"]["degraded"] is True

    # An exact deterministic lookup exercises the store and profile only.
    exact = profile.model_copy(
        update={"signature": signature, "exact_fingerprint": signature.exact_fingerprint()}
    )
    store.profiles[("tenant-a", profile.profile_id)] = exact
    second = await runtime.resolve(
        "tenant-a", "task-store-recovery-only", evidence, "application/pdf"
    )
    assert second.reason == "exact_fingerprint"
    status = runtime.status_snapshot()
    assert status["dependencies"]["store"]["degraded"] is False
    assert status["dependencies"]["model"]["degraded"] is True
    assert status["degraded"] is True


@pytest.mark.asyncio
async def test_model_failure_fails_closed_and_creates_only_candidate() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    candidate_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "similar_layout")}
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-known",
            candidate_signature,
            embedding=_unit_vector(),
        )
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=FakeSelector(failure=True),
        mode="guarded",
        auto_min_score=0.99,
        model_min_score=0.70,
    )

    resolved = await runtime.resolve(
        "tenant-a", "task-model-failure", evidence, "application/pdf"
    )
    assert resolved.reason == "model_failure"
    assert resolved.recommendation == "generic"
    assert resolved.applied_profile_id is None
    candidate = await store.get_route_profile(
        "tenant-a", resolved.candidate_profile_id or ""
    )
    assert candidate is not None
    assert candidate.status is RouteProfileStatus.CANDIDATE
    status = runtime.status_snapshot()
    assert status["calls"] == 1
    assert status["failures"] == 1
    assert status["fallbacks"] == 1
    assert status["last_error_type"] == "RuntimeError"
    assert status["degraded"] is True
    assert status["dependency_failure"] is True
    assert status["circuit_open"] is False
    assert status["ready"] is False


@pytest.mark.asyncio
async def test_required_model_failure_raises_controlled_error() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    candidate_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "similar_layout")}
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-known",
            candidate_signature,
            embedding=_unit_vector(),
        )
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=FakeSelector(failure=True),
        required=True,
        auto_min_score=0.99,
        model_min_score=0.70,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            "tenant-a", "task-required-model", evidence, "application/pdf"
        )

    assert caught.value.dependency == "model"
    assert caught.value.error_type == "RuntimeError"
    assert runtime.status_snapshot()["fallbacks"] == 0


@pytest.mark.asyncio
async def test_required_invalid_model_output_raises_controlled_error() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    candidate_signature = signature.model_copy(
        update={"layout_tokens": (*signature.layout_tokens, "similar_layout")}
    )
    store = FakeRouteStore()
    store.add(
        _active_profile(
            "tenant-a",
            "route-known",
            candidate_signature,
            embedding=_unit_vector(),
        )
    )
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        selector=FakeSelector({"action": "invented", "confidence": 1.0}),
        required=True,
        auto_min_score=0.99,
        model_min_score=0.70,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            "tenant-a", "task-invalid-model", evidence, "application/pdf"
        )

    assert caught.value.dependency == "model"
    assert caught.value.error_type == "ValidationError"


@pytest.mark.asyncio
@pytest.mark.parametrize("exact_match", [True, False])
async def test_required_invalid_active_policy_fails_closed(
    exact_match: bool,
) -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    stored_signature = (
        signature
        if exact_match
        else signature.model_copy(
            update={"layout_tokens": (*signature.layout_tokens, "nearby_layout")}
        )
    )
    invalid = _active_profile(
        "tenant-a",
        "route-invalid-policy",
        stored_signature,
        embedding=None if exact_match else _unit_vector(),
    ).model_copy(update={"policy": {"schema_family": "invented"}})
    store = FakeRouteStore()
    store.add(invalid)
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            "tenant-a", "task-invalid-active-policy", evidence, "application/pdf"
        )

    assert caught.value.dependency == "profile"
    assert caught.value.error_type == "ValueError"
    status = runtime.status_snapshot()
    assert status["degraded"] is True
    assert status["dependency_failure"] is True


@pytest.mark.asyncio
async def test_optional_invalid_active_policy_falls_back_and_degrades() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    invalid = _active_profile(
        "tenant-a", "route-invalid-policy", signature
    ).model_copy(update={"policy": {"schema_family": "invented"}})
    store = FakeRouteStore()
    store.add(invalid)
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )

    resolution = await runtime.resolve(
        "tenant-a", "task-invalid-active-policy", evidence, "application/pdf"
    )

    assert resolution.reason == "invalid_active_policy"
    assert resolution.applied_profile_id is None
    status = runtime.status_snapshot()
    assert status["degraded"] is True
    assert status["dependency_failure"] is True


def test_required_router_construction_needs_embedding_provider() -> None:
    with pytest.raises(RuntimeError, match="knowledge embedding provider"):
        DocumentRoutingRuntime.from_settings(
            SimpleNamespace(
                document_router_enabled=True,
                document_router_required=True,
            ),
            store=FakeRouteStore(),
            embedding_provider=None,
            model_client=object(),
        )


@pytest.mark.asyncio
async def test_optional_embedding_failure_degrades_then_success_recovers() -> None:
    embedding = FakeEmbeddingProvider(failure=True)
    proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
    )
    runtime = DocumentRoutingRuntime(
        store=FakeRouteStore(),
        embedding_provider=embedding,
        policy_proposer=proposer,
    )

    fallback = await runtime.resolve(
        "tenant-a", "task-embedding-failure", _evidence(), "application/pdf"
    )
    assert fallback.reason == "policy_proposed"
    failed = runtime.status_snapshot()
    assert (failed["calls"], failed["successes"], failed["failures"]) == (1, 0, 1)
    assert failed["last_error_type"] == "TimeoutError"
    assert failed["dependency_failure"] is True

    embedding.failure = False
    recovered = await runtime.resolve(
        "tenant-a", "task-embedding-recovered", _evidence(), "application/pdf"
    )
    assert recovered.reason == "policy_proposed"
    status = runtime.status_snapshot()
    assert (status["calls"], status["successes"], status["failures"]) == (2, 1, 1)
    assert status["fallbacks"] == 2
    assert status["consecutive_failures"] == 0
    assert status["degraded"] is False
    assert status["dependency_failure"] is False
    assert status["ready"] is True
    assert status["last_success_at"] is not None
    assert status["last_failure_at"] is not None


@pytest.mark.asyncio
async def test_required_embedding_and_policy_failures_do_not_create_candidates() -> None:
    store = FakeRouteStore()
    embedding_runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(failure=True),
        policy_proposer=FakePolicyProposer(
            DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
        ),
        required=True,
    )
    with pytest.raises(DocumentRoutingDependencyError) as embedding_error:
        await embedding_runtime.resolve(
            "tenant-a", "task-required-embedding", _evidence(), "application/pdf"
        )
    assert embedding_error.value.dependency == "embedding"
    assert store.profiles == {}

    invalid_embedding_runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(vector=[1.0]),
        policy_proposer=FakePolicyProposer(
            DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
        ),
        required=True,
    )
    with pytest.raises(DocumentRoutingDependencyError) as invalid_embedding:
        await invalid_embedding_runtime.resolve(
            "tenant-a", "task-invalid-embedding", _evidence(), "application/pdf"
        )
    assert invalid_embedding.value.dependency == "embedding"
    assert invalid_embedding.value.error_type == "ValueError"

    policy_runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=FakePolicyProposer(
            {"policy": {"schema_family": "invented"}, "confidence": 1.0}
        ),
        required=True,
    )
    with pytest.raises(DocumentRoutingDependencyError) as policy_error:
        await policy_runtime.resolve(
            "tenant-a", "task-required-policy", _evidence(), "application/pdf"
        )
    assert policy_error.value.dependency == "policy"
    assert store.profiles == {}

    policy_transport_runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=FakePolicyProposer(failure=True),
        required=True,
    )
    with pytest.raises(DocumentRoutingDependencyError) as policy_transport:
        await policy_transport_runtime.resolve(
            "tenant-a", "task-policy-transport", _evidence(), "application/pdf"
        )
    assert policy_transport.value.dependency == "policy"
    assert policy_transport.value.error_type == "RuntimeError"
    assert store.profiles == {}


@pytest.mark.asyncio
async def test_store_failure_status_contains_only_exception_type() -> None:
    class FailingStore(FakeRouteStore):
        async def get_active_route_profile_by_fingerprint(
            self, tenant_id: str, exact_fingerprint: str
        ) -> RouteProfileRecord | None:
            raise OSError("private database address and credential")

    runtime = DocumentRoutingRuntime(
        store=FailingStore(),
        embedding_provider=FakeEmbeddingProvider(),
    )
    with pytest.raises(OSError, match="private database"):
        await runtime.resolve(
            "tenant-a", "task-store-failure", _evidence(), "application/pdf"
        )

    status = runtime.status_snapshot()
    assert status["last_error_type"] == "OSError"
    assert "private" not in str(status)
    assert status["dependency_failure"] is True


@pytest.mark.asyncio
async def test_outcome_store_failure_updates_router_status() -> None:
    class FailingOutcomeStore(FakeRouteStore):
        async def get_route_profile(
            self, tenant_id: str, profile_id: str
        ) -> RouteProfileRecord | None:
            raise OSError("private database address and credential")

    runtime = DocumentRoutingRuntime(
        store=FailingOutcomeStore(),
        embedding_provider=FakeEmbeddingProvider(),
    )

    with pytest.raises(OSError, match="private database"):
        await runtime.record_outcome(
            tenant_id="tenant-a",
            task_id="task-outcome-store-failure",
            profile_id="route-a",
            success=True,
        )

    status = runtime.status_snapshot()
    assert status["calls"] == 1
    assert status["failures"] == 1
    assert status["last_error_type"] == "OSError"
    assert status["dependency_failure"] is True
    assert "private" not in str(status)


@pytest.mark.asyncio
async def test_no_match_candidate_and_embedding_contain_no_document_values() -> None:
    secret = "王某 13800000000 合同 SO-SECRET-9001"
    task_id = "task-customer-secret-9001"
    evidence = _evidence(secret=secret)
    store = FakeRouteStore()
    embedding = FakeEmbeddingProvider()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        mode="guarded",
    )

    resolved = await runtime.resolve(
        "tenant-a", task_id, evidence, "客户机密采购单.pdf"
    )
    assert resolved.reason == "no_active_profiles"
    assert resolved.recommendation == "generic"
    assert resolved.applied_profile_id is None
    candidate = await store.get_route_profile(
        "tenant-a", resolved.candidate_profile_id or ""
    )
    assert candidate is not None
    persisted = candidate.model_dump_json()
    embedded = "\n".join(embedding.inputs)
    for forbidden in (
        "王某",
        "13800000000",
        "SO-SECRET-9001",
        "示例客户甲有限公司",
        "客户机密采购单",
        task_id,
    ):
        assert forbidden not in persisted
        assert forbidden not in embedded
    assert RouteProfilePolicy.model_validate(candidate.policy).schema_family is (
        RouteSchemaFamily.GENERIC_LAYOUT
    )


@pytest.mark.asyncio
async def test_generic_candidate_cannot_collect_runtime_outcomes_or_activate() -> None:
    evidence = _evidence()
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        mode="guarded",
        min_activation_samples=2,
    )
    resolution = await runtime.resolve(
        "tenant-a", "task-first", evidence, "application/pdf"
    )
    profile_id = resolution.candidate_profile_id or ""

    with pytest.raises(ValueError, match="explicit route review approval"):
        await runtime.approve_candidate(
            tenant_id="tenant-a",
            profile_id=profile_id,
            review_approved=False,
            approved_by="approver",
            reviewed_by="reviewer",
        )
    with pytest.raises(ValueError, match="generic/open-domain"):
        await runtime.approve_candidate(
            tenant_id="tenant-a",
            profile_id=profile_id,
            review_approved=True,
            approved_by="approver",
            reviewed_by="reviewer",
        )

    with pytest.raises(ValueError, match="active profile"):
        await runtime.record_outcome(
            tenant_id="tenant-a",
            task_id="task-first",
            profile_id=profile_id,
            success=True,
        )
    profile = await store.get_route_profile("tenant-a", profile_id)
    assert profile is not None
    assert (profile.observation_count, profile.success_count, profile.failure_count) == (
        0,
        0,
        0,
    )


@pytest.mark.asyncio
async def test_outcome_attempt_cannot_mint_a_second_governance_sample() -> None:
    evidence = _evidence()
    store = FakeRouteStore()
    signature = build_document_route_signature(evidence, "application/pdf")
    active = _active_profile("tenant-a", "route-active", signature)
    store.add(active)
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )
    profile_id = active.profile_id

    failed = await runtime.record_outcome(
        tenant_id="tenant-a",
        task_id="task-retry",
        profile_id=profile_id,
        success=False,
        error_code="DOCUMENT_EXTRACTION_FAILED",
        attempt=1,
    )
    replay = await runtime.record_outcome(
        tenant_id="tenant-a",
        task_id="task-retry",
        profile_id=profile_id,
        success=False,
        error_code="DOCUMENT_EXTRACTION_FAILED",
        attempt=1,
    )
    with pytest.raises(IdempotencyConflictError):
        await runtime.record_outcome(
            tenant_id="tenant-a",
            task_id="task-retry",
            profile_id=profile_id,
            success=True,
            attempt=2,
        )

    assert replay.observation_id == failed.observation_id
    assert ":attempt:" not in failed.idempotency_key
    assert failed.details["attempt"] == 1
    updated = await store.get_route_profile("tenant-a", profile_id)
    assert updated is not None
    assert (updated.observation_count, updated.failure_count, updated.success_count) == (
        1,
        1,
        0,
    )


@pytest.mark.asyncio
async def test_route_profiles_are_tenant_isolated() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    store = FakeRouteStore()
    store.add(_active_profile("tenant-a", "route-a", signature))
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        mode="guarded",
    )

    first = await runtime.resolve(
        "tenant-a", "task-shared", evidence, "application/pdf"
    )
    second = await runtime.resolve(
        "tenant-b", "task-shared", evidence, "application/pdf"
    )
    assert first.applied_profile_id == "route-a"
    assert second.applied_profile_id is None
    assert second.candidate_profile_id != "route-a"
    candidate = await store.get_route_profile(
        "tenant-b", second.candidate_profile_id or ""
    )
    assert candidate is not None and candidate.tenant_id == "tenant-b"


@pytest.mark.asyncio
async def test_observe_candidate_rejects_untyped_policy_mapping() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    runtime = DocumentRoutingRuntime(
        store=FakeRouteStore(),
        embedding_provider=FakeEmbeddingProvider(),
    )

    with pytest.raises(TypeError, match="RouteProfilePolicy"):
        await runtime.observe_candidate(
            tenant_id="tenant-a",
            task_id="task-a",
            signature=signature,
            policy={"schema_family": "order", "raw": "secret"},  # type: ignore[arg-type]
        )


@pytest.mark.asyncio
async def test_generic_candidate_can_be_superseded_by_specialized_revision() -> None:
    evidence = _evidence()
    signature = build_document_route_signature(evidence, "application/pdf")
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )
    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-first",
        signature=signature,
        embedding=None,
    )
    replay = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-retry",
        signature=signature,
        embedding=_unit_vector(),
    )
    assert replay.profile_id == candidate.profile_id
    assert replay.embedding is None

    specialized = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-policy-change",
        signature=signature,
        policy=_order_policy(),
    )
    previous = await store.get_route_profile("tenant-a", candidate.profile_id)
    assert specialized.version == 2
    assert specialized.profile_id.endswith("-v2")
    assert specialized.profile_key == candidate.profile_key
    assert specialized.supersedes_profile_id == candidate.profile_id
    assert previous is not None
    assert previous.status is RouteProfileStatus.DEPRECATED

    replay_specialized = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-specialized-retry",
        signature=signature,
        policy=_order_policy(),
    )
    assert replay_specialized.profile_id == specialized.profile_id

    generic_retry = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-generic-after-specialized",
        signature=signature,
    )
    assert generic_retry.profile_id == specialized.profile_id
    assert len(store.profiles) == 2


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "terminal_status",
    [RouteProfileStatus.REJECTED, RouteProfileStatus.DEPRECATED],
)
async def test_terminal_route_can_start_next_specialized_revision(
    terminal_status: RouteProfileStatus,
) -> None:
    signature = build_document_route_signature(_evidence(), "application/pdf")
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )
    first = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-generic",
        signature=signature,
    )
    store.profiles[(first.tenant_id, first.profile_id)] = first.model_copy(
        update={"status": terminal_status}
    )

    revision = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="task-specialized",
        signature=signature,
        policy=_order_policy(),
    )

    assert revision.version == 2
    assert revision.supersedes_profile_id == first.profile_id
    assert RouteProfilePolicy.model_validate(revision.policy) == _order_policy()


@pytest.mark.asyncio
async def test_candidate_table_roles_follow_stable_evidence_table_indexes() -> None:
    evidence = _heterogeneous_table_evidence()
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        mode="guarded",
    )

    resolution = await runtime.resolve(
        "tenant-a", "task-two-tables", evidence, "application/pdf"
    )
    candidate = await store.get_route_profile(
        "tenant-a", resolution.candidate_profile_id or ""
    )
    assert candidate is not None
    assert [shape.table_index for shape in candidate.signature.table_shapes] == [0, 1]
    policy = RouteProfilePolicy.model_validate(candidate.policy)
    assert [(item.table_index, item.role) for item in policy.table_roles] == [
        (0, RouteTableRole.REPEATED_RECORDS),
        (1, RouteTableRole.KEY_VALUE),
    ]


@pytest.mark.asyncio
async def test_no_match_model_proposes_typed_order_candidate_but_cannot_activate_it() -> None:
    evidence = _evidence()
    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        document_subtype_hint=RouteDocumentSubtype.PURCHASE_CONTRACT,
        table_roles=(RouteTablePolicy(table_index=0, role=RouteTableRole.ORDER_LINES),),
        authority_policy=RouteAuthorityPolicy.CORE_STRICT,
    )
    proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=policy, confidence=0.96)
    )
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=proposer,
        mode="guarded",
        min_activation_samples=2,
    )

    resolution = await runtime.resolve(
        "tenant-a", "task-proposed-order", evidence, "application/pdf"
    )
    assert resolution.reason == "policy_proposed"
    assert resolution.recommendation == "propose"
    assert resolution.proposal_applied is True
    assert resolution.proposal_schema_family is RouteSchemaFamily.ORDER
    assert resolution.applied_profile_id is None
    candidate = await store.get_route_profile(
        "tenant-a", resolution.candidate_profile_id or ""
    )
    assert candidate is not None
    assert candidate.status is RouteProfileStatus.CANDIDATE
    assert RouteProfilePolicy.model_validate(candidate.policy) == policy

    with pytest.raises(ValueError, match="successful observation threshold"):
        await runtime.approve_candidate(
            tenant_id="tenant-a",
            profile_id=candidate.profile_id,
            review_approved=True,
            approved_by="approver",
            reviewed_by="reviewer",
        )
    validation_records = []
    for task_id in ("validated-a", "validated-b"):
        validation_records.append(
            await runtime.record_candidate_validation(
                tenant_id="tenant-a",
                task_id=task_id,
                profile_id=candidate.profile_id,
                document=_candidate_document(candidate),
                knowledge_version_id=f"version-{task_id}",
                decision="approve",
                reviewed_by="route-reviewer",
                review_note="policy and final structure agree",
            )
        )
    persisted = [item.model_dump(mode="json") for item in validation_records]
    assert all(item.outcome is RouteObservationOutcome.SUCCESS for item in validation_records)
    assert "validated-a" not in str(persisted)
    assert "policy and final structure agree" not in str(persisted)
    assert all(
        item.details["check_codes"] == ["ROUTE_POLICY_PREFLIGHT_PASSED"]
        for item in validation_records
    )
    assert all(
        item.details["validation_scope"] == "classification_and_table_roles"
        and item.details["advisory_fields"]
        == ["verifier_policy", "authority_policy"]
        for item in validation_records
    )
    with pytest.raises(ValueError, match="active profile"):
        await runtime.record_outcome(
            tenant_id="tenant-a",
            task_id="generic-success-does-not-count",
            profile_id=candidate.profile_id,
            success=True,
        )
    active = await runtime.approve_candidate(
        tenant_id="tenant-a",
        profile_id=candidate.profile_id,
        review_approved=True,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="two explicit route validations",
    )
    assert active.status is RouteProfileStatus.ACTIVE
    reused = await runtime.resolve(
        "tenant-a", "task-after-approval", evidence, "application/pdf"
    )
    assert reused.applied_policy == policy


@pytest.mark.asyncio
async def test_candidate_activation_ignores_generic_success_and_blocks_failed_review() -> None:
    evidence = _evidence()
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        min_activation_samples=1,
    )
    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="candidate-source",
        signature=build_document_route_signature(evidence, "application/pdf"),
        policy=_order_policy(),
    )
    generic_observation = RouteObservationRecord(
        tenant_id="tenant-a",
        profile_id=candidate.profile_id,
        idempotency_key="legacy-generic-success",
        exact_fingerprint=candidate.exact_fingerprint,
        outcome=RouteObservationOutcome.SUCCESS,
        details={"kind": "applied_policy_outcome", "task_ref": "c" * 64},
    )
    await store.record_route_observation(generic_observation)
    with pytest.raises(ValueError, match="successful observation threshold"):
        await runtime.approve_candidate(
            tenant_id="tenant-a",
            profile_id=candidate.profile_id,
            review_approved=True,
            approved_by="approver",
            reviewed_by="reviewer",
        )

    document = _candidate_document(
        candidate,
        document_subtype="supplier_purchase_order",
    )
    document["header"] = {"customer": "PRIVATE CUSTOMER VALUE"}
    failed = await runtime.record_candidate_validation(
        tenant_id="tenant-a",
        task_id="failed-sensitive-task",
        profile_id=candidate.profile_id,
        document=document,
        knowledge_version_id="version-failed-sensitive-task",
        decision="approve",
        reviewed_by="route-reviewer",
        review_note="subtype does not agree",
    )

    assert failed.outcome is RouteObservationOutcome.FAILURE
    assert failed.error_code == "ROUTE_POLICY_PREFLIGHT_FAILED"
    assert "ROUTE_DOCUMENT_SUBTYPE_MISMATCH" in failed.details["check_codes"]
    serialized = failed.model_dump_json()
    assert "PRIVATE CUSTOMER VALUE" not in serialized
    assert "failed-sensitive-task" not in serialized
    assert "subtype does not agree" not in serialized
    with pytest.raises(ValueError, match="failed explicit validation"):
        await runtime.approve_candidate(
            tenant_id="tenant-a",
            profile_id=candidate.profile_id,
            review_approved=True,
            approved_by="approver",
            reviewed_by="reviewer",
        )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("role", "primary_table_ids", "expected_code"),
    [
        (RouteTableRole.ORDER_LINES, (), "ROUTE_PRIMARY_TABLE_ROLE_MISMATCH"),
        (
            RouteTableRole.KEY_VALUE,
            ("t1",),
            "ROUTE_NONPRIMARY_TABLE_ROLE_MISMATCH",
        ),
    ],
)
async def test_candidate_preflight_rejects_table_role_mismatch(
    role: RouteTableRole,
    primary_table_ids: tuple[str, ...],
    expected_code: str,
) -> None:
    evidence = _evidence()
    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        document_subtype_hint=RouteDocumentSubtype.PURCHASE_CONTRACT,
        table_roles=(RouteTablePolicy(table_index=0, role=role),),
    )
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )
    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id=f"candidate-{role}",
        signature=build_document_route_signature(evidence, "application/pdf"),
        policy=policy,
    )

    observation = await runtime.record_candidate_validation(
        tenant_id="tenant-a",
        task_id=f"validated-{role}",
        profile_id=candidate.profile_id,
        document=_candidate_document(
            candidate,
            primary_table_ids=primary_table_ids,
        ),
        knowledge_version_id=f"version-{role}",
        decision="approve",
        reviewed_by="route-reviewer",
        review_note="checked table role",
    )

    assert observation.outcome is RouteObservationOutcome.FAILURE
    assert expected_code in observation.details["check_codes"]


@pytest.mark.asyncio
async def test_candidate_validation_is_idempotent_per_task_and_policy() -> None:
    evidence = _evidence()
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
    )
    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        task_id="candidate-source",
        signature=build_document_route_signature(evidence, "application/pdf"),
        policy=_order_policy(),
    )
    kwargs = {
        "tenant_id": "tenant-a",
        "task_id": "validated-once",
        "profile_id": candidate.profile_id,
        "document": _candidate_document(candidate),
        "knowledge_version_id": "version-validated-once",
        "decision": "approve",
        "reviewed_by": "route-reviewer",
        "review_note": "validated once",
    }

    first = await runtime.record_candidate_validation(**kwargs)
    replay = await runtime.record_candidate_validation(**kwargs)

    assert replay.observation_id == first.observation_id
    with pytest.raises(IdempotencyConflictError):
        await runtime.record_candidate_validation(
            **{**kwargs, "decision": "reject"},
        )
    profile = await store.get_route_profile("tenant-a", candidate.profile_id)
    assert profile is not None
    assert (profile.observation_count, profile.success_count, profile.failure_count) == (
        1,
        1,
        0,
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("proposal", "reason"),
    [
        (
            DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.50),
            "policy_proposal_low_confidence",
        ),
        (
            {
                "policy": {
                    **_order_policy().model_dump(mode="json"),
                    "field_map": {"$.lines[*].quantity": "raw-secret-value"},
                },
                "confidence": 0.99,
            },
            "policy_proposal_invalid",
        ),
    ],
)
async def test_low_confidence_or_arbitrary_policy_output_does_not_freeze_candidate(
    proposal, reason: str
) -> None:
    evidence = _evidence()
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=FakePolicyProposer(proposal),
        mode="guarded",
    )

    resolution = await runtime.resolve(
        "tenant-a", f"task-{reason}", evidence, "application/pdf"
    )
    assert resolution.reason == reason
    assert resolution.recommendation == "generic"
    assert resolution.proposal_applied is False
    assert resolution.candidate_profile_id is None
    assert store.profiles == {}


@pytest.mark.asyncio
async def test_policy_proposer_failure_does_not_freeze_later_specialized_candidate() -> None:
    proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99),
        failure=True,
    )
    store = FakeRouteStore()
    runtime = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=proposer,
    )
    failed = await runtime.resolve(
        "tenant-a", "task-proposer-failure", _evidence(), "application/pdf"
    )
    assert failed.reason == "policy_proposal_failure"
    assert failed.candidate_profile_id is None
    assert store.profiles == {}

    recovered = DocumentRoutingRuntime(
        store=store,
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=FakePolicyProposer(
            DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
        ),
    )
    proposed = await recovered.resolve(
        "tenant-a", "task-proposer-recovered", _evidence(), "application/pdf"
    )
    assert proposed.reason == "policy_proposed"
    candidate = await store.get_route_profile(
        "tenant-a", proposed.candidate_profile_id or ""
    )
    assert candidate is not None
    assert RouteProfilePolicy.model_validate(candidate.policy) == _order_policy()


@pytest.mark.asyncio
async def test_missing_labels_stays_generic_without_calling_policy_model() -> None:

    no_labels_proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
    )
    no_labels_runtime = DocumentRoutingRuntime(
        store=FakeRouteStore(),
        embedding_provider=FakeEmbeddingProvider(),
        policy_proposer=no_labels_proposer,
    )
    no_labels = await no_labels_runtime.resolve(
        "tenant-a", "task-no-labels", _topology_only_evidence(), "application/pdf"
    )
    assert no_labels.reason == "no_active_profiles"
    assert no_labels.proposal_applied is False
    assert no_labels_proposer.signatures == []
    status = no_labels_runtime.status_snapshot()
    assert (status["successes"], status["failures"], status["fallbacks"]) == (
        1,
        0,
        1,
    )
    assert status["dependency_failure"] is False
    assert status["ready"] is True


@pytest.mark.asyncio
async def test_embedding_unavailable_still_allows_sanitized_policy_proposal() -> None:
    proposer = FakePolicyProposer(
        DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
    )
    runtime = DocumentRoutingRuntime(
        store=FakeRouteStore(),
        embedding_provider=None,
        policy_proposer=proposer,
    )

    resolution = await runtime.resolve(
        "tenant-a", "task-no-embedding", _evidence(), "application/pdf"
    )

    assert resolution.reason == "policy_proposed"
    assert resolution.candidate_profile_id is not None
    assert len(proposer.signatures) == 1


def test_from_settings_propagates_required_semantics() -> None:
    client = FakeStructuredPolicyClient(
        DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.99)
    )
    settings = SimpleNamespace(
        document_router_enabled=True,
        document_router_api_key="test-secret-not-observed",
        document_router_base_url="http://router.invalid/v1",
        document_router_model="small-router",
        document_router_timeout_seconds=10,
        document_router_mode="guarded",
        document_router_top_k=3,
        document_router_auto_min_score=0.90,
        document_router_model_min_score=0.75,
        document_router_min_margin=0.08,
        document_router_min_activation_samples=2,
        document_router_required=True,
    )

    runtime = DocumentRoutingRuntime.from_settings(
        settings,
        store=FakeRouteStore(),
        embedding_provider=FakeEmbeddingProvider(),
        model_client=client,
    )

    assert runtime.required is True


@pytest.mark.asyncio
async def test_pydantic_policy_proposer_prompt_contains_only_sanitized_signature() -> None:
    evidence = _evidence(
        secret="PRIVATE PERSON 13800000000 ORDER SO-SECRET-9001"
    )
    signature = build_document_route_signature(evidence, "private-order.pdf")
    output = DocumentRoutePolicyProposal(policy=_order_policy(), confidence=0.92)
    client = FakeStructuredPolicyClient(output)
    proposer = PydanticDocumentRoutePolicyProposer(client)

    assert await proposer.propose(signature) == output
    assert len(client.calls) == 1
    call = client.calls[0]
    assert call["output_type"] is DocumentRoutePolicyProposal
    assert call["request_limit"] == 1
    assert call["prompt"] == signature.model_dump_json()
    for forbidden in (
        "PRIVATE PERSON",
        "13800000000",
        "SO-SECRET-9001",
        "private-order.pdf",
        "$.lines",
    ):
        assert forbidden not in str(call["prompt"])
