from __future__ import annotations

import base64
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import m1.documents.spreadsheets as spreadsheet_module
import pytest
from m1.documents import (
    UnsupportedSpreadsheetError,
    parse_spreadsheet_document,
    parse_spreadsheet_envelope,
    sniff_file_type,
)
from m1.documents.envelope import ImageAnchor, SheetEnvelope
from m1.documents.image_roles import classify_image_role
from m1.documents.orders import TableRegion
from m1.review_policy import assess_document_review


def _write_synthetic_xlsx(path: Path) -> None:
    content_types = """<?xml version="1.0" encoding="UTF-8"?>
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
      <Default Extension="xml" ContentType="application/xml"/>
      <Default Extension="png" ContentType="image/png"/>
      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    </Types>"""
    workbook = """<?xml version="1.0" encoding="UTF-8"?>
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <sheets><sheet name="订单" sheetId="1" r:id="rId1"/></sheets>
    </workbook>"""
    workbook_rels = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    </Relationships>"""

    def inline(ref: str, value: str) -> str:
        return f'<c r="{ref}" t="inlineStr"><is><t>{value}</t></is></c>'

    rows = [
        f'<row r="1">{inline("A1", "备货单")}</row>',
        f'<row r="2">{inline("A2", "订单号：TX2607150002")}{inline("H2", "旧号 TX2607110001")}</row>',
        f'<row r="3">{inline("A3", "下单日期：7月15日")}</row>',
        '<row r="4">'
        + "".join(
            inline(ref, value)
            for ref, value in (
                ("A4", "序号"),
                ("B4", "产品图片"),
                ("C4", "型号"),
                ("D4", "名称"),
                ("E4", "规格"),
                ("F4", "备货数量"),
                ("G4", "单位"),
                ("H4", "内部字段"),
            )
        )
        + "</row>",
        '<row r="5">'
        + inline("A5", "1")
        + inline("C5", "M-1")
        + inline("D5", "中性 DP1.4 8K60Hz")
        + inline("E5", "1M")
        + '<c r="F5"><v>1</v></c>'
        + inline("G5", "PCS")
        + inline("H5", "A")
        + "</row>",
        '<row r="6">'
        + inline("A6", "2")
        + inline("C6", "M-2")
        + inline("E6", "2M")
        + '<c r="F6"><v>2</v></c>'
        + inline("G6", "PCS")
        + "</row>",
        '<row r="7">'
        + inline("A7", "3")
        + '<c r="B7" t="str"><f>DISPIMG(&quot;ID_CELL&quot;,1)</f><v>ID_CELL</v></c>'
        + inline("C7", "M-3")
        + inline("E7", "3M")
        + '<c r="F7"><v>3</v></c>'
        + inline("G7", "PCS")
        + "</row>",
        '<row r="8">'
        + inline("E8", "合计数量")
        + '<c r="F8"><f>SUM(F5:F7)</f><v>6</v></c>'
        + "</row>",
    ]
    worksheet = f"""<?xml version="1.0" encoding="UTF-8"?>
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <dimension ref="A1:H8"/>
      <cols><col min="8" max="8" hidden="1" width="2"/></cols>
      <sheetData>{''.join(rows)}</sheetData>
      <mergeCells count="2"><mergeCell ref="B5:B6"/><mergeCell ref="D5:D6"/></mergeCells>
      <drawing r:id="rId1"/>
    </worksheet>"""
    sheet_rels = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>
    </Relationships>"""
    drawing = """<?xml version="1.0" encoding="UTF-8"?>
    <xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <xdr:twoCellAnchor><xdr:from><xdr:col>1</xdr:col><xdr:row>4</xdr:row></xdr:from>
        <xdr:to><xdr:col>1</xdr:col><xdr:row>5</xdr:row></xdr:to>
        <xdr:pic><xdr:nvPicPr><xdr:cNvPr id="1" name="synthetic"/></xdr:nvPicPr>
          <xdr:blipFill><a:blip r:embed="rId1"/></xdr:blipFill></xdr:pic><xdr:clientData/>
      </xdr:twoCellAnchor>
    </xdr:wsDr>"""
    drawing_rels = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.png"/>
    </Relationships>"""
    cell_images = """<?xml version="1.0" encoding="UTF-8"?>
    <etc:cellImages xmlns:etc="http://www.wps.cn/officeDocument/2017/etCustomData"
      xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <etc:cellImage><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="ID_CELL"/></xdr:nvPicPr>
        <xdr:blipFill><a:blip r:embed="rId1"/></xdr:blipFill></xdr:pic></etc:cellImage>
    </etc:cellImages>"""
    cell_image_rels = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image2.png"/>
    </Relationships>"""
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        for name, payload in {
            "[Content_Types].xml": content_types,
            "xl/workbook.xml": workbook,
            "xl/_rels/workbook.xml.rels": workbook_rels,
            "xl/worksheets/sheet1.xml": worksheet,
            "xl/worksheets/_rels/sheet1.xml.rels": sheet_rels,
            "xl/drawings/drawing1.xml": drawing,
            "xl/drawings/_rels/drawing1.xml.rels": drawing_rels,
            "xl/cellimages.xml": cell_images,
            "xl/_rels/cellimages.xml.rels": cell_image_rels,
        }.items():
            archive.writestr(name, payload)
        pixel = base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        )
        archive.writestr("xl/media/image1.png", pixel)
        archive.writestr("xl/media/image2.png", pixel)


def test_magic_does_not_trust_binary_jpeg_extension(tmp_path: Path) -> None:
    fake = tmp_path / "payload.jpg"
    fake.write_bytes(b"not an image\x00\x01")
    assert sniff_file_type(fake).kind == "unknown"
    with pytest.raises(UnsupportedSpreadsheetError):
        parse_spreadsheet_envelope(fake)


def test_csv_gb18030_and_utf8_are_supported(tmp_path: Path) -> None:
    csv_path = tmp_path / "订单.csv"
    csv_path.write_bytes("序号,型号,数量\n1,A-1,2\n".encode("gb18030"))
    envelope = parse_spreadsheet_envelope(csv_path)
    assert envelope.file_kind == "csv"
    assert envelope.sheets[0].cell(1, 2).value == "型号"
    assert envelope.sheets[0].cell(2, 3).value == "2"


def test_ooxml_formula_merge_hidden_and_both_image_kinds(tmp_path: Path) -> None:
    workbook = tmp_path / "synthetic.xlsx"
    _write_synthetic_xlsx(workbook)
    envelope = parse_spreadsheet_envelope(workbook)
    sheet = envelope.sheets[0]
    total = sheet.cell(8, 6)
    assert total.formula == "SUM(F5:F7)"
    assert total.cached_value == 6
    inherited = sheet.cell(6, 4, inherit_merged=True)
    assert inherited.value == "中性 DP1.4 8K60Hz"
    assert inherited.inherited_from == "D5"
    assert sheet.cell(7, 4, inherit_merged=True) is None
    assert 8 in sheet.hidden_columns
    assert {image.source_kind for image in sheet.images} == {"drawing", "wps_cell_image"}


def test_xlsx_ignores_style_only_cells_and_bounds_duplicate_overlay(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    from openpyxl.styles import PatternFill

    source = tmp_path / "style-only.xlsx"
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "material_code"
    sheet["A2"] = "RAW-001"
    sheet["Z500"].fill = PatternFill(fill_type="solid", fgColor="FFFF00")
    workbook.save(source)
    workbook.close()
    monkeypatch.setattr(
        spreadsheet_module,
        "_OPENPYXL_OVERLAY_MAX_WORKSHEET_XML_BYTES",
        1,
    )

    envelope = parse_spreadsheet_envelope(source)

    parsed = envelope.sheets[0]
    assert parsed.cell(1, 1).value == "material_code"
    assert parsed.cell(2, 1).value == "RAW-001"
    assert parsed.cell(500, 26) is None
    assert parsed.max_row == 2
    assert parsed.max_column == 1
    assert any(
        warning.startswith("openpyxl_overlay_skipped_large_worksheet_xml:")
        for warning in envelope.warnings
    )


def test_hidden_and_wps_reserved_sheets_do_not_create_business_rows(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    visible = workbook.active
    visible.title = "订单"
    for column, value in enumerate(["序号", "型号", "名称", "数量", "单位"], 1):
        visible.cell(1, column, value)
    for column, value in enumerate([1, "M-1", "DP线", 2, "PCS"], 1):
        visible.cell(2, column, value)
    hidden = workbook.create_sheet("WpsReserved_CellImgList")
    hidden.sheet_state = "hidden"
    hidden["A1"] = "BAD"
    hidden["B1"] = 999
    source = tmp_path / "wps-hidden.xlsx"
    workbook.save(source)

    envelope = parse_spreadsheet_envelope(source)
    assert [sheet.name for sheet in envelope.sheets] == ["订单"]
    assert any("hidden_sheet_skipped" in warning for warning in envelope.warnings)
    document = parse_spreadsheet_document(source)
    assert [line.model for line in document.lines] == ["M-1"]
    assert document.totals.calculated_quantity == 2


def test_synthetic_order_mapping_and_explicit_merge_inheritance(tmp_path: Path) -> None:
    workbook = tmp_path / "TX2607150002.xlsx"
    _write_synthetic_xlsx(workbook)
    document = parse_spreadsheet_document(workbook)
    assert document.schema_version == "m1.document.v2"
    assert document.document_subtype == "stocking_order"
    assert document.header.order_number == "TX2607150002"
    assert document.header.date_standard.isoformat() == "2026-07-15"
    assert document.header.date_inferred is True
    assert [line.quantity for line in document.lines] == [1, 2, 3]
    assert document.totals.calculated_quantity == 6
    assert document.totals.declared_quantity == 6
    assert document.totals.quantity_matches is True
    assert document.lines[0].name_raw == document.lines[1].name_raw
    assert document.lines[2].name_raw is None
    assert document.lines[0].custom_fields == {"内部字段": "A"}
    assert document.lines[1].custom_fields == {"内部字段": None}
    assert document.lines[0].image_refs == document.lines[1].image_refs
    assert document.lines[2].image_refs != document.lines[1].image_refs
    assert len(document.bom) == 3


def test_headerless_compact_order_is_recovered_conservatively(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "12.8"
    sheet["A1"] = "3月31日刘娟林光纤订单"
    values = [
        1,
        None,
        "光纤线-铜包钢-银色锌合金",
        "30M",
        "PCS",
        "壳子印字：NYK",
        "打大轴",
        "客供彩盒+标签+覆膜",
        "线头标",
        300,
        10,
        30,
        "53*42*27",
        None,
    ]
    for column, value in enumerate(values, 1):
        sheet.cell(2, column, value)
    sheet["A4"] = "总件数："
    sheet["J4"] = 300
    source = tmp_path / "4月23日深圳优特比光纤订单.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_type == "order"
    assert len(document.lines) == 1
    line = document.lines[0]
    assert line.name_raw == "光纤线-铜包钢-银色锌合金"
    assert line.specification_raw == "30M"
    assert line.quantity == 300
    assert line.package_quantity == 10
    assert line.piece_count == 30
    assert line.carton_specification == "53*42*27"
    assert "HEADERLESS_TABLE_INFERRED" in {
        issue.code for issue in document.validation_issues
    }


def test_supplier_contract_header_and_declared_amount_are_extracted(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "义乌供应商采购合同"
    sheet["A2"] = "合同编号：HT-001"
    sheet["D2"] = "交期：2026-07-20"
    sheet["A3"] = "买方：云派科技"
    sheet["D3"] = "供应商：义乌线缆厂"
    sheet["A4"] = "结算方式：月结30天"
    sheet["D4"] = "交货地址：深圳市"
    sheet["G4"] = "币种：RMB"
    headers = ["序号", "型号", "名称", "数量", "单位", "未税单价", "未税金额"]
    for column, value in enumerate(headers, 1):
        sheet.cell(6, column, value)
    rows = [
        [1, "M-1", "DP线", 2, "PCS", 10, 20],
        [2, "M-2", "HDMI线", 3, "PCS", 10, 30],
    ]
    for row_index, values in enumerate(rows, 7):
        for column, value in enumerate(values, 1):
            sheet.cell(row_index, column, value)
    sheet["A9"] = "合计"
    sheet["D9"] = 5
    sheet["G9"] = 50
    source = tmp_path / "义乌采购合同.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_subtype == "purchase_contract"
    assert document.header.contract_number == "HT-001"
    assert document.header.delivery_date_standard.isoformat() == "2026-07-20"
    assert document.header.buyer == "云派科技"
    assert document.header.supplier == "义乌线缆厂"
    assert document.header.settlement_method == "月结30天"
    assert document.header.delivery_address == "深圳市"
    assert document.header.currency == "CNY"
    assert document.totals.declared_quantity == 5
    assert document.totals.quantity_matches is True
    assert document.totals.declared_amount == 50
    assert document.totals.amount_matches is True


def test_line_amount_mismatch_forces_both_aggregate_match_flags_false(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = "合同编号：POORD000456"
    sheet.append([])
    sheet.append(["序号", "型号", "名称", "数量", "单位", "含税单价", "含税金额"])
    sheet.append([1, "M-1", "测试产品", 7100, "PCS", 0.017, 120])
    sheet.append(["合计", None, None, 7100, None, None, 120])
    source = tmp_path / "行金额与合计冲突.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert "LINE_AMOUNT_MISMATCH" in {
        issue.code for issue in document.validation_issues
    }
    assert document.totals.calculated_amount == 120
    assert document.totals.declared_amount == 120
    assert document.totals.amount_matches is False
    assert document.totals.matches["amount"] is False


def test_explicit_order_number_label_beats_old_number_in_notes(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "订单"
    sheet.merge_cells("A1:F1")
    sheet["A1"] = "采购订单"
    sheet["A2"] = "订单号"
    sheet["B2"] = "TX2607150002"
    sheet["A3"] = "备注"
    sheet["B3"] = "旧订单号 TX2607110001，仅作历史参考"
    for column, value in enumerate(["序号", "型号", "名称", "规格", "数量", "单位"], 1):
        sheet.cell(5, column, value)
    for column, value in enumerate([1, "M-1", "DP线", "1M", 2, "PCS"], 1):
        sheet.cell(6, column, value)
    source = tmp_path / "采购订单.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.order_number == "TX2607150002"
    assert [candidate.value for candidate in document.header.candidate_numbers] == [
        "TX2607150002",
        "TX2607110001",
    ]
    assert "ORDER_NUMBER_CONFLICT" in {
        issue.code for issue in document.validation_issues
    }


def test_contract_and_product_identifiers_do_not_conflict_with_order_number(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "订单"
    sheet["A1"] = "采购合同"
    sheet["A2"] = "订单号码：PO-20260515-001"
    sheet["A3"] = "合同编号：POORD009667"
    sheet["A4"] = "MODELO:MHD-4023 Y00060710000"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "Cable", 2, "PCS"])
    source = tmp_path / "不同语义编号.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.order_number == "PO-20260515-001"
    assert document.header.contract_number == "POORD009667"
    assert {
        candidate.value: candidate.kind
        for candidate in document.header.candidate_numbers
    } == {
        "PO-20260515-001": "order_number",
        "POORD009667": "contract_number",
        "Y00060710000": "product_identifier",
    }
    assert "ORDER_NUMBER_CONFLICT" not in {
        issue.code for issue in document.validation_issues
    }


@pytest.mark.parametrize(
    ("filename", "headers", "values", "expected_subtype", "custom_key"),
    [
        (
            "采购入库2026.xlsx",
            ["供应商名称", "物料型号", "单位", "应收数量", "入库单号", "物料代码"],
            ["供应商A", "锌合金", "PCS", 12, "WIN001", "YA.F.01.066"],
            "purchase_receipt_ledger",
            "receipt_number",
        ),
        (
            "采购申请2026.xlsx",
            ["客户名称", "物料型号", "单位", "申请数量", "系统单号", "物料代码"],
            ["客户A", "DP 2.1", "PCS", 20, "REQ001", "WX.01.001"],
            "purchase_requisition_ledger",
            "system_document_number",
        ),
        (
            "采购订单台账.xlsx",
            [
                "供应商名称",
                "物料型号",
                "单位",
                "未交数量",
                "采购单号",
                "物料代码",
                "审核状态",
            ],
            ["供应商B", "HDMI 2.1", "PCS", 30, "POORD001", "WX.02.001", "1"],
            "purchase_order_ledger",
            "purchase_order_number",
        ),
    ],
)
def test_purchase_ledgers_use_procurement_schema_and_row_identifiers(
    tmp_path: Path,
    filename: str,
    headers: list[str],
    values: list[object],
    expected_subtype: str,
    custom_key: str,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "数据"
    sheet.append(headers)
    sheet.append(values)
    source = tmp_path / filename
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_type == "procurement"
    assert document.document_subtype == expected_subtype
    assert len(document.lines) == 1
    line = document.lines[0]
    assert line.product_code in {"YA.F.01.066", "WX.01.001", "WX.02.001"}
    assert line.model in {"锌合金", "DP 2.1", "HDMI 2.1"}
    assert line.quantity in {12, 20, 30}
    assert line.unit == "PCS"
    assert line.name_raw is None
    assert line.full_product_name == f"{line.product_code} {line.model}"
    for field in (
        "line_no",
        "name_normalized",
        "full_product_name",
        "product_category",
        "name_attributes",
    ):
        metadata = document.field_meta[f"$.lines[0].{field}"]
        assert metadata.inferred is True
        assert metadata.model_extra["review_required"] is False
        assert metadata.source_refs[0].sheet == "数据"
        assert metadata.source_refs[0].cell
    assert custom_key in line.custom_fields
    assert set(headers) == set(line.raw_columns)
    assert "ORDER_NUMBER_CONFLICT" not in {
        issue.code for issue in document.validation_issues
    }
    assessment = assess_document_review(document.model_dump(mode="json"))
    assert assessment.blockers == []


def test_bom_purpose_and_semantic_headers_route_to_technical_document(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "产品结构"
    sheet.append(["产品结构"])
    sheet.append(
        ["序号", "材料编号", "原材料名称", "实际用量", "计量单位", "材料单价"]
    )
    sheet.append([1, "MAT-001", "铜线", "2.5", "M", "1.25"])
    source = tmp_path / "任意名称.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_type == "technical_document"
    assert document.document_subtype == "bill_of_materials"
    assert len(document.lines) == 1
    assert document.lines[0].product_code == "MAT-001"
    assert document.lines[0].name_raw == "铜线"
    assert document.lines[0].quantity == 2.5
    assert document.lines[0].unit == "M"


def test_bom_identifier_column_does_not_override_inventory_purpose(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["物料编码", "物料名称", "即时库存数量", "单位", "BOM单号"])
    sheet.append(["MAT-001", "铜线", 12, "M", "BOM-001"])
    source = tmp_path / "库存快照.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_type == "inventory"
    assert document.document_subtype == "inventory_snapshot"


def test_equipment_register_preserves_raw_identity_without_product_semantics(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "设备"
    sheet.append(["设备名称", "设备型号", "单位", "数量", "使用状态"])
    sheet.append(["螺杆空压机", "LG-10", "台", 1, "在用"])
    source = tmp_path / "生产设备一览表.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)
    assessment = assess_document_review(document.model_dump(mode="json"))

    assert document.document_type == "equipment"
    assert document.document_subtype == "equipment_register"
    assert len(document.lines) == 1
    assert assessment.blockers == []
    line = document.lines[0]
    assert line.name_raw == "螺杆空压机"
    assert line.model == "LG-10"
    assert line.name_normalized is None
    assert line.full_product_name is None
    assert line.product_category is None
    assert line.name_attributes.model_dump(exclude_none=True) == {"custom": {}}
    assert document.field_meta["$.lines[0].name_raw"].source_refs[0].cell == "A2"
    assert document.field_meta["$.lines[0].model"].source_refs[0].cell == "B2"
    assert not {
        "$.lines[0].name_normalized",
        "$.lines[0].full_product_name",
        "$.lines[0].product_category",
        "$.lines[0].name_attributes",
    }.intersection(document.field_meta)


@pytest.mark.parametrize("order_number", ["POORD009581", "PO-20260408-001"])
def test_commercial_order_numbers_are_not_missed_or_truncated(
    tmp_path: Path,
    order_number: str,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = f"订单号码：{order_number} 订单日期：2026年6月1日"
    sheet.append([])
    sheet.append(["序号", "货品编号", "型号", "中文品名", "数量", "单位", "金额"])
    sheet.append([1, "BQ-001", "V-H401", "产品 Y00060710000", 10, "PCS", 1])
    source = tmp_path / f"采购合同-{order_number}.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.order_number == order_number
    assert document.lines[0].product_code == "BQ-001"
    assert document.lines[0].name_raw == "产品 Y00060710000"


def test_purchase_contract_title_outranks_incidental_mold_text_and_maps_totals(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采 购 合 同"
    sheet["A2"] = "买方：义乌市艾理德国际贸易有限公司  地址：浙江义乌"
    sheet["A3"] = "卖方：桐曦电子科技有限公司  地址：广西全州"
    sheet["A4"] = "合同编号：YWxxxxxxx，签订日期：2026年1月9日，签约地：义乌"
    sheet.append([])
    sheet.append(
        [
            "中文品名",
            "型号",
            "颜色",
            "单位",
            "装箱数(PCS)",
            "箱数",
            "总数量",
            "含税总单价(RMB)",
            "含税总金额(RMB)",
            "要求",
        ]
    )
    sheet.append(
        [
            "音视频线",
            "MHD-4022",
            "单色",
            "条",
            200,
            60,
            12000,
            3.95,
            47400,
            "要求模具有客户LOGO",
        ]
    )
    source = tmp_path / "20260109桐曦采购合同.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_type == "order"
    assert document.document_subtype == "purchase_contract"
    assert document.header.contract_number is None
    assert document.header.date_standard.isoformat() == "2026-01-09"
    assert document.header.buyer == "义乌市艾理德国际贸易有限公司"
    assert document.header.seller == "桐曦电子科技有限公司"
    assert document.header.supplier == "桐曦电子科技有限公司"
    assert len(document.lines) == 1
    line = document.lines[0]
    assert line.name_raw == "音视频线"
    assert line.quantity == 12000
    assert str(line.unit_price_tax_included) == "3.95"
    assert line.amount_tax_included == 47400
    assert document.totals.calculated_quantity == 12000
    assert document.totals.calculated_amount == 47400


@pytest.mark.parametrize(
    ("contract_label", "contract_value", "expected_date"),
    [
        ("合同编号：           签订日期：2026年3月19日，签约地：义乌", None, "2026-03-19"),
        ("合同编号", "2026-03-19", None),
    ],
)
def test_empty_contract_number_does_not_absorb_a_date(
    tmp_path: Path,
    contract_label: str,
    contract_value: str | None,
    expected_date: str | None,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = contract_label
    if contract_value is not None:
        sheet["B2"] = contract_value
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "测试产品", 2, "PCS"])
    source = tmp_path / "20260319桐曦采购合同.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.contract_number is None
    assert (
        document.header.date_standard.isoformat()
        if document.header.date_standard is not None
        else None
    ) == expected_date


@pytest.mark.parametrize(
    ("first_label", "second_label", "third_value"),
    [
        ("合同编号", "签订日期", "2026-03-19"),
        ("交货日期", "下单日期", "2026-03-19"),
        ("合同编号", "签订日期：2026-03-19", None),
        ("交货日期", "下单日期：2026-03-19", None),
        ("合同编号", "下单日期 2026-03-19", None),
        ("交货日期", "下单日期 2026-03-19", None),
        ("合同编号", "下单日期2026-03-19", None),
        ("交货日期", "下单日期2026-03-19", None),
    ],
)
def test_horizontal_header_lookup_stops_at_another_field_label(
    tmp_path: Path,
    first_label: str,
    second_label: str,
    third_value: str | None,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = first_label
    sheet["B2"] = second_label
    if third_value is not None:
        sheet["C2"] = third_value
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "测试产品", 2, "PCS"])
    source = tmp_path / f"跨标签-{first_label}.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.contract_number is None
    assert document.header.delivery_date_raw is None
    assert document.header.delivery_date_standard is None
    assert document.header.date_standard.isoformat() == "2026-03-19"
    assert "$.header.contract_number" not in document.field_meta
    assert "$.header.delivery_date_raw" not in document.field_meta
    assert "$.header.delivery_date_standard" not in document.field_meta


def test_spaced_date_value_does_not_become_contract_number(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = "合同编号"
    sheet["B2"] = "2026 年 3 月 19 日"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "测试产品", 2, "PCS"])
    source = tmp_path / "采购合同-空格日期.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.contract_number is None
    assert "$.header.contract_number" not in document.field_meta


@pytest.mark.parametrize("separator", [":", "：", " ", ""])
def test_inline_order_date_is_a_horizontal_delivery_date_boundary(
    tmp_path: Path,
    separator: str,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet["A2"] = "交货日期"
    sheet["B2"] = f"下单日期{separator}2026-07-21"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "测试产品", 2, "PCS"])
    source = tmp_path / "采购合同-相邻日期标签.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.date_standard.isoformat() == "2026-07-21"
    assert document.header.delivery_date_raw is None
    assert document.header.delivery_date_standard is None
    assert "$.header.delivery_date_raw" not in document.field_meta
    assert "$.header.delivery_date_standard" not in document.field_meta


def test_order_date_is_not_reused_without_delivery_date_evidence(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购订单"
    sheet["A2"] = "订单号"
    sheet["B2"] = "PO-20260721-001"
    sheet["A3"] = "下单日期"
    sheet["B3"] = "2026-07-21"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "测试产品", 2, "PCS"])
    source = tmp_path / "采购订单-只有下单日期.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.date_standard.isoformat() == "2026-07-21"
    assert document.header.delivery_date_raw is None
    assert document.header.delivery_date_standard is None
    assert "$.header.delivery_date_raw" not in document.field_meta
    assert "$.header.delivery_date_standard" not in document.field_meta


def test_supplier_label_is_not_reused_as_issuer_or_buyer(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购订单"
    sheet["A2"] = "供应商：广西桐曦电子科技有限公司"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "M-1", "Cable", 2, "PCS"])
    source = tmp_path / "仅供应商标签采购订单.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.header.supplier == "广西桐曦电子科技有限公司"
    assert document.header.issuer is None
    assert document.header.buyer is None


def test_evidence_backed_issuer_to_buyer_derivation_does_not_block_review(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "合同"
    sheet["A1"] = "东莞市唯格电子科技有限公司"
    sheet["A2"] = "采购合同"
    sheet["A3"] = "供应商：广西桐曦电子科技有限公司"
    sheet["A4"] = "订单号：PO-20260408-001"
    sheet.append(["序号", "型号", "名称", "规格", "数量", "单位"])
    sheet.append([1, "W-H917", "中性 DP1.4 高清线", "1.5M", 2000, "PCS"])
    source = tmp_path / "有明确采购双方的合同.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)
    assessment = assess_document_review(document.model_dump(mode="json"))

    assert document.header.issuer == "东莞市唯格电子科技有限公司"
    assert document.header.buyer == document.header.issuer
    assert document.header.supplier == "广西桐曦电子科技有限公司"
    buyer_meta = document.field_meta["$.header.buyer"]
    issuer_meta = document.field_meta["$.header.issuer"]
    assert buyer_meta.inferred is True
    assert buyer_meta.model_extra["review_required"] is False
    assert buyer_meta.source_refs == issuer_meta.source_refs
    assert "INFERRED_FIELD" not in assessment.reason_codes


def test_evidence_backed_name_and_specification_are_valid_line_identity(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "订单"
    sheet["A1"] = "客户采购订单"
    sheet["A2"] = "订单号：TX2607090001"
    sheet.append(["序号", "货物", "规格", "数量", "单位"])
    sheet.append([1, "HDTV 4K 银色光纤", "15M", 100, "PCS"])
    source = tmp_path / "按名称和规格识别的采购订单.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)
    assessment = assess_document_review(document.model_dump(mode="json"))

    assert document.lines[0].model is None
    assert document.lines[0].product_code is None
    assert document.lines[0].name_raw == "HDTV 4K 银色光纤"
    assert document.lines[0].specification_raw == "15M"
    assert document.field_meta["$.lines[0].name_raw"].source_refs
    assert document.field_meta["$.lines[0].specification_raw"].source_refs
    assert "LINE_CORE_FIELD_MISSING" not in {
        issue.code for issue in document.validation_issues
    }
    assert "LINE_IDENTITY_MISSING" not in assessment.reason_codes


def test_order_rows_require_direct_identity_but_keep_vertical_merges(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet.append([])
    sheet.append([])
    sheet.append(["序号", "货品编号", "型号", "名称", "数量", "单位", "单价", "金额"])
    sheet.append([1, "P-1", "M-1", "纵向合并产品", 2, "PCS", 10, 20])
    sheet.append([2, "P-2", "M-2", None, 3, "PCS", 10, 30])
    sheet.merge_cells("D5:D6")
    sheet["E7"] = 5
    sheet["H7"] = 50
    sheet.merge_cells("A8:H8")
    sheet["A8"] = "附加：印刷前确认标签"
    sheet.merge_cells("A9:H9")
    sheet["A9"] = "特别注意事项：1. 供应商按期交货"
    sheet["A10"] = "收货单位签字盖章："
    sheet["E10"] = "发货单位签字盖章："
    source = tmp_path / "带条款采购合同.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert len(document.lines) == 2
    assert [line.model for line in document.lines] == ["M-1", "M-2"]
    assert document.lines[0].name_raw == document.lines[1].name_raw == "纵向合并产品"
    assert document.totals.calculated_quantity == 5
    assert document.totals.calculated_amount == 50


def test_customer_order_total_row_is_not_duplicated_and_goods_become_name(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "7月9日深圳优特比光纤订单"
    sheet.append(["序号", "规格型号", "单位", "数量", "装箱数量", "件数", "货物"])
    sheet.append([1, "15M", "PCS", 100, 10, 10, "HDTV 4K 银色光纤"])
    sheet.append([2, "70M", "PCS", 20, 5, 4, "HDTV 4K 银色光纤"])
    sheet.append([3, "50M", "PCS", 100, 5, 20, "HDTV 8K 枪黑色光纤"])
    sheet.append([None, None, None, 220, None, 34, None])
    source = tmp_path / "7月9日优特比.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert len(document.lines) == 3
    assert [line.name_raw for line in document.lines] == [
        "HDTV 4K 银色光纤",
        "HDTV 4K 银色光纤",
        "HDTV 8K 枪黑色光纤",
    ]
    assert document.totals.calculated_quantity == 220
    assert sum(line.piece_count or 0 for line in document.lines) == 34


def test_total_word_inside_product_name_does_not_truncate_following_items(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购订单"
    sheet.append(["序号", "型号", "名称", "数量", "单位"])
    sheet.append([1, "T-1", "TOTAL CABLE", 2, "PCS"])
    sheet.append([2, "T-2", "Normal Cable", 3, "PCS"])
    sheet.append([None, None, "合计", 5, None])
    source = tmp_path / "产品名含TOTAL.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert [line.model for line in document.lines] == ["T-1", "T-2"]
    assert [line.name_raw for line in document.lines] == [
        "TOTAL CABLE",
        "Normal Cable",
    ]
    assert document.totals.calculated_quantity == 5


def test_numbered_footer_with_totals_labels_is_not_an_order_line(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "采购合同"
    sheet.append(
        ["序号", "货品编号", "型号", "名称", "数量", "单位", "单价", "金额", "标签条码"]
    )
    sheet.append([1, "P-1", "M-1", "Cable", 2, "PCS", 10, 20, "690000000001"])
    # Some supplier workbooks number the totals row and place its labels in
    # otherwise unrelated columns. Product identity, not sequence alone,
    # distinguishes this structural footer from a real item.
    sheet.append([2, None, None, None, 2, None, "合计金额：", 20, "合计数量："])
    source = tmp_path / "带序号合计行.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert [line.model for line in document.lines] == ["M-1"]
    assert document.totals.calculated_quantity == 2
    assert document.totals.declared_quantity == 2
    assert document.totals.quantity_matches is True


def test_equipment_skips_empty_sequence_and_document_control_footer(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet["A1"] = "检测设备一览表"
    sheet.append([])
    sheet.append(["序号", "设备名称", "设备型号", "数量", "单位", "设备状况"])
    sheet.append([1, "钢卷尺", None, 1, "个", "正常运行"])
    sheet.append([20, None, None, None, None, None])
    sheet.append([])
    sheet.append([None, None, "制定日期：2026/7/11", None, "制定：", "周素锦"])
    source = tmp_path / "测试设备一览表.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_subtype == "equipment_register"
    assert len(document.lines) == 1
    assert document.lines[0].name_raw == "钢卷尺"
    assert document.totals.calculated_quantity == 1
    assert document.totals.system_calculated["row_count"] == 1


def test_mixed_unit_inventory_reports_per_unit_without_physical_grand_total(
    tmp_path: Path,
) -> None:
    source = tmp_path / "库存.csv"
    source.write_text(
        "仓库名称,物料代码,物料名称,单位,即时库存数量\n"
        "成品仓,A,产品A,PCS,10\n"
        "材料仓,B,产品B,KG,2.5\n",
        encoding="utf-8",
    )

    document = parse_spreadsheet_document(source)

    assert document.document_subtype == "inventory_snapshot"
    assert document.totals.calculated_quantity is None
    assert document.totals.system_calculated["quantity"] is None
    assert document.totals.system_calculated["by_unit"] == {"PCS": 10, "KG": 2.5}


def test_side_by_side_mold_mapping_pairs_columns_across_one_spacer(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["模号", "外模", None, "DP模具", None, None])
    sheet.append(["L-001", "左外模一", None, "模型", None, "模号"])
    sheet.append(["L-002", "左外模二", None, "右内模一", "1/2", "R-001"])
    sheet.append([None, None, None, "右外模二", "1/4", "R-002"])
    source = tmp_path / "双栏模号外模类型明细.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert document.document_subtype == "mold_mapping"
    assert len(document.lines) == 4
    pairs = {(line.product_code, line.name_raw) for line in document.lines}
    assert pairs == {
        ("L-001", "左外模一"),
        ("L-002", "左外模二"),
        ("R-001", "右内模一"),
        ("R-002", "右外模二"),
    }


def test_mold_mapping_keeps_ambiguous_identifiers_and_flags_conflicts(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["模号", "外模"])
    sheet.append(["M-001", "六类外模"])
    sheet.append(["M-001", "七类外模"])
    sheet.append(["在二楼", "义乌 DP 外模"])
    sheet.append(["DP", "纯字母合法模号"])
    sheet.append(["HDMI-A", "字母连字符合法模号"])
    source = tmp_path / "模号外模冲突.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert len(document.lines) == 5
    assert document.lines[2].product_code == "在二楼"
    assert [line.product_code for line in document.lines[3:]] == ["DP", "HDMI-A"]
    assert {
        issue.code for issue in document.validation_issues
    } >= {"MOLD_IDENTIFIER_AMBIGUOUS", "MOLD_IDENTIFIER_CONFLICT"}
    assert document.needs_review is True
    assert all(line.name_normalized is None for line in document.lines)
    assert all(line.full_product_name is None for line in document.lines)
    assert all(line.product_category is None for line in document.lines)
    assert document.field_meta["$.lines[0].name_raw"].source_refs[0].cell == "B2"


def _add_test_worksheet_image(sheet, image_path: Path, anchor: str) -> None:
    image_module = pytest.importorskip("openpyxl.drawing.image")
    image = image_module.Image(image_path)
    image.width = 40
    image.height = 24
    sheet.add_image(image, anchor)


def _write_test_pixel(path: Path) -> None:
    path.write_bytes(
        base64.b64decode(
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
        )
    )


def test_structural_images_do_not_block_associated_product_image(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "合同"
    sheet["A1"] = "采购合同"
    sheet.append([])
    sheet.append([])
    sheet.append(["序号", "产品图片", "型号", "数量", "单位"])
    sheet.append([1, None, "M-1", 2, "PCS"])
    pixel = tmp_path / "pixel.png"
    _write_test_pixel(pixel)
    _add_test_worksheet_image(sheet, pixel, "B1")
    _add_test_worksheet_image(sheet, pixel, "B5")
    _add_test_worksheet_image(sheet, pixel, "F9")
    source = tmp_path / "带页眉产品图和签章.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert "IMAGE_UNASSOCIATED" not in {
        issue.code for issue in document.validation_issues
    }
    roles = {
        image["anchor"]["from_row"]: image["visual_role"]
        for image in document.extraction["images"]
    }
    assert roles == {1: "document_header", 5: "product", 9: "document_footer"}
    product_image_id = next(
        image["image_id"]
        for image in document.extraction["images"]
        if image["visual_role"] == "product"
    )
    assert document.lines[0].image_refs == [product_image_id]


def test_side_by_side_tables_do_not_share_same_row_product_image(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "并排订单"
    headers = ["序号", "产品图片", "型号", "数量", "单位"]
    for column, value in enumerate(headers, start=1):
        sheet.cell(1, column, value)
    for column, value in enumerate(headers, start=7):
        sheet.cell(1, column, value)
    for column, value in enumerate([1, None, "LEFT-1", 2, "PCS"], start=1):
        sheet.cell(2, column, value)
    for column, value in enumerate([1, None, "RIGHT-1", 3, "PCS"], start=7):
        sheet.cell(2, column, value)
    pixel = tmp_path / "pixel.png"
    _write_test_pixel(pixel)
    _add_test_worksheet_image(sheet, pixel, "B2")
    source = tmp_path / "同排左右双表.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    assert [line.model for line in document.lines] == ["LEFT-1", "RIGHT-1"]
    assert len(document.lines[0].image_refs) == 1
    assert document.lines[1].image_refs == []
    assert "IMAGE_UNASSOCIATED" not in {
        issue.code for issue in document.validation_issues
    }
    assert document.extraction["images"][0]["visual_role"] == "product"


def test_unassociated_image_inside_product_region_still_blocks(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "订单"
    sheet.append(["序号", "产品图片", "型号", "数量", "单位"])
    sheet.append([1, None, "M-1", 2, "PCS"])
    sheet.append([])
    sheet.append([2, None, "M-2", 3, "PCS"])
    pixel = tmp_path / "pixel.png"
    _write_test_pixel(pixel)
    _add_test_worksheet_image(sheet, pixel, "B2")
    _add_test_worksheet_image(sheet, pixel, "B3")
    source = tmp_path / "产品区孤立图片.xlsx"
    workbook.save(source)

    document = parse_spreadsheet_document(source)

    issue = next(
        issue
        for issue in document.validation_issues
        if issue.code == "IMAGE_UNASSOCIATED"
    )
    isolated = next(
        image
        for image in document.extraction["images"]
        if image["anchor"]["from_row"] == 3
    )
    assert isolated["visual_role"] == "product"
    assert issue.actual == [isolated["image_id"]]


def test_footer_role_uses_anchor_span_but_keeps_adjacent_candidate_unresolved() -> None:
    sheet = SheetEnvelope(name="合同", max_row=5, max_column=5)
    region = TableRegion(
        sheet=sheet,
        header_row=1,
        min_column=1,
        max_column=5,
        data_start_row=2,
        data_end_row=2,
    )

    def anchored(image_id: str, to_row: int) -> ImageAnchor:
        return ImageAnchor(
            image_id=image_id,
            sheet=sheet.name,
            part_name=f"xl/media/{image_id}.png",
            media_type="image/png",
            sha256="0" * 64,
            from_row=3,
            from_col=2,
            to_row=to_row,
            to_col=3,
        )

    assert classify_image_role(anchored("signature", 5), [region]).role == (
        "document_footer"
    )
    assert classify_image_role(anchored("adjacent", 3), [region]).role == "unresolved"


def test_target_stocking_order_golden_if_available() -> None:
    parents = Path(__file__).resolve().parents
    if len(parents) <= 4:
        pytest.skip("local read-only production acceptance workbook is unavailable")
    source = parents[4] / "DP桐曦备货单TX2607150002(2).xlsx"
    if not source.exists():
        pytest.skip("local read-only production acceptance workbook is unavailable")
    document = parse_spreadsheet_document(source)
    assert document.document_subtype == "stocking_order"
    assert document.header.order_number == "TX2607150002"
    assert {candidate.value for candidate in document.header.candidate_numbers} == {
        "TX2607150002",
        "TX2607110001",
        "TX260715002",
    }
    old_number = next(
        candidate for candidate in document.header.candidate_numbers if candidate.value == "TX2607110001"
    )
    assert old_number.hidden is True
    assert document.header.date_raw == "7月15日"
    assert document.header.date_standard.isoformat() == "2026-07-15"
    assert document.header.date_inferred is True
    assert len(document.lines) == 12
    assert [line.model for line in document.lines] == [
        "W-H937", "W-H938", "W-H939", "W-H940",
        "W-H941", "W-H942", "W-H943", "W-H944",
        "W-H120", "W-H121", "W-H122", "W-H123",
    ]
    assert [line.specification_raw for line in document.lines] == [
        "1M", "1.5M", "2M", "3M", "1M", "1.5M", "2M", "3M", "1.5M", "2M", "3M", "5M",
    ]
    assert [line.quantity for line in document.lines] == [
        800, 1000, 700, 500, 500, 500, 1000, 300, 1000, 500, 300, 300,
    ]
    assert all(line.unit == "PCS" for line in document.lines)
    assert document.totals.declared_quantity == 7400
    assert document.totals.calculated_quantity == 7400
    assert document.totals.quantity_matches is True
    assert len({tuple(line.image_refs) for line in document.lines}) == 3
    assert len({line.name_normalized for line in document.lines}) == 12
    assert all(line.name_normalized for line in document.lines)
    assert all(
        {"可订", "月销", "土耳其"} <= line.custom_fields.keys()
        for line in document.lines
    )
    assert document.lines[0].name_raw == document.lines[3].name_raw
    assert document.lines[4].name_raw == document.lines[7].name_raw
    assert document.lines[0].name_raw != document.lines[4].name_raw
    assert document.lines[0].packaging_requirements == document.lines[7].packaging_requirements
    assert document.lines[8].packaging_requirements == document.lines[11].packaging_requirements
    assert document.lines[7].packaging_requirements != document.lines[8].packaging_requirements
    assert "ORDER_NUMBER_CONFLICT" in {issue.code for issue in document.validation_issues}
    assert document.needs_review is True


def test_english_inventory_columns_recognized_as_inventory_snapshot(
    tmp_path: Path,
) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(
        [
            "material_code",
            "material_name",
            "warehouse",
            "lot_no",
            "available_qty",
            "locked_qty",
            "qc_status",
            "received_at",
        ]
    )
    sheet.append(["XU2013", "灰色1.5-5M线材", "WH-A", "LOT-1", 900, 100, "passed", "2026-06-01"])
    sheet.append(["JL003", "45P胶料", "WH-A", "LOT-2", 18, 2, "passed", "2026-06-05"])
    source = tmp_path / "inventory_snapshot.csv"
    with source.open("w", encoding="utf-8-sig", newline="") as f:
        import csv as _csv
        writer = _csv.writer(f)
        writer.writerow(
            [
                "material_code",
                "material_name",
                "warehouse",
                "lot_no",
                "available_qty",
                "locked_qty",
                "qc_status",
                "received_at",
            ]
        )
        writer.writerow(["XU2013", "灰色1.5-5M线材", "WH-A", "LOT-1", 900, 100, "passed", "2026-06-01"])
        writer.writerow(["JL003", "45P胶料", "WH-A", "LOT-2", 18, 2, "passed", "2026-06-05"])

    document = parse_spreadsheet_document(source)

    assert document.document_type == "inventory"
    assert document.document_subtype == "inventory_snapshot"
    assert len(document.lines) == 2
    assert document.lines[0].product_code == "XU2013"
    assert document.lines[0].name_raw == "灰色1.5-5M线材"
    assert document.lines[0].quantity == 900
    assert document.lines[0].custom_fields.get("warehouse") == "WH-A"
    assert document.lines[0].custom_fields.get("lot_no") == "LOT-1"
    assert document.lines[0].custom_fields.get("status") == "passed"
