from __future__ import annotations

import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from m1.documents.parsing.docx_native_classification import (
    classify_docx_native_content,
)
from m1.documents.parsing.docx_native_evidence import (
    DOCXNativeEvidenceError,
    DOCXNativeEvidenceParser,
    parse_docx_native_evidence,
)

CONTENT_TYPES = b"""<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="png" ContentType="image/png"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

DOCUMENT = b"""<?xml version="1.0" encoding="UTF-8"?>
<w:document
 xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">
 <w:body>
  <w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>Intro</w:t></w:r>
   <w:r><w:drawing><wp:inline><wp:docPr id="1" name="Product" descr="Front view"/>
    <a:blip r:embed="rIdImage"/></wp:inline></w:drawing></w:r>
  </w:p>
  <w:tbl><w:tr>
   <w:tc><w:p><w:r><w:t>Code</w:t></w:r></w:p></w:tc>
   <w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>Value</w:t></w:r></w:p></w:tc>
  </w:tr></w:tbl>
  <w:p><w:r><w:t>End</w:t><w:tab/><w:t>Tail</w:t><w:br/><w:t>Next</w:t></w:r></w:p>
  <w:sectPr/>
 </w:body>
</w:document>"""

RELATIONSHIPS = b"""<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
 <Relationship Id="rIdImage" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>
 <Relationship Id="rIdExternal" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://example.invalid" TargetMode="External"/>
</Relationships>"""


def _docx(
    path: Path,
    *,
    document: bytes = DOCUMENT,
    relationships: bytes | None = RELATIONSHIPS,
    image: bytes = b"png-fixture",
) -> None:
    with ZipFile(path, "w", ZIP_DEFLATED) as package:
        package.writestr("[Content_Types].xml", CONTENT_TYPES)
        package.writestr("word/document.xml", document)
        if relationships is not None:
            package.writestr("word/_rels/document.xml.rels", relationships)
        package.writestr("word/media/image1.png", image)


def test_native_docx_preserves_body_order_tables_cells_and_images(
    tmp_path: Path,
) -> None:
    source = tmp_path / "sample.docx"
    image = b"authoritative-image-bytes"
    _docx(source, image=image)

    evidence = parse_docx_native_evidence(source)

    assert evidence.backend == "docx-native-ooxml"
    assert evidence.backend_version == "1"
    assert len(evidence.pages) == 1
    page = evidence.pages[0]
    assert [(item.kind, item.order) for item in page.blocks] == [
        ("paragraph", 0),
        ("table", 1),
        ("paragraph", 2),
    ]
    assert [item["kind"] for item in evidence.raw["body_order"]] == [
        "paragraph",
        "table",
        "paragraph",
    ]
    assert page.blocks[0].text == "Intro"
    assert page.blocks[0].model_extra["source_id"] == (
        "word/document.xml#paragraph:0"
    )
    assert page.blocks[0].model_extra["image_refs"] == [
        "docx:image:rIdImage"
    ]
    assert page.blocks[2].text == "End\tTail\nNext"

    table = page.tables[0]
    assert table.table_id == "docx:t:0"
    assert table.rows == [["Code", "Value", None]]
    assert table.cells[1].column == 1
    assert table.cells[1].model_extra["grid_span"] == 2
    assert table.cells[0].model_extra["source_id"] == (
        "word/document.xml#table:0/row:0/cell:0"
    )
    assert table.cells[0].model_extra["paragraph_source_ids"] == [
        "word/document.xml#table:0/row:0/cell:0/paragraph:0"
    ]

    relationships = {
        item["relationship_id"]: item
        for item in evidence.raw["relationships"]
    }
    assert relationships["rIdImage"]["target_part"] == "word/media/image1.png"
    assert relationships["rIdExternal"]["external"] is True
    assert evidence.raw["images"] == [
        {
            "image_id": "docx:image:rIdImage",
            "relationship_id": "rIdImage",
            "target_part": "word/media/image1.png",
            "content_type": "image/png",
            "sha256": hashlib.sha256(image).hexdigest(),
            "byte_size": len(image),
            "references": [
                {
                    "source_id": "word/document.xml#paragraph:0",
                    "image_alt_text": ["Product", "Front view"],
                }
            ],
        }
    ]
    assert evidence.raw["source"]["original_filename"] == "sample.docx"
    assert evidence.raw["native_classification"] == {
        "schema_version": "m1.native-classification.v1",
        "source": "docx-native-classifier-v1",
        "document_type": "unknown",
        "document_subtype": "unknown",
        "authority": "none",
        "confidence": 0.0,
        "evidence": [],
        "competing_evidence": [],
        "filename_advisory": [],
    }
    assert str(source.resolve()) not in str(evidence.model_dump(mode="json"))


@pytest.mark.parametrize(
    ("title", "body", "expected"),
    [
        ("产品承认书", "产品图纸及尺寸要求", "approval_drawing"),
        (
            "产品规格书",
            "安装尺寸请参考客户图纸，技术参数以本规格书为准。",
            "product_specification",
        ),
        ("工程图纸", "装配尺寸及公差要求", "engineering_drawing"),
    ],
)
def test_native_docx_classifier_distinguishes_explicit_technical_purpose(
    title: str,
    body: str,
    expected: str,
) -> None:
    classification = classify_docx_native_content(
        paragraphs=[
            {
                "source_id": "word/document.xml#paragraph:0",
                "text": title,
                "style": "Title",
            },
            {
                "source_id": "word/document.xml#paragraph:1",
                "text": body,
                "style": None,
            },
        ],
        table_cells=[],
        original_filename="renamed-upload.docx",
    )

    assert classification["document_type"] == "technical_document"
    assert classification["document_subtype"] == expected
    assert classification["authority"] == "native_content"
    assert classification["evidence"][0]["source_id"].startswith(
        "word/document.xml#paragraph:"
    )
    assert classification["evidence"][0]["quote"] == title
    assert classification["evidence"][0]["source_ref"] == {
        "page": 1,
        "part": "word/document.xml#paragraph:0",
    }


def test_native_docx_filename_is_advisory_and_cannot_reverse_content() -> None:
    classification = classify_docx_native_content(
        paragraphs=[
            {
                "source_id": "word/document.xml#paragraph:0",
                "text": "产品规格书",
                "style": "Title",
            }
        ],
        table_cells=[],
        original_filename="客户承认书.docx",
    )

    assert classification["document_subtype"] == "product_specification"
    assert classification["filename_advisory"] == [
        {
            "document_subtype": "approval_drawing",
            "matched_marker": "承认书",
            "source_id": "source.original_filename",
            "quote": "客户承认书.docx",
            "source_ref": {
                "part": "source.original_filename",
                "authority": "advisory",
            },
            "role": "filename_advisory",
        }
    ]


def test_native_docx_filename_alone_has_no_classification_authority() -> None:
    classification = classify_docx_native_content(
        paragraphs=[
            {
                "source_id": "word/document.xml#paragraph:0",
                "text": "连接器资料",
                "style": "Title",
            }
        ],
        table_cells=[],
        original_filename="产品承认书.docx",
    )

    assert classification["document_type"] == "unknown"
    assert classification["document_subtype"] == "unknown"
    assert classification["authority"] == "none"
    assert classification["filename_advisory"][0]["document_subtype"] == (
        "approval_drawing"
    )


def test_native_docx_uses_original_upload_name_only_as_advisory(
    tmp_path: Path,
) -> None:
    source = tmp_path / "stored-hash.docx"
    _docx(source)

    evidence = parse_docx_native_evidence(
        source,
        original_filename="客户承认书.docx",
    )

    assert evidence.raw["source"]["original_filename"] == "客户承认书.docx"
    classification = evidence.raw["native_classification"]
    assert classification["document_subtype"] == "unknown"
    assert classification["filename_advisory"][0]["document_subtype"] == (
        "approval_drawing"
    )


def test_native_docx_allows_document_without_relationship_part(tmp_path: Path) -> None:
    source = tmp_path / "plain.docx"
    _docx(source, relationships=None)

    evidence = DOCXNativeEvidenceParser().parse(source)

    assert evidence.raw["relationships"] == []
    assert evidence.raw["images"] == []
    assert evidence.warnings == ["missing_relationship:rIdImage"]


def test_native_docx_rejects_relationship_escaping_package(tmp_path: Path) -> None:
    source = tmp_path / "unsafe.docx"
    relationships = b"""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rIdImage" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../../../escape.png"/>
    </Relationships>"""
    _docx(source, relationships=relationships)

    with pytest.raises(DOCXNativeEvidenceError, match="escapes the package"):
        parse_docx_native_evidence(source)


def test_native_docx_rejects_non_ooxml_zip(tmp_path: Path) -> None:
    source = tmp_path / "fake.docx"
    with ZipFile(source, "w", ZIP_DEFLATED) as package:
        package.writestr("payload.txt", "not OOXML")

    with pytest.raises(DOCXNativeEvidenceError, match="Content_Types"):
        parse_docx_native_evidence(source)
