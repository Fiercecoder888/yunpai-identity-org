from __future__ import annotations

import pytest

from m1.documents.parsing.docx_semantics import (
    extract_docx_process_facts,
    extract_filename_advisory_facts,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidencePage,
)


def _evidence(*texts: str) -> DocumentEvidence:
    return DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="unknown",
                blocks=[
                    EvidenceBlock(
                        block_id=f"docx:p:{index}",
                        kind="paragraph",
                        text=text,
                        confidence=1.0,
                        order=index,
                        source="docx-native-ooxml",
                        source_id=f"word/document.xml#paragraph:{index}",
                    )
                    for index, text in enumerate(texts)
                ],
            )
        ],
    )


def test_real_docx_process_flow_is_atomized_with_replayable_ranges() -> None:
    first = "素材\t\t   切割\t\t     抛光      喷180砂   阳极氧化\t\t    前检       镭雕"
    second = "      包装\t\t\t 出货"
    evidence = _evidence(
        "工艺流程",
        first,
        second,
        "东莞市纬线电子科技外壳下料尺寸规格表",
    )

    facts = extract_docx_process_facts(evidence)

    assert [fact.value for fact in facts] == [
        "素材",
        "切割",
        "抛光",
        "喷180砂",
        "阳极氧化",
        "前检",
        "镭雕",
        "包装",
        "出货",
    ]
    assert [fact.attributes["order"] for fact in facts] == list(range(1, 10))
    assert all(fact.name == "manufacturing_process_step" for fact in facts)
    assert all(fact.status == "verified" for fact in facts)
    assert all(fact.extractor == "docx_explicit_process_flow" for fact in facts)

    parents = {"docx:p:1": first, "docx:p:2": second}
    for fact in facts:
        parent_id = str(fact.attributes["parent_evidence_id"])
        source_ref = fact.evidence_refs[0].source_ref
        assert fact.evidence_refs[0].evidence_id == parent_id
        assert source_ref.model_extra["parent_evidence_id"] == parent_id
        assert source_ref.model_extra["native_source_id"].endswith(
            parent_id.removeprefix("docx:p:")
        )
        prefix, start, end = str(source_ref.range).split(":")
        assert prefix == "chars"
        assert parents[parent_id][int(start) : int(end)] == fact.value
        assert fact.evidence_refs[0].quote == fact.value
        assert fact.evidence_refs[1].quote == "工艺流程"


def test_process_sections_are_independent_and_keep_global_order() -> None:
    evidence = _evidence(
        "一、工艺流程：",
        "下料  切割",
        "产品说明正文",
        "Workflow",
        "Assembly -> Inspection",
    )

    facts = extract_docx_process_facts(evidence)

    assert [fact.value for fact in facts] == [
        "下料",
        "切割",
        "Assembly",
        "Inspection",
    ]
    assert [fact.attributes["section_order"] for fact in facts] == [1, 1, 2, 2]
    assert [fact.attributes["order_in_section"] for fact in facts] == [1, 2, 1, 2]
    assert [fact.attributes["order"] for fact in facts] == [1, 2, 3, 4]


@pytest.mark.parametrize(
    "paragraphs",
    [
        ("素材 切割 抛光",),
        ("工艺流程", "素材 切割 抛光"),
        ("普通说明", "素材  切割"),
    ],
)
def test_ambiguous_or_unheaded_process_text_fails_closed(
    paragraphs: tuple[str, ...],
) -> None:
    assert extract_docx_process_facts(_evidence(*paragraphs)) == []


def test_ambiguous_paragraph_ends_section_instead_of_skipping_forward() -> None:
    facts = extract_docx_process_facts(
        _evidence(
            "工艺流程",
            "素材  切割",
            "这是无法安全拆分的连续说明",
            "抛光  包装",
        )
    )

    assert [fact.value for fact in facts] == ["素材", "切割"]


def test_random_sample_filename_yields_only_advisory_exact_quotes() -> None:
    filename = "3988-27.6长弧形太空灰.docx"
    stem = "3988-27.6长弧形太空灰"

    facts = extract_filename_advisory_facts(filename)

    assert {(fact.name, fact.value) for fact in facts} == {
        ("model", "3988"),
        ("length", "27.6"),
        ("shape", "长弧形"),
        ("color", "太空灰"),
    }
    assert next(fact for fact in facts if fact.name == "length").unit is None
    assert all(fact.status == "advisory" for fact in facts)
    assert all(fact.confidence <= 0.7 for fact in facts)
    assert all(fact.extractor == "filename_token_candidates" for fact in facts)
    for fact in facts:
        evidence_ref = fact.evidence_refs[0]
        source_ref = evidence_ref.source_ref
        prefix, start, end = str(source_ref.range).split(":")
        assert prefix == "chars"
        assert stem[int(start) : int(end)] == evidence_ref.quote
        assert source_ref.part == "source.original_filename"
        assert source_ref.model_extra["authority"] == "advisory"
        assert source_ref.model_extra["inferred"] is True


def test_filename_length_uses_only_an_explicit_unit() -> None:
    without_unit = extract_filename_advisory_facts("TX3988-27.6长弧形.docx")
    with_unit = extract_filename_advisory_facts("TX3988-27.6mm长弧形.docx")

    assert next(fact for fact in without_unit if fact.name == "length").unit is None
    explicit = next(fact for fact in with_unit if fact.name == "length")
    assert explicit.unit == "mm"
    assert explicit.evidence_refs[0].quote == "27.6mm"


@pytest.mark.parametrize(
    "filename",
    [
        "2026-07-24最终版.docx",
        "550e8400-e29b-41d4-a716-446655440000.docx",
        "123e4567e89b12d3a456426614174000-final.docx",
        "最终版.docx",
    ],
)
def test_filename_dates_uuids_and_final_markers_are_not_business_facts(
    filename: str,
) -> None:
    assert extract_filename_advisory_facts(filename) == []


def test_filename_model_candidates_remain_advisory_on_possible_conflict() -> None:
    facts = extract_filename_advisory_facts("TX3988-27.6太空灰.docx")

    model = next(fact for fact in facts if fact.name == "model")
    color = next(fact for fact in facts if fact.name == "color")
    assert model.value == "TX3988"
    assert model.status == color.status == "advisory"
    assert all(
        evidence.source_ref.model_extra["authority"] == "advisory"
        for fact in facts
        for evidence in fact.evidence_refs
    )
