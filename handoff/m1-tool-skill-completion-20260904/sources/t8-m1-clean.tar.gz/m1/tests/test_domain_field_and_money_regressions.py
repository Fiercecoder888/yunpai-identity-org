from __future__ import annotations

from collections.abc import Callable
from decimal import Decimal

import pytest

from m1.documents.adapters.pdf_order import _validate_pdf_lines
from m1.documents.models import DocumentRecord, DocumentSource, OrderLine
from m1.documents.numeric import monetary_values_equal, numeric_values_equal
from m1.documents.orders import _validate_lines, resolve_line_header_alias
from m1.documents.parsing.mineru_domain import (
    classify_line_business_payload,
    domain_minimum_failures,
    replay_line_value,
    source_label_line_target,
    target_direct_field,
)


def _document(document_type: str, line: OrderLine) -> DocumentRecord:
    return DocumentRecord(
        source=DocumentSource(original_filename=f"{document_type}.xlsx"),
        document_type=document_type,
        lines=[line],
    )


@pytest.mark.parametrize(
    ("label", "target"),
    [
        ("总数量", "quantity"),
        ("总数量(PCS)", "quantity"),
        ("含税总单价(RMB)", "unit_price_tax_included"),
        ("含税总金额(RMB)", "amount_tax_included"),
        ("含税总金额(￥)", "amount_tax_included"),
        ("不含税总单价（USD）", "unit_price_tax_excluded"),
        ("不含税总金额（USD）", "amount_tax_excluded"),
        ("规格米数", "specification_raw"),
        ("工厂型号", "model"),
    ],
)
def test_mineru_and_deterministic_order_aliases_converge(
    label: str,
    target: str,
) -> None:
    assert resolve_line_header_alias(label) == target
    assert source_label_line_target(label, "order") == target


def test_customer_model_keeps_its_qualified_order_semantics() -> None:
    assert resolve_line_header_alias("客户型号") is None
    assert source_label_line_target("客户型号", "order") == "customer_model"
    line = OrderLine(line_id="line-1")
    replay_line_value(line, "customer_model", "VA0329-5")
    assert line.custom_fields == {"customer_model": "VA0329-5"}
    assert "customer_product_code" not in line.custom_fields


def test_business_decorated_unit_price_replays_to_the_standard_field() -> None:
    label = "采购单价(包运费)"

    assert resolve_line_header_alias(label) == "unit_price_tax_excluded"
    assert source_label_line_target(label, "order") == "unit_price_tax_excluded"


def test_qualified_contract_columns_replay_to_standard_fields() -> None:
    line = OrderLine(line_id="line-1")

    for label, value in (
        ("总数量(PCS)", "60"),
        ("含税总单价(RMB)", "39.58"),
        ("含税总金额(RMB)", "2374.80"),
    ):
        target = source_label_line_target(label, "order")
        assert target is not None
        replay_line_value(line, target, value)

    assert line.quantity == Decimal(60)
    assert line.unit_price_tax_included == Decimal("39.58")
    assert line.amount_tax_included == Decimal("2374.80")
    assert line.custom_fields == {}


def test_non_business_image_header_is_not_exposed_as_a_line_target() -> None:
    assert source_label_line_target("产品图片", "order") is None


@pytest.mark.parametrize("label", ["壳子数量", "插头数量", "彩盒单价"])
def test_component_specific_columns_are_not_promoted_to_line_totals(label: str) -> None:
    assert resolve_line_header_alias(label) is None
    assert source_label_line_target(label, "order") is None


def test_inventory_available_quantity_satisfies_domain_minimum() -> None:
    document = _document(
        "inventory",
        OrderLine(
            line_id="line-1",
            product_code="SKU-1",
            unit="PCS",
            custom_fields={"available_quantity": Decimal(416)},
        ),
    )

    assert domain_minimum_failures(document) == ([], set())


@pytest.mark.parametrize(
    "label",
    ["即时库存数量", "库存数量", "当前库存数量", "Available Qty", "On-hand Qty"],
)
def test_inventory_quantity_aliases_keep_inventory_semantics(label: str) -> None:
    assert source_label_line_target(label, "inventory") == "available_quantity"


@pytest.mark.parametrize(
    ("document_type", "label", "target"),
    [
        ("equipment", "设备编号", "asset_number"),
        ("equipment", "设备编码", "equipment_code"),
        ("equipment", "设备名称", "equipment_name"),
        ("equipment", "设备型号", "model"),
        ("equipment", "制造商", "manufacturer"),
        ("equipment", "启用日期", "commissioned_date"),
        ("equipment", "使用状态", "status"),
        ("equipment", "设备状况", "status"),
        ("mold", "模号", "mold_number"),
        ("mold", "模具编号", "mold_number"),
        ("mold", "外模", "mold_name"),
        ("mold", "模型", "mold_name"),
        ("mold", "型腔数", "cavity_count"),
    ],
)
def test_equipment_and_mold_labels_have_stable_domain_targets(
    document_type: str,
    label: str,
    target: str,
) -> None:
    assert source_label_line_target(label, document_type) == target


def test_domain_specific_label_does_not_leak_into_an_order() -> None:
    assert source_label_line_target("模号", "order") is None
    assert source_label_line_target("设备名称", "order") is None


@pytest.mark.parametrize(
    ("target", "field"),
    [
        ("equipment_code", "product_code"),
        ("equipment_name", "name_raw"),
        ("mold_number", "product_code"),
        ("mold_name", "name_raw"),
        ("material_code", "product_code"),
        ("material_name", "name_raw"),
        ("asset_number", None),
    ],
)
def test_semantic_aliases_project_through_the_compatible_line_contract(
    target: str,
    field: str | None,
) -> None:
    assert target_direct_field(target) == field


def test_inventory_without_any_quantity_is_rejected() -> None:
    document = _document(
        "inventory",
        OrderLine(line_id="line-1", product_code="SKU-1", unit="PCS"),
    )

    reasons, invalid = domain_minimum_failures(document)

    assert reasons == ["invalid_domain_records"]
    assert "$.lines[0].quantity" in invalid
    assert '$.lines[0].custom_fields["available_quantity"]' in invalid


@pytest.mark.parametrize(
    ("document_type", "line"),
    [
        (
            "equipment",
            OrderLine(line_id="equipment-1", custom_fields={"asset_number": "EQ-1"}),
        ),
        ("mold", OrderLine(line_id="mold-1", product_code="MOLD-1")),
        (
            "procurement",
            OrderLine(
                line_id="receipt-1",
                quantity=5,
                unit="PCS",
                custom_fields={"receipt_number": "RCPT-1"},
            ),
        ),
    ],
)
def test_domain_specific_identity_is_accepted(
    document_type: str,
    line: OrderLine,
) -> None:
    assert domain_minimum_failures(_document(document_type, line)) == ([], set())


@pytest.mark.parametrize("document_type", ["equipment", "mold"])
def test_status_only_asset_record_is_not_a_business_identity(
    document_type: str,
) -> None:
    document = _document(
        document_type,
        OrderLine(line_id="line-1", custom_fields={"status": "active"}),
    )

    reasons, invalid = domain_minimum_failures(document)

    assert reasons == ["invalid_domain_records"]
    assert invalid == {"$.lines[0]"}


def test_raw_only_business_identity_satisfies_domain_minimum() -> None:
    document = _document(
        "order",
        OrderLine(
            line_id="line-1",
            quantity=4,
            unit="PCS",
            raw_columns={
                "Unmapped product descriptor": "Fiber optic cable assembly",
                "Qty": "4",
                "UOM": "PCS",
            },
        ),
    )
    document.header.order_number = "PO-RAW-1"

    assessment = classify_line_business_payload(
        document.lines[0],
        document_type=document.document_type,
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert domain_minimum_failures(document) == ([], set())


def test_total_marker_in_product_code_remains_business_identity() -> None:
    assessment = classify_line_business_payload(
        {"product_code": "TOTAL", "quantity": 4},
        document_type="order",
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert assessment.strong_business_payload is True


def test_direct_canonical_identity_field_is_not_treated_as_structure() -> None:
    assessment = classify_line_business_payload(
        {"asset_number": "ASSET-001", "quantity": 1},
        document_type="equipment",
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert assessment.strong_business_payload is True


def test_name_only_payload_remains_meaningful_but_not_strong() -> None:
    assessment = classify_line_business_payload(
        {"name_raw": "Payment is due within 30 days"},
        document_type="order",
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert assessment.strong_business_payload is False


def test_name_and_quantity_payload_is_strong_business_evidence() -> None:
    assessment = classify_line_business_payload(
        {"name_raw": "Fiber cable", "quantity": 20},
        document_type="order",
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert assessment.strong_business_payload is True


def test_legacy_row_issue_cannot_delete_quantity_only_continuation() -> None:
    assessment = classify_line_business_payload(
        {"quantity": 20, "unit": "PCS"},
        document_type="order",
        structural_issue_codes=["ROW_METADATA_ONLY"],
    )

    assert assessment.meaningful_business_payload is False
    assert assessment.provably_structural is False


def test_pre_normalization_unknown_column_can_protect_business_payload() -> None:
    assessment = classify_line_business_payload(
        {"Unmapped descriptor": "Fiber cable", "quantity": 4},
        document_type="order",
    )

    assert assessment.meaningful_business_payload is True
    assert assessment.provably_structural is False
    assert assessment.strong_business_payload is True


def test_missing_unit_is_a_field_review_failure_without_guessing() -> None:
    document = _document(
        "order",
        OrderLine(
            line_id="line-1",
            product_code="SKU-NO-UOM",
            quantity=8,
            unit=None,
        ),
    )
    document.header.order_number = "PO-NO-UOM"

    reasons, invalid = domain_minimum_failures(document)

    assert reasons == ["invalid_domain_records"]
    assert invalid == {"$.lines[0].unit"}
    assert document.lines[0].quantity == 8
    assert document.lines[0].unit is None


@pytest.mark.parametrize(
    "validator",
    [_validate_lines, _validate_pdf_lines],
)
@pytest.mark.parametrize(
    ("quantity", "price", "amount"),
    [
        (60, 39.58, 2374.8),
        (3, 0.333, 1.0),
    ],
)
def test_money_validation_uses_decimal_text_and_currency_precision(
    validator: Callable[[list[OrderLine]], list[object]],
    quantity: int,
    price: float,
    amount: float,
) -> None:
    issues = validator(
        [
            OrderLine(
                line_id="line-1",
                product_code="SKU-1",
                quantity=quantity,
                unit="PCS",
                unit_price_tax_included=price,
                amount_tax_included=amount,
            )
        ]
    )

    assert "LINE_AMOUNT_MISMATCH" not in {
        getattr(issue, "code", None) for issue in issues
    }


@pytest.mark.parametrize("validator", [_validate_lines, _validate_pdf_lines])
def test_money_validation_still_rejects_real_mismatch(
    validator: Callable[[list[OrderLine]], list[object]],
) -> None:
    issues = validator(
        [
            OrderLine(
                line_id="line-1",
                product_code="SKU-1",
                quantity=60,
                unit="PCS",
                unit_price_tax_included=39.58,
                amount_tax_included=2300,
            )
        ]
    )

    assert "LINE_AMOUNT_MISMATCH" in {getattr(issue, "code", None) for issue in issues}


def test_invalid_money_values_fail_comparison_without_crashing() -> None:
    assert monetary_values_equal(float("inf"), float("inf")) is False


def test_quantity_comparison_absorbs_cached_formula_float_noise() -> None:
    assert numeric_values_equal(Decimal("200.0000000000004"), 200) is True
    assert numeric_values_equal(Decimal("99.99999999999996"), 100) is True


def test_quantity_comparison_still_rejects_business_mismatch() -> None:
    assert numeric_values_equal(Decimal("200.4"), 200) is False

    issues = _validate_lines(
        [
            OrderLine(
                line_id="line-1",
                product_code="SKU-1",
                quantity=200,
                unit="PCS",
                package_quantity=12,
                piece_count=Decimal("16.7"),
            )
        ]
    )

    assert "PACKAGING_QUANTITY_MISMATCH" in {
        getattr(issue, "code", None) for issue in issues
    }
