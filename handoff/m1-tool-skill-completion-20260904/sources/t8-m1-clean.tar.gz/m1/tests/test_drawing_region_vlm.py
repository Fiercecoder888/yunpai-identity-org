from __future__ import annotations

import hashlib
import io
from pathlib import Path
from typing import Any

import pytest
from m1.documents.models import SourceReference
from m1.documents.parsing.drawing_region_vlm import (
    DRAWING_REGION_PROMPT,
    DrawingRegionVLMConfig,
    DrawingRegionVLMExtractor,
    OCRRegionProposal,
    OpenAICompatibleRegionVLMClient,
    PaddleOCRRegionLocator,
    RegionVLMResponse,
    normalize_region_callout,
)
from PIL import Image
from PIL import __version__ as PILLOW_VERSION


class FakeOCR:
    def __init__(
        self,
        proposals: list[OCRRegionProposal] | None = None,
        *,
        error: Exception | None = None,
    ) -> None:
        self.proposals = proposals or []
        self.error = error
        self.image_sizes: list[tuple[int, int]] = []

    def locate(self, image: Image.Image) -> list[OCRRegionProposal]:
        self.image_sizes.append(image.size)
        if self.error is not None:
            raise self.error
        return self.proposals


class FakeVLM:
    def __init__(self, responses: list[RegionVLMResponse | Exception]) -> None:
        self.responses = list(responses)
        self.calls: list[dict[str, Any]] = []

    async def transcribe(
        self,
        image_png: bytes,
        *,
        prompt: str,
        temperature: float,
        max_tokens: int,
        stop: list[str] | tuple[str, ...],
    ) -> RegionVLMResponse:
        with Image.open(io.BytesIO(image_png)) as image:
            size = image.size
        self.calls.append(
            {
                "size": size,
                "prompt": prompt,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "stop": tuple(stop),
                "sha256": hashlib.sha256(image_png).hexdigest(),
            }
        )
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def _proposal(
    bbox: tuple[float, float, float, float],
    *,
    score: float = 0.95,
    numeric: bool = True,
) -> OCRRegionProposal:
    return OCRRegionProposal(
        bbox=bbox,
        score=score,
        contains_numeric_hint=numeric,
    )


def _image_bytes(width: int = 240, height: int = 160) -> bytes:
    image = Image.new("RGB", (width, height), "white")
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def _source(
    asset_sha256: str | None = hashlib.sha256(_image_bytes()).hexdigest(),
) -> SourceReference:
    payload: dict[str, Any] = {
        "page": 1,
        "part": "word/media/drawing.png",
    }
    if asset_sha256 is not None:
        payload["asset_sha256"] = asset_sha256
    return SourceReference.model_validate(payload)


@pytest.mark.asyncio
async def test_symmetric_and_asymmetric_callouts_are_advisory_and_bounded() -> None:
    ocr = FakeOCR(
        [
            _proposal((10, 10, 105, 34)),
            _proposal((110, 60, 220, 90)),
        ]
    )
    vlm = FakeVLM(
        [
            RegionVLMResponse(r"$20.9 \pm 0.06$", "stop"),
            RegionVLMResponse(r"$19.5^{+0.1}_{-0.05}$", "stop"),
        ]
    )
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:drawing",
        source_ref=_source(),
        subject="line:1",
        default_unit="mm",
    )

    assert result.needs_review is False
    assert len(result.facts) == 2
    assert result.facts[0].value == {
        "nominal": "20.9",
        "symmetric_deviation": "0.06",
    }
    assert result.facts[1].value == {
        "nominal": "19.5",
        "upper_deviation": "0.1",
        "lower_deviation": "-0.05",
    }
    assert {fact.status for fact in result.facts} == {"advisory"}
    assert {fact.extractor for fact in result.facts} == {"drawing_region_vlm.v1"}
    assert all(fact.attributes["ocr_text_trusted"] is False for fact in result.facts)
    assert result.facts[0].evidence_refs[0].source_ref.model_extra["bbox"] == [
        10.0,
        10.0,
        105.0,
        34.0,
    ]
    assert (
        result.facts[0]
        .evidence_refs[0]
        .source_ref.model_extra["coordinate_space"]
        == "image_pixels"
    )
    evidence = result.facts[0].evidence_refs[0]
    extras = evidence.source_ref.model_extra
    assert evidence.evidence_id == f"asset:drawing/region:{vlm.calls[0]['sha256']}"
    assert extras == {
        "asset_sha256": hashlib.sha256(_image_bytes()).hexdigest(),
        "bbox": [10.0, 10.0, 105.0, 34.0],
        "coordinate_space": "image_pixels",
        "parent_evidence_id": "asset:drawing",
        "asset_width_pixels": 240,
        "asset_height_pixels": 160,
        "region_bbox_pixels": [10, 10, 105, 34],
        "region_crop_bbox_pixels": [0, 2, 138, 42],
        "region_output_size_pixels": [552, 160],
        "region_upscale_factor": 4,
        "region_resampling": "lanczos",
        "region_image_mode": "RGB",
        "region_encoding": "PNG",
        "region_encoding_options": {"optimize": True},
        "region_encoder": f"Pillow/{PILLOW_VERSION}",
        "region_hash_basis": "encoded_region_png_bytes",
        "region_transform_version": "m1.region-crop.v1",
        "region_sha256": vlm.calls[0]["sha256"],
        "region_rotation_degrees": 0,
        "authority": "advisory",
        "inferred": True,
        "evidence_kind": "model_transcription",
        "model_transcription": True,
    }
    assert result.audit[0].source_ref == evidence.source_ref
    assert [entry.disposition for entry in result.audit] == ["fact", "fact"]


@pytest.mark.asyncio
async def test_crop_hash_evidence_and_fact_ids_are_stable_for_replay() -> None:
    source_image = _image_bytes()

    async def run_once() -> Any:
        extractor = DrawingRegionVLMExtractor(
            ocr=FakeOCR([_proposal((12, 14, 112, 42))]),
            vlm=FakeVLM([RegionVLMResponse("R32.8", "stop")]),
        )
        return await extractor.analyze(
            source_image,
            evidence_id="asset:stable",
            source_ref=_source(hashlib.sha256(source_image).hexdigest()),
        )

    first = await run_once()
    second = await run_once()

    first_evidence = first.facts[0].evidence_refs[0]
    second_evidence = second.facts[0].evidence_refs[0]
    assert first.facts[0].fact_id == second.facts[0].fact_id
    assert first_evidence.evidence_id == second_evidence.evidence_id
    assert first_evidence.evidence_id.startswith("asset:stable/region:")
    assert len(first_evidence.evidence_id.rsplit(":", 1)[1]) == 64
    assert first_evidence.source_ref.model_extra["asset_sha256"] == hashlib.sha256(
        source_image
    ).hexdigest()
    assert (
        first_evidence.source_ref.model_extra["region_sha256"]
        == first_evidence.evidence_id.rsplit(":", 1)[1]
    )
    extras = first_evidence.source_ref.model_extra
    assert extras["region_crop_bbox_pixels"] == [0, 4, 147, 52]
    assert extras["region_output_size_pixels"] == [588, 192]
    assert extras["region_hash_basis"] == "encoded_region_png_bytes"

    with Image.open(io.BytesIO(source_image)) as image:
        replay = image.crop(tuple(extras["region_crop_bbox_pixels"])).convert("RGB")
        if extras["region_rotation_degrees"] == 90:
            replay = replay.transpose(Image.Transpose.ROTATE_270)
        replay = replay.resize(
            tuple(extras["region_output_size_pixels"]),
            Image.Resampling.LANCZOS,
        )
    replay_buffer = io.BytesIO()
    replay.save(replay_buffer, format="PNG", optimize=True)
    assert hashlib.sha256(replay_buffer.getvalue()).hexdigest() == extras[
        "region_sha256"
    ]


@pytest.mark.asyncio
async def test_region_bbox_is_clipped_to_original_asset_pixel_bounds() -> None:
    ocr = FakeOCR([_proposal((-20, -10, 280, 190))])
    vlm = FakeVLM([RegionVLMResponse("R4.9", "stop")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(width=240, height=160),
        evidence_id="asset:bounds",
        source_ref=_source(),
    )

    source_ref = result.facts[0].evidence_refs[0].source_ref
    assert source_ref.model_extra["bbox"] == [0.0, 0.0, 240.0, 160.0]
    assert source_ref.model_extra["region_bbox_pixels"] == [0, 0, 240, 160]
    assert source_ref.model_extra["asset_width_pixels"] == 240
    assert source_ref.model_extra["asset_height_pixels"] == 160


@pytest.mark.asyncio
@pytest.mark.parametrize("asset_sha256", [None, "short", "g" * 64])
async def test_missing_or_invalid_parent_asset_provenance_fails_closed(
    asset_sha256: str | None,
) -> None:
    ocr = FakeOCR([_proposal((10, 10, 100, 35))])
    vlm = FakeVLM([RegionVLMResponse("R1.1", "stop")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:missing-provenance",
        source_ref=_source(asset_sha256),
    )

    assert result.facts == []
    assert result.audit == []
    assert result.issues[0].code == "DRAWING_REGION_ASSET_PROVENANCE_MISSING"
    assert ocr.image_sizes == []
    assert vlm.calls == []


@pytest.mark.asyncio
async def test_parent_asset_sha256_must_match_analyzed_bytes() -> None:
    ocr = FakeOCR([_proposal((10, 10, 100, 35))])
    vlm = FakeVLM([RegionVLMResponse("R1.1", "stop")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:content-mismatch",
        source_ref=_source("b" * 64),
    )

    assert result.facts == []
    assert result.audit == []
    assert [issue.code for issue in result.issues] == [
        "DRAWING_REGION_ASSET_CONTENT_MISMATCH"
    ]
    assert ocr.image_sizes == []
    assert vlm.calls == []


@pytest.mark.asyncio
async def test_vertical_region_is_rotated_before_four_times_upscale() -> None:
    ocr = FakeOCR([_proposal((40, 20, 80, 100))])
    vlm = FakeVLM([RegionVLMResponse("R11.8", "stop")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(height=160),
        evidence_id="asset:vertical",
        source_ref=_source(),
    )

    assert len(result.facts) == 1
    assert result.facts[0].value == {"nominal": "11.8"}
    assert result.audit[0].rotation_degrees == 90
    assert result.facts[0].attributes["crop_rotation_degrees"] == 90
    assert vlm.calls[0]["size"][0] > vlm.calls[0]["size"][1]
    assert all(dimension % 4 == 0 for dimension in vlm.calls[0]["size"])


@pytest.mark.asyncio
async def test_overlapping_ocr_duplicates_are_transcribed_once() -> None:
    ocr = FakeOCR(
        [
            _proposal((10, 10, 110, 40), score=0.98),
            _proposal((10, 10, 110, 40), score=0.91),
        ]
    )
    vlm = FakeVLM([RegionVLMResponse("R33.5", "stop")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:duplicate",
        source_ref=_source(),
    )

    assert len(vlm.calls) == 1
    assert len(result.facts) == 1
    assert [entry.disposition for entry in result.audit].count("duplicate") == 1
    assert len({entry.candidate_id for entry in result.audit}) == 2
    assert result.issues == []


@pytest.mark.asyncio
async def test_token_truncation_returns_issue_without_partial_fact() -> None:
    ocr = FakeOCR([_proposal((10, 10, 100, 35))])
    vlm = FakeVLM([RegionVLMResponse("19.5 +0.1", "length")])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:truncated",
        source_ref=_source(),
    )

    assert result.facts == []
    assert result.issues[0].code == "DRAWING_REGION_VLM_TRUNCATED"
    assert result.audit[0].disposition == "truncated"
    assert vlm.calls[0]["temperature"] == 0.0
    assert vlm.calls[0]["max_tokens"] == 64
    assert vlm.calls[0]["stop"] == ("\n",)
    with pytest.raises(ValueError, match="between 1 and 64"):
        DrawingRegionVLMConfig(max_tokens=65)


@pytest.mark.asyncio
async def test_incomplete_and_conflicting_callouts_fail_closed() -> None:
    ocr = FakeOCR(
        [
            _proposal((10, 10, 100, 35)),
            _proposal((10, 70, 130, 100)),
        ]
    )
    vlm = FakeVLM(
        [
            RegionVLMResponse("19.5 +0.1", "stop"),
            RegionVLMResponse("19.5 ±0.05 +0.1/-0.05", "stop"),
        ]
    )
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:invalid",
        source_ref=_source(),
    )

    assert result.facts == []
    assert [issue.code for issue in result.issues] == [
        "DRAWING_REGION_CALLOUT_INVALID",
        "DRAWING_CONFLICTING_TOLERANCE",
    ]
    assert [entry.disposition for entry in result.audit] == ["invalid", "conflict"]


@pytest.mark.asyncio
async def test_explicit_negative_and_clear_identifier_are_screened() -> None:
    ocr = FakeOCR(
        [
            _proposal((10, 10, 100, 35)),
            _proposal((10, 70, 130, 100)),
        ]
    )
    vlm = FakeVLM(
        [
            RegionVLMResponse("INVALID", "stop"),
            RegionVLMResponse("DP2.1", "stop"),
        ]
    )
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:negative",
        source_ref=_source(),
    )

    assert result.facts == []
    assert result.issues == []
    assert result.needs_review is False
    assert [entry.disposition for entry in result.audit] == [
        "not_a_callout",
        "screened",
    ]
    assert [entry.normalized_text for entry in result.audit] == ["INVALID", "DP2.1"]


@pytest.mark.asyncio
async def test_bare_numeric_region_remains_ambiguous() -> None:
    extractor = DrawingRegionVLMExtractor(
        ocr=FakeOCR([_proposal((10, 10, 100, 35))]),
        vlm=FakeVLM([RegionVLMResponse("0.7", "stop")]),
    )

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:bare-number",
        source_ref=_source(),
    )

    assert result.facts == []
    assert [issue.code for issue in result.issues] == [
        "DRAWING_REGION_CALLOUT_AMBIGUOUS"
    ]
    assert result.audit[0].disposition == "ambiguous"
    assert result.audit[0].normalized_text == "0.7"


@pytest.mark.asyncio
async def test_candidate_policy_uses_signal_area_cap_and_never_ocr_text() -> None:
    ocr = FakeOCR(
        [
            _proposal((0, 0, 5, 5), numeric=True),
            _proposal((10, 10, 35, 35), score=0.95, numeric=False),
            _proposal((40, 10, 65, 35), score=0.4, numeric=False),
            _proposal((10, 60, 160, 75), score=0.95, numeric=False),
        ]
    )
    vlm = FakeVLM(
        [
            RegionVLMResponse("R1.1", "stop"),
            RegionVLMResponse("R4.2", "stop"),
        ]
    )
    extractor = DrawingRegionVLMExtractor(
        ocr=ocr,
        vlm=vlm,
        config=DrawingRegionVLMConfig(max_candidates=1),
    )

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:policy",
        source_ref=_source(),
    )

    assert len(vlm.calls) == 1
    assert len(result.facts) == 1
    assert result.issues[0].code == "DRAWING_REGION_CANDIDATE_LIMIT"
    assert any(entry.disposition == "candidate_limit" for entry in result.audit)
    assert "20.9" not in DRAWING_REGION_PROMPT
    assert "19.5" not in DRAWING_REGION_PROMPT


@pytest.mark.asyncio
async def test_ocr_unavailable_is_fail_closed_and_does_not_call_vlm() -> None:
    ocr = FakeOCR(error=RuntimeError("missing local cache"))
    vlm = FakeVLM([])
    extractor = DrawingRegionVLMExtractor(ocr=ocr, vlm=vlm)

    result = await extractor.analyze(
        _image_bytes(),
        evidence_id="asset:no-ocr",
        source_ref=_source(),
    )

    assert result.facts == []
    assert result.issues[0].code == "DRAWING_REGION_OCR_UNAVAILABLE"
    assert vlm.calls == []


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        (r"$20.9 \pm 0.06$", "20.9 ± 0.06"),
        (r"$19.5^{+0.1}_{-0.05}$", "19.5 +0.1/-0.05"),
        ("9.85 +0.1 -0.05<|txt_contd_src|>", "9.85 +0.1/-0.05"),
        (r"\(\varnothing 12.5 \pm 0.1\)", "Ø 12.5 ± 0.1"),
        ("INVALID", None),
        ("20.9 ±0.06\nexplanation", None),
    ],
)
def test_normalize_region_callout_is_conservative(
    raw: str,
    expected: str | None,
) -> None:
    assert normalize_region_callout(raw) == expected


class FakeHTTPResponse:
    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict[str, Any]:
        return {
            "choices": [
                {
                    "message": {"content": "R4.9"},
                    "finish_reason": "stop",
                }
            ]
        }


class FakeHTTPClient:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    async def post(self, endpoint: str, **kwargs: Any) -> FakeHTTPResponse:
        self.calls.append({"endpoint": endpoint, **kwargs})
        return FakeHTTPResponse()


class FakeModelCatalogResponse:
    def __init__(self, model_ids: list[str]) -> None:
        self.model_ids = model_ids

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict[str, Any]:
        return {"data": [{"id": model_id} for model_id in self.model_ids]}


class FakeModelCatalogHTTPClient:
    def __init__(self, model_ids: list[str]) -> None:
        self.model_ids = model_ids
        self.calls: list[dict[str, Any]] = []

    async def get(self, endpoint: str, **kwargs: Any) -> FakeModelCatalogResponse:
        self.calls.append({"endpoint": endpoint, **kwargs})
        return FakeModelCatalogResponse(self.model_ids)


@pytest.mark.asyncio
async def test_openai_adapter_enforces_short_deterministic_request_without_network(
) -> None:
    http = FakeHTTPClient()
    client = OpenAICompatibleRegionVLMClient(
        http_client=http,
        endpoint="http://model.invalid/v1/chat/completions",
        model="local-model",
    )

    response = await client.transcribe(
        _image_bytes(),
        prompt=DRAWING_REGION_PROMPT,
        temperature=0,
        max_tokens=64,
        stop=["\n"],
    )

    assert response == RegionVLMResponse(text="R4.9", finish_reason="stop")
    payload = http.calls[0]["json"]
    assert payload["model"] == "local-model"
    assert payload["temperature"] == 0
    assert payload["max_tokens"] == 64
    assert payload["stop"] == ["\n"]
    assert payload["messages"][0]["content"][1]["image_url"]["url"].startswith(
        "data:image/png;base64,"
    )


@pytest.mark.asyncio
async def test_openai_adapter_probe_verifies_configured_model() -> None:
    http = FakeModelCatalogHTTPClient(["other-model", "local-model"])
    client = OpenAICompatibleRegionVLMClient(
        http_client=http,
        endpoint="http://model.invalid/v1/chat/completions",
        model="local-model",
        headers={"Authorization": "Bearer test-secret"},
    )

    status = await client.probe()

    assert status == {
        "ready": True,
        "configured": True,
        "model": "local-model",
        "model_verified": True,
    }
    assert http.calls == [
        {
            "endpoint": "http://model.invalid/v1/models",
            "headers": {"Authorization": "Bearer test-secret"},
        }
    ]


@pytest.mark.asyncio
async def test_openai_adapter_probe_rejects_missing_model() -> None:
    client = OpenAICompatibleRegionVLMClient(
        http_client=FakeModelCatalogHTTPClient(["other-model"]),
        endpoint="http://model.invalid/v1/chat/completions",
        model="local-model",
    )

    with pytest.raises(RuntimeError, match="is not served by the endpoint"):
        await client.probe()


def test_paddle_locator_is_lazy_singleton_and_discards_recognized_text(
    tmp_path: Path,
) -> None:
    detection = tmp_path / "official_models" / "PP-OCRv5_server_det"
    recognition = tmp_path / "official_models" / "PP-OCRv5_server_rec"
    detection.mkdir(parents=True)
    recognition.mkdir(parents=True)

    class FakePaddle:
        def predict(self, _path: str) -> Any:
            return iter(
                [
                    {
                        "rec_texts": ["secret OCR guess 20.9"],
                        "rec_scores": [0.8],
                        "rec_polys": [[[1, 2], [11, 2], [11, 8], [1, 8]]],
                    },
                ]
            )

    instances: list[FakePaddle] = []

    def factory() -> FakePaddle:
        model = FakePaddle()
        instances.append(model)
        return model

    locator = PaddleOCRRegionLocator.from_model_root(
        tmp_path,
        model_factory=factory,
    )

    assert locator._model_options() == {
        "text_detection_model_name": "PP-OCRv5_server_det",
        "text_detection_model_dir": str(detection),
        "text_recognition_model_name": "PP-OCRv5_server_rec",
        "text_recognition_model_dir": str(recognition),
        "use_doc_orientation_classify": False,
        "use_doc_unwarping": False,
        "use_textline_orientation": False,
        "enable_mkldnn": False,
        "device": "cpu",
    }

    first = locator.locate(Image.new("RGB", (20, 20), "white"))
    second = locator.locate(Image.new("RGB", (20, 20), "white"))

    assert len(instances) == 1
    assert first == second
    assert first == [
        OCRRegionProposal(
            bbox=(1.0, 2.0, 11.0, 8.0),
            score=0.8,
            contains_numeric_hint=True,
        )
    ]
    assert not hasattr(first[0], "text")
