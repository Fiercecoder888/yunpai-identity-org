from __future__ import annotations

import pytest

from m1.documents.models import SourceReference
from m1.documents.parsing.drawing_semantics import (
    DrawingAssetObservation,
    associate_drawing_assets,
    canonical_decimal,
    extract_drawing_semantics,
)


def _ref() -> SourceReference:
    return SourceReference(page=1, part="word/media/drawing.png")


@pytest.mark.parametrize(
    ("raw", "expected"),
    [("001.100", "1.1"), (".70", "0.7"), ("-0.0500", "-0.05"), ("-0", "0")],
)
def test_canonical_decimal_is_string_preserving_and_non_exponential(
    raw: str,
    expected: str,
) -> None:
    assert canonical_decimal(raw) == expected


def test_sample_callouts_are_extracted_without_promoting_bare_thickness() -> None:
    result = extract_drawing_semantics(
        "R1.1 R11.8 R32.8 R33.5 R4.9 R4.2 0.7 "
        "20.9±0.06 11.25±0.06 19.5 +0.1/-0.05 9.85 +0.1/-0.05",
        evidence_id="asset:drawing/block:0",
        source_ref=_ref(),
        localization="token_bbox",
    )

    assert [fact.name for fact in result.facts].count("drawing_radius") == 6
    assert [fact.name for fact in result.facts].count("drawing_linear_dimension") == 4
    assert not any(
        fact.name == "drawing_thickness"
        or (isinstance(fact.value, dict) and fact.value.get("nominal") == "0.7")
        for fact in result.facts
    )
    asymmetric = next(
        fact
        for fact in result.facts
        if isinstance(fact.value, dict) and fact.value.get("nominal") == "19.5"
    )
    assert asymmetric.value == {
        "nominal": "19.5",
        "upper_deviation": "0.1",
        "lower_deviation": "-0.05",
    }
    assert asymmetric.status == "verified"
    assert result.needs_review is False


def test_diameter_and_explicit_thickness_are_typed_and_units_normalized() -> None:
    result = extract_drawing_semantics(
        "⌀12.50 ±0.10 mm; 厚度=0.700毫米",
        evidence_id="asset:drawing/block:1",
        source_ref=_ref(),
        localization="region_bbox",
    )

    diameter, thickness = result.facts
    assert diameter.name == "drawing_diameter"
    assert diameter.value == {"nominal": "12.5", "symmetric_deviation": "0.1"}
    assert diameter.unit == "mm"
    assert thickness.name == "drawing_thickness"
    assert thickness.value == {"nominal": "0.7"}
    assert thickness.unit == "mm"


def test_whole_image_flattened_text_can_only_produce_advisory_callouts() -> None:
    result = extract_drawing_semantics(
        "R33.5 20.9±0.06",
        evidence_id="asset:drawing/full-image",
        source_ref=_ref(),
    )

    assert {fact.status for fact in result.facts} == {"advisory"}
    assert all(
        fact.attributes["localization"] == "whole_image_flattened"
        for fact in result.facts
    )
    assert all(
        fact.evidence_refs[0].source_ref.range.startswith("chars:")
        for fact in result.facts
    )


def test_isolated_tolerance_is_not_attached_to_nearby_nominal() -> None:
    result = extract_drawing_semantics(
        "19.5 unrelated label +0.1/-0.05",
        evidence_id="asset:drawing/block:2",
        source_ref=_ref(),
        localization="token_bbox",
    )

    assert len(result.facts) == 1
    fact = result.facts[0]
    assert fact.name == "drawing_unassigned_tolerance"
    assert fact.value == {"upper_deviation": "0.1", "lower_deviation": "-0.05"}
    assert fact.status == "ambiguous"
    assert result.issues[0].code == "DRAWING_UNASSIGNED_TOLERANCE"
    assert result.needs_review is True


def test_tolerance_on_another_flattened_line_is_not_attached() -> None:
    result = extract_drawing_semantics(
        "19.5\n+0.1/-0.05",
        evidence_id="asset:drawing/full-image",
        source_ref=_ref(),
    )

    assert len(result.facts) == 1
    assert result.facts[0].name == "drawing_unassigned_tolerance"
    assert result.facts[0].evidence_refs[0].quote == "+0.1/-0.05"
    assert result.issues[0].code == "DRAWING_UNASSIGNED_TOLERANCE"


def test_v18_flattened_signed_pair_is_retained_as_unassigned_review_fact() -> None:
    result = extract_drawing_semantics(
        "9.85±0.05 +0.1 -0.05 工程图说明 19.5±0.05",
        evidence_id="asset:drawing/v18-flat-text",
        source_ref=_ref(),
    )

    symmetric = [
        fact
        for fact in result.facts
        if fact.name == "drawing_linear_dimension"
    ]
    unassigned = [
        fact
        for fact in result.facts
        if fact.name == "drawing_unassigned_tolerance"
    ]
    assert [fact.value["nominal"] for fact in symmetric] == ["9.85", "19.5"]
    assert len(unassigned) == 1
    assert unassigned[0].value == {
        "upper_deviation": "0.1",
        "lower_deviation": "-0.05",
    }
    assert unassigned[0].evidence_refs[0].quote == "+0.1 -0.05"
    assert unassigned[0].status == "ambiguous"
    assert result.needs_review is True


@pytest.mark.parametrize(
    "text",
    [
        "19.5±0.05 +0.1/-0.05",
        "19.5 +0.1/-0.05 ±0.05",
        "R19.5±0.05 +0.1/-0.05",
        "⌀19.5 +0.1/-0.05 ±0.05",
        "厚度 19.5±0.05 +0.1/-0.05",
    ],
)
def test_conflicting_tolerance_is_one_ambiguous_fact(text: str) -> None:
    result = extract_drawing_semantics(
        text,
        evidence_id="asset:drawing/block:3",
        source_ref=_ref(),
        localization="token_bbox",
    )

    assert len(result.facts) == 1
    fact = result.facts[0]
    assert fact.name == "drawing_dimension_tolerance_conflict"
    assert fact.value == {
        "nominal": "19.5",
        "symmetric_deviation": "0.05",
        "upper_deviation": "0.1",
        "lower_deviation": "-0.05",
    }
    assert fact.status == "ambiguous"
    assert result.issues[0].code == "DRAWING_CONFLICTING_TOLERANCE"
    assert result.needs_review is True


def _asset(
    asset_id: str,
    *,
    description: str | None = None,
    observed_color: str | None = None,
    anchor: str | None = None,
) -> DrawingAssetObservation:
    return DrawingAssetObservation(
        asset_id=asset_id,
        evidence_id=f"evidence:{asset_id}",
        source_ref=SourceReference(part=f"word/media/{asset_id}.png"),
        description=description,
        observed_color=observed_color,
        anchored_product_id=anchor,
    )


def test_unique_product_receives_all_images_as_advisory_associations() -> None:
    result = associate_drawing_assets(
        [_asset("drawing"), _asset("photo", description="product photo")],
        product_ids=["line:1"],
    )

    associations = [
        fact
        for fact in result.facts
        if fact.name == "product_image_association"
    ]
    assert len(associations) == 2
    assert {fact.value["product_id"] for fact in associations} == {"line:1"}
    assert {fact.status for fact in associations} == {"advisory"}
    assert {
        fact.attributes["association_method"] for fact in associations
    } == {"single_product_document"}
    assert result.needs_review is False


def test_multiple_products_without_row_anchor_remain_ambiguous() -> None:
    result = associate_drawing_assets(
        [_asset("photo")],
        product_ids=["line:1", "line:2"],
    )

    assert result.facts[0].status == "ambiguous"
    assert result.facts[0].value["product_id"] is None
    assert result.issues[0].code == "DRAWING_ASSET_ASSOCIATION_AMBIGUOUS"
    assert result.needs_review is True


def test_explicit_valid_anchor_can_associate_across_multiple_products() -> None:
    result = associate_drawing_assets(
        [_asset("photo", anchor="line:2")],
        product_ids=["line:1", "line:2"],
    )

    assert result.facts[0].value["product_id"] == "line:2"
    assert result.facts[0].attributes["association_method"] == "explicit_product_anchor"
    assert result.facts[0].status == "advisory"
    assert result.needs_review is False


def test_space_gray_filename_and_blue_visual_description_require_review() -> None:
    result = associate_drawing_assets(
        [_asset("photo", description="a blue cylindrical object")],
        product_ids=["line:1"],
        declared_colors={"line:1": "太空灰"},
    )

    color_fact = next(
        fact for fact in result.facts if fact.name == "visual_color_observation"
    )
    assert color_fact.value["normalized"] == "blue"
    assert color_fact.attributes["declared_normalized"] == "space_gray"
    assert color_fact.attributes["conflicts_with_declared"] is True
    assert color_fact.status == "ambiguous"
    assert result.issues[-1].code == "DRAWING_VISUAL_COLOR_CONFLICT"
    assert result.needs_review is True
