from __future__ import annotations

from types import SimpleNamespace

import pytest

from m1.knowledge.embeddings import OpenAIEmbeddingProvider


class _EmbeddingEndpoint:
    def __init__(self, dimensions: int) -> None:
        self.dimensions = dimensions
        self.calls: list[list[str]] = []

    async def create(self, *, model: str, input: list[str], encoding_format: str):
        assert model == "test-model"
        assert encoding_format == "float"
        self.calls.append(input)
        return SimpleNamespace(
            data=[
                SimpleNamespace(index=index, embedding=[float(index + 1)] * self.dimensions)
                for index, _text in reversed(list(enumerate(input)))
            ]
        )


class _Client:
    def __init__(self, dimensions: int) -> None:
        self.embeddings = _EmbeddingEndpoint(dimensions)
        self.closed = False

    async def close(self) -> None:
        self.closed = True


@pytest.mark.asyncio
async def test_openai_embedding_provider_batches_orders_and_closes():
    client = _Client(4)
    provider = OpenAIEmbeddingProvider(
        api_key="",
        base_url="https://example.invalid/v1",
        model="test-model",
        dimensions=4,
        batch_size=2,
        client=client,
    )

    vectors = await provider.embed_texts(["a", "b", "c"])

    assert client.embeddings.calls == [["a", "b"], ["c"]]
    assert vectors == [[1.0] * 4, [2.0] * 4, [1.0] * 4]
    await provider.close()
    assert client.closed is True


@pytest.mark.asyncio
async def test_openai_embedding_provider_rejects_wrong_dimensions():
    provider = OpenAIEmbeddingProvider(
        api_key="",
        base_url="https://example.invalid/v1",
        model="test-model",
        dimensions=4,
        client=_Client(3),
    )

    with pytest.raises(ValueError, match="dimension mismatch"):
        await provider.embed_texts(["bad shape"])
