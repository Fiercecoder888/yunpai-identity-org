from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from m1.api.enhanced_health_routes import (
    enhanced_configuration_fingerprint,
    register_enhanced_health_routes,
)
from m1.benchmarks.enhanced_preflight import request_preflight, save_report
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
)
from m1.enhanced_probe import (
    DOCLING,
    EMBEDDING_1024,
    LIGHTRAG_HEALTH,
    LIGHTRAG_LIFECYCLE,
    MINERU_VLM_LLM,
    PADDLEOCR_VL,
    PP_STRUCTURE,
    PREFLIGHT_CAPABILITIES,
    VLM_IMAGE,
    EnhancedCapabilityProbe,
    EnhancedProbeDependencies,
    _probe_artifacts,
)


class FakeParser:
    def __init__(
        self,
        name: str,
        *,
        low_confidence: bool = False,
        recognized_text: str = "M1PROBE42",
    ) -> None:
        self.name = name
        self.low_confidence = low_confidence
        self.recognized_text = recognized_text
        self.readiness_calls = 0
        self.parse_calls: list[dict] = []

    def readiness(self) -> dict:
        self.readiness_calls += 1
        return {
            "backend": self.name,
            "ready": True,
            "model_fingerprints": {"probe-model": "a" * 64},
        }

    def parse(self, _path: Path, *, pages=None) -> DocumentEvidence:
        self.parse_calls.append({"pages": pages})
        confidence = 0.2 if self.low_confidence else 0.99
        return DocumentEvidence(
            backend=self.name,
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=1000,
                    height=400,
                    blocks=[
                        EvidenceBlock(
                            block_id="probe",
                            text=self.recognized_text,
                            confidence=confidence,
                            bbox=EvidenceBBox(x0=10, y0=10, x1=500, y1=100),
                        )
                    ],
                    raw={"nonempty": True},
                )
            ],
        )


class FakeDocling(FakeParser):
    def parse(self, _path: Path, *, pages=None) -> DocumentEvidence:
        self.parse_calls.append({"pages": pages})
        return DocumentEvidence(
            backend=self.name,
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=100,
                    height=100,
                    blocks=[EvidenceBlock(block_id="d", text=self.recognized_text)],
                )
            ],
        )


class FakeStructuredModel:
    def __init__(self, model_name: str) -> None:
        self.model_name = model_name
        self.calls: list[dict] = []

    async def run(
        self,
        output_type,
        *,
        instructions: str,
        prompt: str,
        images=(),
    ):
        self.calls.append(
            {
                "instructions": instructions,
                "prompt": prompt,
                "image_count": len(images),
            }
        )
        if "observed_text" in output_type.model_fields:
            output = output_type(observed_text="M1 PROBE 42")
        else:
            output = output_type(result=42, marker="m1-structured-probe")
        return SimpleNamespace(output=output)


class FakeEmbedding:
    model = "BAAI/bge-m3"
    dimensions = 1024

    def __init__(
        self,
        *,
        vector_dimensions: int = 1024,
        error: Exception | None = None,
        constant: float | None = None,
    ):
        self.vector_dimensions = vector_dimensions
        self.error = error
        self.constant = constant
        self.calls = 0

    async def embed_texts(self, texts):
        self.calls += 1
        if self.error is not None:
            raise self.error
        return [
            [self.constant if self.constant is not None else 0.25 + (index * 0.01)]
            * self.vector_dimensions
            for index, _text in enumerate(texts)
        ]


class FakeLightRAG:
    workspace = "m1_shadow"

    def __init__(self) -> None:
        self.health_calls = 0

    async def health(self) -> dict:
        self.health_calls += 1
        return {
            "enabled": True,
            "ready": True,
            "workspace": self.workspace,
            "error": None,
        }


class FakeMinerUShadow:
    def __init__(self) -> None:
        self.run_calls: list[dict] = []
        self.deleted: list[str] = []

    def status(self) -> dict:
        return {
            "ready": True,
            "mapper": {"model": "qwen-probe-35b"},
        }

    async def run(self, **kwargs) -> dict:
        self.run_calls.append(kwargs)
        return {
            "status": "completed",
            "classification_match": True,
            "header_field_matches": {"order_number": True},
            "mapper_requests": 1,
            "rejected_citations": 0,
            "backend": "vlm-engine",
            "backend_version": "3.4.4",
            "line_count": {"authoritative": 1, "mineru": 1},
            "first_line_critical_matches": {
                "line_no": True,
                "product_code": True,
                "name_raw": True,
                "quantity": True,
                "unit": True,
            },
            "source_reference_coverage": {"located": 5, "total": 5, "ratio": 1.0},
        }

    async def delete_artifact(self, task_id: str) -> bool:
        self.deleted.append(task_id)
        return True


def probe_fixture(
    tmp_path: Path,
    *,
    embedding: FakeEmbedding | None = None,
):
    tmp_path.mkdir(parents=True, exist_ok=True)
    image = tmp_path / "probe.png"
    image.write_bytes(b"not-decoded-by-fakes")
    document = tmp_path / "probe.html"
    document.write_text("<p>M1DOCLING42</p>", encoding="utf-8")
    pp = FakeParser("pp-structure-v3", low_confidence=True)
    paddle_vl = FakeParser("paddleocr-vl-1.6")
    docling = FakeDocling("docling", recognized_text="M1DOCLING42")
    image_model = FakeStructuredModel("probe-image-vlm")
    embedding = embedding or FakeEmbedding()
    lightrag = FakeLightRAG()
    mineru = FakeMinerUShadow()
    lifecycle_calls: list[float] = []

    async def lifecycle(_client, timeout: float):
        lifecycle_calls.append(timeout)
        return {
            "duplicate_idempotent": True,
            "repeat_write_document_count": 1,
            "indexed_retrievable": True,
            "document_absent_after_delete": True,
            "query_absent_after_delete": True,
            "deletion_consistent": True,
            "latency_ms": 1.25,
            "error": None,
        }

    probe = EnhancedCapabilityProbe(
        EnhancedProbeDependencies(
            pp_structure=pp,
            paddleocr_vl=paddle_vl,
            docling=docling,
            image_model=image_model,
            embedding_provider=embedding,
            lightrag=lightrag,
            lightrag_lifecycle=lifecycle,
            mineru_shadow=mineru,
        ),
        required_capabilities=PREFLIGHT_CAPABILITIES,
        image_path=image,
        docling_path=document,
        expected_image_text="M1PROBE42",
        timeout_seconds=5,
    )
    return probe, SimpleNamespace(
        pp=pp,
        paddle_vl=paddle_vl,
        docling=docling,
        image_model=image_model,
        embedding=embedding,
        lightrag=lightrag,
        mineru=mineru,
        lifecycle_calls=lifecycle_calls,
    )


def test_readiness_is_side_effect_free_and_does_not_call_remote_services(
    tmp_path: Path,
) -> None:
    probe, calls = probe_fixture(tmp_path)

    report = probe.readiness()

    assert report.ready is True
    assert report.mode == "ready"
    assert report.inference_executed is False
    assert report.network_executed is False
    assert calls.pp.readiness_calls == 1
    assert calls.pp.parse_calls == []
    assert calls.paddle_vl.parse_calls == []
    assert calls.docling.parse_calls == []
    assert calls.image_model.calls == []
    assert calls.embedding.calls == 0
    assert calls.lightrag.health_calls == 0
    assert calls.mineru.run_calls == []


def test_synthetic_probe_marker_is_large_without_system_fonts() -> None:
    from PIL import Image, ImageChops

    with (
        _probe_artifacts(None, None, "M1PROBE42") as (image_path, _, _, _),
        Image.open(image_path) as image,
    ):
        interior = image.convert("L").crop((40, 40, 1160, 320))
        ink_bounds = ImageChops.invert(interior).getbbox()

    assert ink_bounds is not None
    assert ink_bounds[3] - ink_bounds[1] >= 60


@pytest.mark.asyncio
async def test_preflight_exercises_every_real_capability_and_triggered_vl_page(
    tmp_path: Path,
) -> None:
    probe, calls = probe_fixture(tmp_path)

    report = await probe.preflight(include_lightrag_lifecycle=True)

    assert report.ready is True
    assert report.inference_executed is True
    assert report.network_executed is True
    assert report.lifecycle_side_effects_requested is True
    assert set(report.results) == PREFLIGHT_CAPABILITIES | {LIGHTRAG_LIFECYCLE}
    assert all(result.status == "passed" for result in report.results.values())
    assert len(calls.pp.parse_calls) == 1
    assert len(calls.paddle_vl.parse_calls) == 1
    assert calls.paddle_vl.parse_calls[0]["pages"][0].page_number == 1
    assert report.results[PADDLEOCR_VL].details["explicit_preflight_trigger"] is False
    assert report.results[PADDLEOCR_VL].details["trigger_reasons"] == {
        "1": ["low_text_confidence"]
    }
    assert len(calls.docling.parse_calls) == 1
    assert [call["image_count"] for call in calls.image_model.calls] == [1]
    assert calls.embedding.calls == 1
    assert report.results[EMBEDDING_1024].details["dimensions"] == [1024, 1024]
    assert report.results[EMBEDDING_1024].details["nonzero"] is True
    assert report.results[EMBEDDING_1024].details["distinct"] is True
    assert calls.lightrag.health_calls == 1
    assert len(calls.mineru.run_calls) == 1
    assert len(calls.mineru.deleted) == 1
    assert calls.mineru.deleted[0].startswith("enhanced-preflight-mineru-")
    assert calls.mineru.run_calls[0]["task_id"] == calls.mineru.deleted[0]
    assert report.results[MINERU_VLM_LLM].status == "passed"
    assert calls.lifecycle_calls == [120.0]
    assert probe.last_preflight is report


@pytest.mark.asyncio
async def test_parser_probes_reject_unrelated_nonempty_results(tmp_path: Path) -> None:
    probe, calls = probe_fixture(tmp_path)
    calls.pp.recognized_text = "UNRELATED PP OUTPUT"
    calls.paddle_vl.recognized_text = "UNRELATED PADDLE VLM OUTPUT"
    calls.docling.recognized_text = "UNRELATED DOCLING OUTPUT"

    report = await probe.preflight()

    for capability in (PP_STRUCTURE, PADDLEOCR_VL, DOCLING):
        assert report.results[capability].status == "failed"
        assert report.results[capability].details["expected_marker_matched"] is False


@pytest.mark.asyncio
async def test_probe_reports_only_exception_type_and_never_secret_message(
    tmp_path: Path,
) -> None:
    embedding = FakeEmbedding(error=RuntimeError("api_key=super-secret-value"))
    probe, _calls = probe_fixture(tmp_path, embedding=embedding)

    report = await probe.preflight()
    encoded = report.model_dump_json()

    assert report.ready is False
    assert report.results[EMBEDDING_1024].status == "failed"
    assert report.results[EMBEDDING_1024].error_type == "RuntimeError"
    assert "super-secret-value" not in encoded
    assert "api_key" not in encoded


@pytest.mark.asyncio
async def test_embedding_probe_rejects_non_1024_vector(tmp_path: Path) -> None:
    probe, _calls = probe_fixture(
        tmp_path,
        embedding=FakeEmbedding(vector_dimensions=3),
    )

    report = await probe.preflight()

    assert report.ready is False
    assert report.results[EMBEDDING_1024].status == "failed"
    assert report.results[EMBEDDING_1024].details["dimensions"] == [3, 3]
    assert report.results[EMBEDDING_1024].error_type == "ProbeAssertionFailed"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("constant", "failed_detail"),
    [(0.0, "nonzero"), (0.25, "distinct")],
)
async def test_embedding_probe_rejects_zero_or_identical_vectors(
    tmp_path: Path,
    constant: float,
    failed_detail: str,
) -> None:
    probe, _calls = probe_fixture(
        tmp_path,
        embedding=FakeEmbedding(constant=constant),
    )

    report = await probe.preflight()

    assert report.results[EMBEDDING_1024].status == "failed"
    assert report.results[EMBEDDING_1024].details[failed_detail] is False


def test_enhanced_routes_keep_ready_non_inferencing_and_gate_lifecycle(
    tmp_path: Path,
) -> None:
    probe, calls = probe_fixture(tmp_path)
    app = FastAPI()
    register_enhanced_health_routes(
        app,
        SimpleNamespace(),
        settings_obj=SimpleNamespace(
            enhanced_preflight_api_key="route-preflight-secret"
        ),
        probe_factory=lambda: probe,
    )

    with TestClient(app) as client:
        ready = client.get("/enhanced/ready")
        assert ready.status_code == 200
        assert ready.json()["inference_executed"] is False
        configuration_fingerprint = ready.json()["configuration_fingerprint"]
        assert len(configuration_fingerprint) == 64
        assert calls.lightrag.health_calls == 0

        unconfirmed = client.post(
            "/enhanced/preflight",
            json={"include_lightrag_lifecycle": True},
            headers={"X-M1-Preflight-Key": "route-preflight-secret"},
        )
        assert unconfirmed.status_code == 422
        assert calls.lifecycle_calls == []

        preflight = client.post(
            "/enhanced/preflight",
            json={
                "include_lightrag_lifecycle": True,
                "confirm_lightrag_lifecycle_side_effects": True,
            },
            headers={"X-M1-Preflight-Key": "route-preflight-secret"},
        )
        assert preflight.status_code == 200
        assert preflight.json()["mode"] == "preflight"
        assert (
            preflight.json()["configuration_fingerprint"] == configuration_fingerprint
        )
        assert calls.lifecycle_calls == [120.0]

        cached = client.get("/enhanced/ready")
        assert cached.status_code == 200
        assert cached.json()["inference_executed"] is False
        assert cached.json()["last_preflight_ready"] is True
        assert cached.json()["last_preflight_finished_at"] is not None
        assert calls.lightrag.health_calls == 1

    assert probe.readiness().results[PP_STRUCTURE].exercised is False
    assert probe.readiness().results[DOCLING].exercised is False
    assert probe.readiness().results[VLM_IMAGE].exercised is False
    assert probe.readiness().results[LIGHTRAG_HEALTH].exercised is False


def test_enhanced_configuration_fingerprint_binds_secret_and_endpoint() -> None:
    original_settings = SimpleNamespace(
        model="model-a",
        base_url="http://model-a/v1",
        api_key="a",
        enhanced_preflight_api_key="preflight-secret-a",
    )
    original = enhanced_configuration_fingerprint(original_settings)
    repeated = enhanced_configuration_fingerprint(original_settings)
    changed_secret = enhanced_configuration_fingerprint(
        SimpleNamespace(
            model="model-a",
            base_url="http://model-a/v1",
            api_key="b",
            enhanced_preflight_api_key="preflight-secret-a",
        )
    )
    changed_endpoint = enhanced_configuration_fingerprint(
        SimpleNamespace(
            model="model-a",
            base_url="http://model-b/v1",
            api_key="a",
            enhanced_preflight_api_key="preflight-secret-a",
        )
    )
    changed_fingerprint_key = enhanced_configuration_fingerprint(
        SimpleNamespace(
            model="model-a",
            base_url="http://model-a/v1",
            api_key="a",
            enhanced_preflight_api_key="preflight-secret-b",
        )
    )

    assert original is not None
    assert len(original) == 64
    assert original == repeated
    assert original != changed_secret
    assert original != changed_endpoint
    assert original != changed_fingerprint_key
    unhashed_payload = vars(original_settings).copy()
    unhashed_payload.pop("enhanced_preflight_api_key")
    assert (
        original
        != hashlib.sha256(
            b"m1-enhanced-configuration-fingerprint-v1\0"
            + json.dumps(
                unhashed_payload,
                ensure_ascii=True,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            ).encode("utf-8")
        ).hexdigest()
    )
    assert (
        enhanced_configuration_fingerprint(
            SimpleNamespace(model="model-a", enhanced_preflight_api_key="")
        )
        is None
    )


def test_enhanced_preflight_requires_independent_secret_and_disables_when_empty(
    tmp_path: Path,
) -> None:
    disabled_probe, _disabled_calls = probe_fixture(tmp_path / "disabled")
    disabled_app = FastAPI()
    register_enhanced_health_routes(
        disabled_app,
        SimpleNamespace(),
        settings_obj=SimpleNamespace(enhanced_preflight_api_key=""),
        probe_factory=lambda: disabled_probe,
    )
    with TestClient(disabled_app) as client:
        disabled = client.post("/enhanced/preflight", json={})

    assert disabled.status_code == 503

    protected_probe, _protected_calls = probe_fixture(tmp_path / "protected")
    protected_app = FastAPI()
    register_enhanced_health_routes(
        protected_app,
        SimpleNamespace(),
        settings_obj=SimpleNamespace(
            enhanced_preflight_api_key="independent-preflight-secret"
        ),
        probe_factory=lambda: protected_probe,
    )
    with TestClient(protected_app) as client:
        missing = client.post("/enhanced/preflight", json={})
        wrong = client.post(
            "/enhanced/preflight",
            json={},
            headers={"X-M1-Preflight-Key": "wrong"},
        )
        accepted = client.post(
            "/enhanced/preflight",
            json={},
            headers={"X-M1-Preflight-Key": "independent-preflight-secret"},
        )

    assert missing.status_code == 401
    assert wrong.status_code == 403
    assert accepted.status_code == 200


def test_enhanced_routes_are_protected_by_existing_api_key_middleware(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from m1.api import main as api_main

    probe, calls = probe_fixture(tmp_path)
    monkeypatch.setattr(
        api_main,
        "settings",
        SimpleNamespace(
            api_auth_key="enhanced-route-secret",
            tenant_api_key_hashes="",
        ),
    )
    app = FastAPI()
    register_enhanced_health_routes(
        app,
        SimpleNamespace(),
        probe_factory=lambda: probe,
    )
    app.add_middleware(api_main.ApiKeyMiddleware)

    with TestClient(app) as client:
        assert client.get("/enhanced/ready").status_code == 401
        authorized = client.get(
            "/enhanced/ready",
            headers={"X-API-Key": "enhanced-route-secret"},
        )

    assert authorized.status_code == 200
    assert calls.lightrag.health_calls == 0


@pytest.mark.asyncio
async def test_deployment_preflight_client_archives_report_without_api_key(
    tmp_path: Path,
) -> None:
    seen: dict = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["api_key"] = request.headers.get("X-API-Key")
        seen["preflight_key"] = request.headers.get("X-M1-Preflight-Key")
        seen["body"] = request.read().decode("utf-8")
        return httpx.Response(
            200,
            json={
                "mode": "preflight",
                "ready": True,
                "finished_at": "2026-07-19T12:00:00+00:00",
                "results": {},
            },
        )

    status, report = await request_preflight(
        base_url="http://m1.invalid",
        api_key="deployment-secret",
        preflight_key="preflight-secret",
        require_all=True,
        include_lightrag_lifecycle=True,
        timeout_seconds=5,
        transport=httpx.MockTransport(handler),
    )
    output = tmp_path / "last-preflight.json"
    save_report(output, report)
    archived = output.read_text(encoding="utf-8")

    assert status == 200
    assert seen["api_key"] == "deployment-secret"
    assert seen["preflight_key"] == "preflight-secret"
    assert '"require_all":true' in seen["body"]
    assert '"confirm_lightrag_lifecycle_side_effects":true' in seen["body"]
    assert "deployment-secret" not in archived
    assert "preflight-secret" not in archived
    assert "captured_at" in archived
    assert "2026-07-19T12:00:00+00:00" in archived
