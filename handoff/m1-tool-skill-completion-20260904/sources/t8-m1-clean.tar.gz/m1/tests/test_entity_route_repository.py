from __future__ import annotations

from pathlib import Path

import pytest
from m1.knowledge import (
    CanonicalEntityRecord,
    ClaimStatus,
    EntityAliasRecord,
    KnowledgeStore,
    LifecycleStatus,
    TenantRecord,
)
from m1.knowledge.db_models import EntityRouteDecisionRow, EntityRouteIndexRow
from m1.knowledge.entity_routing import EntityRouteAction, EntityRouteDecision
from m1.knowledge.persistence import IdempotencyConflictError, RecordNotFoundError
from m1.knowledge.schema import TaskTombstonedError, new_id, utc_now
from sqlalchemy.exc import IntegrityError


def _document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "route-source.xlsx",
            "display_filename": "route-source.xlsx",
            "sha256": "e" * 64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "size_bytes": 128,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {"title": "route source"},
        "lines": [],
        "field_meta": {},
        "needs_review": False,
    }


@pytest.fixture
async def routed_store(tmp_path: Path):
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'entity-routes.db'}")
    await store.init()
    tenant = await store.create_tenant(
        TenantRecord(tenant_key="entity-route", display_name="Entity route tenant")
    )
    try:
        yield store, tenant
    finally:
        await store.close()


async def _enterprise(store: KnowledgeStore, tenant_id: str, key: str, label: str):
    return await store.put_entity(
        CanonicalEntityRecord(
            tenant_id=tenant_id,
            entity_type="enterprise",
            canonical_key=key,
            canonical_label=label,
            lifecycle_status=LifecycleStatus.ACTIVE,
        )
    )


@pytest.mark.asyncio
async def test_entity_candidate_search_is_tenant_scoped_and_fuses_vector(routed_store):
    store, tenant = routed_store
    first = await _enterprise(store, tenant.tenant_id, "enterprise:a", "Acme Industrial")
    second = await _enterprise(store, tenant.tenant_id, "enterprise:b", "Different Company")
    other = await store.create_tenant(
        TenantRecord(tenant_key="entity-route-other", display_name="Other tenant")
    )
    other_entity = await _enterprise(
        store, other.tenant_id, "enterprise:other", "Acme Industrial"
    )
    await store.add_entity_alias(
        EntityAliasRecord(
            tenant_id=tenant.tenant_id,
            entity_id=first.entity_id,
            alias="ACME",
            normalized_alias="acme",
            source_system="manual",
            status=ClaimStatus.ACCEPTED,
        )
    )
    vector = [1.0, *([0.0] * 1023)]
    await store.upsert_entity_route_index(
        tenant.tenant_id,
        entity_id=first.entity_id,
        entity_type="enterprise",
        normalized_text="acme industrial acme",
        embedding=vector,
        embedding_model="test-embedding",
    )
    await store.upsert_entity_route_index(
        tenant.tenant_id,
        entity_id=second.entity_id,
        entity_type="enterprise",
        normalized_text="different company",
        embedding=[0.0, 1.0, *([0.0] * 1022)],
        embedding_model="test-embedding",
    )

    candidates = await store.find_entity_route_candidates(
        tenant.tenant_id,
        entity_type="enterprise",
        normalized_label="acme",
        query_embedding=vector,
        embedding_model="test-embedding",
    )

    assert candidates[0].entity_id == first.entity_id
    assert all(candidate.entity_id != other_entity.entity_id for candidate in candidates)
    assert candidates[0].exact_alias is True
    assert candidates[0].vector_score == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_entity_route_decision_is_idempotent_and_validates_candidate(routed_store):
    store, tenant = routed_store
    entity = await _enterprise(store, tenant.tenant_id, "enterprise:a", "Acme Industrial")
    fence = await store.begin_task_fence(tenant.tenant_id, "task-route")
    ingested = await store.ingest_document(
        tenant.tenant_id,
        "task-route",
        _document(),
        fence=fence,
    )
    decision = EntityRouteDecision(
        action=EntityRouteAction.LINK,
        candidate_entity_id=entity.entity_id,
        candidate_score=0.98,
        top1_top2_margin=0.20,
        model_confidence=0.91,
        reason_codes=("model_confirmed_candidate",),
        model_used=True,
    )
    first = await store.record_entity_route_decision(
        tenant.tenant_id,
        source_version_id=ingested.version_id,
        proposed_entity_id="proposed-enterprise",
        entity_type="enterprise",
        decision=decision,
        fence=fence,
        model_name="small-model",
    )
    replay = await store.record_entity_route_decision(
        tenant.tenant_id,
        source_version_id=ingested.version_id,
        proposed_entity_id="proposed-enterprise",
        entity_type="enterprise",
        decision=decision,
        fence=fence,
        model_name="small-model",
    )

    assert replay == first
    stored = await store.get_entity_route_decision(
        tenant.tenant_id,
        source_version_id=ingested.version_id,
        proposed_entity_id="proposed-enterprise",
        entity_type="enterprise",
    )
    assert stored == decision
    with pytest.raises(IdempotencyConflictError):
        await store.record_entity_route_decision(
            tenant.tenant_id,
            source_version_id=ingested.version_id,
            proposed_entity_id="proposed-enterprise",
            entity_type="enterprise",
            decision=decision.model_copy(update={"candidate_score": 0.90}),
            fence=fence,
            model_name="small-model",
        )


@pytest.mark.asyncio
async def test_entity_route_decision_rejects_cross_tenant_candidate_and_stale_fence(
    routed_store,
):
    store, tenant = routed_store
    fence = await store.begin_task_fence(tenant.tenant_id, "task-route-fence")
    ingested = await store.ingest_document(
        tenant.tenant_id,
        "task-route-fence",
        _document(),
        fence=fence,
    )
    other = await store.create_tenant(
        TenantRecord(tenant_key="entity-route-foreign", display_name="Foreign tenant")
    )
    foreign = await _enterprise(
        store,
        other.tenant_id,
        "enterprise:foreign",
        "Foreign enterprise",
    )
    decision = EntityRouteDecision(
        action=EntityRouteAction.LINK,
        candidate_entity_id=foreign.entity_id,
        candidate_score=1.0,
        top1_top2_margin=1.0,
        model_confidence=1.0,
        reason_codes=("test",),
        model_used=False,
    )

    with pytest.raises(RecordNotFoundError):
        await store.record_entity_route_decision(
            tenant.tenant_id,
            source_version_id=ingested.version_id,
            proposed_entity_id="proposed-enterprise",
            entity_type="enterprise",
            decision=decision,
            fence=fence,
        )

    await store.tombstone_task_fence(tenant.tenant_id, "task-route-fence")
    with pytest.raises(TaskTombstonedError):
        await store.record_entity_route_decision(
            tenant.tenant_id,
            source_version_id=ingested.version_id,
            proposed_entity_id="proposed-enterprise",
            entity_type="enterprise",
            decision=EntityRouteDecision(
                action=EntityRouteAction.NEW_CANDIDATE,
                reason_codes=("test",),
            ),
            fence=fence,
        )


@pytest.mark.asyncio
async def test_entity_route_database_foreign_keys_reject_cross_tenant_references(
    routed_store,
):
    store, tenant = routed_store
    local_fence = await store.begin_task_fence(tenant.tenant_id, "tenant-fk-local")
    local_version = await store.ingest_document(
        tenant.tenant_id,
        "tenant-fk-local",
        _document(),
        fence=local_fence,
    )
    other = await store.create_tenant(
        TenantRecord(tenant_key="tenant-fk-other", display_name="Foreign tenant")
    )
    foreign_entity = await _enterprise(
        store,
        other.tenant_id,
        "enterprise:tenant-fk-foreign",
        "Foreign enterprise",
    )
    foreign_fence = await store.begin_task_fence(other.tenant_id, "tenant-fk-other")
    foreign_version = await store.ingest_document(
        other.tenant_id,
        "tenant-fk-other",
        _document(),
        fence=foreign_fence,
    )

    async def reject(row) -> None:
        with pytest.raises(IntegrityError):
            async with store.sessionmaker() as session:
                session.add(row)
                await session.commit()

    await reject(
        EntityRouteIndexRow(
            index_id=new_id(),
            tenant_id=tenant.tenant_id,
            entity_id=foreign_entity.entity_id,
            entity_type="enterprise",
            normalized_text="foreign enterprise",
            embedding=[0.0] * 1024,
            embedding_model="test-embedding",
            embedding_dimensions=1024,
            updated_at=utc_now(),
        )
    )
    await reject(
        EntityRouteDecisionRow(
            decision_id=new_id(),
            tenant_id=tenant.tenant_id,
            source_version_id=foreign_version.version_id,
            proposed_entity_id="foreign-source-version",
            entity_type="enterprise",
            action=EntityRouteAction.REVIEW.value,
            candidate_entity_id=None,
            candidate_score=0.0,
            top1_top2_margin=0.0,
            model_confidence=0.0,
            reason_codes=[],
            model_name="",
            model_revision="",
            created_at=utc_now(),
        )
    )
    await reject(
        EntityRouteDecisionRow(
            decision_id=new_id(),
            tenant_id=tenant.tenant_id,
            source_version_id=local_version.version_id,
            proposed_entity_id="foreign-candidate",
            entity_type="enterprise",
            action=EntityRouteAction.LINK.value,
            candidate_entity_id=foreign_entity.entity_id,
            candidate_score=1.0,
            top1_top2_margin=1.0,
            model_confidence=1.0,
            reason_codes=["test"],
            model_name="",
            model_revision="",
            created_at=utc_now(),
        )
    )
