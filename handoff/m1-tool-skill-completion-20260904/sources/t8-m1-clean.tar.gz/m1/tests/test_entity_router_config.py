"""Configuration contract for tenant-scoped entity identity routing."""

from pathlib import Path

import pytest
import yaml
from m1.core.config import Settings
from pydantic import ValidationError

_REPOSITORY = Path(__file__).resolve().parents[2]
_ENTITY_ROUTER_VARIABLES = {
    "ENTITY_ROUTER_ENABLED",
    "ENTITY_ROUTER_REQUIRED",
    "ENTITY_ROUTER_BASE_URL",
    "ENTITY_ROUTER_API_KEY",
    "ENTITY_ROUTER_MODEL",
    "ENTITY_ROUTER_TIMEOUT_SECONDS",
    "ENTITY_ROUTER_TOP_K",
    "ENTITY_ROUTER_AUTO_MIN_SCORE",
    "ENTITY_ROUTER_MODEL_MIN_CONFIDENCE",
    "ENTITY_ROUTER_MIN_MARGIN",
    "ENTITY_ROUTER_CIRCUIT_FAILURES",
    "ENTITY_ROUTER_CIRCUIT_SECONDS",
}


def _compose_environment(relative_path: str) -> dict[str, str]:
    compose = yaml.safe_load((_REPOSITORY / relative_path).read_text(encoding="utf-8"))
    values = compose["services"]["m1"]["environment"]
    return values if isinstance(values, dict) else dict(value.split("=", 1) for value in values)


def _settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "entity_router_enabled": False,
        "entity_router_required": False,
        "entity_router_base_url": "",
        "entity_router_api_key": "",
        "entity_router_model": "",
    }
    values.update(overrides)
    return Settings(**values)


def test_entity_router_defaults_are_disabled_and_fail_safe() -> None:
    settings = _settings()

    assert settings.entity_router_enabled is False
    assert settings.entity_router_required is False
    assert settings.entity_router_top_k == 5
    assert settings.entity_router_auto_min_score == 0.90
    assert settings.entity_router_model_min_confidence == 0.85


def test_required_entity_router_must_be_enabled() -> None:
    with pytest.raises(
        ValidationError,
        match="ENTITY_ROUTER_REQUIRED requires ENTITY_ROUTER_ENABLED",
    ):
        _settings(entity_router_required=True)


@pytest.mark.parametrize(
    ("missing_field", "message"),
    [
        ("entity_router_base_url", "ENTITY_ROUTER_BASE_URL is required"),
        ("entity_router_api_key", "ENTITY_ROUTER_API_KEY is required"),
        ("entity_router_model", "ENTITY_ROUTER_MODEL is required"),
    ],
)
def test_enabled_entity_router_requires_complete_model_contract(
    missing_field: str,
    message: str,
) -> None:
    values: dict[str, object] = {
        "entity_router_enabled": True,
        "entity_router_base_url": "http://router.invalid/v1",
        "entity_router_api_key": "test-only-secret",
        "entity_router_model": "small-router",
    }
    values[missing_field] = ""

    with pytest.raises(ValidationError, match=message) as error:
        _settings(**values)
    assert "test-only-secret" not in str(error.value)


def test_entity_router_secret_is_not_in_settings_repr() -> None:
    settings = _settings(
        entity_router_enabled=True,
        entity_router_base_url="http://router.invalid/v1",
        entity_router_api_key="test-only-secret",
        entity_router_model="small-router",
    )

    assert "test-only-secret" not in repr(settings)


def test_entity_router_runtime_and_dev_contracts_are_complete_and_off() -> None:
    runtime = _compose_environment("m1/deploy/compose.runtime.yml")
    development = _compose_environment("m1/deploy/compose.dev.yml")

    assert _ENTITY_ROUTER_VARIABLES <= set(runtime)
    assert _ENTITY_ROUTER_VARIABLES <= set(development)
    assert runtime["ENTITY_ROUTER_ENABLED"].endswith(":-false}")
    assert runtime["ENTITY_ROUTER_REQUIRED"].endswith(":-false}")
    assert runtime["ENTITY_ROUTER_API_KEY"] == "${M1_ENTITY_ROUTER_API_KEY:-}"
    assert development["ENTITY_ROUTER_ENABLED"].endswith(":-false}")
    assert development["ENTITY_ROUTER_API_KEY"] == "${ENTITY_ROUTER_API_KEY:-}"


def test_entity_router_safe_environment_examples_document_all_variables() -> None:
    for relative_path in ("m1/.env.example", "deploy/source-runtime/deploy.env.example"):
        lines = set((_REPOSITORY / relative_path).read_text(encoding="utf-8").splitlines())
        for name in _ENTITY_ROUTER_VARIABLES:
            prefixed = f"M1_{name}"
            assert any(line.startswith(f"{prefixed}=") for line in lines)
            if relative_path == "m1/.env.example":
                assert any(line.startswith(f"{name}=") for line in lines)
