from __future__ import annotations

import pytest
from m1.knowledge.entity_routing import (
    EntityRouteAction,
    EntityRouteCandidate,
    EntityRouteModelChoice,
    EntityRoutePolicy,
    EntityRouteRequest,
)
from m1.knowledge.entity_routing_runtime import EntityRoutingRuntime
from m1.knowledge.schema import (
    CanonicalEntityRecord,
    ClaimStatus,
    ExternalIdentityRecord,
    LifecycleStatus,
)
from pydantic import ValidationError


def _candidate(
    entity_id: str,
    *,
    score: float,
    exact_identity: bool = False,
) -> EntityRouteCandidate:
    return EntityRouteCandidate(
        tenant_id="tenant-a",
        entity_id=entity_id,
        entity_type="enterprise",
        canonical_label=entity_id,
        accepted_aliases=(entity_id,),
        fused_score=score,
        lexical_score=score,
        vector_score=score,
        exact_identity=exact_identity,
    )


def _request(*candidates: EntityRouteCandidate) -> EntityRouteRequest:
    return EntityRouteRequest(
        tenant_id="tenant-a",
        proposed_entity_id="proposed-1",
        entity_type="enterprise",
        normalized_label="example enterprise",
        candidates=candidates,
    )


def test_no_candidate_starts_candidate_without_model() -> None:
    decision = EntityRoutePolicy().decide(_request())

    assert decision.action is EntityRouteAction.NEW_CANDIDATE
    assert decision.candidate_entity_id is None


def test_exact_external_identity_links_without_model() -> None:
    decision = EntityRoutePolicy().decide(
        _request(_candidate("entity-1", score=0.4, exact_identity=True))
    )

    assert decision.action is EntityRouteAction.LINK
    assert decision.candidate_entity_id == "entity-1"
    assert decision.model_used is False


def test_conflicting_exact_identities_fail_closed_to_review() -> None:
    decision = EntityRoutePolicy().decide(
        _request(
            _candidate("entity-1", score=1.0, exact_identity=True),
            _candidate("entity-2", score=1.0, exact_identity=True),
        )
    )

    assert decision.action is EntityRouteAction.REVIEW
    assert decision.candidate_entity_id is None


def test_model_cannot_select_candidate_outside_server_list() -> None:
    decision = EntityRoutePolicy().decide(
        _request(_candidate("entity-1", score=0.99)),
        {
            "action": "link",
            "candidate_entity_id": "invented-id",
            "confidence": 0.99,
        },
    )

    assert decision.action is EntityRouteAction.REVIEW
    assert decision.reason_codes == ("model_selected_unknown_candidate",)


def test_model_link_requires_score_margin_and_confidence() -> None:
    policy = EntityRoutePolicy(auto_min_score=0.9, min_margin=0.1, model_min_confidence=0.85)
    request = _request(
        _candidate("entity-1", score=0.95),
        _candidate("entity-2", score=0.88),
    )
    decision = policy.decide(
        request,
        {
            "action": "link",
            "candidate_entity_id": "entity-1",
            "confidence": 0.9,
            "reason_codes": ["semantic_match"],
        },
    )

    assert decision.action is EntityRouteAction.REVIEW
    assert decision.reason_codes[0] == "model_link_below_hard_threshold"


def test_strong_model_link_is_accepted() -> None:
    decision = EntityRoutePolicy().decide(
        _request(
            _candidate("entity-1", score=0.98),
            _candidate("entity-2", score=0.80),
        ),
        {
            "action": "link",
            "candidate_entity_id": "entity-1",
            "confidence": 0.91,
            "reason_codes": ["same_alias"],
        },
    )

    assert decision.action is EntityRouteAction.LINK
    assert decision.candidate_entity_id == "entity-1"
    assert decision.model_used is True


def test_model_new_candidate_requires_confidence() -> None:
    request = _request(_candidate("entity-1", score=0.82))
    decision = EntityRoutePolicy(model_min_confidence=0.85).decide(
        request,
        {
            "action": "new_candidate",
            "confidence": 0.84,
            "reason_codes": ["different_entity"],
        },
    )

    assert decision.action is EntityRouteAction.REVIEW
    assert decision.reason_codes[0] == "model_new_candidate_below_confidence"
    assert decision.model_used is True


def test_confident_model_may_start_reviewable_candidate() -> None:
    request = _request(_candidate("entity-1", score=0.82))
    decision = EntityRoutePolicy(model_min_confidence=0.85).decide(
        request,
        {
            "action": "new_candidate",
            "confidence": 0.91,
            "reason_codes": ["different_entity"],
        },
    )

    assert decision.action is EntityRouteAction.NEW_CANDIDATE
    assert decision.reason_codes[0] == "model_new_candidate"
    assert decision.model_used is True


def test_model_choice_rejects_candidate_for_non_link_action() -> None:
    with pytest.raises(ValidationError):
        EntityRouteModelChoice(
            action="review",
            candidate_entity_id="entity-1",
            confidence=0.5,
        )


def test_blocking_conflict_overrides_an_exact_candidate() -> None:
    request = _request(_candidate("entity-1", score=1.0, exact_identity=True)).model_copy(
        update={"blocking_conflict": True}
    )

    decision = EntityRoutePolicy().decide(request)

    assert decision.action is EntityRouteAction.REVIEW
    assert decision.reason_codes == ("blocking_identity_conflict",)


def test_request_rejects_cross_tenant_candidate() -> None:
    candidate = _candidate("entity-1", score=0.99).model_copy(
        update={"tenant_id": "tenant-b"}
    )

    with pytest.raises(ValidationError, match="requested tenant"):
        _request(candidate)


def test_only_trusted_accepted_stable_identity_can_bypass_model() -> None:
    def identity(**updates: object) -> ExternalIdentityRecord:
        values: dict[str, object] = {
            "tenant_id": "tenant-a",
            "entity_id": "proposed-product",
            "entity_type": "product",
            "source_system": "tenant:internal_product_code",
            "external_id": "SKU-001",
            "mapping_rule": "exact_internal_code",
            "confidence": 0.99,
            "status": ClaimStatus.ACCEPTED,
        }
        values.update(updates)
        return ExternalIdentityRecord(**values)

    assert EntityRoutingRuntime._is_trusted_stable_identity(identity())
    assert not EntityRoutingRuntime._is_trusted_stable_identity(
        identity(status=ClaimStatus.CANDIDATE)
    )
    assert not EntityRoutingRuntime._is_trusted_stable_identity(
        identity(
            source_system="m1:product_model",
            mapping_rule="exact_model_code",
        )
    )
    assert not EntityRoutingRuntime._is_trusted_stable_identity(
        identity(
            source_system="customer:unresolved:source-1",
            mapping_rule="exact_customer_code_scoped",
        )
    )


@pytest.mark.asyncio
async def test_candidate_or_model_identity_cannot_create_an_exact_link() -> None:
    target = CanonicalEntityRecord(
        tenant_id="tenant-a",
        entity_id="existing-product",
        entity_type="product",
        canonical_key="product:existing:sku-001",
        canonical_label="Existing product",
        lifecycle_status=LifecycleStatus.ACTIVE,
    )

    class _Store:
        def __init__(self, existing: ExternalIdentityRecord) -> None:
            self.existing = existing

        async def find_external_identity(self, *args, **kwargs):
            return self.existing

        async def get_entity(self, *args, **kwargs):
            return target

    entity = CanonicalEntityRecord(
        tenant_id="tenant-a",
        entity_id="proposed-product",
        entity_type="product",
        canonical_key="product:internal:sku-001",
        canonical_label="Proposed product",
        lifecycle_status=LifecycleStatus.UNDER_REVIEW,
    )
    candidate_identity = ExternalIdentityRecord(
        tenant_id="tenant-a",
        entity_id=entity.entity_id,
        entity_type="product",
        source_system="tenant:internal_product_code",
        external_id="SKU-001",
        mapping_rule="exact_internal_code",
        confidence=0.99,
        status=ClaimStatus.CANDIDATE,
    )
    accepted_existing = ExternalIdentityRecord(
        tenant_id="tenant-a",
        entity_id=target.entity_id,
        entity_type="product",
        source_system="tenant:internal_product_code",
        external_id="SKU-001",
        mapping_rule="exact_internal_code",
        confidence=0.99,
        status=ClaimStatus.ACCEPTED,
    )
    router = EntityRoutingRuntime(store=_Store(accepted_existing), embedding_provider=None)

    candidates, blocking = await router._exact_identity_candidates(
        tenant_id="tenant-a",
        entity=entity,
        identities=[candidate_identity],
    )

    assert candidates == []
    assert blocking is True

    trusted_identity = candidate_identity.model_copy(
        update={"status": ClaimStatus.ACCEPTED}
    )
    candidates, blocking = await router._exact_identity_candidates(
        tenant_id="tenant-a",
        entity=entity,
        identities=[trusted_identity],
    )

    assert [candidate.entity_id for candidate in candidates] == [target.entity_id]
    assert blocking is False

    model_identity = candidate_identity.model_copy(
        update={
            "source_system": "m1:product_model",
            "mapping_rule": "exact_model_code",
            "status": ClaimStatus.ACCEPTED,
        }
    )
    model_existing = accepted_existing.model_copy(
        update={
            "source_system": "m1:product_model",
            "mapping_rule": "exact_model_code",
        }
    )
    model_router = EntityRoutingRuntime(store=_Store(model_existing), embedding_provider=None)

    candidates, blocking = await model_router._exact_identity_candidates(
        tenant_id="tenant-a",
        entity=entity,
        identities=[model_identity],
    )

    assert candidates == []
    assert blocking is True
