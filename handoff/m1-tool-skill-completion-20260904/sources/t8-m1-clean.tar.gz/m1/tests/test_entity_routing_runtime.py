from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from m1.knowledge import (
    CanonicalEntityRecord,
    ClaimStatus,
    EntityAliasRecord,
    KnowledgeRuntime,
    KnowledgeStore,
    LifecycleStatus,
)
from m1.knowledge.canonicalization import CanonicalizationResult
from m1.knowledge.db_models import (
    CanonicalEntityRow,
    EntityRouteDecisionRow,
    EntitySourceBindingRow,
)
from m1.knowledge.entity_routing import (
    EntityRouteAction,
    EntityRouteDecision,
    EntityRoutePolicy,
)
from m1.knowledge.entity_routing_runtime import EntityRoutingRuntime
from m1.knowledge.schema import TaskFenceToken
from m1.knowledge.sinks import InMemoryGraphSink
from sqlalchemy import select


class _EmbeddingProvider:
    model = "entity-routing-test"
    dimensions = 1024

    async def embed_texts(self, texts):
        return [[1.0, *([0.0] * 1023)] for _text in texts]

    async def close(self) -> None:
        return None


class _Selector:
    async def select(self, request):
        return {
            "action": "link",
            "candidate_entity_id": request.candidates[0].entity_id,
            "confidence": 0.95,
            "reason_codes": ["same_enterprise_alias"],
        }


class _ReplaySelector(_Selector):
    def __init__(self) -> None:
        self.calls = 0

    async def select(self, request):
        self.calls += 1
        if self.calls > 1:
            raise AssertionError("persisted route decisions must be replayed before model use")
        return await super().select(request)


def _document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "identity-route.xlsx",
            "display_filename": "identity-route.xlsx",
            "sha256": "f" * 64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "size_bytes": 1024,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "Identity route order",
            "order_number": "ENTITY-ROUTE-1",
            "supplier": "Runtime Supplier",
        },
        "lines": [],
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            },
            "$.header.supplier": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B3"}],
            },
        },
        "needs_review": False,
    }


@pytest.mark.asyncio
async def test_entity_router_links_only_a_server_candidate_without_overwriting_it(
    tmp_path: Path,
) -> None:
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'runtime.db'}")
    provider = _EmbeddingProvider()
    router = EntityRoutingRuntime(
        store=store,
        embedding_provider=provider,
        selector=_Selector(),
        policy=EntityRoutePolicy(
            auto_min_score=0.90,
            min_margin=0.10,
            model_min_confidence=0.85,
        ),
        model_name="test-small-router",
    )
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
        entity_routing_runtime=router,
    )
    await service.init()
    try:
        existing = await store.put_entity(
            CanonicalEntityRecord(
                tenant_id="default",
                entity_type="enterprise",
                canonical_key="enterprise:external:runtime-supplier-001",
                canonical_label="Runtime Supplier",
                attributes={"authority": "existing"},
                lifecycle_status=LifecycleStatus.ACTIVE,
            )
        )
        await store.add_entity_alias(
            EntityAliasRecord(
                tenant_id="default",
                entity_id=existing.entity_id,
                alias="Runtime Supplier",
                normalized_alias="runtime supplier",
                source_system="manual",
                status=ClaimStatus.ACCEPTED,
            )
        )
        assert await router.index_entity(entity=existing)
        refresh = AsyncMock(wraps=router.refresh_entity_index)
        router.refresh_entity_index = refresh

        outcome = await service.sync_document(
            tenant_id="default",
            task_id="entity-route-task",
            document=_document(),
        )

        async with store.sessionmaker() as session:
            decisions = (
                await session.scalars(
                    select(EntityRouteDecisionRow).where(
                        EntityRouteDecisionRow.tenant_id == "default",
                        EntityRouteDecisionRow.source_version_id == outcome.document.version_id,
                    )
                )
            ).all()
            bindings = (
                await session.scalars(
                    select(EntitySourceBindingRow).where(
                        EntitySourceBindingRow.tenant_id == "default",
                        EntitySourceBindingRow.entity_id == existing.entity_id,
                        EntitySourceBindingRow.version_id == outcome.document.version_id,
                    )
                )
            ).all()
        assert decisions
        assert len(bindings) == 1
        assert bindings[0].status == "active"
        enterprises = await store.list_entities("default", entity_type="enterprise")
        assert [entity.entity_id for entity in enterprises if entity.canonical_label == "Runtime Supplier"] == [
            existing.entity_id
        ]
        retained = await store.get_entity("default", existing.entity_id)
        assert retained is not None
        assert retained.attributes["authority"] == "existing"
        supplier_decision = next(
            item for item in decisions if item.candidate_entity_id == existing.entity_id
        )
        assert supplier_decision.action == "link"
        assert supplier_decision.model_name == "test-small-router"
        assert any(
            call.kwargs == {
                "tenant_id": "default",
                "entity_id": existing.entity_id,
            }
            for call in refresh.await_args_list
        )
        async with store.sessionmaker() as session, session.begin():
            target_row = await session.get(CanonicalEntityRow, existing.entity_id)
            assert target_row is not None
            target_row.lifecycle_status = LifecycleStatus.DEPRECATED.value
        replay = await store.get_entity_route_decision(
            "default",
            source_version_id=outcome.document.version_id,
            proposed_entity_id=supplier_decision.proposed_entity_id,
            entity_type="enterprise",
        )
        assert replay is not None
        assert replay.action is EntityRouteAction.REVIEW
        assert replay.candidate_entity_id is None
        assert "link_target_not_routable" in replay.reason_codes
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_entity_router_does_not_call_model_without_candidates() -> None:
    class EmptyStore:
        async def get_entity_route_decision(self, *_args, **_kwargs):
            return None

        async def get_routable_entity_by_key(self, *_args, **_kwargs):
            return None

        async def find_external_identity(self, *_args, **_kwargs):
            return None

        async def find_entity_route_candidates(self, *_args, **_kwargs):
            return []

        async def record_entity_route_decision(self, *_args, **kwargs):
            self.decision = kwargs["decision"]

    class CountingSelector:
        calls = 0

        async def select(self, _request):
            self.calls += 1
            raise AssertionError("empty candidate sets must start a new candidate")

    entity = CanonicalEntityRecord(
        tenant_id="default",
        entity_id="proposed-enterprise",
        entity_type="enterprise",
        canonical_key="enterprise:name:brand-new",
        canonical_label="Brand New Enterprise",
        lifecycle_status=LifecycleStatus.ACTIVE,
    )
    alias = EntityAliasRecord(
        tenant_id="default",
        entity_id=entity.entity_id,
        alias="Brand New Enterprise",
        normalized_alias="brand new enterprise",
        source_system="m1:header_supplier",
        confidence=0.99,
        status=ClaimStatus.ACCEPTED,
    )
    canonical = CanonicalizationResult(
        tenant_id="default",
        source_record_id="doc-1",
        document_entity_id="doc-1",
        entities=[entity],
        aliases=[alias],
    )
    store = EmptyStore()
    selector = CountingSelector()
    router = EntityRoutingRuntime(
        store=store,
        embedding_provider=None,
        selector=selector,
    )

    result = await router.resolve(
        tenant_id="default",
        source_version_id="version-1",
        fence=TaskFenceToken(tenant_id="default", task_id="task-1", epoch=1),
        canonical=canonical,
    )

    assert selector.calls == 0
    assert result.decisions[entity.entity_id].action.value == "new_candidate"
    assert result.canonical.entities[0].lifecycle_status is LifecycleStatus.UNDER_REVIEW
    assert result.canonical.aliases[0].status is ClaimStatus.CANDIDATE


@pytest.mark.asyncio
async def test_entity_router_replays_persisted_link_without_a_second_model_call(
    tmp_path: Path,
) -> None:
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'replay.db'}")
    provider = _EmbeddingProvider()
    selector = _ReplaySelector()
    router = EntityRoutingRuntime(
        store=store,
        embedding_provider=provider,
        selector=selector,
        policy=EntityRoutePolicy(
            auto_min_score=0.90,
            min_margin=0.10,
            model_min_confidence=0.85,
        ),
        model_name="test-small-router",
    )
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
        entity_routing_runtime=router,
    )
    await service.init()
    try:
        existing = await store.put_entity(
            CanonicalEntityRecord(
                tenant_id="default",
                entity_type="enterprise",
                canonical_key="enterprise:external:replay-supplier",
                canonical_label="Runtime Supplier",
                lifecycle_status=LifecycleStatus.ACTIVE,
            )
        )
        await store.add_entity_alias(
            EntityAliasRecord(
                tenant_id="default",
                entity_id=existing.entity_id,
                alias="Runtime Supplier",
                normalized_alias="runtime supplier",
                source_system="manual",
                status=ClaimStatus.ACCEPTED,
            )
        )
        assert await router.index_entity(entity=existing)

        first = await service.sync_document(
            tenant_id="default",
            task_id="entity-route-replay",
            document=_document(),
        )
        second = await service.sync_document(
            tenant_id="default",
            task_id="entity-route-replay",
            document=_document(),
        )

        assert first.document.version_id == second.document.version_id
        assert selector.calls == 1
        enterprises = await store.list_entities("default", entity_type="enterprise")
        assert [item.entity_id for item in enterprises if item.canonical_label == "Runtime Supplier"] == [
            existing.entity_id
        ]
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_entity_router_invalidates_persisted_link_to_deprecated_target() -> None:
    proposed = CanonicalEntityRecord(
        tenant_id="default",
        entity_id="proposed-enterprise",
        entity_type="enterprise",
        canonical_key="enterprise:name:runtime-supplier",
        canonical_label="Runtime Supplier",
        lifecycle_status=LifecycleStatus.ACTIVE,
    )
    stale_target = CanonicalEntityRecord(
        tenant_id="default",
        entity_id="deprecated-enterprise",
        entity_type="enterprise",
        canonical_key="enterprise:external:deprecated",
        canonical_label="Deprecated Supplier",
        lifecycle_status=LifecycleStatus.DEPRECATED,
    )

    class ReplayStore:
        async def get_entity_route_decision(self, *_args, **_kwargs):
            return EntityRouteDecision(
                action=EntityRouteAction.LINK,
                candidate_entity_id=stale_target.entity_id,
                candidate_score=0.99,
                top1_top2_margin=0.50,
                reason_codes=("persisted_link",),
            )

        async def get_entity(self, tenant_id, entity_id):
            assert tenant_id == "default"
            assert entity_id == stale_target.entity_id
            return stale_target

    router = EntityRoutingRuntime(
        store=ReplayStore(),
        embedding_provider=None,
        selector=None,
    )
    canonical = CanonicalizationResult(
        tenant_id="default",
        source_record_id="doc-stale-link",
        document_entity_id="doc-stale-link",
        entities=[proposed],
    )

    routed = await router.resolve(
        tenant_id="default",
        source_version_id="version-stale-link",
        fence=TaskFenceToken(
            tenant_id="default",
            task_id="task-stale-link",
            epoch=1,
        ),
        canonical=canonical,
    )

    decision = routed.decisions[proposed.entity_id]
    assert decision.action is EntityRouteAction.REVIEW
    assert decision.candidate_entity_id is None
    assert "link_target_not_routable" in decision.reason_codes
    assert routed.linked_entity_ids == {}
    assert routed.canonical.entities[0].entity_id == proposed.entity_id
    assert (
        routed.canonical.entities[0].lifecycle_status
        is LifecycleStatus.UNDER_REVIEW
    )
