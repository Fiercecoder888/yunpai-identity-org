"""Runtime contract for field-semantic and unresolved-visual routing."""

from pathlib import Path

import pytest
import yaml
from m1.core.config import Settings
from pydantic import ValidationError

_REPOSITORY = Path(__file__).resolve().parents[2]
_ROUTER_SUFFIXES = {
    "FIELD_SEMANTIC_ROUTER": {
        "ENABLED",
        "REQUIRED",
        "MODE",
        "BASE_URL",
        "API_KEY",
        "MODEL",
        "TIMEOUT_SECONDS",
        "MAX_FIELDS_PER_DOCUMENT",
    },
    "VISUAL_REGION_ROUTER": {
        "ENABLED",
        "REQUIRED",
        "MODE",
        "BASE_URL",
        "API_KEY",
        "MODEL",
        "TIMEOUT_SECONDS",
        "MAX_REGIONS_PER_DOCUMENT",
    },
    "REGION_CAPABILITY_ROUTER": {
        "ENABLED",
        "REQUIRED",
        "BASE_URL",
        "API_KEY",
        "MODEL",
        "TIMEOUT_SECONDS",
        "CIRCUIT_FAILURES",
        "CIRCUIT_SECONDS",
    },
    "CONTENT_REGION_ROUTER": {
        "ENABLED",
        "REQUIRED",
        "BASE_URL",
        "API_KEY",
        "MODEL",
        "TIMEOUT_SECONDS",
        "CIRCUIT_FAILURES",
        "CIRCUIT_SECONDS",
    },
}
_VARIABLES = {
    f"{prefix}_{suffix}"
    for prefix, suffixes in _ROUTER_SUFFIXES.items()
    for suffix in suffixes
}


def _settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "field_semantic_router_enabled": False,
        "field_semantic_router_required": False,
        "field_semantic_router_base_url": "",
        "field_semantic_router_api_key": "",
        "field_semantic_router_model": "",
        "visual_region_router_enabled": False,
        "visual_region_router_required": False,
        "visual_region_router_base_url": "",
        "visual_region_router_api_key": "",
        "visual_region_router_model": "",
        "region_capability_router_enabled": False,
        "region_capability_router_required": False,
        "region_capability_router_base_url": "",
        "region_capability_router_api_key": "",
        "region_capability_router_model": "",
        "content_region_router_enabled": False,
        "content_region_router_required": False,
        "content_region_router_base_url": "",
        "content_region_router_api_key": "",
        "content_region_router_model": "",
    }
    values.update(overrides)
    return Settings(**values)


def _compose_environment(relative_path: str) -> dict[str, str]:
    payload = yaml.safe_load((_REPOSITORY / relative_path).read_text(encoding="utf-8"))
    values = payload["services"]["m1"]["environment"]
    return (
        values
        if isinstance(values, dict)
        else dict(value.split("=", 1) for value in values)
    )


def test_extension_routers_default_to_fail_safe_shadow_mode() -> None:
    settings = _settings()

    assert settings.field_semantic_router_enabled is False
    assert settings.field_semantic_router_required is False
    assert settings.field_semantic_router_mode == "shadow"
    assert settings.field_semantic_router_max_fields_per_document == 128
    assert settings.visual_region_router_enabled is False
    assert settings.visual_region_router_required is False
    assert settings.visual_region_router_mode == "shadow"
    assert settings.visual_region_router_max_regions_per_document == 32
    assert settings.region_capability_router_enabled is False
    assert settings.region_capability_router_required is False
    assert settings.region_capability_router_circuit_failures == 3
    assert settings.content_region_router_enabled is False
    assert settings.content_region_router_required is False
    assert settings.content_region_router_circuit_failures == 3


@pytest.mark.parametrize(
    "prefix",
    (
        "field_semantic_router",
        "visual_region_router",
        "region_capability_router",
        "content_region_router",
    ),
)
def test_required_extension_router_must_be_enabled(prefix: str) -> None:
    with pytest.raises(ValidationError, match="REQUIRED requires .*_ENABLED"):
        _settings(**{f"{prefix}_required": True})


@pytest.mark.parametrize(
    "prefix",
    (
        "field_semantic_router",
        "visual_region_router",
        "region_capability_router",
        "content_region_router",
    ),
)
@pytest.mark.parametrize("missing", ("base_url", "api_key", "model"))
def test_enabled_extension_router_requires_isolated_model_tuple(
    prefix: str,
    missing: str,
) -> None:
    values: dict[str, object] = {
        f"{prefix}_enabled": True,
        f"{prefix}_base_url": "http://router.invalid/v1",
        f"{prefix}_api_key": "test-only-secret",
        f"{prefix}_model": "small-router",
    }
    values[f"{prefix}_{missing}"] = ""

    with pytest.raises(
        ValidationError, match=f"{prefix.upper()}_{missing.upper()}"
    ) as error:
        _settings(**values)
    assert "test-only-secret" not in str(error.value)


@pytest.mark.parametrize(
    "prefix",
    (
        "field_semantic_router",
        "visual_region_router",
        "region_capability_router",
        "content_region_router",
    ),
)
def test_extension_router_secret_is_not_in_settings_repr(prefix: str) -> None:
    settings = _settings(
        **{
            f"{prefix}_enabled": True,
            f"{prefix}_base_url": "http://router.invalid/v1",
            f"{prefix}_api_key": "test-only-secret",
            f"{prefix}_model": "small-router",
        }
    )

    assert "test-only-secret" not in repr(settings)


def test_extension_router_runtime_and_dev_contracts_are_complete() -> None:
    runtime = _compose_environment("m1/deploy/compose.runtime.yml")
    development = _compose_environment("m1/deploy/compose.dev.yml")

    assert _VARIABLES <= set(runtime)
    assert _VARIABLES <= set(development)
    for prefix in _ROUTER_SUFFIXES:
        assert runtime[f"{prefix}_ENABLED"].endswith(":-false}")
        assert runtime[f"{prefix}_REQUIRED"].endswith(":-false}")
        assert runtime[f"{prefix}_API_KEY"] == f"${{M1_{prefix}_API_KEY:-}}"
        assert development[f"{prefix}_ENABLED"].endswith(":-false}")
        assert development[f"{prefix}_API_KEY"] == f"${{{prefix}_API_KEY:-}}"


def test_extension_router_safe_examples_document_every_variable() -> None:
    module_lines = set(
        (_REPOSITORY / "m1/.env.example").read_text(encoding="utf-8").splitlines()
    )
    runtime_lines = set(
        (_REPOSITORY / "deploy/source-runtime/deploy.env.example")
        .read_text(encoding="utf-8")
        .splitlines()
    )
    for name in _VARIABLES:
        assert any(line.startswith(f"{name}=") for line in module_lines)
        assert any(line.startswith(f"M1_{name}=") for line in module_lines)
        assert any(line.startswith(f"M1_{name}=") for line in runtime_lines)
