from __future__ import annotations

from types import SimpleNamespace
from typing import ClassVar

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from m1.api import health_routes, main
from m1.api.adaptive_route_runtime import AdaptiveRouteRuntimeManager
from m1.api.health_routes import register_health_routes
from m1.documents.parsing.content_region_contracts import (
    CONTENT_REGION_EMBEDDING_SPACE,
)

from m1 import structured_llm


class _EmbeddingProvider:
    model = "embedding-model"
    dimensions = 3

    async def embed_texts(self, _texts):
        return [[0.1, 0.2, 0.3]]


class _StructuredClient:
    instances: ClassVar[list[_StructuredClient]] = []
    probe_error: ClassVar[Exception | None] = None

    def __init__(self, **kwargs) -> None:
        self.kwargs = kwargs
        self.closed = False
        self.__class__.instances.append(self)

    async def probe(self) -> dict[str, object]:
        if self.probe_error is not None:
            raise self.probe_error
        return {"ready": True, "model": self.kwargs["model"]}

    async def close(self) -> None:
        self.closed = True

    async def run(self, *_args, **_kwargs):  # pragma: no cover - adapter contract only
        raise AssertionError("lifecycle tests must not run inference")


def test_manager_snapshot_merges_runtime_health_without_losing_startup_contract() -> (
    None
):
    manager = AdaptiveRouteRuntimeManager()
    manager.region_status.update(
        enabled=True,
        required=True,
        ready=True,
        consumers=["document_parser"],
    )
    manager.region_runtime = SimpleNamespace(
        status_snapshot=lambda: {
            "ready": False,
            "degraded": True,
            "circuit_open": True,
            "last_error_type": "TimeoutError",
        }
    )

    snapshot = manager.snapshot("region")

    assert snapshot["enabled"] is True
    assert snapshot["required"] is True
    assert snapshot["consumers"] == ["document_parser"]
    assert snapshot["ready"] is False
    assert snapshot["circuit_open"] is True


@pytest.mark.asyncio
async def test_adaptive_router_startup_failure_unwinds_in_reverse_order(
    monkeypatch,
) -> None:
    events: list[str] = []

    async def init(name: str) -> None:
        events.append(f"init:{name}")
        if name == "region":
            raise TimeoutError()

    async def close(name: str) -> None:
        events.append(f"close:{name}")

    monkeypatch.setattr(
        main, "_init_field_semantic_routing", lambda _settings: init("field")
    )
    monkeypatch.setattr(
        main, "_init_visual_region_routing", lambda _settings: init("visual")
    )
    monkeypatch.setattr(
        main, "_init_region_capability_routing", lambda _settings: init("region")
    )
    monkeypatch.setattr(
        main, "_init_content_region_routing", lambda _settings: init("content")
    )
    monkeypatch.setattr(
        main, "_close_field_semantic_routing_runtime", lambda: close("field")
    )
    monkeypatch.setattr(
        main, "_close_visual_region_routing_runtime", lambda: close("visual")
    )
    monkeypatch.setattr(
        main, "_close_region_capability_routing_runtime", lambda: close("region")
    )
    monkeypatch.setattr(
        main, "_close_content_region_routing_runtime", lambda: close("content")
    )

    with pytest.raises(TimeoutError):
        await main._init_adaptive_route_runtimes(SimpleNamespace())

    assert events == [
        "init:field",
        "init:visual",
        "init:region",
        "close:content",
        "close:region",
        "close:visual",
        "close:field",
    ]


def _field_settings(*, required: bool = False) -> SimpleNamespace:
    return SimpleNamespace(
        field_semantic_router_enabled=True,
        field_semantic_router_required=required,
        field_semantic_router_mode="guarded",
        field_semantic_router_timeout_seconds=17.0,
        field_semantic_router_max_fields_per_document=23,
        resolved_field_semantic_router_base_url="http://field-router/v1",
        resolved_field_semantic_router_api_key="field-secret",
        resolved_field_semantic_router_model="field-model",
    )


def _visual_settings(*, required: bool = False) -> SimpleNamespace:
    return SimpleNamespace(
        visual_region_router_enabled=True,
        visual_region_router_required=required,
        visual_region_router_mode="shadow",
        visual_region_router_timeout_seconds=19.0,
        visual_region_router_max_regions_per_document=11,
        resolved_visual_region_router_base_url="http://visual-router/v1",
        resolved_visual_region_router_api_key="visual-secret",
        resolved_visual_region_router_model="visual-model",
    )


def _region_settings(*, required: bool = False) -> SimpleNamespace:
    return SimpleNamespace(
        region_capability_router_enabled=True,
        region_capability_router_required=required,
        region_capability_router_timeout_seconds=13.0,
        region_capability_router_circuit_failures=4,
        region_capability_router_circuit_seconds=90.0,
        resolved_region_capability_router_base_url="http://region-router/v1",
        resolved_region_capability_router_api_key="region-secret",
        resolved_region_capability_router_model="region-model",
        pp_structure_enabled=True,
        paddleocr_vl_enabled=True,
    )


def _content_settings(*, required: bool = False) -> SimpleNamespace:
    return SimpleNamespace(
        content_region_router_enabled=True,
        content_region_router_required=required,
        content_region_router_timeout_seconds=15.0,
        content_region_router_circuit_failures=5,
        content_region_router_circuit_seconds=120.0,
        resolved_content_region_router_base_url="http://content-router/v1",
        resolved_content_region_router_api_key="content-secret",
        resolved_content_region_router_model="content-model",
    )


@pytest.fixture(autouse=True)
def _reset_router_globals(monkeypatch):
    _StructuredClient.instances.clear()
    _StructuredClient.probe_error = None
    monkeypatch.setattr(structured_llm, "StructuredModelClient", _StructuredClient)
    monkeypatch.setattr(
        main,
        "knowledge_runtime",
        SimpleNamespace(store=object(), embedding_provider=_EmbeddingProvider()),
    )
    monkeypatch.setattr(main, "field_semantic_routing_runtime", None)
    monkeypatch.setattr(main, "field_semantic_routing_client", None)
    monkeypatch.setattr(
        main,
        "field_semantic_routing_status",
        {
            "enabled": False,
            "mode": "shadow",
            "ready": True,
            "degraded": False,
            "error_type": None,
        },
    )
    monkeypatch.setattr(main, "visual_region_routing_runtime", None)
    monkeypatch.setattr(main, "visual_region_routing_client", None)
    monkeypatch.setattr(
        main,
        "visual_region_routing_status",
        {
            "enabled": False,
            "mode": "shadow",
            "ready": True,
            "degraded": False,
            "error_type": None,
        },
    )
    monkeypatch.setattr(main, "region_capability_routing_runtime", None)
    monkeypatch.setattr(main, "region_capability_routing_client", None)
    monkeypatch.setattr(
        main,
        "region_capability_routing_status",
        {
            "enabled": False,
            "ready": True,
            "degraded": False,
            "error_type": None,
        },
    )
    monkeypatch.setattr(main, "content_region_routing_runtime", None)
    monkeypatch.setattr(main, "content_region_routing_client", None)
    monkeypatch.setattr(
        main,
        "content_region_routing_status",
        {
            "enabled": False,
            "ready": True,
            "degraded": False,
            "error_type": None,
        },
    )


@pytest.mark.asyncio
async def test_field_router_uses_dedicated_contract_and_wires_consumers() -> None:
    settings = _field_settings()

    await main._init_field_semantic_routing(settings)

    runtime = main.field_semantic_routing_runtime
    client = _StructuredClient.instances[-1]
    assert runtime is not None
    assert runtime.mode == "guarded"
    assert runtime.max_fields_per_document == 23
    assert client.kwargs["base_url"] == "http://field-router/v1"
    assert client.kwargs["api_key"] == "field-secret"
    assert client.kwargs["model"] == "field-model"
    assert client.kwargs["timeout"] == 17.0

    instructor = SimpleNamespace()
    runner = SimpleNamespace(instructor_service=instructor)
    consumers = main._wire_field_semantic_consumers(
        mineru_shadow_runner=runner,
    )
    main._record_field_semantic_consumers(settings, consumers)

    assert consumers == (
        "workflow_postbuild",
        "mineru_instructor",
    )
    assert instructor.field_semantic_router is runtime
    assert main.field_semantic_routing_status["consumers"] == [
        "workflow_postbuild",
        "mineru_instructor",
    ]

    await main._close_field_semantic_routing_runtime()
    assert client.closed is True
    assert main.field_semantic_routing_runtime is None


@pytest.mark.asyncio
async def test_field_only_configuration_registers_postbuild_and_stays_ready() -> None:
    settings = _field_settings(required=True)
    await main._init_field_semantic_routing(settings)

    consumers = main._wire_field_semantic_consumers(
        mineru_shadow_runner=None,
    )
    main._record_field_semantic_consumers(settings, consumers)

    assert consumers == ("workflow_postbuild",)
    assert main.field_semantic_routing_status["consumers"] == ["workflow_postbuild"]
    assert main.field_semantic_routing_status["ready"] is True
    assert main.field_semantic_routing_status["degraded"] is False

    await main._close_field_semantic_routing_runtime()


@pytest.mark.asyncio
async def test_required_field_router_probe_failure_closes_client() -> None:
    _StructuredClient.probe_error = TimeoutError()

    with pytest.raises(TimeoutError):
        await main._init_field_semantic_routing(_field_settings(required=True))

    assert _StructuredClient.instances[-1].closed is True
    assert main.field_semantic_routing_runtime is None
    assert main.field_semantic_routing_status["ready"] is False
    assert main.field_semantic_routing_status["error_type"] == "TimeoutError"


@pytest.mark.asyncio
async def test_optional_field_router_probe_failure_does_not_leave_runtime() -> None:
    _StructuredClient.probe_error = ConnectionError()

    await main._init_field_semantic_routing(_field_settings(required=False))

    assert _StructuredClient.instances[-1].closed is True
    assert main.field_semantic_routing_client is None
    assert main.field_semantic_routing_runtime is None
    assert main.field_semantic_routing_status["degraded"] is True
    assert main.field_semantic_routing_status["error_type"] == "ConnectionError"


@pytest.mark.asyncio
async def test_required_field_router_without_consumers_fails_closed() -> None:
    settings = _field_settings(required=True)
    await main._init_field_semantic_routing(settings)

    with pytest.raises(RuntimeError, match="no active consumers"):
        main._record_field_semantic_consumers(settings, ())

    assert main.field_semantic_routing_status["ready"] is False
    assert main.field_semantic_routing_status["error_type"] == "NoConsumers"
    await main._close_field_semantic_routing_runtime()


@pytest.mark.asyncio
async def test_visual_router_uses_dedicated_contract_and_closes_client() -> None:
    await main._init_visual_region_routing(_visual_settings())

    runtime = main.visual_region_routing_runtime
    client = _StructuredClient.instances[-1]
    assert runtime is not None
    assert runtime.mode == "shadow"
    assert runtime.max_regions_per_document == 11
    assert client.kwargs["base_url"] == "http://visual-router/v1"
    assert client.kwargs["api_key"] == "visual-secret"
    assert client.kwargs["model"] == "visual-model"
    assert client.kwargs["timeout"] == 19.0

    await main._close_visual_region_routing_runtime()
    assert client.closed is True
    assert main.visual_region_routing_runtime is None


@pytest.mark.asyncio
async def test_optional_visual_router_probe_failure_does_not_leave_runtime() -> None:
    _StructuredClient.probe_error = TimeoutError()

    await main._init_visual_region_routing(_visual_settings(required=False))

    assert _StructuredClient.instances[-1].closed is True
    assert main.visual_region_routing_client is None
    assert main.visual_region_routing_runtime is None
    assert main.visual_region_routing_status["degraded"] is True
    assert main.visual_region_routing_status["error_type"] == "TimeoutError"


@pytest.mark.asyncio
async def test_region_capability_router_uses_dedicated_contract_and_wires_parser() -> (
    None
):
    settings = _region_settings(required=True)

    await main._init_region_capability_routing(settings)

    runtime = main.region_capability_routing_runtime
    client = _StructuredClient.instances[-1]
    assert runtime is not None
    assert runtime.required is True
    assert [item.value for item in runtime.available_capabilities] == ["paddleocr_vl"]
    assert client.kwargs["base_url"] == "http://region-router/v1"
    assert client.kwargs["api_key"] == "region-secret"
    assert client.kwargs["model"] == "region-model"
    assert client.kwargs["timeout"] == 13.0

    parser = SimpleNamespace(page_capability_router=None)
    consumers = main._wire_region_capability_consumer(parser)
    main._record_region_capability_consumers(settings, consumers)
    assert parser.page_capability_router is runtime
    assert consumers == ("document_parser",)

    await main._close_region_capability_routing_runtime()
    assert client.closed is True
    assert main.region_capability_routing_runtime is None


@pytest.mark.asyncio
async def test_required_region_capability_probe_failure_closes_client() -> None:
    _StructuredClient.probe_error = TimeoutError()

    with pytest.raises(TimeoutError):
        await main._init_region_capability_routing(_region_settings(required=True))

    assert _StructuredClient.instances[-1].closed is True
    assert main.region_capability_routing_runtime is None
    assert main.region_capability_routing_status["ready"] is False


@pytest.mark.asyncio
async def test_content_region_router_uses_dedicated_contract_and_closes_client() -> (
    None
):
    settings = _content_settings(required=True)

    await main._init_content_region_routing(settings)

    runtime = main.content_region_routing_runtime
    client = _StructuredClient.instances[-1]
    assert runtime is not None
    assert runtime.required is True
    assert runtime.embedding_provider.space == CONTENT_REGION_EMBEDDING_SPACE
    assert client.kwargs["base_url"] == "http://content-router/v1"
    assert client.kwargs["api_key"] == "content-secret"
    assert client.kwargs["model"] == "content-model"
    assert client.kwargs["timeout"] == 15.0

    main._record_content_region_consumers(settings, ("workflow_postbuild",))
    assert main.content_region_routing_status["consumers"] == ["workflow_postbuild"]

    await main._close_content_region_routing_runtime()
    assert client.closed is True
    assert main.content_region_routing_runtime is None


@pytest.mark.asyncio
async def test_required_content_region_probe_failure_closes_client() -> None:
    _StructuredClient.probe_error = ConnectionError()

    with pytest.raises(ConnectionError):
        await main._init_content_region_routing(_content_settings(required=True))

    assert _StructuredClient.instances[-1].closed is True
    assert main.content_region_routing_runtime is None
    assert main.content_region_routing_status["error_type"] == "ConnectionError"


def _health_runtime(
    *,
    field_status: dict[str, object],
    region_status: dict[str, object] | None = None,
    content_status: dict[str, object] | None = None,
    tabular_status: dict[str, object] | None = None,
) -> SimpleNamespace:
    mineru = SimpleNamespace(
        authority_mode="full",
        status=lambda: {
            "ready": True,
            "degraded": False,
            "candidate_pipeline": "mineru_instructor",
        },
    )
    tabular_runtime = (
        SimpleNamespace(status_snapshot=lambda: dict(tabular_status))
        if tabular_status is not None
        else None
    )
    return SimpleNamespace(
        engine=SimpleNamespace(
            deps=SimpleNamespace(
                document_parser=None,
                mineru_shadow_runner=mineru,
            )
        ),
        knowledge_runtime=None,
        knowledge_init_error="",
        document_routing_runtime=None,
        entity_routing_runtime=None,
        tabular_layout_routing_runtime=tabular_runtime,
        field_semantic_routing_runtime=None,
        visual_region_routing_runtime=None,
        region_capability_routing_runtime=None,
        content_region_routing_runtime=None,
        _field_semantic_routing_status_snapshot=lambda: dict(field_status),
        _tabular_layout_routing_status_snapshot=lambda: dict(tabular_status or {}),
        _region_capability_routing_status_snapshot=lambda: dict(region_status or {}),
        _content_region_routing_status_snapshot=lambda: dict(content_status or {}),
        _outbox_worker_status={"enabled": False, "running": False},
    )


def test_required_field_router_failure_is_exposed_and_fails_ready(monkeypatch) -> None:
    overrides = {
        "document_parser_mode": "legacy",
        "document_router_enabled": False,
        "document_router_required": False,
        "entity_router_enabled": False,
        "entity_router_required": False,
        "tabular_layout_router_enabled": False,
        "tabular_layout_router_required": False,
        "field_semantic_router_enabled": True,
        "field_semantic_router_required": True,
        "field_semantic_router_mode": "guarded",
        "visual_region_router_enabled": False,
        "visual_region_router_required": False,
        "region_capability_router_enabled": False,
        "region_capability_router_required": False,
        "content_region_router_enabled": False,
        "content_region_router_required": False,
        "mineru_shadow_enabled": True,
        "mineru_shadow_required": True,
        "knowledge_enabled": False,
        "knowledge_required": False,
        "knowledge_outbox_worker_enabled": False,
        "lightrag_shadow_enabled": False,
    }
    for name, value in overrides.items():
        monkeypatch.setattr(health_routes.settings, name, value)
    runtime = _health_runtime(
        field_status={
            "enabled": True,
            "mode": "guarded",
            "ready": False,
            "degraded": True,
            "error_type": "TimeoutError",
        }
    )
    app = FastAPI()
    register_health_routes(app, runtime)

    response = TestClient(app).get("/ready")

    assert response.status_code == 503
    payload = response.json()
    assert payload["field_semantic_router"]["error_type"] == "TimeoutError"
    assert payload["field_semantic_router"]["ready"] is False
    assert payload["visual_region_router"]["ready"] is True
    assert "field_semantic_router_degraded" in payload["degraded_reasons"]


@pytest.mark.parametrize(("required", "status_code"), [(False, 200), (True, 503)])
def test_tabular_layout_router_runtime_failure_uses_required_readiness_semantics(
    monkeypatch,
    required: bool,
    status_code: int,
) -> None:
    overrides = {
        "document_parser_mode": "legacy",
        "document_router_enabled": False,
        "document_router_required": False,
        "entity_router_enabled": False,
        "entity_router_required": False,
        "tabular_layout_router_enabled": True,
        "tabular_layout_router_required": required,
        "field_semantic_router_enabled": False,
        "field_semantic_router_required": False,
        "visual_region_router_enabled": False,
        "visual_region_router_required": False,
        "region_capability_router_enabled": False,
        "region_capability_router_required": False,
        "content_region_router_enabled": False,
        "content_region_router_required": False,
        "mineru_shadow_enabled": True,
        "mineru_shadow_required": True,
        "knowledge_enabled": False,
        "knowledge_required": False,
        "knowledge_outbox_worker_enabled": False,
        "lightrag_shadow_enabled": False,
    }
    for name, value in overrides.items():
        monkeypatch.setattr(health_routes.settings, name, value)
    runtime = _health_runtime(
        field_status={},
        tabular_status={
            "enabled": True,
            "required": required,
            "ready": False,
            "degraded": True,
            "circuit_open": True,
            "last_error_type": "TimeoutError",
        },
    )
    app = FastAPI()
    register_health_routes(app, runtime)

    response = TestClient(app).get("/ready")

    assert response.status_code == status_code
    payload = response.json()
    assert payload["tabular_layout_router"]["ready"] is False
    assert payload["tabular_layout_router"]["required"] is required
    assert payload["tabular_layout_router"]["circuit_open"] is True
    assert "tabular_layout_router_degraded" in payload["degraded_reasons"]
    assert payload["status"] == ("not_ready" if required else "degraded")
