from __future__ import annotations

import hashlib
import json
from types import SimpleNamespace

import m1.extension_routes as routes
import pytest
from m1.knowledge.field_semantic_schema import FieldSemanticProfileStatus
from m1.state import TaskStatus


def _profile(
    *, status: FieldSemanticProfileStatus = FieldSemanticProfileStatus.CANDIDATE
):
    return SimpleNamespace(
        profile_id="candidate-field-order-id",
        tenant_id="tenant-a",
        profile_key="field-semantic:order-id",
        version=1,
        status=status,
        exact_fingerprint="a" * 64,
        canonical_field_id="header.order_number",
        signature=SimpleNamespace(contract_revision="m1.field-semantic.v1"),
        observation_count=3,
        success_count=3,
        failure_count=0,
        approved_by=None,
        approved_at=None,
        last_success_at=None,
        last_failure_at=None,
    )


def _document(*, profile_id: str = "candidate-field-order-id") -> dict:
    return {
        "schema_version": "m1.document.v2",
        "extraction": {
            "metadata": {
                "field_semantic_routing": {
                    "status": "completed",
                    "decisions": [
                        {
                            "action": "preserved",
                            "reason": "model_proposed_canonical_field",
                            "candidate_profile_id": profile_id,
                        }
                    ],
                }
            }
        },
    }


def _state(**updates):
    values = {
        "tenant_id": "tenant-a",
        "status": TaskStatus.DONE,
        "knowledge_sync_status": "synced",
        "knowledge_version_id": "knowledge-version-1",
        "document": _document(),
    }
    values.update(updates)
    return SimpleNamespace(**values)


class _RouteStore:
    def __init__(self, profile=None) -> None:
        self.profile = profile or _profile()
        self.observations = []
        self.activation = None
        self.state_changes: list[tuple[str, str, str]] = []
        self.closed = False

    async def init(self) -> None:
        return None

    async def close(self) -> None:
        self.closed = True

    async def get_field_semantic_profile(self, tenant_id: str, profile_id: str):
        if (
            tenant_id == self.profile.tenant_id
            and profile_id == self.profile.profile_id
        ):
            return self.profile
        return None

    async def list_field_semantic_profiles(self, tenant_id: str, **kwargs):
        del kwargs
        return [self.profile] if tenant_id == self.profile.tenant_id else []

    async def record_field_semantic_execution_observation(self, observation):
        self.observations.append(observation)
        return SimpleNamespace(observation_id=f"observation-{len(self.observations)}")

    async def activate_field_semantic_profile(
        self, tenant_id: str, profile_id: str, **kwargs
    ):
        self.activation = (tenant_id, profile_id, kwargs)
        self.profile.status = FieldSemanticProfileStatus.ACTIVE
        self.profile.approved_by = kwargs["approved_by"]
        return self.profile

    async def reject_field_semantic_profile(
        self, tenant_id: str, profile_id: str, **kwargs
    ):
        self.state_changes.append(("reject", tenant_id, profile_id))
        self.profile.status = FieldSemanticProfileStatus.REJECTED
        return self.profile

    async def deprecate_field_semantic_profile(
        self, tenant_id: str, profile_id: str, **kwargs
    ):
        self.state_changes.append(("deprecate", tenant_id, profile_id))
        self.profile.status = FieldSemanticProfileStatus.DEPRECATED
        return self.profile


class _TaskStore:
    def __init__(self, state) -> None:
        self.state = state
        self.loaded_task_id = None
        self.closed = False

    async def load(self, task_id: str):
        self.loaded_task_id = task_id
        return self.state

    async def close(self) -> None:
        self.closed = True


def _install_stores(monkeypatch, *, route_store: _RouteStore, task_store: _TaskStore):
    monkeypatch.setattr(routes, "KnowledgeStore", lambda _url: route_store)
    monkeypatch.setattr(routes, "TaskStore", lambda _url: task_store)


@pytest.mark.asyncio
async def test_validate_success_requires_final_candidate_audit_and_hashes_task_id(
    monkeypatch,
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(_state())
    _install_stores(monkeypatch, route_store=route_store, task_store=task_store)
    raw_task_id = "task-sensitive-1001"
    args = routes._parser().parse_args(
        [
            "validate",
            "success",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-field-order-id",
            "--task-id",
            raw_task_id,
            "--reviewed-by",
            "reviewer-1",
            "--review-note",
            "verified against final document",
        ]
    )

    result = await routes._run(args)

    assert task_store.loaded_task_id == raw_task_id
    assert len(route_store.observations) == 1
    observation = route_store.observations[0]
    assert observation.outcome == "success"
    assert observation.validation_passed is True
    assert (
        observation.task_reference_hash
        == hashlib.sha256(f"tenant-a\0{raw_task_id}".encode()).hexdigest()
    )
    assert raw_task_id not in json.dumps(
        observation.model_dump(mode="json"), ensure_ascii=False
    )
    assert raw_task_id not in json.dumps(result, ensure_ascii=False)
    assert result["knowledge_version_id"] == "knowledge-version-1"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("state", "message"),
    [
        (_state(tenant_id="tenant-b"), "another tenant"),
        (_state(status=TaskStatus.CREATED), "completed task"),
        (_state(knowledge_sync_status="pending"), "synced knowledge version"),
        (_state(knowledge_version_id=""), "synced knowledge version"),
        (
            _state(document=_document(profile_id="another-candidate")),
            "does not reference",
        ),
    ],
)
async def test_validate_fails_closed_without_task_and_audit_gates(
    monkeypatch,
    state,
    message: str,
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(state)
    _install_stores(monkeypatch, route_store=route_store, task_store=task_store)
    args = routes._parser().parse_args(
        [
            "validate",
            "success",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-field-order-id",
            "--task-id",
            "task-1",
            "--reviewed-by",
            "reviewer-1",
            "--review-note",
            "reviewed",
        ]
    )

    with pytest.raises((TypeError, ValueError), match=message):
        await routes._run(args)
    assert route_store.observations == []


@pytest.mark.asyncio
async def test_validate_failure_can_disable_an_active_profile(monkeypatch) -> None:
    route_store = _RouteStore(_profile(status=FieldSemanticProfileStatus.ACTIVE))
    task_store = _TaskStore(_state())
    _install_stores(monkeypatch, route_store=route_store, task_store=task_store)
    args = routes._parser().parse_args(
        [
            "validate",
            "failure",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-field-order-id",
            "--task-id",
            "task-failed-active",
            "--reviewed-by",
            "reviewer-2",
            "--review-note",
            "mapping was incorrect",
            "--error-code",
            "wrong_mapping",
        ]
    )

    await routes._run(args)

    observation = route_store.observations[0]
    assert observation.outcome == "failure"
    assert observation.validation_passed is False
    assert observation.error_code == "wrong_mapping"


@pytest.mark.asyncio
async def test_approve_uses_repository_counts_and_code_owned_registry(
    monkeypatch,
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(_state())
    _install_stores(monkeypatch, route_store=route_store, task_store=task_store)
    args = routes._parser().parse_args(
        [
            "approve",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-field-order-id",
            "--approved-by",
            "approver-1",
            "--reviewed-by",
            "reviewer-1",
            "--review-note",
            "three samples passed",
        ]
    )

    result = await routes._run(args)

    assert route_store.activation is not None
    kwargs = route_store.activation[2]
    assert kwargs["expected_observation_count"] == 3
    assert "header.order_number" in kwargs["allowed_canonical_field_ids"]
    assert result["profile"]["status"] == "active"


@pytest.mark.asyncio
@pytest.mark.parametrize("command", ["reject", "deprecate"])
async def test_review_state_commands_use_repository_methods(
    monkeypatch, command
) -> None:
    route_store = _RouteStore()
    task_store = _TaskStore(_state())
    _install_stores(monkeypatch, route_store=route_store, task_store=task_store)
    args = routes._parser().parse_args(
        [
            command,
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "candidate-field-order-id",
            "--reviewed-by",
            "reviewer-1",
            "--review-note",
            "operator decision",
        ]
    )

    result = await routes._run(args)

    assert route_store.state_changes == [
        (command, "tenant-a", "candidate-field-order-id")
    ]
    assert result["operation"] == command
