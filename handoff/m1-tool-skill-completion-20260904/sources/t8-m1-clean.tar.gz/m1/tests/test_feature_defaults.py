from __future__ import annotations

import pytest
from m1.api.main import create_app
from m1.core.config import Settings
from m1.state import TaskState


def test_full_authority_removes_legacy_runtime_switches() -> None:
    assert "ocr_enabled" not in Settings.model_fields
    assert "semantic_enrichment_default" not in Settings.model_fields
    assert "document_verifier_enabled" not in Settings.model_fields
    assert "tabular_schema_interpreter_enabled" not in Settings.model_fields
    assert Settings().mineru_authority_mode == "full"
    assert Settings.model_fields["knowledge_outbox_worker_enabled"].default is True
    assert Settings.model_fields["knowledge_outbox_interval_seconds"].default == 5.0
    assert Settings.model_fields["knowledge_outbox_batch_size"].default == 200
    assert Settings.model_fields["knowledge_outbox_max_attempts"].default == 10
    assert (
        Settings.model_fields["knowledge_outbox_protect_fresh_seconds"].default == 0.0
    )
    assert TaskState(task_id="defaults").semantic_enrichment is True
    assert Settings.model_fields["mineru_document_circuit_failures"].default == 3
    assert Settings.model_fields["mineru_document_circuit_seconds"].default == 300.0


def test_required_mineru_cannot_be_disabled() -> None:
    with pytest.raises(ValueError, match="MINERU_SHADOW_REQUIRED"):
        Settings(mineru_shadow_enabled=False, mineru_shadow_required=True)


def test_every_upload_endpoint_defaults_semantic_enrichment_on() -> None:
    app = create_app()
    expected_paths = {"/ingest", "/ingest/sync", "/ingest/batch", "/ingest/archive"}
    routes = {
        route.path: route
        for route in app.routes
        if getattr(route, "path", "") in expected_paths
    }
    assert set(routes) == expected_paths
    for route in routes.values():
        defaults = {
            parameter.name: parameter.default
            for parameter in route.dependant.body_params
        }
        assert defaults["semantic_enrichment"] is True
