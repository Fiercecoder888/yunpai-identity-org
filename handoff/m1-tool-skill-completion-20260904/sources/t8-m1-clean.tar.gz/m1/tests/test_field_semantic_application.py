from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from m1.documents.envelope import CellValue, DocumentEnvelope, SheetEnvelope
from m1.documents.models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
)
from m1.documents.parsing.document_routing_status import DocumentRoutingDependencyError
from m1.documents.parsing.field_semantic_application import (
    merge_lossless_plan_fields,
    route_document_custom_fields,
    route_tabular_schema_plan,
)
from m1.documents.parsing.field_semantic_registry import (
    CanonicalFieldDefinition,
    CanonicalFieldRegistry,
    build_document_canonical_field_registry,
)
from m1.documents.parsing.field_semantic_routing import (
    CustomFieldEntry,
    FieldSemanticInput,
    FieldSemanticResolution,
    FieldSemanticResolvedInput,
)
from m1.documents.parsing.mineru_domain import mapping_path
from m1.documents.tabular_schema import (
    ColumnMapping,
    HeaderFieldMapping,
    TableMapping,
    TabularSchemaPlan,
    apply_plan,
    validate_plan,
)


class _Runtime:
    def __init__(
        self,
        registry: CanonicalFieldRegistry,
        targets: dict[str, str],
        *,
        mode: str = "guarded",
    ) -> None:
        self.registry = registry
        self.targets = targets
        self.mode = mode
        self.max_fields_per_document = 128
        self.calls: list[tuple[FieldSemanticInput, ...]] = []

    async def resolve_fields(
        self,
        *,
        tenant_id: str,
        fields: tuple[FieldSemanticInput, ...],
        created_by: str = "field-semantic-router",
    ) -> tuple[FieldSemanticResolvedInput, ...]:
        assert tenant_id == "tenant-a"
        assert created_by
        self.calls.append(fields)
        return tuple(
            FieldSemanticResolvedInput(
                source_ref=field.source_ref,
                resolution=FieldSemanticResolution(
                    action="mapped",
                    reason="exact_active_mapping",
                    canonical_field_id=self.targets[field.source_ref],
                    profile_id=f"active-{index}",
                ),
            )
            for index, field in enumerate(fields)
        )


class _FailingRuntime:
    mode = "guarded"
    max_fields_per_document = 128

    def __init__(self, *, required: bool) -> None:
        self.required = required

    async def resolve_fields(self, **kwargs):
        del kwargs
        raise DocumentRoutingDependencyError("store", "TimeoutError")


class _PlanClient:
    output_mode = "prompted"

    def __init__(self, plan: TabularSchemaPlan) -> None:
        self.plan = plan
        self.calls = 0

    async def run(
        self,
        output_type,
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> SimpleNamespace:
        del output_type, instructions, prompt, request_limit
        self.calls += 1
        return SimpleNamespace(output=self.plan, usage={"requests": 1})


def _cell(coordinate: str, row: int, column: int, value: Any) -> CellValue:
    return CellValue(
        sheet="Sheet1",
        coordinate=coordinate,
        row=row,
        column=column,
        value=value,
        normalized_value=str(value),
    )


def _envelope() -> DocumentEnvelope:
    cells = {
        (1, 1): _cell("A1", 1, 1, "Customer part reference"),
        (2, 1): _cell("A2", 2, 1, "SKU-NEW"),
        (4, 1): _cell("A4", 4, 1, "Responsible organization"),
        (4, 2): _cell("B4", 4, 2, "Example issuer"),
    }
    return DocumentEnvelope(
        path=Path("novel.csv"),
        original_filename="novel.csv",
        display_filename="novel.csv",
        sha256="sha",
        mime_type="text/csv",
        file_kind="csv",
        sheets=[
            SheetEnvelope(
                name="Sheet1",
                cells=cells,
                max_row=4,
                max_column=2,
            )
        ],
    )


def _unknown_plan() -> TabularSchemaPlan:
    return TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="responsible_organization",
                strategy="horizontal",
                sheet="Sheet1",
                label_cells=["A4"],
                value_cells=["B4"],
            )
        ],
        tables=[
            TableMapping(
                sheet="Sheet1",
                header_rows=[1],
                data_start_row=2,
                data_end_row=2,
                columns=[ColumnMapping(column=1, field="customer_part_reference")],
            )
        ],
    )


def test_default_registry_has_static_document_record_coverage() -> None:
    registry = build_document_canonical_field_registry()
    paths = {item.value for item in registry.target_paths.values()}

    assert {
        "$.header.title",
        "$.header.issuer",
        "$.header.order_number",
        "$.header.contract_number",
        "$.header.date_raw",
        "$.header.delivery_date_raw",
        "$.header.settlement_method",
        "$.header.delivery_address",
        "$.header.buyer",
        "$.header.seller",
        "$.header.supplier",
        "$.header.currency",
    } <= paths
    assert {
        "$.lines[*].line_no",
        "$.lines[*].model",
        "$.lines[*].product_code",
        "$.lines[*].name_raw",
        "$.lines[*].specification_raw",
        "$.lines[*].quantity",
        "$.lines[*].unit",
        "$.lines[*].remark",
    } <= paths
    assert {
        "$.totals.declared_quantity",
        "$.totals.declared_amount",
    } <= paths
    assert registry.get("line.product_code").aliases


def test_registry_rejects_runtime_jsonpath_binding() -> None:
    definition = CanonicalFieldDefinition(field_id="header.title", title="Title")
    with pytest.raises(TypeError, match="code-owned enum"):
        CanonicalFieldRegistry(
            (definition,),
            target_paths={"header.title": "$.header.title"},  # type: ignore[dict-item]
        )


@pytest.mark.asyncio
async def test_tabular_route_rewrites_only_unknown_targets_and_preserves_lossless_data() -> (
    None
):
    envelope = _envelope()
    original = validate_plan(envelope, _unknown_plan())
    baseline = DocumentRecord(
        source=DocumentSource(original_filename="novel.csv"),
        document_type="order",
        document_subtype="supplier_purchase_order",
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {
            "header_fields:0": "header.issuer",
            "tables:0:columns:0": "line.product_code",
        },
    )

    routed = await route_tabular_schema_plan(
        envelope=envelope,
        plan=original,
        document=baseline,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )
    validated = validate_plan(envelope, routed.plan)
    lossless = apply_plan(envelope, baseline.model_copy(deep=True), original)
    result = apply_plan(envelope, baseline.model_copy(deep=True), validated)
    result = merge_lossless_plan_fields(result, lossless)

    assert routed.changed is True
    assert len(runtime.calls) == 1
    assert len(runtime.calls[0]) == 2
    assert result.header.issuer == "Example issuer"
    assert result.lines[0].product_code == "SKU-NEW"
    assert result.extraction["custom_fields"]["responsible_organization"] == (
        "Example issuer"
    )
    assert result.lines[0].custom_fields["customer_part_reference"] == "SKU-NEW"
    assert result.lines[0].raw_columns["Customer part reference"] == "SKU-NEW"


@pytest.mark.asyncio
async def test_tabular_route_does_not_overwrite_deterministic_value() -> None:
    envelope = _envelope()
    original = validate_plan(envelope, _unknown_plan())
    baseline = DocumentRecord(
        source=DocumentSource(original_filename="novel.csv"),
        document_type="order",
        document_subtype="supplier_purchase_order",
        header=DocumentHeader(issuer="Deterministic issuer"),
        lines=[OrderLine(line_id="schema:Sheet1:2", product_code="DET-SKU")],
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {
            "header_fields:0": "header.issuer",
            "tables:0:columns:0": "line.product_code",
        },
    )

    routed = await route_tabular_schema_plan(
        envelope=envelope,
        plan=original,
        document=baseline,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )
    result = apply_plan(envelope, baseline.model_copy(deep=True), routed.plan)

    assert result.header.issuer == "Deterministic issuer"
    assert result.lines[0].product_code == "DET-SKU"


@pytest.mark.asyncio
async def test_tabular_shadow_observes_mapping_without_rewriting_plan() -> None:
    envelope = _envelope()
    original = validate_plan(envelope, _unknown_plan())
    baseline = DocumentRecord(
        source=DocumentSource(original_filename="novel.csv"),
        document_type="order",
        document_subtype="supplier_purchase_order",
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {
            "header_fields:0": "header.issuer",
            "tables:0:columns:0": "line.product_code",
        },
        mode="shadow",
    )

    routed = await route_tabular_schema_plan(
        envelope=envelope,
        plan=original,
        document=baseline,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )

    assert routed.changed is False
    assert {item.reason for item in routed.audits} == {"shadow_mapping_observed"}
    assert all(item.action == "preserved" for item in routed.audits)


@pytest.mark.asyncio
async def test_optional_tabular_field_adapter_preserves_original_plan() -> None:
    envelope = _envelope()
    plan = validate_plan(envelope, _unknown_plan())
    baseline = DocumentRecord(source=DocumentSource(original_filename="novel.csv"))

    routed = await route_tabular_schema_plan(
        envelope=envelope,
        plan=plan,
        document=baseline,
        tenant_id="tenant-a",
        runtime=_FailingRuntime(required=False),
        registry=build_document_canonical_field_registry(),
    )

    assert routed.status == "degraded"
    assert routed.plan == plan
    assert {item.reason for item in routed.audits} == {"runtime_failure"}


@pytest.mark.asyncio
async def test_required_tabular_field_adapter_propagates_dependency_failure() -> None:
    envelope = _envelope()
    plan = validate_plan(envelope, _unknown_plan())

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await route_tabular_schema_plan(
            envelope=envelope,
            plan=plan,
            document=DocumentRecord(
                source=DocumentSource(original_filename="novel.csv")
            ),
            tenant_id="tenant-a",
            runtime=_FailingRuntime(required=True),
            registry=build_document_canonical_field_registry(),
        )

    assert caught.value.dependency == "store"


@pytest.mark.asyncio
async def test_mineru_route_groups_labels_and_copies_evidence_without_data_loss() -> (
    None
):
    line_raw_path = mapping_path("$.lines[0]", "raw_columns", "Customer SKU")
    line_custom_path = mapping_path("$.lines[0]", "custom_fields", "Customer SKU")
    header_path = mapping_path(
        "$.extraction", "custom_fields", "Responsible organization"
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename="mineru.pdf"),
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="mineru-1",
                raw_columns={"Customer SKU": "SKU-NEW"},
                custom_fields={"Customer SKU": "SKU-NEW"},
            )
        ],
        extraction={"custom_fields": {"Responsible organization": "Example issuer"}},
        field_meta={
            line_raw_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            ),
            line_custom_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            ),
            header_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="block:3")]
            ),
        },
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {
            "document-field:0": "header.issuer",
            "document-field:1": "line.product_code",
        },
    )

    result = await route_document_custom_fields(
        document=document,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )

    assert len(runtime.calls) == 1
    assert len(runtime.calls[0]) == 2
    assert result.header.issuer == "Example issuer"
    assert result.lines[0].product_code == "SKU-NEW"
    assert result.lines[0].raw_columns == {"Customer SKU": "SKU-NEW"}
    assert result.lines[0].custom_fields == {"Customer SKU": "SKU-NEW"}
    assert result.extraction["custom_fields"] == {
        "Responsible organization": "Example issuer"
    }
    assert result.field_meta["$.header.issuer"].source_refs[0].part == "block:3"
    assert result.field_meta["$.lines[0].product_code"].source_refs[0].part == (
        "table:1/cell:A2"
    )


@pytest.mark.asyncio
async def test_mineru_route_requires_evidence_and_never_overwrites() -> None:
    document = DocumentRecord(
        source=DocumentSource(original_filename="mineru.pdf"),
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="mineru-1",
                product_code="DET-SKU",
                raw_columns={"Customer SKU": "MODEL-SKU"},
            ),
            OrderLine(
                line_id="mineru-2",
                raw_columns={"Customer SKU": "NO-EVIDENCE-SKU"},
            ),
        ],
        field_meta={
            mapping_path("$.lines[0]", "raw_columns", "Customer SKU"): FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            )
        },
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {"document-field:0": "line.product_code"},
    )

    result = await route_document_custom_fields(
        document=document,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )

    assert result.lines[0].product_code == "DET-SKU"
    assert result.lines[1].product_code is None
    assert result.lines[1].raw_columns["Customer SKU"] == "NO-EVIDENCE-SKU"


@pytest.mark.asyncio
async def test_mineru_shadow_observes_mapping_without_filling_canonical_field() -> None:
    raw_path = mapping_path("$.lines[0]", "raw_columns", "Customer SKU")
    document = DocumentRecord(
        source=DocumentSource(original_filename="mineru.pdf"),
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="mineru-1",
                raw_columns={"Customer SKU": "SKU-NEW"},
            )
        ],
        field_meta={
            raw_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            )
        },
    )
    registry = build_document_canonical_field_registry()
    runtime = _Runtime(
        registry,
        {"document-field:0": "line.product_code"},
        mode="shadow",
    )

    result = await route_document_custom_fields(
        document=document,
        tenant_id="tenant-a",
        runtime=runtime,
        registry=registry,
    )

    assert result.lines[0].product_code is None
    assert result.lines[0].raw_columns == {"Customer SKU": "SKU-NEW"}
    routing = result.extraction["metadata"]["field_semantic_routing"]
    assert routing["mapped_fields"] == 0
    assert routing["decisions"][0]["reason"] == "shadow_mapping_observed"


@pytest.mark.asyncio
async def test_required_document_field_adapter_propagates_dependency_failure() -> None:
    raw_path = mapping_path("$.lines[0]", "raw_columns", "Customer SKU")
    document = DocumentRecord(
        source=DocumentSource(original_filename="mineru.pdf"),
        lines=[
            OrderLine(
                line_id="mineru-1",
                raw_columns={"Customer SKU": "SKU-NEW"},
            )
        ],
        field_meta={
            raw_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            )
        },
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await route_document_custom_fields(
            document=document,
            tenant_id="tenant-a",
            runtime=_FailingRuntime(required=True),
            registry=build_document_canonical_field_registry(),
        )

    assert caught.value.dependency == "store"


@pytest.mark.asyncio
async def test_candidate_profile_identity_is_preserved_in_final_document_audit() -> (
    None
):
    class _CandidateRuntime:
        mode = "guarded"
        max_fields_per_document = 128

        async def resolve_fields(
            self,
            *,
            tenant_id: str,
            fields: tuple[FieldSemanticInput, ...],
            created_by: str = "field-semantic-router",
        ) -> tuple[FieldSemanticResolvedInput, ...]:
            assert tenant_id == "tenant-a"
            assert created_by
            return tuple(
                FieldSemanticResolvedInput(
                    source_ref=field.source_ref,
                    resolution=FieldSemanticResolution(
                        action="custom_field",
                        reason="model_proposed_canonical_field",
                        candidate_profile_id="candidate-field-order-id",
                        custom_fields=(
                            CustomFieldEntry(
                                label=field.probe.label,
                                value=field.value,
                                evidence_refs=field.evidence_refs,
                                reason="model_proposed_canonical_field",
                            ),
                        ),
                        model_used=True,
                    ),
                )
                for field in fields
            )

    raw_path = mapping_path("$.lines[0]", "raw_columns", "Customer SKU")
    document = DocumentRecord(
        source=DocumentSource(original_filename="mineru.pdf"),
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="mineru-1",
                raw_columns={"Customer SKU": "SKU-NEW"},
            )
        ],
        field_meta={
            raw_path: FieldMetadata(
                source_refs=[SourceReference(page=1, part="table:1/cell:A2")]
            )
        },
    )

    result = await route_document_custom_fields(
        document=document,
        tenant_id="tenant-a",
        runtime=_CandidateRuntime(),
        registry=build_document_canonical_field_registry(),
    )

    decision = result.extraction["metadata"]["field_semantic_routing"]["decisions"][0]
    assert decision["action"] == "preserved"
    assert decision["candidate_profile_id"] == "candidate-field-order-id"
    assert result.lines[0].raw_columns == {"Customer SKU": "SKU-NEW"}
