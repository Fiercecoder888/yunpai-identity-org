from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from alembic import command
from m1.documents.parsing.field_semantic_routing import (
    FieldScope,
    FieldSemanticCandidateProposal,
    FieldSemanticExecutionObservation,
    FieldSemanticProbe,
    FieldValueKind,
    TableRole,
)
from m1.knowledge.db_models_base import (
    IdempotencyConflictError,
    TenantBoundaryError,
)
from m1.knowledge.field_semantic_db_models import FieldSemanticObservationRow
from m1.knowledge.field_semantic_repository import FieldSemanticRepository
from m1.knowledge.field_semantic_schema import (
    FieldSemanticObservationOutcome,
    FieldSemanticObservationRecord,
    FieldSemanticProfileRecord,
    FieldSemanticProfileStatus,
)
from m1.knowledge.migrations.runner import _config
from m1.knowledge.route_lifecycle_db_models import RouteLifecycleEventRow
from m1.knowledge.schema import TenantRecord
from sqlalchemy import create_engine, inspect, select
from sqlalchemy.exc import IntegrityError


def _signature(label: str = "订单号"):
    return FieldSemanticProbe(
        label=label,
        neighboring_labels=("下单日期", "客户"),
        document_domain="order",
        document_type="supplier_purchase_order",
        field_scope=FieldScope.DOCUMENT,
        table_role=TableRole.KEY_VALUE,
        value_kind=FieldValueKind.IDENTIFIER,
    ).signature()


def _profile(
    tenant_id: str,
    *,
    profile_id: str,
    canonical_field_id: str | None = "order.order_id",
    label: str = "订单号",
    embedding: list[float] | None = None,
) -> FieldSemanticProfileRecord:
    signature = _signature(label)
    return FieldSemanticProfileRecord(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=f"field-semantic:{profile_id}",
        version=1,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        canonical_field_id=canonical_field_id,
        embedding=embedding,
        embedding_model="test-embedding" if embedding is not None else "",
        embedding_dimensions=len(embedding) if embedding is not None else 0,
        created_by="test-suite",
    )


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


async def _seed_successes(
    store: FieldSemanticRepository,
    profile: FieldSemanticProfileRecord,
    *,
    task_names: tuple[str, ...] = ("task-1", "task-2", "task-3"),
) -> None:
    for index, task_name in enumerate(task_names):
        await store.record_field_semantic_execution_observation(
            FieldSemanticExecutionObservation(
                tenant_id=profile.tenant_id,
                profile_id=profile.profile_id,
                exact_fingerprint=profile.exact_fingerprint,
                task_reference_hash=_hash(task_name),
                outcome="success",
                validation_passed=True,
                reviewed_by=f"reviewer-{index}",
                review_note_sha256=_hash(f"review-note-{index}"),
                latency_ms=10 + index,
            )
        )


@pytest.fixture
async def field_store(tmp_path: Path):
    store = FieldSemanticRepository(
        f"sqlite+aiosqlite:///{(tmp_path / 'field-routes.db').as_posix()}"
    )
    await store.init()
    first = TenantRecord(tenant_key="tenant-a", display_name="Tenant A")
    second = TenantRecord(tenant_key="tenant-b", display_name="Tenant B")
    await store.create_tenant(first)
    await store.create_tenant(second)
    try:
        yield store, first, second
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_candidate_is_inactive_until_three_distinct_reviewed_tasks(field_store):
    store, tenant, _second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-order-id")
    )
    assert profile.status is FieldSemanticProfileStatus.CANDIDATE
    assert (
        await store.get_active_field_semantic_profile_by_fingerprint(
            tenant.tenant_id,
            profile.exact_fingerprint,
            contract_revision=profile.signature.contract_revision,
        )
        is None
    )

    await _seed_successes(store, profile, task_names=("task-1", "task-2"))
    with pytest.raises(ValueError, match="at least three"):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="approved after validation",
            expected_observation_count=2,
            allowed_canonical_field_ids={"order.order_id"},
        )

    await store.record_field_semantic_execution_observation(
        FieldSemanticExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=_hash("task-3"),
            outcome="success",
            validation_passed=True,
            reviewed_by="reviewer-3",
            review_note_sha256=_hash("review-note-3"),
        )
    )
    active = await store.activate_field_semantic_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="approved after validation",
        expected_observation_count=3,
        allowed_canonical_field_ids={"order.order_id"},
    )
    assert active.status is FieldSemanticProfileStatus.ACTIVE
    assert active.canonical_field_id == "order.order_id"
    exact = await store.get_active_field_semantic_profile_by_fingerprint(
        tenant.tenant_id,
        profile.exact_fingerprint,
        contract_revision=profile.signature.contract_revision,
    )
    assert exact is not None and exact.profile_id == profile.profile_id


@pytest.mark.asyncio
async def test_automatic_candidate_creation_is_idempotent_and_inactive(field_store):
    store, tenant, _second = field_store
    signature = _signature("客户订单编号")
    proposal = FieldSemanticCandidateProposal(
        tenant_id=tenant.tenant_id,
        profile_key=f"field-semantic:{signature.exact_fingerprint()[:24]}",
        signature=signature,
        canonical_field_id="order.order_id",
        created_by="field-semantic-router",
    )

    created = await store.create_field_semantic_candidate(proposal)
    replay = await store.create_field_semantic_candidate(proposal)

    assert created.status == "candidate"
    assert replay.profile_id == created.profile_id
    assert replay.canonical_field_id == "order.order_id"
    assert (
        await store.get_active_field_semantic_profile_by_fingerprint(
            tenant.tenant_id,
            signature.exact_fingerprint(),
            contract_revision=signature.contract_revision,
        )
        is None
    )


@pytest.mark.asyncio
async def test_activation_requires_distinct_task_hashes(field_store) -> None:
    store, tenant, _second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-duplicate-tasks")
    )
    for index in range(3):
        await store.record_field_semantic_observation(
            FieldSemanticObservationRecord(
                observation_id=f"duplicate-observation-{index}",
                tenant_id=tenant.tenant_id,
                profile_id=profile.profile_id,
                idempotency_key=f"duplicate-key-{index}",
                exact_fingerprint=profile.exact_fingerprint,
                task_reference_hash=_hash("same-task"),
                outcome=FieldSemanticObservationOutcome.SUCCESS,
                validation_passed=True,
                reviewed_by="reviewer",
                review_note_sha256=_hash(f"note-{index}"),
            )
        )

    with pytest.raises(IdempotencyConflictError, match="distinct-tasks"):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="duplicate tasks must fail",
            expected_observation_count=3,
            allowed_canonical_field_ids={"order.order_id"},
        )


@pytest.mark.asyncio
async def test_activation_rejects_any_failed_validation_sample(field_store) -> None:
    store, tenant, _second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-failed-sample")
    )
    await _seed_successes(store, profile)
    await store.record_field_semantic_execution_observation(
        FieldSemanticExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=_hash("failed-task"),
            outcome="failure",
            validation_passed=False,
            error_code="wrong_mapping",
        )
    )

    with pytest.raises(IdempotencyConflictError, match="failures"):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="failure must block activation",
            expected_observation_count=4,
            allowed_canonical_field_ids={"order.order_id"},
        )


@pytest.mark.asyncio
async def test_activation_rejects_unresolved_or_unregistered_field(field_store) -> None:
    store, tenant, _second = field_store
    unresolved = await store.create_field_semantic_profile(
        _profile(
            tenant.tenant_id,
            profile_id="field-unresolved",
            canonical_field_id=None,
        )
    )
    await _seed_successes(store, unresolved)
    with pytest.raises(ValueError, match="code-owned registry"):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            unresolved.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="cannot approve unresolved",
            expected_observation_count=3,
            allowed_canonical_field_ids={"order.order_id"},
        )


@pytest.mark.asyncio
async def test_observations_are_idempotent_and_tenant_safe(field_store) -> None:
    store, tenant, second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-idempotent")
    )
    observation = FieldSemanticObservationRecord(
        observation_id="field-observation-one",
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        idempotency_key="field-observation-key",
        exact_fingerprint=profile.exact_fingerprint,
        task_reference_hash=_hash("task-idempotent"),
        outcome=FieldSemanticObservationOutcome.SUCCESS,
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256=_hash("reviewed"),
        latency_ms=17,
    )
    first = await store.record_field_semantic_observation(observation)
    replay = await store.record_field_semantic_observation(
        observation.model_copy(update={"observation_id": "field-observation-replay"})
    )
    assert replay.observation_id == first.observation_id
    with pytest.raises(IdempotencyConflictError):
        await store.record_field_semantic_observation(
            observation.model_copy(update={"latency_ms": 99})
        )
    with pytest.raises(TenantBoundaryError):
        await store.record_field_semantic_observation(
            observation.model_copy(
                update={
                    "tenant_id": second.tenant_id,
                    "observation_id": "field-cross-tenant",
                    "idempotency_key": "field-cross-tenant",
                }
            )
        )


@pytest.mark.asyncio
async def test_vector_search_is_tenant_and_embedding_space_scoped(field_store) -> None:
    store, tenant, second = field_store
    vector = [1.0, *([0.0] * 1023)]
    first = await store.create_field_semantic_profile(
        _profile(
            tenant.tenant_id,
            profile_id="field-vector-a",
            embedding=vector,
        )
    )
    other = await store.create_field_semantic_profile(
        _profile(
            second.tenant_id,
            profile_id="field-vector-b",
            embedding=vector,
        )
    )
    for profile in (first, other):
        await _seed_successes(store, profile)
        await store.activate_field_semantic_profile(
            profile.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="validated vector profile",
            expected_observation_count=3,
            allowed_canonical_field_ids={"order.order_id"},
        )

    matches = await store.find_active_field_semantic_profiles(
        tenant.tenant_id,
        vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        contract_revision="m1.field-semantic.v1",
        limit=5,
    )
    assert [(item.profile.profile_id, item.vector_similarity) for item in matches] == [
        (first.profile_id, 1.0)
    ]

    await store.record_field_semantic_execution_observation(
        FieldSemanticExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=first.profile_id,
            exact_fingerprint=first.exact_fingerprint,
            task_reference_hash=_hash("failed-active-task"),
            outcome="failure",
            validation_passed=False,
            error_code="wrong_mapping",
        )
    )
    assert (
        await store.find_active_field_semantic_profiles(
            tenant.tenant_id,
            vector,
            embedding_model="test-embedding",
            embedding_dimensions=1024,
            contract_revision="m1.field-semantic.v1",
            limit=5,
        )
        == []
    )


@pytest.mark.asyncio
async def test_composite_foreign_key_blocks_cross_tenant_direct_write(field_store):
    store, tenant, second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-composite-fk")
    )
    with pytest.raises(IntegrityError):
        async with store.sessionmaker.begin() as session:
            session.add(
                FieldSemanticObservationRow(
                    observation_id="field-invalid-fk",
                    tenant_id=second.tenant_id,
                    profile_id=profile.profile_id,
                    idempotency_key="field-invalid-fk",
                    exact_fingerprint=profile.exact_fingerprint,
                    task_reference_hash=_hash("direct-cross-tenant"),
                    outcome="success",
                    validation_passed=True,
                    reviewed_by="reviewer",
                    review_note_sha256=_hash("reviewed"),
                    latency_ms=0,
                    error_code="",
                    observed_at=profile.created_at,
                )
            )


def test_field_semantic_migration_round_trip_and_identifiers(tmp_path: Path) -> None:
    migration = __import__(
        "m1.knowledge.migrations.versions.0012_field_semantic_routes",
        fromlist=["revision"],
    )
    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63
    assert len(migration.EMBEDDING_SPACE_INDEX) <= 63
    assert set(migration.TENANT_TABLES) == {
        "knowledge_field_semantic_profiles",
        "knowledge_field_semantic_observations",
        "knowledge_route_lifecycle_events",
    }
    assert set(migration.POLICY_NAMES) == set(migration.TENANT_TABLES)

    database = tmp_path / "field-semantic-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, migration.revision)
            schema = inspect(connection)
            assert {
                migration.PROFILE_TABLE,
                migration.OBSERVATION_TABLE,
            }.issubset(schema.get_table_names())
            command.downgrade(config, migration.down_revision)
            assert migration.PROFILE_TABLE not in inspect(connection).get_table_names()
            command.upgrade(config, migration.revision)
            assert migration.PROFILE_TABLE in inspect(connection).get_table_names()
    finally:
        engine.dispose()


@pytest.mark.asyncio
async def test_activation_replay_and_deprecation_audit_are_immutable(
    field_store,
) -> None:
    store, tenant, _second = field_store
    profile = await store.create_field_semantic_profile(
        _profile(tenant.tenant_id, profile_id="field-governance")
    )
    await _seed_successes(store, profile)
    common = {
        "reviewed_by": "activation-reviewer",
        "review_note": "three samples verified",
        "expected_observation_count": 3,
        "allowed_canonical_field_ids": {"order.order_id"},
    }
    with pytest.raises(ValueError, match="independent"):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="reviewer-0",
            **common,
        )
    active = await store.activate_field_semantic_profile(
        tenant.tenant_id, profile.profile_id, approved_by="approver", **common
    )
    replay = await store.activate_field_semantic_profile(
        tenant.tenant_id, profile.profile_id, approved_by="approver", **common
    )
    assert replay.approved_at == active.approved_at
    with pytest.raises(IdempotencyConflictError):
        await store.activate_field_semantic_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            **{**common, "review_note": "different replay"},
        )
    deprecated = await store.deprecate_field_semantic_profile(
        tenant.tenant_id,
        profile.profile_id,
        reviewed_by="deprecator",
        review_note="retired after replacement",
    )
    assert deprecated.reviewed_by == "activation-reviewer"
    assert deprecated.review_note == "three samples verified"
    async with store.sessionmaker() as session:
        events = (
            await session.scalars(
                select(RouteLifecycleEventRow).where(
                    RouteLifecycleEventRow.tenant_id == tenant.tenant_id,
                    RouteLifecycleEventRow.profile_id == profile.profile_id,
                )
            )
        ).all()
    assert {event.event_type for event in events} == {"activated", "deprecated"}
    assert all(len(event.actor_reference_sha256) == 64 for event in events)
    assert all(
        event.counterparty_reference_sha256 == ""
        or len(event.counterparty_reference_sha256) == 64
        for event in events
    )
    assert all(
        value not in {"approver", "activation-reviewer", "deprecator"}
        for event in events
        for value in (
            event.actor_reference_sha256,
            event.counterparty_reference_sha256,
        )
    )


def test_field_semantic_models_have_tenant_safe_composite_foreign_keys() -> None:
    from m1.knowledge.db_models_base import KnowledgeBase

    observation = KnowledgeBase.metadata.tables["knowledge_field_semantic_observations"]
    targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in observation.foreign_key_constraints
    }
    assert (
        "knowledge_field_semantic_profiles.tenant_id",
        "knowledge_field_semantic_profiles.profile_id",
    ) in targets
