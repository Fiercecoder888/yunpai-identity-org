from __future__ import annotations

import os
from importlib import import_module
from pathlib import Path

import asyncpg
import pytest
from alembic import command
from sqlalchemy import create_engine, inspect
from sqlalchemy.ext.asyncio import create_async_engine

from m1.knowledge.migrations.runner import _config, upgrade_database


HEAD_REVISION = "0022_flow_request_persistence"
POSTGRES_URL = os.getenv("M1_TEST_POSTGRES_URL", "").strip()


def _asyncpg_url(url: str) -> str:
    return url.replace("postgresql+asyncpg://", "postgresql://", 1)


def test_finished_goods_revision_is_sqlite_safe(tmp_path: Path) -> None:
    engine = create_engine(f"sqlite:///{tmp_path / 'knowledge.db'}")
    try:
        with engine.begin() as connection:
            command.upgrade(_config(connection), HEAD_REVISION)
            assert not inspect(connection).has_table("orders")
            command.downgrade(_config(connection), "0017_recalculation_ledger")
    finally:
        engine.dispose()


def test_finished_goods_revision_declares_governed_contract() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0018_finished_goods_output"
    )

    assert migration.down_revision == "0017_recalculation_ledger"
    assert migration.SCHEMA == "yunpai_core"
    assert len(migration.PRODUCT_FK_NAME) <= 63
    assert len(migration.MOVEMENT_TYPE_CHECK_NAME) <= 63
    assert len(migration.FACT_TYPE_CHECK_NAME) <= 63

    source = Path(migration.__file__).read_text(encoding="utf-8")
    assert "movement_type IN" in source
    assert "'produced'" in source
    assert "fact_type IN" in source
    assert "'production_output'" in source


async def _insert_movement(
    connection: asyncpg.Connection, movement_id: str, movement_type: str
) -> None:
    await connection.execute(
        """
        INSERT INTO yunpai_core.inventory_movements
            (movement_id, tenant_id, material_id, movement_type, quantity,
             location_id, source_module, source_event_id, occurred_at)
        VALUES ($1, 't1', 'FG-MAT', $2, 1, 'FG-WH', 'm5', $3, CURRENT_TIMESTAMP)
        """,
        movement_id,
        movement_type,
        f"EVT-{movement_id}",
    )


async def _insert_fact(
    connection: asyncpg.Connection, fact_id: str, fact_type: str
) -> None:
    await connection.execute(
        """
        INSERT INTO yunpai_core.fact_versions
            (fact_version_id, tenant_id, fact_type, aggregate_type, aggregate_id,
             version, source_module, source_event_id, occurred_at, effective_at,
             payload_digest, payload, validation, created_at)
        VALUES ($1, 't1', $2, 'material', 'FG-MAT', 1, 'm5', $3,
                CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, repeat('a', 64),
                '{}'::jsonb, '[]'::jsonb, CURRENT_TIMESTAMP)
        """,
        fact_id,
        fact_type,
        f"EVT-{fact_id}",
    )


@pytest.mark.skipif(not POSTGRES_URL, reason="M1_TEST_POSTGRES_URL is not configured")
@pytest.mark.asyncio
async def test_finished_goods_postgres_constraints_upgrade_and_downgrade() -> None:
    assert await upgrade_database(POSTGRES_URL) == HEAD_REVISION

    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    await admin.execute("SELECT set_config('yunpai.tenant_id', 't1', false)")
    try:
        product_column = await admin.fetch(
            """
            SELECT column_name, is_nullable
            FROM information_schema.columns
            WHERE table_schema='yunpai_core' AND table_name='orders'
              AND column_name='product_id'
            """
        )
        assert len(product_column) == 1
        assert product_column[0]["is_nullable"] == "YES"

        product_fk = await admin.fetchval(
            """
            SELECT count(*) FROM pg_constraint c
            JOIN pg_namespace n ON n.oid=c.connamespace
            WHERE n.nspname='yunpai_core' AND c.conname='fk_core_orders_product'
              AND c.contype='f'
            """
        )
        assert product_fk == 1

        await admin.execute(
            """
            INSERT INTO yunpai_core.materials
                (tenant_id, material_id, material_code, name, unit,
                 lifecycle_status, version)
            VALUES ('t1', 'FG-MAT', 'FG-MAT', '成品', 'PCS', 'active', 1)
            """
        )

        # 'produced' movement and 'production_output' fact are accepted at head,
        # but rolled back so the downgrade below sees no violating rows.
        transaction = admin.transaction()
        await transaction.start()
        await _insert_movement(admin, "MV-PROD-OK", "produced")
        await transaction.rollback()

        transaction = admin.transaction()
        await transaction.start()
        with pytest.raises(asyncpg.exceptions.CheckViolationError):
            await _insert_movement(admin, "MV-PROD-BAD", "bogus")
        await transaction.rollback()

        transaction = admin.transaction()
        await transaction.start()
        await _insert_fact(admin, "FACT-PROD-OK", "production_output")
        await transaction.rollback()

        transaction = admin.transaction()
        await transaction.start()
        with pytest.raises(asyncpg.exceptions.CheckViolationError):
            await _insert_fact(admin, "FACT-PROD-BAD", "bogus")
        await transaction.rollback()
    finally:
        await admin.close()

    engine = create_async_engine(POSTGRES_URL)
    try:
        async with engine.begin() as connection:
            await connection.run_sync(
                lambda sync_connection: command.downgrade(
                    _config(sync_connection), "0017_recalculation_ledger"
                )
            )
    finally:
        await engine.dispose()

    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    await admin.execute("SELECT set_config('yunpai.tenant_id', 't1', false)")
    try:
        assert await admin.fetchval(
            """
            SELECT count(*) FROM information_schema.columns
            WHERE table_schema='yunpai_core' AND table_name='orders'
              AND column_name='product_id'
            """
        ) == 0

        transaction = admin.transaction()
        await transaction.start()
        with pytest.raises(asyncpg.exceptions.CheckViolationError):
            await _insert_movement(admin, "MV-PROD-AFTER", "produced")
        await transaction.rollback()

        transaction = admin.transaction()
        await transaction.start()
        with pytest.raises(asyncpg.exceptions.CheckViolationError):
            await _insert_fact(admin, "FACT-PROD-AFTER", "production_output")
        await transaction.rollback()
    finally:
        await admin.close()

    assert await upgrade_database(POSTGRES_URL) == HEAD_REVISION
