"""Opt-in, full production-corpus regression through the real FastAPI boundary."""

from __future__ import annotations

import json
import os
import time
from collections import Counter
from pathlib import Path

import pytest

pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(
        os.environ.get("M1_RUN_FULL_API_CORPUS") != "1",
        reason="set M1_RUN_FULL_API_CORPUS=1 for the full HTTP corpus regression",
    ),
]


def _corpus_dir() -> Path:
    configured = os.environ.get("M1_LIVE_CORPUS_DIR")
    path = (
        Path(configured)
        if configured
        else Path(__file__).resolve().parents[3] / "生产数据"
    )
    if not path.is_dir():
        pytest.fail(f"production corpus does not exist: {path}")
    return path


def test_full_production_corpus_through_batch_http(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Every supported unique leaf must finish with a retrievable v2 document."""

    import m1.deps as deps_module
    from fastapi.testclient import TestClient
    from m1.api import main as api_main

    corpus = _corpus_dir()
    inputs = sorted(path for path in corpus.iterdir() if path.is_file())
    assert inputs, corpus
    semantic_enrichment = os.environ.get("M1_FULL_API_SEMANTIC") == "1"
    resume_database = os.environ.get("M1_FULL_API_RESUME_DB")
    resume_upload_dir = os.environ.get("M1_FULL_API_RESUME_UPLOAD_DIR")
    resume_parent_id = os.environ.get("M1_FULL_API_RESUME_PARENT_ID")
    fresh_database = os.environ.get("M1_FULL_API_DATABASE")
    fresh_upload_dir = os.environ.get("M1_FULL_API_UPLOAD_DIR")

    database_path = (
        Path(resume_database)
        if resume_database
        else Path(fresh_database)
        if fresh_database
        else tmp_path / "full-api-corpus.db"
    )
    if not resume_database and fresh_database and database_path.exists():
        pytest.fail(
            f"fresh full-API database already exists: {database_path}; "
            "use M1_FULL_API_RESUME_DB to resume explicitly"
        )
    monkeypatch.setattr(
        api_main.settings,
        "database_url",
        f"sqlite+aiosqlite:///{database_path.as_posix()}",
    )
    monkeypatch.setattr(
        api_main.settings,
        "upload_dir",
        resume_upload_dir or fresh_upload_dir or str(tmp_path / "uploads"),
    )
    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(
        api_main.settings,
        "max_concurrent",
        int(os.environ.get("M1_FULL_API_MAX_CONCURRENT", "5")),
    )
    monkeypatch.setattr(deps_module, "_deps", None)
    monkeypatch.setattr(api_main, "store", None)
    monkeypatch.setattr(api_main, "engine", None)
    api_main._task_registry.clear()

    started = time.monotonic()
    rows: list[dict] = []
    with TestClient(api_main.create_app()) as client:
        if resume_database:
            task_response = client.get("/tasks")
            assert task_response.status_code == 200
            parents = [
                task
                for task in task_response.json()
                if task.get("file_type") == "batch" and task.get("child_ids")
            ]
            if resume_parent_id:
                parents = [
                    task for task in parents if task.get("task_id") == resume_parent_id
                ]
            assert len(parents) == 1, (
                "set M1_FULL_API_RESUME_PARENT_ID when the database contains multiple batch parents",
                parents,
            )
            parent_id = parents[0]["task_id"]
            print(f"FULL_API_RESUMED_PARENT={parent_id}", flush=True)
        else:
            streams = [path.open("rb") for path in inputs]
            try:
                response = client.post(
                    "/ingest/batch",
                    files=[
                        ("files", (path.name, stream, "application/octet-stream"))
                        for path, stream in zip(inputs, streams, strict=True)
                    ],
                    data={
                        "semantic_enrichment": (
                            "true" if semantic_enrichment else "false"
                        )
                    },
                )
            finally:
                for stream in streams:
                    stream.close()
            assert response.status_code == 202, response.text[:1000]
            parent_id = response.json()["task_id"]

        deadline = time.monotonic() + float(
            os.environ.get("M1_FULL_API_TIMEOUT_SECONDS", "1800")
        )
        last_counts: tuple[int, int, int, int] | None = None
        while True:
            batch_response = client.get(f"/batch/{parent_id}")
            assert batch_response.status_code == 200, batch_response.text[:1000]
            batch = batch_response.json()
            counts = (
                batch["done_count"],
                batch["pending_count"],
                batch["failed_count"],
                batch["review_count"],
            )
            if counts != last_counts:
                print(
                    "FULL_API_PROGRESS="
                    + json.dumps(
                        {
                            "parent_id": parent_id,
                            "child_count": batch["child_count"],
                            "done_count": batch["done_count"],
                            "pending_count": batch["pending_count"],
                            "failed_count": batch["failed_count"],
                            "review_count": batch["review_count"],
                        },
                        ensure_ascii=False,
                    ),
                    flush=True,
                )
                last_counts = counts
            if batch["pending_count"] == 0:
                if batch["parent"]["status"] in {"done", "needs_review"}:
                    break
                # A persisted parent deadline can expire while long-running
                # children continue successfully.  Startup recovery repairs
                # that stale parent asynchronously; do not cancel it merely
                # because every child has now reached a good terminal state.
                if batch["parent"]["status"] == "failed" and batch["failed_count"]:
                    break
            if time.monotonic() >= deadline:
                pytest.fail(f"full API batch timed out: {batch}")
            time.sleep(0.5)

        expected_unique = int(os.environ.get("M1_EXPECTED_UNIQUE_DOCUMENTS", "304"))
        assert batch["child_count"] == expected_unique
        assert batch["done_count"] == expected_unique
        assert batch["failed_count"] == 0
        assert batch["pending_count"] == 0
        assert batch["parent"]["status"] in {"done", "needs_review"}
        assert not batch["parent"].get("error")

        for index, child in enumerate(batch["children"], 1):
            task_id = child["task_id"]
            document_response = client.get(f"/tasks/{task_id}/document")
            assert document_response.status_code == 200, (
                task_id,
                child,
                document_response.text[:1000],
            )
            document = document_response.json()
            assert document["schema_version"] == "m1.document.v2", task_id
            assert document["source"]["sha256"], task_id
            assert document["source"]["original_filename"], task_id
            extraction = document.get("extraction") or {}
            metadata = extraction.get("metadata") or {}
            assert metadata.get("adapter"), (task_id, document["source"])
            semantic_vlm = metadata.get("semantic_vlm") or {}
            rows.append(
                {
                    "task_id": task_id,
                    "filename": child.get("filename"),
                    "status": child.get("status"),
                    "file_type": child.get("file_type"),
                    "document_type": document.get("document_type"),
                    "document_subtype": document.get("document_subtype"),
                    "schema_version": document.get("schema_version"),
                    "sha256": document["source"].get("sha256"),
                    "adapter": metadata.get("adapter"),
                    "semantic_vlm": semantic_vlm,
                    "line_count": len(document.get("lines") or []),
                    "issue_codes": [
                        issue.get("code")
                        for issue in document.get("validation_issues") or []
                    ],
                    "needs_review": document.get("needs_review"),
                    "error": child.get("error"),
                }
            )
            if index % 50 == 0:
                print(f"FULL_API_DOCUMENTS_VALIDATED={index}", flush=True)

        search_hits: list[dict] = []
        for offset in range(0, expected_unique, 200):
            search_response = client.get(
                "/documents/search", params={"limit": 200, "offset": offset}
            )
            assert search_response.status_code == 200
            search_hits.extend(search_response.json())
        assert len({hit["task_id"] for hit in search_hits}) == expected_unique

    elapsed = time.monotonic() - started
    file_types = Counter(str(row["file_type"]) for row in rows)
    statuses = Counter(str(row["status"]) for row in rows)
    assert len(rows) == expected_unique
    assert len({str(row["sha256"]) for row in rows}) == expected_unique
    expected_file_types = json.loads(
        os.environ.get(
            "M1_EXPECTED_FILE_TYPES",
            '{"xlsx": 130, "xls": 6, "pdf": 152, "docx": 16}',
        )
    )
    assert dict(file_types) == expected_file_types
    semantic_rows = [row for row in rows if row.get("semantic_vlm")]
    semantic_metrics = {
        "document_count": len(semantic_rows),
        "request_count": sum(
            int(row["semantic_vlm"].get("request_count") or 0) for row in semantic_rows
        ),
        "schema_retry_count": sum(
            int(row["semantic_vlm"].get("schema_retry_count") or 0)
            for row in semantic_rows
        ),
        "degradation_count": sum(
            int(row["semantic_vlm"].get("degradation_count") or 0)
            for row in semantic_rows
        ),
        "degradation_errors": dict(
            sorted(
                Counter(
                    str(row["semantic_vlm"].get("error_type"))
                    for row in semantic_rows
                    if row["semantic_vlm"].get("degraded")
                ).items()
            )
        ),
        "models": dict(
            sorted(
                Counter(
                    str(row["semantic_vlm"].get("model")) for row in semantic_rows
                ).items()
            )
        ),
        "duration_seconds": round(
            sum(
                float(row["semantic_vlm"].get("duration_seconds") or 0.0)
                for row in semantic_rows
            ),
            3,
        ),
        "usage": {
            key: sum(
                int((row["semantic_vlm"].get("total_usage") or {}).get(key) or 0)
                for row in semantic_rows
            )
            for key in ("prompt_tokens", "completion_tokens", "total_tokens")
        },
    }
    persisted_semantic_enrichment = bool(
        batch["parent"].get("semantic_enrichment", semantic_enrichment)
    )
    if persisted_semantic_enrichment:
        expected_semantic_documents = sum(
            row["document_type"] == "order" and int(row["line_count"] or 0) > 0
            for row in rows
        )
        assert semantic_metrics["document_count"] == expected_semantic_documents
        assert semantic_metrics["document_count"] > 0
        assert semantic_metrics["request_count"] > 0
        assert {row["semantic_vlm"].get("model") for row in semantic_rows} == {
            "Qwen/Qwen3.6-27B"
        }
        assert all(
            row["semantic_vlm"].get("finish_reason") != "length"
            for row in semantic_rows
        )
        allowed_degradations = int(
            os.environ.get("M1_ALLOWED_SEMANTIC_DEGRADATIONS", "0")
        )
        assert semantic_metrics["degradation_count"] <= allowed_degradations
    summary = {
        "parent_id": parent_id,
        "top_level_inputs": [
            {"name": path.name, "bytes": path.stat().st_size} for path in inputs
        ],
        "unique_document_count": len(rows),
        "file_types": dict(sorted(file_types.items())),
        "statuses": dict(sorted(statuses.items())),
        "elapsed_seconds": round(elapsed, 3),
        "semantic_enrichment": persisted_semantic_enrichment,
        "resumed_from_persistence": bool(resume_database),
        "semantic_metrics": semantic_metrics,
        "documents": rows,
    }
    report_path_value = os.environ.get("M1_API_REPORT_PATH")
    if report_path_value:
        report_path = Path(report_path_value)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"FULL_API_REPORT={report_path}", flush=True)
    # Archive members can contain mojibake/private-use code points which are not
    # representable by the default Windows GBK console.  Keep the JSON report
    # UTF-8, but make the one-line console summary transport-safe.
    print(
        "FULL_API_METRICS="
        + json.dumps(summary | {"documents": []}, ensure_ascii=True),
        flush=True,
    )
