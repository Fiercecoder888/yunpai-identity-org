from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from m1.knowledge.eligibility import knowledge_sync_eligibility
from m1.state import TaskState, TaskStatus
from m1.workflow.document_pipeline import DocumentPipelineMixin
from m1.workflow.engine import WorkflowEngine
from m1.workflow.persistence import TaskStore
from m1.workflow.review import ReviewWorkflowMixin


class FixedTypeRouter:
    def __init__(self, file_type: str) -> None:
        self.file_type = file_type

    def detect_type(self, _file_path: str | Path) -> str:
        return self.file_type

    async def parse(self, *_args, **_kwargs):
        raise AssertionError("legacy parser fallback must not execute")


def _memory_store() -> SimpleNamespace:
    return SimpleNamespace(
        save=AsyncMock(),
        update_mineru_shadow_status=AsyncMock(),
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "detected_type",
    [
        "image",
        "pdf",
        "xlsx",
        "xlsm",
        "xls",
        "csv",
        "docx",
        "pptx",
        "html",
        "dxf",
        "dwg",
        "unknown",
    ],
)
async def test_entrypoint_sends_every_detected_type_to_full_authority(
    tmp_path: Path,
    detected_type: str,
) -> None:
    source = tmp_path / f"source.{detected_type}"
    source.write_bytes(b"full-authority fixture")
    store = _memory_store()
    engine = WorkflowEngine(
        SimpleNamespace(
            parser_router=FixedTypeRouter(detected_type),
            mineru_shadow_runner=None,
        ),
        store,
    )
    engine._run_mineru_full_pipeline = AsyncMock()
    state = TaskState(task_id=f"full-{detected_type}", file_path=str(source))

    result = await engine.run_to_completion(state)

    assert result is state
    assert state.file_type == detected_type
    engine._run_mineru_full_pipeline.assert_awaited_once()
    assert engine._run_mineru_full_pipeline.await_args.args == (state,)
    assert engine._run_mineru_full_pipeline.await_args.kwargs == {
        "active_route_plan": None,
        "route_plan": None,
        "routing_summary": None,
    }


@pytest.mark.asyncio
async def test_htm_detection_is_normalized_to_html(tmp_path: Path) -> None:
    source = tmp_path / "source.htm"
    source.write_text("<html></html>", encoding="utf-8")
    engine = WorkflowEngine(
        SimpleNamespace(
            parser_router=FixedTypeRouter("htm"),
            mineru_shadow_runner=None,
        ),
        _memory_store(),
    )
    engine._run_mineru_full_pipeline = AsyncMock()
    state = TaskState(task_id="full-htm", file_path=str(source))

    await engine.run_to_completion(state)

    assert state.file_type == "html"
    engine._run_mineru_full_pipeline.assert_awaited_once()


@pytest.mark.asyncio
async def test_unknown_input_is_persisted_as_full_authority_fail_closed(
    tmp_path: Path,
) -> None:
    source = tmp_path / "unknown.bin"
    source.write_bytes(b"unsupported input")
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'unknown.db').as_posix()}")
    await store.init()
    engine = WorkflowEngine(
        SimpleNamespace(
            parser_router=FixedTypeRouter("unknown"),
            mineru_shadow_runner=None,
            confidence_threshold=0.8,
        ),
        store,
    )
    state = TaskState(
        task_id="full-unknown",
        file_path=str(source),
        original_filename="unknown.bin",
    )

    try:
        await engine.run_to_completion(state)

        assert state.status == TaskStatus.NEEDS_REVIEW
        assert state.processing_stage == "needs_review"
        document = await store.get_document(state.task_id)
        assert document is not None
        assert not any(document["header"].values())
        assert document["lines"] == []
        assert document["validation_issues"][0]["code"] == (
            "MINERU_FULL_INPUT_UNSUPPORTED"
        )
        metadata = document["extraction"]["metadata"]
        assert metadata["authority_mode"] == "full"
        assert metadata["knowledge_sync_eligible"] is False
        assert state.mineru_shadow["authority_selected"] is False
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_unexpected_full_pipeline_error_is_safely_persisted(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source.pdf"
    source.write_bytes(b"%PDF-1.7")
    store = _memory_store()
    engine = WorkflowEngine(
        SimpleNamespace(
            parser_router=FixedTypeRouter("pdf"),
            mineru_shadow_runner=None,
        ),
        store,
    )
    engine._run_mineru_full_pipeline = AsyncMock(
        side_effect=RuntimeError("Authorization: must-not-leak")
    )
    state = TaskState(task_id="full-error", file_path=str(source))

    await engine.run_to_completion(state)

    assert state.status == TaskStatus.FAILED
    assert state.processing_stage == "failed"
    assert state.error == "RuntimeError"
    assert "must-not-leak" not in state.error
    assert store.save.await_count >= 3


def test_non_mineru_route_is_audited_but_never_executed_as_authority() -> None:
    pipeline = object.__new__(WorkflowEngine)
    document = {"extraction": {"metadata": {}}}
    route_plan = {
        "backend_chain": [
            {"backend": "pp_structure_v3", "role": "primary"},
            {"backend": "mineru", "role": "fallback"},
        ],
        "policy_applied": True,
    }

    pipeline._record_full_mineru_route_execution(
        document,
        route_plan=route_plan,
        routing_summary={"status": "resolved", "stage": "preparse"},
        accepted=True,
        error_type="",
    )

    metadata = document["extraction"]["metadata"]
    assert metadata["route_authority_enforcement"] == {
        "policy": "mineru_full_only",
        "recommended_primary": "pp_structure_v3",
        "authority_backend": "mineru",
        "recommendation_executed_as_authority": False,
    }
    assert metadata["route_execution"]["status"] == "authority_applied"
    assert metadata["route_execution"]["backend"] == "mineru"
    assert metadata["route_execution_attempts"] == [
        {
            "backend": "pp_structure_v3",
            "role": "recommended_primary",
            "status": "not_executed",
            "reason": "mineru_full_authority",
        },
        {"backend": "mineru", "role": "authority", "status": "applied"},
    ]


def test_legacy_stages_are_not_part_of_the_public_workflow() -> None:
    assert WorkflowEngine.__bases__ == (DocumentPipelineMixin, ReviewWorkflowMixin)
    for name in (
        "_mineru_authority_stage",
        "_mineru_shadow_stage",
        "_model_verification_stage",
        "_semantic_enrichment_stage",
        "_augment_pdf_with_ocr",
    ):
        assert not hasattr(WorkflowEngine, name)


@pytest.mark.asyncio
async def test_non_full_runner_is_rejected_without_execution(tmp_path: Path) -> None:
    source = tmp_path / "source.pdf"
    source.write_bytes(b"%PDF-1.7\n%%EOF\n")
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'mismatch.db').as_posix()}")
    await store.init()
    runner = SimpleNamespace(
        authority_mode="guarded",
        run_candidate=AsyncMock(),
    )
    engine = WorkflowEngine(
        SimpleNamespace(
            mineru_shadow_runner=runner,
            confidence_threshold=0.8,
        ),
        store,
    )
    state = TaskState(
        task_id="authority-mismatch",
        file_path=str(source),
        file_type="pdf",
        original_filename=source.name,
    )

    try:
        await engine._run_mineru_full_pipeline(state)

        runner.run_candidate.assert_not_awaited()
        document = await store.get_document(state.task_id)
        assert document is not None
        assert document["validation_issues"][0]["code"] == (
            "MINERU_FULL_AUTHORITY_CONTRACT_MISMATCH"
        )
        assert document["extraction"]["metadata"]["knowledge_sync_eligible"] is False
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_full_runner_failure_persists_bounded_stage_diagnostic(
    tmp_path: Path,
) -> None:
    source = tmp_path / "source.pdf"
    source.write_bytes(b"%PDF-1.7\n%%EOF\n")
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'failure.db').as_posix()}")
    await store.init()
    failure = RuntimeError("document text must not be persisted")
    failure.__dict__["failure_stage"] = "document_projection"
    failure.__dict__["failure_reason"] = "invalid_document_record_projection"
    runner = SimpleNamespace(
        authority_mode="full",
        run_candidate=AsyncMock(side_effect=failure),
    )
    engine = WorkflowEngine(
        SimpleNamespace(
            mineru_shadow_runner=runner,
            confidence_threshold=0.8,
        ),
        store,
    )
    state = TaskState(
        task_id="authority-stage-failure",
        file_path=str(source),
        file_type="pdf",
        original_filename=source.name,
    )

    try:
        await engine._run_mineru_full_pipeline(state)

        document = await store.get_document(state.task_id)
        assert document is not None
        actual = document["validation_issues"][0]["actual"]
        assert actual == {
            "error_type": "RuntimeError",
            "failure_stage": "document_projection",
            "failure_reason": "invalid_document_record_projection",
        }
        assert "document text" not in str(document)
        assert state.mineru_shadow["failure_stage"] == "document_projection"
        assert state.mineru_shadow["failure_reason"] == (
            "invalid_document_record_projection"
        )
    finally:
        await store.close()


def test_semantic_enrichment_false_suppresses_only_optional_order_fields() -> None:
    engine = object.__new__(WorkflowEngine)
    state = TaskState(task_id="semantic-off", semantic_enrichment=False)
    document = {
        "document_type": "order",
        "lines": [
            {
                "line_id": "line-1",
                "model": "MODEL-1",
                "quantity": "2",
                "name_raw": "HDMI cable",
                "name_normalized": "HDMI Cable",
                "full_product_name": "HDMI Cable 2m",
                "product_category": "cable",
                "name_attributes": {"cable_length": "2m"},
            }
        ],
        "field_meta": {
            "$.lines[0].model": {"source_refs": [{"page": 1}]},
            "$.lines[0].name_normalized": {"inferred": True},
            "$.lines[0].name_attributes.cable_length": {"inferred": True},
        },
        "extraction": {"metadata": {"authority_mode": "full"}},
    }

    engine._apply_semantic_enrichment_contract(
        state,
        document,
        authority_selected=True,
    )

    line = document["lines"][0]
    assert line["model"] == "MODEL-1"
    assert line["quantity"] == "2"
    assert line["name_raw"] == "HDMI cable"
    assert line["name_normalized"] is None
    assert line["full_product_name"] is None
    assert line["product_category"] is None
    assert line["name_attributes"] == {}
    assert "$.lines[0].model" in document["field_meta"]
    assert "$.lines[0].name_normalized" not in document["field_meta"]
    audit = document["extraction"]["metadata"]["semantic_enrichment"]
    assert audit["status"] == "disabled"
    assert audit["suppressed_paths"] == [
        "$.lines[0].name_normalized",
        "$.lines[0].full_product_name",
        "$.lines[0].product_category",
        "$.lines[0].name_attributes",
    ]


def test_full_authority_knowledge_requires_selected_or_manual_review() -> None:
    rejected = {
        "extraction": {
            "metadata": {
                "authority_mode": "full",
                "authority_selected": False,
            }
        }
    }
    selected = {
        "extraction": {
            "metadata": {
                "authority_mode": "full",
                "authority_selected": True,
            }
        }
    }
    reviewed = {
        "extraction": {
            "metadata": {
                "authority_mode": "full",
                "authority_selected": "manual_review",
            }
        }
    }

    assert knowledge_sync_eligibility(rejected) == (
        False,
        "full_authority_not_selected",
    )
    assert knowledge_sync_eligibility(selected) == (True, "")
    assert knowledge_sync_eligibility(reviewed) == (True, "")


def test_manual_approval_explicitly_unlocks_full_authority_knowledge() -> None:
    engine = object.__new__(WorkflowEngine)
    document = {
        "document_type": "unknown",
        "header": {},
        "lines": [],
        "field_meta": {},
        "validation_issues": [
            {
                "code": "MINERU_FULL_AUTHORITY_REJECTED",
                "severity": "error",
                "message": "review required",
                "paths": ["$"],
                "source_refs": [],
            }
        ],
        "needs_review": True,
        "extraction": {
            "metadata": {
                "authority_mode": "full",
                "authority_selected": False,
                "knowledge_sync_eligible": False,
                "knowledge_sync_block_reason": "MINERU_FULL_AUTHORITY_REJECTED",
            }
        },
    }

    engine._apply_document_review(
        document,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=None,
        issue_resolutions=None,
        reviewer="reviewer-1",
        comment="source checked",
        approve=True,
    )

    metadata = document["extraction"]["metadata"]
    assert metadata["authority_selected"] == "manual_review"
    assert metadata["knowledge_sync_eligible"] is True
    assert "knowledge_sync_block_reason" not in metadata
    assert knowledge_sync_eligibility(document) == (True, "")


@pytest.mark.asyncio
async def test_manual_approval_persists_and_queues_reviewed_visual_facts(
    tmp_path: Path,
) -> None:
    sink = AsyncMock()
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'reviewed-visual.db').as_posix()}",
        document_sink=sink,
    )
    await store.init()
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "visual-only.docx"},
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "generic_facts": [
            {
                "name": "visual_identifier",
                "value": "ZXQ-86420-VISUAL-ONLY",
                "source_refs": [{"page": 1, "part": "word/media/image1.png"}],
            }
        ],
        "header": {},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [
            {
                "code": "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW",
                "severity": "warning",
                "message": "visual evidence requires confirmation",
                "paths": ["$.generic_facts[0].value"],
                "source_refs": [{"page": 1, "part": "word/media/image1.png"}],
            }
        ],
        "needs_review": True,
        "extraction": {
            "metadata": {
                "authority_mode": "full",
                "authority_selected": False,
                "authority_review_preserved": True,
                "knowledge_sync_eligible": False,
                "knowledge_sync_block_reason": (
                    "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW"
                ),
            }
        },
    }
    state = TaskState(
        task_id="reviewed-visual",
        status=TaskStatus.NEEDS_REVIEW,
        processing_stage="needs_review",
        original_filename="visual-only.docx",
        file_type="docx",
        document=document,
        document_schema_version="m1.document.v2",
    )
    await store.save(state)
    engine = WorkflowEngine(SimpleNamespace(confidence_threshold=0.8), store)

    try:
        completed = await engine.submit_review(
            state.task_id,
            reviewer="reviewer-1",
            comment="visual source checked",
            approve=True,
        )

        assert completed.status == TaskStatus.DONE
        sink.assert_awaited_once()
        synced = sink.await_args.args[1]
        metadata = synced["extraction"]["metadata"]
        assert metadata["authority_mode"] == "full"
        assert metadata["authority_selected"] == "manual_review"
        assert metadata["knowledge_sync_eligible"] is True
        assert "knowledge_sync_block_reason" not in metadata
        assert synced["generic_facts"][0]["value"] == "ZXQ-86420-VISUAL-ONLY"
        assert knowledge_sync_eligibility(synced) == (True, "")
    finally:
        await store.close()
