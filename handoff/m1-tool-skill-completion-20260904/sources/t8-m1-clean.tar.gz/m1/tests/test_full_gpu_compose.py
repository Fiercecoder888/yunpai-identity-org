import re
from pathlib import Path

import yaml


def _repository() -> Path:
    return Path(__file__).resolve().parents[2]


def _load(relative_path: str) -> dict:
    return yaml.safe_load((_repository() / relative_path).read_text(encoding="utf-8"))


def _environment(service: dict) -> dict[str, str]:
    values = service.get("environment", {})
    if isinstance(values, dict):
        return values
    return dict(value.split("=", 1) for value in values)


def _dotenv(relative_path: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in (
        (_repository() / relative_path).read_text(encoding="utf-8").splitlines()
    ):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        values[name] = value
    return values


def test_module_runtime_mineru_is_required_internal_gpu0_authority() -> None:
    compose = _load("m1/deploy/compose.runtime.yml")
    mineru = compose["services"]["m1-mineru"]

    assert "profiles" not in mineru
    assert mineru["image"] == "${M1_MINERU_IMAGE:?M1_MINERU_IMAGE is required}"
    assert "ports" not in mineru
    assert mineru["expose"] == ["8000"]
    environment = _environment(mineru)
    assert environment["MINERU_MODEL_SOURCE"] == "local"
    assert environment["MINERU_API_MAX_CONCURRENT_REQUESTS"] == "1"
    assert environment["CUDA_VISIBLE_DEVICES"] == "0"
    assert environment["NVIDIA_VISIBLE_DEVICES"] == "${M1_PARSER_GPU_ID:-0}"
    assert mineru["user"] == "10001:10001"
    assert mineru["read_only"] is True
    assert mineru["cap_drop"] == ["ALL"]
    assert mineru["security_opt"] == ["no-new-privileges:true"]
    assert "ipc" not in mineru
    assert mineru["shm_size"] == "32gb"
    assert mineru["tmpfs"] == [
        "/tmp:size=1g,mode=1777,nodev,nosuid",
        "/tmp/mineru-cache:size=${M1_MINERU_CACHE_TMPFS_SIZE:-8g},mode=1777,nodev,nosuid,exec",
        "/tmp/mineru-api-output:size=${M1_MINERU_OUTPUT_TMPFS_SIZE:-4g},mode=1770,uid=10001,gid=10001,nodev,nosuid,noexec",
    ]
    devices = mineru["deploy"]["resources"]["reservations"]["devices"]
    assert devices[0]["device_ids"] == ["${M1_PARSER_GPU_ID:-0}"]
    assert mineru["healthcheck"]["test"][-1] == "http://localhost:8000/health"
    assert "pipeline" not in " ".join(mineru["command"])

    m1_environment = _environment(compose["services"]["m1"])
    assert m1_environment["MINERU_SHADOW_ENABLED"].endswith(":-true}")
    assert m1_environment["MINERU_SHADOW_REQUIRED"].endswith(":-true}")
    assert "MINERU_AUTHORITY_MODE" not in m1_environment
    assert m1_environment["MINERU_BASE_URL"] == "http://m1-mineru:8000"
    assert m1_environment["MINERU_BACKEND"] == "vlm-engine"
    assert m1_environment["MINERU_VERSION"] == "3.4.4"
    assert m1_environment["MINERU_MODEL_REVISION"] == (
        "bff20d4ae2bf202df9f45284b4d43681555a97ed"
    )
    assert m1_environment["MINERU_MAX_CONCURRENCY"] == "1"
    assert m1_environment["MINERU_DOCUMENT_CIRCUIT_FAILURES"].endswith(":-3}")
    assert m1_environment["MINERU_DOCUMENT_CIRCUIT_SECONDS"].endswith(":-300}")
    for name in (
        "MINERU_MAPPER_BASE_URL",
        "MINERU_MAPPER_API_KEY",
        "MINERU_MAPPER_MODEL",
    ):
        assert name in m1_environment
    assert m1_environment["MINERU_MAPPER_BASE_URL"].startswith(
        "${M1_MINERU_MAPPER_BASE_URL:?"
    )
    assert m1_environment["MINERU_MAPPER_MODEL"].startswith(
        "${M1_MINERU_MAPPER_MODEL:?"
    )
    assert m1_environment["MINERU_MAPPER_API_KEY"] == (
        "${M1_MINERU_MAPPER_API_KEY:-}"
    )
    assert m1_environment["MINERU_MAPPER_TIMEOUT_SECONDS"].endswith(":-60}")
    assert m1_environment["MINERU_DRAWING_REGION_VLM_BASE_URL"].startswith(
        "${M1_MINERU_DRAWING_REGION_VLM_BASE_URL:?"
    )
    assert m1_environment["MINERU_DRAWING_REGION_VLM_MODEL"].startswith(
        "${M1_MINERU_DRAWING_REGION_VLM_MODEL:?"
    )
    assert m1_environment["MINERU_DRAWING_REGION_VLM_API_KEY"] == (
        "${M1_MINERU_DRAWING_REGION_VLM_API_KEY:-}"
    )
    assert m1_environment[
        "MINERU_DRAWING_REGION_VLM_REQUEST_TIMEOUT_SECONDS"
    ].endswith(":-30}")
    assert m1_environment[
        "MINERU_DRAWING_REGION_VLM_ASSET_TIMEOUT_SECONDS"
    ].endswith(":-180}")
    assert m1_environment["VLM_BASE_URL"].startswith("${VLM_BASE_URL:?")
    assert m1_environment["VLM_MODEL"].startswith("${VLM_MODEL:?")
    assert m1_environment["VLM_TIMEOUT_SECONDS"].endswith(":-300}")
    assert compose["services"]["m1"]["depends_on"]["m1-mineru"] == {
        "condition": "service_healthy",
        "required": True,
    }


def test_module_build_compose_does_not_require_runtime_image_variables() -> None:
    compose = _load("m1/deploy/compose.build.yml")

    for service_name in ("m1", "m1-mineru"):
        service = compose["services"][service_name]
        assert "build" in service
        assert "image" not in service


def test_local_compose_is_only_a_canonical_fragment_wrapper() -> None:
    compose = _load("m1/docker-compose.yml")

    assert set(compose) == {"include"}
    assert compose["include"] == [
        {
            "path": [
                "./deploy/compose.runtime.yml",
                "./deploy/compose.build.yml",
                "./deploy/compose.dev.yml",
            ]
        }
    ]
    runtime = _load("m1/deploy/compose.runtime.yml")
    assert runtime["services"]["m1"]["environment"][0] == (
        "DATABASE_URL=sqlite+aiosqlite:////app/data/m1.db"
    )
    assert runtime["services"]["m1"]["depends_on"]["m1-knowledge-migrate"] == {
        "condition": "service_completed_successfully",
        "required": True,
    }


def test_module_env_documents_mineru_as_a_release_catalog_variable() -> None:
    lines = (_repository() / "m1/.env.example").read_text(encoding="utf-8").splitlines()

    assert "M1_MINERU_IMAGE=" in lines


def test_mineru_mapper_and_drawing_vlm_examples_use_independent_models() -> None:
    expected = {
        "VLM_BASE_URL": "http://host.docker.internal:18086/v1",
        "VLM_MODEL": "Qwen/Qwen2.5-VL-7B-Instruct",
        "VLM_TIMEOUT_SECONDS": "300",
        "M1_MINERU_MAPPER_BASE_URL": "http://host.docker.internal:18085/v1",
        "M1_MINERU_MAPPER_MODEL": "qwen3.6-35b-a3b-fp8-gpu0-200k",
        "M1_MINERU_MAPPER_TIMEOUT_SECONDS": "60",
        "M1_MINERU_DRAWING_REGION_VLM_BASE_URL": (
            "http://host.docker.internal:18086/v1"
        ),
        "M1_MINERU_DRAWING_REGION_VLM_MODEL": "Qwen/Qwen2.5-VL-7B-Instruct",
        "M1_MINERU_DRAWING_REGION_VLM_REQUEST_TIMEOUT_SECONDS": "30",
        "M1_MINERU_DRAWING_REGION_VLM_ASSET_TIMEOUT_SECONDS": "180",
    }

    for relative_path in (
        "m1/.env.example",
        "deploy/source-runtime/deploy.env.example",
    ):
        values = _dotenv(relative_path)
        assert {name: values[name] for name in expected} == expected
        assert values["VLM_API_KEY"] == ""
        assert values["M1_MINERU_MAPPER_API_KEY"] == ""
        assert values["M1_MINERU_DRAWING_REGION_VLM_API_KEY"] == ""
        assert (
            values["M1_MINERU_MAPPER_BASE_URL"]
            != values["M1_MINERU_DRAWING_REGION_VLM_BASE_URL"]
        )
        assert (
            values["M1_MINERU_MAPPER_MODEL"]
            != values["M1_MINERU_DRAWING_REGION_VLM_MODEL"]
        )


def test_legacy_m1_runtime_overlays_are_removed() -> None:
    repository = _repository()

    assert not (repository / "deploy/source-runtime/compose.m1-full-gpu.yml").exists()
    assert not (
        repository / "deploy/source-runtime/compose.m1-cpu-rollback.yml"
    ).exists()
    deployer = (repository / "deploy/source-runtime/deploy.sh").read_text(
        encoding="utf-8"
    )
    assert "cpu-rollback" not in deployer
    assert "M1_RUNTIME_PROFILE" not in deployer


def test_module_runtime_mineru_is_always_enabled_and_dev_exposes_loopback() -> None:
    runtime = _load("m1/deploy/compose.runtime.yml")
    mineru = runtime["services"]["m1-mineru"]
    assert "profiles" not in mineru
    assert mineru["image"] == "${M1_MINERU_IMAGE:?M1_MINERU_IMAGE is required}"
    dev = _load("m1/deploy/compose.dev.yml")
    dev_environment = _environment(dev["services"]["m1"])
    assert dev_environment["MINERU_SHADOW_ENABLED"].endswith(":-true}")
    assert dev_environment["MINERU_SHADOW_REQUIRED"].endswith(":-true}")
    assert "MINERU_AUTHORITY_MODE" not in dev_environment
    assert dev_environment["MINERU_DRAWING_REGION_VLM_BASE_URL"] == (
        "${MINERU_DRAWING_REGION_VLM_BASE_URL:-"
        "${M1_MINERU_DRAWING_REGION_VLM_BASE_URL}}"
    )
    assert dev_environment["MINERU_DRAWING_REGION_VLM_MODEL"] == (
        "${MINERU_DRAWING_REGION_VLM_MODEL:-${M1_MINERU_DRAWING_REGION_VLM_MODEL}}"
    )
    assert dev_environment["MINERU_DRAWING_REGION_VLM_API_KEY"] == (
        "${MINERU_DRAWING_REGION_VLM_API_KEY:-"
        "${M1_MINERU_DRAWING_REGION_VLM_API_KEY:-}}"
    )
    assert dev_environment["MINERU_MAPPER_BASE_URL"] == (
        "${MINERU_MAPPER_BASE_URL:-${M1_MINERU_MAPPER_BASE_URL}}"
    )
    assert dev_environment["MINERU_MAPPER_MODEL"] == (
        "${MINERU_MAPPER_MODEL:-${M1_MINERU_MAPPER_MODEL}}"
    )
    assert dev_environment["MINERU_MAPPER_API_KEY"] == (
        "${MINERU_MAPPER_API_KEY:-${M1_MINERU_MAPPER_API_KEY:-}}"
    )
    assert dev_environment["MINERU_MAPPER_TIMEOUT_SECONDS"] == (
        "${MINERU_MAPPER_TIMEOUT_SECONDS:-"
        "${M1_MINERU_MAPPER_TIMEOUT_SECONDS:-60}}"
    )
    assert dev_environment["VLM_TIMEOUT_SECONDS"] == (
        "${VLM_TIMEOUT_SECONDS:-300}"
    )
    assert dev["services"]["m1-mineru"]["ports"] == [
        "127.0.0.1:${M1_MINERU_DEV_PORT:-8000}:8000"
    ]


def test_module_runtime_keeps_paddlex_cache_writable_and_models_read_only() -> None:
    compose = _load("m1/deploy/compose.runtime.yml")
    service = compose["services"]["m1"]
    environment = _environment(service)

    assert environment["PADDLE_PDX_CACHE_HOME"] == "/app/data/paddlex"
    assert environment["PP_STRUCTURE_MODEL_ROOT"] == "/app/data/paddlex"
    assert environment["PADDLEOCR_VL_MODEL_ROOT"] == "/app/data/paddlex"

    volumes = service["volumes"]
    assert any(
        value.get("target") == "/app/data/paddlex/official_models"
        and value.get("read_only") is True
        for value in volumes
        if isinstance(value, dict)
    )
    assert any(
        value.get("target") == "/app/data/paddlex/document-parser-models.json"
        and value.get("read_only") is True
        for value in volumes
        if isinstance(value, dict)
    )


def test_full_authority_runtime_omits_removed_legacy_pipeline_settings() -> None:
    runtime = _environment(_load("m1/deploy/compose.runtime.yml")["services"]["m1"])
    dev = _load("m1/deploy/compose.dev.yml")["services"]["m1"]["environment"]
    removed_exact = {
        "MINERU_AUTHORITY_MODE",
        "SEMANTIC_ENRICHMENT_DEFAULT",
        "STRUCTURED_LLM_BACKEND",
    }
    removed_prefixes = (
        "DOCUMENT_VERIFIER_",
        "TABULAR_SCHEMA_INTERPRETER_",
        "OCR_",
    )
    for environment in (runtime, dev):
        assert removed_exact.isdisjoint(environment)
        assert not any(name.startswith(removed_prefixes) for name in environment)
        assert "TABULAR_LAYOUT_ROUTER_ENABLED" in environment


def test_runtime_secret_interpolation_has_no_committed_password_fallbacks() -> None:
    text = (_repository() / "m1/deploy/compose.runtime.yml").read_text(encoding="utf-8")
    assert "replace-me-before-deploy" not in text
    assert "local-internal-only" not in text
    # PostgreSQL ownership and bootstrap secrets moved to the shared platform
    # compose; M1 consumes required role-scoped URLs instead of passwords.
    assert "M1_POSTGRES_APP_PASSWORD" not in text
    assert "M1_POSTGRES_ADMIN_PASSWORD" not in text
    for variable in (
        "M1_NEO4J_PASSWORD",
        "M1_LIGHTRAG_POSTGRES_PASSWORD",
        "M1_LIGHTRAG_NEO4J_PASSWORD",
        "M1_LIGHTRAG_API_KEY",
        "M1_LIGHTRAG_LLM_API_KEY",
        "M1_ENHANCED_PREFLIGHT_API_KEY",
    ):
        assert f"{variable}:-}}" in text


def test_runtime_enhancement_switches_are_outer_configurable_and_on_by_default() -> (
    None
):
    environment = _environment(_load("m1/deploy/compose.runtime.yml")["services"]["m1"])
    expected = {
        "KNOWLEDGE_EMBEDDINGS_ENABLED": "${M1_KNOWLEDGE_EMBEDDINGS_ENABLED:-true}",
        "DOCLING_ENABLED": "${M1_DOCLING_ENABLED:-true}",
        "LIGHTRAG_SHADOW_ENABLED": "${M1_LIGHTRAG_SHADOW_ENABLED:-true}",
        "PADDLEOCR_VL_ENABLED": "${M1_PADDLEOCR_VL_ENABLED:-true}",
        "PP_STRUCTURE_ENABLED": "${M1_PP_STRUCTURE_ENABLED:-true}",
    }

    assert {name: environment[name] for name in expected} == expected


def test_build_compose_keeps_runtime_images_out_of_build_services() -> None:
    build = _load("m1/deploy/compose.build.yml")
    runtime = _load("m1/deploy/compose.runtime.yml")

    assert "image" not in build["services"]["m1"]
    assert "image" not in build["services"]["m1-mineru"]
    assert build["services"]["m1"]["build"]
    assert build["services"]["m1-mineru"]["build"]
    assert runtime["services"]["m1"]["image"] == ("${M1_IMAGE:?M1_IMAGE is required}")
    assert runtime["services"]["m1-mineru"]["image"] == (
        "${M1_MINERU_IMAGE:?M1_MINERU_IMAGE is required}"
    )


def test_module_environment_covers_every_m1_runtime_variable() -> None:
    repository = _repository()
    runtime_text = (repository / "m1/deploy/compose.runtime.yml").read_text(
        encoding="utf-8"
    )
    runtime_variables = set(re.findall(r"\$\{(M1_[A-Z0-9_]+)", runtime_text))
    environment_lines = (
        (repository / "m1/.env.example").read_text(encoding="utf-8").splitlines()
    )
    environment_variables = {
        line.split("=", 1)[0]
        for line in environment_lines
        if re.fullmatch(r"[A-Z0-9_]+=.*", line)
    }

    assert runtime_variables <= environment_variables
    assert "M1_MINERU_IMAGE=" in environment_lines
    assert "M1_POSTGRES_IMAGE=" in environment_lines
    assert "M1_NEO4J_IMAGE=" in environment_lines


def test_source_runtime_deployer_enables_tracking_migration_profile() -> None:
    deployer = (_repository() / "deploy/source-runtime/deploy.sh").read_text(
        encoding="utf-8"
    )
    compose_library = (
        _repository() / "deploy/source-runtime/compose-lib.sh"
    ).read_text(encoding="utf-8")

    assert 'source "$script_dir/compose-lib.sh"' in deployer
    assert "append_yunpai_runtime_profiles compose" in deployer
    assert 'case "${TRACKING_MODE:-off}" in' in compose_library
    assert "shadow|strict)" in compose_library
    assert "selected_compose+=(--profile tracking-migrate)" in compose_library
    assert "cpu-rollback" not in deployer
