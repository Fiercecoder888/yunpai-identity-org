"""Black-box upload coverage for every format accepted by ``/ingest/sync``.

These tests intentionally enter through FastAPI's multipart boundary. They use
the real parser router, full-authority workflow, and SQLite persistence while
replacing only the external MinerU/Instructor boundary with a deterministic fake.
"""

from __future__ import annotations

import copy
import hashlib
import io
import zipfile
from collections.abc import Callable, Iterator
from pathlib import Path
from types import SimpleNamespace

import m1.deps as deps_module
import pytest
from fastapi.testclient import TestClient
from m1.api import main as api_main
from m1.deps import WorkflowDeps
from m1.parsers import ParserRouter
from m1.schemas import ExtractedField, ExtractionResult


class _LocalVLM:
    """Compatibility dependency that the full-authority workflow must not call."""

    model = "fixture-vlm"

    def __init__(self) -> None:
        self.calls: list[dict[str, str]] = []

    async def extract(self, *, file_path, context: str = "", doc_type: str = "drawing"):
        self.calls.append(
            {
                "file_path": str(file_path),
                "context": context,
                "doc_type": doc_type,
            }
        )
        return ExtractionResult(
            fields=[
                ExtractedField(
                    name="title_block.drawing_number", value="HTTP-MATRIX-001"
                ),
                ExtractedField(name="title_block.drawing_name", value="Upload fixture"),
            ],
            raw_text='{"fixture":"local-vlm"}',
            bom=[
                {
                    "index": 1,
                    "code": "PART-HTTP-1",
                    "name": "Fixture part",
                    "quantity": 1,
                    "unit": "pcs",
                }
            ],
        )


class _Candidate:
    def __init__(self, payload: dict) -> None:
        self.payload = payload

    def model_dump(self, *, mode: str) -> dict:
        assert mode == "json"
        return copy.deepcopy(self.payload)


class _LocalMinerURunner:
    """Return one evidence-backed candidate for every normalized source kind."""

    authority_mode = "full"

    async def run_candidate(self, **kwargs):
        payload = copy.deepcopy(kwargs["authoritative"])
        file_type = str(kwargs["file_type"])
        metadata = payload.setdefault("extraction", {}).setdefault("metadata", {})
        metadata.update(
            {
                "evidence_complete": True,
                "fixture_file_type": file_type,
            }
        )
        if file_type in {"xlsx", "xlsm", "xls", "csv"}:
            payload.update(
                {
                    "document_type": "order",
                    "document_subtype": "supplier_purchase_order",
                    "header": {"order_number": "TX2607150002"},
                    "lines": [
                        {
                            "line_id": "fixture-line-1",
                            "line_no": 1,
                            "product_code": "M-HTTP-1",
                            "name_raw": "DP cable",
                            "quantity": "2",
                            "unit": "PCS",
                        }
                    ],
                    "field_meta": {
                        "$.header.order_number": {
                            "confidence": 0.99,
                            "source_refs": [{"sheet": "Order", "cell": "B2"}],
                        },
                        "$.lines[0].product_code": {
                            "confidence": 0.99,
                            "source_refs": [{"sheet": "Order", "cell": "B5"}],
                        },
                        "$.lines[0].quantity": {
                            "confidence": 0.99,
                            "source_refs": [{"sheet": "Order", "cell": "E5"}],
                        },
                    },
                }
            )
        elif file_type in {"image", "dxf", "dwg"}:
            payload.update(
                {
                    "document_type": "technical_document",
                    "document_subtype": "approval_drawing",
                    "header": {"drawing_number": "HTTP-MATRIX-001"},
                    "field_meta": {
                        "$.header.drawing_number": {
                            "confidence": 0.99,
                            "source_refs": [
                                {
                                    "page": 1,
                                    "bbox": [1, 1, 20, 10],
                                    "coordinate_space": "pixels",
                                }
                            ],
                        }
                    },
                }
            )
        else:
            payload.update(
                {
                    "document_type": "technical_document",
                    "document_subtype": "product_specification",
                }
            )
        return SimpleNamespace(
            document=_Candidate(payload),
            summary={
                "status": "completed",
                "pipeline": "mineru_instructor",
                "instructor_complete": True,
            },
        )


@pytest.fixture
def upload_api(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Iterator[tuple[TestClient, _LocalVLM, Path]]:
    """Run a clean app with real workflow components and a private SQLite DB."""

    upload_dir = tmp_path / "uploads"
    database_path = tmp_path / "upload-matrix.db"
    local_vlm = _LocalVLM()
    deps = WorkflowDeps(
        parser_router=ParserRouter(),
        vlm_agent=local_vlm,
        confidence_threshold=0.9,
        mineru_shadow_runner=_LocalMinerURunner(),
    )

    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: SimpleNamespace(
            accepted=True,
            summary=lambda: {"passed": True, "reasons": []},
        ),
    )

    monkeypatch.setattr(deps_module, "_deps", deps)
    monkeypatch.setattr(
        api_main.settings,
        "database_url",
        f"sqlite+aiosqlite:///{database_path.as_posix()}",
    )
    monkeypatch.setattr(api_main.settings, "upload_dir", str(upload_dir))
    monkeypatch.setattr(api_main.settings, "vlm_api_key", "")
    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(api_main.settings, "max_concurrent", 4)
    monkeypatch.setattr(api_main, "store", None)
    monkeypatch.setattr(api_main, "engine", None)
    monkeypatch.setattr(api_main, "_processing_semaphore", None)
    api_main._task_registry.clear()

    with TestClient(api_main.create_app()) as client:
        yield client, local_vlm, upload_dir

    # Explicitly clear module globals so a later app cannot reuse a closed store
    # or an event-loop-bound semaphore.  Lifespan shutdown has already closed DB.
    api_main.store = None
    api_main.engine = None
    api_main._processing_semaphore = None
    api_main._task_registry.clear()


def _order_workbook_bytes() -> bytes:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Order"
    sheet["A1"] = "采购订单"
    sheet["A2"] = "订单号"
    sheet["B2"] = "TX2607150002"
    for column, value in enumerate(
        ["序号", "型号", "名称", "规格", "数量", "单位"], start=1
    ):
        sheet.cell(4, column, value)
    for column, value in enumerate(
        [1, "M-HTTP-1", "DP1.4 8K60Hz cable", "1M", 2, "PCS"], start=1
    ):
        sheet.cell(5, column, value)
    output = io.BytesIO()
    workbook.save(output)
    workbook.close()
    return output.getvalue()


def _macro_enabled_workbook_bytes() -> bytes:
    """Create a macro-enabled OOXML package without embedding executable VBA.

    XLSM identity comes from the package content type, not the caller-supplied
    suffix.  A macro-enabled workbook is allowed to contain no VBA project, which
    gives this test a safe, content-authentic fixture instead of renaming XLSX.
    """

    xlsx_payload = _order_workbook_bytes()
    source = io.BytesIO(xlsx_payload)
    output = io.BytesIO()
    with zipfile.ZipFile(source, "r") as reader, zipfile.ZipFile(output, "w") as writer:
        for info in reader.infolist():
            payload = reader.read(info.filename)
            if info.filename == "[Content_Types].xml":
                payload = payload.replace(
                    b"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
                    b"application/vnd.ms-excel.sheet.macroEnabled.main+xml",
                )
            writer.writestr(info, payload)
    return output.getvalue()


def _csv_bytes() -> bytes:
    return (
        "采购订单,,,,,\r\n"
        "订单号,TX2607150002,,,,\r\n"
        "序号,型号,名称,规格,数量,单位\r\n"
        "1,M-HTTP-CSV,DP1.4 cable,2M,3,PCS\r\n"
    ).encode("utf-8-sig")


def _pdf_bytes() -> bytes:
    fitz = pytest.importorskip("fitz")
    document = fitz.open()
    page = document.new_page(width=420, height=300)
    page.insert_text((40, 60), "M1 upload matrix PDF")
    page.insert_text((40, 90), "Model: PDF-HTTP-1  Quantity: 4")
    payload = document.tobytes()
    document.close()
    return payload


def _docx_bytes() -> bytes:
    docx = pytest.importorskip("docx")
    document = docx.Document()
    document.add_heading("M1 upload matrix DOCX", level=1)
    document.add_paragraph("Product specification DOCX-HTTP-1")
    table = document.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Model"
    table.cell(0, 1).text = "Quantity"
    table.cell(1, 0).text = "DOCX-HTTP-1"
    table.cell(1, 1).text = "5"
    output = io.BytesIO()
    document.save(output)
    return output.getvalue()


def _image_bytes(image_format: str) -> bytes:
    image_module = pytest.importorskip("PIL.Image")
    image = image_module.new("RGB", (32, 24), color=(32, 96, 160))
    output = io.BytesIO()
    image.save(output, format=image_format)
    return output.getvalue()


def _dxf_bytes() -> bytes:
    ezdxf = pytest.importorskip("ezdxf")
    document = ezdxf.new("R2010")
    document.modelspace().add_text("DXF-HTTP-1")
    output = io.StringIO()
    document.write(output)
    return output.getvalue().encode("utf-8")


def _dwg_placeholder_bytes() -> bytes:
    # ParserRouter intentionally treats an AC10 signature as DWG and emits a
    # reviewable conversion context before the local VLM projection.
    return b"AC1027\x00HTTP-MATRIX-DWG"


_FORMAT_CASES: tuple[tuple[str, str, Callable[[], bytes], str, str], ...] = (
    (
        "xlsx",
        "order.xlsx",
        _order_workbook_bytes,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "xlsx",
    ),
    (
        "xlsm",
        "order.xlsm",
        _macro_enabled_workbook_bytes,
        "application/vnd.ms-excel.sheet.macroEnabled.12",
        "xlsm",
    ),
    ("csv", "order.csv", _csv_bytes, "text/csv", "csv"),
    ("pdf", "specification.pdf", _pdf_bytes, "application/pdf", "pdf"),
    (
        "docx",
        "specification.docx",
        _docx_bytes,
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "docx",
    ),
    ("png", "drawing.png", lambda: _image_bytes("PNG"), "image/png", "image"),
    (
        "jpeg",
        "drawing.jpeg",
        lambda: _image_bytes("JPEG"),
        "image/jpeg",
        "image",
    ),
    (
        "webp",
        "drawing.webp",
        lambda: _image_bytes("WEBP"),
        "image/webp",
        "image",
    ),
    ("dxf", "drawing.dxf", _dxf_bytes, "image/vnd.dxf", "dxf"),
    (
        "dwg",
        "drawing.dwg",
        _dwg_placeholder_bytes,
        "image/vnd.dwg",
        "dwg",
    ),
)


@pytest.mark.parametrize(
    ("case_id", "filename", "payload_factory", "content_type", "expected_file_type"),
    _FORMAT_CASES,
    ids=[case[0] for case in _FORMAT_CASES],
)
def test_ingest_sync_supported_format_matrix_returns_persisted_v2(
    upload_api: tuple[TestClient, _LocalVLM, Path],
    case_id: str,
    filename: str,
    payload_factory: Callable[[], bytes],
    content_type: str,
    expected_file_type: str,
) -> None:
    client, local_vlm, _upload_dir = upload_api
    payload = payload_factory()

    response = client.post(
        "/ingest/sync",
        files={"file": (filename, payload, content_type)},
        data={"semantic_enrichment": "false"},
    )

    assert response.status_code == 200, (case_id, response.text)
    body = response.json()
    assert body["sync_complete"] is True, (case_id, body)
    assert body["status"] in {"done", "needs_review"}, (case_id, body)
    assert body["file_type"] == expected_file_type, (case_id, body)
    assert body["document_schema_version"] == "m1.document.v2"
    document = body["document"]
    assert document["schema_version"] == "m1.document.v2"
    assert document["source"]["original_filename"] == filename
    assert document["source"]["sha256"] == hashlib.sha256(payload).hexdigest()
    extraction = document["extraction"]
    adapter = extraction.get("adapter") or (extraction.get("metadata") or {}).get(
        "adapter"
    )
    assert adapter, (case_id, extraction)

    persisted = client.get(f"/tasks/{body['task_id']}/document")
    assert persisted.status_code == 200, (case_id, persisted.text)
    assert persisted.json() == document

    assert local_vlm.calls == []
    assert adapter == "mineru_llm_full_authority"
    if expected_file_type in {"image", "dxf", "dwg"}:
        assert document["header"]["drawing_number"] == "HTTP-MATRIX-001"
    else:
        assert extraction["compatibility_result"]

    if expected_file_type in {"xlsx", "xlsm", "csv"}:
        assert document["lines"], (case_id, document)


@pytest.mark.parametrize(
    ("filename", "payload_factory", "declared_type", "expected_file_type"),
    [
        pytest.param(
            "image-disguised-as.pdf",
            lambda: _image_bytes("PNG"),
            "application/pdf",
            "image",
            id="png-named-pdf",
        ),
        pytest.param(
            "workbook-disguised-as.jpg",
            _order_workbook_bytes,
            "image/jpeg",
            "xlsx",
            id="xlsx-named-jpeg",
        ),
    ],
)
def test_ingest_sync_routes_by_magic_not_multipart_name_or_content_type(
    upload_api: tuple[TestClient, _LocalVLM, Path],
    filename: str,
    payload_factory: Callable[[], bytes],
    declared_type: str,
    expected_file_type: str,
) -> None:
    client, local_vlm, _upload_dir = upload_api
    payload = payload_factory()

    response = client.post(
        "/ingest/sync",
        files={"file": (filename, payload, declared_type)},
        data={"semantic_enrichment": "false"},
    )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["file_type"] == expected_file_type
    assert body["status"] in {"done", "needs_review"}
    assert body["document_schema_version"] == "m1.document.v2"
    assert body["document"]["source"]["original_filename"] == filename
    assert body["document"]["source"]["sha256"] == hashlib.sha256(payload).hexdigest()
    assert local_vlm.calls == []
    metadata = body["document"]["extraction"]["metadata"]
    assert metadata["adapter"] == "mineru_llm_full_authority"


def test_ingest_sync_rejects_unknown_binary_without_dispatching_or_persisting(
    upload_api: tuple[TestClient, _LocalVLM, Path],
) -> None:
    client, local_vlm, upload_dir = upload_api
    payload = b"MZ\x00\x01not-an-image-or-supported-document"

    response = client.post(
        "/ingest/sync",
        files={"file": ("malicious.jpg", payload, "image/jpeg")},
        data={"semantic_enrichment": "false"},
    )

    assert response.status_code == 415
    assert "Unsupported or damaged content" in response.json()["detail"]
    assert local_vlm.calls == []
    assert not [path for path in upload_dir.rglob("*") if path.is_file()]
    assert client.get("/tasks").json() == []


def test_ingest_sync_zip_auto_fanout_returns_parent_and_children_v2(
    upload_api: tuple[TestClient, _LocalVLM, Path],
) -> None:
    client, local_vlm, _upload_dir = upload_api
    workbook = _order_workbook_bytes()
    preview = _image_bytes("PNG")
    archive_buffer = io.BytesIO()
    with zipfile.ZipFile(
        archive_buffer, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        archive.writestr("orders/customer-order.xlsx", workbook)
        archive.writestr("drawings/preview.png", preview)
    archive_payload = archive_buffer.getvalue()

    response = client.post(
        "/ingest/sync",
        files={"file": ("mixed-documents.zip", archive_payload, "application/zip")},
        data={"semantic_enrichment": "false"},
    )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["sync_complete"] is True, body
    assert body["file_type"] == "batch"
    assert body["status"] in {"done", "needs_review"}
    assert body["poll_url"] == f"/batch/{body['task_id']}"
    assert body["child_count"] == 2
    assert len(body["child_ids"]) == 2
    assert body["document_schema_version"] == "m1.document.v2"
    assert body["document"]["schema_version"] == "m1.document.v2"
    assert body["document"]["document_type"] == "archive"
    assert body["document"]["document_subtype"] == "archive"
    assert body["document"]["source"]["original_filename"] == "mixed-documents.zip"
    assert (
        body["document"]["source"]["sha256"]
        == hashlib.sha256(archive_payload).hexdigest()
    )

    children = body["children"]
    assert {child["file_type"] for child in children} == {"xlsx", "image"}
    assert {child["status"] for child in children} <= {"done", "needs_review"}
    for child in children:
        assert child["parent_id"] == body["task_id"]
        assert child["document_schema_version"] == "m1.document.v2"
        detail_response = client.get(f"/tasks/{child['task_id']}")
        assert detail_response.status_code == 200
        detail = detail_response.json()
        assert detail["document"]["schema_version"] == "m1.document.v2"
        assert detail["document"]["source"]["archive_path"].startswith(
            "mixed-documents.zip!/"
        )
        persisted = client.get(f"/tasks/{child['task_id']}/document")
        assert persisted.status_code == 200
        assert persisted.json() == detail["document"]

    parent_document = client.get(f"/tasks/{body['task_id']}/document")
    assert parent_document.status_code == 200
    assert parent_document.json() == body["document"]
    batch = client.get(body["poll_url"])
    assert batch.status_code == 200
    batch_body = batch.json()
    assert batch_body["pending_count"] == 0
    assert batch_body["done_count"] == batch_body["child_count"] == 2
    assert local_vlm.calls == []
