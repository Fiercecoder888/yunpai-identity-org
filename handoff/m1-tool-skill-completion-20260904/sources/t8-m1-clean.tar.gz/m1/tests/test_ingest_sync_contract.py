from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from m1.api import ingest_routes
from m1.state import TaskState, TaskStatus


class _PendingStore:
    state: TaskState | None = None

    async def save(self, state: TaskState) -> None:
        self.state = state

    async def load(self, task_id: str) -> TaskState | None:
        if self.state is None or self.state.task_id != task_id:
            return None
        return self.state


def test_ingest_sync_timeout_returns_accepted_task_contract(
    tmp_path, monkeypatch
) -> None:
    store = _PendingStore()

    async def classify(_path) -> str:
        return "csv"

    async def wait_for_task(_task_id: str, *, timeout: float) -> None:
        assert timeout == 45.0
        raise asyncio.TimeoutError

    def spawn(state: TaskState) -> None:
        state.status = TaskStatus.PARSING
        state.processing_stage = "model_verification"

    monkeypatch.setattr(ingest_routes, "classify_staged_upload", classify)
    monkeypatch.setattr(ingest_routes.settings, "upload_dir", str(tmp_path))
    runtime = SimpleNamespace(
        engine=object(),
        store=store,
        _form_tenant=lambda _request, tenant_id: tenant_id or "default",
        _spawn=spawn,
        wait_for_task=wait_for_task,
    )
    app = FastAPI()
    ingest_routes.register_ingest_routes(app, runtime)

    with TestClient(app) as client:
        response = client.post(
            "/ingest/sync",
            files={"file": ("inventory.csv", b"sku,quantity\nA-1,2\n", "text/csv")},
            data={"semantic_enrichment": "false"},
        )

    assert response.status_code == 202
    assert response.headers["retry-after"] == "5"
    detail = response.json()
    assert detail == {
        "code": "M1_INGEST_ACCEPTED",
        "message": "Document processing continues asynchronously.",
        "task_id": store.state.task_id,
        "status": "parsing",
        "processing_stage": "model_verification",
        "sync_complete": False,
        "poll_url": f"/tasks/{store.state.task_id}",
    }
    assert "file_path" not in detail


def test_sync_terminal_guard_rejects_nonterminal_registry_race() -> None:
    state = TaskState(
        task_id="pending-task",
        status=TaskStatus.EXTRACTING,
        processing_stage="mineru_authority",
    )

    with pytest.raises(HTTPException) as captured:
        ingest_routes._require_sync_terminal(
            state,
            poll_url="/tasks/pending-task",
            timed_out=False,
        )

    assert captured.value.status_code == 409
    assert captured.value.detail["code"] == "M1_INGEST_SYNC_INCOMPLETE"
