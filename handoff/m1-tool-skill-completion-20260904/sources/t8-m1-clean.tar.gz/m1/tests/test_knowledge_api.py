from __future__ import annotations

import hashlib
import json
from collections.abc import Iterator
from pathlib import Path
from types import SimpleNamespace

import m1.deps as deps_module
import pytest
from fastapi.testclient import TestClient
from m1.api import main as api_main
from m1.deps import WorkflowDeps
from m1.knowledge.runtime import KnowledgeSyncIneligibleError
from m1.parsers import ParserRouter
from m1.state import TaskState, TaskStatus
from m1.workflow.engine import WorkflowEngine


class _ForbiddenExternalBoundary:
    """Raises if an API replay accidentally enters an OCR/VLM-like boundary."""

    model = "must-not-run"

    def __init__(self) -> None:
        self.calls = 0

    async def extract(self, **_kwargs):
        self.calls += 1
        raise AssertionError("backfill must not invoke VLM")


def _document(
    *,
    model: str,
    order_number: str,
    needs_review: bool = False,
) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": f"{order_number}.xlsx",
            "display_filename": f"orders/{order_number}.xlsx",
            "sha256": (order_number.encode().hex() + "0" * 64)[:64],
            "mime_type": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ),
            "size_bytes": 2048,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "API stocking order",
            "order_number": order_number,
            "buyer": "API Buyer",
            "supplier": "API Supplier",
        },
        "lines": [
            {
                "line_id": "1",
                "line_no": 1,
                "model": model,
                "product_code": f"P-{model}",
                "name_raw": f"{model} DP cable",
                "name_normalized": f"{model} DisplayPort cable",
                "full_product_name": f"{model} DisplayPort 8K cable 1m",
                "product_category": "cable",
                "quantity": 8,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 8},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B5"}],
            },
        },
        "validation_issues": (
            [
                {
                    "code": "ORDER_NUMBER_CONFLICT",
                    "severity": "warning",
                    "message": "historical order number requires review",
                    "paths": ["$.header.order_number"],
                }
            ]
            if needs_review
            else []
        ),
        "needs_review": needs_review,
    }


@pytest.fixture
def knowledge_api(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Iterator[tuple[TestClient, _ForbiddenExternalBoundary]]:
    database_path = tmp_path / "knowledge-api.db"
    external = _ForbiddenExternalBoundary()
    deps = WorkflowDeps(
        parser_router=ParserRouter(),
        vlm_agent=external,
        confidence_threshold=0.9,
    )

    monkeypatch.setattr(deps_module, "_deps", deps)
    monkeypatch.setattr(
        api_main.settings,
        "database_url",
        f"sqlite+aiosqlite:///{database_path.as_posix()}",
    )
    monkeypatch.setattr(api_main.settings, "knowledge_database_url", "")
    monkeypatch.setattr(api_main.settings, "knowledge_enabled", True)
    monkeypatch.setattr(api_main.settings, "knowledge_required", True)
    monkeypatch.setattr(api_main.settings, "knowledge_default_tenant_id", "default")
    monkeypatch.setattr(api_main.settings, "knowledge_default_tenant_name", "Default")
    monkeypatch.setattr(api_main.settings, "knowledge_auto_project", True)
    monkeypatch.setattr(api_main.settings, "graph_backend", "memory")
    monkeypatch.setattr(api_main.settings, "upload_dir", str(tmp_path / "uploads"))
    monkeypatch.setattr(api_main.settings, "vlm_api_key", "")
    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(api_main.settings, "tenant_api_key_hashes", "")
    monkeypatch.setattr(api_main.settings, "max_concurrent", 1)
    monkeypatch.setattr(api_main, "store", None)
    monkeypatch.setattr(api_main, "engine", None)
    monkeypatch.setattr(api_main, "knowledge_runtime", None)
    monkeypatch.setattr(api_main, "knowledge_init_error", "")
    monkeypatch.setattr(api_main, "_processing_semaphore", None)
    api_main._task_registry.clear()

    with TestClient(api_main.create_app()) as client:
        yield client, external

    api_main.store = None
    api_main.engine = None
    api_main.knowledge_runtime = None
    api_main.knowledge_init_error = ""
    api_main._processing_semaphore = None
    api_main._task_registry.clear()


def _create_tenant(client: TestClient, tenant_id: str) -> None:
    response = client.post(
        "/knowledge/tenants",
        headers={"X-Actor-Roles": "admin"},
        json={"tenant_id": tenant_id, "display_name": tenant_id.title()},
    )
    assert response.status_code == 200, response.text
    assert response.json()["tenant_id"] == tenant_id


def _seed_m1_document(
    client: TestClient,
    *,
    tenant_id: str,
    task_id: str,
    document: dict,
) -> None:
    assert api_main.store is not None
    # Deliberately disable the automatic sidecar for this one legacy record.
    # It must reach Wiki/Graph exclusively through /knowledge/backfill.
    api_main.store.set_document_sink(None)
    state = TaskState(
        task_id=task_id,
        tenant_id=tenant_id,
        file_path=f"C:/read-only/{task_id}.xlsx",
        original_filename=f"{task_id}.xlsx",
        file_type="xlsx",
        document=document,
        document_schema_version="m1.document.v2",
        status=TaskStatus.DONE,
        processing_stage="done",
        semantic_enrichment=False,
    )
    assert client.portal is not None
    client.portal.call(api_main.store.save, state)
    client.portal.call(api_main.store.save_document, task_id, document)


def test_reassess_endpoint_repairs_false_review_and_activates_knowledge(
    knowledge_api,
) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-reassess")
    document = _document(
        model="REASSESS-MODEL-1",
        order_number="REASSESS-ORDER-1",
        needs_review=False,
    )
    document["needs_review"] = True
    document["scored_result"] = {
        "task_id": "false-review-task",
        "fields": [
            {
                "name": "supplier.optional",
                "value": None,
                "confidence": 0.0,
                "needs_review": True,
            }
        ],
        "needs_review": True,
        "review_status": "needs_review",
    }
    assert api_main.store is not None
    assert client.portal is not None
    state = TaskState(
        task_id="false-review-task",
        tenant_id="tenant-reassess",
        file_path="C:/read-only/false-review.xlsx",
        original_filename="false-review.xlsx",
        file_type="xlsx",
        document=document,
        document_schema_version="m1.document.v2",
        status=TaskStatus.NEEDS_REVIEW,
        processing_stage="needs_review",
        semantic_enrichment=False,
    )
    client.portal.call(api_main.store.save, state)
    client.portal.call(api_main.store.save_document, state.task_id, document)

    headers = {
        "X-Tenant-ID": "tenant-reassess",
        "X-Actor-ID": "admin-1",
        "X-Actor-Roles": "admin",
    }
    preview = client.post(
        "/knowledge/reviews/reassess",
        headers=headers,
        json={"dry_run": True, "task_ids": [state.task_id]},
    )
    assert preview.status_code == 200, preview.text
    assert preview.json()["auto_approvable"] == 1
    assert (
        client.get(f"/tasks/{state.task_id}", headers=headers).json()["status"]
        == "needs_review"
    )

    applied = client.post(
        "/knowledge/reviews/reassess",
        headers=headers,
        json={"dry_run": False, "task_ids": [state.task_id]},
    )
    assert applied.status_code == 200, applied.text
    assert applied.json()["auto_approvable"] == 1
    assert (
        client.get(f"/tasks/{state.task_id}", headers=headers).json()["status"]
        == "done"
    )
    search = client.get(
        "/knowledge/search",
        headers=headers,
        params={"q": "REASSESS-MODEL-1"},
    )
    assert search.status_code == 200, search.text
    assert search.json()["hits"]
    assert external.calls == 0


def test_upload_tenant_form_must_match_header_and_cross_tenant_is_404(
    knowledge_api,
) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-a")
    payload = (
        "序号,型号,名称,规格,数量,单位\n1,TENANT-UPLOAD-1,DP1.4连接线,1M,2,PCS\n"
    ).encode("utf-8-sig")

    upload_shapes = {
        "/ingest": {"file": ("order.csv", payload, "text/csv")},
        "/ingest/sync": {"file": ("order.csv", payload, "text/csv")},
        "/ingest/batch": [("files", ("order.csv", payload, "text/csv"))],
        "/ingest/archive": {"file": ("orders.zip", payload, "application/zip")},
    }
    for endpoint, files in upload_shapes.items():
        mismatch = client.post(
            endpoint,
            headers={"X-Tenant-ID": "tenant-a"},
            files=files,
            data={"tenant_id": "default", "semantic_enrichment": "false"},
        )
        assert mismatch.status_code == 403, (endpoint, mismatch.text)
    assert client.get("/tasks", headers={"X-Tenant-ID": "tenant-a"}).json() == []

    accepted = client.post(
        "/ingest/sync",
        headers={"X-Tenant-ID": "tenant-a"},
        files={"file": ("order.csv", payload, "text/csv")},
        data={"tenant_id": "tenant-a", "semantic_enrichment": "false"},
    )
    assert accepted.status_code == 200, accepted.text
    body = accepted.json()
    assert body["tenant_id"] == "tenant-a"
    task_id = body["task_id"]
    assert external.calls == 0

    own = client.get(f"/tasks/{task_id}", headers={"X-Tenant-ID": "tenant-a"})
    assert own.status_code == 200
    assert own.json()["tenant_id"] == "tenant-a"
    assert client.get(f"/tasks/{task_id}").status_code == 404
    assert (
        client.post(
            f"/knowledge/tasks/{task_id}/sync",
            headers={"X-Tenant-ID": "default"},
        ).status_code
        == 404
    )
    default_tasks = client.get("/tasks").json()
    tenant_tasks = client.get("/tasks", headers={"X-Tenant-ID": "tenant-a"}).json()
    assert all(task["task_id"] != task_id for task in default_tasks)
    assert [task["task_id"] for task in tenant_tasks] == [task_id]


def test_knowledge_api_candidate_access_review_and_activation(knowledge_api) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-review")
    document = _document(
        model="API-CANDIDATE-1",
        order_number="API-CANDIDATE-ORDER",
        needs_review=True,
    )
    document["extraction"] = {
        "metadata": {
            "adapter": "mineru_llm_full_authority",
            "authority_mode": "full",
            "authority_selected": True,
        }
    }
    _seed_m1_document(
        client,
        tenant_id="tenant-review",
        task_id="candidate-task",
        document=document,
    )

    synced = client.post(
        "/knowledge/tasks/candidate-task/sync",
        headers={"X-Tenant-ID": "tenant-review"},
    )
    assert synced.status_code == 200, synced.text
    outcome = synced.json()
    assert outcome["projection"]["status"] == "candidate"
    assert external.calls == 0

    public_entities = client.get(
        "/knowledge/entities",
        headers={"X-Tenant-ID": "tenant-review"},
    )
    assert public_entities.status_code == 200
    assert all(
        item["lifecycle_status"] in {"active", "approved"}
        for item in public_entities.json()
    )
    assert (
        client.get(
            "/knowledge/entities",
            headers={"X-Tenant-ID": "tenant-review"},
            params={"lifecycle_status": "under_review"},
        ).status_code
        == 403
    )
    governed_entities = client.get(
        "/knowledge/entities",
        headers={
            "X-Tenant-ID": "tenant-review",
            "X-Actor-ID": "reviewer-1",
            "X-Actor-Roles": "reviewer",
        },
        params={"include_candidate": "true"},
    )
    assert governed_entities.status_code == 200
    candidate_entity = next(
        item
        for item in governed_entities.json()
        if item["lifecycle_status"] not in {"active", "approved"}
    )
    entity_url = f"/knowledge/entities/{candidate_entity['entity_id']}"
    assert (
        client.get(entity_url, headers={"X-Tenant-ID": "tenant-review"}).status_code
        == 404
    )
    assert (
        client.get(
            entity_url,
            headers={"X-Tenant-ID": "tenant-review"},
            params={"include_candidate": "true"},
        ).status_code
        == 403
    )
    assert (
        client.get(
            entity_url,
            headers={
                "X-Tenant-ID": "tenant-review",
                "X-Actor-ID": "reviewer-1",
                "X-Actor-Roles": "reviewer",
            },
            params={"include_candidate": "true"},
        ).status_code
        == 200
    )

    hidden = client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-review"},
        params={"q": "API-CANDIDATE-1"},
    )
    assert hidden.status_code == 200
    assert hidden.json()["hits"] == []
    forbidden = client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-review"},
        params={"q": "API-CANDIDATE-1", "include_candidate": "true"},
    )
    assert forbidden.status_code == 403
    staged = client.get(
        "/knowledge/search",
        headers={
            "X-Tenant-ID": "tenant-review",
            "X-Actor-ID": "reviewer-1",
            "X-Actor-Roles": "reviewer",
        },
        params={"q": "API-CANDIDATE-1", "include_candidate": "true"},
    )
    assert staged.status_code == 200
    assert staged.json()["hits"]
    assert all(
        hit["document"]["status"] == "candidate" for hit in staged.json()["hits"]
    )

    reviews = client.get(
        "/knowledge/reviews",
        headers={"X-Tenant-ID": "tenant-review", "X-Actor-Roles": "reviewer"},
    )
    assert reviews.status_code == 200
    document_review = next(
        task for task in reviews.json() if task["target_type"] == "document_version"
    )
    unsupported_review = next(
        task for task in reviews.json() if task["target_type"] != "document_version"
    )
    unsupported = client.post(
        f"/knowledge/reviews/{unsupported_review['review_task_id']}",
        headers={
            "X-Tenant-ID": "tenant-review",
            "X-Actor-ID": "reviewer-1",
            "X-Actor-Roles": "reviewer",
        },
        json={"decision": "correct", "reviewer_id": "spoofed-reviewer"},
    )
    assert unsupported.status_code == 422
    accepted = client.post(
        f"/knowledge/reviews/{document_review['review_task_id']}",
        headers={
            "X-Tenant-ID": "tenant-review",
            "X-Actor-ID": "reviewer-1",
            "X-Actor-Roles": "reviewer",
        },
        json={
            "decision": "accept",
            "reviewer_id": "spoofed-reviewer",
            "reason": "evidence checked",
        },
    )
    assert accepted.status_code == 200, accepted.text
    assert accepted.json()["decision"] == "accept"
    assert accepted.json()["reviewer_id"] == "reviewer-1"
    remaining_reviews = client.get(
        "/knowledge/reviews",
        headers={"X-Tenant-ID": "tenant-review", "X-Actor-Roles": "reviewer"},
    )
    assert remaining_reviews.status_code == 200
    assert remaining_reviews.json() == []

    active = client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-review"},
        params={"q": "API-CANDIDATE-1"},
    )
    assert active.status_code == 200
    assert active.json()["hits"]
    assert all(hit["document"]["status"] == "active" for hit in active.json()["hits"])
    assert (
        client.get("/knowledge/search", params={"q": "API-CANDIDATE-1"}).json()["hits"]
        == []
    )

    graph = client.get(
        f"/knowledge/graph/{outcome['document']['document_id']}",
        headers={"X-Tenant-ID": "tenant-review"},
        params={"version": "1"},
    )
    assert graph.status_code == 200
    assert all(node["status"] == "active" for node in graph.json()["nodes"])
    stats = client.get("/knowledge/stats", headers={"X-Tenant-ID": "tenant-review"})
    assert stats.status_code == 200
    stats_body = stats.json()
    assert stats_body["projections"]["graph_snapshots"]["by_status"] == {"active": 1}
    assert stats_body["inventory"]["task_version_bindings"] == {
        "total": 1,
        "by_status": {"active": 1},
    }
    assert stats_body["inventory"]["document_versions"]["total"] == 1
    assert stats_body["inventory"]["source_assets"]["total"] == 1
    outbox = stats_body["inventory"]["projection_outbox"]
    assert outbox["total"] >= 2
    assert any(
        key.startswith("graph:document_projection:")
        for key in outbox["by_projection_aggregate_status"]
    )


def test_review_idempotency_key_reuse_for_another_task_returns_409(
    knowledge_api,
) -> None:
    client, _external = knowledge_api
    tenant_id = "tenant-review-key"
    _create_tenant(client, tenant_id)
    headers = {
        "X-Tenant-ID": tenant_id,
        "X-Actor-ID": "reviewer-1",
        "X-Actor-Roles": "reviewer",
    }
    review_task_ids: list[str] = []
    for index in (1, 2):
        task_id = f"candidate-key-task-{index}"
        _seed_m1_document(
            client,
            tenant_id=tenant_id,
            task_id=task_id,
            document=_document(
                model=f"API-REVIEW-KEY-{index}",
                order_number=f"API-REVIEW-KEY-ORDER-{index}",
                needs_review=True,
            ),
        )
        synced = client.post(
            f"/knowledge/tasks/{task_id}/sync",
            headers={"X-Tenant-ID": tenant_id},
        )
        assert synced.status_code == 200, synced.text
        reviews = client.get("/knowledge/reviews", headers=headers)
        assert reviews.status_code == 200, reviews.text
        current = {
            review["review_task_id"]
            for review in reviews.json()
            if review["target_type"] == "document_version"
        }
        new_ids = current.difference(review_task_ids)
        assert len(new_ids) == 1
        review_task_ids.append(new_ids.pop())

    payload = {
        "decision": "accept",
        "reason": "evidence checked",
        "idempotency_key": "api-review-key-bound-to-one-task",
    }
    accepted = client.post(
        f"/knowledge/reviews/{review_task_ids[0]}",
        headers=headers,
        json=payload,
    )
    assert accepted.status_code == 200, accepted.text

    conflict = client.post(
        f"/knowledge/reviews/{review_task_ids[1]}",
        headers=headers,
        json=payload,
    )
    assert conflict.status_code == 409, conflict.text


def test_bulk_document_review_previews_then_resolves_derived_backlog(
    knowledge_api,
) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-bulk")
    for index in (1, 2):
        task_id = f"bulk-task-{index}"
        _seed_m1_document(
            client,
            tenant_id="tenant-bulk",
            task_id=task_id,
            document=_document(
                model=f"BULK-MODEL-{index}",
                order_number=f"BULK-ORDER-{index}",
                needs_review=True,
            ),
        )
        synced = client.post(
            f"/knowledge/tasks/{task_id}/sync",
            headers={"X-Tenant-ID": "tenant-bulk"},
        )
        assert synced.status_code == 200, synced.text

    headers = {
        "X-Tenant-ID": "tenant-bulk",
        "X-Actor-ID": "bulk-admin",
        "X-Actor-Roles": "admin",
    }
    preview = client.post(
        "/knowledge/reviews/bulk",
        headers=headers,
        json={"dry_run": True, "decision": "accept", "limit": 10},
    )
    assert preview.status_code == 200, preview.text
    assert preview.json()["selected"] == 2
    open_before = client.get("/knowledge/reviews", headers=headers).json()
    assert len(open_before) > 2

    applied = client.post(
        "/knowledge/reviews/bulk",
        headers=headers,
        json={
            "dry_run": False,
            "decision": "accept",
            "reason": "template and source evidence approved",
            "limit": 10,
            "max_concurrent": 2,
        },
    )
    assert applied.status_code == 200, applied.text
    assert applied.json()["decided"] == 2
    assert applied.json()["failed"] == 0
    assert client.get("/knowledge/reviews", headers=headers).json() == []
    for index in (1, 2):
        result = client.get(
            "/knowledge/search",
            headers=headers,
            params={"q": f"BULK-MODEL-{index}"},
        )
        assert result.status_code == 200
        assert result.json()["hits"]
    assert external.calls == 0


def test_backfill_replays_persisted_v2_without_ocr_or_vlm(knowledge_api) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-backfill")
    _seed_m1_document(
        client,
        tenant_id="tenant-backfill",
        task_id="legacy-task",
        document=_document(
            model="BACKFILL-MODEL-1",
            order_number="BACKFILL-ORDER-1",
        ),
    )

    result = client.post(
        "/knowledge/backfill",
        headers={
            "X-Tenant-ID": "tenant-backfill",
            "X-Actor-Roles": "reviewer",
        },
        json={"limit": 10},
    )
    assert result.status_code == 200, result.text
    body = result.json()
    assert body["tenant_id"] == "tenant-backfill"
    assert body["selected"] == 1
    assert body["synced"] == 1
    assert body["failed"] == 0
    assert body["failures"] == []
    assert external.calls == 0

    task = client.get("/tasks/legacy-task", headers={"X-Tenant-ID": "tenant-backfill"})
    assert task.status_code == 200
    assert task.json()["knowledge_sync_status"] == "synced"
    search = client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-backfill"},
        params={"q": "BACKFILL-MODEL-1"},
    )
    assert search.status_code == 200
    assert search.json()["hits"]

    replay = client.post(
        "/knowledge/backfill",
        headers={
            "X-Tenant-ID": "tenant-backfill",
            "X-Actor-Roles": "reviewer",
        },
        json={"limit": 10},
    )
    assert replay.status_code == 200
    assert replay.json()["synced"] == 0
    assert replay.json()["skipped"] == 1
    assert external.calls == 0


def test_full_authority_failure_never_enters_governed_knowledge(knowledge_api) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-mineru-failed")
    source = _document(
        model="MINERU-FAILED-MODEL",
        order_number="MINERU-FAILED-ORDER",
    )["source"]
    seed = {
        "schema_version": "m1.document.v2",
        "source": source,
        "document_type": "unknown",
        "document_subtype": "unknown",
        "header": {},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
        "extraction": {
            "metadata": {
                "adapter": "mineru_full_source_seed",
                "authority_mode": "full",
            }
        },
    }
    document = WorkflowEngine._mineru_full_failure_document(
        SimpleNamespace(file_type="pdf"),
        seed=seed,
        code="MINERU_FULL_AUTHORITY_FAILED",
        message="MinerU could not produce a validated authoritative document.",
        actual={"error_type": "RuntimeError"},
    )
    _seed_m1_document(
        client,
        tenant_id="tenant-mineru-failed",
        task_id="mineru-failed-task",
        document=document,
    )

    blocked = client.post(
        "/knowledge/tasks/mineru-failed-task/sync",
        headers={"X-Tenant-ID": "tenant-mineru-failed"},
    )
    assert blocked.status_code == 409, blocked.text

    assert api_main.store is not None
    assert api_main.knowledge_runtime is not None
    assert client.portal is not None

    async def sync_failed_document() -> None:
        assert api_main.knowledge_runtime is not None
        await api_main.knowledge_runtime.sync_document(
            tenant_id="tenant-mineru-failed",
            task_id="mineru-failed-task",
            document=document,
        )

    with pytest.raises(KnowledgeSyncIneligibleError):
        client.portal.call(sync_failed_document)

    async def mark_stale_synced() -> None:
        assert api_main.store is not None
        await api_main.store.update_knowledge_status(
            "mineru-failed-task",
            status="synced",
            document_id="old-document-version",
            version_id="old-version",
        )

    client.portal.call(mark_stale_synced)

    backfill = client.post(
        "/knowledge/backfill",
        headers={
            "X-Tenant-ID": "tenant-mineru-failed",
            "X-Actor-Roles": "reviewer",
        },
        json={"limit": 10},
    )
    assert backfill.status_code == 200, backfill.text
    assert backfill.json()["synced"] == 0
    assert backfill.json()["skipped"] == 1
    task = client.get(
        "/tasks/mineru-failed-task",
        headers={"X-Tenant-ID": "tenant-mineru-failed"},
    )
    assert task.status_code == 200
    assert task.json()["knowledge_sync_status"] == "skipped"
    assert task.json()["knowledge_sync_error"] == "MINERU_FULL_AUTHORITY_FAILED"

    api_main.store.set_document_sink(api_main._sync_document_to_knowledge)
    client.portal.call(
        api_main.store.save_document,
        "mineru-failed-task",
        document,
    )
    task_after_sink = client.get(
        "/tasks/mineru-failed-task",
        headers={"X-Tenant-ID": "tenant-mineru-failed"},
    )
    assert task_after_sink.status_code == 200
    assert task_after_sink.json()["knowledge_sync_status"] == "skipped"
    search = client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-mineru-failed"},
        params={"q": "MINERU-FAILED-MODEL"},
    )
    assert search.status_code == 200
    assert search.json()["hits"] == []
    assert external.calls == 0


def test_hashed_tenant_credentials_bind_tenant_and_roles(
    knowledge_api, monkeypatch: pytest.MonkeyPatch
) -> None:
    client, _external = knowledge_api
    _create_tenant(client, "tenant-bound-a")
    _create_tenant(client, "tenant-bound-b")
    _seed_m1_document(
        client,
        tenant_id="tenant-bound-a",
        task_id="bound-task-a",
        document=_document(model="BOUND-A", order_number="BOUND-ORDER-A"),
    )

    reader_key = "reader-key-for-test"
    admin_key = "admin-key-for-test"
    credentials = {
        hashlib.sha256(reader_key.encode()).hexdigest(): {
            "tenant_id": "tenant-bound-a",
            "actor_id": "reader-a",
            "roles": ["reader"],
        },
        hashlib.sha256(admin_key.encode()).hexdigest(): {
            "tenant_id": "tenant-bound-b",
            "actor_id": "admin-b",
            "roles": ["admin"],
        },
    }
    monkeypatch.setattr(
        api_main.settings,
        "tenant_api_key_hashes",
        json.dumps(credentials),
    )

    assert client.get("/tasks").status_code == 401
    own = client.get(
        "/tasks/bound-task-a",
        headers={"X-API-Key": reader_key, "X-Tenant-ID": "tenant-bound-a"},
    )
    assert own.status_code == 200
    assert (
        client.get(
            "/tasks/bound-task-a",
            headers={"X-API-Key": reader_key, "X-Tenant-ID": "tenant-bound-b"},
        ).status_code
        == 404
    )
    # Client-supplied role escalation is ignored once a credential binds roles.
    escalated = client.post(
        "/knowledge/tenants",
        headers={"X-API-Key": reader_key, "X-Actor-Roles": "admin"},
        json={"tenant_id": "forbidden", "display_name": "Forbidden"},
    )
    assert escalated.status_code == 403
    allowed = client.post(
        "/knowledge/tenants",
        headers={"X-API-Key": admin_key},
        json={"tenant_id": "created-by-admin", "display_name": "Created"},
    )
    assert allowed.status_code == 200


def test_delete_task_tombstones_knowledge_and_graph(knowledge_api) -> None:
    client, external = knowledge_api
    _create_tenant(client, "tenant-delete")
    _seed_m1_document(
        client,
        tenant_id="tenant-delete",
        task_id="delete-task",
        document=_document(
            model="DELETE-MODEL",
            order_number="DELETE-ORDER",
        ),
    )
    synced = client.post(
        "/knowledge/tasks/delete-task/sync",
        headers={"X-Tenant-ID": "tenant-delete"},
    )
    assert synced.status_code == 200, synced.text
    document_id = synced.json()["document"]["document_id"]
    assert client.get(
        "/knowledge/search",
        headers={"X-Tenant-ID": "tenant-delete"},
        params={"q": "DELETE-MODEL"},
    ).json()["hits"]

    deleted = client.delete(
        "/tasks/delete-task",
        headers={"X-Tenant-ID": "tenant-delete"},
    )
    assert deleted.status_code == 200, deleted.text
    assert deleted.json()["knowledge_tombstones"][0]["status"] == "tombstoned"
    assert (
        client.get(
            "/tasks/delete-task", headers={"X-Tenant-ID": "tenant-delete"}
        ).status_code
        == 404
    )
    assert (
        client.get(
            "/knowledge/search",
            headers={"X-Tenant-ID": "tenant-delete"},
            params={"q": "DELETE-MODEL"},
        ).json()["hits"]
        == []
    )
    assert (
        client.get(
            f"/knowledge/graph/{document_id}",
            headers={"X-Tenant-ID": "tenant-delete"},
        ).status_code
        == 404
    )
    assert external.calls == 0
