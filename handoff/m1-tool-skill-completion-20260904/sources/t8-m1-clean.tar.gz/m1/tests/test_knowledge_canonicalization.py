from __future__ import annotations

from copy import deepcopy

import pytest

from m1.knowledge.canonicalization import canonicalize_document
from m1.knowledge.schema import ClaimStatus, LifecycleStatus


def _document(
    *,
    document_type: str,
    document_subtype: str,
    sha: str = "a" * 64,
    header: dict | None = None,
    lines: list[dict] | None = None,
    field_meta: dict | None = None,
) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": f"{document_subtype}.xlsx",
            "display_filename": f"{document_subtype}.xlsx",
            "sha256": sha,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "sheet": "Sheet1",
        },
        "document_type": document_type,
        "document_subtype": document_subtype,
        "header": header or {},
        "lines": lines or [],
        "field_meta": field_meta or {},
        "validation_issues": [],
        "needs_review": False,
    }


def _entity(result, entity_type: str, *, label: str | None = None):
    matches = [item for item in result.entities if item.entity_type == entity_type]
    if label is not None:
        matches = [item for item in matches if item.canonical_label == label]
    assert len(matches) == 1
    return matches[0]


def test_order_generates_stable_scoped_entities_identities_aliases_and_evidence() -> None:
    source = _document(
        document_type="order",
        document_subtype="stocking_order",
        header={
            "title": "桐曦备货单",
            "issuer": "云派科技有限公司",
            "buyer": "桐曦有限公司",
            "supplier": "线材供应商有限公司",
            "order_number": "TX2607150002",
        },
        lines=[
            {
                "line_id": "Sheet1:6:1",
                "line_no": 1,
                "product_code": "YP-DP-001",
                "model": "DP-100",
                "name_raw": "DP 8K连接线 1米",
                "name_normalized": "DisplayPort 8K连接线 1m",
                "quantity": 800,
                "unit": "PCS",
                "custom_fields": {
                    "customer_product_code": "TX-DP-A",
                    "supplier_material_code": "SUP-CABLE-9",
                },
            }
        ],
        field_meta={
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "Q3"}],
            },
            "$.lines[0].product_code": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "C6"}],
            },
            "$.lines[0].quantity": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "Q6"}],
            },
        },
    )
    untouched = deepcopy(source)

    first = canonicalize_document(source, tenant_id="tenant-a")
    second = canonicalize_document(deepcopy(source), tenant_id="tenant-a")

    assert source == untouched
    assert first.source_record_id == second.source_record_id
    assert [item.entity_id for item in first.entities] == [
        item.entity_id for item in second.entities
    ]
    assert [item.identity_id for item in first.external_identities] == [
        item.identity_id for item in second.external_identities
    ]
    assert [item.idempotency_key for item in first.relationships] == [
        item.idempotency_key for item in second.relationships
    ]

    assert {item.entity_type for item in first.entities} >= {
        "document",
        "enterprise",
        "order",
        "product",
    }
    order = _entity(first, "order")
    product = _entity(first, "product")
    assert "stocking_order" in order.canonical_key
    assert "tx2607150002" in order.canonical_key
    assert "云派科技有限公司" in order.canonical_key
    assert order.lifecycle_status == LifecycleStatus.ACTIVE
    assert product.lifecycle_status == LifecycleStatus.ACTIVE

    customer = _entity(first, "enterprise", label="桐曦有限公司")
    supplier = _entity(first, "enterprise", label="线材供应商有限公司")
    customer_identity = next(
        item for item in first.external_identities if item.external_id == "TX-DP-A"
    )
    supplier_identity = next(
        item for item in first.external_identities if item.external_id == "SUP-CABLE-9"
    )
    assert customer.entity_id in customer_identity.source_system
    assert supplier.entity_id in supplier_identity.source_system
    assert customer_identity.status == ClaimStatus.ACCEPTED
    assert supplier_identity.status == ClaimStatus.ACCEPTED
    assert customer_identity.entity_id == product.entity_id
    assert supplier_identity.entity_id == product.entity_id

    contains = next(
        item for item in first.relationships if item.relation_type == "CONTAINS_PRODUCT"
    )
    assert contains.status == ClaimStatus.ACCEPTED
    assert contains.evidence_anchor_id
    assert contains.additional_evidence_anchor_ids
    assert contains.properties["source_path"] == "$.lines[0].product_code"
    assert contains.properties["source_refs"] == [{"sheet": "Sheet1", "cell": "C6"}]
    assert all("CAUSE" not in item.relation_type for item in first.relationships)
    assert all(not item.relation_type.startswith("CONFIRMED_") for item in first.relationships)

    other_tenant = canonicalize_document(deepcopy(source), tenant_id="tenant-b")
    assert _entity(other_tenant, "product").entity_id != product.entity_id


def test_enterprise_role_prefixes_merge_into_one_entity_and_union_roles() -> None:
    result = canonicalize_document(
        _document(
            document_type="order",
            document_subtype="purchase_contract",
            header={
                "issuer": "广西桐曦电子科技有限公司",
                "buyer": "甲方：广西桐曦电子科技有限公司",
                "seller": "乙 方:广西桐曦电子科技有限公司",
                "supplier": "供应商：广西桐曦电子科技有限公司",
            },
        ),
        tenant_id="tenant-a",
    )

    enterprise = _entity(
        result,
        "enterprise",
        label="广西桐曦电子科技有限公司",
    )
    assert enterprise.attributes["observed_roles"] == [
        "issuer",
        "buyer",
        "seller",
        "supplier",
    ]
    aliases = {
        item.alias for item in result.aliases if item.entity_id == enterprise.entity_id
    }
    assert "广西桐曦电子科技有限公司" in aliases
    assert "甲方:广西桐曦电子科技有限公司" in aliases
    assert "乙 方:广西桐曦电子科技有限公司" in aliases
    assert "供应商:广西桐曦电子科技有限公司" in aliases


@pytest.mark.parametrize(
    ("document_type", "subtype", "entity_type", "relation_type", "code"),
    [
        ("equipment", "equipment_register", "equipment", "LISTS_EQUIPMENT", "EQ-001"),
        ("mold", "mold_mapping", "mold", "LISTS_MOLD", "MOLD-001"),
    ],
)
def test_exact_equipment_and_mold_codes_are_active_and_accepted(
    document_type: str,
    subtype: str,
    entity_type: str,
    relation_type: str,
    code: str,
) -> None:
    result = canonicalize_document(
        _document(
            document_type=document_type,
            document_subtype=subtype,
            lines=[
                {
                    "line_id": "Sheet1:2:1",
                    "line_no": 1,
                    "product_code": code,
                    "name_raw": f"{code}名称",
                }
            ],
            field_meta={
                "$.lines[0].product_code": {
                    "confidence": 0.99,
                    "source_refs": [{"sheet": "Sheet1", "cell": "A2"}],
                }
            },
        ),
        tenant_id="factory-a",
    )

    entity = _entity(result, entity_type)
    identity = next(
        item for item in result.external_identities if item.entity_id == entity.entity_id
    )
    relation = next(item for item in result.relationships if item.relation_type == relation_type)
    assert entity.lifecycle_status == LifecycleStatus.ACTIVE
    assert identity.status == ClaimStatus.ACCEPTED
    assert relation.status == ClaimStatus.ACCEPTED
    assert relation.evidence_anchor_id


def test_names_and_inferred_codes_never_bypass_review() -> None:
    inventory = canonicalize_document(
        _document(
            document_type="inventory",
            document_subtype="inventory_snapshot",
            lines=[
                {
                    "line_id": "Sheet1:2:1",
                    "line_no": 1,
                    "name_raw": "无氧铜导体",
                    "quantity": 120,
                    "unit": "KG",
                }
            ],
            field_meta={
                "$.lines[0].name_raw": {
                    "confidence": 0.88,
                    "source_refs": [{"sheet": "Sheet1", "cell": "B2"}],
                }
            },
        ),
        tenant_id="factory-a",
    )
    material = _entity(inventory, "material")
    alias = next(item for item in inventory.aliases if item.entity_id == material.entity_id)
    relation = next(
        item for item in inventory.relationships if item.relation_type == "LISTS_MATERIAL"
    )
    assert material.lifecycle_status == LifecycleStatus.UNDER_REVIEW
    assert alias.status == ClaimStatus.CANDIDATE
    assert relation.status == ClaimStatus.CANDIDATE

    inferred_equipment = canonicalize_document(
        _document(
            document_type="equipment",
            document_subtype="equipment_register",
            sha="b" * 64,
            lines=[
                {
                    "line_id": "Sheet1:2:1",
                    "line_no": 1,
                    "product_code": "EQ-INFERRED",
                    "name_raw": "推断设备",
                }
            ],
            field_meta={
                "$.lines[0].product_code": {
                    "confidence": 0.7,
                    "inferred": True,
                    "source_refs": [{"sheet": "Sheet1", "cell": "A2"}],
                }
            },
        ),
        tenant_id="factory-a",
    )
    equipment = _entity(inferred_equipment, "equipment")
    identity = next(
        item
        for item in inferred_equipment.external_identities
        if item.entity_id == equipment.entity_id
    )
    assert equipment.lifecycle_status == LifecycleStatus.UNDER_REVIEW
    assert identity.status == ClaimStatus.CANDIDATE


def test_customer_and_supplier_codes_are_organisation_scoped() -> None:
    def scoped(customer: str, supplier: str, sha: str):
        return canonicalize_document(
            _document(
                document_type="inventory",
                document_subtype="inventory_snapshot",
                sha=sha,
                header={"buyer": customer, "supplier": supplier},
                lines=[
                    {
                        "line_id": "1",
                        "name_raw": "客户专用线材",
                        "custom_fields": {
                            "customer_product_code": "SHARED-001",
                            "supplier_material_code": "SUP-001",
                        },
                    }
                ],
            ),
            tenant_id="factory-a",
        )

    first = scoped("客户甲", "供应商甲", "c" * 64)
    second = scoped("客户乙", "供应商乙", "d" * 64)
    first_material = _entity(first, "material")
    second_material = _entity(second, "material")
    assert first_material.canonical_key != second_material.canonical_key

    first_customer_identity = next(
        item for item in first.external_identities if item.external_id == "SHARED-001"
    )
    second_customer_identity = next(
        item for item in second.external_identities if item.external_id == "SHARED-001"
    )
    assert first_customer_identity.source_system != second_customer_identity.source_system
    assert first_customer_identity.status == ClaimStatus.ACCEPTED
    assert second_customer_identity.status == ClaimStatus.ACCEPTED


def test_unscoped_customer_code_and_technical_document_are_governed() -> None:
    unscoped = canonicalize_document(
        _document(
            document_type="inventory",
            document_subtype="inventory_snapshot",
            lines=[
                {
                    "line_id": "1",
                    "name_raw": "未知客户线材",
                    "custom_fields": {"customer_product_code": "C-UNKNOWN"},
                }
            ],
        ),
        tenant_id="factory-a",
    )
    material = _entity(unscoped, "material")
    identity = next(
        item for item in unscoped.external_identities if item.external_id == "C-UNKNOWN"
    )
    assert "unresolved" in material.canonical_key
    assert material.lifecycle_status == LifecycleStatus.UNDER_REVIEW
    assert identity.status == ClaimStatus.CANDIDATE

    technical = canonicalize_document(
        _document(
            document_type="technical_document",
            document_subtype="product_specification",
            sha="e" * 64,
            header={
                "title": "DP-900 产品规格书",
                "issuer": "研发中心",
                "product_code": "DP-900",
            },
            field_meta={
                "$.header.product_code": {
                    "confidence": 1.0,
                    "source_refs": [{"page": 1, "part": "title-block"}],
                }
            },
        ),
        tenant_id="factory-a",
    )
    document = _entity(technical, "document")
    product = _entity(technical, "product")
    relation = next(item for item in technical.relationships if item.relation_type == "DESCRIBES")
    assert document.lifecycle_status == LifecycleStatus.ACTIVE
    assert product.lifecycle_status == LifecycleStatus.ACTIVE
    assert relation.status == ClaimStatus.ACCEPTED
    assert relation.properties["source_refs"] == [{"page": 1, "part": "title-block"}]


def test_overlong_terms_cell_is_not_promoted_to_identity_or_alias() -> None:
    malformed_model = "Special terms and conditions\n" + ("not-a-model " * 100)
    result = canonicalize_document(
        _document(
            document_type="order",
            document_subtype="customer_purchase_order",
            lines=[
                {
                    "line_id": "1",
                    "model": malformed_model,
                    "name_raw": "DisplayPort cable",
                    "quantity": 1,
                }
            ],
        ),
        tenant_id="factory-a",
    )
    product = _entity(result, "product")
    assert all(
        identity.external_id != malformed_model
        for identity in result.external_identities
    )
    assert all(alias.alias != malformed_model for alias in result.aliases)
    assert product.attributes["model"] == malformed_model
