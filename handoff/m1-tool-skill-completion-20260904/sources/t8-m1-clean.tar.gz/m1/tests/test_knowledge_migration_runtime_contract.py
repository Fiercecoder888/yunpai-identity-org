from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from alembic import command
from sqlalchemy import create_engine, text

from m1.knowledge.migrations import runner as migration_runner
from m1.knowledge.migrations.runner import (
    KnowledgeSchemaError,
    _config,
    upgrade_knowledge_schema,
    validate_knowledge_schema,
)
from m1.knowledge.persistence import KnowledgeBase, KnowledgeStore


def _repository() -> Path:
    return Path(__file__).resolve().parents[2]


def test_runtime_declares_ordered_knowledge_migration_service() -> None:
    compose = yaml.safe_load(
        (_repository() / "m1/deploy/compose.runtime.yml").read_text(encoding="utf-8")
    )
    services = compose["services"]
    migration = services["m1-knowledge-migrate"]

    assert migration["image"] == "${M1_IMAGE:?M1_IMAGE is required}"
    assert migration["restart"] == "no"
    assert migration["command"] == [
        "/app/.venv/bin/python",
        "-m",
        "m1.knowledge.migrations",
    ]
    assert migration["depends_on"]["postgres"]["condition"] == "service_healthy"
    assert services["m1"]["depends_on"]["m1-knowledge-migrate"]["condition"] == (
        "service_completed_successfully"
    )


@pytest.mark.parametrize(
    "future_revision",
    [
        "0013_visual_region_routes",
        "0014_region_capability_routes",
        "0015_content_region_routes",
        "0016_unified_business_core",
        "0017_recalculation_ledger",
        "0018_finished_goods_output",
        "0019_quality_inspection",
        "0020_lot_traceability",
        "0021_receipt_flow",
        "0022_flow_request_persistence",
    ],
)
def test_declared_route_revision_is_accepted_read_only(
    tmp_path: Path,
    future_revision: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class BridgeScriptDirectory:
        @staticmethod
        def get_current_head() -> str:
            return "0012_field_semantic_routes"

        @staticmethod
        def get_revision(revision: str) -> None:
            raise migration_runner.CommandError(
                f"Can't locate revision identified by {revision!r}"
            )

    monkeypatch.setattr(
        migration_runner.ScriptDirectory,
        "from_config",
        lambda _config: BridgeScriptDirectory(),
    )
    database = tmp_path / f"future-{future_revision}.db"
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        KnowledgeBase.metadata.create_all(connection)
        connection.execute(
            text("CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)")
        )
        connection.execute(
            text(
                "INSERT INTO alembic_version (version_num) "
                "VALUES (:future_revision)"
            ),
            {"future_revision": future_revision},
        )
        assert validate_knowledge_schema(connection) == future_revision
        assert upgrade_knowledge_schema(connection) == future_revision
    engine.dispose()


@pytest.mark.parametrize(
    "known_revision",
    [
        "0013_visual_region_routes",
        "0014_region_capability_routes",
    ],
)
def test_known_older_route_revision_requires_ordered_migration(
    tmp_path: Path,
    known_revision: str,
) -> None:
    database = tmp_path / f"known-{known_revision}.db"
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        command.upgrade(_config(connection), known_revision)

        with pytest.raises(KnowledgeSchemaError, match="expected '0022"):
            validate_knowledge_schema(connection)

        assert upgrade_knowledge_schema(connection) == "0022_flow_request_persistence"
        assert validate_knowledge_schema(connection) == "0022_flow_request_persistence"
    engine.dispose()


def test_undeclared_future_revision_is_rejected(tmp_path: Path) -> None:
    database = tmp_path / "undeclared-future.db"
    engine = create_engine(f"sqlite:///{database}")
    with engine.begin() as connection:
        KnowledgeBase.metadata.create_all(connection)
        connection.execute(
            text("CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)")
        )
        connection.execute(
            text("INSERT INTO alembic_version (version_num) VALUES ('9999_future')")
        )
        with pytest.raises(KnowledgeSchemaError, match="not declared"):
            validate_knowledge_schema(connection)
        with pytest.raises(KnowledgeSchemaError, match="not declared"):
            upgrade_knowledge_schema(connection)
    engine.dispose()


@pytest.mark.asyncio
async def test_api_style_init_requires_pre_migrated_schema(tmp_path: Path) -> None:
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'knowledge.db'}"
    store = KnowledgeStore(database_url)
    try:
        with pytest.raises(KnowledgeSchemaError):
            await store.init(migrate_schema=False)
        await store.init(migrate_schema=True)
        await store.init(migrate_schema=False)
    finally:
        await store.close()
