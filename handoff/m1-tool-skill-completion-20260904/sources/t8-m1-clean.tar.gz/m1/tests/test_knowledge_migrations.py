from __future__ import annotations

from importlib import import_module
from pathlib import Path

import pytest
from alembic import command
from alembic.script import ScriptDirectory
from m1.knowledge.migrations.runner import _config, upgrade_database
from m1.knowledge.persistence import (
    IdempotencyConflictError,
    KnowledgeBase,
    KnowledgeStore,
)
from sqlalchemy import create_engine, inspect, text

_HEAD_REVISION = "0022_flow_request_persistence"


def test_knowledge_migrations_have_one_linear_extension_head() -> None:
    scripts = ScriptDirectory.from_config(_config())

    assert scripts.get_heads() == [_HEAD_REVISION]
    assert scripts.get_current_head() == _HEAD_REVISION
    assert (
        scripts.get_revision("0017_recalculation_ledger").down_revision
        == "0016_unified_business_core"
    )
    assert (
        scripts.get_revision("0018_finished_goods_output").down_revision
        == "0017_recalculation_ledger"
    )
    assert (
        scripts.get_revision("0019_quality_inspection").down_revision
        == "0018_finished_goods_output"
    )
    assert (
        scripts.get_revision("0020_lot_traceability").down_revision
        == "0019_quality_inspection"
    )
    assert (
        scripts.get_revision("0021_receipt_flow").down_revision
        == "0020_lot_traceability"
    )
    assert (
        scripts.get_revision("0022_flow_request_persistence").down_revision
        == "0021_receipt_flow"
    )
    assert (
        scripts.get_revision("0016_unified_business_core").down_revision
        == "0015_content_region_routes"
    )
    assert (
        scripts.get_revision("0015_content_region_routes").down_revision
        == "0014_region_capability_routes"
    )
    assert (
        scripts.get_revision("0014_region_capability_routes").down_revision
        == "0013_visual_region_routes"
    )
    assert (
        scripts.get_revision("0013_visual_region_routes").down_revision
        == "0012_field_semantic_routes"
    )
    assert (
        scripts.get_revision("0012_field_semantic_routes").down_revision
        == "0011_tabular_layout_profiles"
    )


def test_0006_identifiers_fit_postgres_limits() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0006_review_decision_task_reference"
    )

    assert len(migration.revision) <= 32
    assert len(migration.FOREIGN_KEY_NAME) <= 63


def test_0007_identifiers_fit_postgres_limits() -> None:
    migration = import_module("m1.knowledge.migrations.versions.0007_route_profiles")

    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63
    assert len(migration.EMBEDDING_SPACE_INDEX) <= 63


def test_0008_identifiers_fit_postgres_limits() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0008_entity_route_index"
    )

    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63


def test_0009_identifiers_fit_postgres_limits() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0009_document_identity_routing"
    )

    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.PROCESSING_REVISION_INDEX) <= 63


def test_0010_identifiers_fit_postgres_limits() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0010_entity_route_tenant_references"
    )

    assert len(migration.revision) <= 32
    assert all(
        len(name) <= 63
        for name in (
            migration.ENTITY_TENANT_KEY,
            migration.INDEX_ENTITY_FK,
            migration.DECISION_VERSION_FK,
            migration.DECISION_CANDIDATE_FK,
        )
    )


def test_0011_identifiers_fit_postgres_limits() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0011_tabular_layout_profiles"
    )

    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63
    assert len(migration.EMBEDDING_SPACE_INDEX) <= 63


@pytest.mark.parametrize(
    "revision",
    (
        "0012_field_semantic_routes",
        "0013_visual_region_routes",
        "0014_region_capability_routes",
        "0015_content_region_routes",
    ),
)
def test_extension_route_identifiers_fit_postgres_limits(revision: str) -> None:
    migration = import_module(f"m1.knowledge.migrations.versions.{revision}")

    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63
    assert len(migration.EMBEDDING_SPACE_INDEX) <= 63


@pytest.mark.asyncio
async def test_0010_rebuilds_legacy_entity_route_foreign_keys_on_sqlite(
    tmp_path: Path,
) -> None:
    database = tmp_path / "legacy-entity-route-fks.db"
    sync_url = f"sqlite:///{database.as_posix()}"
    async_url = f"sqlite+aiosqlite:///{database.as_posix()}"
    engine = create_engine(sync_url)
    try:
        KnowledgeBase.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(text("DROP TABLE knowledge_entity_route_decisions"))
            connection.execute(text("DROP TABLE knowledge_entity_route_index"))
            connection.execute(
                text(
                    "CREATE TABLE knowledge_entity_route_index ("
                    "index_id VARCHAR(128) NOT NULL PRIMARY KEY, "
                    "entity_id VARCHAR(128) NOT NULL, "
                    "entity_type VARCHAR(128) NOT NULL, "
                    "normalized_text TEXT NOT NULL, "
                    "embedding JSON NOT NULL, "
                    "embedding_model VARCHAR(256) NOT NULL, "
                    "embedding_dimensions INTEGER NOT NULL, "
                    "updated_at DATETIME NOT NULL, "
                    "tenant_id VARCHAR(128) NOT NULL, "
                    "CONSTRAINT legacy_index_entity FOREIGN KEY (entity_id) "
                    "REFERENCES knowledge_canonical_entities(entity_id) ON DELETE RESTRICT, "
                    "CONSTRAINT legacy_index_tenant FOREIGN KEY (tenant_id) "
                    "REFERENCES knowledge_tenants(tenant_id) ON DELETE RESTRICT"
                    ")"
                )
            )
            connection.execute(
                text(
                    "CREATE TABLE knowledge_entity_route_decisions ("
                    "decision_id VARCHAR(128) NOT NULL PRIMARY KEY, "
                    "source_version_id VARCHAR(128) NOT NULL, "
                    "proposed_entity_id VARCHAR(128) NOT NULL, "
                    "entity_type VARCHAR(128) NOT NULL, "
                    "action VARCHAR(32) NOT NULL, "
                    "candidate_entity_id VARCHAR(128), "
                    "candidate_score FLOAT NOT NULL, "
                    "top1_top2_margin FLOAT NOT NULL, "
                    "model_confidence FLOAT NOT NULL, "
                    "reason_codes JSON NOT NULL, "
                    "model_name VARCHAR(256) NOT NULL, "
                    "model_revision VARCHAR(256) NOT NULL, "
                    "created_at DATETIME NOT NULL, "
                    "tenant_id VARCHAR(128) NOT NULL, "
                    "CONSTRAINT legacy_decision_version FOREIGN KEY (source_version_id) "
                    "REFERENCES knowledge_document_versions(version_id) ON DELETE RESTRICT, "
                    "CONSTRAINT legacy_decision_candidate FOREIGN KEY (candidate_entity_id) "
                    "REFERENCES knowledge_canonical_entities(entity_id) ON DELETE RESTRICT, "
                    "CONSTRAINT legacy_decision_tenant FOREIGN KEY (tenant_id) "
                    "REFERENCES knowledge_tenants(tenant_id) ON DELETE RESTRICT"
                    ")"
                )
            )
            connection.execute(
                text("CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)")
            )
            connection.execute(
                text(
                    "INSERT INTO alembic_version (version_num) "
                    "VALUES ('0009_document_identity_routing')"
                )
            )
    finally:
        engine.dispose()

    assert await upgrade_database(async_url) == _HEAD_REVISION

    engine = create_engine(sync_url)
    try:
        schema = inspect(engine)
        index_foreign_keys = schema.get_foreign_keys("knowledge_entity_route_index")
        decision_foreign_keys = schema.get_foreign_keys(
            "knowledge_entity_route_decisions"
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "entity_id"]
            and foreign_key["referred_columns"] == ["tenant_id", "entity_id"]
            for foreign_key in index_foreign_keys
        )
        assert not any(
            foreign_key["constrained_columns"] == ["entity_id"]
            and foreign_key["referred_table"] == "knowledge_canonical_entities"
            for foreign_key in index_foreign_keys
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "source_version_id"]
            and foreign_key["referred_columns"] == ["tenant_id", "version_id"]
            for foreign_key in decision_foreign_keys
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "candidate_entity_id"]
            and foreign_key["referred_columns"] == ["tenant_id", "entity_id"]
            for foreign_key in decision_foreign_keys
        )
        assert not any(
            foreign_key["constrained_columns"]
            in (
                ["source_version_id"],
                ["candidate_entity_id"],
            )
            for foreign_key in decision_foreign_keys
        )
    finally:
        engine.dispose()


def test_0009_sqlite_downgrade_and_reupgrade_round_trip(tmp_path: Path) -> None:
    """The lineage index must be removed before SQLite batch drops its column."""

    database = tmp_path / "identity-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, "head")
            command.downgrade(config, "0007_route_profiles")

            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == "0007_route_profiles"
            )
            version_columns = {
                column["name"]
                for column in inspect(connection).get_columns(
                    "knowledge_document_versions"
                )
            }
            assert "processing_revision" not in version_columns
            assert "supersedes_version_id" not in version_columns

            command.upgrade(config, "head")
            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == _HEAD_REVISION
            )
            version_columns = {
                column["name"]
                for column in inspect(connection).get_columns(
                    "knowledge_document_versions"
                )
            }
            assert {"processing_revision", "supersedes_version_id"}.issubset(
                version_columns
            )
    finally:
        engine.dispose()


def test_0010_sqlite_tenant_reference_downgrade_and_reupgrade_round_trip(
    tmp_path: Path,
) -> None:
    """Downgrading tenant-scoped route FKs must restore the prior FK shape."""

    database = tmp_path / "entity-route-fk-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, "head")
            command.downgrade(config, "0009_document_identity_routing")

            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == "0009_document_identity_routing"
            )
            legacy_foreign_keys = inspect(connection).get_foreign_keys(
                "knowledge_entity_route_index"
            )
            assert any(
                foreign_key["constrained_columns"] == ["entity_id"]
                and foreign_key["referred_columns"] == ["entity_id"]
                for foreign_key in legacy_foreign_keys
            )
            assert not any(
                foreign_key["constrained_columns"] == ["tenant_id", "entity_id"]
                for foreign_key in legacy_foreign_keys
            )

            command.upgrade(config, "head")
            upgraded_foreign_keys = inspect(connection).get_foreign_keys(
                "knowledge_entity_route_index"
            )
            assert any(
                foreign_key["constrained_columns"] == ["tenant_id", "entity_id"]
                and foreign_key["referred_columns"] == ["tenant_id", "entity_id"]
                for foreign_key in upgraded_foreign_keys
            )
    finally:
        engine.dispose()


def test_0011_tabular_layout_fresh_upgrade_downgrade_and_reupgrade(
    tmp_path: Path,
) -> None:
    database = tmp_path / "tabular-layout-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, "head")
            schema = inspect(connection)
            assert {
                "knowledge_tabular_layout_profiles",
                "knowledge_tabular_layout_observations",
            }.issubset(schema.get_table_names())
            profile_columns = {
                column["name"]
                for column in schema.get_columns("knowledge_tabular_layout_profiles")
            }
            assert {
                "signature",
                "plan",
                "contract_revision",
                "interpreter_revision",
                "embedding",
                "embedding_model",
                "embedding_dimensions",
            }.issubset(profile_columns)

            command.downgrade(config, "0010_entity_route_tenant_fks")
            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == "0010_entity_route_tenant_fks"
            )
            downgraded = inspect(connection).get_table_names()
            assert "knowledge_tabular_layout_profiles" not in downgraded
            assert "knowledge_tabular_layout_observations" not in downgraded

            command.upgrade(config, "head")
            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == _HEAD_REVISION
            )
            upgraded = inspect(connection)
            observation_foreign_keys = upgraded.get_foreign_keys(
                "knowledge_tabular_layout_observations"
            )
            assert any(
                foreign_key["constrained_columns"] == ["tenant_id", "profile_id"]
                and foreign_key["referred_table"] == "knowledge_tabular_layout_profiles"
                and foreign_key["referred_columns"] == ["tenant_id", "profile_id"]
                for foreign_key in observation_foreign_keys
            )
    finally:
        engine.dispose()


def test_0012_0015_extension_routes_round_trip(tmp_path: Path) -> None:
    database = tmp_path / "extension-routes-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    field_migration = import_module(
        "m1.knowledge.migrations.versions.0012_field_semantic_routes"
    )
    visual_migration = import_module(
        "m1.knowledge.migrations.versions.0013_visual_region_routes"
    )
    region_migration = import_module(
        "m1.knowledge.migrations.versions.0014_region_capability_routes"
    )
    content_migration = import_module(
        "m1.knowledge.migrations.versions.0015_content_region_routes"
    )
    field_tables = set(field_migration.TENANT_TABLES)
    visual_tables = set(visual_migration.TENANT_TABLES)
    region_tables = set(region_migration.TENANT_TABLES)
    content_tables = set(content_migration.TENANT_TABLES)
    expected_tables = field_tables | visual_tables | region_tables | content_tables

    def current_revision(connection) -> str:
        return connection.execute(
            text("SELECT version_num FROM alembic_version")
        ).scalar_one()

    def assert_profile_schema(connection, migration) -> None:
        schema = inspect(connection)
        assert migration.EMBEDDING_SPACE_INDEX in {
            index["name"] for index in schema.get_indexes(migration.PROFILE_TABLE)
        }
        assert {
            "tenant_id",
            "profile_id",
            "status",
            "exact_fingerprint",
            "embedding",
            "embedding_model",
            "embedding_dimensions",
        } <= {column["name"] for column in schema.get_columns(migration.PROFILE_TABLE)}
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "profile_id"]
            and foreign_key["referred_table"] == migration.PROFILE_TABLE
            and foreign_key["referred_columns"] == ["tenant_id", "profile_id"]
            for foreign_key in schema.get_foreign_keys(migration.OBSERVATION_TABLE)
        )

    def assert_lifecycle_schema(connection) -> None:
        columns = {
            column["name"]
            for column in inspect(connection).get_columns(
                field_migration.LIFECYCLE_TABLE
            )
        }
        assert {
            "actor_reference_sha256",
            "counterparty_reference_sha256",
            "reason_sha256",
        } <= columns
        assert {"actor_id", "counterparty_id"}.isdisjoint(columns)

    try:
        with engine.begin() as connection:
            config = _config(connection)

            # The legacy compatibility bridge creates current metadata on a
            # fresh database. Establish the historical 0011 boundary through
            # the real downgrade path before testing the four new revisions.
            command.upgrade(config, "head")
            assert current_revision(connection) == _HEAD_REVISION
            assert expected_tables <= set(inspect(connection).get_table_names())

            command.downgrade(config, "0011_tabular_layout_profiles")
            assert current_revision(connection) == "0011_tabular_layout_profiles"
            assert expected_tables.isdisjoint(inspect(connection).get_table_names())

            command.upgrade(config, "0012_field_semantic_routes")
            assert current_revision(connection) == "0012_field_semantic_routes"
            assert field_tables <= set(inspect(connection).get_table_names())
            assert (visual_tables | region_tables | content_tables).isdisjoint(
                inspect(connection).get_table_names()
            )
            assert_profile_schema(connection, field_migration)
            assert_lifecycle_schema(connection)

            command.upgrade(config, "0013_visual_region_routes")
            assert current_revision(connection) == "0013_visual_region_routes"
            assert field_tables | visual_tables <= set(
                inspect(connection).get_table_names()
            )
            assert (region_tables | content_tables).isdisjoint(
                inspect(connection).get_table_names()
            )
            assert_profile_schema(connection, field_migration)
            assert_profile_schema(connection, visual_migration)

            command.upgrade(config, "0014_region_capability_routes")
            assert current_revision(connection) == "0014_region_capability_routes"
            assert field_tables | visual_tables | region_tables <= set(
                inspect(connection).get_table_names()
            )
            assert content_tables.isdisjoint(inspect(connection).get_table_names())
            assert_profile_schema(connection, region_migration)

            command.upgrade(config, "0015_content_region_routes")
            assert current_revision(connection) == "0015_content_region_routes"
            assert expected_tables <= set(inspect(connection).get_table_names())
            assert_profile_schema(connection, content_migration)

            command.downgrade(config, "0013_visual_region_routes")
            assert current_revision(connection) == "0013_visual_region_routes"
            assert field_tables | visual_tables <= set(
                inspect(connection).get_table_names()
            )
            assert (region_tables | content_tables).isdisjoint(
                inspect(connection).get_table_names()
            )

            command.downgrade(config, "0012_field_semantic_routes")
            assert current_revision(connection) == "0012_field_semantic_routes"
            assert field_tables <= set(inspect(connection).get_table_names())
            assert visual_tables.isdisjoint(inspect(connection).get_table_names())

            command.downgrade(config, "0011_tabular_layout_profiles")
            assert current_revision(connection) == "0011_tabular_layout_profiles"
            assert expected_tables.isdisjoint(inspect(connection).get_table_names())

            command.upgrade(config, "head")
            assert current_revision(connection) == _HEAD_REVISION
            assert expected_tables <= set(inspect(connection).get_table_names())
            assert_profile_schema(connection, field_migration)
            assert_profile_schema(connection, visual_migration)
            assert_profile_schema(connection, region_migration)
            assert_profile_schema(connection, content_migration)
            assert_lifecycle_schema(connection)
    finally:
        engine.dispose()


@pytest.mark.asyncio
async def test_0005_to_0006_binds_new_decisions_and_preserves_history(
    tmp_path: Path,
) -> None:
    database = tmp_path / "versioned-0005.db"
    sync_url = f"sqlite:///{database.as_posix()}"
    async_url = f"sqlite+aiosqlite:///{database.as_posix()}"
    engine = create_engine(sync_url)
    try:
        with engine.begin() as connection:
            command.upgrade(_config(connection), "0005_task_lifecycle_fence")
            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == "0005_task_lifecycle_fence"
            )
            # Current metadata is imported by the legacy compatibility bridge.
            # Remove future tables to model a real database created by 0005.
            connection.execute(text("DROP TABLE knowledge_route_observations"))
            connection.execute(text("DROP TABLE knowledge_route_profiles"))
            connection.execute(
                text(
                    "INSERT INTO knowledge_tenants "
                    "(tenant_id, tenant_key, display_name, lifecycle_status, default_acl, "
                    "metadata, created_at, updated_at) VALUES "
                    "('migration-tenant', 'migration-tenant', 'Migration Tenant', "
                    "'active', '{}', '{}', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
                )
            )
            connection.execute(
                text(
                    "INSERT INTO knowledge_review_tasks "
                    "(review_task_id, idempotency_key, target_type, target_id, status, "
                    "priority, reason_codes, summary, payload, created_at, updated_at, "
                    "resolved_at, tenant_id) VALUES "
                    "('historical-review-task', 'historical-review-task-key', "
                    "'document_version', 'historical-version', 'resolved', 50, '[]', "
                    "'', '{}', '2026-07-20 10:00:00', '2026-07-20 10:00:00', "
                    "'2026-07-20 10:00:00', 'migration-tenant'), "
                    "('different-review-task', 'different-review-task-key', "
                    "'document_version', 'historical-version', 'resolved', 50, '[]', "
                    "'', '{}', '2026-07-20 11:00:00', '2026-07-20 11:00:00', "
                    "'2026-07-20 11:00:00', 'migration-tenant')"
                )
            )
            connection.execute(
                text(
                    "INSERT INTO knowledge_review_decisions "
                    "(decision_id, idempotency_key, target_type, target_id, decision, "
                    "reviewer_id, reason, corrections, evidence_anchor_ids, decided_at, "
                    "tenant_id) VALUES "
                    "('historical-decision', 'historical-key', 'document_version', "
                    "'historical-version', 'accept', 'historical-reviewer', '', '{}', "
                    "'[]', '2026-07-20 10:00:00', 'migration-tenant')"
                )
            )
    finally:
        engine.dispose()

    assert await upgrade_database(async_url) == _HEAD_REVISION

    engine = create_engine(sync_url)
    try:
        schema = inspect(engine)
        assert "review_task_id" in {
            column["name"]
            for column in schema.get_columns("knowledge_review_decisions")
        }
        assert "ix_knowledge_review_decisions_review_task_id" in {
            index["name"] for index in schema.get_indexes("knowledge_review_decisions")
        }
        assert any(
            foreign_key["constrained_columns"] == ["review_task_id"]
            and foreign_key["referred_table"] == "knowledge_review_tasks"
            and foreign_key["referred_columns"] == ["review_task_id"]
            for foreign_key in schema.get_foreign_keys("knowledge_review_decisions")
        )
        assert {
            "knowledge_entity_route_index",
            "knowledge_entity_route_decisions",
            "knowledge_document_identity_bindings",
            "knowledge_document_identity_decisions",
        }.issubset(schema.get_table_names())
        assert any(
            constraint["column_names"] == ["tenant_id", "entity_id"]
            for constraint in schema.get_unique_constraints(
                "knowledge_canonical_entities"
            )
        )
        route_index_foreign_keys = schema.get_foreign_keys(
            "knowledge_entity_route_index"
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "entity_id"]
            and foreign_key["referred_table"] == "knowledge_canonical_entities"
            and foreign_key["referred_columns"] == ["tenant_id", "entity_id"]
            for foreign_key in route_index_foreign_keys
        )
        route_decision_foreign_keys = schema.get_foreign_keys(
            "knowledge_entity_route_decisions"
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "source_version_id"]
            and foreign_key["referred_table"] == "knowledge_document_versions"
            and foreign_key["referred_columns"] == ["tenant_id", "version_id"]
            for foreign_key in route_decision_foreign_keys
        )
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "candidate_entity_id"]
            and foreign_key["referred_table"] == "knowledge_canonical_entities"
            and foreign_key["referred_columns"] == ["tenant_id", "entity_id"]
            for foreign_key in route_decision_foreign_keys
        )
        version_columns = {
            column["name"]
            for column in schema.get_columns("knowledge_document_versions")
        }
        assert {"processing_revision", "supersedes_version_id"}.issubset(
            version_columns
        )
        assert "supersedes_profile_id" in {
            column["name"] for column in schema.get_columns("knowledge_route_profiles")
        }
        assert "embedding_dimensions" in {
            column["name"] for column in schema.get_columns("knowledge_route_profiles")
        }
        migration_indexes = {
            index["name"] for index in schema.get_indexes("knowledge_route_profiles")
        }
        assert "ix_route_profiles_embedding_space" in migration_indexes
        assert any(
            foreign_key["constrained_columns"] == ["tenant_id", "supersedes_profile_id"]
            and foreign_key["referred_table"] == "knowledge_route_profiles"
            and foreign_key["referred_columns"] == ["tenant_id", "profile_id"]
            for foreign_key in schema.get_foreign_keys("knowledge_route_profiles")
        )
        assert any(
            constraint["column_names"] == ["tenant_id", "supersedes_profile_id"]
            for constraint in schema.get_unique_constraints("knowledge_route_profiles")
        )
        with engine.connect() as connection:
            historical = connection.execute(
                text(
                    "SELECT decision_id, review_task_id "
                    "FROM knowledge_review_decisions "
                    "WHERE decision_id = 'historical-decision'"
                )
            ).one()
            assert tuple(historical) == ("historical-decision", None)
    finally:
        engine.dispose()

    store = KnowledgeStore(async_url)
    await store.init()
    try:
        legacy_request = {
            "tenant_id": "migration-tenant",
            "review_task_id": "historical-review-task",
            "decision": "accept",
            "reviewer_id": "historical-reviewer",
            "idempotency_key": "historical-key",
        }
        with pytest.raises(IdempotencyConflictError):
            await store.decide_review(
                **{**legacy_request, "reason": "different semantics"}
            )
        with pytest.raises(IdempotencyConflictError):
            await store.decide_review(
                **{
                    **legacy_request,
                    "review_task_id": "different-review-task",
                }
            )

        replay = await store.decide_review(**legacy_request)
        assert replay.decision_id == "historical-decision"
        assert replay.review_task_id == "historical-review-task"
        assert await store.decide_review(**legacy_request) == replay
    finally:
        await store.close()

    engine = create_engine(sync_url)
    try:
        with engine.connect() as connection:
            bound_task_id = connection.execute(
                text(
                    "SELECT review_task_id FROM knowledge_review_decisions "
                    "WHERE decision_id = 'historical-decision'"
                )
            ).scalar_one()
            assert bound_task_id == "historical-review-task"
    finally:
        engine.dispose()


@pytest.mark.asyncio
async def test_versioned_0004_database_adds_task_lifecycle_fence(
    tmp_path: Path,
) -> None:
    database = tmp_path / "versioned-0004.db"
    sync_url = f"sqlite:///{database.as_posix()}"
    async_url = f"sqlite+aiosqlite:///{database.as_posix()}"
    engine = create_engine(sync_url)
    try:
        KnowledgeBase.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(text("DROP TABLE knowledge_task_lifecycles"))
            connection.execute(
                text("CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)")
            )
            connection.execute(
                text(
                    "INSERT INTO alembic_version (version_num) "
                    "VALUES ('0004_postgres_tenant_rls')"
                )
            )
    finally:
        engine.dispose()

    assert await upgrade_database(async_url) == _HEAD_REVISION

    engine = create_engine(sync_url)
    try:
        schema = inspect(engine)
        assert "knowledge_task_lifecycles" in schema.get_table_names()
        indexes = {
            index["name"] for index in schema.get_indexes("knowledge_task_lifecycles")
        }
        assert {
            "ix_knowledge_task_lifecycle_lookup",
            "ix_knowledge_task_lifecycles_status",
            "ix_knowledge_task_lifecycles_task_id",
            "ix_knowledge_task_lifecycles_tenant_id",
        }.issubset(indexes)
        assert "review_task_id" in {
            column["name"]
            for column in schema.get_columns("knowledge_review_decisions")
        }
    finally:
        engine.dispose()


@pytest.mark.asyncio
async def test_unversioned_legacy_schema_is_upgraded_without_losing_generation(
    tmp_path: Path,
) -> None:
    database = tmp_path / "legacy-knowledge.db"
    sync_url = f"sqlite:///{database.as_posix()}"
    async_url = f"sqlite+aiosqlite:///{database.as_posix()}"
    engine = create_engine(sync_url)
    try:
        KnowledgeBase.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(
                text(
                    "INSERT INTO knowledge_tenants "
                    "(tenant_id, tenant_key, display_name, lifecycle_status, default_acl, "
                    "metadata, created_at, updated_at) VALUES "
                    "('tenant-a', 'tenant-a', 'Tenant A', 'active', '{}', '{}', "
                    "CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)"
                )
            )

            connection.execute(
                text("DROP INDEX ix_knowledge_source_occurrences_task_id")
            )
            connection.execute(
                text("ALTER TABLE knowledge_source_occurrences DROP COLUMN task_id")
            )

            for index_name in (
                "ix_knowledge_relationship_source_version",
                "ix_knowledge_relationship_claims_source_record_id",
                "ix_knowledge_relationship_claims_source_version",
            ):
                connection.execute(text(f"DROP INDEX {index_name}"))
            connection.execute(
                text(
                    "ALTER TABLE knowledge_relationship_claims "
                    "DROP COLUMN source_record_id"
                )
            )
            connection.execute(
                text(
                    "ALTER TABLE knowledge_relationship_claims "
                    "DROP COLUMN source_version"
                )
            )

            for column in (
                "asserted_label",
                "asserted_attributes",
                "asserted_lifecycle_status",
                "asserted_confidence",
            ):
                connection.execute(
                    text(
                        "ALTER TABLE knowledge_entity_source_bindings "
                        f"DROP COLUMN {column}"
                    )
                )

            connection.execute(text("DROP TABLE knowledge_graph_generations"))
            connection.execute(
                text(
                    "CREATE TABLE knowledge_graph_generations ("
                    "source_record_id VARCHAR(128) PRIMARY KEY, "
                    "generation BIGINT NOT NULL, "
                    "updated_at DATETIME NOT NULL, "
                    "tenant_id VARCHAR(128) NOT NULL)"
                )
            )
            connection.execute(
                text(
                    "INSERT INTO knowledge_graph_generations "
                    "(source_record_id, generation, updated_at, tenant_id) VALUES "
                    "('shared-source', 7, CURRENT_TIMESTAMP, 'tenant-a')"
                )
            )
    finally:
        engine.dispose()

    revision = await upgrade_database(async_url)
    assert revision == _HEAD_REVISION

    engine = create_engine(sync_url)
    try:
        schema = inspect(engine)
        assert "task_id" in {
            column["name"]
            for column in schema.get_columns("knowledge_source_occurrences")
        }
        relationship_columns = {
            column["name"]
            for column in schema.get_columns("knowledge_relationship_claims")
        }
        assert {"source_record_id", "source_version"}.issubset(relationship_columns)
        binding_columns = {
            column["name"]
            for column in schema.get_columns("knowledge_entity_source_bindings")
        }
        assert {
            "asserted_label",
            "asserted_attributes",
            "asserted_lifecycle_status",
            "asserted_confidence",
        }.issubset(binding_columns)
        generation_columns = {
            column["name"]
            for column in schema.get_columns("knowledge_graph_generations")
        }
        assert "generation_id" in generation_columns
        lifecycle_columns = {
            column["name"] for column in schema.get_columns("knowledge_task_lifecycles")
        }
        assert {
            "lifecycle_id",
            "tenant_id",
            "task_id",
            "epoch",
            "status",
            "updated_at",
            "tombstoned_at",
        } == lifecycle_columns
        assert "review_task_id" in {
            column["name"]
            for column in schema.get_columns("knowledge_review_decisions")
        }
        assert {
            "knowledge_route_profiles",
            "knowledge_route_observations",
            "knowledge_entity_route_index",
            "knowledge_entity_route_decisions",
            "knowledge_document_identity_bindings",
            "knowledge_document_identity_decisions",
            "knowledge_tabular_layout_profiles",
            "knowledge_tabular_layout_observations",
        }.issubset(schema.get_table_names())
        with engine.connect() as connection:
            row = connection.execute(
                text(
                    "SELECT tenant_id, source_record_id, generation "
                    "FROM knowledge_graph_generations"
                )
            ).one()
            assert tuple(row) == ("tenant-a", "shared-source", 7)
            assert (
                connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                == revision
            )
    finally:
        engine.dispose()
