from __future__ import annotations

import json
from copy import deepcopy

import pytest
from m1.knowledge import (
    GraphSink,
    HybridSearchEngine,
    InMemoryGraphSink,
    apply_semantic_enrichment,
    build_field_index_documents,
    build_graph_projection,
    build_knowledge_chunks,
    build_knowledge_records,
    hybrid_search,
)
from m1.knowledge.projection import (
    MAX_INDEXED_CUSTOM_FIELDS,
    MAX_INDEXED_CUSTOM_TOTAL_CHARS,
    MAX_INDEXED_CUSTOM_VALUE_CHARS,
)


def _document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "DP备货单.xlsx",
            "display_filename": "DP备货单.xlsx",
            "sha256": "a" * 64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "sheet": "订单",
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "DP备货单",
            "issuer": "云派科技",
            "order_number": "TX2607150002",
            "date_raw": "7月15日",
            "date_standard": "2026-07-15",
            "date_inferred": True,
            "buyer": "桐曦",
            "supplier": "云派科技",
        },
        "lines": [
            {
                "line_id": "订单:6:1",
                "line_no": 1,
                "model": "DP-100",
                "product_code": "P-001",
                "name_raw": "DP 8K线 1米",
                "name_normalized": "DisplayPort 8K连接线 1m",
                "full_product_name": "P-001 DP-100 DisplayPort 8K连接线 1m",
                "product_category": "cable",
                "name_attributes": {"interface": "DP", "resolution": "8K"},
                "specification_raw": "DP1.4, 1m, 黑色",
                "quantity": 800,
                "unit": "PCS",
                "remark": "首批",
                "raw_columns": {"可订": "Y", "内部隐藏列": "不得进入精选索引"},
            },
            {
                "line_id": "订单:7:1",
                "line_no": 2,
                "model": "HDMI-200",
                "name_raw": "HDMI线 2米",
                "name_normalized": "HDMI连接线 2m",
                "quantity": 1000,
                "unit": "PCS",
            },
        ],
        "totals": {
            "declared_quantity": 1800,
            "calculated_quantity": 1800,
            "quantity_matches": True,
            "system_calculated": {"quantity": 1800, "row_count": 2},
        },
        "field_meta": {
            "$.header.order_number": {
                "source_refs": [{"sheet": "订单", "cell": "Q3"}],
                "confidence": 1.0,
            },
            "$.header.date_standard": {
                "source_refs": [{"sheet": "订单", "cell": "Q4"}],
                "confidence": 0.9,
                "inferred": True,
            },
            "$.lines[0].model": {
                "source_refs": [{"sheet": "订单", "cell": "D6"}],
                "confidence": 1.0,
            },
            "$.lines[0].quantity": {
                "source_refs": [{"sheet": "订单", "cell": "Q6"}],
                "confidence": 1.0,
            },
        },
        "validation_issues": [],
        "needs_review": False,
        "extraction": {
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "text_original": "技术证据：DP-100 满足 DP1.4 和 8K 要求。",
                        "text_normalized": "技术证据: DP-100 满足 DP1.4 和 8K 要求。",
                    }
                ]
            },
            "sections": [],
        },
    }


def test_records_and_claims_are_stable_evidence_backed_and_fact_locked():
    document = _document()
    first = build_knowledge_records(document, tenant_id="tenant-a")
    second = build_knowledge_records(deepcopy(document), tenant_id="tenant-a")

    assert [record.record_id for record in first] == [record.record_id for record in second]
    assert [claim.claim_id for record in first for claim in record.claims] == [
        claim.claim_id for record in second for claim in record.claims
    ]
    assert len(first) == 3
    line = first[1]
    assert line.facts["quantity"] == 800
    assert "name_normalized" not in line.facts
    assert line.semantic_annotations["name_normalized"] == "DisplayPort 8K连接线 1m"

    quantity = next(claim for claim in line.claims if claim.path == "$.lines[0].quantity")
    assert quantity.fact_locked is True
    assert quantity.origin == "source"
    assert quantity.source_refs[0].cell == "Q6"
    normalized_name = next(
        claim for claim in line.claims if claim.path == "$.lines[0].name_normalized"
    )
    assert normalized_name.fact_locked is False
    assert normalized_name.origin == "semantic"

    inferred_date = next(
        claim for claim in first[0].claims if claim.path == "$.header.date_standard"
    )
    assert inferred_date.fact_locked is True
    assert inferred_date.inferred is True
    assert inferred_date.origin == "deterministic_inference"


def test_semantic_merge_rejects_vlm_fact_changes_without_mutating_input():
    document = _document()
    before = deepcopy(document)
    result = apply_semantic_enrichment(
        document,
        {
            "header": {"order_number": "VLM-HALLUCINATION"},
            "lines": [
                {
                    "line_id": "订单:6:1",
                    "name_normalized": "DP 8K成品线 1m",
                    "name_attributes": {"interface": "DP", "protocol_version": "1.4"},
                    "quantity": 999999,
                    "model": "FAKE-MODEL",
                }
            ],
        },
    )

    assert document == before
    assert result.document["header"]["order_number"] == "TX2607150002"
    assert result.document["lines"][0]["quantity"] == 800
    assert result.document["lines"][0]["model"] == "DP-100"
    assert result.document["lines"][0]["name_normalized"] == "DP 8K成品线 1m"
    assert "$.header" in result.rejected_paths
    assert "$.lines[0].quantity" in result.rejected_paths
    assert "$.lines[0].model" in result.rejected_paths


def test_chunks_and_selected_field_index_preserve_evidence_and_omit_raw_columns():
    document = _document()
    chunks = build_knowledge_chunks(document, tenant_id="tenant-a")
    rerun = build_knowledge_chunks(deepcopy(document), tenant_id="tenant-a")

    assert [chunk.chunk_id for chunk in chunks] == [chunk.chunk_id for chunk in rerun]
    assert {chunk.chunk_kind for chunk in chunks} == {"header", "line", "page"}
    line_chunk = next(chunk for chunk in chunks if chunk.chunk_kind == "line")
    page_chunk = next(chunk for chunk in chunks if chunk.chunk_kind == "page")
    assert any(ref.cell == "Q6" for ref in line_chunk.source_refs)
    assert page_chunk.source_refs[0].page == 1
    assert page_chunk.content_sha256

    indexed = build_field_index_documents(document, tenant_id="tenant-a")
    first_line = next(item for item in indexed if item.metadata["chunk_kind"] == "line")
    assert first_line.selected_fields["model"] == "DP-100"
    assert "raw_columns" not in first_line.selected_fields
    assert "内部隐藏列" not in first_line.text
    assert first_line.graph_keys == ["P-001", "DP-100"]


def test_generic_facts_become_searchable_claims_without_product_entities():
    document = _document()
    document.update(
        {
            "document_type": "technical_document",
            "document_subtype": "service_policy",
            "header": {"title": "产品售后服务政策"},
            "lines": [],
            "totals": {},
            "generic_facts": [
                {
                    "name": "table_record",
                    "value": {
                        "类别": "MINI PC",
                        "子类别": "主要部件",
                        "保修期限": "3年",
                    },
                    "source_refs": [
                        {
                            "page": 1,
                            "part": "mineru/p1:t0:r5",
                            "bbox": [0.03, 0.58, 0.89, 0.83],
                            "coordinate_space": "normalized",
                        }
                    ],
                },
                {
                    "name": "internal_note",
                    "value": "不得公开的内部处理说明",
                    "source_refs": [{"page": 1, "part": "mineru/p1:b9"}],
                    "sensitive": True,
                },
            ],
            "field_meta": {
                "$.generic_facts[0].value": {
                    "source_refs": [{"page": 1, "part": "mineru/p1:t0:r5"}],
                    "confidence": 1.0,
                },
                "$.generic_facts[1].value": {
                    "source_refs": [{"page": 1, "part": "mineru/p1:b9"}],
                    "confidence": 1.0,
                },
            },
            "needs_review": True,
        }
    )

    records = build_knowledge_records(document, tenant_id="tenant-a")
    root = records[0]
    generic_claims = [
        claim for claim in root.claims if claim.path.startswith("$.generic_facts[0]")
    ]
    assert {claim.value for claim in generic_claims} == {
        "MINI PC",
        "主要部件",
        "3年",
    }
    assert all(claim.source_refs[0].part == "mineru/p1:t0:r5" for claim in generic_claims)
    assert not any(
        claim.path.startswith("$.generic_facts[1]") for claim in root.claims
    )

    chunks = build_knowledge_chunks(document, tenant_id="tenant-a")
    generic_chunks = [chunk for chunk in chunks if chunk.chunk_kind == "generic_fact"]
    assert len(generic_chunks) == 1
    assert "MINI PC" in generic_chunks[0].text
    assert "保修期限=3年" in generic_chunks[0].text
    assert "不得公开" not in "\n".join(chunk.text for chunk in chunks)

    indexed = build_field_index_documents(document, tenant_id="tenant-a")
    hits = HybridSearchEngine(indexed).search("MINI PC 3年", tenant_id="tenant-a")
    assert hits
    assert hits[0].document.metadata["chunk_kind"] == "generic_fact"
    graph = build_graph_projection(document, tenant_id="tenant-a")
    assert any("TechnicalDocument" in node.labels for node in graph.nodes)
    assert not any("Product" in node.labels for node in graph.nodes)


def test_dynamic_custom_fields_are_searchable_without_indexing_raw_column_duplicates():
    document = _document()
    document["lines"][0]["custom_fields"] = {
        "型号": "W-H937",
        "备货数量": 800,
        "料号": "50403-326",
        "规格参数": {"外径": "27.6mm", "颜色": "太空灰"},
    }
    document["lines"][0]["raw_columns"] = {
        "型号": "W-H937",
        "备货数量": 800,
        "仅原始列": "RAW-ONLY-999",
    }

    documents = build_field_index_documents(document, tenant_id="tenant-a")
    target = next(
        item
        for item in documents
        if item.metadata["chunk_kind"] == "line"
        and item.selected_fields.get("model") == "DP-100"
    )

    assert target.selected_fields["custom_fields"] == {
        "备货数量": 800,
        "型号": "W-H937",
        "料号": "50403-326",
        "规格参数": {"外径": "27.6mm", "颜色": "太空灰"},
    }
    assert "型号=W-H937" in target.text
    assert "备货数量=800" in target.text
    assert "raw_columns" not in target.selected_fields
    assert "RAW-ONLY-999" not in target.text

    engine = HybridSearchEngine(documents)
    for identifier in ("W-H937", "50403-326"):
        hits = engine.search(identifier, tenant_id="tenant-a")
        assert hits
        assert hits[0].index_id == target.index_id
        assert hits[0].match_reason == "exact_identifier"


def test_dynamic_custom_fields_are_stable_and_bounded():
    document = _document()
    custom_fields = {
        "00长说明": "规格" * 300,
        "01预览数据": "data:image/png;base64," + "A" * 1024,
        "02preview_base64": "A" * 1024,
        "03image_refs": ["asset-1.png"],
        "04deep": {"level1": {"level2": {"level3": "TOO-DEEP"}}},
        **{
            f"字段{index:02d}": f"值{index:02d}"
            for index in range(MAX_INDEXED_CUSTOM_FIELDS + 8)
        },
    }
    document["lines"][0]["custom_fields"] = custom_fields
    document["lines"][0]["raw_columns"] = {"隐藏原始字段": "RAW-ONLY-BOUNDED"}

    first = build_field_index_documents(document, tenant_id="tenant-a")
    first_line = next(item for item in first if item.metadata["chunk_kind"] == "line")
    selected = first_line.selected_fields["custom_fields"]

    assert len(selected) == MAX_INDEXED_CUSTOM_FIELDS
    assert len(selected["00长说明"]) == MAX_INDEXED_CUSTOM_VALUE_CHARS
    assert selected["00长说明"].endswith("...")
    assert len(
        json.dumps(selected, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    ) <= MAX_INDEXED_CUSTOM_TOTAL_CHARS
    assert "01预览数据" not in selected
    assert "02preview_base64" not in selected
    assert "03image_refs" not in selected
    assert "04deep" not in selected
    assert "RAW-ONLY-BOUNDED" not in first_line.text

    reversed_document = deepcopy(document)
    reversed_document["lines"][0]["custom_fields"] = dict(
        reversed(list(custom_fields.items()))
    )
    second = build_field_index_documents(reversed_document, tenant_id="tenant-a")
    second_line = next(item for item in second if item.metadata["chunk_kind"] == "line")
    assert second_line.selected_fields == first_line.selected_fields
    assert second_line.index_id == first_line.index_id


def test_graph_projection_is_rebuildable_and_every_element_has_governance_metadata():
    document = _document()
    projection = build_graph_projection(document, tenant_id="tenant-a", version="v1")

    assert any("Order" in node.labels for node in projection.nodes)
    assert any("Product" in node.labels for node in projection.nodes)
    assert {edge.relation for edge in projection.edges} >= {
        "HAS_LINE",
        "REFERS_TO_PRODUCT",
        "HAS_BUYER",
        "HAS_SUPPLIER",
    }
    for element in [*projection.nodes, *projection.edges]:
        assert element.tenant_id == "tenant-a"
        assert element.source_record_id == projection.source_record_id
        assert element.version == "v1"
        assert element.status == "active"
        assert element.confidence > 0

    sink = InMemoryGraphSink()
    assert isinstance(sink, GraphSink)
    sink.replace_projection(projection)
    v2 = build_graph_projection(document, tenant_id="tenant-a", version="v2")
    sink.replace_projection(v2)
    assert len(sink.projections) == 1
    assert sink.projections[0].version == "v2"
    assert all(node.version == "v2" for node in sink.nodes.values())
    sink.delete_projection("tenant-a", projection.source_record_id)
    assert sink.projections == ()


def test_commercial_document_projection_uses_the_audited_graph_label():
    document = _document()
    document["document_type"] = "commercial_document"
    document["document_subtype"] = "quotation"

    projection = build_graph_projection(document, tenant_id="tenant-a", version="v1")
    document_node = next(
        node for node in projection.nodes if "Document" in node.labels
    )

    assert document_node.labels == ["Document", "CommercialDocument"]


@pytest.mark.parametrize(
    ("document_type", "expected_label"),
    (
        ("inventory_report", "Inventory"),
        ("procurement_process", "Procurement"),
        ("purchase_order", "Order"),
        ("purchase_contract", "Order"),
        ("po", "Order"),
        ("sales_order", "Order"),
        ("approval_drawing", "TechnicalDocument"),
        ("drawing", "TechnicalDocument"),
        ("quotation", "CommercialDocument"),
    ),
)
def test_graph_projection_normalizes_legacy_document_type_aliases(
    document_type: str,
    expected_label: str,
):
    document = _document()
    document["document_type"] = document_type

    projection = build_graph_projection(document, tenant_id="tenant-a", version="v1")
    document_node = next(
        node for node in projection.nodes if "Document" in node.labels
    )

    assert document_node.labels == ["Document", expected_label]
    assert document_node.properties["document_type"] == document_type


def test_graph_projection_keeps_unknown_document_types_as_document_properties():
    document = _document()
    document["document_type"] = "application_form"

    projection = build_graph_projection(document, tenant_id="tenant-a", version="v1")
    document_node = next(
        node for node in projection.nodes if "Document" in node.labels
    )

    assert document_node.labels == ["Document"]
    assert document_node.properties["document_type"] == "application_form"


def test_graph_projection_normalizes_full_width_known_document_types():
    document = _document()
    document["document_type"] = " ＰＯ "

    projection = build_graph_projection(document, tenant_id="tenant-a", version="v1")
    document_node = next(
        node for node in projection.nodes if "Document" in node.labels
    )

    assert document_node.labels == ["Document", "Order"]


def test_graph_projection_rejects_cross_tenant_canonical_records():
    records = build_knowledge_records(_document(), tenant_id="tenant-a")
    records[1] = records[1].model_copy(update={"tenant_id": "tenant-b"})
    with pytest.raises(ValueError, match="tenant"):
        build_graph_projection(records)


def test_hybrid_search_combines_keyword_vector_graph_and_filters():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    other = [item.model_copy(update={"tenant_id": "tenant-b"}) for item in documents]
    engine = HybridSearchEngine([*documents, *other])
    dp = next(item for item in documents if item.selected_fields.get("model") == "DP-100")
    hdmi = next(item for item in documents if item.selected_fields.get("model") == "HDMI-200")

    keyword_hits = engine.search(
        "DP-100 8K", tenant_id="tenant-a", filters={"document_type": "order"}
    )
    assert keyword_hits[0].index_id == dp.index_id
    assert all(hit.document.tenant_id == "tenant-a" for hit in keyword_hits)

    boosted = engine.search(
        "连接线",
        tenant_id="tenant-a",
        vector_scores={hdmi.index_id: 1.0},
        graph_context={"HDMI-200": 1.0},
        keyword_weight=0.1,
        vector_weight=0.6,
        graph_weight=0.3,
    )
    assert boosted[0].index_id == hdmi.index_id
    assert boosted[0].vector_score == 1.0
    assert boosted[0].graph_score == 1.0

    one_shot = hybrid_search(documents, "P-001", tenant_id="tenant-a", limit=1)
    assert one_shot[0].record_id == dp.record_id


def test_precise_search_filters_low_scores_identifiers_and_duplicate_sources():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    engine = HybridSearchEngine(documents)
    dp = next(item for item in documents if item.selected_fields.get("model") == "DP-100")

    identifier_hits = engine.search("DP-100", tenant_id="tenant-a", limit=10)
    assert identifier_hits
    assert identifier_hits[0].index_id == dp.index_id
    assert identifier_hits[0].match_reason == "exact_identifier"
    assert all(hit.document.source_record_id == dp.source_record_id for hit in identifier_hits)
    assert len(identifier_hits) <= 2

    assert engine.search(
        "NO-SUCH-999",
        tenant_id="tenant-a",
        vector_scores={dp.index_id: 0.29},
    ) == []
    broad = engine.search(
        "NO-SUCH-999",
        tenant_id="tenant-a",
        vector_scores={dp.index_id: 0.29},
        mode="broad",
        min_score=0,
    )
    assert broad


def test_precise_search_requires_compact_and_numeric_identifiers_to_match():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    dp = next(item for item in documents if item.selected_fields.get("model") == "DP-100")
    compact_identifier = "TX2699990001"
    numeric_identifier = "2607150002"
    indexed = dp.model_copy(
        update={
            "text": f"{dp.text} {compact_identifier} {numeric_identifier}",
            "vector_text": f"{dp.vector_text} {compact_identifier} {numeric_identifier}",
            "selected_fields": {
                **dp.selected_fields,
                "order_number": compact_identifier,
                "material_number": numeric_identifier,
            },
        }
    )
    engine = HybridSearchEngine([indexed])

    compact_hits = engine.search(
        compact_identifier,
        tenant_id="tenant-a",
        vector_scores={indexed.index_id: 0.99},
    )
    assert compact_hits[0].match_reason == "exact_identifier"

    numeric_hits = engine.search(
        numeric_identifier,
        tenant_id="tenant-a",
        vector_scores={indexed.index_id: 0.99},
    )
    assert numeric_hits[0].match_reason == "exact_identifier"

    assert engine.search(
        "TX2699999999",
        tenant_id="tenant-a",
        vector_scores={indexed.index_id: 0.99},
    ) == []


def test_precise_search_requires_keyword_or_strong_vector_not_graph_only():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    target = documents[0]
    engine = HybridSearchEngine(documents)

    assert engine.search(
        "unrelated phrase",
        tenant_id="tenant-a",
        graph_context={target.index_id: 1.0},
    ) == []

    vector_hits = engine.search(
        "unrelated phrase",
        tenant_id="tenant-a",
        vector_scores={target.index_id: 0.55},
    )
    assert vector_hits[0].index_id == target.index_id
    assert vector_hits[0].match_reason == "vector"

    graph_hits = engine.search(
        "unrelated phrase",
        tenant_id="tenant-a",
        graph_context={target.index_id: 1.0},
        mode="broad",
    )
    assert graph_hits[0].index_id == target.index_id
    assert graph_hits[0].match_reason == "graph"


def test_identifier_match_uses_structured_fields_and_exact_boundaries():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    target = documents[0].model_copy(
        update={
            "text": "no identifier in the body",
            "vector_text": "vector projection also omits it",
            "selected_fields": {"order_number": "TX2607150002"},
        }
    )
    longer = documents[1].model_copy(
        update={
            "text": "order TX26071500020",
            "vector_text": "order TX26071500020",
            "selected_fields": {"order_number": "TX26071500020"},
        }
    )
    engine = HybridSearchEngine([target, longer])

    hits = engine.search("TX2607150002", tenant_id="tenant-a")
    assert [hit.index_id for hit in hits] == [target.index_id]
    assert hits[0].score == 1.0
    assert hits[0].match_reason == "exact_identifier"

    broad = engine.search(
        "NO-SUCH-999",
        tenant_id="tenant-a",
        vector_scores={target.index_id: 0.9},
        mode="broad",
    )
    assert broad[0].match_reason == "vector"


def test_identifier_boundary_rejects_a_longer_separated_identifier():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    target = documents[0].model_copy(
        update={
            "text": "model DP-10-A",
            "vector_text": "model DP-10-A",
            "selected_fields": {"model": "DP-10-A"},
        }
    )

    assert HybridSearchEngine([target]).search("DP-10", tenant_id="tenant-a") == []


def test_precise_search_limits_each_source_to_two_hits():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    source = documents[0].source_record_id
    same_source = [
        documents[0].model_copy(
            update={
                "index_id": f"same-source-{index}",
                "record_id": f"same-record-{index}",
                "text": f"shared reliable keyword row {index}",
            }
        )
        for index in range(3)
    ]
    other_source = documents[1].model_copy(
        update={
            "index_id": "other-source",
            "record_id": "other-record",
            "source_record_id": "different-source",
            "text": "shared reliable keyword other row",
        }
    )

    hits = HybridSearchEngine([*same_source, other_source]).search(
        "shared reliable keyword",
        tenant_id="tenant-a",
        limit=10,
    )
    assert sum(hit.document.source_record_id == source for hit in hits) == 2
    assert any(hit.document.source_record_id == "different-source" for hit in hits)


def test_exact_score_ties_prefer_the_newest_source():
    documents = build_field_index_documents(_document(), tenant_id="tenant-a")
    old = documents[0].model_copy(
        update={
            "index_id": "old-index",
            "record_id": "old-record",
            "source_record_id": "old-source",
            "text": "order TX2607150002",
        }
    )
    new = old.model_copy(
        update={
            "index_id": "new-index",
            "record_id": "new-record",
            "source_record_id": "new-source",
        }
    )

    hits = HybridSearchEngine(
        [old, new],
        rank_timestamps={old.index_id: 1.0, new.index_id: 2.0},
    ).search("TX2607150002", tenant_id="tenant-a")

    assert [hit.document.source_record_id for hit in hits] == [
        "new-source",
        "old-source",
    ]
