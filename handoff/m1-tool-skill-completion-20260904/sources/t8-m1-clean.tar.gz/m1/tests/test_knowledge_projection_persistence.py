from __future__ import annotations

import asyncio
import copy
import hashlib
from datetime import timedelta

import pytest
from sqlalchemy import select

from m1.knowledge import KnowledgeStore, TenantBoundaryError, TenantRecord
from m1.knowledge.db_models import (
    DocumentVersionRow,
    GraphGenerationRow,
    GraphProjectionSnapshotRow,
    ProjectionOutboxRow,
)
from m1.knowledge.models import GraphProjection
from m1.knowledge.rebuild_terminal_graph_event import rebuild_terminal_graph_event
from m1.knowledge.requeue_terminal_graph_event import (
    requeue_terminal_graph_event as requeue_terminal_graph_event_command,
)
from m1.knowledge.schema import LifecycleStatus, ProjectionEventRecord, utc_now


def _document(*, model: str = "DP-100", needs_review: bool = False) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "order.xlsx",
            "display_filename": "order.xlsx",
            "sha256": "b" * 64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "sheet": "订单",
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "DP备货单",
            "order_number": "TX2607150002",
            "buyer": "桐曦",
            "supplier": "云派科技",
        },
        "lines": [{
            "line_id": "line-1",
            "line_no": 1,
            "model": model,
            "product_code": "P-001" if model == "DP-100" else "P-NEW",
            "name_raw": f"{model} 8K连接线",
            "name_normalized": f"{model} DisplayPort 8K连接线",
            "product_category": "cable",
            "quantity": 800,
            "unit": "PCS",
        }],
        "totals": {"calculated_quantity": 800},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "订单", "cell": "Q3"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "订单", "cell": "D6"}],
            },
        },
        "validation_issues": [],
        "needs_review": needs_review,
    }


@pytest.fixture
async def projection_wiki(tmp_path):
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'projection.db'}")
    await store.init()
    tenant = await store.create_tenant(TenantRecord(
        tenant_key="projection-a",
        display_name="Projection Tenant A",
    ))
    try:
        yield store, tenant
    finally:
        await store.close()


def _embedding_event(tenant_id: str, suffix: str) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        tenant_id=tenant_id,
        projection_name="embedding",
        idempotency_key=f"embedding-lease-{suffix}",
        aggregate_type="document_projection",
        aggregate_id=f"source-{suffix}",
        event_type="embedding.projection.replaced",
    )


def _lightrag_event(
    tenant_id: str,
    *,
    source_record_id: str,
    action: str,
    created_at,
) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        tenant_id=tenant_id,
        projection_name="lightrag_shadow",
        idempotency_key=f"lightrag-{source_record_id}-{action}",
        aggregate_type="document_projection",
        aggregate_id=source_record_id,
        event_type=f"lightrag.shadow.{action}",
        payload={"source_record_id": source_record_id, "action": action},
        available_at=created_at,
        created_at=created_at,
    )


async def _active_governed_projection(
    store: KnowledgeStore,
    tenant: TenantRecord,
    *,
    task_id: str,
) -> tuple[dict, object, object]:
    """Create the governed active version required by rebuild recovery."""

    document = _document()
    document["document_type"] = "inventory_report"
    ingested = await store.ingest_document(
        tenant.tenant_id,
        task_id,
        document,
    )
    projection = await store.replace_document_projections(
        tenant.tenant_id,
        document,
        source_record_id=ingested.document_id,
        version=str(ingested.version_number),
        status_override="active",
    )
    return document, ingested, projection


async def _make_legacy_dynamic_graph_failure(
    store: KnowledgeStore,
    tenant: TenantRecord,
    *,
    document_id: str,
    version: str,
    event_id: str,
) -> None:
    """Make an old persisted label/event pair that matches its snapshot."""

    legacy_fingerprint = hashlib.sha256(
        f"legacy-dynamic-label:{document_id}:{version}".encode()
    ).hexdigest()
    async with store.sessionmaker.begin() as session:
        snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == document_id,
                GraphProjectionSnapshotRow.version == version,
            )
        )
        event = await session.get(ProjectionOutboxRow, event_id)
        assert snapshot is not None
        assert event is not None
        legacy_graph = copy.deepcopy(snapshot.projection_json)
        root_node = next(
            node
            for node in legacy_graph["nodes"]
            if node["properties"].get("document_type") == "inventory_report"
        )
        assert root_node["labels"] == ["Document", "Inventory"]
        root_node["labels"] = ["Document", "InventoryReport"]
        snapshot.projection_json = legacy_graph
        snapshot.fingerprint = legacy_fingerprint
        event.payload = {**event.payload, "fingerprint": legacy_fingerprint}

    leased = await store.lease_projection_event(event_id, tenant_id=tenant.tenant_id)
    assert leased is not None
    assert await store.fail_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
        error="graph label is not whitelisted: 'InventoryReport'",
        terminal=True,
        lease_attempt=leased.attempts,
    )


@pytest.mark.asyncio
async def test_exact_and_worker_outbox_claims_have_one_owner(projection_wiki):
    store, tenant = projection_wiki
    event = await store.enqueue_projection(_embedding_event(tenant.tenant_id, "race"))

    exact, batch = await asyncio.gather(
        store.lease_projection_event(
            event.event_id,
            tenant_id=tenant.tenant_id,
            lease_seconds=30,
        ),
        store.lease_projection_events(
            "embedding",
            tenant_id=tenant.tenant_id,
            limit=1,
            lease_seconds=30,
        ),
    )

    owners = ([exact] if exact is not None else []) + batch
    assert len(owners) == 1
    assert owners[0].event_id == event.event_id
    assert owners[0].attempts == 1


@pytest.mark.asyncio
async def test_stale_outbox_completion_cannot_overwrite_new_lease_or_delivery(
    projection_wiki,
):
    store, tenant = projection_wiki
    event = await store.enqueue_projection(_embedding_event(tenant.tenant_id, "cas"))
    started_at = utc_now()

    first = await store.lease_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        lease_seconds=1,
        now=started_at,
    )
    assert first is not None and first.attempts == 1
    second = await store.lease_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        lease_seconds=1,
        now=started_at + timedelta(seconds=2),
    )
    assert second is not None and second.attempts == 2

    assert await store.mark_projection_delivered(
        event.event_id,
        tenant_id=tenant.tenant_id,
        lease_attempt=first.attempts,
    ) is False
    assert await store.fail_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        error="stale owner",
        lease_attempt=first.attempts,
    ) is False
    assert await store.lease_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        now=started_at + timedelta(seconds=2.5),
    ) is None

    assert await store.mark_projection_delivered(
        event.event_id,
        tenant_id=tenant.tenant_id,
        lease_attempt=second.attempts,
    ) is True
    assert await store.fail_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        error="late failure",
        lease_attempt=second.attempts,
    ) is False
    stats = await store.projection_stats(tenant.tenant_id)
    assert stats["outbox"] == {"embedding:delivered": 1}


@pytest.mark.asyncio
async def test_terminal_graph_event_requeue_is_guarded_and_idempotent(projection_wiki):
    store, tenant = projection_wiki
    projection = await store.replace_document_projections(
        tenant.tenant_id,
        _document(),
        source_record_id="source-commercial-document",
        version="v1",
    )
    event_id = projection.graph_event_id
    leased = await store.lease_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    terminal_error = (
        "ordinary_failures=10 graph label is not whitelisted: "
        "'CommercialDocument'"
    )
    assert await store.fail_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
        error=terminal_error,
        terminal=True,
        lease_attempt=leased.attempts,
    )

    with pytest.raises(ValueError, match="did not match"):
        await store.requeue_terminal_graph_event(
            event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="some other failure",
        )
    with pytest.raises(TenantBoundaryError):
        await store.requeue_terminal_graph_event(
            event_id,
            tenant_id="another-tenant",
            expected_last_error_contains="CommercialDocument",
        )

    first = await store.requeue_terminal_graph_event(
        event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="CommercialDocument",
    )
    second = await store.requeue_terminal_graph_event(
        event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="CommercialDocument",
    )

    assert first.status == second.status == "pending"
    assert first.event_id == second.event_id == event_id
    assert first.attempts == second.attempts == leased.attempts
    assert first.last_error == second.last_error == (
        "terminal_graph_replay_once=true "
        f"original_error_sha256={first.payload['_terminal_graph_replay']['original_error_sha256']}"
    )
    replay_lease = await store.lease_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
    )
    assert replay_lease is not None
    assert replay_lease.attempts == leased.attempts + 1
    assert await store.mark_projection_delivered(
        event_id,
        tenant_id=tenant.tenant_id,
        lease_attempt=replay_lease.attempts,
    )
    delivered = await store.requeue_terminal_graph_event(
        event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="CommercialDocument",
    )
    assert delivered.status == "delivered"


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_regenerates_snapshot_and_delivers_fresh_event(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-rebuild",
    )
    source_version = str(ingested.version_number)
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=source_version,
        event_id=projection.graph_event_id,
    )

    replacement = await store.rebuild_terminal_graph_projection_event(
        projection.graph_event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="graph label is not whitelisted",
    )
    repeated = await store.rebuild_terminal_graph_projection_event(
        projection.graph_event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="graph label is not whitelisted",
    )

    assert replacement.event_id != projection.graph_event_id
    assert replacement.event_id == repeated.event_id
    assert replacement.status == repeated.status == "pending"
    assert replacement.payload["_terminal_graph_recovery"] == {
        "mode": "rebuild_snapshot_and_replay",
        "source_event_id": projection.graph_event_id,
    }
    graph = await store.get_graph_projection(
        tenant.tenant_id,
        ingested.document_id,
        source_version,
    )
    assert graph is not None
    root_node = next(
        node
        for node in graph.nodes
        if node.properties.get("document_type") == "inventory_report"
    )
    assert root_node.labels == ["Document", "Inventory"]
    assert all("InventoryReport" not in node.labels for node in graph.nodes)

    async with store.sessionmaker() as session:
        original = await session.get(ProjectionOutboxRow, projection.graph_event_id)
        generation = await session.scalar(
            select(GraphGenerationRow).where(
                GraphGenerationRow.tenant_id == tenant.tenant_id,
                GraphGenerationRow.source_record_id == ingested.document_id,
            )
        )
    assert original is not None
    assert original.status == "failed"
    assert original.last_error.startswith("superseded by terminal graph rebuild")
    marker = original.payload["_terminal_graph_rebuild"]
    assert marker["replacement_event_id"] == replacement.event_id
    assert marker["original_error_sha256"]
    assert generation is not None
    assert generation.generation == replacement.payload["generation"]
    assert (await store.projection_outbox_health(tenant.tenant_id))["terminal_failures"] == 0

    leased = await store.lease_projection_event(
        replacement.event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.mark_projection_delivered(
        replacement.event_id,
        tenant_id=tenant.tenant_id,
        lease_attempt=leased.attempts,
    )
    async with store.sessionmaker() as session:
        delivered = await session.get(ProjectionOutboxRow, replacement.event_id)
    assert delivered is not None
    assert delivered.status == "delivered"


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_helper_uses_configured_store(
    projection_wiki,
    monkeypatch,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-helper",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    monkeypatch.setenv("KNOWLEDGE_DATABASE_URL", str(store.engine.url))

    result = await rebuild_terminal_graph_event(
        tenant_id=tenant.tenant_id,
        event_id=projection.graph_event_id,
        expected_error_contains="graph label is not whitelisted",
    )

    assert result["recovered_event_id"] == projection.graph_event_id
    assert result["event_id"] != projection.graph_event_id
    assert result["tenant_id"] == tenant.tenant_id
    assert result["projection_name"] == "graph"
    assert result["status"] == "pending"


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_helper_retires_stale_source(
    projection_wiki,
    monkeypatch,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-helper-retired",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    async with store.sessionmaker.begin() as session:
        version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == ingested.document_id,
                GraphProjectionSnapshotRow.version == str(ingested.version_number),
            )
        )
        assert version is not None
        assert snapshot is not None
        version.lifecycle_status = "deprecated"
        snapshot.status = "deprecated"
    monkeypatch.setenv("KNOWLEDGE_DATABASE_URL", str(store.engine.url))

    result = await rebuild_terminal_graph_event(
        tenant_id=tenant.tenant_id,
        event_id=projection.graph_event_id,
        expected_error_contains="graph label is not whitelisted",
    )

    assert result["recovered_event_id"] == projection.graph_event_id
    assert result["event_id"] == projection.graph_event_id
    assert result["status"] == "retired"


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_helper_preserves_nonretirement_reason(
    projection_wiki,
    monkeypatch,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-helper-nonterminal",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    async with store.sessionmaker.begin() as session:
        version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == ingested.document_id,
                GraphProjectionSnapshotRow.version == str(ingested.version_number),
            )
        )
        assert version is not None
        assert snapshot is not None
        version.lifecycle_status = LifecycleStatus.UNDER_REVIEW.value
        snapshot.status = "deprecated"
    monkeypatch.setenv("KNOWLEDGE_DATABASE_URL", str(store.engine.url))

    with pytest.raises(ValueError, match="no longer has an active source version"):
        await rebuild_terminal_graph_event(
            tenant_id=tenant.tenant_id,
            event_id=projection.graph_event_id,
            expected_error_contains="graph label is not whitelisted",
        )


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_rejects_wrong_tenant_and_stale_generation(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-stale",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )

    with pytest.raises(TenantBoundaryError):
        await store.rebuild_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id="another-tenant",
            expected_last_error_contains="graph label is not whitelisted",
        )
    async with store.sessionmaker.begin() as session:
        generation = await session.scalar(
            select(GraphGenerationRow).where(
                GraphGenerationRow.tenant_id == tenant.tenant_id,
                GraphGenerationRow.source_record_id == ingested.document_id,
            )
        )
        assert generation is not None
        generation.generation += 1

    with pytest.raises(ValueError, match="no longer matches the active graph"):
        await store.rebuild_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="graph label is not whitelisted",
        )


@pytest.mark.asyncio
async def test_terminal_graph_rebuild_rejects_retired_or_lifecycle_events(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-retired",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    async with store.sessionmaker.begin() as session:
        version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        assert version is not None
        version.lifecycle_status = "deprecated"

    with pytest.raises(ValueError, match="no longer has an active source version"):
        await store.rebuild_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="graph label is not whitelisted",
        )

    tombstone = await store.enqueue_projection(
        ProjectionEventRecord(
            tenant_id=tenant.tenant_id,
            projection_name="graph",
            idempotency_key="graph-terminal-rebuild-tombstone",
            aggregate_type="document_projection",
            aggregate_id=ingested.document_id,
            event_type="graph.projection.deleted",
            payload={"source_record_id": ingested.document_id, "action": "delete"},
        )
    )
    leased = await store.lease_projection_event(
        tombstone.event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.fail_projection_event(
        tombstone.event_id,
        tenant_id=tenant.tenant_id,
        error="source task tombstoned: task-terminal-graph-retired",
        terminal=True,
        lease_attempt=leased.attempts,
    )
    with pytest.raises(ValueError, match="lifecycle-terminal"):
        await store.rebuild_terminal_graph_projection_event(
            tombstone.event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="source task tombstoned",
        )
    async with store.sessionmaker() as session:
        untouched = await session.get(ProjectionOutboxRow, tombstone.event_id)
    assert untouched is not None
    assert untouched.status == "failed"
    assert "_terminal_graph_rebuild" not in untouched.payload


@pytest.mark.asyncio
async def test_terminal_graph_retirement_keeps_retired_source_as_audit_evidence(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-retirement-source",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    async with store.sessionmaker.begin() as session:
        version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == ingested.document_id,
                GraphProjectionSnapshotRow.version == str(ingested.version_number),
            )
        )
        assert version is not None
        assert snapshot is not None
        version.lifecycle_status = "deprecated"
        snapshot.status = "deprecated"

    first = await store.retire_stale_terminal_graph_projection_event(
        projection.graph_event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="graph label is not whitelisted",
    )
    repeated = await store.retire_stale_terminal_graph_projection_event(
        projection.graph_event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="graph label is not whitelisted",
    )

    assert first.event_id == repeated.event_id == projection.graph_event_id
    assert first.status == repeated.status == "failed"
    assert first.last_error.startswith("superseded by terminal graph retirement")
    marker = first.payload["_terminal_graph_retirement"]
    assert marker["mode"] == "retire_stale_terminal"
    assert marker["reason"] == "source_retired"
    assert marker["original_error_sha256"]
    assert (await store.projection_outbox_health(tenant.tenant_id))["terminal_failures"] == 0

    with pytest.raises(ValueError, match="another error"):
        await store.retire_stale_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="a different error",
        )


@pytest.mark.asyncio
async def test_terminal_graph_retirement_requires_a_current_replacement(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-retirement-current",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )

    with pytest.raises(ValueError, match="source version is not retired"):
        await store.retire_stale_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="graph label is not whitelisted",
        )

    assert (await store.projection_outbox_health(tenant.tenant_id))["terminal_failures"] == 1


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "lifecycle_status",
    [LifecycleStatus.UNDER_REVIEW.value, LifecycleStatus.APPROVED.value],
)
async def test_terminal_graph_retirement_rejects_nonterminal_source_lifecycle(
    projection_wiki,
    lifecycle_status: str,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id=f"task-terminal-graph-retirement-{lifecycle_status}",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    async with store.sessionmaker.begin() as session:
        version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == ingested.document_id,
                GraphProjectionSnapshotRow.version == str(ingested.version_number),
            )
        )
        assert version is not None
        assert snapshot is not None
        version.lifecycle_status = lifecycle_status
        snapshot.status = "deprecated"

    with pytest.raises(ValueError, match="source version is not retired"):
        await store.retire_stale_terminal_graph_projection_event(
            projection.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="graph label is not whitelisted",
        )

    assert (await store.projection_outbox_health(tenant.tenant_id))["terminal_failures"] == 1


@pytest.mark.asyncio
async def test_terminal_graph_retirement_accepts_a_replaced_active_projection(
    projection_wiki,
):
    store, tenant = projection_wiki
    _document_value, ingested, projection = await _active_governed_projection(
        store,
        tenant,
        task_id="task-terminal-graph-retirement-replaced",
    )
    await _make_legacy_dynamic_graph_failure(
        store,
        tenant,
        document_id=ingested.document_id,
        version=str(ingested.version_number),
        event_id=projection.graph_event_id,
    )
    now = utc_now()
    async with store.sessionmaker.begin() as session:
        original_version = await session.scalar(
            select(DocumentVersionRow).where(
                DocumentVersionRow.tenant_id == tenant.tenant_id,
                DocumentVersionRow.document_id == ingested.document_id,
                DocumentVersionRow.version_number == ingested.version_number,
            )
        )
        original_snapshot = await session.scalar(
            select(GraphProjectionSnapshotRow).where(
                GraphProjectionSnapshotRow.tenant_id == tenant.tenant_id,
                GraphProjectionSnapshotRow.source_record_id == ingested.document_id,
                GraphProjectionSnapshotRow.version == str(ingested.version_number),
            )
        )
        assert original_version is not None
        assert original_snapshot is not None
        original_version.lifecycle_status = "deprecated"
        original_version.recorded_to = now
        original_snapshot.status = "deprecated"
        original_snapshot.updated_at = now

        active_projection_id = "projection-retirement-current"
        active_graph = GraphProjection.model_validate(
            copy.deepcopy(original_snapshot.projection_json)
        ).model_copy(
            update={
                "projection_id": active_projection_id,
                "version": str(ingested.version_number + 1),
                "generation": 2,
            }
        )
        session.add(
            DocumentVersionRow(
                tenant_id=tenant.tenant_id,
                version_id="version-retirement-current",
                document_id=original_version.document_id,
                source_asset_id=original_version.source_asset_id,
                source_occurrence_id=original_version.source_occurrence_id,
                version_number=ingested.version_number + 1,
                schema_version=original_version.schema_version,
                content_hash=hashlib.sha256(
                    b"terminal-graph-retirement-current"
                ).hexdigest(),
                parser_version=original_version.parser_version,
                processing_revision=original_version.processing_revision,
                supersedes_version_id=original_version.version_id,
                payload=copy.deepcopy(original_version.payload),
                lifecycle_status="active",
                acl=copy.deepcopy(original_version.acl),
                valid_from=now,
                valid_to=None,
                recorded_from=now,
                recorded_to=None,
                created_at=now,
            )
        )
        session.add(
            GraphProjectionSnapshotRow(
                tenant_id=tenant.tenant_id,
                projection_id=active_projection_id,
                source_record_id=ingested.document_id,
                version=str(ingested.version_number + 1),
                fingerprint=hashlib.sha256(
                    b"terminal-graph-retirement-current-snapshot"
                ).hexdigest(),
                status="active",
                node_count=len(active_graph.nodes),
                edge_count=len(active_graph.edges),
                projection_json=active_graph.model_dump(mode="json"),
                acl=copy.deepcopy(original_snapshot.acl),
                created_at=now,
                updated_at=now,
            )
        )

    retired = await store.retire_stale_terminal_graph_projection_event(
        projection.graph_event_id,
        tenant_id=tenant.tenant_id,
        expected_last_error_contains="graph label is not whitelisted",
    )

    assert retired.payload["_terminal_graph_retirement"]["reason"] == (
        "active_projection_replaced"
    )
    assert (await store.projection_outbox_health(tenant.tenant_id))["terminal_failures"] == 0


@pytest.mark.asyncio
async def test_terminal_graph_event_requeue_rejects_lifecycle_terminal(projection_wiki):
    store, tenant = projection_wiki
    event = await store.enqueue_projection(
        ProjectionEventRecord(
            tenant_id=tenant.tenant_id,
            projection_name="graph",
            idempotency_key="graph-terminal-tombstone",
            aggregate_type="document_projection",
            aggregate_id="source-tombstoned",
            event_type="graph.projection.deleted",
            payload={"source_record_id": "source-tombstoned", "action": "delete"},
        )
    )
    leased = await store.lease_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.fail_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        error="source task tombstoned: task-1",
        terminal=True,
        lease_attempt=leased.attempts,
    )

    with pytest.raises(ValueError, match="lifecycle-terminal"):
        await store.requeue_terminal_graph_event(
            event.event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="source task tombstoned",
        )


@pytest.mark.asyncio
async def test_terminal_graph_event_requeue_rejects_retired_active_version(
    projection_wiki,
):
    store, tenant = projection_wiki
    first = await store.replace_document_projections(
        tenant.tenant_id,
        _document(model="OLD-MODEL"),
        source_record_id="source-retired",
        version="v1",
    )
    leased = await store.lease_projection_event(
        first.graph_event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.fail_projection_event(
        first.graph_event_id,
        tenant_id=tenant.tenant_id,
        error="graph label is not whitelisted: 'CommercialDocument'",
        terminal=True,
        lease_attempt=leased.attempts,
    )
    await store.replace_document_projections(
        tenant.tenant_id,
        _document(model="NEW-MODEL"),
        source_record_id="source-retired",
        version="v2",
    )

    with pytest.raises(ValueError, match="no longer matches the active graph"):
        await store.requeue_terminal_graph_event(
            first.graph_event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="CommercialDocument",
        )


@pytest.mark.asyncio
async def test_terminal_graph_event_requeue_rejects_other_projections(projection_wiki):
    store, tenant = projection_wiki
    event = await store.enqueue_projection(_embedding_event(tenant.tenant_id, "terminal"))
    leased = await store.lease_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.fail_projection_event(
        event.event_id,
        tenant_id=tenant.tenant_id,
        error="embedding contract failure",
        terminal=True,
        lease_attempt=leased.attempts,
    )

    with pytest.raises(ValueError, match="not a graph event"):
        await store.requeue_terminal_graph_event(
            event.event_id,
            tenant_id=tenant.tenant_id,
            expected_last_error_contains="embedding contract failure",
        )


@pytest.mark.asyncio
async def test_terminal_graph_requeue_command_uses_configured_store(
    projection_wiki,
    monkeypatch,
):
    store, tenant = projection_wiki
    projection = await store.replace_document_projections(
        tenant.tenant_id,
        _document(),
        source_record_id="source-cli",
        version="v1",
    )
    event_id = projection.graph_event_id
    leased = await store.lease_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
    )
    assert leased is not None
    assert await store.fail_projection_event(
        event_id,
        tenant_id=tenant.tenant_id,
        error="graph label is not whitelisted: 'CommercialDocument'",
        terminal=True,
        lease_attempt=leased.attempts,
    )
    monkeypatch.setenv("KNOWLEDGE_DATABASE_URL", str(store.engine.url))

    result = await requeue_terminal_graph_event_command(
        tenant_id=tenant.tenant_id,
        event_id=event_id,
        expected_error_contains="CommercialDocument",
    )

    assert result == {
        "event_id": event_id,
        "tenant_id": tenant.tenant_id,
        "projection_name": "graph",
        "status": "pending",
        "attempts": leased.attempts,
        "available_at": result["available_at"],
    }


@pytest.mark.asyncio
async def test_lightrag_source_events_are_fifo_and_crash_lease_is_bounded(
    projection_wiki,
):
    store, tenant = projection_wiki
    started_at = utc_now()
    source_record_id = "source-lightrag-crash"
    upsert = await store.enqueue_projection(
        _lightrag_event(
            tenant.tenant_id,
            source_record_id=source_record_id,
            action="upsert",
            created_at=started_at,
        )
    )
    delete = await store.enqueue_projection(
        _lightrag_event(
            tenant.tenant_id,
            source_record_id=source_record_id,
            action="delete",
            created_at=started_at + timedelta(microseconds=1),
        )
    )

    first = await store.lease_projection_event(
        upsert.event_id,
        tenant_id=tenant.tenant_id,
        lease_seconds=600,
        now=started_at,
    )
    assert first is not None
    assert first.leased_until == started_at + timedelta(seconds=120)
    assert (
        await store.lease_projection_event(
            delete.event_id,
            tenant_id=tenant.tenant_id,
            now=started_at + timedelta(seconds=60),
        )
        is None
    )

    # Simulate an external upsert that succeeded just before its process died.
    # Once that bounded lease expires, the old upsert must be reclaimed before
    # the queued delete can run, so the delete can never be overtaken.
    recovered = await store.lease_projection_events(
        "lightrag_shadow",
        tenant_id=tenant.tenant_id,
        limit=10,
        lease_seconds=600,
        now=started_at + timedelta(seconds=121),
    )
    assert [event.event_id for event in recovered] == [upsert.event_id]
    assert recovered[0].attempts == 2
    assert recovered[0].leased_until == started_at + timedelta(seconds=241)
    assert await store.mark_projection_delivered(
        upsert.event_id,
        tenant_id=tenant.tenant_id,
        lease_attempt=recovered[0].attempts,
    )

    delete_lease = await store.lease_projection_event(
        delete.event_id,
        tenant_id=tenant.tenant_id,
        lease_seconds=600,
        now=started_at + timedelta(seconds=121),
    )
    assert delete_lease is not None
    assert delete_lease.leased_until == started_at + timedelta(seconds=241)


@pytest.mark.asyncio
async def test_projection_replace_is_atomic_idempotent_and_hybrid_searchable(projection_wiki):
    store, tenant = projection_wiki
    first = await store.replace_document_projections(
        tenant.tenant_id, _document(), source_record_id="source-1", version="v1"
    )
    replay = await store.replace_document_projections(
        tenant.tenant_id, _document(), source_record_id="source-1", version="v1"
    )

    assert first.changed is True
    assert replay.changed is False
    assert replay.fingerprint == first.fingerprint
    assert replay.search_event_id == first.search_event_id
    assert replay.graph_event_id == first.graph_event_id
    assert first.chunk_count == first.index_count > 0
    assert first.node_count > 0
    assert first.edge_count > 0

    keyword = await store.search_index(
        tenant.tenant_id,
        "DP-100 8K",
        filters={"document_type": "order", "source_record_id": "source-1"},
    )
    assert keyword
    assert keyword[0].document.selected_fields["model"] == "DP-100"
    vector = await store.search_index(
        tenant.tenant_id,
        "",
        vector_scores={keyword[0].index_id: 1.0},
        keyword_weight=0,
        vector_weight=1,
        graph_weight=0,
    )
    assert vector[0].index_id == keyword[0].index_id
    graph_boost = await store.search_index(
        tenant.tenant_id,
        "",
        graph_context={"DP-100": 1.0},
        keyword_weight=0,
        vector_weight=0,
        graph_weight=1,
        mode="broad",
    )
    assert graph_boost[0].document.selected_fields["model"] == "DP-100"

    graph = await store.get_graph_projection(tenant.tenant_id, "source-1", "v1")
    assert graph is not None
    assert graph.projection_id
    assert graph.source_record_id == "source-1"

    stats = await store.projection_stats(
        tenant.tenant_id, source_record_id="source-1", version="v1"
    )
    assert stats["chunks"] == {"total": first.chunk_count, "by_status": {"active": first.chunk_count}}
    assert stats["index_documents"]["total"] == first.index_count
    assert stats["graph_snapshots"] == {"total": 1, "by_status": {"active": 1}}

    assert len(await store.lease_projection_events("search", tenant_id=tenant.tenant_id)) == 1
    assert len(await store.lease_projection_events("graph", tenant_id=tenant.tenant_id)) == 1


@pytest.mark.asyncio
async def test_persisted_precise_search_indexes_dynamic_custom_identifiers(projection_wiki):
    store, tenant = projection_wiki
    document = _document(model="GENERIC")
    document["lines"][0]["custom_fields"] = {
        "型号": "W-H937",
        "备货数量": 800,
    }
    document["lines"][0]["raw_columns"] = {
        "型号": "W-H937",
        "仅原始列": "RAW-COLUMN-ONLY-999",
    }
    await store.replace_document_projections(
        tenant.tenant_id,
        document,
        source_record_id="dynamic-custom-source",
        version="v1",
    )

    hits = await store.search_index(tenant.tenant_id, "W-H937")

    assert hits
    assert hits[0].document.source_record_id == "dynamic-custom-source"
    assert hits[0].match_reason == "exact_identifier"
    assert hits[0].document.selected_fields["custom_fields"] == {
        "备货数量": 800,
        "型号": "W-H937",
    }
    assert await store.search_index(tenant.tenant_id, "RAW-COLUMN-ONLY-999") == []


@pytest.mark.asyncio
async def test_persisted_exact_score_ties_prefer_newest_source(projection_wiki):
    store, tenant = projection_wiki
    for source_record_id in ("old-exact-source", "new-exact-source"):
        await store.replace_document_projections(
            tenant.tenant_id,
            _document(model="TX2607150002"),
            source_record_id=source_record_id,
            version="v1",
        )

    hits = await store.search_index(
        tenant.tenant_id,
        "TX2607150002",
        candidate_pool_limit=1,
        limit=1,
    )

    assert len(hits) == 1
    assert hits[0].document.source_record_id == "new-exact-source"


@pytest.mark.asyncio
async def test_sql_candidate_generation_finds_match_beyond_pool_prefix(
    projection_wiki,
) -> None:
    store, tenant = projection_wiki
    await store.replace_document_projections(
        tenant.tenant_id,
        _document(model="FIRST-NONMATCH"),
        source_record_id="candidate-source-1",
        version="v1",
    )
    await store.replace_document_projections(
        tenant.tenant_id,
        _document(model="TARGET-AFTER-PREFIX"),
        source_record_id="candidate-source-2",
        version="v1",
    )

    hits = await store.search_index(
        tenant.tenant_id,
        "TARGET-AFTER-PREFIX",
        candidate_pool_limit=1,
    )

    assert hits
    assert hits[0].document.source_record_id == "candidate-source-2"
    assert hits[0].document.selected_fields["model"] == "TARGET-AFTER-PREFIX"


@pytest.mark.asyncio
async def test_changed_same_version_replaces_rows_and_supersedes_stale_events(projection_wiki):
    store, tenant = projection_wiki
    old = await store.replace_document_projections(
        tenant.tenant_id, _document(model="DP-100"), source_record_id="source-2", version="v1"
    )
    new = await store.replace_document_projections(
        tenant.tenant_id, _document(model="DP-900"), source_record_id="source-2", version="v1"
    )

    assert new.changed is True
    assert new.fingerprint != old.fingerprint
    stats = await store.projection_stats(
        tenant.tenant_id, source_record_id="source-2", version="v1"
    )
    assert stats["chunks"]["total"] == new.chunk_count
    assert stats["index_documents"]["total"] == new.index_count
    assert stats["graph_snapshots"]["total"] == 1
    assert await store.search_index(tenant.tenant_id, "DP-100") == []
    assert (await store.search_index(tenant.tenant_id, "DP-900"))[0].document.selected_fields[
        "model"
    ] == "DP-900"

    # Only the latest fingerprint remains deliverable; stale pending events are
    # retained as failed audit evidence rather than being deleted.
    search_events = await store.lease_projection_events("search", tenant_id=tenant.tenant_id)
    graph_events = await store.lease_projection_events("graph", tenant_id=tenant.tenant_id)
    assert [event.payload["fingerprint"] for event in search_events] == [new.fingerprint]
    assert [event.payload["fingerprint"] for event in graph_events] == [new.fingerprint]
    all_stats = await store.projection_stats(tenant.tenant_id)
    assert all_stats["outbox"]["search:failed"] == 1
    assert all_stats["outbox"]["graph:failed"] == 1


@pytest.mark.asyncio
async def test_candidate_projection_requires_explicit_review_access_and_uses_staging_outbox(
    projection_wiki,
):
    store, tenant = projection_wiki
    result = await store.replace_document_projections(
        tenant.tenant_id,
        _document(model="CANDIDATE-1", needs_review=True),
        source_record_id="candidate-source",
        version="v1",
    )
    assert result.status == "candidate"

    assert await store.search_index(tenant.tenant_id, "CANDIDATE-1") == []
    assert await store.search_index(
        tenant.tenant_id, "CANDIDATE-1", statuses={"candidate"}
    ) == []
    reviewed = await store.search_index(
        tenant.tenant_id,
        "CANDIDATE-1",
        statuses={"candidate"},
        include_candidate=True,
    )
    assert reviewed and reviewed[0].document.status == "candidate"

    assert await store.get_graph_projection(
        tenant.tenant_id, "candidate-source", "v1"
    ) is None
    staged_graph = await store.get_graph_projection(
        tenant.tenant_id, "candidate-source", "v1", include_candidate=True
    )
    assert staged_graph is not None
    assert all(node.status == "candidate" for node in staged_graph.nodes)

    assert await store.lease_projection_events("search", tenant_id=tenant.tenant_id) == []
    assert await store.lease_projection_events("graph", tenant_id=tenant.tenant_id) == []
    assert len(await store.lease_projection_events("search_staging", tenant_id=tenant.tenant_id)) == 1
    assert len(await store.lease_projection_events("graph_staging", tenant_id=tenant.tenant_id)) == 1


@pytest.mark.asyncio
async def test_projection_queries_are_tenant_isolated(projection_wiki):
    store, first = projection_wiki
    second = await store.create_tenant(TenantRecord(
        tenant_key="projection-b", display_name="Projection Tenant B"
    ))
    await store.replace_document_projections(
        first.tenant_id, _document(model="TENANT-A"), source_record_id="shared", version="v1"
    )
    await store.replace_document_projections(
        second.tenant_id, _document(model="TENANT-B"), source_record_id="shared", version="v1"
    )

    assert await store.search_index(first.tenant_id, "TENANT-B") == []
    assert await store.search_index(second.tenant_id, "TENANT-A") == []
    assert (await store.search_index(first.tenant_id, "TENANT-A"))[0].document.tenant_id == first.tenant_id
    assert (await store.search_index(second.tenant_id, "TENANT-B"))[0].document.tenant_id == second.tenant_id
    first_graph = await store.get_graph_projection(first.tenant_id, "shared", "v1")
    second_graph = await store.get_graph_projection(second.tenant_id, "shared", "v1")
    assert first_graph and second_graph
    assert first_graph.tenant_id == first.tenant_id
    assert second_graph.tenant_id == second.tenant_id
