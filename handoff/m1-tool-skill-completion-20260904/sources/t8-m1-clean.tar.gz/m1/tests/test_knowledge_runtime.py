from __future__ import annotations

import asyncio
import hashlib
import threading
from copy import deepcopy

import pytest
from m1.knowledge import (
    AccessControl,
    KnowledgeRuntime,
    KnowledgeStore,
    ReviewDecisionType,
    TenantRecord,
    outbox_delivery,
)
from m1.knowledge.db_models import ProjectionOutboxRow, RelationshipClaimRow
from m1.knowledge.persistence import (
    EntityAliasRow,
    EntityRevisionRow,
    ExternalIdentityRow,
)
from m1.knowledge.schema import ProjectionEventRecord, utc_now
from m1.knowledge.sinks import InMemoryGraphSink
from sqlalchemy import event, select


class _SemanticEmbeddingProvider:
    model = "test-semantic-1024"
    dimensions = 1024

    def __init__(self) -> None:
        self.closed = False

    async def embed_texts(self, texts):
        vectors = []
        for text in texts:
            vector = [0.0] * self.dimensions
            if "SEMANTIC-ALPHA" in text or "meaning-alpha" in text:
                vector[0] = 1.0
            else:
                vector[1] = 1.0
            vectors.append(vector)
        return vectors

    async def close(self) -> None:
        self.closed = True


class _BlockingEmbeddingProvider(_SemanticEmbeddingProvider):
    def __init__(self) -> None:
        super().__init__()
        self.calls = 0
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def embed_texts(self, texts):
        self.calls += 1
        self.started.set()
        await self.release.wait()
        return await super().embed_texts(texts)


class _BlockingGraphSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.calls = 0
        self.started = threading.Event()
        self.release = threading.Event()

    def replace_projection(self, projection) -> None:
        self.calls += 1
        self.started.set()
        self.release.wait(timeout=2)
        super().replace_projection(projection)


class _BlockingGraphDeleteSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.delete_calls = 0
        self.delete_started = threading.Event()
        self.delete_release = threading.Event()

    def delete_projection(self, *args, **kwargs) -> None:
        self.delete_calls += 1
        self.delete_started.set()
        self.delete_release.wait(timeout=2)
        super().delete_projection(*args, **kwargs)


class _ArmableGraphSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.armed = False
        self.started = threading.Event()
        self.release = threading.Event()

    def arm(self) -> None:
        self.started.clear()
        self.release.clear()
        self.armed = True

    def replace_projection(self, projection) -> None:
        if self.armed:
            self.started.set()
            self.release.wait(timeout=2)
        super().replace_projection(projection)


class _BlockingHealthGraphSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.health_calls = 0
        self.health_started = threading.Event()
        self.health_release = threading.Event()

    def health(self) -> dict[str, object]:
        self.health_calls += 1
        self.health_started.set()
        self.health_release.wait(timeout=2)
        return super().health()

    def close(self) -> None:
        self.health_release.set()
        super().close()


class _BlockingLightRAG:
    workspace = "lease-owner-test"

    def __init__(self) -> None:
        self.calls = 0
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def upsert_document(self, **_kwargs) -> None:
        self.calls += 1
        self.started.set()
        await self.release.wait()

    async def delete_source(self, **_kwargs) -> None:
        return None

    async def health(self) -> dict[str, object]:
        return {"enabled": True, "ready": True, "workspace": self.workspace}

    async def close(self) -> None:
        self.release.set()


class _VersionedBlockingLightRAG:
    workspace = "version-order-test"

    def __init__(self) -> None:
        self.calls: list[str] = []
        self.current_version: str | None = None
        self.first_started = asyncio.Event()
        self.release_first = asyncio.Event()

    async def upsert_document(self, **kwargs) -> None:
        version = str(kwargs["version"])
        self.calls.append(version)
        if len(self.calls) == 1:
            self.first_started.set()
            await self.release_first.wait()
        self.current_version = version

    async def delete_source(self, **_kwargs) -> None:
        self.current_version = None

    async def health(self) -> dict[str, object]:
        return {"enabled": True, "ready": True, "workspace": self.workspace}

    async def close(self) -> None:
        self.release_first.set()


def _document(
    *,
    model: str = "DP-RUNTIME-1",
    order_number: str = "TX-RUNTIME-001",
    needs_review: bool = False,
) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": f"{order_number}.xlsx",
            "display_filename": f"orders/{order_number}.xlsx",
            "sha256": hashlib.sha256(
                f"{order_number}\x1f{model}".encode()
            ).hexdigest(),
            "verified_external_identity": {
                "verified": True,
                "source_system": "test-order-source",
                "external_id": order_number,
            },
            "mime_type": (
                "application/vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            ),
            "size_bytes": 4096,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "Runtime stocking order",
            "order_number": order_number,
            "buyer": "Runtime Buyer",
            "supplier": "Runtime Supplier",
        },
        "lines": [
            {
                "line_id": "line-1",
                "line_no": 1,
                "model": model,
                "product_code": f"P-{model}",
                "name_raw": f"{model} DP cable",
                "name_normalized": f"{model} DisplayPort cable",
                "full_product_name": f"{model} DisplayPort 8K cable 1m",
                "product_category": "cable",
                "quantity": 12,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 12},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B5"}],
            },
            "$.lines[0].quantity": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "E5"}],
            },
        },
        "validation_issues": (
            [
                {
                    "code": "ORDER_NUMBER_CONFLICT",
                    "severity": "warning",
                    "message": "A historical number also occurs in a note",
                    "paths": ["$.header.order_number"],
                }
            ]
            if needs_review
            else []
        ),
        "needs_review": needs_review,
    }


def _technical_document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "lease-owner-specification.pdf",
            "display_filename": "lease-owner-specification.pdf",
            "sha256": "c" * 64,
            "mime_type": "application/pdf",
            "size_bytes": 512,
        },
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "header": {"title": "Lease owner specification"},
        "lines": [],
        "totals": {},
        "field_meta": {
            "$.header.title": {
                "confidence": 1.0,
                "source_refs": [{"page": 1, "bbox": [10, 10, 100, 30]}],
            }
        },
        "validation_issues": [],
        "needs_review": False,
    }


@pytest.fixture
async def runtime(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'runtime.db').as_posix()}"
    )
    graph = InMemoryGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        yield service, store, graph
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_health_reuses_probe_after_caller_timeout(tmp_path) -> None:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'health-probe.db').as_posix()}"
    )
    graph = _BlockingHealthGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        first = asyncio.create_task(service.health())
        started = await asyncio.to_thread(graph.health_started.wait, 1.0)
        assert started is True
        first.cancel()
        await asyncio.gather(first, return_exceptions=True)

        with pytest.raises(TimeoutError):
            await asyncio.wait_for(service.health(), timeout=0.01)
        assert graph.health_calls == 1

        graph.health_release.set()
        result = await asyncio.wait_for(service.health(), timeout=1.0)
        assert result["status"] == "ok"
        assert graph.health_calls == 1
    finally:
        graph.health_release.set()
        await service.close()


@pytest.mark.asyncio
async def test_runtime_ingests_v2_and_identical_replay_is_idempotent(runtime):
    service, store, graph = runtime
    document = _document()

    first = await service.sync_document(
        tenant_id="default", task_id="task-runtime-1", document=document
    )
    replay = await service.sync_document(
        tenant_id="default", task_id="task-runtime-1", document=deepcopy(document)
    )

    assert first.status == replay.status == "synced"
    assert first.document.created is True
    assert replay.document.created is False
    assert replay.document.document_id == first.document.document_id
    assert replay.document.version_id == first.document.version_id
    assert replay.projection.changed is False
    assert replay.projection.fingerprint == first.projection.fingerprint
    assert replay.projection.search_event_id == first.projection.search_event_id
    assert replay.projection.graph_event_id == first.projection.graph_event_id

    stats = await store.projection_stats(
        "default",
        source_record_id=first.document.document_id,
        version="1",
    )
    assert stats["chunks"]["total"] == first.projection.chunk_count
    assert stats["index_documents"]["total"] == first.projection.index_count
    assert stats["graph_snapshots"] == {"total": 1, "by_status": {"active": 1}}
    assert stats["outbox"] == {"graph:delivered": 1, "search:delivered": 1}
    assert len(graph.projections) == 1
    assert (
        await store.search_index("default", "DP-RUNTIME-1")
    )[0].document.selected_fields["model"] == "DP-RUNTIME-1"
    logical_relations = {
        edge.relation
        for edge in graph.get_projection(
            "default", first.document.document_id
        ).edges
    }
    assert {"REPRESENTS_ORDER", "CONTAINS_PRODUCT"}.issubset(
        logical_relations
    )


@pytest.mark.asyncio
async def test_runtime_persists_embeddings_and_semantically_recalls(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'semantic.db').as_posix()}"
    )
    provider = _SemanticEmbeddingProvider()
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
    )
    await service.init()
    try:
        outcome = await service.sync_document(
            tenant_id="default",
            task_id="task-semantic",
            document=_document(
                model="SEMANTIC-ALPHA",
                order_number="TX-SEMANTIC-001",
            ),
        )

        assert outcome.embedding_synced is True
        assert outcome.embedding_count == outcome.projection.index_count
        assert await store.list_index_embedding_inputs(
            "default",
            outcome.document.document_id,
            "1",
            only_missing=True,
        ) == []
        hits = await service.search_index("default", "meaning-alpha", limit=5)
        assert hits
        assert any(
            hit.document.selected_fields.get("model") == "SEMANTIC-ALPHA"
            for hit in hits
        )
        stats = await store.projection_stats(
            "default",
            source_record_id=outcome.document.document_id,
            version="1",
        )
        assert stats["outbox"]["embedding:delivered"] == 1
    finally:
        await service.close()
    assert provider.closed is True


@pytest.mark.asyncio
async def test_outbox_drain_limit_is_global_across_projection_types(runtime):
    service, store, _graph = runtime
    for index, projection_name in enumerate(
        ("knowledge", "search", "search_staging", "graph_staging"),
        start=1,
    ):
        await store.enqueue_projection(
            ProjectionEventRecord(
                tenant_id="default",
                projection_name=projection_name,
                idempotency_key=f"global-limit-{index}",
                aggregate_type="test",
                aggregate_id=f"global-limit-{index}",
                event_type="test.local-projection",
            )
        )

    drained = await service.drain_outbox(tenant_id="default", limit=1)

    assert drained.leased == 1
    assert drained.delivered == 1
    health = await store.projection_outbox_health("default")
    assert health["pending"] == 3


@pytest.mark.asyncio
async def test_sync_fast_path_and_worker_do_not_deliver_same_embedding(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'embedding-owner.db').as_posix()}"
    )
    provider = _BlockingEmbeddingProvider()
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
    )
    await service.init()
    try:
        syncing = asyncio.create_task(
            service.sync_document(
                tenant_id="default",
                task_id="embedding-owner-task",
                document=_document(
                    model="EMBEDDING-OWNER",
                    order_number="EMBEDDING-OWNER-ORDER",
                ),
            )
        )
        await asyncio.wait_for(provider.started.wait(), timeout=1)

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)
        assert drained.retried == drained.terminal_failures == 0
        assert provider.calls == 1

        provider.release.set()
        outcome = await asyncio.wait_for(syncing, timeout=2)
        assert outcome.embedding_synced is True
        assert provider.calls == 1
        stats = await store.projection_stats(
            "default",
            source_record_id=outcome.document.document_id,
            version="1",
        )
        assert stats["outbox"]["embedding:delivered"] == 1
    finally:
        provider.release.set()
        await service.close()


@pytest.mark.asyncio
async def test_sync_fast_path_and_worker_do_not_deliver_same_graph(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'graph-owner.db').as_posix()}"
    )
    graph = _BlockingGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        syncing = asyncio.create_task(
            service.sync_document(
                tenant_id="default",
                task_id="graph-owner-task",
                document=_technical_document(),
            )
        )
        started = await asyncio.wait_for(
            asyncio.to_thread(graph.started.wait, 1), timeout=2
        )
        assert started is True

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)
        assert drained.retried == drained.terminal_failures == 0
        assert graph.calls == 1

        graph.release.set()
        outcome = await asyncio.wait_for(syncing, timeout=2)
        assert outcome.graph_synced is True
        assert graph.calls == 1
        stats = await store.projection_stats(
            "default",
            source_record_id=outcome.document.document_id,
            version="1",
        )
        assert stats["outbox"]["graph:delivered"] == 1
    finally:
        graph.release.set()
        await service.close()


@pytest.mark.asyncio
async def test_sync_fast_path_and_worker_do_not_deliver_same_lightrag(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'lightrag-owner.db').as_posix()}"
    )
    shadow = _BlockingLightRAG()
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    await service.init()
    try:
        syncing = asyncio.create_task(
            service.sync_document(
                tenant_id="default",
                task_id="lightrag-owner-task",
                document=_technical_document(),
            )
        )
        await asyncio.wait_for(shadow.started.wait(), timeout=1)

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)
        assert drained.retried == drained.terminal_failures == 0
        assert shadow.calls == 1

        shadow.release.set()
        outcome = await asyncio.wait_for(syncing, timeout=2)
        assert outcome.shadow_synced is True
        assert shadow.calls == 1
        stats = await store.projection_stats(
            "default",
            source_record_id=outcome.document.document_id,
            version="1",
        )
        assert stats["outbox"]["lightrag_shadow:delivered"] == 1
    finally:
        shadow.release.set()
        await service.close()


@pytest.mark.asyncio
async def test_new_lightrag_version_finishes_after_older_inflight_version(
    tmp_path,
) -> None:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'lightrag-version-order.db').as_posix()}"
    )
    shadow = _VersionedBlockingLightRAG()
    service = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    await service.init()
    try:
        first_sync = asyncio.create_task(
            service.sync_document(
                tenant_id="default",
                task_id="lightrag-version-1",
                document=_document(
                    model="LIGHTRAG-V1",
                    order_number="LIGHTRAG-VERSIONED-ORDER",
                ),
            )
        )
        await asyncio.wait_for(shadow.first_started.wait(), timeout=5)
        second_sync = asyncio.create_task(
            service.sync_document(
                tenant_id="default",
                task_id="lightrag-version-2",
                document=_document(
                    model="LIGHTRAG-V2",
                    order_number="LIGHTRAG-VERSIONED-ORDER",
                ),
            )
        )

        for _ in range(100):
            stats = await store.projection_stats("default")
            shadow_events = sum(
                count
                for key, count in stats["outbox"].items()
                if key.startswith("lightrag_shadow:")
            )
            if (
                shadow_events >= 2
                and stats["outbox"].get("lightrag_shadow:processing", 0) >= 1
            ):
                break
            await asyncio.sleep(0.01)
        else:
            pytest.fail("new LightRAG version never reached the serialized delivery")

        shadow.release_first.set()
        first, second = await asyncio.wait_for(
            asyncio.gather(first_sync, second_sync), timeout=3
        )

        assert first.shadow_synced is False
        assert second.shadow_synced is True
        # The first delivery observes version 2 after its blocked version 1
        # write and compensates immediately. The version 2 event then replays
        # idempotently, so the final state cannot regress across processes.
        assert shadow.calls == ["1", "2", "2"]
        assert shadow.current_version == "2"
    finally:
        shadow.release_first.set()
        await service.close()


@pytest.mark.asyncio
async def test_tombstone_fast_path_and_worker_do_not_delete_same_graph(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'graph-delete-owner.db').as_posix()}"
    )
    graph = _BlockingGraphDeleteSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        synced = await service.sync_document(
            tenant_id="default",
            task_id="graph-delete-owner-task",
            document=_technical_document(),
        )
        assert synced.graph_synced is True

        tombstoning = asyncio.create_task(
            service.tombstone_task(
                tenant_id="default",
                task_id="graph-delete-owner-task",
            )
        )
        started = await asyncio.wait_for(
            asyncio.to_thread(graph.delete_started.wait, 1), timeout=2
        )
        assert started is True

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)
        assert drained.retried == drained.terminal_failures == 0
        assert graph.delete_calls == 1

        graph.delete_release.set()
        outcome = await asyncio.wait_for(tombstoning, timeout=2)
        assert outcome.graph_deleted == 1
        assert graph.delete_calls == 1
        assert graph.get_projection("default", synced.document.document_id) is None
    finally:
        graph.delete_release.set()
        await service.close()


@pytest.mark.asyncio
async def test_candidate_is_hidden_then_review_acceptance_promotes_projection(runtime):
    service, store, graph = runtime
    candidate_document = _document(
        model="DP-CANDIDATE",
        order_number="TX-CANDIDATE-001",
        needs_review=True,
    )
    outcome = await service.sync_document(
        tenant_id="default",
        task_id="task-candidate",
        document=candidate_document,
    )

    assert outcome.projection.status == "candidate"
    assert outcome.document.review_task_id
    assert graph.projections == ()
    assert await store.search_index("default", "DP-CANDIDATE") == []
    candidate_hits = await store.search_index(
        "default",
        "DP-CANDIDATE",
        statuses={"candidate"},
        include_candidate=True,
    )
    assert candidate_hits and candidate_hits[0].document.status == "candidate"
    assert await store.get_graph_projection(
        "default", outcome.document.document_id, "1"
    ) is None
    candidate_drain = await service.drain_outbox(tenant_id="default")
    assert candidate_drain.retried == candidate_drain.terminal_failures == 0
    assert graph.projections == ()

    await store.decide_review(
        tenant_id="default",
        review_task_id=outcome.document.review_task_id,
        decision=ReviewDecisionType.ACCEPT,
        reviewer_id="quality-reviewer",
        reason="source evidence verified",
    )

    active_hits = await store.search_index("default", "DP-CANDIDATE")
    assert active_hits and active_hits[0].document.status == "active"
    active_graph = await store.get_graph_projection(
        "default", outcome.document.document_id, "1"
    )
    assert active_graph is not None
    assert all(node.status == "active" for node in active_graph.nodes)
    assert all(edge.status == "active" for edge in active_graph.edges)

    # The source payload still truthfully records that the parser requested a
    # review.  Governance state must win on replay: identical content reuses
    # the approved version/fingerprint and must never regress to candidate.
    replay = await service.sync_document(
        tenant_id="default",
        task_id="task-candidate",
        document=deepcopy(candidate_document),
    )
    assert replay.document.created is False
    assert replay.document.version_id == outcome.document.version_id
    assert replay.projection.status == "active"
    assert replay.projection.changed is False
    assert await store.search_index("default", "DP-CANDIDATE")

    drained = await service.drain_outbox(tenant_id="default")
    assert drained.retried == drained.terminal_failures == 0
    assert drained.delivered >= 1
    projected = graph.get_projection("default", outcome.document.document_id)
    assert projected is not None
    assert all(node.status == "active" for node in projected.nodes)


@pytest.mark.asyncio
async def test_tenant_boundaries_and_private_restricted_acl_are_enforced(runtime):
    service, store, _graph = runtime
    private_acl = AccessControl(
        visibility="private",
        owner_principal="alice",
        read_principals=["bob"],
    )
    restricted_acl = AccessControl(
        visibility="restricted",
        security_labels=["role:quality"],
    )
    await store.create_tenant(
        TenantRecord(
            tenant_id="private-co",
            tenant_key="private-co",
            display_name="Private Co",
            default_acl=private_acl,
        )
    )
    await store.create_tenant(
        TenantRecord(
            tenant_id="restricted-co",
            tenant_key="restricted-co",
            display_name="Restricted Co",
            default_acl=restricted_acl,
        )
    )
    private = await service.sync_document(
        tenant_id="private-co",
        task_id="private-task",
        document=_document(model="PRIVATE-MODEL", order_number="PRIVATE-ORDER"),
    )
    restricted = await service.sync_document(
        tenant_id="restricted-co",
        task_id="restricted-task",
        document=_document(model="RESTRICTED-MODEL", order_number="RESTRICTED-ORDER"),
    )

    assert await store.search_index("private-co", "PRIVATE-MODEL") == []
    assert await store.search_index(
        "private-co", "PRIVATE-MODEL", actor_id="mallory"
    ) == []
    assert await store.search_index(
        "private-co", "PRIVATE-MODEL", actor_id="alice"
    )
    assert await store.search_index(
        "private-co", "PRIVATE-MODEL", actor_id="bob"
    )
    assert await store.search_index(
        "private-co", "PRIVATE-MODEL", actor_roles={"admin"}
    )
    assert await store.search_index("private-co", "RESTRICTED-MODEL") == []

    assert await store.search_index("restricted-co", "RESTRICTED-MODEL") == []
    assert await store.search_index(
        "restricted-co", "RESTRICTED-MODEL", actor_roles={"quality"}
    )
    assert await store.search_index(
        "restricted-co", "RESTRICTED-MODEL", actor_roles={"role:quality"}
    )
    assert await store.search_index("restricted-co", "PRIVATE-MODEL") == []

    private_entities = await store.list_entities("private-co")
    restricted_entities = await store.list_entities("restricted-co")
    assert private_entities and all(
        entity.acl == private_acl for entity in private_entities
    )
    assert restricted_entities and all(
        entity.acl == restricted_acl for entity in restricted_entities
    )
    assert await store.get_graph_projection(
        "private-co", private.document.document_id, actor_id="mallory"
    ) is None
    assert await store.get_graph_projection(
        "private-co", private.document.document_id, actor_id="alice"
    ) is not None
    assert await store.get_graph_projection(
        "restricted-co",
        restricted.document.document_id,
        actor_roles={"quality"},
    ) is not None


class _FlakyGraphSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.fail = True
        self.calls = 0

    def replace_projection(self, projection) -> None:
        self.calls += 1
        if self.fail:
            raise RuntimeError("temporary graph outage")
        super().replace_projection(projection)


class _CountingGraphSink(InMemoryGraphSink):
    def __init__(self) -> None:
        super().__init__()
        self.replace_calls = 0

    def replace_projection(self, projection) -> None:
        self.replace_calls += 1
        super().replace_projection(projection)


@pytest.mark.asyncio
async def test_graph_relationship_outbox_is_coalesced_per_document(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'coalesced-outbox.db').as_posix()}"
    )
    graph = _CountingGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        first = await service.sync_document(
            tenant_id="default",
            task_id="coalesced-first",
            document=_document(
                model="COALESCED-A",
                order_number="COALESCED-ORDER-A",
            ),
        )
        second = await service.sync_document(
            tenant_id="default",
            task_id="coalesced-second",
            document=_document(
                model="COALESCED-B",
                order_number="COALESCED-ORDER-B",
            ),
        )
        assert first.graph_synced is True
        assert second.graph_synced is True

        # Direct document projection happens during sync.  The remaining
        # relationship notifications used to replay that complete projection
        # once per relationship, which made a full corpus drain quadratic in
        # practice.  A drain must now replay each affected document once.
        graph.replace_calls = 0
        drained = await service.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.leased > 2
        assert drained.delivered == drained.leased
        assert drained.retried == drained.terminal_failures == 0
        assert graph.replace_calls == 2
        stats = await store.projection_stats("default")
        assert not any(
            key.startswith(("graph:pending", "graph:processing"))
            for key in stats["outbox"]
        )
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_relationship_event_waits_for_graph_snapshot_materialization(
    tmp_path, monkeypatch
):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'relationship-ordering.db').as_posix()}"
    )
    graph = InMemoryGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    projection_started = asyncio.Event()
    release_projection = asyncio.Event()
    projection_target: dict[str, str] = {}
    original_replace = store.replace_document_projections

    async def blocked_replace(*args, **kwargs):
        projection_target.update(
            source_record_id=str(kwargs["source_record_id"]),
            version=str(kwargs["version"]),
        )
        projection_started.set()
        await release_projection.wait()
        return await original_replace(*args, **kwargs)

    monkeypatch.setattr(store, "replace_document_projections", blocked_replace)
    monkeypatch.setattr(outbox_delivery, "LIFECYCLE_WAIT_RETRY_SECONDS", 0)
    syncing = asyncio.create_task(
        service.sync_document(
            tenant_id="default",
            task_id="relationship-ordering-task",
            document=_document(
                model="RELATIONSHIP-ORDERING",
                order_number="RELATIONSHIP-ORDERING-ORDER",
            ),
        )
    )
    try:
        await asyncio.wait_for(projection_started.wait(), timeout=2)
        await store.enqueue_projection(
            ProjectionEventRecord(
                tenant_id="default",
                projection_name="graph",
                idempotency_key="relationship-ordering-accepted",
                aggregate_type="relationship_claim",
                aggregate_id="relationship-ordering-accepted",
                event_type="relationship.accepted",
                payload=dict(projection_target),
            )
        )

        before_snapshot = await service.drain_outbox(
            tenant_id="default", limit=1_000
        )

        assert before_snapshot.lifecycle_waits > 0
        assert before_snapshot.terminal_failures == 0

        release_projection.set()
        outcome = await asyncio.wait_for(syncing, timeout=2)
        assert outcome.graph_synced is True

        after_snapshot = await service.drain_outbox(
            tenant_id="default", limit=1_000
        )
        assert after_snapshot.terminal_failures == 0
        health = await store.projection_outbox_health("default")
        assert health["pending"] == 0
        assert health["terminal_failures"] == 0
    finally:
        release_projection.set()
        if not syncing.done():
            syncing.cancel()
        await asyncio.gather(syncing, return_exceptions=True)
        await service.close()


@pytest.mark.asyncio
async def test_relationship_delivery_rereads_snapshot_after_commit_race(
    tmp_path, monkeypatch
):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'relationship-commit-race.db').as_posix()}"
    )
    service = KnowledgeRuntime(store, InMemoryGraphSink())
    await service.init()
    projection_started = asyncio.Event()
    release_projection = asyncio.Event()
    projection_committed = asyncio.Event()
    original_replace = store.replace_document_projections
    original_pending = store.graph_projection_materialization_pending

    async def blocked_replace(*args, **kwargs):
        projection_started.set()
        await release_projection.wait()
        result = await original_replace(*args, **kwargs)
        projection_committed.set()
        return result

    async def commit_during_state_check(*args, **kwargs):
        release_projection.set()
        await projection_committed.wait()
        return await original_pending(*args, **kwargs)

    monkeypatch.setattr(store, "replace_document_projections", blocked_replace)
    monkeypatch.setattr(
        store,
        "graph_projection_materialization_pending",
        commit_during_state_check,
    )
    syncing = asyncio.create_task(
        service.sync_document(
            tenant_id="default",
            task_id="relationship-commit-race-task",
            document=_document(
                model="RELATIONSHIP-COMMIT-RACE",
                order_number="RELATIONSHIP-COMMIT-RACE-ORDER",
            ),
        )
    )
    try:
        await asyncio.wait_for(projection_started.wait(), timeout=2)

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.lifecycle_waits == 0
        assert drained.terminal_failures == 0
        outcome = await asyncio.wait_for(syncing, timeout=2)
        assert outcome.graph_synced is True
        health = await store.projection_outbox_health("default")
        assert health["pending"] == 0
        assert health["terminal_failures"] == 0
    finally:
        release_projection.set()
        if not syncing.done():
            syncing.cancel()
        await asyncio.gather(syncing, return_exceptions=True)
        await service.close()


@pytest.mark.asyncio
async def test_tombstone_supersedes_inflight_relationship_delivery(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'relationship-tombstone-race.db').as_posix()}"
    )
    graph = _ArmableGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    draining = None
    try:
        outcome = await service.sync_document(
            tenant_id="default",
            task_id="relationship-tombstone-race-task",
            document=_document(
                model="RELATIONSHIP-TOMBSTONE-RACE",
                order_number="RELATIONSHIP-TOMBSTONE-RACE-ORDER",
            ),
        )
        assert outcome.graph_synced is True
        graph.arm()
        draining = asyncio.create_task(
            service.drain_outbox(tenant_id="default", limit=1_000)
        )
        started = await asyncio.wait_for(
            asyncio.to_thread(graph.started.wait, 1), timeout=2
        )
        assert started is True

        tombstoned = await service.tombstone_task(
            tenant_id="default", task_id="relationship-tombstone-race-task"
        )
        assert tombstoned.graph_deleted == 1
        graph.release.set()
        drained = await asyncio.wait_for(draining, timeout=2)

        assert drained.terminal_failures == 0
        assert graph.get_projection("default", outcome.document.document_id) is None
        health = await store.projection_outbox_health("default")
        assert health["terminal_failures"] == 0
        graph_health = health["by_projection"].get("graph", {})
        assert graph_health.get("pending", 0) == 0
        assert graph_health.get("processing", 0) == 0
    finally:
        graph.release.set()
        if draining is not None and not draining.done():
            draining.cancel()
            await asyncio.gather(draining, return_exceptions=True)
        await service.close()


@pytest.mark.asyncio
async def test_tombstone_supersedes_only_target_version_relationship_events(runtime):
    service, store, _graph = runtime
    first = await service.sync_document(
        tenant_id="default",
        task_id="relationship-version-one",
        document=_document(
            model="RELATIONSHIP-VERSION-ONE",
            order_number="RELATIONSHIP-VERSIONED-ORDER",
        ),
    )
    second = await service.sync_document(
        tenant_id="default",
        task_id="relationship-version-two",
        document=_document(
            model="RELATIONSHIP-VERSION-TWO",
            order_number="RELATIONSHIP-VERSIONED-ORDER",
        ),
    )
    assert second.document.document_id == first.document.document_id
    assert second.document.version_number == 2
    async with store.sessionmaker() as session:
        relationships = (
            await session.scalars(
                select(RelationshipClaimRow).where(
                    RelationshipClaimRow.tenant_id == "default",
                    RelationshipClaimRow.source_record_id
                    == first.document.document_id,
                )
            )
        ).all()
    by_version = {}
    for relationship in relationships:
        by_version.setdefault(relationship.source_version, relationship)
    first_relationship = by_version["1"]
    second_relationship = by_version["2"]

    first_event = await store.enqueue_projection(
        ProjectionEventRecord(
            tenant_id="default",
            projection_name="graph",
            idempotency_key="relationship-version-one-manual",
            aggregate_type="relationship_claim",
            aggregate_id=first_relationship.relationship_id,
            event_type="relationship.accepted",
            payload={
                "source_record_id": first.document.document_id,
                "version": "1",
            },
        )
    )
    second_event = await store.enqueue_projection(
        ProjectionEventRecord(
            tenant_id="default",
            projection_name="graph",
            idempotency_key="relationship-version-two-manual",
            aggregate_type="relationship_claim",
            aggregate_id=second_relationship.relationship_id,
            event_type="relationship.accepted",
            payload={
                "source_record_id": second.document.document_id,
                "version": "2",
            },
        )
    )

    tombstoned = await service.tombstone_task(
        tenant_id="default", task_id="relationship-version-two"
    )

    assert tombstoned.graph_replaced == 1
    async with store.sessionmaker() as session:
        rows = (
            await session.scalars(
                select(ProjectionOutboxRow).where(
                    ProjectionOutboxRow.event_id.in_(
                        [first_event.event_id, second_event.event_id]
                    )
                )
            )
        ).all()
    by_event_id = {row.event_id: row for row in rows}
    assert by_event_id[first_event.event_id].status == "pending"
    assert by_event_id[second_event.event_id].status == "failed"
    assert by_event_id[second_event.event_id].last_error.startswith(
        "source task tombstoned:"
    )


@pytest.mark.asyncio
async def test_orphan_relationship_event_without_version_is_terminal(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'orphan-relationship.db').as_posix()}"
    )
    service = KnowledgeRuntime(store, InMemoryGraphSink())
    await service.init()
    try:
        await store.enqueue_projection(
            ProjectionEventRecord(
                tenant_id="default",
                projection_name="graph",
                idempotency_key="orphan-relationship",
                aggregate_type="relationship_claim",
                aggregate_id="relationship-orphan",
                event_type="relationship.claimed",
                payload={
                    "source_record_id": "document-orphan",
                    "version": "1",
                },
            )
        )

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.terminal_failures == 1
        assert drained.lifecycle_waits == 0
        health = await store.projection_outbox_health("default")
        assert health["pending"] == 0
        assert health["terminal_failures"] == 1
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_graph_failure_is_durable_and_outbox_retry_recovers(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'retry.db').as_posix()}"
    )
    graph = _FlakyGraphSink()
    service = KnowledgeRuntime(store, graph)
    await service.init()
    try:
        outcome = await service.sync_document(
            tenant_id="default",
            task_id="retry-task",
            document=_document(model="RETRY-MODEL", order_number="RETRY-ORDER"),
        )
        assert outcome.status == "partial"
        assert outcome.graph_synced is False
        assert outcome.graph_error == "RuntimeError"
        assert graph.projections == ()

        # The runtime uses a short backoff.  Make the same durable event due now
        # instead of sleeping in a unit test, then verify exactly that event is
        # leased and delivered on the next bounded drain.
        await store.fail_projection_event(
            outcome.projection.graph_event_id,
            tenant_id="default",
            error="ready-for-retry",
            retry_at=utc_now(),
        )
        graph.fail = False
        drained = await service.drain_outbox(tenant_id="default")

        # Canonical entity/relationship Wiki events share the same bounded
        # drain and may be acknowledged alongside the one retried graph event.
        assert drained.leased == drained.delivered
        assert drained.delivered >= 1
        assert drained.retried == drained.terminal_failures == 0
        # Entity/relationship graph notifications can replay the same
        # idempotent source projection in this drain as well.
        assert graph.calls >= 2
        assert graph.get_projection(
            "default", outcome.document.document_id
        ) is not None
        stats = await store.projection_stats("default")
        assert stats["outbox"]["graph:delivered"] == 1
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_runtime_requeues_one_terminal_graph_event_and_worker_recovers(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'terminal-replay.db').as_posix()}"
    )
    graph = _FlakyGraphSink()
    service = KnowledgeRuntime(store, graph, outbox_max_attempts=1)
    await service.init()
    try:
        outcome = await service.sync_document(
            tenant_id="default",
            task_id="terminal-replay-task",
            document=_document(
                model="TERMINAL-REPLAY-MODEL",
                order_number="TERMINAL-REPLAY-ORDER",
            ),
        )
        assert outcome.graph_synced is False
        health = await store.projection_outbox_health("default")
        assert health["terminal_failures"] == 1

        graph.fail = False
        requeued = await service.requeue_terminal_graph_event(
            outcome.projection.graph_event_id,
            tenant_id="default",
            expected_last_error_contains="temporary graph outage",
        )
        assert requeued.status == "pending"

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.terminal_failures == drained.retried == 0
        assert drained.delivered >= 1
        assert graph.get_projection(
            "default", outcome.document.document_id
        ) is not None
        health = await store.projection_outbox_health("default")
        assert health["terminal_failures"] == 0
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_terminal_graph_replay_has_only_one_additional_delivery_attempt(tmp_path):
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'terminal-replay-once.db').as_posix()}"
    )
    graph = _FlakyGraphSink()
    service = KnowledgeRuntime(store, graph, outbox_max_attempts=1)
    await service.init()
    try:
        outcome = await service.sync_document(
            tenant_id="default",
            task_id="terminal-replay-once-task",
            document=_document(
                model="TERMINAL-REPLAY-ONCE",
                order_number="TERMINAL-REPLAY-ONCE-ORDER",
            ),
        )
        assert outcome.graph_synced is False
        service.outbox_max_attempts = 10
        await service.requeue_terminal_graph_event(
            outcome.projection.graph_event_id,
            tenant_id="default",
            expected_last_error_contains="temporary graph outage",
        )

        drained = await service.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.terminal_failures == 1
        health = await store.projection_outbox_health("default")
        assert health["terminal_failures"] == 1
        with pytest.raises(ValueError, match="already used its one replay"):
            await service.requeue_terminal_graph_event(
                outcome.projection.graph_event_id,
                tenant_id="default",
                expected_last_error_contains="temporary graph outage",
            )
    finally:
        await service.close()


@pytest.mark.asyncio
async def test_new_active_version_retires_old_projection_and_review(runtime):
    service, store, _graph = runtime
    candidate = _document(
        model="VERSION-OLD",
        order_number="VERSIONED-ORDER",
        needs_review=True,
    )
    first = await service.sync_document(
        tenant_id="default", task_id="version-task-old", document=candidate
    )
    assert first.document.review_task_id

    corrected = _document(
        model="VERSION-NEW",
        order_number="VERSIONED-ORDER",
        needs_review=False,
    )
    second = await service.sync_document(
        tenant_id="default", task_id="version-task-new", document=corrected
    )
    assert second.document.document_id == first.document.document_id
    assert second.document.version_number == 2
    assert await store.search_index("default", "VERSION-OLD") == []
    assert await store.search_index("default", "VERSION-NEW")
    stats = await store.projection_stats(
        "default", source_record_id=second.document.document_id
    )
    assert stats["index_documents"]["by_status"] == {
        "active": second.projection.index_count,
        "deprecated": first.projection.index_count,
    }
    assert stats["graph_snapshots"]["by_status"] == {
        "active": 1,
        "deprecated": 1,
    }
    # Master-data entity/relationship reviews may legitimately remain open;
    # only the review tied to the superseded document version must be closed.
    open_reviews = await store.list_review_tasks("default")
    assert all(
        review.review_task_id != first.document.review_task_id
        for review in open_reviews
    )
    with pytest.raises(ValueError, match="not actionable"):
        await store.decide_review(
            tenant_id="default",
            review_task_id=first.document.review_task_id,
            decision="accept",
            reviewer_id="late-reviewer",
        )


@pytest.mark.asyncio
async def test_task_tombstone_refcounts_shared_version_and_entities(runtime):
    service, store, graph = runtime
    document = _document(
        model="SHARED-MODEL",
        order_number="SHARED-ORDER",
    )
    first = await service.sync_document(
        tenant_id="default", task_id="shared-task-1", document=document
    )
    replay = await service.sync_document(
        tenant_id="default", task_id="shared-task-2", document=deepcopy(document)
    )
    assert replay.document.version_id == first.document.version_id
    stale_projection = graph.get_projection(
        "default", first.document.document_id
    )
    assert stale_projection is not None
    assert stale_projection.generation > 0

    partial = await service.tombstone_task(
        tenant_id="default", task_id="shared-task-1"
    )
    assert partial.version_count == 0
    assert await store.search_index("default", "SHARED-MODEL")
    assert graph.get_projection("default", first.document.document_id) is not None

    final = await service.tombstone_task(
        tenant_id="default", task_id="shared-task-2"
    )
    assert final.version_count == 1
    assert final.graph_deleted == 1
    assert await store.search_index("default", "SHARED-MODEL") == []
    assert graph.get_projection("default", first.document.document_id) is None
    # A worker that loaded the old snapshot before the tombstone cannot
    # resurrect it after the higher database generation has been applied.
    graph.replace_projection(stale_projection)
    assert graph.get_projection("default", first.document.document_id) is None
    assert await store.list_entities(
        "default", lifecycle_statuses={"active", "approved"}
    ) == []
    health = await store.projection_outbox_health("default")
    assert health["terminal_failures"] == 0
    graph_health = health["by_projection"].get("graph", {})
    assert graph_health.get("pending", 0) == 0
    assert graph_health.get("processing", 0) == 0


@pytest.mark.asyncio
async def test_tombstone_recomputes_shared_entity_and_source_scoped_names(runtime):
    service, store, _graph = runtime
    first_document = _document(model="MODEL-A", order_number="SOURCE-A")
    first_document["lines"][0].update({
        "product_code": "P-SAME",
        "name_raw": "Alias-A raw",
        "name_normalized": "Alias-A normalized",
        "full_product_name": "Alias-A full",
    })
    second_document = _document(model="MODEL-B", order_number="SOURCE-B")
    second_document["lines"][0].update({
        "product_code": "P-SAME",
        "name_raw": "Alias-B raw",
        "name_normalized": "Alias-B normalized",
        "full_product_name": "Alias-B full",
    })

    await service.sync_document(
        tenant_id="default", task_id="source-a-task", document=first_document
    )
    await service.sync_document(
        tenant_id="default", task_id="source-b-task", document=second_document
    )
    products = await store.list_entities("default", entity_type="product")
    product = next(row for row in products if row.canonical_key.endswith(":p-same"))
    assert product.canonical_label == "Alias-B full"
    assert product.attributes["model"] == "MODEL-B"

    await service.tombstone_task(tenant_id="default", task_id="source-b-task")
    surviving = await store.get_entity("default", product.entity_id)
    assert surviving is not None
    assert surviving.lifecycle_status == "active"
    assert surviving.canonical_label == "Alias-A full"
    assert surviving.attributes["model"] == "MODEL-A"

    shared_identity = await store.find_external_identity(
        "default",
        entity_type="product",
        source_system="tenant:internal_product_code",
        external_id="P-SAME",
    )
    assert shared_identity is not None
    assert shared_identity.status == "accepted"
    async with store.sessionmaker() as session:
        alias_statuses = dict((await session.execute(select(
            EntityAliasRow.alias,
            EntityAliasRow.status,
        ).where(
            EntityAliasRow.tenant_id == "default",
            EntityAliasRow.entity_id == product.entity_id,
        ))).all())
        revision_count = len((await session.scalars(select(
            EntityRevisionRow
        ).where(
            EntityRevisionRow.tenant_id == "default",
            EntityRevisionRow.entity_id == product.entity_id,
        ))).all())
    assert alias_statuses["Alias-A full"] == "candidate"
    assert alias_statuses["Alias-B full"] == "superseded"
    assert revision_count >= 2

    await service.tombstone_task(tenant_id="default", task_id="source-a-task")
    deprecated = await store.get_entity("default", product.entity_id)
    assert deprecated is not None
    assert deprecated.lifecycle_status == "deprecated"
    async with store.sessionmaker() as session:
        remaining_alias_statuses = set((await session.scalars(select(
            EntityAliasRow.status
        ).where(
            EntityAliasRow.tenant_id == "default",
            EntityAliasRow.entity_id == product.entity_id,
        ))).all())
        remaining_identity_statuses = set((await session.scalars(select(
            ExternalIdentityRow.status
        ).where(
            ExternalIdentityRow.tenant_id == "default",
            ExternalIdentityRow.entity_id == product.entity_id,
        ))).all())
    assert remaining_alias_statuses == {"superseded"}
    assert remaining_identity_statuses == {"superseded"}


@pytest.mark.asyncio
async def test_tombstone_queries_are_source_scoped_for_large_tenants(runtime):
    service, store, _graph = runtime
    target = await service.sync_document(
        tenant_id="default",
        task_id="scoped-delete-target",
        document=_document(model="SCOPED-TARGET", order_number="SCOPED-TARGET"),
    )
    await service.sync_document(
        tenant_id="default",
        task_id="scoped-delete-noise",
        document=_document(model="SCOPED-NOISE", order_number="SCOPED-NOISE"),
    )

    statements: list[str] = []

    def capture_statement(
        _connection, _cursor, statement, _parameters, _context, _executemany
    ) -> None:
        normalized = " ".join(str(statement).casefold().split())
        if normalized.startswith("select"):
            statements.append(normalized)

    event.listen(store.engine.sync_engine, "before_cursor_execute", capture_statement)
    try:
        await service.tombstone_task(
            tenant_id="default", task_id="scoped-delete-target"
        )
    finally:
        event.remove(
            store.engine.sync_engine, "before_cursor_execute", capture_statement
        )

    occurrence_queries = [
        sql for sql in statements if "from knowledge_source_occurrences" in sql
    ]
    assert occurrence_queries
    assert all(
        "knowledge_source_occurrences.task_id =" in sql.partition(" where ")[2]
        or "knowledge_source_occurrences.asset_id in" in sql.partition(" where ")[2]
        for sql in occurrence_queries
    )
    for table_name in (
        "knowledge_relationship_claims",
        "knowledge_chunks",
        "knowledge_search_index",
        "knowledge_graph_snapshots",
    ):
        scoped = [sql for sql in statements if f"from {table_name}" in sql]
        assert scoped, table_name
        assert all(
            "source_record_id" in sql.partition(" where ")[2] and (
                "source_version" in sql.partition(" where ")[2]
                or ".version" in sql.partition(" where ")[2]
            )
            for sql in scoped
        ), (table_name, scoped)
    assert all(
        target.document.document_id not in sql  # values remain bound parameters
        for sql in statements
    )


@pytest.mark.asyncio
async def test_deleting_current_version_restores_latest_still_bound_version(runtime):
    service, store, graph = runtime
    first = await service.sync_document(
        tenant_id="default",
        task_id="fallback-old-task",
        document=_document(
            model="FALLBACK-OLD",
            order_number="FALLBACK-ORDER",
        ),
    )
    second = await service.sync_document(
        tenant_id="default",
        task_id="fallback-new-task",
        document=_document(
            model="FALLBACK-NEW",
            order_number="FALLBACK-ORDER",
        ),
    )
    assert second.document.version_number == 2
    assert await store.search_index("default", "FALLBACK-OLD") == []
    assert await store.search_index("default", "FALLBACK-NEW")
    current = graph.get_projection("default", first.document.document_id)
    assert current is not None and current.version == "2"

    outcome = await service.tombstone_task(
        tenant_id="default", task_id="fallback-new-task"
    )
    assert outcome.graph_replaced == 1
    assert await store.search_index("default", "FALLBACK-NEW") == []
    assert await store.search_index("default", "FALLBACK-OLD")
    restored = graph.get_projection("default", first.document.document_id)
    assert restored is not None
    assert restored.version == "1"
    assert restored.generation > current.generation
    assert {"REPRESENTS_ORDER", "CONTAINS_PRODUCT"}.issubset(
        {edge.relation for edge in restored.edges}
    )
