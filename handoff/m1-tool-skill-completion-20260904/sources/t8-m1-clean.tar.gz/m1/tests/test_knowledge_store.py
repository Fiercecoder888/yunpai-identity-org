from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError
from sqlalchemy.dialects import postgresql
from sqlalchemy import event
from sqlalchemy.schema import CreateTable

from m1.knowledge import (
    CanonicalEntityRecord,
    ClaimStatus,
    KnowledgeBase,
    KnowledgeStore,
    LifecycleStatus,
    RelationshipClaimRecord,
    ReviewDecisionType,
    TenantBoundaryError,
    TenantRecord,
)
from m1.knowledge.persistence import (
    IdempotencyConflictError,
    _POSTGRES_TENANT_CONTEXT,
)


@pytest.fixture
async def wiki(tmp_path):
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'knowledge.db'}")
    await store.init()
    tenant = await store.create_tenant(TenantRecord(
        tenant_key="acme",
        display_name="ACME Manufacturing",
    ))
    try:
        yield store, tenant
    finally:
        await store.close()


def sample_document(*, quantity: int = 800, needs_review: bool = True) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "stocking-order.xlsx",
            "display_filename": "stocking-order.xlsx",
            "sha256": "a" * 64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "object_uri": "s3://raw/acme/stocking-order.xlsx",
            "size_bytes": 4096,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "桐曦备货单",
            "order_number": "TX2607150002",
            "date_standard": "2026-07-15",
        },
        "lines": [{
            "line_id": "1",
            "line_no": 1,
            "model": "DP-001",
            "name_raw": "DP高清线 1米",
            "quantity": quantity,
            "unit": "条",
        }],
        "totals": {"calculated_quantity": quantity},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "Q3"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "C6"}],
            },
            "$.lines[0].quantity": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Sheet1", "cell": "Q6"}],
            },
        },
        "validation_issues": ([{
            "code": "ORDER_NUMBER_CONFLICT",
            "severity": "warning",
            "message": "备注中存在旧订单号",
            "paths": ["$.header.order_number"],
        }] if needs_review else []),
        "needs_review": needs_review,
    }


@pytest.mark.asyncio
async def test_document_ingest_is_idempotent_evidenced_searchable_and_reviewable(wiki):
    store, tenant = wiki
    first = await store.ingest_document(tenant.tenant_id, "task-1", sample_document())
    replay = await store.ingest_document(tenant.tenant_id, "task-1", sample_document())

    assert first.created is True
    assert replay.created is False
    assert replay.version_id == first.version_id
    assert first.version_number == 1
    assert first.evidence_anchor_count == 3
    assert first.field_claim_count == 3
    assert first.review_task_id is not None

    hits = await store.search_records(tenant.tenant_id, "TX2607150002")
    assert any(hit.record_type == "field_claim" for hit in hits)

    tasks = await store.list_review_tasks(tenant.tenant_id)
    assert [task.review_task_id for task in tasks] == [first.review_task_id]
    decision = await store.decide_review(
        tenant_id=tenant.tenant_id,
        review_task_id=first.review_task_id,
        decision=ReviewDecisionType.ACCEPT,
        reviewer_id="quality-user",
        reason="证据已核对",
    )
    assert decision.target_id == first.version_id
    assert await store.list_review_tasks(tenant.tenant_id) == []

    stats = await store.claim_stats(tenant.tenant_id)
    # Deterministic, non-inferred source facts at >= 0.95 are auto-accepted;
    # the document itself still remains reviewable because of its conflict.
    assert stats["field_claims"] == {"accepted": 3}
    assert stats["open_review_tasks"] == 0
    assert stats["open_conflicts"] == 0


@pytest.mark.asyncio
async def test_public_store_calls_bind_and_reset_transaction_tenant_context(wiki):
    store, tenant = wiki
    observed: list[str] = []

    def capture_context(*_args):  # noqa: ANN002
        observed.append(_POSTGRES_TENANT_CONTEXT.get())

    event.listen(store.engine.sync_engine, "before_cursor_execute", capture_context)
    try:
        loaded = await store.get_tenant(tenant.tenant_id)
    finally:
        event.remove(
            store.engine.sync_engine, "before_cursor_execute", capture_context
        )

    assert loaded is not None
    assert observed and set(observed) == {tenant.tenant_id}
    assert _POSTGRES_TENANT_CONTEXT.get() == ""


@pytest.mark.asyncio
async def test_same_operation_key_rejects_different_document(wiki):
    store, tenant = wiki
    await store.ingest_document(
        tenant.tenant_id, "task-2", sample_document(), idempotency_key="fixed"
    )
    with pytest.raises(IdempotencyConflictError):
        await store.ingest_document(
            tenant.tenant_id,
            "task-2",
            sample_document(quantity=999),
            idempotency_key="fixed",
        )


@pytest.mark.asyncio
async def test_entity_identity_search_relationship_review_and_graph_outbox(wiki):
    store, tenant = wiki
    product = await store.put_entity(CanonicalEntityRecord(
        tenant_id=tenant.tenant_id,
        entity_type="product",
        canonical_key="product:DP-001",
        canonical_label="DP高清连接线 1米",
        lifecycle_status=LifecycleStatus.ACTIVE,
    ))
    material = await store.put_entity(CanonicalEntityRecord(
        tenant_id=tenant.tenant_id,
        entity_type="material",
        canonical_key="material:COPPER-01",
        canonical_label="无氧铜导体",
        lifecycle_status=LifecycleStatus.ACTIVE,
    ))

    relation = await store.claim_relationship(RelationshipClaimRecord(
        tenant_id=tenant.tenant_id,
        idempotency_key="dp001-made-of-copper",
        from_entity_id=product.entity_id,
        relation_type="MADE_OF",
        to_entity_id=material.entity_id,
        confidence=0.91,
        status=ClaimStatus.CANDIDATE,
    ))
    assert relation.relation_type == "MADE_OF"
    assert (await store.search_records(tenant.tenant_id, "无氧铜"))[0].record_id == material.entity_id

    review = (await store.list_review_tasks(tenant.tenant_id))[0]
    assert review.target_id == relation.relationship_id
    await store.decide_review(
        tenant_id=tenant.tenant_id,
        review_task_id=review.review_task_id,
        decision="accept",
        reviewer_id="engineer-1",
    )
    stats = await store.claim_stats(tenant.tenant_id)
    assert stats["relationship_claims"] == {"accepted": 1}

    leased = await store.lease_projection_events(
        "graph", tenant_id=tenant.tenant_id, limit=10, lease_seconds=30
    )
    assert len(leased) == 1
    assert leased[0].aggregate_id == relation.relationship_id
    assert leased[0].attempts == 1
    await store.mark_projection_delivered(leased[0].event_id, tenant_id=tenant.tenant_id)
    assert await store.lease_projection_events("graph", tenant_id=tenant.tenant_id) == []


@pytest.mark.asyncio
async def test_cross_tenant_relationship_is_rejected(wiki):
    store, first_tenant = wiki
    second_tenant = await store.create_tenant(TenantRecord(
        tenant_key="other", display_name="Other Tenant"
    ))
    first_entity = await store.put_entity(CanonicalEntityRecord(
        tenant_id=first_tenant.tenant_id,
        entity_type="product",
        canonical_key="P1",
        canonical_label="Product 1",
        lifecycle_status=LifecycleStatus.ACTIVE,
    ))
    second_entity = await store.put_entity(CanonicalEntityRecord(
        tenant_id=second_tenant.tenant_id,
        entity_type="material",
        canonical_key="M1",
        canonical_label="Material 1",
        lifecycle_status=LifecycleStatus.ACTIVE,
    ))
    with pytest.raises(TenantBoundaryError):
        await store.claim_relationship(RelationshipClaimRecord(
            tenant_id=first_tenant.tenant_id,
            idempotency_key="cross-tenant",
            from_entity_id=first_entity.entity_id,
            relation_type="MADE_OF",
            to_entity_id=second_entity.entity_id,
        ))


def test_bitemporal_contract_rejects_reversed_windows():
    now = datetime.now(timezone.utc)
    with pytest.raises(ValidationError, match="valid_to must be later"):
        CanonicalEntityRecord(
            tenant_id="tenant",
            entity_type="product",
            canonical_key="P1",
            canonical_label="Product",
            valid_from=now,
            valid_to=now - timedelta(seconds=1),
        )


def test_all_knowledge_tables_compile_for_postgresql():
    dialect = postgresql.dialect()
    rendered = {
        table.name: str(CreateTable(table).compile(dialect=dialect))
        for table in KnowledgeBase.metadata.sorted_tables
    }
    assert "knowledge_tenants" in rendered
    assert "knowledge_field_claims" in rendered
    assert "knowledge_chunks" in rendered
    assert "knowledge_search_index" in rendered
    assert "knowledge_graph_snapshots" in rendered
    assert "knowledge_projection_outbox" in rendered
    assert all("CREATE TABLE" in ddl for ddl in rendered.values())
