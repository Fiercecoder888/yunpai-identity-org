from __future__ import annotations

import asyncio
import hashlib
import json
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from time import perf_counter
from types import SimpleNamespace

import httpx
import pytest
import yaml
from m1.benchmarks.lightrag_shadow import lifecycle_probe
from m1.knowledge.lightrag_model_cache import verify_lightrag_model
from m1.knowledge.lightrag_shadow import (
    LightRAGShadowClient,
    LightRAGShadowError,
)
from m1.knowledge.outbox_delivery import (
    EXTERNAL_PROJECTION_LEASE_SECONDS,
    LIGHTRAG_PROJECTION_LEASE_SECONDS,
    OutboxDrainResult,
    _fail_events,
    drain_projection_outbox,
)
from m1.knowledge.persistence import KnowledgeStore
from m1.knowledge.runtime import KnowledgeRuntime
from m1.knowledge.schema import ProjectionEventRecord, utc_now
from m1.knowledge.sinks import InMemoryGraphSink


def test_compose_uses_lightrag_v1_4_storage_environment_names() -> None:
    overlay = (
        Path(__file__).resolve().parents[1] / "docker-compose.lightrag-shadow.yml"
    ).read_text(encoding="utf-8")

    for name in (
        "LIGHTRAG_KV_STORAGE",
        "LIGHTRAG_DOC_STATUS_STORAGE",
        "LIGHTRAG_VECTOR_STORAGE",
        "LIGHTRAG_GRAPH_STORAGE",
    ):
        assert f"      {name}:" in overlay
    for obsolete in (
        "KV_STORAGE",
        "DOC_STATUS_STORAGE",
        "VECTOR_STORAGE",
        "GRAPH_STORAGE",
    ):
        assert f"\n      {obsolete}:" not in overlay


def test_compose_lightrag_healthcheck_uses_an_available_runtime() -> None:
    overlay = yaml.safe_load(
        (
            Path(__file__).resolve().parents[1] / "docker-compose.lightrag-shadow.yml"
        ).read_text(encoding="utf-8")
    )
    probe = overlay["services"]["m1-lightrag"]["healthcheck"]["test"]

    assert probe[:2] == ["CMD", "python"]
    assert "urllib.request.urlopen" in probe[-1]


class _LightRAGServer:
    def __init__(self) -> None:
        self.documents: list[dict] = []
        self.requests: list[tuple[str, str, dict]] = []
        self.fail_inserts = 0
        self.reject_inserts_status = 0
        self.busy_deletes = 0
        self.defer_deletes = False
        self.pending_deletes: set[str] = set()
        self.empty_queries = 0

    def complete_deletes(self) -> None:
        self.documents = [
            item for item in self.documents if item["id"] not in self.pending_deletes
        ]
        self.pending_deletes.clear()

    def __call__(self, request: httpx.Request) -> httpx.Response:
        payload = json.loads(request.content or b"{}")
        path = request.url.path
        self.requests.append((request.method, path, payload))
        assert request.headers["LIGHTRAG-WORKSPACE"] == "m1_shadow"
        assert request.headers["X-API-Key"] == "shadow-secret"
        if path == "/documents/paginated":
            page = int(payload["page"])
            page_size = int(payload["page_size"])
            start = (page - 1) * page_size
            selected = self.documents[start : start + page_size]
            return httpx.Response(
                200,
                json={
                    "documents": selected,
                    "pagination": {
                        "page": page,
                        "page_size": page_size,
                        "total_count": len(self.documents),
                        "total_pages": max(
                            1, (len(self.documents) + page_size - 1) // page_size
                        ),
                        "has_next": start + page_size < len(self.documents),
                        "has_prev": page > 1,
                    },
                    "status_counts": {},
                },
            )
        if path == "/documents/text":
            if self.reject_inserts_status:
                return httpx.Response(
                    self.reject_inserts_status,
                    json={"detail": "rejected"},
                )
            if self.fail_inserts:
                self.fail_inserts -= 1
                return httpx.Response(503, json={"detail": "offline"})
            file_source = payload["file_source"]
            if any(item["file_path"] == file_source for item in self.documents):
                return httpx.Response(409, json={"detail": "same name"})
            if any(item["content"] == payload["text"] for item in self.documents):
                return httpx.Response(
                    200,
                    json={
                        "status": "duplicated",
                        "message": "same content",
                        "track_id": "track-duplicate",
                    },
                )
            self.documents.append(
                {
                    "id": f"doc-{len(self.documents) + 1}",
                    "file_path": file_source,
                    "status": "processed",
                    "content": payload["text"],
                    "content_summary": payload["text"][:100],
                    "content_length": len(payload["text"]),
                    "created_at": "2026-07-19T00:00:00Z",
                    "updated_at": "2026-07-19T00:00:00Z",
                }
            )
            return httpx.Response(
                200,
                json={
                    "status": "success",
                    "message": "accepted",
                    "track_id": "track-1",
                },
            )
        if path == "/documents/delete_document":
            if self.busy_deletes:
                self.busy_deletes -= 1
                return httpx.Response(200, json={"status": "busy"})
            deleted = set(payload["doc_ids"])
            if self.defer_deletes:
                self.pending_deletes.update(deleted)
            else:
                self.documents = [
                    item for item in self.documents if item["id"] not in deleted
                ]
            return httpx.Response(200, json={"status": "deletion_started"})
        if path == "/documents/pipeline_status":
            return httpx.Response(200, json={"busy": bool(self.pending_deletes)})
        if path == "/query":
            if self.empty_queries:
                self.empty_queries -= 1
                return httpx.Response(
                    200,
                    json={"response": "context", "data": {"references": []}},
                )
            return httpx.Response(
                200,
                json={
                    "response": "\n".join(
                        item["content_summary"] for item in self.documents
                    )
                    or "context",
                    "data": {"references": []},
                },
            )
        if path == "/health":
            return httpx.Response(200, json={"status": "healthy"})
        return httpx.Response(404, json={"detail": "not found"})


def _client(server: _LightRAGServer) -> LightRAGShadowClient:
    return LightRAGShadowClient(
        "http://lightrag.test",
        api_key="shadow-secret",
        workspace="m1-shadow",
        transport=httpx.MockTransport(server),
    )


@pytest.mark.asyncio
async def test_rest_adapter_classifies_terminal_and_retryable_failures() -> None:
    async def exercise(status: int) -> LightRAGShadowError:
        client = LightRAGShadowClient(
            "http://lightrag.test",
            transport=httpx.MockTransport(
                lambda _request: httpx.Response(status, json={"detail": "failed"})
            ),
        )
        try:
            with pytest.raises(LightRAGShadowError) as captured:
                await client.query("probe")
            return captured.value
        finally:
            await client.close()

    unauthorized = await exercise(401)
    assert unauthorized.code == "HTTP_401"
    assert unauthorized.category == "authentication"
    assert unauthorized.retryable is False

    invalid_contract = await exercise(422)
    assert invalid_contract.category == "contract"
    assert invalid_contract.retryable is False

    unavailable = await exercise(503)
    assert unavailable.category == "retryable"
    assert unavailable.retryable is True

    lifecycle = LightRAGShadowError("delete_in_progress", category="lifecycle")
    assert lifecycle.retryable is True
    assert lifecycle.lifecycle_wait is True


def _document(*, model: str, needs_review: bool = False) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "private-order.xlsx",
            "display_filename": "customer/private-order.xlsx",
            "sha256": hashlib.sha256(
                f"SHADOW-ORDER-1\x1f{model}".encode()
            ).hexdigest(),
            "verified_external_identity": {
                "verified": True,
                "source_system": "test-shadow-source",
                "external_id": "SHADOW-ORDER-1",
            },
            "mime_type": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ),
            "size_bytes": 4096,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "Shadow order",
            "order_number": "SHADOW-ORDER-1",
            "buyer": "Private Buyer",
            "supplier": "Private Supplier",
        },
        "lines": [
            {
                "line_id": "line-1",
                "line_no": 1,
                "model": model,
                "product_code": f"P-{model}",
                "name_raw": model,
                "name_normalized": model,
                "full_product_name": f"{model} product",
                "product_category": "cable",
                "quantity": 1,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 1},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B5"}],
            },
        },
        "validation_issues": (
            [
                {
                    "code": "SHADOW_REVIEW",
                    "severity": "warning",
                    "message": "review required",
                    "paths": ["$.lines[0].model"],
                }
            ]
            if needs_review
            else []
        ),
        "needs_review": needs_review,
    }


def test_offline_model_manifest_verifier_rejects_corruption(tmp_path) -> None:
    model_root = tmp_path / "model"
    model_root.mkdir()
    model_file = model_root / "weights.bin"
    model_file.write_bytes(b"fixed-model")
    lock = tmp_path / "lock.json"
    lock.write_text(
        json.dumps(
            {
                "model": {
                    "name": "test/model",
                    "revision": "fixed-revision",
                    "files": [
                        {
                            "path": "weights.bin",
                            "size": len(b"fixed-model"),
                            "sha256": hashlib.sha256(b"fixed-model").hexdigest(),
                        }
                    ],
                }
            }
        ),
        encoding="utf-8",
    )
    result = verify_lightrag_model(model_root, lock)
    assert result["status"] == "verified"
    assert result["revision"] == "fixed-revision"

    model_file.write_bytes(b"corrupt")
    with pytest.raises(ValueError, match="size mismatch"):
        verify_lightrag_model(model_root, lock)


@pytest.mark.asyncio
async def test_rest_adapter_hashes_sources_and_is_idempotent() -> None:
    server = _LightRAGServer()
    client = _client(server)
    try:
        first = await client.upsert_document(
            tenant_id="private-tenant",
            source_record_id="raw/source/id",
            version="1",
            fingerprint="fingerprint-1",
            texts=["governed text", "governed text", "second chunk"],
        )
        replay = await client.upsert_document(
            tenant_id="private-tenant",
            source_record_id="raw/source/id",
            version="1",
            fingerprint="fingerprint-1",
            texts=["governed text", "second chunk"],
        )

        assert first.action == "inserted"
        assert replay.action == "unchanged"
        assert len(server.documents) == 1
        file_source = server.documents[0]["file_path"]
        assert file_source.startswith("m1shadow-") and file_source.endswith(".txt")
        assert "private-tenant" not in file_source
        assert "source" not in file_source
        assert "/" not in file_source and "\\" not in file_source
        inserts = [
            item for item in server.requests if item[:2] == ("POST", "/documents/text")
        ]
        assert len(inserts) == 1
        indexed_text = inserts[0][2]["text"]
        content, marker = indexed_text.rsplit("\n\n", maxsplit=1)
        assert content == "governed text\n\n---\n\nsecond chunk"
        marker_digest = marker.removeprefix(
            "<!-- m1-shadow-identity:sha256:"
        ).removesuffix(" -->")
        assert len(marker_digest) == 64
        assert all(character in "0123456789abcdef" for character in marker_digest)
        assert "private-tenant" not in indexed_text
        assert "raw/source/id" not in indexed_text
        assert "fingerprint-1" not in indexed_text
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_same_content_isolated_by_source_and_deleted_independently() -> None:
    server = _LightRAGServer()
    client = _client(server)
    try:
        first = await client.upsert_document(
            tenant_id="tenant-private-value",
            source_record_id="source-private-one",
            version="version-private-one",
            fingerprint="fingerprint-private-one",
            texts=["identical governed content"],
        )
        second = await client.upsert_document(
            tenant_id="tenant-private-value",
            source_record_id="source-private-two",
            version="version-private-two",
            fingerprint="fingerprint-private-two",
            texts=["identical governed content"],
        )
        replay = await client.upsert_document(
            tenant_id="tenant-private-value",
            source_record_id="source-private-one",
            version="version-private-one",
            fingerprint="fingerprint-private-one",
            texts=["identical governed content"],
        )

        assert first.action == second.action == "inserted"
        assert replay.action == "unchanged"
        assert len(server.documents) == 2
        assert len({item["file_path"] for item in server.documents}) == 2
        indexed_texts = [item["content"] for item in server.documents]
        assert indexed_texts[0] != indexed_texts[1]
        for indexed_text in indexed_texts:
            assert indexed_text.startswith("identical governed content\n\n")
            assert "tenant-private-value" not in indexed_text
            assert "source-private-" not in indexed_text
            assert "version-private-" not in indexed_text
            assert "fingerprint-private-" not in indexed_text
        inserts = [
            item for item in server.requests if item[:2] == ("POST", "/documents/text")
        ]
        assert len(inserts) == 2

        first_deleted = await client.delete_source(
            tenant_id="tenant-private-value",
            source_record_id="source-private-one",
        )
        assert first_deleted.action == "deleted"
        assert len(first_deleted.document_ids) == 1
        assert len(server.documents) == 1
        assert server.documents[0]["file_path"] == second.file_source

        second_deleted = await client.delete_source(
            tenant_id="tenant-private-value",
            source_record_id="source-private-two",
        )
        assert second_deleted.action == "deleted"
        assert len(second_deleted.document_ids) == 1
        assert server.documents == []
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_lifecycle_probe_measures_duplicate_and_delete_consistency() -> None:
    server = _LightRAGServer()
    server.empty_queries = 1
    client = _client(server)
    try:
        result = await lifecycle_probe(client, timeout_seconds=5)
        assert result["duplicate_idempotent"] is True
        assert result["repeat_write_document_count"] == 1
        assert result["indexed_retrievable"] is True
        assert result["document_absent_after_delete"] is True
        assert result["query_absent_after_delete"] is True
        assert result["deletion_consistent"] is True
        assert result["error"] is None
        assert server.documents == []
        query_payloads = [
            payload
            for method, path, payload in server.requests
            if method == "POST" and path == "/query"
        ]
        assert query_payloads
        assert {payload["mode"] for payload in query_payloads} == {"naive"}
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_rest_adapter_update_delete_retry_and_query() -> None:
    server = _LightRAGServer()
    client = _client(server)
    try:
        await client.upsert_document(
            tenant_id="default",
            source_record_id="source-1",
            version="1",
            fingerprint="old",
            texts=["old text"],
        )
        server.defer_deletes = True
        with pytest.raises(LightRAGShadowError, match="delete_in_progress"):
            await client.upsert_document(
                tenant_id="default",
                source_record_id="source-1",
                version="2",
                fingerprint="new",
                texts=["new text"],
            )
        server.complete_deletes()
        server.defer_deletes = False
        update = await client.upsert_document(
            tenant_id="default",
            source_record_id="source-1",
            version="2",
            fingerprint="new",
            texts=["new text"],
        )
        assert update.action == "inserted"
        assert len(server.documents) == 1
        assert server.documents[0]["content_summary"].startswith("new text\n\n")
        delete_payloads = [
            payload
            for method, path, payload in server.requests
            if method == "DELETE" and path == "/documents/delete_document"
        ]
        assert delete_payloads == [
            {
                "doc_ids": ["doc-1"],
                "delete_file": False,
                "delete_llm_cache": False,
            }
        ]

        server.busy_deletes = 1
        with pytest.raises(LightRAGShadowError, match="delete_busy"):
            await client.delete_source(tenant_id="default", source_record_id="source-1")
        deleted = await client.delete_source(
            tenant_id="default", source_record_id="source-1"
        )
        assert deleted.action == "deleted"
        assert server.documents == []

        response = await client.query("where is the order", mode="hybrid", top_k=7)
        assert response["response"] == "context"
        query_payload = next(
            payload
            for method, path, payload in server.requests
            if method == "POST" and path == "/query"
        )
        assert query_payload == {
            "query": "where is the order",
            "mode": "hybrid",
            "top_k": 7,
            "chunk_top_k": 7,
            "only_need_context": True,
        }
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_rest_adapter_polls_one_async_delete_without_resubmitting() -> None:
    server = _LightRAGServer()
    client = _client(server)
    try:
        await client.upsert_document(
            tenant_id="default",
            source_record_id="source-async-delete",
            version="1",
            fingerprint="v1",
            texts=["delete me"],
        )
        server.defer_deletes = True

        with pytest.raises(LightRAGShadowError, match="delete_in_progress") as first:
            await client.delete_source(
                tenant_id="default", source_record_id="source-async-delete"
            )
        assert first.value.category == "lifecycle"

        for _ in range(12):
            with pytest.raises(LightRAGShadowError, match="delete_in_progress"):
                await client.delete_source(
                    tenant_id="default", source_record_id="source-async-delete"
                )

        delete_requests = [
            request
            for request in server.requests
            if request[:2] == ("DELETE", "/documents/delete_document")
        ]
        assert len(delete_requests) == 1

        server.complete_deletes()
        result = await client.delete_source(
            tenant_id="default", source_record_id="source-async-delete"
        )
        assert result.action == "deleted"
        assert result.document_ids == ("doc-1",)
    finally:
        await client.close()


class _FailureStore:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    async def fail_projection_event(self, _event_id: str, **kwargs) -> None:
        self.calls.append(kwargs)


def _outbox_event(
    *,
    created_at=None,
    attempts: int = 99,
    last_error: str = "",
) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        tenant_id="default",
        projection_name="lightrag_shadow",
        idempotency_key="lifecycle-wait",
        aggregate_type="document_projection",
        aggregate_id="source-1",
        event_type="lightrag.shadow.delete",
        payload={"action": "delete", "source_record_id": "source-1"},
        attempts=attempts,
        last_error=last_error,
        created_at=created_at or utc_now(),
    )


@pytest.mark.asyncio
async def test_lifecycle_wait_uses_elapsed_deadline_not_attempt_count() -> None:
    store = _FailureStore()
    runtime = SimpleNamespace(store=store, outbox_max_attempts=1)
    lifecycle_error = LightRAGShadowError("delete_in_progress", category="lifecycle")

    fresh_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=99)],
        fresh_result,
        lifecycle_error,
    )
    assert fresh_result.lifecycle_waits == 1
    assert fresh_result.terminal_failures == 0
    assert store.calls[-1]["terminal"] is False
    assert store.calls[-1]["lease_attempt"] == 99

    old_first_wait_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(created_at=utc_now() - timedelta(minutes=31))],
        old_first_wait_result,
        lifecycle_error,
    )
    assert old_first_wait_result.lifecycle_waits == 1
    assert old_first_wait_result.terminal_failures == 0
    assert store.calls[-1]["terminal"] is False
    assert store.calls[-1]["error"].startswith("lifecycle_wait_since=")

    expired_result = OutboxDrainResult(tenant_id="default")
    lifecycle_started = (utc_now() - timedelta(minutes=31)).isoformat()
    await _fail_events(
        runtime,
        [_outbox_event(last_error=f"lifecycle_wait_since={lifecycle_started} busy")],
        expired_result,
        lifecycle_error,
    )
    assert expired_result.lifecycle_waits == 0
    assert expired_result.terminal_failures == 1
    assert store.calls[-1]["terminal"] is True

    transport_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=1)],
        transport_result,
        LightRAGShadowError("HTTP_503"),
    )
    assert transport_result.retried == 0
    assert transport_result.terminal_failures == 1
    assert store.calls[-1]["terminal"] is True


@pytest.mark.asyncio
async def test_lifecycle_polls_do_not_consume_ordinary_failure_budget() -> None:
    store = _FailureStore()
    runtime = SimpleNamespace(store=store, outbox_max_attempts=3)
    lifecycle_error = LightRAGShadowError("delete_in_progress", category="lifecycle")
    lifecycle_started = (utc_now() - timedelta(minutes=1)).isoformat()
    persisted_error = (
        f"lifecycle_wait_since={lifecycle_started} ordinary_failures=1 "
        "delete_in_progress"
    )

    lifecycle_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=500, last_error=persisted_error)],
        lifecycle_result,
        lifecycle_error,
    )
    after_lifecycle = store.calls[-1]["error"]
    assert store.calls[-1]["terminal"] is False
    assert f"lifecycle_wait_since={lifecycle_started}" in after_lifecycle
    assert "ordinary_failures=1" in after_lifecycle

    transport_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=501, last_error=after_lifecycle)],
        transport_result,
        LightRAGShadowError("HTTP_503"),
    )
    after_transport = store.calls[-1]["error"]
    assert store.calls[-1]["terminal"] is False
    assert f"lifecycle_wait_since={lifecycle_started}" in after_transport
    assert "ordinary_failures=2" in after_transport

    second_lifecycle = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=502, last_error=after_transport)],
        second_lifecycle,
        lifecycle_error,
    )
    after_second_lifecycle = store.calls[-1]["error"]
    assert store.calls[-1]["terminal"] is False
    assert "ordinary_failures=2" in after_second_lifecycle

    terminal_result = OutboxDrainResult(tenant_id="default")
    await _fail_events(
        runtime,
        [_outbox_event(attempts=503, last_error=after_second_lifecycle)],
        terminal_result,
        LightRAGShadowError("HTTP_503"),
    )
    assert store.calls[-1]["terminal"] is True
    assert "ordinary_failures=3" in store.calls[-1]["error"]
    assert terminal_result.terminal_failures == 1


@pytest.mark.asyncio
async def test_runtime_fast_path_preserves_worker_failure_budget() -> None:
    event = _outbox_event(
        attempts=503,
        last_error="ordinary_failures=2 previous transport failure",
    )

    class FastPathStore(_FailureStore):
        async def lease_projection_event(self, *_args, **_kwargs):
            return event

    store = FastPathStore()
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        outbox_max_attempts=3,
    )

    async def fail_delivery(_event):
        raise LightRAGShadowError("HTTP_503")

    runtime._deliver_lightrag_projection = fail_delivery

    delivered, error = await runtime._try_lightrag_projection(event)

    assert delivered is False
    assert error == "HTTP_503"
    assert store.calls[-1]["terminal"] is True
    assert store.calls[-1]["lease_attempt"] == 503
    assert "ordinary_failures=3" in store.calls[-1]["error"]


class _BudgetStore:
    def __init__(self, backlog: dict[str, int]) -> None:
        self.backlog = dict(backlog)
        self.lease_calls: list[dict[str, object]] = []
        self.delivered: list[str] = []
        self._sequence = 0

    async def lease_projection_events(
        self,
        projection_name: str,
        *,
        tenant_id: str | None,
        limit: int,
        protect_fresh_seconds: float,
        lease_seconds: int = 60,
    ) -> list[ProjectionEventRecord]:
        self.lease_calls.append(
            {
                "projection_name": projection_name,
                "tenant_id": tenant_id,
                "limit": limit,
                "lease_seconds": lease_seconds,
                "protect_fresh_seconds": protect_fresh_seconds,
            }
        )
        count = min(limit, self.backlog.get(projection_name, 0))
        self.backlog[projection_name] = self.backlog.get(projection_name, 0) - count
        events: list[ProjectionEventRecord] = []
        for _ in range(count):
            self._sequence += 1
            events.append(
                ProjectionEventRecord(
                    tenant_id="default",
                    projection_name=projection_name,
                    idempotency_key=f"{projection_name}-{self._sequence}",
                    aggregate_type="document_projection",
                    aggregate_id=f"source-{self._sequence}",
                    event_type=f"{projection_name}.test",
                    attempts=1,
                )
            )
        return events

    async def mark_projection_events_delivered(
        self,
        event_ids: list[str],
        *,
        tenant_id: str,
        lease_attempts: dict[str, int],
    ) -> int:
        assert tenant_id == "default"
        assert lease_attempts == {event_id: 1 for event_id in event_ids}
        self.delivered.extend(event_ids)
        return len(event_ids)


@pytest.mark.asyncio
async def test_outbox_limit_is_global_and_fair_across_projections() -> None:
    local_projections = ("knowledge", "search", "search_staging", "graph_staging")
    store = _BudgetStore({name: 1_000 for name in local_projections})
    runtime = SimpleNamespace(
        store=store,
        lightrag_shadow=None,
        outbox_max_attempts=10,
    )

    result = await drain_projection_outbox(runtime, tenant_id="default", limit=200)

    assert result.leased == result.delivered == 200
    assert len(store.delivered) == 200
    leased_by_projection = {
        name: 1_000 - store.backlog[name] for name in local_projections
    }
    assert max(leased_by_projection.values()) - min(leased_by_projection.values()) <= 1
    assert all(call["tenant_id"] == "default" for call in store.lease_calls)


@pytest.mark.asyncio
async def test_external_delivery_leases_singly_with_a_per_drain_cap() -> None:
    store = _BudgetStore({"lightrag_shadow": 3})
    runtime = SimpleNamespace(
        store=store,
        lightrag_shadow=object(),
        outbox_max_attempts=10,
    )

    async def deliver(_event: ProjectionEventRecord) -> None:
        return None

    runtime._deliver_lightrag_projection = deliver
    result = await drain_projection_outbox(runtime, tenant_id="default", limit=3)

    assert result.leased == result.delivered == 3
    shadow_calls = [
        call
        for call in store.lease_calls
        if call["projection_name"] == "lightrag_shadow"
    ]
    assert len(shadow_calls) == 3
    assert all(call["limit"] == 1 for call in shadow_calls)
    assert all(
        call["lease_seconds"] == LIGHTRAG_PROJECTION_LEASE_SECONDS
        for call in shadow_calls
    )
    assert LIGHTRAG_PROJECTION_LEASE_SECONDS <= 120
    assert EXTERNAL_PROJECTION_LEASE_SECONDS > LIGHTRAG_PROJECTION_LEASE_SECONDS


class _SlowHealthShadow:
    workspace = "slow-shadow"

    async def health(self) -> dict[str, object]:
        await asyncio.sleep(30)
        return {"enabled": True, "ready": True, "workspace": self.workspace}

    async def close(self) -> None:
        return None


@pytest.mark.asyncio
async def test_lightrag_health_blackhole_degrades_within_one_second(tmp_path) -> None:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'slow-health.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=_SlowHealthShadow(),
    )
    await runtime.init()
    try:
        started = perf_counter()
        health = await runtime.health()
        elapsed = perf_counter() - started

        assert elapsed < 1.0
        assert health["status"] == "ok"
        assert health["lightrag_shadow"]["status"] == "degraded"
        assert health["lightrag_shadow"]["error"] == "TimeoutError"
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_runtime_outbox_retry_tombstone_and_health(tmp_path) -> None:
    server = _LightRAGServer()
    server.fail_inserts = 1
    client = _client(server)
    store = KnowledgeStore(f"sqlite+aiosqlite:///{(tmp_path / 'shadow.db').as_posix()}")
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=client,
    )
    await runtime.init()
    try:
        outcome = await runtime.sync_document(
            tenant_id="default",
            task_id="shadow-task",
            document=_document(model="SHADOW-V1"),
        )
        assert outcome.status == "synced"
        assert outcome.shadow_synced is False
        assert outcome.shadow_error == "HTTP_503"
        assert server.documents == []
        outbox_health = await store.projection_outbox_health("default")
        assert outbox_health["pending"] >= 1
        assert outbox_health["terminal_failures"] == 0
        assert outbox_health["by_projection"]["lightrag_shadow"]["pending"] == 1

        shadow_events = await store.lease_projection_events(
            "lightrag_shadow", tenant_id="default"
        )
        assert len(shadow_events) == 0  # the failed event is still in backoff
        await store.fail_projection_event(
            (
                await store.enqueue_projection(
                    # Enqueueing the same idempotency key returns the durable row.
                    shadow_event_from_outcome(outcome)
                )
            ).event_id,
            tenant_id="default",
            error="due",
            retry_at=utc_now(),
        )
        drained = await runtime.drain_outbox(tenant_id="default")
        assert drained.retried == drained.terminal_failures == 0
        assert server.documents
        stats = await store.projection_stats("default")
        assert stats["outbox"]["lightrag_shadow:delivered"] == 1

        health = await runtime.health()
        assert health["status"] == "ok"
        shadow_health = health["lightrag_shadow"]
        assert shadow_health["enabled"] is True
        assert shadow_health["ready"] is True
        assert shadow_health["workspace"] == "m1_shadow"
        assert shadow_health["error"] is None
        assert shadow_health["last_success_sync_at"]
        assert shadow_health["last_success_delete_at"] is None

        server.defer_deletes = True
        tombstone = await runtime.tombstone_task(
            tenant_id="default", task_id="shadow-task"
        )
        assert tombstone.status == "tombstoned"
        assert tombstone.shadow_deleted == 0
        assert tombstone.shadow_queued == 1
        assert tombstone.shadow_errors == []
        assert server.documents
        server.complete_deletes()
        server.defer_deletes = False
        delete_event = await store.enqueue_projection(
            shadow_delete_event_from_outcome(outcome, task_id="shadow-task")
        )
        await store.fail_projection_event(
            delete_event.event_id,
            tenant_id="default",
            error="due",
            retry_at=utc_now(),
        )
        deleted = await runtime.drain_outbox(tenant_id="default")
        assert deleted.retried == deleted.terminal_failures == 0
        assert server.documents == []
        stats = await store.projection_stats("default")
        assert stats["outbox"]["lightrag_shadow:delivered"] == 2
        health = await runtime.health()
        assert health["lightrag_shadow"]["last_success_delete_at"]
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_lightrag_auth_failure_is_terminal_without_retry_loop(tmp_path) -> None:
    server = _LightRAGServer()
    server.reject_inserts_status = 401
    client = _client(server)
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'shadow-auth.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(store, InMemoryGraphSink(), lightrag_shadow=client)
    await runtime.init()
    try:
        outcome = await runtime.sync_document(
            tenant_id="default",
            task_id="shadow-auth-task",
            document=_document(model="SHADOW-AUTH"),
        )
        assert outcome.status == "synced"
        assert outcome.shadow_synced is False
        assert outcome.shadow_error == "HTTP_401"
        health = await store.projection_outbox_health("default")
        assert health["by_projection"]["lightrag_shadow"]["failed"] == 1
        assert health["by_projection"]["lightrag_shadow"].get("pending", 0) == 0
        assert health["terminal_failures"] == 1
    finally:
        await runtime.close()


def shadow_event_from_outcome(outcome):
    from m1.knowledge.schema import ProjectionEventRecord

    projection = outcome.projection
    return ProjectionEventRecord(
        tenant_id=outcome.tenant_id,
        projection_name="lightrag_shadow",
        idempotency_key=(
            f"lightrag-shadow:upsert:{projection.source_record_id}:"
            f"{projection.version}:{projection.fingerprint}"
        ),
        aggregate_type="document_projection",
        aggregate_id=projection.source_record_id,
        event_type="lightrag.shadow.upsert",
        payload={
            "action": "upsert",
            "reason": "active",
            "source_record_id": projection.source_record_id,
            "version": projection.version,
            "fingerprint": projection.fingerprint,
        },
    )


def shadow_delete_event_from_outcome(
    outcome, *, task_id: str
):
    from m1.knowledge.schema import ProjectionEventRecord

    source_record_id = outcome.projection.source_record_id
    return ProjectionEventRecord(
        tenant_id=outcome.tenant_id,
        projection_name="lightrag_shadow",
        idempotency_key=(
            f"lightrag-shadow:delete:{source_record_id}:tombstone:{task_id}"
        ),
        aggregate_type="document_projection",
        aggregate_id=source_record_id,
        event_type="lightrag.shadow.delete",
        payload={
            "action": "delete",
            "reason": "tombstone",
            "source_record_id": source_record_id,
            "version": "tombstone",
            "fingerprint": "",
        },
    )


@pytest.mark.asyncio
async def test_delayed_active_event_cannot_resurrect_candidate(tmp_path) -> None:
    server = _LightRAGServer()
    server.fail_inserts = 1
    client = _client(server)
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'ordering.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=client,
    )
    await runtime.init()
    try:
        active = await runtime.sync_document(
            tenant_id="default",
            task_id="active-task",
            document=_document(model="ACTIVE-V1"),
        )
        assert active.shadow_synced is False
        candidate_document = deepcopy(_document(model="CANDIDATE-V2"))
        candidate_document["needs_review"] = True
        candidate_document["validation_issues"] = [
            {
                "code": "REVIEW",
                "severity": "warning",
                "message": "review required",
                "paths": ["$.lines[0].model"],
            }
        ]
        candidate = await runtime.sync_document(
            tenant_id="default",
            task_id="candidate-task",
            document=candidate_document,
        )
        assert candidate.projection.status == "candidate"
        # The candidate delete queues behind the failed active upsert for the
        # same source. The worker will reconcile that oldest event to delete
        # before leasing the candidate event.
        assert candidate.shadow_synced is False
        assert server.documents == []

        stale_event = await store.enqueue_projection(shadow_event_from_outcome(active))
        await store.fail_projection_event(
            stale_event.event_id,
            tenant_id="default",
            error="force-out-of-order-retry",
            retry_at=utc_now(),
        )
        drained = await runtime.drain_outbox(tenant_id="default")
        assert drained.retried == drained.terminal_failures == 0
        assert server.documents == []
        # Only the original failed insert reached /documents/text; replaying
        # the oldest event reconciled to the authoritative candidate delete.
        assert (
            len(
                [
                    item
                    for item in server.requests
                    if item[:2] == ("POST", "/documents/text")
                ]
            )
            == 1
        )

        await store.decide_review(
            tenant_id="default",
            review_task_id=candidate.document.review_task_id,
            decision="accept",
            reviewer_id="shadow-reviewer",
            reason="evidence verified",
        )
        promoted = await runtime.drain_outbox(tenant_id="default")
        assert promoted.retried == promoted.terminal_failures == 0
        assert len(server.documents) == 1
        assert (
            "CANDIDATE-V2"
            in [
                payload["text"]
                for method, path, payload in server.requests
                if method == "POST" and path == "/documents/text"
            ][-1]
        )
    finally:
        await runtime.close()
