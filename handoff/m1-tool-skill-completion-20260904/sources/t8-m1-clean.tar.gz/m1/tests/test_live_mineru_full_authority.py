"""Opt-in acceptance against explicitly supplied MinerU and Instructor endpoints."""

from __future__ import annotations

import os
from decimal import Decimal

import pytest
from m1.core.config import Settings
from m1.deps import WorkflowDeps
from m1.documents.parsing.mineru_shadow import build_mineru_shadow_runner
from m1.parsers import ParserRouter
from m1.state import TaskState, TaskStatus
from m1.workflow import TaskStore, WorkflowEngine

pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(
        os.environ.get("M1_RUN_LIVE_FULL_AUTHORITY") != "1",
        reason="set M1_RUN_LIVE_FULL_AUTHORITY=1 for the external model gate",
    ),
]


def _required_environment(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        pytest.fail(f"{name} is required when the live full-authority gate is enabled")
    return value


@pytest.mark.asyncio
async def test_live_mineru_instructor_is_the_only_document_authority(tmp_path) -> None:
    """Exercise parsing, typed mapping, authority gating, and persisted v2 output."""

    source = tmp_path / "synthetic-purchase-order.html"
    source.write_text(
        """<!doctype html>
<html><body>
<h1>采购订单</h1>
<p>订单号: M1-LIVE-PO-42</p>
<p>供应商: 示例电子科技有限公司</p>
<table border="1">
<tr><th>序号</th><th>物料编码</th><th>产品名称</th><th>数量</th><th>单位</th><th>交货日期</th></tr>
<tr><td>1</td><td>LIVE-CABLE-01</td><td>DisplayPort 线缆</td><td>2</td><td>PCS</td><td>2026-08-15</td></tr>
</table>
</body></html>
""",
        encoding="utf-8",
    )
    settings = Settings(
        mineru_shadow_enabled=True,
        mineru_shadow_required=True,
        mineru_base_url=_required_environment("M1_LIVE_MINERU_BASE_URL"),
        mineru_mapper_base_url=_required_environment("M1_LIVE_MAPPER_BASE_URL"),
        mineru_mapper_api_key=os.environ.get("M1_LIVE_MAPPER_API_KEY", ""),
        mineru_mapper_model=_required_environment("M1_LIVE_MAPPER_MODEL"),
        mineru_version=os.environ.get("M1_LIVE_MINERU_VERSION", "3.4.4"),
        mineru_model_revision=os.environ.get("M1_LIVE_MINERU_MODEL_REVISION", ""),
        mineru_timeout_seconds=float(
            os.environ.get("M1_LIVE_MINERU_TIMEOUT_SECONDS", "240")
        ),
        mineru_mapper_timeout_seconds=float(
            os.environ.get("M1_LIVE_MAPPER_TIMEOUT_SECONDS", "90")
        ),
        mineru_full_timeout_seconds=float(
            os.environ.get("M1_LIVE_FULL_TIMEOUT_SECONDS", "600")
        ),
        mineru_visual_assets_enabled=False,
        mineru_drawing_region_vlm_enabled=False,
        mineru_shadow_output_dir=str(tmp_path / "mineru-artifacts"),
    )
    runner = build_mineru_shadow_runner(settings)
    assert runner is not None
    assert runner.authority_mode == "full"
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'live.db').as_posix()}")
    await store.init()
    engine = WorkflowEngine(
        WorkflowDeps(
            parser_router=ParserRouter(),
            vlm_agent=object(),
            confidence_threshold=0.9,
            mineru_shadow_runner=runner,
        ),
        store,
    )
    state = TaskState(
        task_id="live-mineru-full-authority",
        file_path=str(source),
        original_filename=source.name,
        doc_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    try:
        probe = await runner.probe()
        assert probe["ready"] is True
        await engine.run_to_completion(state)

        assert state.status in {TaskStatus.DONE, TaskStatus.NEEDS_REVIEW}
        assert state.mineru_shadow["authority_mode"] == "full"
        assert state.mineru_shadow["authority_selected"] is True
        document = state.document
        assert document is not None
        assert document["schema_version"] == "m1.document.v2"
        assert document["header"]["order_number"] == "M1-LIVE-PO-42"
        line = next(
            item
            for item in document["lines"]
            if item.get("product_code") == "LIVE-CABLE-01"
        )
        line_index = document["lines"].index(line)
        assert Decimal(str(line["quantity"])) == Decimal(2)
        assert line["unit"].casefold() == "pcs"
        assert document["field_meta"]["$.header.order_number"]["source_refs"]
        assert document["field_meta"][f"$.lines[{line_index}].quantity"]["source_refs"]
    finally:
        await runner.close()
        await store.close()
