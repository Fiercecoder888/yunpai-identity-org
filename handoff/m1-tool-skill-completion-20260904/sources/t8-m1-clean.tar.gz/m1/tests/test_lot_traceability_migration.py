from __future__ import annotations

import os
from importlib import import_module
from pathlib import Path

import asyncpg
import pytest
from alembic import command
from sqlalchemy import create_engine, inspect
from sqlalchemy.ext.asyncio import create_async_engine

from m1.knowledge.migrations.runner import _config, upgrade_database


HEAD_REVISION = "0022_flow_request_persistence"
POSTGRES_URL = os.getenv("M1_TEST_POSTGRES_URL", "").strip()


def _asyncpg_url(url: str) -> str:
    return url.replace("postgresql+asyncpg://", "postgresql://", 1)


def test_lot_revision_is_sqlite_safe(tmp_path: Path) -> None:
    engine = create_engine(f"sqlite:///{tmp_path / 'knowledge.db'}")
    try:
        with engine.begin() as connection:
            command.upgrade(_config(connection), HEAD_REVISION)
            assert not inspect(connection).has_table("inventory_movements")
            command.downgrade(_config(connection), "0019_quality_inspection")
    finally:
        engine.dispose()


def test_lot_revision_declares_contract() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0020_lot_traceability"
    )
    assert migration.down_revision == "0019_quality_inspection"
    assert migration.SCHEMA == "yunpai_core"
    assert "lot_id" in Path(migration.__file__).read_text(encoding="utf-8")


@pytest.mark.skipif(not POSTGRES_URL, reason="M1_TEST_POSTGRES_URL is not configured")
@pytest.mark.asyncio
async def test_lot_postgres_upgrade_and_downgrade() -> None:
    assert await upgrade_database(POSTGRES_URL) == HEAD_REVISION
    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    try:
        assert await admin.fetchval(
            """
            SELECT count(*) FROM information_schema.columns
            WHERE table_schema='yunpai_core'
              AND table_name='inventory_movements' AND column_name='lot_id'
            """
        ) == 1
    finally:
        await admin.close()

    engine = create_async_engine(POSTGRES_URL)
    try:
        async with engine.begin() as connection:
            await connection.run_sync(
                lambda sync_connection: command.downgrade(
                    _config(sync_connection), "0019_quality_inspection"
                )
            )
    finally:
        await engine.dispose()

    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    try:
        assert await admin.fetchval(
            """
            SELECT count(*) FROM information_schema.columns
            WHERE table_schema='yunpai_core'
              AND table_name='inventory_movements' AND column_name='lot_id'
            """
        ) == 0
    finally:
        await admin.close()

    assert await upgrade_database(POSTGRES_URL) == HEAD_REVISION
