from pathlib import Path


def _repository() -> Path:
    return Path(__file__).resolve().parents[2]


def test_m1_image_forces_a_verified_system_runtime_layer() -> None:
    dockerfile = (_repository() / "m1/Dockerfile").read_text(encoding="utf-8")

    final_stage = dockerfile.rindex("FROM ${PYTHON_IMAGE}\n")
    apt_layer = dockerfile.index("apt-get install -y --no-install-recommends", final_stage)
    apt_layer_end = dockerfile.index("\n\n# Keep", apt_layer)
    apt_layer_text = dockerfile[apt_layer:apt_layer_end]
    marker = dockerfile.index("20260725-r1", apt_layer, apt_layer_end)
    opencv_reinstall = dockerfile.index("opencv_contrib_version", marker)
    native_load = dockerfile.index("libgls[0]", opencv_reinstall)
    command = dockerfile.index('CMD ["/app/.venv/bin/uvicorn"', native_load)

    assert final_stage < apt_layer < marker < opencv_reinstall < native_load < command
    assert "binutils libgl1 libglx0" in dockerfile
    assert "libgl1:amd64.md5sums" in apt_layer_text
    assert "md5sum --ignore-missing -c" in apt_layer_text
    assert 'test -s "${libgl_path}"' in apt_layer_text
    assert 'readelf -h "${libgl_path}"' in apt_layer_text
    assert "/usr/share/yunpai/m1-rootfs-repair" in apt_layer_text
    assert 'case "$(uname -m)" in' in apt_layer_text
    assert "aarch64-linux-gnu" in apt_layer_text
    assert 'com.yunpai.m1.paddle-model-residency="exclusive-switch-v1"' in dockerfile


def test_release_gates_smoke_the_pulled_m1_image_rootfs() -> None:
    repository = _repository()

    for relative_path in (
        "deploy/source-runtime/deploy.sh",
        "deploy/source-runtime/m1-full-canary.sh",
    ):
        script = (repository / relative_path).read_text(encoding="utf-8")
        assert "--entrypoint /app/.venv/bin/python" in script
        assert 'Path("/var/lib/dpkg/status").stat().st_size > 0' in script
        assert 'Path("/var/lib/dpkg/info/libgl1:amd64.md5sums")' in script
        assert (
            'subprocess.run(["md5sum", "--ignore-missing", "--quiet", "-c"'
            in script
        )
        assert 'ctypes.CDLL("libGL.so.1")' in script
        assert 'version("instructor") == "1.15.1"' in script
        assert "M1 full GPU image dependency smoke failed" in script


def test_docling_import_smoke_is_limited_to_full_parser_builds() -> None:
    dockerfile = (_repository() / "m1/Dockerfile").read_text(encoding="utf-8")

    docling_import = dockerfile.index(
        "from docling.document_converter import DocumentConverter"
    )
    conditional = dockerfile.rindex(
        'if [ "${M1_INSTALL_DOCUMENT_PARSERS}" = "true" ]; then',
        0,
        docling_import,
    )
    conditional_end = dockerfile.index("\n    fi", conditional)
    assert conditional < docling_import < conditional_end
