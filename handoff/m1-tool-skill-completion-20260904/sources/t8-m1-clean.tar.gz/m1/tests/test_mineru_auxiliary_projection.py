from __future__ import annotations

from m1.documents.models import SourceReference
from m1.documents.parsing import mineru_instructor_service as candidate
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru import MinerUParseResult
from m1.documents.parsing.mineru_instructor_poc import (
    ContentUnit,
    EvidenceReference,
    ExtractedFact,
    ExtractedRecord,
    ExtractedSegment,
    MinerUInstructorResult,
)
from m1.documents.parsing.mineru_regions import assess_record_regions


def _table(
    table_id: str,
    rows: list[list[str]],
    *,
    native_part_prefix: str | None = None,
) -> EvidenceTable:
    return EvidenceTable(
        table_id=table_id,
        rows=rows,
        cells=[
            EvidenceCell(
                row=row,
                column=column,
                text=value,
                **(
                    {"source_id": (f"{native_part_prefix}/row:{row}/cell:{column}")}
                    if native_part_prefix is not None
                    else {}
                ),
            )
            for row, values in enumerate(rows)
            for column, value in enumerate(values)
            if value
        ],
    )


def _evidence(
    *tables: EvidenceTable,
    blocks: list[EvidenceBlock] | None = None,
) -> DocumentEvidence:
    return DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=blocks or [],
                tables=list(tables),
            )
        ],
    )


def _reference(evidence_id: str, quote: str) -> EvidenceReference:
    return EvidenceReference(
        evidence_id=evidence_id,
        quote=quote,
        source_ref=SourceReference(page=1, part=f"mineru/{evidence_id}"),
    )


def _result(
    *,
    subtype: str = "engineering_drawing",
    primary_table_ids: list[str] | None = None,
    document_facts: list[ExtractedFact] | None = None,
    segments: list[ExtractedSegment] | None = None,
    content_units: list[ContentUnit] | None = None,
) -> MinerUInstructorResult:
    return MinerUInstructorResult(
        document_intent="technical_document",
        document_intent_family="technical_document",
        document_kind_label=subtype,
        document_subtype=subtype,
        primary_record_table_ids=primary_table_ids or [],
        document_facts=document_facts or [],
        segments=segments or [],
        content_units=content_units or [],
        complete=True,
        semantic_complete=True,
        accounted_complete=True,
        retained_complete=True,
        total_evidence_count=0,
        mapped_evidence_count=0,
        schema_evidence_count=0,
        redundant_evidence_count=0,
        raw_content_evidence_count=0,
        unresolved_evidence_count=0,
        retained_evidence_count=0,
        unmapped_evidence_count=0,
        evidence_coverage_ratio=1.0,
        semantic_accounting_ratio=1.0,
        evidence_accounting_ratio=1.0,
        retained_evidence_ratio=1.0,
        intent_calls=0,
        segment_calls=0,
    )


def _projection(
    evidence: DocumentEvidence,
    extracted: MinerUInstructorResult,
) -> tuple[dict[str, object], dict[str, object]]:
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="fixture-task",
        member_name="fixture.json",
        content_list_v2=[],
        middle_json=None,
        elapsed_ms=1.0,
    )
    record, _field_names = candidate._benchmark_projection(
        source_sha256="a" * 64,
        original_filename="fixture.pdf",
        parsed=parsed,
        extracted=extracted,
    )
    return record, extracted.model_dump(mode="json")


def test_pin_map_is_projected_as_auxiliary_and_replays_without_duplicating_bom() -> (
    None
):
    bom = _table(
        "p1:bom",
        [
            ["Item", "Part Number", "Description", "Qty"],
            ["1", "MAT-100", "Cable", "2"],
            ["2", "MAT-200", "Connector", "4"],
        ],
    )
    pin_map = _table(
        "p1:pin-map",
        [
            ["TYPE C A", "Signal", "TYPE C B"],
            ["A2", "SSTX+", "B11"],
            ["A3", "SSTX-", "B10"],
        ],
    )
    evidence = _evidence(bom, pin_map)
    bom_records = [
        ExtractedRecord(
            fields=[
                ExtractedFact(
                    name="product_code",
                    value=code,
                    evidence_refs=[_reference(f"p1:bom:r{row}:c1", code)],
                )
            ]
        )
        for row, code in ((1, "MAT-100"), (2, "MAT-200"))
    ]
    extracted = _result(
        primary_table_ids=[bom.table_id],
        segments=[
            ExtractedSegment(
                table_id=bom.table_id,
                segment_id="bom-segment",
                intent="records",
                orientation="rows",
                start=1,
                end=2,
                records=bom_records,
            )
        ],
    )

    projection, result_payload = _projection(evidence, extracted)

    generic_facts = projection["generic_facts"]
    assert isinstance(generic_facts, list)
    assert {fact["table_id"] for fact in generic_facts} == {pin_map.table_id}
    pin_records = [fact for fact in generic_facts if fact["name"] == "table_record"]
    assert [fact["value"] for fact in pin_records] == [
        {"TYPE C A": "A2", "Signal": "SSTX+", "TYPE C B": "B11"},
        {"TYPE C A": "A3", "Signal": "SSTX-", "TYPE C B": "B10"},
    ]
    assert all(fact["source_refs"] for fact in generic_facts)
    assert [fact["record_binding"]["axis_index"] for fact in pin_records] == [1, 2]

    document = candidate._production_document(
        {"record": projection, "result": result_payload}
    )
    summary = candidate._record_region_summary(document, result_payload)
    assessment = assess_record_regions(evidence)
    assert summary["mapped_region_ids"] == sorted(
        region.region_id for region in assessment.record_regions
    )
    assert summary["unmapped_region_ids"] == []
    assert summary["generic_record_table_ids"] == [pin_map.table_id]
    assert summary["generic_projection_authoritative"] is True


def test_key_value_table_keeps_first_pair_and_excludes_dedicated_content() -> None:
    key_values = _table(
        "p1:key-values",
        [
            ["Inner mold", "I-01"],
            ["Outer mold", "O-02"],
            ["Housing material", "Aluminum alloy"],
        ],
        native_part_prefix="word/document.xml#table:0",
    )
    blocks = [
        EvidenceBlock(
            block_id="p1:b0",
            kind="title",
            text="Cable assembly",
            source_id="word/document.xml#paragraph:0",
        ),
        EvidenceBlock(
            block_id="p1:b1",
            kind="text",
            text="Apply adhesive after continuity test.",
            source_id="word/document.xml#paragraph:1",
        ),
    ]
    evidence = _evidence(key_values, blocks=blocks)
    title = ExtractedFact(
        name="title",
        value="Cable assembly",
        evidence_refs=[_reference("p1:b0", "Cable assembly")],
    )
    extracted = _result(
        document_facts=[title],
        content_units=[
            ContentUnit(
                evidence_id="p1:b0",
                content_kind="title",
                label="Title",
                exact_text="Cable assembly",
                source_ref=title.evidence_refs[0].source_ref,
                source_kind="title",
                binding_source="local_fallback",
            ),
            ContentUnit(
                evidence_id="p1:b1",
                content_kind="instruction",
                label="Assembly instruction",
                exact_text="Apply adhesive after continuity test.",
                source_ref=SourceReference(page=1, part="mineru/p1:b1"),
                source_kind="text",
                binding_source="model",
            ),
        ],
    )

    projection, result_payload = _projection(evidence, extracted)

    facts = projection["generic_facts"]
    assert isinstance(facts, list)
    assert [fact["value"] for fact in facts if fact["name"] == "table_record"] == [
        {"field": "Inner mold", "value": "I-01"},
        {"field": "Outer mold", "value": "O-02"},
        {"field": "Housing material", "value": "Aluminum alloy"},
    ]
    content = [fact for fact in facts if fact["name"].startswith("content_")]
    assert [(fact["name"], fact["value"]) for fact in content] == [
        ("content_instruction", "Apply adhesive after continuity test.")
    ]
    assert all(fact["source_refs"] for fact in facts)
    source_refs = [reference for fact in facts for reference in fact["source_refs"]]
    assert all(reference["evidence_id"] for reference in source_refs)
    assert all(reference["evidence_quote"] for reference in source_refs)
    assert all(
        reference["native_part"].startswith("word/document.xml#")
        for reference in source_refs
    )

    document = candidate._production_document(
        {"record": projection, "result": result_payload}
    )
    summary = candidate._record_region_summary(document, result_payload)
    assert summary["unmapped_region_ids"] == []
    assert summary["generic_record_bindings"] == [
        {
            "table_id": key_values.table_id,
            "orientation": "rows",
            "axis_indices": [0, 1, 2],
        }
    ]


def test_revision_history_is_nonbusiness_but_remains_losslessly_projected() -> None:
    revision = _table(
        "p1:revision",
        [
            ["Rev.", "Change Details", "Changed By", "Release On"],
            ["A", "Initial release", "Alice", "2026-07-01"],
            ["B", "Connector update", "Bob", "2026-07-18"],
        ],
    )
    evidence = _evidence(revision)

    assessment = assess_record_regions(evidence)

    assert assessment.status == "complete"
    assert assessment.no_record_table_ids == [revision.table_id]
    assert assessment.inconclusive_table_ids == []
    assert assessment.record_regions == []

    projection, _result_payload = _projection(evidence, _result())
    facts = projection["generic_facts"]
    assert isinstance(facts, list)
    schemas = [fact for fact in facts if fact["name"] == "table_schema"]
    records = [fact for fact in facts if fact["name"] == "table_record"]
    assert len(schemas) == 1
    assert schemas[0]["value"]["layout"] == "header_records"
    assert [fact["value"] for fact in records] == [
        {
            "Rev.": "A",
            "Change Details": "Initial release",
            "Changed By": "Alice",
            "Release On": "2026-07-01",
        },
        {
            "Rev.": "B",
            "Change Details": "Connector update",
            "Changed By": "Bob",
            "Release On": "2026-07-18",
        },
    ]
    assert all(fact["source_refs"] for fact in facts)
