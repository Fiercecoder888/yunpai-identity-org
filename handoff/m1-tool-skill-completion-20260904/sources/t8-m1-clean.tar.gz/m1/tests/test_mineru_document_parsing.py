from __future__ import annotations

import asyncio
import io
import json
import os
import threading
import time
import zipfile
from pathlib import Path
from types import SimpleNamespace
from typing import ClassVar

import httpx
import pytest
from pydantic import ValidationError

from m1.documents.models import (
    DocumentRecord,
    FieldMetadata,
    GenericFact,
    OrderLine,
    SourceReference,
)
from m1.documents.parsing.evidence import EvidenceCell, EvidenceTable
from m1.documents.parsing.mineru import (
    MinerUClient,
    MinerUContractError,
    MinerUError,
    MinerUParseResult,
    adapt_content_list_v2,
)
from m1.documents.parsing.mineru_authority import (
    MinerUAuthorityDecision,
    evaluate_mineru_authority,
    fail_closed_authority_payload,
    full_authority_rejection_is_reviewable,
    locally_accepted_candidate_payload,
    preserved_document_with_issue,
    selected_candidate_payload,
)
from m1.documents.parsing.mineru_candidate import (
    MinerUAxisMapping,
    MinerUBusinessMapper,
    MinerUBusinessPlan,
    MinerUFactPlan,
    MinerUTablePlan,
    build_mineru_candidate,
    mapper_evidence_payload,
)
from m1.documents.parsing.mineru_domain import evidence_fact_paths
from m1.documents.parsing.mineru_regions import (
    RecordRegionAssessment,
    assess_record_regions,
    record_region_binding_report,
)
from m1.documents.parsing.mineru_shadow import (
    MinerUCandidateRunResult,
    MinerUShadowRunner,
)

FIXTURE = (
    Path(__file__).parent
    / "fixtures"
    / "mineru"
    / "3.4.4"
    / "sample_order_content_list_v2.json"
)
REVISION = "bff20d4ae2bf202df9f45284b4d43681555a97ed"
_MIDDLE_UNSET = object()


def _payload() -> list[list[dict]]:
    return json.loads(FIXTURE.read_text(encoding="utf-8"))


def _middle() -> dict:
    return {
        "pdf_info": [
            {"page_idx": 0, "page_size": [1000, 1400], "rotation": 0},
            {"page_idx": 1, "page_size": [1000, 1400], "rotation": 90},
        ],
        "_backend": "vlm",
        "_version_name": "3.4.4",
    }


def _archive(
    payload=None,
    *,
    unsafe_member: str | None = None,
    middle: object = _MIDDLE_UNSET,
) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as bundle:
        member = unsafe_member or "sample_order/vlm/sample_order_content_list_v2.json"
        bundle.writestr(
            member, json.dumps(payload if payload is not None else _payload())
        )
        middle_payload = _middle() if middle is _MIDDLE_UNSET else middle
        if middle_payload is not None:
            bundle.writestr(
                "sample_order/vlm/sample_order_middle.json",
                json.dumps(middle_payload),
            )
        bundle.writestr("sample_order/vlm/sample_order.md", "# sample")
    return stream.getvalue()


def _plan(*, data_end: int = 3) -> MinerUBusinessPlan:
    return MinerUBusinessPlan(
        document_type="order",
        document_subtype="supplier_purchase_order",
        classification_evidence_ids=["p1:b0"],
        facts=[
            MinerUFactPlan(
                target="header.title",
                evidence_id="p1:b0",
                quote="采购订单 PO-20260722-01",
                value="采购订单 PO-20260722-01",
            ),
            MinerUFactPlan(
                target="header.order_number",
                evidence_id="p1:b0",
                quote="采购订单 PO-20260722-01",
                value="PO-20260722-01",
            ),
            MinerUFactPlan(
                target="header.delivery_date_raw",
                evidence_id="p1:b1",
                quote="交货日期：2026-07-30",
                value="2026-07-30",
            ),
        ],
        tables=[
            MinerUTablePlan(
                table_id="p1:t0",
                header_indices=[0],
                data_start=1,
                data_end=data_end,
                mappings=[
                    MinerUAxisMapping(
                        axis_index=0,
                        field="product_code",
                        header_evidence_id="p1:t0:r0:c0",
                        header_quote="物料号",
                    ),
                    MinerUAxisMapping(
                        axis_index=1,
                        field="name_raw",
                        header_evidence_id="p1:t0:r0:c1",
                        header_quote="品名",
                    ),
                    MinerUAxisMapping(
                        axis_index=2,
                        field="quantity",
                        header_evidence_id="p1:t0:r0:c2",
                        header_quote="数量",
                    ),
                    MinerUAxisMapping(
                        axis_index=3,
                        field="unit",
                        header_evidence_id="p1:t0:r0:c3",
                        header_quote="单位",
                    ),
                ],
            )
        ],
    )


def _guarded_document(
    *, line_count: int = 1, title: str = "采购订单"
) -> DocumentRecord:
    field_meta: dict[str, FieldMetadata] = {}

    def metadata(part: str) -> FieldMetadata:
        return FieldMetadata(
            source_refs=[
                SourceReference(
                    page=1,
                    part=part,
                    bbox=[0, 0, 20, 10],
                    coordinate_space="page_points",
                )
            ],
            confidence=0.85,
            inferred=True,
        )

    field_meta["$.header.title"] = metadata("mineru/title")
    field_meta["$.header.order_number"] = metadata("mineru/order-number")
    lines: list[OrderLine] = []
    for index in range(line_count):
        lines.append(
            OrderLine(
                line_id=f"mineru-line-{index + 1}",
                product_code=f"SKU-{index + 1}",
                name_raw=f"产品 {index + 1}",
                quantity=index + 1,
                unit="pcs",
            )
        )
        for field in ("product_code", "name_raw", "quantity", "unit"):
            field_meta[f"$.lines[{index}].{field}"] = metadata(
                f"mineru/line-{index + 1}/{field}"
            )
    return DocumentRecord(
        source={"original_filename": "order.pdf", "sha256": "abc"},
        document_type="order",
        document_subtype="supplier_purchase_order",
        header={"title": title, "order_number": "PO-GUARDED-1"},
        lines=lines,
        field_meta=field_meta,
        extraction={
            "metadata": {
                "adapter": "mineru_instructor",
                "evidence_complete": True,
            }
        },
    )


def _completed_candidate_summary() -> dict:
    return {
        "status": "completed",
        "pipeline": "mineru_instructor",
        "instructor_complete": True,
        "candidate_isolation": True,
        "rejected_citations": 0,
        "mapper_dropped_mappings": 0,
        "mapper_dropped_tables": 0,
        "mapper_invalid_facts": 0,
        "source_reference_coverage": {"located": 6, "total": 6, "ratio": 1.0},
        # These direct authority fixtures do not carry MinerU table evidence.
        # Runtime full-authority candidates populate this from the independent
        # full-table assessor; focused record-region tests cover that path.
        "record_region_assessment": {
            "status": "complete",
            "assessed_table_ids": [],
            "no_record_table_ids": [],
            "record_regions": [],
            "inconclusive_table_ids": [],
            "reasons": [],
            "mapped_region_ids": [],
            "mapped_region_bindings": [],
        },
    }


def _mark_instructor_candidate(candidate: DocumentRecord) -> DocumentRecord:
    metadata = candidate.extraction.setdefault("metadata", {})
    metadata["adapter"] = "mineru_instructor"
    metadata["evidence_complete"] = True
    return candidate


def _strict_domain_plan(
    evidence,
    *,
    document_type: str,
    document_subtype: str,
    code_target: str,
    name_target: str,
) -> tuple[RecordRegionAssessment, MinerUBusinessPlan]:
    assessment = assess_record_regions(evidence)
    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert region.table_id == "p1:t0"
    return (
        assessment,
        MinerUBusinessPlan(
            document_type=document_type,
            document_subtype=document_subtype,
            classification_evidence_ids=(
                [] if document_type == "unknown" else ["p1:b0"]
            ),
            facts=(
                [
                    MinerUFactPlan(
                        target="header.order_number",
                        evidence_id="p1:b0",
                        quote="采购订单 PO-20260722-01",
                        value="PO-20260722-01",
                    )
                ]
                if document_type == "order"
                else []
            ),
            tables=[
                MinerUTablePlan(
                    table_id=region.table_id,
                    region_id=region.region_id,
                    orientation=region.orientation,
                    header_indices=[region.data_start - 1],
                    data_start=region.data_start,
                    data_end=region.data_end,
                    mappings=[
                        MinerUAxisMapping(
                            axis_index=0,
                            field=code_target,
                            header_evidence_id="p1:t0:r0:c0",
                            header_quote="物料号",
                        ),
                        MinerUAxisMapping(
                            axis_index=1,
                            field=name_target,
                            header_evidence_id="p1:t0:r0:c1",
                            header_quote="品名",
                        ),
                        MinerUAxisMapping(
                            axis_index=2,
                            field="quantity",
                            header_evidence_id="p1:t0:r0:c2",
                            header_quote="数量",
                        ),
                        MinerUAxisMapping(
                            axis_index=3,
                            field="unit",
                            header_evidence_id="p1:t0:r0:c3",
                            header_quote="单位",
                        ),
                    ],
                )
            ],
        ),
    )


def _strict_candidate_summary(
    assessment: RecordRegionAssessment,
    plan: MinerUBusinessPlan,
) -> dict:
    bindings = [
        {
            "region_id": table.region_id,
            "table_id": table.table_id,
            "orientation": table.orientation,
            "data_start": table.data_start,
            "data_end": table.data_end,
        }
        for table in plan.tables
    ]
    report = record_region_binding_report(assessment, bindings)
    assert report.accepted is True
    summary = _completed_candidate_summary()
    summary["record_region_assessment"] = {
        **assessment.model_dump(mode="json"),
        **report.summary(),
    }
    return summary


@pytest.mark.parametrize(
    ("document_type", "document_subtype", "code_target", "name_target"),
    [
        ("order", "supplier_purchase_order", "product_code", "name_raw"),
        ("inventory", "inventory_snapshot", "material_code", "material_name"),
        ("equipment", "equipment_register", "equipment_code", "equipment_name"),
        ("mold", "mold_mapping", "mold_number", "mold_name"),
        ("procurement", "purchase_order_ledger", "material_code", "material_name"),
        (
            "technical_document",
            "product_specification",
            "technical_drawing_number",
            "technical_product_name",
        ),
    ],
)
def test_full_authority_replays_every_business_domain_from_mineru_evidence(
    tmp_path: Path,
    document_type: str,
    document_subtype: str,
    code_target: str,
    name_target: str,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    assessment, plan = _strict_domain_plan(
        evidence,
        document_type=document_type,
        document_subtype=document_subtype,
        code_target=code_target,
        name_target=name_target,
    )
    source = tmp_path / f"{document_type}.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    _mark_instructor_candidate(candidate)
    decision = evaluate_mineru_authority(
        candidate,
        _strict_candidate_summary(assessment, plan),
        baseline={"source": candidate.source.model_dump(mode="json")},
        document_type_hint=None,
        document_subtype_hint=None,
        authority_mode="full",
    )

    assert rejected == 0
    assert candidate.schema_version == "m1.document.v2"
    assert candidate.document_type == document_type
    assert candidate.document_subtype == document_subtype
    assert len(candidate.lines) == 3
    assert candidate.lines[0].product_code == "SKU-A"
    assert candidate.lines[0].name_raw == "HDMI 2.1线缆"
    assert decision.accepted is True
    assert decision.reasons == ()
    assert evidence_fact_paths(candidate) <= set(candidate.field_meta)


def test_full_authority_rejects_unknown_classification_with_complete_region(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    assessment, plan = _strict_domain_plan(
        evidence,
        document_type="unknown",
        document_subtype="unknown",
        code_target="record_code",
        name_target="record_name",
    )
    source = tmp_path / "unknown.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    _mark_instructor_candidate(candidate)

    assert rejected == 0
    decision = evaluate_mineru_authority(
        candidate,
        _strict_candidate_summary(assessment, plan),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "unknown_classification" in decision.reasons


@pytest.mark.parametrize(
    ("document_type", "document_kind_label"),
    [
        ("commercial_document", "vendor_statement"),
        ("unknown", "custom_compliance_sheet"),
    ],
)
def test_full_authority_accepts_evidence_backed_open_domain_profile(
    document_type: str,
    document_kind_label: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority._record_region_authority_failures",
        lambda _candidate, _summary: [],
    )
    source_ref = SourceReference(
        page=1,
        part="mineru/p1:b0",
        bbox=[0, 0, 20, 10],
        coordinate_space="page_points",
    )
    metadata = FieldMetadata(source_refs=[source_ref], inferred=True)
    candidate = DocumentRecord(
        source={"original_filename": "open-domain.pdf", "sha256": "abc"},
        document_type=document_type,
        document_subtype="unknown",
        document_kind_label=document_kind_label,
        generic_facts=[
            GenericFact(
                name="retention_policy",
                value="Internal handling only",
                source_refs=[source_ref],
                sensitive=True,
            )
        ],
        field_meta={
            "$.document_type": metadata,
            "$.document_kind_label": metadata,
            "$.generic_facts[0].value": metadata,
        },
        extraction={
            "metadata": {
                "adapter": "mineru_instructor",
                "evidence_complete": True,
            },
            "raw_content": {"text_original": "Internal handling only"},
        },
    )

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        authority_mode="full",
    )

    assert decision.accepted is True
    assert decision.reasons == ()
    assert evidence_fact_paths(candidate) <= set(candidate.field_meta)


def test_evidence_fact_paths_require_nested_mapping_leaves_not_container() -> None:
    document = DocumentRecord(
        source={"original_filename": "drawing.docx", "sha256": "abc"},
        document_type="technical_document",
        document_subtype="engineering_drawing",
        lines=[
            OrderLine(
                line_id="line-1",
                name_raw="铝壳",
                custom_fields={
                    "specifications": {
                        "外径尺寸": "19.5±0.05mm",
                        "圆角": {"外圆角": "R3.3", "内圆角": "R2"},
                    }
                },
            )
        ],
    )

    paths = evidence_fact_paths(document)

    prefix = '$.lines[0].custom_fields["specifications"]'
    assert f'{prefix}["外径尺寸"]' in paths
    assert f'{prefix}["圆角"]["外圆角"]' in paths
    assert f'{prefix}["圆角"]["内圆角"]' in paths
    assert prefix not in paths


@pytest.mark.parametrize(
    "document_type",
    ["order", "purchase_order", "technical_document"],
)
def test_full_authority_requires_subtype_for_core_profiles(
    document_type: str,
) -> None:
    candidate = _guarded_document().model_copy(
        update={
            "document_type": document_type,
            "document_subtype": "unknown",
            "document_kind_label": document_type,
        },
        deep=True,
    )
    candidate.field_meta["$.document_type"] = candidate.field_meta[
        "$.header.title"
    ].model_copy(deep=True)
    candidate.field_meta["$.document_kind_label"] = candidate.field_meta[
        "$.header.title"
    ].model_copy(deep=True)

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "incomplete_classification" in decision.reasons


def test_document_record_defaults_new_open_domain_fields_for_legacy_payload() -> None:
    payload = _guarded_document().model_dump(mode="json")
    payload.pop("document_kind_label", None)
    payload.pop("generic_facts", None)

    record = DocumentRecord.model_validate(payload)

    assert record.document_kind_label is None
    assert record.generic_facts == []


def test_full_authority_accepts_sheet_cell_evidence_and_ignores_legacy_baseline(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    assessment, plan = _strict_domain_plan(
        evidence,
        document_type="inventory",
        document_subtype="inventory_snapshot",
        code_target="material_code",
        name_target="material_name",
    )
    source = tmp_path / "inventory.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="库存.xlsx",
        evidence=evidence,
        plan=plan,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    _mark_instructor_candidate(candidate)
    assert rejected == 0
    for metadata in candidate.field_meta.values():
        metadata.source_refs = [SourceReference(sheet="库存", cell="A2")]

    decision = evaluate_mineru_authority(
        candidate,
        _strict_candidate_summary(assessment, plan),
        baseline={
            "document_type": "order",
            "document_subtype": "supplier_purchase_order",
            "lines": [],
        },
        authority_mode="full",
    )

    assert decision.accepted is True
    assert decision.mismatched_baseline_paths == ()


def test_full_authority_accepts_a_completely_replanned_table(tmp_path: Path) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    assessment, plan = _strict_domain_plan(
        evidence,
        document_type="order",
        document_subtype="supplier_purchase_order",
        code_target="product_code",
        name_target="name_raw",
    )
    source = tmp_path / "replanned.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    _mark_instructor_candidate(candidate)
    assert rejected == 0
    summary = _strict_candidate_summary(assessment, plan)
    summary.update(
        {
            "mapper_initial_dropped_mappings": 1,
            "mapper_dropped_mappings": 0,
            "mapper_unresolved_dropped_mappings": 0,
        }
    )

    decision = evaluate_mineru_authority(
        candidate,
        summary,
        authority_mode="full",
    )

    assert decision.accepted is True
    assert "dropped_mappings" not in decision.reasons


def test_full_authority_rejects_nonempty_invalid_fact_proposals() -> None:
    summary = _completed_candidate_summary()
    summary.update(
        {
            "mapper_dropped_facts": 2,
            "mapper_empty_facts": 1,
            "mapper_invalid_facts": 1,
        }
    )

    decision = evaluate_mineru_authority(
        _guarded_document(),
        summary,
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "invalid_fact_proposals" in decision.reasons


def test_full_authority_preserves_locally_rejected_fact_proposals_for_review(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    assessment, plan = _strict_domain_plan(
        evidence,
        document_type="order",
        document_subtype="supplier_purchase_order",
        code_target="product_code",
        name_target="name_raw",
    )
    source = tmp_path / "local-rejection.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    assert rejected == 0
    _mark_instructor_candidate(candidate)
    payload = candidate.model_dump(mode="json")
    payload["validation_issues"] = [
        {
            "code": "MINERU_INSTRUCTOR_UNSUPPORTED_FACT_VALUE",
            "severity": "warning",
            "message": "unsupported_fact_value:quantity",
            "paths": ["$.lines[0].quantity"],
            "source_refs": [],
        },
        {
            "code": "MINERU_INSTRUCTOR_UNKNOWN_EVIDENCE_ID",
            "severity": "warning",
            "message": "unknown_evidence_id:missing-cell",
            "paths": ["$.lines[0].quantity"],
            "source_refs": [],
        },
    ]
    candidate = DocumentRecord.model_validate(payload)
    summary = _strict_candidate_summary(assessment, plan)
    summary.update(
        {
            "mapper_rejected_fact_proposals": 1,
            "mapper_rejected_citations": 1,
        }
    )

    decision = evaluate_mineru_authority(
        candidate,
        summary,
        authority_mode="full",
    )

    assert decision.accepted is False
    assert decision.reasons == ("local_fact_rejections",)
    assert decision.locally_rejected_fact_proposals == 1
    assert decision.locally_rejected_citations == 1
    assert full_authority_rejection_is_reviewable(decision) is True
    assert candidate.lines[0].product_code == "SKU-A"


def test_full_authority_fails_closed_when_local_rejection_audit_mismatches() -> None:
    summary = _completed_candidate_summary()
    summary["mapper_rejected_fact_proposals"] = 1

    decision = evaluate_mineru_authority(
        _guarded_document(),
        summary,
        authority_mode="full",
    )

    assert "local_rejection_audit_mismatch" in decision.reasons
    assert full_authority_rejection_is_reviewable(decision) is False


def test_full_authority_rejects_context_inherited_field_as_current_evidence() -> None:
    candidate = _guarded_document()
    candidate.field_meta["$.lines[0].unit"] = FieldMetadata(
        source_refs=[
            SourceReference(
                sheet="Order",
                cell="D2",
                part="spreadsheet/Order/D2",
            )
        ],
        inferred=True,
        confidence=0.65,
        inference_source="shared_identity_record_group",
    )

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        authority_mode="full",
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert decision.accepted is False
    assert "missing_source_refs" in decision.reasons
    assert "$.lines[0].unit" in decision.missing_source_paths


def test_local_acceptance_keeps_ambiguous_rows_despite_legacy_issue_label() -> None:
    candidate_payload = _guarded_document(line_count=3).model_dump(mode="json")
    for field in ("model", "product_code", "name_raw", "specification_raw"):
        candidate_payload["lines"][1][field] = None
        candidate_payload["field_meta"].pop(f"$.lines[1].{field}", None)
    candidate_payload["validation_issues"] = [
        {
            "code": "ROW_METADATA_ONLY",
            "severity": "warning",
            "message": "The row contains metadata rather than a business record.",
            "paths": ["$.lines[1]"],
            "source_refs": [],
        }
    ]
    candidate = DocumentRecord.model_validate(candidate_payload)
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_domain_records", "invalid_business_lines"),
        invalid_line_paths=("$.lines[1]", "$.lines[2].quantity"),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert [line["product_code"] for line in payload["lines"]] == [
        "SKU-1",
        None,
        "SKU-3",
    ]
    assert "$.lines[1].product_code" not in payload["field_meta"]
    assert "$.lines[2].product_code" in payload["field_meta"]
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 0
    assert acceptance["dropped_line_paths"] == []
    assert acceptance["protected_line_paths"] == ["$.lines[1]"]
    assert acceptance["line_index_map"] == {"0": 0, "1": 1, "2": 2}
    assert acceptance["dropped_validation_issue_codes"] == []
    assert acceptance["review_path_count"] == 2
    assert payload["bom"] == payload["lines"]
    assert all(issue["paths"] != ["$"] for issue in payload["validation_issues"])

    preserved = preserved_document_with_issue(
        payload,
        code="MINERU_FULL_AUTHORITY_REQUIRES_REVIEW",
        message="Review required.",
        gate=decision.summary(),
    )
    issue = preserved["validation_issues"][-1]
    assert issue["paths"] == ["$.lines[1]", "$.lines[2].quantity"]
    assert preserved["extraction"]["metadata"]["local_fact_acceptance"][
        "dropped_gate_paths"
    ] == []


def test_local_acceptance_never_drops_an_identified_business_row() -> None:
    candidate = _guarded_document(line_count=2)
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_business_lines",),
        invalid_line_paths=("$.lines[0]",),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert [line["product_code"] for line in payload["lines"]] == [
        "SKU-1",
        "SKU-2",
    ]
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 0
    assert acceptance["protected_line_paths"] == ["$.lines[0]"]


def test_local_acceptance_retains_raw_only_business_row_for_review() -> None:
    candidate = DocumentRecord(
        source={"original_filename": "raw-only.xlsx"},
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="raw-line-1",
                quantity=4,
                unit="PCS",
                remark="Note",
                custom_fields={"special_process": "custom overmold"},
                raw_columns={
                    "Unmapped product descriptor": "Fiber optic cable assembly",
                    "Qty": "4",
                    "UOM": "PCS",
                },
            )
        ],
    )
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_business_lines",),
        invalid_line_paths=("$.lines[0]",),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert len(payload["lines"]) == 1
    assert payload["lines"][0]["raw_columns"]["Unmapped product descriptor"] == (
        "Fiber optic cable assembly"
    )
    assert payload["lines"][0]["custom_fields"] == {
        "special_process": "custom overmold"
    }
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 0
    assert acceptance["protected_line_paths"] == ["$.lines[0]"]


def test_total_marker_cannot_drop_a_row_with_separate_product_identity() -> None:
    candidate = DocumentRecord(
        source={"original_filename": "total-marker-product.xlsx"},
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="line-1",
                product_code="123456",
                quantity=2,
                raw_columns={"Row type": "Total"},
            )
        ],
    )
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_business_lines",),
        invalid_line_paths=("$.lines[0]",),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert len(payload["lines"]) == 1
    assert payload["lines"][0]["product_code"] == "123456"
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 0
    assert acceptance["protected_line_paths"] == ["$.lines[0]"]


@pytest.mark.parametrize(
    "line",
    [
        OrderLine(line_id="empty"),
        OrderLine(line_id="total", name_raw="\u5408\u8ba1", quantity=12),
        OrderLine(
            line_id="raw-total",
            raw_columns={"Row type": "Total", "Value": "12"},
        ),
        OrderLine(line_id="note", remark="\u5907\u6ce8: confirm packaging before shipment"),
        OrderLine(line_id="placeholder", raw_columns={"Product": "--"}),
    ],
    ids=["empty", "total", "raw-total", "note", "placeholder"],
)
def test_local_acceptance_drops_only_proven_structural_rows(line: OrderLine) -> None:
    candidate = DocumentRecord(
        source={"original_filename": "structural-rows.xlsx"},
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[line],
    )
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_business_lines",),
        invalid_line_paths=("$.lines[0]",),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert payload["lines"] == []
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 1
    assert acceptance["dropped_line_paths"] == ["$.lines[0]"]


def test_local_acceptance_keeps_missing_unit_row_reviewable_without_guessing() -> None:
    candidate = DocumentRecord(
        source={"original_filename": "missing-unit.xlsx"},
        document_type="order",
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="line-1",
                product_code="SKU-NO-UOM",
                quantity=8,
            )
        ],
    )
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_domain_records", "invalid_business_lines"),
        invalid_line_paths=("$.lines[0].unit",),
    )

    payload = locally_accepted_candidate_payload(candidate, decision)

    assert len(payload["lines"]) == 1
    assert payload["lines"][0]["product_code"] == "SKU-NO-UOM"
    assert payload["lines"][0]["quantity"] == 8
    assert payload["lines"][0]["unit"] is None
    acceptance = payload["extraction"]["metadata"]["local_fact_acceptance"]
    assert acceptance["dropped_line_count"] == 0
    assert acceptance["review_path_count"] == 1


def test_full_authority_failure_payload_never_copies_legacy_business_facts() -> None:
    legacy = _guarded_document(line_count=2).model_dump(mode="json")
    legacy["header"]["contract_number"] = "LEGACY-WRONG"

    failed = fail_closed_authority_payload(
        legacy,
        code="MINERU_AUTHORITY_FAILED_CLOSED",
        message="MinerU mapping failed.",
        gate={"reasons": ["candidate_error"]},
        error_type="TimeoutError",
    )

    assert failed["schema_version"] == "m1.document.v2"
    assert failed["document_type"] == "unknown"
    assert failed["document_subtype"] == "unknown"
    assert failed["header"]["contract_number"] is None
    assert failed["lines"] == []
    assert "LEGACY-WRONG" not in json.dumps(failed, ensure_ascii=False)
    assert failed["needs_review"] is True
    assert failed["validation_issues"][0]["severity"] == "error"
    assert failed["extraction"]["metadata"]["authority_mode"] == "full"


def test_selected_full_authority_payload_marks_non_shadow_provenance() -> None:
    payload = selected_candidate_payload(
        _guarded_document(),
        authority_mode="full",
    )

    assert payload["extraction"]["metadata"] == {
        "adapter": "mineru_llm_full_authority",
        "candidate_isolation": False,
        "authority_mode": "full",
        "evidence_complete": True,
    }


def test_selected_full_authority_payload_accepts_only_replayed_high_confidence_inference() -> None:
    candidate = _guarded_document()
    candidate.field_meta["$.header.title"].confidence = 0.95
    candidate.field_meta["$.header.order_number"].confidence = 0.89
    candidate.field_meta["$.header.order_number"].source_refs[0].bbox = None

    payload = selected_candidate_payload(candidate, authority_mode="full")

    title_meta = payload["field_meta"]["$.header.title"]
    assert title_meta["review_required"] is False
    assert title_meta["authority_evidence_replayed"] is True
    order_meta = payload["field_meta"]["$.header.order_number"]
    assert "review_required" not in order_meta
    assert "authority_evidence_replayed" not in order_meta


def test_selected_guarded_payload_does_not_auto_accept_inferred_fields() -> None:
    candidate = _guarded_document()
    candidate.field_meta["$.header.title"].confidence = 1.0

    payload = selected_candidate_payload(candidate, authority_mode="guarded")

    metadata = payload["field_meta"]["$.header.title"]
    assert "review_required" not in metadata
    assert "authority_evidence_replayed" not in metadata


def test_selected_order_candidate_recalculates_line_totals() -> None:
    candidate = _guarded_document(line_count=2)
    candidate.lines[0].amount_tax_excluded = 5
    candidate.lines[1].amount_tax_excluded = 7

    payload = selected_candidate_payload(candidate, authority_mode="full")

    assert payload["totals"]["calculated_quantity"] == 3
    assert payload["totals"]["calculated_amount"] == 12
    assert payload["totals"]["system_calculated"] == {
        "quantity": 3,
        "amount": 12,
    }


def test_full_authority_coverage_only_rejection_is_reviewable() -> None:
    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=(
            "instructor_incomplete",
            "inconclusive_record_region_assessment",
            "missing_source_refs",
        ),
        missing_source_paths=("$.header.title",),
    )

    assert full_authority_rejection_is_reviewable(decision) is True


@pytest.mark.parametrize(
    "reason",
    [
        "rejected_citations",
        "record_region_evidence_fingerprint_mismatch",
        "invalid_fact_proposals",
        "document_subtype_hint_mismatch",
    ],
)
def test_full_authority_integrity_rejection_remains_fail_closed(reason: str) -> None:
    decision = MinerUAuthorityDecision(accepted=False, reasons=(reason,))

    assert full_authority_rejection_is_reviewable(decision) is False


def test_mineru_plan_requires_canonical_consistent_classification() -> None:
    with pytest.raises(ValidationError):
        MinerUBusinessPlan(
            document_type="采购订单",
            document_subtype="supplier_purchase_order",
        )
    with pytest.raises(ValidationError, match="inconsistent"):
        MinerUBusinessPlan(
            document_type="inventory",
            document_subtype="supplier_purchase_order",
        )
    with pytest.raises(ValidationError):
        MinerUAxisMapping(
            axis_index=0,
            field="drawing_number",
            header_evidence_id="p1:t0:r0:c0",
            header_quote="物料号",
        )


@pytest.mark.asyncio
async def test_mineru_mapper_normalizes_local_mapping_failures_and_layout_tables(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    evidence.pages[0].tables.append(
        EvidenceTable(
            table_id="p1:t-layout",
            rows=[["版本", "日期"], ["A", "2026-07-22"]],
            cells=[
                EvidenceCell(row=0, column=0, text="版本"),
                EvidenceCell(row=0, column=1, text="日期"),
                EvidenceCell(row=1, column=0, text="A"),
                EvidenceCell(row=1, column=1, text="2026-07-22"),
            ],
        )
    )

    class ProposalClient:
        instructions: ClassVar[list[str]] = []

        async def run(self, output_type, *, instructions, prompt, request_limit):
            self.instructions.append(instructions)
            assert request_limit == 2
            assert "p1:t-layout" in prompt
            output = output_type.model_validate(
                {
                    "document_type": "technical_document",
                    "document_subtype": "approval_drawing",
                    "classification_evidence_ids": ["p1:b0"],
                    "facts": [],
                    "tables": [
                        {
                            "table_id": "p1:t0",
                            "orientation": "rows",
                            "header_indices": [0],
                            "data_start": 1,
                            "data_end": 3,
                            "mappings": [
                                {
                                    "axis_index": 0,
                                    "field": "product_code",
                                    "header_evidence_id": "p1:t0:r0:c0",
                                    "header_quote": "",
                                },
                                {
                                    "axis_index": 1,
                                    "field": "name_raw",
                                    "header_evidence_id": "p1:t0:r0:c1",
                                    "header_quote": "品名",
                                },
                                {
                                    "axis_index": 2,
                                    "field": "quantity",
                                    "header_evidence_id": "p1:t0:r0:c2",
                                    "header_quote": "",
                                },
                                {
                                    "axis_index": 3,
                                    "field": "drawing_number",
                                    "header_evidence_id": "p1:t0:r0:c3",
                                    "header_quote": "单位",
                                },
                                {
                                    "axis_index": 0,
                                    "field": "product_code",
                                    "header_evidence_id": "p1:t0:r0:c0",
                                    "header_quote": "物料号",
                                },
                                {
                                    "axis_index": 0,
                                    "field": "model",
                                    "header_evidence_id": "p1:t0:r0:c1",
                                    "header_quote": "",
                                },
                            ],
                        },
                        {
                            "table_id": "p1:t-layout",
                            "orientation": "rows",
                            "header_indices": [0],
                            "data_start": 1,
                            "data_end": 1,
                            "mappings": [
                                {
                                    "axis_index": 0,
                                    "field": "",
                                    "header_evidence_id": "p1:t-layout:r0:c0",
                                    "header_quote": "版本",
                                },
                                {
                                    "axis_index": 1,
                                    "field": "drawing_number",
                                    "header_evidence_id": "",
                                    "header_quote": "日期",
                                },
                            ],
                        },
                    ],
                }
            )
            return SimpleNamespace(
                output=output,
                duration_seconds=0.01,
                usage={"requests": 1, "completion_tokens": 1397},
            )

    client = ProposalClient()
    mapper = MinerUBusinessMapper(client=client, model="qwen35b")
    plan, _, usage = await mapper.plan(evidence)

    assert isinstance(plan, MinerUBusinessPlan)
    assert len(plan.tables) == 1
    assert plan.tables[0].table_id == "p1:t0"
    assert [mapping.field for mapping in plan.tables[0].mappings] == [
        "product_code",
        "name_raw",
        "quantity",
    ]
    assert plan.tables[0].mappings[0].header_quote == "物料号"
    assert plan.tables[0].mappings[2].header_quote == "数量"
    assert usage["repaired_mappings"] == 2
    assert usage["dropped_mappings"] == 5
    assert usage["dropped_tables"] == 1
    assert usage["completion_tokens"] == 1397
    assert "repeated business records or BOM rows" in client.instructions[0]
    assert "inventory, procurement ledger entries" in client.instructions[0]
    assert (
        "all unmapped source columns are retained losslessly" in client.instructions[0]
    )
    assert "header_indices may be empty" in client.instructions[0]

    source = tmp_path / "technical-drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="技术图纸.pdf",
        evidence=evidence,
        plan=plan,
    )
    assert rejected == 0
    assert len(candidate.lines) == 3
    assert all(line.product_code for line in candidate.lines)
    assert all(line.quantity is not None for line in candidate.lines)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("data_end", "sample_rows", "accepted"),
    [
        (3, (1,), True),
        (None, (1,), False),
        (3, (1, 2), False),
    ],
)
async def test_mineru_mapper_requires_one_explicit_headerless_record_range(
    tmp_path: Path,
    data_end: int | None,
    sample_rows: tuple[int, ...],
    accepted: bool,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    fields = ("product_code", "name_raw", "quantity", "unit")

    class ProposalClient:
        async def run(self, output_type, *, instructions, prompt, request_limit):
            assert "contiguous data range" in instructions
            mappings = []
            table = evidence.pages[0].tables[0]
            for axis_index, field in enumerate(fields):
                sample_row = sample_rows[axis_index % len(sample_rows)]
                value = str(table.rows[sample_row][axis_index])
                mappings.append(
                    {
                        "axis_index": axis_index,
                        "field": field,
                        "header_evidence_id": f"p1:t0:r{sample_row}:c{axis_index}",
                        "header_quote": value,
                    }
                )
            return SimpleNamespace(
                output=output_type.model_validate(
                    {
                        "document_type": "order",
                        "document_subtype": "supplier_purchase_order",
                        "classification_evidence_ids": ["p1:b0"],
                        "facts": [],
                        "tables": [
                            {
                                "table_id": "p1:t0",
                                "orientation": "rows",
                                "header_indices": [],
                                "data_start": 1,
                                "data_end": data_end,
                                "mappings": mappings,
                            }
                        ],
                    }
                ),
                duration_seconds=0.01,
                usage={"requests": 1},
            )

    plan, _, usage = await MinerUBusinessMapper(
        client=ProposalClient(), model="qwen35b"
    ).plan(evidence)

    if not accepted:
        assert plan.tables == []
        assert usage["dropped_tables"] == 1
        return

    assert plan.tables[0].header_indices == []
    source = tmp_path / "headerless-order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="headerless-order.pdf",
        evidence=evidence,
        plan=plan,
    )
    assert rejected == 0
    assert len(candidate.lines) == 3
    assert all(line.product_code for line in candidate.lines)


@pytest.mark.asyncio
async def test_mapper_drops_blank_fact_values_without_losing_valid_or_rejected_facts(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    title = evidence.pages[0].blocks[0].text

    class ProposalClient:
        async def run(self, output_type, *, instructions, prompt, request_limit):
            assert "labelled empty form field is not a fact" in instructions
            assert request_limit == 2
            return SimpleNamespace(
                output=output_type.model_validate(
                    {
                        "document_type": "order",
                        "document_subtype": "supplier_purchase_order",
                        "classification_evidence_ids": ["p1:b0"],
                        "facts": [
                            {
                                "target": "header.seller",
                                "evidence_id": "p1:b0",
                                "quote": title,
                                "value": "",
                            },
                            {
                                "target": "header.not_a_real_field",
                                "evidence_id": "p1:b0",
                                "quote": title,
                                "value": "unsupported",
                            },
                            {
                                "target": "header.title",
                                "evidence_id": "p1:b0",
                                "quote": title,
                                "value": "PO-20260722-01",
                            },
                            {
                                "target": "header.order_number",
                                "evidence_id": "p1:b0",
                                "quote": "citation that is absent from the evidence",
                                "value": "PO-REJECTED",
                            },
                        ],
                        "tables": [],
                    }
                ),
                duration_seconds=0.01,
                usage={"requests": 1},
            )

    mapper = MinerUBusinessMapper(client=ProposalClient(), model="qwen35b")
    plan, _, usage = await mapper.plan(evidence)

    assert [fact.target for fact in plan.facts] == [
        "header.title",
        "header.order_number",
    ]
    assert usage["dropped_facts"] == 2
    assert usage["empty_facts"] == 1
    assert usage["invalid_facts"] == 1

    source = tmp_path / "blank-fields.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
    )

    assert candidate.header.title == "PO-20260722-01"
    assert candidate.header.order_number is None
    assert rejected == 1
    assert any(
        issue.code == "MINERU_MAPPER_EVIDENCE_REJECTED"
        and issue.paths == ["$.header.order_number"]
        for issue in candidate.validation_issues
    )


@pytest.mark.asyncio
async def test_mapper_repairs_field_axis_header_indices_from_cited_cells(
    tmp_path: Path,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    headers = ["序号", "物料号", "品名", "数量", "单位", "备注"]
    values = ["1", "SKU-1", "电缆", "10", "pcs", "加急"]
    evidence.pages[0].tables.append(
        EvidenceTable(
            table_id="p1:t-repair",
            rows=[headers, values],
            cells=[
                EvidenceCell(row=row, column=column, text=value)
                for row, values_row in enumerate((headers, values))
                for column, value in enumerate(values_row)
            ],
        )
    )

    class ProposalClient:
        instructions = ""

        async def run(self, output_type, *, instructions, prompt, request_limit):
            self.instructions = instructions
            mappings = [
                {
                    "axis_index": column,
                    "field": field,
                    "header_evidence_id": f"p1:t-repair:r0:c{column}",
                    "header_quote": f"{headers[column]} (model paraphrase)",
                }
                for column, field in enumerate(
                    (
                        "line_no",
                        "product_code",
                        "name_raw",
                        "quantity",
                        "unit",
                        "remark",
                    )
                )
            ]
            return SimpleNamespace(
                output=output_type.model_validate(
                    {
                        "document_type": "order",
                        "document_subtype": "supplier_purchase_order",
                        "classification_evidence_ids": ["p1:b0"],
                        "facts": [],
                        "tables": [
                            {
                                "table_id": "p1:t-repair",
                                "orientation": "rows",
                                "header_indices": [0, 1, 2, 3, 4, 5],
                                "data_start": 1,
                                "data_end": 2,
                                "mappings": mappings,
                            }
                        ],
                    }
                ),
                duration_seconds=0.01,
                usage={"requests": 1},
            )

    client = ProposalClient()
    mapper = MinerUBusinessMapper(client=client, model="qwen35b")
    plan, _, usage = await mapper.plan(evidence)

    assert plan.tables[0].header_indices == [0]
    assert plan.tables[0].data_end == 1
    assert [mapping.header_quote for mapping in plan.tables[0].mappings] == headers
    assert usage["repaired_mappings"] == 6
    assert usage["dropped_mappings"] == 0
    assert usage["dropped_tables"] == 0
    assert "header_indices are record-axis indexes" in client.instructions
    source = tmp_path / "repair.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="repair.pdf",
        evidence=evidence,
        plan=plan,
    )
    assert rejected == 0
    assert len(candidate.lines) == 1
    assert candidate.lines[0].product_code == "SKU-1"
    assert candidate.lines[0].quantity == 10


@pytest.mark.asyncio
@pytest.mark.parametrize("duplicate_target", [False, True])
async def test_mapper_table_replan_is_exact_and_preserves_document_facts(
    duplicate_target: bool,
) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    table = evidence.pages[0].tables[0]
    fields = ("product_code", "name_raw", "quantity", "unit")
    title = evidence.pages[0].blocks[0].text

    def mappings(count: int) -> list[dict[str, object]]:
        return [
            {
                "axis_index": column,
                "field": field,
                "header_evidence_id": f"p1:t0:r0:c{column}",
                "header_quote": str(table.rows[0][column]),
            }
            for column, field in enumerate(fields[:count])
        ]

    class ProposalClient:
        calls: ClassVar[list[tuple[type, str, str]]] = []

        async def run(self, output_type, *, instructions, prompt, request_limit):
            self.calls.append((output_type, instructions, prompt))
            assert request_limit == 2
            if len(self.calls) == 1:
                initial_mappings = mappings(3)
                initial_mappings.append(
                    {
                        "axis_index": 99,
                        "field": "unit",
                        "header_evidence_id": "p1:t0:r0:c3",
                        "header_quote": str(table.rows[0][3]),
                    }
                )
                return SimpleNamespace(
                    output=output_type.model_validate(
                        {
                            "document_type": "technical_document",
                            "document_subtype": "approval_drawing",
                            "classification_evidence_ids": ["p1:b0"],
                            "facts": [
                                {
                                    "target": "header.title",
                                    "evidence_id": "p1:b0",
                                    "quote": title,
                                    "value": title,
                                }
                            ],
                            "tables": [
                                {
                                    "table_id": "p1:t0",
                                    "orientation": "rows",
                                    "header_indices": [0],
                                    "data_start": 1,
                                    "data_end": 3,
                                    "mappings": initial_mappings,
                                }
                            ],
                        }
                    ),
                    duration_seconds=0.01,
                    usage={"requests": 1, "completion_tokens": 10},
                )
            assert "must not output document classification or facts" in instructions
            assert json.loads(prompt)["target_table_ids"] == ["p1:t0"]
            replan_table = {
                "table_id": "p1:t0",
                "orientation": "rows",
                "header_indices": [0],
                "data_start": 1,
                "data_end": 3,
                "mappings": mappings(3 if duplicate_target else 4),
            }
            return SimpleNamespace(
                output=output_type.model_validate(
                    {"tables": [replan_table] * (2 if duplicate_target else 1)}
                ),
                duration_seconds=0.02,
                usage={"requests": 1, "completion_tokens": 12},
            )

    client = ProposalClient()
    plan, duration, usage = await MinerUBusinessMapper(
        client=client,
        model="qwen35b",
    ).plan(evidence)

    assert len(client.calls) == 2
    assert plan.document_type == "technical_document"
    assert plan.document_subtype == "approval_drawing"
    assert [fact.target for fact in plan.facts] == ["header.title"]
    assert [mapping.field for mapping in plan.tables[0].mappings] == list(
        fields[: (3 if duplicate_target else 4)]
    )
    assert duration == pytest.approx(0.03)
    assert usage["requests"] == 2
    assert usage["completion_tokens"] == 22
    assert usage["dropped_mappings"] == 1
    assert usage["dropped_tables"] == 0
    assert usage["initial_dropped_mappings"] == 1
    assert usage["initial_dropped_tables"] == 0
    assert usage["unresolved_dropped_mappings"] == int(duplicate_target)
    assert usage["unresolved_dropped_tables"] == 0
    assert usage["replan_attempted"] == 1
    assert usage["replan_replaced_tables"] == int(not duplicate_target)
    assert usage["replan_rejected"] == int(duplicate_target)


def test_mineru_v2_adapter_preserves_pages_tables_and_honest_geometry() -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=12.5,
        middle_json=_middle(),
    )

    assert len(evidence.pages) == 2
    assert (evidence.pages[0].width, evidence.pages[0].height) == (1000, 1400)
    assert evidence.pages[1].rotation == 90
    assert evidence.pages[1].blocks == []
    table = evidence.pages[0].tables[0]
    assert table.table_type == "complex_table"
    assert table.rows[1] == ["SKU-A", "HDMI 2.1线缆", "100", "pcs"]
    assert table.rows[3] == ["SKU-B", "DP 2.1线缆黑色", "30", "pcs"]
    assert table.cells[0].bbox_precision == "table"
    assert table.cells[0].bbox.as_list() == [0.05, 0.25, 0.95, 0.72]
    assert any(block.sub_type == "seal" for block in evidence.pages[0].blocks)


def test_mineru_v2_adapter_preserves_equations_and_all_visual_captions() -> None:
    evidence = adapt_content_list_v2(
        [
            [
                {
                    "type": "equation_interline",
                    "content": {"math_content": "E = mc^2", "math_type": "latex"},
                    "bbox": [10, 10, 200, 80],
                },
                {
                    "type": "chart",
                    "content": {
                        "chart_caption": [{"type": "text", "content": "Sales"}],
                        "chart_footnote": [{"type": "text", "content": "Unit: CNY"}],
                    },
                    "bbox": [20, 100, 900, 800],
                },
            ]
        ],
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json={
            "pdf_info": [{"page_size": [1000, 1400]}],
            "_backend": "vlm",
            "_version_name": "3.4.4",
        },
    )

    assert evidence.pages[0].blocks[0].text == "E = mc^2"
    assert evidence.pages[0].blocks[1].text == "Sales\nUnit: CNY"


@pytest.mark.asyncio
async def test_mineru_client_polls_and_reads_pinned_zip_contract(
    tmp_path: Path,
) -> None:
    statuses = iter(["pending", "processing", "completed"])
    requests: list[httpx.Request] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        if request.method == "POST" and request.url.path == "/tasks":
            body = await request.aread()
            assert b'name="backend"' in body and b"vlm-engine" in body
            assert b'name="response_format_zip"' in body and b"true" in body
            assert b'name="return_images"' in body and b"false" in body
            assert b'name="end_page_id"' not in body
            return httpx.Response(202, json={"task_id": "task-1", "status": "pending"})
        if request.url.path == "/tasks/task-1":
            return httpx.Response(
                200, json={"task_id": "task-1", "status": next(statuses)}
            )
        if request.url.path == "/tasks/task-1/result":
            return httpx.Response(
                200,
                content=_archive(),
                headers={"content-type": "application/zip"},
            )
        raise AssertionError(request.url)

    source = tmp_path / "采购订单.pdf"
    source.write_bytes(b"%PDF-1.4 fixture")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        model_revision=REVISION,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await client.parse(source)
    finally:
        await client.close()

    assert result.task_id == "task-1"
    assert result.member_name.endswith("_content_list_v2.json")
    assert len(result.evidence.pages) == 2
    assert [request.url.path for request in requests].count("/tasks/task-1") == 3


@pytest.mark.asyncio
async def test_mineru_client_reconnects_status_get_without_resubmitting(
    tmp_path: Path,
) -> None:
    calls = {"post": 0, "status": 0, "result": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            calls["post"] += 1
            return httpx.Response(202, json={"task_id": "task-reconnect"})
        if request.url.path.endswith("/result"):
            calls["result"] += 1
            return httpx.Response(200, content=_archive())
        calls["status"] += 1
        if calls["status"] == 1:
            raise httpx.RemoteProtocolError("peer closed reused connection")
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "status-reconnect.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await client.parse(source)
        status = client.status()
    finally:
        await client.close()

    assert result.task_id == "task-reconnect"
    assert calls == {"post": 1, "status": 2, "result": 1}
    assert status["transport_disconnects"] == 1
    assert status["transport_reconnects"] == 1
    assert status["transport_retry_exhaustions"] == 0
    assert status["last_transport_operation"] == "status_poll"


@pytest.mark.asyncio
async def test_mineru_client_redownloads_result_after_stream_disconnect(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class DisconnectingStream(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b"PKpartial"
            raise httpx.RemoteProtocolError("peer closed streamed result")

    calls = {"post": 0, "status": 0, "result": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            calls["post"] += 1
            return httpx.Response(202, json={"task_id": "task-stream"})
        if request.url.path.endswith("/result"):
            calls["result"] += 1
            if calls["result"] == 1:
                return httpx.Response(200, stream=DisconnectingStream())
            return httpx.Response(200, content=_archive())
        calls["status"] += 1
        return httpx.Response(200, json={"status": "completed"})

    monkeypatch.setattr("m1.documents.parsing.mineru.tempfile.tempdir", str(tmp_path))
    source = tmp_path / "stream-reconnect.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await client.parse(source)
        status = client.status()
    finally:
        await client.close()

    assert result.task_id == "task-stream"
    assert calls == {"post": 1, "status": 1, "result": 2}
    assert status["transport_reconnects"] == 1
    assert status["last_transport_operation"] == "result_download"
    assert list(tmp_path.glob("m1-mineru-result-*.zip")) == []


@pytest.mark.asyncio
async def test_mineru_client_exhausts_status_reconnect_without_resubmitting(
    tmp_path: Path,
) -> None:
    calls = {"post": 0, "status": 0}

    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            calls["post"] += 1
            return httpx.Response(202, json={"task_id": "task-disconnect"})
        calls["status"] += 1
        raise httpx.RemoteProtocolError("peer closed reused connection")

    source = tmp_path / "status-exhausted.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(httpx.RemoteProtocolError):
            await client.parse(source)
        status = client.status()
    finally:
        await client.close()

    assert calls == {"post": 1, "status": 2}
    assert status["transport_disconnects"] == 2
    assert status["transport_reconnects"] == 1
    assert status["transport_retry_exhaustions"] == 1
    assert status["last_failure_stage"] == "status_poll"


@pytest.mark.asyncio
async def test_mineru_client_never_retries_submit_disconnect(tmp_path: Path) -> None:
    post_calls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal post_calls
        assert request.method == "POST"
        post_calls += 1
        raise httpx.RemoteProtocolError("submit response was lost")

    source = tmp_path / "submit-disconnect.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(httpx.RemoteProtocolError):
            await client.parse(source)
        status = client.status()
    finally:
        await client.close()

    assert post_calls == 1
    assert status["transport_disconnects"] == 0
    assert status["transport_reconnects"] == 0
    assert status["last_failure_stage"] == "submit"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("middle", "message"),
    [
        (None, "missing the required middle JSON"),
        ({**_middle(), "_version_name": "3.5.0"}, "result version"),
        ({**_middle(), "_backend": "pipeline"}, "result backend"),
    ],
)
async def test_mineru_client_rejects_result_contract_drift(
    tmp_path: Path,
    middle: dict | None,
    message: str,
) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task-drift"})
        if request.url.path.endswith("/result"):
            return httpx.Response(200, content=_archive(middle=middle))
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "sample.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(MinerUContractError, match=message):
            await client.parse(source)
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_mineru_client_rejects_known_page_limit_before_upload(
    tmp_path: Path,
) -> None:
    import fitz

    source = tmp_path / "too-long.pdf"
    document = fitz.open()
    for _ in range(3):
        document.new_page()
    document.save(source)
    document.close()
    submitted = False

    async def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal submitted
        submitted = True
        return httpx.Response(500)

    client = MinerUClient(
        base_url="http://mineru.test",
        max_pages=2,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(MinerUContractError, match="MINERU_PAGE_LIMIT_EXCEEDED"):
            await client.parse(source)
    finally:
        await client.close()
    assert submitted is False


@pytest.mark.asyncio
async def test_mineru_client_rejects_unbounded_result_page_count(
    tmp_path: Path,
) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task-long"})
        if request.url.path.endswith("/result"):
            return httpx.Response(200, content=_archive(payload=[[], [], []]))
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "unknown.docx"
    source.write_bytes(b"not-countable-by-client")
    client = MinerUClient(
        base_url="http://mineru.test",
        max_pages=2,
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(MinerUContractError, match="MINERU_PAGE_LIMIT_EXCEEDED"):
            await client.parse(source)
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_mineru_client_rejects_zip_path_traversal(tmp_path: Path) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task-1"})
        if request.url.path.endswith("/result"):
            return httpx.Response(
                200,
                content=_archive(unsafe_member="../sample_content_list_v2.json"),
            )
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "sample.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(MinerUContractError, match="unsafe"):
            await client.parse(source)
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_mineru_result_202_is_polled_without_resubmitting(tmp_path: Path) -> None:
    submit_calls = 0
    result_calls = 0

    async def handler(request: httpx.Request) -> httpx.Response:
        nonlocal submit_calls, result_calls
        if request.method == "POST":
            submit_calls += 1
            return httpx.Response(202, json={"task_id": "task-race"})
        if request.url.path == "/tasks/task-race":
            return httpx.Response(200, json={"status": "completed"})
        if request.url.path == "/tasks/task-race/result":
            result_calls += 1
            if result_calls == 1:
                return httpx.Response(202, json={"status": "processing"})
            return httpx.Response(200, content=_archive())
        raise AssertionError(request.url)

    source = tmp_path / "sample.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await client.parse(source)
    finally:
        await client.close()

    assert result.task_id == "task-race"
    assert submit_calls == 1
    assert result_calls == 2


@pytest.mark.asyncio
async def test_mineru_result_404_resubmits_but_409_fails(tmp_path: Path) -> None:
    submit_calls = 0

    async def recover_handler(request: httpx.Request) -> httpx.Response:
        nonlocal submit_calls
        if request.method == "POST":
            submit_calls += 1
            return httpx.Response(202, json={"task_id": f"task-{submit_calls}"})
        if request.url.path.endswith("/result"):
            if request.url.path == "/tasks/task-1/result":
                return httpx.Response(404, json={"detail": "Task not found"})
            return httpx.Response(200, content=_archive())
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "sample.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(recover_handler),
    )
    try:
        result = await client.parse(source)
    finally:
        await client.close()
    assert result.task_id == "task-2"
    assert submit_calls == 2

    async def failed_handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task-failed"})
        if request.url.path.endswith("/result"):
            return httpx.Response(409, json={"status": "failed"})
        return httpx.Response(200, json={"status": "completed"})

    failed_client = MinerUClient(
        base_url="http://mineru.test",
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(failed_handler),
    )
    try:
        with pytest.raises(MinerUError, match="failed status"):
            await failed_client.parse(source)
    finally:
        await failed_client.close()


@pytest.mark.asyncio
async def test_mineru_result_size_limit_is_enforced_while_streaming(
    tmp_path: Path,
) -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task-large"})
        if request.url.path.endswith("/result"):
            return httpx.Response(
                200,
                content=b"PK" + (b"x" * 2048),
                headers={"content-length": "2050", "content-type": "application/zip"},
            )
        return httpx.Response(200, json={"status": "completed"})

    source = tmp_path / "large-result.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    client = MinerUClient(
        base_url="http://mineru.test",
        max_archive_bytes=1024,
        poll_interval_seconds=0.001,
        transport=httpx.MockTransport(handler),
    )
    try:
        with pytest.raises(MinerUContractError, match="size limit"):
            await client.parse(source, original_filename=source.name)
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_mineru_probe_rejects_unhealthy_or_drifted_contract(
    tmp_path: Path,
) -> None:
    class FakeMapper:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    async def unhealthy(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/health"
        return httpx.Response(503, json={"status": "unhealthy"})

    unhealthy_client = MinerUClient(
        base_url="http://mineru.test",
        transport=httpx.MockTransport(unhealthy),
    )
    unhealthy_runner = MinerUShadowRunner(
        client=unhealthy_client,
        mapper=FakeMapper(),
        output_dir=tmp_path / "unhealthy",
    )
    try:
        with pytest.raises(httpx.HTTPStatusError):
            await unhealthy_runner.probe()
    finally:
        await unhealthy_runner.close()

    async def drifted(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/health"
        return httpx.Response(
            200,
            json={"status": "healthy", "version": "3.5.0", "protocol_version": 3},
        )

    drifted_client = MinerUClient(
        base_url="http://mineru.test",
        backend_version="3.4.4",
        transport=httpx.MockTransport(drifted),
    )
    drifted_runner = MinerUShadowRunner(
        client=drifted_client,
        mapper=FakeMapper(),
        output_dir=tmp_path / "drifted",
    )
    try:
        with pytest.raises(MinerUContractError, match="unsupported MinerU"):
            await drifted_runner.probe()
    finally:
        await drifted_runner.close()

    async def malformed(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/health"
        return httpx.Response(
            200,
            json={
                "status": "healthy",
                "version": "3.4.4",
                "protocol_version": "not-an-integer",
            },
        )

    malformed_client = MinerUClient(
        base_url="http://mineru.test",
        backend_version="3.4.4",
        transport=httpx.MockTransport(malformed),
    )
    malformed_runner = MinerUShadowRunner(
        client=malformed_client,
        mapper=FakeMapper(),
        output_dir=tmp_path / "malformed",
    )
    try:
        with pytest.raises(MinerUContractError, match="protocol=not-an-integer"):
            await malformed_runner.probe()
    finally:
        await malformed_runner.close()


def test_mineru_candidate_is_independent_and_replays_every_table_row(
    tmp_path: Path,
) -> None:
    payload = _payload()
    header = payload[0][2]["content"]["html"].split("</tr>", 1)[0] + "</tr>"
    rows = "".join(
        f"<tr><td>SKU-{index:03d}</td><td>Product {index}</td>"
        f"<td>{index}</td><td>pcs</td></tr>"
        for index in range(1, 401)
    )
    payload[0][2]["content"]["html"] = f"<table>{header}{rows}</table>"
    evidence = adapt_content_list_v2(
        payload,
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    plan = _plan(data_end=400)

    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="原始采购订单.pdf",
        evidence=evidence,
        plan=plan,
        document_subtype_hint="purchase_contract",
    )

    serialized = candidate.model_dump_json()
    assert "OLD-WRONG" not in serialized
    assert candidate.document_subtype == "purchase_contract"
    assert len(candidate.lines) == 400
    assert candidate.lines[0].product_code == "SKU-001"
    assert candidate.lines[-1].quantity == 400
    assert rejected == 0
    ref = candidate.field_meta["$.lines[399].quantity"].source_refs[0]
    assert ref.page == 1
    assert ref.bbox == [0.05, 0.25, 0.95, 0.72]
    assert ref.granularity == "table"


def test_mineru_candidate_rejects_reversed_explicit_party_role(tmp_path: Path) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    plan = _plan()
    plan.facts.append(
        MinerUFactPlan(
            target="header.seller",
            evidence_id="p1:b1",
            quote="甲方：广西桐曦电子科技有限公司",
            value="广西桐曦电子科技有限公司",
        )
    )
    source = tmp_path / "purchase-order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="采购订单.pdf",
        evidence=evidence,
        plan=plan,
    )

    assert candidate.header.seller is None
    assert rejected == 1
    assert any(
        issue.code == "MINERU_MAPPER_EVIDENCE_REJECTED"
        and issue.paths == ["$.header.seller"]
        for issue in candidate.validation_issues
    )


def test_mineru_table_mapping_must_cite_its_own_header_axis(tmp_path: Path) -> None:
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )
    plan = _plan()
    plan.tables[0].mappings[0] = MinerUAxisMapping(
        axis_index=0,
        field="product_code",
        header_evidence_id="p1:t0:r0:c1",
        header_quote="品名",
    )
    plan.tables[0].mappings.append(
        MinerUAxisMapping(
            axis_index=99,
            field="model",
            header_evidence_id="p1:t0:r0:c0",
            header_quote="物料号",
        )
    )
    source = tmp_path / "purchase-order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="采购订单.pdf",
        evidence=evidence,
        plan=plan,
    )

    assert rejected == 2
    assert all(line.product_code is None for line in candidate.lines)
    assert all(line.model is None for line in candidate.lines)


@pytest.mark.asyncio
async def test_shadow_runner_writes_candidate_without_copying_authoritative_facts(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=10,
        middle_json=_middle(),
    )

    class FakeClient:
        model_revision = REVISION

        async def parse(self, path, *, original_filename=None):
            return MinerUParseResult(
                evidence=evidence,
                task_id="mineru-task",
                member_name="sample_content_list_v2.json",
                content_list_v2=_payload(),
                middle_json=_middle(),
                elapsed_ms=10,
            )

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class FakeMapper:
        async def plan(self, evidence, **kwargs):
            return (
                _plan(),
                0.01,
                {
                    "requests": 1,
                    "repaired_mappings": 2,
                    "dropped_mappings": 1,
                    "dropped_tables": 1,
                    "dropped_facts": 3,
                    "empty_facts": 2,
                    "invalid_facts": 1,
                },
            )

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    authoritative = {
        "schema_version": "m1.document.v2",
        "source": {"sha256": "abc"},
        "document_type": "order",
        "document_subtype": "wrong",
        "header": {"order_number": "OLD-WRONG"},
        "lines": [],
        "field_meta": {},
    }
    runner = MinerUShadowRunner(
        client=FakeClient(),
        mapper=FakeMapper(),
        output_dir=tmp_path / "shadow",
    )

    summary = await runner.run(
        task_id="task-1",
        path=source,
        original_filename="order.pdf",
        file_type="pdf",
        authoritative=authoritative,
    )

    artifact = json.loads(
        (tmp_path / "shadow" / summary["artifact"]).read_text(encoding="utf-8")
    )
    assert summary["status"] == "completed"
    assert summary["candidate_isolation"] is True
    assert summary["mapper_repaired_mappings"] == 2
    assert summary["mapper_dropped_mappings"] == 1
    assert summary["mapper_dropped_tables"] == 1
    assert summary["mapper_initial_dropped_mappings"] == 1
    assert summary["mapper_initial_dropped_tables"] == 1
    assert summary["mapper_unresolved_dropped_mappings"] == 1
    assert summary["mapper_unresolved_dropped_tables"] == 1
    assert summary["mapper_dropped_facts"] == 3
    assert summary["mapper_empty_facts"] == 2
    assert summary["mapper_invalid_facts"] == 1
    assert "OLD-WRONG" not in json.dumps(artifact["candidate"], ensure_ascii=False)
    assert artifact["candidate"]["header"]["order_number"] == "PO-20260722-01"

    assert await runner.delete_artifact("task-1") is True
    assert not (tmp_path / "shadow" / summary["artifact"]).exists()
    assert await runner.delete_artifact("task-1") is False


@pytest.mark.asyncio
async def test_runner_exposes_inline_candidate_without_writing_shadow_artifact(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=10,
        middle_json=_middle(),
    )

    class FakeClient:
        model_revision = REVISION

        async def parse(self, path, *, original_filename=None):
            return MinerUParseResult(
                evidence=evidence,
                task_id="mineru-inline",
                member_name="sample_content_list_v2.json",
                content_list_v2=_payload(),
                middle_json=_middle(),
                elapsed_ms=10,
            )

        async def close(self):
            return None

    class FakeMapper:
        async def plan(self, evidence, **kwargs):
            return _plan(), 0.01, {"requests": 1}

        async def close(self):
            return None

    output = tmp_path / "shadow"
    runner = MinerUShadowRunner(
        client=FakeClient(),
        mapper=FakeMapper(),
        output_dir=output,
        authority_mode="guarded",
    )

    result = await runner.run_candidate(
        task_id="task-inline",
        path=source,
        original_filename="order.pdf",
        file_type="pdf",
        authoritative=_guarded_document(line_count=2).model_dump(mode="json"),
    )

    assert isinstance(result, MinerUCandidateRunResult)
    assert result.document.header.order_number == "PO-20260722-01"
    assert result.summary["status"] == "completed"
    assert result.summary["rejected_citations"] == 0
    assert not (output / "task-inline.json").exists()
    assert runner.status()["authority_mode"] == "guarded"
    await runner.close()


def test_guarded_authority_rejects_line_count_regression_like_test_cable() -> None:
    baseline = _guarded_document(line_count=10).model_dump(mode="json")
    candidate = _guarded_document(line_count=37)

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert decision.accepted is False
    assert "business_line_count_mismatch" in decision.reasons


def test_guarded_authority_requires_every_critical_value_to_keep_evidence() -> None:
    candidate = _guarded_document(line_count=1)
    candidate.field_meta["$.lines[0].quantity"] = FieldMetadata(
        source_refs=[SourceReference(page=1, part="mineru/unpositioned")]
    )
    baseline = _guarded_document(line_count=1).model_dump(mode="json")

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert decision.accepted is False
    assert decision.missing_source_paths == ("$.lines[0].quantity",)
    assert "missing_source_refs" in decision.reasons


def test_guarded_authority_preserves_nonempty_baseline_facts_exactly() -> None:
    baseline = _guarded_document(line_count=1).model_dump(mode="json")
    baseline["lines"][0]["remark"] = "baseline remark"
    baseline["totals"]["declared_quantity"] = 1
    candidate = _guarded_document(line_count=1, title="不同标题")
    candidate.lines[0].quantity = 99
    candidate.lines[0].remark = "changed remark"
    candidate.totals.declared_quantity = 2
    positioned = FieldMetadata(
        source_refs=[
            SourceReference(
                page=1,
                part="mineru/extended",
                bbox=[0, 0, 20, 10],
                coordinate_space="page_points",
            )
        ]
    )
    candidate.field_meta["$.lines[0].remark"] = positioned
    candidate.field_meta["$.totals.declared_quantity"] = positioned

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert decision.accepted is False
    assert decision.mismatched_baseline_paths == (
        "$.header.title",
        "$.lines[0].quantity",
        "$.lines[0].remark",
        "$.totals.declared_quantity",
    )
    assert "baseline_fact_mismatch" in decision.reasons


def test_guarded_authority_can_promote_unknown_baseline_to_complete_order() -> None:
    baseline = _guarded_document(line_count=1).model_dump(mode="json")
    baseline["document_type"] = "unknown"
    baseline["document_subtype"] = "unknown"
    candidate = _guarded_document(line_count=1)

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint="order",
        document_subtype_hint=None,
    )

    assert decision.accepted is True


def test_guarded_authority_rejects_unknown_baseline_without_order_hint() -> None:
    baseline = _guarded_document(line_count=1).model_dump(mode="json")
    baseline["document_type"] = "unknown"
    baseline["document_subtype"] = "unknown"

    decision = evaluate_mineru_authority(
        _guarded_document(line_count=1),
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint=None,
        document_subtype_hint=None,
    )

    assert decision.accepted is False
    assert "unsupported_authority_domain" in decision.reasons


def test_guarded_authority_explicit_subtype_hint_overrides_baseline_subtype() -> None:
    baseline = _guarded_document(line_count=1).model_dump(mode="json")
    candidate = _guarded_document(line_count=1)
    candidate.document_subtype = "purchase_contract"

    decision = evaluate_mineru_authority(
        candidate,
        _completed_candidate_summary(),
        baseline=baseline,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert decision.accepted is True


@pytest.mark.asyncio
async def test_shadow_schedule_is_nonblocking_bounded_and_completes_artifact(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=10,
        middle_json=_middle(),
    )
    release = asyncio.Event()

    class SlowClient:
        model_revision = REVISION

        async def parse(self, path, *, original_filename=None):
            await release.wait()
            return MinerUParseResult(
                evidence=evidence,
                task_id="mineru-task",
                member_name="sample_content_list_v2.json",
                content_list_v2=_payload(),
                middle_json=_middle(),
                elapsed_ms=10,
            )

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class FakeMapper:
        async def plan(self, evidence, **kwargs):
            return _plan(), 0.01, {"requests": 1}

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=SlowClient(),
        mapper=FakeMapper(),
        output_dir=tmp_path / "shadow",
        max_pending=1,
    )
    published: list[tuple[str, dict]] = []

    async def publish(task_id: str, summary: dict) -> None:
        published.append((task_id, summary))

    runner.set_completion_sink(publish)
    authoritative = {"source": {"sha256": "abc"}, "header": {}, "lines": []}

    queued = runner.schedule(
        task_id="task-queued",
        path=source,
        original_filename="order.pdf",
        file_type="pdf",
        authoritative=authoritative,
    )
    duplicate = runner.schedule(
        task_id="task-queued",
        path=source,
        original_filename="order.pdf",
        file_type="pdf",
        authoritative=authoritative,
    )
    full = runner.schedule(
        task_id="task-overflow",
        path=source,
        original_filename="order.pdf",
        file_type="pdf",
        authoritative=authoritative,
    )

    assert queued["status"] == "queued"
    assert duplicate["reason"] == "already_queued"
    assert full["reason"] == "queue_full"
    assert runner.status()["pending"] == 1
    release.set()
    for _ in range(100):
        if (tmp_path / "shadow" / "task-queued.json").is_file():
            break
        await asyncio.sleep(0.01)
    assert (tmp_path / "shadow" / "task-queued.json").is_file()
    for _ in range(100):
        if runner.status()["pending"] == 0:
            break
        await asyncio.sleep(0.01)
    assert runner.status()["pending"] == 0
    assert published[0][0] == "task-queued"
    assert published[0][1]["status"] == "completed"
    await runner.close()


@pytest.mark.asyncio
async def test_shadow_close_marks_interrupted_candidate_for_restart(
    tmp_path: Path,
) -> None:
    release = asyncio.Event()

    class SlowClient:
        async def parse(self, *_args, **_kwargs):
            await release.wait()

        async def close(self):
            return None

    class UnusedMapper:
        async def close(self):
            return None

    runner = MinerUShadowRunner(
        client=SlowClient(),
        mapper=UnusedMapper(),
        output_dir=tmp_path / "shadow",
    )
    published: list[tuple[str, dict]] = []

    async def publish(task_id: str, summary: dict) -> None:
        published.append((task_id, summary))

    runner.set_completion_sink(publish)
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    runner.schedule(
        task_id="task-restart",
        path=source,
        original_filename="input.pdf",
        file_type="pdf",
        authoritative={},
    )
    await asyncio.sleep(0)
    await runner.close()

    assert published == [
        (
            "task-restart",
            {
                "status": "queued",
                "reason": "shutdown_interrupted",
                "task_id": "task-restart",
                "candidate_isolation": True,
            },
        )
    ]


def test_mapper_evidence_payload_enforces_hard_limit_for_wide_tables() -> None:
    payload = _payload()
    columns = 80
    header = "".join(f"<th>Column-{index}</th>" for index in range(columns))
    rows = "".join(
        "<tr>"
        + "".join(
            f"<td>row-{row_index}-column-{column_index}-{'x' * 80}</td>"
            for column_index in range(columns)
        )
        + "</tr>"
        for row_index in range(60)
    )
    payload[0][2]["content"]["html"] = f"<table><tr>{header}</tr>{rows}</table>"
    evidence = adapt_content_list_v2(
        payload,
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=1,
        middle_json=_middle(),
    )

    bounded = mapper_evidence_payload(evidence, max_chars=4_000)

    serialized = json.dumps(
        bounded,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    assert len(serialized) <= 4_000
    assert bounded["truncated"]["content_reduced"] is True


@pytest.mark.asyncio
async def test_shadow_runner_skips_formats_without_a_normalization_route(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

    class UnusedMapper:
        async def close(self):
            return None

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedMapper(),
        output_dir=tmp_path / "shadow",
    )

    result = await runner.run(
        task_id="task-odt",
        path=tmp_path / "unsupported.odt",
        original_filename="unsupported.odt",
        file_type="odt",
        authoritative={},
    )

    assert result == {
        "status": "skipped",
        "reason": "unsupported_file_type",
        "file_type": "odt",
        "candidate_isolation": True,
    }


def test_shadow_artifact_retention_removes_stale_private_results(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        def status(self):
            return {}

    class UnusedMapper:
        def status(self):
            return {}

    output = tmp_path / "shadow"
    output.mkdir()
    stale = output / "stale.json"
    stale.write_text("{}", encoding="utf-8")
    old = time.time() - 120
    os.utime(stale, (old, old))
    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedMapper(),
        output_dir=output,
        artifact_retention_seconds=60,
    )

    current = runner._write_artifact("current", {"status": "completed"})

    assert current.is_file()
    assert not stale.exists()
    assert runner.status()["pruned_artifacts"] == 1


@pytest.mark.asyncio
async def test_shadow_delete_waits_for_writer_and_removes_temporary_files(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class UnusedMapper(UnusedClient):
        pass

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedMapper(),
        output_dir=tmp_path / "shadow",
    )
    started = threading.Event()
    release = threading.Event()
    original_writer = runner._write_artifact

    def blocked_writer(task_id: str, payload: dict) -> Path:
        started.set()
        release.wait(timeout=5)
        return original_writer(task_id, payload)

    runner._write_artifact = blocked_writer
    writer = asyncio.create_task(
        runner._write_artifact_async("task-delete-race", {"secret": "value"})
    )
    assert await asyncio.to_thread(started.wait, 2)
    deletion = asyncio.create_task(runner.delete_artifact("task-delete-race"))
    await asyncio.sleep(0)
    assert not deletion.done()
    release.set()
    await deletion
    await asyncio.gather(writer, return_exceptions=True)
    assert not (tmp_path / "shadow" / "task-delete-race.json").exists()
    assert not (tmp_path / "shadow" / "task-delete-race.json.tmp").exists()
    await runner.close()


@pytest.mark.asyncio
async def test_shadow_completion_publish_retries_and_exposes_failures(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=tmp_path / "shadow",
    )
    calls = 0

    async def flaky_publish(_task_id: str, _summary: dict) -> None:
        nonlocal calls
        calls += 1
        if calls == 1:
            raise RuntimeError("temporary store failure")

    runner.set_completion_sink(flaky_publish)
    await runner._publish_completion("task-retry", {"status": "completed"})
    status = runner.status()
    assert calls == 2
    assert status["completion_pending"] == 0
    assert status["completion_successes"] == 1
    assert status["completion_failures"] == 1
    assert not runner._completion_path("task-retry").exists()
    await runner.close()


@pytest.mark.asyncio
async def test_shadow_completion_failure_is_retained_for_recovery(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=tmp_path / "shadow",
    )

    async def failed_publish(_task_id: str, _summary: dict) -> None:
        raise RuntimeError("store unavailable")

    runner.set_completion_sink(failed_publish)
    await runner._publish_completion("task-pending", {"status": "completed"})
    status = runner.status()
    assert status["completion_pending"] == 1
    assert status["completion_terminal_failures"] == 1
    assert runner._completion_path("task-pending").is_file()
    await runner.close()


def test_shadow_queue_rejects_an_oversized_authoritative_snapshot(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=tmp_path / "shadow",
        max_queued_bytes=1024 * 1024,
    )
    result = runner.schedule(
        task_id="task-too-large",
        path=tmp_path / "input.pdf",
        original_filename="input.pdf",
        file_type="pdf",
        authoritative={"lines": [{"name_raw": "x" * (2 * 1024 * 1024)}]},
    )
    assert result["status"] == "skipped"
    assert result["reason"] == "authoritative_snapshot_too_large"


@pytest.mark.asyncio
async def test_shadow_probe_checks_mapper_endpoint_when_available() -> None:
    class Client:
        backend_version = "3.4.4"

        async def probe(self):
            return {"status": "healthy", "version": "3.4.4", "protocol_version": 2}

        def status(self):
            return {"ready": True}

    class Mapper:
        async def probe(self):
            return {"ready": False, "status": "unavailable"}

        def status(self):
            return {"ready": False}

    runner = MinerUShadowRunner(client=Client(), mapper=Mapper(), output_dir=Path("."))
    with pytest.raises(RuntimeError, match="mapper"):
        await runner.probe()
    assert runner.status()["parser_ready"] is True
    assert runner.status()["mapper_ready"] is False


@pytest.mark.asyncio
async def test_shadow_queue_spools_authority_and_recovers_after_restart(
    tmp_path: Path,
) -> None:
    source = tmp_path / "restart.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    evidence = adapt_content_list_v2(
        _payload(),
        backend="vlm-engine",
        backend_version="3.4.4",
        model_revision=REVISION,
        elapsed_ms=10,
        middle_json=_middle(),
    )
    release = asyncio.Event()

    class InterruptedClient:
        model_revision = REVISION

        async def parse(self, *_args, **_kwargs):
            await release.wait()

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class WorkingClient(InterruptedClient):
        async def parse(self, *_args, **_kwargs):
            return MinerUParseResult(
                evidence=evidence,
                task_id="mineru-recovered",
                member_name="sample_content_list_v2.json",
                content_list_v2=_payload(),
                middle_json=_middle(),
                elapsed_ms=10,
            )

    class FakeMapper:
        async def plan(self, _evidence, **_kwargs):
            return _plan(), 0.01, {"requests": 1}

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    output = tmp_path / "shadow"
    first = MinerUShadowRunner(
        client=InterruptedClient(),
        mapper=FakeMapper(),
        output_dir=output,
    )
    published: list[tuple[str, dict]] = []

    async def publish(task_id: str, summary: dict) -> None:
        published.append((task_id, summary))

    first.set_completion_sink(publish)
    authoritative = {"source": {"sha256": "abc"}, "header": {}, "lines": []}
    queued = first.schedule(
        task_id="task-recover-job",
        path=source,
        original_filename=source.name,
        file_type="pdf",
        authoritative=authoritative,
    )
    job = first._scheduled_jobs["task-recover-job"]
    assert not hasattr(job, "authoritative")
    assert job.snapshot_path.is_file()
    authoritative["header"]["order_number"] = "MUTATED-AFTER-SCHEDULE"
    persisted = json.loads(job.snapshot_path.read_text(encoding="utf-8"))
    assert persisted["authoritative"]["header"] == {}
    assert queued["pending_bytes"] == job.snapshot_bytes

    await asyncio.sleep(0)
    await first.close()
    assert job.snapshot_path.is_file()
    assert published[-1][1]["reason"] == "shutdown_interrupted"

    second = MinerUShadowRunner(
        client=WorkingClient(),
        mapper=FakeMapper(),
        output_dir=output,
    )
    second.set_completion_sink(publish)
    for _ in range(200):
        if (
            output / "task-recover-job.json"
        ).is_file() and not job.snapshot_path.exists():
            break
        await asyncio.sleep(0.01)
    assert (output / "task-recover-job.json").is_file()
    assert not job.snapshot_path.exists()
    assert any(item[1].get("status") == "completed" for item in published)
    await second.close()


@pytest.mark.asyncio
async def test_shadow_completion_spool_recovers_in_a_new_runner(
    tmp_path: Path,
) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    output = tmp_path / "shadow"
    first = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=output,
    )

    async def fail(_task_id: str, _summary: dict) -> None:
        raise RuntimeError("temporary store outage")

    first.set_completion_sink(fail)
    await first._publish_completion("task-recover-completion", {"status": "completed"})
    spool = first._completion_path("task-recover-completion")
    assert spool.is_file()
    await first.close()

    recovered: list[tuple[str, dict]] = []
    second = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=output,
    )

    async def publish(task_id: str, summary: dict) -> None:
        recovered.append((task_id, summary))

    second.set_completion_sink(publish)
    for _ in range(100):
        if recovered and not spool.exists():
            break
        await asyncio.sleep(0.01)
    assert recovered == [("task-recover-completion", {"status": "completed"})]
    assert not spool.exists()
    await second.close()


@pytest.mark.asyncio
async def test_shadow_delete_fences_multiple_inflight_writers(tmp_path: Path) -> None:
    class UnusedClient:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=UnusedClient(),
        mapper=UnusedClient(),
        output_dir=tmp_path / "shadow",
    )
    started = threading.Barrier(3)
    release = threading.Event()
    original_writer = runner._write_artifact

    def blocked_writer(task_id: str, payload: dict) -> Path:
        started.wait(timeout=5)
        release.wait(timeout=5)
        return original_writer(task_id, payload)

    runner._write_artifact = blocked_writer
    writers = [
        asyncio.create_task(runner._write_artifact_async("task-multi", {"n": index}))
        for index in range(2)
    ]
    await asyncio.to_thread(started.wait, 5)
    deletion = asyncio.create_task(runner.delete_artifact("task-multi"))
    await asyncio.sleep(0)
    assert not deletion.done()
    release.set()
    await deletion
    await asyncio.gather(*writers, return_exceptions=True)
    assert not (tmp_path / "shadow" / "task-multi.json").exists()
    assert runner._artifact_writers == {}
    await runner.close()


@pytest.mark.asyncio
async def test_shadow_document_failure_does_not_poison_infrastructure_readiness(
    tmp_path: Path,
) -> None:
    class FailingClient:
        backend_version = "3.4.4"
        model_revision = REVISION

        async def probe(self):
            return {
                "status": "healthy",
                "version": "3.4.4",
                "protocol_version": 2,
            }

        async def parse(self, *_args, **_kwargs):
            raise ValueError("document-specific parse failure")

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class ReadyMapper:
        async def probe(self):
            return {"ready": True}

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=FailingClient(),
        mapper=ReadyMapper(),
        output_dir=tmp_path / "shadow",
    )
    await runner.probe()
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    with pytest.raises(ValueError, match="document-specific"):
        await runner.run(
            task_id="task-document-failure",
            path=source,
            original_filename="input.pdf",
            file_type="pdf",
            authoritative={},
        )
    status = runner.status()
    assert status["ready"] is True
    assert status["parser_ready"] is True
    assert status["mapper_ready"] is True
    assert status["document_failures"] == 1
    assert status["last_document_error_type"] == "ValueError"
    await runner.close()


@pytest.mark.asyncio
async def test_shadow_persistence_failure_keeps_job_snapshot_for_recovery(
    tmp_path: Path,
) -> None:
    """A failed completion write must not acknowledge/delete the durable job."""

    class FailingClient:
        async def parse(self, *_args, **_kwargs):
            raise ValueError("document parse failed")

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class UnusedMapper:
        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    runner = MinerUShadowRunner(
        client=FailingClient(),
        mapper=UnusedMapper(),
        output_dir=tmp_path / "shadow",
    )

    def fail_persistence(*_args, **_kwargs):
        raise OSError("completion spool unavailable")

    runner._persist_completion = fail_persistence

    async def publish(_task_id: str, _summary: dict) -> None:
        return None

    runner.set_completion_sink(publish)
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    queued = runner.schedule(
        task_id="task-persistence-failure",
        path=source,
        original_filename="input.pdf",
        file_type="pdf",
        authoritative={"source": {"sha256": "abc"}},
    )
    assert queued["status"] == "queued"
    job = runner._scheduled_jobs["task-persistence-failure"]
    await runner._background_tasks["task-persistence-failure"]

    assert job.snapshot_path.is_file()
    assert runner.status()["completion_terminal_failures"] == 1
    await runner.close()
    assert job.snapshot_path.is_file()
