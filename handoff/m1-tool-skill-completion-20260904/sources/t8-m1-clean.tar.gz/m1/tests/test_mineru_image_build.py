from pathlib import Path

import yaml


PYLATEXENC_SDIST_SHA256 = (
    "3dd8fd84eb46dc30bee1e23eaab8d8fb5a7f507347b23e5f38ad9675c84f40d3"
)
SETUPTOOLS_WHEEL_SHA256 = (
    "29b23c360f22f414dc7336bb39178cc7bcbf6021ed2733cde173f09dba19abb3"
)


def test_mineru_build_pins_and_reproduces_source_only_dependency() -> None:
    repository = Path(__file__).resolve().parents[2]
    compose = yaml.safe_load(
        (repository / "m1/deploy/compose.build.yml").read_text(encoding="utf-8")
    )
    build_args = compose["services"]["m1-mineru"]["build"]["args"]

    assert build_args["PYLATEXENC_VERSION"] == "2.10"
    assert build_args["PYLATEXENC_SDIST_SHA256"] == PYLATEXENC_SDIST_SHA256
    assert build_args["PYLATEXENC_BUILD_BACKEND_VERSION"] == "83.0.0"
    assert (
        build_args["PYLATEXENC_BUILD_BACKEND_SHA256"]
        == SETUPTOOLS_WHEEL_SHA256
    )
    assert build_args["PYLATEXENC_SOURCE_DATE_EPOCH"] == "1617695767"
    assert build_args["PYPI_INDEX_URL"] == (
        "${MINERU_PYPI_INDEX_URL:-https://pypi.tuna.tsinghua.edu.cn/simple}"
    )

    dockerfile = (repository / "m1/docker/mineru/Dockerfile").read_text(
        encoding="utf-8"
    )
    assert "AS pylatexenc-wheel-builder" in dockerfile
    assert "SOURCE_DATE_EPOCH=\"${PYLATEXENC_SOURCE_DATE_EPOCH}\"" in dockerfile
    assert "--no-build-isolation" in dockerfile
    assert "\n    cmp " in dockerfile
    assert "pylatexenc @ file:///tmp/mineru-wheels/" in dockerfile
    assert "'transformers==4.57.6'" in dockerfile
    assert "mineru[vlm,vllm] @ file:///tmp/mineru-wheels/" in dockerfile
    assert "com.yunpai.mineru.transformers-version=\"4.57.6\"" in dockerfile
    assert "version('transformers') == '4.57.6'" in dockerfile
    assert "--only-binary=:all:" in dockerfile
    initial_cleanup = dockerfile.index(
        "python3 -m pip --isolated uninstall --yes \\\n        PyGObject"
    )
    lmcache_cleanup = dockerfile.index("PyGObject lmcache", initial_cleanup)
    dependency_check = dockerfile.index("python3 -m pip --isolated check")
    headless_cleanup = dockerfile.index(
        "python3 -m pip --isolated uninstall --yes \\"
        "\n        opencv-python-headless",
        dependency_check,
    )
    provider_restore = dockerfile.index(
        '"opencv-python==${opencv_python_version}"',
        headless_cleanup,
    )
    assert (
        initial_cleanup
        < lmcache_cleanup
        < dependency_check
        < headless_cleanup
        < provider_restore
    )
    assert "/root/.cache/pip" in dockerfile
    assert "providers == ['opencv-python']" in dockerfile

    constraints = (
        repository / "m1/docker/mineru/vllm-constraints.txt"
    ).read_text(encoding="utf-8")
    assert "transformers==4.57.6" in constraints


def test_mineru_runtime_uses_non_root_user_and_tmp_backed_caches() -> None:
    repository = Path(__file__).resolve().parents[2]
    dockerfile = (repository / "m1/docker/mineru/Dockerfile").read_text(
        encoding="utf-8"
    )

    assert "groupadd --gid 10001 mineru" in dockerfile
    assert "useradd --uid 10001 --gid 10001" in dockerfile
    assert "chown -R root:root /opt/mineru" in dockerfile
    assert "chmod -R a=rX /opt/mineru" in dockerfile
    assert "USER 10001:10001" in dockerfile
    assert dockerfile.index("USER 10001:10001") > dockerfile.index(
        "mineru-api --help >/dev/null"
    )
    for value in (
        "HOME=/tmp/mineru-home",
        "XDG_CACHE_HOME=/tmp/mineru-cache",
        "XDG_CONFIG_HOME=/tmp/mineru-config",
        "HF_HOME=/tmp/mineru-cache/huggingface",
        "HF_HUB_CACHE=/tmp/mineru-cache/huggingface/hub",
        "VLLM_CACHE_ROOT=/tmp/mineru-cache/vllm",
        "VLLM_CONFIG_ROOT=/tmp/mineru-config/vllm",
        "TRITON_CACHE_DIR=/tmp/mineru-cache/triton",
        "TORCHINDUCTOR_CACHE_DIR=/tmp/mineru-cache/torchinductor",
        "TMPDIR=/tmp",
    ):
        assert value in dockerfile


def test_mineru_build_uses_the_reachable_hash_verified_model_mirror() -> None:
    repository = Path(__file__).resolve().parents[2]
    dockerfile = (repository / "m1/docker/mineru/Dockerfile").read_text(
        encoding="utf-8"
    )
    build_compose = (repository / "m1/deploy/compose.build.yml").read_text(
        encoding="utf-8"
    )
    environment = (repository / "m1/.env.example").read_text(encoding="utf-8")

    assert "ARG HF_ENDPOINT=https://hf-mirror.com" in dockerfile
    assert "MINERU_HF_ENDPOINT:-https://hf-mirror.com" in build_compose
    assert "MINERU_HF_ENDPOINT=https://hf-mirror.com" in environment
