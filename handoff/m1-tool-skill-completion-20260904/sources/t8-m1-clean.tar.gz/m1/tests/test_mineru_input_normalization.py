from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from m1.documents.envelope import CellValue, DocumentEnvelope, SheetEnvelope
from m1.documents.models import (
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    SourceReference,
)
from m1.documents.parsing.evidence import DocumentEvidence
from m1.documents.parsing.mineru import MinerUParseResult
from m1.documents.parsing.mineru_candidate import (
    MinerUBusinessPlan,
    MinerUCandidateResult,
)
from m1.documents.parsing.mineru_input import (
    MinerUCADRendererRequired,
    MinerUInputContractError,
    MinerUInputNormalizer,
)
from m1.documents.parsing.mineru_instructor_service import (
    MinerUInstructorServiceResult,
)
from m1.documents.parsing.mineru_shadow import (
    MinerUShadowRunner,
    _bind_spreadsheet_source_refs,
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _minimal_ooxml(path: Path, member: str) -> None:
    with ZipFile(path, "w", ZIP_DEFLATED) as package:
        package.writestr(
            "[Content_Types].xml",
            "<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'/>",
        )
        package.writestr(member, "<root />")


@pytest.mark.parametrize(
    ("filename", "file_type", "payload", "member"),
    [
        ("source.pdf", "pdf", b"%PDF-1.4\n%%EOF\n", None),
        ("source.png", "image", b"\x89PNG\r\n\x1a\nfixture", None),
        ("source.docx", "docx", None, "word/document.xml"),
        ("source.pptx", "pptx", None, "ppt/presentation.xml"),
    ],
)
def test_native_mineru_inputs_are_identity_mapped(
    tmp_path: Path,
    filename: str,
    file_type: str,
    payload: bytes | None,
    member: str | None,
) -> None:
    source = tmp_path / filename
    if member is not None:
        _minimal_ooxml(source, member)
    else:
        source.write_bytes(payload or b"")

    with MinerUInputNormalizer().prepare(
        source,
        original_filename=f"客户原名-{filename}",
        file_type=file_type,
    ) as prepared:
        assert prepared.ready is True
        assert prepared.path == source
        assert prepared.source_sha256 == _sha256(source)
        assert prepared.metadata["mapping"] == {
            "strategy": "identity",
            "complete": True,
        }
        assert prepared.metadata["normalized"]["conversion"] == "native"
        assert prepared.upload_filename is not None
        assert prepared.upload_filename.endswith(source.suffix)


def test_native_input_preserves_original_unicode_filename(tmp_path: Path) -> None:
    source = tmp_path / "source.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    original = "nested\\HDMI2.1 短窄长距 （禾橙黄）-规格书2025-11-21.pdf"

    with MinerUInputNormalizer().prepare(
        source,
        original_filename=original,
        file_type="pdf",
    ) as prepared:
        expected = "HDMI2.1 短窄长距 （禾橙黄）-规格书2025-11-21.pdf"
        assert prepared.original_filename == expected
        assert prepared.metadata["source"]["original_filename"] == expected
        assert prepared.upload_filename != expected


def test_xlsx_is_rendered_to_pdf_with_original_sheet_range_mapping(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "native.xlsx"
    workbook = Workbook()
    workbook.active.title = "库存"
    workbook.active["A1"] = "模号"
    workbook.active["B1"] = "数量"
    workbook.active["A2"] = "M-001"
    workbook.active["B2"] = 2
    workbook.save(source)
    workbook.close()
    before = source.read_bytes()

    with MinerUInputNormalizer().prepare(
        source, original_filename="原生工作簿.xlsx", file_type="xlsx"
    ) as prepared:
        assert prepared.path is not None
        assert prepared.path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "原生工作簿.pdf"
        assert prepared.metadata["normalized"]["conversion"] == "xlsx_to_pdf"
        assert prepared.metadata["normalized"]["sha256"] != _sha256(source)
        mapping = prepared.metadata["spreadsheet_mapping"]
        assert mapping["rendered_page_count"] >= 1
        assert mapping["rendered_pages"][0]["sheet"] == "库存"
        assert mapping["rendered_pages"][0]["range"] == "A1:B2"
    assert source.read_bytes() == before


def test_xlsx_with_native_evidence_skips_bounded_pdf_rendering(tmp_path: Path) -> None:
    from openpyxl import Workbook

    source = tmp_path / "large-native.xlsx"
    workbook = Workbook()
    for row in range(1, 82):
        workbook.active.cell(row=row, column=1, value=f"ROW-{row}")
    workbook.save(source)
    workbook.close()
    before = source.read_bytes()

    normalizer = MinerUInputNormalizer(max_html_pages=1)
    with normalizer.prepare(
        source,
        original_filename="large-native.xlsx",
        file_type="xlsx",
        native_evidence_available=True,
    ) as prepared:
        assert prepared.path == source
        assert prepared.metadata["normalized"]["conversion"] == (
            "native_evidence_identity"
        )
        assert prepared.metadata["mapping"] == {
            "strategy": "identity",
            "complete": True,
            "authority": "native_document_evidence",
        }
    assert source.read_bytes() == before


def test_csv_is_rendered_to_pdf_with_identity_cell_map_and_literal_formulas(
    tmp_path: Path,
) -> None:
    import fitz

    source = tmp_path / "input.csv"
    source.write_text(
        "订单号,数量,备注\nSO-1,2,正常\nSO-2,3,=HYPERLINK(\"http://invalid\")\n",
        encoding="utf-8",
    )
    normalized_path: Path
    with MinerUInputNormalizer().prepare(
        source,
        original_filename="客户订单.csv",
        file_type="csv",
    ) as prepared:
        assert prepared.ready is True
        assert prepared.path is not None
        normalized_path = prepared.path
        assert normalized_path.is_file()
        assert normalized_path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "客户订单.pdf"
        assert prepared.source_sha256 == _sha256(source)
        mapping = prepared.metadata["spreadsheet_mapping"]
        assert mapping["mapping_complete"] is True
        assert mapping["source_sha256"] == _sha256(source)
        assert mapping["sheet_count"] == 1
        assert mapping["sheets"][0]["cell_mapping"] == {
            "strategy": "identity_a1",
            "source_coordinate_system": "csv_1_based_row_column",
            "normalized_coordinate_system": "pdf_page_range",
            "complete": True,
        }
        with fitz.open(normalized_path) as rendered:
            content = "\n".join(page.get_text() for page in rendered)
        assert "SO-1" in content
        assert "HYPERLINK" in content
    assert not normalized_path.exists()


def test_xlsm_is_rendered_to_pdf_and_keeps_sheet_mapping(
    tmp_path: Path,
) -> None:
    import fitz
    from openpyxl import Workbook

    xlsx = tmp_path / "seed.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "报价明细"
    sheet["A1"] = "物料号"
    sheet["B1"] = "数量"
    sheet["A2"] = "P-100"
    sheet["B2"] = "=1+1"
    workbook.save(xlsx)
    workbook.close()

    source = tmp_path / "报价.xlsm"
    with ZipFile(xlsx) as original, ZipFile(source, "w", ZIP_DEFLATED) as converted:
        for item in original.infolist():
            content = original.read(item.filename)
            if item.filename == "[Content_Types].xml":
                content = content.replace(
                    b"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
                    b"application/vnd.ms-excel.sheet.macroEnabled.main+xml",
                )
            converted.writestr(item, content)

    with MinerUInputNormalizer().prepare(
        source,
        original_filename="报价.xlsm",
        file_type="xlsm",
    ) as prepared:
        assert prepared.path is not None
        assert prepared.path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "报价.pdf"
        mapping = prepared.metadata["spreadsheet_mapping"]
        assert mapping["source_kind"] == "xlsm"
        assert mapping["sheets"][0]["source_sheet"] == "报价明细"
        with fitz.open(prepared.path) as rendered:
            content = "\n".join(page.get_text() for page in rendered)
        assert "=1+1" in content


def test_xls_conversion_uses_lossless_envelope_and_preserves_original_hash(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import fitz

    source = tmp_path / "legacy.xls"
    source.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1fixture")
    sheet = SheetEnvelope(name="库存")
    sheet.cells[(1, 1)] = CellValue(
        sheet="库存", coordinate="A1", row=1, column=1, value="模号"
    )
    sheet.cells[(2, 1)] = CellValue(
        sheet="库存", coordinate="A2", row=2, column=1, value="M-001"
    )
    sheet.max_row = 2
    sheet.max_column = 1
    envelope = DocumentEnvelope(
        path=source,
        original_filename="库存.xls",
        display_filename="库存.xls",
        sha256=_sha256(source),
        mime_type="application/vnd.ms-excel",
        file_kind="xls",
        sheets=[sheet],
    )
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_input.parse_spreadsheet_envelope",
        lambda *_args, **_kwargs: envelope,
    )

    with MinerUInputNormalizer().prepare(
        source, original_filename="库存.xls", file_type="xls"
    ) as prepared:
        assert prepared.path is not None
        assert prepared.path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "库存.pdf"
        assert prepared.metadata["source"]["sha256"] == _sha256(source)
        assert prepared.metadata["normalized"]["sha256"] != _sha256(source)
        with fitz.open(prepared.path) as rendered:
            content = "\n".join(page.get_text() for page in rendered)
        assert "M-001" in content


def test_html_is_sanitized_and_rendered_to_pdf_without_external_resources(
    tmp_path: Path,
) -> None:
    source = tmp_path / "采购函.html"
    source.write_text(
        "<!doctype html><html><body><h1>采购函</h1>"
        "<script>window.bad = true</script>"
        "<img src='https://invalid.example/secret.png'>"
        "<table><tr><th>物料</th><th>数量</th></tr>"
        "<tr><td>P-1</td><td>5</td></tr></table></body></html>",
        encoding="utf-8",
    )
    rendered_path: Path
    with MinerUInputNormalizer().prepare(
        source, original_filename="采购函.html", file_type="html"
    ) as prepared:
        assert prepared.path is not None
        rendered_path = prepared.path
        assert rendered_path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "采购函.pdf"
        evidence = prepared.metadata["html_evidence"]
        assert evidence["external_resources_enabled"] is False
        assert evidence["script_execution_enabled"] is False
        assert evidence["dropped_tag_count"] >= 2
        assert evidence["rendered_page_count"] >= 1
    assert not rendered_path.exists()


def test_archive_returns_terminal_members_for_recursive_ingestion(
    tmp_path: Path,
) -> None:
    source = tmp_path / "batch.zip"
    with ZipFile(source, "w", ZIP_DEFLATED) as archive:
        archive.writestr("一组/order.csv", "订单号,数量\nSO-1,2\n")
        archive.writestr("drawing.pdf", b"%PDF-1.4\n%%EOF\n")

    child_paths: tuple[Path, ...]
    with MinerUInputNormalizer().prepare(
        source, original_filename="业务包.zip", file_type="zip"
    ) as prepared:
        assert prepared.action == "recurse"
        assert prepared.ready is False
        assert prepared.path is None
        assert len(prepared.recursive_members) == 2
        child_paths = tuple(member.path for member in prepared.recursive_members)
        assert all(path.is_file() for path in child_paths)
        metadata = prepared.metadata["archive"]["recursive_members"]
        assert {item["file_type"] for item in metadata} == {"csv", "pdf"}
        assert all(len(item["sha256"]) == 64 for item in metadata)
    assert all(not path.exists() for path in child_paths)


def test_cad_without_renderer_fails_closed_with_explicit_contract(
    tmp_path: Path,
) -> None:
    source = tmp_path / "drawing.dxf"
    source.write_text("0\nSECTION\n0\nEOF\n", encoding="ascii")
    normalizer = MinerUInputNormalizer(cad_renderer=None)

    with pytest.raises(
        MinerUCADRendererRequired, match="MINERU_CAD_RENDERER_REQUIRED"
    ):
        normalizer.prepare(source, file_type="dxf")


def test_default_cad_renderer_produces_pdf_and_geometry_sidecar(
    tmp_path: Path,
) -> None:
    import ezdxf

    source = tmp_path / "drawing.dxf"
    document = ezdxf.new()
    modelspace = document.modelspace()
    modelspace.add_line((0, 0), (100, 50))
    modelspace.add_text("PART-100", dxfattribs={"height": 5}).set_placement((5, 5))
    document.saveas(source)

    with MinerUInputNormalizer().prepare(
        source, original_filename="零件图.dxf", file_type="dxf"
    ) as prepared:
        assert prepared.path is not None
        assert prepared.path.read_bytes().startswith(b"%PDF-")
        assert prepared.upload_filename == "零件图.pdf"
        renderer = prepared.metadata["cad_renderer"]
        assert renderer["contract"] == "m1.mineru-cad-renderer.v1"
        assert renderer["sidecar"]["geometry_summary_sha256"]
        assert "PART-100" in renderer["sidecar"]["geometry_summary"]


def test_rendered_spreadsheet_refs_bind_to_original_sheet_range() -> None:
    document = DocumentRecord(
        source=DocumentSource(original_filename="模号.xlsx", sha256="fixture"),
        field_meta={
            "$.header.title": FieldMetadata(
                source_refs=[SourceReference(page=2, part="mineru/table:1")]
            )
        },
    )

    bound = _bind_spreadsheet_source_refs(
        document,
        {
            "spreadsheet_mapping": {
                "rendered_pages": [
                    {
                        "page_start": 1,
                        "page_end": 1,
                        "sheet": "封面",
                        "range": "A1:C10",
                    },
                    {
                        "page_start": 2,
                        "page_end": 3,
                        "sheet": "模号明细",
                        "range": "A11:L50",
                    },
                ]
            }
        },
    )

    reference = bound.field_meta["$.header.title"].source_refs[0]
    assert reference.sheet == "模号明细"
    assert reference.range == "A11:L50"
    assert reference.model_extra["normalized_from"] == "spreadsheet_pdf"


@dataclass
class _CapturedClient:
    fail: bool = False
    timeout_seconds: float = 10.0
    backend_version: str = "3.4.4"
    model_revision: str = "fixture"
    submitted_path: Path | None = None
    submitted_filename: str | None = None
    submitted_bytes: bytes = b""

    async def parse(
        self, path: str | Path, *, original_filename: str | None = None
    ) -> MinerUParseResult:
        self.submitted_path = Path(path)
        self.submitted_filename = original_filename
        self.submitted_bytes = self.submitted_path.read_bytes()
        if self.fail:
            raise TimeoutError("sidecar unavailable")
        return MinerUParseResult(
            evidence=DocumentEvidence(backend="mineru:fixture"),
            task_id="mineru-fixture",
            member_name="fixture_content_list_v2.json",
            content_list_v2=[],
            middle_json={"_version_name": "3.4.4", "_backend": "vlm"},
            elapsed_ms=1.0,
        )

    async def close(self) -> None:
        return None

    async def probe(self) -> dict[str, object]:
        if self.fail:
            raise TimeoutError("sidecar unavailable")
        return {
            "status": "healthy",
            "version": self.backend_version,
            "protocol_version": 2,
        }

    def status(self) -> dict[str, object]:
        return {"ready": not self.fail}


class _UnusedMapper:
    async def close(self) -> None:
        return None

    def status(self) -> dict[str, object]:
        return {"ready": True}


class _CapturedInstructorService:
    total_timeout_seconds = 10.0

    def __init__(self, client: _CapturedClient) -> None:
        self.client = client

    async def run(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ) -> MinerUInstructorServiceResult:
        source = Path(path)
        with MinerUInputNormalizer().prepare(
            source,
            original_filename=original_filename,
        ) as prepared:
            if not prepared.ready or prepared.path is None:
                raise MinerUInputContractError("fixture input is not ready")
            parsed = await self.client.parse(
                prepared.path,
                original_filename=prepared.upload_filename,
            )
            parsed.evidence.raw["input_normalization"] = prepared.metadata
            mapped = await _mapped_candidate(
                path=source,
                original_filename=original_filename,
                evidence=parsed.evidence,
            )
            return MinerUInstructorServiceResult(
                document=mapped.document,
                summary={"status": "completed", "mineru_task_id": parsed.task_id},
                payload={"input_normalization": prepared.metadata},
            )

    async def close(self) -> None:
        return None

    def status(self) -> dict[str, object]:
        return {"ready": not self.client.fail}


async def _mapped_candidate(
    *,
    path: str | Path,
    original_filename: str | None,
    evidence: DocumentEvidence,
    **_kwargs: object,
) -> MinerUCandidateResult:
    source = Path(path)
    assert evidence.raw["input_normalization"]["source"]["sha256"] == _sha256(
        source
    )
    return MinerUCandidateResult(
        document=DocumentRecord(
            source=DocumentSource(
                original_filename=original_filename or source.name,
                sha256=_sha256(source),
            )
        ),
        plan=MinerUBusinessPlan(),
        mapper_duration_seconds=0.001,
        mapper_usage={"requests": 1},
        rejected_citations=0,
    )


@pytest.mark.asyncio
async def test_runner_submits_normalized_name_but_keeps_original_source_identity(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "订单.csv"
    source.write_text("订单号,数量\nSO-100,2\n", encoding="utf-8")
    client = _CapturedClient()
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_shadow.map_mineru_candidate",
        _mapped_candidate,
    )
    runner = MinerUShadowRunner(
        client=client,
        instructor_service=_CapturedInstructorService(client),
        output_dir=tmp_path / "shadow",
        authority_mode="full",
    )
    runner._parser_ready = True
    runner._mapper_ready = True

    result = await runner.run_candidate(
        task_id="task-csv",
        path=source,
        original_filename="客户原始订单.csv",
        file_type="csv",
        authoritative={},
    )

    assert client.submitted_filename == "客户原始订单.pdf"
    assert client.submitted_bytes.startswith(b"%PDF-")
    assert client.submitted_path is not None and not client.submitted_path.exists()
    assert result.document.source.original_filename == "客户原始订单.csv"
    assert result.document.source.sha256 == _sha256(source)
    assert result.summary["input_normalization"]["normalized"][
        "conversion"
    ] == "csv_to_pdf"
    assert runner.status()["ready"] is True
    await runner.close()


@pytest.mark.asyncio
async def test_full_runner_readiness_tracks_system_failures_but_not_bad_input(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "订单.csv"
    source.write_text("订单号,数量\nSO-100,2\n", encoding="utf-8")
    client = _CapturedClient(fail=True)
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_shadow.map_mineru_candidate",
        _mapped_candidate,
    )
    runner = MinerUShadowRunner(
        client=client,
        instructor_service=_CapturedInstructorService(client),
        output_dir=tmp_path / "shadow",
        authority_mode="full",
        document_circuit_failures=3,
    )
    runner._parser_ready = True
    runner._mapper_ready = True

    with pytest.raises(TimeoutError):
        await runner.run_candidate(
            task_id="task-system-failure",
            path=source,
            original_filename="订单.csv",
            file_type="csv",
            authoritative={},
        )
    failed = runner.status()
    assert failed["document_ready"] is True
    assert failed["ready"] is True
    assert failed["degraded"] is True
    assert failed["consecutive_document_system_failures"] == 1

    for attempt in (2, 3):
        with pytest.raises(TimeoutError):
            await runner.run_candidate(
                task_id=f"task-system-failure-{attempt}",
                path=source,
                original_filename="订单.csv",
                file_type="csv",
                authoritative={},
            )
    circuit = runner.status()
    assert circuit["document_ready"] is False
    assert circuit["ready"] is False
    assert circuit["document_circuit_open"] is True
    assert circuit["consecutive_document_system_failures"] == 3

    runner._document_circuit_open_until = time.monotonic() - 0.01
    half_open = runner.status()
    assert half_open["ready"] is True
    assert half_open["document_circuit_half_open"] is True
    assert half_open["consecutive_document_system_failures"] == 2

    client.fail = False
    await runner.probe()
    recovered = runner.status()
    assert recovered["document_ready"] is True
    assert recovered["ready"] is True
    assert recovered["consecutive_document_system_failures"] == 0

    invalid = tmp_path / "invalid.csv"
    invalid.write_bytes(b"binary\x00payload")
    with pytest.raises(MinerUInputContractError):
        await runner.run_candidate(
            task_id="task-invalid-input",
            path=invalid,
            original_filename="invalid.csv",
            file_type="csv",
            authoritative={},
        )
    task_local = runner.status()
    assert task_local["document_ready"] is True
    assert task_local["ready"] is True
    assert task_local["document_system_failures"] == 3
    await runner.close()
