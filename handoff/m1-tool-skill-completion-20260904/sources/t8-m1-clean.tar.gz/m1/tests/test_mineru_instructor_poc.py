from __future__ import annotations

import importlib.util
import json
from typing import Any, ClassVar

import httpx
import pytest
from pydantic import ValidationError

from m1.documents.models import SourceReference
from m1.documents.parsing import mineru_instructor_poc as instructor_poc
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru_instructor_poc import (
    BlockSemantics,
    DocumentClassification,
    DocumentIntent,
    EvidenceReference,
    ExtractedFact,
    ExtractedRecord,
    ExtractedSegment,
    InstructorUnavailableError,
    MinerUInstructorExtractor,
    ModelFailureDiagnostic,
    ProposedContentBinding,
    ProposedFact,
    ProposedRecord,
    RecordCellRemap,
    RecordFieldBinding,
    RecordFieldMapping,
    RecordKindDecision,
    RecordKindMapping,
    SegmentExtraction,
    TableIntent,
    TablePartition,
    TableSegmentIntent,
    _align_geometry_primary_partition,
    _apply_geometry_table_partition,
    _apply_route_primary_table_policy,
    _apply_route_table_partitions,
    _augment_geometry_tables,
    _bounded_record_kind_evidence,
    _canonical_fact_name,
    _complete_geometry_line_sequence,
    _document_subtype,
    _evidence_backed_field_names,
    _evidence_payload,
    _explicit_document_intent,
    _field_names_from_mapping,
    _has_commercial_record_structure,
    _inherit_record_context,
    _is_blocking_issue,
    _label_occurrences,
    _local_metadata_fallback,
    _looks_like_product_specification,
    _migrate_route_roles_to_geometry_tables,
    _model_failure_diagnostic,
    _narrow_proposed_fact_value,
    _native_title_text,
    _normalize_intent_partition,
    _redundant_consumed_block_ids,
    _redundant_table_block_ids,
    _refine_primary_record_table_ids,
    _refine_technical_primary_table_segments,
    _repair_document_fact_from_evidence,
    _select_primary_record_table_ids,
    _table_index,
    _technical_document_signals,
    _technical_preferred_orientation,
    _technical_primary_record_axes,
    _technical_primary_record_rows,
    _technical_primary_table_candidates,
    _validate_intent_partition,
    _validated_fact,
    _ValidatedSegment,
    evidence_inventory,
)
from m1.documents.parsing.mineru_regions import (
    EvidenceRecordRegion,
    RecordRegionAssessment,
    assess_record_regions,
    record_region_id,
)

_BBOX = EvidenceBBox(x0=0, y0=0, x1=10, y1=10, coordinate_space="pdf_points")


def _product_record_kind_mapping(messages: list[dict[str, str]]) -> RecordKindMapping:
    payload = json.loads(messages[1]["content"])["evidence"]
    return RecordKindMapping(
        decisions=[
            RecordKindDecision(
                axis_index=candidate["axis_index"],
                record_kind="product",
                citations=[candidate["fields"][0]["evidence_id"]],
            )
            for candidate in payload["candidates"]
        ]
    )


def _single_block_evidence(text: str) -> DocumentEvidence:
    return DocumentEvidence(
        backend="mineru",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="text",
                        text=text,
                        bbox=_BBOX,
                    )
                ],
                tables=[],
            )
        ],
    )


def _evidence() -> DocumentEvidence:
    rows = [
        ["Item", "Code", "Qty"],
        ["1", "SKU-1", "2"],
        ["2", "SKU-2", "3"],
    ]
    return DocumentEvidence(
        backend="mineru",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="text",
                        text="Order PO-1",
                        bbox=_BBOX,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=rows,
                        cells=[
                            EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
                            for row, values in enumerate(rows)
                            for column, value in enumerate(values)
                        ],
                        bbox=_BBOX,
                    )
                ],
            )
        ],
    )


def _inconclusive_evidence() -> DocumentEvidence:
    evidence = _evidence().model_copy(deep=True)
    rows = [
        ["alpha", "beta", "charlie"],
        ["gamma", "delta", "echo"],
        ["epsilon", "zeta", "theta"],
    ]
    table = evidence.pages[0].tables[0]
    table.rows = rows
    table.cells = [
        EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]
    return evidence


def _long_table_evidence() -> DocumentEvidence:
    evidence = _evidence().model_copy(deep=True)
    rows = [
        ["Item", "Code", "Qty"],
        *[[str(index), f"SKU-{index:03d}", str(index * 2)] for index in range(1, 26)],
    ]
    table = evidence.pages[0].tables[0]
    table.rows = rows
    table.cells = [
        EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]
    return evidence


def test_mapper_schema_exposes_bounded_nonempty_strings() -> None:
    fact_schema = ProposedFact.model_json_schema()["properties"]
    assert fact_schema["name"]["minLength"] == 1
    assert fact_schema["name"]["maxLength"] == 128
    assert fact_schema["value"]["minLength"] == 1
    assert fact_schema["value"]["maxLength"] == 4000

    content_schema = ProposedContentBinding.model_json_schema()["properties"]
    assert content_schema["evidence_id"]["minLength"] == 1
    assert content_schema["label"]["minLength"] == 1

    field_schema = RecordFieldBinding.model_json_schema()["properties"]
    assert "product_code" in field_schema["field_name"]["enum"]
    assert "quantity" in field_schema["field_name"]["enum"]


def test_model_mapping_cannot_override_canonical_inventory_headers() -> None:
    mapping = RecordFieldMapping(
        field_axis_count=3,
        bindings=[
            RecordFieldBinding(axis_index=0, field_name="product_code"),
            RecordFieldBinding(axis_index=1, field_name="quantity"),
            RecordFieldBinding(axis_index=2, field_name="name_raw"),
        ],
    )

    assert _field_names_from_mapping(
        mapping,
        orientation="rows",
        expected_count=3,
        fallback_names={
            0: "bom_number",
            1: "available_quantity",
            2: "unknown_source_column",
        },
        document_type="inventory",
    ) == {
        0: "bom_number",
        1: "available_quantity",
        2: "name_raw",
    }


def test_product_specification_is_resolved_from_semantic_evidence() -> None:
    rows = [
        ["产品规格书"],
        ["产品编号", "494-12732 TX / 494-12733 RX", "产品名称", "HDMI2.1 光模组"],
        ["规格参数", "带宽", "48Gbps"],
        ["规格参数", "分辨率", "8K@60Hz"],
        ["规格参数", "工作电压", "5V"],
        ["规格参数", "传输距离", "100米"],
    ]
    evidence = DocumentEvidence(
        backend="mineru:3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=rows,
                        cells=[
                            EvidenceCell(row=row, column=column, text=value)
                            for row, values in enumerate(rows)
                            for column, value in enumerate(values)
                        ],
                    )
                ],
            )
        ],
    )

    assert _looks_like_product_specification(
        "\n".join(value for row in rows for value in row)
    )
    assert _document_subtype(
        DocumentIntent(document_intent="technical_document"), evidence
    ) == ("product_specification")


def test_sparse_drawing_evidence_is_not_misclassified_as_order() -> None:
    evidence = _single_block_evidence(
        "壳子镭雕：DP 2.1 视频高清线\n镭雕白色\n正面\n反面\n外壳1:1比例\n示图"
    )

    signals = _technical_document_signals(_native_title_text(evidence))

    assert signals.is_technical_document
    assert signals.subtype == "engineering_drawing"
    assert _explicit_document_intent(evidence) == "technical_document"
    assert (
        _document_subtype(
            DocumentIntent(document_intent="technical_document"), evidence
        )
        == "engineering_drawing"
    )


def test_specification_sections_outweigh_drawing_title_block() -> None:
    evidence = _single_block_evidence(
        "DWG NO. ICP-0018-A0 PART NO. PJM38P801-0xxF-0 SCALE 1:1 "
        "GENERAL TOLERANCE ±0.1 REVISION A/0 APPROVED CHECKED DRAWN "
        "Electrical Test: Insulation Resistance and Contact Resistance. "
        "Mechanical: Durability and tensile strength. "
        "RoHS and REACH environmental protection. "
        "Operating Temperature: -40~+125°C."
    )

    signals = _technical_document_signals(_native_title_text(evidence))

    assert signals.is_technical_document
    assert signals.subtype == "product_specification"
    assert _explicit_document_intent(evidence) == "technical_document"
    assert (
        _document_subtype(
            DocumentIntent(document_intent="technical_document"), evidence
        )
        == "product_specification"
    )


def test_commercial_evidence_prevents_drawing_note_from_reversing_order() -> None:
    evidence = _single_block_evidence(
        "采购订单 订单号 PO-108 采购方甲公司 供应商乙公司 "
        "交货日期 2026-08-10 单价 2.50 金额 2500 "
        "备注：外壳镭雕按1:1示图确认正面和反面"
    )

    signals = _technical_document_signals(_native_title_text(evidence))

    assert not signals.is_technical_document
    assert _explicit_document_intent(evidence) is None


def test_sample_request_title_is_an_explicit_order_subtype() -> None:
    evidence = _single_block_evidence(
        "东莞市唯格电子科技有限公司 样品需求单\n"
        "产品编号 ATZ-FD-15 产品名称 光纤线 数量 1"
    )

    assert _explicit_document_intent(evidence) == "sample_request"
    assert (
        _document_subtype(DocumentIntent(document_intent="order"), evidence)
        == "sample_request"
    )


def test_order_anchor_vetoes_sparse_drawing_signals_without_prices() -> None:
    evidence = _single_block_evidence(
        "订单 料号 ABC-1 版本 A 公差 ±0.1 比例 1:1 正面 反面"
    )

    signals = _technical_document_signals(_native_title_text(evidence))

    assert signals.drawing_groups >= 3
    assert signals.order_marker
    assert not signals.is_technical_document
    assert _explicit_document_intent(evidence) is None


def test_spreadsheet_native_classification_overrides_model_family_and_subtype() -> None:
    evidence = _single_block_evidence("设备名称 设备型号 数量 单位")
    evidence.backend = "spreadsheet-envelope"
    evidence.raw = {
        "native_classification": {
            "schema_version": "m1.native-classification.v1",
            "source": "spreadsheet-tabular-v1",
            "document_type": "equipment",
            "document_subtype": "equipment_register",
            "authority": "native_content",
            "confidence": 0.95,
            "evidence": [
                {
                    "document_subtype": "equipment_register",
                    "quote": "设备名称 设备型号 数量 单位",
                    "source_ref": {"page": 1, "part": "mineru/p1:b0"},
                }
            ],
        }
    }

    assert _explicit_document_intent(evidence) == "equipment"
    assert (
        _document_subtype(
            DocumentIntent(
                document_intent="inventory",
                document_subtype="inventory_snapshot",
            ),
            evidence,
        )
        == "equipment_register"
    )


@pytest.mark.parametrize(
    ("authority", "quote", "part"),
    [
        ("none", "设备名称", "mineru/p1:b0"),
        ("native_content", "不存在的文字", "mineru/p1:b0"),
        ("native_content", "设备名称", "mineru/missing"),
    ],
)
def test_native_classification_requires_replayable_authoritative_evidence(
    authority: str,
    quote: str,
    part: str,
) -> None:
    evidence = _single_block_evidence("设备名称 设备型号 数量 单位")
    evidence.backend = "spreadsheet-envelope"
    evidence.raw = {
        "native_classification": {
            "schema_version": "m1.native-classification.v1",
            "source": "spreadsheet-tabular-v1",
            "document_type": "equipment",
            "document_subtype": "equipment_register",
            "authority": authority,
            "confidence": 0.95,
            "evidence": [
                {
                    "document_subtype": "equipment_register",
                    "quote": quote,
                    "source_ref": {"page": 1, "part": part},
                }
            ],
        }
    }

    assert instructor_poc._trusted_native_classification(evidence) == (None, None)


def test_service_policy_replaces_unsupported_product_specification_subtype() -> None:
    evidence = _single_block_evidence(
        "前言 产品售后服务政策 保修产品 保修服务内容 产品保修政策"
    )

    assert (
        _document_subtype(
            DocumentIntent(
                document_intent="technical_document",
                document_subtype="product_specification",
            ),
            evidence,
        )
        == "service_policy"
    )


def test_service_policy_resolves_to_its_open_domain_subtype() -> None:
    evidence = _single_block_evidence(
        "前言 产品售后服务政策 保修产品 保修服务内容 产品保修政策"
    )

    assert _explicit_document_intent(evidence) == "technical_document"
    assert (
        _document_subtype(
            DocumentIntent(
                document_intent="technical_document",
                document_subtype="service_policy",
            ),
            evidence,
        )
        == "service_policy"
    )


def test_full_page_natural_image_overrides_unsupported_order_intent() -> None:
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=2010,
                height=3015,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="image",
                        text="Two electronic devices with visible internal components",
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=0.998,
                            y1=0.998,
                            coordinate_space="normalized",
                        ),
                        sub_type="natural_image",
                    )
                ],
            )
        ],
    )
    issues: list[str] = []

    resolved, _route_applicable = instructor_poc._apply_guarded_route_classification(
        DocumentIntent(
            document_intent="order",
            document_subtype="customer_purchase_order",
        ),
        evidence,
        instructor_poc._GuardedDocumentRouteContext(),
        document_type_hint=None,
        document_subtype_hint=None,
        issues=issues,
    )

    assert resolved.document_intent == "technical_document"
    assert _document_subtype(resolved, evidence) == "product_photo"
    assert issues == ["explicit_document_intent_override:order:technical_document"]


def test_order_intent_requires_order_text_or_selected_record_table() -> None:
    photo = _single_block_evidence("V750 动力充足")
    unsupported = DocumentIntent(
        document_intent="order",
        document_subtype="customer_purchase_order",
    )

    assert instructor_poc._order_intent_has_native_support(unsupported, photo) is False

    table = EvidenceTable(
        table_id="p1:t0",
        rows=[["1", "光纤线", "100", "PCS"]],
        cells=[
            EvidenceCell(row=0, column=column, text=value)
            for column, value in enumerate(("1", "光纤线", "100", "PCS"))
        ],
    )
    photo.pages[0].tables = [table]
    supported = unsupported.model_copy(
        update={"primary_record_table_ids": ["p1:t0"]},
        deep=True,
    )

    assert instructor_poc._order_intent_has_native_support(supported, photo) is True


@pytest.mark.parametrize(
    ("header", "values", "title", "expected"),
    [
        (
            ["PART NO", "DESCRIPTION", "QTY"],
            ["P-100", "Connector shell", "2"],
            "Technical BOM",
            False,
        ),
        (
            ["PART NO", "QTY", "UNIT PRICE"],
            ["P-100", "20", "3.50"],
            "PURCHASE ORDER",
            True,
        ),
    ],
)
def test_commercial_record_structure_requires_order_commitment(
    header: list[str],
    values: list[str],
    title: str,
    expected: bool,
) -> None:
    table = EvidenceTable(
        table_id="p1:t0",
        rows=[header, values],
        cells=[
            EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
            for row, entries in enumerate((header, values))
            for column, value in enumerate(entries)
        ],
    )
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="title",
                        text=title,
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=100,
                            y1=10,
                            coordinate_space="normalized",
                        ),
                    )
                ],
                tables=[table],
            )
        ],
    )

    assert _has_commercial_record_structure(evidence) is expected


def test_order_header_evidence_excludes_metadata_and_total_rows() -> None:
    rows = [
        ["供应商:广西桐曦电子科技有限公司", "", "", "订单日期:2026-03-31"],
        ["结款方式:月结90天", "", "", "交货日期:2026-04-26"],
        ["序号", "型号", "名称", "数量"],
        ["1", "IGO-H001", "HDTV 4K 定制线", "3600"],
        ["", "", "", "3600"],
        ["产品要求: 做货前确认样品", "", "", ""],
    ]
    table = EvidenceTable(
        table_id="order",
        rows=rows,
        cells=[
            EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
            for row, values in enumerate(rows)
            for column, value in enumerate(values)
        ],
    )
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                tables=[table],
            )
        ],
    )
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table.table_id,
                orientation="rows",
                segments=[TableSegmentIntent(start=0, end=5, intent="records")],
            )
        ],
    )

    normalized = _normalize_intent_partition(
        intent,
        {table.table_id: table},
        evidence,
    )

    assert [
        (segment.start, segment.end, segment.intent)
        for segment in normalized.tables[0].segments
    ] == [
        (0, 2, "layout"),
        (3, 3, "records"),
        (4, 5, "layout"),
    ]


def test_purchase_order_reference_in_specification_body_is_not_order_anchor() -> None:
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:title",
                        kind="title",
                        text="Product Specification",
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0.05,
                            x1=1,
                            y1=0.1,
                            coordinate_space="normalized",
                        ),
                    ),
                    EvidenceBlock(
                        block_id="p1:body",
                        kind="text",
                        text=(
                            "Electrical Test and Mechanical characteristics. "
                            "RoHS and REACH. Operating Temperature -40~+125C. "
                            "Packaging shall follow the customer's purchase order."
                        ),
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0.5,
                            x1=1,
                            y1=0.9,
                            coordinate_space="normalized",
                        ),
                    ),
                ],
            )
        ],
    )

    signals = _technical_document_signals(
        instructor_poc._native_evidence_text(evidence),
        order_anchor_text=_native_title_text(evidence),
    )

    assert not signals.order_marker
    assert signals.is_technical_document
    assert _explicit_document_intent(evidence) == "technical_document"


def _long_table_intent() -> DocumentIntent:
    return DocumentIntent(
        document_intent="bill_of_materials",
        tables=[
            TableIntent(
                table_id="p1:t0",
                orientation="rows",
                segments=[
                    TableSegmentIntent(start=0, end=0, intent="layout"),
                    TableSegmentIntent(start=1, end=25, intent="records"),
                ],
            )
        ],
    )


def _three_column_mapping() -> RecordFieldMapping:
    return RecordFieldMapping(
        field_axis_count=3,
        bindings=[
            RecordFieldBinding(axis_index=0, field_name="line_no"),
            RecordFieldBinding(axis_index=1, field_name="product_code"),
            RecordFieldBinding(axis_index=2, field_name="quantity"),
        ],
    )


def test_spreadsheet_cell_reference_keeps_original_sheet_and_coordinate() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=2,
                height=20,
                coordinate_space="unknown",
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[["SKU-108"]],
                        cells=[
                            EvidenceCell(
                                row=0,
                                column=0,
                                text="SKU-108",
                                sheet="采购明细",
                                cell="B108",
                                source_row=108,
                                source_column=2,
                            )
                        ],
                    )
                ],
            )
        ],
    )

    item = evidence_inventory(evidence)["spreadsheet:s0:r0:c0"]

    assert item.source_ref.sheet == "采购明细"
    assert item.source_ref.cell == "B108"
    assert item.source_ref.part == "spreadsheet/采购明细/B108"
    assert item.source_ref.model_extra["source_row"] == 108


def test_visual_asset_references_keep_original_asset_provenance() -> None:
    sha256 = "a" * 64
    asset_source_refs = [
        {
            "source_ref": {
                "sheet": "Order",
                "cell": "L9",
                "part": "spreadsheet/Order/L9",
            },
            "relationship_id": "rId9",
            "anchor": {"kind": "wps_dispimg", "from_cell": "L9"},
            "alt_text": [],
        }
    ]
    asset_context = {
        "asset_id": f"asset:sha256:{sha256}",
        "asset_sha256": sha256,
        "asset_parts": ["xl/media/image9.png"],
        "asset_source_refs": asset_source_refs,
        "asset_parser_backend": "mineru-vlm",
        "asset_parser_backend_version": "1.0",
        "asset_parser_page_number": 1,
        "asset_parser_page_index": 0,
    }
    evidence = DocumentEvidence(
        backend="visual-asset-enriched",
        pages=[
            EvidencePage(
                page_number=7,
                page_index=6,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id=f"asset:{sha256}/p0/b0",
                        text="Product photo label",
                        bbox=_BBOX,
                        asset_parser_block_id="b0",
                        **asset_context,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id=f"asset:{sha256}/p0/t0",
                        rows=[["SKU-9", "unpositioned value"]],
                        cells=[
                            EvidenceCell(
                                row=0,
                                column=0,
                                text="SKU-9",
                                bbox=_BBOX,
                                asset_cell_id=f"asset:{sha256}/p0/t0/cell:0:0:0",
                                **asset_context,
                            )
                        ],
                        asset_parser_table_id="t0",
                        **asset_context,
                    )
                ],
            )
        ],
    )

    inventory = evidence_inventory(evidence)
    references = [
        inventory[f"asset:{sha256}/p0/b0"].source_ref,
        inventory[f"asset:{sha256}/p0/t0:r0:c0"].source_ref,
        inventory[f"asset:{sha256}/p0/t0:r0:c1"].source_ref,
    ]

    assert references[0].page == 7
    assert references[0].part == f"mineru/asset:{sha256}/p0/b0"
    assert references[1].part == f"mineru/asset:{sha256}/p0/t0/r0/c0"
    assert references[2].part == f"mineru/asset:{sha256}/p0/t0/r0/c1"
    for reference in references:
        assert reference.model_extra["asset_sha256"] == sha256
        assert reference.model_extra["asset_parts"] == ["xl/media/image9.png"]
        assert reference.model_extra["asset_source_refs"] == asset_source_refs
        assert reference.model_extra["asset_parser_page_number"] == 1
        assert reference.model_extra["asset_parser_page_index"] == 0
        assert reference.model_extra["authority"] == "advisory"
        assert reference.model_extra["inferred"] is True
    assert references[0].model_extra["asset_parser_block_id"] == "b0"
    assert references[1].model_extra["asset_cell_id"].endswith("/cell:0:0:0")
    assert references[2].model_extra["asset_parser_table_id"] == "t0"
    assert references[2].model_extra["coordinate_inferred"] is True

    assert _evidence_payload(evidence)["blocks"] == []
    assert _evidence_payload(evidence)["tables"] == []
    issues: list[str] = []
    extracted, consumed = _validated_fact(
        ProposedFact(
            name="product_type",
            value="Product photo label",
            citations=[f"asset:{sha256}/p0/b0"],
        ),
        inventory,
        allowed_ids=None,
        issues=issues,
    )
    assert extracted is None
    assert consumed == set()
    assert issues == [f"advisory_evidence_forbidden:asset:{sha256}/p0/b0"]


def test_technical_primary_table_requires_business_column_corroboration() -> None:
    def record(*names: str) -> ExtractedRecord:
        return ExtractedRecord(
            fields=[
                ExtractedFact(
                    name=name,
                    value=name,
                    evidence_refs=[
                        EvidenceReference(
                            evidence_id=f"e:{name}",
                            quote=name,
                            source_ref=SourceReference(page=1, part=f"p:{name}"),
                        )
                    ],
                )
                for name in names
            ]
        )

    segments = [
        ExtractedSegment(
            table_id="bom",
            segment_id="bom-segment",
            intent="records",
            records=[record("料号", "产品描述", "数量", "单位")],
        ),
        ExtractedSegment(
            table_id="pin-map",
            segment_id="pin-segment",
            intent="records",
            records=[record("TYPE C A", "Signal", "TYPE C B")],
        ),
    ]
    issues: list[str] = []

    selected = _refine_primary_record_table_ids(
        "technical_document",
        ["bom", "pin-map"],
        segments,
        issues,
    )

    assert selected == ["bom"]
    assert issues == ["primary_record_table_refined:business_column_corroboration"]


def test_technical_primary_table_fallback_excludes_pin_and_revision_tables() -> None:
    """A failed intent call must not promote every drawing table to BOM rows."""

    def table(table_id: str, rows: list[list[str]]) -> EvidenceTable:
        return EvidenceTable(
            table_id=table_id,
            rows=rows,
            cells=[
                EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
                for row, values in enumerate(rows)
                for column, value in enumerate(values)
            ],
        )

    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                tables=[
                    table(
                        "p1:bom",
                        [
                            ["10", "50403-326", "50mm", "Copper foil"],
                            ["9", "30402-160", "2pcs", "Type C shell"],
                            ["8", "82324-019", "1pcs", "Type C plug"],
                            ["7", "82324-018", "1pcs", "Type C plug"],
                        ],
                    ),
                    table(
                        "p1:pin-map",
                        [
                            ["TYPE C A", "Signal", "TYPE C B"],
                            ["A4", "VBUS", "B4"],
                            ["A5", "CC", "B5"],
                            ["A6", "D+", "B6"],
                        ],
                    ),
                    table(
                        "p1:revision",
                        [
                            ["Version", "Date", "Change", "Checker"],
                            ["A", "2026-01-01", "Initial release", "QA"],
                            ["B", "2026-01-02", "Shell update", "QA"],
                        ],
                    ),
                    table(
                        "p1:title",
                        [["Part", "CY1703786A"], ["Material", "CY1701732A"]],
                    ),
                ],
            )
        ],
    )
    assessment = assess_record_regions(evidence)
    issues: list[str] = []

    selected = _select_primary_record_table_ids(
        # The classifier is allowed to fail closed.  Evidence scoring must
        # still keep a BOM separate from pin/revision tables in that case.
        DocumentIntent(document_intent="unknown"),
        _table_index(evidence),
        assessment,
        issues,
    )

    assert selected == ["p1:bom"]
    assert "primary_record_table_fallback:all_record_tables" not in issues
    assert any(
        issue.startswith("primary_record_table_fallback:business_evidence:")
        for issue in issues
    )


def test_technical_primary_rows_stop_before_swallowed_title_block() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["3", "SKU-3", "1pcs", "Third part"],
            ["2", "SKU-2", "1pcs", "Second part"],
            ["2", "SKU-2", "1pcs", "Second part"],
            ["1", "SKU-1", "1pcs", "First part"],
            ["1", "SKU-1", "1pcs", "Type C Plug PIN gold"],
            ["1", "SKU-1", "1pcs", "Drawing number D-1"],
        ],
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        tables=[
            TableIntent(
                table_id="p1:bom",
                orientation="rows",
                segments=[TableSegmentIntent(start=0, end=5, intent="records")],
            )
        ],
    )
    issues: list[str] = []

    refined = _refine_technical_primary_table_segments(
        intent,
        {"p1:bom": table},
        ["p1:bom"],
        issues,
    )

    assert [
        (segment.start, segment.end, segment.intent)
        for segment in refined.tables[0].segments
    ] == [
        (0, 4, "records"),
        (5, 5, "layout"),
    ]
    assert issues == ["primary_record_rows_refined:evidence_shape"]


def test_technical_primary_rows_keep_unheaded_numeric_bom() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["1", "123456", "Screw", "2"],
            ["2", "123457", "Nut", "4"],
        ],
    )

    assert _technical_primary_record_rows(table) == {0, 1}


def test_technical_primary_rows_keep_continued_bom_after_repeated_header() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["Item", "Part Number", "Description", "Qty"],
            ["1", "123456", "Screw", "2"],
            ["2", "123457", "Nut", "4"],
            ["Item", "Part Number", "Description", "Qty"],
            ["3", "123458", "Washer", "6"],
        ],
    )

    assert _technical_primary_record_rows(table) == {1, 2, 4}


def test_technical_primary_rows_do_not_treat_dimension_word_as_title_boundary() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["1", "ABC-001", "1pcs", "Drawing cable length 100mm"],
            ["2", "ABC-002", "1pcs", "Length-adjustable shell"],
            ["3", "ABC-003", "1pcs", "Drawing spacer"],
        ],
    )

    assert _technical_primary_record_rows(table) == {0, 1, 2}


def test_technical_primary_axes_preserve_column_oriented_bom() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["Item", "1", "2"],
            ["Code", "123456", "123457"],
            ["Name", "Screw", "Nut"],
            ["Qty", "2", "4"],
        ],
    )

    assert _technical_primary_record_axes(table, "columns") == {1, 2}
    assert _technical_preferred_orientation(table) == ("columns", {1, 2})


def test_technical_primary_refinement_corrects_model_transposition() -> None:
    table = EvidenceTable(
        table_id="bom",
        rows=[
            ["10", "50403-326", "50mm", "双面导电铜箔"],
            ["9", "30402-160", "2pcs", "Type C 分线槽"],
            ["8", "82324-019", "1pcs", "Type C Plug"],
            ["7", "82324-018", "1pcs", "Type C Plug"],
        ],
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        tables=[
            TableIntent(
                table_id="bom",
                orientation="columns",
                segments=[TableSegmentIntent(start=0, end=3, intent="records")],
            )
        ],
    )
    issues: list[str] = []

    refined = _refine_technical_primary_table_segments(
        intent,
        {"bom": table},
        ["bom"],
        issues,
    )

    assert refined.tables[0].orientation == "rows"
    assert [
        (item.start, item.end, item.intent) for item in refined.tables[0].segments
    ] == [(0, 3, "records")]
    assert issues == ["primary_record_rows_refined:evidence_shape"]


def test_technical_refinement_preserves_deterministic_spreadsheet_row_geometry() -> (
    None
):
    table = EvidenceTable(
        table_id="spreadsheet:s1",
        rows=[
            [str(row), *[f"value-{row}-{column}" for column in range(1, 12)]]
            for row in range(2885)
        ],
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        tables=[
            TableIntent(
                table_id=table.table_id,
                orientation="rows",
                segments=[
                    TableSegmentIntent(start=0, end=0, intent="layout"),
                    TableSegmentIntent(start=1, end=2773, intent="records"),
                    TableSegmentIntent(start=2774, end=2774, intent="layout"),
                    TableSegmentIntent(start=2775, end=2786, intent="records"),
                    TableSegmentIntent(start=2787, end=2787, intent="layout"),
                    TableSegmentIntent(start=2788, end=2811, intent="records"),
                    TableSegmentIntent(start=2812, end=2812, intent="layout"),
                    TableSegmentIntent(start=2813, end=2884, intent="records"),
                ],
            )
        ],
    )
    record_ranges = [(1, 2773), (2775, 2786), (2788, 2811), (2813, 2884)]
    assessment = RecordRegionAssessment(
        status="complete",
        assessed_table_ids=[table.table_id],
        record_regions=[
            EvidenceRecordRegion(
                region_id=record_region_id(table.table_id, "rows", start, end),
                table_id=table.table_id,
                orientation="rows",
                data_start=start,
                data_end=end,
                boundary_evidence_ids=[
                    f"{table.table_id}:r{start}:c0",
                    f"{table.table_id}:r{end}:c0",
                ],
            )
            for start, end in record_ranges
        ],
    )
    issues: list[str] = []

    refined = _refine_technical_primary_table_segments(
        intent,
        {table.table_id: table},
        [table.table_id],
        issues,
        assessment=assessment,
    )

    assert refined.tables[0].orientation == "rows"
    assert [
        (segment.start, segment.end, segment.intent)
        for segment in refined.tables[0].segments
    ] == [
        (0, 0, "layout"),
        (1, 2773, "records"),
        (2774, 2774, "layout"),
        (2775, 2786, "records"),
        (2787, 2787, "layout"),
        (2788, 2811, "records"),
        (2812, 2812, "layout"),
        (2813, 2884, "records"),
    ]
    assert sum(end - start + 1 for start, end in record_ranges) == 2881
    assert (
        sum(segment.end - segment.start + 1 for segment in refined.tables[0].segments)
        == 2885
    )
    assert max(len(row) for row in table.rows) == 12
    assert issues == []


def test_technical_refinement_preserves_deterministic_column_geometry() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["Item", "1", "2"],
            ["Code", "123456", "123457"],
            ["Name", "Screw", "Nut"],
            ["Qty", "2", "4"],
        ],
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        tables=[
            TableIntent(
                table_id=table.table_id,
                orientation="columns",
                segments=[
                    TableSegmentIntent(start=0, end=0, intent="layout"),
                    TableSegmentIntent(start=1, end=2, intent="records"),
                ],
            )
        ],
    )
    assessment = RecordRegionAssessment(
        status="complete",
        assessed_table_ids=[table.table_id],
        record_regions=[
            EvidenceRecordRegion(
                region_id=record_region_id(table.table_id, "columns", 1, 2),
                table_id=table.table_id,
                orientation="columns",
                data_start=1,
                data_end=2,
                boundary_evidence_ids=[
                    f"{table.table_id}:r0:c1",
                    f"{table.table_id}:r0:c2",
                ],
            )
        ],
    )
    issues: list[str] = []

    refined = _refine_technical_primary_table_segments(
        intent,
        {table.table_id: table},
        [table.table_id],
        issues,
        assessment=assessment,
    )

    assert refined == intent
    assert issues == []


def test_long_record_projection_rejects_oversized_field_axis_before_validation() -> (
    None
):
    table = EvidenceTable(
        table_id="spreadsheet:s1",
        rows=[[str(row)] for row in range(2001)],
    )
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="columns",
        start=0,
        end=0,
        intent="records",
    )

    with pytest.raises(
        instructor_poc.RecordGeometryContractError,
        match=(
            r"record_field_axis_exceeds_limit:spreadsheet:s1:columns:"
            r"record_axis=0:field_count=2001:limit=2000"
        ),
    ):
        instructor_poc._project_long_record_segment(table, segment, {}, {})


def test_product_specification_pin_matrix_is_not_a_bom() -> None:
    table = EvidenceTable(
        table_id="spec-pin",
        rows=[
            ["产品编号", "494-05295 TX", "产品名称", "HDMI2.0 光模组"],
            ["规格参数", "带宽", "18Gbps", ""],
            ["光缆线材焊线规格", "PIN", "TX焊盘丝印", "线规"],
            ["", "2", "VCC", "24AWG"],
            ["", "3", "CEC", "28AWG"],
            ["", "4", "SCL", "30AWG"],
            ["", "5", "SDA", "30AWG"],
        ],
    )

    selected = _technical_primary_table_candidates(
        {table.table_id: table},
        assessment=RecordRegionAssessment(
            status="complete",
            assessed_table_ids=[table.table_id],
            no_record_table_ids=[table.table_id],
        ),
        record_table_ids={table.table_id},
    )

    assert selected == []


def test_incidental_pin_text_does_not_hide_component_bom() -> None:
    table = EvidenceTable(
        table_id="bom",
        rows=[
            ["10", "50403-326", "50mm", "双面导电铜箔"],
            ["9", "30402-160", "2pcs", "Type C 分线槽"],
            ["8", "82324-019", "1pcs", "Type C Plug 22PIN 镀镍外壳"],
            ["7", "82324-018", "1pcs", "Type C Plug 22PIN 定位脚"],
        ],
    )

    selected = _technical_primary_table_candidates(
        {table.table_id: table},
        assessment=RecordRegionAssessment(
            status="complete",
            assessed_table_ids=[table.table_id],
            no_record_table_ids=[table.table_id],
        ),
        record_table_ids={table.table_id},
    )

    assert selected == [table.table_id]


def test_technical_primary_fallback_does_not_promote_auxiliary_only_tables() -> None:
    tables = {
        "pin": EvidenceTable(
            table_id="pin",
            rows=[
                ["TYPE C A", "Signal", "TYPE C B"],
                ["A1", "GND", "B1"],
                ["A2", "D+", "B2"],
            ],
        ),
        "revision": EvidenceTable(
            table_id="revision",
            rows=[
                ["Version", "Date", "Change", "Checker"],
                ["A", "2026-01-01", "Initial", "QA"],
            ],
        ),
    }
    issues: list[str] = []

    selected = _select_primary_record_table_ids(
        DocumentIntent(document_intent="technical_document"),
        tables,
        RecordRegionAssessment(
            status="complete",
            assessed_table_ids=list(tables),
            no_record_table_ids=list(tables),
        ),
        issues,
    )

    assert selected == []
    assert "primary_record_table_fallback:all_record_tables" not in issues
    assert "primary_record_table_fallback:no_business_evidence" in issues


def test_technical_primary_fallback_does_not_promote_drawing_title_block() -> None:
    rows = [
        ["APPROVED", "J.G.QING", "PC", "8P8C六类四上四下", "m/m", "华思"],
        ["", "", "MATERIAL", "NAME", "UNIT", ""],
        ["CHECKED", "", "ICP-0018-A0", "PJM38P801-0xxF-0", "", "±0.1"],
        ["DRAWN", "", "DWG NO.", "PART NO.", "WEIGHT", "TOLERANCE"],
        ["", "", "透明", "射出成型", "1:1", "A/0"],
        ["DESIGNED", "Y.Cheng", "COLOR", "MANUFACTURE", "SCALE", "VERSION"],
    ]
    table = EvidenceTable(
        table_id="title-block",
        rows=rows,
        cells=[
            EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
            for row, values in enumerate(rows)
            for column, value in enumerate(values)
        ],
    )
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                tables=[table],
            )
        ],
    )
    issues: list[str] = []

    selected = _select_primary_record_table_ids(
        DocumentIntent(document_intent="technical_document"),
        {table.table_id: table},
        assess_record_regions(evidence),
        issues,
    )

    assert selected == []
    assert "primary_record_table_fallback:largest_technical_table" not in issues
    assert "primary_record_table_fallback:no_business_evidence" in issues


def test_technical_primary_fallback_excludes_dimension_only_block() -> None:
    tables = {
        "dimensions": EvidenceTable(
            table_id="dimensions",
            rows=[
                ["M3", "10mm", "Length"],
                ["M4", "12mm", "Width"],
                ["M5", "14mm", "Height"],
            ],
        ),
        "bom": EvidenceTable(
            table_id="bom",
            rows=[
                ["123456", "2pcs", "Screw"],
                ["123457", "4pcs", "Nut"],
            ],
        ),
    }
    issues: list[str] = []

    selected = _select_primary_record_table_ids(
        DocumentIntent(document_intent="technical_document"),
        tables,
        RecordRegionAssessment(
            status="complete",
            assessed_table_ids=list(tables),
            no_record_table_ids=list(tables),
        ),
        issues,
    )

    assert selected == ["bom"]


def _inconclusive_bom_evidence() -> DocumentEvidence:
    def table(table_id: str, rows: list[list[str]]) -> EvidenceTable:
        return EvidenceTable(
            table_id=table_id,
            rows=rows,
            cells=[
                EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
                for row, values in enumerate(rows)
                for column, value in enumerate(values)
            ],
        )

    return DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:title",
                        kind="text",
                        text="drawing number D-1",
                        bbox=_BBOX,
                    )
                ],
                tables=[
                    table(
                        "p1:bom",
                        [
                            ["10", "50403-326", "50mm", "Copper"],
                            ["9", "30402-160", "2pcs", "Shell"],
                            ["8", "82324-019", "1pcs", "Plug"],
                            ["8", "82324-019", "1pcs", "Plug"],
                            ["7", "82324-018", "1pcs", "Plug"],
                            ["1", "10501-256", "160mm", "Cable"],
                            ["1", "10501-256", "160mm", "Date"],
                            ["1", "10501-256", "160mm", "Drawing number D-1"],
                        ],
                    ),
                    table(
                        "p1:pin",
                        [
                            ["TYPE C A", "Signal", "TYPE C B"],
                            ["A1", "GND", "B1"],
                            ["A2", "D+", "B2"],
                        ],
                    ),
                    table(
                        "p1:unknown",
                        [
                            ["alpha", "beta"],
                            ["gamma", "delta"],
                            ["epsilon", "zeta"],
                        ],
                    ),
                ],
            )
        ],
    )


@pytest.mark.asyncio
async def test_inconclusive_intent_failure_keeps_evidence_scored_bom_records() -> None:
    class FailingClient:
        async def create(self, response_model, *, messages, max_retries):
            raise RuntimeError("intent unavailable")

    evidence = _inconclusive_bom_evidence()
    evidence.pages[0].blocks = []
    result = await MinerUInstructorExtractor(
        client=FailingClient(),
        max_retries=0,
    ).extract(evidence)

    assert result.primary_record_table_ids == ["p1:bom"]
    assert sum(len(segment.records) for segment in result.segments) == 5
    assert all(
        not segment.records or segment.table_id == "p1:bom"
        for segment in result.segments
    )
    assert "technical_partition_fallback:evidence_shape" in result.issues


@pytest.mark.asyncio
async def test_intent_input_limit_uses_safe_partition_without_model_retry() -> None:
    class UnexpectedClient:
        def __init__(self) -> None:
            self.intent_calls = 0

        async def create(self, response_model, *, messages, max_retries):
            if response_model is DocumentIntent:
                self.intent_calls += 1
            raise RuntimeError("model unavailable")

    evidence = _inconclusive_bom_evidence()
    evidence.pages[0].blocks = [
        EvidenceBlock(
            block_id="p1:large",
            kind="text",
            text="x" * 12_000,
            bbox=_BBOX,
        )
    ]
    client = UnexpectedClient()
    result = await MinerUInstructorExtractor(
        client=client,
        max_input_chars=4_000,
        max_retries=0,
    ).extract(evidence)

    assert client.intent_calls == 0
    assert "intent_input_limit_exceeded" in result.issues
    assert result.document_intent == "technical_document"
    assert result.primary_record_table_ids == ["p1:bom"]
    assert sum(len(segment.records) for segment in result.segments) == 5
    assert all(
        not segment.records or segment.table_id == "p1:bom"
        for segment in result.segments
    )


@pytest.mark.asyncio
async def test_inconclusive_correction_failure_keeps_only_scored_bom_records() -> None:
    class CorrectionFailingClient:
        def __init__(self) -> None:
            self.intent_calls = 0

        async def create(self, response_model, *, messages, max_retries):
            if response_model is DocumentIntent:
                self.intent_calls += 1
                if self.intent_calls == 1:
                    return DocumentIntent(
                        document_intent="technical_document",
                        tables=[
                            TableIntent(
                                table_id="p1:bom",
                                orientation="rows",
                                segments=[
                                    TableSegmentIntent(
                                        start=0,
                                        end=7,
                                        intent="records",
                                    )
                                ],
                            ),
                            TableIntent(
                                table_id="ghost",
                                orientation="rows",
                                segments=[
                                    TableSegmentIntent(
                                        start=0,
                                        end=0,
                                        intent="records",
                                    )
                                ],
                            ),
                        ],
                    )
                raise RuntimeError("correction unavailable")
            raise RuntimeError("unexpected model call")

    result = await MinerUInstructorExtractor(
        client=CorrectionFailingClient(),
        max_retries=0,
    ).extract(_inconclusive_bom_evidence())

    assert result.primary_record_table_ids == ["p1:bom"]
    assert sum(len(segment.records) for segment in result.segments) == 5
    assert all(
        not segment.records or segment.table_id == "p1:bom"
        for segment in result.segments
    )
    assert any(
        issue.startswith("intent_partition_correction_error:")
        for issue in result.issues
    )
    assert "technical_partition_fallback:evidence_shape" in result.issues


def test_geometry_reconstruction_splits_swallowed_bom_rows() -> None:
    texts = [
        "3",
        "SKU-3",
        "3pcs",
        "Widget C",
        "2",
        "SKU-2",
        "2pcs",
        "Widget B",
        "H",
        "SKU-1",
        "1pcs",
        "A1 Cable shell",
    ]
    boxes: list[list[int]] = []
    for index in range(3):
        y = 100 + index * 30
        boxes.extend(
            [
                [10, y, 20, y + 10],
                [40, y, 90, y + 10],
                [100, y, 130, y + 10],
                [150, y, 230, y + 10],
            ]
        )
    source_rows = [
        ["Version", "Date", "Signal", "Dimension", "Drawing", *([""] * 5)]
    ] + [["merged source row", *([""] * 9)] for _ in range(11)]
    source_table = EvidenceTable(
        table_id="p1:swallowed",
        rows=source_rows,
        bbox=EvidenceBBox(x0=0, y0=0, x1=300, y1=220),
    )
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=300,
                height=220,
                coordinate_space="pixels",
                tables=[source_table],
                raw={
                    "overall_ocr_res": {
                        "rec_texts": texts,
                        "rec_boxes": boxes,
                        "rec_scores": [0.99] * len(texts),
                    }
                },
            )
        ],
    )

    derived_ids = _augment_geometry_tables(evidence)

    assert derived_ids == ["p1:swallowed:geometry-bom"]
    assert evidence.pages[0].tables[0].rows == source_rows
    assert evidence.pages[0].tables[1].rows == [
        ["3", "SKU-3", "3pcs", "Widget C"],
        ["2", "SKU-2", "2pcs", "Widget B"],
        ["1", "SKU-1", "1pcs", "A1 Cable shell"],
    ]
    inventory = evidence_inventory(evidence)
    assert "p1:swallowed:geometry-bom:r1:c3" in inventory
    assert inventory["p1:swallowed:geometry-bom:r1:c3"].source_ref.bbox
    inferred_ref = inventory["p1:swallowed:geometry-bom:r2:c0"].source_ref
    assert inferred_ref.model_extra["inferred"] is True
    assert inferred_ref.model_extra["derived_from_table"] == "p1:swallowed"
    assert _augment_geometry_tables(evidence) == ["p1:swallowed:geometry-bom"]
    assert len(evidence.pages[0].tables) == 2


def test_geometry_reconstruction_rejects_same_page_tables_without_bbox() -> None:
    texts = [
        value
        for row in (
            ("3", "SKU-3", "3pcs", "Widget C"),
            ("2", "SKU-2", "2pcs", "Widget B"),
            ("1", "SKU-1", "1pcs", "Widget A"),
        )
        for value in row
    ]
    boxes = [
        [x0, 100 + row * 30, x1, 110 + row * 30]
        for row in range(3)
        for x0, x1 in ((10, 20), (40, 90), (100, 130), (150, 230))
    ]
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=300,
                height=220,
                coordinate_space="pixels",
                tables=[
                    EvidenceTable(table_id="p1:left", rows=[["merged"]]),
                    EvidenceTable(table_id="p1:right", rows=[["merged"]]),
                ],
                raw={
                    "overall_ocr_res": {
                        "rec_texts": texts,
                        "rec_boxes": boxes,
                        "rec_scores": [0.99] * len(texts),
                    }
                },
            )
        ],
    )

    assert _augment_geometry_tables(evidence) == []
    assert [table.table_id for table in evidence.pages[0].tables] == [
        "p1:left",
        "p1:right",
    ]


@pytest.mark.parametrize("table_coordinate_space", ["normalized", "unknown"])
def test_geometry_reconstruction_rejects_unusable_coordinate_space(
    table_coordinate_space: str,
) -> None:
    texts = [
        value
        for row in (
            ("3", "SKU-3", "3pcs", "Widget C"),
            ("2", "SKU-2", "2pcs", "Widget B"),
            ("1", "SKU-1", "1pcs", "Widget A"),
        )
        for value in row
    ]
    boxes = [
        [x0, 100 + row * 30, x1, 110 + row * 30]
        for row in range(3)
        for x0, x1 in ((10, 20), (40, 90), (100, 130), (150, 230))
    ]
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=300,
                height=220,
                coordinate_space="pixels",
                tables=[
                    EvidenceTable(
                        table_id="p1:mismatch",
                        rows=[["merged"]],
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=1,
                            y1=1,
                            coordinate_space=table_coordinate_space,
                        ),
                    )
                ],
                raw={
                    "overall_ocr_res": {
                        "rec_texts": texts,
                        "rec_boxes": boxes,
                        "rec_scores": [0.99] * len(texts),
                    }
                },
            )
        ],
    )

    assert _augment_geometry_tables(evidence) == []
    assert [table.table_id for table in evidence.pages[0].tables] == ["p1:mismatch"]


def test_geometry_reconstruction_ignores_large_order_without_drawing_context() -> None:
    header = [
        "Order Date",
        "Unit",
        "Length",
        "Product Name",
        "Product Code",
        "Quantity",
        "Customer",
        "Price",
        "Amount",
        "Remark",
    ]
    rows = [header] + [
        [
            "2026-07-31",
            "pcs",
            "100mm",
            f"Widget {index}",
            f"SKU-{index}",
            f"{index}pcs",
            "Customer A",
            "1.00",
            f"{index}.00",
            "normal order",
        ]
        for index in range(1, 12)
    ]
    texts = [
        value
        for row in (
            ("3", "SKU-3", "3pcs", "Widget C"),
            ("2", "SKU-2", "2pcs", "Widget B"),
            ("1", "SKU-1", "1pcs", "Widget A"),
        )
        for value in row
    ]
    boxes = [
        [x0, 100 + row * 30, x1, 110 + row * 30]
        for row in range(3)
        for x0, x1 in ((10, 20), (40, 90), (100, 130), (150, 230))
    ]
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=300,
                height=220,
                coordinate_space="pixels",
                tables=[
                    EvidenceTable(
                        table_id="p1:order-lines",
                        rows=rows,
                        bbox=EvidenceBBox(x0=0, y0=0, x1=300, y1=220),
                    )
                ],
                raw={
                    "overall_ocr_res": {
                        "rec_texts": texts,
                        "rec_boxes": boxes,
                        "rec_scores": [0.99] * len(texts),
                    }
                },
            )
        ],
    )

    assert _augment_geometry_tables(evidence) == []
    assert [table.table_id for table in evidence.pages[0].tables] == ["p1:order-lines"]


def test_geometry_line_completion_never_overwrites_observed_values() -> None:
    values: list[int | None] = [10, None, 1]

    _complete_geometry_line_sequence(values, [0, 1, 2])

    assert values == [10, None, 1]


@pytest.mark.parametrize(
    ("document_intent", "primary_role"),
    [("order", "order_lines"), ("inventory", "inventory_lines")],
)
def test_geometry_table_cannot_become_nontechnical_primary_records(
    document_intent: str,
    primary_role: str,
) -> None:
    source = EvidenceTable(
        table_id="source",
        rows=[["SKU-1", "1pcs"]],
    )
    derived = EvidenceTable(
        table_id="source:geometry-bom",
        rows=[["1", "SKU-1", "1pcs", "Widget"]],
        derived_geometry=True,
        derived_from_table="source",
    )
    intent = DocumentIntent(
        document_intent=document_intent,
        primary_record_table_ids=[source.table_id, derived.table_id],
        tables=[
            TableIntent(
                table_id=table.table_id,
                orientation="rows",
                segments=[TableSegmentIntent(start=0, end=0, intent="records")],
            )
            for table in (source, derived)
        ],
    )
    tables = {source.table_id: source, derived.table_id: derived}
    assessment = RecordRegionAssessment(
        status="complete",
        assessed_table_ids=list(tables),
        record_regions=[
            EvidenceRecordRegion(
                region_id=record_region_id(table_id, "rows", 0, 0),
                table_id=table_id,
                orientation="rows",
                data_start=0,
                data_end=0,
                boundary_evidence_ids=[
                    f"{table_id}:r0:c0",
                    f"{table_id}:r0:c1",
                ],
            )
            for table_id in tables
        ],
    )
    issues: list[str] = []

    filtered = _apply_geometry_table_partition(
        intent,
        tables,
        [derived.table_id],
        issues,
    )
    roles = _migrate_route_roles_to_geometry_tables(
        tables,
        {source.table_id: primary_role},
        [derived.table_id],
        document_intent=filtered.document_intent,
        issues=issues,
    )
    selected = _select_primary_record_table_ids(
        filtered,
        tables,
        assessment,
        issues,
    )
    selected = _apply_route_primary_table_policy(
        selected,
        tables,
        assessment,
        roles,
        issues,
        document_intent=filtered.document_intent,
    )

    assert filtered.primary_record_table_ids == [source.table_id]
    assert [table.table_id for table in filtered.tables] == [
        source.table_id,
        derived.table_id,
    ]
    derived_intent = next(
        table for table in filtered.tables if table.table_id == derived.table_id
    )
    assert [segment.intent for segment in derived_intent.segments] == ["layout"]
    partition_issues: list[str] = []
    planned = _validate_intent_partition(filtered, tables, partition_issues)
    assert partition_issues == []
    assert [
        (segment.table_id, segment.intent)
        for segment in planned
        if segment.intent == "records"
    ] == [(source.table_id, "records")]
    assert roles == {source.table_id: primary_role}
    assert selected == [source.table_id]


def test_geometry_route_role_migrates_and_keeps_one_primary_record_partition() -> None:
    source = EvidenceTable(
        table_id="p1:swallowed",
        rows=[
            ["3", "SKU-3", "3pcs", "Widget C"],
            ["2", "SKU-2", "2pcs", "Widget B"],
            ["1", "SKU-1", "1pcs", "Widget A"],
            ["1", "SKU-1", "1pcs", "Drawing number D-1"],
        ],
    )
    derived = EvidenceTable(
        table_id="p1:swallowed:geometry-bom",
        rows=[
            ["3", "SKU-3", "3pcs", "Widget C"],
            ["2", "SKU-2", "2pcs", "Widget B"],
            ["1", "SKU-1", "1pcs", "Widget A"],
        ],
        derived_geometry=True,
        derived_from_table=source.table_id,
    )
    tables = {source.table_id: source, derived.table_id: derived}
    intent = DocumentIntent(
        document_intent="technical_document",
        primary_record_table_ids=[source.table_id],
        tables=[
            TableIntent(
                table_id=source.table_id,
                orientation="rows",
                segments=[
                    TableSegmentIntent(
                        start=0,
                        end=len(source.rows) - 1,
                        intent="records",
                    )
                ],
            )
        ],
    )
    assessment = RecordRegionAssessment(
        status="complete",
        assessed_table_ids=list(tables),
        record_regions=[
            EvidenceRecordRegion(
                region_id=record_region_id(
                    table_id,
                    "rows",
                    0,
                    len(table.rows) - 1,
                ),
                table_id=table_id,
                orientation="rows",
                data_start=0,
                data_end=len(table.rows) - 1,
                boundary_evidence_ids=[
                    f"{table_id}:r0:c0",
                    f"{table_id}:r{len(table.rows) - 1}:c0",
                ],
            )
            for table_id, table in tables.items()
        ],
    )
    issues: list[str] = []

    roles = _migrate_route_roles_to_geometry_tables(
        tables,
        {source.table_id: "bom"},
        [derived.table_id],
        document_intent=intent.document_intent,
        issues=issues,
    )
    partitioned = _apply_geometry_table_partition(
        intent,
        tables,
        [derived.table_id],
        issues,
    )
    partitioned = _apply_route_table_partitions(partitioned, tables, roles)
    selected = _select_primary_record_table_ids(
        partitioned,
        tables,
        assessment,
        issues,
    )
    selected = _apply_route_primary_table_policy(
        selected,
        tables,
        assessment,
        roles,
        issues,
        document_intent=partitioned.document_intent,
    )
    partitioned = _align_geometry_primary_partition(
        partitioned,
        tables,
        [derived.table_id],
        selected,
        issues,
    )
    refined = _refine_technical_primary_table_segments(
        partitioned,
        tables,
        selected,
        issues,
    )
    planned = _validate_intent_partition(refined, tables, [])

    assert roles == {derived.table_id: "bom"}
    assert source.table_id not in roles
    assert selected == [derived.table_id]
    assert refined.primary_record_table_ids == [derived.table_id]
    assert [
        (segment.table_id, segment.intent)
        for segment in planned
        if segment.intent == "records"
    ] == [(derived.table_id, "records")]
    assert all(
        segment.intent == "layout"
        for segment in planned
        if segment.table_id == source.table_id
    )
    assert any(
        issue.startswith("document_route_geometry_roles_migrated:") for issue in issues
    )


def test_unheaded_technical_bom_gets_evidence_backed_line_field_names() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["10", "50403-326", "50mm", "Copper foil"],
            ["9", "30402-160", "2pcs", "Type C shell"],
            ["8", "82324-019", "1pcs", "Type C plug"],
            ["7", "82324-018", "1pcs", "Type C plug"],
        ],
    )
    segment = _ValidatedSegment(
        table_id="p1:bom",
        orientation="rows",
        start=0,
        end=3,
        intent="records",
    )

    names = _evidence_backed_field_names(
        table,
        segment,
        document_type="technical_document",
    )

    assert names == {
        0: "line_no",
        1: "material_code",
        2: "quantity",
        3: "name_raw",
    }


def test_unheaded_order_distinguishes_bare_quantity_from_line_number() -> None:
    table = EvidenceTable(
        table_id="p1:order",
        rows=[
            ["SKU-1", "Widget part", "2"],
            ["SKU-2", "Widget shell", "4"],
            ["SKU-3", "Widget cable", "6"],
        ],
    )
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="rows",
        start=0,
        end=2,
        intent="records",
    )

    assert _evidence_backed_field_names(
        table,
        segment,
        document_type="order",
    ) == {
        0: "product_code",
        1: "name_raw",
        2: "quantity",
    }


def test_unheaded_bom_keeps_invalid_date_shaped_eight_digit_material_codes() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["3", "12345678", "3pcs", "Copper foil"],
            ["2", "87654321", "2pcs", "Type C shell"],
            ["1", "31022026", "1pcs", "Type C plug"],
        ],
    )
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="rows",
        start=0,
        end=2,
        intent="records",
    )

    assert _evidence_backed_field_names(
        table,
        segment,
        document_type="technical_document",
    ) == {
        0: "line_no",
        1: "material_code",
        2: "quantity",
        3: "name_raw",
    }


def test_metadata_fact_can_cite_a_narrow_value_inside_one_table_cell() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.rows[0][0] = "Order: PO-1 Date: 2026-07-15"
    table.cells[0].text = table.rows[0][0]
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="order_number",
            value="PO-1",
            citations=["p1:t0:r0:c0"],
        ),
        inventory,
        allowed_ids=None,
        issues=issues,
        allow_table_substring=True,
    )

    assert extracted is not None
    assert extracted.value == "PO-1"
    assert consumed == {"p1:t0:r0:c0"}
    assert issues == []


def test_canonical_fact_name_preserves_allowed_raw_name_before_aliasing() -> None:
    assert (
        _canonical_fact_name("document_title", {"document_title", "title"})
        == "document_title"
    )
    assert _canonical_fact_name("document_title", {"title"}) == "title"


def test_labeled_fact_value_supports_same_line_and_stops_at_next_label() -> None:
    evidence = _single_block_evidence("采购订单号：PO-202607-18付款方式：月结30天")
    inventory = evidence_inventory(evidence)

    order = _narrow_proposed_fact_value(
        ProposedFact(
            name="order_number",
            value="PO-202607-18 付款方式：月结30天",
            citations=["p1:b0"],
        ),
        inventory,
    )
    payment = _narrow_proposed_fact_value(
        ProposedFact(
            name="payment_terms",
            value="付款方式：月结30天",
            citations=["p1:b0"],
        ),
        inventory,
    )

    assert order.value == "PO-202607-18"
    assert order.citations == ["p1:b0"]
    assert payment.value == "月结30天"


def test_labeled_fact_value_supports_next_nonempty_line() -> None:
    evidence = _single_block_evidence(
        "订单号码:\n\nTX2607110001\n供应商名称:\n广西桐曦电子科技有限公司"
    )
    inventory = evidence_inventory(evidence)

    source_order = _narrow_proposed_fact_value(
        ProposedFact(
            name="source_order_number",
            value="订单号码: TX2607110001",
            citations=["p1:b0"],
        ),
        inventory,
    )
    supplier = _narrow_proposed_fact_value(
        ProposedFact(
            name="supplier",
            value="广西桐曦电子科技有限公司",
            citations=["p1:b0"],
        ),
        inventory,
    )

    assert source_order.value == "TX2607110001"
    assert supplier.value == "广西桐曦电子科技有限公司"


def test_label_occurrences_prefers_longest_covering_label() -> None:
    assert _label_occurrences(
        "Source order number: SO-7",
        ("order", "source order", "source order number"),
    ) == [(0, len("Source order number"))]


def test_labeled_fact_value_uses_matching_candidate_across_all_citations() -> None:
    evidence = _single_block_evidence("Order no: PO-OLD")
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id="p1:b1",
            kind="text",
            text="Order no: PO-NEW",
            bbox=_BBOX,
        )
    )
    inventory = evidence_inventory(evidence)

    proposed = _narrow_proposed_fact_value(
        ProposedFact(
            name="order_number",
            value="The selected value is PO-NEW",
            citations=["p1:b0", "p1:b1"],
        ),
        inventory,
    )

    assert proposed.value == "PO-NEW"


def test_labeled_fact_value_fails_closed_when_citations_are_ambiguous() -> None:
    evidence = _single_block_evidence("Order no: PO-A")
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id="p1:b1",
            kind="text",
            text="Order no: PO-B",
            bbox=_BBOX,
        )
    )
    inventory = evidence_inventory(evidence)

    proposed = _narrow_proposed_fact_value(
        ProposedFact(
            name="order_number",
            value="unresolved",
            citations=["p1:b0", "p1:b1"],
        ),
        inventory,
    )

    assert proposed.value == "unresolved"


def test_labeled_fact_value_collects_multiline_value_until_next_label() -> None:
    evidence = _single_block_evidence(
        "Payment terms:\n30% prepaid\n70% after inspection\nSupplier:\nAcme Cable"
    )
    inventory = evidence_inventory(evidence)

    payment = _narrow_proposed_fact_value(
        ProposedFact(
            name="payment_terms",
            value="30% prepaid 70% after inspection",
            citations=["p1:b0"],
        ),
        inventory,
    )

    assert payment.value == "30% prepaid 70% after inspection"


def test_metadata_fallback_does_not_bridge_over_a_consumed_cell() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.rows = [["Order number", "PO-7", "Order date", "2026-07-24"]]
    table.cells = [
        EvidenceCell(row=0, column=column, text=value, bbox=_BBOX)
        for column, value in enumerate(table.rows[0])
    ]
    inventory = evidence_inventory(evidence)

    facts, consumed = _local_metadata_fallback(
        table,
        _ValidatedSegment(
            table_id="p1:t0",
            orientation="rows",
            start=0,
            end=0,
            intent="metadata",
        ),
        inventory,
        already_consumed={"p1:t0:r0:c1"},
    )

    assert [(fact.name, fact.value) for fact in facts] == [("Order date", "2026-07-24")]
    assert consumed == {"p1:t0:r0:c2", "p1:t0:r0:c3"}


def test_order_number_does_not_cross_a_total_quantity_label() -> None:
    evidence = _single_block_evidence("订单号码:\n合计数量：7400")
    inventory = evidence_inventory(evidence)
    proposed = _narrow_proposed_fact_value(
        ProposedFact(
            name="order_number",
            value="7400",
            citations=["p1:b0"],
        ),
        inventory,
    )
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        proposed,
        inventory,
        allowed_ids=None,
        issues=issues,
    )

    assert proposed.value == "7400"
    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_evidence_ref:order_number:p1:b0"]


def test_docx_five_column_specification_signature_overrides_model_hint() -> None:
    evidence = _single_block_evidence("外壳下料尺寸规格表")
    evidence.backend = "docx-native-ooxml"
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="docx:t:0",
            rows=[
                ["产品名称", "外径尺寸", "内径尺寸", "下料尺寸", "公差"],
                ["六边形铝壳", "19.94*9.96", "18.74*8.76", "18", "±0.05"],
            ],
            cells=[],
            bbox=_BBOX,
        )
    ]
    wrong_model_hint = DocumentIntent(
        document_intent="purchase_order",
        document_subtype="stocking_order",
    )

    assert _document_subtype(wrong_model_hint, evidence) == "product_specification"


def test_labeled_single_character_version_is_allowed() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.rows[0][0] = "版本 c"
    table.cells[0].text = "版本 c"
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="version",
            value="c",
            citations=["p1:t0:r0:c0"],
        ),
        inventory,
        allowed_ids=None,
        issues=issues,
        allow_table_substring=True,
    )

    assert extracted is not None
    assert extracted.value == "c"
    assert consumed == {"p1:t0:r0:c0"}
    assert issues == []


def test_unlabeled_substring_cannot_consume_a_narrative_block() -> None:
    evidence = _evidence()
    evidence.pages[0].blocks[0].text = "1.短路测试\n2.导通阻抗\n3.真机实测"
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(name="version", value="1", citations=["p1:b0"]),
        inventory,
        allowed_ids=None,
        issues=issues,
        allow_table_substring=True,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_evidence_ref:version:p1:b0"]


def test_label_only_value_is_not_a_fact() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.rows[0][0] = "版本"
    table.cells[0].text = "版本"
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(name="version", value="版本", citations=["p1:t0:r0:c0"]),
        inventory,
        allowed_ids=None,
        issues=issues,
        allow_table_substring=True,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_fact_value:version"]


class _Client:
    def __init__(self, outputs: list[Any]) -> None:
        self.outputs = list(outputs)
        self.calls: list[tuple[type[Any], list[dict[str, str]], int]] = []

    async def create(self, response_model, *, messages, max_retries):
        self.calls.append((response_model, messages, max_retries))
        assert self.outputs
        result = self.outputs.pop(0)
        assert isinstance(result, response_model)
        return result


@pytest.mark.asyncio
async def test_prompted_transport_caps_small_schema_output_budget() -> None:
    class CapturingStructuredClient:
        def __init__(self) -> None:
            self.kwargs: dict[str, Any] = {}

        async def run(self, output_type, **kwargs):
            self.kwargs = kwargs
            if output_type is instructor_poc._RecordFieldMappingOutput:
                output = output_type(bindings=[])
            elif output_type is instructor_poc._RecordKindMappingOutput:
                output = output_type(
                    decisions=[
                        {
                            "axis_index": 1,
                            "record_kind": "product",
                            "citations": ["t:r1:c0"],
                            "field_remaps": [],
                        }
                    ]
                )
            else:
                output = output_type(document_intent="order")
            return type(
                "StructuredRun",
                (),
                {"output": output},
            )()

    client = CapturingStructuredClient()
    transport = instructor_poc._PromptedOutputTransport(client, model="local")

    result = await transport.create(
        DocumentClassification,
        messages=[
            {"role": "system", "content": "classify"},
            {"role": "user", "content": "source"},
        ],
        max_retries=2,
    )

    assert result.document_intent == "order"
    assert client.kwargs["max_tokens"] == 768
    assert client.kwargs["retries"] == 2

    mapping = await transport.create(
        RecordFieldMapping,
        messages=[
            {"role": "system", "content": "map fields"},
            {
                "role": "user",
                "content": json.dumps({"evidence": {"field_axis": {"count": 0}}}),
            },
        ],
        max_retries=2,
    )

    assert mapping.field_axis_count == 0
    assert client.kwargs["max_tokens"] == 512

    kinds = await transport.create(
        RecordKindMapping,
        messages=instructor_poc._base_messages(
            role="record_kind_mapping",
            payload={
                "allowed_field_names": ["product_code"],
                "candidates": [
                    {
                        "axis_index": 1,
                        "fields": [
                            {
                                "evidence_id": "t:r1:c0",
                                "current_field_name": "product_code",
                                "value": "SKU-1",
                            }
                        ],
                    }
                ],
            },
        ),
        max_retries=2,
    )

    assert kinds.decisions[0].record_kind == "product"
    assert client.kwargs["max_tokens"] == 4096


def test_record_field_mapping_accepts_valid_proposals_independently() -> None:
    output = instructor_poc._RecordFieldMappingOutput(
        bindings=[
            {"axis_index": "1", "field_name": "quantity"},
            {"axis_index": "outside", "field_name": "unit"},
            {"axis_index": 1, "field_name": "unit"},
            {"axis_index": 2, "field_name": "not_a_line_target"},
            {"axis_index": 3, "field_name": "unit"},
        ]
    )

    mapping = instructor_poc._validated_record_field_mapping(
        output,
        field_axis_count=4,
    )

    assert mapping == RecordFieldMapping(
        field_axis_count=4,
        bindings=[
            RecordFieldBinding(axis_index=1, field_name="quantity"),
            RecordFieldBinding(axis_index=3, field_name="unit"),
        ],
    )


def test_record_kind_mapping_rejects_cross_axis_citations_and_invalid_remaps() -> None:
    messages = instructor_poc._base_messages(
        role="record_kind_mapping",
        payload={
            "allowed_field_names": ["product_code", "quantity", "unit"],
            "candidates": [
                {
                    "axis_index": 1,
                    "fields": [
                        {
                            "evidence_id": "t:r1:c0",
                            "current_field_name": "product_code",
                            "value": "SKU-1",
                        }
                    ],
                },
                {
                    "axis_index": 2,
                    "fields": [
                        {
                            "evidence_id": "t:r2:c0",
                            "current_field_name": "product_code",
                            "value": "SKU-2",
                        }
                    ],
                },
            ],
        },
    )
    output = instructor_poc._RecordKindMappingOutput.model_validate(
        {
            "decisions": [
                {
                    "axis_index": 1,
                    "record_kind": "product",
                    "citations": ["t:r1:c0"],
                    "field_remaps": [
                        {"evidence_id": "t:r1:c0", "field_name": "unit"}
                    ],
                },
                {
                    "axis_index": 2,
                    "record_kind": "narrative",
                    "citations": ["t:r1:c0"],
                    "field_remaps": [],
                },
                {
                    "axis_index": 3,
                    "record_kind": "total",
                    "citations": ["t:r2:c0"],
                    "field_remaps": [],
                },
                {
                    "axis_index": 2,
                    "record_kind": "product",
                    "citations": ["t:r2:c0"],
                    "field_remaps": [
                        {
                            "evidence_id": "t:r2:c0",
                            "field_name": "not_allowed",
                        }
                    ],
                },
            ]
        }
    )

    mapping = instructor_poc._validated_record_kind_mapping(
        output,
        messages=messages,
    )

    assert mapping == RecordKindMapping(
        decisions=[
            RecordKindDecision(
                axis_index=1,
                record_kind="product",
                citations=["t:r1:c0"],
                field_remaps=[
                    RecordCellRemap(
                        evidence_id="t:r1:c0",
                        field_name="unit",
                    )
                ],
            ),
            RecordKindDecision(
                axis_index=2,
                record_kind="product",
                citations=["t:r2:c0"],
            ),
        ]
    )


def test_long_record_mapping_payload_is_bounded_by_field_axis() -> None:
    rows = [
        [f"header-{column}" for column in range(80)],
        *[
            [f"record-{row}-column-{column}-{'x' * 120}" for column in range(80)]
            for row in range(1, 6)
        ],
    ]
    table = EvidenceTable(
        table_id="p1:t0",
        rows=rows,
        cells=[],
        bbox=_BBOX,
    )
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="rows",
        start=1,
        end=5,
        intent="records",
    )

    payload = instructor_poc._long_record_mapping_payload(
        table,
        segment,
        document_type="order",
    )

    samples = payload["field_axis_samples"]
    assert "sample_axes" not in payload
    assert "field_definitions" not in payload
    assert len(samples) == 16
    assert all(1 <= len(item["examples"]) <= 2 for item in samples)
    assert all(len(example) <= 64 for item in samples for example in item["examples"])
    assert len(json.dumps(payload, ensure_ascii=False)) < 10_000


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("intent", "expected_property", "forbidden_property"),
    [
        ("metadata", "facts", "records"),
        ("layout", "facts", "records"),
        ("records", "records", "facts"),
    ],
)
async def test_prompted_segment_transport_exposes_only_intended_schema_branch(
    intent: str,
    expected_property: str,
    forbidden_property: str,
) -> None:
    class CapturingStructuredClient:
        output_schema_properties: set[str]

        async def run(self, output_type, **_kwargs):
            self.output_schema_properties = set(
                output_type.model_json_schema()["properties"]
            )
            output = (
                output_type(
                    records=[
                        {
                            "fields": [
                                {
                                    "name": "product_code",
                                    "value": "SKU-1",
                                    "citations": ["p1:t0:r1:c1"],
                                }
                            ]
                        }
                    ]
                )
                if intent == "records"
                else output_type(
                    facts=[
                        {
                            "name": "company",
                            "value": "Acme Cable",
                            "citations": ["p1:t0:r0:c1"],
                        }
                    ]
                )
            )
            return type("StructuredRun", (), {"output": output})()

    client = CapturingStructuredClient()
    transport = instructor_poc._PromptedOutputTransport(client, model="local")

    result = await transport.create(
        SegmentExtraction,
        messages=[
            {"role": "system", "content": "extract"},
            {
                "role": "user",
                "content": json.dumps(
                    {"task": "segment_extraction", "evidence": {"intent": intent}}
                ),
            },
        ],
        max_retries=2,
    )

    assert expected_property in client.output_schema_properties
    assert forbidden_property not in client.output_schema_properties
    assert bool(result.records) is (intent == "records")
    assert bool(result.facts) is (intent != "records")


def test_segment_proposals_are_strictly_accepted_per_item() -> None:
    response = SegmentExtraction(
        facts=[
            {
                "name": "company",
                "value": "Acme Cable",
                "citations": ["p1:t0:r0:c1"],
            },
            {"name": "company", "value": "Acme Cable", "citations": []},
        ],
        records=[
            {
                "fields": [
                    {
                        "name": "product_code",
                        "value": "SKU-1",
                        "citations": ["p1:t0:r1:c1"],
                    },
                    {"name": "quantity", "value": "", "citations": []},
                ]
            }
        ],
    )
    issues: list[str] = []

    facts = instructor_poc._strict_segment_fact_proposals(
        response.facts,
        segment_id="segment-facts",
        issues=issues,
    )
    records = instructor_poc._strict_segment_record_proposals(
        response.records,
        segment_id="segment-records",
        issues=issues,
    )

    assert [(fact.name, fact.value) for fact in facts] == [("company", "Acme Cable")]
    assert [[field.name for field in record.fields] for record in records] == [
        ["product_code"]
    ]
    assert any("segment-facts:1" in issue for issue in issues)
    assert any("segment-records:record:0:1" in issue for issue in issues)


def _intent(*, complete_table_partition: bool = True) -> DocumentIntent:
    segments = (
        [TableSegmentIntent(start=0, end=2, intent="records")]
        if complete_table_partition
        else [TableSegmentIntent(start=0, end=1, intent="records")]
    )
    return DocumentIntent(
        document_intent="purchase_order",
        document_facts=[
            ProposedFact(
                name="order_number",
                value="PO-1",
                citations=["p1:b0"],
            )
        ],
        tables=[TableIntent(table_id="p1:t0", orientation="rows", segments=segments)],
    )


def test_local_partition_gate_rejects_overlapping_table_segments() -> None:
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id="p1:t0",
                orientation="rows",
                segments=[
                    TableSegmentIntent(start=0, end=0, intent="metadata"),
                    TableSegmentIntent(start=0, end=2, intent="records"),
                ],
            )
        ],
    )
    issues: list[str] = []

    segments = _validate_intent_partition(
        intent,
        _table_index(_evidence()),
        issues,
    )

    assert segments == []
    assert "overlapping_segments:p1:t0:0:2" in issues


def _orientation_evidence(rows: list[list[str]]) -> DocumentEvidence:
    evidence = _evidence().model_copy(deep=True)
    table = evidence.pages[0].tables[0]
    table.rows = rows
    table.cells = [
        EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]
    return evidence


def _use_inconclusive_record_regions(
    monkeypatch: pytest.MonkeyPatch,
    table_id: str,
) -> None:
    monkeypatch.setattr(
        instructor_poc,
        "assess_record_regions",
        lambda _evidence: RecordRegionAssessment(
            status="inconclusive",
            assessed_table_ids=[table_id],
            inconclusive_table_ids=[table_id],
        ),
    )


def test_orientation_score_prefers_rows_for_horizontal_business_header(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence(
        [
            ["Product Code", "Product Name", "Quantity"],
            ["SKU-A", "Cable", "10"],
            ["SKU-B", "Adapter", "20"],
        ]
    )
    table_id = evidence.pages[0].tables[0].table_id
    _use_inconclusive_record_regions(monkeypatch, table_id)
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table_id,
                orientation="columns",
                segments=[TableSegmentIntent(start=0, end=2, intent="records")],
            )
        ],
    )

    normalized = instructor_poc._normalize_intent_partition(
        intent,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables[0].orientation == "rows"
    assert [
        (segment.start, segment.end, segment.intent)
        for segment in normalized.tables[0].segments
    ] == [(0, 0, "layout"), (1, 2, "records")]


def test_orientation_score_excludes_order_metadata_totals_and_notes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence(
        [
            ["Supplier: ACME", "", "", "", "Order date: 2026-08-01", ""],
            ["Payment: net 30", "", "", "", "Delivery: 2026-08-10", ""],
            ["No", "Model", "Name", "Quantity", "Amount", "Remark"],
            ["1", "HAM-1", "Cable 1.5M", "10", "27", "first"],
            ["2", "HAM-2", "Cable 3M", "20", "76", "second"],
            ["3", "HAM-3", "Cable 5M", "30", "174", "third"],
            ["", "", "", "60", "277", ""],
            ["Product requirement", "", "", "", "", ""],
            ["Confirm packaging before shipment", "", "", "", "", ""],
        ]
    )
    table_id = evidence.pages[0].tables[0].table_id
    _use_inconclusive_record_regions(monkeypatch, table_id)
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table_id,
                orientation="columns",
                segments=[TableSegmentIntent(start=0, end=5, intent="records")],
            )
        ],
    )

    normalized = instructor_poc._normalize_intent_partition(
        intent,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables[0].orientation == "rows"
    assert [
        (segment.start, segment.end, segment.intent)
        for segment in normalized.tables[0].segments
    ] == [
        (0, 2, "layout"),
        (3, 5, "records"),
        (6, 8, "layout"),
    ]

    recovery_issues: list[str] = []
    recovered = instructor_poc._normalize_intent_partition(
        DocumentIntent(document_intent="order"),
        _table_index(evidence),
        evidence,
        issues=recovery_issues,
        complete_missing=True,
    )
    assert recovered.tables == normalized.tables
    assert recovery_issues == [f"intent_partition_geometry_repaired:{table_id}"]


def test_compact_classification_payload_keeps_geometry_and_respects_budget() -> None:
    evidence = _orientation_evidence(
        [
            ["No", "Model", "Name", "Quantity", "Amount", "Remark"],
            *[
                [
                    str(index),
                    f"MODEL-{index}",
                    "Long product description " * 20,
                    str(index * 10),
                    str(index * 25),
                    "General note " * 20,
                ]
                for index in range(1, 40)
            ],
        ]
    )

    payload = instructor_poc._classification_evidence_payload(
        evidence,
        max_payload_chars=3_200,
    )
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

    assert len(encoded) <= 3_200
    assert "title_region_text" in payload
    assert payload["tables"][0]["table_id"] == "p1:t0"
    assert payload["tables"][0]["row_count"] == 40
    sampled_rows = payload["tables"][0]["sample_rows"]
    assert sampled_rows[0]["row"] == 0
    assert [cell["value"] for cell in sampled_rows[0]["cells"]] == [
        "No",
        "Model",
        "Name",
        "Quantity",
        "Amount",
        "Remark",
    ]

    compact_payload, messages = instructor_poc._compact_classification_messages(
        evidence,
        max_input_chars=5_000,
        semantic_execution=None,
    )
    assert instructor_poc._prompt_size(messages) <= 5_000
    assert compact_payload["document_type_definitions"] == (
        instructor_poc._DOCUMENT_TYPE_DEFINITIONS
    )
    assert compact_payload["document_subtype_definitions"] == (
        instructor_poc._DOCUMENT_SUBTYPE_DEFINITIONS
    )
    assert "bill_of_materials" in compact_payload["allowed_document_subtypes"]
    assert (
        instructor_poc._ROUTE_DOCUMENT_SUBTYPE_TYPES["bill_of_materials"]
        == "technical_document"
    )
    assert "bill_of_materials" in instructor_poc.OPEN_DOMAIN_DOCUMENT_SUBTYPES


def test_orientation_score_prefers_columns_for_vertical_business_labels(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence(
        [
            ["Product Code", "SKU-A", "SKU-B"],
            ["Product Name", "Cable", "Adapter"],
            ["Quantity", "10", "20"],
        ]
    )
    table_id = evidence.pages[0].tables[0].table_id
    _use_inconclusive_record_regions(monkeypatch, table_id)
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table_id,
                orientation="rows",
                segments=[TableSegmentIntent(start=0, end=2, intent="records")],
            )
        ],
    )

    normalized = instructor_poc._normalize_intent_partition(
        intent,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables[0].orientation == "columns"
    assert [
        (segment.start, segment.end, segment.intent)
        for segment in normalized.tables[0].segments
    ] == [(0, 0, "layout"), (1, 2, "records")]


def test_partition_repair_clamps_and_merges_same_intent_overlap() -> None:
    table = EvidenceTable(
        table_id="repair",
        rows=[[str(index)] for index in range(5)],
    )

    repaired = instructor_poc._repair_axis_partition(
        table,
        "rows",
        [
            TableSegmentIntent(start=0, end=3, intent="records"),
            TableSegmentIntent(start=2, end=8, intent="records"),
        ],
    )

    assert repaired.geometry_changed is True
    assert repaired.ambiguity_changed is False
    assert [
        (segment.start, segment.end, segment.intent) for segment in repaired.segments
    ] == [(0, 4, "records")]


def test_partition_repair_never_expands_records_into_conflicts_or_gaps() -> None:
    table = EvidenceTable(
        table_id="repair",
        rows=[[str(index)] for index in range(5)],
    )

    repaired = instructor_poc._repair_axis_partition(
        table,
        "rows",
        [
            TableSegmentIntent(start=1, end=3, intent="records"),
            TableSegmentIntent(start=3, end=4, intent="layout"),
        ],
    )

    assert repaired.ambiguity_changed is True
    assert [
        (segment.start, segment.end, segment.intent) for segment in repaired.segments
    ] == [
        (0, 0, "metadata"),
        (1, 2, "records"),
        (3, 3, "metadata"),
        (4, 4, "layout"),
    ]


def test_partition_completion_fills_missing_table_without_inventing_records(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence([["Label", "Value"], ["Order", "PO-1"]])
    table_id = evidence.pages[0].tables[0].table_id
    _use_inconclusive_record_regions(monkeypatch, table_id)
    issues: list[str] = []

    incomplete = instructor_poc._normalize_intent_partition(
        DocumentIntent(document_intent="order"),
        _table_index(evidence),
        evidence,
    )
    completed = instructor_poc._normalize_intent_partition(
        DocumentIntent(document_intent="order"),
        _table_index(evidence),
        evidence,
        issues=issues,
        complete_missing=True,
    )

    assert incomplete.tables == []
    assert completed.tables == [
        TableIntent(
            table_id=table_id,
            orientation="rows",
            segments=[TableSegmentIntent(start=0, end=1, intent="metadata")],
        )
    ]
    assert issues == [f"intent_partition_ambiguity_repaired:{table_id}"]


def test_orientation_score_preserves_model_advice_when_labels_are_ambiguous(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence(
        [
            ["Product Code", "Product Name", "Quantity"],
            ["Product Name", "Cable", "Adapter"],
            ["Quantity", "10", "20"],
        ]
    )
    table_id = evidence.pages[0].tables[0].table_id
    _use_inconclusive_record_regions(monkeypatch, table_id)
    proposed = TableIntent(
        table_id=table_id,
        orientation="columns",
        segments=[TableSegmentIntent(start=0, end=2, intent="records")],
    )
    intent = DocumentIntent(document_intent="order", tables=[proposed])

    normalized = instructor_poc._normalize_intent_partition(
        intent,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables[0] == proposed


def test_orientation_score_does_not_override_single_deterministic_direction(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    evidence = _orientation_evidence(
        [
            ["Product Code", "SKU-A", "SKU-B"],
            ["Product Name", "Cable", "Adapter"],
            ["Quantity", "10", "20"],
        ]
    )
    table_id = evidence.pages[0].tables[0].table_id
    monkeypatch.setattr(
        instructor_poc,
        "assess_record_regions",
        lambda _evidence: RecordRegionAssessment(
            status="complete",
            assessed_table_ids=[table_id],
            record_regions=[
                EvidenceRecordRegion(
                    region_id=record_region_id(table_id, "rows", 1, 2),
                    table_id=table_id,
                    orientation="rows",
                    data_start=1,
                    data_end=2,
                    boundary_evidence_ids=[
                        f"{table_id}:r1:c0",
                        f"{table_id}:r2:c2",
                    ],
                )
            ],
        ),
    )
    intent = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table_id,
                orientation="columns",
                segments=[TableSegmentIntent(start=0, end=2, intent="records")],
            )
        ],
    )

    normalized = instructor_poc._normalize_intent_partition(
        intent,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables[0].orientation == "rows"
    assert [
        (segment.start, segment.end, segment.intent)
        for segment in normalized.tables[0].segments
    ] == [(0, 0, "layout"), (1, 2, "records")]


@pytest.mark.asyncio
async def test_poc_extracts_document_and_segment_with_typed_evidence() -> None:
    class ValidClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            if response_model is RecordFieldMapping:
                self.calls.append((response_model, messages, max_retries))
                return _three_column_mapping()
            if response_model is SegmentExtraction:
                request = json.loads(messages[1]["content"])
                payload = request["evidence"]
                result = SegmentExtraction(
                    table_id="untrusted-table-echo",
                    segment_id="untrusted-segment-echo",
                    records=[]
                    if payload["intent"] != "records"
                    else [
                        ProposedRecord(
                            fields=[
                                ProposedFact(
                                    name="product_code",
                                    value="SKU-1",
                                    citations=["p1:t0:r1:c1"],
                                )
                            ]
                        )
                    ],
                )
                self.calls.append((response_model, messages, max_retries))
                return result
            return await super().create(
                response_model, messages=messages, max_retries=max_retries
            )

    client = ValidClient([_intent()])
    result = await MinerUInstructorExtractor(client=client).extract(_evidence())

    assert result.complete is True
    record_segment = next(item for item in result.segments if item.intent == "records")
    assert record_segment.table_id == "p1:t0"
    assert record_segment.segment_id.startswith("mineru-instructor-")
    assert result.document_facts[0].evidence_refs[0].source_ref.page == 1
    assert [field.value for field in record_segment.records[0].fields] == [
        "1",
        "SKU-1",
        "2",
    ]
    assert "p1:t0:r2:c2" not in {item.evidence_id for item in result.unmapped_evidence}
    assert {item.evidence_id for item in result.schema_evidence} == {
        "p1:t0:r0:c0",
        "p1:t0:r0:c1",
        "p1:t0:r0:c2",
    }
    assert result.semantic_accounting_ratio == 1.0
    assert result.retained_evidence_ratio == 1.0
    assert result.retained_complete is True
    assert any(call[0] is RecordFieldMapping for call in client.calls)


@pytest.mark.asyncio
async def test_poc_rejects_one_bad_field_without_losing_valid_rows() -> None:
    class PartiallyInvalidClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            if response_model is RecordFieldMapping:
                self.calls.append((response_model, messages, max_retries))
                return _three_column_mapping()
            if response_model is SegmentExtraction:
                self.calls.append((response_model, messages, max_retries))
                return SegmentExtraction(
                    facts=[
                        ProposedFact(
                            name="version",
                            value="fabricated version",
                            citations=["p1:t1:r1:c1"],
                        )
                    ]
                )
            return await super().create(
                response_model,
                messages=messages,
                max_retries=max_retries,
            )

    evidence = _evidence().model_copy(deep=True)
    evidence.pages[0].tables.append(
        EvidenceTable(
            table_id="p1:t1",
            rows=[["Label", "Value"], ["Version", "A"]],
            cells=[
                EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
                for row, values in enumerate([["Label", "Value"], ["Version", "A"]])
                for column, value in enumerate(values)
            ],
            bbox=_BBOX,
        )
    )
    intent = _intent().model_copy(
        update={
            "tables": [
                *_intent().tables,
                TableIntent(
                    table_id="p1:t1",
                    orientation="rows",
                    segments=[TableSegmentIntent(start=0, end=1, intent="metadata")],
                ),
            ]
        },
        deep=True,
    )
    result = await MinerUInstructorExtractor(
        client=PartiallyInvalidClient([intent])
    ).extract(evidence)

    record_segment = next(item for item in result.segments if item.intent == "records")
    assert result.complete is True
    assert len(record_segment.records) == 2
    assert [
        next(field.value for field in record.fields if field.name == "product_code")
        for record in record_segment.records
    ] == ["SKU-1", "SKU-2"]
    assert not any(
        fact.name == "version" for segment in result.segments for fact in segment.facts
    )
    assert "unsupported_evidence_ref:version:p1:t1:r1:c1" in result.issues


@pytest.mark.asyncio
async def test_long_record_segment_uses_source_headers_and_projects_all_25_rows() -> (
    None
):
    class LongTableClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentIntent:
                return _long_table_intent().model_copy(
                    update={"document_intent": "technical_document"}
                )
            if response_model is SegmentExtraction:
                return SegmentExtraction()
            if response_model is RecordKindMapping:
                return _product_record_kind_mapping(messages)
            assert response_model is RecordFieldMapping
            return RecordFieldMapping(
                field_axis_count=3,
                bindings=[
                    RecordFieldBinding(axis_index=0, field_name="line_no"),
                    RecordFieldBinding(axis_index=1, field_name="product_code"),
                    RecordFieldBinding(axis_index=2, field_name="quantity"),
                ],
            )

    client = LongTableClient([])
    result = await MinerUInstructorExtractor(client=client).extract(
        _long_table_evidence()
    )

    record_segment = next(
        segment for segment in result.segments if segment.intent == "records"
    )
    assert len(record_segment.records) == 25
    assert [field.name for field in record_segment.records[0].fields] == [
        "line_no",
        "product_code",
        "quantity",
    ]
    references = {
        reference.evidence_id
        for record in record_segment.records
        for field in record.fields
        for reference in field.evidence_refs
    }
    assert references == {
        f"p1:t0:r{row}:c{column}" for row in range(1, 26) for column in range(3)
    }
    mapping_calls = [call for call in client.calls if call[0] is RecordFieldMapping]
    assert len(mapping_calls) == 1
    mapping_payload = json.loads(mapping_calls[0][1][1]["content"])["evidence"]
    assert mapping_payload["document_type"] == "technical_document"
    assert "product_code" in mapping_payload["allowed_field_names"]
    assert result.segment_calls == 1
    assert result.record_kind_calls == 1
    assert all(
        max_retries == 0
        for response_model, _messages, max_retries in client.calls
        if response_model is RecordKindMapping
    )


def _native_spreadsheet_evidence(
    tables: list[EvidenceTable],
) -> DocumentEvidence:
    source_cell = next(
        cell
        for table in tables
        for cell in table.cells
        if cell.text not in (None, "")
    )
    source_extra = source_cell.model_extra or {}
    source_sheet = str(source_extra.get("sheet") or tables[0].table_id)
    source_coordinate = str(source_extra.get("cell") or "A1")
    source_quote = str(source_cell.text)
    return DocumentEvidence(
        backend="spreadsheet-envelope",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=3_000,
                coordinate_space="unknown",
                blocks=[],
                tables=tables,
            )
        ],
        raw={
            "source_filename": "native.xlsx",
            "native_classification": {
                "schema_version": "m1.native-classification.v1",
                "source": "spreadsheet-tabular-v1",
                "document_type": "order",
                "document_subtype": "customer_purchase_order",
                "authority": "native_content",
                "confidence": 0.95,
                "evidence": [
                    {
                        "quote": source_quote,
                        "source_ref": {
                            "sheet": source_sheet,
                            "page": 1,
                            "cell": source_coordinate,
                            "part": (
                                f"spreadsheet/{source_sheet}/{source_coordinate}"
                            ),
                        },
                    }
                ],
            },
        },
    )


def _native_spreadsheet_table(
    *,
    table_id: str,
    rows: list[list[str | None]],
    record_axes: list[int],
) -> EvidenceTable:
    columns = ("A", "B", "C")
    cells = [
        EvidenceCell(
            row=row_index,
            column=column_index,
            text=value,
            bbox=_BBOX,
            sheet=table_id,
            cell=f"{columns[column_index]}{row_index + 1}",
            source_row=row_index + 1,
            source_column=column_index + 1,
            formula=(
                "=A2"
                if row_index == 1 and column_index == 1 and table_id == "Scale"
                else None
            ),
        )
        for row_index, row in enumerate(rows)
        for column_index, value in enumerate(row)
        if value is not None
    ]
    return EvidenceTable(
        table_id=table_id,
        rows=rows,
        cells=cells,
        bbox=_BBOX,
        source="spreadsheet-envelope",
        native_record_layout={
            "source": "spreadsheet-tabular-v1",
            "orientation": "rows",
            "header_axes": [0],
            "record_axes": record_axes,
            "document_type": "order",
            "document_subtype": "customer_purchase_order",
        },
    )


@pytest.mark.asyncio
async def test_record_kind_mapping_classifies_every_axis_and_remaps_same_axis() -> None:
    table = _native_spreadsheet_table(
        table_id="Kinds",
        rows=[
            ["line_no", "product_code", "quantity"],
            ["1", "SKU-1", "10"],
            ["note", "ship before noon", None],
            ["TOTAL", None, "10"],
        ],
        record_axes=[1, 2, 3],
    )

    class KindClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is RecordFieldMapping:
                return RecordFieldMapping(
                    field_axis_count=3,
                    bindings=[
                        RecordFieldBinding(axis_index=0, field_name="line_no"),
                        RecordFieldBinding(axis_index=1, field_name="product_code"),
                        RecordFieldBinding(axis_index=2, field_name="quantity"),
                    ],
                )
            assert response_model is RecordKindMapping
            payload = json.loads(messages[1]["content"])["evidence"]
            candidates = {item["axis_index"]: item for item in payload["candidates"]}

            def evidence_id(axis: int, field_index: int) -> str:
                return candidates[axis]["fields"][field_index]["evidence_id"]

            return RecordKindMapping(
                decisions=[
                    RecordKindDecision(
                        axis_index=1,
                        record_kind="product",
                        citations=[evidence_id(1, 1)],
                    ),
                    RecordKindDecision(
                        axis_index=2,
                        record_kind="narrative",
                        citations=[evidence_id(2, 1)],
                        field_remaps=[
                            RecordCellRemap(
                                evidence_id=evidence_id(2, 0),
                                field_name="remark",
                            ),
                            RecordCellRemap(
                                evidence_id=evidence_id(2, 1),
                                field_name="packaging_requirements",
                            ),
                        ],
                    ),
                    RecordKindDecision(
                        axis_index=3,
                        record_kind="total",
                        citations=[evidence_id(3, 0)],
                    ),
                ]
            )

    result = await MinerUInstructorExtractor(
        client=KindClient([]),
        compact_intent=True,
    ).extract(_native_spreadsheet_evidence([table]))

    records = next(segment.records for segment in result.segments if segment.records)
    assert [record.record_kind for record in records] == [
        "product",
        "narrative",
        "total",
    ]
    assert all(record.record_kind_source == "model" for record in records)
    assert all(record.record_kind_evidence_refs for record in records)
    assert [field.name for field in records[1].fields] == [
        "remark",
        "packaging_requirements",
    ]
    assert all(
        field.mapping_source == "record_kind_model_remap"
        for field in records[1].fields
    )
    assert result.segment_calls == 1
    assert result.record_kind_calls == 1


@pytest.mark.asyncio
async def test_record_kind_mapping_retries_only_omitted_axes_once() -> None:
    table = _native_spreadsheet_table(
        table_id="Kinds",
        rows=[
            ["line_no", "product_code", "quantity"],
            ["1", "SKU-1", "10"],
            ["2", "SKU-2", "20"],
        ],
        record_axes=[1, 2],
    )

    class IncompleteKindClient(_Client):
        kind_calls = 0

        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is RecordFieldMapping:
                return RecordFieldMapping(
                    field_axis_count=3,
                    bindings=[
                        RecordFieldBinding(axis_index=0, field_name="line_no"),
                        RecordFieldBinding(axis_index=1, field_name="product_code"),
                        RecordFieldBinding(axis_index=2, field_name="quantity"),
                    ],
                )
            assert response_model is RecordKindMapping
            self.kind_calls += 1
            complete = _product_record_kind_mapping(messages)
            if self.kind_calls == 1:
                return complete.model_copy(update={"decisions": complete.decisions[:1]})
            payload = json.loads(messages[1]["content"])["evidence"]
            assert payload["correction"] == "classify every previously omitted axis"
            assert [item["axis_index"] for item in payload["candidates"]] == [2]
            return complete

    client = IncompleteKindClient([])
    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(_native_spreadsheet_evidence([table]))

    records = next(segment.records for segment in result.segments if segment.records)
    assert [record.record_kind for record in records] == ["product", "product"]
    assert result.record_kind_calls == 2
    assert not any(
        issue.startswith("record_kind_mapping_incomplete:")
        for issue in result.issues
    )


def test_record_context_inheritance_requires_identity_or_surrounding_consensus() -> None:
    def fact(name: str, value: str, axis: int, column: int) -> ExtractedFact:
        evidence_id = f"Kinds:r{axis}:c{column}"
        return ExtractedFact(
            name=name,
            value=value,
            evidence_refs=[
                EvidenceReference(
                    evidence_id=evidence_id,
                    quote=value,
                    source_ref=SourceReference(
                        page=1,
                        sheet="Kinds",
                        cell=f"{chr(65 + column)}{axis + 1}",
                        part=f"spreadsheet/Kinds/{evidence_id}",
                    ),
                )
            ],
        )

    def product(axis: int, fields: list[ExtractedFact]) -> ExtractedRecord:
        return ExtractedRecord(
            fields=fields,
            record_kind="product",
            record_kind_evidence_refs=[fields[0].evidence_refs[0]],
            record_kind_source="model",
            record_axis=axis,
        )

    shared_identity = [
        product(
            1,
            [
                fact("product_code", "SKU-1", 1, 0),
                fact("name_raw", "Cable", 1, 1),
                fact("quantity", "10", 1, 2),
                fact("unit", "PCS", 1, 3),
            ],
        ),
        product(
            2,
            [
                fact("product_code", "SKU-1", 2, 0),
                fact("quantity", "20", 2, 2),
            ],
        ),
    ]
    issues: list[str] = []

    inherited = _inherit_record_context(
        shared_identity,
        document_type="order",
        table_id="Kinds",
        issues=issues,
    )

    inherited_fields = {field.name: field for field in inherited[1].fields}
    assert inherited_fields["unit"].value == "PCS"
    assert inherited_fields["unit"].inferred is True
    assert inherited_fields["unit"].inference_source == "shared_identity_record_group"
    assert inherited_fields["name_raw"].value == "Cable"
    assert len(issues) == 2

    different_identity = [
        shared_identity[0],
        product(
            2,
            [
                fact("product_code", "SKU-2", 2, 0),
                fact("quantity", "20", 2, 2),
            ],
        ),
    ]
    untouched = _inherit_record_context(
        different_identity,
        document_type="order",
        table_id="Kinds",
        issues=[],
    )
    assert {field.name for field in untouched[1].fields} == {
        "product_code",
        "quantity",
    }


def test_bounded_record_kind_evidence_keeps_each_record_represented() -> None:
    def reference(evidence_id: str) -> EvidenceReference:
        return EvidenceReference(
            evidence_id=evidence_id,
            quote=evidence_id,
            source_ref=SourceReference(
                page=1,
                part=f"mineru/{evidence_id}",
                bbox=[1.0, 2.0, 3.0, 4.0],
                coordinate_space="normalized",
            ),
        )

    first_refs = [reference(f"first-{index}") for index in range(12)]
    second_ref = reference("second-0")
    records = [
        ExtractedRecord(
            fields=[
                ExtractedFact(
                    name="product_code",
                    value="SKU-1",
                    evidence_refs=[first_refs[0]],
                )
            ],
            record_kind="product",
            record_kind_evidence_refs=first_refs,
            record_kind_source="model",
        ),
        ExtractedRecord(
            fields=[
                ExtractedFact(
                    name="product_code",
                    value="SKU-1",
                    evidence_refs=[second_ref],
                )
            ],
            record_kind="narrative",
            record_kind_evidence_refs=[second_ref],
            record_kind_source="model",
        ),
    ]

    retained = _bounded_record_kind_evidence(records)

    assert len(retained) == 12
    assert retained[0].evidence_id == "first-0"
    assert retained[1].evidence_id == "second-0"


def test_native_spreadsheet_layout_is_a_hard_axis_contract(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    table = _native_spreadsheet_table(
        table_id="Native",
        rows=[
            ["line_no", "product_code", "quantity"],
            [None, None, None],
            ["1", "SKU-1", "10"],
            ["subtotal", None, "10"],
            ["2", "SKU-2", "20"],
        ],
        record_axes=[2, 4],
    )
    evidence = _native_spreadsheet_evidence([table])
    _use_inconclusive_record_regions(monkeypatch, table.table_id)
    proposed = DocumentIntent(
        document_intent="order",
        tables=[
            TableIntent(
                table_id=table.table_id,
                orientation="columns",
                segments=[TableSegmentIntent(start=0, end=2, intent="records")],
            )
        ],
    )

    normalized = instructor_poc._normalize_intent_partition(
        proposed,
        _table_index(evidence),
        evidence,
    )

    assert normalized.tables == [
        TableIntent(
            table_id=table.table_id,
            orientation="rows",
            segments=[
                TableSegmentIntent(start=0, end=1, intent="layout"),
                TableSegmentIntent(start=2, end=2, intent="records"),
                TableSegmentIntent(start=3, end=3, intent="layout"),
                TableSegmentIntent(start=4, end=4, intent="records"),
            ],
        )
    ]


def test_invalid_native_record_axes_cannot_supply_header_mapping() -> None:
    table = _native_spreadsheet_table(
        table_id="InvalidNative",
        rows=[
            ["line_no", "product_code", "quantity"],
            ["1", "SKU-1", "10"],
        ],
        record_axes=[1],
    )
    table.model_extra["native_record_layout"]["record_axes"] = [1, 1]
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="rows",
        start=1,
        end=1,
        intent="records",
    )

    assert instructor_poc._trusted_native_record_intent(table.table_id, table) is None
    assert instructor_poc._native_record_header_labels(table, segment) == ({}, ())


def test_native_headers_are_not_applied_outside_declared_record_axes() -> None:
    table = _native_spreadsheet_table(
        table_id="BoundedNative",
        rows=[
            ["line_no", "product_code", "quantity"],
            ["layout", "not-a-record", "0"],
            ["1", "SKU-1", "10"],
        ],
        record_axes=[2],
    )
    segment = _ValidatedSegment(
        table_id=table.table_id,
        orientation="rows",
        start=1,
        end=1,
        intent="records",
    )

    assert instructor_poc._native_record_header_labels(table, segment) == ({}, ())


@pytest.mark.asyncio
async def test_open_domain_native_spreadsheet_keeps_records_without_model_mapping(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def unexpected_domain_heuristic(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("native open-domain evidence must skip typed heuristics")

    for name in (
        "_augment_geometry_tables",
        "_safe_technical_partition_fallback",
        "_select_primary_record_table_ids",
        "_refine_technical_primary_table_segments",
    ):
        monkeypatch.setattr(instructor_poc, name, unexpected_domain_heuristic)
    table = _native_spreadsheet_table(
        table_id="NativeBOM",
        rows=[
            ["材料编号", "原材料名称", "实际用量"],
            ["MAT-1", "铜线", "2.5"],
            ["MAT-2", "铝箔", "1"],
        ],
        record_axes=[1, 2],
    )
    table.model_extra["native_record_layout"].update(
        {
            "document_type": "technical_document",
            "document_subtype": "bill_of_materials",
        }
    )
    evidence = _native_spreadsheet_evidence([table])
    evidence.raw["native_classification"].update(
        {
            "document_type": "technical_document",
            "document_subtype": "bill_of_materials",
        }
    )
    client = _Client([])

    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(evidence)

    record_segments = [
        segment for segment in result.segments if segment.intent == "records"
    ]
    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "bill_of_materials"
    assert len(record_segments) == 1
    assert record_segments[0].records == []
    assert result.segment_calls == 0
    assert client.calls == []
    assert result.schema_evidence == []
    assert result.unmapped_evidence == []
    assert result.semantic_accounting_ratio == 1.0
    assert result.retained_evidence_ratio == 1.0


@pytest.mark.asyncio
async def test_native_spreadsheet_reuses_one_mapping_for_100_record_segments() -> None:
    rows: list[list[str | None]] = [["line_no", "product_code", "quantity"]]
    record_axes: list[int] = []
    for row_index in range(1, 3_000):
        if row_index % 30 == 0:
            rows.append([None, None, None])
            continue
        record_axes.append(row_index)
        rows.append([str(row_index), f"SKU-{row_index}", str(row_index * 2)])
    evidence = _native_spreadsheet_evidence(
        [
            _native_spreadsheet_table(
                table_id="Scale",
                rows=rows,
                record_axes=record_axes,
            )
        ]
    )

    class MappingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is RecordKindMapping:
                return _product_record_kind_mapping(messages)
            assert response_model is RecordFieldMapping
            return RecordFieldMapping(
                field_axis_count=instructor_poc._record_field_axis_count(messages),
                bindings=[],
            )

    client = MappingClient([])
    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(evidence)

    record_segments = [segment for segment in result.segments if segment.records]
    assert len(record_segments) == 100
    assert sum(len(segment.records) for segment in record_segments) == len(record_axes)
    assert client.calls[0][0] is RecordFieldMapping
    assert all(call[0] is RecordKindMapping for call in client.calls[1:])
    assert client.calls[0][2] == 1
    assert result.segment_calls == 1
    assert result.record_kind_calls == 7
    assert result.retained_complete is True
    assert result.retained_evidence_ratio == 1.0
    first_record = record_segments[0].records[0]
    product = next(
        field for field in first_record.fields if field.name == "product_code"
    )
    assert product.evidence_refs[0].source_ref.sheet == "Scale"
    assert product.evidence_refs[0].source_ref.cell == "B2"
    formula_cell = next(
        cell
        for cell in evidence.pages[0].tables[0].cells
        if cell.row == 1 and cell.column == 1
    )
    assert formula_cell.model_extra["formula"] == "=A2"


@pytest.mark.asyncio
async def test_model_request_hard_cap_applies_without_semantic_execution() -> None:
    tables = [
        _native_spreadsheet_table(
            table_id=f"Sheet{index}",
            rows=[
                [f"line_{index}", f"code_{index}", f"quantity_{index}"],
                [str(index), f"SKU-{index}", str(index + 1)],
            ],
            record_axes=[1],
        )
        for index in range(10)
    ]

    class MappingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            assert response_model is RecordFieldMapping
            return RecordFieldMapping(
                field_axis_count=instructor_poc._record_field_axis_count(messages),
                bindings=[],
            )

    client = MappingClient([])
    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(_native_spreadsheet_evidence(tables))

    assert len(client.calls) == 8
    assert all(call[0] is RecordFieldMapping for call in client.calls)
    assert all(call[2] == 1 for call in client.calls)
    assert result.segment_calls == 8
    assert result.retained_complete is True
    assert result.retained_evidence_ratio == 1.0
    budget_issue = next(
        issue
        for issue in result.issues
        if issue.startswith("model_request_budget_exhausted:limit=8:")
    )
    assert "long_record_field_mapping=2" in budget_issue
    assert "record_kind_mapping=10" in budget_issue
    assert result.complete is True


@pytest.mark.asyncio
async def test_long_record_source_headers_avoid_model_failure_without_losing_rows() -> (
    None
):
    class FailingMappingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentIntent:
                return _long_table_intent().model_copy(
                    update={"document_intent": "technical_document"}
                )
            if response_model is SegmentExtraction:
                return SegmentExtraction()
            assert response_model is RecordFieldMapping
            raise TimeoutError("model unavailable")

    client = FailingMappingClient([])
    result = await MinerUInstructorExtractor(client=client).extract(
        _long_table_evidence()
    )

    record_segment = next(
        segment for segment in result.segments if segment.intent == "records"
    )
    assert len(record_segment.records) == 25
    assert [field.name for field in record_segment.records[-1].fields] == [
        "line_no",
        "product_code",
        "quantity",
    ]
    assert sum(len(record.fields) for record in record_segment.records) == 75
    assert all(
        len(field.evidence_refs) == 1
        for record in record_segment.records
        for field in record.fields
    )
    assert any(
        issue.startswith("long_record_field_mapping_fallback:")
        and issue.endswith(":TimeoutError")
        for issue in result.issues
    )
    assert result.complete is True
    retained_ids = {
        reference.evidence_id
        for references in (
            result.schema_evidence,
            result.redundant_evidence,
            result.raw_content_evidence,
            result.unmapped_evidence,
        )
        for reference in references
    }
    assert {f"p1:t0:r0:c{column}" for column in range(3)} <= retained_ids
    unmapped = {reference.evidence_id for reference in result.unmapped_evidence}
    assert not any(
        reference.startswith("p1:t0:r") and ":r0:" not in reference
        for reference in unmapped
    )


@pytest.mark.asyncio
async def test_model_failures_preserve_locally_verified_short_table_records() -> None:
    class FailingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            raise TimeoutError("model unavailable")

    result = await MinerUInstructorExtractor(client=FailingClient([])).extract(
        _evidence(),
        document_type_hint="order",
    )

    assert result.document_intent == "order"
    record_segment = next(
        segment for segment in result.segments if segment.intent == "records"
    )
    assert len(record_segment.records) == 2
    assert [field.name for field in record_segment.records[0].fields] == [
        "line_no",
        "product_code",
        "quantity",
    ]
    assert {field.value for field in record_segment.records[0].fields} == {
        "1",
        "SKU-1",
        "2",
    }
    assert "intent_model_error:TimeoutError" in result.issues
    assert not any(issue.startswith("segment_model_error:") for issue in result.issues)
    retained_ids = {
        reference.evidence_id
        for references in (
            result.schema_evidence,
            result.redundant_evidence,
            result.raw_content_evidence,
            result.unmapped_evidence,
        )
        for reference in references
    }
    assert {f"p1:t0:r0:c{column}" for column in range(3)} <= retained_ids


@pytest.mark.asyncio
@pytest.mark.parametrize("document_type_hint", ["order", "inventory"])
async def test_governed_nontechnical_type_skips_geometry_reconstruction(
    monkeypatch: pytest.MonkeyPatch,
    document_type_hint: str,
) -> None:
    class FailingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            raise TimeoutError("model unavailable")

    def unexpected_geometry(_evidence: DocumentEvidence) -> list[str]:
        raise AssertionError("governed nontechnical input must skip geometry")

    monkeypatch.setattr(
        instructor_poc,
        "_augment_geometry_tables",
        unexpected_geometry,
    )

    result = await MinerUInstructorExtractor(client=FailingClient([])).extract(
        _evidence(),
        document_type_hint=document_type_hint,
    )

    assert result.document_intent == document_type_hint
    assert any(segment.records for segment in result.segments)
    assert not any("geometry" in issue for issue in result.issues)


@pytest.mark.asyncio
async def test_unknown_model_failure_keeps_scored_bom_when_other_table_is_inconclusive() -> (
    None
):
    """A missing intent response must not discard a deterministic BOM region."""

    def table(table_id: str, rows: list[list[str]]) -> EvidenceTable:
        return EvidenceTable(
            table_id=table_id,
            rows=rows,
            cells=[
                EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
                for row, values in enumerate(rows)
                for column, value in enumerate(values)
            ],
        )

    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:title",
                        text="Drawing number D-1",
                        bbox=_BBOX,
                    )
                ],
                tables=[
                    table(
                        "p1:bom",
                        [
                            ["10", "SKU-10", "2pcs", "Copper foil"],
                            ["9", "SKU-9", "1pcs", "Type C shell"],
                        ],
                    ),
                    table(
                        "p1:ambiguous",
                        [["alpha", "beta", "gamma"], ["delta", "echo", "foxtrot"]],
                    ),
                ],
            )
        ],
    )

    class FailingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            raise TimeoutError("intent service unavailable")

    result = await MinerUInstructorExtractor(
        client=FailingClient([]),
        max_retries=0,
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.primary_record_table_ids == ["p1:bom"]
    assert "intent_model_error:TimeoutError" in result.issues
    assert "technical_partition_fallback:evidence_shape" in result.issues
    assert [
        (segment.table_id, segment.intent, len(segment.records))
        for segment in result.segments
    ] == [
        ("p1:ambiguous", "layout", 0),
        ("p1:bom", "records", 2),
    ]
    assert result.complete is False


@pytest.mark.asyncio
async def test_instructor_retry_diagnostic_is_bounded_and_redacted() -> None:
    class InstructorRetryException(RuntimeError):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args)
            self.failed_attempts = kwargs.get("failed_attempts", [])
            self.n_attempts = kwargs.get("n_attempts", 2)
            self.total_usage = kwargs.get("total_usage", 123)
            self.create_kwargs = {
                "api_key": "secret-token",
                "messages": [{"content": "customer secret"}],
            }
            self.last_completion = {"customer": "secret"}

    class Attempt:
        attempt_number = 1
        completion: ClassVar[dict[str, str]] = {"customer": "secret"}

        @staticmethod
        def _validation_error() -> ValidationError:
            try:
                DocumentClassification.model_validate(
                    {
                        "document_intent": "not-a-canonical-intent",
                        "customer": "secret customer",
                    }
                )
            except ValidationError as exc:
                return exc
            raise AssertionError("expected validation error")

        @property
        def exception(self) -> ValidationError:
            return self._validation_error()

    class FailingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            raise InstructorRetryException(
                "customer secret should not be persisted",
                failed_attempts=[Attempt(), Attempt()],
                n_attempts=2,
                total_usage=123,
            )

    result = await MinerUInstructorExtractor(
        client=FailingClient([]),
        max_retries=1,
    ).extract(_document_without_tables())

    assert "intent_model_error:InstructorRetryException" in result.issues
    assert len(result.model_diagnostics) == 1
    diagnostic = result.model_diagnostics[0]
    assert isinstance(diagnostic, ModelFailureDiagnostic)
    assert diagnostic.error_type == "InstructorRetryException"
    assert diagnostic.reason == "retry_exhausted"
    assert diagnostic.root_error_type == "ValidationError"
    assert diagnostic.attempt_count == 2
    assert diagnostic.failed_attempt_count == 2
    assert diagnostic.total_usage_tokens == 123
    assert diagnostic.validation_errors
    assert all(set(item) == {"loc", "type"} for item in diagnostic.validation_errors)
    serialized = json.dumps(
        diagnostic.model_dump(mode="json"),
        ensure_ascii=False,
    )
    assert "secret" not in serialized
    assert "customer secret" not in serialized
    assert "secret-token" not in serialized


def test_instructor_retry_diagnostic_surfaces_nested_http_status() -> None:
    request = httpx.Request("POST", "http://llm.test/v1/chat")
    response = httpx.Response(503, request=request)
    nested = httpx.HTTPStatusError(
        "provider unavailable",
        request=request,
        response=response,
    )

    class Attempt:
        attempt_number = 1
        exception = nested
        completion = None

    class InstructorRetryException(RuntimeError):
        failed_attempts: ClassVar[list[Attempt]] = [Attempt()]
        n_attempts = 1
        total_usage = 0

    diagnostic = _model_failure_diagnostic(
        stage="document_intent",
        response_model=DocumentIntent,
        exception=InstructorRetryException("provider unavailable"),
    )

    assert diagnostic.http_status == 503
    assert diagnostic.failed_attempts[0]["reason"] == "http_error"
    assert diagnostic.failed_attempts[0]["http_status"] == 503


def test_model_failure_diagnostic_hashes_untrusted_schema_and_provider_values() -> None:
    class MaliciousValidationError(RuntimeError):
        code = "api_key_sk-secret"
        type = "customer-secret"

        @staticmethod
        def errors(**_kwargs: Any) -> list[dict[str, Any]]:
            return [
                {
                    "loc": ["api_key_sk-secret", 7],
                    "type": "customer-secret",
                    "input": "document secret",
                }
            ]

    diagnostic = _model_failure_diagnostic(
        stage="document_intent",
        response_model=DocumentIntent,
        exception=MaliciousValidationError("document secret"),
    )

    assert diagnostic.provider_error_code is None
    assert diagnostic.provider_error_type is None
    assert diagnostic.validation_errors[0]["type"] == "validation_error"
    assert diagnostic.validation_errors[0]["loc"][1] == 7
    opaque_field = diagnostic.validation_errors[0]["loc"][0]
    assert isinstance(opaque_field, str)
    assert opaque_field.startswith("field#")
    assert len(opaque_field) == 18
    int(opaque_field.removeprefix("field#"), 16)
    serialized = json.dumps(diagnostic.model_dump(mode="json"))
    assert "secret" not in serialized
    assert "api_key" not in serialized


def test_model_failure_diagnostic_consumes_prompted_output_failure_metadata() -> None:
    failure = RuntimeError("response body must not be persisted")
    failure._m1_structured_attempts = 2
    failure._m1_structured_failure_code = "STRUCTURED_OUTPUT_SCHEMA_INVALID"
    failure._m1_structured_failure_reason = "unexpected_model_output"

    diagnostic = _model_failure_diagnostic(
        stage="document_intent",
        response_model=DocumentIntent,
        exception=failure,
    )

    assert diagnostic.reason == "unexpected_model_output"
    assert diagnostic.provider_error_code == "STRUCTURED_OUTPUT_SCHEMA_INVALID"
    assert diagnostic.attempt_count == 2
    assert diagnostic.failed_attempt_count == 2


@pytest.mark.asyncio
async def test_source_headers_follow_physical_cells_across_mismatched_spans() -> None:
    rows = [
        ["产品名称", "外径尺寸", "内径尺寸", "下料尺寸", None, "公差"],
        ["HDMI椭圆形铝壳", "19.03*10.8mm", "17.43*9.46mm", "21mm", "±0.05mm", None],
    ]
    evidence = DocumentEvidence(
        backend="docx-native-ooxml",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="unknown",
                tables=[
                    EvidenceTable(
                        table_id="docx:t:0",
                        rows=rows,
                        cells=[
                            EvidenceCell(row=0, column=0, text="产品名称"),
                            EvidenceCell(row=0, column=1, text="外径尺寸"),
                            EvidenceCell(row=0, column=2, text="内径尺寸"),
                            EvidenceCell(
                                row=0,
                                column=3,
                                text="下料尺寸",
                                grid_span=2,
                            ),
                            EvidenceCell(row=0, column=5, text="公差"),
                            EvidenceCell(row=1, column=0, text="HDMI椭圆形铝壳"),
                            EvidenceCell(row=1, column=1, text="19.03*10.8mm"),
                            EvidenceCell(row=1, column=2, text="17.43*9.46mm"),
                            EvidenceCell(row=1, column=3, text="21mm"),
                            EvidenceCell(
                                row=1,
                                column=4,
                                text="±0.05mm",
                                grid_span=2,
                            ),
                        ],
                    )
                ],
            )
        ],
    )

    class MappingFailureClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentIntent:
                return DocumentIntent(
                    document_intent="technical_document",
                    tables=[
                        TableIntent(
                            table_id="docx:t:0",
                            orientation="rows",
                            segments=[
                                TableSegmentIntent(start=0, end=0, intent="layout"),
                                TableSegmentIntent(start=1, end=1, intent="records"),
                            ],
                        )
                    ],
                )
            if response_model is SegmentExtraction:
                return SegmentExtraction()
            assert response_model is RecordFieldMapping
            raise TimeoutError("model unavailable")

    client = MappingFailureClient([])
    result = await MinerUInstructorExtractor(client=client).extract(evidence)

    record_segment = next(
        segment for segment in result.segments if segment.intent == "records"
    )
    assert len(record_segment.records) == 1
    assert [field.name for field in record_segment.records[0].fields] == [
        "name_raw",
        "外径尺寸",
        "内径尺寸",
        "下料尺寸",
        "公差",
    ]
    retained_ids = {
        reference.evidence_id
        for references in (
            result.schema_evidence,
            result.redundant_evidence,
            result.raw_content_evidence,
            result.unmapped_evidence,
        )
        for reference in references
    }
    assert {
        "docx:t:0:r0:c0",
        "docx:t:0:r0:c1",
        "docx:t:0:r0:c2",
        "docx:t:0:r0:c3",
        "docx:t:0:r0:c5",
    } <= retained_ids
    assert any(call[0] is RecordFieldMapping for call in client.calls)
    assert any(
        issue.startswith("long_record_field_mapping_fallback:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_failed_metadata_segment_uses_same_row_label_value_fallback() -> None:
    evidence = _inconclusive_evidence()
    table = evidence.pages[0].tables[0]
    table.rows = [
        ["Order number", "PO-7", "Order date", "2026-07-24"],
        ["Supplier: Acme Cable"],
    ]
    table.cells = [
        EvidenceCell(row=row, column=column, text=value, bbox=_BBOX)
        for row, values in enumerate(table.rows)
        for column, value in enumerate(values)
    ]

    class MetadataFailureClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentIntent:
                return DocumentIntent(
                    document_intent="purchase_order",
                    tables=[
                        TableIntent(
                            table_id="p1:t0",
                            orientation="rows",
                            segments=[
                                TableSegmentIntent(
                                    start=0,
                                    end=1,
                                    intent="metadata",
                                )
                            ],
                        )
                    ],
                )
            raise TimeoutError("metadata model unavailable")

    result = await MinerUInstructorExtractor(client=MetadataFailureClient([])).extract(
        evidence
    )

    facts = {fact.name: fact for segment in result.segments for fact in segment.facts}
    assert {name: fact.value for name, fact in facts.items()} == {
        "Order number": "PO-7",
        "Order date": "2026-07-24",
        "Supplier": "Acme Cable",
    }
    assert {
        reference.evidence_id
        for fact in facts.values()
        for reference in fact.evidence_refs
    } == {
        "p1:t0:r0:c0",
        "p1:t0:r0:c1",
        "p1:t0:r0:c2",
        "p1:t0:r0:c3",
        "p1:t0:r1:c0",
    }


def test_exact_table_block_alias_is_accounted_without_becoming_a_fact() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.bbox = _BBOX
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id="p1:b-table",
            kind="table",
            text="Item | Code | Qty | 1 | SKU-1 | 2 | 2 | SKU-2 | 3",
            bbox=_BBOX,
        )
    )

    assert _redundant_table_block_ids(evidence) == {"p1:b-table"}


def test_provider_table_block_alias_uses_item_index_and_bbox() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.bbox = _BBOX
    table.model_extra["mineru_item_index"] = 7
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id="p1:b-provider-table",
            kind="table",
            text="provider flattened representation",
            bbox=_BBOX,
            mineru_item_index=7,
        )
    )

    assert _redundant_table_block_ids(evidence) == {"p1:b-provider-table"}


def test_auxiliary_technical_table_demotion_is_not_an_incomplete_extraction() -> None:
    assert _is_blocking_issue("technical_nonprimary_record_segments_demoted") is False


def test_record_kind_correction_failure_is_nonblocking() -> None:
    assert (
        _is_blocking_issue(
            "record_kind_mapping_correction_fallback:table:TimeoutError"
        )
        is False
    )


def test_repeated_complete_consumed_lines_are_redundant_but_short_tokens_are_not() -> (
    None
):
    evidence = _document_without_tables()
    evidence.pages[0].blocks = [
        EvidenceBlock(
            block_id="p1:dimension-list",
            kind="native_text",
            text="6.65+/-0.1\n27+/-0.3",
            bbox=_BBOX,
        ),
        EvidenceBlock(
            block_id="p1:dimension-repeat",
            kind="native_text",
            text="6.65+/-0.1",
            bbox=_BBOX,
        ),
        EvidenceBlock(
            block_id="p1:short-repeat",
            kind="native_text",
            text="27",
            bbox=_BBOX,
        ),
    ]
    inventory = evidence_inventory(evidence)

    assert _redundant_consumed_block_ids(
        inventory,
        {"p1:dimension-list"},
    ) == {"p1:dimension-repeat"}


def test_record_field_mapping_rejects_out_of_bounds_and_duplicate_bindings() -> None:
    with pytest.raises(ValidationError, match="outside field_axis_count"):
        RecordFieldMapping(
            field_axis_count=3,
            bindings=[RecordFieldBinding(axis_index=3, field_name="quantity")],
        )
    with pytest.raises(ValidationError, match="duplicate field axis binding"):
        RecordFieldMapping(
            field_axis_count=3,
            bindings=[
                RecordFieldBinding(axis_index=1, field_name="product_code"),
                RecordFieldBinding(axis_index=1, field_name="quantity"),
            ],
        )


def test_record_fact_still_requires_the_complete_cited_cell_value() -> None:
    inventory = evidence_inventory(_evidence())
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="product_code",
            value="SKU",
            citations=["p1:t0:r1:c1"],
        ),
        inventory,
        allowed_ids={"p1:t0:r1:c1"},
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_evidence_ref:product_code:p1:t0:r1:c1"]


@pytest.mark.parametrize(
    ("fact_name", "value", "evidence_id", "citation"),
    [
        (
            "seller",
            "Acme Cable Limited",
            "native:word/document.xml#paragraph:3",
            "seller:native:word/document.xml#paragraph:3",
        ),
        (
            "seller",
            "Acme Cable Limited",
            "native:word/document.xml#paragraph:3",
            "$.header.seller:native:word/document.xml#paragraph:3",
        ),
        ("overall_length", "28 mm", "p1:b9", "overall_length:p1:b9"),
    ],
)
def test_fact_evidence_gate_repairs_matching_model_field_prefix(
    fact_name: str,
    value: str,
    evidence_id: str,
    citation: str,
) -> None:
    evidence = _single_block_evidence(
        f"Seller: {value}" if fact_name == "seller" else value
    )
    evidence.pages[0].blocks[0].block_id = evidence_id
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(name=fact_name, value=value, citations=[citation]),
        evidence_inventory(evidence),
        allowed_ids={evidence_id},
        issues=issues,
    )

    assert extracted is not None
    assert [reference.evidence_id for reference in extracted.evidence_refs] == [
        evidence_id
    ]
    assert consumed == {evidence_id}
    assert issues == []


def test_unlabeled_role_fact_downgrades_to_company_without_assigning_role() -> None:
    evidence = _single_block_evidence("东莞市唯格电子科技有限公司")
    evidence.pages[0].blocks[0].block_id = (
        "native:pdf-text-block-4b208f3fc3890ffc8a46"
    )
    inventory = evidence_inventory(evidence)
    proposed = ProposedFact(
        name="seller",
        value="东莞市唯格电子科技有限公司",
        citations=["native:pdf-text-block-4b208f3fc3890ffc8a46"],
    )

    repaired = _repair_document_fact_from_evidence(
        proposed,
        inventory,
        allowed_ids=set(inventory),
    )
    issues: list[str] = []
    extracted, consumed = _validated_fact(
        repaired,
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert repaired.name == "company"
    assert extracted is not None
    assert extracted.name == "company"
    assert extracted.value == "东莞市唯格电子科技有限公司"
    assert consumed == {"native:pdf-text-block-4b208f3fc3890ffc8a46"}
    assert issues == []


def test_overall_length_repair_requires_labeled_nominal_and_matching_tolerance() -> None:
    evidence = _single_block_evidence("1.00 B1 12.27±0.2 B12 3.28")
    evidence.pages[0].blocks[0].block_id = "p1:b9"
    evidence.pages[0].blocks.extend(
        [
            EvidenceBlock(
                block_id="native:pdf-text-block-a2e75be4514ffcc25d89",
                kind="native_text",
                text="12,27±0,2",
                bbox=_BBOX,
            ),
            EvidenceBlock(
                block_id="p1:title",
                kind="title",
                text="milan2 Type C-C Cable L=152mm",
                bbox=_BBOX,
            ),
            EvidenceBlock(
                block_id="native:overall-length",
                kind="native_text",
                text="152±15",
                bbox=_BBOX,
            ),
        ]
    )
    inventory = evidence_inventory(evidence)
    proposed = ProposedFact(
        name="overall_length",
        value="12.27±0.2",
        citations=[
            "p1:b9",
            "native:pdf-text-block-a2e75be4514ffcc25d89",
        ],
    )

    repaired = _repair_document_fact_from_evidence(
        proposed,
        inventory,
        allowed_ids=set(inventory),
    )
    issues: list[str] = []
    extracted, consumed = _validated_fact(
        repaired,
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert repaired.value == "152±15"
    assert repaired.citations == ["native:overall-length"]
    assert extracted is not None
    assert extracted.value == "152±15"
    assert consumed == {"native:overall-length"}
    assert issues == []


def test_overall_length_repair_does_not_promote_unlabeled_component_dimension() -> None:
    evidence = _single_block_evidence("12.27±0.2")
    evidence.pages[0].blocks[0].block_id = "p1:b9"
    inventory = evidence_inventory(evidence)
    proposed = ProposedFact(
        name="overall_length",
        value="12.27±0.2",
        citations=["p1:b9"],
    )

    repaired = _repair_document_fact_from_evidence(
        proposed,
        inventory,
        allowed_ids=set(inventory),
    )

    assert repaired == proposed


def test_overall_length_accepts_explicit_drawing_title_length() -> None:
    evidence = _single_block_evidence("HDMI弧形铝壳图纸 长度27.6")
    evidence.pages[0].blocks[0].block_id = "docx:p:6"
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="overall_length",
            value="27.6",
            citations=["docx:p:6"],
        ),
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert extracted is not None
    assert extracted.value == "27.6"
    assert consumed == {"docx:p:6"}
    assert issues == []


@pytest.mark.parametrize(
    "text",
    [
        "连接器组件 长度27.6",
        "BOM物料 图纸版本A 长度27.6",
        "HDMI弧形铝壳图纸 宽度27.6",
    ],
)
def test_overall_length_rejects_unanchored_component_length(text: str) -> None:
    evidence = _single_block_evidence(text)
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="overall_length",
            value="27.6",
            citations=["p1:b0"],
        ),
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_evidence_ref:overall_length:p1:b0"]


@pytest.mark.parametrize(
    "source_text",
    [
        "东莞市纬线电子科技产品质量很好",
        "前缀 东莞市纬线电子科技 外壳下料尺寸规格表",
    ],
)
def test_company_title_support_rejects_unanchored_or_non_title_substrings(
    source_text: str,
) -> None:
    evidence = _single_block_evidence(source_text)
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="company",
            value="东莞市纬线电子科技",
            citations=["p1:b0"],
        ),
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["unsupported_evidence_ref:company:p1:b0"]


def test_company_title_support_accepts_anchored_company_value() -> None:
    evidence = _single_block_evidence("东莞市纬线电子科技外壳下料尺寸规格表")
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="company",
            value="东莞市纬线电子科技",
            citations=["p1:b0"],
        ),
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert extracted is not None
    assert extracted.value == "东莞市纬线电子科技"
    assert consumed == {"p1:b0"}
    assert issues == []


@pytest.mark.parametrize(
    ("source_text", "accepted"),
    [
        ("50391铝壳图纸 铝壳长度", True),
        ("50391铝壳图纸仅供参考", False),
        ("前缀 50391铝壳图纸 铝壳长度", False),
    ],
)
def test_product_title_prefix_requires_anchored_structural_remainder(
    source_text: str,
    accepted: bool,
) -> None:
    evidence = _single_block_evidence(source_text)
    inventory = evidence_inventory(evidence)
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="product_name",
            value="50391铝壳图纸",
            citations=["p1:b0"],
        ),
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert (extracted is not None) is accepted
    assert consumed == ({"p1:b0"} if accepted else set())
    assert issues == ([] if accepted else ["unsupported_evidence_ref:product_name:p1:b0"])


@pytest.mark.parametrize(
    "proposed_name",
    ["material_number", "product_number", "product_name"],
)
def test_number_before_drawing_title_is_reclassified_as_drawing_number(
    proposed_name: str,
) -> None:
    evidence = _single_block_evidence("50391铝壳图纸 铝壳长度")
    evidence.pages[0].blocks[0].block_id = "docx:p:11"
    inventory = evidence_inventory(evidence)
    proposed = ProposedFact(
        name=proposed_name,
        value="50391",
        citations=["docx:p:11"],
    )

    repaired = _repair_document_fact_from_evidence(
        proposed,
        inventory,
        allowed_ids=set(inventory),
    )
    issues: list[str] = []
    extracted, consumed = _validated_fact(
        repaired,
        inventory,
        allowed_ids=set(inventory),
        issues=issues,
    )

    assert repaired.name == "drawing_number"
    assert extracted is not None
    assert extracted.name == "drawing_number"
    assert extracted.value == "50391"
    assert consumed == {"docx:p:11"}
    assert issues == []


@pytest.mark.parametrize(
    ("citation", "extra_evidence_id"),
    [
        ("buyer:p1:b9", None),
        ("overall_length:missing", None),
        ("overall_length:p1:b9", "b9"),
    ],
)
def test_fact_evidence_gate_does_not_guess_prefixed_reference(
    citation: str,
    extra_evidence_id: str | None,
) -> None:
    evidence = _single_block_evidence("28 mm")
    evidence.pages[0].blocks[0].block_id = "p1:b9"
    if extra_evidence_id is not None:
        evidence.pages[0].blocks.append(
            EvidenceBlock(
                block_id=extra_evidence_id,
                kind="text",
                text="28 mm",
                bbox=_BBOX,
            )
        )
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="overall_length",
            value="28 mm",
            citations=[citation],
        ),
        evidence_inventory(evidence),
        allowed_ids={"p1:b9"},
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == [f"unknown_evidence_id:{citation}"]


def test_repaired_fact_reference_still_enforces_segment_boundary() -> None:
    evidence = _single_block_evidence("28 mm")
    evidence.pages[0].blocks[0].block_id = "p1:b9"
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="overall_length",
            value="28 mm",
            citations=["overall_length:p1:b9"],
        ),
        evidence_inventory(evidence),
        allowed_ids={"p1:b8"},
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == ["out_of_segment_evidence_id:p1:b9"]


@pytest.mark.asyncio
async def test_prefixed_document_fact_is_repaired_before_scope_validation() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].block_id = (
        "native:word/document.xml#paragraph:3"
    )
    evidence.pages[0].blocks[0].text = "Seller: Acme Cable Limited"
    intent = DocumentIntent(
        document_intent="purchase_order",
        document_facts=[
            ProposedFact(
                name="seller",
                value="Acme Cable Limited",
                citations=[
                    "seller:native:word/document.xml#paragraph:3"
                ],
            )
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(
        evidence
    )

    assert len(result.document_facts) == 1
    assert result.document_facts[0].name == "seller"
    assert result.document_facts[0].evidence_refs[0].evidence_id == (
        "native:word/document.xml#paragraph:3"
    )
    assert not any(
        issue.startswith("ignored_model_fact:record_or_schema_evidence:")
        for issue in result.issues
    )


@pytest.mark.parametrize(
    ("value", "citation", "allowed_ids", "issue_prefix"),
    [
        ("SKU-1", "missing", {"missing"}, "unknown_evidence_id:"),
        (
            "SKU-1",
            "p1:t0:r1:c1",
            {"p1:t0:r2:c1"},
            "out_of_segment_evidence_id:",
        ),
        (
            "fabricated",
            "p1:t0:r1:c1",
            {"p1:t0:r1:c1"},
            "unsupported_evidence_ref:",
        ),
    ],
)
def test_segment_fact_evidence_gate_rejects_untrusted_citations_and_values(
    value: str,
    citation: str,
    allowed_ids: set[str],
    issue_prefix: str,
) -> None:
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="product_code",
            value=value,
            citations=[citation],
        ),
        evidence_inventory(_evidence()),
        allowed_ids=allowed_ids,
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert any(issue.startswith(issue_prefix) for issue in issues)


@pytest.mark.parametrize("role", ["buyer", "seller", "supplier"])
def test_unlabeled_company_cannot_become_a_role_fact(role: str) -> None:
    evidence = _single_block_evidence("Acme Cable Limited")
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name=role,
            value="Acme Cable Limited",
            citations=["p1:b0"],
        ),
        evidence_inventory(evidence),
        allowed_ids={"p1:b0"},
        issues=issues,
    )

    assert extracted is None
    assert consumed == set()
    assert issues == [f"unsupported_evidence_ref:{role}:p1:b0"]


def test_separate_role_label_and_value_cells_are_jointly_cited() -> None:
    evidence = _orientation_evidence([["Supplier", "Acme Cable Limited"]])
    issues: list[str] = []

    extracted, consumed = _validated_fact(
        ProposedFact(
            name="supplier",
            value="Acme Cable Limited",
            citations=["p1:t0:r0:c0", "p1:t0:r0:c1"],
        ),
        evidence_inventory(evidence),
        allowed_ids={"p1:t0:r0:c0", "p1:t0:r0:c1"},
        issues=issues,
    )

    assert extracted is not None
    assert [ref.evidence_id for ref in extracted.evidence_refs] == [
        "p1:t0:r0:c0",
        "p1:t0:r0:c1",
    ]
    assert consumed == {"p1:t0:r0:c0", "p1:t0:r0:c1"}
    assert issues == []


@pytest.mark.asyncio
async def test_poc_merges_adjacent_duplicate_rows_and_keeps_both_citations() -> None:
    evidence = _evidence().model_copy(deep=True)
    table = evidence.pages[0].tables[0]
    table.rows[2] = list(table.rows[1])
    for cell in table.cells:
        if cell.row == 2:
            cell.text = table.rows[1][cell.column]

    class DuplicateClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            if response_model is RecordFieldMapping:
                self.calls.append((response_model, messages, max_retries))
                return _three_column_mapping()
            if response_model is SegmentExtraction:
                payload = json.loads(messages[1]["content"])["evidence"]
                records = []
                if payload["intent"] == "records":
                    records = [
                        ProposedRecord(
                            fields=[
                                ProposedFact(
                                    name="product_code",
                                    value="SKU-1",
                                    citations=[f"p1:t0:r{row}:c1"],
                                )
                            ]
                        )
                        for row in (1, 2)
                    ]
                result = SegmentExtraction(records=records)
                self.calls.append((response_model, messages, max_retries))
                return result
            return await super().create(
                response_model,
                messages=messages,
                max_retries=max_retries,
            )

    client = DuplicateClient([_intent()])
    result = await MinerUInstructorExtractor(client=client).extract(evidence)

    record_segment = next(item for item in result.segments if item.intent == "records")
    assert len(record_segment.records) == 1
    product_code = next(
        field
        for field in record_segment.records[0].fields
        if field.name == "product_code"
    )
    refs = product_code.evidence_refs
    assert [reference.evidence_id for reference in refs] == [
        "p1:t0:r1:c1",
        "p1:t0:r2:c1",
    ]
    assert "duplicate_record_evidence_merged:p1:t0:1:2" in result.issues
    assert result.complete is False


@pytest.mark.asyncio
async def test_poc_repairs_tail_out_of_bounds_without_second_model_call() -> None:
    class CorrectedClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            if response_model is RecordFieldMapping:
                self.calls.append((response_model, messages, max_retries))
                return _three_column_mapping()
            if response_model is SegmentExtraction:
                request = json.loads(messages[1]["content"])
                payload = request["evidence"]
                segment_id = request["evidence"]["segment_id"]
                result = SegmentExtraction(
                    table_id="p1:t0",
                    segment_id=segment_id,
                    records=[]
                    if payload["intent"] != "records"
                    else [
                        ProposedRecord(
                            fields=[
                                ProposedFact(
                                    name="value",
                                    value="delta",
                                    citations=["p1:t0:r1:c1"],
                                )
                            ]
                        )
                    ],
                )
                self.calls.append((response_model, messages, max_retries))
                return result
            return await super().create(
                response_model,
                messages=messages,
                max_retries=max_retries,
            )

    invalid = _intent().model_copy(
        update={
            "tables": [
                TableIntent(
                    table_id="p1:t0",
                    orientation="rows",
                    segments=[TableSegmentIntent(start=0, end=3, intent="records")],
                )
            ]
        }
    )
    client = CorrectedClient([invalid])

    result = await MinerUInstructorExtractor(client=client).extract(
        _inconclusive_evidence()
    )

    assert result.complete is True
    assert result.document_intent == "order"
    assert result.document_kind_label == "purchase_order"
    assert result.document_facts[0].evidence_refs[0].evidence_id == "p1:b0"
    record_segment = next(item for item in result.segments if item.intent == "records")
    assert [field.value for field in record_segment.records[0].fields] == [
        "alpha",
        "beta",
        "charlie",
    ]
    assert result.intent_calls == 1
    assert result.segment_calls == 0
    assert [call[0] for call in client.calls] == [DocumentIntent]
    assert "intent_partition_geometry_repaired:p1:t0" in result.issues


@pytest.mark.asyncio
async def test_poc_preserves_partial_partition_and_marks_gap_for_review() -> None:
    initial = _intent(complete_table_partition=False)

    class PartialRepairClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            if response_model is SegmentExtraction:
                self.calls.append((response_model, messages, max_retries))
                return SegmentExtraction()
            return await super().create(
                response_model,
                messages=messages,
                max_retries=max_retries,
            )

    client = PartialRepairClient([initial])

    result = await MinerUInstructorExtractor(client=client).extract(
        _inconclusive_evidence()
    )

    assert result.complete is False
    assert "intent_partition_ambiguity_repaired:p1:t0" in result.issues
    assert not any(
        issue.startswith(("incomplete_table_partition:", "segment_out_of_bounds:"))
        for issue in result.issues
    )
    assert [
        (segment.start, segment.end, segment.intent) for segment in result.segments
    ] == [(0, 1, "records"), (2, 2, "metadata")]
    assert result.intent_calls == 1
    assert result.segment_calls == 1
    assert len(client.calls) == 2
    assert [call[0] for call in client.calls] == [
        DocumentIntent,
        SegmentExtraction,
    ]


def test_poc_reports_missing_optional_instructor_dependency() -> None:
    if importlib.util.find_spec("instructor") is not None:
        pytest.skip("optional Instructor dependency is installed in this environment")

    with pytest.raises(
        InstructorUnavailableError, match="optional 'instructor' package"
    ):
        MinerUInstructorExtractor.from_openai(
            base_url="http://127.0.0.1:18085/v1",
            api_key="test-key",
            model="qwen35b",
        )


def test_inventory_preserves_row_values_when_mineru_omits_cell_geometry() -> None:
    evidence = _evidence()
    table = evidence.pages[0].tables[0]
    table.cells = [cell for cell in table.cells if (cell.row, cell.column) != (1, 1)]

    items = evidence_inventory(evidence)

    recovered = items["p1:t0:r1:c1"]
    assert recovered.text == "SKU-1"
    assert recovered.positioned is False
    assert recovered.source_ref.model_extra["coordinate_inferred"] is True


@pytest.mark.asyncio
async def test_unmapped_long_block_is_preserved_in_audit_output() -> None:
    evidence = _evidence().model_copy(deep=True)
    long_text = "A" * 12_570
    evidence.pages[0].blocks[0].text = long_text
    evidence.pages[0].tables = []
    client = _Client([DocumentIntent(document_intent="technical_document")])

    result = await MinerUInstructorExtractor(client=client).extract(evidence)

    assert result.complete is True
    assert result.unmapped_evidence[0].evidence_id == "p1:b0"
    assert result.unmapped_evidence[0].quote == long_text
    assert result.raw_content_evidence[0].quote == long_text
    assert result.raw_content_evidence_count == 1
    assert result.semantic_complete is False
    assert result.content_local_fallback_count == 1
    assert result.content_accounted_complete is True
    assert result.accounted_complete is True
    assert result.evidence_accounting_ratio == 1.0
    assert result.retained_evidence_ratio == 1.0


@pytest.mark.asyncio
async def test_model_content_bindings_project_exact_long_contract_text_locally() -> (
    None
):
    evidence = _document_without_tables()
    clause = (
        "第七条 乙方延迟交货时，每延迟一日按未交付货款的百分之一承担违约金，"
        "甲方仍有权要求继续履行并保留其他损失索赔权。"
    )
    evidence.pages[0].blocks = [
        EvidenceBlock(
            block_id="p1:title",
            kind="title",
            text="采购合同",
            bbox=_BBOX,
        ),
        EvidenceBlock(
            block_id="p1:clause:7",
            kind="text",
            text=clause,
            bbox=_BBOX,
        ),
    ]
    intent = DocumentIntent(
        document_intent="purchase_contract",
        content_bindings=[
            ProposedContentBinding(
                evidence_id="p1:title",
                content_kind="title",
                label="document_title",
            ),
            ProposedContentBinding(
                evidence_id="p1:clause:7",
                content_kind="contract_clause",
                label="late_delivery_liability",
            ),
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert [unit.exact_text for unit in result.content_units] == [
        "采购合同",
        clause,
    ]
    assert [unit.content_kind for unit in result.content_units] == [
        "title",
        "contract_clause",
    ]
    assert all(unit.binding_source == "model" for unit in result.content_units)
    assert result.content_units[1].source_ref.page == 1
    assert result.content_units[1].source_ref.model_extra["bbox"] == [
        0.0,
        0.0,
        10.0,
        10.0,
    ]
    assert result.content_evidence_count == 2
    assert result.content_model_bound_count == 2
    assert result.content_local_fallback_count == 0
    assert result.content_semantic_coverage_ratio == 1.0
    assert result.content_accounting_ratio == 1.0
    # Content semantics are independent of the existing business-field metric.
    assert result.semantic_accounting_ratio == 0.0


@pytest.mark.asyncio
async def test_unbound_docx_process_blocks_become_explicit_local_fallback_units() -> (
    None
):
    evidence = _document_without_tables()
    evidence.backend = "docx-native"
    evidence.pages[0].blocks = [
        EvidenceBlock(
            block_id="docx:p:0",
            kind="heading",
            text="工艺流程",
        ),
        EvidenceBlock(
            block_id="docx:p:1",
            kind="paragraph",
            text="素材、切割、抛光、喷180砂、阳极氧化、前检、镭雕、包装、出货",
        ),
    ]

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="process_specification")])
    ).extract(evidence)

    assert [unit.evidence_id for unit in result.content_units] == [
        "docx:p:0",
        "docx:p:1",
    ]
    assert [unit.content_kind for unit in result.content_units] == [
        "heading",
        "paragraph",
    ]
    assert [unit.label for unit in result.content_units] == [
        "local_fallback:heading",
        "local_fallback:paragraph",
    ]
    assert all(unit.binding_source == "local_fallback" for unit in result.content_units)
    assert result.content_model_bound_count == 0
    assert result.content_local_fallback_count == 2
    assert result.content_semantic_coverage_ratio == 0.0
    assert result.content_accounted_complete is True
    assert result.content_accounting_ratio == 1.0


@pytest.mark.asyncio
async def test_content_binding_does_not_duplicate_document_fact_evidence() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id="p1:b1",
            kind="text",
            text="交货地点：甲方工厂",
            bbox=_BBOX,
        )
    )
    intent = DocumentIntent(
        document_intent="purchase_order",
        document_facts=[
            ProposedFact(
                name="order_number",
                value="PO-1",
                citations=["p1:b0"],
            )
        ],
        content_bindings=[
            ProposedContentBinding(
                evidence_id="p1:b0",
                content_kind="document_metadata",
                label="order_header",
            ),
            ProposedContentBinding(
                evidence_id="p1:b1",
                content_kind="contract_clause",
                label="delivery_location",
            ),
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert [unit.evidence_id for unit in result.content_units] == ["p1:b1"]
    assert result.content_units[0].exact_text == "交货地点：甲方工厂"
    assert any(
        issue == "ignored_content_binding:document_fact_consumed:p1:b0"
        for issue in result.issues
    )
    assert result.complete is True


@pytest.mark.asyncio
async def test_invalid_and_duplicate_content_bindings_are_audited_without_loss() -> (
    None
):
    evidence = _document_without_tables()
    evidence.pages[0].blocks.append(
        EvidenceBlock(block_id="p1:b1", kind="text", text="第二段原文")
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        content_bindings=[
            ProposedContentBinding(
                evidence_id="p1:b0",
                content_kind="title",
                label="document_title",
            ),
            ProposedContentBinding(
                evidence_id="p1:b0",
                content_kind="drawing_note",
                label="duplicate_binding",
            ),
            ProposedContentBinding(
                evidence_id="missing:block",
                content_kind="contract_clause",
                label="unknown_source",
            ),
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert [
        (unit.evidence_id, unit.binding_source) for unit in result.content_units
    ] == [
        ("p1:b0", "model"),
        ("p1:b1", "local_fallback"),
    ]
    assert [unit.exact_text for unit in result.content_units] == [
        "Order PO-1",
        "第二段原文",
    ]
    assert result.content_units[0].alternate_semantics == [
        {"content_kind": "drawing_note", "label": "duplicate_binding"}
    ]
    assert "ignored_content_binding:merged_semantics:p1:b0" in result.issues
    assert "invalid_content_binding:unknown_evidence_id:missing:block" in result.issues
    assert result.complete is True


@pytest.mark.asyncio
async def test_content_binding_repairs_unique_exact_text_id_without_guessing() -> None:
    evidence = _document_without_tables()
    valid_id = "native:pdf-text-block-96cadc6898c300d92ced"
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id=valid_id,
            kind="native_text",
            text="6,65±0,1\n27±0,3\n34±0,4",
            bbox=_BBOX,
        )
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        content_bindings=[
            ProposedContentBinding(
                evidence_id="native:pdf-text-block-27±0,3",
                content_kind="dimension_group",
                label="drawing_dimensions",
            )
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(
        evidence
    )

    unit = next(item for item in result.content_units if item.evidence_id == valid_id)
    assert unit.binding_source == "model"
    assert unit.content_kind == "dimension_group"
    assert (
        f"content_binding_evidence_id_repaired:unique_exact_text:{valid_id}"
        in result.issues
    )
    assert not any(
        issue.startswith("invalid_content_binding:unknown_evidence_id")
        for issue in result.issues
    )
    assert result.complete is True


@pytest.mark.asyncio
async def test_content_binding_exact_text_repair_fails_closed_when_ambiguous() -> None:
    evidence = _document_without_tables()
    for suffix in ("a" * 20, "b" * 20):
        evidence.pages[0].blocks.append(
            EvidenceBlock(
                block_id=f"native:pdf-text-block-{suffix}",
                kind="native_text",
                text="27±0,3",
                bbox=_BBOX,
            )
        )
    intent = DocumentIntent(
        document_intent="technical_document",
        content_bindings=[
            ProposedContentBinding(
                evidence_id="native:pdf-text-block-27±0,3",
                content_kind="dimension_group",
                label="drawing_dimensions",
            )
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(
        evidence
    )

    assert all(
        unit.binding_source == "local_fallback"
        for unit in result.content_units
        if unit.evidence_id.startswith("native:pdf-text-block-")
    )
    assert (
        "invalid_content_binding:unknown_evidence_id:"
        "native:pdf-text-block-27±0,3"
    ) in result.issues
    assert not any(
        issue.startswith("content_binding_evidence_id_repaired:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_content_binding_repairs_duplicate_native_pdf_prefix() -> None:
    evidence = _document_without_tables()
    suffix = "c78e65efade9cc980a3a"
    valid_id = f"native:pdf-text-block-{suffix}"
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id=valid_id,
            kind="native_text",
            text="A1, B1, A12, B12",
            bbox=_BBOX,
        )
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        content_bindings=[
            ProposedContentBinding(
                evidence_id=f"native:pdf:pdf-text-block-{suffix}",
                content_kind="pin_assignment",
                label="connector_pin_group",
            )
        ],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(
        evidence
    )

    unit = next(item for item in result.content_units if item.evidence_id == valid_id)
    assert unit.binding_source == "model"
    assert unit.content_kind == "pin_assignment"
    assert (
        f"content_binding_evidence_id_repaired:normalized_id:{valid_id}"
        in result.issues
    )


@pytest.mark.asyncio
async def test_explicit_purchase_contract_title_overrides_model_intent() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "采购合同"
    intent = DocumentIntent(document_intent="purchase_order")

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert result.document_intent == "order"
    assert result.document_subtype == "purchase_contract"
    assert result.document_kind_label == "purchase_contract"
    assert result.complete is True
    assert (
        "explicit_document_intent_override:purchase_order:purchase_contract"
        in result.issues
    )


@pytest.mark.asyncio
@pytest.mark.parametrize("body_text", ["采购合同", "备货单"])
async def test_unpositioned_body_text_does_not_override_model_intent(
    body_text: str,
) -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0] = EvidenceBlock(
        block_id="p1:b0",
        kind="text",
        text=body_text,
        bbox=None,
    )
    intent = DocumentIntent(
        document_intent="technical_document",
        document_subtype="engineering_drawing",
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_subtype == "engineering_drawing"
    assert not any(
        issue.startswith("explicit_document_intent_override:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_lower_page_body_text_does_not_override_model_intent() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0] = EvidenceBlock(
        block_id="p1:b0",
        kind="text",
        text="采购合同",
        bbox=EvidenceBBox(
            x0=0,
            y0=60,
            x1=90,
            y1=80,
            coordinate_space="pdf_points",
        ),
    )

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="purchase_order")])
    ).extract(evidence)

    assert result.document_intent == "order"
    assert result.document_kind_label == "purchase_order"


@pytest.mark.asyncio
async def test_unpositioned_table_rows_do_not_act_as_native_title() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="p1:t0",
            rows=[["备货单"], ["采购合同"]],
            cells=[],
            bbox=None,
        )
    ]

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="technical_document")])
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_subtype is None


def test_spreadsheet_merged_top_cell_is_native_title_evidence_without_bbox() -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=[["品牌", "桐曦"], ["备货单", None]],
            cells=[
                EvidenceCell(
                    row=0,
                    column=0,
                    text="品牌",
                    source_row=1,
                    source_column=1,
                ),
                EvidenceCell(
                    row=0,
                    column=1,
                    text="桐曦",
                    source_row=1,
                    source_column=2,
                ),
                EvidenceCell(
                    row=1,
                    column=0,
                    text="备货单",
                    source_row=2,
                    source_column=1,
                    merged_range="A2:Z2",
                ),
            ],
            bbox=None,
        )
    ]

    assert _native_title_text(evidence) == "备货单"


def test_spreadsheet_merged_title_accepts_an_exact_marker_line() -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=[["广西桐曦电子科技有限公司\n采购合同"]],
            cells=[
                EvidenceCell(
                    row=0,
                    column=0,
                    text="广西桐曦电子科技有限公司\n采购合同",
                    source_row=1,
                    source_column=1,
                    merged_range="A1:K1",
                )
            ],
            bbox=None,
        )
    ]

    assert _native_title_text(evidence) == "采购合同"


def test_spreadsheet_merged_title_keeps_hidden_anchor_column() -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=[["采 购 合 同", None]],
            cells=[
                EvidenceCell(
                    row=0,
                    column=0,
                    text="采 购 合 同",
                    source_row=1,
                    source_column=1,
                    hidden_column=True,
                    merged_range="A1:R1",
                )
            ],
            bbox=None,
        )
    ]

    assert _native_title_text(evidence) == "采购合同"


def test_unheaded_order_fallback_uses_unit_and_packaging_arithmetic() -> None:
    table = EvidenceTable(
        table_id="spreadsheet:s0",
        rows=[
            ["3月31日客户光纤订单", None, None, None, None],
            [
                "1",
                None,
                "光纤线-铜包钢-银色锌合金",
                "30M",
                "PCS",
                "壳子印字:NYK",
                "打大轴",
                "客供彩盒+标签+覆膜",
                "线头标",
                "300",
                "10",
                "30",
                "53*42*27",
            ],
        ],
    )
    segment = instructor_poc._ValidatedSegment(
        table_id="spreadsheet:s0",
        intent="records",
        orientation="rows",
        start=1,
        end=1,
    )

    names = instructor_poc._evidence_backed_field_names(
        table,
        segment,
        document_type="order",
    )

    assert names[0] == "line_no"
    assert names[2] == "name_raw"
    assert names[3] == "specification_raw"
    assert names[4] == "unit"
    assert names[9] == "quantity"
    assert names[10] == "package_quantity"
    assert names[11] == "piece_count"
    assert names[12] == "carton_specification"


def test_isolated_dated_order_title_resolves_customer_order_subtype() -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=[
                ["3月31日客户光纤订单", None],
                ["1", "光纤线"],
            ],
            cells=[
                EvidenceCell(
                    row=0,
                    column=0,
                    text="3月31日客户光纤订单",
                    source_row=1,
                    source_column=1,
                ),
                EvidenceCell(row=1, column=0, text="1", source_row=2),
                EvidenceCell(row=1, column=1, text="光纤线", source_row=2),
            ],
        )
    ]
    intent = DocumentIntent(document_intent="order")

    assert instructor_poc._native_generic_order_title(evidence) == (
        "3月31日客户光纤订单"
    )
    assert instructor_poc._document_subtype(intent, evidence) == (
        "customer_purchase_order"
    )


def test_spreadsheet_isolated_top_cell_is_native_title_evidence() -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=[["采购合同"]],
            cells=[
                EvidenceCell(
                    row=0,
                    column=0,
                    text="采购合同",
                    source_row=3,
                    source_column=2,
                )
            ],
            bbox=None,
        )
    ]

    assert _native_title_text(evidence) == "采购合同"


@pytest.mark.parametrize(
    ("rows", "cells"),
    [
        (
            [["备注：采购合同仅供历史数据核对"]],
            [
                EvidenceCell(
                    row=0,
                    column=0,
                    text="备注：采购合同仅供历史数据核对",
                    source_row=1,
                    source_column=1,
                )
            ],
        ),
        (
            [["文档类型", "采购合同", "状态", "已归档"]],
            [
                EvidenceCell(
                    row=0,
                    column=0,
                    text="文档类型",
                    source_row=2,
                    source_column=1,
                ),
                EvidenceCell(
                    row=0,
                    column=1,
                    text="采购合同",
                    source_row=2,
                    source_column=2,
                ),
                EvidenceCell(
                    row=0,
                    column=2,
                    text="状态",
                    source_row=2,
                    source_column=3,
                ),
                EvidenceCell(
                    row=0,
                    column=3,
                    text="已归档",
                    source_row=2,
                    source_column=4,
                ),
            ],
        ),
    ],
)
def test_spreadsheet_notes_and_multicolumn_data_are_not_native_titles(
    rows: list[list[str]],
    cells: list[EvidenceCell],
) -> None:
    evidence = _document_without_tables()
    evidence.backend = "spreadsheet-envelope"
    evidence.pages[0].blocks = []
    evidence.pages[0].tables = [
        EvidenceTable(
            table_id="spreadsheet:s0",
            rows=rows,
            cells=cells,
            bbox=None,
        )
    ]

    assert _native_title_text(evidence) == ""


@pytest.mark.asyncio
async def test_explicit_unpositioned_heading_can_override_model_intent() -> None:
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0] = EvidenceBlock(
        block_id="p1:b0",
        kind="heading",
        text="采购合同",
        bbox=None,
    )

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="purchase_order")])
    ).extract(evidence)

    assert result.document_intent == "order"
    assert result.document_subtype == "purchase_contract"
    assert result.document_kind_label == "purchase_contract"


@pytest.mark.asyncio
async def test_record_cell_cannot_be_duplicated_as_document_fact() -> None:
    intent = DocumentIntent(
        document_intent="purchase_order",
        document_facts=[
            ProposedFact(
                name="product_code",
                value="SKU-1",
                citations=["p1:t0:r1:c1"],
            )
        ],
    )

    result = await MinerUInstructorExtractor(
        client=_Client([intent, SegmentExtraction(), _three_column_mapping()])
    ).extract(_evidence())

    assert result.document_facts == []
    assert result.complete is True, result.issues
    assert (
        "ignored_model_fact:record_or_schema_evidence:"
        "product_code:p1:t0:r1:c1" in result.issues
    )
    assert sum(len(segment.records) for segment in result.segments) == 2


@pytest.mark.asyncio
async def test_table_id_only_document_fact_is_ignored_without_relaxing_citations() -> (
    None
):
    evidence = _document_without_tables()
    evidence.pages[0].tables = [EvidenceTable(table_id="docx:t:0", rows=[])]
    intent = DocumentIntent(
        document_intent="process_specification",
        document_facts=[
            ProposedFact(
                name="table_summary",
                value="六边形铝壳",
                citations=["docx:t:0", "p1:b0"],
            )
        ],
        tables=[TableIntent(table_id="docx:t:0", orientation="rows", segments=[])],
    )

    result = await MinerUInstructorExtractor(client=_Client([intent])).extract(evidence)

    assert result.document_facts == []
    assert result.complete is True
    assert result.issues == [
        "ignored_model_fact:table_id_is_not_citation:table_summary:docx:t:0"
    ]
    assert not any(issue.startswith("unknown_evidence_id:") for issue in result.issues)


def _document_without_tables() -> DocumentEvidence:
    evidence = _evidence().model_copy(deep=True)
    evidence.pages[0].tables = []
    return evidence


@pytest.mark.asyncio
async def test_compact_intent_splits_classification_from_block_semantics() -> None:
    class CompactClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="technical_document",
                    document_subtype="engineering_drawing",
                )
            assert response_model is BlockSemantics
            return BlockSemantics(
                document_facts=[
                    ProposedFact(
                        name="material_number",
                        value="PO-1",
                        citations=["p1:b0"],
                    )
                ],
                content_bindings=[
                    ProposedContentBinding(
                        evidence_id="p1:b0",
                        content_kind="title",
                        label="document_title",
                    )
                ],
            )

    client = CompactClient([])
    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "料号 PO-1"
    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(evidence)

    assert [call[0] for call in client.calls] == [
        DocumentClassification,
        BlockSemantics,
    ]
    assert all(call[2] == 0 for call in client.calls)
    assert result.document_intent == "technical_document"
    assert result.document_subtype == "engineering_drawing"
    assert result.document_facts[0].value == "PO-1"
    assert result.content_units == []
    assert result.issues == ["ignored_content_binding:document_fact_consumed:p1:b0"]


@pytest.mark.asyncio
async def test_compact_intent_uses_native_docx_classification_before_model() -> None:
    class NativeDOCXClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.backend = "docx-native-ooxml"
    evidence.pages[0].blocks[0].text = "产品承认书"
    evidence.raw = {
        "native_classification": {
            "schema_version": "m1.native-classification.v1",
            "source": "docx-native-classifier-v1",
            "document_type": "technical_document",
            "document_subtype": "approval_drawing",
            "authority": "native_content",
            "confidence": 1.0,
            "evidence": [
                {
                    "document_subtype": "approval_drawing",
                    "quote": "产品承认书",
                    "source_ref": {
                        "page": 1,
                        "part": "word/document.xml#paragraph:0",
                    },
                }
            ],
        }
    }
    evidence.pages[0].blocks[0].model_extra["source_id"] = (
        "word/document.xml#paragraph:0"
    )
    client = NativeDOCXClient([])

    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(evidence)

    assert [call[0] for call in client.calls] == [BlockSemantics]
    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "approval_drawing"
    assert "native_document_classification_applied" in result.issues
    assert result.complete is True


@pytest.mark.asyncio
async def test_explicit_subtype_hint_wins_over_native_docx_classification() -> None:
    class HintedDOCXClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="technical_document",
                    document_subtype="approval_drawing",
                )
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.backend = "docx-native-ooxml"
    evidence.pages[0].blocks[0].text = "产品承认书"
    evidence.raw = {
        "native_classification": {
            "schema_version": "m1.native-classification.v1",
            "source": "docx-native-classifier-v1",
            "document_type": "technical_document",
            "document_subtype": "approval_drawing",
            "authority": "native_content",
            "confidence": 1.0,
            "evidence": [
                {
                    "document_subtype": "approval_drawing",
                    "quote": "产品承认书",
                    "source_ref": {
                        "page": 1,
                        "part": "word/document.xml#paragraph:0",
                    },
                }
            ],
        }
    }
    evidence.pages[0].blocks[0].model_extra["source_id"] = (
        "word/document.xml#paragraph:0"
    )

    result = await MinerUInstructorExtractor(
        client=HintedDOCXClient([]),
        compact_intent=True,
    ).extract(
        evidence,
        document_subtype_hint="product_specification",
    )

    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "product_specification"


@pytest.mark.asyncio
async def test_compact_block_semantics_rejects_bad_items_not_whole_response() -> None:
    class PartiallyValidBlockClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(document_intent="commercial_document")
            assert response_model is BlockSemantics
            return BlockSemantics(
                document_facts=[
                    {"name": "", "value": "", "citations": []},
                    {"name": "payment_terms", "value": "", "citations": []},
                ],
                content_bindings=[
                    {
                        "evidence_id": "p1:b0",
                        "content_kind": "contract_clause",
                        "label": "payment_terms",
                    },
                    {"evidence_id": "", "content_kind": "not valid", "label": ""},
                ],
            )

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "Payment is due within 30 days."
    result = await MinerUInstructorExtractor(
        client=PartiallyValidBlockClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert not any(
        issue.startswith("block_semantics_model_error:") for issue in result.issues
    )
    assert "ignored_model_fact:invalid_block_semantics_proposal" in result.issues
    assert "invalid_content_binding:invalid_block_semantics_proposal" in result.issues
    assert result.content_model_bound_count == 1
    assert result.content_units[0].content_kind == "contract_clause"
    assert result.content_units[0].binding_source == "model"


@pytest.mark.asyncio
async def test_compact_block_semantics_ignores_empty_optional_proposals() -> None:
    class EmptyPlaceholderClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(document_intent="commercial_document")
            assert response_model is BlockSemantics
            return BlockSemantics(
                document_facts=[
                    {"name": "", "value": "", "citations": []},
                ],
                content_bindings=[
                    {"evidence_id": "", "content_kind": "", "label": ""},
                ],
            )

    result = await MinerUInstructorExtractor(
        client=EmptyPlaceholderClient([]),
        compact_intent=True,
    ).extract(_document_without_tables())

    assert "ignored_model_fact:invalid_block_semantics_proposal" not in result.issues
    assert "invalid_content_binding:invalid_block_semantics_proposal" not in (
        result.issues
    )


@pytest.mark.asyncio
async def test_compact_intent_model_failure_preserves_purchase_contract_family() -> (
    None
):
    class FailingClassificationClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                raise TimeoutError("classification unavailable")
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "采购合同"

    result = await MinerUInstructorExtractor(
        client=FailingClassificationClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_intent == "order"
    assert result.document_intent_family == "order"
    assert result.document_subtype == "purchase_contract"
    assert "intent_model_error:TimeoutError" in result.issues


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("text", "expected_subtype"),
    [
        (
            ("壳子镭雕：DP 2.1 视频高清线 镭雕白色 正面 反面 外壳1:1比例 示图"),
            "engineering_drawing",
        ),
        (
            (
                "DWG NO. ICP-0018-A0 PART NO. PJM38P801-0xxF-0 SCALE 1:1 "
                "GENERAL TOLERANCE ±0.1 REVISION A/0 APPROVED CHECKED DRAWN "
                "Electrical Test: Insulation Resistance and Contact Resistance. "
                "Mechanical: Durability and tensile strength. RoHS and REACH. "
                "Operating Temperature: -40~+125°C."
            ),
            "product_specification",
        ),
    ],
)
async def test_compact_intent_technical_evidence_corrects_order_model(
    text: str,
    expected_subtype: str,
) -> None:
    class WrongOrderClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="order",
                    document_kind_label="unknown",
                    document_subtype="unknown",
                )
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = text

    result = await MinerUInstructorExtractor(
        client=WrongOrderClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_subtype == expected_subtype
    assert result.document_kind_label == expected_subtype
    assert "explicit_document_intent_override:order:technical_document" in (
        result.issues
    )
    assert "document_kind_label_inferred_from_evidence" in result.issues
    assert result.complete is True


def test_document_classification_prompt_distinguishes_bom_from_order() -> None:
    messages = instructor_poc._base_messages(
        role="document_classification",
        payload={},
    )
    system_prompt = messages[0]["content"]

    assert "contains a BOM, quantities, units" in system_prompt
    assert "commercial commitment" in system_prompt
    assert "Do not infer order" in system_prompt


@pytest.mark.asyncio
async def test_compact_intent_reconciles_specific_model_label_with_trusted_family() -> (
    None
):
    class InternallyConflictingClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="order",
                    document_kind_label="engineering_drawing",
                    document_subtype="engineering_drawing",
                )
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = (
        "DWG NO. 80826-041 REV C GENERAL TOLERANCE +/-0.2 "
        "USB Type-C cable engineering drawing and BOM"
    )

    result = await MinerUInstructorExtractor(
        client=InternallyConflictingClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_subtype == "engineering_drawing"
    assert result.document_kind_label == "engineering_drawing"
    assert (
        "document_classification_trusted_family_reconciled:"
        "order:technical_document"
    ) in result.issues
    assert not any(
        issue.startswith("document_classification_consistency_repair:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_compact_intent_conflicting_subtype_cannot_reverse_native_family() -> (
    None
):
    class ConflictingClassificationClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="technical_document",
                    document_kind_label="inventory_snapshot",
                    document_subtype="inventory_snapshot",
                )
            assert response_model is BlockSemantics
            return BlockSemantics()

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = (
        "产品规格书 产品编号 494-12732 产品名称 HDMI2.1 光模组 "
        "规格参数 带宽 48Gbps 分辨率 8K@60Hz 工作电压 5V 传输距离 100米"
    )

    result = await MinerUInstructorExtractor(
        client=ConflictingClassificationClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "product_specification"
    assert result.document_kind_label == "product_specification"
    assert (
        "document_classification_consistency_repair:technical_document:inventory"
    ) in result.issues


@pytest.mark.asyncio
async def test_compact_intent_uses_table_only_schema_for_inconclusive_layout() -> None:
    class CompactPartitionClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(document_intent="order")
            if response_model is BlockSemantics:
                return BlockSemantics()
            assert response_model is TablePartition
            return TablePartition(
                tables=[
                    TableIntent(
                        table_id="p1:t0",
                        orientation="rows",
                        segments=[TableSegmentIntent(start=0, end=2, intent="layout")],
                    )
                ]
            )

    client = CompactPartitionClient([])
    result = await MinerUInstructorExtractor(
        client=client,
        compact_intent=True,
    ).extract(_inconclusive_evidence())

    assert result.document_intent == "order"
    assert [call[0] for call in client.calls] == [
        DocumentClassification,
        BlockSemantics,
        TablePartition,
    ]
    correction_request = json.loads(client.calls[-1][1][1]["content"])
    assert correction_request["task"] == "table_partition_correction"
    assert DocumentIntent not in [call[0] for call in client.calls]


@pytest.mark.asyncio
async def test_compact_intent_retains_evidence_backed_unknown_fact() -> None:
    class CompactClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(
                    document_intent="commercial_document",
                    document_subtype="unknown",
                )
            assert response_model is BlockSemantics
            return BlockSemantics(
                document_facts=[
                    ProposedFact(
                        name="retention_policy",
                        value="Internal handling only",
                        citations=["p1:b0"],
                        sensitive=True,
                    ),
                    ProposedFact(
                        name="unverified_claim",
                        value="Internal handling only",
                        citations=["missing:evidence"],
                    ),
                ]
            )

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "Internal handling only"
    result = await MinerUInstructorExtractor(
        client=CompactClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_facts == []
    assert len(result.generic_facts) == 1
    fact = result.generic_facts[0]
    assert fact.name == "retention_policy"
    assert fact.value == "Internal handling only"
    assert fact.sensitive is True
    assert fact.evidence_refs[0].evidence_id == "p1:b0"
    assert fact.evidence_refs[0].source_ref.page == 1
    assert fact.evidence_refs[0].source_ref.model_extra["bbox"] == [
        0.0,
        0.0,
        10.0,
        10.0,
    ]
    assert not any(item.name == "unverified_claim" for item in result.generic_facts)
    assert "unmapped_supported_fact:retention_policy" in result.issues
    assert any(
        issue.startswith(
            "ignored_model_fact:record_or_schema_evidence:unverified_claim:"
        )
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_guarded_route_uses_explicit_upload_hints_before_profile_hints() -> None:
    evidence = _document_without_tables()
    evidence.raw["document_route_context"] = {
        "schema_family": "order",
        "document_type_hint": "order",
        "document_subtype_hint": "purchase_contract",
        "table_roles": [],
        "verifier_policy": "always",
        "authority_policy": "core_strict",
    }

    result = await MinerUInstructorExtractor(
        client=_Client(
            [
                DocumentIntent(
                    document_intent="order",
                    document_subtype="supplier_purchase_order",
                )
            ]
        )
    ).extract(
        evidence,
        document_type_hint="technical_document",
        document_subtype_hint="product_specification",
    )

    assert result.document_intent == "technical_document"
    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "product_specification"
    assert not any(
        issue.startswith("document_route_classification_fallback:")
        for issue in result.issues
    )
    assert result.route_policy_advice is not None
    assert result.route_policy_advice.verifier_policy == "always"
    assert result.route_policy_advice.authority_policy == "core_strict"


@pytest.mark.asyncio
async def test_guarded_route_uses_native_title_before_profile_hint() -> None:
    evidence = _single_block_evidence("drawing_number: DWG-1")
    evidence.pages[0].blocks[0].kind = "heading"
    evidence.raw["document_route_context"] = {
        "schema_family": "order",
        "document_type_hint": "order",
        "document_subtype_hint": "purchase_contract",
        "table_roles": [],
        "verifier_policy": "on_uncertainty",
        "authority_policy": "core_strict",
    }

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="unknown")])
    ).extract(evidence)

    assert result.document_intent == "technical_document"
    assert result.document_intent_family == "technical_document"
    assert result.document_subtype == "engineering_drawing"
    assert "explicit_document_intent_override:unknown:technical_document" in (
        result.issues
    )
    assert not any(
        issue.startswith("document_route_classification_fallback:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_explicit_type_hint_rejects_conflicting_native_subtype() -> None:
    evidence = _single_block_evidence("drawing_number: DWG-1")
    evidence.pages[0].blocks[0].kind = "heading"
    evidence.raw["document_route_context"] = {
        "schema_family": "technical",
        "document_type_hint": "technical_document",
        "document_subtype_hint": "product_specification",
        "table_roles": [],
        "verifier_policy": "on_uncertainty",
        "authority_policy": "core_strict",
    }

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="unknown")])
    ).extract(evidence, document_type_hint="order")

    assert result.document_intent == "order"
    assert result.document_intent_family == "order"
    assert result.document_subtype is None
    assert not any(
        issue.startswith("document_route_classification_fallback:")
        for issue in result.issues
    )


@pytest.mark.asyncio
async def test_invalid_guarded_route_context_fails_safe_without_echoing_payload() -> (
    None
):
    evidence = _document_without_tables()
    evidence.raw["document_route_context"] = {
        "schema_family": "../../order",
        "document_type_hint": ["order"],
        "document_subtype_hint": "purchase_contract",
        "table_roles": [
            {
                "table_index": 0,
                "role": "order_lines",
                "json_path": "$.customer.secret",
            }
        ],
        "verifier_policy": "sometimes",
        "authority_policy": "unsafe_override",
        "customer_name": "Secret Customer",
    }

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="commercial_document")])
    ).extract(evidence)

    assert result.document_intent == "commercial_document"
    assert result.route_policy_advice is None
    assert result.complete is True
    assert "ignored_document_route_context:extra_keys:1" in result.issues
    assert "ignored_document_route_context:invalid_schema_family" in result.issues
    assert "ignored_document_route_context:invalid_document_type_hint" in result.issues
    assert "ignored_document_route_context:invalid_table_role_items:1" in result.issues
    audit = "\n".join(result.issues)
    assert "Secret Customer" not in audit
    assert "$.customer.secret" not in audit


@pytest.mark.asyncio
async def test_guarded_route_rejects_policy_wrapper_and_raw_text() -> None:
    evidence = _document_without_tables()
    evidence.raw["document_route_context"] = {
        "policy": {
            "schema_family": "order",
            "document_type_hint": "order",
        },
        "raw_text": "purchase contract for Secret Customer",
    }

    result = await MinerUInstructorExtractor(
        client=_Client([DocumentIntent(document_intent="unknown")])
    ).extract(evidence)

    assert result.document_intent == "unknown"
    assert result.route_policy_advice is None
    assert result.complete is True
    assert result.issues == ["ignored_document_route_context:extra_keys:2"]
    assert "Secret Customer" not in "\n".join(result.issues)


@pytest.mark.asyncio
async def test_generic_guarded_route_uses_only_evidence_backed_generic_facts() -> None:
    class GenericRouteClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentClassification:
                return DocumentClassification(document_intent="unknown")
            assert response_model is BlockSemantics
            payload = json.loads(messages[1]["content"])["evidence"]
            assert payload["document_context"]["generic_facts_only"] is True
            assert payload["document_context"]["allowed_fact_names"] == []
            return BlockSemantics(
                document_facts=[
                    ProposedFact(
                        name="retention_policy",
                        value="Internal handling only",
                        citations=["p1:b0"],
                    )
                ]
            )

    evidence = _document_without_tables()
    evidence.pages[0].blocks[0].text = "Internal handling only"
    evidence.raw["document_route_context"] = {
        "schema_family": "generic_layout",
        "document_type_hint": None,
        "document_subtype_hint": None,
        "table_roles": [],
        "verifier_policy": "on_uncertainty",
        "authority_policy": "evidence_required",
    }
    result = await MinerUInstructorExtractor(
        client=GenericRouteClient([]),
        compact_intent=True,
    ).extract(evidence)

    assert result.document_facts == []
    assert [(fact.name, fact.value) for fact in result.generic_facts] == [
        ("retention_policy", "Internal handling only")
    ]
    assert result.generic_facts[0].evidence_refs[0].evidence_id == "p1:b0"
    assert result.route_policy_advice is not None
    assert result.route_policy_advice.schema_family == "generic_layout"


@pytest.mark.asyncio
async def test_guarded_table_roles_follow_evidence_order_and_preserve_values() -> None:
    evidence = _evidence()
    for index in (1, 2):
        table_id = f"p1:t{index}"
        rows = [
            ["Item", "Code", "Qty"],
            [str(index), f"SKU-{index}", str(index + 1)],
        ]
        evidence.pages[0].tables.append(
            EvidenceTable(
                table_id=table_id,
                rows=rows,
                cells=[
                    EvidenceCell(
                        row=row,
                        column=column,
                        text=value,
                        bbox=_BBOX,
                    )
                    for row, values in enumerate(rows)
                    for column, value in enumerate(values)
                ],
                bbox=_BBOX,
            )
        )
    evidence.raw["document_route_context"] = {
        "schema_family": "order",
        "document_type_hint": "order",
        "document_subtype_hint": "supplier_purchase_order",
        "table_roles": [
            {"table_index": 0, "role": "key_value"},
            {"table_index": 1, "role": "ignore"},
            {"table_index": 2, "role": "order_lines"},
        ],
        "verifier_policy": "on_uncertainty",
        "authority_policy": "core_strict",
    }

    class RoutedTableClient(_Client):
        async def create(self, response_model, *, messages, max_retries):
            self.calls.append((response_model, messages, max_retries))
            if response_model is DocumentIntent:
                return DocumentIntent(
                    document_intent="purchase_order",
                    primary_record_table_ids=["p1:t0", "p1:t1", "p1:t2"],
                    tables=[
                        TableIntent(
                            table_id=f"p1:t{index}",
                            orientation="rows",
                            segments=[
                                TableSegmentIntent(
                                    start=0,
                                    end=len(table.rows) - 1,
                                    intent="records",
                                )
                            ],
                        )
                        for index, table in enumerate(evidence.pages[0].tables)
                    ],
                )
            if response_model is SegmentExtraction:
                return SegmentExtraction()
            raise AssertionError(response_model)

    result = await MinerUInstructorExtractor(client=RoutedTableClient([])).extract(
        evidence
    )

    assert result.primary_record_table_ids == ["p1:t2"]
    assert {segment.table_id: segment.intent for segment in result.segments} == {
        "p1:t0": "metadata",
        "p1:t1": "layout",
        "p1:t2": "records",
    }
    routed_records = next(
        segment.records
        for segment in result.segments
        if segment.table_id == "p1:t2" and segment.intent == "records"
    )
    assert [field.value for field in routed_records[0].fields] == [
        "2",
        "SKU-2",
        "3",
    ]
    assert "document_route_primary_tables_applied" in result.issues


@pytest.mark.asyncio
async def test_ollama_native_uses_schema_think_false_and_configured_context() -> None:
    requests: list[dict[str, Any]] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/chat"
        payload = json.loads((await request.aread()).decode("utf-8"))
        requests.append(payload)
        return httpx.Response(
            200,
            json={
                "message": {
                    "role": "assistant",
                    "content": json.dumps(
                        {
                            "document_intent": "technical_document",
                            "document_facts": [],
                            "content_bindings": [],
                            "tables": [],
                        }
                    ),
                }
            },
        )

    extractor = MinerUInstructorExtractor.from_ollama_native(
        base_url="http://ollama.test",
        model="qwen3-m1:8b",
        num_ctx=12_288,
        max_retries=2,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await extractor.extract(_document_without_tables())
    finally:
        await extractor.close()

    assert result.complete is True
    assert len(requests) == 1
    assert requests[0]["model"] == "qwen3-m1:8b"
    assert requests[0]["stream"] is False
    assert requests[0]["think"] is False
    assert requests[0]["options"]["num_ctx"] == 12_288
    grammar_schema = requests[0]["format"]
    assert grammar_schema["required"] == [
        "document_intent",
        "document_kind_label",
        "document_subtype",
        "document_facts",
        "primary_record_table_ids",
        "content_bindings",
        "tables",
    ]
    assert "maxItems" not in grammar_schema["properties"]["document_facts"]


@pytest.mark.asyncio
async def test_ollama_native_corrects_pydantic_validation_once() -> None:
    requests: list[dict[str, Any]] = []

    async def handler(request: httpx.Request) -> httpx.Response:
        payload = json.loads((await request.aread()).decode("utf-8"))
        requests.append(payload)
        content = (
            '{"document_intent":"technical_document","unexpected":true}'
            if len(requests) == 1
            else json.dumps(
                {
                    "document_intent": "technical_document",
                    "document_facts": [],
                    "content_bindings": [],
                    "tables": [],
                }
            )
        )
        return httpx.Response(200, json={"message": {"content": content}})

    extractor = MinerUInstructorExtractor.from_ollama_native(
        base_url="http://ollama.test",
        model="qwen3-m1:8b",
        max_retries=1,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await extractor.extract(_document_without_tables())
    finally:
        await extractor.close()

    assert result.complete is True
    assert len(requests) == 2
    correction = json.loads(requests[1]["messages"][-1]["content"])
    assert correction["task"] == "correct_structured_output"
    assert correction["validation_errors"]


@pytest.mark.asyncio
async def test_ollama_native_validation_failure_is_bounded() -> None:
    calls = 0

    async def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            200,
            json={"message": {"content": '{"unexpected":true}'}},
        )

    extractor = MinerUInstructorExtractor.from_ollama_native(
        base_url="http://ollama.test",
        model="qwen3-m1:8b",
        max_retries=2,
        transport=httpx.MockTransport(handler),
    )
    try:
        result = await extractor.extract(_document_without_tables())
    finally:
        await extractor.close()

    assert calls == 3
    assert result.complete is False
    assert result.issues == ["intent_model_error:OllamaNativeOutputError"]
