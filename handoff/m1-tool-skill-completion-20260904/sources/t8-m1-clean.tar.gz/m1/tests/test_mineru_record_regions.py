from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import ClassVar

import pytest
from m1.documents.models import DocumentRecord
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru_authority import evaluate_mineru_authority
from m1.documents.parsing.mineru_candidate import (
    MinerUAxisMapping,
    MinerUBusinessMapper,
    MinerUBusinessPlan,
    MinerUFactPlan,
    MinerUTablePlan,
    build_mineru_candidate,
    mapper_evidence_payload,
)
from m1.documents.parsing.mineru_regions import (
    EvidenceRecordRegion,
    RecordRegionAssessment,
    assess_record_regions,
)

_TABLE_BBOX = EvidenceBBox(
    x0=20,
    y0=80,
    x1=580,
    y1=760,
    coordinate_space="pdf_points",
)
_TEXT_BBOX = EvidenceBBox(
    x0=20,
    y0=20,
    x1=360,
    y1=60,
    coordinate_space="pdf_points",
)


def _cells(rows: list[list[str | None]]) -> list[EvidenceCell]:
    return [
        EvidenceCell(row=row, column=column, text=value, bbox=_TABLE_BBOX)
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]


def _evidence(
    rows: list[list[str | None]],
    *,
    title: str = "设备总装图 DWG-001",
) -> DocumentEvidence:
    return DocumentEvidence(
        backend="mineru",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="text",
                        text=title,
                        bbox=_TEXT_BBOX,
                        order=0,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=rows,
                        cells=_cells(rows),
                        bbox=_TABLE_BBOX,
                    )
                ],
            )
        ],
    )


def _text_only_evidence(
    *,
    record_text: str = "",
    markdown: str = "",
) -> DocumentEvidence:
    blocks = [
        EvidenceBlock(
            block_id="p1:b0",
            kind="text",
            text="Cable drawing",
            bbox=_TEXT_BBOX,
            order=0,
        )
    ]
    if record_text:
        blocks.append(
            EvidenceBlock(
                block_id="p1:b1",
                kind="text",
                text=record_text,
                bbox=_TABLE_BBOX,
                order=1,
            )
        )
    return DocumentEvidence(
        backend="mineru",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                coordinate_space="pdf_points",
                blocks=blocks,
                tables=[],
                markdown=markdown,
            )
        ],
    )


def _drawing_evidence() -> DocumentEvidence:
    return _evidence(
        [
            ["图号", "版本", "比例", "审核"],
            ["版本", "图号", "审核", "比例"],
        ]
    )


def _mixed_bom_evidence() -> DocumentEvidence:
    """One layout table with a title block and one isolated BOM range."""

    return _evidence(
        [
            ["图号", "DWG-001", "版本", "A", ""],
            ["名称", "设备总装图", "审核", "张三", ""],
            ["零件明细表", "", "", "", ""],
            ["序号", "物料编码", "物料名称", "数量", "单位"],
            ["1", "BOM-001", "线缆组件", "2", "pcs"],
            ["2", "BOM-002", "接插件", "4", "pcs"],
            ["备注", "仅供审核", "", "", ""],
        ]
    )


def _two_bom_regions_evidence() -> DocumentEvidence:
    """Two record regions deliberately share one MinerU table ID."""

    return _evidence(
        [
            ["图号", "DWG-002", "版本", "B", ""],
            ["A 区零件明细表", "", "", "", ""],
            ["序号", "物料编码", "物料名称", "数量", "单位"],
            ["1", "A-001", "线缆", "2", "pcs"],
            ["2", "A-002", "端子", "4", "pcs"],
            ["审核", "张三", "批准", "李四", ""],
            ["B 区零件明细表", "", "", "", ""],
            ["序号", "物料编码", "物料名称", "数量", "单位"],
            ["1", "B-001", "支架", "1", "pcs"],
            ["2", "B-002", "螺钉", "8", "pcs"],
        ],
        title="设备总装图 DWG-002",
    )


def _bom_mappings(*, header_row: int) -> list[MinerUAxisMapping]:
    headers = ["序号", "物料编码", "物料名称", "数量", "单位"]
    fields = ["line_no", "product_code", "name_raw", "quantity", "unit"]
    return [
        MinerUAxisMapping(
            axis_index=index,
            field=field,
            header_evidence_id=f"p1:t0:r{header_row}:c{index}",
            header_quote=headers[index],
        )
        for index, field in enumerate(fields)
    ]


def _table_plan(region: EvidenceRecordRegion) -> MinerUTablePlan:
    assert region.orientation == "rows"
    return MinerUTablePlan(
        region_id=region.region_id,
        table_id=region.table_id,
        orientation=region.orientation,
        header_indices=[region.data_start - 1],
        data_start=region.data_start,
        data_end=region.data_end,
        mappings=_bom_mappings(header_row=region.data_start - 1),
    )


def _technical_plan(*, tables: list[MinerUTablePlan]) -> MinerUBusinessPlan:
    return MinerUBusinessPlan(
        document_type="technical_document",
        document_subtype="approval_drawing",
        classification_evidence_ids=["p1:b0"],
        facts=[
            MinerUFactPlan(
                target="header.title",
                evidence_id="p1:b0",
                quote="设备总装图",
                value="设备总装图",
            )
        ],
        tables=tables,
    )


def _authority_summary(
    assessment: RecordRegionAssessment,
    *,
    bindings: list[dict[str, object]],
) -> dict[str, object]:
    """Use a serializable gate payload so authority can validate independently."""

    region_summary = assessment.model_dump(mode="json")
    region_summary["summary"] = assessment.summary()
    region_summary["mapped_region_ids"] = [
        str(binding["region_id"])
        for binding in bindings
    ]
    region_summary["mapped_region_bindings"] = bindings
    return {
        "status": "completed",
        "pipeline": "mineru_instructor",
        "instructor_complete": True,
        "candidate_isolation": True,
        "rejected_citations": 0,
        "mapper_dropped_mappings": 0,
        "mapper_dropped_tables": 0,
        "mapper_invalid_facts": 0,
        "source_reference_coverage": {"located": 6, "total": 6, "ratio": 1.0},
        "record_region_assessment": region_summary,
    }


def _binding(table: MinerUTablePlan) -> dict[str, object]:
    return {
        "region_id": table.region_id,
        "table_id": table.table_id,
        "orientation": table.orientation,
        "data_start": table.data_start,
        "data_end": table.data_end,
    }


def _candidate(
    tmp_path: Path,
    *,
    evidence: DocumentEvidence,
    assessment: RecordRegionAssessment,
    tables: list[MinerUTablePlan],
) -> DocumentRecord:
    source = tmp_path / "drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename="设备总装图.pdf",
        evidence=evidence,
        plan=_technical_plan(tables=tables),
        record_region_assessment=assessment,
        strict_record_regions=True,
    )
    assert rejected == 0
    metadata = candidate.extraction.setdefault("metadata", {})
    metadata["adapter"] = "mineru_instructor"
    metadata["evidence_complete"] = True
    return candidate


def test_full_authority_accepts_complete_no_record_technical_drawing(
    tmp_path: Path,
) -> None:
    evidence = _drawing_evidence()
    assessment = assess_record_regions(evidence)

    assert assessment.status == "complete"
    assert assessment.assessed_table_ids == ["p1:t0"]
    assert assessment.no_record_table_ids == ["p1:t0"]
    assert assessment.record_regions == []

    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[],
    )
    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[]),
        authority_mode="full",
    )

    assert candidate.lines == []
    assert decision.accepted is True


@pytest.mark.parametrize(
    ("record_text", "markdown"),
    [
        ("BOM\nItem | Part Number | Qty\n1 | SKU-001 | 2 pcs", ""),
        ("", "| Item | Part Number | Qty |\n| 1 | SKU-001 | 2 pcs |"),
    ],
)
def test_unrecovered_text_or_markdown_records_are_inconclusive(
    record_text: str,
    markdown: str,
) -> None:
    assessment = assess_record_regions(
        _text_only_evidence(record_text=record_text, markdown=markdown)
    )

    assert assessment.status == "inconclusive"
    assert assessment.assessed_table_ids == ["p1:unrecovered-record-content"]
    assert assessment.inconclusive_table_ids == [
        "p1:unrecovered-record-content"
    ]
    assert assessment.reasons == [
        "p1:unrecovered-record-content:record_signal_without_table"
    ]


def test_text_only_nonrecord_drawing_keeps_explicit_no_record_path() -> None:
    assessment = assess_record_regions(_text_only_evidence())

    assert assessment.status == "complete"
    assert assessment.assessed_table_ids == []
    assert assessment.record_regions == []


def test_empty_recovered_table_is_an_explicit_no_record_table() -> None:
    assessment = assess_record_regions(_evidence([]))

    assert assessment.status == "complete"
    assert assessment.assessed_table_ids == ["p1:t0"]
    assert assessment.no_record_table_ids == ["p1:t0"]
    assert assessment.record_regions == []


def test_full_authority_rejects_unrecovered_text_only_bom(tmp_path: Path) -> None:
    evidence = _text_only_evidence(
        record_text="BOM\nItem | Part Number | Qty\n1 | SKU-001 | 2 pcs"
    )
    assessment = assess_record_regions(evidence)
    source = tmp_path / "drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=MinerUBusinessPlan(
            document_type="technical_document",
            document_subtype="approval_drawing",
            classification_evidence_ids=["p1:b0"],
            facts=[
                MinerUFactPlan(
                    target="header.title",
                    evidence_id="p1:b0",
                    quote="Cable drawing",
                    value="Cable drawing",
                )
            ],
            tables=[],
        ),
        record_region_assessment=assessment,
        strict_record_regions=True,
    )

    assert rejected == 0
    assert candidate.lines == []
    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[]),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "inconclusive_record_region_assessment" in decision.reasons


def test_record_codes_containing_model_are_not_misclassified_as_headers() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["Item", "Model", "Description", "Qty", "Unit"],
                ["1", "MODEL-100", "Cable assembly", "2", "pcs"],
                ["2", "MODEL-200", "Connector", "4", "pcs"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert assessment.no_record_table_ids == []
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        2,
    )


def test_signal_mapping_header_is_not_a_business_record() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["TYPE C A", "Signal", "TYPE C B"],
                ["A2", "SSTX+", "B11"],
                ["A3", "SSTX-", "B10"],
                ["Shell", "Shield", "Shell"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        3,
    )


def test_document_metadata_before_header_does_not_block_record_region() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["桐曦电子科技有限公司", "", ""],
                ["备货单", "", ""],
                ["订单号", "TX2607150002", ""],
                ["序号", "型号", "名称"],
                ["1", "W-H937", "DP cable"],
                ["2", "W-H938", "DP cable"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        4,
        5,
    )


def test_remark_column_does_not_turn_a_real_header_into_annotation() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["Stocking order", "", "", "", ""],
                ["Order", "TX2607150002", "Date", "2026-07-15", ""],
                ["Item", "Model", "Qty", "Unit", "Remark"],
                *[
                    [str(index), f"W-H{936 + index}", "800", "PCS", "Blue bag"]
                    for index in range(1, 13)
                ],
                ["Total", "", "9600", "", ""],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        3,
        14,
    )


def test_dense_order_rows_with_remark_text_follow_the_strong_header() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["供应商:桐曦 订单号码:PO-20260529-011", *("" for _ in range(8)), "订单日期:2026-06-01", *("" for _ in range(8))],
                ["结款方式:月结90天 收货地址:东莞", *("" for _ in range(8)), "交货日期:2026-06-27", *("" for _ in range(8))],
                [
                    "序号",
                    "产品图片",
                    "型号",
                    "名称",
                    "插头规格",
                    "铝合金",
                    "产品LOGO",
                    "线材规格",
                    "规格米数",
                    "数量",
                    "备品",
                    "采购单价",
                    "金额",
                    "装箱数量",
                    "件数",
                    "包装方式",
                    "备注",
                    "模具编号",
                ],
                ["1", "图片", "HAM-H910", "HDTV线", "仿金", "灰色", "LOGO", "OD7.0", "1.5M", "4010", "7", "2.7", "10827", "200", "20.05", "透明袋", "请注意印字", "H-4"],
                ["2", "图片", "HAM-H912", "HDTV线", "仿金", "灰色", "LOGO", "OD7.0", "3M", "2005", "4", "3.8", "7619", "125", "16.04", "透明袋", "请注意印字", "H-4"],
                ["3", "图片", "HAM-H913", "HDTV线", "仿金", "灰色", "LOGO", "OD7.0", "5M", "1002", "3", "5.8", "5811.6", "80", "12.525", "透明袋", "请注意印字", "H-4"],
                ["", "", "", "", "", "", "", "", "", "7017", "14", "", "24257.6", "", "48.615", "", "", ""],
                ["产品要求:确认镭雕LOGO", *("" for _ in range(17))],
            ],
            title="采购合同",
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        3,
        5,
    )


def test_rows_without_a_formal_code_follow_a_clear_record_header() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["Material", "Description", "Qty", "Unit"],
                ["", "Copper wire", "100", "kg"],
                ["", "Heat-shrink tube", "20", "pcs"],
                ["Total", "", "120", ""],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        2,
    )


def test_wide_order_uses_rows_instead_of_turning_fields_into_records() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                [
                    "图片/产品",
                    "规格型号",
                    "单位/印字",
                    "单位/打轴",
                    "包装",
                    "标贴",
                    "件数",
                    "箱规",
                ],
                ["光纤", "100M", "PCS", "中性", "卷装", "白标", "20", "40PCS"],
                ["光纤", "200M", "PCS", "中性", "卷装", "白标", "10", "20PCS"],
                ["合计", "", "", "", "", "", "30", ""],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        2,
    )


def test_data_value_containing_header_word_is_not_dropped() -> None:
    rows = [["物料代码", "物料名称", "产品规格", "即时库存数量"]]
    rows.extend(
        [f"SKU-{index:03d}", "外壳", f"蓝色{index}尺寸", str(index + 1)]
        for index in range(416)
    )
    assessment = assess_record_regions(_evidence(rows))

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        416,
    )


def test_structural_sum_row_is_not_a_business_record_without_total_label() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["产品", "型号", "数量", "单位", "金额"],
                ["光纤", "A-100", "2", "PCS", "20"],
                ["光纤", "B-200", "3", "PCS", "45"],
                ["", "", "5", "", "65"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        2,
    )


def test_single_record_footer_needs_two_matching_aggregate_columns() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["产品", "型号", "数量", "单位", "件数"],
                ["光纤", "A-100", "40", "PCS", "8"],
                ["", "", "40", "", "8"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        1,
    )


def test_spaced_cjk_total_label_is_not_a_business_record() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["序号", "物料编码", "物料名称", "数量", "单位", "合计金额"],
                ["1", "YA.C.06.0008", "8P8C CAT6 UTP", "10000", "PCS", "750"],
                ["合 计 金 额:", "", "¥750.00", "", "", ""],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        1,
    )


def test_empty_order_table_header_and_summary_do_not_form_column_record() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                [
                    "序号",
                    "物料编码",
                    "物料名称",
                    "规格型号",
                    "单位",
                    "数量",
                    "单价",
                    "合计金额",
                    "备注",
                ],
                ["1", "", "", "", "", "", "", "", ""],
                ["合计金额:", None, "¥", None, None, None, None, None, None],
            ],
            title="采购合同",
        )
    )

    assert assessment.status == "complete"
    assert assessment.record_regions == []
    assert assessment.no_record_table_ids == ["p1:t0"]


def test_orthogonal_structure_guard_preserves_horizontal_order_records() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                [
                    "序号",
                    "物料编码",
                    "物料名称",
                    "规格型号",
                    "单位",
                    "数量",
                    "单价",
                    "合计金额",
                    "备注",
                ],
                ["1", "SKU-001", "标签", "25x12.5", "PCS", "2000", "0.03", "60", ""],
                ["2", "SKU-002", "标签", "30x15", "PCS", "1000", "0.04", "40", ""],
                ["合计金额:", "", "", "", "", "", "", "100", ""],
            ],
            title="采购合同",
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "rows",
        1,
        2,
    )


def test_column_oriented_bom_is_a_single_verified_region() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["Item", "1", "2"],
                ["Part", "SKU-100", "SKU-200"],
                ["Description", "Cable", "Connector"],
                ["Qty", "2", "4"],
                ["Unit", "pcs", "pcs"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    assert (region.orientation, region.data_start, region.data_end) == (
        "columns",
        1,
        2,
    )


def test_revision_table_with_drawing_codes_is_not_a_bom() -> None:
    assessment = assess_record_regions(
        _evidence(
            [
                ["Drawing No", "DWG-001", "Revision", "A"],
                ["Checked", "Zhang", "Version", "V1"],
            ]
        )
    )

    assert assessment.status == "complete"
    assert assessment.no_record_table_ids == ["p1:t0"]
    assert assessment.record_regions == []


def test_mapper_payload_preserves_context_for_a_deep_verified_header() -> None:
    rows = [["", "", "", "", ""] for _ in range(20)]
    rows.extend(
        [
            ["Item", "Code", "Description", "Qty", "Unit"],
            ["1", "P-100", "Cable", "2", "pcs"],
            ["2", "P-200", "Connector", "4", "pcs"],
        ]
    )
    evidence = _evidence(rows)
    assessment = assess_record_regions(evidence)
    payload = mapper_evidence_payload(
        evidence,
        max_chars=12_000,
        record_region_assessment=assessment,
    )

    assert assessment.status == "complete"
    region = assessment.record_regions[0]
    context = payload["record_region_assessment"]["region_context"][0]
    assert context["region_id"] == region.region_id
    assert context["axis_examples"][0]["axis_index"] == 19
    header_axis = next(
        example
        for example in context["axis_examples"]
        if example["axis_index"] == 20
    )
    assert [cell["value"] for cell in header_axis["cells"]] == [
        "Item",
        "Code",
        "Description",
        "Qty",
        "Unit",
    ]


def test_full_authority_maps_only_declared_bom_region_in_mixed_title_block_table(
    tmp_path: Path,
) -> None:
    evidence = _mixed_bom_evidence()
    assessment = assess_record_regions(evidence)

    assert assessment.status == "complete"
    assert assessment.no_record_table_ids == []
    assert len(assessment.record_regions) == 1
    region = assessment.record_regions[0]
    plan = _table_plan(region)

    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[plan],
    )
    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[_binding(plan)]),
        authority_mode="full",
    )

    assert [line.product_code for line in candidate.lines] == ["BOM-001", "BOM-002"]
    assert all("DWG-001" not in line.raw_columns.values() for line in candidate.lines)
    assert all("仅供审核" not in line.raw_columns.values() for line in candidate.lines)
    assert decision.accepted is True


def test_full_authority_rejects_omitted_verified_bom_region(tmp_path: Path) -> None:
    evidence = _mixed_bom_evidence()
    assessment = assess_record_regions(evidence)
    plan = _table_plan(assessment.record_regions[0])
    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[plan],
    )

    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[]),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "unmapped_record_regions" in decision.reasons


def test_full_authority_rejects_fabricated_record_region_binding(
    tmp_path: Path,
) -> None:
    evidence = _mixed_bom_evidence()
    assessment = assess_record_regions(evidence)
    plan = _table_plan(assessment.record_regions[0])
    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[plan],
    )
    fabricated = _binding(plan)
    fabricated["region_id"] = "p1:t0:rows:999:1001"

    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[fabricated]),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "fabricated_record_region" in decision.reasons


def test_full_authority_rejects_cross_region_range_binding(tmp_path: Path) -> None:
    evidence = _two_bom_regions_evidence()
    assessment = assess_record_regions(evidence)
    first, second = assessment.record_regions
    plan = _table_plan(first)
    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[plan],
    )
    cross_region = _binding(plan)
    cross_region["data_end"] = second.data_end

    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(assessment, bindings=[cross_region]),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "cross_region_mapping" in decision.reasons


def test_full_authority_rejects_overlapping_region_bindings(tmp_path: Path) -> None:
    evidence = _mixed_bom_evidence()
    assessment = assess_record_regions(evidence)
    plan = _table_plan(assessment.record_regions[0])
    candidate = _candidate(
        tmp_path,
        evidence=evidence,
        assessment=assessment,
        tables=[plan],
    )

    decision = evaluate_mineru_authority(
        candidate,
        _authority_summary(
            assessment,
            bindings=[_binding(plan), _binding(plan)],
        ),
        authority_mode="full",
    )

    assert decision.accepted is False
    assert "overlapping_region_mappings" in decision.reasons


@pytest.mark.asyncio
async def test_replan_repairs_only_the_failed_region_when_two_regions_share_a_table(
) -> None:
    evidence = _two_bom_regions_evidence()
    assessment = assess_record_regions(evidence)
    first, second = assessment.record_regions
    rows = evidence.pages[0].tables[0].rows

    def proposal_table(
        region: EvidenceRecordRegion,
        *,
        invalid_quantity_axis: bool = False,
    ) -> dict[str, object]:
        mappings: list[dict[str, object]] = [
            {
                "axis_index": index,
                "field": field,
                "header_evidence_id": (
                    f"p1:t0:r{region.data_start - 1}:c{index}"
                ),
                "header_quote": str(rows[region.data_start - 1][index]),
            }
            for index, field in enumerate(
                ("line_no", "product_code", "name_raw", "quantity", "unit")
            )
        ]
        if invalid_quantity_axis:
            mappings[3]["axis_index"] = 99
        return {
            "region_id": region.region_id,
            "table_id": region.table_id,
            "orientation": region.orientation,
            "header_indices": [region.data_start - 1],
            "data_start": region.data_start,
            "data_end": region.data_end,
            "mappings": mappings,
        }

    class ProposalClient:
        calls: ClassVar[list[tuple[type, str]]] = []

        async def run(self, output_type, *, instructions, prompt, request_limit):
            self.calls.append((output_type, prompt))
            assert request_limit == 2
            if len(self.calls) == 1:
                return SimpleNamespace(
                    output=output_type.model_validate(
                        {
                            "document_type": "technical_document",
                            "document_subtype": "approval_drawing",
                            "classification_evidence_ids": ["p1:b0"],
                            "facts": [],
                            "tables": [
                                proposal_table(first),
                                proposal_table(second, invalid_quantity_axis=True),
                            ],
                        }
                    ),
                    duration_seconds=0.01,
                    usage={"requests": 1},
                )
            envelope = json.loads(prompt)
            assert envelope["target_region_ids"] == [second.region_id]
            assert envelope["target_table_ids"] == ["p1:t0"]
            return SimpleNamespace(
                output=output_type.model_validate(
                    {"tables": [proposal_table(second)]}
                ),
                duration_seconds=0.01,
                usage={"requests": 1},
            )

    mapper = MinerUBusinessMapper(client=ProposalClient(), model="qwen35b")
    plan, _duration, usage = await mapper.plan(
        evidence,
        record_region_assessment=assessment,
        strict_record_regions=True,
    )

    assert [table.region_id for table in plan.tables] == [
        first.region_id,
        second.region_id,
    ]
    assert all(len(table.mappings) == 5 for table in plan.tables)
    assert usage["unresolved_dropped_mappings"] == 0


def test_headerless_dense_row_with_arithmetic_summary_is_one_record() -> None:
    rows = [
        ["3月31日客户光纤订单", None, None, None, None, None],
        ["1", "光纤线-铜包钢", "30M", "PCS", "300", "10"],
        [None, None, None, None, None, None],
        ["总件数", None, None, None, "300", "10"],
    ]

    assessment = assess_record_regions(_evidence(rows, title=""))

    assert assessment.status == "complete"
    assert assessment.inconclusive_table_ids == []
    assert len(assessment.record_regions) == 1
    assert assessment.record_regions[0].orientation == "rows"
    assert assessment.record_regions[0].data_start == 1
    assert assessment.record_regions[0].data_end == 1


def test_document_control_footer_does_not_invalidate_a_record_table() -> None:
    rows = [
        ["设备一览表", None, None, None],
        ["序号", "设备名称", "数量", "单位"],
        ["1", "测试机", "2", "台"],
        ["2", "显示器", "1", "台"],
        [None, None, None, None],
        [None, "制定日期：2026/7/11", "制定：", "张三"],
    ]

    assessment = assess_record_regions(_evidence(rows, title=""))

    assert assessment.status == "complete"
    assert len(assessment.record_regions) == 1
    assert assessment.record_regions[0].data_start == 2
    assert assessment.record_regions[0].data_end == 3
