from __future__ import annotations

import pytest
from m1.documents.models import DocumentRecord, DocumentSource
from m1.documents.parsing.mineru_authority import _has_positioned_source_refs
from m1.documents.parsing.mineru_shadow import _source_reference_coverage


def test_source_reference_coverage_accepts_native_and_spreadsheet_locators() -> None:
    candidate = {
        "field_meta": {
            "$.sheet.cell": {
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "B5",
                        "part": "spreadsheet/Sheet1/B5",
                    }
                ]
            },
            "$.docx.colon_cell": {
                "source_refs": [
                    {"page": 1, "part": "mineru/docx:t:0:r1:c1"}
                ]
            },
            "$.docx.slash_cell": {
                "source_refs": [
                    {"page": 1, "part": "mineru/docx:t:0/r1/c2"}
                ]
            },
            "$.docx.paragraph": {
                "source_refs": [{"page": 1, "part": "mineru/docx:p:3"}]
            },
            "$.docx.native_part": {
                "source_refs": [
                    {"page": 1, "part": "word/document.xml#paragraph:3"}
                ]
            },
            "$.unpositioned": {
                "source_refs": [{"page": 1, "part": "mineru/unpositioned"}]
            },
        }
    }

    assert _source_reference_coverage(candidate) == {
        "located": 5,
        "total": 6,
        "ratio": pytest.approx(5 / 6, abs=1e-6),
    }


def test_source_reference_coverage_excludes_only_external_classification_locks() -> None:
    explicit_lock = {
        "source_refs": [],
        "confidence": 1.0,
        "inferred": False,
        "model_mapped": False,
        "manual_locked": True,
        "review_required": False,
        "classification_evidence_source": "explicit_hint",
    }
    candidate = {
        "field_meta": {
            "$.document_type": explicit_lock,
            "$.document_subtype": explicit_lock,
            "$.document_kind_label": explicit_lock,
            "$.header.order_number": {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "mineru/p1:b0",
                        "bbox": [10.0, 20.0, 200.0, 40.0],
                    }
                ]
            },
            "$.lines[0].quantity": {
                **explicit_lock,
                "classification_evidence_source": "manual_review",
            },
        }
    }

    assert _source_reference_coverage(candidate) == {
        "located": 1,
        "total": 2,
        "ratio": 0.5,
    }


@pytest.mark.parametrize(
    "part",
    ["mineru/docx:t:0:r1:c1", "mineru/docx:t:0/r1/c1"],
)
def test_authority_replays_both_native_docx_cell_locator_forms(part: str) -> None:
    path = "$.lines[0].name_raw"
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        field_meta={
            path: {
                "source_refs": [
                    {
                        "page": 1,
                        "part": part,
                        "evidence_id": "docx:t:0:r1:c1",
                        "evidence_quote": "19.5mm*11.4mm",
                    }
                ]
            }
        },
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "tables": [
                            {
                                "table_id": "docx:t:0",
                                "source": "docx-native-ooxml",
                                "rows": [
                                    ["外径尺寸"],
                                    ["unused", "19.5mm*11.4mm"],
                                ],
                            }
                        ],
                    }
                ]
            }
        },
    )

    assert _has_positioned_source_refs(record, path) is True


def test_authority_rejects_native_docx_locator_with_mismatched_quote() -> None:
    path = "$.header.title"
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        field_meta={
            path: {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "mineru/docx:p:1",
                        "evidence_id": "docx:p:1",
                        "evidence_quote": "forged title",
                    }
                ]
            }
        },
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "blocks": [
                            {
                                "block_id": "docx:p:1",
                                "source": "docx-native-ooxml",
                                "text": "actual title",
                            }
                        ],
                    }
                ]
            }
        },
    )

    assert _has_positioned_source_refs(record, path) is False


def test_authority_replays_exact_generic_docx_content_without_attestation() -> None:
    path = "$.generic_facts[0].value"
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        generic_facts=[
            {
                "name": "content_process_step",
                "value": "Cut, polish, and inspect",
                "source_refs": [{"page": 1, "part": "mineru/docx:p:3"}],
                "binding_source": "model",
                "authority": "source",
            }
        ],
        field_meta={
            path: {
                "source_refs": [{"page": 1, "part": "mineru/docx:p:3"}]
            }
        },
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "blocks": [
                            {
                                "block_id": "docx:p:3",
                                "source": "docx-native-ooxml",
                                "text": "Cut, polish, and inspect",
                            }
                        ],
                    }
                ]
            }
        },
    )

    assert _has_positioned_source_refs(record, path) is True
    record.generic_facts[0].value = "Cut, polish, inspect, and ship"
    assert _has_positioned_source_refs(record, path) is False


def test_authority_replays_all_cells_for_deterministic_generic_table_fact() -> None:
    path = "$.generic_facts[0].value"
    references = [
        {"page": 1, "part": "mineru/docx:t:0/r0/c0"},
        {"page": 1, "part": "mineru/docx:t:0/r1/c0"},
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        generic_facts=[
            {
                "name": "table_record",
                "value": {"Product Name": "Connector shell"},
                "source_refs": references,
                "projection_role": "auxiliary_technical",
            }
        ],
        field_meta={path: {"source_refs": references}},
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "tables": [
                            {
                                "table_id": "docx:t:0",
                                "source": "docx-native-ooxml",
                                "rows": [["Product Name"], ["Connector shell"]],
                            }
                        ],
                    }
                ]
            }
        },
    )

    assert _has_positioned_source_refs(record, path) is True
    record.generic_facts[0].value = {"Product Name": "Different product"}
    assert _has_positioned_source_refs(record, path) is False
