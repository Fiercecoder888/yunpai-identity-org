from __future__ import annotations

from pathlib import Path

import pytest
from m1.documents.models import DocumentRecord, DocumentSource, ValidationIssue
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.mineru_tabular_layout import (
    apply_governed_tabular_layout,
)
from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutResolution,
    build_tabular_layout_signature,
)
from m1.documents.tabular_schema import (
    ColumnMapping,
    HeaderFieldMapping,
    TableMapping,
    TabularSchemaPlan,
)
from openpyxl import Workbook


def _workbook(path: Path) -> None:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Sheet1"
    rows = (
        ("order number", "PO-SECRET-1", "customer"),
        ("delivery date", "2026-07-30", "Acme-secret"),
        ("line no", "quantity", "unit"),
        (1, 10, "pcs"),
    )
    for row in rows:
        sheet.append(row)
    workbook.save(path)


def _baseline() -> DocumentRecord:
    return DocumentRecord(
        source=DocumentSource(original_filename="input.xlsx"),
        document_type="unknown",
        document_subtype="unknown",
        validation_issues=[
            ValidationIssue(code="ORDER_TABLE_NOT_FOUND", message="missing")
        ],
    )


def _plan() -> TabularSchemaPlan:
    return TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="horizontal",
                sheet="Sheet1",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
        tables=[
            TableMapping(
                sheet="Sheet1",
                header_rows=[3],
                data_start_row=4,
                columns=[
                    ColumnMapping(column=1, field="line_no"),
                    ColumnMapping(column=2, field="quantity"),
                    ColumnMapping(column=3, field="unit"),
                ],
            )
        ],
    )


class _ReuseRouter:
    required = False

    def __init__(self) -> None:
        self.observations = []

    async def resolve(self, *, tenant_id, probe):
        assert tenant_id == "tenant-a"
        return TabularLayoutResolution(
            action="reuse",
            reason="exact_fingerprint",
            signature_fingerprint=(
                build_tabular_layout_signature(probe).exact_fingerprint()
            ),
            profile_id="profile-1",
            plan=_plan().model_dump(mode="json"),
        )

    async def record_execution_observation(self, observation):
        self.observations.append(observation)
        return True


class _ProposalRouter:
    required = False

    async def resolve(self, *, tenant_id, probe):
        return TabularLayoutResolution(
            action="propose",
            reason="no_compatible_candidates",
            signature_fingerprint=(
                build_tabular_layout_signature(probe).exact_fingerprint()
            ),
            candidate_observation_required=True,
        )


class _FailureRouter:
    def __init__(self, *, required: bool) -> None:
        self.required = required

    async def resolve(self, **_kwargs):
        raise RuntimeError("route unavailable")


@pytest.mark.asyncio
async def test_active_layout_replays_source_values_after_mineru(tmp_path: Path) -> None:
    source = tmp_path / "input.xlsx"
    _workbook(source)
    router = _ReuseRouter()

    result = await apply_governed_tabular_layout(
        _baseline(),
        source=source,
        original_filename="input.xlsx",
        source_kind="xlsx",
        tenant_id="tenant-a",
        task_id="task-1",
        document_type_hint="order",
        document_subtype_hint="customer_purchase_order",
        model="mapper-model",
        router=router,
    )

    assert result.header.order_number == "PO-SECRET-1"
    assert result.lines[0].quantity == 10
    route = result.extraction["metadata"]["tabular_layout_routing"]
    assert route["status"] == "applied"
    assert route["profile_id"] == "profile-1"
    assert route["observation_recorded"] is True
    assert len(router.observations) == 1
    assert router.observations[0].outcome == "success"


@pytest.mark.asyncio
async def test_unseen_layout_keeps_mineru_authority_and_records_advice(
    tmp_path: Path,
) -> None:
    source = tmp_path / "input.xlsx"
    _workbook(source)
    baseline = _baseline()

    result = await apply_governed_tabular_layout(
        baseline,
        source=source,
        original_filename="input.xlsx",
        source_kind="xlsx",
        tenant_id="tenant-a",
        task_id="task-2",
        document_type_hint=None,
        document_subtype_hint=None,
        model="mapper-model",
        router=_ProposalRouter(),
    )

    assert result.header.order_number is None
    route = result.extraction["metadata"]["tabular_layout_routing"]
    assert route["status"] == "advisory"
    assert route["action"] == "propose"
    assert route["authority"] == "mineru_instructor"


@pytest.mark.asyncio
async def test_optional_route_failure_preserves_mineru_document(tmp_path: Path) -> None:
    source = tmp_path / "input.xlsx"
    _workbook(source)

    result = await apply_governed_tabular_layout(
        _baseline(),
        source=source,
        original_filename="input.xlsx",
        source_kind="xlsx",
        tenant_id="tenant-a",
        task_id="task-3",
        document_type_hint=None,
        document_subtype_hint=None,
        model="mapper-model",
        router=_FailureRouter(required=False),
    )

    route = result.extraction["metadata"]["tabular_layout_routing"]
    assert route["status"] == "degraded"
    assert route["error_type"] == "RuntimeError"


@pytest.mark.asyncio
async def test_required_route_failure_fails_closed(tmp_path: Path) -> None:
    source = tmp_path / "input.xlsx"
    _workbook(source)

    with pytest.raises(DocumentRoutingDependencyError):
        await apply_governed_tabular_layout(
            _baseline(),
            source=source,
            original_filename="input.xlsx",
            source_kind="xlsx",
            tenant_id="tenant-a",
            task_id="task-4",
            document_type_hint=None,
            document_subtype_hint=None,
            model="mapper-model",
            router=_FailureRouter(required=True),
        )
