from __future__ import annotations

from types import SimpleNamespace

import pytest
from m1.api import main as api_main
from m1.core.config import Settings
from m1.knowledge.embeddings import OpenAIEmbeddingProvider


def test_embedding_endpoint_falls_back_to_legacy_vlm_settings() -> None:
    settings = Settings(
        VLM_API_KEY="legacy-secret",
        vlm_base_url="http://legacy-vlm.invalid/v1",
        vlm_model="legacy-model",
    )

    assert settings.resolved_knowledge_embedding_base_url == settings.vlm_base_url
    assert settings.resolved_knowledge_embedding_api_key == "legacy-secret"


def test_dedicated_model_endpoints_load_independent_environment_settings(
    monkeypatch,
) -> None:
    monkeypatch.setenv("VLM_BASE_URL", "http://vlm.invalid/v1")
    monkeypatch.setenv("VLM_API_KEY", "vlm-secret")
    monkeypatch.setenv("VLM_MODEL", "vlm-model")
    monkeypatch.setenv("VLM_TIMEOUT_SECONDS", "37")
    monkeypatch.setenv("KNOWLEDGE_EMBEDDING_BASE_URL", "http://embedding.invalid/v1")
    monkeypatch.setenv("KNOWLEDGE_EMBEDDING_API_KEY", "embedding-secret")
    monkeypatch.setenv("KNOWLEDGE_EMBEDDING_MODEL", "embedding-model")
    monkeypatch.setenv("ENHANCED_PREFLIGHT_API_KEY", "preflight-secret")

    settings = Settings()

    assert settings.resolved_knowledge_embedding_base_url == (
        "http://embedding.invalid/v1"
    )
    assert settings.resolved_knowledge_embedding_api_key == "embedding-secret"
    assert settings.knowledge_embedding_model == "embedding-model"
    assert settings.vlm_timeout_seconds == 37.0

    rendered = repr(settings)
    assert "vlm-secret" not in rendered
    assert "embedding-secret" not in rendered
    assert "preflight-secret" not in rendered


def test_tabular_layout_router_has_an_independent_model_contract() -> None:
    settings = Settings(
        VLM_API_KEY="vlm-secret",
        vlm_base_url="http://vlm.invalid/v1",
        vlm_model="vlm-model",
        tabular_layout_router_enabled=True,
        tabular_layout_router_base_url="http://layout.invalid/v1",
        tabular_layout_router_api_key="layout-secret",
        tabular_layout_router_model="layout-model",
        tabular_layout_router_timeout_seconds=17,
        tabular_layout_router_circuit_failures=4,
        tabular_layout_router_circuit_seconds=45,
    )

    assert settings.resolved_tabular_layout_router_base_url == (
        "http://layout.invalid/v1"
    )
    assert settings.resolved_tabular_layout_router_api_key == "layout-secret"
    assert settings.resolved_tabular_layout_router_model == "layout-model"
    assert settings.tabular_layout_router_timeout_seconds == 17
    assert settings.tabular_layout_router_circuit_failures == 4
    assert settings.tabular_layout_router_circuit_seconds == 45
    rendered = repr(settings)
    assert "layout-secret" not in rendered
    assert "vlm-secret" not in rendered


@pytest.mark.parametrize(
    ("field", "message"),
    [
        ("tabular_layout_router_base_url", "TABULAR_LAYOUT_ROUTER_BASE_URL"),
        ("tabular_layout_router_model", "TABULAR_LAYOUT_ROUTER_MODEL"),
    ],
)
def test_enabled_tabular_layout_router_rejects_partial_contract(
    field: str,
    message: str,
) -> None:
    values = {
        "tabular_layout_router_enabled": True,
        "tabular_layout_router_base_url": "http://layout.invalid/v1",
        "tabular_layout_router_api_key": "layout-secret",
        "tabular_layout_router_model": "layout-model",
    }
    values[field] = ""

    with pytest.raises(ValueError, match=message):
        Settings(**values)


@pytest.mark.asyncio
async def test_tabular_layout_runtime_uses_only_its_dedicated_client(
    monkeypatch,
) -> None:
    captured: dict[str, object] = {}

    class FakeStructuredModelClient:
        def __init__(self, **kwargs) -> None:
            captured.update(kwargs)
            self.closed = False

        async def probe(self) -> dict[str, object]:
            return {"ready": True}

        async def close(self) -> None:
            self.closed = True

    settings = Settings(
        tabular_layout_router_enabled=True,
        tabular_layout_router_required=True,
        tabular_layout_router_base_url="http://layout.invalid/v1",
        tabular_layout_router_api_key="layout-secret",
        tabular_layout_router_model="layout-model",
        tabular_layout_router_timeout_seconds=17,
        tabular_layout_router_circuit_failures=4,
        tabular_layout_router_circuit_seconds=45,
    )
    instructor = SimpleNamespace(tabular_layout_router=None)
    runner = SimpleNamespace(instructor_service=instructor)
    monkeypatch.setattr(
        "m1.structured_llm.StructuredModelClient",
        FakeStructuredModelClient,
    )
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=object(), embedding_provider=None),
    )
    monkeypatch.setattr(api_main, "tabular_layout_routing_runtime", None)
    monkeypatch.setattr(api_main, "tabular_layout_routing_client", None)

    await api_main._init_tabular_layout_routing(settings, runner)

    client = api_main.tabular_layout_routing_client
    assert isinstance(client, FakeStructuredModelClient)
    assert instructor.tabular_layout_router is api_main.tabular_layout_routing_runtime
    assert captured["base_url"] == "http://layout.invalid/v1"
    assert captured["api_key"] == "layout-secret"
    assert captured["model"] == "layout-model"
    assert captured["timeout"] == 17
    assert captured["output_mode"] == "prompted"
    runtime = api_main.tabular_layout_routing_runtime
    assert runtime.required is True
    runtime_status = runtime.status_snapshot()
    assert runtime_status["circuit_failures"] == 4
    assert runtime_status["circuit_seconds"] == 45
    startup_status = api_main._tabular_layout_routing_status_snapshot()
    assert startup_status["enabled"] is True
    assert startup_status["required"] is True
    assert startup_status["ready"] is True

    await api_main._close_tabular_layout_routing_runtime()
    assert client.closed is True


def test_mineru_instructor_runtime_limits_load_from_environment(monkeypatch) -> None:
    values = {
        "MINERU_MAPPER_BASE_URL": "http://mapper.invalid/v1",
        "MINERU_MAPPER_API_KEY": "mapper-secret",
        "MINERU_MAPPER_MODEL": "mapper-35b",
        "MINERU_MAPPER_TIMEOUT_SECONDS": "45",
        "MINERU_INSTRUCTOR_MAX_INPUT_CHARS": "64000",
        "MINERU_INSTRUCTOR_SEGMENT_MAX_INPUT_CHARS": "32000",
        "MINERU_INSTRUCTOR_MAX_RETRIES": "1",
        "MINERU_VISUAL_ASSETS_ENABLED": "false",
        "MINERU_VISUAL_ASSETS_MAX": "6",
        "MINERU_VISUAL_ASSET_MAX_BYTES": "8388608",
        "MINERU_VISUAL_ASSET_TIMEOUT_SECONDS": "150",
        "MINERU_DRAWING_REGION_VLM_ENABLED": "false",
        "MINERU_DRAWING_REGION_VLM_BASE_URL": "http://drawing.invalid/v1",
        "MINERU_DRAWING_REGION_VLM_API_KEY": "drawing-secret",
        "MINERU_DRAWING_REGION_VLM_MODEL": "drawing-model",
        "MINERU_DRAWING_REGION_VLM_MAX_REGIONS": "12",
        "MINERU_DRAWING_REGION_VLM_REQUEST_TIMEOUT_SECONDS": "25",
        "MINERU_DRAWING_REGION_VLM_ASSET_TIMEOUT_SECONDS": "140",
        "MINERU_FULL_TIMEOUT_SECONDS": "480",
    }
    for name, value in values.items():
        monkeypatch.setenv(name, value)

    settings = Settings()

    assert settings.mineru_mapper_base_url == "http://mapper.invalid/v1"
    assert settings.mineru_mapper_api_key == "mapper-secret"
    assert settings.mineru_mapper_model == "mapper-35b"
    assert settings.mineru_mapper_timeout_seconds == 45.0
    assert settings.mineru_instructor_max_input_chars == 64_000
    assert settings.mineru_instructor_segment_max_input_chars == 32_000
    assert settings.mineru_instructor_max_retries == 1
    assert settings.mineru_visual_assets_enabled is False
    assert settings.mineru_visual_assets_max == 6
    assert settings.mineru_visual_asset_max_bytes == 8 * 1024 * 1024
    assert settings.mineru_visual_asset_timeout_seconds == 150.0
    assert settings.mineru_drawing_region_vlm_enabled is False
    assert settings.mineru_drawing_region_vlm_base_url == "http://drawing.invalid/v1"
    assert settings.mineru_drawing_region_vlm_api_key == "drawing-secret"
    assert settings.mineru_drawing_region_vlm_model == "drawing-model"
    assert settings.mineru_drawing_region_vlm_max_regions == 12
    assert settings.mineru_drawing_region_vlm_request_timeout_seconds == 25.0
    assert settings.mineru_drawing_region_vlm_asset_timeout_seconds == 140.0
    assert settings.mineru_full_timeout_seconds == 480.0
    rendered = repr(settings)
    assert "mapper-secret" not in rendered
    assert "drawing-secret" not in rendered


def test_embedding_provider_construction_uses_dedicated_endpoint(monkeypatch) -> None:
    captured: dict[str, object] = {}

    class FakeEmbeddingProvider:
        def __init__(self, **kwargs) -> None:
            captured.update(kwargs)

    monkeypatch.setattr(
        "m1.knowledge.embeddings.OpenAIEmbeddingProvider", FakeEmbeddingProvider
    )
    settings = Settings(
        VLM_API_KEY="vlm-secret",
        vlm_base_url="http://vlm.invalid/v1",
        knowledge_embedding_api_key="",
        knowledge_embedding_base_url="http://embedding.invalid/v1",
        knowledge_embedding_model="embedding-model",
        knowledge_embedding_dimensions=1024,
        knowledge_embedding_batch_size=8,
    )

    provider = api_main._knowledge_embedding_provider_for(
        settings,
        schema_dimensions=1024,
    )

    assert isinstance(provider, FakeEmbeddingProvider)
    assert captured == {
        "api_key": "",
        "base_url": "http://embedding.invalid/v1",
        "model": "embedding-model",
        "dimensions": 1024,
        "batch_size": 8,
    }


def test_embedding_provider_keeps_legacy_disabled_without_any_api_key() -> None:
    settings = Settings(
        VLM_API_KEY="",
        knowledge_embedding_base_url=None,
        knowledge_embedding_api_key=None,
    )

    assert (
        api_main._knowledge_embedding_provider_for(
            settings,
            schema_dimensions=1024,
        )
        is None
    )


def test_openai_embedding_provider_uses_empty_sentinel_for_local_endpoint(
    monkeypatch,
) -> None:
    captured: dict[str, object] = {}
    fake_client = SimpleNamespace()

    def fake_async_openai(**kwargs):
        captured.update(kwargs)
        return fake_client

    monkeypatch.setattr("openai.AsyncOpenAI", fake_async_openai)

    provider = OpenAIEmbeddingProvider(
        api_key="",
        base_url="http://embedding.invalid/v1",
        dimensions=1024,
    )

    assert provider.client is fake_client
    assert captured == {
        "api_key": "EMPTY",
        "base_url": "http://embedding.invalid/v1",
    }
