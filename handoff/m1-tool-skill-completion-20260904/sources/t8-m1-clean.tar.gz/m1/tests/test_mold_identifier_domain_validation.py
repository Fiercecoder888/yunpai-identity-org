from __future__ import annotations

from pathlib import Path

import pytest
from m1.documents.models import (
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru_candidate import (
    MinerUAxisMapping,
    MinerUBusinessPlan,
    MinerUTablePlan,
    build_mineru_candidate,
)
from m1.documents.parsing.mineru_domain import (
    has_mold_identifier_shape,
    mold_identifier_validation_issues,
)


def _mold_document(identifier: str, *, document_type: str = "mold") -> DocumentRecord:
    path = "$.lines[0].product_code"
    return DocumentRecord(
        source=DocumentSource(original_filename="molds.xlsx"),
        document_type=document_type,
        document_subtype="mold_mapping" if document_type == "mold" else "unknown",
        lines=[
            OrderLine(
                line_id="mold-1",
                product_code=identifier,
                name_raw="义乌 DP 外模",
            )
        ],
        field_meta={
            path: FieldMetadata(
                source_refs=[
                    SourceReference(
                        sheet="模具",
                        cell="F13",
                        evidence_id="spreadsheet:s0:region1:r11:c2",
                    )
                ]
            )
        },
    )


@pytest.mark.parametrize(
    "identifier",
    [
        "2024-7-005",
        "YJ-22-07-16",
        "2025.03-10",
        "2025'03-006",
        "DP",
        "HDMI-A",
        "12345",
    ],
)
def test_identifier_shaped_mold_numbers_do_not_require_review(identifier: str) -> None:
    document = _mold_document(identifier)

    assert has_mold_identifier_shape(identifier) is True
    assert mold_identifier_validation_issues(document) == []


@pytest.mark.parametrize(
    "identifier",
    ["在二楼", "二楼库位", "待确认", "外模位置 A", "编号缺失"],
)
def test_narrative_mold_numbers_are_retained_and_flagged(identifier: str) -> None:
    document = _mold_document(identifier)

    issues = mold_identifier_validation_issues(document)

    assert document.lines[0].product_code == identifier
    assert len(issues) == 1
    issue = issues[0]
    assert issue.code == "MOLD_IDENTIFIER_AMBIGUOUS"
    assert issue.severity == "warning"
    assert issue.paths == ["$.lines[0].product_code"]
    assert issue.actual == identifier
    assert issue.source_refs[0].cell == "F13"
    assert issue.source_refs[0].evidence_id == "spreadsheet:s0:region1:r11:c2"


def test_mold_identifier_check_does_not_apply_to_other_domains() -> None:
    document = _mold_document("在二楼", document_type="technical_document")

    assert mold_identifier_validation_issues(document) == []
    assert document.lines[0].product_code == "在二楼"


def test_existing_mold_identifier_issue_is_not_duplicated() -> None:
    document = _mold_document("在二楼")
    document.validation_issues.extend(mold_identifier_validation_issues(document))

    assert mold_identifier_validation_issues(document) == []


def test_mineru_candidate_adds_mold_identifier_review_issue(tmp_path: Path) -> None:
    source = tmp_path / "molds.xlsx"
    source.write_bytes(b"fixture")
    table_id = "p1:t0"
    evidence = DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=2,
                height=2,
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="title",
                        text="模号外模明细",
                        order=0,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id=table_id,
                        rows=[["模号", "外模"], ["在二楼", "义乌 DP 外模"]],
                        cells=[
                            EvidenceCell(row=0, column=0, text="模号"),
                            EvidenceCell(row=0, column=1, text="外模"),
                            EvidenceCell(row=1, column=0, text="在二楼"),
                            EvidenceCell(row=1, column=1, text="义乌 DP 外模"),
                        ],
                    )
                ],
            )
        ],
    )
    plan = MinerUBusinessPlan(
        document_type="mold",
        document_subtype="mold_mapping",
        classification_evidence_ids=["p1:b0"],
        tables=[
            MinerUTablePlan(
                table_id=table_id,
                header_indices=[0],
                data_start=1,
                data_end=1,
                mappings=[
                    MinerUAxisMapping(
                        axis_index=0,
                        field="mold_number",
                        header_evidence_id=f"{table_id}:r0:c0",
                        header_quote="模号",
                    ),
                    MinerUAxisMapping(
                        axis_index=1,
                        field="mold_name",
                        header_evidence_id=f"{table_id}:r0:c1",
                        header_quote="外模",
                    ),
                ],
            )
        ],
    )

    candidate, rejected = build_mineru_candidate(
        path=source,
        original_filename=source.name,
        evidence=evidence,
        plan=plan,
    )

    assert rejected == 0
    assert candidate.lines[0].product_code == "在二楼"
    issue = next(
        issue
        for issue in candidate.validation_issues
        if issue.code == "MOLD_IDENTIFIER_AMBIGUOUS"
    )
    assert issue.paths == ["$.lines[0].product_code"]
    assert issue.source_refs[0].part == "mineru/table:p1:t0/row:1/column:0"
    assert candidate.needs_review is True
