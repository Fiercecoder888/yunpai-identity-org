from __future__ import annotations

from typing import Any

import pytest

import m1.knowledge.sinks as sink_module
from m1.documents.models import SourceReference
from m1.knowledge.models import GraphEdge, GraphNode, GraphProjection
from m1.knowledge.sinks import (
    GraphSink,
    Neo4jConfigurationError,
    Neo4jGraphSink,
    Neo4jProjectionError,
)


class _FakeResult:
    def __init__(self, rows: list[dict[str, Any]] | None = None) -> None:
        self.consumed = False
        self.rows = rows or []

    def consume(self) -> None:
        self.consumed = True

    def data(self) -> list[dict[str, Any]]:
        return self.rows


class _FakeTransaction:
    def __init__(self, calls: list[tuple[str, dict[str, Any], _FakeResult]]) -> None:
        self.calls = calls

    def run(self, query: str, **parameters: Any) -> _FakeResult:
        result = _FakeResult()
        self.calls.append((query, parameters, result))
        return result


class _FakeSession:
    def __init__(self, driver: "_FakeDriver", database: str | None) -> None:
        self.driver = driver
        self.database = database

    def __enter__(self) -> "_FakeSession":
        return self

    def __exit__(self, *_: Any) -> None:
        return None

    def execute_write(self, callback: Any) -> Any:
        self.driver.transaction_count += 1
        return callback(_FakeTransaction(self.driver.calls))

    def run(self, query: str, **parameters: Any) -> _FakeResult:
        if "CREATE CONSTRAINT" in query:
            name = query.split("CREATE CONSTRAINT", 1)[1].strip().split()[0]
            self.driver.schema_constraints.add(name)
        rows = (
            [{"name": name} for name in sorted(self.driver.schema_constraints)]
            if "SHOW CONSTRAINTS" in query
            else []
        )
        result = _FakeResult(rows)
        self.driver.calls.append((query, parameters, result))
        return result


class _FakeDriver:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, Any], _FakeResult]] = []
        self.session_databases: list[str | None] = []
        self.transaction_count = 0
        self.connectivity_checks = 0
        self.schema_constraints: set[str] = set()
        self.closed = False

    def session(self, database: str | None = None) -> _FakeSession:
        self.session_databases.append(database)
        return _FakeSession(self, database)

    def verify_connectivity(self) -> None:
        self.connectivity_checks += 1

    def close(self) -> None:
        self.closed = True


def _projection(
    *, source_record_id: str = "source-A", version: str = "v1"
) -> GraphProjection:
    malicious_value = "Robert'); MATCH (victim) DETACH DELETE victim //"
    common = {
        "tenant_id": "tenant-A",
        "source_record_id": source_record_id,
        "version": version,
        "status": "active",
        "confidence": 0.98,
        "source_refs": [SourceReference(sheet="订单", cell="D6")],
        "source_claim_ids": [f"claim-{source_record_id}"],
    }
    return GraphProjection(
        projection_id=f"projection-{source_record_id}-{version}",
        tenant_id="tenant-A",
        source_record_id=source_record_id,
        version=version,
        nodes=[
            GraphNode(
                node_id="document-1",
                labels=["Document", "Order"],
                properties={"order_number": "TX-1"},
                **common,
            ),
            GraphNode(
                node_id="shared-product-1",
                labels=["Product"],
                properties={
                    "name": malicious_value,
                    "acl": {
                        "visibility": "restricted",
                        "roles": ["planner"],
                        "principals": ["user:42"],
                    },
                },
                **common,
            ),
        ],
        edges=[
            GraphEdge(
                edge_id=f"edge-{source_record_id}-{version}",
                relation="HAS_LINE",
                from_node="document-1",
                to_node="shared-product-1",
                properties={"position": 1},
                **common,
            )
        ],
    )


def test_neo4j_sink_uses_one_parameterized_transaction_and_keeps_source_declarations():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, database="m1-knowledge", ensure_schema=False)
    assert isinstance(sink, GraphSink)

    sink.replace_projection(_projection())

    assert driver.transaction_count == 1
    assert driver.session_databases == ["m1-knowledge"]
    assert all(result.consumed for _, _, result in driver.calls)
    joined_queries = "\n".join(query for query, _, _ in driver.calls)
    assert "Robert'); MATCH" not in joined_queries
    assert "SET declaration:M1Document:M1Order" in joined_queries
    assert "SET declaration:M1Product" in joined_queries
    assert "[relationship:M1_HAS_LINE" in joined_queries
    assert "edge_id: row.edge_id" in joined_queries
    assert "source_record_id: row.source_record_id" in joined_queries
    assert "M1NodeDeclaration" in joined_queries
    assert "source_claim_ids" in joined_queries
    assert "projection_lock.generation" in joined_queries
    assert "projection_lock.tombstoned" in joined_queries
    assert "operation_token: $operation_token" in joined_queries
    assert "$tombstoned = true" in joined_queries
    assert "coalesce(projection_lock.tombstoned, false) = false" in joined_queries

    cleanup = [
        call
        for call in driver.calls
        if "$source_record_id" in call[0] and "UNWIND $rows" not in call[0]
    ]
    assert all(call[1]["tenant_id"] == "tenant-A" for call in cleanup)
    assert all(call[1]["source_record_id"] == "source-A" for call in cleanup)
    assert "DETACH DELETE declaration" in joined_queries
    assert "size(coalesce(entity.source_record_ids, [])) = 0" in joined_queries
    assert "NOT (entity)-[:M1_DECLARED_BY]" in joined_queries
    assert "entity.properties_json" not in joined_queries

    rows = [
        row for _, parameters, _ in driver.calls for row in parameters.get("rows", [])
    ]
    product = next(row for row in rows if row.get("node_id") == "shared-product-1")
    relationship = next(row for row in rows if row.get("edge_id"))
    assert "Robert'); MATCH" in product["properties_json"]
    assert product["acl_visibility"] == "restricted"
    assert product["acl_roles"] == ["planner"]
    assert product["acl_principals"] == ["user:42"]
    assert relationship["tenant_id"] == "tenant-A"
    assert relationship["source_record_id"] == "source-A"
    assert relationship["version"] == "v1"
    assert relationship["status"] == "active"
    assert relationship["evidence_json"]
    assert relationship["source_claim_ids"] == ["claim-source-A"]
    assert relationship["acl_visibility"] == "tenant"


def test_neo4j_sink_accepts_procurement_document_label():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    projection = _projection().model_copy(deep=True)
    projection.nodes[0].labels = ["Document", "Procurement"]

    sink.replace_projection(projection)

    joined_queries = "\n".join(query for query, _, _ in driver.calls)
    assert "SET declaration:M1Document:M1Procurement" in joined_queries


def test_neo4j_sink_accepts_archive_document_label():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    projection = _projection().model_copy(deep=True)
    projection.nodes[0].labels = ["Document", "Archive"]

    sink.replace_projection(projection)

    joined_queries = "\n".join(query for query, _, _ in driver.calls)
    assert "SET declaration:M1Archive:M1Document" in joined_queries


def test_neo4j_sink_accepts_commercial_document_label():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    projection = _projection().model_copy(deep=True)
    projection.nodes[0].labels = ["Document", "CommercialDocument"]

    sink.replace_projection(projection)

    joined_queries = "\n".join(query for query, _, _ in driver.calls)
    assert "SET declaration:M1CommercialDocument:M1Document" in joined_queries


@pytest.mark.parametrize(
    ("logical_label", "neo4j_label"),
    [
        ("Order", "M1Order"),
        ("Procurement", "M1Procurement"),
        ("Inventory", "M1Inventory"),
        ("Equipment", "M1Equipment"),
        ("Mold", "M1Mold"),
        ("TechnicalDocument", "M1TechnicalDocument"),
    ],
)
def test_neo4j_sink_preserves_existing_document_label_contract(
    logical_label: str,
    neo4j_label: str,
):
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    projection = _projection().model_copy(deep=True)
    projection.nodes[0].labels = ["Document", logical_label]

    sink.replace_projection(projection)

    joined_queries = "\n".join(query for query, _, _ in driver.calls)
    assert f"SET declaration:M1Document:{neo4j_label}" in joined_queries


def test_neo4j_sink_rejects_unknown_business_label_before_query_generation():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    projection = _projection().model_copy(deep=True)
    projection.nodes[0].labels = ["Document", "UnregisteredDocumentType"]

    with pytest.raises(Neo4jProjectionError, match="not whitelisted"):
        sink.replace_projection(projection)

    assert driver.transaction_count == 0
    assert driver.calls == []


def test_neo4j_sink_replaces_only_the_requested_source_and_supports_health_close():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    sink.replace_projection(_projection(source_record_id="source-A", version="v1"))
    sink.replace_projection(_projection(source_record_id="source-B", version="v7"))

    assert driver.transaction_count == 2
    cleanup_parameters = [
        parameters
        for query, parameters, _ in driver.calls
        if "relationship.source_record_id = $source_record_id" in query
    ]
    assert [item["source_record_id"] for item in cleanup_parameters] == [
        "source-A",
        "source-B",
    ]
    assert sink.health() == {
        "status": "error",
        "backend": "neo4j",
        "database": None,
        "schema_initialized": False,
    }
    assert driver.connectivity_checks == 1
    sink.close()
    sink.close()
    assert driver.closed is True
    with pytest.raises(Neo4jConfigurationError, match="closed"):
        sink.health()


def test_neo4j_sink_rejects_untrusted_schema_and_cross_source_data_before_transaction():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver, ensure_schema=False)
    unsafe = _projection()
    unsafe.nodes[0].labels = ["Document`) MATCH (n) DETACH DELETE n //"]
    with pytest.raises(Neo4jProjectionError, match="not whitelisted"):
        sink.replace_projection(unsafe)
    assert driver.transaction_count == 0

    crossed = _projection()
    crossed.edges[0].source_record_id = "other-source"
    with pytest.raises(Neo4jProjectionError, match="boundary"):
        sink.replace_projection(crossed)
    assert driver.transaction_count == 0

    with pytest.raises(Neo4jConfigurationError, match="identifier"):
        Neo4jGraphSink(
            driver=driver,
            relation_map={"CUSTOM": "BAD`) DELETE n"},
            ensure_schema=False,
        )


def test_neo4j_sink_initializes_unique_constraints_once_by_default():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver)

    sink.ensure_schema()
    first_call_count = len(driver.calls)
    sink.ensure_schema()

    assert first_call_count == 4
    assert len(driver.calls) == first_call_count
    statements = "\n".join(query for query, _, _ in driver.calls)
    assert "m1_entity_identity" in statements
    assert "m1_node_declaration_identity" in statements
    assert "m1_projection_lock_identity" in statements
    assert statements.count("IS UNIQUE") == 3
    assert all(
        result.consumed
        for query, _, result in driver.calls
        if "CREATE CONSTRAINT" in query
    )


def test_neo4j_health_ensures_managed_schema_before_reporting_ready():
    driver = _FakeDriver()
    sink = Neo4jGraphSink(driver=driver)

    health = sink.health()

    assert health == {
        "status": "ok",
        "backend": "neo4j",
        "database": None,
        "schema_initialized": True,
    }
    assert driver.connectivity_checks == 1
    assert len(driver.calls) == 5


def test_neo4j_sink_has_clear_error_when_optional_driver_is_missing(monkeypatch):
    monkeypatch.setattr(sink_module, "GraphDatabase", None)
    with pytest.raises(
        Neo4jConfigurationError, match="official `neo4j` Python package"
    ):
        Neo4jGraphSink(uri="neo4j://localhost:7687")
