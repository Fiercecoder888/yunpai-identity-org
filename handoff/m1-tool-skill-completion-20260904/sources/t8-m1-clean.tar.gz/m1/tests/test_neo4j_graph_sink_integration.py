"""Opt-in tests against a real Neo4j 5 instance.

Run with ``M1_NEO4J_TEST_URI=neo4j://localhost:7687 pytest
tests/test_neo4j_graph_sink_integration.py``.  The test uses an isolated tenant
and removes all of its data on exit.
"""
from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
from uuid import uuid4

import pytest

from m1.knowledge.models import GraphEdge, GraphNode, GraphProjection
from m1.knowledge.sinks import Neo4jGraphSink


_URI = os.getenv("M1_NEO4J_TEST_URI")
pytestmark = pytest.mark.skipif(not _URI, reason="M1_NEO4J_TEST_URI is not configured")


def _projection(tenant: str, source: str, version: str) -> GraphProjection:
    common = {
        "tenant_id": tenant,
        "source_record_id": source,
        "version": version,
        "status": "active",
        "confidence": 1.0,
        "source_refs": [],
        "source_claim_ids": [f"claim-{source}-{version}"],
    }
    return GraphProjection(
        projection_id=f"projection-{source}-{version}",
        tenant_id=tenant,
        source_record_id=source,
        version=version,
        nodes=[
            GraphNode(
                node_id="shared-document",
                labels=["Document", "Order"],
                properties={"order_number": f"ORDER-{source}"},
                **common,
            ),
            GraphNode(
                node_id="shared-product",
                labels=["Product"],
                properties={"model": "DP-100", "acl": {"visibility": "tenant"}},
                **common,
            ),
        ],
        edges=[
            GraphEdge(
                edge_id="intentionally-shared-edge-id",
                relation="HAS_LINE",
                from_node="shared-document",
                to_node="shared-product",
                properties={"source": source},
                **common,
            )
        ],
    )


def test_real_neo4j_shared_nodes_and_concurrent_replace_are_source_safe():
    neo4j = pytest.importorskip("neo4j")
    tenant = f"m1-integration-{uuid4().hex}"
    user = os.getenv("M1_NEO4J_TEST_USER")
    password = os.getenv("M1_NEO4J_TEST_PASSWORD")
    auth = (user, password) if user else None
    database = os.getenv("M1_NEO4J_TEST_DATABASE") or None
    driver = neo4j.GraphDatabase.driver(_URI, auth=auth)
    primary = Neo4jGraphSink(driver=driver, database=database)
    # The primary sink installs constraints before the second worker is allowed
    # to opt out of schema DDL.
    primary.ensure_schema()
    second_worker = Neo4jGraphSink(
        driver=driver, database=database, ensure_schema=False
    )
    source_a, source_b = "source-A", "source-B"

    try:
        # Separate sink instances have separate process-local locks.  Only the
        # constrained M1ProjectionLock can serialize these two writes.
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [
                pool.submit(primary.replace_projection, _projection(tenant, source_a, "v1")),
                pool.submit(
                    second_worker.replace_projection,
                    _projection(tenant, source_a, "v2"),
                ),
            ]
            for future in futures:
                future.result(timeout=30)

        with driver.session(database=database) if database else driver.session() as session:
            versions = session.run(
                """
                MATCH (declaration:M1NodeDeclaration {
                    tenant_id: $tenant_id, source_record_id: $source_record_id
                })
                RETURN collect(DISTINCT declaration.version) AS versions,
                       count(declaration) AS declaration_count
                """,
                tenant_id=tenant,
                source_record_id=source_a,
            ).single()
            edges = session.run(
                """
                MATCH ()-[relationship]->()
                WHERE relationship.m1_managed = true
                  AND relationship.tenant_id = $tenant_id
                  AND relationship.source_record_id = $source_record_id
                RETURN collect(DISTINCT relationship.version) AS versions,
                       count(relationship) AS edge_count
                """,
                tenant_id=tenant,
                source_record_id=source_a,
            ).single()
        assert len(versions["versions"]) == 1
        assert versions["declaration_count"] == 2
        assert edges["versions"] == versions["versions"]
        assert edges["edge_count"] == 1

        primary.replace_projection(_projection(tenant, source_b, "v7"))
        primary.delete_projection(tenant, source_a)
        with driver.session(database=database) if database else driver.session() as session:
            shared = session.run(
                """
                MATCH (entity:M1Entity {
                    tenant_id: $tenant_id, node_id: 'shared-product'
                })
                OPTIONAL MATCH (entity)-[:M1_DECLARED_BY]->(declaration)
                RETURN entity.source_record_ids AS source_ids,
                       collect(declaration.source_record_id) AS declarations
                """,
                tenant_id=tenant,
            ).single()
        assert set(shared["source_ids"]) == {source_b}
        assert set(shared["declarations"]) == {source_b}

        primary.delete_projection(tenant, source_b)
        with driver.session(database=database) if database else driver.session() as session:
            orphan_count = session.run(
                """
                MATCH (entity:M1Entity {
                    tenant_id: $tenant_id, node_id: 'shared-product'
                })
                RETURN count(entity) AS count
                """,
                tenant_id=tenant,
            ).single()["count"]
        assert orphan_count == 0
    finally:
        with driver.session(database=database) if database else driver.session() as session:
            session.run(
                "MATCH (node {tenant_id: $tenant_id}) DETACH DELETE node",
                tenant_id=tenant,
            ).consume()
        primary.close()
