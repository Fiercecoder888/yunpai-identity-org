from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from m1.core.config import Settings
from m1.state import TaskState, TaskStatus
from m1.workflow import persistence as persistence_module
from m1.workflow.persistence import OutboxWorkerTenantRow, TaskStore
from pydantic import ValidationError
from sqlalchemy import delete, select


def _database_url(tmp_path: Path, name: str) -> str:
    return f"sqlite+aiosqlite:///{(tmp_path / name).as_posix()}"


def test_outbox_tenant_registry_schema_is_durable_and_timezone_aware() -> None:
    table = OutboxWorkerTenantRow.__table__

    assert table.name == "outbox_worker_tenants"
    assert [column.name for column in table.primary_key.columns] == ["tenant_id"]
    assert table.c.tenant_id.type.length == 64
    assert table.c.first_seen_at.nullable is False
    assert table.c.first_seen_at.type.timezone is True
    assert table.c.last_seen_at.nullable is False
    assert table.c.last_seen_at.type.timezone is True


@pytest.mark.asyncio
async def test_register_lists_normalized_tenants_and_preserves_first_seen(
    tmp_path: Path,
) -> None:
    store = TaskStore(_database_url(tmp_path, "explicit-tenants.db"))
    await store.init()

    await store.register_outbox_tenant(" Tenant-B ")
    async with store.sessionmaker() as session:
        first = await session.get(OutboxWorkerTenantRow, "tenant-b")
        assert first is not None
        first_seen_at = first.first_seen_at
        last_seen_at = first.last_seen_at

    await asyncio.sleep(0.002)
    await store.register_outbox_tenant("tenant-b")
    await store.register_outbox_tenant("tenant-a")

    assert await store.list_outbox_tenant_ids() == ["tenant-a", "tenant-b"]
    async with store.sessionmaker() as session:
        refreshed = await session.get(OutboxWorkerTenantRow, "tenant-b")
        assert refreshed is not None
        assert refreshed.first_seen_at == first_seen_at
        assert refreshed.last_seen_at > last_seen_at
    await store.close()


@pytest.mark.asyncio
async def test_save_registers_tenant_atomically_and_delete_retains_it(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    store = TaskStore(_database_url(tmp_path, "save-tenants.db"))
    await store.init()
    state = TaskState(
        task_id="tenant-task",
        tenant_id=" Tenant-A ",
        file_path=str(tmp_path / "order.xlsx"),
    )

    await store.save(state)
    assert state.tenant_id == "tenant-a"
    assert await store.list_outbox_tenant_ids() == ["tenant-a"]
    assert await store.delete(state.task_id) is True
    assert await store.list_outbox_tenant_ids() == ["tenant-a"]

    original_statement_factory = persistence_module._outbox_tenant_upsert_statement

    def fail_registry_write(*args, **kwargs):
        raise RuntimeError("synthetic registry failure")

    monkeypatch.setattr(
        persistence_module,
        "_outbox_tenant_upsert_statement",
        fail_registry_write,
    )
    failed_state = TaskState(
        task_id="must-rollback",
        tenant_id="tenant-c",
        file_path=str(tmp_path / "failed.xlsx"),
        status=TaskStatus.DONE,
    )
    with pytest.raises(RuntimeError, match="synthetic registry failure"):
        await store.save(failed_state)
    monkeypatch.setattr(
        persistence_module,
        "_outbox_tenant_upsert_statement",
        original_statement_factory,
    )

    assert await store.load(failed_state.task_id) is None
    assert await store.list_outbox_tenant_ids() == ["tenant-a"]
    await store.close()


@pytest.mark.asyncio
async def test_init_backfills_distinct_task_tenants(tmp_path: Path) -> None:
    database_url = _database_url(tmp_path, "backfill-tenants.db")
    store = TaskStore(database_url)
    await store.init()
    await store.save(TaskState(task_id="a", tenant_id="tenant-z", file_path="z.pdf"))
    await store.save(TaskState(task_id="b", tenant_id="tenant-a", file_path="a.pdf"))
    await store.save(TaskState(task_id="c", tenant_id="tenant-z", file_path="z-2.pdf"))
    async with store.sessionmaker() as session:
        await session.execute(delete(OutboxWorkerTenantRow))
        await session.commit()
    await store.close()

    reopened = TaskStore(database_url)
    await reopened.init()
    assert await reopened.list_outbox_tenant_ids() == ["tenant-a", "tenant-z"]
    async with reopened.sessionmaker() as session:
        rows = (
            (
                await session.execute(
                    select(OutboxWorkerTenantRow).order_by(
                        OutboxWorkerTenantRow.tenant_id
                    )
                )
            )
            .scalars()
            .all()
        )
    assert all(row.first_seen_at == row.last_seen_at for row in rows)
    await reopened.close()


def test_outbox_tenant_config_normalizes_and_deduplicates(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(
        "KNOWLEDGE_OUTBOX_TENANT_IDS",
        " Tenant-B,default,tenant-b,,TENANT_A ",
    )

    configured = Settings()

    assert configured.knowledge_outbox_tenant_ids == "tenant-b,default,tenant_a"
    assert configured.knowledge_outbox_tenant_ids_list == [
        "tenant-b",
        "default",
        "tenant_a",
    ]
    assert Settings(
        knowledge_outbox_tenant_ids=["Tenant-C", "tenant-c", "tenant.d"]
    ).knowledge_outbox_tenant_ids_list == ["tenant-c", "tenant.d"]


@pytest.mark.parametrize(
    "value",
    ["contains space", "-leading-hyphen", "x" * 65, 123],
)
def test_outbox_tenant_config_rejects_invalid_values(value: object) -> None:
    with pytest.raises(ValidationError):
        Settings(knowledge_outbox_tenant_ids=value)


def test_outbox_tenant_config_is_forwarded_by_compose_examples() -> None:
    repository_root = Path(__file__).resolve().parents[2]
    expected = {
        "deploy/source-runtime/compose.yml": 'KNOWLEDGE_OUTBOX_TENANT_IDS: "${M1_KNOWLEDGE_OUTBOX_TENANT_IDS:-}"',
        "m1/deploy/compose.runtime.yml": "KNOWLEDGE_OUTBOX_TENANT_IDS=${M1_KNOWLEDGE_OUTBOX_TENANT_IDS:-}",
    }
    for relative_path, declaration in expected.items():
        assert declaration in (repository_root / relative_path).read_text(
            encoding="utf-8"
        )

    wrapper = (repository_root / "m1/docker-compose.yml").read_text(encoding="utf-8")
    assert "./deploy/compose.runtime.yml" in wrapper

    assert "KNOWLEDGE_OUTBOX_TENANT_IDS=" in (
        repository_root / "m1/.env.example"
    ).read_text(encoding="utf-8")
    assert "M1_KNOWLEDGE_OUTBOX_TENANT_IDS=" in (
        repository_root / "deploy/source-runtime/deploy.env.example"
    ).read_text(encoding="utf-8")
