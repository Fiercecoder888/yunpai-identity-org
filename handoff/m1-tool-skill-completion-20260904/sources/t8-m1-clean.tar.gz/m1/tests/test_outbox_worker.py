from __future__ import annotations

import asyncio
import json
import time
from types import SimpleNamespace

import pytest

from m1.api import main as api_main


@pytest.fixture(autouse=True)
def _reset_retained_outbox_tracking(monkeypatch) -> None:
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", {})
    monkeypatch.setattr(api_main, "_outbox_tenant_reservations", {})
    monkeypatch.setattr(api_main, "_outbox_tenant_started_at", {})
    monkeypatch.setattr(api_main, "_outbox_health_by_tenant", {})
    monkeypatch.setattr(api_main, "_outbox_health_cursor", 0)


class _DrainResult:
    def __init__(self, leased: int) -> None:
        self.leased = leased

    def model_dump(self, *, mode: str) -> dict[str, object]:
        assert mode == "json"
        return {
            "leased": self.leased,
            "delivered": self.leased,
            "retried": 0,
            "terminal_failures": 0,
        }


class _Runtime:
    def __init__(self, backlog: int = 25) -> None:
        self.calls = 0
        self.backlog = backlog
        self.delivered = 0
        self.idle = asyncio.Event()
        self.call_times: list[float] = []

    async def drain_outbox(
        self,
        *,
        tenant_id: str,
        limit: int,
        protect_fresh_seconds: float,
    ):
        assert tenant_id == "default"
        assert limit == 200
        assert protect_fresh_seconds == 0.0
        self.calls += 1
        self.call_times.append(time.monotonic())
        leased = min(10, self.backlog)
        self.backlog -= leased
        self.delivered += leased
        if leased == 0:
            self.idle.set()
        return _DrainResult(leased)


class _Registry:
    def __init__(self, tenant_ids: list[str] | None = None) -> None:
        self.tenant_ids = list(tenant_ids or [])
        self.registered: list[str] = []

    async def register_outbox_tenant(self, tenant_id: str) -> None:
        self.registered.append(tenant_id)

    async def list_outbox_tenant_ids(self) -> list[str]:
        return list(self.tenant_ids)


class _MultiTenantRuntime:
    def __init__(self, *, failing_tenant: str | None = None) -> None:
        self.failing_tenant = failing_tenant
        self.calls: list[tuple[str, int]] = []

    async def drain_outbox(
        self,
        *,
        tenant_id: str,
        limit: int,
        protect_fresh_seconds: float,
    ) -> _DrainResult:
        assert protect_fresh_seconds == 0.0
        self.calls.append((tenant_id, limit))
        if tenant_id == self.failing_tenant:
            raise RuntimeError("isolated tenant failure")
        return _DrainResult(limit)


@pytest.mark.asyncio
async def test_outbox_worker_drains_repeatedly_and_reports_status(monkeypatch) -> None:
    runtime = _Runtime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    api_main._outbox_worker_status.update(
        {
            "enabled": False,
            "running": False,
            "last_started_at": None,
            "last_completed_at": None,
            "last_error_type": None,
            "last_result": None,
        }
    )
    settings = SimpleNamespace(
        knowledge_default_tenant_id="default",
        knowledge_outbox_interval_seconds=0.1,
        knowledge_outbox_batch_size=200,
        knowledge_outbox_protect_fresh_seconds=0.0,
    )
    task = asyncio.create_task(api_main._outbox_worker_loop(settings))
    await asyncio.wait_for(runtime.idle.wait(), timeout=0.5)
    for _ in range(20):
        if (api_main._outbox_worker_status.get("last_result") or {}).get(
            "delivered"
        ) == 0:
            break
        await asyncio.sleep(0.01)
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)

    # One global budget is consumed per tick even while work remains.
    assert runtime.calls == 4
    assert runtime.delivered == 25
    assert all(
        later - earlier >= 0.08
        for earlier, later in zip(runtime.call_times, runtime.call_times[1:])
    )
    assert api_main._outbox_worker_status["running"] is False
    assert api_main._outbox_worker_status["last_error_type"] is None
    assert api_main._outbox_worker_status["last_result"]["delivered"] == 0


@pytest.mark.asyncio
async def test_startup_registers_default_explicit_and_credential_tenants(
    monkeypatch,
) -> None:
    registry = _Registry()
    monkeypatch.setattr(api_main, "store", registry)
    settings = SimpleNamespace(
        knowledge_default_tenant_id="default",
        knowledge_outbox_tenant_ids_list=["tenant-a", "default"],
        tenant_api_key_hashes=json.dumps(
            {
                "a" * 64: {
                    "tenant_id": "tenant-b",
                    "actor_id": "worker",
                    "roles": [],
                }
            }
        ),
    )

    tenant_ids = await api_main._register_configured_outbox_tenants(settings)

    assert tenant_ids == ["default", "tenant-a", "tenant-b"]
    assert registry.registered == tenant_ids


def test_outbox_cycle_plan_rotates_and_never_exceeds_global_budget() -> None:
    tenants = ["tenant-a", "tenant-b", "tenant-c"]

    first, cursor = api_main._outbox_cycle_plan(
        tenants,
        cursor=0,
        batch_size=5,
    )
    second, next_cursor = api_main._outbox_cycle_plan(
        tenants,
        cursor=cursor,
        batch_size=5,
    )

    assert first == [("tenant-a", 2), ("tenant-b", 2), ("tenant-c", 1)]
    assert second == [("tenant-b", 2), ("tenant-c", 2), ("tenant-a", 1)]
    assert sum(limit for _, limit in first) == 5
    assert sum(limit for _, limit in second) == 5
    assert next_cursor == 2

    many, cursor = api_main._outbox_cycle_plan(
        [f"tenant-{index}" for index in range(250)],
        cursor=0,
        batch_size=200,
    )
    assert len(many) == 8
    assert all(limit == 1 for _, limit in many)
    assert sum(limit for _, limit in many) == 8
    assert cursor == 8


@pytest.mark.asyncio
async def test_outbox_cycle_isolates_tenant_failure_and_keeps_fair_budget(
    monkeypatch,
) -> None:
    runtime = _MultiTenantRuntime(failing_tenant="tenant-b")
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    settings = SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0)

    result, cursor = await api_main._drain_outbox_cycle(
        settings,
        tenant_ids=["tenant-a", "tenant-b", "tenant-c"],
        cursor=0,
        batch_size=5,
    )

    assert runtime.calls == [("tenant-a", 2), ("tenant-b", 2), ("tenant-c", 1)]
    assert result == {
        "leased": 3,
        "delivered": 3,
        "retried": 0,
        "lifecycle_waits": 0,
        "terminal_failures": 0,
        "tenant_count": 3,
        "tenants_attempted": 3,
        "tenant_errors": 1,
        "retained_expired": 0,
        "retained_count": 0,
        "retained_reserved": 0,
        "oldest_retained_age_seconds": 0.0,
        "retained_stalled": False,
        "error_type": "RuntimeError",
    }
    assert cursor == 1


@pytest.mark.asyncio
async def test_outbox_cycle_bounds_hung_tenant_and_continues(monkeypatch) -> None:
    class _HungTenantRuntime(_MultiTenantRuntime):
        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            self.calls.append((tenant_id, limit))
            if tenant_id in {"tenant-b", "tenant-c"}:
                await asyncio.Event().wait()
            return _DrainResult(limit)

    runtime = _HungTenantRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", {})
    monkeypatch.setattr(api_main, "_OUTBOX_TENANT_DRAIN_TIMEOUT_SECONDS", 0.05)

    started = time.monotonic()
    result, _ = await asyncio.wait_for(
        api_main._drain_outbox_cycle(
            SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
            tenant_ids=["tenant-a", "tenant-b", "tenant-c"],
            cursor=0,
            batch_size=5,
        ),
        timeout=0.2,
    )
    elapsed = time.monotonic() - started

    assert runtime.calls == [("tenant-a", 2), ("tenant-b", 2), ("tenant-c", 1)]
    assert result["leased"] == 2
    assert result["tenant_errors"] == 2
    assert result["error_type"] == "TimeoutError"
    assert elapsed < 0.08
    assert set(api_main._outbox_tenant_tasks) == {"tenant-b", "tenant-c"}
    assert all(not task.done() for task in api_main._outbox_tenant_tasks.values())
    retained = list(api_main._outbox_tenant_tasks.values())
    for task in retained:
        task.cancel()
    await asyncio.gather(*retained, return_exceptions=True)
    api_main._outbox_tenant_tasks.clear()


@pytest.mark.asyncio
async def test_retained_tenant_tasks_enforce_global_cross_tick_concurrency(
    monkeypatch,
) -> None:
    blocker = asyncio.Event()
    retained = {
        f"tenant-{index}": asyncio.create_task(blocker.wait())
        for index in range(api_main._OUTBOX_TENANT_DRAIN_CONCURRENCY)
    }
    runtime = _MultiTenantRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", retained)

    result, _ = await api_main._drain_outbox_cycle(
        SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
        tenant_ids=[*retained, "tenant-new"],
        cursor=0,
        batch_size=200,
    )

    assert result["tenants_attempted"] == 0
    assert runtime.calls == []
    for task in retained.values():
        task.cancel()
    await asyncio.gather(*retained.values(), return_exceptions=True)
    api_main._outbox_tenant_tasks.clear()


@pytest.mark.asyncio
async def test_sparse_tenants_reuse_budget_across_concurrent_waves(
    monkeypatch,
) -> None:
    class _SparseRuntime:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []
            self.active = 0
            self.max_active = 0

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            assert protect_fresh_seconds == 0.0
            self.calls.append((tenant_id, limit))
            self.active += 1
            self.max_active = max(self.max_active, self.active)
            try:
                await asyncio.sleep(0)
                return _DrainResult(1)
            finally:
                self.active -= 1

    runtime = _SparseRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", {})
    tenants = [f"tenant-{index}" for index in range(250)]

    result, cursor = await api_main._drain_outbox_cycle(
        SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
        tenant_ids=tenants,
        cursor=0,
        batch_size=200,
        cycle_timeout_seconds=1.0,
    )

    assert result["leased"] == 200
    assert result["tenants_attempted"] == 200
    assert len(runtime.calls) == 200
    assert runtime.max_active == api_main._OUTBOX_TENANT_DRAIN_CONCURRENCY
    assert all(limit == 1 for _tenant_id, limit in runtime.calls)
    assert cursor == 200


@pytest.mark.asyncio
async def test_one_hot_tenant_reuses_sparse_quota_in_same_tick(monkeypatch) -> None:
    class _OneHotRuntime:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            assert protect_fresh_seconds == 0.0
            self.calls.append((tenant_id, limit))
            return _DrainResult(limit if tenant_id == "tenant-hot" else 0)

    runtime = _OneHotRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    tenants = ["tenant-hot", *[f"tenant-{index}" for index in range(199)]]

    result, _cursor = await api_main._drain_outbox_cycle(
        SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
        tenant_ids=tenants,
        cursor=0,
        batch_size=200,
        cycle_timeout_seconds=1.0,
    )

    hot_limits = [limit for tenant_id, limit in runtime.calls if tenant_id == "tenant-hot"]
    assert hot_limits == [1, 199]
    assert result["leased"] == 200
    assert sum(limit for _tenant_id, limit in runtime.calls) <= 399


@pytest.mark.asyncio
async def test_failed_tenants_cannot_reuse_possibly_leased_budget(
    monkeypatch,
) -> None:
    class _LeaseThenFailRuntime:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            self.calls.append((tenant_id, limit))
            raise RuntimeError("failure after an unknown number of leases")

    runtime = _LeaseThenFailRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", {})

    result, _ = await api_main._drain_outbox_cycle(
        SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
        tenant_ids=[f"tenant-{index}" for index in range(250)],
        cursor=0,
        batch_size=200,
        cycle_timeout_seconds=1.0,
    )

    assert sum(limit for _tenant_id, limit in runtime.calls) == 200
    assert len(runtime.calls) == 200
    assert result["leased"] == 0
    assert result["tenant_errors"] == 200


@pytest.mark.asyncio
async def test_retained_quota_is_reserved_across_ticks(monkeypatch) -> None:
    class _DelayedRuntime:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []
            self.first_started = asyncio.Event()
            self.release_first = asyncio.Event()

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            self.calls.append((tenant_id, limit))
            if len(self.calls) == 1:
                self.first_started.set()
                await self.release_first.wait()
            return _DrainResult(limit)

    runtime = _DelayedRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    settings = SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0)

    first, cursor = await api_main._drain_outbox_cycle(
        settings,
        tenant_ids=["tenant-a"],
        cursor=0,
        batch_size=200,
        cycle_timeout_seconds=0.01,
    )
    assert first["retained_reserved"] == 200
    assert runtime.calls == [("tenant-a", 200)]

    second, cursor = await api_main._drain_outbox_cycle(
        settings,
        tenant_ids=["tenant-a", "tenant-b"],
        cursor=cursor,
        batch_size=200,
        cycle_timeout_seconds=0.01,
    )
    assert second["tenants_attempted"] == 0
    assert second["retained_reserved"] == 200
    assert runtime.calls == [("tenant-a", 200)]

    runtime.release_first.set()
    await asyncio.gather(*api_main._outbox_tenant_tasks.values())
    third, _ = await api_main._drain_outbox_cycle(
        settings,
        tenant_ids=["tenant-a", "tenant-b"],
        cursor=cursor,
        batch_size=200,
        cycle_timeout_seconds=0.1,
    )

    assert third["retained_reserved"] == 0
    assert any(tenant_id == "tenant-b" for tenant_id, _limit in runtime.calls)


@pytest.mark.asyncio
async def test_expired_retained_task_releases_worker_slot(monkeypatch) -> None:
    blocker = asyncio.Event()
    expired = asyncio.create_task(blocker.wait())
    loop = asyncio.get_running_loop()
    api_main._outbox_tenant_tasks["tenant-old"] = expired
    api_main._outbox_tenant_reservations["tenant-old"] = 200
    api_main._outbox_tenant_started_at["tenant-old"] = loop.time() - 1.0
    monkeypatch.setattr(api_main, "_OUTBOX_RETAINED_MAX_SECONDS", 0.01)
    runtime = _MultiTenantRuntime()
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)

    result, _ = await api_main._drain_outbox_cycle(
        SimpleNamespace(knowledge_outbox_protect_fresh_seconds=0.0),
        tenant_ids=["tenant-new"],
        cursor=0,
        batch_size=200,
        cycle_timeout_seconds=0.1,
    )

    assert expired.cancelled()
    assert result["retained_expired"] == 1
    assert result["error_type"] == "RetainedTaskExpired"
    assert runtime.calls == [("tenant-new", 200)]


@pytest.mark.asyncio
async def test_slow_tenant_does_not_delay_later_tenant_beyond_next_tick(
    monkeypatch,
) -> None:
    class _SlowFirstRuntime:
        def __init__(self) -> None:
            self.blocker = asyncio.Event()
            self.later_seen = asyncio.Event()

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            if tenant_id == "default":
                await self.blocker.wait()
            if tenant_id == "tenant-8":
                self.later_seen.set()
            return _DrainResult(0)

    runtime = _SlowFirstRuntime()
    registry = _Registry([f"tenant-{index}" for index in range(9)])
    monkeypatch.setattr(api_main, "store", registry)
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_cursor", 0)
    monkeypatch.setattr(api_main, "_outbox_tenant_tasks", {})
    settings = SimpleNamespace(
        knowledge_default_tenant_id="default",
        knowledge_outbox_tenant_ids_list=[],
        tenant_api_key_hashes="",
        knowledge_outbox_interval_seconds=0.05,
        knowledge_outbox_batch_size=200,
        knowledge_outbox_protect_fresh_seconds=0.0,
    )

    worker = asyncio.create_task(api_main._outbox_worker_loop(settings))
    await asyncio.wait_for(runtime.later_seen.wait(), timeout=0.2)
    worker.cancel()
    await asyncio.gather(worker, return_exceptions=True)

    retained = list(api_main._outbox_tenant_tasks.values())
    for task in retained:
        task.cancel()
    await asyncio.gather(*retained, return_exceptions=True)
    api_main._outbox_tenant_tasks.clear()


@pytest.mark.asyncio
async def test_worker_builds_anonymous_aggregate_health_snapshot(monkeypatch) -> None:
    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            if tenant_id == "tenant-b":
                raise RuntimeError("private failure details")
            return {
                "pending": 2 if tenant_id == "default" else 5,
                "oldest_pending_age_seconds": (
                    10.0 if tenant_id == "default" else 80.0
                ),
                "terminal_failures": 1 if tenant_id == "tenant-c" else 0,
                "max_attempts": 4 if tenant_id == "tenant-c" else 1,
                "by_projection": {
                    "graph": {"pending": 1},
                    "knowledge": {
                        "pending": 1 if tenant_id == "default" else 4
                    },
                },
            }

    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )

    snapshot = await api_main._outbox_health_snapshot(
        ["default", "tenant-b", "tenant-c"]
    )

    assert snapshot is not None
    assert snapshot["tenant_count"] == 3
    assert snapshot["pending"] == 7
    assert snapshot["oldest_pending_age_seconds"] == 80.0
    assert snapshot["terminal_failures"] == 1
    assert snapshot["max_attempts"] == 4
    assert snapshot["by_projection"] == {
        "graph": {"pending": 2},
        "knowledge": {"pending": 5},
    }
    assert snapshot["status_error_count"] == 1
    assert snapshot["status_error"] == "RuntimeError"
    assert snapshot["health_complete"] is False
    assert "tenant-b" not in json.dumps(snapshot)
    assert "private failure details" not in json.dumps(snapshot)


@pytest.mark.asyncio
async def test_health_snapshot_accepts_an_empty_tenant_registry(monkeypatch) -> None:
    class _HealthStore:
        async def projection_outbox_health(self, _tenant_id: str):
            raise AssertionError("an empty registry must not call the store")

    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )

    snapshot = await api_main._outbox_health_snapshot([])

    assert snapshot is not None
    assert snapshot["tenant_count"] == 0
    assert snapshot["pending"] == 0
    assert snapshot["status_error_count"] == 0
    assert snapshot["health_complete"] is True


@pytest.mark.asyncio
async def test_health_snapshot_times_out_one_tenant_without_losing_others(
    monkeypatch,
) -> None:
    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            if tenant_id == "tenant-slow":
                await asyncio.Event().wait()
            return {
                "pending": 4,
                "oldest_pending_age_seconds": 9.0,
                "terminal_failures": 0,
            }

    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS", 0.01)
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )

    snapshot = await asyncio.wait_for(
        api_main._outbox_health_snapshot(["default", "tenant-slow"]),
        timeout=0.2,
    )

    assert snapshot is not None
    assert snapshot["pending"] == 4
    assert snapshot["tenant_count"] == 2
    assert snapshot["status_error_count"] == 1
    assert snapshot["status_error"] == "TimeoutError"
    assert snapshot["health_complete"] is False


@pytest.mark.asyncio
async def test_health_snapshot_bounds_and_rotates_a_250_tenant_round(
    monkeypatch,
) -> None:
    started: list[str] = []

    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            started.append(tenant_id)
            await asyncio.Event().wait()

    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_CONCURRENCY", 8)
    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_TIMEOUT_SECONDS", 10.0)
    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_CYCLE_TIMEOUT_SECONDS", 0.02)
    monkeypatch.setattr(api_main, "_outbox_health_cursor", 0)
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )
    tenant_ids = [f"tenant-{index}" for index in range(250)]
    loop = asyncio.get_running_loop()

    started_at = loop.time()
    first = await asyncio.wait_for(
        api_main._outbox_health_snapshot(tenant_ids),
        timeout=0.2,
    )
    elapsed = loop.time() - started_at

    assert first is not None
    assert elapsed < 0.2
    assert first["tenant_count"] == 250
    assert first["status_error_count"] == 250
    assert first["status_error"] == "HealthCycleTimeout"
    assert first["health_complete"] is False
    assert started[:8] == tenant_ids[:8]

    started.clear()
    await asyncio.wait_for(
        api_main._outbox_health_snapshot(tenant_ids),
        timeout=0.2,
    )
    assert started[:8] == tenant_ids[8:16]


@pytest.mark.asyncio
async def test_health_snapshot_completes_eleven_tenants_across_two_cycles(
    monkeypatch,
) -> None:
    calls: list[str] = []

    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            calls.append(tenant_id)
            tenant_number = int(tenant_id.removeprefix("tenant-"))
            return {
                "pending": tenant_number,
                "oldest_pending_age_seconds": float(tenant_number),
                "terminal_failures": 0,
                "max_attempts": tenant_number,
                "by_projection": {"knowledge": {"pending": tenant_number}},
            }

    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_CONCURRENCY", 8)
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )
    tenant_ids = [f"tenant-{index}" for index in range(11)]

    first = await api_main._outbox_health_snapshot(tenant_ids)
    second = await api_main._outbox_health_snapshot(tenant_ids)

    assert first is not None
    assert first["tenant_count"] == 11
    assert first["status_error_count"] == 3
    assert first["status_error"] == "HealthCyclePending"
    assert first["health_complete"] is False
    assert second is not None
    assert second["pending"] == sum(range(11))
    assert second["oldest_pending_age_seconds"] == 10.0
    assert second["max_attempts"] == 10
    assert second["by_projection"] == {"knowledge": {"pending": sum(range(11))}}
    assert second["status_error_count"] == 0
    assert second["health_complete"] is True
    assert calls[:8] == tenant_ids[:8]
    assert calls[8:16] == tenant_ids[8:] + tenant_ids[:5]


@pytest.mark.asyncio
async def test_health_snapshot_replaces_cached_failure_on_later_success(
    monkeypatch,
) -> None:
    attempts: dict[str, int] = {}

    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            attempts[tenant_id] = attempts.get(tenant_id, 0) + 1
            if tenant_id == "tenant-0" and attempts[tenant_id] == 1:
                raise RuntimeError("transient private failure")
            return {
                "pending": 0,
                "oldest_pending_age_seconds": 0.0,
                "terminal_failures": 0,
                "max_attempts": 0,
            }

    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_CONCURRENCY", 8)
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )
    tenant_ids = [f"tenant-{index}" for index in range(11)]

    first = await api_main._outbox_health_snapshot(tenant_ids)
    second = await api_main._outbox_health_snapshot(tenant_ids)

    assert first is not None
    assert first["status_error_count"] == 4
    assert first["status_error"] == "RuntimeError"
    assert first["health_complete"] is False
    assert second is not None
    assert second["status_error_count"] == 0
    assert second["health_complete"] is True
    assert attempts["tenant-0"] == 2
    assert "transient private failure" not in json.dumps(second)


@pytest.mark.asyncio
async def test_health_snapshot_prunes_removed_tenants_and_fails_closed(
    monkeypatch,
) -> None:
    failing_tenants: set[str] = set()

    class _HealthStore:
        async def projection_outbox_health(self, tenant_id: str):
            if tenant_id in failing_tenants:
                raise RuntimeError("private failure")
            return {
                "pending": 1,
                "oldest_pending_age_seconds": 1.0,
                "terminal_failures": 0,
                "max_attempts": 1,
            }

    monkeypatch.setattr(api_main, "_OUTBOX_HEALTH_PROBE_CONCURRENCY", 8)
    monkeypatch.setattr(
        api_main,
        "knowledge_runtime",
        SimpleNamespace(store=_HealthStore()),
    )
    tenant_ids = ["tenant-a", "tenant-b"]

    healthy = await api_main._outbox_health_snapshot(tenant_ids)
    failing_tenants.add("tenant-a")
    failed = await api_main._outbox_health_snapshot(tenant_ids)
    pruned = await api_main._outbox_health_snapshot(["tenant-b"])

    assert healthy is not None
    assert healthy["health_complete"] is True
    assert failed is not None
    assert failed["status_error_count"] == 1
    assert failed["health_complete"] is False
    assert pruned is not None
    assert pruned["tenant_count"] == 1
    assert pruned["pending"] == 1
    assert pruned["status_error_count"] == 0
    assert pruned["health_complete"] is True
    assert set(api_main._outbox_health_by_tenant) == {"tenant-b"}


@pytest.mark.asyncio
async def test_slow_health_refresh_does_not_pause_outbox_delivery(monkeypatch) -> None:
    class _SlowHealthStore:
        async def projection_outbox_health(self, _tenant_id: str):
            await asyncio.Event().wait()

    runtime = _Runtime(backlog=1)
    runtime.store = _SlowHealthStore()
    monkeypatch.setattr(api_main, "store", _Registry())
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_cursor", 0)
    monkeypatch.setattr(api_main, "_outbox_health_task", None)
    settings = SimpleNamespace(
        knowledge_default_tenant_id="default",
        knowledge_outbox_tenant_ids_list=[],
        tenant_api_key_hashes="",
        knowledge_outbox_interval_seconds=0.1,
        knowledge_outbox_batch_size=200,
        knowledge_outbox_protect_fresh_seconds=0.0,
    )

    worker = asyncio.create_task(api_main._outbox_worker_loop(settings))
    await asyncio.wait_for(runtime.idle.wait(), timeout=0.4)
    worker.cancel()
    await asyncio.gather(worker, return_exceptions=True)
    health_worker = api_main._outbox_health_task
    if health_worker is not None:
        health_worker.cancel()
        await asyncio.gather(health_worker, return_exceptions=True)
        monkeypatch.setattr(api_main, "_outbox_health_task", None)

    assert runtime.calls == 2
    assert runtime.delivered == 1


@pytest.mark.asyncio
async def test_failed_health_refresh_marks_previous_cache_incomplete(
    monkeypatch,
) -> None:
    async def fail_snapshot(_tenant_ids):
        raise RuntimeError("private health failure")

    monkeypatch.setattr(api_main, "_outbox_health_snapshot", fail_snapshot)
    monkeypatch.setattr(api_main, "_outbox_health_task", asyncio.current_task())
    api_main._outbox_worker_status["health"] = {
        "pending": 3,
        "tenant_count": 1,
        "health_complete": True,
    }

    await api_main._refresh_outbox_health_cache(
        ["default", "tenant-private"],
        registry_error_type=None,
    )

    cached = api_main._outbox_worker_status["health"]
    assert cached["pending"] == 3
    assert cached["tenant_count"] == 2
    assert cached["health_complete"] is False
    assert cached["refresh_error_type"] == "RuntimeError"
    assert "tenant-private" not in json.dumps(cached)
    assert "private health failure" not in json.dumps(cached)


@pytest.mark.asyncio
async def test_worker_refreshes_registry_on_the_next_backlog_tick(
    monkeypatch,
) -> None:
    class _RefreshingRegistry:
        def __init__(self) -> None:
            self.calls = 0

        async def list_outbox_tenant_ids(self) -> list[str]:
            self.calls += 1
            return [] if self.calls == 1 else ["tenant-b"]

    class _RefreshRuntime:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []
            self.found_new_tenant = asyncio.Event()

        async def drain_outbox(
            self,
            *,
            tenant_id: str,
            limit: int,
            protect_fresh_seconds: float,
        ) -> _DrainResult:
            self.calls.append((tenant_id, limit))
            if tenant_id == "tenant-b":
                self.found_new_tenant.set()
                return _DrainResult(0)
            return _DrainResult(1 if len(self.calls) == 1 else 0)

    registry = _RefreshingRegistry()
    runtime = _RefreshRuntime()
    monkeypatch.setattr(api_main, "store", registry)
    monkeypatch.setattr(api_main, "knowledge_runtime", runtime)
    monkeypatch.setattr(api_main, "_outbox_tenant_cursor", 0)
    settings = SimpleNamespace(
        knowledge_default_tenant_id="default",
        knowledge_outbox_tenant_ids_list=[],
        tenant_api_key_hashes="",
        knowledge_outbox_interval_seconds=0.1,
        knowledge_outbox_batch_size=200,
        knowledge_outbox_protect_fresh_seconds=0.0,
    )

    task = asyncio.create_task(api_main._outbox_worker_loop(settings))
    await asyncio.wait_for(runtime.found_new_tenant.wait(), timeout=0.5)
    for _ in range(20):
        if api_main._outbox_worker_status.get("tenant_count") == 2:
            break
        await asyncio.sleep(0.01)
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)

    assert registry.calls >= 2
    assert runtime.calls[:3] == [
        ("default", 200),
        ("default", 100),
        ("tenant-b", 100),
    ]
    assert api_main._outbox_worker_status["tenant_count"] == 2
