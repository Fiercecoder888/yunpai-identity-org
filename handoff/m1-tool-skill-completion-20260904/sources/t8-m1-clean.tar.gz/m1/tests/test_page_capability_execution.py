from __future__ import annotations

from pathlib import Path

import pytest
from m1.documents.models import DocumentRecord
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
)
from m1.documents.parsing.page_capability_execution import (
    PAGE_CAPABILITY_PAGE_BUDGET,
    resolve_pdf_page_capabilities,
)
from m1.documents.parsing.region_capability_contracts import (
    ParsingCapability,
    RegionCapabilityRoutingDecision,
    RegionFeature,
    RegionSourceKind,
)
from m1.documents.parsing.service import DocumentParserService
from m1.documents.parsing.structured import merge_evidence
from PIL import Image


class _Backend:
    def __init__(self, evidence: DocumentEvidence, *, name: str) -> None:
        self.evidence = evidence
        self.name = name
        self.calls: list[tuple[int, ...] | None] = []

    def readiness(self) -> dict[str, object]:
        return {"backend": self.name, "ready": True}

    def parse(self, path, *, pages=None) -> DocumentEvidence:
        del path
        self.calls.append(
            None if pages is None else tuple(page.page_number for page in pages)
        )
        result = self.evidence.model_copy(deep=True)
        if pages is not None:
            requested = {page.page_number for page in pages}
            result.pages = [
                page for page in result.pages if page.page_number in requested
            ]
        return result


class _Router:
    def __init__(
        self,
        decisions: dict[int, RegionCapabilityRoutingDecision] | None = None,
        *,
        error: Exception | None = None,
        required: bool = False,
    ) -> None:
        self.decisions = decisions or {}
        self.error = error
        self.required = required
        self.calls = 0
        self.probes = []

    async def resolve(self, *, tenant_id, probe):
        assert tenant_id == "tenant-a"
        self.calls += 1
        self.probes.append(probe)
        if self.error is not None:
            raise self.error
        # Probe content is deliberately bucketed and value-free. Page order is
        # stable in this test, so use call count to choose the canned decision.
        return self.decisions[self.calls]


def _decision(
    action: str,
    *,
    capability: ParsingCapability | None = None,
    profile_id: str | None = None,
) -> RegionCapabilityRoutingDecision:
    common = {
        "action": action,
        "reason": {
            "route": "exact_active_profile",
            "generic": "model_generic",
            "review": "model_review",
        }[action],
        "signature_fingerprint": "a" * 64,
        "capability": capability,
        "profile_id": profile_id,
        "review_required": action == "review",
    }
    return RegionCapabilityRoutingDecision.model_validate(common)


def _page(
    page_number: int,
    *,
    bbox_x: float = 0.0,
    confidence: float = 0.5,
    rotation: int = 0,
) -> EvidencePage:
    return EvidencePage(
        page_number=page_number,
        page_index=page_number - 1,
        width=100,
        height=100,
        rotation=rotation,
        blocks=[
            EvidenceBlock(
                block_id=f"block-{page_number}",
                text="重复文字",
                confidence=confidence,
                bbox=EvidenceBBox(x0=bbox_x, y0=1, x1=bbox_x + 20, y1=10),
            )
        ],
    )


def _document(page_paths: list[Path]) -> dict:
    return {
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "header": {},
        "lines": [],
        "bom": [],
        "field_meta": {},
        "validation_issues": [],
        "extraction": {
            "raw_content": {
                "pages": [
                    {
                        "page_number": index,
                        "page_index": index - 1,
                        "width": 100,
                        "height": 100,
                        "render_asset": str(path),
                    }
                    for index, path in enumerate(page_paths, start=1)
                ]
            }
        },
    }


def _record(page_paths: list[Path]) -> DocumentRecord:
    payload = _document(page_paths)
    payload["source"] = {
        "original_filename": "sample.pdf",
        "sha256": "b" * 64,
        "mime_type": "application/pdf",
    }
    return DocumentRecord.model_validate(payload)


def _assets(tmp_path: Path, count: int) -> list[Path]:
    paths: list[Path] = []
    for index in range(1, count + 1):
        path = tmp_path / f"page-{index}.png"
        path.write_bytes(b"rendered-page")
        paths.append(path)
    return paths


@pytest.mark.asyncio
async def test_page_routes_and_generic_fallback_share_one_vlm_batch(
    tmp_path: Path,
) -> None:
    paths = _assets(tmp_path, 2)
    pp = _Backend(
        DocumentEvidence(
            backend="pp-structure-v3",
            pages=[_page(1), _page(2, rotation=90)],
        ),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(
            backend="paddleocr-vl",
            pages=[_page(1, bbox_x=30), _page(2, bbox_x=30, rotation=90)],
        ),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            ),
            2: _decision("generic"),
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
    )

    evidence = await service._pdf_evidence(
        tmp_path / "sample.pdf",
        _document(paths),
        tenant_id="tenant-a",
    )

    assert router.calls == 2
    assert pp.calls == [(1, 2)]
    assert vl.calls == [(1, 2)]
    assert evidence.raw["vlm_escalated_pages"] == [1, 2]
    assert evidence.raw["region_capability_routing"]["routed_pages"] == [1]
    assert evidence.raw["completed_capabilities_by_page"] == {
        "1": ["pp_structure_v3", "paddleocr_vl"],
        "2": ["pp_structure_v3", "paddleocr_vl"],
    }
    assert [block.text for block in evidence.pages[0].blocks] == [
        "重复文字",
        "重复文字",
    ]


@pytest.mark.asyncio
async def test_identical_page_signatures_share_one_router_decision() -> None:
    evidence = DocumentEvidence(
        backend="pp-structure-v3",
        pages=[_page(1), _page(2), _page(3)],
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )

    plan = await resolve_pdf_page_capabilities(
        evidence,
        router=router,
        tenant_id="tenant-a",
        page_numbers=(1, 2, 3),
    )

    assert router.calls == 1
    assert plan.paddleocr_vl_pages == frozenset({1, 2, 3})
    assert plan.audit["unique_signatures"] == 1
    assert plan.audit["router_calls"] == 1
    assert plan.audit["deduplicated_pages"] == [2, 3]
    assert plan.audit["decisions"]["2"]["signature_reused_from_page"] == 1


@pytest.mark.asyncio
async def test_page_budget_prioritizes_deterministic_escalation_pages() -> None:
    evidence = DocumentEvidence(
        backend="pp-structure-v3",
        pages=[_page(page_number) for page_number in range(1, 5)],
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )

    plan = await resolve_pdf_page_capabilities(
        evidence,
        router=router,
        tenant_id="tenant-a",
        page_numbers=range(1, 5),
        priority_page_numbers=(4,),
        page_budget=2,
    )

    assert plan.paddleocr_vl_pages == frozenset({1, 4})
    assert plan.audit["inspected_pages"] == [1, 4]
    assert plan.audit["page_budget_skipped_pages"] == [2, 3]
    assert plan.audit["budget_limited"] is True
    assert plan.audit["router_calls"] == 1


@pytest.mark.asyncio
async def test_default_page_budget_is_a_hard_execution_ceiling() -> None:
    page_count = PAGE_CAPABILITY_PAGE_BUDGET + 1
    evidence = DocumentEvidence(
        backend="pp-structure-v3",
        pages=[_page(page_number) for page_number in range(1, page_count + 1)],
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )

    plan = await resolve_pdf_page_capabilities(
        evidence,
        router=router,
        tenant_id="tenant-a",
        page_numbers=range(1, page_count + 1),
    )

    assert len(plan.paddleocr_vl_pages) == PAGE_CAPABILITY_PAGE_BUDGET
    assert plan.audit["page_budget_skipped_pages"] == [page_count]
    assert router.calls == 1


@pytest.mark.asyncio
async def test_signature_budget_limits_router_dependency_calls() -> None:
    evidence = DocumentEvidence(
        backend="pp-structure-v3",
        pages=[_page(1), _page(2, rotation=90)],
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )

    plan = await resolve_pdf_page_capabilities(
        evidence,
        router=router,
        tenant_id="tenant-a",
        page_numbers=(1, 2),
        signature_budget=1,
    )

    assert router.calls == 1
    assert plan.paddleocr_vl_pages == frozenset({1})
    assert plan.audit["signature_budget_skipped_pages"] == [2]
    assert plan.audit["budget_limited"] is True


@pytest.mark.asyncio
async def test_clean_pdf_page_can_be_discovered_by_capability_router(
    tmp_path: Path,
) -> None:
    paths = _assets(tmp_path, 1)
    pp = _Backend(
        DocumentEvidence(
            backend="pp-structure-v3",
            pages=[_page(1, confidence=0.95)],
        ),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(
            backend="paddleocr-vl",
            pages=[_page(1, bbox_x=30, confidence=0.95)],
        ),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-clean-page",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
    )

    evidence = await service._pdf_evidence(
        tmp_path / "sample.pdf",
        _document(paths),
        tenant_id="tenant-a",
    )

    assert "vlm_escalation_reasons_by_page" not in evidence.raw
    assert router.calls == 1
    assert vl.calls == [(1,)]
    assert evidence.raw["region_capability_routing"]["routed_pages"] == [1]


@pytest.mark.asyncio
async def test_parse_image_uses_image_region_router_and_records_execution(
    tmp_path: Path,
) -> None:
    image = tmp_path / "drawing.png"
    Image.new("RGB", (600, 800), "white").save(image)
    pp = _Backend(
        DocumentEvidence(
            backend="pp-structure-v3",
            pages=[_page(1, confidence=0.95)],
        ),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(
            backend="paddleocr-vl",
            pages=[_page(1, bbox_x=30, confidence=0.95)],
        ),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-image",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
    )

    evidence = await service.parse_image(image, tenant_id="tenant-a")

    assert router.calls == 1
    assert router.probes[0].source_kind is RegionSourceKind.IMAGE_REGION
    assert RegionFeature.HAS_RASTER in router.probes[0].features
    assert vl.calls == [(1,)]
    assert evidence.raw["region_capability_routing"]["source_kind"] == "image_region"
    assert evidence.raw["completed_capabilities_by_page"] == {
        "1": ["pp_structure_v3", "paddleocr_vl"]
    }


@pytest.mark.asyncio
async def test_parse_image_propagates_required_dependency_failure(
    tmp_path: Path,
) -> None:
    image = tmp_path / "drawing.png"
    Image.new("RGB", (600, 800), "white").save(image)
    service = DocumentParserService(
        mode="structured",
        pp_structure=_Backend(
            DocumentEvidence(
                backend="pp-structure-v3",
                pages=[_page(1, confidence=0.95)],
            ),
            name="pp-structure-v3",
        ),
        page_capability_router=_Router(
            error=DocumentRoutingDependencyError("store", "TimeoutError"),
            required=True,
        ),
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await service.parse_image(image, tenant_id="tenant-a")

    assert caught.value.dependency == "store"


@pytest.mark.asyncio
async def test_explicit_image_target_preserves_hint_and_mime_without_page_routing(
    tmp_path: Path,
) -> None:
    image = tmp_path / "drawing.png"
    Image.new("RGB", (600, 800), "white").save(image)
    router = _Router(error=AssertionError("explicit target must bypass page routing"))
    service = DocumentParserService(
        mode="structured",
        pp_structure=_Backend(
            DocumentEvidence(
                backend="pp-structure-v3",
                pages=[_page(1, confidence=0.95)],
            ),
            name="pp-structure-v3",
        ),
        page_capability_router=router,
    )

    result = await service.parse_image_target(
        image,
        "drawing.png",
        backend="pp_structure_v3",
        document_subtype_hint="approval_drawing",
    )

    assert router.calls == 0
    assert result.document_subtype == "approval_drawing"
    assert result.source.mime_type == "image/png"


@pytest.mark.asyncio
async def test_router_failure_keeps_existing_needs_vlm_fallback(tmp_path: Path) -> None:
    paths = _assets(tmp_path, 1)
    pp = _Backend(
        DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1, bbox_x=30)]),
        name="paddleocr-vl",
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=_Router(error=TimeoutError()),
    )

    evidence = await service._pdf_evidence(
        tmp_path / "sample.pdf",
        _document(paths),
        tenant_id="tenant-a",
    )

    assert vl.calls == [(1,)]
    routing = evidence.raw["region_capability_routing"]
    assert routing["status"] == "degraded"
    assert routing["failures"] == {"1": "TimeoutError"}
    assert evidence.raw["completed_capabilities_by_page"]["1"] == [
        "pp_structure_v3",
        "paddleocr_vl",
    ]


@pytest.mark.asyncio
async def test_required_router_failure_propagates_out_of_page_adapter(
    tmp_path: Path,
) -> None:
    del tmp_path
    evidence = DocumentEvidence(
        backend="pp-structure-v3",
        pages=[_page(1)],
    )

    with pytest.raises(TimeoutError, match="private dependency detail"):
        await resolve_pdf_page_capabilities(
            evidence,
            router=_Router(
                error=TimeoutError("private dependency detail"), required=True
            ),
            tenant_id="tenant-a",
            page_numbers=(1,),
        )


@pytest.mark.asyncio
async def test_required_dependency_failure_is_not_swallowed_by_parse_pdf(
    tmp_path: Path,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    service = DocumentParserService(
        mode="structured",
        pp_structure=_Backend(
            DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
            name="pp-structure-v3",
        ),
        page_capability_router=_Router(
            error=DocumentRoutingDependencyError("store", "TimeoutError"),
            required=True,
        ),
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await service.parse_pdf(
            tmp_path / "sample.pdf",
            "sample.pdf",
            tenant_id="tenant-a",
        )

    assert caught.value.dependency == "store"


@pytest.mark.asyncio
async def test_non_vl_route_cannot_execute_another_production_capability(
    tmp_path: Path,
) -> None:
    paths = _assets(tmp_path, 1)
    pp = _Backend(
        DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1, bbox_x=30)]),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.MINERU,
                profile_id="profile-mineru",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
    )

    evidence = await service._pdf_evidence(
        tmp_path / "sample.pdf",
        _document(paths),
        tenant_id="tenant-a",
    )

    # The existing needs_vlm fallback still uses PaddleOCR-VL; the route itself
    # is explicitly rejected and cannot invoke MinerU or arbitrary code.
    assert vl.calls == [(1,)]
    decision = evidence.raw["region_capability_routing"]["decisions"]["1"]
    assert decision["execution_allowed"] is False
    assert decision["execution_rejection"] == "unsupported_production_capability"


@pytest.mark.asyncio
async def test_explicit_pp_target_routes_only_paddle_supplement_in_same_tenant(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    pp = _Backend(
        DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1, bbox_x=30)]),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    applied: list[DocumentEvidence] = []
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda source, evidence, **kwargs: (
            applied.append(evidence.model_copy(deep=True)) or source
        ),
    )

    result = await service.parse_pdf_target(
        tmp_path / "sample.pdf",
        "sample.pdf",
        backend="pp_structure_v3",
        tenant_id="tenant-a",
    )

    assert result.source.original_filename == "sample.pdf"
    assert pp.calls == [(1,)]
    assert vl.calls == [(1,)]
    assert router.calls == 1
    assert applied[0].backend == "pp-structure-v3"
    assert applied[0].raw["region_capability_routing"]["routed_pages"] == [1]
    assert applied[0].raw["completed_capabilities_by_page"] == {
        "1": ["pp_structure_v3", "paddleocr_vl"]
    }


@pytest.mark.asyncio
async def test_explicit_paddle_target_never_invokes_page_router(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1)]),
        name="paddleocr-vl",
    )
    router = _Router(error=AssertionError("page router must not override target"))
    service = DocumentParserService(
        mode="structured",
        paddle_vl=vl,
        page_capability_router=router,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    applied: list[DocumentEvidence] = []
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda source, evidence, **kwargs: (
            applied.append(evidence.model_copy(deep=True)) or source
        ),
    )

    await service.parse_pdf_target(
        tmp_path / "sample.pdf",
        "sample.pdf",
        backend="paddleocr_vl",
        tenant_id="tenant-a",
    )

    assert vl.calls == [(1,)]
    assert router.calls == 0
    assert applied[0].backend == "paddleocr-vl"
    assert applied[0].raw["completed_capabilities_by_page"] == {"1": ["paddleocr_vl"]}


@pytest.mark.asyncio
async def test_explicit_pp_target_rejects_non_paddle_page_capability(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    pp = _Backend(
        DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1, bbox_x=30)]),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.MINERU,
                profile_id="profile-mineru",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    applied: list[DocumentEvidence] = []
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda source, evidence, **kwargs: (
            applied.append(evidence.model_copy(deep=True)) or source
        ),
    )

    await service.parse_pdf_target(
        tmp_path / "sample.pdf",
        "sample.pdf",
        backend="pp_structure_v3",
        tenant_id="tenant-a",
    )

    assert pp.calls == [(1,)]
    assert vl.calls == []
    decision = applied[0].raw["region_capability_routing"]["decisions"]["1"]
    assert decision["execution_allowed"] is False
    assert decision["execution_rejection"] == "unsupported_production_capability"


@pytest.mark.asyncio
async def test_explicit_pp_target_propagates_required_router_failure(
    tmp_path: Path,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    service = DocumentParserService(
        mode="structured",
        pp_structure=_Backend(
            DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
            name="pp-structure-v3",
        ),
        page_capability_router=_Router(
            error=DocumentRoutingDependencyError("store", "TimeoutError"),
            required=True,
        ),
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await service.parse_pdf_target(
            tmp_path / "sample.pdf",
            "sample.pdf",
            backend="pp_structure_v3",
            tenant_id="tenant-a",
        )

    assert caught.value.dependency == "store"


@pytest.mark.asyncio
async def test_explicit_pp_target_keeps_region_profiles_tenant_isolated(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)

    class TenantRouter:
        required = False

        def __init__(self) -> None:
            self.tenants: list[str] = []

        async def resolve(self, *, tenant_id, probe):
            del probe
            self.tenants.append(tenant_id)
            return _decision("generic")

    router = TenantRouter()
    service = DocumentParserService(
        mode="structured",
        pp_structure=_Backend(
            DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
            name="pp-structure-v3",
        ),
        page_capability_router=router,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda source, evidence, **kwargs: source,
    )

    for tenant_id in ("tenant-a", "tenant-b"):
        await service.parse_pdf_target(
            tmp_path / "sample.pdf",
            "sample.pdf",
            backend="pp_structure_v3",
            tenant_id=tenant_id,
        )

    assert router.tenants == ["tenant-a", "tenant-b"]


def test_merge_preserves_equal_text_at_distinct_bounding_boxes() -> None:
    primary = DocumentEvidence(backend="pp", pages=[_page(1, bbox_x=0)])
    supplement = DocumentEvidence(backend="vl", pages=[_page(1, bbox_x=30)])

    merged = merge_evidence(primary, supplement)

    assert len(merged.pages[0].blocks) == 2
    assert [block.bbox.x0 for block in merged.pages[0].blocks] == [0.0, 30.0]


@pytest.mark.asyncio
async def test_normal_pdf_route_applies_merged_evidence_once(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    paths = _assets(tmp_path, 1)
    baseline = _record(paths)
    pp = _Backend(
        DocumentEvidence(backend="pp-structure-v3", pages=[_page(1)]),
        name="pp-structure-v3",
    )
    vl = _Backend(
        DocumentEvidence(backend="paddleocr-vl", pages=[_page(1, bbox_x=30)]),
        name="paddleocr-vl",
    )
    router = _Router(
        {
            1: _decision(
                "route",
                capability=ParsingCapability.PADDLEOCR_VL,
                profile_id="profile-1",
            )
        }
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        page_capability_router=router,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    applied: list[DocumentEvidence] = []

    def apply_once(source, evidence, **kwargs):
        applied.append(evidence.model_copy(deep=True))
        return source

    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        apply_once,
    )

    await service.parse_pdf(
        tmp_path / "sample.pdf",
        "sample.pdf",
        tenant_id="tenant-a",
    )

    assert vl.calls == [(1,)]
    assert len(applied) == 1
    assert len(applied[0].pages[0].blocks) == 2
