"""文件类型路由单测。"""
from __future__ import annotations

import pytest
from zipfile import ZIP_DEFLATED, ZipFile

from m1.parsers.router import ParserRouter


@pytest.fixture
def router() -> ParserRouter:
    return ParserRouter()


@pytest.mark.parametrize("filename,expected", [
    ("a.jpg", "image"),
    ("a.JPEG", "image"),
    ("a.png", "image"),
    ("a.webp", "image"),
    ("a.pdf", "pdf"),
    ("a.PDF", "pdf"),
    ("a.dxf", "dxf"),
    ("a.dwg", "dwg"),
    ("a.docx", "docx"),
    ("a.pptx", "pptx"),
    ("a.html", "html"),
    ("a.xlsx", "xlsx"),
    ("a.xls", "xls"),
    ("a.csv", "csv"),
    ("noext", "unknown"),
])
def test_detect_type(router, filename, expected):
    assert router.detect_type(filename) == expected


def test_existing_binary_cannot_masquerade_as_jpeg(router, tmp_path):
    fake = tmp_path / "payload.jpg"
    fake.write_bytes(b"not-an-image\x00with-binary-data")

    assert router.detect_type(fake) == "unknown"


def test_existing_text_csv_still_routes_to_deterministic_adapter(router, tmp_path):
    source = tmp_path / "order.csv"
    source.write_text("model,quantity\nM-1,2\n", encoding="utf-8")

    assert router.detect_type(source) == "csv"


def test_existing_html_requires_html_content(router, tmp_path):
    valid = tmp_path / "document.html"
    valid.write_text("<!doctype html><html><body>ok</body></html>", encoding="utf-8")
    invalid = tmp_path / "binary.html"
    invalid.write_bytes(b"not-html\x00binary")

    assert router.detect_type(valid) == "html"
    assert router.detect_type(invalid) == "unknown"


def test_pptx_magic_is_preflighted_and_not_treated_as_archive(router, tmp_path):
    presentation = tmp_path / "slides.pptx"
    with ZipFile(presentation, "w", ZIP_DEFLATED) as package:
        package.writestr(
            "[Content_Types].xml",
            "<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'/>",
        )
        package.writestr("ppt/presentation.xml", "<p:presentation xmlns:p='urn:test'/>")

    assert router.detect_type(presentation) == "pptx"


@pytest.mark.asyncio
async def test_parse_unknown_type_raises(router):
    with pytest.raises(ValueError, match="不支持"):
        await router.parse("file.unknown")


@pytest.mark.asyncio
async def test_parse_dwg_returns_explicit_conversion_result(router):
    out = await router.parse("drawing.dwg")
    assert out.startswith("[DWG conversion failed:")
