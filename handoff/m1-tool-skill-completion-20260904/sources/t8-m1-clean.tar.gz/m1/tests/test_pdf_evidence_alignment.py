from __future__ import annotations

from typing import Any

from m1.documents.adapters.pdf_order import _extract_pdf_header, _extract_pdf_lines
from m1.documents.parsing.pdf_evidence_merge import align_structured_order_tables


HEADERS = [
    "序号",
    "物料编码",
    "物料名称",
    "规格型号",
    "单位",
    "数量",
    "单价",
    "合计金额",
    "备注",
]


def _bbox_matrix(rows: list[list[Any]], *, inset: float = 0.0) -> list[list[list[float]]]:
    return [
        [
            [
                float(column * 100) + inset,
                float(row_index * 20) + inset,
                float((column + 1) * 100) - inset,
                float((row_index + 1) * 20) - inset,
            ]
            for column in range(len(row))
        ]
        for row_index, row in enumerate(rows)
    ]


def _tables() -> tuple[dict[str, Any], dict[str, Any]]:
    native_rows = [
        HEADERS,
        [
            "1",
            "YA.C.01.MZ21101",
            "2.1铁壳镀金端子G/F",
            "",
            "套",
            "12500",
            "0.5",
            "6,250.00",
            "",
        ],
        ["合计金额：", None, "¥6,250.00", None, None, None, None, None, None],
    ]
    structured_rows = [
        HEADERS,
        [
            "1",
            "YA C. 01.21101",
            "2.1铁壳镀金端子GF",
            None,
            "套",
            "12500",
            "0.5",
            "6,250.00",
            None,
        ],
        ["合计金额：", "￥6,250.00", None, None, None, None, None, None, None],
    ]
    native = {
        "table_index": 0,
        "bbox": [0.0, 0.0, 900.0, 60.0],
        "rows_original": native_rows,
        "rows_normalized": native_rows,
        "cell_bbox_matrix": _bbox_matrix(native_rows),
        "coordinate_space": "pdf_points",
        "source": "pymupdf-native",
    }
    structured = {
        "table_index": 20100,
        "bbox": [1.0, 1.0, 899.0, 59.0],
        "rows_original": structured_rows,
        "rows_normalized": structured_rows,
        "cell_bbox_matrix": _bbox_matrix(structured_rows, inset=1.0),
        "cell_confidences": [[0.9] * 9 for _ in structured_rows],
        "coordinate_space": "pdf_points",
        "ocr_derived": True,
        "source": "pp-structure-v3",
    }
    return native, structured


def test_native_characters_align_to_structured_cell_coordinates() -> None:
    native, structured = _tables()
    table = align_structured_order_tables([native], [structured])[0]
    pages = [{"page_number": 1, "tables": [table], "text_normalized": "采购合同"}]
    field_meta: dict[str, Any] = {}

    lines, _, _ = _extract_pdf_lines(pages, field_meta, [])

    assert lines[0].product_code == "YA.C.01.MZ21101"
    assert lines[0].name_raw == "2.1铁壳镀金端子G/F"
    assert table["native_aligned"] is True
    refs = field_meta["$.lines[0].product_code"].source_refs
    assert [ref.part for ref in refs] == [
        "ocr/table:20100/row:1/column:1",
        "table:0/row:1/column:1",
    ]
    assert refs[0].bbox == [101.0, 21.0, 199.0, 39.0]
    assert refs[1].bbox == [100.0, 20.0, 200.0, 40.0]
    assert all(ref.coordinate_space == "pdf_points" for ref in refs)


def test_alignment_keeps_unmatched_native_and_structured_tables_in_page_order() -> None:
    native, structured = _tables()
    native_only = {
        "table_index": 1,
        "bbox": [0.0, 120.0, 200.0, 160.0],
        "rows_original": [["原生表"], ["NATIVE-ONLY"]],
        "rows_normalized": [["原生表"], ["NATIVE-ONLY"]],
        "cell_bbox_matrix": [[[0.0, 120.0, 200.0, 140.0]], [[0.0, 140.0, 200.0, 160.0]]],
        "coordinate_space": "pdf_points",
    }
    structured_only = {
        "table_index": 20200,
        "bbox": [0.0, 80.0, 200.0, 110.0],
        "rows_original": [["结构化表"], ["STRUCTURED-ONLY"]],
        "rows_normalized": [["结构化表"], ["STRUCTURED-ONLY"]],
        "cell_bbox_matrix": [[[0.0, 80.0, 200.0, 95.0]], [[0.0, 95.0, 200.0, 110.0]]],
        "coordinate_space": "pdf_points",
        "ocr_derived": True,
    }

    tables = align_structured_order_tables(
        [native, native_only], [structured, structured_only]
    )

    assert [table["table_index"] for table in tables] == [20100, 20200, 1]
    assert tables[0]["native_aligned"] is True
    assert tables[1]["rows_normalized"][1] == ["STRUCTURED-ONLY"]
    assert tables[2]["rows_normalized"][1] == ["NATIVE-ONLY"]


def test_hybrid_retains_structured_extra_row_without_overstating_native_refs() -> None:
    native, structured = _tables()
    structured_rows = structured["rows_normalized"]
    structured_rows[1][3] = "补充规格"
    structured_rows.insert(
        2,
        ["2", "YA.C.09.0002", "结构化独有行", None, "PCS", "3", "2.0", "6.00", None],
    )
    structured["rows_original"] = structured_rows
    structured["row_count"] = len(structured_rows)
    structured["bbox"] = [1.0, 1.0, 899.0, 79.0]
    structured["cell_bbox_matrix"] = _bbox_matrix(structured_rows, inset=1.0)
    structured["cell_confidences"] = [[0.9] * 9 for _ in structured_rows]
    table = align_structured_order_tables([native], [structured])[0]
    field_meta: dict[str, Any] = {}

    lines, _, _ = _extract_pdf_lines(
        [{"page_number": 1, "tables": [table], "text_normalized": "采购合同"}],
        field_meta,
        [],
    )

    assert [line.product_code for line in lines] == [
        "YA.C.01.MZ21101",
        "YA.C.09.0002",
    ]
    assert lines[0].specification_raw == "补充规格"
    supplement_refs = field_meta["$.lines[0].specification_raw"].source_refs
    assert [ref.part for ref in supplement_refs] == [
        "ocr/table:20100/row:1/column:3"
    ]
    extra_refs = field_meta["$.lines[1].product_code"].source_refs
    assert [ref.part for ref in extra_refs] == [
        "ocr/table:20100/row:2/column:1"
    ]
    assert extra_refs[0].bbox == [101.0, 41.0, 199.0, 59.0]


def test_cny_is_inferred_only_from_real_amount_symbol_evidence() -> None:
    native, _ = _tables()
    pages = [{"page_number": 1, "tables": [native], "text_normalized": "采购合同"}]
    field_meta: dict[str, Any] = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", field_meta, []
    )

    assert header.currency == "CNY"
    currency_meta = field_meta["$.header.currency"]
    assert currency_meta.inferred is True
    assert currency_meta.source_refs[0].part == "table:0/row:2/column:2"
    assert currency_meta.source_refs[0].bbox == [200.0, 40.0, 300.0, 60.0]
    assert currency_meta.source_refs[0].coordinate_space == "pdf_points"

    native_without_symbol = {**native, "rows_normalized": [HEADERS, native["rows_normalized"][1]]}
    no_symbol_meta: dict[str, Any] = {}
    no_symbol = _extract_pdf_header(
        "采购合同.pdf",
        [{"page_number": 1, "tables": [native_without_symbol], "text_normalized": "采购合同"}],
        "purchase_contract",
        no_symbol_meta,
        [],
    )
    assert no_symbol.currency is None
    assert "$.header.currency" not in no_symbol_meta
