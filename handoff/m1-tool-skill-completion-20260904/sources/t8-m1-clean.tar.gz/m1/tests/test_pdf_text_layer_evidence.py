from __future__ import annotations

import hashlib
from pathlib import Path

import fitz

from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.pdf_text_layer_evidence import (
    apply_pdf_text_layer_fusion,
    extract_pdf_text_layer,
    propose_pdf_text_layer_fusion,
    text_layer_evidence_from_native_pages,
)


def _mineru_table(text: str) -> DocumentEvidence:
    table_bbox = EvidenceBBox(
        x0=0.0,
        y0=0.0,
        x1=1.0,
        y1=1.0,
        coordinate_space="normalized",
    )
    return DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1.0,
                height=1.0,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=[[text]],
                        cells=[
                            EvidenceCell(
                                row=0,
                                column=0,
                                text=text,
                                bbox=table_bbox,
                                bbox_precision="table",
                            )
                        ],
                        bbox=table_bbox,
                    )
                ],
            )
        ],
    )


def _native_pages(text: str) -> list[dict[str, object]]:
    return [
        {
            "page_number": 1,
            "coordinate_width": 200.0,
            "coordinate_height": 100.0,
            "rotation": 0,
            "text_blocks": [
                {
                    "block_index": 3,
                    "lines": [
                        {
                            "bbox": [20.0, 10.0, 180.0, 30.0],
                            "direction": [1.0, 0.0],
                            "text_original": text,
                            "text_normalized": text,
                        }
                    ],
                }
            ],
        }
    ]


def test_native_page_conversion_has_stable_source_id_and_both_coordinate_spaces() -> None:
    digest = "a" * 64
    first = text_layer_evidence_from_native_pages(
        _native_pages("采购订单 PO-1001"),
        document_sha256=digest,
        backend_version="test",
    )
    second = text_layer_evidence_from_native_pages(
        _native_pages("采购订单 PO-1001"),
        document_sha256=digest,
        backend_version="test",
    )

    line = first.pages[0].lines[0]
    assert line.source_id == second.pages[0].lines[0].source_id
    assert line.source_id.startswith("pdf-text/aaaaaaaaaaaa/p1/")
    assert line.bbox.as_list() == [20.0, 10.0, 180.0, 30.0]
    assert line.bbox.coordinate_space == "pdf_points"
    assert line.normalized_bbox.as_list() == [0.1, 0.1, 0.9, 0.3]
    assert line.normalized_bbox.coordinate_space == "normalized"
    assert line.source_reference().part == line.source_id


def test_extract_pdf_text_layer_uses_existing_pymupdf_dependency(tmp_path: Path) -> None:
    source = tmp_path / "native.pdf"
    document = fitz.open()
    page = document.new_page(width=200, height=100)
    page.insert_text((20, 30), "Native PO-20260724")
    document.save(source)
    document.close()

    result = extract_pdf_text_layer(source)

    assert result.document_sha256 == hashlib.sha256(source.read_bytes()).hexdigest()
    assert result.backend_version == fitz.VersionBind
    assert result.line_count == 1
    assert result.pages[0].lines[0].text_normalized == "Native PO-20260724"
    assert result.pages[0].lines[0].bbox.coordinate_space == "pdf_points"


def test_fusion_proposes_native_correction_without_mutating_mineru_table() -> None:
    native = text_layer_evidence_from_native_pages(
        _native_pages("UV 胶水 针管装 35ml/支 符合RoHS"),
        document_sha256="b" * 64,
    )
    mineru = _mineru_table("UV废水针管装 3smi/支符合 ROHS")
    before = mineru.model_dump(mode="json")

    result = propose_pdf_text_layer_fusion(native, mineru)

    corrections = [
        candidate for candidate in result.candidates if candidate.action == "correct_ocr"
    ]
    assert len(corrections) == 1
    assert corrections[0].target_evidence_id == "p1:t0:r0:c0"
    assert corrections[0].target_kind == "table_cell"
    assert corrections[0].proposed_text == "UV 胶水 针管装 35ml/支 符合RoHS"
    assert corrections[0].advisory_only is True
    assert corrections[0].table_structure_change_allowed is False
    assert mineru.model_dump(mode="json") == before


def test_fusion_proposes_missing_native_text_and_ignores_exact_matches() -> None:
    native = text_layer_evidence_from_native_pages(
        _native_pages("交货日期 2026-07-25"),
        document_sha256="c" * 64,
    )
    missing = propose_pdf_text_layer_fusion(native, _mineru_table("采购订单"))
    exact = propose_pdf_text_layer_fusion(
        native,
        _mineru_table("交货日期 2026-07-25"),
    )

    assert [candidate.action for candidate in missing.candidates] == ["fill_missing"]
    assert missing.candidates[0].target_evidence_id is None
    assert missing.candidates[0].proposed_text == "交货日期 2026-07-25"
    assert exact.candidates == []
    assert exact.represented_source_ids == [native.pages[0].lines[0].source_id]


def test_apply_fusion_copies_evidence_corrects_text_and_adds_missing_blocks() -> None:
    native = text_layer_evidence_from_native_pages(
        _native_pages("Native corrected contract clause"),
        document_sha256="e" * 64,
    )
    mineru = _mineru_table("Native corected contract clause")
    original = mineru.model_dump(mode="json")

    merged, fusion = apply_pdf_text_layer_fusion(native, mineru)

    assert fusion.candidates[0].action == "correct_ocr"
    assert merged.pages[0].tables[0].rows == [["Native corrected contract clause"]]
    cell = merged.pages[0].tables[0].cells[0]
    assert cell.text == "Native corrected contract clause"
    assert cell.model_extra["ocr_text_original"] == (
        "Native corected contract clause"
    )
    assert cell.model_extra["native_source_refs"][0]["page"] == 1
    assert merged.raw["pdf_text_layer"]["table_structure_changed"] is False
    assert mineru.model_dump(mode="json") == original

    missing_native = text_layer_evidence_from_native_pages(
        _native_pages("Completely missing payment clause"),
        document_sha256="f" * 64,
    )
    missing_merged, _ = apply_pdf_text_layer_fusion(
        missing_native,
        _mineru_table("Purchase order"),
    )
    added = next(
        block
        for block in missing_merged.pages[0].blocks
        if block.kind == "native_text"
    )
    assert added.text == "Completely missing payment clause"
    assert added.model_extra["native_source_refs"][0]["part"].startswith(
        "pdf-text/"
    )


def test_compound_native_lines_can_correct_one_long_ocr_cell() -> None:
    pages = _native_pages("first formula section")
    lines = pages[0]["text_blocks"][0]["lines"]  # type: ignore[index]
    lines.append(  # type: ignore[union-attr]
        {
            "bbox": [20.0, 30.0, 180.0, 50.0],
            "direction": [1.0, 0.0],
            "text_original": "second formula section",
            "text_normalized": "second formula section",
        }
    )
    native = text_layer_evidence_from_native_pages(
        pages,
        document_sha256="d" * 64,
    )
    mineru = _mineru_table("first formula sectiom second formula sectiom")

    result = propose_pdf_text_layer_fusion(native, mineru)
    correction = next(
        candidate for candidate in result.candidates if candidate.action == "correct_ocr"
    )

    assert correction.proposed_text == "first formula section second formula section"
    assert correction.native_source_ids == [
        line.source_id for line in native.pages[0].lines
    ]


def test_real_test_cable_native_text_can_recover_known_ocr_damage() -> None:
    source = Path(__file__).parents[1] / "samples" / "test_cable.pdf"
    native = extract_pdf_text_layer(source)
    mineru = _mineru_table("UV废水针管装 3smi/支符合 ROHS")

    result = propose_pdf_text_layer_fusion(native, mineru)

    correction = next(
        candidate
        for candidate in result.candidates
        if candidate.action == "correct_ocr"
        and candidate.target_evidence_id == "p1:t0:r0:c0"
    )
    assert correction.proposed_text == "UV 胶水 针管装 35ml/支 符合RoHS"
    assert correction.similarity >= 0.8
