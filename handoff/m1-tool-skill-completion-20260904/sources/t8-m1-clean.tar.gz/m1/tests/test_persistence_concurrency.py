from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError

from m1.state import TaskState, TaskStatus
from m1.workflow import persistence as persistence_module
from m1.workflow.persistence import DocumentRow, FieldIndexRow, TaskRow, TaskStore


def test_task_store_timestamp_columns_are_timezone_aware() -> None:
    assert TaskRow.created_at.type.timezone is True
    assert TaskRow.updated_at.type.timezone is True
    assert DocumentRow.created_at.type.timezone is True
    assert DocumentRow.updated_at.type.timezone is True


@pytest.mark.asyncio
async def test_sqlite_concurrent_document_writes_are_serialized(tmp_path: Path) -> None:
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'concurrent-writes.db').as_posix()}"
    )
    await store.init()

    async def write(index: int) -> None:
        task_id = f"task-{index:03d}"
        state = TaskState(
            task_id=task_id,
            file_path=str(tmp_path / f"{index}.pdf"),
            original_filename=f"{index}.pdf",
        )
        await store.save(state)
        document = {
            "schema_version": "m1.document.v2",
            "source": {
                "original_filename": state.original_filename,
                "sha256": f"{index:064x}",
                "mime_type": "application/pdf",
            },
            "document_type": "technical_document",
            "document_subtype": "product_specification",
            "header": {"title": f"specification {index}"},
            "lines": [],
            "totals": {},
            "field_meta": {
                f"$.synthetic.field_{item}": {
                    "source_refs": [{"part": "concurrency-test"}],
                    "confidence": 1.0,
                }
                for item in range(100)
            },
            "validation_issues": [],
            "needs_review": False,
            "extraction": {
                "metadata": {"adapter": "concurrency-test"},
                "raw_content": {f"field_{item}": item for item in range(100)},
            },
        }
        await store.save_document(task_id, document)
        state.status = TaskStatus.DONE
        state.document = document
        state.document_schema_version = "m1.document.v2"
        await store.save(state)

    await asyncio.wait_for(asyncio.gather(*(write(index) for index in range(30))), 30)
    hits = await store.search_documents(query="specification", limit=50)
    assert len(hits) == 30
    states = await asyncio.gather(
        *(store.load(f"task-{index:03d}") for index in range(30))
    )
    assert all(state is not None and state.status == TaskStatus.DONE for state in states)
    await store.close()


@pytest.mark.asyncio
async def test_document_index_excludes_raw_evidence_but_keeps_body_search(
    tmp_path: Path,
) -> None:
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'bounded-index.db').as_posix()}"
    )
    await store.init()
    state = TaskState(
        task_id="bounded-index",
        file_path=str(tmp_path / "spec.pdf"),
        original_filename="spec.pdf",
    )
    await store.save(state)
    document = {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "spec.pdf", "sha256": "a" * 64},
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "header": {"title": "DP cable specification"},
        "lines": [{"line_id": "1", "model": "DP-9000", "quantity": 3}],
        "totals": {"calculated_quantity": 3},
        "field_meta": {
            f"$.evidence.{index}": {"source_refs": [{"bbox": [0, 0, 1, 1]}]}
            for index in range(2_000)
        },
        "validation_issues": [],
        "needs_review": False,
        "extraction": {
            "metadata": {"adapter": "pymupdf"},
            "raw_content": {
                "text_normalized": "unique native PDF body phrase",
                "pages": [
                    {
                        "spans": [
                            {"text": f"span-{index}", "bbox": [0, 0, 1, 1]}
                            for index in range(2_000)
                        ]
                    }
                ],
            },
        },
        # Compatibility aliases must not duplicate the canonical business rows.
        "bom": [{"line_id": "1", "model": "DP-9000", "quantity": 3}],
        "fields": [{"name": "model", "value": "DP-9000"}],
    }
    await store.save_document(state.task_id, document)

    async with store.sessionmaker() as session:
        indexed_count = await session.scalar(
            select(func.count()).select_from(FieldIndexRow).where(
                FieldIndexRow.task_id == state.task_id
            )
        )
    assert indexed_count is not None and indexed_count < 30
    assert [
        row["task_id"]
        for row in await store.search_documents(
            field_path="$.lines[*].model", field_value="DP-9000"
        )
    ] == [state.task_id]
    assert await store.search_documents(
        field_path="$.extraction.raw_content.pages[*].spans[*].text",
        field_value="span-1",
    ) == []
    assert [
        row["task_id"]
        for row in await store.search_documents(query="unique native PDF body phrase")
    ] == [state.task_id]
    await store.close()


@pytest.mark.asyncio
async def test_sqlite_locked_write_is_retried(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'locked-write.db').as_posix()}"
    )
    await store.init()
    state = TaskState(task_id="retry", file_path=str(tmp_path / "retry.pdf"))
    attempts = 0
    delays: list[float] = []

    async def flaky_save(_state: TaskState) -> None:
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise OperationalError(
                "UPDATE tasks", {}, RuntimeError("database is locked")
            )

    async def no_sleep(delay: float) -> None:
        delays.append(delay)

    monkeypatch.setattr(store, "_save_unlocked", flaky_save)
    monkeypatch.setattr(persistence_module.asyncio, "sleep", no_sleep)
    await store.save(state)
    assert attempts == 3
    assert delays == [0.25, 0.5]
    await store.close()


@pytest.mark.asyncio
async def test_knowledge_retry_clears_error_and_stale_workflow_save_cannot_regress(
    tmp_path: Path,
) -> None:
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'knowledge-revision.db').as_posix()}"
    )
    await store.init()
    initial = TaskState(
        task_id="knowledge-retry",
        file_path=str(tmp_path / "order.xlsx"),
        original_filename="order.xlsx",
    )
    await store.save(initial)
    stale_workflow_state = await store.load(initial.task_id)
    assert stale_workflow_state is not None

    failed = await store.update_knowledge_status(
        initial.task_id,
        status="failed",
        error="GraphUnavailable",
    )
    assert failed is not None
    assert failed.knowledge_sync_revision == 1

    # Simulate the original M1 workflow finishing with a TaskState loaded
    # before the sidecar write.  Its business fields may advance, but its old
    # knowledge fields must not overwrite the failure observation.
    stale_workflow_state.status = TaskStatus.DONE
    await store.save(stale_workflow_state)
    after_stale_save = await store.load(initial.task_id)
    assert after_stale_save is not None
    assert after_stale_save.status == TaskStatus.DONE
    assert after_stale_save.knowledge_sync_status == "failed"
    assert after_stale_save.knowledge_sync_error == "GraphUnavailable"
    assert after_stale_save.knowledge_sync_revision == 1

    synced = await store.update_knowledge_status(
        initial.task_id,
        status="synced",
        document_id="document-1",
        version_id="version-1",
        error="",
    )
    assert synced is not None
    assert synced.knowledge_sync_revision == 2
    assert synced.knowledge_sync_error == ""
    persisted = await store.load(initial.task_id)
    assert persisted is not None
    assert persisted.knowledge_sync_status == "synced"
    assert persisted.knowledge_sync_error == ""
    assert persisted.knowledge_document_id == "document-1"
    assert persisted.knowledge_version_id == "version-1"
    await store.close()


@pytest.mark.asyncio
async def test_mineru_completion_wins_equal_revision_queue_race(tmp_path: Path) -> None:
    store = TaskStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'mineru-revision.db').as_posix()}"
    )
    await store.init()
    initial = TaskState(
        task_id="mineru-race",
        file_path=str(tmp_path / "order.pdf"),
        original_filename="order.pdf",
    )
    await store.save(initial)
    queued = await store.load(initial.task_id)
    assert queued is not None
    queued.mineru_shadow = {
        "status": "queued",
        "task_id": initial.task_id,
        "candidate_isolation": True,
    }
    queued.mineru_shadow_revision = 1

    completed = await store.update_mineru_shadow_status(
        initial.task_id,
        {
            "status": "completed",
            "task_id": initial.task_id,
            "candidate_isolation": True,
            "artifact": "mineru-race.json",
        },
    )
    assert completed is not None
    assert completed.mineru_shadow_revision == 1

    await store.save(queued)
    persisted = await store.load(initial.task_id)
    assert persisted is not None
    assert persisted.mineru_shadow["status"] == "completed"
    assert persisted.mineru_shadow["artifact"] == "mineru-race.json"
    assert persisted.mineru_shadow_revision == 1
    await store.close()
