"""Opt-in PostgreSQL RLS integration proof for the knowledge outbox.

Run against a disposable application-role database with::

    M1_POSTGRES_TEST_URL=postgresql+asyncpg://... pytest \
        tests/test_postgres_rls_integration.py
"""

from __future__ import annotations

import asyncio
import os
from datetime import timedelta
from uuid import uuid4

import pytest
from sqlalchemy import select

from m1.knowledge.db_models import ProjectionOutboxRow
from m1.knowledge.persistence import KnowledgeStore
from m1.knowledge.schema import ProjectionEventRecord, TenantRecord, utc_now


_DATABASE_URL = os.getenv("M1_POSTGRES_TEST_URL")
pytestmark = pytest.mark.skipif(
    not _DATABASE_URL,
    reason="M1_POSTGRES_TEST_URL is not configured",
)


def _event(tenant_id: str, suffix: str) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        tenant_id=tenant_id,
        projection_name="knowledge",
        idempotency_key=f"rls-integration-{suffix}",
        aggregate_type="document_projection",
        aggregate_id=f"source-{suffix}",
        event_type="knowledge.projection.replaced",
    )


def _lightrag_event(
    tenant_id: str,
    *,
    source_record_id: str,
    action: str,
    created_at,
) -> ProjectionEventRecord:
    return ProjectionEventRecord(
        tenant_id=tenant_id,
        projection_name="lightrag_shadow",
        idempotency_key=f"pg-lightrag-{source_record_id}-{action}",
        aggregate_type="document_projection",
        aggregate_id=source_record_id,
        event_type=f"lightrag.shadow.{action}",
        payload={"source_record_id": source_record_id, "action": action},
        available_at=created_at,
        created_at=created_at,
    )


def _document(token: str) -> dict[str, object]:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": f"{token}.xlsx",
            "display_filename": f"{token}.xlsx",
            "sha256": token * 2,
            "mime_type": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            ),
            "object_uri": f"memory://{token}.xlsx",
            "size_bytes": 1,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {"order_number": token},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
    }


@pytest.mark.asyncio
async def test_postgres_rls_isolates_outbox_leases_and_unscoped_reads() -> None:
    store = KnowledgeStore(str(_DATABASE_URL))
    await store.init()
    token = uuid4().hex
    tenant_a = TenantRecord(
        tenant_id=f"rls-a-{token}",
        tenant_key=f"rls-a-{token}",
        display_name="RLS integration tenant A",
    )
    tenant_b = TenantRecord(
        tenant_id=f"rls-b-{token}",
        tenant_key=f"rls-b-{token}",
        display_name="RLS integration tenant B",
    )
    try:
        await store.create_tenant(tenant_a)
        await store.create_tenant(tenant_b)
        event_a = await store.enqueue_projection(_event(tenant_a.tenant_id, f"a-{token}"))
        event_b = await store.enqueue_projection(_event(tenant_b.tenant_id, f"b-{token}"))

        assert (await store.projection_outbox_health(tenant_a.tenant_id))["pending"] == 1
        assert (await store.projection_outbox_health(tenant_b.tenant_id))["pending"] == 1
        assert (
            await store.lease_projection_event(
                event_b.event_id,
                tenant_id=tenant_a.tenant_id,
            )
            is None
        )

        leased_a = await store.lease_projection_events(
            "knowledge",
            tenant_id=tenant_a.tenant_id,
            limit=10,
        )
        leased_b = await store.lease_projection_events(
            "knowledge",
            tenant_id=tenant_b.tenant_id,
            limit=10,
        )
        assert [event.event_id for event in leased_a] == [event_a.event_id]
        assert [event.event_id for event in leased_b] == [event_b.event_id]

        # The application role is FORCE-RLS protected. A raw session with no
        # transaction-local m1.tenant_id cannot enumerate either tenant.
        async with store.sessionmaker() as session:
            visible = (
                await session.scalars(
                    select(ProjectionOutboxRow).where(
                        ProjectionOutboxRow.event_id.in_(
                            [event_a.event_id, event_b.event_id]
                        )
                    )
                )
            ).all()
        assert visible == []

        assert await store.mark_projection_delivered(
            event_a.event_id,
            tenant_id=tenant_a.tenant_id,
            lease_attempt=leased_a[0].attempts,
        )
        assert await store.mark_projection_delivered(
            event_b.event_id,
            tenant_id=tenant_b.tenant_id,
            lease_attempt=leased_b[0].attempts,
        )
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_postgres_lightrag_leases_serialize_one_source_across_engines() -> None:
    store_a = KnowledgeStore(str(_DATABASE_URL))
    store_b = KnowledgeStore(str(_DATABASE_URL))
    await store_a.init()
    await store_b.init()
    token = uuid4().hex
    tenant = TenantRecord(
        tenant_id=f"lightrag-lease-{token}",
        tenant_key=f"lightrag-lease-{token}",
        display_name="LightRAG lease integration tenant",
    )
    source_record_id = f"source-{token}"
    started_at = utc_now()
    try:
        await store_a.create_tenant(tenant)
        upsert = await store_a.enqueue_projection(
            _lightrag_event(
                tenant.tenant_id,
                source_record_id=source_record_id,
                action="upsert",
                created_at=started_at,
            )
        )
        delete = await store_a.enqueue_projection(
            _lightrag_event(
                tenant.tenant_id,
                source_record_id=source_record_id,
                action="delete",
                created_at=started_at + timedelta(microseconds=1),
            )
        )

        first, blocked = await asyncio.gather(
            store_a.lease_projection_event(
                upsert.event_id,
                tenant_id=tenant.tenant_id,
                lease_seconds=600,
                now=started_at,
            ),
            store_b.lease_projection_event(
                delete.event_id,
                tenant_id=tenant.tenant_id,
                lease_seconds=600,
                now=started_at,
            ),
        )
        assert first is not None
        assert blocked is None
        assert first.leased_until == started_at + timedelta(seconds=120)

        recovered_at = started_at + timedelta(seconds=121)
        claims = await asyncio.gather(
            store_a.lease_projection_events(
                "lightrag_shadow",
                tenant_id=tenant.tenant_id,
                limit=10,
                lease_seconds=600,
                now=recovered_at,
            ),
            store_b.lease_projection_events(
                "lightrag_shadow",
                tenant_id=tenant.tenant_id,
                limit=10,
                lease_seconds=600,
                now=recovered_at,
            ),
        )
        owners = [event for batch in claims for event in batch]
        assert [event.event_id for event in owners] == [upsert.event_id]
        assert owners[0].attempts == 2
        assert owners[0].leased_until == recovered_at + timedelta(seconds=120)
        assert await store_a.mark_projection_delivered(
            upsert.event_id,
            tenant_id=tenant.tenant_id,
            lease_attempt=owners[0].attempts,
        )

        delete_owner = await store_b.lease_projection_event(
            delete.event_id,
            tenant_id=tenant.tenant_id,
            lease_seconds=600,
            now=recovered_at,
        )
        assert delete_owner is not None
        assert delete_owner.leased_until == recovered_at + timedelta(seconds=120)
    finally:
        await store_a.close()
        await store_b.close()


@pytest.mark.asyncio
async def test_postgres_graph_materialization_state_uses_versioned_event() -> None:
    store = KnowledgeStore(str(_DATABASE_URL))
    await store.init()
    token = uuid4().hex
    tenant = TenantRecord(
        tenant_id=f"graph-state-{token}",
        tenant_key=f"graph-state-{token}",
        display_name="Graph state integration tenant",
    )
    try:
        await store.create_tenant(tenant)
        ingested = await store.ingest_document(
            tenant.tenant_id,
            f"graph-state-task-{token}",
            _document(token),
        )
        source_record_id = ingested.document_id
        version = str(ingested.version_number)
        assert await store.graph_projection_materialization_pending(
            tenant.tenant_id, source_record_id, version
        )

        await store.enqueue_projection(
            ProjectionEventRecord(
                tenant_id=tenant.tenant_id,
                projection_name="graph",
                idempotency_key=f"graph-state-{token}",
                aggregate_type="document_projection",
                aggregate_id=source_record_id,
                event_type="graph.projection.replaced",
                payload={
                    "source_record_id": source_record_id,
                    "version": version,
                },
            )
        )

        assert not await store.graph_projection_materialization_pending(
            tenant.tenant_id, source_record_id, version
        )
    finally:
        await store.close()
