from __future__ import annotations

import importlib
from types import SimpleNamespace

import pytest
from m1.knowledge.persistence import KnowledgeBase


def test_legacy_upgrade_prepares_composite_parent_keys_before_current_metadata(
    monkeypatch,
):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0002_legacy_knowledge_upgrade_upgrade_legacy_provenance_and_graph_"
    )
    calls: list[tuple[str, str, tuple[str, ...]]] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(
            has_table=lambda _table: True,
            get_unique_constraints=lambda _table: [],
        ),
    )
    monkeypatch.setattr(
        migration.op,
        "create_unique_constraint",
        lambda name, table, columns: calls.append((name, table, tuple(columns))),
    )

    migration._ensure_current_metadata_parent_keys(bind)

    assert calls == [
        (name, table, columns)
        for table, name, columns in migration._CURRENT_METADATA_PARENT_KEYS
    ]


def test_rls_migration_covers_every_tenant_table():
    baseline_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0004_postgres_tenant_rls"
    )
    fence_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0005_task_lifecycle_fence"
    )
    route_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0007_route_profiles"
    )
    entity_route_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0008_entity_route_index"
    )
    document_identity_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0009_document_identity_routing"
    )
    tenant_reference_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0010_entity_route_tenant_references"
    )
    tabular_layout_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0011_tabular_layout_profiles"
    )
    field_semantic_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0012_field_semantic_routes"
    )
    visual_region_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0013_visual_region_routes"
    )
    region_capability_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0014_region_capability_routes"
    )
    content_region_migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0015_content_region_routes"
    )
    tenant_tables = {
        table.name
        for table in KnowledgeBase.metadata.sorted_tables
        if "tenant_id" in table.columns
    }

    covered_tables = (
        set(baseline_migration.TENANT_TABLES)
        | {fence_migration.TABLE_NAME}
        | set(route_migration.TENANT_TABLES)
        | set(entity_route_migration.TENANT_TABLES)
        | set(document_identity_migration.TENANT_TABLES)
        | set(tabular_layout_migration.TENANT_TABLES)
        | set(field_semantic_migration.TENANT_TABLES)
        | set(visual_region_migration.TENANT_TABLES)
        | set(region_capability_migration.TENANT_TABLES)
        | set(content_region_migration.TENANT_TABLES)
    )
    assert covered_tables == tenant_tables
    assert baseline_migration.down_revision == "0003_postgres_search_candidates"
    assert fence_migration.down_revision == "0004_postgres_tenant_rls"
    assert fence_migration.POLICY_NAME == "m1_tenant_isolation_task_lifecycles"
    assert route_migration.down_revision == "0006_review_task_reference"
    assert entity_route_migration.down_revision == "0007_route_profiles"
    assert document_identity_migration.down_revision == "0008_entity_route_index"
    assert tenant_reference_migration.down_revision == "0009_document_identity_routing"
    assert tabular_layout_migration.down_revision == "0010_entity_route_tenant_fks"
    assert field_semantic_migration.down_revision == "0011_tabular_layout_profiles"
    assert visual_region_migration.down_revision == "0012_field_semantic_routes"
    assert region_capability_migration.down_revision == "0013_visual_region_routes"
    assert content_region_migration.down_revision == "0014_region_capability_routes"
    assert (
        set(field_semantic_migration.TENANT_TABLES)
        | set(visual_region_migration.TENANT_TABLES)
        | set(region_capability_migration.TENANT_TABLES)
        | set(content_region_migration.TENANT_TABLES)
    ) == {
        "knowledge_field_semantic_profiles",
        "knowledge_field_semantic_observations",
        "knowledge_route_lifecycle_events",
        "knowledge_visual_region_profiles",
        "knowledge_visual_region_observations",
        "knowledge_region_capability_profiles",
        "knowledge_region_capability_observations",
        "knowledge_content_region_profiles",
        "knowledge_content_region_observations",
    }


def test_task_fence_migration_enables_and_forces_postgres_rls(monkeypatch):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0005_task_lifecycle_fence"
    )
    statements: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(has_table=lambda _name: True),
    )
    monkeypatch.setattr(migration.op, "execute", statements.append)

    migration.upgrade()

    assert any("ENABLE ROW LEVEL SECURITY" in sql for sql in statements)
    assert any("FORCE ROW LEVEL SECURITY" in sql for sql in statements)
    assert any(
        "CREATE POLICY" in sql
        and "current_setting('m1.tenant_id', true)" in sql
        and "WITH CHECK" in sql
        for sql in statements
    )


def test_route_migration_enables_rls_and_vector_index(monkeypatch):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0007_route_profiles"
    )
    statements: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(has_table=lambda _name: True),
    )
    monkeypatch.setattr(migration.op, "execute", statements.append)

    migration.upgrade()

    assert any(
        "USING hnsw" in sql
        and "vector_cosine_ops" in sql
        and "embedding_dimensions = 1024" in sql
        and "embedding_model <> ''" in sql
        for sql in statements
    )
    assert sum("ENABLE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("FORCE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("CREATE POLICY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert set(migration.POLICY_NAMES) == set(migration.TENANT_TABLES)
    assert all(
        any(policy in sql for sql in statements)
        for policy in migration.POLICY_NAMES.values()
    )
    assert all(
        any(
            f'CREATE POLICY "{migration.POLICY_NAMES[table]}" ON "{table}"' in sql
            and "current_setting('m1.tenant_id', true)" in sql
            and "WITH CHECK" in sql
            for sql in statements
        )
        for table in migration.TENANT_TABLES
    )


@pytest.mark.parametrize(
    "revision",
    (
        "0012_field_semantic_routes",
        "0013_visual_region_routes",
        "0014_region_capability_routes",
        "0015_content_region_routes",
    ),
)
def test_extension_route_downgrades_remove_rls_and_vector_index(
    monkeypatch,
    revision: str,
) -> None:
    migration = importlib.import_module(f"m1.knowledge.migrations.versions.{revision}")
    statements: list[str] = []
    dropped_tables: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(migration.op, "execute", statements.append)
    monkeypatch.setattr(migration.op, "drop_table", dropped_tables.append)

    migration.downgrade()

    assert f"DROP INDEX IF EXISTS {migration.HNSW_INDEX}" in statements
    assert sum("DROP POLICY IF EXISTS" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("NO FORCE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("DISABLE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert all(
        any(
            f'DROP POLICY IF EXISTS "{migration.POLICY_NAMES[table]}" '
            f'ON "{table}"' in sql
            for sql in statements
        )
        for table in migration.TENANT_TABLES
    )
    expected_drops = [migration.OBSERVATION_TABLE, migration.PROFILE_TABLE]
    if hasattr(migration, "LIFECYCLE_TABLE"):
        expected_drops.insert(0, migration.LIFECYCLE_TABLE)
    assert dropped_tables == expected_drops


def test_entity_route_migration_enables_rls_and_vector_index(monkeypatch):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0008_entity_route_index"
    )
    statements: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(has_table=lambda _name: True),
    )
    monkeypatch.setattr(migration.op, "execute", statements.append)

    migration.upgrade()

    assert any(
        "USING hnsw" in sql
        and "vector_cosine_ops" in sql
        and "embedding_dimensions = 1024" in sql
        for sql in statements
    )
    assert sum("ENABLE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("FORCE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("CREATE POLICY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )


def test_document_identity_migration_enables_and_forces_postgres_rls(monkeypatch):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0009_document_identity_routing"
    )
    statements: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(
            has_table=lambda _name: True,
            get_unique_constraints=lambda _name: [],
            get_foreign_keys=lambda _name: [],
            get_columns=lambda _name: [
                {"name": "processing_revision"},
                {"name": "supersedes_version_id"},
            ],
            get_indexes=lambda _name: [{"name": migration.PROCESSING_REVISION_INDEX}],
        ),
    )
    monkeypatch.setattr(migration.op, "execute", statements.append)
    unique_constraints: list[tuple[str, str, tuple[str, ...]]] = []
    foreign_keys: list[tuple[str, str, str, tuple[str, ...], tuple[str, ...]]] = []
    monkeypatch.setattr(
        migration.op,
        "create_unique_constraint",
        lambda name, table, columns: unique_constraints.append(
            (name, table, tuple(columns))
        ),
    )
    monkeypatch.setattr(
        migration.op,
        "create_foreign_key",
        lambda name, source, referent, local, remote, **_kwargs: foreign_keys.append(
            (name, source, referent, tuple(local), tuple(remote))
        ),
    )

    migration.upgrade()

    assert unique_constraints == [
        ("tenant_asset_id", migration.ASSET_TABLE, ("tenant_id", "asset_id")),
        (
            "tenant_occurrence_id",
            migration.OCCURRENCE_TABLE,
            ("tenant_id", "occurrence_id"),
        ),
        (
            "tenant_document_id",
            migration.DOCUMENT_TABLE,
            ("tenant_id", "document_id"),
        ),
        (
            "tenant_version_id",
            migration.VERSION_TABLE,
            ("tenant_id", "version_id"),
        ),
    ]
    assert (
        "tenant_version_supersedes",
        migration.VERSION_TABLE,
        migration.VERSION_TABLE,
        ("tenant_id", "supersedes_version_id"),
        ("tenant_id", "version_id"),
    ) in foreign_keys
    assert sum("ENABLE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("FORCE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("CREATE POLICY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert all(
        any(policy in sql for sql in statements)
        for policy in migration.POLICY_NAMES.values()
    )


def test_entity_route_tenant_reference_migration_replaces_single_column_foreign_keys(
    monkeypatch,
):
    migration = importlib.import_module(
        "m1.knowledge.migrations.versions.0010_entity_route_tenant_references"
    )
    calls: list[tuple[str, tuple[object, ...], dict[str, object]]] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    def foreign_keys(table: str):
        if table == migration.INDEX_TABLE:
            return [
                {
                    "name": "legacy-index-entity",
                    "constrained_columns": ["entity_id"],
                    "referred_table": migration.ENTITY_TABLE,
                    "referred_columns": ["entity_id"],
                }
            ]
        if table == migration.DECISION_TABLE:
            return [
                {
                    "name": "legacy-decision-version",
                    "constrained_columns": ["source_version_id"],
                    "referred_table": migration.VERSION_TABLE,
                    "referred_columns": ["version_id"],
                },
                {
                    "name": "legacy-decision-candidate",
                    "constrained_columns": ["candidate_entity_id"],
                    "referred_table": migration.ENTITY_TABLE,
                    "referred_columns": ["entity_id"],
                },
            ]
        return []

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(
            get_unique_constraints=lambda _table: [],
            get_pk_constraint=lambda _table: {"constrained_columns": ["entity_id"]},
            get_foreign_keys=foreign_keys,
        ),
    )
    monkeypatch.setattr(
        migration.op,
        "create_unique_constraint",
        lambda *args, **kwargs: calls.append(("unique", args, kwargs)),
    )
    monkeypatch.setattr(
        migration.op,
        "drop_constraint",
        lambda *args, **kwargs: calls.append(("drop", args, kwargs)),
    )
    monkeypatch.setattr(
        migration.op,
        "create_foreign_key",
        lambda *args, **kwargs: calls.append(("foreign", args, kwargs)),
    )

    migration.upgrade()

    assert (
        "unique",
        (
            migration.ENTITY_TENANT_KEY,
            migration.ENTITY_TABLE,
            ["tenant_id", "entity_id"],
        ),
        {},
    ) in calls
    assert {call[1][0] for call in calls if call[0] == "drop"} == {
        "legacy-index-entity",
        "legacy-decision-version",
        "legacy-decision-candidate",
    }
    assert {call[1][0] for call in calls if call[0] == "foreign"} == {
        migration.INDEX_ENTITY_FK,
        migration.DECISION_VERSION_FK,
        migration.DECISION_CANDIDATE_FK,
    }


@pytest.mark.parametrize(
    "revision",
    (
        "0011_tabular_layout_profiles",
        "0012_field_semantic_routes",
        "0013_visual_region_routes",
        "0014_region_capability_routes",
        "0015_content_region_routes",
    ),
)
def test_profile_route_migrations_enable_rls_and_vector_index(
    monkeypatch,
    revision: str,
):
    migration = importlib.import_module(f"m1.knowledge.migrations.versions.{revision}")
    statements: list[str] = []
    bind = SimpleNamespace(dialect=SimpleNamespace(name="postgresql"))

    monkeypatch.setattr(migration.op, "get_bind", lambda: bind)
    monkeypatch.setattr(
        migration.sa,
        "inspect",
        lambda _bind: SimpleNamespace(has_table=lambda _name: True),
    )
    monkeypatch.setattr(migration.op, "execute", statements.append)

    migration.upgrade()

    assert any(
        "USING hnsw" in sql
        and "vector_cosine_ops" in sql
        and "embedding_dimensions = 1024" in sql
        and "embedding_model <> ''" in sql
        for sql in statements
    )
    assert sum("ENABLE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("FORCE ROW LEVEL SECURITY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert sum("CREATE POLICY" in sql for sql in statements) == len(
        migration.TENANT_TABLES
    )
    assert set(migration.POLICY_NAMES) == set(migration.TENANT_TABLES)
    assert all(
        any(policy in sql for sql in statements)
        for policy in migration.POLICY_NAMES.values()
    )
    assert all(
        any(
            f'CREATE POLICY "{migration.POLICY_NAMES[table]}" ON "{table}"' in sql
            and "current_setting('m1.tenant_id', true)" in sql
            and "WITH CHECK" in sql
            for sql in statements
        )
        for table in migration.TENANT_TABLES
    )
