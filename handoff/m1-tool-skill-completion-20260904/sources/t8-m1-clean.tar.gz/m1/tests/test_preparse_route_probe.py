from __future__ import annotations

import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from m1.documents.parsing import document_route_probe
from m1.documents.parsing.document_route_plan import (
    DocumentRoutePlan,
    RouteBackend,
    RouteTarget,
)
from m1.documents.parsing.document_route_policy import (
    DocumentRoutingResolution,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
)
from m1.documents.parsing.document_route_probe import build_source_route_probe
from m1.documents.parsing.document_route_signature import (
    build_document_route_signature,
)
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.workflow.document_pipeline import DocumentPipelineMixin


def _route_plan(*targets: RouteTarget) -> DocumentRoutePlan:
    return DocumentRoutePlan(
        mode="guarded",
        recommendation="reuse",
        reason="exact_fingerprint",
        signature_fingerprint="a" * 64,
        route_id="route-probe-a",
        backend_chain=targets,
        policy_applied=True,
    )


def _document(*, adapter: str = "test") -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {},
        "document_type": "unknown",
        "document_subtype": "unknown",
        "header": {},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": False,
        "extraction": {"metadata": {"adapter": adapter}},
    }


def _state(*, file_type: str = "pdf", task_id: str = "") -> SimpleNamespace:
    return SimpleNamespace(
        file_type=file_type,
        file_path="C:/route-probe/input.pdf",
        original_filename="private-contract.pdf",
        doc_type_hint="",
        document_subtype_hint="",
        task_id=task_id,
        tenant_id="tenant-a",
        mineru_shadow_revision=0,
        processing_stage="",
    )


def _write_minimal_xlsx(path: Path) -> None:
    with ZipFile(path, "w", ZIP_DEFLATED) as archive:
        archive.writestr(
            "[Content_Types].xml",
            "<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types' />",
        )
        archive.writestr(
            "xl/workbook.xml",
            "<workbook xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'>"
            "<sheets><sheet sheetId='1'/></sheets></workbook>",
        )
        archive.writestr(
            "xl/worksheets/sheet1.xml",
            "<worksheet xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'>"
            "<dimension ref='A1:C24'/><sheetData><row r='1'><c r='A1'/>"
            "<c r='B1'/><c r='C1'/></row><row r='24'><c r='C24'/></row>"
            "</sheetData></worksheet>",
        )


def test_source_probe_uses_tabular_shape_without_filename_or_values(
    tmp_path: Path,
) -> None:
    secret = "PRIVATE_ORDER_SO-9001"
    source = tmp_path / f"{secret}.csv"
    source.write_text(
        f"customer,amount\n{secret},100\nOTHER,200\n",
        encoding="utf-8",
    )

    probe = build_source_route_probe(source, declared_source_kind="csv")
    signature = build_document_route_signature(probe.evidence, probe.source_kind)
    serialized = json.dumps(
        {
            "probe": probe.evidence.model_dump(mode="json"),
            "signature": signature.model_dump(mode="json"),
        },
        sort_keys=True,
    )

    assert probe.source_kind == "csv"
    assert signature.format_family == "spreadsheet"
    assert signature.table_shapes[0].column_count == 2
    assert signature.table_shapes[0].row_count_bucket == "few"
    assert probe.evidence.text == ""
    assert secret not in serialized
    assert source.name not in serialized


def test_source_probe_reads_ooxml_scale_without_cell_values(tmp_path: Path) -> None:
    source = tmp_path / "private-vendor-layout.xlsx"
    _write_minimal_xlsx(source)

    probe = build_source_route_probe(source, declared_source_kind="xlsx")
    signature = build_document_route_signature(probe.evidence, probe.source_kind)

    assert probe.source_kind == "xlsx"
    assert signature.format_family == "spreadsheet"
    assert signature.table_shapes[0].column_count == 3
    assert signature.table_shapes[0].row_count_bucket == "many"
    assert "container:ooxml" in signature.layout_tokens
    assert "private-vendor-layout" not in signature.embedding_text()


def test_source_probe_reads_pdf_text_layer_and_low_dpi_structure(
    tmp_path: Path,
) -> None:
    fitz = pytest.importorskip("fitz")
    secret = "TOP-SECRET-CONTRACT-9001"
    source = tmp_path / "private.pdf"
    document = fitz.open()
    page = document.new_page(width=400, height=300)
    page.insert_text((40, 40), secret)
    for offset in (60, 120, 180):
        page.draw_line((40, offset), (360, offset))
    for offset in (40, 140, 260, 360):
        page.draw_line((offset, 60), (offset, 180))
    document.save(source)
    document.close()

    probe = build_source_route_probe(source, declared_source_kind="pdf")
    signature = build_document_route_signature(probe.evidence, probe.source_kind)
    serialized = json.dumps(probe.evidence.model_dump(mode="json"), sort_keys=True)

    assert probe.source_kind == "pdf"
    assert "pdf:text_layer" in signature.layout_tokens
    assert any(token.startswith("pdf:low_dpi_") for token in signature.layout_tokens)
    assert secret not in serialized
    assert secret not in signature.embedding_text()


def test_source_probe_stops_before_reading_an_oversized_text_upload(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(document_route_probe, "_MAX_PROBE_SOURCE_BYTES", 64)
    source = tmp_path / "large.csv"
    source.write_bytes(b"a,b\n" + b"x,y\n" * 128)

    probe = build_source_route_probe(source, declared_source_kind="csv")
    signature = build_document_route_signature(probe.evidence, probe.source_kind)

    assert probe.source_kind == "csv"
    assert "probe:source_too_large" in signature.layout_tokens
    assert not signature.table_shapes


def test_source_probe_rejects_zip_member_fanout_without_decompression(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(document_route_probe, "_MAX_PROBE_ZIP_MEMBERS", 1)
    source = tmp_path / "fanout.zip"
    with ZipFile(source, "w", ZIP_DEFLATED) as archive:
        archive.writestr("first.txt", "a")
        archive.writestr("second.txt", "b")

    probe = build_source_route_probe(source, declared_source_kind="zip")
    signature = build_document_route_signature(probe.evidence, probe.source_kind)

    assert probe.source_kind == "archive"
    assert "archive:members" not in signature.layout_tokens


@pytest.mark.asyncio
async def test_preparse_resolver_receives_only_source_probe_structure(
    tmp_path: Path,
) -> None:
    secret = "PRIVATE-VALUE-123"
    source = tmp_path / "private.csv"
    source.write_text(f"field\n{secret}\n", encoding="utf-8")
    policy = RouteProfilePolicy(backend_chain=("spreadsheet",))

    class Runtime:
        required = True

        async def resolve(self, _tenant, _task, evidence, source_kind, **_kwargs):
            serialized = json.dumps(evidence.model_dump(mode="json"), sort_keys=True)
            assert source_kind == "csv"
            assert evidence.text == ""
            assert secret not in serialized
            return DocumentRoutingResolution(
                mode="guarded",
                recommendation="reuse",
                reason="exact_fingerprint",
                signature_fingerprint="b" * 64,
                recommended_profile_id="route-a",
                applied_profile_id="route-a",
                applied_policy=policy,
            )

    class Pipeline(DocumentPipelineMixin):
        deps = SimpleNamespace(document_routing_runtime=Runtime())

        async def _save(self, _state):
            return None

    state = _state(file_type="csv", task_id="task-a")
    state.file_path = str(source)
    plan, summary = await Pipeline()._preparse_document_route_stage(state)

    assert plan is not None
    assert plan["backend_chain"][0]["backend"] == "spreadsheet"
    assert summary is not None and summary["stage"] == "preparse"


@pytest.mark.asyncio
async def test_preparse_required_route_propagates_semantic_selector_failure(
    tmp_path: Path,
) -> None:
    source = tmp_path / "required-semantic-route.csv"
    source.write_text("field\nvalue\n", encoding="utf-8")
    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        backend_chain=("spreadsheet",),
    )

    class Runtime:
        required = True

        async def resolve(self, *_args, **_kwargs):
            return DocumentRoutingResolution(
                mode="guarded",
                recommendation="reuse",
                reason="exact_fingerprint",
                signature_fingerprint="c" * 64,
                recommended_profile_id="route-required",
                applied_profile_id="route-required",
                applied_policy=policy,
            )

    class FailingSelector:
        async def select(self, _request):
            raise RuntimeError("private model provider detail")

    class Pipeline(DocumentPipelineMixin):
        deps = SimpleNamespace(
            document_routing_runtime=Runtime(),
            semantic_strategy_selector=FailingSelector(),
        )

        async def _save(self, _state):
            return None

    state = _state(file_type="csv", task_id="task-required-semantic")
    state.file_path = str(source)

    with pytest.raises(DocumentRoutingDependencyError) as captured:
        await Pipeline()._preparse_document_route_stage(state)

    assert captured.value.dependency == "model"
    assert "private model provider detail" not in str(captured.value)


@pytest.mark.asyncio
async def test_preparse_probe_deadline_uses_deterministic_path(monkeypatch) -> None:
    def slow_probe(*_args, **_kwargs):
        import time

        time.sleep(0.2)
        raise AssertionError("probe should not complete before its deadline")

    monkeypatch.setattr(document_route_probe, "build_source_route_probe", slow_probe)

    class Runtime:
        required = False

        async def resolve(self, *_args, **_kwargs):
            raise AssertionError("a timed-out probe must not reach model routing")

    class Pipeline(DocumentPipelineMixin):
        deps = SimpleNamespace(
            document_routing_runtime=Runtime(),
            document_router_probe_timeout_seconds=0.01,
        )

        async def _save(self, _state):
            return None

    plan, summary = await Pipeline()._preparse_document_route_stage(_state())

    assert plan is None
    assert summary is None
    await asyncio.sleep(0.21)


@pytest.mark.asyncio
async def test_non_mineru_preparse_route_remains_advisory_under_full_authority() -> (
    None
):
    plan = _route_plan(RouteTarget(backend=RouteBackend.PP_STRUCTURE_V3))
    calls: list[dict] = []

    class Pipeline(DocumentPipelineMixin):
        deps = SimpleNamespace(document_routing_runtime=object())

        async def _preparse_document_route_stage(self, state):
            self._activate_route_plan(state, plan)
            return plan.value_free_dump(), {"status": "resolved", "stage": "preparse"}

        async def _run_mineru_full_pipeline(self, _state, **kwargs):
            calls.append(kwargs)

    pipeline = Pipeline()
    state = _state(task_id="task-full-route")
    await pipeline._run_document_pipeline(state)

    assert calls == [
        {
            "active_route_plan": plan,
            "route_plan": plan.value_free_dump(),
            "routing_summary": {"status": "resolved", "stage": "preparse"},
        }
    ]
    assert pipeline._active_route_plan_registry() == {}
