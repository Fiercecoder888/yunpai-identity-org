from __future__ import annotations

from importlib import import_module
from pathlib import Path

from alembic import command
from sqlalchemy import create_engine, inspect

from m1.knowledge.migrations.runner import _config


def test_recalculation_revision_is_sqlite_safe(tmp_path: Path) -> None:
    engine = create_engine(f"sqlite:///{tmp_path / 'knowledge.db'}")
    try:
        with engine.begin() as connection:
            command.upgrade(_config(connection), "0017_recalculation_ledger")
            assert not inspect(connection).has_table("fact_versions")
            command.downgrade(_config(connection), "0016_unified_business_core")
    finally:
        engine.dispose()


def test_recalculation_revision_declares_governed_immutable_contract() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0017_recalculation_ledger"
    )

    assert migration.down_revision == "0016_unified_business_core"
    assert migration.SCHEMA == "yunpai_core"
    assert set(migration.TABLES) == {
        "fact_versions",
        "algorithm_versions",
        "calculation_runs",
        "calculation_inputs",
        "validation_results",
        "supply_allocations",
        "recalculation_jobs",
        "recalculation_job_orders",
    }
    assert set(migration.IMMUTABLE_TABLES) == {
        "fact_versions",
        "algorithm_versions",
        "calculation_runs",
        "calculation_inputs",
        "validation_results",
        "supply_allocations",
    }
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())

    source = Path(migration.__file__).read_text(encoding="utf-8")
    assert "FORCE ROW LEVEL SECURITY" in source
    assert "current_setting('yunpai.tenant_id', true)" in source
    assert "BEFORE UPDATE OR DELETE" in source
    assert "replay_of_run_id" in source
