from __future__ import annotations

from m1.documents.parsing.evidence import (
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.region_capability_contracts import (
    ComplexityBucket,
    ConfidenceBucket,
    CoverageBucket,
    OrientationBucket,
    ParsingCapability,
    RegionFeature,
    RegionKind,
    RegionSourceKind,
    TableState,
    TextPresence,
)
from m1.documents.parsing.region_capability_probe import (
    build_page_capability_probe,
)


def _bbox(x0: float, y0: float, x1: float, y1: float) -> EvidenceBBox:
    return EvidenceBBox(x0=x0, y0=y0, x1=x1, y1=y1)


def test_page_probe_never_retains_text_coordinates_or_page_identity() -> None:
    secret = "CUSTOMER-SECRET-ORDER-9988"
    page = EvidencePage(
        page_number=17,
        page_index=16,
        width=1200,
        height=1600,
        blocks=[
            EvidenceBlock(
                block_id="secret-block-id",
                kind="text",
                text=secret,
                bbox=_bbox(11, 22, 333, 444),
                confidence=0.70,
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.PDF_PAGE,
    )
    payload = probe.model_dump_json()

    assert secret not in payload
    assert "secret-block-id" not in payload
    assert "1200" not in payload
    assert "1600" not in payload
    assert "444" not in payload
    assert "17" not in payload
    assert probe.text_presence is TextPresence.SPARSE
    assert probe.text_confidence is ConfidenceBucket.LOW
    assert probe.orientation is OrientationBucket.PORTRAIT
    assert probe.features == (RegionFeature.HAS_COORDINATES,)


def test_complex_table_and_visual_page_maps_to_coarse_structural_buckets() -> None:
    rows = [[f"cell-{row}-{column}" for column in range(10)] for row in range(20)]
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=1000,
        height=1000,
        rotation=90,
        blocks=[
            EvidenceBlock(
                block_id="figure-1",
                kind="figure",
                bbox=_bbox(0, 0, 600, 600),
            )
        ],
        tables=[
            EvidenceTable(
                table_id="table-1",
                rows=rows,
                bbox=_bbox(0, 0, 900, 900),
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.IMAGE_REGION,
        attempted_capabilities=(ParsingCapability.OCR,),
    )

    assert probe.region_kind is RegionKind.MIXED
    assert probe.visual_coverage is CoverageBucket.HIGH
    assert probe.table_state is TableState.COMPLEX
    assert probe.orientation is OrientationBucket.SQUARE
    assert probe.complexity is ComplexityBucket.HIGH
    assert probe.features == (
        RegionFeature.HAS_COORDINATES,
        RegionFeature.HAS_ROTATION,
        RegionFeature.HAS_CELL_MATRIX,
        RegionFeature.HAS_RASTER,
        RegionFeature.HAS_EMBEDDED_IMAGES,
    )
    assert probe.attempted_capabilities == (ParsingCapability.OCR,)


def test_structured_table_page_does_not_become_complex_without_evidence() -> None:
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=1600,
        height=900,
        tables=[
            EvidenceTable(
                table_id="table-1",
                rows=[["name", "quantity"], ["part", "2"]],
                cells=[EvidenceCell(row=0, column=0, text="name")],
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.SPREADSHEET_REGION,
    )

    assert probe.region_kind is RegionKind.TABLE
    assert probe.table_state is TableState.STRUCTURED
    assert probe.complexity is ComplexityBucket.MEDIUM
    assert probe.orientation is OrientationBucket.LANDSCAPE
    assert probe.features == (RegionFeature.HAS_CELL_MATRIX,)


def test_empty_visual_page_uses_unknown_confidence_and_dominant_coverage() -> None:
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=800,
        height=1000,
        blocks=[
            EvidenceBlock(
                block_id="image-1",
                kind="image",
                bbox=_bbox(0, 0, 800, 1000),
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.IMAGE_REGION,
    )

    assert probe.region_kind is RegionKind.IMAGE
    assert probe.text_presence is TextPresence.NONE
    assert probe.text_confidence is ConfidenceBucket.UNKNOWN
    assert probe.visual_coverage is CoverageBucket.DOMINANT
    assert probe.table_state is TableState.NONE
    assert probe.complexity is ComplexityBucket.MEDIUM


def test_long_high_confidence_text_page_maps_to_substantial_text() -> None:
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=900,
        height=1200,
        blocks=[
            EvidenceBlock(
                block_id="text-1",
                kind="text",
                text="A" * 100,
                confidence=0.95,
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.PDF_PAGE,
    )

    assert probe.region_kind is RegionKind.TEXT
    assert probe.text_presence is TextPresence.SUBSTANTIAL
    assert probe.text_confidence is ConfidenceBucket.HIGH
    assert probe.visual_coverage is CoverageBucket.NONE
    assert probe.complexity is ComplexityBucket.LOW


def test_image_source_keeps_raster_feature_after_successful_text_ocr() -> None:
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=900,
        height=1200,
        blocks=[
            EvidenceBlock(
                block_id="text-1",
                kind="text",
                text="A" * 100,
                confidence=0.95,
            )
        ],
    )

    probe = build_page_capability_probe(
        page,
        source_kind=RegionSourceKind.IMAGE_REGION,
    )

    assert probe.region_kind is RegionKind.TEXT
    assert probe.producer_revision == "m1.region-probe.v2"
    assert probe.features == (RegionFeature.HAS_RASTER,)
