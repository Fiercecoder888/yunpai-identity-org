from __future__ import annotations

import hashlib
import inspect as pyinspect
from pathlib import Path

import pytest
from alembic import command
from m1.documents.parsing.region_capability_contracts import (
    CapabilityProfileStatus,
    ConfidenceBucket,
    ParsingCapability,
    RegionCapabilityCandidateProposal,
    RegionCapabilityExecutionObservation,
    RegionCapabilityProbe,
    RegionKind,
    RegionScope,
    RegionSourceKind,
    TableState,
    TextPresence,
)
from m1.knowledge.db_models_base import (
    IdempotencyConflictError,
    TenantBoundaryError,
)
from m1.knowledge.migrations.runner import _config
from m1.knowledge.region_capability_db_models import (
    RegionCapabilityObservationRow,
    RegionCapabilityProfileRow,
)
from m1.knowledge.region_capability_repository import RegionCapabilityRepository
from m1.knowledge.region_capability_schema import (
    RegionCapabilityObservationOutcome,
    RegionCapabilityObservationRecord,
    RegionCapabilityProfileRecord,
)
from m1.knowledge.schema import TenantRecord
from sqlalchemy import create_engine, inspect
from sqlalchemy.exc import IntegrityError


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _signature(
    *,
    source_kind: RegionSourceKind = RegionSourceKind.PDF_PAGE,
    scope: RegionScope = RegionScope.PAGE,
    region_kind: RegionKind = RegionKind.MIXED,
):
    return RegionCapabilityProbe(
        source_kind=source_kind,
        scope=scope,
        region_kind=region_kind,
        text_presence=TextPresence.SPARSE,
        text_confidence=ConfidenceBucket.LOW,
        table_state=TableState.UNSTRUCTURED,
        attempted_capabilities=(ParsingCapability.PP_STRUCTURE_V3,),
    ).signature()


def _profile(
    tenant_id: str,
    *,
    profile_id: str,
    signature=None,
    capability: ParsingCapability = ParsingCapability.PADDLEOCR_VL,
    embedding: list[float] | None = None,
    profile_key: str | None = None,
) -> RegionCapabilityProfileRecord:
    resolved = signature or _signature()
    return RegionCapabilityProfileRecord(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=profile_key or f"region-capability:{profile_id}",
        version=1,
        exact_fingerprint=resolved.exact_fingerprint(),
        signature=resolved,
        capability=capability,
        embedding=embedding,
        embedding_model="test-embedding" if embedding is not None else "",
        embedding_dimensions=len(embedding) if embedding is not None else 0,
        created_by="test-suite",
    )


async def _seed_successes(
    store: RegionCapabilityRepository,
    profile: RegionCapabilityProfileRecord,
    *,
    task_names: tuple[str, ...] = ("task-1", "task-2", "task-3"),
    region_prefix: str = "page",
) -> None:
    for index, task_name in enumerate(task_names):
        await store.record_region_capability_execution_observation(
            RegionCapabilityExecutionObservation(
                tenant_id=profile.tenant_id,
                profile_id=profile.profile_id,
                exact_fingerprint=profile.exact_fingerprint,
                task_reference_hash=_hash(task_name),
                region_reference_hash=_hash(f"{region_prefix}-{index}"),
                outcome="success",
                validation_passed=True,
                reviewed_by=f"reviewer-{index}",
                review_note_sha256=_hash(f"review-note-{index}"),
                latency_ms=10 + index,
            )
        )


@pytest.fixture
async def region_store(tmp_path: Path):
    store = RegionCapabilityRepository(
        f"sqlite+aiosqlite:///{(tmp_path / 'region-routes.db').as_posix()}"
    )
    await store.init()
    first = TenantRecord(tenant_key="tenant-a", display_name="Tenant A")
    second = TenantRecord(tenant_key="tenant-b", display_name="Tenant B")
    await store.create_tenant(first)
    await store.create_tenant(second)
    try:
        yield store, first, second
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_automatic_candidate_is_idempotent_inactive_and_capability_scoped(
    region_store,
) -> None:
    store, tenant, _second = region_store
    signature = _signature()
    first_proposal = RegionCapabilityCandidateProposal(
        tenant_id=tenant.tenant_id,
        profile_key=(
            f"region-capability:{signature.exact_fingerprint()[:20]}:paddleocr_vl"
        ),
        signature=signature,
        capability=ParsingCapability.PADDLEOCR_VL,
    )
    second_proposal = RegionCapabilityCandidateProposal(
        tenant_id=tenant.tenant_id,
        profile_key=f"region-capability:{signature.exact_fingerprint()[:20]}:ocr",
        signature=signature,
        capability=ParsingCapability.OCR,
    )

    first = await store.create_region_capability_candidate(first_proposal)
    replay = await store.create_region_capability_candidate(first_proposal)
    second = await store.create_region_capability_candidate(second_proposal)
    with pytest.raises(IdempotencyConflictError):
        await store.create_region_capability_candidate(
            first_proposal.model_copy(
                update={"profile_key": "region-capability:conflicting-payload"}
            )
        )

    assert first.status is CapabilityProfileStatus.CANDIDATE
    assert replay.profile_id == first.profile_id
    assert second.profile_id != first.profile_id
    assert second.capability is ParsingCapability.OCR
    assert (
        await store.get_active_region_capability_profile_by_fingerprint(
            tenant.tenant_id,
            signature.exact_fingerprint(),
            contract_revision=signature.contract_revision,
            producer_revision=signature.producer_revision,
        )
        is None
    )


@pytest.mark.asyncio
async def test_activation_requires_three_distinct_reviewed_tasks(region_store) -> None:
    store, tenant, _second = region_store
    profile = await store.create_region_capability_profile(
        _profile(tenant.tenant_id, profile_id="region-three-tasks")
    )
    await _seed_successes(store, profile, task_names=("task-1", "task-2"))

    with pytest.raises(ValueError, match="at least three"):
        await store.activate_region_capability_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="two samples are insufficient",
            expected_observation_count=2,
        )

    await store.record_region_capability_execution_observation(
        RegionCapabilityExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=_hash("task-3"),
            region_reference_hash=_hash("page-3"),
            outcome="success",
            validation_passed=True,
            reviewed_by="reviewer-3",
            review_note_sha256=_hash("review-note-3"),
        )
    )
    active = await store.activate_region_capability_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="three reviewed tasks passed",
        expected_observation_count=3,
    )

    assert active.status is CapabilityProfileStatus.ACTIVE
    exact = await store.get_active_region_capability_profile_by_fingerprint(
        tenant.tenant_id,
        profile.exact_fingerprint,
        contract_revision=profile.signature.contract_revision,
        producer_revision=profile.signature.producer_revision,
    )
    assert exact is not None and exact.profile_id == profile.profile_id


@pytest.mark.asyncio
async def test_activation_rejects_duplicate_tasks_and_failed_samples(
    region_store,
) -> None:
    store, tenant, _second = region_store
    duplicate = await store.create_region_capability_profile(
        _profile(tenant.tenant_id, profile_id="region-duplicate-tasks")
    )
    for index in range(3):
        await store.record_region_capability_observation(
            RegionCapabilityObservationRecord(
                observation_id=f"duplicate-observation-{index}",
                tenant_id=tenant.tenant_id,
                profile_id=duplicate.profile_id,
                idempotency_key=f"duplicate-key-{index}",
                exact_fingerprint=duplicate.exact_fingerprint,
                task_reference_hash=_hash("same-task"),
                region_reference_hash=_hash(f"region-{index}"),
                outcome=RegionCapabilityObservationOutcome.SUCCESS,
                validation_passed=True,
                reviewed_by="reviewer",
                review_note_sha256=_hash(f"note-{index}"),
            )
        )
    with pytest.raises(IdempotencyConflictError, match="distinct-tasks"):
        await store.activate_region_capability_profile(
            tenant.tenant_id,
            duplicate.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="duplicate task samples must fail",
            expected_observation_count=3,
        )

    failed = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-failed-sample",
            signature=_signature(region_kind=RegionKind.IMAGE),
        )
    )
    await _seed_successes(store, failed)
    await store.record_region_capability_execution_observation(
        RegionCapabilityExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=failed.profile_id,
            exact_fingerprint=failed.exact_fingerprint,
            task_reference_hash=_hash("failed-task"),
            region_reference_hash=_hash("failed-region"),
            outcome="failure",
            validation_passed=False,
            error_code="invalid_evidence",
        )
    )
    with pytest.raises(IdempotencyConflictError, match="failures"):
        await store.activate_region_capability_profile(
            tenant.tenant_id,
            failed.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="failure blocks activation",
            expected_observation_count=4,
        )


@pytest.mark.asyncio
async def test_observations_are_region_idempotent_and_tenant_safe(region_store) -> None:
    store, tenant, second = region_store
    profile = await store.create_region_capability_profile(
        _profile(tenant.tenant_id, profile_id="region-idempotent")
    )
    first = RegionCapabilityExecutionObservation(
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        exact_fingerprint=profile.exact_fingerprint,
        task_reference_hash=_hash("task-idempotent"),
        region_reference_hash=_hash("page-1"),
        outcome="success",
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256=_hash("reviewed"),
        latency_ms=17,
    )
    persisted = await store.record_region_capability_execution_observation(first)
    replay = await store.record_region_capability_execution_observation(first)
    second_region = await store.record_region_capability_execution_observation(
        first.model_copy(update={"region_reference_hash": _hash("page-2")})
    )
    assert replay.observation_id == persisted.observation_id
    assert second_region.observation_id != persisted.observation_id

    conflicting = RegionCapabilityObservationRecord(
        observation_id="conflicting-observation",
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        idempotency_key=persisted.idempotency_key,
        exact_fingerprint=profile.exact_fingerprint,
        task_reference_hash=first.task_reference_hash,
        region_reference_hash=first.region_reference_hash,
        outcome=RegionCapabilityObservationOutcome.SUCCESS,
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256=_hash("reviewed"),
        latency_ms=99,
    )
    with pytest.raises(IdempotencyConflictError):
        await store.record_region_capability_observation(conflicting)
    with pytest.raises(TenantBoundaryError):
        await store.record_region_capability_observation(
            conflicting.model_copy(
                update={
                    "tenant_id": second.tenant_id,
                    "observation_id": "cross-tenant-observation",
                    "idempotency_key": "cross-tenant-key",
                }
            )
        )


@pytest.mark.asyncio
async def test_vector_search_is_tenant_source_scope_and_failure_scoped(
    region_store,
) -> None:
    store, tenant, second = region_store
    vector = [1.0, *([0.0] * 1023)]
    page = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-vector-page",
            embedding=vector,
        )
    )
    region_signature = _signature(
        source_kind=RegionSourceKind.IMAGE_REGION,
        scope=RegionScope.REGION,
        region_kind=RegionKind.IMAGE,
    )
    region = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-vector-crop",
            signature=region_signature,
            embedding=vector,
        )
    )
    other = await store.create_region_capability_profile(
        _profile(
            second.tenant_id,
            profile_id="region-vector-other-tenant",
            embedding=vector,
        )
    )
    for profile in (page, region, other):
        await _seed_successes(store, profile, region_prefix=profile.profile_id)
        await store.activate_region_capability_profile(
            profile.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="validated vector profile",
            expected_observation_count=3,
        )

    matches = await store.find_active_region_capability_profiles(
        tenant.tenant_id,
        vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        contract_revision=page.signature.contract_revision,
        producer_revision=page.signature.producer_revision,
        source_kind=RegionSourceKind.PDF_PAGE,
        scope=RegionScope.PAGE,
        limit=5,
    )
    assert [(item.profile.profile_id, item.vector_similarity) for item in matches] == [
        (page.profile_id, 1.0)
    ]

    await store.record_region_capability_execution_observation(
        RegionCapabilityExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=page.profile_id,
            exact_fingerprint=page.exact_fingerprint,
            task_reference_hash=_hash("active-failure-task"),
            region_reference_hash=_hash("active-failure-page"),
            outcome="failure",
            validation_passed=False,
            error_code="backend_failure",
        )
    )
    failed_exact = await store.get_active_region_capability_profile_by_fingerprint(
        tenant.tenant_id,
        page.exact_fingerprint,
        contract_revision=page.signature.contract_revision,
        producer_revision=page.signature.producer_revision,
    )
    assert failed_exact is None
    failed_profile = await store.get_region_capability_profile(
        tenant.tenant_id, page.profile_id
    )
    assert failed_profile is not None
    assert failed_profile.status is CapabilityProfileStatus.DEPRECATED
    assert failed_profile.failure_count == 1
    assert (
        await store.find_active_region_capability_profiles(
            tenant.tenant_id,
            vector,
            embedding_model="test-embedding",
            embedding_dimensions=1024,
            contract_revision=page.signature.contract_revision,
            producer_revision=page.signature.producer_revision,
            source_kind=RegionSourceKind.PDF_PAGE,
            scope=RegionScope.PAGE,
            limit=5,
        )
        == []
    )


@pytest.mark.asyncio
async def test_activation_rejects_a_capability_without_a_current_executor(
    region_store,
) -> None:
    store, tenant, _second = region_store
    signature = _signature()
    first = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-active-first",
            signature=signature,
            profile_key="region-capability:first",
        )
    )
    second = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-active-second",
            signature=signature,
            capability=ParsingCapability.OCR,
            profile_key="region-capability:second",
        )
    )
    for profile in (first, second):
        await _seed_successes(store, profile, region_prefix=profile.profile_id)
    await store.activate_region_capability_profile(
        tenant.tenant_id,
        first.profile_id,
        approved_by="approver-a",
        reviewed_by="reviewer-a",
        review_note="first route",
        expected_observation_count=3,
    )
    with pytest.raises(ValueError, match="currently executable registry"):
        await store.activate_region_capability_profile(
            tenant.tenant_id,
            second.profile_id,
            approved_by="approver-b",
            reviewed_by="reviewer-b",
            review_note="replacement route",
            expected_observation_count=3,
        )

    assert (
        await store.get_region_capability_profile(tenant.tenant_id, first.profile_id)
    ).status is CapabilityProfileStatus.ACTIVE
    exact = await store.get_active_region_capability_profile_by_fingerprint(
        tenant.tenant_id,
        signature.exact_fingerprint(),
        contract_revision=signature.contract_revision,
        producer_revision=signature.producer_revision,
    )
    assert exact is not None and exact.profile_id == first.profile_id


@pytest.mark.asyncio
async def test_database_rejects_two_active_profiles_for_one_fingerprint(
    region_store,
) -> None:
    store, tenant, _second = region_store
    signature = _signature()
    first = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-unique-first",
            signature=signature,
            profile_key="region-capability:unique-first",
        )
    )
    second = await store.create_region_capability_profile(
        _profile(
            tenant.tenant_id,
            profile_id="region-unique-second",
            signature=signature,
            capability=ParsingCapability.OCR,
            profile_key="region-capability:unique-second",
        )
    )
    await _seed_successes(store, first, region_prefix=first.profile_id)
    await store.activate_region_capability_profile(
        tenant.tenant_id,
        first.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="first active profile",
        expected_observation_count=3,
    )

    with pytest.raises(IntegrityError):
        async with store.sessionmaker.begin() as session:
            row = await session.get(RegionCapabilityProfileRow, second.profile_id)
            assert row is not None
            row.status = CapabilityProfileStatus.ACTIVE.value
            row.reviewed_by = "reviewer"
            row.reviewed_at = second.created_at
            row.review_note = "direct conflicting activation"
            row.approved_by = "approver"
            row.approved_at = second.created_at


@pytest.mark.asyncio
async def test_reject_and_deprecate_are_tenant_safe(region_store) -> None:
    store, tenant, second = region_store
    rejected = await store.create_region_capability_profile(
        _profile(tenant.tenant_id, profile_id="region-rejected")
    )
    result = await store.reject_region_capability_profile(
        tenant.tenant_id,
        rejected.profile_id,
        reviewed_by="reviewer",
        review_note="not a valid route",
    )
    assert result.status is CapabilityProfileStatus.REJECTED
    with pytest.raises(ValueError, match="rejected"):
        await store.deprecate_region_capability_profile(
            tenant.tenant_id,
            rejected.profile_id,
            reviewed_by="reviewer",
            review_note="invalid transition",
        )
    with pytest.raises(TenantBoundaryError):
        await store.reject_region_capability_profile(
            second.tenant_id,
            rejected.profile_id,
            reviewed_by="reviewer",
            review_note="cross tenant",
        )


@pytest.mark.asyncio
async def test_composite_foreign_key_blocks_cross_tenant_direct_write(
    region_store,
) -> None:
    store, tenant, second = region_store
    profile = await store.create_region_capability_profile(
        _profile(tenant.tenant_id, profile_id="region-composite-fk")
    )
    with pytest.raises(IntegrityError):
        async with store.sessionmaker.begin() as session:
            session.add(
                RegionCapabilityObservationRow(
                    observation_id="region-invalid-fk",
                    tenant_id=second.tenant_id,
                    profile_id=profile.profile_id,
                    idempotency_key="region-invalid-fk",
                    exact_fingerprint=profile.exact_fingerprint,
                    task_reference_hash=_hash("direct-cross-tenant"),
                    region_reference_hash=_hash("direct-cross-region"),
                    outcome="success",
                    validation_passed=True,
                    reviewed_by="reviewer",
                    review_note_sha256=_hash("reviewed"),
                    latency_ms=0,
                    error_code="",
                    observed_at=profile.created_at,
                )
            )


def test_region_capability_migration_round_trip_rls_and_identifiers(
    tmp_path: Path,
) -> None:
    migration = __import__(
        "m1.knowledge.migrations.versions.0014_region_capability_routes",
        fromlist=["revision"],
    )
    assert migration.down_revision == "0013_visual_region_routes"
    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63
    assert len(migration.EMBEDDING_SPACE_INDEX) <= 63
    assert set(migration.TENANT_TABLES) == {
        "knowledge_region_capability_profiles",
        "knowledge_region_capability_observations",
    }
    source = Path(migration.__file__).read_text(encoding="utf-8")
    assert "ENABLE ROW LEVEL SECURITY" in source
    assert "FORCE ROW LEVEL SECURITY" in source
    assert "CREATE POLICY" in source

    database = tmp_path / "region-capability-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, migration.revision)
            schema = inspect(connection)
            assert {
                migration.PROFILE_TABLE,
                migration.OBSERVATION_TABLE,
            }.issubset(schema.get_table_names())
            indexes = {
                item["name"] for item in schema.get_indexes(migration.PROFILE_TABLE)
            }
            assert "ux_region_cap_profiles_active_fingerprint" in indexes
            command.downgrade(config, migration.down_revision)
            assert migration.PROFILE_TABLE not in inspect(connection).get_table_names()
            command.upgrade(config, migration.revision)
            assert migration.PROFILE_TABLE in inspect(connection).get_table_names()
    finally:
        engine.dispose()


def test_region_capability_models_have_tenant_safe_composite_foreign_keys() -> None:
    from m1.knowledge.db_models_base import KnowledgeBase

    observation = KnowledgeBase.metadata.tables[
        "knowledge_region_capability_observations"
    ]
    targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in observation.foreign_key_constraints
    }
    assert (
        "knowledge_region_capability_profiles.tenant_id",
        "knowledge_region_capability_profiles.profile_id",
    ) in targets


def test_standalone_repository_candidate_call_exposes_record_for_rls_context() -> None:
    parameters = pyinspect.signature(
        RegionCapabilityRepository.create_region_capability_candidate
    ).parameters
    assert "record" in parameters
    assert "proposal" not in parameters
