from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

import pytest
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.region_capability_contracts import (
    CapabilityProfileStatus,
    ComplexityBucket,
    ConfidenceBucket,
    CoverageBucket,
    OrientationBucket,
    ParsingCapability,
    RegionCapabilityCandidateProposal,
    RegionCapabilityExecutionObservation,
    RegionCapabilityModelChoice,
    RegionCapabilityProbe,
    RegionCapabilityProfile,
    RegionCapabilityProfileMatch,
    RegionCapabilityRoutingPolicy,
    RegionCapabilitySelectionRequest,
    RegionFeature,
    RegionKind,
    RegionScope,
    RegionSourceKind,
    TableState,
    TextPresence,
)
from m1.documents.parsing.region_capability_routing import (
    PydanticRegionCapabilitySelector,
    RegionCapabilityRoutingRuntime,
    capability_is_compatible,
)
from pydantic import ValidationError

VECTOR = (0.1, 0.2, 0.3)


def _probe(
    *,
    source_kind: RegionSourceKind = RegionSourceKind.PDF_PAGE,
    region_kind: RegionKind = RegionKind.MIXED,
    attempted: tuple[ParsingCapability, ...] = (),
) -> RegionCapabilityProbe:
    return RegionCapabilityProbe(
        source_kind=source_kind,
        scope=RegionScope.PAGE,
        region_kind=region_kind,
        text_presence=TextPresence.SPARSE,
        text_confidence=ConfidenceBucket.LOW,
        visual_coverage=CoverageBucket.HIGH,
        table_state=TableState.UNSTRUCTURED,
        orientation=OrientationBucket.PORTRAIT,
        complexity=ComplexityBucket.HIGH,
        features=(RegionFeature.HAS_COORDINATES, RegionFeature.HAS_RASTER),
        attempted_capabilities=attempted,
    )


def _profile(
    signature,
    *,
    profile_id: str = "region-profile-a",
    tenant_id: str = "tenant-a",
    capability: ParsingCapability = ParsingCapability.PADDLEOCR_VL,
    status: CapabilityProfileStatus = CapabilityProfileStatus.ACTIVE,
    embedding: tuple[float, ...] | None = VECTOR,
    successes: int = 3,
    failures: int = 0,
) -> RegionCapabilityProfile:
    effective_status = (
        CapabilityProfileStatus.DEPRECATED
        if status is CapabilityProfileStatus.ACTIVE and failures
        else status
    )
    return RegionCapabilityProfile(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=f"key:{profile_id}",
        status=effective_status,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        capability=capability,
        embedding=embedding,
        embedding_model="test-region-embedding" if embedding is not None else "",
        embedding_dimensions=len(embedding) if embedding is not None else 0,
        observation_count=successes + failures,
        success_count=successes,
        failure_count=failures,
    )


class _Store:
    def __init__(
        self,
        *,
        exact: RegionCapabilityProfile | None = None,
        matches: Sequence[RegionCapabilityProfileMatch] = (),
        exact_failure: bool = False,
        search_failure: bool = False,
        candidate_failure: bool = False,
        candidate_status: CapabilityProfileStatus = CapabilityProfileStatus.CANDIDATE,
    ) -> None:
        self.exact = exact
        self.matches = tuple(matches)
        self.exact_failure = exact_failure
        self.search_failure = search_failure
        self.candidate_failure = candidate_failure
        self.candidate_status = candidate_status
        self.exact_calls: list[tuple[str, str, str, str]] = []
        self.search_calls: list[tuple[str, str, int, str, str, int]] = []
        self.proposals: list[RegionCapabilityCandidateProposal] = []
        self.observations: list[RegionCapabilityExecutionObservation] = []

    async def get_active_region_capability_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        producer_revision: str,
    ) -> RegionCapabilityProfile | None:
        self.exact_calls.append(
            (tenant_id, exact_fingerprint, contract_revision, producer_revision)
        )
        if self.exact_failure:
            raise RuntimeError("store secret detail")
        return self.exact

    async def find_active_region_capability_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        contract_revision: str,
        producer_revision: str,
        source_kind=None,
        scope=None,
        limit: int,
    ) -> Sequence[RegionCapabilityProfileMatch]:
        del embedding, source_kind, scope
        self.search_calls.append(
            (
                tenant_id,
                embedding_model,
                embedding_dimensions,
                contract_revision,
                producer_revision,
                limit,
            )
        )
        if self.search_failure:
            raise RuntimeError("store search secret detail")
        return self.matches[:limit]

    async def create_region_capability_candidate(
        self, proposal: RegionCapabilityCandidateProposal
    ) -> RegionCapabilityProfile:
        self.proposals.append(proposal)
        if self.candidate_failure:
            raise RuntimeError("candidate store secret detail")
        return RegionCapabilityProfile(
            profile_id=f"candidate-{len(self.proposals)}",
            tenant_id=proposal.tenant_id,
            profile_key=proposal.profile_key,
            status=self.candidate_status,
            exact_fingerprint=proposal.signature.exact_fingerprint(),
            signature=proposal.signature,
            capability=proposal.capability,
            embedding=proposal.embedding,
            embedding_model=proposal.embedding_model,
            embedding_dimensions=proposal.embedding_dimensions,
        )

    async def record_region_capability_execution_observation(
        self, record: RegionCapabilityExecutionObservation
    ) -> None:
        self.observations.append(record)


class _Embedding:
    model = "test-region-embedding"
    dimensions = len(VECTOR)

    def __init__(
        self,
        *,
        vector: tuple[float, ...] = VECTOR,
        failure: bool = False,
    ) -> None:
        self.vector = vector
        self.failure = failure
        self.inputs: list[str] = []

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        self.inputs.extend(texts)
        if self.failure:
            raise TimeoutError("embedding secret detail")
        return (self.vector,)


class _Selector:
    def __init__(self, output: object, *, failure: bool = False) -> None:
        self.output = output
        self.failure = failure
        self.requests: list[RegionCapabilitySelectionRequest] = []

    async def select(self, request: RegionCapabilitySelectionRequest) -> object:
        self.requests.append(request)
        if self.failure:
            raise TimeoutError("model secret detail")
        return self.output


def _model_policy() -> RegionCapabilityRoutingPolicy:
    return RegionCapabilityRoutingPolicy(
        model_candidate_min_score=0.50,
        auto_reuse_min_score=0.99,
        model_reuse_min_score=0.60,
        min_margin=0.05,
    )


def test_probe_contract_is_value_free_and_rejects_business_fields() -> None:
    probe = _probe()
    payload = probe.signature().model_dump_json()

    assert "purchase_contract" not in payload
    assert "task_" not in payload
    assert "filename" not in payload
    with pytest.raises(ValidationError):
        RegionCapabilityProbe.model_validate(
            {
                **probe.model_dump(mode="python"),
                "document_subtype": "purchase_contract",
            }
        )


def test_embedding_text_contains_only_bounded_topology() -> None:
    text = _probe().signature().embedding_text()

    assert "source:pdf_page" in text
    assert "feature:has_coordinates" in text
    assert "tenant" not in text
    assert "task" not in text
    assert "purchase" not in text


@pytest.mark.asyncio
async def test_exact_active_profile_bypasses_embedding_and_model() -> None:
    probe = _probe()
    embedding = _Embedding(failure=True)
    selector = _Selector({"action": "review", "confidence": 1.0})
    store = _Store(exact=_profile(probe.signature()))

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "route"
    assert decision.reason == "exact_active_profile"
    assert decision.capability is ParsingCapability.PADDLEOCR_VL
    assert embedding.inputs == []
    assert selector.requests == []


@pytest.mark.asyncio
async def test_failed_active_profile_is_never_reused() -> None:
    probe = _probe()
    store = _Store(exact=_profile(probe.signature(), failures=1))

    decision = await RegionCapabilityRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a", probe=probe
    )

    assert decision.action == "review"
    assert decision.reason == "active_profile_failed"
    assert decision.capability is None


@pytest.mark.asyncio
async def test_cross_tenant_exact_profile_is_never_reused() -> None:
    probe = _probe()
    store = _Store(exact=_profile(probe.signature(), tenant_id="tenant-b"))

    decision = await RegionCapabilityRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a", probe=probe
    )

    assert decision.action == "review"
    assert decision.reason == "tenant_scope_violation"


@pytest.mark.asyncio
async def test_store_cannot_substitute_a_different_exact_signature() -> None:
    probe = _probe(region_kind=RegionKind.MIXED)
    different = _probe(region_kind=RegionKind.TABLE)
    store = _Store(exact=_profile(different.signature()))

    decision = await RegionCapabilityRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a", probe=probe
    )

    assert decision.action == "review"
    assert decision.reason == "exact_profile_incompatible"


@pytest.mark.asyncio
async def test_attempted_capability_blocks_exact_reuse() -> None:
    original = _probe()
    retried = _probe(attempted=(ParsingCapability.PADDLEOCR_VL,))
    profile = _profile(
        retried.signature(),
        capability=ParsingCapability.PADDLEOCR_VL,
    )
    store = _Store(exact=profile)

    decision = await RegionCapabilityRoutingRuntime(store=store).resolve(
        tenant_id="tenant-a", probe=retried
    )

    assert original.signature() != retried.signature()
    assert decision.action == "review"
    assert decision.reason == "exact_profile_incompatible"


@pytest.mark.asyncio
async def test_high_score_vector_candidate_auto_reuses_without_model() -> None:
    probe = _probe()
    profile = _profile(probe.signature())
    selector = _Selector({"action": "review", "confidence": 1.0})
    store = _Store(
        matches=(RegionCapabilityProfileMatch(profile=profile, vector_similarity=1.0),)
    )

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "route"
    assert decision.reason == "vector_auto_reuse"
    assert decision.profile_id == profile.profile_id
    assert selector.requests == []


@pytest.mark.asyncio
async def test_vector_query_declares_tenant_contract_and_embedding_space() -> None:
    probe = _probe()
    selector = _Selector({"action": "generic", "confidence": 1.0})
    store = _Store()

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.reason == "model_generic"
    assert store.search_calls == [
        (
            "tenant-a",
            "test-region-embedding",
            len(VECTOR),
            "m1.region-capability.v1",
            "m1.region-probe.v1",
            20,
        )
    ]


@pytest.mark.asyncio
async def test_runtime_filters_cross_tenant_and_wrong_embedding_candidates() -> None:
    probe = _probe()
    cross_tenant = _profile(
        probe.signature(), profile_id="cross-tenant", tenant_id="tenant-b"
    )
    wrong_space = _profile(probe.signature(), profile_id="wrong-space").model_copy(
        update={"embedding_model": "other-embedding"}
    )
    selector = _Selector({"action": "generic", "confidence": 1.0})
    store = _Store(
        matches=(
            RegionCapabilityProfileMatch(profile=cross_tenant, vector_similarity=1.0),
            RegionCapabilityProfileMatch(profile=wrong_space, vector_similarity=1.0),
        )
    )

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.reason == "model_generic"
    assert selector.requests[0].candidates == ()


@pytest.mark.asyncio
async def test_model_may_reuse_only_the_top_active_candidate() -> None:
    probe = _probe()
    first = _profile(probe.signature(), profile_id="profile-first")
    second = _profile(
        probe.signature(),
        profile_id="profile-second",
        capability=ParsingCapability.PP_STRUCTURE_V3,
    )
    store = _Store(
        matches=(
            RegionCapabilityProfileMatch(profile=first, vector_similarity=0.80),
            RegionCapabilityProfileMatch(profile=second, vector_similarity=0.75),
        )
    )
    selector = _Selector({"action": "reuse", "candidate_index": 1, "confidence": 0.99})

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
        policy=_model_policy(),
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "review"
    assert decision.reason == "model_candidate_not_top"
    assert decision.capability is None


@pytest.mark.asyncio
async def test_model_reuses_top_candidate_after_all_thresholds() -> None:
    probe = _probe()
    profile = _profile(probe.signature())
    store = _Store(
        matches=(RegionCapabilityProfileMatch(profile=profile, vector_similarity=0.80),)
    )
    selector = _Selector({"action": "reuse", "candidate_index": 0, "confidence": 0.99})

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
        policy=_model_policy(),
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "route"
    assert decision.reason == "model_reuse"
    assert decision.profile_id == profile.profile_id


@pytest.mark.asyncio
async def test_low_confidence_model_reuse_requires_review() -> None:
    probe = _probe()
    profile = _profile(probe.signature())
    store = _Store(
        matches=(RegionCapabilityProfileMatch(profile=profile, vector_similarity=0.80),)
    )
    selector = _Selector({"action": "reuse", "candidate_index": 0, "confidence": 0.50})

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
        policy=_model_policy(),
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "review"
    assert decision.reason == "model_confidence_below_threshold"


@pytest.mark.asyncio
async def test_model_new_route_creates_only_an_inactive_candidate() -> None:
    probe = _probe()
    selector = _Selector(
        {"action": "new_candidate", "capability_index": 3, "confidence": 0.99}
    )
    store = _Store()

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    assert decision.action == "new_candidate"
    assert decision.reason == "model_new_candidate"
    assert decision.capability is None
    assert decision.profile_id is None
    assert decision.proposed_capability is ParsingCapability.PADDLEOCR_VL
    assert decision.candidate_profile_id == "candidate-1"
    assert store.proposals[0].capability is ParsingCapability.PADDLEOCR_VL


@pytest.mark.asyncio
async def test_model_cannot_invent_a_capability_or_profile_id() -> None:
    selector = _Selector(
        {
            "action": "new_candidate",
            "capability_index": 0,
            "confidence": 0.99,
            "capability": "invented_backend",
            "profile_id": "invented-profile",
        }
    )
    store = _Store()

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert decision.action == "generic"
    assert decision.reason == "invalid_model_output"
    assert store.proposals == []


@pytest.mark.asyncio
async def test_model_capability_index_is_checked_against_compatible_options() -> None:
    selector = _Selector(
        {"action": "new_candidate", "capability_index": 5, "confidence": 0.99}
    )
    probe = _probe(source_kind=RegionSourceKind.IMAGE_REGION)

    decision = await RegionCapabilityRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=probe)

    request = selector.requests[0]
    assert request.available_capabilities == (
        ParsingCapability.MINERU,
        ParsingCapability.PP_STRUCTURE_V3,
        ParsingCapability.PADDLEOCR_VL,
        ParsingCapability.OCR,
    )
    assert decision.action == "review"
    assert decision.reason == "model_capability_invalid"


@pytest.mark.asyncio
async def test_candidate_store_cannot_return_an_active_profile() -> None:
    selector = _Selector(
        {"action": "new_candidate", "capability_index": 0, "confidence": 0.99}
    )
    store = _Store(candidate_status=CapabilityProfileStatus.ACTIVE)

    decision = await RegionCapabilityRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert decision.action == "generic"
    assert decision.reason == "candidate_store_failure"
    assert decision.candidate_profile_id is None


@pytest.mark.asyncio
async def test_no_selector_preserves_generic_route() -> None:
    decision = await RegionCapabilityRoutingRuntime(
        store=_Store(), embedding_provider=_Embedding()
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert decision.action == "generic"
    assert decision.reason == "no_active_candidates"


@pytest.mark.asyncio
async def test_embedding_failures_open_a_bounded_circuit() -> None:
    embedding = _Embedding(failure=True)
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(),
        embedding_provider=embedding,
        circuit_failures=3,
        circuit_seconds=300,
    )

    decisions = [
        await runtime.resolve(tenant_id="tenant-a", probe=_probe()) for _ in range(4)
    ]

    assert len(embedding.inputs) == 3
    assert decisions[-1].reason == "embedding_circuit_open"
    assert runtime.status_snapshot()["circuit_open"] is True


@pytest.mark.asyncio
async def test_model_failures_open_a_bounded_circuit() -> None:
    selector = _Selector({}, failure=True)
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(),
        selector=selector,
        circuit_failures=3,
        circuit_seconds=300,
    )

    decisions = [
        await runtime.resolve(tenant_id="tenant-a", probe=_probe()) for _ in range(4)
    ]

    assert len(selector.requests) == 3
    assert decisions[-1].reason == "model_circuit_open"


@pytest.mark.asyncio
async def test_required_store_failure_raises_only_a_safe_dependency_error() -> None:
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(exact_failure=True), required=True
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert caught.value.dependency == "store"
    assert "secret detail" not in str(caught.value)


@pytest.mark.asyncio
async def test_required_router_fails_closed_when_embedding_is_missing() -> None:
    runtime = RegionCapabilityRoutingRuntime(store=_Store(), required=True)

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert caught.value.dependency == "embedding"


@pytest.mark.asyncio
async def test_required_router_fails_closed_when_selector_is_missing() -> None:
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(), embedding_provider=_Embedding(), required=True
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert caught.value.dependency == "model"


@pytest.mark.asyncio
async def test_required_router_fails_closed_on_invalid_model_output() -> None:
    selector = _Selector(
        {
            "action": "new_candidate",
            "capability_index": 0,
            "confidence": 0.99,
            "profile_id": "invented-profile",
        }
    )
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(),
        selector=selector,
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert caught.value.dependency == "model"


@pytest.mark.asyncio
async def test_required_router_fails_closed_after_embedding_circuit_opens() -> None:
    embedding = _Embedding(failure=True)
    runtime = RegionCapabilityRoutingRuntime(
        store=_Store(),
        embedding_provider=embedding,
        required=True,
        circuit_failures=3,
    )
    for _index in range(3):
        with pytest.raises(DocumentRoutingDependencyError):
            await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert caught.value.dependency == "embedding"
    assert caught.value.error_type == "CircuitOpen"
    assert len(embedding.inputs) == 3


@pytest.mark.asyncio
async def test_observe_candidate_never_activates_or_executes_it() -> None:
    store = _Store()
    runtime = RegionCapabilityRoutingRuntime(
        store=store, embedding_provider=_Embedding()
    )

    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        probe=_probe(),
        capability=ParsingCapability.PP_STRUCTURE_V3,
    )

    assert candidate.status is CapabilityProfileStatus.CANDIDATE
    assert candidate.capability is ParsingCapability.PP_STRUCTURE_V3
    assert len(store.proposals) == 1


@pytest.mark.asyncio
async def test_reviewed_execution_observation_is_delegated_to_store() -> None:
    store = _Store()
    runtime = RegionCapabilityRoutingRuntime(store=store)
    observation = RegionCapabilityExecutionObservation(
        tenant_id="tenant-a",
        profile_id="profile-1",
        exact_fingerprint="a" * 64,
        task_reference_hash="b" * 64,
        region_reference_hash="c" * 64,
        outcome="success",
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256="d" * 64,
    )

    assert await runtime.record_execution_observation(observation) is True
    assert store.observations == [observation]


def test_source_compatibility_is_code_owned() -> None:
    image_signature = _probe(source_kind=RegionSourceKind.IMAGE_REGION).signature()
    spreadsheet_signature = _probe(
        source_kind=RegionSourceKind.SPREADSHEET_REGION
    ).signature()
    available = tuple(ParsingCapability)

    assert capability_is_compatible(
        ParsingCapability.PADDLEOCR_VL, image_signature, available
    )
    assert not capability_is_compatible(
        ParsingCapability.NATIVE, image_signature, available
    )
    assert not capability_is_compatible(
        ParsingCapability.PADDLEOCR_VL, spreadsheet_signature, available
    )


@dataclass
class _Run:
    output: object


class _Client:
    def __init__(self) -> None:
        self.output_type: type[Any] | None = None
        self.instructions = ""
        self.prompt = ""
        self.request_limit: int | None = None

    async def run(
        self,
        output_type,
        *,
        instructions: str,
        prompt: str,
        request_limit: int | None = None,
    ) -> _Run:
        self.output_type = output_type
        self.instructions = instructions
        self.prompt = prompt
        self.request_limit = request_limit
        return _Run(
            RegionCapabilityModelChoice(
                action="generic",
                confidence=1.0,
            )
        )


@pytest.mark.asyncio
async def test_pydantic_selector_sends_only_the_bounded_request() -> None:
    client = _Client()
    request = RegionCapabilitySelectionRequest(
        signature=_probe().signature(),
        available_capabilities=(
            ParsingCapability.NATIVE,
            ParsingCapability.PADDLEOCR_VL,
        ),
    )

    result = await PydanticRegionCapabilitySelector(client).select(request)

    assert result.action == "generic"
    assert client.output_type is RegionCapabilityModelChoice
    assert client.request_limit == 1
    assert "candidate_index" in client.instructions
    assert "tenant-a" not in client.prompt
    assert "task_" not in client.prompt
    assert "purchase_contract" not in client.prompt
    assert "profile_id" not in client.prompt


def test_available_capabilities_must_use_the_closed_enum() -> None:
    with pytest.raises(TypeError):
        RegionCapabilityRoutingRuntime(
            store=_Store(),
            available_capabilities=("paddleocr_vl",),  # type: ignore[arg-type]
        )
    with pytest.raises(ValueError):
        RegionCapabilityRoutingRuntime(
            store=_Store(),
            available_capabilities=(
                ParsingCapability.OCR,
                ParsingCapability.OCR,
            ),
        )
