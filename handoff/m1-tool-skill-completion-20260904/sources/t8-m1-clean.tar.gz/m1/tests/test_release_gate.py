from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
import yaml

from m1.enhanced_probe import LIGHTRAG_LIFECYCLE, PREFLIGHT_CAPABILITIES
from m1.release_gate import (
    GraphRecoveryEvent,
    ReleaseGateSettings,
    _assert_document_router_ready,
    _assert_entity_router_ready,
    _assert_extension_routers_ready,
    _live_enhancement_configuration_matches,
    _recovery_events_from_environ,
    execute_release_gate_once,
    wait_for_gate_health,
)


def _settings(tmp_path: Path, **updates) -> ReleaseGateSettings:
    release_version = str(updates.get("release_version", "2026.07.26.1+gabcdef0"))
    release_manifest = tmp_path / "release.json"
    release_manifest.write_text(
        json.dumps(
            {
                "package": "yunpai-code",
                "version": release_version,
                "git_commit": "a" * 40,
            }
        ),
        encoding="utf-8",
    )
    values = {
        "base_url": "http://m1:8080",
        "api_key": "api-secret",
        "preflight_key": "preflight-secret",
        "release_version": release_version,
        "state_root": tmp_path,
        "ready_timeout_seconds": 10.0,
        "preflight_timeout_seconds": 20.0,
        "healthcheck_timeout_seconds": 40.0,
        "controller_timeout_seconds": 75.0,
        "recovery_timeout_seconds": 5.0,
        "recovery_events": (),
        "knowledge_database_url": "postgresql+asyncpg://m1:db-secret@postgres/m1",
        "release_manifest_path": release_manifest,
        "image_reference": "registry.yunpai.local:5443/yunpai/m1@sha256:" + "b" * 64,
    }
    values.update(updates)
    return ReleaseGateSettings(**values)


def _ready_payload(*, pending: int = 0, terminal: int = 0) -> dict:
    return {
        "status": "degraded" if terminal or pending else "ready",
        "knowledge": {
            "outbox": {
                "health_complete": True,
                "pending": pending,
                "terminal": {"count": terminal, "present": terminal > 0},
            }
        },
    }


def test_release_gate_requires_an_enabled_document_router_to_be_ready() -> None:
    _assert_document_router_ready({"document_router": {"enabled": False}})
    _assert_document_router_ready(
        {"document_router": {"enabled": True, "ready": True}}
    )
    with pytest.raises(RuntimeError, match="document router"):
        _assert_document_router_ready(
            {"document_router": {"enabled": True, "ready": False}}
        )


def test_release_gate_requires_an_enabled_entity_router_to_be_ready() -> None:
    _assert_entity_router_ready({"entity_router": {"enabled": False}})
    _assert_entity_router_ready({"entity_router": {"enabled": True, "ready": True}})
    with pytest.raises(RuntimeError, match="entity router"):
        _assert_entity_router_ready(
            {"entity_router": {"enabled": True, "ready": False}}
        )


@pytest.mark.parametrize(
    "key",
    (
        "tabular_layout_router",
        "field_semantic_router",
        "visual_region_router",
        "region_capability_router",
        "content_region_router",
    ),
)
def test_release_gate_requires_every_required_extension_router(key: str) -> None:
    _assert_extension_routers_ready({key: {"enabled": False, "ready": False}})
    _assert_extension_routers_ready(
        {key: {"enabled": True, "required": False, "ready": False}}
    )
    _assert_extension_routers_ready(
        {key: {"enabled": True, "required": True, "ready": True}}
    )
    with pytest.raises(RuntimeError, match="router"):
        _assert_extension_routers_ready(
            {key: {"enabled": True, "required": True, "ready": False}}
        )


def _passed_preflight_report() -> dict:
    capabilities = set(PREFLIGHT_CAPABILITIES) | {LIGHTRAG_LIFECYCLE}
    return {
        "mode": "preflight",
        "ready": True,
        "started_at": "2026-07-26T00:00:00+00:00",
        "finished_at": "2026-07-26T00:00:01+00:00",
        "duration_ms": 1000.0,
        "inference_executed": True,
        "network_executed": True,
        "lifecycle_side_effects_requested": True,
        "configuration_fingerprint": "c" * 64,
        "last_preflight_finished_at": "2026-07-26T00:00:01+00:00",
        "last_preflight_ready": True,
        "results": {
            capability: {
                "capability": capability,
                "required": True,
                "configured": True,
                "status": "passed",
                "exercised": True,
                "duration_ms": 1.0,
                "details": {},
                "error_type": None,
            }
            for capability in capabilities
        },
    }


@pytest.mark.asyncio
async def test_release_gate_runs_required_lifecycle_preflight_once(
    tmp_path: Path,
) -> None:
    settings = _settings(tmp_path)
    ready_calls = 0
    preflight_calls: list[dict] = []

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        nonlocal ready_calls
        ready_calls += 1
        return _ready_payload()

    async def preflight_request(**kwargs):
        preflight_calls.append(kwargs)
        return 200, _passed_preflight_report()

    first = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )
    second = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )

    assert first["state"] == "passed"
    assert second == first
    assert ready_calls == 2
    assert len(preflight_calls) == 1
    assert preflight_calls[0] == {
        "base_url": "http://m1:8080",
        "api_key": "api-secret",
        "preflight_key": "preflight-secret",
        "require_all": True,
        "include_lightrag_lifecycle": True,
        "timeout_seconds": 20.0,
    }
    assert wait_for_gate_health(settings) is True
    report = json.loads(settings.report_path.read_text(encoding="utf-8"))
    assert report["report"]["ready"] is True
    assert "api-secret" not in settings.state_path.read_text(encoding="utf-8")
    assert "preflight-secret" not in settings.state_path.read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_release_gate_rejects_once_without_retrying_or_hiding_report(
    tmp_path: Path,
) -> None:
    settings = _settings(tmp_path)
    calls = 0

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        return _ready_payload()

    async def preflight_request(**_kwargs):
        nonlocal calls
        calls += 1
        return 503, {
            "ready": False,
            "mode": "preflight",
            "results": {"mineru_vlm_llm": {"status": "failed"}},
        }

    first = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )
    second = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )

    assert calls == 1
    assert first["state"] == "failed"
    assert first["error_type"] == "PreflightRejected"
    assert second == first
    assert wait_for_gate_health(settings) is False
    assert (
        json.loads(settings.report_path.read_text(encoding="utf-8"))["report"]["ready"]
        is False
    )


@pytest.mark.asyncio
async def test_interrupted_attempt_fails_closed_without_repeating_side_effects(
    tmp_path: Path,
) -> None:
    settings = _settings(tmp_path)
    settings.release_root.mkdir(parents=True)
    settings.state_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "release_version": settings.release_version,
                "state": "pending",
                "started_at": "2026-07-26T00:00:00+00:00",
                "finished_at": None,
                "report_path": str(settings.report_path),
            }
        ),
        encoding="utf-8",
    )
    calls = 0

    async def unexpected_preflight(**_kwargs):
        nonlocal calls
        calls += 1
        raise AssertionError("must not repeat a claimed preflight")

    terminal = await execute_release_gate_once(
        settings,
        preflight_request=unexpected_preflight,
    )

    assert calls == 0
    assert terminal["state"] == "failed"
    assert terminal["error_type"] == "InterruptedPreviousAttempt"


@pytest.mark.asyncio
async def test_release_gate_rejects_terminal_projection_before_preflight(
    tmp_path: Path,
) -> None:
    settings = _settings(tmp_path)
    preflight_calls = 0

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        return _ready_payload(terminal=1)

    async def preflight_request(**_kwargs):
        nonlocal preflight_calls
        preflight_calls += 1
        return 200, _passed_preflight_report()

    terminal = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )

    assert preflight_calls == 0
    assert terminal["state"] == "failed"
    assert terminal["error_type"] == "RuntimeError"


@pytest.mark.asyncio
async def test_release_gate_waits_for_pending_projection_drain(tmp_path: Path) -> None:
    settings = _settings(tmp_path)
    ready_calls = 0
    drain_calls = 0

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        nonlocal ready_calls
        ready_calls += 1
        return _ready_payload(pending=1 if ready_calls == 1 else 0)

    async def drain_probe(_settings: ReleaseGateSettings) -> dict:
        nonlocal drain_calls
        drain_calls += 1
        return _ready_payload()

    async def preflight_request(**_kwargs):
        return 200, _passed_preflight_report()

    terminal = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        recovery_wait_probe=drain_probe,
        preflight_request=preflight_request,
    )

    assert terminal["state"] == "passed"
    assert ready_calls == 2
    assert drain_calls == 1


@pytest.mark.asyncio
async def test_release_gate_guarded_recovery_must_clear_projection_state(
    tmp_path: Path,
) -> None:
    settings = _settings(
        tmp_path,
        recovery_events=(
            GraphRecoveryEvent("default", "graph-event-1", "CommercialDocument"),
            GraphRecoveryEvent("default", "graph-event-2", "CommercialDocument"),
            GraphRecoveryEvent("default", "graph-event-3", "CommercialDocument"),
        ),
    )
    ready_calls = 0
    recovery_calls = 0
    clean_calls = 0

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        nonlocal ready_calls
        ready_calls += 1
        return _ready_payload(terminal=1 if ready_calls == 1 else 0)

    async def recovery_request(event: GraphRecoveryEvent) -> dict:
        nonlocal recovery_calls
        recovery_calls += 1
        status = {
            "graph-event-1": "pending",
            "graph-event-2": "retired",
            "graph-event-3": "delivered",
        }[event.event_id]
        return {
            "tenant_id": event.tenant_id,
            "event_id": event.event_id,
            "status": status,
        }

    async def recovery_wait_probe(_settings: ReleaseGateSettings) -> dict:
        nonlocal clean_calls
        clean_calls += 1
        return _ready_payload()

    async def preflight_request(**_kwargs):
        return 200, _passed_preflight_report()

    terminal = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        recovery_request=recovery_request,
        recovery_wait_probe=recovery_wait_probe,
        preflight_request=preflight_request,
    )

    assert terminal["state"] == "passed"
    assert terminal["graph_recoveries"] == [
        {"tenant_id": "default", "event_id": "graph-event-1", "status": "delivered"},
        {"tenant_id": "default", "event_id": "graph-event-2", "status": "retired"},
        {"tenant_id": "default", "event_id": "graph-event-3", "status": "delivered"},
    ]
    assert ready_calls == 2
    assert recovery_calls == 3
    assert clean_calls == 1


@pytest.mark.asyncio
async def test_release_gate_stops_batch_on_first_rejected_recovery(
    tmp_path: Path,
) -> None:
    settings = _settings(
        tmp_path,
        recovery_events=(
            GraphRecoveryEvent("default", "graph-event-1", "label"),
            GraphRecoveryEvent("default", "graph-event-2", "label"),
        ),
    )
    attempted: list[str] = []
    preflight_calls = 0

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        return _ready_payload(terminal=1)

    async def recovery_request(event: GraphRecoveryEvent) -> dict:
        attempted.append(event.event_id)
        return {
            "tenant_id": event.tenant_id,
            "event_id": event.event_id,
            "status": "rejected",
        }

    async def preflight_request(**_kwargs):
        nonlocal preflight_calls
        preflight_calls += 1
        return 200, _passed_preflight_report()

    terminal = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        recovery_request=recovery_request,
        preflight_request=preflight_request,
    )

    assert terminal["state"] == "failed"
    assert attempted == ["graph-event-1"]
    assert preflight_calls == 0


def test_release_gate_legacy_recovery_keeps_single_event_state_shape(
    tmp_path: Path,
) -> None:
    settings = _settings(
        tmp_path,
        recovery_events=(GraphRecoveryEvent("default", "legacy-event", "label"),),
        recovery_legacy=True,
    )
    from m1.release_gate import _safe_state

    state = _safe_state(settings, state="pending", started_at="2026-07-29T00:00:00+00:00")
    assert state["graph_recovery"] == {
        "tenant_id": "default",
        "event_id": "legacy-event",
        "status": "not_started",
    }
    assert "graph_recoveries" not in state


def test_release_gate_recovery_events_are_explicit_and_legacy_compatible() -> None:
    legacy = _recovery_events_from_environ(
        {
            "M1_RELEASE_GATE_GRAPH_RECOVERY_TENANT_ID": "default",
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENT_ID": "legacy-event",
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EXPECTED_ERROR_CONTAINS": "label",
        }
    )
    assert legacy == (GraphRecoveryEvent("default", "legacy-event", "label"),)
    batch = _recovery_events_from_environ(
        {
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": (
                '[{"tenant_id":"default","event_id":"event-a",'
                '"expected_error_contains":"label"},'
                '{"tenant_id":"default","event_id":"event-b",'
                '"expected_error_contains":"label"}]'
            )
        }
    )
    assert tuple(event.event_id for event in batch) == ("event-a", "event-b")


@pytest.mark.parametrize(
    "values",
    (
        {"M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": "not-json"},
        {"M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": "[]"},
        {"M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": "[{}]"},
        {
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": (
                '[{"tenant_id":"default","event_id":"a",'
                '"expected_error_contains":"label","extra":true}]'
            )
        },
        {
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": (
                '[{"tenant_id":"default","event_id":"a",'
                '"expected_error_contains":"label"},'
                '{"tenant_id":"default","event_id":"a",'
                '"expected_error_contains":"other"}]'
            )
        },
        {
            "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": (
                '['
                '{"tenant_id":"default","event_id":"1","expected_error_contains":"x"},'
                '{"tenant_id":"default","event_id":"2","expected_error_contains":"x"},'
                '{"tenant_id":"default","event_id":"3","expected_error_contains":"x"},'
                '{"tenant_id":"default","event_id":"4","expected_error_contains":"x"},'
                '{"tenant_id":"default","event_id":"5","expected_error_contains":"x"},'
                '{"tenant_id":"default","event_id":"6","expected_error_contains":"x"}'
                ']'
            )
        },
    ),
)
def test_release_gate_recovery_events_reject_malformed_input(values: dict[str, str]) -> None:
    with pytest.raises(ValueError):
        _recovery_events_from_environ(values)


def test_release_gate_recovery_events_reject_mixed_forms() -> None:
    with pytest.raises(ValueError, match="either"):
        _recovery_events_from_environ(
            {
                "M1_RELEASE_GATE_GRAPH_RECOVERY_TENANT_ID": "default",
                "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENT_ID": "legacy-event",
                "M1_RELEASE_GATE_GRAPH_RECOVERY_EXPECTED_ERROR_CONTAINS": "label",
                "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": "[]",
            }
        )


@pytest.mark.asyncio
async def test_release_gate_corrupted_pass_cannot_skip_preflight(
    tmp_path: Path,
) -> None:
    settings = _settings(tmp_path)

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        return _ready_payload()

    async def preflight_request(**_kwargs):
        return 200, _passed_preflight_report()

    passed = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )
    assert passed["state"] == "passed"
    settings.report_path.write_text('{"report":{"ready":true}}', encoding="utf-8")

    assert wait_for_gate_health(settings) is False
    rejected = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )
    assert rejected["state"] == "failed"
    assert rejected["error_type"] == "InvalidPreviousState"


@pytest.mark.asyncio
async def test_release_gate_cached_pass_binds_live_configuration(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    settings = _settings(tmp_path)

    async def ready_probe(_settings: ReleaseGateSettings) -> dict:
        return _ready_payload()

    async def preflight_request(**_kwargs):
        return 200, _passed_preflight_report()

    passed = await execute_release_gate_once(
        settings,
        ready_probe=ready_probe,
        preflight_request=preflight_request,
    )
    assert passed["state"] == "passed"

    def ready_response(fingerprint: str) -> httpx.Response:
        return httpx.Response(
            200,
            json={"configuration_fingerprint": fingerprint},
        )

    requests: list[tuple[str, dict]] = []

    def get_ready(url: str, **kwargs) -> httpx.Response:
        requests.append((url, kwargs))
        return ready_response("c" * 64)

    monkeypatch.setattr("m1.release_gate.httpx.get", get_ready)
    assert _live_enhancement_configuration_matches(settings) is True
    assert requests == [
        (
            "http://m1:8080/enhanced/ready",
            {"headers": {"X-API-Key": "api-secret"}, "timeout": 5.0},
        )
    ]

    monkeypatch.setattr(
        "m1.release_gate.httpx.get",
        lambda *_args, **_kwargs: ready_response("d" * 64),
    )
    assert _live_enhancement_configuration_matches(settings) is False


def test_release_gate_timeout_contract_is_fail_closed(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="healthcheck timeout"):
        _settings(
            tmp_path,
            ready_timeout_seconds=240,
            preflight_timeout_seconds=900,
            healthcheck_timeout_seconds=1140,
            controller_timeout_seconds=1200,
        ).validate()

    with pytest.raises(ValueError, match="YUNPAI_HEALTH_TIMEOUT_SECONDS"):
        _settings(
            tmp_path,
            ready_timeout_seconds=240,
            preflight_timeout_seconds=900,
            healthcheck_timeout_seconds=1150,
            controller_timeout_seconds=1179,
        ).validate()


def test_release_gate_settings_repr_never_contains_secrets(tmp_path: Path) -> None:
    rendered = repr(_settings(tmp_path))
    assert "api-secret" not in rendered
    assert "preflight-secret" not in rendered
    assert "db-secret" not in rendered


def test_module_runtime_declares_opt_in_release_gate_without_gpu() -> None:
    repository = Path(__file__).resolve().parents[2]
    runtime = yaml.safe_load(
        (repository / "m1/deploy/compose.runtime.yml").read_text(encoding="utf-8")
    )
    build = yaml.safe_load(
        (repository / "m1/deploy/compose.build.yml").read_text(encoding="utf-8")
    )
    dev = yaml.safe_load(
        (repository / "m1/deploy/compose.dev.yml").read_text(encoding="utf-8")
    )
    outer_healthcheck = (repository / "deploy/source-runtime/healthcheck.sh").read_text(
        encoding="utf-8"
    )
    gate = runtime["services"]["m1-release-gate"]
    environment = dict(value.split("=", 1) for value in gate["environment"])
    m1_environment = dict(
        value.split("=", 1) for value in runtime["services"]["m1"]["environment"]
    )

    assert gate["image"] == "${M1_IMAGE:?M1_IMAGE is required}"
    assert gate["profiles"] == ["release-gate"]
    assert m1_environment["PADDLEOCR_VL_TIMEOUT_SECONDS"] == (
        "${M1_PADDLEOCR_VL_TIMEOUT_SECONDS:-600}"
    )
    assert gate["labels"] == {
        "com.yunpai.release": "${YUNPAI_RELEASE_VERSION:-unknown}",
        "com.yunpai.role": "application",
        "com.yunpai.module": "m1",
    }
    assert gate["depends_on"]["m1"] == {
        "condition": "service_healthy",
        "required": True,
    }
    assert "deploy" not in gate
    assert environment["NVIDIA_VISIBLE_DEVICES"] == "void"
    assert environment["CUDA_VISIBLE_DEVICES"] == ""
    assert gate["restart"] == "unless-stopped"
    assert gate["healthcheck"]["retries"] == 1
    assert gate["healthcheck"]["test"][-1] == "check"
    assert environment["M1_ENHANCED_PREFLIGHT_KEY"] == (
        "${M1_ENHANCED_PREFLIGHT_API_KEY:-}"
    )
    assert environment["M1_RELEASE_GATE_IMAGE_REFERENCE"] == (
        "${M1_IMAGE:?M1_IMAGE is required}"
    )
    assert environment["M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON"] == (
        "${M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON:-}"
    )
    assert environment["KNOWLEDGE_DATABASE_URL"] == (
        "${M1_DATABASE_URL:?M1_DATABASE_URL is required}"
    )
    assert environment["YUNPAI_HEALTH_TIMEOUT_SECONDS"].startswith(
        "${YUNPAI_HEALTH_TIMEOUT_SECONDS:?"
    )
    assert any(
        volume.get("target") == "/app/src" and volume.get("read_only") is True
        for volume in gate["volumes"]
    )
    assert any(
        volume.get("target") == "/app/release.json" and volume.get("read_only") is True
        for volume in gate["volumes"]
    )
    assert any(
        volume.get("source") == "m1-data" and volume.get("target") == "/app/data"
        for volume in gate["volumes"]
    )
    assert "m1-release-gate" not in {
        image["service"] for image in build["x-yunpai-build"]["images"]
    }
    assert "m1-release-gate" not in build["services"]
    assert dev["services"]["m1-release-gate"]["profiles"] == ["release-gate"]
    assert dev["services"]["m1-release-gate"]["environment"] == {
        "M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON": (
            "${M1_RELEASE_GATE_GRAPH_RECOVERY_EVENTS_JSON:-}"
        ),
        "LOGFIRE_CONFIG_DIR": "/tmp/logfire-empty",
    }
    assert 'if [[ "$service" == "m1-release-gate" ]]; then' in outer_healthcheck
    assert "has_m1_release_gate=1" in outer_healthcheck
    assert "has_m1_release_gate == 0" in outer_healthcheck
