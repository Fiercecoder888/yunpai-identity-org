from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]


def _tracked_files() -> set[str]:
    if not (REPOSITORY_ROOT / ".git").exists():
        manifest_value = os.environ.get("M1_TRACKED_FILES_MANIFEST")
        if not manifest_value:
            pytest.skip("repository metadata is unavailable in the packaged test environment")
        manifest = Path(manifest_value)
        if not manifest.is_file():
            pytest.fail(f"tracked-files manifest does not exist: {manifest}")
        return {
            value.decode("utf-8").replace("\\", "/")
            for value in manifest.read_bytes().split(b"\0")
            if value
        }
    result = subprocess.run(
        ["git", "ls-files", "-z"],
        cwd=REPOSITORY_ROOT,
        check=True,
        capture_output=True,
    )
    return {
        value.decode("utf-8").replace("\\", "/")
        for value in result.stdout.split(b"\0")
        if value
    }


def test_runtime_data_and_secret_env_files_are_not_tracked() -> None:
    tracked = _tracked_files()
    forbidden = {
        path
        for path in tracked
        if path.startswith("m1/data/")
        or path == "m1/.env"
        or path.endswith("/.env")
        or path.endswith("/.coverage")
    }

    assert forbidden == set(), (
        "runtime or secret-bearing files must remain outside version control: "
        f"{sorted(forbidden)}"
    )
