from __future__ import annotations

from types import SimpleNamespace

from fastapi import FastAPI
from fastapi.testclient import TestClient
from m1.api.review_routes import register_review_routes
from m1.state import TaskState, TaskStatus


class _ReviewEngine:
    async def prepare_review(self, **kwargs) -> TaskState:
        assert kwargs["task_id"] == "large-review"
        return TaskState(
            task_id="large-review",
            status=TaskStatus.SCORING,
            processing_stage="review_indexing",
            review_target_status=TaskStatus.DONE.value,
        )

    async def finalize_review(self, task_id: str) -> TaskState:
        return TaskState(
            task_id=task_id,
            status=TaskStatus.DONE,
            processing_stage="completed",
        )


def test_review_returns_durable_accepted_poll_contract() -> None:
    app = FastAPI()
    register_review_routes(
        app,
        SimpleNamespace(engine=_ReviewEngine(), store=None),
    )

    with TestClient(app) as client:
        response = client.post(
            "/review/large-review",
            json={"reviewer": "tester", "approve": True},
        )

    assert response.status_code == 202
    assert response.headers["retry-after"] == "2"
    assert response.json() == {
        "code": "M1_REVIEW_ACCEPTED",
        "message": (
            "Review corrections were saved; indexing continues asynchronously."
        ),
        "task_id": "large-review",
        "status": "scoring",
        "processing_stage": "review_indexing",
        "poll_url": "/tasks/large-review",
    }
