from __future__ import annotations

from m1.review_policy import assess_document_review


def _safe_order() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "order.csv"},
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "header": {"order_number": "PO-100"},
        "lines": [
            {
                "line_id": "1",
                "model": "M-1",
                "quantity": 2,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 2},
        "field_meta": {},
        "validation_issues": [],
        # A historical compatibility projection could have set this even when
        # no source evidence required review. The policy must rebuild it.
        "needs_review": True,
    }


def test_legacy_aggregate_flag_does_not_block_safe_document() -> None:
    result = assess_document_review(_safe_order())

    assert result.requires_review is False
    assert result.blockers == []


def test_unresolved_warning_blocks_auto_activation() -> None:
    document = _safe_order()
    document["validation_issues"] = [
        {
            "code": "TOTAL_QUANTITY_MISMATCH",
            "severity": "warning",
            "message": "数量不一致",
            "paths": ["$.totals.quantity_matches"],
        }
    ]

    result = assess_document_review(document)

    assert result.requires_review is True
    assert result.reason_codes == ["TOTAL_QUANTITY_MISMATCH"]


def test_unapplied_suggestion_is_ignored_but_applied_inference_is_reviewed() -> None:
    document = _safe_order()
    document["lines"][0]["name_normalized"] = "DP线"
    document["field_meta"] = {
        "$.lines[0].name_attributes": {
            "confidence": 0.99,
            "inferred": True,
            "accepted": False,
            "candidate": {"interface": "DisplayPort"},
        },
        "$.lines[0].name_normalized": {
            "confidence": 0.96,
            "inferred": True,
            "source_refs": [{"part": "vlm:test"}],
        },
    }

    result = assess_document_review(document)

    assert result.reason_codes == ["INFERRED_FIELD"]
    assert result.blockers[0].path == "$.lines[0].name_normalized"


def test_deterministic_rule_inference_preserves_audit_without_blocking() -> None:
    document = _safe_order()
    document["lines"][0]["name_normalized"] = "M-1 DP线"
    document["field_meta"] = {
        "$.lines[0].name_normalized": {
            "confidence": 1.0,
            "inferred": True,
            "review_required": False,
            "source_refs": [{"sheet": "设备", "cell": "B2"}],
        },
    }

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []


def test_unmarked_date_and_evidenceless_inferences_remain_blocked() -> None:
    document = _safe_order()
    document["header"].update(
        {"date_standard": "2026-07-15", "supplier": "待确认供应商"}
    )
    document["field_meta"] = {
        "$.header.date_standard": {
            "confidence": 0.98,
            "inferred": True,
            "source_refs": [{"sheet": "订单", "cell": "B2"}],
        },
        "$.header.supplier": {
            "confidence": 1.0,
            "inferred": True,
            "source_refs": [],
        },
    }

    result = assess_document_review(document)

    assert result.reason_codes == ["INFERRED_FIELD"]
    assert {blocker.path for blocker in result.blockers} == {
        "$.header.date_standard",
        "$.header.supplier",
    }


def test_low_confidence_rule_inference_still_blocks() -> None:
    document = _safe_order()
    document["lines"][0]["name_normalized"] = "M-1 DP线"
    document["field_meta"] = {
        "$.lines[0].name_normalized": {
            "confidence": 0.72,
            "inferred": True,
            "review_required": False,
            "source_refs": [{"sheet": "设备", "cell": "B2"}],
        },
    }

    result = assess_document_review(document)

    assert result.reason_codes == ["LOW_CONFIDENCE_FIELD"]


def _add_clean_full_semantic_authority(document: dict) -> None:
    extraction = document.setdefault("extraction", {})
    metadata = extraction.setdefault("metadata", {})
    metadata.update(
        {
            "authority_mode": "full",
            "authority_selected": True,
            "evidence_complete": True,
            "accounted_complete": True,
            "retained_complete": True,
            "evidence_unresolved_count": 0,
        }
    )
    raw_content = extraction.setdefault("raw_content", {})
    raw_content["semantic_completeness_audit"] = {
        "schema_version": "m1.semantic-completion.v1",
        "counts": {
            "evidence_total": 3,
            "evidence_accounted": 3,
            "source_evidence_ambiguous": 0,
            "source_evidence_needs_review": 0,
        },
        "review_required": False,
    }


def test_clean_semantic_audit_accepts_grounded_technical_inferences() -> None:
    document = _technical_document({"text_original": "Part length 12.27±0.2"})
    document["document_subtype"] = "product_specification"
    document["header"] = {"company": "Example Technology Co., Ltd."}
    document["key_dimensions"] = [{"name": "尺寸", "value": "12.27±0.2"}]
    source_ref = {
        "page": 1,
        "part": "mineru/p1:b9",
        "evidence_quote": "Part length 12.27±0.2",
    }
    document["field_meta"] = {
        "$.header.company": {
            "confidence": 1.0,
            "inferred": True,
            "source_refs": [{"page": 1, "part": "mineru/p1:b1"}],
        },
        "$.document_type": {
            "confidence": 1.0,
            "inferred": True,
            "model_mapped": True,
            "source_refs": [source_ref],
        },
        "$.key_dimensions[0].name": {
            "confidence": 0.85,
            "source_refs": [source_ref],
        },
        "$.key_dimensions[0].value": {
            "confidence": 0.85,
            "source_refs": [source_ref],
        },
    }
    _add_clean_full_semantic_authority(document)

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []


def test_clean_semantic_audit_does_not_hide_warning_or_unreplayable_value() -> None:
    document = _technical_document({"text_original": "Part length unreadable"})
    document["document_subtype"] = "product_specification"
    document["key_dimensions"] = [{"name": "尺寸", "value": "12.27±0.2"}]
    document["field_meta"] = {
        "$.key_dimensions[0].value": {
            "confidence": 0.85,
            "source_refs": [
                {
                    "page": 1,
                    "part": "mineru/p1:b9",
                    "evidence_quote": "Part length unreadable",
                }
            ],
        }
    }
    document["validation_issues"] = [
        {
            "code": "DIMENSION_CONFLICT",
            "severity": "warning",
            "message": "Conflicting dimension evidence",
        }
    ]
    _add_clean_full_semantic_authority(document)

    result = assess_document_review(document)

    assert set(result.reason_codes) == {
        "DIMENSION_CONFLICT",
        "LOW_CONFIDENCE_FIELD",
    }


def test_semantic_audit_relaxation_does_not_apply_to_order_fields() -> None:
    document = _safe_order()
    document["header"]["supplier"] = "Example Supplier"
    document["field_meta"] = {
        "$.header.supplier": {
            "confidence": 1.0,
            "inferred": True,
            "source_refs": [{"sheet": "Order", "cell": "B2"}],
        }
    }
    _add_clean_full_semantic_authority(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["INFERRED_FIELD"]


def test_low_confidence_and_invalid_required_order_values_are_blocked() -> None:
    document = _safe_order()
    document["lines"][0]["model"] = ""
    document["lines"][0]["quantity"] = 0
    document["lines"][0]["name_raw"] = "cable"
    document["field_meta"] = {
        "$.lines[0].name_raw": {"confidence": 0.72, "inferred": False}
    }

    result = assess_document_review(document)

    assert set(result.reason_codes) == {
        "LOW_CONFIDENCE_FIELD",
        "LINE_QUANTITY_INVALID",
    }


def test_order_without_order_or_contract_number_fails_closed() -> None:
    document = _safe_order()
    document["header"].pop("order_number")

    result = assess_document_review(document)

    assert result.reason_codes == ["ORDER_NUMBER_MISSING"]
    assert result.blockers[0].path == "$.header.order_number"


def _technical_document(raw_content: dict) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "technical.pdf"},
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {"candidate_numbers": [], "date_inferred": False},
        "lines": [],
        "bom": [],
        "field_meta": {},
        "validation_issues": [],
        "extraction": {"raw_content": raw_content, "sections": []},
        "fields": [
            {"name": "lines.item_count", "value": 0},
            {
                "name": "validation.issue.0.PARSER_WARNING",
                "value": "Parser could not structure the page",
            },
        ],
        "scored_result": {
            "fields": [
                {"name": "lines.item_count", "value": 0},
                {
                    "name": "validation.issue.0.PARSER_WARNING",
                    "value": "Parser could not structure the page",
                },
            ],
            "bom": [],
            "key_dimensions": [],
        },
    }


def _ground_existing_approval_metadata(document: dict) -> None:
    field_meta = document.setdefault("field_meta", {})
    for root, container in (
        ("$.header", document.get("header")),
        ("$.title_block", document.get("title_block")),
    ):
        if not isinstance(container, dict):
            continue
        for field in (
            "checked_by",
            "check_by",
            "checker",
            "approved_by",
            "approve_by",
            "approver",
            "version",
            "revision",
            "revision_code",
            "revision_number",
            "rev",
        ):
            if container.get(field) not in (None, ""):
                field_meta[f"{root}.{field}"] = {
                    "confidence": 0.99,
                    "source_refs": [{"page": 1, "part": f"title-block/{field}"}],
                }


def _add_verified_visual(document: dict) -> None:
    extraction = document.setdefault("extraction", {})
    raw_content = extraction.setdefault("raw_content", {})
    raw_content["images"] = [{"image_id": "page-1:image-1"}]
    extraction["visual_facts"] = [
        {
            "fact_type": "approval_drawing",
            "image_refs": ["page-1:image-1"],
            "source_refs": [{"page": 1, "part": "image:1"}],
        }
    ]


def test_nonempty_technical_source_without_typed_content_requires_review() -> None:
    document = _technical_document(
        {
            "text_original": "APPROVAL DRAWING\nProduct size: 20 mm",
            "images": [{"image_id": "page-1:image-1"}],
        }
    )

    result = assess_document_review(document)

    assert result.requires_review is True
    assert set(result.reason_codes) == {
        "TECHNICAL_STRUCTURE_MISSING",
        "TECHNICAL_VISUAL_FACTS_UNVERIFIED",
        "APPROVAL_METADATA_MISSING",
    }
    assert result.blockers[0].path == "$.extraction"


def test_approval_drawing_with_unlinked_image_and_no_approval_metadata_is_reviewed() -> (
    None
):
    document = _technical_document(
        {"pages": [{"images": [{"image_id": "page-1:image-1"}]}]}
    )
    document["header"] = {"title": "USB Type-C cable"}
    document["field_meta"] = {
        "$.header.title": {
            "confidence": 0.99,
            "source_refs": [{"page": 1, "part": "title-block"}],
        }
    }

    result = assess_document_review(document)

    assert result.requires_review is True
    assert set(result.reason_codes) == {
        "TECHNICAL_VISUAL_FACTS_UNVERIFIED",
        "APPROVAL_METADATA_MISSING",
    }


def test_approval_drawing_with_empty_raw_content_fails_closed() -> None:
    document = _technical_document({})
    document["header"] = {"title": "Part", "drawing_number": "DWG-100"}
    document["lines"] = [{"line_id": "1", "name_raw": "Part"}]

    result = assess_document_review(document)

    assert set(result.reason_codes) == {
        "TECHNICAL_VISUAL_FACTS_UNVERIFIED",
        "APPROVAL_METADATA_MISSING",
    }
    visual = next(
        blocker
        for blocker in result.blockers
        if blocker.code == "TECHNICAL_VISUAL_FACTS_UNVERIFIED"
    )
    assert visual.detail.startswith("No retained visual asset")


def test_approval_metadata_without_replayable_field_sources_fails_closed() -> None:
    document = _technical_document({})
    document["header"] = {"title": "Part", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    document["lines"] = [{"line_id": "1", "name_raw": "Part"}]
    _add_verified_visual(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["APPROVAL_METADATA_MISSING"]
    assert all(
        item in result.blockers[0].detail
        for item in ("checker", "approver", "version_or_revision")
    )


def test_image_association_alone_does_not_count_as_verified_visual_fact() -> None:
    document = _technical_document(
        {"pages": [{"images": [{"image_id": "page-1:image-1"}]}]}
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["lines"] = [
        {
            "line_id": "1",
            "name_raw": "USB Type-C cable",
            "image_refs": ["page-1:image-1"],
        }
    ]
    document["field_meta"].update(
        {
            "$.header.title": {
                "confidence": 0.99,
                "source_refs": [{"page": 1, "part": "title-block"}],
            }
        }
    )

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]


def test_verified_visual_fact_and_approval_metadata_may_activate() -> None:
    document = _technical_document(
        {"pages": [{"images": [{"image_id": "page-1:image-1"}]}]}
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["lines"] = [
        {
            "line_id": "1",
            "name_raw": "USB Type-C cable",
            "image_refs": ["page-1:image-1"],
        }
    ]
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "product_view",
            "image_refs": ["page-1:image-1"],
            "source_refs": [{"page": 1, "part": "image:1"}],
        }
    ]
    document["field_meta"].update(
        {
            "$.header.title": {
                "confidence": 0.99,
                "source_refs": [{"page": 1, "part": "title-block"}],
            }
        }
    )

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []


def test_partial_visual_fact_coverage_fails_closed() -> None:
    document = _technical_document(
        {
            "images": [
                {
                    "asset_path": "assets/product.png",
                    "target_part": "word/media/image1.png",
                },
                {
                    "asset_path": "assets/drawing.png",
                    "target_part": "word/media/image2.png",
                },
            ]
        }
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["lines"] = [{"line_id": "1", "name_raw": "USB Type-C cable"}]
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "product_view",
            "image_refs": ["assets/product.png"],
            "source_refs": [{"part": "word/media/image1.png"}],
        }
    ]

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]
    assert result.blockers[0].detail.startswith("1 of 2 retained image")


def test_visual_fact_without_locatable_source_does_not_cover_image() -> None:
    document = _technical_document({"images": [{"asset_path": "assets/product.png"}]})
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "revision": "B",
    }
    _ground_existing_approval_metadata(document)
    document["lines"] = [{"line_id": "1", "name_raw": "USB Type-C cable"}]
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "product_view",
            "image_refs": ["assets/product.png"],
            "source_refs": [],
        }
    ]

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]


def test_pdf_render_asset_requires_its_own_replayable_visual_fact() -> None:
    document = _technical_document(
        {"pages": [{"page_number": 1, "render_asset": "assets/page-0001.png"}]}
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]
    assert result.blockers[0].detail.startswith("1 of 1 retained image")


def test_pdf_render_asset_is_covered_by_same_page_source() -> None:
    document = _technical_document(
        {"pages": [{"page_number": 1, "render_asset": "assets/page-0001.png"}]}
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "page_drawing",
            "image_refs": ["assets/page-0001.png"],
            "source_refs": [{"page": 1, "part": "page-render"}],
        }
    ]

    result = assess_document_review(document)

    assert result.requires_review is False


def test_one_source_ref_cannot_cover_multiple_visual_assets() -> None:
    document = _technical_document(
        {
            "images": [
                {
                    "asset_path": "assets/product.png",
                    "target_part": "word/media/image1.png",
                },
                {
                    "asset_path": "assets/drawing.png",
                    "target_part": "word/media/image2.png",
                },
            ]
        }
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "product_views",
            "image_refs": ["assets/product.png", "assets/drawing.png"],
            "source_refs": [{"part": "word/media/image1.png"}],
        }
    ]

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]
    assert result.blockers[0].detail.startswith("1 of 2 retained image")


def test_unicode_image_names_with_same_extension_remain_distinct_assets() -> None:
    document = _technical_document(
        {
            "images": [
                {
                    "asset_path": "assets/正视图.png",
                    "target_part": "word/media/image1.png",
                },
                {
                    "asset_path": "assets/侧视图.png",
                    "target_part": "word/media/image2.png",
                },
            ]
        }
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "front_view",
            "image_refs": ["assets/正视图.png"],
            "source_refs": [{"part": "word/media/image1.png"}],
        }
    ]

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]
    assert result.blockers[0].detail.startswith("1 of 2 retained image")


def test_ascii_image_paths_differing_only_by_punctuation_remain_distinct() -> None:
    document = _technical_document(
        {
            "images": [
                {
                    "asset_path": "assets/front-view.png",
                    "target_part": "word/media/image1.png",
                },
                {
                    "asset_path": "assets/frontview.png",
                    "target_part": "word/media/image2.png",
                },
            ]
        }
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "front_view",
            "image_refs": ["assets/front-view.png"],
            "source_refs": [{"part": "word/media/image1.png"}],
        }
    ]

    result = assess_document_review(document)

    assert result.reason_codes == ["TECHNICAL_VISUAL_FACTS_UNVERIFIED"]
    assert result.blockers[0].detail.startswith("1 of 2 retained image")


def test_each_visual_asset_with_its_own_source_may_activate() -> None:
    document = _technical_document(
        {
            "images": [
                {
                    "asset_path": "assets/product.png",
                    "target_part": "word/media/image1.png",
                },
                {
                    "asset_path": "assets/drawing.png",
                    "target_part": "word/media/image2.png",
                },
            ]
        }
    )
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _ground_existing_approval_metadata(document)
    document["extraction"]["visual_facts"] = [
        {
            "fact_type": "product_views",
            "image_refs": ["assets/product.png", "assets/drawing.png"],
            "source_refs": [
                {"part": "word/media/image1.png"},
                {"part": "word/media/image2.png"},
            ],
        }
    ]

    result = assess_document_review(document)

    assert result.requires_review is False


def test_revision_without_checker_or_approver_does_not_satisfy_approval_gate() -> None:
    document = _technical_document({"text_original": "APPROVAL DRAWING"})
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {"version": "A"}
    _add_verified_visual(document)
    _ground_existing_approval_metadata(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["APPROVAL_METADATA_MISSING"]


def test_approval_role_label_and_date_composite_is_not_a_person() -> None:
    document = _technical_document({"text_original": "APPROVAL DRAWING"})
    document["header"] = {"title": "USB Type-C cable", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "GSH",
        "approve_by": "\u7ed8\u56fe \u65e5\u671f GSH 2019.05.07",
        "version": "A",
    }
    _add_verified_visual(document)
    _ground_existing_approval_metadata(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["APPROVAL_METADATA_MISSING"]
    assert "approver" in result.blockers[0].detail


def test_approval_people_require_dedicated_source_refs_when_available() -> None:
    document = _technical_document({"text_original": "APPROVAL DRAWING"})
    document["header"] = {
        "title": "USB Type-C cable",
        "drawing_number": "DWG-100",
        "checked_by": "Alice Chen",
        "approved_by": "Bob Li",
    }
    document["title_block"] = {"version": "A"}
    _add_verified_visual(document)
    document["field_meta"] = {
        "$.header.checked_by": {
            "source_refs": [{"page": 1, "part": "title-block/checker"}],
            "confidence": 0.99,
        },
        "$.title_block.version": {
            "source_refs": [{"page": 1, "part": "title-block/version"}],
            "confidence": 0.99,
        },
    }

    result = assess_document_review(document)

    assert result.reason_codes == ["APPROVAL_METADATA_MISSING"]
    assert "approver" in result.blockers[0].detail


def test_each_required_approval_metadata_component_fails_closed() -> None:
    complete = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    expected_detail = {
        "check_by": "checker",
        "approve_by": "approver",
        "version": "version_or_revision",
    }

    for missing_field, missing_name in expected_detail.items():
        document = _technical_document({"text_original": "APPROVAL DRAWING"})
        document["header"] = {
            "title": "USB Type-C cable",
            "drawing_number": "DWG-100",
        }
        document["title_block"] = {
            key: value for key, value in complete.items() if key != missing_field
        }
        _add_verified_visual(document)
        _ground_existing_approval_metadata(document)

        result = assess_document_review(document)

        assert result.reason_codes == ["APPROVAL_METADATA_MISSING"]
        assert missing_name in result.blockers[0].detail


def test_filename_and_drawing_identifier_conflict_requires_review() -> None:
    document = _technical_document({"text_original": "APPROVAL DRAWING"})
    document["source"]["original_filename"] = "DBA103-15方壳.docx"
    document["header"] = {"title": "方壳", "drawing_number": "HDTV"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _add_verified_visual(document)
    _ground_existing_approval_metadata(document)

    result = assess_document_review(document)

    assert result.reason_codes == ["DRAWING_IDENTIFIER_CONFLICT"]


def test_engineering_drawing_filename_and_body_identifier_conflict_requires_review() -> (
    None
):
    document = _technical_document({"text_original": "ENGINEERING DRAWING"})
    document["document_subtype"] = "engineering_drawing"
    document["source"]["original_filename"] = "product-50392.docx"
    document["header"] = {"title": "HDMI shell", "drawing_number": "50391"}

    result = assess_document_review(document)

    assert result.reason_codes == ["DRAWING_IDENTIFIER_CONFLICT"]


def test_calendar_only_filename_does_not_conflict_with_drawing_identifier() -> None:
    document = _technical_document({"text_original": "APPROVAL DRAWING"})
    document["source"]["original_filename"] = "20260722-approval-drawing.docx"
    document["header"] = {"title": "方壳", "drawing_number": "DWG-100"}
    document["title_block"] = {
        "check_by": "Alice Chen",
        "approve_by": "Bob Li",
        "version": "A",
    }
    _add_verified_visual(document)
    _ground_existing_approval_metadata(document)

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []


def test_structured_technical_dimensions_count_without_template_rules() -> None:
    document = _technical_document({"tables": [{"rows": [["length", "20 mm"]]}]})
    document["document_subtype"] = "product_specification"
    document["key_dimensions"] = [{"name": "length", "value": "20 mm"}]

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []


def test_empty_approval_drawing_source_fails_closed() -> None:
    document = _technical_document({"text_original": "", "pages": []})

    result = assess_document_review(document)

    assert set(result.reason_codes) == {
        "TECHNICAL_VISUAL_FACTS_UNVERIFIED",
        "APPROVAL_METADATA_MISSING",
    }


def test_raw_nontechnical_document_is_unaffected() -> None:
    document = _technical_document({"text_original": "unstructured content"})
    document["document_type"] = "inventory"

    result = assess_document_review(document)

    assert result.requires_review is False
    assert result.blockers == []
