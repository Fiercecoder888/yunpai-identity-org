from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from m1.documents.parsing.adaptive_routing import (
    DocumentRouteSignature,
    RouteTableShape,
)
from m1.knowledge import (
    IdempotencyConflictError,
    KnowledgeStore,
    RouteObservationOutcome,
    RouteObservationRecord,
    RouteProfileRecord,
    RouteProfileStatus,
    TenantBoundaryError,
    TenantRecord,
)


def _signature(*, label: str = "order_number") -> DocumentRouteSignature:
    return DocumentRouteSignature(
        format_family="spreadsheet",
        page_count_bucket="none",
        block_kinds=("table",),
        label_tokens=(label, "quantity"),
        layout_tokens=("header_then_rows",),
        table_shapes=(
            RouteTableShape(
                table_index=0,
                row_count_bucket="many",
                column_count=6,
                header_row_count=1,
                orientation="records_by_row",
            ),
        ),
    )


def _profile(
    tenant_id: str,
    *,
    profile_id: str,
    profile_key: str = "orders-vendor-a",
    version: int = 1,
    supersedes_profile_id: str | None = None,
    label: str = "order_number",
    embedding: list[float] | None = None,
    embedding_model: str = "test-embedding",
    embedding_dimensions: int | None = None,
) -> RouteProfileRecord:
    signature = _signature(label=label)
    return RouteProfileRecord(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=profile_key,
        version=version,
        supersedes_profile_id=supersedes_profile_id,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        embedding=embedding,
        embedding_model=embedding_model if embedding is not None else "",
        embedding_dimensions=(
            (1024 if embedding_dimensions is None else embedding_dimensions)
            if embedding is not None
            else 0
        ),
        policy={"parser": "generic", "field_map": {"A": "order_number"}},
        created_by="route-proposer",
    )


async def _record_activation_samples(
    store: KnowledgeStore,
    profile: RouteProfileRecord,
    *,
    task_refs: tuple[str, ...] | None = None,
    start_index: int = 1,
) -> None:
    refs = task_refs or tuple(f"{index:064x}" for index in range(1, 4))
    for index, task_ref in enumerate(refs, start=start_index):
        await store.record_route_observation(
            RouteObservationRecord(
                observation_id=f"review-{profile.profile_id}-{index}",
                tenant_id=profile.tenant_id,
                profile_id=profile.profile_id,
                idempotency_key=(
                    f"route-policy-validation:{task_ref}:{profile.profile_id}:{index}"
                ),
                exact_fingerprint=profile.exact_fingerprint,
                outcome=RouteObservationOutcome.SUCCESS,
                details={
                    "kind": "candidate_policy_validation",
                    "task_ref": task_ref,
                    "decision": "approve",
                    "reviewed_by": "route-reviewer",
                    "review_note_sha256": "a" * 64,
                },
            )
        )


async def _activate_profile(
    store: KnowledgeStore,
    profile: RouteProfileRecord,
    *,
    approved_by: str = "approver",
    reviewed_by: str = "route-reviewer",
    review_note: str = "three distinct route validations passed",
) -> RouteProfileRecord:
    await _record_activation_samples(store, profile)
    refreshed = await store.get_route_profile(profile.tenant_id, profile.profile_id)
    assert refreshed is not None
    return await store.activate_route_profile(
        profile.tenant_id,
        profile.profile_id,
        approved_by=approved_by,
        reviewed_by=reviewed_by,
        review_note=review_note,
        expected_observation_count=refreshed.observation_count,
    )


@pytest.fixture
async def routes(tmp_path: Path):
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'routes.db'}")
    await store.init()
    tenant = await store.create_tenant(
        TenantRecord(tenant_key="route-a", display_name="Route tenant A")
    )
    second = await store.create_tenant(
        TenantRecord(tenant_key="route-b", display_name="Route tenant B")
    )
    try:
        yield store, tenant, second
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_route_profile_create_is_idempotent_and_tenant_scoped(routes) -> None:
    store, tenant, second = routes
    record = _profile(tenant.tenant_id, profile_id="route-1")

    created = await store.create_route_profile(record)
    replay = await store.create_route_profile(record.model_copy(update={"profile_id": "retry"}))

    assert replay.profile_id == created.profile_id == "route-1"
    assert created.as_candidate().route_id == "route-1"
    assert await store.get_route_profile(second.tenant_id, "route-1") is None
    assert [item.profile_id for item in await store.list_route_profiles(tenant.tenant_id)] == [
        "route-1"
    ]

    changed = record.model_copy(update={"policy": {"parser": "different"}})
    with pytest.raises(IdempotencyConflictError):
        await store.create_route_profile(changed)


@pytest.mark.asyncio
async def test_activation_deprecates_previous_version_and_records_approval(routes) -> None:
    store, tenant, _second = routes
    first = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id="route-v1")
    )
    await _activate_profile(
        store,
        first,
        approved_by="reviewer-a",
        reviewed_by="reviewer-a",
        review_note="initial route validation passed",
    )
    await store.deprecate_route_profile(
        tenant.tenant_id,
        first.profile_id,
        reviewed_by="reviewer-a",
        review_note="replaced by validated revision",
    )
    second = await store.create_route_profile(
        _profile(
            tenant.tenant_id,
            profile_id="route-v2",
            version=2,
            supersedes_profile_id=first.profile_id,
        )
    )

    active = await _activate_profile(
        store,
        second,
        approved_by="reviewer-b",
        reviewed_by="reviewer-b",
        review_note="benchmark passed",
    )

    previous = await store.get_route_profile(tenant.tenant_id, first.profile_id)
    assert previous is not None and previous.status is RouteProfileStatus.DEPRECATED
    assert active.status is RouteProfileStatus.ACTIVE
    assert active.approved_by == "reviewer-b"
    assert active.approved_at is not None
    assert active.review_note == "benchmark passed"
    assert (
        await store.get_active_route_profile_by_fingerprint(
            tenant.tenant_id, active.exact_fingerprint
        )
    ).profile_id == active.profile_id


@pytest.mark.asyncio
async def test_activation_requires_manual_review_and_three_distinct_tasks(routes) -> None:
    store, tenant, _second = routes
    profile = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id="route-governed-activation")
    )

    with pytest.raises(ValueError, match="at least three distinct"):
        await store.activate_route_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="insufficient validation samples",
        )

    await _record_activation_samples(
        store,
        profile,
        task_refs=(f"{1:064x}", f"{2:064x}"),
    )
    with pytest.raises(ValueError, match="at least three distinct"):
        await store.activate_route_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="only two distinct samples",
        )

    await _record_activation_samples(
        store,
        profile,
        task_refs=(f"{3:064x}",),
        start_index=3,
    )
    with pytest.raises(ValueError, match="reviewed_by is required"):
        await store.activate_route_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            review_note="manual review identity missing",
        )
    with pytest.raises(ValueError, match="review_note is required"):
        await store.activate_route_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
        )

    active = await store.activate_route_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="three distinct samples reviewed",
        expected_observation_count=3,
    )
    assert active.status is RouteProfileStatus.ACTIVE


@pytest.mark.asyncio
async def test_candidate_revision_is_consecutive_idempotent_and_queryable(routes) -> None:
    store, tenant, _second = routes
    first = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id="route-generic-v1")
    )
    revision = _profile(
        tenant.tenant_id,
        profile_id="route-specialized-v2",
        version=2,
        supersedes_profile_id=first.profile_id,
    ).model_copy(update={"policy": {"parser": "order", "strict": True}})

    created, replay = await asyncio.gather(
        store.create_route_profile(revision),
        store.create_route_profile(
            revision.model_copy(update={"profile_id": "route-specialized-retry"})
        ),
    )

    previous = await store.get_route_profile(tenant.tenant_id, first.profile_id)
    latest = await store.get_latest_route_profile_by_fingerprint(
        tenant.tenant_id, first.exact_fingerprint
    )
    assert previous is not None
    assert previous.status is RouteProfileStatus.DEPRECATED
    assert replay.profile_id == created.profile_id
    assert created.profile_id in {"route-specialized-v2", "route-specialized-retry"}
    assert latest is not None and latest.profile_id == created.profile_id
    assert latest.version == 2
    assert latest.supersedes_profile_id == first.profile_id


@pytest.mark.asyncio
async def test_route_revision_rejects_cross_tenant_gap_and_active_parent(routes) -> None:
    store, tenant, second = routes
    first = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id="route-parent")
    )

    cross_tenant = _profile(
        second.tenant_id,
        profile_id="route-cross-tenant-v2",
        version=2,
        supersedes_profile_id=first.profile_id,
    )
    with pytest.raises(TenantBoundaryError):
        await store.create_route_profile(cross_tenant)

    gap = _profile(
        tenant.tenant_id,
        profile_id="route-gap-v3",
        version=3,
        supersedes_profile_id=first.profile_id,
    )
    with pytest.raises(ValueError, match="consecutive"):
        await store.create_route_profile(gap)

    await _activate_profile(
        store,
        first,
        approved_by="reviewer",
        reviewed_by="reviewer",
        review_note="parent route validation passed",
    )
    revision = _profile(
        tenant.tenant_id,
        profile_id="route-active-parent-v2",
        version=2,
        supersedes_profile_id=first.profile_id,
    )
    with pytest.raises(ValueError, match="must be deprecated"):
        await store.create_route_profile(revision)


@pytest.mark.asyncio
@pytest.mark.parametrize("terminal_action", ["reject", "deprecate"])
async def test_terminal_profile_can_start_specialized_revision(
    routes, terminal_action: str
) -> None:
    store, tenant, _second = routes
    first = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id=f"route-{terminal_action}-v1")
    )
    if terminal_action == "reject":
        await store.reject_route_profile(
            tenant.tenant_id,
            first.profile_id,
            reviewed_by="reviewer",
            review_note="generic route rejected",
        )
    else:
        await store.deprecate_route_profile(
            tenant.tenant_id,
            first.profile_id,
            reviewed_by="reviewer",
            review_note="generic route replaced",
        )

    revision = await store.create_route_profile(
        _profile(
            tenant.tenant_id,
            profile_id=f"route-{terminal_action}-v2",
            version=2,
            supersedes_profile_id=first.profile_id,
        ).model_copy(update={"policy": {"parser": "specialized"}})
    )

    assert revision.version == 2
    assert revision.supersedes_profile_id == first.profile_id


def test_route_profile_record_requires_explicit_revision_predecessor() -> None:
    signature = _signature()
    base = {
        "profile_id": "route-v2",
        "tenant_id": "tenant-a",
        "profile_key": "orders",
        "version": 2,
        "exact_fingerprint": signature.exact_fingerprint(),
        "signature": signature,
        "created_by": "test",
    }
    with pytest.raises(ValueError, match="require a superseded profile"):
        RouteProfileRecord(**base)
    with pytest.raises(ValueError, match="first route profile"):
        RouteProfileRecord(
            **{
                **base,
                "version": 1,
                "supersedes_profile_id": "route-v0",
            }
        )


@pytest.mark.asyncio
async def test_observations_are_idempotent_and_update_statistics(routes) -> None:
    store, tenant, second = routes
    profile = await store.create_route_profile(
        _profile(tenant.tenant_id, profile_id="route-observed")
    )
    observation = RouteObservationRecord(
        observation_id="observation-1",
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        idempotency_key="document-1:route-observed",
        exact_fingerprint=profile.exact_fingerprint,
        outcome=RouteObservationOutcome.SUCCESS,
        latency_ms=37,
        details={"parser": "xlsx"},
    )

    first = await store.record_route_observation(observation)
    replay = await store.record_route_observation(
        observation.model_copy(update={"observation_id": "retry-observation"})
    )
    assert replay.observation_id == first.observation_id == "observation-1"
    updated = await store.get_route_profile(tenant.tenant_id, profile.profile_id)
    assert (updated.observation_count, updated.success_count, updated.failure_count) == (
        1,
        1,
        0,
    )
    assert len(await store.list_route_observations(tenant.tenant_id)) == 1

    with pytest.raises(IdempotencyConflictError):
        await store.record_route_observation(
            observation.model_copy(update={"latency_ms": 99})
        )
    with pytest.raises(TenantBoundaryError):
        await store.record_route_observation(
            observation.model_copy(
                update={
                    "tenant_id": second.tenant_id,
                    "observation_id": "cross-tenant",
                    "idempotency_key": "cross-tenant",
                }
            )
        )


@pytest.mark.asyncio
async def test_sqlite_vector_search_isolates_embedding_space(routes) -> None:
    store, tenant, _second = routes
    first_vector = [1.0, *([0.0] * 1023)]
    second_vector = [0.0, 1.0, *([0.0] * 1022)]
    first = await store.create_route_profile(
        _profile(
            tenant.tenant_id,
            profile_id="route-vector-a",
            profile_key="vector-a",
            embedding=first_vector,
        )
    )
    second = await store.create_route_profile(
        _profile(
            tenant.tenant_id,
            profile_id="route-vector-b",
            profile_key="vector-b",
            label="product_code",
            embedding=second_vector,
            embedding_model="other-embedding",
        )
    )
    legacy = await store.create_route_profile(
        _profile(
            tenant.tenant_id,
            profile_id="route-vector-legacy",
            profile_key="vector-legacy",
            label="mold_number",
            embedding=first_vector,
            embedding_dimensions=0,
        )
    )
    await _activate_profile(store, first)
    await _activate_profile(store, second)
    await _activate_profile(store, legacy)

    matches = await store.find_route_profiles(
        tenant.tenant_id,
        first_vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        min_similarity=0.5,
    )
    assert [(item.profile.profile_id, item.similarity) for item in matches] == [
        ("route-vector-a", 1.0)
    ]
    other_matches = await store.find_route_profiles(
        tenant.tenant_id,
        second_vector,
        embedding_model="other-embedding",
        embedding_dimensions=1024,
        min_similarity=0.5,
    )
    assert [item.profile.profile_id for item in other_matches] == [
        "route-vector-b"
    ]


@pytest.mark.asyncio
async def test_vector_search_rejects_incomplete_embedding_identity(routes) -> None:
    store, tenant, _second = routes
    vector = [1.0, *([0.0] * 1023)]

    with pytest.raises(ValueError, match="model identity"):
        await store.find_route_profiles(
            tenant.tenant_id,
            vector,
            embedding_model=" ",
            embedding_dimensions=1024,
        )
    with pytest.raises(ValueError, match="identity dimension mismatch"):
        await store.find_route_profiles(
            tenant.tenant_id,
            vector,
            embedding_model="test-embedding",
            embedding_dimensions=768,
        )


def test_route_tables_have_composite_tenant_foreign_key() -> None:
    tables = {table.name: table for table in __import__(
        "m1.knowledge", fromlist=["KnowledgeBase"]
    ).KnowledgeBase.metadata.sorted_tables}
    observation = tables["knowledge_route_observations"]
    targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in observation.foreign_key_constraints
    }
    assert (
        "knowledge_route_profiles.tenant_id",
        "knowledge_route_profiles.profile_id",
    ) in targets
    profile = tables["knowledge_route_profiles"]
    profile_targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in profile.foreign_key_constraints
    }
    assert (
        "knowledge_route_profiles.tenant_id",
        "knowledge_route_profiles.profile_id",
    ) in profile_targets
    unique_columns = {
        tuple(column.name for column in constraint.columns)
        for constraint in profile.constraints
        if constraint.__class__.__name__ == "UniqueConstraint"
    }
    assert ("tenant_id", "supersedes_profile_id") in unique_columns
    active_indexes = {
        index.name: index for index in profile.indexes if index.name.startswith("ux_")
    }
    assert active_indexes["ux_route_profiles_active_key"].unique is True
    assert active_indexes["ux_route_profiles_active_fingerprint"].unique is True
    assert (
        str(
            active_indexes["ux_route_profiles_active_fingerprint"]
            .dialect_options["sqlite"]["where"]
        )
        == "status = 'active'"
    )
    embedding_space_index = next(
        index
        for index in profile.indexes
        if index.name == "ix_route_profiles_embedding_space"
    )
    assert tuple(column.name for column in embedding_space_index.columns) == (
        "tenant_id",
        "status",
        "embedding_model",
        "embedding_dimensions",
    )
