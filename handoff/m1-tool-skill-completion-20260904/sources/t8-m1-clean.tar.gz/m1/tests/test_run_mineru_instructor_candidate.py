from __future__ import annotations

import asyncio
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZipFile

import pytest

from m1.documents.models import (
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    SourceReference,
)
from m1.documents.parsing import mineru_authority
from m1.documents.parsing import mineru_instructor_poc as instructor_poc
from m1.documents.parsing import mineru_instructor_service as candidate
from m1.documents.parsing.document_routing_runtime import (
    DocumentRoutingResolution,
    RouteAuthorityPolicy,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
)
from m1.documents.parsing.drawing_region_vlm import (
    DrawingRegionAudit,
    DrawingRegionVLMResult,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.mineru import MinerUParseResult
from m1.documents.parsing.mineru_authority import evaluate_mineru_authority
from m1.documents.parsing.mineru_domain import domain_minimum_failures
from m1.documents.parsing.mineru_instructor_poc import (
    ContentUnit,
    DocumentIntent,
    EvidenceReference,
    ExtractedFact,
    ExtractedRecord,
    ExtractedSegment,
    MinerUInstructorExtractor,
    MinerUInstructorResult,
    ModelFailureDiagnostic,
)
from m1.documents.parsing.mineru_regions import assess_record_regions
from m1.documents.parsing.mineru_shadow import (
    MinerUShadowRunner,
    _source_reference_coverage,
    build_mineru_shadow_runner,
)
from m1.documents.parsing.semantic_facts import (
    SemanticEvidence,
    SemanticFact,
    stable_fact_id,
)
from m1.documents.parsing.source_asset_inventory import (
    SourceAsset,
    SourceAssetInventory,
    SourceAssetReference,
)

SCRIPT_PATH = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "run_mineru_instructor_candidate.py"
)
BENCHMARK_PATH = (
    Path(__file__).resolve().parents[1] / "scripts" / "benchmark_document_extractor.py"
)
BENCHMARK_SPEC = importlib.util.spec_from_file_location(
    "benchmark_document_extractor_script",
    BENCHMARK_PATH,
)
assert BENCHMARK_SPEC is not None and BENCHMARK_SPEC.loader is not None
benchmark = importlib.util.module_from_spec(BENCHMARK_SPEC)
sys.modules[BENCHMARK_SPEC.name] = benchmark
BENCHMARK_SPEC.loader.exec_module(benchmark)


def _ref(
    evidence_id: str,
    value: str,
    *,
    page: int = 1,
    bbox: list[float] | None = None,
    source_row: int | None = None,
) -> EvidenceReference:
    return EvidenceReference(
        evidence_id=evidence_id,
        quote=value,
        source_ref=SourceReference(
            page=page,
            part=f"mineru/{evidence_id}",
            bbox=bbox or [1.0, 2.0, 3.0, 4.0],
            coordinate_space="normalized",
            **({"source_row": source_row} if source_row is not None else {}),
        ),
    )


def test_native_spreadsheet_headers_reconcile_model_misroutes_and_images() -> None:
    image_identifier = "ID_E7DA007B0A9F4133AB4105491F360971"
    image_formula = f'=DISPIMG("{image_identifier}",1)'
    record = {
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "lines": [
            {
                "line_id": "line-1",
                "product_code": image_formula,
                "name_raw": "fiber cable",
                "unit_price_tax_included": "small reel",
                "quantity": 200,
                "unit": "PCS",
                "image_refs": [],
                "custom_fields": {},
                "raw_columns": {},
            }
        ],
        "field_meta": {
            "$.lines[0].product_code": {
                "source_label": "product_code",
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "B3",
                        "source_row": 3,
                        "source_column": 2,
                    }
                ],
            },
            "$.lines[0].name_raw": {
                "source_label": "name_raw",
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "C3",
                        "source_row": 3,
                        "source_column": 3,
                    }
                ],
            },
            "$.lines[0].unit_price_tax_included": {
                "source_label": "unit_price_tax_included",
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "G3",
                        "source_row": 3,
                        "source_column": 7,
                    }
                ],
            },
            "$.lines[0].quantity": {
                "source_label": "quantity",
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "J3",
                        "source_row": 3,
                        "source_column": 10,
                    }
                ],
            },
            "$.lines[0].unit": {
                "source_label": "unit",
                "source_refs": [
                    {
                        "sheet": "Sheet1",
                        "cell": "E3",
                        "source_row": 3,
                        "source_column": 5,
                    }
                ],
            },
        },
        "extraction": {
            "raw_content": {
                "pages": [
                    {
                        "tables": [
                            {
                                "sheet": "Sheet1",
                                "source_row_offset": 1,
                                "source_column_offset": 1,
                                "rows": [
                                    ["order"],
                                    [
                                        "line",
                                        "\u56fe\u7247",
                                        "\u4ea7\u54c1",
                                        "specification",
                                        "\u5355\u4f4d",
                                        "printing",
                                        "\u6253\u8f74",
                                        "packaging",
                                        "label",
                                        "\u6570\u91cf",
                                    ],
                                    [
                                        "1",
                                        image_formula,
                                        "fiber cable",
                                        "20M",
                                        "PCS",
                                        "NYK",
                                        "small reel",
                                        "box",
                                        "head label",
                                        "200",
                                    ],
                                ],
                                "native_record_layout": {
                                    "orientation": "rows",
                                    "header_axes": [1],
                                    "record_axes": [2],
                                },
                            }
                        ]
                    }
                ],
                "source_asset_inventory": {
                    "assets": [
                        {
                            "asset_id": "asset:sha256:image-1",
                            "source_refs": [
                                {"alt_text": [image_identifier]}
                            ],
                        }
                    ]
                },
            }
        },
    }

    candidate._normalize_production_lines(record)

    line = record["lines"][0]
    assert line["product_code"] is None
    assert line["unit_price_tax_included"] is None
    assert line["custom_fields"]["\u56fe\u7247"] == image_formula
    assert line["custom_fields"]["\u6253\u8f74"] == "small reel"
    assert line["raw_columns"]["\u56fe\u7247"] == image_formula
    assert line["raw_columns"]["\u6253\u8f74"] == "small reel"
    assert line["image_refs"] == ["asset:sha256:image-1"]
    assert record["field_meta"]["$.lines[0].image_refs"][
        "association_method"
    ] == "spreadsheet_display_formula"


def test_purchase_header_spatial_pairing_is_semantic_and_page_bounded() -> None:
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="buyer-label",
                        kind="text",
                        text="甲 方:",
                        bbox=EvidenceBBox(
                            x0=40, y0=120, x1=90, y1=140, coordinate_space="pdf_points"
                        ),
                    ),
                    EvidenceBlock(
                        block_id="buyer-value",
                        kind="text",
                        text="广西桐曦电子科技有限公司",
                        bbox=EvidenceBBox(
                            x0=95, y0=120, x1=250, y1=140, coordinate_space="pdf_points"
                        ),
                    ),
                    EvidenceBlock(
                        block_id="seller-label",
                        kind="text",
                        text="乙 方:",
                        bbox=EvidenceBBox(
                            x0=320, y0=120, x1=370, y1=140, coordinate_space="pdf_points"
                        ),
                    ),
                    EvidenceBlock(
                        block_id="seller-value",
                        kind="text",
                        text="东莞市华思精密电子有限公司",
                        bbox=EvidenceBBox(
                            x0=375, y0=120, x1=550, y1=140, coordinate_space="pdf_points"
                        ),
                    ),
                ],
            )
        ],
    )

    paired = candidate._spatial_purchase_header_candidates(evidence)

    assert paired["buyer"][0][0] == "广西桐曦电子科技有限公司"
    assert paired["seller"][0][0] == "东莞市华思精密电子有限公司"
    assert paired["supplier"][0][0] == "东莞市华思精密电子有限公司"


def test_purchase_signature_role_spatially_pairs_the_nearby_company() -> None:
    company = "东莞市唯格电子科技有限公司"
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                coordinate_space="pdf_points",
                blocks=[
                    EvidenceBlock(
                        block_id="receiver-signature-label",
                        kind="text",
                        text="收货单位签字盖章：",
                        bbox=EvidenceBBox(
                            x0=40,
                            y0=700,
                            x1=100,
                            y1=720,
                            coordinate_space="pdf_points",
                        ),
                    ),
                    EvidenceBlock(
                        block_id="receiver-company-stamp",
                        kind="text",
                        text=f"{company}\n合同专用章",
                        bbox=EvidenceBBox(
                            x0=100,
                            y0=650,
                            x1=260,
                            y1=750,
                            coordinate_space="pdf_points",
                        ),
                    ),
                ],
            )
        ],
    )

    paired = candidate._spatial_purchase_header_candidates(evidence)

    assert paired["buyer"][0][0] == company


def test_model_document_labels_are_normalized_to_canonical_types() -> None:
    assert instructor_poc._document_intent_family("purchase_order") == "order"
    assert instructor_poc._document_intent_family("supplier_purchase_order") == "order"
    assert (
        instructor_poc._document_intent_family("product_specification")
        == "technical_document"
    )
    assert instructor_poc._document_intent_family("inform") == "unknown"


def test_no_record_table_is_extracted_as_metadata_instead_of_skipped_layout() -> None:
    table = EvidenceTable(
        table_id="p1:t0",
        rows=[["图号", "版本", "比例", "审核"], ["版本", "图号", "审核", "比例"]],
        cells=[
            EvidenceCell(row=row, column=column, text=value)
            for row, values in enumerate(
                [["图号", "版本", "比例", "审核"], ["版本", "图号", "审核", "比例"]]
            )
            for column, value in enumerate(values)
        ],
    )
    evidence = DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                tables=[table],
            )
        ],
    )
    normalized = instructor_poc._normalize_intent_partition(
        DocumentIntent(
            document_intent="technical_document",
            tables=[
                instructor_poc.TableIntent(
                    table_id="p1:t0",
                    orientation="rows",
                    segments=[
                        instructor_poc.TableSegmentIntent(
                            start=0,
                            end=1,
                            intent="layout",
                        )
                    ],
                )
            ],
        ),
        {"p1:t0": table},
        evidence,
    )

    assert normalized.tables[0].segments[0].intent == "metadata"


def _result() -> MinerUInstructorResult:
    order = ExtractedFact(
        name="order_number",
        value="PO-1",
        evidence_refs=[_ref("p1:b0", "PO-1")],
    )
    product = ExtractedFact(
        name="product_code",
        value="SKU-1",
        evidence_refs=[_ref("p1:t0:r1:c0", "SKU-1")],
    )
    duplicate = ExtractedFact(
        name="product_code",
        value="SKU-ALIAS",
        evidence_refs=[_ref("p1:t0:r1:c1", "SKU-ALIAS")],
    )
    localized = ExtractedFact(
        name="123 localized label",
        value="Cable",
        evidence_refs=[_ref("p1:t0:r1:c2", "Cable")],
    )
    return MinerUInstructorResult(
        document_intent="purchase_order",
        document_intent_family="purchase_order",
        document_facts=[order],
        segments=[
            ExtractedSegment(
                table_id="p1:t0",
                segment_id="segment-1",
                intent="records",
                records=[
                    ExtractedRecord(fields=[product, duplicate, localized]),
                ],
            )
        ],
        unmapped_evidence=[],
        issues=[],
        complete=True,
        semantic_complete=True,
        accounted_complete=True,
        retained_complete=True,
        total_evidence_count=4,
        mapped_evidence_count=4,
        schema_evidence_count=0,
        redundant_evidence_count=0,
        raw_content_evidence_count=0,
        unresolved_evidence_count=0,
        retained_evidence_count=4,
        unmapped_evidence_count=0,
        evidence_coverage_ratio=1.0,
        semantic_accounting_ratio=1.0,
        evidence_accounting_ratio=1.0,
        retained_evidence_ratio=1.0,
        intent_calls=1,
        segment_calls=1,
    )


def test_projection_isolates_non_product_records_without_losing_evidence() -> None:
    product_ref = _ref("p1:t0:r1:c1", "SKU-1")
    narrative_ref = _ref("p1:t0:r2:c1", "ship before noon")
    total_label_ref = _ref("p1:t0:r3:c0", "TOTAL")
    total_value_ref = _ref("p1:t0:r3:c2", "10")
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="record-kinds",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="product_code",
                                    value="SKU-1",
                                    evidence_refs=[product_ref],
                                )
                            ],
                            record_kind="product",
                            record_kind_evidence_refs=[product_ref],
                            record_kind_source="model",
                            record_axis=1,
                        ),
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="remark",
                                    value="ship before noon",
                                    evidence_refs=[narrative_ref],
                                )
                            ],
                            record_kind="narrative",
                            record_kind_evidence_refs=[narrative_ref],
                            record_kind_source="model",
                            record_axis=2,
                        ),
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="line_no",
                                    value="TOTAL",
                                    evidence_refs=[total_label_ref],
                                ),
                                ExtractedFact(
                                    name="quantity",
                                    value="10",
                                    evidence_refs=[total_value_ref],
                                ),
                            ],
                            record_kind="total",
                            record_kind_evidence_refs=[total_label_ref],
                            record_kind_source="model",
                            record_axis=3,
                        ),
                    ],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="record-kind-task",
        member_name="record-kind.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="1" * 64,
        original_filename="record-kinds.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert [line["product_code"] for line in record["lines"]] == ["SKU-1"]
    narrative = next(
        fact for fact in record["generic_facts"] if fact["name"] == "narrative.remark"
    )
    assert narrative["value"] == "ship before noon"
    assert narrative["record_axis"] == 2
    assert narrative["record_kind_source_refs"][0]["evidence_id"] == narrative_ref.evidence_id
    total_record = next(
        fact for fact in record["generic_facts"] if fact["name"] == "total_record"
    )
    assert total_record["value"] == {"line_no": "TOTAL", "quantity": "10"}
    assert record["totals"]["source_declared"] == {
        "line_no": "TOTAL",
        "quantity": "10",
    }
    metadata = record["field_meta"]["$.generic_facts[0].value"]
    assert metadata["record_kind"] == "narrative"
    assert metadata["model_mapped"] is True
    assert record["extraction"]["metadata"]["isolated_non_product_record_count"] == 2
    record_set = record["extraction"]["record_sets"][0]["records"]
    assert [item["record_kind"] for item in record_set] == [
        "product",
        "narrative",
        "total",
    ]


def test_projection_retains_business_row_when_model_calls_it_total() -> None:
    product_ref = _ref("p1:t0:r1:c0", "SKU-TOTAL")
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="protected-product",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="product_code",
                                    value="SKU-TOTAL",
                                    evidence_refs=[product_ref],
                                )
                            ],
                            record_kind="total",
                            record_kind_evidence_refs=[product_ref],
                            record_kind_source="model",
                            record_axis=1,
                        )
                    ],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="protected-product-task",
        member_name="protected-product.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="2" * 64,
        original_filename="protected-product.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["lines"][0]["product_code"] == "SKU-TOTAL"
    assert record["needs_review"] is True
    assert "MINERU_INSTRUCTOR_RECORD_KIND_CONFLICT_RETAINED" in {
        issue["code"] for issue in record["validation_issues"]
    }


def test_projection_trusts_cited_model_for_weak_name_only_narrative() -> None:
    clause_ref = _ref("p1:t0:r1:c0", "Payment is due within 30 days")
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="name-only-clause",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="name_raw",
                                    value="Payment is due within 30 days",
                                    evidence_refs=[clause_ref],
                                )
                            ],
                            record_kind="narrative",
                            record_kind_evidence_refs=[clause_ref],
                            record_kind_source="model",
                            record_axis=1,
                        )
                    ],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="name-only-clause-task",
        member_name="name-only-clause.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="3" * 64,
        original_filename="name-only-clause.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["lines"] == []
    fact = next(
        item
        for item in record["generic_facts"]
        if item["name"] == "narrative.name_raw"
    )
    assert fact["value"] == "Payment is due within 30 days"
    assert fact["source_refs"][0]["part"] == "mineru/p1:t0:r1:c0"


def test_projection_does_not_trust_uncited_local_non_product_kind() -> None:
    name_ref = _ref("p1:t0:r1:c0", "Potential product")
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="unverified-kind",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="name_raw",
                                    value="Potential product",
                                    evidence_refs=[name_ref],
                                )
                            ],
                            record_kind="narrative",
                            record_kind_source="local_fallback",
                            record_axis=1,
                        )
                    ],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="unverified-kind-task",
        member_name="unverified-kind.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="4" * 64,
        original_filename="unverified-kind.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["lines"][0]["name_raw"] == "Potential product"
    assert "MINERU_INSTRUCTOR_RECORD_KIND_UNVERIFIED_RETAINED" in {
        issue["code"] for issue in record["validation_issues"]
    }


def test_context_inherited_value_is_not_rewritten_as_raw_source_cell() -> None:
    source_ref = {
        "page": 1,
        "sheet": "Order",
        "cell": "D2",
        "part": "spreadsheet/Order/D2",
        "bbox": [1.0, 2.0, 3.0, 4.0],
        "coordinate_space": "normalized",
    }
    record = {
        "document_type": "order",
        "document_subtype": "customer_purchase_order",
        "lines": [
            {
                "line_id": "line-1",
                "product_code": "SKU-1",
                "quantity": "10",
                "unit": "PCS",
            }
        ],
        "field_meta": {
            "$.lines[0].product_code": {
                "source_refs": [source_ref],
                "source_label": "product_code",
                "inferred": False,
            },
            "$.lines[0].quantity": {
                "source_refs": [source_ref],
                "source_label": "quantity",
                "inferred": False,
            },
            "$.lines[0].unit": {
                "source_refs": [source_ref],
                "source_label": "unit",
                "inferred": True,
                "inference_source": "shared_identity_record_group",
                "review_required": True,
            },
        },
    }

    candidate._normalize_production_lines(record)

    assert record["lines"][0]["unit"] == "PCS"
    assert "unit" not in record["lines"][0]["raw_columns"]
    assert record["field_meta"]["$.lines[0].unit"]["inferred"] is True
    assert record["field_meta"]["$.lines[0].unit"]["review_required"] is True


def test_context_inherited_reference_is_not_current_row_authority_evidence() -> None:
    previous_row_ref = SourceReference(
        sheet="Order",
        cell="D2",
        part="spreadsheet/Order/D2",
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename="context-inherited.xlsx"),
        document_type="order",
        lines=[
            {
                "line_id": "line-1",
                "product_code": "SKU-1",
                "quantity": 20,
                "unit": "PCS",
            }
        ],
        field_meta={
            "$.lines[0].unit": FieldMetadata(
                source_refs=[previous_row_ref],
                inferred=True,
                confidence=0.65,
                inference_source="shared_identity_record_group",
            )
        },
    )

    assert (
        mineru_authority._has_positioned_source_refs(
            document,
            "$.lines[0].unit",
        )
        is False
    )

    document.field_meta["$.lines[0].unit"] = FieldMetadata(
        source_refs=[previous_row_ref],
        inferred=True,
        inherited_from_merge=True,
        inference_source="merged_spreadsheet_cell",
    )
    assert (
        mineru_authority._has_positioned_source_refs(
            document,
            "$.lines[0].unit",
        )
        is False
    )

    document.field_meta["$.lines[0].unit"] = FieldMetadata(
        source_refs=[previous_row_ref],
        inferred=True,
        inherited_from_merge=True,
    )
    assert (
        mineru_authority._has_positioned_source_refs(
            document,
            "$.lines[0].unit",
        )
        is True
    )


def test_service_policy_projection_preserves_content_and_merged_table_columns() -> None:
    rows = [
        ["类别", "子类别", None, "保修期限", None],
        ["平板电脑", "电源适配器、键盘", None, "1年", None],
        ["显卡坞", "电源适配器", None, "1年", None],
        ["便携屏", "电源适配器", None, "1年", None],
        ["MODT(主板)", "主板", None, "3年", None],
        ["MINI PC", "主要部件(主板、CPU、内存、显卡、硬盘)三年", None, "3年", None],
        ["NAS系列", None, "主要部件(主板、CPU、内存、硬盘)三年", None, "3年"],
    ]
    table = EvidenceTable(
        table_id="p1:t0",
        rows=rows,
        cells=[
            EvidenceCell(row=row, column=column, text=value)
            for row, values in enumerate(rows)
            for column, value in enumerate(values)
            if value is not None
        ],
    )
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=884,
                height=857,
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="title",
                        text="产品售后服务政策",
                    )
                ],
                tables=[table],
            )
        ],
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="mineru-service-policy",
        member_name="service-policy.json",
        content_list_v2=[],
        middle_json=None,
        elapsed_ms=1.0,
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_kind_label": "service_policy",
            "document_subtype": "service_policy",
            "document_facts": [],
            "generic_facts": [],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="service-policy-table",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="product_name",
                                    value="must-not-become-a-product-line",
                                    evidence_refs=[
                                        _ref(
                                            "p1:t0:r1:c0",
                                            "must-not-become-a-product-line",
                                        )
                                    ],
                                )
                            ]
                        )
                    ],
                )
            ],
            "content_units": [
                ContentUnit(
                    evidence_id="p1:b0",
                    content_kind="title",
                    label="Policy title",
                    exact_text="产品售后服务政策",
                    source_ref=SourceReference(page=1, part="mineru/p1:b0"),
                    source_kind="title",
                    binding_source="local_fallback",
                )
            ],
            "issues": [],
        },
        deep=True,
    )

    projection, _field_names = candidate._benchmark_projection(
        source_sha256="a" * 64,
        original_filename="service-policy.jpg",
        parsed=parsed,
        extracted=extracted,
    )

    facts = projection["generic_facts"]
    assert projection["document_subtype"] == "service_policy"
    assert projection["lines"] == []
    assert sum(fact["name"] == "content_title" for fact in facts) == 1
    assert sum(fact["name"] == "table_schema" for fact in facts) == 1
    records = [fact for fact in facts if fact["name"] == "table_record"]
    assert len(records) == 6
    assert records[-1]["value"] == {
        "类别": "NAS系列",
        "子类别": "主要部件(主板、CPU、内存、硬盘)三年",
        "保修期限": "3年",
    }
    assert all(fact["source_refs"] for fact in facts)
    assert all(
        projection["field_meta"][f"$.generic_facts[{index}].value"]["source_refs"]
        for index in range(len(facts))
    )
    document = candidate._production_document(
        {
            "schema_version": "m1.mineru-instructor-candidate.v1",
            "record": projection,
            "result": extracted.model_dump(mode="json"),
        }
    )
    assert document.lines == []
    assert document.bom == []
    classification_meta = document.field_meta["$.document_subtype"]
    assert classification_meta.source_refs
    assert classification_meta.model_extra is not None
    assert classification_meta.model_extra["model_mapped"] is False
    assert (
        classification_meta.model_extra["classification_evidence_source"]
        == "local_projection"
    )


def test_product_photo_description_is_advisory_generic_fact() -> None:
    description = "Two electronic devices with visible internal components"
    evidence = DocumentEvidence(
        backend="mineru",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=2010,
                height=3015,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="image",
                        text=description,
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=0.998,
                            y1=0.998,
                            coordinate_space="normalized",
                        ),
                        sub_type="natural_image",
                    )
                ],
            )
        ],
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="mineru-product-photo",
        member_name="product-photo.json",
        content_list_v2=[],
        middle_json=None,
        elapsed_ms=1.0,
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_kind_label": "product_photo",
            "document_subtype": "product_photo",
            "document_facts": [],
            "generic_facts": [],
            "segments": [],
            "content_units": [
                ContentUnit(
                    evidence_id="p1:b0",
                    content_kind="description",
                    label="Description",
                    exact_text=description,
                    source_ref=SourceReference(page=1, part="mineru/p1:b0"),
                    source_kind="image",
                    binding_source="model",
                )
            ],
            "issues": [],
        },
        deep=True,
    )

    projection, _field_names = candidate._benchmark_projection(
        source_sha256="b" * 64,
        original_filename="IMG_5289.PNG",
        parsed=parsed,
        extracted=extracted,
    )

    assert projection["document_type"] == "technical_document"
    assert projection["document_subtype"] == "product_photo"
    assert projection["lines"] == []
    assert len(projection["generic_facts"]) == 1
    fact = projection["generic_facts"][0]
    assert fact["name"] == "visual_description"
    assert fact["value"] == description
    assert fact["authority"] == "advisory"
    assert fact["inferred"] is True
    assert fact["source_refs"][0]["authority"] == "advisory"
    assert fact["source_refs"][0]["inferred"] is True
    metadata = projection["field_meta"]["$.generic_facts[0].value"]
    assert metadata["inferred"] is True
    assert metadata["confidence"] == 0.65
    assert projection["needs_review"] is True
    issue = next(
        issue
        for issue in projection["validation_issues"]
        if issue["code"] == "MINERU_PRODUCT_PHOTO_DESCRIPTION_ADVISORY"
    )
    assert issue["source_refs"][0]["authority"] == "advisory"
    document = candidate._production_document(
        {
            "schema_version": "m1.mineru-instructor-candidate.v1",
            "record": projection,
            "result": extracted.model_dump(mode="json"),
        }
    )
    assert document.needs_review is True
    assert document.lines == []
    assert document.bom == []
    assert "$.document_subtype" not in document.field_meta
    source_ref = document.generic_facts[0].source_refs[0]
    assert source_ref.model_extra is not None
    assert source_ref.model_extra["authority"] == "advisory"
    assert source_ref.model_extra["inferred"] is True


def test_normalized_classification_discards_conflicting_model_subtype() -> None:
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_kind_label": "inventory_snapshot",
            "document_subtype": "inventory_snapshot",
        },
        deep=True,
    )

    normalized, diagnostics = candidate._normalized_instructor_classification(
        extracted,
        document_type_hint=None,
        document_subtype_hint=None,
    )

    assert normalized.document_intent == "technical_document"
    assert normalized.document_intent_family == "technical_document"
    assert normalized.document_subtype is None
    assert normalized.document_kind_label == "technical_document"
    assert (
        "document_classification_consistency_repair:"
        "technical_document:inventory"
    ) in normalized.issues
    assert diagnostics["canonical_subtype_type_applied"] is False


def test_normalized_classification_can_derive_unknown_family_from_subtype() -> None:
    extracted = _result().model_copy(
        update={
            "document_intent": "unknown",
            "document_intent_family": "unknown",
            "document_kind_label": "inventory_snapshot",
            "document_subtype": "inventory_snapshot",
        },
        deep=True,
    )

    normalized, diagnostics = candidate._normalized_instructor_classification(
        extracted,
        document_type_hint=None,
        document_subtype_hint=None,
    )

    assert normalized.document_intent == "inventory"
    assert normalized.document_intent_family == "inventory"
    assert normalized.document_subtype == "inventory_snapshot"
    assert diagnostics["canonical_subtype_type_applied"] is True


def test_normalized_classification_promotes_matching_canonical_kind_label() -> None:
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_kind_label": "engineering_drawing",
            "document_subtype": None,
        },
        deep=True,
    )

    normalized, diagnostics = candidate._normalized_instructor_classification(
        extracted,
        document_type_hint=None,
        document_subtype_hint=None,
    )

    assert normalized.document_intent == "technical_document"
    assert normalized.document_intent_family == "technical_document"
    assert normalized.document_subtype == "engineering_drawing"
    assert normalized.document_kind_label == "engineering_drawing"
    assert diagnostics["canonical_subtype_type_applied"] is True
    assert diagnostics["document_kind_subtype_applied"] is True
    assert diagnostics["structural_type_applied"] is False


def _production_order_payload(
    *, order_blocks: list[dict[str, object]]
) -> dict[str, object]:
    positioned = {
        "source_refs": [
            {
                "page": 1,
                "part": "mineru/p1:t0:r1:c0",
                "bbox": [1.0, 2.0, 3.0, 4.0],
                "coordinate_space": "pdf_points",
            }
        ],
        "source_label": "Material Code",
    }
    return {
        "schema_version": "m1.mineru-instructor-candidate.v1",
        "record": {
            "source": {
                "original_filename": "probe.pdf",
                "sha256": "a" * 64,
            },
            "document_type": "inventory",
            "document_subtype": "inventory_snapshot",
            "header": {},
            "lines": [
                {
                    "material_code": "CABLE-PROBE-01",
                    "name": "Test cable",
                    "quantity": "12",
                    "unit": "pcs",
                    "customer_reference": "REF-7",
                }
            ],
            "field_meta": {
                "$.lines[0].material_code": positioned,
                "$.lines[0].name": {**positioned, "source_label": "Description"},
                "$.lines[0].quantity": {**positioned, "source_label": "Quantity"},
                "$.lines[0].unit": {**positioned, "source_label": "Unit"},
                "$.lines[0].customer_reference": {
                    **positioned,
                    "source_label": "Customer Reference",
                },
            },
            "validation_issues": [],
            "extraction": {
                "metadata": {},
                "raw_content": {
                    "pages": [
                        {
                            "page_number": 1,
                            "coordinate_space": "pdf_points",
                            "blocks": order_blocks,
                        }
                    ]
                },
            },
        },
        "result": {},
    }


def _production_native_table_payload(
    *,
    document_type: str,
    document_subtype: str,
    fields: list[tuple[str, str]],
    records: list[dict[str, object]],
) -> dict[str, object]:
    sheet = "Data"
    lines: list[dict[str, object]] = []
    field_meta: dict[str, object] = {}
    rows: list[list[object]] = [[label for _name, label in fields]]
    for line_index, values in enumerate(records):
        source_row = line_index + 2
        line: dict[str, object] = {}
        row: list[object] = []
        for column_index, (canonical_name, _label) in enumerate(fields, start=1):
            value = values[canonical_name]
            line[canonical_name] = value
            row.append(value)
            coordinate = f"{chr(ord('A') + column_index - 1)}{source_row}"
            field_meta[f"$.lines[{line_index}].{canonical_name}"] = {
                "source_refs": [
                    {
                        "sheet": sheet,
                        "cell": coordinate,
                        "part": f"spreadsheet/{sheet}/{coordinate}",
                        "source_row": source_row,
                        "source_column": column_index,
                    }
                ],
                "source_label": canonical_name,
            }
        lines.append(line)
        rows.append(row)
    return {
        "schema_version": "m1.mineru-instructor-candidate.v1",
        "record": {
            "source": {
                "original_filename": "native-table.xlsx",
                "sha256": "b" * 64,
            },
            "document_type": document_type,
            "document_subtype": document_subtype,
            "document_kind_label": document_subtype,
            "header": {},
            "lines": lines,
            "field_meta": field_meta,
            "validation_issues": [],
            "extraction": {
                "metadata": {},
                "raw_content": {
                    "pages": [
                        {
                            "page_number": 1,
                            "tables": [
                                {
                                    "sheet": sheet,
                                    "source_row_offset": 1,
                                    "source_column_offset": 1,
                                    "rows": rows,
                                    "native_record_layout": {
                                        "orientation": "rows",
                                        "header_axes": [0],
                                        "record_axes": list(range(1, len(rows))),
                                    },
                                }
                            ],
                        }
                    ]
                },
            },
        },
        "result": {},
    }


def test_production_document_replays_native_docx_classification_evidence() -> None:
    native_part = "word/document.xml#paragraph:2"
    payload = {
        "schema_version": "m1.mineru-instructor-candidate.v1",
        "record": {
            "source": {
                "original_filename": "renamed.docx",
                "sha256": "c" * 64,
            },
            "document_type": "technical_document",
            "document_subtype": "approval_drawing",
            "document_kind_label": "approval_drawing",
            "header": {},
            "lines": [],
            "field_meta": {},
            "validation_issues": [],
            "extraction": {
                "metadata": {},
                "raw_content": {
                    "native_classification": {
                        "schema_version": "m1.native-classification.v1",
                        "source": "docx-native-classifier-v1",
                        "document_type": "technical_document",
                        "document_subtype": "approval_drawing",
                        "authority": "native_content",
                        "confidence": 1.0,
                        "evidence": [
                            {
                                "document_subtype": "approval_drawing",
                                "source_id": native_part,
                                "matched_marker": "approval drawing",
                                "evidence_id": "docx:p:2:classification",
                                "quote": "Product approval drawing",
                                "source_ref": {"page": 1, "part": native_part},
                            }
                        ],
                    },
                    "pages": [
                        {
                            "page_number": 1,
                            "blocks": [
                                {
                                    "block_id": "docx:p:2",
                                    "source": "docx-native-ooxml",
                                    "source_id": native_part,
                                    "text": "Product approval drawing",
                                }
                            ],
                            "tables": [],
                        }
                    ],
                },
            },
        },
        "result": {},
    }

    document = candidate._production_document(payload)

    for path in (
        "$.document_type",
        "$.document_subtype",
        "$.document_kind_label",
    ):
        metadata = document.field_meta[path]
        reference = metadata.source_refs[0]
        assert metadata.inferred is False
        assert metadata.model_extra["review_required"] is False
        assert metadata.model_extra["model_mapped"] is False
        assert (
            metadata.model_extra["classification_evidence_source"]
            == "native_classification"
        )
        assert reference.page == 1
        assert reference.part == native_part
        assert reference.model_extra["evidence_id"] == "docx:p:2:classification"
        assert reference.model_extra["evidence_quote"] == (
            "Product approval drawing"
        )
        assert mineru_authority._has_positioned_source_refs(document, path) is True


def test_native_docx_classification_replays_table_cell_evidence() -> None:
    record = {
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "extraction": {
            "raw_content": {
                "native_classification": {
                    "schema_version": "m1.native-classification.v1",
                    "source": "docx-native-classifier-v1",
                    "authority": "native_content",
                    "document_type": "technical_document",
                    "document_subtype": "product_specification",
                    "confidence": 1.0,
                    "evidence": [
                        {
                            "document_subtype": "product_specification",
                            "source_id": "word/document.xml#table:0/row:1/cell:2",
                            "matched_marker": "Product specification",
                            "evidence_id": "docx:t:0:r1:c2:classification",
                            "quote": "Product specification sheet",
                            "source_ref": {
                                "page": 1,
                                "part": (
                                    "word/document.xml#table:0/row:1/cell:2"
                                ),
                            },
                        }
                    ],
                },
                "pages": [
                    {
                        "page_number": 1,
                        "blocks": [],
                        "tables": [
                            {
                                "table_id": "docx:t:0",
                                "cells": [
                                    {
                                        "row": 1,
                                        "column": 2,
                                        "source_id": (
                                            "word/document.xml#table:0/row:1/cell:2"
                                        ),
                                        "text": "Product specification sheet",
                                    }
                                ],
                            }
                        ],
                    }
                ],
            }
        }
    }

    references = candidate._native_classification_source_refs(record)

    assert references == [
        {
            "page": 1,
            "part": "word/document.xml#table:0/row:1/cell:2",
            "evidence_id": "docx:t:0:r1:c2:classification",
            "evidence_quote": "Product specification sheet",
        }
    ]

    record["document_subtype"] = "engineering_drawing"
    assert candidate._native_classification_source_refs(record) == []


def test_native_spreadsheet_classification_replays_header_cells() -> None:
    record = {
        "document_type": "inventory",
        "document_subtype": "inventory_snapshot",
        "extraction": {
            "raw_content": {
                "native_classification": {
                    "schema_version": "m1.native-classification.v1",
                    "source": "spreadsheet-tabular-v1",
                    "document_type": "inventory",
                    "document_subtype": "inventory_snapshot",
                    "authority": "native_content",
                    "confidence": 0.95,
                    "evidence": [
                        {
                            "document_subtype": "inventory_snapshot",
                            "evidence_id": "inventory:a1:classification",
                            "quote": "Material code",
                            "source_ref": {
                                "sheet": "Inventory",
                                "page": 1,
                                "cell": "A1",
                                "part": "spreadsheet/Inventory/A1",
                            },
                        }
                    ],
                },
                "pages": [
                    {
                        "page_number": 1,
                        "tables": [
                            {
                                "table_id": "spreadsheet:s0",
                                "sheet": "Inventory",
                                "native_record_layout": {
                                    "source": "spreadsheet-tabular-v1",
                                    "orientation": "rows",
                                    "header_axes": [0],
                                    "record_axes": [1],
                                    "document_type": "inventory",
                                    "document_subtype": "inventory_snapshot",
                                },
                                "cells": [
                                    {
                                        "row": 0,
                                        "column": 0,
                                        "text": "Material code",
                                        "sheet": "Inventory",
                                        "cell": "A1",
                                    },
                                    {
                                        "row": 1,
                                        "column": 0,
                                        "text": "MAT-1",
                                        "sheet": "Inventory",
                                        "cell": "A2",
                                    },
                                ],
                            }
                        ],
                    }
                ],
            }
        },
    }

    references = candidate._native_classification_source_refs(record)

    assert references == [
        {
            "sheet": "Inventory",
            "page": 1,
            "cell": "A1",
            "part": "spreadsheet/Inventory/A1",
            "evidence_id": "inventory:a1:classification",
            "evidence_quote": "Material code",
        }
    ]


@pytest.mark.parametrize("generic_fact_order", [("first", "second"), ("second", "first")])
def test_production_classification_prefers_native_cell_over_generic_fact_order(
    generic_fact_order: tuple[str, str],
) -> None:
    native_reference = {
        "sheet": "Inventory",
        "page": 1,
        "cell": "A1",
        "part": "spreadsheet/Inventory/A1",
    }
    generic_facts = [
        {
            "name": name,
            "value": name,
            "source_refs": [
                {
                    "page": 1,
                    "part": f"mineru/{name}",
                }
            ],
        }
        for name in generic_fact_order
    ]
    payload = {
        "schema_version": "m1.mineru-instructor-candidate.v1",
        "record": {
            "source": {
                "original_filename": "inventory.xlsx",
                "sha256": "d" * 64,
            },
            "document_type": "inventory",
            "document_subtype": "inventory_snapshot",
            "document_kind_label": "inventory_snapshot",
            "generic_facts": generic_facts,
            "header": {},
            "lines": [],
            "field_meta": {},
            "validation_issues": [],
            "extraction": {
                "metadata": {},
                "raw_content": {
                    "native_classification": {
                        "schema_version": "m1.native-classification.v1",
                        "source": "spreadsheet-tabular-v1",
                        "document_type": "inventory",
                        "document_subtype": "inventory_snapshot",
                        "authority": "native_content",
                        "confidence": 0.95,
                        "evidence": [
                            {
                                "document_subtype": "inventory_snapshot",
                                "evidence_id": "inventory:a1:classification",
                                "quote": "Material code",
                                "source_ref": native_reference,
                            }
                        ],
                    },
                    "pages": [
                        {
                            "page_number": 1,
                            "tables": [
                                {
                                    "table_id": "spreadsheet:s0",
                                    "sheet": "Inventory",
                                    "cells": [
                                        {
                                            "row": 0,
                                            "column": 0,
                                            "text": "Material code",
                                            "sheet": "Inventory",
                                            "cell": "A1",
                                        }
                                    ],
                                }
                            ],
                        }
                    ],
                },
            },
        },
        "result": {
            "generic_facts": [
                {
                    "evidence_refs": [
                        {
                            "evidence_id": "model-classification",
                            "quote": "model classification",
                            "source_ref": {
                                "page": 1,
                                "part": "mineru/model-classification",
                            },
                        }
                    ]
                }
            ]
        },
    }

    document = candidate._production_document(payload)

    for path in (
        "$.document_type",
        "$.document_subtype",
        "$.document_kind_label",
    ):
        metadata = document.field_meta[path]
        assert [reference.part for reference in metadata.source_refs] == [
            "spreadsheet/Inventory/A1"
        ]
        assert (
            metadata.model_extra["classification_evidence_source"]
            == "native_classification"
        )


@pytest.mark.parametrize(
    ("authority", "quote", "part"),
    [
        ("none", "Material code", "spreadsheet/Inventory/A1"),
        ("native_content", "Quantity", "spreadsheet/Inventory/A1"),
        ("native_content", "Material code", "spreadsheet/Inventory/Z99"),
    ],
)
def test_native_classification_refs_reject_untrusted_or_unreplayable_evidence(
    authority: str,
    quote: str,
    part: str,
) -> None:
    record = {
        "document_type": "inventory",
        "document_subtype": "inventory_snapshot",
        "extraction": {
            "raw_content": {
                "native_classification": {
                    "schema_version": "m1.native-classification.v1",
                    "source": "spreadsheet-tabular-v1",
                    "document_type": "inventory",
                    "document_subtype": "inventory_snapshot",
                    "authority": authority,
                    "confidence": 0.95,
                    "evidence": [
                        {
                            "document_subtype": "inventory_snapshot",
                            "quote": quote,
                            "source_ref": {
                                "sheet": "Inventory",
                                "page": 1,
                                "cell": "A1",
                                "part": part,
                            },
                        }
                    ],
                },
                "pages": [
                    {
                        "page_number": 1,
                        "tables": [
                            {
                                "table_id": "spreadsheet:s0",
                                "sheet": "Inventory",
                                "cells": [
                                    {
                                        "row": 0,
                                        "column": 0,
                                        "text": "Material code",
                                        "sheet": "Inventory",
                                        "cell": "A1",
                                    }
                                ],
                            }
                        ],
                    }
                ],
            }
        },
    }

    assert candidate._native_classification_source_refs(record) == []


@pytest.mark.parametrize(
    ("issue", "severity"),
    [
        ("unmapped_supported_fact:retention_policy", "info"),
        ("native_document_classification_applied", "info"),
        ("native_parallel_record_tables_applied", "info"),
        ("document_route_classification_fallback:model_error", "warning"),
    ],
)
def test_instructor_issue_severity_preserves_nonblocking_diagnostics(
    issue: str,
    severity: str,
) -> None:
    assert candidate._issue_severity(issue) == severity


@pytest.mark.parametrize("row_count", [15, 19, 17, 25])
def test_production_normalization_projects_equipment_records_across_native_layouts(
    row_count: int,
) -> None:
    payload = _production_native_table_payload(
        document_type="equipment",
        document_subtype="equipment_register",
        fields=[
            ("line_no", "序号"),
            ("equipment_name", "设备名称"),
            ("model", "设备型号"),
            ("quantity", "数量"),
            ("unit", "单位"),
            ("status", "使用状态"),
        ],
        records=[
            {
                "line_no": index,
                "equipment_name": f"设备-{index}",
                "model": f"MODEL-{index}",
                "quantity": index,
                "unit": "台",
                "status": "正常运行",
            }
            for index in range(1, row_count + 1)
        ],
    )

    document = candidate._production_document(payload)

    assert len(document.lines) == row_count
    assert domain_minimum_failures(document) == ([], set())
    assert [line.name_raw for line in document.lines] == [
        f"设备-{index}" for index in range(1, row_count + 1)
    ]
    assert [line.model for line in document.lines] == [
        f"MODEL-{index}" for index in range(1, row_count + 1)
    ]
    assert all(line.quantity == index for index, line in enumerate(document.lines, 1))
    assert all(line.unit == "台" for line in document.lines)
    assert all(line.custom_fields["status"] == "正常运行" for line in document.lines)
    for index in range(row_count):
        name_meta = document.field_meta[f"$.lines[{index}].name_raw"]
        assert name_meta.source_refs
        assert name_meta.model_extra["review_required"] is False
        assert document.field_meta[f"$.lines[{index}].model"].source_refs
        assert document.field_meta[f"$.lines[{index}].quantity"].source_refs
        assert document.field_meta[f"$.lines[{index}].unit"].source_refs
        assert document.field_meta[
            f'$.lines[{index}].custom_fields["status"]'
        ].source_refs


def test_production_normalization_projects_inventory_quantity_view_for_all_rows() -> None:
    row_count = 416
    payload = _production_native_table_payload(
        document_type="inventory",
        document_subtype="inventory_snapshot",
        fields=[
            ("material_code", "物料代码"),
            ("name_raw", "物料名称"),
            ("unit", "单位"),
            ("available_quantity", "即时库存数量"),
        ],
        records=[
            {
                "material_code": f"MAT-{index:04d}",
                "name_raw": f"物料-{index}",
                "unit": "PCS",
                "available_quantity": str(index),
            }
            for index in range(1, row_count + 1)
        ],
    )

    document = candidate._production_document(payload)

    assert len(document.lines) == row_count
    assert domain_minimum_failures(document) == ([], set())
    for index, line in enumerate(document.lines, 1):
        assert line.product_code == f"MAT-{index:04d}"
        assert line.name_raw == f"物料-{index}"
        assert line.quantity == index
        assert line.unit == "PCS"
        assert str(line.custom_fields["available_quantity"]) == str(index)
        line_index = index - 1
        quantity_meta = document.field_meta[f"$.lines[{line_index}].quantity"]
        product_meta = document.field_meta[f"$.lines[{line_index}].product_code"]
        available_meta = document.field_meta[
            f'$.lines[{line_index}].custom_fields["available_quantity"]'
        ]
        assert quantity_meta.source_refs == available_meta.source_refs
        assert quantity_meta.model_extra["review_required"] is False
        assert product_meta.model_extra["review_required"] is False
        assert document.field_meta[f"$.lines[{line_index}].unit"].source_refs
        assert line.raw_columns["即时库存数量"] == str(index)


def test_production_normalization_locks_hints_and_maps_order_lines_losslessly() -> None:
    payload = _production_order_payload(
        order_blocks=[
            {
                "block_id": "p1:b0",
                "text": "Order No: M1-MINERU-PROBE-42",
                "bbox": {
                    "x0": 10,
                    "y0": 20,
                    "x1": 200,
                    "y1": 40,
                    "coordinate_space": "pdf_points",
                },
            }
        ]
    )
    record = payload["record"]
    assert isinstance(record, dict)
    field_meta = record["field_meta"]
    assert isinstance(field_meta, dict)
    stale_classification = {
        "source_refs": [
            {
                "page": 1,
                "part": "mineru/stale-model-classification",
            }
        ],
        "inferred": True,
        "model_mapped": True,
        "classification_evidence_source": "model",
    }
    field_meta["$.document_type"] = copy.deepcopy(stale_classification)
    field_meta["$.document_subtype"] = copy.deepcopy(stale_classification)

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert document.document_type == "order"
    assert document.document_subtype == "supplier_purchase_order"
    assert document.header.order_number == "M1-MINERU-PROBE-42"
    order_number_meta = document.field_meta["$.header.order_number"]
    assert order_number_meta.source_refs
    assert order_number_meta.model_extra["review_required"] is False
    line = document.lines[0]
    assert line.product_code == "CABLE-PROBE-01"
    assert line.name_raw == "Test cable"
    assert str(line.quantity) == "12"
    assert line.unit == "pcs"
    assert line.raw_columns == {
        "Material Code": "CABLE-PROBE-01",
        "Description": "Test cable",
        "Quantity": "12",
        "Unit": "pcs",
        "Customer Reference": "REF-7",
    }
    assert line.custom_fields == {"Customer Reference": "REF-7"}
    assert document.field_meta["$.lines[0].product_code"].source_refs
    assert document.field_meta['$.lines[0].raw_columns["Material Code"]'].source_refs
    for path in ("$.document_type", "$.document_subtype"):
        classification_meta = document.field_meta[path]
        assert classification_meta.source_refs == []
        assert classification_meta.confidence == 1.0
        assert classification_meta.inferred is False
        assert classification_meta.model_extra["model_mapped"] is False
        assert classification_meta.model_extra["manual_locked"] is True
        assert (
            classification_meta.model_extra["classification_evidence_source"]
            == "explicit_hint"
        )
    normalization = document.extraction["metadata"]["production_normalization"]
    assert normalization == {
        "document_type_hint_applied": True,
        "document_subtype_hint_applied": True,
        "canonical_subtype_type_applied": True,
        "normalized_header_field_count": 0,
        "header_alias_conflict_count": 0,
        "line_semantic_conflict_count": 0,
        "typed_line_field_counts": {
            "product_code": 1,
            "name_raw": 1,
            "quantity": 1,
            "unit": 1,
        },
        "positioned_order_number_candidate_count": 1,
        "order_number_recovered": True,
        "order_number_conflict": False,
    }
    assert _source_reference_coverage(document.model_dump(mode="json")) == {
        "located": 14,
        "total": 14,
        "ratio": 1.0,
    }


def test_production_normalization_does_not_reverse_trusted_family() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    record["document_type"] = "technical_document"
    record["document_subtype"] = "inventory_snapshot"
    record["document_kind_label"] = "inventory_snapshot"

    document = candidate._production_document(payload)

    assert document.document_type == "technical_document"
    assert document.document_subtype == "unknown"
    assert document.document_kind_label == "technical_document"
    assert document.needs_review is True
    assert document.validation_issues[-1].code == (
        "MINERU_CLASSIFICATION_SUBTYPE_CONFLICT"
    )
    assert document.extraction["metadata"]["production_normalization"][
        "subtype_conflict_repaired"
    ] is True


def test_production_normalization_rejects_only_invalid_numeric_field() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    lines = record["lines"]
    assert isinstance(lines, list)
    lines[0]["quantity"] = "正面 反面"

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    line = document.lines[0]
    assert line.product_code == "CABLE-PROBE-01"
    assert line.name_raw == "Test cable"
    assert line.quantity is None
    assert line.raw_columns["Quantity"] == "正面 反面"
    assert line.custom_fields["Quantity"] == "正面 反面"
    assert "$.lines[0].quantity" not in document.field_meta
    issue = document.validation_issues[-1]
    assert issue.code == "MINERU_LOCAL_FIELD_TYPE_REJECTED"
    assert issue.paths == ["$.lines[0].quantity"]
    assert issue.source_refs
    assert document.needs_review is True


def test_production_normalization_reports_conflicting_qualified_model_label() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    line = record["lines"][0]
    field_meta = record["field_meta"]
    positioned = field_meta["$.lines[0].material_code"]
    line.update(
        {
            "model": "镀仿金插头",
            "工厂型号": "ZS-H119",
            "客户型号": "VA0329-5",
            "specification_raw": "5M",
        }
    )
    field_meta.update(
        {
            "$.lines[0].model": {**positioned, "source_label": "model"},
            "$.lines[0].工厂型号": {
                **positioned,
                "source_label": "工厂型号",
            },
            "$.lines[0].客户型号": {
                **positioned,
                "source_label": "客户型号",
            },
            "$.lines[0].specification_raw": {
                **positioned,
                "source_label": "规格米数",
            },
        }
    )

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    normalized = document.lines[0]
    assert normalized.model == "镀仿金插头"
    assert normalized.specification_raw == "5M"
    assert normalized.custom_fields["customer_model"] == "VA0329-5"
    assert normalized.custom_fields.get("customer_product_code") is None
    assert normalized.raw_columns["工厂型号"] == "ZS-H119"
    issue = next(
        issue
        for issue in document.validation_issues
        if issue.code == "MINERU_LINE_ALIAS_CONFLICT"
    )
    assert issue.paths == ["$.lines[0].model", "$.lines[0].工厂型号"]
    assert issue.expected == "镀仿金插头"
    assert issue.actual == "ZS-H119"


def test_production_normalization_removes_only_a_standalone_length_prefix() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    line = record["lines"][0]
    field_meta = record["field_meta"]
    positioned = field_meta["$.lines[0].material_code"]
    line["specification_raw"] = "L:1.5M"
    field_meta["$.lines[0].specification_raw"] = {
        **positioned,
        "source_label": "规格",
    }

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    normalized = document.lines[0]
    assert normalized.specification_raw == "1.5M"
    assert normalized.raw_columns["规格"] == "L:1.5M"
    metadata = document.field_meta["$.lines[0].specification_raw"]
    assert metadata.model_extra["value_normalized_from"] == "L:1.5M"


def test_production_normalization_preserves_composite_length_specification() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    line = record["lines"][0]
    field_meta = record["field_meta"]
    line["specification_raw"] = "L:1.5M OD:6MM"
    field_meta["$.lines[0].specification_raw"] = {
        **field_meta["$.lines[0].material_code"],
        "source_label": "规格",
    }

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert document.lines[0].specification_raw == "L:1.5M OD:6MM"


def test_production_normalization_reconciles_labeled_p0_with_positioned_po() -> None:
    payload = _production_order_payload(
        order_blocks=[
            {
                "block_id": "p1:b0",
                "text": "订单号码:P0-20260424-004",
                "bbox": {
                    "x0": 10,
                    "y0": 20,
                    "x1": 200,
                    "y1": 40,
                    "coordinate_space": "pdf_points",
                },
            }
        ]
    )
    record = payload["record"]
    assert isinstance(record, dict)
    record["header"] = {"order_number": "P0-20260424-004"}
    pages = record["extraction"]["raw_content"]["pages"]
    pages[0]["tables"] = [
        {
            "table_id": "p1:t0",
            "cells": [
                {
                    "row": 0,
                    "column": 0,
                    "source": "p1:t0:r0:c0",
                    "text": "供应商:测试公司 订单号码:PO-20260424-004",
                    "bbox": {
                        "x0": 10,
                        "y0": 20,
                        "x1": 200,
                        "y1": 40,
                        "coordinate_space": "pdf_points",
                    },
                    "native_source_refs": [
                        {
                            "page": 1,
                            "part": "pdf-text/probe/p1/native-order-number",
                            "bbox": [10.0, 20.0, 200.0, 40.0],
                            "coordinate_space": "pdf_points",
                        }
                    ],
                }
            ],
        }
    ]

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert document.header.order_number == "PO-20260424-004"
    normalization = document.extraction["metadata"]["production_normalization"]
    assert normalization["order_number_ocr_corrected"] is True
    assert normalization["order_number_conflict"] is False
    quotes = {
        reference.model_extra.get("evidence_quote")
        for reference in document.field_meta["$.header.order_number"].source_refs
    }
    assert quotes == {
        "订单号码:P0-20260424-004",
        "订单号码:PO-20260424-004",
    }


def test_production_normalization_does_not_treat_duplicate_ocr_as_po_evidence() -> (
    None
):
    payload = _production_order_payload(
        order_blocks=[
            {
                "block_id": "p1:b0",
                "text": "订单号码:P0-20260424-004",
                "bbox": {
                    "x0": 10,
                    "y0": 20,
                    "x1": 200,
                    "y1": 40,
                    "coordinate_space": "pdf_points",
                },
            }
        ]
    )
    record = payload["record"]
    assert isinstance(record, dict)
    record["header"] = {"order_number": "P0-20260424-004"}
    record["extraction"]["raw_content"]["pages"][0]["tables"] = [
        {
            "table_id": "p1:t0",
            "cells": [
                {
                    "row": 0,
                    "column": 0,
                    "source": "p1:t0:r0:c0",
                    "text": "订单号码:PO-20260424-004",
                    "ocr_text_original": "订单号码:P0-20260424-004",
                    "bbox": {
                        "x0": 10,
                        "y0": 20,
                        "x1": 200,
                        "y1": 40,
                        "coordinate_space": "pdf_points",
                    },
                }
            ],
        }
    ]

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert document.header.order_number is None
    assert any(
        issue.code == "MINERU_ORDER_NUMBER_CONFLICT"
        for issue in document.validation_issues
    )


def test_production_normalization_requires_native_provenance_for_single_po() -> (
    None
):
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    record["header"] = {"order_number": "P0-20260424-004"}
    record["extraction"]["raw_content"]["pages"][0]["tables"] = [
        {
            "table_id": "p1:t0",
            "cells": [
                {
                    "row": 0,
                    "column": 0,
                    "source": "p1:t0:r0:c0",
                    "text": "订单号码:PO-20260424-004",
                    "bbox": {
                        "x0": 10,
                        "y0": 20,
                        "x1": 200,
                        "y1": 40,
                        "coordinate_space": "pdf_points",
                    },
                }
            ],
        }
    ]

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert document.header.order_number is None
    assert any(
        issue.code == "MINERU_ORDER_NUMBER_CONFLICT"
        for issue in document.validation_issues
    )


def test_production_normalization_preserves_conflicting_standard_date() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    record["header"] = {
        "date_raw": "2026年7月17日",
        "date_standard": "2026-07-18",
    }
    record["field_meta"]["$.header.date_raw"] = {
        "source_refs": [{"page": 1, "part": "pdf-text/probe/date"}],
        "source_label": "下单日期",
    }

    document = candidate._production_document(payload)

    assert document.header.date_raw == "2026-07-17"
    assert document.header.date_standard.isoformat() == "2026-07-18"
    assert any(
        issue.code == "MINERU_HEADER_ALIAS_CONFLICT"
        and issue.paths
        == ["$.header.date_standard", "$.header.date_raw"]
        for issue in document.validation_issues
    )


def test_production_normalization_preserves_unconfirmed_p0_order_number() -> None:
    payload = _production_order_payload(
        order_blocks=[
            {
                "block_id": "p1:b0",
                "text": "订单号码:P0-20260424-004",
                "bbox": {
                    "x0": 10,
                    "y0": 20,
                    "x1": 200,
                    "y1": 40,
                    "coordinate_space": "pdf_points",
                },
            }
        ]
    )

    document = candidate._production_document(
        payload,
        document_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert document.header.order_number == "P0-20260424-004"
    normalization = document.extraction["metadata"]["production_normalization"]
    assert "order_number_ocr_corrected" not in normalization


def test_production_normalization_maps_stocking_labels_from_source_metadata() -> None:
    payload = _production_order_payload(order_blocks=[])
    record = payload["record"]
    assert isinstance(record, dict)
    record["document_type"] = "order"
    record["document_subtype"] = "stocking_order"
    source_values = {
        "序号": "1",
        "型号": "W-H937",
        "名称": "中性DP2.1 16K60hz 线",
        "线身印字": "DisplayPort Cable AWM STYLE 20276",
        "规格": "1M",
        "备货数量": "800",
        "单位": "PCS",
        "包装要求": "装蓝色中性复合袋+标签",
        "备注": "按备货单入库",
        "特殊工艺": "喷砂",
    }
    line = {
        candidate._field_key(label): value for label, value in source_values.items()
    }
    positioned = {
        "source_refs": [
            {
                "sheet": "备货单",
                "cell": "A1",
                "coordinate_space": "spreadsheet_cell",
            }
        ],
        "inferred": False,
    }
    record["lines"] = [line]
    record["field_meta"] = {
        f"$.lines[0].{candidate._field_key(label)}": {
            **positioned,
            "source_label": label,
        }
        for label in source_values
    }

    document = candidate._production_document(payload)

    normalized = document.lines[0]
    assert str(normalized.line_no) == "1"
    assert normalized.model == "W-H937"
    assert normalized.name_raw == "中性DP2.1 16K60hz 线"
    assert normalized.body_printing == "DisplayPort Cable AWM STYLE 20276"
    assert normalized.specification_raw == "1M"
    assert str(normalized.quantity) == "800"
    assert normalized.unit == "PCS"
    assert normalized.packaging_requirements == "装蓝色中性复合袋+标签"
    assert normalized.remark == "按备货单入库"
    assert normalized.custom_fields == {"特殊工艺": "喷砂"}
    assert normalized.raw_columns == source_values
    model_meta = document.field_meta["$.lines[0].model"]
    assert model_meta.source_refs
    assert model_meta.model_extra["normalized_from"] == candidate._field_key("型号")
    assert document.extraction["metadata"]["production_normalization"][
        "typed_line_field_counts"
    ] == {
        "model": 1,
        "name_raw": 1,
        "quantity": 1,
        "unit": 1,
    }


def test_production_order_number_recovery_fails_closed_on_positioned_conflict() -> None:
    blocks = [
        {
            "block_id": f"p1:b{index}",
            "text": f"Order No: {value}",
            "bbox": {
                "x0": 10,
                "y0": 20 + index * 30,
                "x1": 200,
                "y1": 40 + index * 30,
                "coordinate_space": "pdf_points",
            },
        }
        for index, value in enumerate(("PO-ONE", "PO-TWO"))
    ]

    document = candidate._production_document(
        _production_order_payload(order_blocks=blocks),
        document_subtype_hint="supplier_purchase_order",
    )

    assert document.document_type == "order"
    assert document.header.order_number is None
    assert document.needs_review is True
    assert [issue.code for issue in document.validation_issues] == [
        "MINERU_ORDER_NUMBER_CONFLICT"
    ]


def test_physical_classification_guard_rejects_archive_for_single_image() -> None:
    document = DocumentRecord(
        source={"original_filename": "product.png"},
        document_type="archive",
        document_subtype="archive",
        extraction={"raw_content": {"text_original": "Product model P-1"}},
    )

    guarded = candidate._apply_physical_classification_guard(
        document,
        source="product.png",
        source_kind="image",
        document_type_hint=None,
        document_subtype_hint=None,
    )

    assert guarded.document_type == "technical_document"
    assert guarded.document_subtype == "image_document"
    assert guarded.needs_review is True
    assert guarded.validation_issues[-1].code == (
        "MINERU_CLASSIFICATION_PHYSICAL_TYPE_CONFLICT"
    )

    explicitly_hinted = candidate._apply_physical_classification_guard(
        document,
        source="product.png",
        source_kind="image",
        document_type_hint="archive",
        document_subtype_hint="archive",
    )
    assert explicitly_hinted.document_type == "archive"
    assert explicitly_hinted.document_subtype == "archive"


@pytest.mark.asyncio
async def test_full_runner_forwards_explicit_classification_hints(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    captured: dict[str, object] = {}

    class Service:
        total_timeout_seconds = 10.0

        async def run(self, path, **kwargs):
            captured.update({"path": path, **kwargs})
            return candidate.MinerUInstructorServiceResult(
                document=DocumentRecord(
                    source=DocumentSource(original_filename="order.pdf"),
                    document_type="order",
                    document_subtype="supplier_purchase_order",
                ),
                summary={"pipeline": "mineru_instructor"},
                payload={"input_normalization": {}},
            )

    runner = MinerUShadowRunner(
        client=SimpleNamespace(model_revision="mineru-model"),
        instructor_service=Service(),
        output_dir=tmp_path / "shadow",
        authority_mode="full",
    )

    await runner.run_candidate(
        task_id="task-hints",
        path=source,
        original_filename="original-order.pdf",
        file_type="pdf",
        authoritative={},
        document_type_hint="order",
        document_subtype_hint="supplier_purchase_order",
    )

    assert captured == {
        "path": source,
        "original_filename": "original-order.pdf",
        "document_type_hint": "order",
        "document_subtype_hint": "supplier_purchase_order",
        "tenant_id": "default",
        "task_id": "task-hints",
        "source_kind": "pdf",
        "routing_attempt": 0,
    }


def _evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="mineru:vlm-engine",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="text",
                        text="PO-1",
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=10,
                            y1=10,
                            coordinate_space="normalized",
                        ),
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=[
                            ["code", "alias", "name"],
                            ["SKU-1", "SKU-ALIAS", "Cable"],
                        ],
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=100,
                            y1=100,
                            coordinate_space="normalized",
                        ),
                    )
                ],
            )
        ],
    )


def test_projected_keys_are_unique_for_case_insensitive_consumers() -> None:
    target = {"Signal": "A1"}

    assert candidate._unique_key(target, "signal") == "signal__2"


@pytest.mark.parametrize(
    "issue",
    [
        "ignored_model_fact:invalid_block_semantics_proposal",
        "primary_record_table_fallback:business_evidence:p1:t0",
        "content_binding_evidence_id_repaired:normalized_id:native:block",
        "document_fact_evidence_repaired:seller:company",
        "ignored_content_binding:document_fact_consumed:p1:b0",
        "explicit_document_intent_override:order:purchase_contract",
        "document_classification_consistency_repair:technical_document:order",
        "document_classification_trusted_family_reconciled:order:technical_document",
        "long_record_field_mapping_fallback:segment-1:ValueError",
        "document_kind_label_inferred_from_evidence",
        "technical_nonprimary_record_segments_demoted",
    ],
)
def test_replayed_nonblocking_mapper_diagnostics_are_informational(
    issue: str,
) -> None:
    assert candidate._issue_severity(issue) == "info"


def test_invalid_optional_block_proposal_does_not_require_human_review() -> None:
    assert (
        candidate._has_local_rejected_proposal(
            ["ignored_model_fact:invalid_block_semantics_proposal"]
        )
        is False
    )
    assert (
        candidate._has_local_rejected_proposal(
            ["unsupported_fact_value:quantity"]
        )
        is True
    )


class _MinerU:
    def __init__(self) -> None:
        self.calls: list[tuple[Path, str | None]] = []
        self.submitted_bytes = b""

    async def parse(self, path, *, original_filename=None):
        self.calls.append((Path(path), original_filename))
        self.submitted_bytes = Path(path).read_bytes()
        return MinerUParseResult(
            evidence=_evidence(),
            task_id="mineru-task-1",
            member_name="sample_content_list_v2.json",
            content_list_v2=[],
            middle_json={},
            elapsed_ms=12.0,
        )


class _Extractor:
    def __init__(self, result: MinerUInstructorResult | None = None) -> None:
        self.seen: list[DocumentEvidence] = []
        self.result = result

    async def extract(self, evidence):
        self.seen.append(evidence)
        return (
            self.result.model_copy(deep=True) if self.result is not None else _result()
        )


class _DrawingRegionExtractor:
    def __init__(self, result_factory=None, *, error: Exception | None = None) -> None:
        self.result_factory = result_factory
        self.error = error
        self.calls: list[dict[str, object]] = []

    async def analyze(self, image, **kwargs):
        self.calls.append({"image": bytes(image), **kwargs})
        if self.error is not None:
            raise self.error
        if self.result_factory is None:
            return DrawingRegionVLMResult()
        return self.result_factory(**kwargs)


@pytest.mark.asyncio
async def test_final_semantic_audit_supersedes_raw_model_coverage_flag(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    title = ExtractedFact(
        name="title",
        value="Product specification",
        evidence_refs=[_ref("p1:b0", "Product specification")],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_kind_label": "product_specification",
            "document_subtype": "product_specification",
            "document_facts": [title],
            "segments": [],
            "schema_evidence": [],
            "redundant_evidence": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
            "semantic_complete": False,
            "total_evidence_count": 1,
            "mapped_evidence_count": 1,
            "schema_evidence_count": 0,
            "redundant_evidence_count": 0,
            "raw_content_evidence_count": 0,
            "unresolved_evidence_count": 0,
            "retained_evidence_count": 1,
            "unmapped_evidence_count": 0,
            "content_evidence_count": 1,
            "content_unit_count": 1,
            "content_model_bound_count": 0,
            "content_local_fallback_count": 1,
            "content_accounted_complete": True,
            "content_semantic_coverage_ratio": 0.0,
            "content_accounting_ratio": 1.0,
        },
        deep=True,
    )

    class SingleBlockMinerU(_MinerU):
        async def parse(self, path, *, original_filename=None):
            del path, original_filename
            return MinerUParseResult(
                evidence=DocumentEvidence(
                    backend="fixture",
                    pages=[
                        EvidencePage(
                            page_number=1,
                            page_index=0,
                            width=100,
                            height=100,
                            coordinate_space="normalized",
                            blocks=[
                                EvidenceBlock(
                                    block_id="p1:b0",
                                    text="Product specification",
                                )
                            ],
                        )
                    ],
                ),
                task_id="semantic-completion-test",
                member_name="specification_content_list_v2.json",
                content_list_v2=[],
                middle_json={},
                elapsed_ms=1.0,
            )

    service = candidate.MinerUInstructorService(
        mineru=SingleBlockMinerU(),
        extractor=_Extractor(extracted),
        visual_assets_enabled=False,
        drawing_region_vlm_enabled=False,
        total_timeout_seconds=10.0,
    )

    result = await service.run(source)

    result_payload = result.payload["result"]
    metadata = result.document.extraction["metadata"]
    assert result_payload["instructor_raw_semantic_complete"] is False
    assert result_payload["semantic_complete"] is True
    assert result_payload["semantic_completeness_audit"]["review_required"] is False
    assert metadata["instructor_raw_semantic_complete"] is False
    assert metadata["semantic_complete"] is True
    assert metadata["content_local_fallback_count"] == 1
    assert result.summary["instructor_raw_semantic_complete"] is False
    assert result.summary["instructor_semantic_complete"] is True
    classification = result.document.field_meta["$.document_type"]
    assert classification.model_extra["review_required"] is False


@pytest.mark.asyncio
async def test_workflow_issued_policy_reaches_real_instructor_without_content_leak(
    tmp_path: Path,
) -> None:
    source = tmp_path / "routed.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    evidence = DocumentEvidence(
        backend="mineru:vlm-engine",
        backend_version="3.4.4",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b0",
                        kind="text",
                        text="private document content",
                        bbox=EvidenceBBox(
                            x0=0,
                            y0=0,
                            x1=10,
                            y1=10,
                            coordinate_space="normalized",
                        ),
                    )
                ],
            )
        ],
    )

    class MinerU:
        async def parse(self, _path, *, original_filename=None):
            return MinerUParseResult(
                evidence=evidence.model_copy(deep=True),
                task_id="mineru-route-task",
                member_name=original_filename or "routed.pdf",
                content_list_v2=[],
                middle_json={},
                elapsed_ms=1.0,
            )

    policy = RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        authority_policy=RouteAuthorityPolicy.CORE_STRICT,
    )
    resolution = DocumentRoutingResolution(
        mode="guarded",
        recommendation="reuse",
        reason="exact_fingerprint",
        signature_fingerprint="a" * 64,
        recommended_profile_id="route-safe",
        applied_profile_id="route-safe",
        applied_policy=policy,
        top_score=1.0,
        top1_top2_margin=1.0,
    )

    class Client:
        async def create(self, response_model, *, messages, max_retries):
            assert response_model is DocumentIntent
            assert messages and max_retries >= 0
            return DocumentIntent(document_intent="unknown")

    extractor = MinerUInstructorExtractor(client=Client())
    payload = await candidate.run_candidate(
        source,
        mineru=MinerU(),
        extractor=extractor,
        route_plan=resolution.to_route_plan(),
        tenant_id="tenant-a",
        task_id="task-a",
        source_kind="pdf",
        routing_attempt=3,
    )

    routing = payload["adaptive_routing"]
    assert {
        key: routing[key]
        for key in (
            "schema_version",
            "enabled",
            "status",
            "mode",
            "recommendation",
            "reason",
            "signature_fingerprint",
            "recommended_profile_id",
            "applied_profile_id",
            "candidate_profile_id",
            "model_used",
            "policy_applied",
            "processing_attempt",
            "routing_authority",
        )
    } == {
        "schema_version": "m1.adaptive-routing.v1",
        "enabled": True,
        "status": "consumed",
        "mode": "guarded",
        "recommendation": "reuse",
        "reason": "exact_fingerprint",
        "signature_fingerprint": "a" * 64,
        "recommended_profile_id": "route-safe",
        "applied_profile_id": "route-safe",
        "candidate_profile_id": None,
        "model_used": False,
        "policy_applied": True,
        "processing_attempt": 3,
        "routing_authority": "workflow_preparse",
    }
    assert routing["execution_status"] == "consumed"
    assert routing["executed_backend"] == "mineru"
    assert routing["route_plan"]["schema_version"] == "m1.route-plan.v1"
    assert routing["route_plan"]["backend_chain"] == [
        {
            "backend": "auto",
            "role": "primary",
            "revision": "m1.route-parser.v1",
        }
    ]
    advice = payload["result"]["route_policy_advice"]
    assert advice == {
        "schema_family": "order",
        "verifier_policy": "on_uncertainty",
        "authority_policy": "core_strict",
    }
    serialized = json.dumps(payload["adaptive_routing"], sort_keys=True)
    assert "private document content" not in serialized
    assert "tenant-a" not in serialized
    assert "task-a" not in serialized


def _drawing_region_result(
    *,
    evidence_id: str,
    source_ref: SourceReference,
    **_kwargs,
) -> DrawingRegionVLMResult:
    region_sha256 = "f" * 64
    region_evidence_id = f"{evidence_id}/region:{region_sha256}"
    source_payload = source_ref.model_dump(mode="python", exclude_none=True)
    source_payload.update(
        {
            "parent_evidence_id": evidence_id,
            "asset_width_pixels": 100,
            "asset_height_pixels": 80,
            "bbox": [10.0, 20.0, 50.0, 40.0],
            "region_bbox_pixels": [10, 20, 50, 40],
            "region_crop_bbox_pixels": [5, 15, 55, 45],
            "region_output_size_pixels": [200, 120],
            "region_upscale_factor": 4,
            "region_resampling": "lanczos",
            "region_image_mode": "RGB",
            "region_encoding": "PNG",
            "region_encoding_options": {"optimize": True},
            "region_encoder": "Pillow/test",
            "region_hash_basis": "encoded_region_png_bytes",
            "region_transform_version": "m1.region-crop.v1",
            "coordinate_space": "image_pixels",
            "region_sha256": region_sha256,
            "region_rotation_degrees": 0,
            "authority": "advisory",
            "inferred": True,
            "evidence_kind": "model_transcription",
            "model_transcription": True,
        }
    )
    region_source_ref = SourceReference.model_validate(source_payload)
    evidence = SemanticEvidence(
        evidence_id=region_evidence_id,
        quote="R1.1",
        source_ref=region_source_ref,
    )
    attributes = {
        "dimension_type": "radius",
        "localization": "region_bbox",
        "tolerance_type": "none",
        "source_boundary": "visual_region_advisory",
        "ocr_text_trusted": False,
        "crop_rotation_degrees": 0,
        "evidence_kind": "model_transcription",
        "model_transcription": True,
    }
    value = {"nominal": "1.1"}
    fact = SemanticFact(
        fact_id=stable_fact_id(
            name="drawing_radius",
            value=value,
            attributes=attributes,
            evidence_ids=[region_evidence_id],
        ),
        name="drawing_radius",
        value=value,
        attributes=attributes,
        evidence_refs=[evidence],
        extractor="drawing_region_vlm.v1",
        confidence=0.85,
        status="advisory",
    )
    return DrawingRegionVLMResult(
        facts=[fact],
        audit=[
            DrawingRegionAudit(
                candidate_id="candidate-1",
                source_ref=region_source_ref,
                ocr_score=0.95,
                selection_reasons=["numeric_hint"],
                disposition="fact",
                normalized_text="R1.1",
                fact_ids=[fact.fact_id],
            )
        ],
    )


@pytest.mark.asyncio
async def test_candidate_runs_mineru_then_instructor_and_projects_benchmark_json(
    tmp_path: Path,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    mineru = _MinerU()
    extractor = _Extractor()
    expected_record, expected_field_names = candidate._benchmark_projection(
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        original_filename="original-order.pdf",
        parsed=MinerUParseResult(
            evidence=_evidence(),
            task_id="expected",
            member_name="expected.json",
            content_list_v2=[],
            middle_json={},
            elapsed_ms=0,
        ),
        extracted=_result(),
    )

    payload = await candidate.run_candidate(
        source,
        mineru=mineru,
        extractor=extractor,
        original_filename="original-order.pdf",
    )

    assert mineru.calls == [(source.resolve(), "original-order.pdf")]
    assert extractor.seen[0].backend == "mineru:vlm-engine"
    record = payload["record"]
    assert record["header"]["order_number"] == "PO-1"
    assert record["lines"][0]["product_code"] == "SKU-1"
    assert record["lines"][0]["product_code__2"] == "SKU-ALIAS"
    localized_key = next(key for key in record["lines"][0] if key.startswith("field_"))
    localized_path = f"$.lines[0].{localized_key}"
    assert payload["projection"]["field_names"][localized_path] == (
        "123 localized label"
    )
    assert (
        record["field_meta"]["$.lines[0].product_code"]["source_refs"][0]["part"]
        == "mineru/p1:t0:r1:c0"
    )
    assert (
        record["extraction"]["raw_content"]["pages"][0]["tables"][0]["row_count"] == 2
    )
    assert record["document_type"] == "purchase_order"
    assert record["document_subtype"] is None
    assert payload["result"]["document_intent"] == "purchase_order"
    assert record["source"]["original_filename"] == "original-order.pdf"
    assert payload["visual_asset_enrichment"] is None
    assert payload["source_asset_inventory"]["analyzed_asset_count"] == 0
    assert benchmark._record(payload) is record
    assert str(source.resolve()) not in json.dumps(payload, ensure_ascii=False)

    for key in ("header", "lines", "field_meta"):
        expected_bytes = json.dumps(
            expected_record[key],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        actual_bytes = json.dumps(
            record[key],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        assert actual_bytes == expected_bytes
    for key in ("record_sets", "line_field_order"):
        expected_bytes = json.dumps(
            expected_record["extraction"][key],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        actual_bytes = json.dumps(
            record["extraction"][key],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        assert actual_bytes == expected_bytes
    assert payload["projection"]["field_names"] == expected_field_names

    raw_content = record["extraction"]["raw_content"]
    assert set(raw_content["evidence_dispositions"]) == {
        "schema_label",
        "redundant_alias",
        "raw_content",
        "content_model_bound",
        "content_local_fallback",
    }
    assert payload["result"]["semantic_facts"] == raw_content["semantic_facts"]
    assert payload["result"]["semantic_facts"] is not raw_content["semantic_facts"]
    assert (
        payload["result"]["semantic_evidence_dispositions"]
        == raw_content["semantic_evidence_dispositions"]
    )
    assert (
        payload["result"]["semantic_evidence_dispositions"]
        is not raw_content["semantic_evidence_dispositions"]
    )
    assert (
        payload["result"]["semantic_completeness_audit"]
        == raw_content["semantic_completeness_audit"]
    )
    assert payload["timing"]["semantic_completion_ms"] >= 0


@pytest.mark.asyncio
async def test_technical_candidate_normalizes_lines_before_semantic_projection(
    tmp_path: Path,
) -> None:
    source = tmp_path / "drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    technical_result = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
        },
        deep=True,
    )

    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(technical_result),
    )

    audit = payload["result"]["semantic_completeness_audit"]
    assert audit["schema_version"] == "m1.semantic-completion.v1"
    assert audit.get("status") != "failed"
    assert not any(
        issue["code"] == "SEMANTIC_COMPLETION_FAILED"
        for issue in payload["record"]["validation_issues"]
    )


def test_projection_reports_instructor_issues_without_silent_success(
    tmp_path: Path,
) -> None:
    source = tmp_path / "broken.pdf"
    source.write_bytes(b"fixture")
    extracted = _result().model_copy(
        update={
            "complete": False,
            "issues": ["unsupported_fact_value:quantity"],
        }
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="task-2",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename=source.name,
        parsed=parsed,
        extracted=extracted,
    )

    assert record["needs_review"] is True
    assert record["validation_issues"] == [
        {
            "code": "MINERU_INSTRUCTOR_UNSUPPORTED_FACT_VALUE",
            "severity": "warning",
            "message": "unsupported_fact_value:quantity",
        }
    ]


def test_projection_persists_only_bounded_model_diagnostic_details() -> None:
    diagnostic = ModelFailureDiagnostic(
        stage="document_intent",
        response_model="DocumentIntent",
        error_type="InstructorRetryException",
        reason="retry_exhausted",
        root_error_type="ValidationError",
        attempt_count=2,
        failed_attempt_count=2,
        validation_errors=[{"loc": ["document_intent"], "type": "literal_error"}],
    )
    extracted = _result().model_copy(
        update={
            "complete": False,
            "issues": ["intent_model_error:InstructorRetryException"],
            "model_diagnostics": [diagnostic],
        }
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="diagnostic-task",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="diagnostic.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    metadata = record["extraction"]["metadata"]
    assert metadata["instructor_model_diagnostics"] == [
        diagnostic.model_dump(mode="json", exclude_none=True)
    ]
    issue = next(
        issue
        for issue in record["validation_issues"]
        if issue["code"] == "MINERU_INSTRUCTOR_MODEL_DIAGNOSTIC"
    )
    assert issue["details"] == metadata["instructor_model_diagnostics"][0]
    assert "messages" not in issue["details"]
    assert "completion" not in issue["details"]


def test_projection_and_benchmark_report_content_semantics_independently() -> None:
    content = ContentUnit(
        evidence_id="p1:b1",
        content_kind="contract_clause",
        label="payment_terms",
        exact_text="付款条件以合同原文为准。",
        source_ref=SourceReference(page=1, part="mineru/p1:b1"),
        source_kind="text",
        binding_source="model",
    )
    fallback = ContentUnit(
        evidence_id="p1:b2",
        content_kind="paragraph",
        label="local_fallback:paragraph",
        exact_text="包装、出货",
        source_ref=SourceReference(page=1, part="mineru/p1:b2"),
        source_kind="paragraph",
        binding_source="local_fallback",
    )
    extracted = _result().model_copy(
        update={
            "content_units": [content, fallback],
            "content_evidence_count": 2,
            "content_unit_count": 2,
            "content_model_bound_count": 1,
            "content_local_fallback_count": 1,
            "content_accounted_complete": True,
            "content_semantic_coverage_ratio": 0.5,
            "content_accounting_ratio": 1.0,
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="task-content",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="contract.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    metadata = record["extraction"]["metadata"]
    assert metadata["semantic_accounting_ratio"] == 1.0
    assert metadata["content_evidence_count"] == 2
    assert metadata["content_model_bound_count"] == 1
    assert metadata["content_local_fallback_count"] == 1
    assert metadata["content_semantic_coverage_ratio"] == 0.5
    dispositions = record["extraction"]["raw_content"]["evidence_dispositions"]
    assert dispositions["content_model_bound"][0]["exact_text"] == (
        "付款条件以合同原文为准。"
    )
    assert dispositions["content_local_fallback"][0]["exact_text"] == "包装、出货"

    overview = benchmark._overview(record)
    assert overview["content_evidence_count"] == 2
    assert overview["content_accounting_ratio"] == 1.0
    aggregate = benchmark._aggregate(
        [
            {
                "category": "pdf",
                "candidate": {"status": "completed", "elapsed_ms": 1.0},
                "source_coverage": {},
                "candidate_overview": overview,
                "gold": {},
            }
        ]
    )
    assert aggregate["content_semantics"] == {
        "evidence": 2,
        "units": 2,
        "model_bound": 1,
        "local_fallback": 1,
        "accounted_complete_cases": 1,
        "semantic_coverage_ratio": 0.5,
        "accounting_ratio": 1.0,
    }


def test_engineering_projection_recovers_unambiguous_evidence_backed_facts() -> None:
    version_ref = _ref("p1:t0:r13:c6", "版本 c")
    material_ref = _ref("p1:t0:r14:c5", "料号 80826-041")
    length_ref = _ref("native:length", "152±15")
    condition_label = _ref("p1:b4", "测试条件：")
    condition_sequence = _ref(
        "native:conditions",
        "1.短路测试\n2.导通阻抗\n3.真机实测\n4.插拔测试\n"
        "5.盐雾测试\n6.存储温度\n7.连接器方向\n8.重点检验尺寸",
    )
    product = ExtractedFact(
        name="product_name",
        value="Cable L=152mm",
        evidence_refs=[_ref("p1:t0:r15:c3", "Cable L=152mm")],
    )
    wrong_version = ExtractedFact(
        name="version",
        value="1",
        evidence_refs=[_ref("native:axis", "1")],
    )
    wrong_material = ExtractedFact(
        name="material_number",
        value="10501-256",
        evidence_refs=[_ref("p1:t0:r1:c1", "10501-256")],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "document_facts": [wrong_version, wrong_material, product],
            "segments": [],
            "content_units": [
                ContentUnit(
                    evidence_id="native:length",
                    content_kind="native_text",
                    label="dimension",
                    exact_text="152±15",
                    source_ref=length_ref.source_ref,
                    source_kind="native_text",
                    binding_source="local_fallback",
                ),
                ContentUnit(
                    evidence_id="p1:b4",
                    content_kind="paragraph",
                    label="test_conditions",
                    exact_text="测试条件：",
                    source_ref=condition_label.source_ref,
                    source_kind="text",
                    binding_source="model",
                ),
                ContentUnit(
                    evidence_id="native:conditions",
                    content_kind="paragraph",
                    label="test_condition_list",
                    exact_text=(
                        "1.短路测试\n2.导通阻抗\n3.真机实测\n4.插拔测试\n"
                        "5.盐雾测试\n6.存储温度\n7.连接器方向\n8.重点检验尺寸"
                    ),
                    source_ref=condition_sequence.source_ref,
                    source_kind="text",
                    binding_source="local_fallback",
                ),
            ],
            "unmapped_evidence": [version_ref, material_ref, length_ref],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="task-engineering",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="drawing.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["header"]["version"] == "c"
    assert record["header"]["material_number"] == "80826-041"
    assert record["header"]["overall_length"] == "152±15"
    assert record["header"]["test_condition_count"] == 8
    assert "version__2" not in record["header"]
    assert field_names["$.header.version"] == "version"
    assert record["field_meta"]["$.header.version"]["source_refs"] == [
        version_ref.source_ref.model_dump(mode="json", exclude_none=True)
    ]


def _project_engineering_company(
    authority_values: list[str],
    model_value: str,
) -> tuple[dict, dict[str, str]]:
    blocks = [
        EvidenceBlock(
            block_id=f"native:company:{index}",
            kind="native_text",
            text=value,
            bbox=EvidenceBBox(
                x0=0.1 + index * 0.1,
                y0=0.2,
                x1=0.15 + index * 0.1,
                y1=0.8,
                coordinate_space="normalized",
            ),
        )
        for index, value in enumerate(authority_values)
    ]
    evidence = DocumentEvidence(
        backend="pdf-text-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=blocks,
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "document_facts": [
                ExtractedFact(
                    name="company",
                    value=model_value,
                    evidence_refs=[_ref("model:company", model_value)],
                )
            ],
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="task-engineering-company",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )
    return candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="drawing.pdf",
        parsed=parsed,
        extracted=extracted,
    )


def test_engineering_company_prefers_unique_authoritative_chinese_legal_name() -> None:
    chinese_name = "深圳市创益通技术股份有限公司"
    english_name = "Shenzhen Chuangyitong Technology Co.,Ltd."

    record, field_names = _project_engineering_company(
        [chinese_name, english_name],
        english_name,
    )

    assert record["header"] == {"company": chinese_name}
    assert field_names == {"$.header.company": "company"}
    assert record["field_meta"]["$.header.company"] == {
        "source_refs": [
            {
                "page": 1,
                "part": "mineru/native:company:0",
                "bbox": [0.1, 0.2, 0.15, 0.8],
                "coordinate_space": "normalized",
            }
        ],
        "inferred": True,
        "mapping_source": "deterministic_header_projection",
        "review_required": False,
    }


def test_engineering_company_does_not_choose_between_chinese_legal_names() -> None:
    english_name = "Shenzhen Chuangyitong Technology Co.,Ltd."

    record, _field_names = _project_engineering_company(
        ["深圳市创益通技术股份有限公司", "东莞市示例电子有限公司"],
        english_name,
    )

    assert record["header"] == {"company": english_name}
    assert (
        record["field_meta"]["$.header.company"]["source_refs"][0]["part"]
        == "mineru/model:company"
    )


def test_engineering_company_keeps_model_value_without_chinese_authority() -> None:
    english_name = "Shenzhen Chuangyitong Technology Co.,Ltd."

    record, _field_names = _project_engineering_company(
        [english_name],
        english_name,
    )

    assert record["header"] == {"company": english_name}


def test_engineering_company_rejects_non_company_layout_text() -> None:
    record, _field_names = _project_engineering_company(["TYPE C A"], "TYPE C A")

    assert "company" not in record["header"]


def test_product_name_rejects_an_empty_title_block_placeholder() -> None:
    assert candidate._header_fact_plausible(
        "engineering_drawing",
        "product_name",
        "milan2 Type C-C 3.1 Gen2 Cable L=152mm",
    )
    assert not candidate._header_fact_plausible(
        "engineering_drawing",
        "product_name",
        "样品代码 /",
    )


def test_engineering_projection_drops_an_empty_product_name_placeholder() -> None:
    product_name = "milan2 Type C-C 3.1 Gen2 Cable L=152mm"
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "primary_record_table_ids": ["p1:t0"],
            "document_facts": [],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="title-block",
                    intent="layout",
                    facts=[
                        ExtractedFact(
                            name="product_name",
                            value=product_name,
                            evidence_refs=[_ref("p1:t0:r14:c3", product_name)],
                        ),
                        ExtractedFact(
                            name="product_name",
                            value="样品代码 /",
                            evidence_refs=[_ref("p1:t0:r13:c7", "样品代码 /")],
                        ),
                    ],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="engineering-product-name",
        member_name="drawing.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="drawing.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["header"] == {"product_name": product_name}
    assert field_names == {"$.header.product_name": "product_name"}


def test_engineering_projection_prefers_title_block_and_counts_split_conditions() -> (
    None
):
    product_name = "milan2 Type C-C 3.1 Gen2 Cable L=152mm"
    bom_records = [
        ExtractedRecord(
            fields=[
                ExtractedFact(
                    name="product_code",
                    value=f"PART-{index:02d}",
                    evidence_refs=[
                        _ref(
                            f"p1:t0:r{index}:c1",
                            f"PART-{index:02d}",
                        )
                    ],
                )
            ]
        )
        for index in range(1, 11)
    ]
    condition_chunks = (
        "1.100%短断路测试\n2.导通阻抗",
        "3.100%真机实测",
        ("4.TYPE C插拔测试\n5.盐雾测试\n6.存储温度\n7.连接器方向\n8.重点检验尺寸"),
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "primary_record_table_ids": ["p1:t0"],
            "document_facts": [
                ExtractedFact(
                    name="product_name",
                    value="QinDi",
                    evidence_refs=[_ref("native:footer-author", "QinDi")],
                )
            ],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="drawing-table",
                    intent="records",
                    facts=[
                        ExtractedFact(
                            name="product_name",
                            value=product_name,
                            evidence_refs=[_ref("p1:t0:r14:c3", product_name)],
                        )
                    ],
                    records=bom_records,
                )
            ],
            "content_units": [
                ContentUnit(
                    evidence_id="p1:b4",
                    content_kind="section_header",
                    label="test_conditions",
                    exact_text="测试条件：",
                    source_ref=_ref("p1:b4", "测试条件：").source_ref,
                    source_kind="text",
                    binding_source="model",
                ),
                ContentUnit(
                    evidence_id="p1:continuity-frame",
                    content_kind="test_result",
                    label="continuity frame",
                    exact_text="2.导通图框：38",
                    source_ref=_ref(
                        "p1:continuity-frame",
                        "2.导通图框：38",
                    ).source_ref,
                    source_kind="text",
                    binding_source="model",
                ),
                *[
                    ContentUnit(
                        evidence_id=f"native:conditions:{index}",
                        content_kind="test_requirement",
                        label="test_condition",
                        exact_text=text,
                        source_ref=_ref(
                            f"native:conditions:{index}",
                            text,
                        ).source_ref,
                        source_kind="native_text",
                        binding_source="model",
                    )
                    for index, text in enumerate(condition_chunks, start=1)
                ],
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="engineering-test-cable-regression",
        member_name="test_cable_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="test_cable.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["header"]["product_name"] == product_name
    assert "product_name__2" not in record["header"]
    assert field_names["$.header.product_name"] == "product_name"
    assert (
        record["field_meta"]["$.header.product_name"]["source_refs"][0]["part"]
        == "mineru/p1:t0:r14:c3"
    )
    assert record["header"]["test_condition_count"] == 8
    assert (
        len(record["field_meta"]["$.header.test_condition_count"]["source_refs"]) == 3
    )
    assert all(
        source_ref["part"] != "mineru/p1:continuity-frame"
        for source_ref in record["field_meta"]["$.header.test_condition_count"][
            "source_refs"
        ]
    )
    assert record["header"]["bom_line_count"] == 10
    assert len(record["lines"]) == 10


def test_engineering_projection_rejects_conflicting_primary_product_names() -> None:
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "primary_record_table_ids": ["p1:t0"],
            "document_facts": [
                ExtractedFact(
                    name="product_name",
                    value="QinDi",
                    evidence_refs=[_ref("native:footer-author", "QinDi")],
                )
            ],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="drawing-title-block",
                    intent="metadata",
                    facts=[
                        ExtractedFact(
                            name="product_name",
                            value="Cable A",
                            evidence_refs=[_ref("p1:t0:r1:c1", "Cable A")],
                        ),
                        ExtractedFact(
                            name="product_name",
                            value="Cable B",
                            evidence_refs=[_ref("p1:t0:r2:c1", "Cable B")],
                        ),
                    ],
                )
            ],
            "content_units": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="engineering-product-conflict",
        member_name="drawing_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="drawing.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert not any(key.startswith("product_name") for key in record["header"])
    assert "product_name" not in field_names.values()
    assert record["needs_review"] is True
    assert any(
        issue["code"] == "MINERU_INSTRUCTOR_ENGINEERING_PRODUCT_NAME_CONFLICT"
        for issue in record["validation_issues"]
    )


def test_numbered_test_conditions_do_not_merge_across_pages() -> None:
    units = [
        ContentUnit(
            evidence_id="p1:heading",
            content_kind="section_header",
            label="test_conditions",
            exact_text="测试条件：",
            source_ref=_ref("p1:heading", "测试条件：", page=1).source_ref,
            source_kind="text",
            binding_source="model",
        ),
        ContentUnit(
            evidence_id="p1:conditions",
            content_kind="test_requirement",
            label="test_condition",
            exact_text="1.First test\n2.Second test",
            source_ref=_ref(
                "p1:conditions",
                "1.First test\n2.Second test",
                page=1,
            ).source_ref,
            source_kind="native_text",
            binding_source="model",
        ),
        ContentUnit(
            evidence_id="p2:conditions",
            content_kind="test_requirement",
            label="test_condition",
            exact_text="3.Third test",
            source_ref=_ref(
                "p2:conditions",
                "3.Third test",
                page=2,
            ).source_ref,
            source_kind="native_text",
            binding_source="model",
        ),
    ]
    extracted = _result().model_copy(update={"content_units": units}, deep=True)

    assert candidate._numbered_test_condition_count(extracted) == (0, [])


def test_numbered_test_conditions_ignore_advisory_heading() -> None:
    advisory_heading = SourceReference(
        page=1,
        part="visual/test-condition-heading",
        authority="advisory",
    )
    units = [
        ContentUnit(
            evidence_id="visual:heading",
            content_kind="section_header",
            label="test_conditions",
            exact_text="测试条件：",
            source_ref=advisory_heading,
            source_kind="visual",
            binding_source="model",
        ),
        ContentUnit(
            evidence_id="p1:conditions",
            content_kind="test_requirement",
            label="test_condition",
            exact_text="1.First test\n2.Second test",
            source_ref=_ref(
                "p1:conditions",
                "1.First test\n2.Second test",
            ).source_ref,
            source_kind="native_text",
            binding_source="model",
        ),
    ]
    extracted = _result().model_copy(update={"content_units": units}, deep=True)

    assert candidate._numbered_test_condition_count(extracted) is None


def test_engineering_projection_does_not_guess_conflicting_version_values() -> None:
    extracted = _result().model_copy(
        update={
            "document_intent": "technical_document",
            "document_intent_family": "technical_document",
            "document_subtype": "engineering_drawing",
            "document_facts": [],
            "segments": [],
            "unmapped_evidence": [
                _ref("p1:b1", "版本 A"),
                _ref("p1:b2", "版本 B"),
            ],
        },
        deep=True,
    )

    assert "version" not in candidate._derived_engineering_headers(extracted)


def test_page_border_numbering_is_not_a_test_condition_list() -> None:
    assert (
        candidate._ordered_numbered_sequence_count("1 Ⅱ 2 Ⅲ 3 Ⅳ 4 Ⅴ 5 Ⅵ 6 Ⅶ 7 Ⅷ 8") == 0
    )


def test_numbered_contract_clauses_are_atomized_without_losing_parent_evidence() -> (
    None
):
    heading = ContentUnit(
        evidence_id="p1:heading",
        content_kind="title",
        label="contract_terms_heading",
        exact_text="合同条款",
        source_ref=_ref("p1:heading", "合同条款").source_ref,
        source_kind="text",
        binding_source="model",
    )
    first = ContentUnit(
        evidence_id="native:clause:1",
        content_kind="native_text",
        label="local_fallback:native_text",
        exact_text="1、交货地址：甲方工厂",
        source_ref=_ref("native:clause:1", "1、交货地址：甲方工厂").source_ref,
        source_kind="native_text",
        binding_source="local_fallback",
    )
    second = ContentUnit(
        evidence_id="native:clause:2",
        content_kind="native_text",
        label="local_fallback:native_text",
        exact_text="2、付款方式：现金",
        source_ref=_ref("native:clause:2", "2、付款方式：现金").source_ref,
        source_kind="native_text",
        binding_source="local_fallback",
    )
    combined = ContentUnit(
        evidence_id="native:clause:3-4",
        content_kind="native_text",
        label="local_fallback:native_text",
        exact_text="3、质量要求：符合图纸。\n4、争议由双方协商。",
        source_ref=_ref(
            "native:clause:3-4",
            "3、质量要求：符合图纸。\n4、争议由双方协商。",
        ).source_ref,
        source_kind="native_text",
        binding_source="local_fallback",
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "content_units": [heading, first, second, combined],
        },
        deep=True,
    )

    payload = candidate._semantic_content_units_payload(extracted)
    clauses = [item for item in payload if item["content_kind"] == "contract_clause"]

    assert [item["label"] for item in clauses] == [
        "clause_1",
        "clause_2",
        "clause_3",
        "clause_4",
    ]
    assert clauses[2]["source_ref"]["parent_evidence_id"] == ("native:clause:3-4")
    assert clauses[2]["source_ref"]["range"].startswith("chars:")
    assert all(item["binding_source"] == "deterministic" for item in clauses)


def test_contract_clause_atomization_fails_closed_on_numbering_gap() -> None:
    units = [
        ContentUnit(
            evidence_id="heading",
            content_kind="title",
            label="contract_terms_heading",
            exact_text="合同条款",
            source_ref=_ref("heading", "合同条款").source_ref,
            source_kind="text",
            binding_source="model",
        ),
        ContentUnit(
            evidence_id="clauses",
            content_kind="native_text",
            label="local_fallback:native_text",
            exact_text="1、第一条\n3、第三条",
            source_ref=_ref("clauses", "1、第一条\n3、第三条").source_ref,
            source_kind="native_text",
            binding_source="local_fallback",
        ),
    ]
    extracted = _result().model_copy(
        update={"document_subtype": "purchase_contract", "content_units": units},
        deep=True,
    )

    payload = candidate._semantic_content_units_payload(extracted)

    assert not any(item["binding_source"] == "deterministic" for item in payload)


def test_contract_clauses_recover_from_consumed_exact_evidence() -> None:
    clause_text = (
        "合同条款\n1、质量要求：符合图纸。\n2、付款方式：月结30天。\n"
        "3、交货地点：甲方工厂。"
    )
    consumed = ExtractedFact(
        name="payment_terms",
        value="月结30天",
        evidence_refs=[_ref("p1:b8", clause_text)],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [consumed],
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    clauses = [
        item
        for item in candidate._semantic_content_units_payload(extracted)
        if item["content_kind"] == "contract_clause"
    ]

    assert [item["label"] for item in clauses] == [
        "clause_1",
        "clause_2",
        "clause_3",
    ]
    assert all(item["source_ref"]["parent_evidence_id"] == "p1:b8" for item in clauses)


def test_contract_clauses_use_full_authority_evidence_after_narrow_fact() -> None:
    clause_text = (
        "合同条款\n1、质量要求:符合图纸。\n2、付款方式:月结30天。\n"
        "3、交货地点:甲方工厂。"
    )
    evidence = DocumentEvidence(
        backend="pdf-text-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="p1:b8",
                        kind="native_text",
                        text=clause_text,
                    )
                ],
            )
        ],
    )
    consumed = ExtractedFact(
        name="payment_terms",
        value="月结30天",
        evidence_refs=[_ref("p1:b8", "月结30天")],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [consumed],
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    clauses = [
        item
        for item in candidate._semantic_content_units_payload(extracted, evidence)
        if item["content_kind"] == "contract_clause"
    ]

    assert [item["label"] for item in clauses] == [
        "clause_1",
        "clause_2",
        "clause_3",
    ]
    assert all(item["source_ref"]["parent_evidence_id"] == "p1:b8" for item in clauses)


def test_contract_clause_sequence_ignores_decimal_table_cells() -> None:
    evidence = DocumentEvidence(
        backend="pdf-text-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="heading",
                        kind="native_text",
                        text="合同条款",
                    ),
                    EvidenceBlock(
                        block_id="clauses",
                        kind="native_text",
                        text="1、第一条\n2、第二条\n3、第三条",
                    ),
                ],
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=[["22.5长", "0.34", "3,400.00"]],
                    )
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    clauses = [
        item
        for item in candidate._semantic_content_units_payload(extracted, evidence)
        if item["content_kind"] == "contract_clause"
    ]

    assert [item["label"] for item in clauses] == [
        "clause_1",
        "clause_2",
        "clause_3",
    ]


def test_contract_clause_atomization_fails_closed_on_conflicting_exact_text() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [
                _ref("p1:b0", "合同条款"),
                _ref("p1:b1", "1、质量要求\n2、现金付款\n3、甲方工厂交货"),
                _ref("p1:b2", "2、月结30天"),
            ],
        },
        deep=True,
    )

    payload = candidate._semantic_content_units_payload(extracted)

    assert not any(item["binding_source"] == "deterministic" for item in payload)


def test_contract_clauses_do_not_stitch_across_pages() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [
                _ref("p1:heading", "合同条款", page=1),
                _ref("p1:clauses", "1、第一条\n2、第二条", page=1),
                _ref("p2:clause", "3、第三条", page=2),
            ],
        },
        deep=True,
    )

    payload = candidate._semantic_content_units_payload(extracted)

    assert not any(item["binding_source"] == "deterministic" for item in payload)


def test_contract_clauses_stop_at_signature_boundary() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [
                _ref("p1:heading", "合同条款"),
                _ref("p1:clauses", "1、第一条\n2、第二条"),
                _ref("p1:signature", "甲方签章："),
                _ref("p1:appendix", "3、附件第三条"),
            ],
        },
        deep=True,
    )

    payload = candidate._semantic_content_units_payload(extracted)

    assert not any(item["binding_source"] == "deterministic" for item in payload)


def test_contract_clause_ranges_slice_the_original_exact_text() -> None:
    parent = "合同条款\n   1、Ａ㍉\n  2、第二条\n3、第三条   "
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [_ref("p1:clauses", parent)],
        },
        deep=True,
    )

    clauses = [
        item
        for item in candidate._semantic_content_units_payload(extracted)
        if item["content_kind"] == "contract_clause"
    ]

    assert len(clauses) == 3
    for clause in clauses:
        source_range = clause["source_ref"]["range"]
        _prefix, start, end = source_range.split(":")
        assert parent[int(start) : int(end)] == clause["exact_text"]
    assert clauses[0]["exact_text"] == "1、Ａ㍉"


def test_deterministic_contract_clauses_do_not_duplicate_model_clause() -> None:
    model_clause = ContentUnit(
        evidence_id="p1:clauses#model:1",
        content_kind="contract_clause",
        label="clause_1",
        exact_text="1、第一条",
        source_ref=_ref("p1:clauses", "1、第一条").source_ref,
        source_kind="text",
        binding_source="model",
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "segments": [],
            "content_units": [model_clause],
            "raw_content_evidence": [
                _ref(
                    "p1:clauses",
                    "合同条款\n1、第一条\n2、第二条\n3、第三条",
                )
            ],
        },
        deep=True,
    )

    clauses = [
        item
        for item in candidate._semantic_content_units_payload(extracted)
        if item["content_kind"] == "contract_clause"
    ]

    assert [item["label"] for item in clauses] == [
        "clause_1",
        "clause_2",
        "clause_3",
    ]
    assert clauses[0]["binding_source"] == "model"


def test_docx_process_steps_are_deterministic_only_after_explicit_heading() -> None:
    extracted = _result().model_copy(
        update={
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [
                _ref("docx:p:0", "工艺流程"),
                _ref("docx:p:2", "素材 切割 抛光 喷180砂 阳极氧化"),
                _ref("docx:p:3", "前检 镭雕 包装 出货"),
                _ref("docx:p:7", "产品名称 外径尺寸 内径尺寸"),
            ],
        },
        deep=True,
    )

    units = candidate._semantic_content_units_payload(extracted)

    process = [
        item for item in units if item["content_kind"] == "manufacturing_process"
    ]
    assert [item["exact_text"] for item in process] == [
        "素材 切割 抛光 喷180砂 阳极氧化",
        "前检 镭雕 包装 出货",
    ]
    assert all(item["binding_source"] == "deterministic" for item in process)
    assert all("parent_evidence_id" in item["source_ref"] for item in process)


def test_unlabeled_docx_fallback_is_not_promoted_to_process_semantics() -> None:
    extracted = _result().model_copy(
        update={
            "segments": [],
            "content_units": [],
            "raw_content_evidence": [
                _ref("docx:p:2", "素材 切割 抛光 包装 出货"),
            ],
        },
        deep=True,
    )

    assert candidate._semantic_content_units_payload(extracted) == []


def test_purchase_contract_projection_keeps_source_label_and_canonical_name() -> None:
    sequence = ExtractedFact(
        name="序号",
        value="1",
        evidence_refs=[_ref("p1:t0:r1:c0", "1")],
    )
    material = ExtractedFact(
        name="物料编码",
        value="1 YA.B.04.3416001",
        evidence_refs=[_ref("p1:t0:r1:c1", "1 YA.B.04.3416001")],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "purchase_contract",
            "document_intent_family": "purchase_order",
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="records",
                    intent="records",
                    records=[ExtractedRecord(fields=[sequence, material])],
                )
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="contract-projection",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="contract.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert record["lines"][0]["product_code"] == "YA.B.04.3416001"
    assert field_names["$.lines[0].product_code"] == "product_code"
    _source = material.evidence_refs[0].source_ref.model_dump(
        mode="json", exclude_none=True
    )
    _source.update(
        evidence_id=material.evidence_refs[0].evidence_id,
        evidence_quote=material.evidence_refs[0].quote,
    )
    assert record["field_meta"]["$.lines[0].product_code"] == {
        "source_refs": [_source],
        "inferred": True,
        "inherited_from_merge": False,
        "source_label": "物料编码",
        "source_value": "1 YA.B.04.3416001",
    }
    assert _source["part"] == "mineru/p1:t0:r1:c1"


def test_primary_schema_coordinates_declare_empty_columns_in_numeric_order() -> None:
    image_header = _ref("p1:t0:r4:c3", "产品图片")
    name_header = _ref("p1:t0:r4:c1", "产品名称")
    quantity_header = _ref("p1:t0:r4:c2", "数量")
    auxiliary_header = _ref("p1:t9:r0:c0", "辅助说明")
    record = ExtractedRecord(
        fields=[
            ExtractedFact(
                name="数量",
                value="10",
                evidence_refs=[_ref("p1:t0:r5:c2", "10")],
            ),
            ExtractedFact(
                name="产品名称",
                value="连接器",
                evidence_refs=[_ref("p1:t0:r5:c1", "连接器")],
            ),
        ]
    )
    extracted = _result().model_copy(
        update={
            "document_facts": [],
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                ExtractedSegment(
                    table_id="p1:t9",
                    segment_id="aux",
                    intent="records",
                    records=[
                        ExtractedRecord(
                            fields=[
                                ExtractedFact(
                                    name="辅助说明",
                                    value="仅供参考",
                                    evidence_refs=[_ref("p1:t9:r1:c0", "仅供参考")],
                                )
                            ]
                        )
                    ],
                ),
                ExtractedSegment(
                    table_id="p1:t0",
                    segment_id="primary",
                    intent="records",
                    records=[record],
                ),
            ],
            "schema_evidence": [
                image_header,
                auxiliary_header,
                quantity_header,
                name_header,
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="schema-order",
        member_name="fixture.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    projected, field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="stocking.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert projected["extraction"]["line_field_order"] == [
        "产品名称",
        "数量",
        "产品图片",
    ]
    line = projected["lines"][0]
    semantic_line = {
        field_names[f"$.lines[0].{key}"]: value for key, value in line.items()
    }
    assert semantic_line == {"数量": "10", "产品名称": "连接器"}
    assert "产品图片" not in semantic_line
    assert projected["extraction"]["metadata"]["primary_record_table_ids"] == ["p1:t0"]
    assert [item["table_id"] for item in projected["extraction"]["record_sets"]] == [
        "p1:t0",
        "p1:t9",
    ]


def test_docx_schema_order_fills_model_omissions_from_authoritative_header() -> None:
    table_id = "docx:t0"
    headers = ["产品名称", "外径尺寸", "内径尺寸", "下料尺寸", "公差"]
    extracted = _result().model_copy(
        update={
            "document_subtype": "product_specification",
            "schema_evidence": [
                _ref(f"{table_id}:r0:c0", headers[0]),
                _ref(f"{table_id}:r0:c1", headers[1]),
                _ref(f"{table_id}:r0:c3", headers[3]),
            ],
        },
        deep=True,
    )
    evidence = DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[EvidenceTable(table_id=table_id, rows=[headers])],
            )
        ],
    )

    assert (
        candidate._schema_line_field_order(
            extracted,
            [table_id],
            evidence,
        )
        == headers
    )


def test_docx_schema_order_recovers_header_when_all_schema_was_consumed() -> None:
    table_id = "docx:t0"
    headers = ["产品名称", "外径尺寸", "内径尺寸", "下料尺寸", "公差"]
    values = ["HDMI椭圆形铝壳", "19.93*10.05mm", "18.6*8.7mm", "21mm", "±0.05mm"]
    record = ExtractedRecord(
        fields=[
            ExtractedFact(
                name=header,
                value=value,
                evidence_refs=[_ref(f"{table_id}:r3:c{column}", value)],
            )
            for column, (header, value) in enumerate(zip(headers, values))
        ]
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "product_specification",
            "primary_record_table_ids": [table_id],
            "segments": [
                ExtractedSegment(
                    table_id=table_id,
                    segment_id="records",
                    intent="records",
                    records=[record],
                )
            ],
            "schema_evidence": [],
        },
        deep=True,
    )
    rows = [
        ["产品规格表", None, None, None, None, None],
        [*headers, "内部备注"],
        ["单位：mm", None, None, None, None, None],
        [*values, "不可见值"],
    ]
    evidence = DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id=table_id,
                        rows=rows,
                        cells=[
                            EvidenceCell(
                                row=row,
                                column=5,
                                text=rows[row][5],
                                hidden_column=True,
                            )
                            for row in (1, 3)
                        ],
                    )
                ],
            )
        ],
    )

    assert (
        candidate._schema_line_field_order(
            extracted,
            [table_id],
            evidence,
        )
        == headers
    )


def test_purchase_contract_headers_require_typed_non_record_evidence() -> None:
    header_text = (
        "采购合同\n合同编号：HT-2026-001\n下单日期：2026-07-15\n"
        "甲方：广西桐曦电子科技有限公司\n乙方：东莞市线缆有限公司\n"
        "付款方式：月结30天\n税率：13%\n合计金额：￥4,194.00"
    )
    schema = [
        _ref("p1:t0:r0:c0", "公司"),
        _ref("p1:t0:r0:c1", "单位"),
        _ref("p1:t0:r0:c2", "物料编码"),
    ]
    fake_header_facts = [
        ExtractedFact(
            name="buyer",
            value="公司",
            evidence_refs=[schema[0]],
        ),
        ExtractedFact(
            name="seller",
            value="单位",
            evidence_refs=[schema[1]],
        ),
        ExtractedFact(
            name="contract_number",
            value="物料编码",
            evidence_refs=[schema[2]],
        ),
    ]
    extracted = _result().model_copy(
        update={
            "document_intent": "purchase_contract",
            "document_intent_family": "purchase_order",
            "document_subtype": "purchase_contract",
            "document_facts": fake_header_facts,
            "primary_record_table_ids": ["p1:t0"],
            "segments": [],
            "schema_evidence": schema,
            "raw_content_evidence": [_ref("p1:b0", header_text)],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="contract-header",
        member_name="fixture.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    projected, names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="采购合同.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert projected["header"] == {
        "title": "采购合同",
        "contract_number": "HT-2026-001",
        "order_date": "2026-07-15",
        "buyer": "广西桐曦电子科技有限公司",
        "seller": "东莞市线缆有限公司",
        "supplier": "东莞市线缆有限公司",
        "payment_terms": "月结30天",
        "tax_rate": "13",
        "total_amount": "4,194.00",
    }
    assert "delivery_date" not in projected["header"]
    assert not any("__2" in key for key in projected["header"])
    assert set(names.values()) >= {
        "contract_number",
        "order_date",
        "buyer",
        "seller",
        "supplier",
        "payment_terms",
        "tax_rate",
        "total_amount",
    }


def test_purchase_party_header_stops_before_contact_metadata() -> None:
    buyer = "义乌市艾理德国际贸易有限公司"
    seller = "桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref(
                    "p1:b0",
                    (
                        f"买方:{buyer} 地址:浙江省义乌市银海路399号 "
                        "联系人:林先生 15200000000"
                    ),
                ),
                _ref(
                    "p1:b1",
                    f"卖方:{seller} 地址:广西全州县工业集中区 18000000000 刘先生",
                ),
                _ref("p1:b2", f"买方:{buyer}"),
                _ref("p1:b3", f"卖方:{seller}"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["buyer"][0] == buyer
    assert headers["seller"][0] == seller
    assert headers["supplier"][0] == seller


def test_purchase_party_header_stops_before_order_metadata() -> None:
    supplier = "广西桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref(
                    "p1:t0:r0:c0",
                    f"供应商:{supplier} 订单号码:PO-20260529-011",
                )
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["supplier"][0] == supplier
    assert headers["order_number"][0] == "PO-20260529-011"


@pytest.mark.parametrize(
    "title_text",
    [
        "VegGieg 唯格 东莞市唯格电子科技有限公司采购合同",
        "东莞市唯格电子科技有限公司\n采购合同",
    ],
)
def test_purchase_title_company_is_source_backed_buyer(title_text: str) -> None:
    supplier = "广西桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", title_text),
                _ref("p1:b1", f"供应商:{supplier}"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["buyer"][0] == "东莞市唯格电子科技有限公司"
    assert headers["supplier"][0] == supplier
    assert headers["buyer"][1]


def test_purchase_title_does_not_relabel_supplier_as_buyer() -> None:
    supplier = "广西桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", f"供应商:{supplier} 采购合同"),
                _ref("p1:b1", f"供应商:{supplier}"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert "buyer" not in headers
    assert headers["supplier"][0] == supplier


def test_purchase_title_company_requires_an_independent_counterparty() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", "东莞市唯格电子科技有限公司采购合同")
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert "buyer" not in headers


def test_purchase_title_company_may_span_adjacent_layout_blocks() -> None:
    buyer = "东莞市唯格电子科技有限公司"
    supplier = "广西桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", buyer, bbox=[0.1, 0.10, 0.8, 0.18]),
                _ref("p1:b1", "采购合同", bbox=[0.1, 0.20, 0.8, 0.28]),
                _ref(
                    "p1:b2",
                    f"供应商:{supplier}",
                    bbox=[0.1, 0.30, 0.8, 0.38],
                ),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["buyer"][0] == buyer
    assert headers["supplier"][0] == supplier


def test_purchase_title_company_does_not_cross_pages() -> None:
    buyer = "东莞市唯格电子科技有限公司"
    supplier = "广西桐曦电子科技有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", buyer, page=1),
                _ref("p2:b0", "采购合同", page=2),
                _ref("p2:b1", f"供应商:{supplier}", page=2),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert "buyer" not in headers


def test_purchase_headers_accept_clause_aliases_and_unique_currency() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", "采 购 合 同"),
                _ref("p1:b1", "第3条、交货时间:2026年2月9日"),
                _ref("p1:b2", "第4条、结算方式及期限:一个月账期"),
                _ref("p1:t0:r0:c0", "含税总金额(RMB)"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["title"][0] == "采购合同"
    assert headers["delivery_date"][0] == "2026-02-09"
    assert headers["payment_terms"][0] == "一个月账期"
    assert headers["currency"][0] == "RMB"


def test_purchase_party_near_alias_selects_more_complete_legal_name() -> None:
    complete = "义乌市艾理德国际贸易有限公司"
    abbreviated = "义乌市艾理德贸易有限公司"
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", f"买方:{complete}"),
                _ref("p1:b1", f"买方:{abbreviated}"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["buyer"][0] == complete
    assert candidate._party_values_equivalent({complete, abbreviated}) is True
    assert (
        candidate._party_values_equivalent(
            {complete, "深圳市另一家电子科技有限公司"}
        )
        is False
    )


def test_generic_order_header_uses_top_cell_title_and_date() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=3,
                height=2,
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[
                            ["3月31日客户光纤订单", None, None],
                            ["1", "光纤线", "300"],
                        ],
                        cells=[
                            EvidenceCell(
                                row=0,
                                column=0,
                                text="3月31日客户光纤订单",
                                sheet="Sheet1",
                                cell="A1",
                            )
                        ],
                    )
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "document_subtype": "customer_purchase_order",
        },
        deep=True,
    )

    headers = candidate._derived_generic_order_headers(extracted, evidence)

    assert headers["document_title"][0] == "3月31日客户光纤订单"
    assert headers["order_date_raw"][0] == "3月31日"


def test_generic_price_columns_use_explicit_document_tax_semantics() -> None:
    table_id = "p1:t0"
    headers = ["产品编码", "数量", "单价", "金额"]
    values = ["YA.C.06.0008", "10000", "0.075", "750.00"]
    record = ExtractedRecord(
        fields=[
            ExtractedFact(
                name=header,
                value=value,
                evidence_refs=[_ref(f"{table_id}:r1:c{column}", value)],
            )
            for column, (header, value) in enumerate(zip(headers, values))
        ]
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "primary_record_table_ids": [table_id],
            "segments": [
                ExtractedSegment(
                    table_id=table_id,
                    segment_id="records",
                    intent="records",
                    records=[record],
                )
            ],
            "schema_evidence": [
                _ref(f"{table_id}:r0:c{column}", header)
                for column, header in enumerate(headers)
            ],
        },
        deep=True,
    )

    def project(context: str) -> dict[str, object]:
        evidence = DocumentEvidence(
            backend="pymupdf-native",
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=100,
                    height=100,
                    coordinate_space="pdf_points",
                    blocks=[EvidenceBlock(block_id="p1:b0", text=context)],
                    tables=[EvidenceTable(table_id=table_id, rows=[headers, values])],
                )
            ],
        )
        projected, _ = candidate._benchmark_projection(
            source_sha256="0" * 64,
            original_filename="采购合同.pdf",
            parsed=MinerUParseResult(
                evidence=evidence,
                task_id="tax-context",
                member_name="采购合同.pdf",
                content_list_v2=[],
                middle_json={},
                elapsed_ms=1,
            ),
            extracted=extracted,
        )
        return projected

    included = project("此单价含税率：10%")
    ambiguous = project("税率：10%")

    assert included["lines"][0]["unit_price_tax_included"] == "0.075"
    assert included["lines"][0]["amount_tax_included"] == "750.00"
    assert "unit_price_tax_excluded" not in included["lines"][0]
    assert ambiguous["lines"][0]["unit_price_tax_excluded"] == "0.075"
    assert ambiguous["lines"][0]["amount_tax_excluded"] == "750.00"
    assert ambiguous["needs_review"] is True
    assert "MINERU_INSTRUCTOR_AMBIGUOUS_PRICE_TAX_SEMANTICS" in {
        issue["code"] for issue in ambiguous["validation_issues"]
    }


def test_delivery_date_requires_its_own_label_even_when_dates_are_equal() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref(
                    "p1:b0",
                    "下单日期：2026年7月15日\n交货日期：2026年7月15日",
                )
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert headers["order_date"][0] == "2026-07-15"
    assert headers["delivery_date"][0] == "2026-07-15"


def test_purchase_headers_reject_invalid_complete_chinese_date() -> None:
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [
                _ref("p1:b0", "订单日期：2026年2月30日"),
            ],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted)

    assert "order_date" not in headers


def test_purchase_headers_use_complete_authority_cell_after_partial_model_use() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[
                            [
                                (
                                    "供 应 商:东莞市凯非特包装制品有限公司"
                                    "                                    订单号码: POORD009546"
                                    "                                    订单日期:2026年 05 月12日"
                                )
                            ],
                            [
                                (
                                    "联系电话:15220422062"
                                    "                                                   结款方式:月结30天"
                                    "                                       交货日期:2026年 05 月22日"
                                )
                            ],
                        ],
                    )
                ],
            )
        ],
    )
    consumed_date = ExtractedFact(
        name="order_date",
        value="2026年 05 月12日",
        evidence_refs=[_ref("spreadsheet:s0:r0:c0", "2026年 05 月12日")],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [consumed_date],
            "segments": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted, evidence)

    values = {name: value for name, (value, _refs) in headers.items()}
    assert values["supplier"] == "东莞市凯非特包装制品有限公司"
    assert values["order_number"] == "POORD009546"
    assert values["order_date"] == "2026-05-12"
    assert values["payment_terms"] == "月结30天"
    assert values["delivery_date"] == "2026-05-22"


def test_sparse_spreadsheet_header_cells_project_to_standard_order_fields() -> None:
    def cell(block_id: str, coordinate: str, text: str) -> EvidenceBlock:
        return EvidenceBlock(
            block_id=block_id,
            kind="spreadsheet_cell",
            text=text,
            source_ref_part=f"spreadsheet/Sheet1/{coordinate}",
            native_source_refs=[{"sheet": "Sheet1", "cell": coordinate}],
        )

    delivery_source = "2026年4月16日（越南订单，请加急安排）"
    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=33,
                height=16,
                coordinate_space="unknown",
                blocks=[
                    cell("company", "D2", "东莞市唯格电子科技有限公司"),
                    cell("title", "B4", "采购合同"),
                    cell("supplier-label", "D6", "供应商："),
                    cell("supplier-value", "G6", "广西桐曦电子科技有限公司"),
                    cell("order-label", "M6", "订单号码："),
                    cell("order-value", "P6", "PO-20260529-003"),
                    cell("order-date-label", "U6", "订单日期："),
                    cell("order-date-value", "X6", "46171"),
                    cell("payment-label", "M7", "结款方式："),
                    cell("payment-value", "P7", "120天"),
                    cell("delivery-label", "U7", "交货日期："),
                    cell("delivery-value", "X7", delivery_source),
                    cell(
                        "address",
                        "D8",
                        "收货地址：广东省东莞市石排镇埔心商业街3号2楼",
                    ),
                ],
            )
        ],
        raw={"spreadsheet_date_1904": False},
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="spreadsheet-header",
        member_name="采购合同.xlsx",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="采购合同.xlsx",
        parsed=parsed,
        extracted=extracted,
    )
    document = candidate._production_document(
        {
            "schema_version": "m1.mineru-instructor-candidate.v1",
            "record": record,
            "result": {},
        }
    )

    assert document.header.title == "采购合同"
    assert document.header.issuer == "东莞市唯格电子科技有限公司"
    assert document.header.buyer == "东莞市唯格电子科技有限公司"
    assert document.header.seller == "广西桐曦电子科技有限公司"
    assert document.header.supplier == "广西桐曦电子科技有限公司"
    assert document.header.order_number == "PO-20260529-003"
    assert document.header.date_raw == "2026-05-29"
    assert document.header.date_standard.isoformat() == "2026-05-29"
    assert document.header.delivery_date_raw == "2026-04-16"
    assert document.header.delivery_date_standard.isoformat() == "2026-04-16"
    assert document.header.settlement_method == "120天"
    assert document.header.delivery_address == (
        "广东省东莞市石排镇埔心商业街3号2楼"
    )
    assert document.header.candidate_numbers[0].selected is True
    delivery_ref = document.field_meta["$.header.delivery_date_raw"].source_refs[0]
    assert delivery_ref.sheet == "Sheet1"
    assert delivery_ref.cell == "X7"
    assert delivery_ref.model_extra["evidence_quote"] == delivery_source
    for path in (
        "$.header.title",
        "$.header.issuer",
        "$.header.buyer",
        "$.header.seller",
        "$.header.supplier",
        "$.header.order_number",
        "$.header.date_raw",
        "$.header.date_standard",
        "$.header.delivery_date_raw",
        "$.header.delivery_date_standard",
        "$.header.settlement_method",
        "$.header.delivery_address",
    ):
        metadata = document.field_meta[path]
        assert metadata.inferred is True
        assert metadata.source_refs
        assert metadata.model_extra["review_required"] is False


def test_sparse_header_does_not_skip_intermediate_note_for_payment_terms() -> None:
    def cell(block_id: str, coordinate: str, text: str) -> EvidenceBlock:
        return EvidenceBlock(
            block_id=block_id,
            kind="spreadsheet_cell",
            text=text,
            source_ref_part=f"spreadsheet/Sheet1/{coordinate}",
            native_source_refs=[{"sheet": "Sheet1", "cell": coordinate}],
        )

    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=30,
                height=20,
                blocks=[
                    cell("title", "B4", "采购合同"),
                    cell("payment-label", "M7", "结款方式："),
                    cell("contact-note", "P7", "联系人张三"),
                    cell("payment-value", "T7", "月结30天"),
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted, evidence)

    assert "payment_terms" not in headers


def test_sparse_header_does_not_use_distant_unlabeled_company_as_buyer() -> None:
    def cell(block_id: str, coordinate: str, text: str) -> EvidenceBlock:
        return EvidenceBlock(
            block_id=block_id,
            kind="spreadsheet_cell",
            text=text,
            source_ref_part=f"spreadsheet/Sheet1/{coordinate}",
            native_source_refs=[{"sheet": "Sheet1", "cell": coordinate}],
        )

    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=30,
                height=30,
                blocks=[
                    cell("title", "B4", "采购合同"),
                    cell("supplier-label", "D6", "供应商："),
                    cell("supplier-value", "G6", "广西桐曦电子科技有限公司"),
                    cell("footer-company", "D20", "东莞市收货服务有限公司"),
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted, evidence)

    assert headers["supplier"][0] == "广西桐曦电子科技有限公司"
    assert "buyer" not in headers


def test_production_preserves_and_reports_source_semantic_conflicts() -> None:
    def metadata(cell: str) -> dict[str, object]:
        return {
            "source_refs": [{"sheet": "Sheet1", "cell": cell}],
            "inferred": False,
        }

    document = candidate._production_document(
        {
            "schema_version": "m1.mineru-instructor-candidate.v1",
            "record": {
                "document_type": "order",
                "document_subtype": "purchase_contract",
                "source": {
                    "original_filename": "PO-20260422-004.xlsx",
                    "sha256": "1" * 64,
                },
                "header": {
                    "order_number": "PO-20260422-004",
                    "order_date": "2026-04-27",
                },
                "lines": [
                    {
                        "model": "FC-20",
                        "name_raw": "中性灰色铝合金光纤线 20M",
                        "specification_raw": "210M",
                        "quantity": 300,
                        "unit": "PCS",
                    }
                ],
                "field_meta": {
                    "$.header.order_number": metadata("P6"),
                    "$.header.order_date": metadata("X6"),
                    "$.lines[0].model": metadata("I10"),
                    "$.lines[0].name_raw": metadata("J10"),
                    "$.lines[0].specification_raw": metadata("N10"),
                    "$.lines[0].quantity": metadata("R10"),
                    "$.lines[0].unit": metadata("S10"),
                },
                "validation_issues": [],
                "needs_review": False,
                "extraction": {"metadata": {}, "raw_content": {"pages": []}},
            },
            "result": {},
        }
    )

    assert document.header.date_raw == "2026-04-27"
    assert document.lines[0].model == "FC-20"
    assert document.lines[0].name_raw.endswith("20M")
    assert document.lines[0].specification_raw == "210M"
    assert {issue.code for issue in document.validation_issues} >= {
        "ORDER_NUMBER_DATE_CONFLICT",
        "LINE_IDENTITY_SPECIFICATION_CONFLICT",
    }
    assert document.needs_review is True


def test_sample_request_spreadsheet_projects_title_parties_and_date() -> None:
    def cell(block_id: str, coordinate: str, text: str) -> EvidenceBlock:
        return EvidenceBlock(
            block_id=block_id,
            kind="spreadsheet_cell",
            text=text,
            source_ref_part=f"spreadsheet/样品/{coordinate}",
            native_source_refs=[{"sheet": "样品", "cell": coordinate}],
        )

    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=8,
                height=14,
                blocks=[
                    cell(
                        "title",
                        "A1",
                        "东莞市唯格电子科技有限公司 样品单",
                    ),
                    cell("supplier", "A2", "供应商：纬线"),
                    cell("date", "G2", "日期：2026-4-30"),
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "order",
            "document_intent_family": "order",
            "document_subtype": "sample_request",
            "document_facts": [],
            "segments": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="sample-request",
        member_name="样品需求单2026.4.30.xlsx",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _field_names = candidate._benchmark_projection(
        source_sha256="2" * 64,
        original_filename="样品需求单2026.4.30.xlsx",
        parsed=parsed,
        extracted=extracted,
    )
    document = candidate._production_document(
        {
            "schema_version": "m1.mineru-instructor-candidate.v1",
            "record": record,
            "result": {},
        }
    )

    assert document.document_subtype == "sample_request"
    assert document.header.title == "样品单"
    assert document.header.issuer == "东莞市唯格电子科技有限公司"
    assert document.header.buyer == "东莞市唯格电子科技有限公司"
    assert document.header.seller == "纬线"
    assert document.header.supplier == "纬线"
    assert document.header.date_standard.isoformat() == "2026-04-30"


def test_purchase_total_uses_labeled_total_row_not_detail_amount_column() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=[
                            ["序号", "物料名称", "合计金额"],
                            ["1", "产品A", "1,200.00"],
                            ["2", "产品B", "2,200.00"],
                            ["合计金额:", None, "¥3,400.00"],
                        ],
                    )
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted, evidence)

    assert headers["total_amount"][0] == "3,400.00"


def test_declared_quantity_matches_calculated_value_in_ambiguous_summary_row() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=5,
                height=2,
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[
                            ["1", "光纤线", "300", "10", "30"],
                            ["总件数:", None, "300", None, "30"],
                        ],
                    )
                ],
            )
        ],
    )

    totals = candidate._derived_declared_order_totals(
        [{"quantity": 300, "piece_count": 30}],
        evidence,
    )

    assert totals["declared_quantity"][0] == 300
    assert totals["declared_quantity"][1][0]["evidence_quote"] == "300"


def test_declared_totals_preserve_labeled_source_mismatches() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-envelope",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=8,
                height=3,
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[
                            ["型号", "数量", "金额"],
                            ["FC-20", "300", "11220"],
                            ["合计数量：", "299", "合计金额：", "11221"],
                        ],
                    )
                ],
            )
        ],
    )

    totals = candidate._derived_declared_order_totals(
        [
            {
                "quantity": 300,
                "amount_tax_excluded": 11220,
            }
        ],
        evidence,
    )

    assert totals["declared_quantity"][0] == 299
    assert totals["declared_amount"][0] == 11221


def test_purchase_authoritative_header_conflict_fails_closed() -> None:
    first = ExtractedFact(
        name="contract_number",
        value="HT-2026-001",
        evidence_refs=[_ref("p1:b1", "合同编号：HT-2026-001")],
    )
    second = ExtractedFact(
        name="contract_number",
        value="HT-2026-002",
        evidence_refs=[_ref("p1:b2", "合同编号：HT-2026-002")],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "purchase_contract",
            "document_subtype": "purchase_contract",
            "document_facts": [first, second],
            "segments": [],
            "primary_record_table_ids": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="contract-conflict",
        member_name="fixture.pdf",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    projected, names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="合同.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert "contract_number" not in names.values()
    assert projected["needs_review"] is True
    assert {issue["message"] for issue in projected["validation_issues"]} >= {
        "PURCHASE_AUTHORITATIVE_HEADER_CONFLICT:contract_number"
    }


def test_purchase_total_ignores_auxiliary_table() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="p1:t0",
                        rows=[
                            ["序号", "物料名称", "金额"],
                            ["1", "产品A", "1,200.00"],
                            ["合计金额", None, "1,200.00"],
                        ],
                    ),
                    EvidenceTable(
                        table_id="p1:t9",
                        rows=[
                            ["辅助统计", "金额"],
                            ["合计金额", "9,999.00"],
                        ],
                    ),
                ],
            )
        ],
    )
    extracted = _result().model_copy(
        update={
            "document_subtype": "purchase_contract",
            "document_facts": [],
            "segments": [],
            "primary_record_table_ids": ["p1:t0"],
            "raw_content_evidence": [],
            "unmapped_evidence": [],
        },
        deep=True,
    )

    headers = candidate._derived_purchase_headers(extracted, evidence)

    assert headers["total_amount"][0] == "1,200.00"


def test_stocking_headers_replace_weaker_duplicate_order_number() -> None:
    evidence = DocumentEvidence(
        backend="spreadsheet-native",
        backend_version="test",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="normalized",
                tables=[
                    EvidenceTable(
                        table_id="spreadsheet:s0",
                        rows=[
                            ["桐曦电子科技有限公司", None],
                            ["备货单", None],
                            [
                                "订单号码:\nTX2607110001",
                                "订单号:TX2607150002    下单日期:7月15日",
                            ],
                        ],
                    )
                ],
            )
        ],
    )
    false_total = ExtractedFact(
        name="order_number",
        value="7400",
        evidence_refs=[_ref("spreadsheet:s0:r9:c1", "7400")],
    )
    extracted = _result().model_copy(
        update={
            "document_intent": "stocking_order",
            "document_intent_family": "purchase_order",
            "document_subtype": "stocking_order",
            "document_facts": [false_total],
            "segments": [],
            "primary_record_table_ids": [],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=evidence,
        task_id="stocking-header",
        member_name="fixture.xlsx",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    projected, _names = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="备货单.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert projected["header"] == {
        "company": "桐曦电子科技有限公司",
        "document_title": "备货单",
        "order_date_raw": "7月15日",
        "order_number": "TX2607150002",
        "source_order_number": "TX2607110001",
    }
    assert "7400" not in projected["header"].values()


def test_auxiliary_table_facts_do_not_pollute_document_header() -> None:
    auxiliary_fact = ExtractedFact(
        name="company",
        value="TYPE C A",
        evidence_refs=[_ref("p1:t1:r0:c0", "TYPE C A")],
    )
    extracted = _result().model_copy(
        update={
            "document_facts": [],
            "primary_record_table_ids": ["p1:t0"],
            "segments": [
                *_result().segments,
                ExtractedSegment(
                    table_id="p1:t1",
                    segment_id="auxiliary-layout",
                    intent="metadata",
                    facts=[auxiliary_fact],
                ),
            ],
        },
        deep=True,
    )
    parsed = MinerUParseResult(
        evidence=_evidence(),
        task_id="task-auxiliary",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )

    record, _ = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="drawing.pdf",
        parsed=parsed,
        extracted=extracted,
    )

    assert "company" not in record["header"]
    auxiliary = next(
        item
        for item in record["extraction"]["record_sets"]
        if item["table_id"] == "p1:t1"
    )
    assert auxiliary["facts"][0]["value"] == "TYPE C A"


def test_projection_merges_adjacent_spreadsheet_column_continuations() -> None:
    pages = []
    segments = []
    for page_number, (source_range, table_id, field_name) in enumerate(
        [
            ("A1:B4", "p1:t0", "product_code"),
            ("C1:D4", "p2:t0", "quantity"),
        ],
        start=1,
    ):
        pages.append(
            EvidencePage(
                page_number=page_number,
                page_index=page_number - 1,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id=f"p{page_number}:b0",
                        kind="text",
                        text="Spreadsheet: Sheet1",
                    ),
                    EvidenceBlock(
                        block_id=f"p{page_number}:b1",
                        kind="text",
                        text=f"Source range: {source_range}",
                    ),
                ],
                tables=[EvidenceTable(table_id=table_id, rows=[["h"], ["v"]])],
            )
        )
        segments.append(
            ExtractedSegment(
                table_id=table_id,
                segment_id=f"segment-{page_number}",
                intent="records",
                records=[
                    ExtractedRecord(
                        fields=[
                            ExtractedFact(
                                name=field_name,
                                value=f"value-{index}",
                                evidence_refs=[
                                    _ref(
                                        f"{table_id}:r{index}:c0",
                                        f"value-{index}",
                                        page=page_number,
                                        source_row=index + 1,
                                    )
                                ],
                            )
                        ]
                    )
                    for index in (1, 2)
                ],
            )
        )
    parsed = MinerUParseResult(
        evidence=DocumentEvidence(backend="mineru", pages=pages),
        task_id="task-continuation",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )
    extracted = _result().model_copy(
        update={"document_facts": [], "segments": segments},
        deep=True,
    )

    record, _ = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="fixture.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert len(record["lines"]) == 2
    assert record["lines"][0] == {
        "product_code": "value-1",
        "quantity": "value-1",
    }
    assert record["extraction"]["metadata"]["spreadsheet_continuation_groups"] == [
        ["p1:t0", "p2:t0"]
    ]


def test_projection_refuses_misaligned_spreadsheet_column_continuations() -> None:
    pages = []
    segments = []
    for page_number, (source_range, table_id, field_name, source_rows) in enumerate(
        [
            ("A1:B4", "p1:t0", "product_code", [2, 3]),
            ("C1:D4", "p2:t0", "quantity", [None, 4]),
        ],
        start=1,
    ):
        pages.append(
            EvidencePage(
                page_number=page_number,
                page_index=page_number - 1,
                width=100,
                height=200,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id=f"p{page_number}:b0",
                        kind="text",
                        text="Spreadsheet: Sheet1",
                    ),
                    EvidenceBlock(
                        block_id=f"p{page_number}:b1",
                        kind="text",
                        text=f"Source range: {source_range}",
                    ),
                ],
                tables=[EvidenceTable(table_id=table_id, rows=[["h"], ["v"]])],
            )
        )
        segments.append(
            ExtractedSegment(
                table_id=table_id,
                segment_id=f"segment-{page_number}",
                intent="records",
                records=[
                    ExtractedRecord(
                        fields=[
                            ExtractedFact(
                                name=field_name,
                                value=f"value-{index}",
                                evidence_refs=[
                                    EvidenceReference(
                                        evidence_id=f"{table_id}:r{index}:c0",
                                        quote=f"value-{index}",
                                        source_ref=SourceReference(
                                            page=page_number,
                                            part=f"mineru/{table_id}:r{index}:c0",
                                            bbox=[1.0, 2.0, 3.0, 4.0],
                                            coordinate_space="normalized",
                                            source_row=source_row,
                                        ),
                                    )
                                ],
                            )
                        ],
                        record_axis=index,
                    )
                    for index, source_row in zip((1, 2), source_rows, strict=True)
                ],
            )
        )
    parsed = MinerUParseResult(
        evidence=DocumentEvidence(backend="mineru", pages=pages),
        task_id="task-misaligned-continuation",
        member_name="fixture_content_list_v2.json",
        content_list_v2=[],
        middle_json={},
        elapsed_ms=1,
    )
    extracted = _result().model_copy(
        update={"document_facts": [], "segments": segments},
        deep=True,
    )

    record, _ = candidate._benchmark_projection(
        source_sha256="0" * 64,
        original_filename="fixture.xlsx",
        parsed=parsed,
        extracted=extracted,
    )

    assert len(record["lines"]) == 4
    assert all(
        not ({"product_code", "quantity"} <= set(line))
        for line in record["lines"]
    )
    assert record["extraction"]["metadata"]["spreadsheet_continuation_groups"] == []
    assert "MINERU_INSTRUCTOR_CONTINUATION_RECORD_AXIS_CONFLICT" in {
        issue["code"] for issue in record["validation_issues"]
    }


def test_extra_body_must_be_a_json_object() -> None:
    assert candidate._extra_body(
        '{"chat_template_kwargs":{"enable_thinking":false}}'
    ) == {"chat_template_kwargs": {"enable_thinking": False}}
    with pytest.raises(candidate.argparse.ArgumentTypeError):
        candidate._extra_body("[]")
    with pytest.raises(candidate.argparse.ArgumentTypeError):
        candidate._extra_body("not-json")


def test_production_lines_project_domain_aliases_into_compatible_fields() -> None:
    source_ref = {
        "source_refs": [
            {
                "sheet": "Sheet1",
                "cell": "A2",
                "source_row": 2,
                "source_column": 1,
            }
        ],
        "confidence": 1.0,
    }
    record = {
        "document_type": "mold",
        "document_subtype": "mold_mapping",
        "lines": [
            {
                "mold_number": "MOLD-001",
                "mold_name": "Outer mold",
            }
        ],
        "field_meta": {
            "$.lines[0].mold_number": {
                **source_ref,
                "source_label": "mold_number",
            },
            "$.lines[0].mold_name": {
                **source_ref,
                "source_label": "mold_name",
            },
        },
    }

    populated = candidate._normalize_production_lines(record)

    assert record["lines"][0]["product_code"] == "MOLD-001"
    assert record["lines"][0]["name_raw"] == "Outer mold"
    assert record["lines"][0]["custom_fields"] == {}
    assert populated["product_code"] == 1
    assert populated["name_raw"] == 1


@pytest.mark.parametrize(
    "field",
    [
        "unit_price_tax_included",
        "amount_tax_included",
        "unit_price_tax_excluded",
        "amount_tax_excluded",
    ],
)
def test_canonical_tax_fields_are_not_reinterpreted_as_raw_labels(
    field: str,
) -> None:
    assert candidate._canonical_record_field_name(
        "purchase_contract",
        field,
        document_type="order",
    ) == field


def test_spreadsheet_evidence_preserves_physical_rows_and_cell_coordinates(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "rows.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "采购明细"
    sheet["A5"] = "序号"
    sheet["B5"] = "物料"
    for row in range(6, 117):
        sheet.cell(row=row, column=1, value=row - 5)
        sheet.cell(row=row, column=2, value=f"SKU-{row:03d}")
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    table = evidence.pages[0].tables[0]
    assert len(table.rows) == 112
    assert table.rows[24][1] == "SKU-029"
    assert table.rows[25][1] == "SKU-030"
    assert table.rows[71][1] == "SKU-076"
    assert table.rows[72][1] == "SKU-077"
    assert table.rows[102][1] == "SKU-107"
    assert table.rows[103][1] == "SKU-108"
    assert len(table.cells) == 224
    source_cell = next(
        cell for cell in table.cells if cell.model_extra.get("cell") == "B108"
    )
    assert source_cell.text == "SKU-108"
    assert source_cell.model_extra["sheet"] == "采购明细"
    assert source_cell.model_extra["source_row"] == 108


def test_spreadsheet_evidence_inherits_vertical_merges_only_in_anchor_column(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "merged-order.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["序号", "产品名称", "规格", "数量", "单位"])
    sheet.append([1, "DP 线", "1M", 100, "PCS"])
    sheet.append([2, None, "2M", 200, "PCS"])
    sheet.merge_cells("B2:B3")
    sheet.merge_cells("A5:E5")
    sheet["A5"] = "横向合并标题"
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    table = evidence.pages[0].tables[0]
    assert table.rows[1][1] == "DP 线"
    assert table.rows[2][1] == "DP 线"
    inherited = next(
        cell for cell in table.cells if cell.model_extra.get("cell") == "B3"
    )
    assert inherited.model_extra["inherited_from"] == "B2"
    assert inherited.model_extra["merged_range"] == "B2:B3"
    inventory = instructor_poc.evidence_inventory(evidence)
    inherited_item = next(
        item
        for item in inventory.values()
        if item.table_id == table.table_id and item.row == 2 and item.column == 1
    )
    assert inherited_item.source_ref.cell == "B2"
    assert inherited_item.source_ref.range == "B2:B3"
    assert inherited_item.source_ref.part == "spreadsheet/Sheet/B2"
    assert inherited_item.source_ref.model_extra["logical_cell"] == "B3"
    assert inherited_item.source_ref.model_extra["source_row"] == 3
    assert inherited_item.source_ref.model_extra["inherited_from_merge"] is True
    fact = ExtractedFact(
        name="product_name",
        value="DP 线",
        evidence_refs=[
            EvidenceReference(
                evidence_id=inherited_item.evidence_id,
                quote="DP 线",
                source_ref=inherited_item.source_ref,
            )
        ],
    )
    target: dict[str, object] = {}
    field_meta: dict[str, object] = {}
    candidate._place_fact(
        fact,
        target=target,
        path_prefix="$.lines[1]",
        field_meta=field_meta,
        field_names={},
    )
    assert field_meta["$.lines[1].product_name"]["inherited_from_merge"] is True
    assert table.rows[4][0] == "横向合并标题"
    assert all(value is None for value in table.rows[4][1:])


def test_spreadsheet_evidence_separates_parallel_logical_tables(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "并排模具.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["模号", "外模", None, "DP模具", None, None])
    sheet.append(["L-001", "左外模", None, "模型", None, "模号"])
    sheet.append(["L-002", "左内模", None, "右内模", "1/2", "R-001"])
    sheet.append([None, None, None, "右外模", "1/4", "R-002"])
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    assert len(evidence.pages[0].tables) == 2
    left, right = evidence.pages[0].tables
    assert left.rows == [
        ["模号", "外模"],
        ["L-001", "左外模"],
        ["L-002", "左内模"],
    ]
    assert right.rows == [
        ["模型", None, "模号"],
        ["右内模", "1/2", "R-001"],
        ["右外模", "1/4", "R-002"],
    ]
    assert {cell.model_extra["cell"] for cell in left.cells} == {
        "A1",
        "B1",
        "A2",
        "B2",
        "A3",
        "B3",
    }
    assert {cell.model_extra["cell"] for cell in right.cells} == {
        "D2",
        "F2",
        "D3",
        "E3",
        "F3",
        "D4",
        "E4",
        "F4",
    }
    assert [block.text for block in evidence.pages[0].blocks] == ["DP模具"]
    assert left.model_extra["native_record_layout"] == {
        "source": "spreadsheet-tabular-v1",
        "orientation": "rows",
        "header_axes": [0],
        "record_axes": [1, 2],
        "parallel_group": "spreadsheet:s0",
        "document_type": "mold",
        "document_subtype": "mold_mapping",
    }
    assert right.model_extra["native_record_layout"]["record_axes"] == [1, 2]
    assessment = assess_record_regions(evidence)
    assert assessment.status == "complete"
    assert [
        (
            region.table_id,
            region.orientation,
            region.data_start,
            region.data_end,
        )
        for region in assessment.record_regions
    ] == [
        ("spreadsheet:s0:region0", "rows", 1, 2),
        ("spreadsheet:s0:region1", "rows", 1, 2),
    ]
    issues: list[str] = []
    selected = instructor_poc._select_primary_record_table_ids(
        DocumentIntent(
            document_intent="mold",
            primary_record_table_ids=["spreadsheet:s0:region0"],
        ),
        {table.table_id: table for table in evidence.pages[0].tables},
        assessment,
        issues,
    )
    assert selected == ["spreadsheet:s0:region0", "spreadsheet:s0:region1"]
    assert issues == ["native_parallel_record_tables_applied"]
    classification = evidence.raw["native_classification"]
    assert classification["schema_version"] == "m1.native-classification.v1"
    assert classification["source"] == "spreadsheet-tabular-v1"
    assert classification["document_type"] == "mold"
    assert classification["document_subtype"] == "mold_mapping"
    assert classification["authority"] == "native_content"
    assert classification["confidence"] == 1.0
    assert [item["source_ref"]["cell"] for item in classification["evidence"]] == [
        "A1",
        "D1",
    ]
    assert [item["quote"] for item in classification["evidence"]] == [
        "模号",
        "DP模具",
    ]
    assert classification["filename_advisory"][0]["source_ref"] == {
        "part": "source.original_filename",
        "authority": "advisory",
    }


def test_spreadsheet_filename_only_classification_remains_advisory(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "采购入库.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["普通说明", "无采购台账表头"])
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    classification = evidence.raw["native_classification"]
    assert classification["document_subtype"] == "purchase_receipt_ledger"
    assert classification["authority"] == "advisory"
    assert classification["evidence"] == []
    assert classification["filename_advisory"]
    assert instructor_poc._trusted_native_classification(evidence) == (None, None)


def test_spreadsheet_evidence_separates_sequential_repeated_tables(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "重复分段.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["序号", "物料编号", "物料名称", "实际用量", "单位"])
    sheet.append([1, "MAT-1", "铜线", 2, "M"])
    sheet.append([])
    sheet.append(["序号", "物料编号", "物料名称", "实际用量", "单位"])
    sheet.append([1, "MAT-2", "铝箔", 1, "M"])
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    assert [table.rows for table in evidence.pages[0].tables] == [
        [
            ["序号", "物料编号", "物料名称", "实际用量", "单位"],
            ["1", "MAT-1", "铜线", "2", "M"],
        ],
        [
            ["序号", "物料编号", "物料名称", "实际用量", "单位"],
            ["1", "MAT-2", "铝箔", "1", "M"],
        ],
    ]
    assert [
        table.model_extra["native_record_layout"]["record_axes"]
        for table in evidence.pages[0].tables
    ] == [[1], [1]]
    assert {
        cell.model_extra["cell"]
        for table in evidence.pages[0].tables
        for cell in table.cells
    } == {"A1", "B1", "C1", "D1", "E1", "A2", "B2", "C2", "D2", "E2", "A4", "B4", "C4", "D4", "E4", "A5", "B5", "C5", "D5", "E5"}


def test_headerless_bom_uses_physical_rows_without_inventing_headers(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "BOM成本分析.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["PRODUCT-A", "MAT-1", "铜线", 2, "M", 1.25])
    sheet.append([None, "MAT-2", "铝箔", 1, "M", 0.5])
    sheet.append(["合计", None, None, 3, None, 1.75])
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    table = evidence.pages[0].tables[0]
    assert table.model_extra["native_record_layout"] == {
        "source": "spreadsheet-tabular-v1",
        "orientation": "rows",
        "header_axes": [],
        "record_axes": [0, 1],
        "document_type": "technical_document",
        "document_subtype": "bill_of_materials",
    }
    assessment = assess_record_regions(evidence)
    assert assessment.status == "complete"
    assert [
        (region.orientation, region.data_start, region.data_end)
        for region in assessment.record_regions
    ] == [("rows", 0, 1)]


def test_spreadsheet_evidence_locks_one_known_table_to_its_business_rows(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "equipment.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["Example Company"])
    sheet.append(["Equipment register"])
    sheet.append(["序号", "设备名称", "设备型号", "数量", "单位", "设备状况"])
    sheet.append([1, "Tester", "T-1", 2, "台", "正常运行"])
    sheet.append([2, "Caliper", None, 1, "把", "正常运行"])
    sheet.append([None, None, None, 3])
    sheet.append([3])
    sheet.append([])
    sheet.append([None, None, "制定日期：2026/8/2", None, "制定：", "User"])
    workbook.save(source)
    workbook.close()

    evidence = candidate._spreadsheet_document_evidence(
        source,
        original_filename=source.name,
    )

    assert evidence is not None
    table = evidence.pages[0].tables[0]
    assert table.model_extra["native_record_layout"] == {
        "source": "spreadsheet-tabular-v1",
        "orientation": "rows",
        "header_axes": [2],
        "record_axes": [3, 4],
        "document_type": "equipment",
        "document_subtype": "equipment_register",
    }
    assessment = assess_record_regions(evidence)
    assert assessment.status == "complete"
    assert [
        (region.orientation, region.data_start, region.data_end)
        for region in assessment.record_regions
    ] == [("rows", 3, 4)]


def test_mineru_transport_defaults_to_tasks_api() -> None:
    args = candidate._parser().parse_args(["sample.pdf"])

    assert args.mineru_transport == "tasks-api"


def test_visual_asset_enrichment_defaults_to_disabled_and_bounded() -> None:
    args = candidate._parser().parse_args(["sample.pdf"])

    assert args.visual_assets_enabled is False
    assert args.visual_assets_max == 8
    assert args.visual_asset_max_bytes == 10 * 1024 * 1024
    assert args.visual_asset_timeout_seconds == 180.0

    configured = candidate._parser().parse_args(
        [
            "sample.pdf",
            "--visual-assets-enabled",
            "--visual-assets-max",
            "3",
            "--visual-asset-max-bytes",
            "2048",
            "--visual-asset-timeout-seconds",
            "7.5",
        ]
    )
    assert configured.visual_assets_enabled is True
    assert configured.visual_assets_max == 3
    assert configured.visual_asset_max_bytes == 2048
    assert configured.visual_asset_timeout_seconds == 7.5


def test_cli_rejects_visual_enrichment_with_cached_document_evidence(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        candidate.sys,
        "argv",
        [
            str(SCRIPT_PATH),
            "sample.pdf",
            "--visual-assets-enabled",
            "--mineru-content-list-v2",
            "content.json",
            "--mineru-middle-json",
            "middle.json",
        ],
    )

    with pytest.raises(SystemExit, match="requires a live MinerU transport"):
        candidate.main()


@pytest.mark.asyncio
async def test_visual_assets_are_enriched_before_semantic_extraction(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    source_sha256 = hashlib.sha256(source.read_bytes()).hexdigest()
    asset_sha256 = hashlib.sha256(b"embedded-image").hexdigest()
    inventory = SourceAssetInventory(
        source_kind="pdf",
        source_name=source.name,
        source_sha256=source_sha256,
        source_byte_size=source.stat().st_size,
        assets=[
            SourceAsset(
                asset_id=f"asset:sha256:{asset_sha256}",
                sha256=asset_sha256,
                mime_type="image/png",
                byte_size=len(b"embedded-image"),
                parts=["pdf:xref:1"],
                coverage_status="inventoried_unreferenced",
            )
        ],
        coverage_status="complete",
    )
    monkeypatch.setattr(
        candidate,
        "inventory_source_assets",
        lambda _path: inventory,
    )
    captured: dict[str, object] = {}

    async def enrich(
        source_path,
        evidence,
        received_inventory,
        parser,
        **limits,
    ):
        captured.update(
            source_path=source_path,
            inventory=received_inventory,
            parser=parser,
            limits=limits,
        )
        result = evidence.model_copy(deep=True)
        result.pages.append(
            EvidencePage(
                page_number=2,
                page_index=1,
                width=20,
                height=20,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id=f"asset:{asset_sha256}/p0/b0",
                        kind="text",
                        text="VISUAL-ASSET-TEXT",
                    )
                ],
            )
        )
        result.raw["source_asset_inventory"] = inventory.model_dump(mode="json")
        result.raw["visual_asset_enrichment"] = {
            "success_count": 1,
            "failed_count": 0,
            "skipped_count": 0,
            "assets": [{"asset_sha256": asset_sha256, "status": "success"}],
        }
        return result

    monkeypatch.setattr(candidate, "enrich_visual_asset_evidence", enrich)
    mineru = _MinerU()
    extractor = _Extractor()

    payload = await candidate.run_candidate(
        source,
        mineru=mineru,
        extractor=extractor,
        visual_assets_enabled=True,
        visual_assets_max=3,
        visual_asset_max_bytes=2048,
        visual_asset_timeout_seconds=7.5,
    )

    assert captured == {
        "source_path": source.resolve(),
        "inventory": inventory,
        "parser": mineru,
        "limits": {
            "max_assets": 3,
            "max_asset_bytes": 2048,
            "timeout_seconds": 7.5,
            "concurrency": 1,
        },
    }
    assert extractor.seen[0].pages[1].blocks[0].text == "VISUAL-ASSET-TEXT"
    assert payload["source_asset_inventory"]["analyzed_asset_count"] == 1
    assert payload["source_asset_inventory"]["analyzed_count"] == 1
    assert payload["visual_asset_enrichment"]["success_count"] == 1
    assert (
        payload["record"]["extraction"]["metadata"]["source_asset_analysis_ratio"]
        == 1.0
    )


@pytest.mark.asyncio
async def test_full_runner_uses_instructor_visual_and_drawing_pipeline(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "specification.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    source_sha256 = hashlib.sha256(source.read_bytes()).hexdigest()
    asset_sha256 = hashlib.sha256(b"embedded-image").hexdigest()
    inventory = SourceAssetInventory(
        source_kind="pdf",
        source_name=source.name,
        source_sha256=source_sha256,
        source_byte_size=source.stat().st_size,
        assets=[
            SourceAsset(
                asset_id=f"asset:sha256:{asset_sha256}",
                sha256=asset_sha256,
                mime_type="image/png",
                byte_size=len(b"embedded-image"),
                parts=["pdf:xref:1"],
                coverage_status="inventoried_unreferenced",
            )
        ],
        coverage_status="complete",
    )
    monkeypatch.setattr(candidate, "inventory_source_assets", lambda _path: inventory)
    stages: list[str] = []

    async def enrich(_source, evidence, _inventory, _parser, **_limits):
        stages.append("visual")
        result = evidence.model_copy(deep=True)
        result.pages.append(
            EvidencePage(
                page_number=2,
                page_index=1,
                width=20,
                height=20,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id=f"asset:{asset_sha256}/p0/b0",
                        kind="text",
                        text="VISUAL-PRODUCTION-EVIDENCE",
                    )
                ],
            )
        )
        result.raw["visual_asset_enrichment"] = {
            "success_count": 1,
            "failed_count": 0,
            "skipped_count": 0,
            "assets": [{"asset_sha256": asset_sha256, "status": "success"}],
        }
        return result

    async def drawing(*_args, **_kwargs):
        stages.append("drawing")
        return [], {
            "schema_version": "m1.drawing-region-vlm-sidecar.v1",
            "status": "completed",
            "fact_count": 0,
            "needs_review": False,
            "issues": [],
            "assets": [],
        }

    monkeypatch.setattr(candidate, "enrich_visual_asset_evidence", enrich)
    monkeypatch.setattr(candidate, "_drawing_region_vlm_sidecar", drawing)

    class Parser:
        timeout_seconds = 10.0
        model_revision = "mineru-model"

        async def parse(self, _path, *, original_filename=None):
            del original_filename
            return MinerUParseResult(
                evidence=DocumentEvidence(
                    backend="mineru:fixture",
                    backend_version="3.4.4",
                    pages=[
                        EvidencePage(
                            page_number=1,
                            page_index=0,
                            width=100,
                            height=100,
                            coordinate_space="normalized",
                            blocks=[
                                EvidenceBlock(
                                    block_id="p1:b0",
                                    text="Product specification",
                                )
                            ],
                        )
                    ],
                ),
                task_id="mineru-provider-task",
                member_name="specification_content_list_v2.json",
                content_list_v2=[],
                middle_json={},
                elapsed_ms=5.0,
            )

        async def close(self):
            return None

        def status(self):
            return {"ready": True}

    class Extractor:
        def __init__(self) -> None:
            self.seen_visual = False

        async def extract(self, evidence):
            stages.append("instructor")
            self.seen_visual = any(
                block.text == "VISUAL-PRODUCTION-EVIDENCE"
                for page in evidence.pages
                for block in page.blocks
            )
            return MinerUInstructorResult(
                document_intent="product_specification",
                document_intent_family="technical_document",
                document_subtype="product_specification",
                document_facts=[
                    ExtractedFact(
                        name="title",
                        value="Product specification",
                        evidence_refs=[_ref("p1:b0", "Product specification")],
                    )
                ],
                generic_facts=[
                    ExtractedFact(
                        name="retention_policy",
                        value="Product specification",
                        evidence_refs=[_ref("p1:b0", "Product specification")],
                        sensitive=True,
                    )
                ],
                issues=["unmapped_supported_fact:retention_policy"],
                complete=True,
                semantic_complete=True,
                accounted_complete=True,
                retained_complete=True,
                total_evidence_count=2,
                mapped_evidence_count=2,
                schema_evidence_count=0,
                redundant_evidence_count=0,
                raw_content_evidence_count=2,
                unresolved_evidence_count=0,
                retained_evidence_count=2,
                unmapped_evidence_count=0,
                evidence_coverage_ratio=1.0,
                semantic_accounting_ratio=1.0,
                evidence_accounting_ratio=1.0,
                retained_evidence_ratio=1.0,
                intent_calls=1,
                segment_calls=0,
            )

        async def close(self):
            return None

    class Drawing:
        async def close(self):
            return None

    parser = Parser()
    extractor = Extractor()
    service = candidate.MinerUInstructorService(
        mineru=parser,
        extractor=extractor,
        visual_assets_enabled=True,
        drawing_region_vlm_enabled=True,
        drawing_region_vlm_extractor=Drawing(),
        total_timeout_seconds=10.0,
    )
    runner = MinerUShadowRunner(
        client=parser,
        instructor_service=service,
        output_dir=tmp_path / "shadow",
        authority_mode="full",
    )

    result = await runner.run_candidate(
        task_id="m1-task-id",
        path=source,
        original_filename="specification.pdf",
        file_type="pdf",
        authoritative={},
    )
    decision = evaluate_mineru_authority(
        result.document,
        result.summary,
        authority_mode="full",
    )

    assert stages == ["visual", "instructor", "drawing"]
    assert extractor.seen_visual is True
    assert result.document.schema_version == "m1.document.v2"
    assert result.summary["task_id"] == "m1-task-id"
    assert result.summary["mineru_task_id"] == "mineru-provider-task"
    assert result.summary["candidate_isolation"] is False
    assert result.summary["visual_asset_enrichment"]["success_count"] == 1
    assert result.summary["drawing_region_vlm"]["status"] == "completed"
    assert result.summary["mapper_invalid_facts"] == 0
    assert result.document.document_kind_label == "product_specification"
    assert result.document.generic_facts[0].name == "retention_policy"
    assert result.document.generic_facts[0].sensitive is True
    generic_meta = result.document.field_meta["$.generic_facts[0].value"]
    assert generic_meta.source_refs[0].model_extra["evidence_id"] == "p1:b0"
    assert generic_meta.model_extra["sensitive"] is True
    assert generic_meta.inferred is False
    assert "$.document_kind_label" in result.document.field_meta
    generic_issue = next(
        issue
        for issue in result.document.validation_issues
        if issue.code == "MINERU_INSTRUCTOR_UNMAPPED_SUPPORTED_FACT"
    )
    assert generic_issue.severity == "info"
    classification_ref = result.document.field_meta["$.document_type"].source_refs[0]
    assert classification_ref.model_extra is not None
    assert classification_ref.model_extra["evidence_id"] == "p1:b0"
    assert classification_ref.model_extra["evidence_quote"] == ("Product specification")
    assert decision.accepted is True
    await runner.close()


def test_full_gate_accepts_complete_split_416_row_region() -> None:
    rows = [["code", "quantity", "unit"]] + [
        [f"SKU-{index:03d}", str(index + 1), "PCS"] for index in range(416)
    ]
    table = EvidenceTable(
        table_id="p1:t0",
        rows=rows,
        cells=[
            EvidenceCell(row=row, column=column, text=value)
            for row, values in enumerate(rows)
            for column, value in enumerate(values)
        ],
    )
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=100,
        height=100,
        coordinate_space="normalized",
        tables=[table],
    )
    evidence = DocumentEvidence(backend="fixture", pages=[page])
    assessment = assess_record_regions(evidence)
    assert assessment.status == "complete"
    assert [(item.data_start, item.data_end) for item in assessment.record_regions] == [
        (1, 416)
    ]
    positioned_ref = SourceReference(
        page=1,
        part="mineru/p1:t0",
        bbox=[0.0, 0.0, 10.0, 10.0],
        coordinate_space="normalized",
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename="large-table.pdf", sha256="a" * 64),
        document_type="technical_document",
        document_subtype="product_specification",
        field_meta={
            "$.document_type": FieldMetadata(
                source_refs=[positioned_ref], inferred=True
            ),
            "$.document_subtype": FieldMetadata(
                source_refs=[positioned_ref], inferred=True
            ),
        },
        extraction={
            "metadata": {
                "adapter": "mineru_instructor",
                "evidence_complete": True,
            },
            "raw_content": {
                "text_original": "large product specification table",
                "pages": [page.model_dump(mode="json")],
            }
        },
    )
    boundaries = [(1, 100), (101, 200), (201, 300), (301, 400), (401, 416)]
    segments = []
    for start, end in boundaries:
        records = [
            ExtractedRecord(
                fields=[
                    ExtractedFact(
                        name="product_code",
                        value=f"SKU-{axis - 1:03d}",
                        evidence_refs=[
                            _ref(
                                f"p1:t0:r{axis}:c0",
                                f"SKU-{axis - 1:03d}",
                            )
                        ],
                    )
                ]
            )
            for axis in range(start, end + 1)
        ]
        segments.append(
            ExtractedSegment(
                table_id="p1:t0",
                segment_id=candidate._instructor_segment_id(
                    "p1:t0", "rows", start, end
                ),
                intent="records",
                orientation="rows",
                start=start,
                end=end,
                records=records,
            ).model_dump(mode="json")
        )

    region_summary = candidate._record_region_summary(
        document,
        {"segments": segments},
    )
    summary = {
        "status": "completed",
        "pipeline": "mineru_instructor",
        "instructor_complete": True,
        "candidate_isolation": False,
        "rejected_citations": 0,
        "mapper_unresolved_dropped_mappings": 0,
        "mapper_unresolved_dropped_tables": 0,
        "mapper_invalid_facts": 0,
        "record_region_assessment": region_summary,
    }
    accepted = evaluate_mineru_authority(
        document,
        summary,
        authority_mode="full",
    )

    assert region_summary["mapped_region_ids"] == [
        assessment.record_regions[0].region_id
    ]
    assert len(region_summary["mapped_region_bindings"]) == 1
    assert accepted.accepted is True

    missing_chunk_summary = candidate._record_region_summary(
        document,
        {"segments": [*segments[:2], *segments[3:]]},
    )
    rejected = evaluate_mineru_authority(
        document,
        {**summary, "record_region_assessment": missing_chunk_summary},
        authority_mode="full",
    )
    assert missing_chunk_summary["unmapped_region_ids"] == [
        assessment.record_regions[0].region_id
    ]
    assert "unmapped_record_regions" in rejected.reasons


def test_open_domain_generic_records_satisfy_record_region_replay() -> None:
    table = EvidenceTable(
        table_id="p1:bom",
        rows=[
            ["材料编号", "原材料名称"],
            ["MAT-1", "铜线"],
            ["MAT-2", "铝箔"],
        ],
        cells=[
            EvidenceCell(row=row, column=column, text=value)
            for row, values in enumerate(
                [
                    ["材料编号", "原材料名称"],
                    ["MAT-1", "铜线"],
                    ["MAT-2", "铝箔"],
                ]
            )
            for column, value in enumerate(values)
        ],
        source="spreadsheet-envelope",
        native_record_layout={
            "source": "spreadsheet-tabular-v1",
            "orientation": "rows",
            "header_axes": [0],
            "record_axes": [1, 2],
        },
    )
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=2,
        height=3,
        coordinate_space="unknown",
        tables=[table],
    )
    assessment = assess_record_regions(
        DocumentEvidence(
            backend="spreadsheet-envelope",
            backend_version="1",
            pages=[page],
        )
    )
    document = DocumentRecord(
        source=DocumentSource(original_filename="bom.xlsx", sha256="a" * 64),
        document_type="technical_document",
        document_subtype="bill_of_materials",
        generic_facts=[
            {
                "name": "table_record",
                "value": {"材料编号": code, "原材料名称": name},
                "table_id": table.table_id,
                "row_index": row_index,
            }
            for row_index, (code, name) in enumerate(
                [("MAT-1", "铜线"), ("MAT-2", "铝箔")],
                start=1,
            )
        ],
        extraction={
            "raw_content": {"pages": [page.model_dump(mode="json")]},
        },
    )

    summary = candidate._record_region_summary(document, {"segments": []})

    assert summary["mapped_region_ids"] == [
        assessment.record_regions[0].region_id
    ]
    assert summary["unmapped_region_ids"] == []
    assert summary["generic_record_table_ids"] == [table.table_id]
    assert summary["generic_projection_authoritative"] is True


def test_full_gate_replays_docx_native_cells_and_rejects_incomplete_instructor() -> (
    None
):
    table = EvidenceTable(
        table_id="docx:t:0",
        rows=[["产品名称"], ["HDMI铝壳"]],
        cells=[
            EvidenceCell(row=0, column=0, text="产品名称"),
            EvidenceCell(row=1, column=0, text="HDMI铝壳"),
        ],
        source="docx-native-ooxml",
    )
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=1,
        height=1,
        coordinate_space="unknown",
        tables=[table],
    )
    evidence = DocumentEvidence(backend="docx-native-ooxml", pages=[page])
    assessment = assess_record_regions(evidence)
    source_ref = SourceReference(
        page=1,
        part="mineru/docx:t:0/r1/c0",
        evidence_id="docx:t:0:r1:c0",
        evidence_quote="HDMI铝壳",
    )
    document = DocumentRecord(
        source=DocumentSource(
            original_filename="50391承认书.docx",
            sha256="a" * 64,
        ),
        document_type="technical_document",
        document_subtype="product_specification",
        lines=[{"line_id": "line-1", "name_raw": "HDMI铝壳"}],
        field_meta={
            path: FieldMetadata(
                source_refs=[source_ref.model_copy(deep=True)],
                inferred=True,
            )
            for path in (
                "$.document_type",
                "$.document_subtype",
                "$.lines[0].name_raw",
            )
        },
        extraction={
            "metadata": {
                "adapter": "mineru_instructor",
                "evidence_complete": True,
            },
            "raw_content": {
                "text_original": "产品名称 HDMI铝壳",
                "pages": [page.model_dump(mode="json")],
            },
        },
    )
    segments = [
        {
            "table_id": region.table_id,
            "segment_id": candidate._instructor_segment_id(
                region.table_id,
                region.orientation,
                region.data_start,
                region.data_end,
            ),
            "intent": "records",
            "orientation": region.orientation,
            "start": region.data_start,
            "end": region.data_end,
            "records": [{} for _ in range(region.data_end - region.data_start + 1)],
        }
        for region in assessment.record_regions
    ]
    summary = {
        "status": "completed",
        "pipeline": "mineru_instructor",
        "instructor_complete": True,
        "rejected_citations": 0,
        "mapper_unresolved_dropped_mappings": 0,
        "mapper_unresolved_dropped_tables": 0,
        "mapper_invalid_facts": 0,
        "record_region_assessment": candidate._record_region_summary(
            document,
            {"segments": segments},
        ),
    }

    accepted = evaluate_mineru_authority(
        document,
        summary,
        authority_mode="full",
    )
    incomplete = evaluate_mineru_authority(
        document,
        {**summary, "instructor_complete": False},
        authority_mode="full",
    )
    wrong_pipeline = evaluate_mineru_authority(
        document,
        {**summary, "pipeline": "mineru_business_mapper"},
        authority_mode="full",
    )
    tampered = document.model_copy(deep=True)
    tampered_ref = tampered.field_meta["$.lines[0].name_raw"].source_refs[0]
    assert tampered_ref.model_extra is not None
    tampered_ref.model_extra["evidence_quote"] = "不存在的值"
    unsupported = evaluate_mineru_authority(
        tampered,
        summary,
        authority_mode="full",
    )

    assert accepted.accepted is True
    assert "instructor_incomplete" in incomplete.reasons
    assert "unexpected_candidate_pipeline" in wrong_pipeline.reasons
    assert unsupported.missing_source_paths == ("$.lines[0].name_raw",)


@pytest.mark.asyncio
async def test_full_runner_builder_wires_and_closes_production_clients(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: dict[str, object] = {}

    class Client:
        def __init__(self, **kwargs) -> None:
            calls["mineru"] = kwargs
            self.backend_version = kwargs["backend_version"]
            self.model_revision = kwargs["model_revision"]
            self.timeout_seconds = kwargs["timeout_seconds"]
            self.closed = False

        async def probe(self):
            return {
                "status": "healthy",
                "version": self.backend_version,
                "protocol_version": 2,
            }

        def status(self):
            return {"ready": not self.closed}

        async def close(self):
            self.closed = True

    class Extractor:
        def __init__(self) -> None:
            self.probed = False
            self.closed = False

        async def probe(self):
            self.probed = True
            return {"ready": True, "model": "mapper-model"}

        async def close(self):
            self.closed = True

    class Drawing:
        def __init__(self) -> None:
            self.probed = False
            self.closed = False

        async def probe(self):
            self.probed = True
            return {"ready": True, "model": "vision-model"}

        async def aclose(self):
            self.closed = True

    extractor = Extractor()
    drawing = Drawing()

    def build_extractor(**kwargs):
        calls["instructor"] = kwargs
        return extractor

    def build_drawing(**kwargs):
        calls["drawing"] = kwargs
        return drawing

    monkeypatch.setattr(
        "m1.documents.parsing.mineru_shadow.MinerUClient",
        Client,
    )
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_instructor_poc."
        "MinerUInstructorExtractor.from_openai",
        build_extractor,
    )
    monkeypatch.setattr(
        "m1.documents.parsing.drawing_region_vlm.DrawingRegionVLMExtractor.from_openai",
        build_drawing,
    )
    settings = SimpleNamespace(
        mineru_shadow_enabled=True,
        mineru_shadow_required=True,
        mineru_authority_mode="full",
        mineru_base_url="http://mineru:8000",
        mineru_backend="vlm-engine",
        mineru_effort="high",
        mineru_language="ch",
        mineru_image_analysis=True,
        mineru_timeout_seconds=240.0,
        mineru_poll_interval_seconds=1.0,
        mineru_max_pages=200,
        mineru_max_archive_bytes=64 * 1024 * 1024,
        mineru_max_uncompressed_bytes=128 * 1024 * 1024,
        mineru_version="3.4.4",
        mineru_model_revision="mineru-revision",
        mineru_mapper_base_url="http://mapper:8000/v1",
        mineru_mapper_api_key="mapper-key",
        mineru_mapper_model="mapper-model",
        mineru_mapper_timeout_seconds=45.0,
        mineru_mapper_max_tokens=8192,
        mineru_instructor_max_input_chars=90_000,
        mineru_instructor_segment_max_input_chars=70_000,
        mineru_instructor_max_retries=1,
        mineru_visual_assets_enabled=True,
        mineru_visual_assets_max=6,
        mineru_visual_asset_max_bytes=4096,
        mineru_visual_asset_timeout_seconds=123.0,
        mineru_drawing_region_vlm_enabled=True,
        mineru_drawing_region_vlm_base_url="http://drawing:8000/v1",
        mineru_drawing_region_vlm_api_key="drawing-key",
        mineru_drawing_region_vlm_model="drawing-model",
        mineru_drawing_region_vlm_max_regions=12,
        mineru_drawing_region_vlm_request_timeout_seconds=17.0,
        mineru_drawing_region_vlm_asset_timeout_seconds=91.0,
        mineru_full_timeout_seconds=777.0,
        vlm_base_url="http://vision:8000/v1",
        vlm_api_key="vision-key",
        vlm_model="vision-model",
        paddleocr_vl_model_root="C:/models/paddlex",
        pp_structure_device="gpu:0",
        mineru_shadow_output_dir=str(tmp_path / "shadow"),
        mineru_max_concurrency=1,
        mineru_shadow_max_pending=4,
        mineru_shadow_artifact_retention_seconds=60,
        mineru_shadow_artifact_max_bytes=1024 * 1024,
    )

    field_router = object()
    field_registry = object()
    runner = build_mineru_shadow_runner(
        settings,
        field_semantic_router=field_router,
        field_semantic_registry=field_registry,
    )
    assert runner is not None
    assert runner.mapper is None
    assert runner.instructor_service is not None
    assert runner.instructor_service.field_semantic_router is field_router
    assert runner.instructor_service.field_semantic_registry is field_registry
    assert runner.instructor_service.visual_assets_enabled is True
    assert runner.instructor_service.visual_assets_max == 6
    assert runner.instructor_service.visual_asset_max_bytes == 4096
    assert runner.instructor_service.visual_asset_timeout_seconds == 123.0
    assert runner.instructor_service.drawing_region_vlm_enabled is True
    assert runner.instructor_service.drawing_region_vlm_max_regions == 12
    assert runner.instructor_service.drawing_region_vlm_timeout_seconds == 91.0
    assert runner.instructor_service.total_timeout_seconds == 777.0
    assert calls["instructor"] == {
        "base_url": "http://mapper:8000/v1",
        "api_key": "mapper-key",
        "model": "mapper-model",
        "timeout": 45.0,
        "temperature": 0.0,
        "max_tokens": 8192,
        "max_input_chars": 90_000,
        "max_segment_input_chars": 70_000,
        "max_retries": 1,
        "extra_body": {},
        "compact_intent": True,
        "output_mode": "prompted",
    }
    drawing_args = calls["drawing"]
    assert isinstance(drawing_args, dict)
    assert drawing_args["base_url"] == "http://drawing:8000/v1"
    assert drawing_args["api_key"] == "drawing-key"
    assert drawing_args["model"] == "drawing-model"
    assert drawing_args["paddle_model_root"] == "C:/models/paddlex"
    assert drawing_args["device"] == "gpu:0"
    assert drawing_args["config"].max_candidates == 12
    assert drawing_args["config"].request_timeout_seconds == 17.0

    health = await runner.probe()
    assert health["ready"] is True
    assert runner.status()["candidate_pipeline"] == "mineru_instructor"
    assert runner.status()["mapper"]["model"] == "mapper-model"
    assert extractor.probed is True
    assert drawing.probed is True

    await runner.close()
    assert runner.client.closed is True
    assert extractor.closed is True
    assert drawing.closed is True


@pytest.mark.asyncio
async def test_production_service_total_timeout_cancels_complete_pipeline(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "timeout.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    cancelled = asyncio.Event()

    async def hanging_candidate(*_args, **_kwargs):
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            cancelled.set()
            raise

    monkeypatch.setattr(candidate, "run_candidate", hanging_candidate)
    service = candidate.MinerUInstructorService(
        mineru=object(),
        extractor=object(),
        visual_assets_enabled=False,
        drawing_region_vlm_enabled=False,
        total_timeout_seconds=0.01,
    )

    with pytest.raises(TimeoutError):
        await service.run(source)

    assert cancelled.is_set()


@pytest.mark.asyncio
async def test_vlm_http_client_invokes_mineru_cli_and_cleans_outputs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "input.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    executable = tmp_path / "mineru.exe"
    calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    output_roots: list[Path] = []

    class CompletedProcess:
        returncode = 0

        async def communicate(self):
            return b"completed", b""

        async def wait(self):
            return self.returncode

        def kill(self):
            raise AssertionError("completed process must not be killed")

    async def create_subprocess_exec(*command, **kwargs):
        calls.append((command, kwargs))
        output_root = Path(command[command.index("-o") + 1])
        output_roots.append(output_root)
        result_dir = output_root / "input" / "vlm"
        result_dir.mkdir(parents=True)
        (result_dir / "input_content_list_v2.json").write_text(
            json.dumps(
                [
                    [
                        {
                            "type": "text",
                            "bbox": [0, 0, 1000, 1000],
                            "content": {"content": "Cable"},
                        }
                    ]
                ]
            ),
            encoding="utf-8",
        )
        (result_dir / "input_middle.json").write_text(
            json.dumps(
                {
                    "_version_name": "3.4.4",
                    "_backend": "vlm",
                    "pdf_info": [{"page_size": [100, 200]}],
                }
            ),
            encoding="utf-8",
        )
        return CompletedProcess()

    monkeypatch.setattr(
        candidate.asyncio,
        "create_subprocess_exec",
        create_subprocess_exec,
    )
    parser = candidate._MinerUVLMHTTPClientParser(
        base_url="http://127.0.0.1:30000/",
        timeout_seconds=5,
        backend_version="3.4.4",
        model_revision="revision-1",
        executable=executable,
    )

    parsed = await parser.parse(source)

    command, kwargs = calls[0]
    output_root = output_roots[0]
    assert command == (
        str(executable.resolve()),
        "-p",
        str(source.resolve()),
        "-o",
        str(output_root),
        "-b",
        "vlm-http-client",
        "-u",
        "http://127.0.0.1:30000",
        "-t",
        "true",
        "--image-analysis",
        "true",
        "--client-side-output-generation",
        "true",
        "--max-concurrency",
        "1",
    )
    assert kwargs["stdout"] is not candidate.asyncio.subprocess.PIPE
    assert hasattr(kwargs["stdout"], "write")
    assert kwargs["stderr"] == candidate.subprocess.STDOUT
    assert kwargs["stdin"] == candidate.subprocess.DEVNULL
    assert kwargs["env"]["MINERU_API_MAX_CONCURRENT_REQUESTS"] == "1"
    assert kwargs["env"]["MINERU_PDF_RENDER_THREADS"] == "1"
    if sys.platform == "win32":
        assert kwargs["creationflags"] & candidate.subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        assert kwargs["start_new_session"] is True
    assert parsed.evidence.backend == "mineru:vlm-http-client"
    assert parsed.evidence.pages[0].blocks[0].text == "Cable"
    assert parsed.task_id.startswith("cli-")
    assert not output_root.exists()


@pytest.mark.asyncio
async def test_vlm_http_client_batches_inputs_once_and_isolates_missing_output(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first = tmp_path / "first.png"
    second = tmp_path / "second.png"
    first.write_bytes(b"first-image")
    second.write_bytes(b"second-image")
    executable = tmp_path / "mineru.exe"
    calls: list[tuple[tuple[object, ...], dict[str, object]]] = []
    temporary_roots: list[Path] = []

    class CompletedProcess:
        returncode = 0

        async def communicate(self):
            return b"completed", b""

        async def wait(self):
            return self.returncode

        def kill(self):
            raise AssertionError("completed process must not be killed")

    async def create_subprocess_exec(*command, **kwargs):
        calls.append((command, kwargs))
        input_root = Path(command[command.index("-p") + 1])
        output_root = Path(command[command.index("-o") + 1])
        temporary_roots.extend([input_root, output_root])
        inputs = sorted(path for path in input_root.iterdir() if path.is_file())
        assert len(inputs) == 2
        stem = inputs[0].stem
        result_dir = output_root / stem / "vlm"
        result_dir.mkdir(parents=True)
        (result_dir / f"{stem}_content_list_v2.json").write_text(
            json.dumps([[{"type": "text", "content": {"content": "first"}}]]),
            encoding="utf-8",
        )
        (result_dir / f"{stem}_middle.json").write_text(
            json.dumps(
                {
                    "_version_name": "3.4.4",
                    "_backend": "vlm",
                    "pdf_info": [{"page_size": [10, 10]}],
                }
            ),
            encoding="utf-8",
        )
        return CompletedProcess()

    monkeypatch.setattr(
        candidate.asyncio,
        "create_subprocess_exec",
        create_subprocess_exec,
    )
    parser = candidate._MinerUVLMHTTPClientParser(
        base_url="http://127.0.0.1:30000",
        timeout_seconds=5,
        backend_version="3.4.4",
        model_revision="revision-1",
        executable=executable,
    )

    results = await parser.parse_many([first, second], concurrency=2)

    assert len(calls) == 1
    command, kwargs = calls[0]
    assert Path(command[command.index("-p") + 1]).name.startswith(
        "m1-mineru-batch-input-"
    )
    assert command[command.index("--max-concurrency") + 1] == "2"
    assert kwargs["env"]["MINERU_API_MAX_CONCURRENT_REQUESTS"] == "2"
    assert isinstance(results[first.resolve()], candidate.MinerUParseResult)
    assert results[first.resolve()].evidence.pages[0].blocks[0].text == "first"
    assert isinstance(results[second.resolve()], candidate.MinerUContractError)
    assert "found 0 content and 0 middle" in str(results[second.resolve()])
    assert all(not root.exists() for root in temporary_roots)


@pytest.mark.asyncio
async def test_vlm_http_client_keeps_completed_batch_outputs_after_cli_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    first = tmp_path / "first.png"
    second = tmp_path / "second.png"
    first.write_bytes(b"first-image")
    second.write_bytes(b"second-image")

    class FailedProcess:
        returncode = 17

        async def wait(self):
            return self.returncode

        def kill(self):
            raise AssertionError("exited process must not be killed")

    async def create_subprocess_exec(*command, **_kwargs):
        input_root = Path(command[command.index("-p") + 1])
        output_root = Path(command[command.index("-o") + 1])
        first_input = min(path for path in input_root.iterdir() if path.is_file())
        stem = first_input.stem
        result_dir = output_root / stem / "vlm"
        result_dir.mkdir(parents=True)
        (result_dir / f"{stem}_content_list_v2.json").write_text(
            json.dumps([[{"type": "text", "content": {"content": "kept"}}]]),
            encoding="utf-8",
        )
        (result_dir / f"{stem}_middle.json").write_text(
            json.dumps(
                {
                    "_version_name": "3.4.4",
                    "_backend": "vlm",
                    "pdf_info": [{"page_size": [10, 10]}],
                }
            ),
            encoding="utf-8",
        )
        return FailedProcess()

    monkeypatch.setattr(
        candidate.asyncio,
        "create_subprocess_exec",
        create_subprocess_exec,
    )
    parser = candidate._MinerUVLMHTTPClientParser(
        base_url="http://127.0.0.1:30000",
        timeout_seconds=5,
        backend_version="3.4.4",
        model_revision="revision-1",
        executable=tmp_path / "mineru.exe",
    )

    results = await parser.parse_many([first, second])

    assert isinstance(results[first.resolve()], candidate.MinerUParseResult)
    assert results[first.resolve()].evidence.pages[0].blocks[0].text == "kept"
    assert isinstance(results[second.resolve()], candidate.MinerUError)
    assert "status 17" in str(results[second.resolve()])


def test_batch_output_pairing_rejects_duplicates_and_unexpected_stems(
    tmp_path: Path,
) -> None:
    first = tmp_path / "first" / "vlm"
    duplicate = tmp_path / "duplicate" / "vlm"
    second = tmp_path / "second" / "vlm"
    for directory in (first, duplicate, second):
        directory.mkdir(parents=True)
    (first / "asset_a_content_list_v2.json").write_text("[]", encoding="utf-8")
    (first / "asset_a_middle.json").write_text("{}", encoding="utf-8")
    (duplicate / "asset_a_content_list_v2.json").write_text("[]", encoding="utf-8")
    (second / "asset_b_content_list_v2.json").write_text("[]", encoding="utf-8")

    pairs = candidate._discover_mineru_batch_output_pairs(
        tmp_path,
        ["asset_a", "asset_b"],
    )

    assert isinstance(pairs["asset_a"], candidate.MinerUContractError)
    assert "found 2 content and 1 middle" in str(pairs["asset_a"])
    assert isinstance(pairs["asset_b"], candidate.MinerUContractError)
    assert "found 1 content and 0 middle" in str(pairs["asset_b"])

    (second / "unknown_content_list_v2.json").write_text("[]", encoding="utf-8")
    with pytest.raises(candidate.MinerUContractError, match="unexpected output stem"):
        candidate._discover_mineru_batch_output_pairs(
            tmp_path,
            ["asset_a", "asset_b"],
        )


def test_vlm_http_client_requires_one_matching_output_pair(tmp_path: Path) -> None:
    (tmp_path / "a_content_list_v2.json").write_text("[]", encoding="utf-8")
    (tmp_path / "b_content_list_v2.json").write_text("[]", encoding="utf-8")
    (tmp_path / "a_middle.json").write_text("{}", encoding="utf-8")

    with pytest.raises(candidate.MinerUContractError, match="found 2"):
        candidate._discover_mineru_output_pair(tmp_path)

    (tmp_path / "b_content_list_v2.json").unlink()
    (tmp_path / "a_middle.json").rename(tmp_path / "b_middle.json")
    with pytest.raises(candidate.MinerUContractError, match="not a pair"):
        candidate._discover_mineru_output_pair(tmp_path)


def test_loader_accepts_pinned_office_contract_without_vlm_fingerprint(
    tmp_path: Path,
) -> None:
    content = tmp_path / "input_content_list_v2.json"
    middle = tmp_path / "input_middle.json"
    content.write_text("[]", encoding="utf-8")
    middle.write_text(
        json.dumps({"_version_name": "3.4.4", "_backend": "office"}),
        encoding="utf-8",
    )

    parsed = candidate._load_mineru_output(
        content_list_v2_path=content,
        middle_json_path=middle,
        backend_version="3.4.4",
        model_revision="vlm-revision-must-not-leak",
        backend="vlm-http-client",
        elapsed_ms=1.0,
        task_id_prefix="test",
    )

    assert parsed.evidence.backend == "mineru:vlm-http-client:office"
    assert parsed.evidence.model_fingerprints == {}


@pytest.mark.asyncio
async def test_vlm_http_client_timeout_kills_process_and_cleans_outputs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "input.pdf"
    source.write_bytes(b"fixture")
    state: dict[str, object] = {"killed": False}

    class HangingProcess:
        def __init__(self) -> None:
            self.returncode = None
            self.exited = candidate.asyncio.Event()

        async def wait(self):
            await self.exited.wait()
            return self.returncode

        def kill(self):
            state["killed"] = True
            self.returncode = -9
            self.exited.set()

    async def create_subprocess_exec(*command, **_kwargs):
        state["output_root"] = Path(command[command.index("-o") + 1])
        return HangingProcess()

    monkeypatch.setattr(
        candidate.asyncio,
        "create_subprocess_exec",
        create_subprocess_exec,
    )
    parser = candidate._MinerUVLMHTTPClientParser(
        base_url="http://127.0.0.1:30000",
        timeout_seconds=0.01,
        backend_version="3.4.4",
        model_revision="",
        executable=tmp_path / "mineru.exe",
    )

    with pytest.raises(candidate.MinerUError, match="timed out"):
        await parser.parse(source)

    assert state["killed"] is True
    assert not Path(state["output_root"]).exists()


@pytest.mark.skipif(sys.platform != "win32", reason="Windows process-tree regression")
@pytest.mark.asyncio
async def test_windows_process_tree_cleanup_terminates_inherited_handle_child(
    tmp_path: Path,
) -> None:
    child_pid_path = tmp_path / "child.pid"
    log_path = tmp_path / "inherited.log"
    parent_code = (
        "import pathlib, subprocess, sys, time; "
        "child=subprocess.Popen([sys.executable, '-c', "
        "'import time; time.sleep(60)']); "
        "pathlib.Path(sys.argv[1]).write_text(str(child.pid), encoding='ascii'); "
        "time.sleep(60)"
    )

    def is_running(pid: int) -> bool:
        completed = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
            check=False,
            capture_output=True,
            text=True,
        )
        return str(pid) in completed.stdout

    process = None
    child_pid = None
    try:
        with log_path.open("w+b") as log_stream:
            process = await candidate.asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                parent_code,
                str(child_pid_path),
                stdout=log_stream,
                stderr=candidate.subprocess.STDOUT,
                **candidate._process_group_kwargs(),
            )
            deadline = candidate.asyncio.get_running_loop().time() + 5
            child_pid_text = ""
            while not child_pid_text:
                if child_pid_path.exists():
                    child_pid_text = child_pid_path.read_text(encoding="ascii").strip()
                if candidate.asyncio.get_running_loop().time() >= deadline:
                    raise AssertionError("child process did not publish its PID")
                if not child_pid_text:
                    await candidate.asyncio.sleep(0.02)
            child_pid = int(child_pid_text)
            assert is_running(process.pid)
            assert is_running(child_pid)

            started = candidate.asyncio.get_running_loop().time()
            await candidate._terminate_process_tree(process, timeout_seconds=5)
            assert candidate.asyncio.get_running_loop().time() - started < 5.5

        deadline = candidate.asyncio.get_running_loop().time() + 3
        while is_running(child_pid):
            if candidate.asyncio.get_running_loop().time() >= deadline:
                break
            await candidate.asyncio.sleep(0.05)
        assert process.returncode is not None
        assert not is_running(process.pid)
        assert not is_running(child_pid)
    finally:
        for pid in (
            getattr(process, "pid", None),
            child_pid,
        ):
            if isinstance(pid, int) and is_running(pid):
                await candidate.asyncio.to_thread(
                    subprocess.run,
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )


def test_output_file_is_atomic_and_benchmark_loadable(tmp_path: Path) -> None:
    output = tmp_path / "candidate.json"
    rendered = json.dumps({"record": {"header": {"order_number": "PO-1"}}})

    candidate._write_output(output, rendered)

    assert json.loads(output.read_text(encoding="utf-8"))["record"]["header"] == {
        "order_number": "PO-1"
    }
    assert not output.with_name(f".{output.name}.tmp").exists()


@pytest.mark.asyncio
async def test_cached_mineru_parser_replays_pinned_evidence(tmp_path: Path) -> None:
    content_path = tmp_path / "sample_content_list_v2.json"
    middle_path = tmp_path / "sample_middle.json"
    content_path.write_text(
        json.dumps(
            [[{"type": "text", "bbox": [0, 0, 1, 1], "content": {"content": "A"}}]]
        ),
        encoding="utf-8",
    )
    middle_path.write_text(
        json.dumps(
            {
                "_version_name": "3.4.4",
                "_backend": "vlm",
                "pdf_info": [{"page_size": [100, 200]}],
            }
        ),
        encoding="utf-8",
    )
    parser = candidate._CachedMinerUParser(
        content_list_v2_path=content_path,
        middle_json_path=middle_path,
        backend_version="3.4.4",
        model_revision="revision-1",
    )

    parsed = await parser.parse(tmp_path / "ignored.pdf")

    assert parsed.task_id.startswith("cached-")
    assert parsed.evidence.pages[0].width == 100
    assert parsed.evidence.pages[0].blocks[0].text == "A"
    assert parsed.evidence.model_fingerprints == {"mineru_vlm": "revision-1"}


def test_cached_mineru_cli_paths_must_be_paired() -> None:
    args = candidate._parser().parse_args(
        ["sample.pdf", "--mineru-content-list-v2", "content.json"]
    )
    with pytest.raises(SystemExit, match="must be used together"):
        cached_paths = (args.mineru_content_list_v2, args.mineru_middle_json)
        if sum(path is not None for path in cached_paths) == 1:
            raise SystemExit(
                "--mineru-content-list-v2 and --mineru-middle-json must be used "
                "together"
            )


@pytest.mark.asyncio
async def test_cli_builds_native_ollama_transport_with_context_override() -> None:
    args = candidate._parser().parse_args(
        [
            "sample.pdf",
            "--llm-transport",
            "ollama-native",
            "--llm-num-ctx",
            "24576",
        ]
    )

    extractor = candidate._build_extractor(args)
    try:
        assert extractor._client._num_ctx == 24_576
        assert str(extractor._client._client.base_url) == "http://127.0.0.1:11434"
    finally:
        await extractor.close()


@pytest.mark.asyncio
async def test_candidate_uses_spreadsheet_evidence_without_lossy_mineru_roundtrip(
    tmp_path: Path,
) -> None:
    from openpyxl import Workbook

    source = tmp_path / "order.xlsx"
    workbook = Workbook()
    workbook.active["A1"] = "product_code"
    workbook.active["A2"] = "SKU-1"
    workbook.save(source)
    workbook.close()
    original = source.read_bytes()
    mineru = _MinerU()

    payload = await candidate.run_candidate(
        source,
        mineru=mineru,
        extractor=_Extractor(
            _result().model_copy(
                update={"document_facts": [], "segments": []},
                deep=True,
            )
        ),
    )

    assert mineru.calls == []
    assert mineru.submitted_bytes == b""
    assert source.read_bytes() == original
    assert payload["record"]["source"]["original_filename"] == "order.xlsx"
    assert payload["input_normalization"]["normalized"]["conversion"] == (
        "native_evidence_identity"
    )
    assert payload["input_normalization"]["mapping"] == {
        "strategy": "identity",
        "complete": True,
        "authority": "native_document_evidence",
    }
    assert payload["evidence_summary"]["backend"] == "spreadsheet-envelope"


def _docx_region_fixture(
    tmp_path: Path,
) -> tuple[Path, bytes, SourceAssetInventory, DocumentEvidence, str]:
    source = tmp_path / "drawing.docx"
    image_bytes = b"mock-image-bytes"
    with ZipFile(source, "w") as package:
        package.writestr(
            "[Content_Types].xml",
            """<?xml version="1.0" encoding="UTF-8"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
              <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
              <Default Extension="xml" ContentType="application/xml"/>
              <Default Extension="png" ContentType="image/png"/>
              <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
            </Types>""",
        )
        package.writestr(
            "word/document.xml",
            """<?xml version="1.0" encoding="UTF-8"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
              xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
              xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
              <w:body><w:p><w:r><w:t>Drawing</w:t><w:drawing>
                <a:blip r:embed="rId1"/>
              </w:drawing></w:r></w:p><w:sectPr/></w:body>
            </w:document>""",
        )
        package.writestr(
            "word/_rels/document.xml.rels",
            """<?xml version="1.0" encoding="UTF-8"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/drawing.png"/>
            </Relationships>""",
        )
        package.writestr("word/media/drawing.png", image_bytes)
    source_sha256 = hashlib.sha256(source.read_bytes()).hexdigest()
    asset_sha256 = hashlib.sha256(image_bytes).hexdigest()
    asset_id = f"asset:sha256:{asset_sha256}"
    inventory = SourceAssetInventory(
        source_kind="docx",
        source_name=source.name,
        source_sha256=source_sha256,
        source_byte_size=source.stat().st_size,
        assets=[
            SourceAsset(
                asset_id=asset_id,
                sha256=asset_sha256,
                mime_type="image/png",
                byte_size=len(image_bytes),
                parts=["word/media/drawing.png"],
                source_refs=[
                    SourceAssetReference(
                        source_ref=SourceReference(part="word/document.xml#paragraph:0")
                    )
                ],
                coverage_status="inventoried_referenced",
            )
        ],
        coverage_status="complete",
    )
    evidence = _evidence().model_copy(deep=True)
    evidence.pages[0].blocks.append(
        EvidenceBlock(
            block_id=f"asset:{asset_sha256}/p0/p1:b0",
            kind="image",
            text="engineering drawing R1.1",
            asset_sha256=asset_sha256,
            asset_id=asset_id,
            asset_parts=["word/media/drawing.png"],
            source_ref_part="word/document.xml#paragraph:0",
        )
    )
    return source, image_bytes, inventory, evidence, asset_sha256


def test_drawing_region_vlm_cli_is_explicit_and_bounded() -> None:
    args = candidate._parser().parse_args(["sample.docx"])

    assert args.drawing_region_vlm_enabled is False
    assert args.drawing_region_vlm_base_url is None
    assert args.drawing_region_vlm_model is None
    assert args.drawing_region_vlm_paddle_model_root is None
    assert args.drawing_region_vlm_device == "cpu"
    assert args.drawing_region_vlm_max_regions == 16
    assert args.drawing_region_vlm_timeout_seconds == 30.0
    assert args.drawing_region_vlm_asset_timeout_seconds == 180.0

    configured = candidate._parser().parse_args(
        [
            "sample.docx",
            "--mineru-transport",
            "vlm-http-client",
            "--mineru-base-url",
            "http://127.0.0.1:30000",
            "--mineru-model-revision",
            "mineru-vlm",
            "--drawing-region-vlm-enabled",
            "--drawing-region-vlm-paddle-model-root",
            "models",
            "--drawing-region-vlm-max-regions",
            "4",
            "--drawing-region-vlm-timeout-seconds",
            "7.5",
            "--drawing-region-vlm-asset-timeout-seconds",
            "45",
        ]
    )
    assert candidate._drawing_region_vlm_connection(configured) == (
        "http://127.0.0.1:30000",
        "mineru-vlm",
    )
    assert configured.drawing_region_vlm_max_regions == 4
    assert configured.drawing_region_vlm_timeout_seconds == 7.5
    assert configured.drawing_region_vlm_asset_timeout_seconds == 45.0


@pytest.mark.asyncio
async def test_drawing_region_vlm_default_disabled_path_is_unchanged(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source, _image, inventory, evidence, _asset_sha256 = _docx_region_fixture(tmp_path)
    monkeypatch.setattr(candidate, "inventory_source_assets", lambda _path: inventory)
    monkeypatch.setattr(candidate, "parse_docx_native_evidence", lambda _path: evidence)
    region = _DrawingRegionExtractor(error=AssertionError("must not be called"))
    clock_values = iter((0.0, 1.0, 2.0, 3.0, 4.0, 4.0, 5.0, 6.0))
    monkeypatch.setattr(candidate.time, "perf_counter", lambda: next(clock_values))

    baseline = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
    )
    clock_values = iter((0.0, 1.0, 2.0, 3.0, 4.0, 4.0, 5.0, 6.0))

    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
        drawing_region_vlm_extractor=region,
    )

    assert region.calls == []
    assert "drawing_region_vlm" not in payload
    assert "drawing_region_vlm" not in payload["result"]
    assert "drawing_region_vlm" not in payload["record"]["extraction"]["raw_content"]
    assert "drawing_region_vlm_ms" not in payload["timing"]
    assert payload["record"]["header"]["order_number"] == "PO-1"
    assert payload["record"]["lines"][0]["product_code"] == "SKU-1"
    assert json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8") == json.dumps(
        baseline,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


@pytest.mark.asyncio
async def test_drawing_region_vlm_adds_only_audited_sidecar_facts(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source, image_bytes, inventory, evidence, asset_sha256 = _docx_region_fixture(
        tmp_path
    )
    monkeypatch.setattr(candidate, "inventory_source_assets", lambda _path: inventory)
    monkeypatch.setattr(candidate, "parse_docx_native_evidence", lambda _path: evidence)
    region = _DrawingRegionExtractor(_drawing_region_result)

    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
        visual_assets_max=2,
        visual_asset_max_bytes=1024,
        drawing_region_vlm_enabled=True,
        drawing_region_vlm_extractor=region,
        drawing_region_vlm_max_regions=3,
        drawing_region_vlm_timeout_seconds=5,
    )

    assert len(region.calls) == 1
    call = region.calls[0]
    assert call["image"] == image_bytes
    assert call["evidence_id"] == f"asset:{asset_sha256}/p0/p1:b0"
    assert call["max_regions"] == 3
    assert call["source_ref"].model_extra["asset_sha256"] == asset_sha256
    region_facts = [
        fact
        for fact in payload["result"]["semantic_facts"]
        if fact["extractor"] == "drawing_region_vlm.v1"
    ]
    assert len(region_facts) == 1
    assert region_facts[0]["name"] == "drawing_radius"
    region_evidence_id = region_facts[0]["evidence_refs"][0]["evidence_id"]
    disposition = next(
        item
        for item in payload["result"]["semantic_evidence_dispositions"]
        if item["evidence_id"] == region_evidence_id
    )
    assert disposition["status"] == "structured"
    assert payload["drawing_region_vlm"]["status"] == "completed"
    assert payload["drawing_region_vlm"]["region_call_count"] == 1
    assert payload["drawing_region_vlm"]["fact_count"] == 1
    assert payload["result"]["drawing_region_vlm"] == payload["drawing_region_vlm"]
    assert payload["record"]["header"]["order_number"] == "PO-1"
    assert payload["record"]["lines"][0]["product_code"] == "SKU-1"


@pytest.mark.asyncio
async def test_drawing_region_negative_screening_consumes_calls_without_review(
    tmp_path: Path,
) -> None:
    source, _image_bytes, inventory, evidence, _asset_sha256 = (
        _docx_region_fixture(tmp_path)
    )

    def screened_result(
        *,
        source_ref: SourceReference,
        **_kwargs: object,
    ) -> DrawingRegionVLMResult:
        return DrawingRegionVLMResult(
            audit=[
                DrawingRegionAudit(
                    candidate_id="candidate-invalid",
                    source_ref=source_ref,
                    ocr_score=0.95,
                    selection_reasons=["numeric_hint"],
                    disposition="not_a_callout",
                    normalized_text="INVALID",
                ),
                DrawingRegionAudit(
                    candidate_id="candidate-identifier",
                    source_ref=source_ref,
                    ocr_score=0.94,
                    selection_reasons=["numeric_hint"],
                    disposition="screened",
                    normalized_text="DP2.1",
                ),
            ]
        )

    facts, sidecar = await candidate._drawing_region_vlm_sidecar(
        source,
        evidence,
        inventory,
        _DrawingRegionExtractor(screened_result),
        max_assets=1,
        max_asset_bytes=1024,
        max_regions=3,
        timeout_seconds=5,
    )

    assert facts == []
    assert sidecar["region_call_count"] == 2
    assert sidecar["status"] == "completed"
    assert sidecar["needs_review"] is False
    assert sidecar["issues"] == []
    assert sidecar["assets"][0]["status"] == "screened_no_regions"


@pytest.mark.asyncio
async def test_drawing_region_asset_limit_is_partial_and_requires_review(
    tmp_path: Path,
) -> None:
    source, _image_bytes, inventory, evidence, _asset_sha256 = _docx_region_fixture(
        tmp_path
    )
    repeated_inventory = inventory.model_copy(
        update={"assets": [inventory.assets[0], inventory.assets[0].model_copy()]},
        deep=True,
    )
    region = _DrawingRegionExtractor(_drawing_region_result)

    facts, sidecar = await candidate._drawing_region_vlm_sidecar(
        source,
        evidence,
        repeated_inventory,
        region,
        max_assets=1,
        max_asset_bytes=1024,
        max_regions=3,
        timeout_seconds=5,
    )

    assert len(facts) == 1
    assert len(region.calls) == 1
    assert sidecar["status"] == "partial"
    assert sidecar["needs_review"] is True
    assert sidecar["assets"][1]["status"] == "skipped"
    assert sidecar["assets"][1]["reason"] == "max_assets"
    assert [issue["code"] for issue in sidecar["issues"]] == [
        "DRAWING_REGION_ASSET_LIMIT"
    ]


@pytest.mark.asyncio
async def test_drawing_region_vlm_failure_preserves_deterministic_record(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source, _image, inventory, evidence, _asset_sha256 = _docx_region_fixture(tmp_path)
    monkeypatch.setattr(candidate, "inventory_source_assets", lambda _path: inventory)
    monkeypatch.setattr(candidate, "parse_docx_native_evidence", lambda _path: evidence)
    region = _DrawingRegionExtractor(error=RuntimeError("provider failed"))

    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
        drawing_region_vlm_enabled=True,
        drawing_region_vlm_extractor=region,
    )

    assert payload["drawing_region_vlm"]["status"] == "failed"
    assert payload["drawing_region_vlm"]["needs_review"] is True
    assert payload["drawing_region_vlm"]["issues"][0]["code"] == (
        "DRAWING_REGION_ASSET_FAILED"
    )
    assert not any(
        fact["extractor"] == "drawing_region_vlm.v1"
        for fact in payload["result"]["semantic_facts"]
    )
    assert payload["record"]["header"]["order_number"] == "PO-1"
    assert payload["record"]["lines"][0]["product_code"] == "SKU-1"


@pytest.mark.asyncio
async def test_drawing_region_vlm_unsupported_source_is_audited(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "drawing.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    inventory = SourceAssetInventory(
        source_kind="pdf",
        source_name=source.name,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        source_byte_size=source.stat().st_size,
        coverage_status="complete",
    )
    monkeypatch.setattr(candidate, "inventory_source_assets", lambda _path: inventory)
    region = _DrawingRegionExtractor(error=AssertionError("must not be called"))

    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
        drawing_region_vlm_enabled=True,
        drawing_region_vlm_extractor=region,
    )

    assert region.calls == []
    assert payload["drawing_region_vlm"]["status"] == "unsupported"
    assert payload["drawing_region_vlm"]["issues"] == [
        {
            "code": "DRAWING_REGION_SOURCE_UNSUPPORTED",
            "message": (
                "drawing region VLM currently supports DOCX embedded images only"
            ),
        }
    ]
    assert payload["record"]["header"]["order_number"] == "PO-1"


@pytest.mark.asyncio
async def test_semantic_completion_failure_is_fail_open_and_audited(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    def fail_completion(*_args, **_kwargs):
        raise RuntimeError("semantic completion failed")

    monkeypatch.setattr(candidate, "build_semantic_completion", fail_completion)
    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
    )

    assert payload["record"]["header"]["order_number"] == "PO-1"
    assert payload["record"]["lines"][0]["product_code"] == "SKU-1"
    assert payload["record"]["needs_review"] is True
    assert any(
        issue["code"] == "SEMANTIC_COMPLETION_FAILED"
        for issue in payload["record"]["validation_issues"]
    )
    assert payload["result"]["semantic_facts"] == []
    assert payload["result"]["semantic_completeness_audit"]["status"] == ("failed")


@pytest.mark.asyncio
async def test_semantic_completion_review_promotes_record_review_state(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class ReviewCompletion:
        review_required = True

        @staticmethod
        def model_dump(*_args, **_kwargs):
            return {
                "schema_version": "m1.semantic-completion.v1",
                "facts": [],
                "dispositions": [],
                "counts": {},
                "ratios": {},
                "review_required": True,
            }

    monkeypatch.setattr(
        candidate,
        "build_semantic_completion",
        lambda *_args, **_kwargs: ReviewCompletion(),
    )
    payload = await candidate.run_candidate(
        source,
        mineru=_MinerU(),
        extractor=_Extractor(),
    )

    assert payload["record"]["needs_review"] is True
    assert [
        issue["code"]
        for issue in payload["record"]["validation_issues"]
        if issue["code"] == "SEMANTIC_COMPLETION_REVIEW_REQUIRED"
    ] == ["SEMANTIC_COMPLETION_REVIEW_REQUIRED"]
    assert payload["record"]["header"]["order_number"] == "PO-1"
    assert payload["record"]["lines"][0]["product_code"] == "SKU-1"
