"""ScoredResult.recompute_flags 单测：审核标记与整体置信度口径。"""
from __future__ import annotations

import pytest

from m1.schemas import ScoredField, ScoredResult


def _result(confidences: list[float]) -> ScoredResult:
    return ScoredResult(
        task_id="t",
        fields=[
            ScoredField(name=f"f{i}", value="v", confidence=c)
            for i, c in enumerate(confidences)
        ],
    )


def test_overall_is_min():
    r = _result([0.95, 0.7, 0.99])
    r.recompute_flags(threshold=0.9)
    assert r.overall_confidence == pytest.approx(0.7)


def test_needs_review_when_any_below_threshold():
    r = _result([0.95, 0.7])
    r.recompute_flags(threshold=0.9)
    assert r.needs_review is True
    assert r.review_status == "needs_review"
    assert [f.needs_review for f in r.fields] == [False, True]


def test_auto_approved_when_all_pass():
    r = _result([0.95, 0.92])
    r.recompute_flags(threshold=0.9)
    assert r.needs_review is False
    assert r.review_status == "auto_approved"


def test_non_applicable_compatibility_fields_do_not_trigger_review():
    result = ScoredResult(
        task_id="optional-fields",
        fields=[
            ScoredField(
                name="supplier",
                value=None,
                confidence=0.0,
                applicable=False,
                breakdown={"not_applicable": 1.0},
            ),
            ScoredField(name="model", value="M-1", confidence=0.99),
        ],
    )

    result.recompute_flags(0.9)

    assert result.overall_confidence == 0.99
    assert result.needs_review is False
    assert result.fields[0].needs_review is False
    assert result.review_status == "auto_approved"


def test_empty_fields_zero_confidence():
    r = _result([])
    r.recompute_flags(threshold=0.9)
    assert r.overall_confidence == 0.0
    assert r.needs_review is False
