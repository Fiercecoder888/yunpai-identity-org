from __future__ import annotations

import copy
import json
from typing import Any

import pytest
from m1.documents.models import SourceReference
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
)
from m1.documents.parsing.mineru_instructor_poc import (
    EvidenceReference,
    ExtractedFact,
    MinerUInstructorResult,
)
from m1.documents.parsing.semantic_completion import build_semantic_completion
from m1.documents.parsing.semantic_facts import (
    SemanticEvidence,
    SemanticFact,
    stable_fact_id,
)


def _ref(evidence_id: str, quote: str) -> EvidenceReference:
    return EvidenceReference(
        evidence_id=evidence_id,
        quote=quote,
        source_ref=SourceReference(page=1, part=f"mineru/{evidence_id}"),
    )


def _evidence(*texts: str) -> DocumentEvidence:
    return DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1,
                height=1,
                coordinate_space="unknown",
                blocks=[
                    EvidenceBlock(
                        block_id=f"docx:p:{index}",
                        kind="paragraph",
                        text=text,
                        confidence=1.0,
                        order=index,
                        source="docx-native-ooxml",
                    )
                    for index, text in enumerate(texts)
                ],
            )
        ],
    )


def _drawing_evidence(text: str) -> DocumentEvidence:
    return DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id="asset:drawing/p0/b0",
                        kind="image",
                        text=text,
                        confidence=0.8,
                        order=0,
                        source="mineru:vlm-http-client",
                        asset_sha256="a" * 64,
                    )
                ],
            )
        ],
    )


def _visual_evidence(
    *assets: tuple[str, str, str],
) -> DocumentEvidence:
    return DocumentEvidence(
        backend="docx-native-ooxml",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                coordinate_space="normalized",
                blocks=[
                    EvidenceBlock(
                        block_id=block_id,
                        kind="image",
                        text=text,
                        confidence=0.8,
                        order=index,
                        source="mineru:vlm-http-client",
                        asset_sha256=sha256,
                        asset_id=f"asset:sha256:{sha256}",
                    )
                    for index, (block_id, sha256, text) in enumerate(assets)
                ],
            )
        ],
    )


def _extracted(
    *,
    structured: tuple[tuple[str, str], ...] = (),
    schema: tuple[tuple[str, str], ...] = (),
    redundant: tuple[tuple[str, str], ...] = (),
) -> MinerUInstructorResult:
    document_facts = [
        ExtractedFact(name="existing_fact", value=value, evidence_refs=[_ref(key, value)])
        for key, value in structured
    ]
    return MinerUInstructorResult(
        document_intent="technical_document",
        document_intent_family="technical_document",
        document_subtype="product_specification",
        document_facts=document_facts,
        segments=[],
        content_units=[],
        schema_evidence=[_ref(key, value) for key, value in schema],
        redundant_evidence=[_ref(key, value) for key, value in redundant],
        raw_content_evidence=[],
        unmapped_evidence=[],
        issues=[],
        complete=True,
        semantic_complete=True,
        accounted_complete=True,
        retained_complete=True,
        total_evidence_count=len(structured) + len(schema) + len(redundant),
        mapped_evidence_count=len(structured),
        schema_evidence_count=len(schema),
        redundant_evidence_count=len(redundant),
        raw_content_evidence_count=0,
        unresolved_evidence_count=0,
        retained_evidence_count=len(structured) + len(schema) + len(redundant),
        unmapped_evidence_count=0,
        evidence_coverage_ratio=1.0,
        semantic_accounting_ratio=1.0,
        evidence_accounting_ratio=1.0,
        retained_evidence_ratio=1.0,
        intent_calls=1,
        segment_calls=0,
    )


def _additional_fact(evidence_id: str, quote: str) -> SemanticFact:
    attributes = {"source": "test"}
    fact_id = stable_fact_id(
        name="technical_note",
        value=quote,
        attributes=attributes,
        evidence_ids=[evidence_id],
    )
    return SemanticFact(
        fact_id=fact_id,
        name="technical_note",
        value=quote,
        attributes=attributes,
        evidence_refs=[
            SemanticEvidence(
                evidence_id=evidence_id,
                quote=quote,
                source_ref=SourceReference(page=1, part=f"mineru/{evidence_id}"),
            )
        ],
        extractor="injected-test-builder",
        confidence=0.99,
        status="verified",
    )


def _region_fact(
    *,
    parent_evidence_id: str = "asset:drawing/p0/b0",
    asset_sha256: str = "a" * 64,
    region_sha256: str = "c" * 64,
    bbox: list[float] | None = None,
    value: dict[str, str] | None = None,
    quote: str = "20.9±0.06",
    unit: str | None = "mm",
    source_ref_updates: dict[str, Any] | None = None,
    fact_updates: dict[str, Any] | None = None,
) -> SemanticFact:
    evidence_id = f"{parent_evidence_id}/region:{region_sha256}"
    resolved_value = value or {"nominal": "20.9", "symmetric_deviation": "0.06"}
    attributes: dict[str, Any] = {
        "dimension_type": "linear",
        "localization": "region_bbox",
        "tolerance_type": (
            "asymmetric"
            if "upper_deviation" in resolved_value
            else "symmetric"
            if "symmetric_deviation" in resolved_value
            else "none"
        ),
        "source_boundary": "visual_region_advisory",
        "ocr_text_trusted": False,
        "crop_rotation_degrees": 0,
        "evidence_kind": "model_transcription",
        "model_transcription": True,
    }
    source_payload: dict[str, Any] = {
        "page": 1,
        "part": f"mineru/{parent_evidence_id}",
        "asset_sha256": asset_sha256,
        "bbox": bbox or [10.0, 10.0, 100.0, 40.0],
        "coordinate_space": "image_pixels",
        "parent_evidence_id": parent_evidence_id,
        "asset_width_pixels": 240,
        "asset_height_pixels": 160,
        "region_bbox_pixels": [10, 10, 100, 40],
        "region_crop_bbox_pixels": [0, 0, 132, 50],
        "region_output_size_pixels": [528, 200],
        "region_upscale_factor": 4,
        "region_resampling": "lanczos",
        "region_image_mode": "RGB",
        "region_encoding": "PNG",
        "region_encoding_options": {"optimize": True},
        "region_encoder": "Pillow/test",
        "region_hash_basis": "encoded_region_png_bytes",
        "region_transform_version": "m1.region-crop.v1",
        "region_sha256": region_sha256,
        "region_rotation_degrees": 0,
        "authority": "advisory",
        "inferred": True,
        "evidence_kind": "model_transcription",
        "model_transcription": True,
    }
    source_payload.update(source_ref_updates or {})
    fact_id = stable_fact_id(
        name="drawing_linear_dimension",
        value=resolved_value,
        unit=unit,
        attributes=attributes,
        evidence_ids=[evidence_id],
    )
    fact = SemanticFact(
        fact_id=fact_id,
        name="drawing_linear_dimension",
        value=resolved_value,
        unit=unit,
        attributes=attributes,
        evidence_refs=[
            SemanticEvidence(
                evidence_id=evidence_id,
                quote=quote,
                source_ref=SourceReference.model_validate(source_payload),
            )
        ],
        extractor="drawing_region_vlm.v1",
        confidence=0.85,
        status="advisory",
    )
    return fact.model_copy(update=fact_updates or {}, deep=True)


def test_completion_combines_existing_and_new_facts_with_full_audit() -> None:
    evidence = _evidence(
        "工艺流程",
        "下料  切割",
        "权威标题",
        "产品名称",
        "重复别名",
        "尚未理解的说明",
    )
    extracted = _extracted(
        structured=(("docx:p:2", "权威标题"),),
        schema=(("docx:p:3", "产品名称"),),
        redundant=(("docx:p:4", "重复别名"),),
    )
    projected = {
        "header": {"title": "不得复制"},
        "lines": [{"name": "不得复制"}],
        "needs_review": False,
    }
    projected_before = copy.deepcopy(projected)

    completion = build_semantic_completion(
        evidence,
        "3988-27.6长弧形太空灰.docx",
        extracted,
        projected,
    )

    assert projected == projected_before
    assert completion.counts.model_dump() == {
        "evidence_total": 7,
        "source_evidence_total": 7,
        "supplemental_evidence_total": 0,
        "evidence_accounted": 7,
        "evidence_structured": 4,
        "evidence_schema": 1,
        "evidence_redundant": 1,
        "evidence_non_semantic": 0,
        "evidence_ambiguous": 0,
        "evidence_needs_review": 1,
        "evidence_verified": 3,
        "evidence_advisory": 1,
        "source_evidence_structured": 4,
        "source_evidence_schema": 1,
        "source_evidence_redundant": 1,
        "source_evidence_non_semantic": 0,
        "source_evidence_ambiguous": 0,
        "source_evidence_needs_review": 1,
        "source_evidence_verified": 3,
        "source_evidence_advisory": 1,
        "supplemental_evidence_structured": 0,
        "supplemental_evidence_schema": 0,
        "supplemental_evidence_redundant": 0,
        "supplemental_evidence_non_semantic": 0,
        "supplemental_evidence_ambiguous": 0,
        "supplemental_evidence_needs_review": 0,
        "supplemental_evidence_verified": 0,
        "supplemental_evidence_advisory": 0,
        "facts_total": 6,
        "facts_verified": 2,
        "facts_ambiguous": 0,
        "facts_advisory": 4,
        "source_facts_verified": 2,
        "source_facts_ambiguous": 0,
        "source_facts_advisory": 4,
        "supplemental_facts_verified": 0,
        "supplemental_facts_ambiguous": 0,
        "supplemental_facts_advisory": 0,
    }
    assert completion.ratios.audit_completeness == 1.0
    assert completion.ratios.source_semantically_verified == pytest.approx(3 / 7)
    assert completion.ratios.source_structured == pytest.approx(3 / 7)
    assert completion.ratios.source_requiring_review == pytest.approx(1 / 7)
    assert completion.ratios.evidence_accounting == 1.0
    assert completion.ratios.audited_structured == pytest.approx(3 / 7)
    assert completion.ratios.audited_requiring_review == pytest.approx(1 / 7)
    assert completion.review_required is True
    assert [fact.value for fact in completion.facts[:2]] == ["下料", "切割"]
    payload = completion.model_dump(mode="json")
    assert "header" not in payload and "lines" not in payload
    assert "不得复制" not in json.dumps(payload, ensure_ascii=False)
    json.dumps(payload, ensure_ascii=False)


def test_injected_fact_closes_an_unmapped_evidence_gap() -> None:
    evidence = _evidence("权威标题", "图纸注释")
    extracted = _extracted(structured=(("docx:p:0", "权威标题"),))
    additional = _additional_fact("docx:p:1", "图纸注释")

    completion = build_semantic_completion(
        evidence,
        "最终版.docx",
        extracted,
        {"needs_review": False},
        additional_facts=[additional],
    )

    assert completion.facts == [additional]
    assert completion.counts.evidence_structured == 2
    assert completion.counts.evidence_non_semantic == 1
    assert completion.counts.evidence_needs_review == 0
    assert completion.review_required is False


def test_projected_dimension_refs_close_repeated_native_evidence_without_review() -> (
    None
):
    evidence = _evidence("6.65+/-0.1\n27+/-0.3", "6.65+/-0.1")
    projected = {
        "field_meta": {
            "$.key_dimensions[0].value": {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "mineru/docx:p:0",
                        "evidence_quote": "6.65+/-0.1\n27+/-0.3",
                    }
                ]
            }
        },
        "needs_review": False,
    }

    completion = build_semantic_completion(
        evidence,
        "drawing.docx",
        _extracted(),
        projected,
    )

    disposition_by_id = {
        item.evidence_id: item for item in completion.dispositions
    }
    assert disposition_by_id["docx:p:0"].status == "structured"
    assert disposition_by_id["docx:p:1"].status == "redundant"
    assert completion.counts.evidence_needs_review == 0
    assert completion.review_required is False


def test_projected_dimension_marks_decimal_comma_text_layer_redundant() -> None:
    evidence = _evidence("12.27±0.2", "12,27±0,2")
    projected = {
        "field_meta": {
            "$.key_dimensions[0].value": {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "mineru/docx:p:0",
                        "evidence_quote": "12.27±0.2",
                    }
                ]
            }
        },
        "needs_review": False,
    }

    completion = build_semantic_completion(
        evidence,
        "drawing.pdf",
        _extracted(),
        projected,
    )

    disposition_by_id = {
        item.evidence_id: item for item in completion.dispositions
    }
    assert disposition_by_id["docx:p:0"].status == "structured"
    assert disposition_by_id["docx:p:1"].status == "redundant"
    assert completion.counts.evidence_needs_review == 0
    assert completion.review_required is False


def test_projected_field_promotes_prior_schema_evidence_to_structured() -> None:
    evidence = _evidence("material number 80826-041")
    projected = {
        "field_meta": {
            "$.technical_identity.material_number": {
                "source_refs": [
                    {
                        "page": 1,
                        "part": "mineru/docx:p:0",
                        "evidence_quote": "material number 80826-041",
                    }
                ]
            }
        },
        "needs_review": False,
    }

    completion = build_semantic_completion(
        evidence,
        "drawing.pdf",
        _extracted(schema=(("docx:p:0", "material number 80826-041"),)),
        projected,
    )

    assert completion.dispositions[0].status == "structured"
    assert completion.counts.evidence_structured == 1
    assert completion.counts.evidence_schema == 0
    assert completion.counts.evidence_needs_review == 0
    assert completion.review_required is False


def test_filename_advisory_facts_do_not_create_artificial_review_work() -> None:
    completion = build_semantic_completion(
        _evidence("权威标题"),
        "3988-27.6长弧形太空灰.docx",
        _extracted(structured=(("docx:p:0", "权威标题"),)),
        {"needs_review": False},
    )

    assert completion.counts.facts_advisory == 4
    assert completion.counts.evidence_needs_review == 0
    assert completion.counts.evidence_ambiguous == 0
    assert completion.review_required is False


def test_ambiguous_fact_overrides_existing_structured_and_requires_review() -> None:
    ambiguous = _additional_fact("docx:p:0", "权威标题").model_copy(
        update={"fact_id": "semantic_fact:ambiguous", "status": "ambiguous"}
    )
    completion = build_semantic_completion(
        _evidence("权威标题"),
        "最终版.docx",
        _extracted(structured=(("docx:p:0", "权威标题"),)),
        {"needs_review": False},
        additional_facts=[ambiguous],
    )

    assert completion.dispositions[0].status == "ambiguous"
    assert completion.dispositions[0].fact_ids == [ambiguous.fact_id]
    assert completion.review_required is True


def test_projected_legacy_review_state_does_not_override_semantic_audit() -> None:
    evidence = _evidence("权威标题")
    extracted = _extracted(structured=(("docx:p:0", "权威标题"),))

    completion = build_semantic_completion(
        evidence,
        "最终版.docx",
        extracted,
        {"header": {"title": "secret"}, "lines": [], "needs_review": True},
    )

    assert completion.review_required is False
    assert "secret" not in json.dumps(completion.model_dump(mode="json"))


def test_incomplete_extraction_still_requires_review_after_full_accounting() -> None:
    extracted = _extracted(structured=(("docx:p:0", "权威标题"),)).model_copy(
        update={"complete": False}
    )

    completion = build_semantic_completion(
        _evidence("权威标题"),
        "最终版.docx",
        extracted,
        {"needs_review": False},
    )

    assert completion.counts.evidence_needs_review == 0
    assert completion.review_required is True


def test_visual_drawing_builder_adds_only_replayable_atomic_advisory_facts() -> None:
    text = "R1.1 20.9±0.06"
    completion = build_semantic_completion(
        _drawing_evidence(text),
        "最终版.docx",
        _extracted(),
        {"needs_review": False},
    )

    drawing_facts = [
        fact
        for fact in completion.facts
        if fact.name in {"drawing_radius", "drawing_linear_dimension"}
    ]
    assert [fact.name for fact in drawing_facts] == [
        "drawing_radius",
        "drawing_linear_dimension",
    ]
    assert {fact.status for fact in drawing_facts} == {"advisory"}
    assert completion.counts.source_evidence_total == 2
    assert completion.counts.supplemental_evidence_total == 3
    disposition_by_id = {
        item.evidence_id: item for item in completion.dispositions
    }
    assert disposition_by_id["asset:drawing/p0/b0"].status == "needs_review"
    for fact in drawing_facts:
        reference = fact.evidence_refs[0]
        assert reference.evidence_id.startswith("asset:drawing/p0/b0/chars:")
        assert disposition_by_id[reference.evidence_id].status == "structured"
        _prefix, start, end = str(reference.source_ref.range).split(":")
        assert text[int(start) : int(end)] == reference.quote
    assert completion.review_required is True


def test_single_line_random_style_assets_associate_once_and_flag_color_conflict() -> None:
    drawing_text = "R1.1 20.9±0.06"
    photo_text = "a blue cylindrical object on a wooden surface"
    completion = build_semantic_completion(
        _visual_evidence(
            ("asset:drawing/p0/b0", "d" * 64, drawing_text),
            ("asset:photo/p0/b0", "p" * 64, photo_text),
        ),
        "3988-27.6长弧形太空灰.docx",
        _extracted(),
        {"lines": [{"name": "不得复制的产品"}], "needs_review": False},
    )

    associations = [
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    ]
    assert len(associations) == 2
    assert {fact.value["product_id"] for fact in associations} == {"line:0"}
    assert {fact.status for fact in associations} == {"advisory"}
    assert {fact.value["asset_id"] for fact in associations} == {
        f"asset:sha256:{'d' * 64}",
        f"asset:sha256:{'p' * 64}",
    }
    parent_text = {
        "asset:drawing/p0/b0": drawing_text,
        "asset:photo/p0/b0": photo_text,
    }
    for fact in associations:
        reference = fact.evidence_refs[0]
        parent_id = reference.evidence_id.rsplit("/chars:", 1)[0]
        assert reference.quote == parent_text[parent_id]
        assert reference.evidence_id == (
            f"{parent_id}/chars:0:{len(parent_text[parent_id])}"
        )
    conflict = next(
        fact
        for fact in completion.facts
        if fact.name == "visual_color_observation"
    )
    assert conflict.value["normalized"] == "blue"
    assert conflict.attributes["declared"] == "太空灰"
    assert conflict.attributes["conflicts_with_declared"] is True
    assert conflict.status == "ambiguous"
    photo_association = next(
        fact
        for fact in associations
        if fact.value["asset_id"] == f"asset:sha256:{'p' * 64}"
    )
    assert conflict.evidence_refs[0].evidence_id == (
        photo_association.evidence_refs[0].evidence_id
    )
    disposition_by_id = {
        item.evidence_id: item for item in completion.dispositions
    }
    assert disposition_by_id["asset:drawing/p0/b0"].status == "needs_review"
    assert disposition_by_id["asset:photo/p0/b0"].status == "needs_review"
    shared = disposition_by_id[conflict.evidence_refs[0].evidence_id]
    assert shared.status == "ambiguous"
    assert set(shared.fact_ids) == {
        conflict.fact_id,
        photo_association.fact_id,
    }
    assert completion.review_required is True
    serialized = json.dumps(completion.model_dump(mode="json"), ensure_ascii=False)
    assert "不得复制的产品" not in serialized
    assert any(
        fact.name == "drawing_radius" for fact in completion.facts
    )


def test_multiple_lines_leave_unanchored_assets_ambiguous() -> None:
    completion = build_semantic_completion(
        _visual_evidence(
            ("asset:photo/p0/b0", "a" * 64, "product photo"),
        ),
        "最终版.docx",
        _extracted(),
        {"lines": [{}, {}], "needs_review": False},
    )

    association = next(
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    )
    assert association.value["product_id"] is None
    assert association.status == "ambiguous"
    assert completion.review_required is True


def test_spreadsheet_asset_cell_anchor_maps_to_unique_projected_line() -> None:
    evidence = _visual_evidence(
        ("asset:photo/p0/b0", "a" * 64, "product photo"),
    )
    block = evidence.pages[0].blocks[0]
    evidence.pages[0].blocks[0] = EvidenceBlock.model_validate(
        {
            **block.model_dump(mode="python"),
            "asset_source_refs": [
                {"source_ref": {"sheet": "Sheet1", "cell": "L7"}}
            ],
        }
    )
    projected = {
        "lines": [{}, {}],
        "field_meta": {
            "$.lines[0].code": {
                "source_refs": [
                    {"sheet": "Sheet1", "cell": "B6", "source_row": 6}
                ]
            },
            "$.lines[1].code": {
                "source_refs": [
                    {"sheet": "Sheet1", "cell": "B7", "source_row": 7}
                ]
            },
        },
        "needs_review": False,
    }

    completion = build_semantic_completion(
        evidence,
        "order.xlsx",
        _extracted(),
        projected,
    )

    association = next(
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    )
    assert association.value["product_id"] == "line:1"
    assert association.subject == "line:1"
    assert association.attributes["association_method"] == (
        "spreadsheet_row_anchor"
    )
    assert association.status == "advisory"


def test_spreadsheet_asset_conflicting_row_anchors_remain_ambiguous() -> None:
    evidence = _visual_evidence(
        ("asset:photo/p0/b0", "a" * 64, "shared product photo"),
    )
    block = evidence.pages[0].blocks[0]
    evidence.pages[0].blocks[0] = EvidenceBlock.model_validate(
        {
            **block.model_dump(mode="python"),
            "asset_source_refs": [
                {"source_ref": {"sheet": "Sheet1", "cell": "L6"}},
                {"source_ref": {"sheet": "Sheet1", "cell": "L7"}},
            ],
        }
    )
    projected = {
        "lines": [{}, {}],
        "field_meta": {
            "$.lines[0].code": {
                "source_refs": [
                    {"sheet": "Sheet1", "cell": "B6", "source_row": 6}
                ]
            },
            "$.lines[1].code": {
                "source_refs": [
                    {"sheet": "Sheet1", "cell": "B7", "source_row": 7}
                ]
            },
        },
        "needs_review": False,
    }

    completion = build_semantic_completion(
        evidence,
        "order.xlsx",
        _extracted(),
        projected,
    )

    association = next(
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    )
    assert association.value["product_id"] is None
    assert association.status == "ambiguous"
    assert completion.review_required is True


def test_multiple_blocks_for_one_source_asset_emit_one_association() -> None:
    sha256 = "b" * 64
    completion = build_semantic_completion(
        _visual_evidence(
            ("asset:photo/p0/b0", sha256, "front view"),
            ("asset:photo/p0/b1", sha256, "a blue product photo"),
        ),
        "最终版.docx",
        _extracted(),
        {"lines": [{}], "needs_review": False},
    )

    associations = [
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    ]
    assert len(associations) == 1
    assert associations[0].value["asset_id"] == f"asset:sha256:{sha256}"
    assert associations[0].evidence_refs[0].evidence_id == (
        "asset:photo/p0/b1/chars:0:20"
    )
    assert associations[0].evidence_refs[0].quote == "a blue product photo"
    disposition_by_id = {
        item.evidence_id: item for item in completion.dispositions
    }
    assert disposition_by_id["asset:photo/p0/b0"].status == "needs_review"
    assert disposition_by_id["asset:photo/p0/b1"].status == "needs_review"


def test_injected_atomic_evidence_must_replay_exactly_from_known_parent() -> None:
    invalid = _additional_fact("docx:p:0/chars:0:2", "错误")
    invalid.evidence_refs[0].source_ref.range = "chars:0:2"

    with pytest.raises(ValueError, match="atomic evidence is not replayable"):
        build_semantic_completion(
            _evidence("权威标题"),
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[invalid],
        )


def test_unknown_additional_fact_evidence_fails_closed() -> None:
    with pytest.raises(ValueError, match="references unknown evidence ID"):
        build_semantic_completion(
            _evidence("权威标题"),
            "最终版.docx",
            _extracted(structured=(("docx:p:0", "权威标题"),)),
            {"needs_review": False},
            additional_facts=[_additional_fact("missing", "缺失")],
        )


def test_known_inventory_reference_rejects_forged_quote_and_locator() -> None:
    forged_quote = _additional_fact("docx:p:0", "伪造内容")
    with pytest.raises(ValueError, match="quote does not match inventory"):
        build_semantic_completion(
            _evidence("权威标题"),
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[forged_quote],
        )

    forged_page = _additional_fact("docx:p:0", "权威标题")
    forged_page.evidence_refs[0].source_ref.page = 999
    with pytest.raises(ValueError, match="locator conflicts with parent: page"):
        build_semantic_completion(
            _evidence("权威标题"),
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[forged_page],
        )


def test_same_source_evidence_is_revalidated_for_every_fact() -> None:
    valid = _additional_fact("docx:p:0", "权威标题")
    forged = _additional_fact("docx:p:0", "权威标题").model_copy(
        update={
            "fact_id": "semantic_fact:second-reference",
            "name": "second_note",
            "value": "second",
        },
        deep=True,
    )
    forged.evidence_refs[0].quote = "伪造内容"

    with pytest.raises(ValueError, match="quote does not match inventory"):
        build_semantic_completion(
            _evidence("权威标题"),
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[valid, forged],
        )


def test_intentional_quote_normalization_requires_explicit_mode() -> None:
    evidence = _evidence("  Ａ   B  ")
    normalized = _additional_fact("docx:p:0", "A B")
    with pytest.raises(ValueError, match="quote does not match inventory"):
        build_semantic_completion(
            evidence,
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[normalized],
        )

    normalized.evidence_refs[0].source_ref = SourceReference(
        page=1,
        part="mineru/docx:p:0",
        quote_normalization="nfkc_whitespace_v1",
    )
    completion = build_semantic_completion(
        evidence,
        "最终版.docx",
        _extracted(),
        {"needs_review": False},
        additional_facts=[normalized],
    )
    assert completion.facts == [normalized]


def test_filename_evidence_must_replay_exact_stem_range() -> None:
    forged = _additional_fact("source.filename", "伪造")
    forged = forged.model_copy(
        update={"status": "advisory", "fact_id": "semantic_fact:forged-filename"},
        deep=True,
    )
    forged.evidence_refs[0].source_ref = SourceReference(
        part="source.original_filename",
        range="chars:0:2",
        authority="advisory",
        inferred=True,
        parent_evidence_id="source.filename",
    )

    with pytest.raises(ValueError, match="source.filename semantic evidence"):
        build_semantic_completion(
            _evidence("权威标题"),
            "真实名称.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[forged],
        )


def test_direct_visual_reference_rejects_bbox_and_asset_sha_conflicts() -> None:
    evidence = _drawing_evidence("caption")
    evidence.pages[0].blocks[0].bbox = EvidenceBBox(
        x0=0,
        y0=0,
        x1=20,
        y1=20,
        coordinate_space="normalized",
    )
    forged_bbox = _additional_fact("asset:drawing/p0/b0", "caption")
    forged_bbox.evidence_refs[0].source_ref = SourceReference(
        page=1,
        part="mineru/asset:drawing/p0/b0",
        bbox=[1.0, 1.0, 20.0, 20.0],
        coordinate_space="normalized",
        asset_sha256="a" * 64,
    )
    with pytest.raises(ValueError, match="bbox conflicts with parent"):
        build_semantic_completion(
            evidence,
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[forged_bbox],
        )

    forged_sha = _additional_fact("asset:drawing/p0/b0", "caption")
    forged_sha.evidence_refs[0].source_ref = SourceReference(
        page=1,
        part="mineru/asset:drawing/p0/b0",
        asset_sha256="b" * 64,
    )
    with pytest.raises(ValueError, match="asset_sha256 conflicts with parent"):
        build_semantic_completion(
            evidence,
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[forged_sha],
        )


def test_visual_description_is_trimmed_before_evidence_construction() -> None:
    raw = "  product photo \n"
    completion = build_semantic_completion(
        _visual_evidence(("asset:photo/p0/b0", "a" * 64, raw)),
        "最终版.docx",
        _extracted(),
        {"lines": [{}], "needs_review": False},
    )

    association = next(
        fact
        for fact in completion.facts
        if fact.name == "product_image_association"
    )
    reference = association.evidence_refs[0]
    assert reference.quote == "product photo"
    assert reference.evidence_id == "asset:photo/p0/b0/chars:2:15"
    assert reference.source_ref.range == "chars:2:15"
    assert raw[2:15] == reference.quote


def test_whitespace_only_visual_description_produces_no_semantic_fact() -> None:
    completion = build_semantic_completion(
        _visual_evidence(("asset:photo/p0/b0", "a" * 64, " \t\n ")),
        "最终版.docx",
        _extracted(),
        {"lines": [{}], "needs_review": False},
    )
    assert not any(
        fact.name == "product_image_association" for fact in completion.facts
    )


def test_region_supplemental_fact_requires_complete_replay_contract() -> None:
    fact = _region_fact()
    completion = build_semantic_completion(
        _drawing_evidence("flattened caption"),
        "最终版.docx",
        _extracted(),
        {"needs_review": False},
        additional_facts=[fact],
    )

    assert fact in completion.facts
    assert completion.counts.supplemental_evidence_advisory == 1
    assert completion.counts.supplemental_facts_advisory == 1


@pytest.mark.parametrize(
    ("fact", "message"),
    [
        (
            _region_fact(source_ref_updates={"asset_sha256": "b" * 64}),
            "provenance contract",
        ),
        (
            _region_fact(source_ref_updates={"region_sha256": "d" * 64}),
            "provenance contract",
        ),
        (
            _region_fact(source_ref_updates={"asset_width_pixels": 50}),
            "geometry contract",
        ),
        (
            _region_fact(
                source_ref_updates={
                    "region_crop_bbox_pixels": [20, 0, 132, 50]
                }
            ),
            "geometry contract",
        ),
        (
            _region_fact(
                source_ref_updates={"region_output_size_pixels": [1, 1]}
            ),
            "geometry contract",
        ),
        (
            _region_fact(
                source_ref_updates={"region_hash_basis": "raw_pixels"}
            ),
            "transform contract",
        ),
        (
            _region_fact(source_ref_updates={"authority": "verified"}),
            "provenance contract",
        ),
        (
            _region_fact(fact_updates={"status": "verified"}),
            "authority contract",
        ),
        (
            _region_fact(fact_updates={"extractor": "unknown"}),
            "authority contract",
        ),
        (
            _region_fact(quote="R1.1"),
            "inconsistent with its transcription",
        ),
    ],
)
def test_region_supplemental_forgery_fails_closed(
    fact: SemanticFact,
    message: str,
) -> None:
    with pytest.raises(ValueError, match=message):
        build_semantic_completion(
            _drawing_evidence("flattened caption"),
            "最终版.docx",
            _extracted(),
            {"needs_review": False},
            additional_facts=[fact],
        )


def test_supplemental_atomic_facts_cannot_inflate_source_semantic_ratio() -> None:
    parent_text = "".join(chr(0x4E00 + index) for index in range(100))
    facts: list[SemanticFact] = []
    for index, quote in enumerate(parent_text):
        evidence_id = f"docx:p:0/chars:{index}:{index + 1}"
        fact = _additional_fact(evidence_id, quote)
        fact.evidence_refs[0].source_ref = SourceReference(
            page=1,
            part="mineru/docx:p:0",
            range=f"chars:{index}:{index + 1}",
        )
        facts.append(fact)

    completion = build_semantic_completion(
        _evidence(parent_text),
        "最终版.docx",
        _extracted(),
        {"needs_review": False},
        additional_facts=facts,
    )

    assert completion.counts.source_evidence_total == 2
    assert completion.counts.supplemental_evidence_total == 100
    assert completion.counts.source_evidence_verified == 0
    assert completion.counts.supplemental_evidence_verified == 100
    assert completion.ratios.source_semantically_verified == 0.0
    assert completion.ratios.source_structured == 0.0
    assert completion.ratios.audited_structured == 0.0
    assert completion.ratios.audit_completeness == 1.0


def test_matching_region_fact_suppresses_flattened_duplicate_as_redundant() -> None:
    region = _region_fact()
    completion = build_semantic_completion(
        _drawing_evidence("R1.1 20.9±0.06"),
        "最终版.docx",
        _extracted(),
        {"lines": [{}], "needs_review": False},
        additional_facts=[region],
    )

    matching = [
        fact
        for fact in completion.facts
        if isinstance(fact.value, dict) and fact.value.get("nominal") == "20.9"
    ]
    assert matching == [region]
    assert region.status == "advisory"
    assert any(
        fact.name == "drawing_radius" and fact.status == "advisory"
        for fact in completion.facts
    )
    disposition = next(
        item
        for item in completion.dispositions
        if item.evidence_id == "asset:drawing/p0/b0/chars:5:14"
    )
    assert disposition.status == "redundant"
    assert disposition.fact_ids == []


def test_conflicting_region_fact_makes_flattened_value_ambiguous() -> None:
    region = _region_fact(
        value={
            "nominal": "19.5",
            "upper_deviation": "0.1",
            "lower_deviation": "-0.05",
        },
        quote="19.5 +0.1/-0.05",
    )
    completion = build_semantic_completion(
        _drawing_evidence("19.5±0.05"),
        "最终版.docx",
        _extracted(),
        {"lines": [{}], "needs_review": False},
        additional_facts=[region],
    )

    matching = [
        fact
        for fact in completion.facts
        if isinstance(fact.value, dict) and fact.value.get("nominal") == "19.5"
    ]
    assert len(matching) == 2
    retained_region = next(
        fact for fact in matching if fact.extractor == "drawing_region_vlm.v1"
    )
    flattened = next(
        fact for fact in matching if fact.extractor == "drawing_semantics.v1"
    )
    assert retained_region == region
    assert retained_region.status == "advisory"
    assert flattened.status == "ambiguous"
    assert flattened.attributes["conflicts_with"] == region.fact_id
    assert completion.review_required is True
    disposition = next(
        item
        for item in completion.dispositions
        if item.evidence_id == "asset:drawing/p0/b0/chars:0:9"
    )
    assert disposition.status == "ambiguous"
    assert flattened.fact_id in disposition.fact_ids
