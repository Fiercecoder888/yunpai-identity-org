from __future__ import annotations

import pytest
from pydantic import ValidationError

from m1.documents.models import SourceReference
from m1.documents.parsing.semantic_facts import (
    SemanticEvidence,
    SemanticFact,
    audit_evidence_dispositions,
    stable_fact_id,
)


def _fact(*, evidence_id: str = "page:1/block:1") -> SemanticFact:
    value = {"nominal": "19.5", "upper": "0.1", "lower": "-0.05"}
    attributes = {"dimension_type": "linear"}
    fact_id = stable_fact_id(
        name="outer_dimension",
        value=value,
        unit="mm",
        subject="HDMI shell",
        relation="has_dimension",
        attributes=attributes,
        evidence_ids=[evidence_id],
    )
    return SemanticFact(
        fact_id=fact_id,
        name="outer_dimension",
        value=value,
        unit="mm",
        subject="HDMI shell",
        relation="has_dimension",
        attributes=attributes,
        evidence_refs=[
            SemanticEvidence(
                evidence_id=evidence_id,
                quote="19.5 +0.1/-0.05",
                source_ref=SourceReference(page=1, part="drawing:dimension:4"),
            )
        ],
        extractor="qwen-vl",
        confidence=0.98,
        status="verified",
    )


def test_audit_accounts_for_every_evidence_once() -> None:
    fact = _fact()
    dispositions = audit_evidence_dispositions(
        [
            "page:1/block:1",
            "page:1/table:1/header:1",
            "page:1/block:2",
            "page:1/decorative:1",
            "page:1/block:3",
            "page:1/block:4",
        ],
        [fact],
        schema_evidence_ids={"page:1/table:1/header:1"},
        redundant_evidence_ids={"page:1/block:2"},
        nonsemantic_evidence_ids={"page:1/decorative:1"},
        ambiguous_evidence_ids={"page:1/block:3"},
    )

    assert [disposition.evidence_id for disposition in dispositions] == [
        "page:1/block:1",
        "page:1/table:1/header:1",
        "page:1/block:2",
        "page:1/decorative:1",
        "page:1/block:3",
        "page:1/block:4",
    ]
    assert [disposition.status for disposition in dispositions] == [
        "structured",
        "schema",
        "redundant",
        "non_semantic",
        "ambiguous",
        "needs_review",
    ]
    assert dispositions[0].fact_ids == [fact.fact_id]
    assert all(not item.fact_ids for item in dispositions[1:])


def test_audit_rejects_overlapping_dispositions() -> None:
    fact = _fact()

    with pytest.raises(ValueError, match="evidence disposition overlap"):
        audit_evidence_dispositions(
            ["page:1/block:1"],
            [fact],
            schema_evidence_ids={"page:1/block:1"},
        )


def test_audit_rejects_unknown_fact_evidence() -> None:
    fact = _fact(evidence_id="page:2/block:9")

    with pytest.raises(ValueError, match="references unknown evidence ID"):
        audit_evidence_dispositions(["page:1/block:1"], [fact])


def test_audit_accepts_existing_structured_evidence_without_a_new_fact() -> None:
    dispositions = audit_evidence_dispositions(
        ["existing:field", "new:fact"],
        [_fact(evidence_id="new:fact")],
        structured_evidence_ids={"existing:field"},
    )

    assert [item.status for item in dispositions] == ["structured", "structured"]
    assert dispositions[0].fact_ids == []
    assert dispositions[0].reason == "existing_structured_evidence"
    assert dispositions[1].fact_ids
    assert dispositions[1].reason == "referenced_by_semantic_fact"


def test_audit_rejects_structured_evidence_overlapping_another_disposition() -> None:
    with pytest.raises(ValueError, match="evidence disposition overlap"):
        audit_evidence_dispositions(
            ["existing:field"],
            [],
            structured_evidence_ids={"existing:field"},
            schema_evidence_ids={"existing:field"},
        )


def test_audit_rejects_unknown_existing_structured_evidence() -> None:
    with pytest.raises(ValueError, match="structured contains unknown evidence IDs"):
        audit_evidence_dispositions(
            ["known"],
            [],
            structured_evidence_ids={"unknown"},
        )


def test_ambiguous_fact_takes_priority_and_retains_all_fact_ids() -> None:
    verified = _fact()
    ambiguous = verified.model_copy(
        update={
            "fact_id": "semantic_fact:ambiguous",
            "status": "ambiguous",
            "value": {"nominal": "19.5", "interpretation": "uncertain"},
        }
    )

    dispositions = audit_evidence_dispositions(
        ["page:1/block:1"],
        [verified, ambiguous],
        structured_evidence_ids={"page:1/block:1"},
    )

    assert dispositions[0].status == "ambiguous"
    assert dispositions[0].fact_ids == [verified.fact_id, ambiguous.fact_id]
    assert dispositions[0].reason == "referenced_by_ambiguous_semantic_fact"


def test_ambiguous_fact_still_conflicts_with_schema_disposition() -> None:
    ambiguous = _fact().model_copy(
        update={"fact_id": "semantic_fact:ambiguous", "status": "ambiguous"}
    )

    with pytest.raises(ValueError, match="evidence disposition overlap"):
        audit_evidence_dispositions(
            ["page:1/block:1"],
            [ambiguous],
            schema_evidence_ids={"page:1/block:1"},
        )


def test_stable_fact_id_is_canonical_and_content_sensitive() -> None:
    first = stable_fact_id(
        name="color",
        value="space gray",
        attributes={"source": "filename", "language": "en"},
        evidence_ids=["b", "a", "a"],
    )
    reordered = stable_fact_id(
        name="color",
        value="space gray",
        attributes={"language": "en", "source": "filename"},
        evidence_ids=["a", "b"],
    )
    changed = stable_fact_id(
        name="color",
        value="blue",
        attributes={"language": "en", "source": "filename"},
        evidence_ids=["a", "b"],
    )

    assert first == reordered
    assert first.startswith("semantic_fact:")
    assert len(first.removeprefix("semantic_fact:")) == 64
    assert changed != first


def test_semantic_fact_model_dump_preserves_evidence_and_is_strict() -> None:
    fact = _fact()

    payload = fact.model_dump(mode="json")

    assert payload["value"] == {
        "nominal": "19.5",
        "upper": "0.1",
        "lower": "-0.05",
    }
    assert payload["fact_id"] == stable_fact_id(
        name="outer_dimension",
        value={"lower": "-0.05", "nominal": "19.5", "upper": "0.1"},
        unit="mm",
        subject="HDMI shell",
        relation="has_dimension",
        attributes={"dimension_type": "linear"},
        evidence_ids=["page:1/block:1"],
    )
    assert payload["evidence_refs"] == [
        {
            "evidence_id": "page:1/block:1",
            "quote": "19.5 +0.1/-0.05",
            "source_ref": {
                "sheet": None,
                "page": 1,
                "cell": None,
                "range": None,
                "part": "drawing:dimension:4",
                "archive_path": None,
            },
        }
    ]
    with pytest.raises(ValidationError):
        SemanticFact.model_validate({**payload, "unexpected": True})
