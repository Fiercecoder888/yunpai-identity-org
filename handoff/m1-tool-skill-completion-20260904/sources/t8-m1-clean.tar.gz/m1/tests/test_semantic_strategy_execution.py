from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from m1.documents.models import DocumentRecord, DocumentSource
from m1.documents.parsing.evidence import DocumentEvidence, EvidenceBlock, EvidencePage
from m1.state import TaskState, TaskStatus
from m1.workflow.engine import WorkflowEngine


def _classification_evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1000,
                blocks=[
                    EvidenceBlock(
                        block_id="p1:title",
                        kind="title",
                        text="采购订单",
                        confidence=0.99,
                    )
                ],
            )
        ],
    )


def _routed_unknown_document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "order.pdf"},
        "document_type": "unknown",
        "document_subtype": "unknown",
        "header": {"title": "采购订单"},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "needs_review": True,
        "validation_issues": [
            {
                "code": "DOCUMENT_CLASSIFICATION_ROUTE_REMAP_REQUIRED",
                "severity": "warning",
                "message": "mapper replay required",
            }
        ],
        "extraction": {
            "metadata": {
                "classification_routing": {
                    "schema_version": "m1.document-classification-routing.v1",
                    "action": "reuse",
                    "reason": "exact_active_profile",
                    "document_type": "order",
                    "document_subtype": "supplier_purchase_order",
                    "applied_fields": [],
                    "advisory_fields": ["document_type", "document_subtype"],
                    "application_status": "mapper_replay_required",
                }
            }
        },
    }


@pytest.mark.asyncio
async def test_classification_taxonomy_changes_only_after_closed_mapper_replay(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "order.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    calls: list[dict] = []

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **kwargs):
            calls.append(kwargs)
            return SimpleNamespace(
                document=DocumentRecord(
                    source=DocumentSource(original_filename=source.name),
                    document_type="order",
                    document_subtype="supplier_purchase_order",
                    extraction={"metadata": {"mapper": "replayed"}},
                ),
                summary={"status": "completed"},
            )

    gate = SimpleNamespace(accepted=True, summary=lambda: {"passed": True})
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: gate,
    )
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=FullRunner())
    engine._save = AsyncMock()
    state = TaskState(
        task_id="classification-replay",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )
    routed = _routed_unknown_document()

    result = await engine._replay_classification_mapper(
        state,
        original={"document_type": "unknown", "lines": []},
        routed=routed,
        evidence=_classification_evidence(),
    )

    assert result["document_type"] == "order"
    assert result["document_subtype"] == "supplier_purchase_order"
    execution = calls[0]["semantic_execution"]
    assert execution.mapper_id.value == "order_evidence_mapper_v1"
    assert execution.schema_id.value == "m1.semantic.order.v1"
    assert execution.prompt_id.value == "m1.prompt.semantic.order.v1"
    assert calls[0]["route_plan"] is None
    routing = result["extraction"]["metadata"]["classification_routing"]
    assert routing["application_status"] == "mapper_replayed"
    assert routing["mapper_replay"]["accepted"] is True


@pytest.mark.asyncio
async def test_classification_without_replay_keeps_original_taxonomy_and_review() -> (
    None
):
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=None)
    state = SimpleNamespace()
    routed = _routed_unknown_document()

    result = await engine._replay_classification_mapper(
        state,
        original={"document_type": "unknown", "lines": []},
        routed=routed,
        evidence=_classification_evidence(),
    )

    assert result["document_type"] == "unknown"
    assert result["document_subtype"] == "unknown"
    assert result["needs_review"] is True
    routing = result["extraction"]["metadata"]["classification_routing"]
    assert routing["application_status"] == "mapper_replay_unavailable"


@pytest.mark.asyncio
async def test_full_mineru_receives_only_live_route_and_semantic_capabilities(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from m1.documents.parsing.document_route_plan import DocumentRoutePlan
    from m1.documents.parsing.document_route_policy import (
        RouteDocumentType,
        RouteSchemaFamily,
    )
    from m1.documents.parsing.semantic_strategy_executor import SemanticStrategyExecutor
    from m1.documents.parsing.semantic_strategy_router import SemanticStrategyRouter

    source = tmp_path / "routed.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    calls: list[dict] = []
    plan = DocumentRoutePlan(
        mode="guarded",
        recommendation="reuse",
        reason="exact_fingerprint",
        signature_fingerprint="a" * 64,
        route_id="route-order",
        backend_chain=("mineru",),
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        policy_applied=True,
    )
    semantic = SemanticStrategyExecutor.bind(
        SemanticStrategyRouter().resolve(
            _classification_evidence(),
            route_plan=plan,
        )
    )

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **kwargs):
            calls.append(kwargs)
            return SimpleNamespace(
                document=DocumentRecord(
                    source=DocumentSource(original_filename=source.name),
                    document_type="order",
                ),
                summary={},
            )

    gate = SimpleNamespace(accepted=True, summary=lambda: {"passed": True})
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: gate,
    )
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=FullRunner())
    engine._save = AsyncMock()
    engine._classification_route_stage = AsyncMock(side_effect=lambda _s, doc: doc)
    engine._validation_stage = lambda document, _native: document
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="live-capability",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )
    engine._activate_route_plan(state, plan)
    engine._activate_semantic_execution(state, semantic)

    await engine._run_mineru_full_pipeline(
        state,
        active_route_plan=plan,
        route_plan=plan.value_free_dump(),
    )

    assert calls[0]["route_plan"] is plan
    assert calls[0]["semantic_execution"] is semantic
    engine._knowledge_sync_stage.assert_awaited_once()
