from __future__ import annotations

import pytest
from m1.documents.parsing.document_route_plan import DocumentRoutePlan
from m1.documents.parsing.document_route_policy import (
    RouteAuthorityPolicy,
    RouteDocumentType,
    RouteProfilePolicy,
    RouteSchemaFamily,
    RouteTablePolicy,
    RouteTableRole,
    RouteVerifierPolicy,
)
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBBox,
    EvidenceBlock,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.semantic_strategy_executor import (
    SemanticExecutionSpec,
    SemanticStrategyExecutor,
)
from m1.documents.parsing.semantic_strategy_router import (
    SemanticStrategyId,
    SemanticStrategyModelChoice,
    SemanticStrategyRouter,
    build_document_semantic_topology,
    registered_semantic_strategies,
)
from pydantic import ValidationError


def _evidence(
    *, visual: bool = False, confidential: str = "SO-SECRET-9001"
) -> DocumentEvidence:
    blocks = [
        EvidenceBlock(
            block_id="p1:title",
            kind="title",
            text=f"confidential {confidential}",
            confidence=0.99,
        )
    ]
    if visual:
        blocks.append(
            EvidenceBlock(
                block_id="p1:image",
                kind="figure",
                text="",
                bbox=EvidenceBBox(x0=0, y0=0, x1=900, y1=900),
            )
        )
    return DocumentEvidence(
        backend="fixture",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=1000,
                height=1000,
                blocks=blocks,
                tables=[
                    EvidenceTable(
                        table_id="t1",
                        rows=[["secret header", confidential], ["quantity", "100"]],
                    )
                ],
            )
        ],
    )


def _order_policy() -> RouteProfilePolicy:
    return RouteProfilePolicy(
        schema_family=RouteSchemaFamily.ORDER,
        document_type_hint=RouteDocumentType.ORDER,
        table_roles=(RouteTablePolicy(table_index=0, role=RouteTableRole.ORDER_LINES),),
        verifier_policy=RouteVerifierPolicy.ALWAYS,
        visual_policy="disabled",
        authority_policy=RouteAuthorityPolicy.CORE_STRICT,
    )


def test_registered_strategies_are_closed_and_prompt_text_is_absent() -> None:
    registry = registered_semantic_strategies()

    assert SemanticStrategyId.ORDER in registry
    with pytest.raises(TypeError):
        registry[SemanticStrategyId.ORDER] = registry[SemanticStrategyId.ORDER]
    assert not hasattr(registry[SemanticStrategyId.ORDER], "prompt")
    assert registry[SemanticStrategyId.ORDER].prompt_id.value.endswith(".v1")


def test_route_policy_selects_order_strategy_and_overrides_closed_policies() -> None:
    router = SemanticStrategyRouter()
    decision = router.resolve(_evidence(visual=True), route_policy=_order_policy())

    assert decision.strategy_id is SemanticStrategyId.ORDER
    assert decision.verifier_policy is RouteVerifierPolicy.ALWAYS
    assert decision.visual_policy == "disabled"
    assert decision.authority_policy is RouteAuthorityPolicy.CORE_STRICT
    assert decision.reason_codes == ("route_schema_family",)


def test_table_role_specializes_generic_route_without_cell_value_access() -> None:
    router = SemanticStrategyRouter()
    policy = RouteProfilePolicy(
        table_roles=(
            RouteTablePolicy(table_index=0, role=RouteTableRole.INVENTORY_LINES),
        )
    )
    evidence = _evidence(confidential="MATERIAL-SECRET-88")

    request, basis = router.selection_request(evidence, route_policy=policy)

    assert basis == "route_table_role"
    assert request.candidates[0].strategy_id is SemanticStrategyId.INVENTORY
    serialized = request.model_dump_json()
    assert "MATERIAL-SECRET-88" not in serialized
    assert "secret header" not in serialized
    assert "confidential" not in serialized


def test_visual_topology_selects_closed_visual_generic_strategy() -> None:
    router = SemanticStrategyRouter()
    decision = router.resolve(_evidence(visual=True))

    assert decision.strategy_id is SemanticStrategyId.VISUAL_GENERIC
    assert decision.budget.max_visual_regions == 16
    assert decision.topology.visual_page_count == 1
    assert "visual_topology" in decision.reason_codes


def test_invalid_or_out_of_candidate_model_choice_fails_closed_to_default() -> None:
    router = SemanticStrategyRouter(model_min_confidence=0.85)
    evidence = _evidence()
    policy = _order_policy()

    invalid = router.resolve(evidence, route_policy=policy, model_choice={"x": 1})
    rejected = router.resolve(
        evidence,
        route_policy=policy,
        model_choice=SemanticStrategyModelChoice(
            strategy_id=SemanticStrategyId.TECHNICAL,
            confidence=0.99,
        ),
    )
    low_confidence = router.resolve(
        evidence,
        route_policy=policy,
        model_choice=SemanticStrategyModelChoice(
            strategy_id=SemanticStrategyId.GENERIC,
            confidence=0.84,
        ),
    )

    assert invalid.strategy_id is SemanticStrategyId.ORDER
    assert invalid.reason_codes[-1] == "invalid_model_choice"
    assert rejected.strategy_id is SemanticStrategyId.ORDER
    assert rejected.reason_codes[-1] == "model_candidate_rejected"
    assert low_confidence.strategy_id is SemanticStrategyId.ORDER
    assert low_confidence.reason_codes[-1] == "model_confidence_below_threshold"


def test_valid_model_may_choose_only_registered_fallback_candidate() -> None:
    router = SemanticStrategyRouter(model_min_confidence=0.80)
    decision = router.resolve(
        _evidence(),
        route_policy=_order_policy(),
        model_choice={"strategy_id": "generic_evidence_v1", "confidence": 0.90},
    )

    assert decision.strategy_id is SemanticStrategyId.GENERIC
    assert decision.model_used is True
    assert decision.reason_codes[-1] == "model_selected"


@pytest.mark.asyncio
async def test_selector_failure_preserves_deterministic_route() -> None:
    class FailingSelector:
        async def select(self, _request):
            raise TimeoutError("model unavailable")

    decision = await SemanticStrategyRouter().resolve_with_selector(
        _evidence(),
        selector=FailingSelector(),
        route_policy=_order_policy(),
    )

    assert decision.strategy_id is SemanticStrategyId.ORDER
    assert decision.model_used is True
    assert decision.reason_codes[-1] == "model_failure"


@pytest.mark.asyncio
async def test_selector_is_not_called_when_registry_has_no_alternative() -> None:
    class MustNotRunSelector:
        async def select(self, _request):
            raise AssertionError("a model must not run without a closed alternative")

    decision = await SemanticStrategyRouter().resolve_with_selector(
        _evidence(),
        selector=MustNotRunSelector(),
    )

    assert decision.strategy_id is SemanticStrategyId.GENERIC
    assert decision.model_used is False
    assert decision.reason_codes == ("generic_fallback",)


def test_route_plan_context_reuses_the_existing_policy_shape() -> None:
    plan = DocumentRoutePlan(
        mode="guarded",
        recommendation="reuse",
        reason="exact_fingerprint",
        signature_fingerprint="a" * 64,
        route_id="route-a",
        backend_chain=("mineru",),
        schema_family=RouteSchemaFamily.MOLD,
        document_type_hint=RouteDocumentType.MOLD,
        table_roles=(
            RouteTablePolicy(table_index=0, role=RouteTableRole.MOLD_MAPPING),
        ),
        verifier_policy=RouteVerifierPolicy.ON_UNCERTAINTY,
        visual_policy="on_uncertainty",
        authority_policy=RouteAuthorityPolicy.EVIDENCE_REQUIRED,
        policy_applied=True,
    )

    decision = SemanticStrategyRouter().resolve(_evidence(), route_plan=plan)

    assert decision.strategy_id is SemanticStrategyId.MOLD
    assert decision.route_context.policy_applied is True


def test_topology_contains_only_aggregate_quality_and_shape_signals() -> None:
    topology = build_document_semantic_topology(_evidence(visual=True))

    assert topology.page_count == 1
    assert topology.table_count == 1
    assert topology.table_cell_count == 4
    assert topology.visual_page_count == 1
    assert "SO-SECRET" not in topology.model_dump_json()


def test_model_choice_rejects_unrecognized_fields() -> None:
    with pytest.raises(ValidationError):
        SemanticStrategyModelChoice.model_validate(
            {
                "strategy_id": "generic_evidence_v1",
                "confidence": 0.99,
                "endpoint": "http://untrusted.invalid/v1",
            },
        )


def test_registered_decision_binds_real_mapper_schema_prompt_and_budget() -> None:
    decision = SemanticStrategyRouter().resolve(
        _evidence(),
        route_policy=_order_policy(),
    )

    execution = SemanticStrategyExecutor.bind(decision)

    assert execution.strategy_id is SemanticStrategyId.ORDER
    assert execution.mapper_id.value == "order_evidence_mapper_v1"
    assert execution.schema_id.value == "m1.semantic.order.v1"
    assert execution.prompt_id.value == "m1.prompt.semantic.order.v1"
    assert execution.document_type_hint is RouteDocumentType.ORDER
    assert (
        SemanticStrategyExecutor.output_schema_name(
            execution,
            role="document_intent",
        )
        == "DocumentIntent"
    )

    class DocumentIntent:
        pass

    SemanticStrategyExecutor.validate_output_schema(
        execution,
        role="document_intent",
        output_type=DocumentIntent,
    )

    class TablePartition:
        pass

    assert (
        SemanticStrategyExecutor.output_schema_name(
            execution,
            role="table_partition",
        )
        == "TablePartition"
    )
    SemanticStrategyExecutor.validate_output_schema(
        execution,
        role="table_partition",
        output_type=TablePartition,
    )
    with pytest.raises(ValueError):
        SemanticStrategyExecutor.validate_output_schema(
            execution,
            role="document_intent",
            output_type=dict,
        )
    assert (
        "order"
        in SemanticStrategyExecutor.prompt_directive(
            execution,
            role="document_intent",
        ).casefold()
    )
    assert SemanticStrategyExecutor.effective_input_limit(execution, 80_000) == 32_000


def test_execution_rejects_metadata_and_tampered_registry_tuple() -> None:
    decision = SemanticStrategyRouter().resolve(
        _evidence(),
        route_policy=_order_policy(),
    )
    execution = SemanticStrategyExecutor.bind(decision)

    with pytest.raises(TypeError):
        SemanticStrategyExecutor.bind(decision.value_free_dump())  # type: ignore[arg-type]
    reconstructed = SemanticExecutionSpec.model_validate(execution.value_free_dump())
    with pytest.raises(ValueError, match="not issued by this process"):
        SemanticStrategyExecutor.validate_capability(reconstructed)
    with pytest.raises(ValueError):
        SemanticStrategyExecutor.validate_capability(
            execution.model_copy(
                update={"mapper_id": "generic_evidence_mapper_v1"},
            )
        )
    with pytest.raises(ValidationError):
        SemanticExecutionSpec.model_validate(
            {**execution.value_free_dump(), "endpoint": "http://untrusted.invalid/v1"}
        )


def test_taxonomy_replay_resolves_only_the_matching_closed_strategy() -> None:
    router = SemanticStrategyRouter()

    inventory = router.resolve_for_taxonomy(
        _evidence(),
        document_type="inventory",
        document_subtype="inventory_snapshot",
    )
    mismatched_subtype = router.resolve_for_taxonomy(
        _evidence(),
        document_type="order",
        document_subtype="mold_mapping",
    )

    assert inventory.strategy_id is SemanticStrategyId.INVENTORY
    assert inventory.route_context.document_subtype_hint.value == "inventory_snapshot"
    assert mismatched_subtype.strategy_id is SemanticStrategyId.ORDER
    assert mismatched_subtype.route_context.document_subtype_hint is None
