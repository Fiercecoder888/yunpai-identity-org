from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import fitz
import pytest

from m1.documents.parsing.source_asset_inventory import (
    SourceAssetInventoryError,
    inventory_source_assets,
)

PIXEL = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+"
    "A8AAQUBAScY42YAAAAASUVORK5CYII="
)


def _content_types(*, kind: str) -> str:
    if kind == "docx":
        override = (
            '<Override PartName="/word/document.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'wordprocessingml.document.main+xml"/>'
        )
    elif kind == "xlsm":
        override = (
            '<Override PartName="/xl/workbook.xml" '
            'ContentType="application/vnd.ms-excel.sheet.macroEnabled.main+xml"/>'
        )
    else:
        override = (
            '<Override PartName="/xl/workbook.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.'
            'spreadsheetml.sheet.main+xml"/>'
        )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
      <Default Extension="xml" ContentType="application/xml"/>
      <Default Extension="png" ContentType="image/png"/>
      {override}
    </Types>"""


def _docx(path: Path) -> None:
    document = """<?xml version="1.0" encoding="UTF-8"?>
    <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
      <w:body>
        <w:p><w:r><w:t>First</w:t><w:drawing><a:blip r:embed="rId1"/></w:drawing></w:r></w:p>
        <w:p><w:r><w:t>Second</w:t><w:drawing><a:blip r:embed="rId2"/></w:drawing></w:r></w:p>
        <w:sectPr/>
      </w:body>
    </w:document>"""
    relationships = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image2.png"/>
    </Relationships>"""
    with ZipFile(path, "w", ZIP_DEFLATED) as package:
        package.writestr("[Content_Types].xml", _content_types(kind="docx"))
        package.writestr("word/document.xml", document)
        package.writestr("word/_rels/document.xml.rels", relationships)
        package.writestr("word/media/image1.png", PIXEL)
        package.writestr("word/media/image2.png", PIXEL)
        package.writestr("word/media/unreferenced.png", b"unreferenced-image")


def _spreadsheet(path: Path, *, kind: str = "xlsx", unsafe: bool = False) -> None:
    workbook = """<?xml version="1.0" encoding="UTF-8"?>
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <sheets><sheet name="Assets" sheetId="1" r:id="rIdSheet"/></sheets>
    </workbook>"""
    workbook_relationships = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rIdSheet" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    </Relationships>"""
    worksheet = """<?xml version="1.0" encoding="UTF-8"?>
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <sheetData>
        <row r="9"><c r="L9" t="str"><f>_xlfn.DISPIMG(&quot;ID_ONE&quot;,1)</f><v>=DISPIMG(&quot;ID_ONE&quot;,1)</v></c></row>
        <row r="10"><c r="M10" t="str"><v>=DISPIMG(&quot;ID_TWO&quot;,1)</v></c></row>
      </sheetData><drawing r:id="rIdDrawing"/>
    </worksheet>"""
    worksheet_relationships = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rIdDrawing" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>
    </Relationships>"""
    drawing = """<?xml version="1.0" encoding="UTF-8"?>
    <xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <xdr:twoCellAnchor>
        <xdr:from><xdr:col>1</xdr:col><xdr:colOff>11</xdr:colOff><xdr:row>4</xdr:row><xdr:rowOff>12</xdr:rowOff></xdr:from>
        <xdr:to><xdr:col>2</xdr:col><xdr:colOff>13</xdr:colOff><xdr:row>5</xdr:row><xdr:rowOff>14</xdr:rowOff></xdr:to>
        <xdr:pic><xdr:nvPicPr><xdr:cNvPr id="1" name="First image" descr="Front"/></xdr:nvPicPr>
          <xdr:blipFill><a:blip r:embed="rId1"/></xdr:blipFill></xdr:pic><xdr:clientData/>
      </xdr:twoCellAnchor>
      <xdr:oneCellAnchor>
        <xdr:from><xdr:col>3</xdr:col><xdr:row>7</xdr:row></xdr:from>
        <xdr:ext cx="100" cy="200"/>
        <xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="Second image"/></xdr:nvPicPr>
          <xdr:blipFill><a:blip r:embed="rId2"/></xdr:blipFill></xdr:pic><xdr:clientData/>
      </xdr:oneCellAnchor>
    </xdr:wsDr>"""
    first_target = "../../../outside.png" if unsafe else "../media/image1.png"
    drawing_relationships = f"""<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="{first_target}"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image2.png"/>
    </Relationships>"""
    cell_images = """<?xml version="1.0" encoding="UTF-8"?>
    <etc:cellImages xmlns:etc="http://www.wps.cn/officeDocument/2017/etCustomData"
      xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing"
      xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
      xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <etc:cellImage><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="1" name="ID_ONE"/></xdr:nvPicPr>
        <xdr:blipFill><a:blip r:embed="rId1"/></xdr:blipFill></xdr:pic></etc:cellImage>
      <etc:cellImage><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="2" name="ID_TWO"/></xdr:nvPicPr>
        <xdr:blipFill><a:blip r:embed="rId2"/></xdr:blipFill></xdr:pic></etc:cellImage>
    </etc:cellImages>"""
    cell_image_relationships = """<?xml version="1.0" encoding="UTF-8"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image2.png"/>
    </Relationships>"""
    with ZipFile(path, "w", ZIP_DEFLATED) as package:
        package.writestr("[Content_Types].xml", _content_types(kind=kind))
        package.writestr("xl/workbook.xml", workbook)
        package.writestr("xl/_rels/workbook.xml.rels", workbook_relationships)
        package.writestr("xl/worksheets/sheet1.xml", worksheet)
        package.writestr(
            "xl/worksheets/_rels/sheet1.xml.rels",
            worksheet_relationships,
        )
        package.writestr("xl/drawings/drawing1.xml", drawing)
        package.writestr(
            "xl/drawings/_rels/drawing1.xml.rels",
            drawing_relationships,
        )
        package.writestr("xl/cellimages.xml", cell_images)
        package.writestr(
            "xl/_rels/cellimages.xml.rels",
            cell_image_relationships,
        )
        package.writestr("xl/media/image1.png", PIXEL)
        package.writestr("xl/media/image2.png", PIXEL)
        package.writestr("xl/media/unreferenced.png", b"unreferenced-image")


def test_pdf_inventory_hashes_images_and_requires_vector_page_render(
    tmp_path: Path,
) -> None:
    source = tmp_path / "drawing.pdf"
    document = fitz.open()
    page = document.new_page(width=200, height=200)
    page.insert_image(fitz.Rect(10, 20, 60, 80), stream=PIXEL)
    page.draw_rect(fitz.Rect(90, 100, 150, 160))
    document.save(source)
    document.close()
    before = set(tmp_path.iterdir())

    first = inventory_source_assets(source)
    second = inventory_source_assets(source)

    assert first.model_dump(mode="json") == second.model_dump(mode="json")
    assert first.source_kind == "pdf"
    assert first.coverage_status == "complete"
    assert len(first.assets) == 1
    asset = first.assets[0]
    assert asset.asset_id == f"asset:sha256:{asset.sha256}"
    assert asset.mime_type == "image/png"
    assert asset.byte_size > 0
    assert asset.parts[0].startswith("pdf:xref:")
    assert asset.source_refs[0].source_ref.page == 1
    assert asset.source_refs[0].anchor is not None
    assert asset.source_refs[0].anchor.bbox == [10.0, 20.0, 60.0, 80.0]
    assert len(first.requirements) == 1
    assert first.requirements[0].kind == "pdf_page_render"
    assert first.requirements[0].vector_drawing_count >= 1
    assert str(source.resolve()) not in str(first.model_dump(mode="json"))
    assert set(tmp_path.iterdir()) == before


def test_docx_inventory_deduplicates_content_but_keeps_parts_and_references(
    tmp_path: Path,
) -> None:
    source = tmp_path / "images.docx"
    _docx(source)

    inventory = inventory_source_assets(source)

    assert inventory.coverage_status == "complete"
    assert inventory.media_part_count == 3
    assert len(inventory.assets) == 2
    shared = next(asset for asset in inventory.assets if asset.sha256 == hashlib.sha256(PIXEL).hexdigest())
    assert shared.parts == ["word/media/image1.png", "word/media/image2.png"]
    assert len(shared.source_refs) == 2
    assert {item.relationship_id for item in shared.source_refs} == {"rId1", "rId2"}
    assert {item.source_ref.part for item in shared.source_refs} == {
        "word/document.xml#paragraph:0",
        "word/document.xml#paragraph:1",
    }
    unreferenced = next(asset for asset in inventory.assets if not asset.source_refs)
    assert unreferenced.parts == ["word/media/unreferenced.png"]
    assert unreferenced.coverage_status == "inventoried_unreferenced"


@pytest.mark.parametrize(("kind", "suffix"), [("xlsx", ".xlsx"), ("xlsm", ".xlsm")])
def test_ooxml_spreadsheet_inventory_preserves_anchors_and_duplicate_references(
    tmp_path: Path,
    kind: str,
    suffix: str,
) -> None:
    source = tmp_path / f"assets{suffix}"
    _spreadsheet(source, kind=kind)

    inventory = inventory_source_assets(source)

    assert inventory.source_kind == kind
    assert inventory.coverage_status == "complete"
    assert inventory.media_part_count == 3
    assert len(inventory.assets) == 2
    shared = next(asset for asset in inventory.assets if len(asset.parts) == 2)
    assert len(shared.source_refs) == 6
    references = {
        item.source_ref.range: item
        for item in shared.source_refs
        if item.anchor is not None
        and item.anchor.kind in {"xlsx_oneCellAnchor", "xlsx_twoCellAnchor"}
    }
    assert set(references) == {"B5:C6", "D8"}
    assert references["B5:C6"].source_ref.sheet == "Assets"
    assert references["B5:C6"].anchor is not None
    assert references["B5:C6"].anchor.from_column_offset == 11
    assert references["B5:C6"].anchor.to_row_offset == 14
    assert references["D8"].anchor is not None
    assert references["D8"].anchor.extent_cx == 100
    wps_references = {
        (item.source_ref.sheet, item.source_ref.cell)
        for item in shared.source_refs
        if item.anchor is not None and item.anchor.kind == "wps_cell_image"
    }
    assert wps_references == {("Assets", "L9"), ("Assets", "M10")}
    unreferenced = next(asset for asset in inventory.assets if not asset.source_refs)
    assert unreferenced.parts == ["xl/media/unreferenced.png"]


def test_spreadsheet_inventory_rejects_relationship_escape(tmp_path: Path) -> None:
    source = tmp_path / "unsafe.xlsx"
    _spreadsheet(source, unsafe=True)

    with pytest.raises(SourceAssetInventoryError, match="escapes the package"):
        inventory_source_assets(source)


def test_binary_xls_returns_explicit_unsupported_inventory(tmp_path: Path) -> None:
    source = tmp_path / "legacy.xls"
    source.write_bytes(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 64)

    inventory = inventory_source_assets(source)

    assert inventory.source_kind == "xls"
    assert inventory.coverage_status == "unsupported"
    assert inventory.assets == []
    assert inventory.warnings == ["binary_xls_asset_inventory_unsupported"]
