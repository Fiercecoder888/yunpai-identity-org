from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from m1.state import TaskState, TaskStatus
from m1.workflow.engine import WorkflowEngine
from m1.workflow.persistence import DocumentRow, TaskStore
from sqlalchemy import select


def _document(digest: str, *, needs_review: bool = False) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {"original_filename": "source.pdf", "sha256": digest},
        "document_type": "technical_document",
        "document_subtype": "product_specification",
        "header": {"title": "replay fixture"},
        "lines": [],
        "totals": {},
        "field_meta": {},
        "validation_issues": [],
        "needs_review": needs_review,
        "extraction": {
            "metadata": {
                "route_plan": {
                    "contract_revision": "m1.document.v2",
                    "parser_revision": "parser-r1",
                }
            }
        },
    }


async def _persist(
    store: TaskStore,
    tmp_path: Path,
    *,
    task_id: str,
    tenant_id: str,
    digest: str,
    status: TaskStatus = TaskStatus.DONE,
    needs_review: bool = False,
    parser_revision: str = "parser-r1",
    model_revision: str = "model-r1",
) -> None:
    document = _document(digest, needs_review=needs_review)
    document["extraction"]["metadata"]["route_plan"][
        "parser_revision"
    ] = parser_revision
    state = TaskState(
        task_id=task_id,
        tenant_id=tenant_id,
        file_path=str(tmp_path / "source.pdf"),
        original_filename="source.pdf",
        status=status,
        processing_stage="completed" if status == TaskStatus.DONE else "failed",
        mineru_shadow={"model_revision": model_revision},
    )
    await store.save(state)
    await store.save_document(task_id, document)
    state.document = document
    state.document_schema_version = "m1.document.v2"
    await store.save(state)


@pytest.mark.asyncio
async def test_source_sha_replay_requires_exact_scope_and_revisions(
    tmp_path: Path,
) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'replay.db').as_posix()}")
    await store.init()
    digest = "a" * 64
    await _persist(store, tmp_path, task_id="done-a", tenant_id="tenant-a", digest=digest)

    with pytest.raises(ValueError, match="64-character"):
        await store.find_replayable_document(
            digest[:12],
            tenant_id="tenant-a",
            parser_revision="parser-r1",
            model_revision="model-r1",
        )

    hit = await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r1",
    )
    assert hit is not None
    assert hit["task_id"] == "done-a"
    assert hit["document"]["source"]["sha256"] == digest

    # A fresh decode prevents a caller from mutating the persisted replay.
    hit["document"]["header"]["title"] = "mutated"
    again = await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r1",
    )
    assert again is not None
    assert again["document"]["header"]["title"] == "replay fixture"

    assert await store.find_replayable_document(
        digest,
        tenant_id="tenant-b",
        parser_revision="parser-r1",
        model_revision="model-r1",
    ) is None
    assert await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r2",
        model_revision="model-r1",
    ) is None
    assert await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r2",
    ) is None

    # A conflicting duplicate declaration is ambiguous, even when one value
    # happens to equal the current revision.
    async with store.sessionmaker() as session:
        row = (
            await session.execute(
                select(DocumentRow).where(DocumentRow.task_id == "done-a")
            )
        ).scalar_one()
        payload = json.loads(row.document_json)
        payload["extraction"]["metadata"]["parser_revision"] = "parser-r2"
        row.document_json = json.dumps(payload, ensure_ascii=False)
        await session.commit()
    assert await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r1",
    ) is None
    await store.close()


@pytest.mark.asyncio
async def test_source_sha_replay_excludes_review_and_failed_rows(tmp_path: Path) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'gates.db').as_posix()}")
    await store.init()
    digest = "b" * 64
    await _persist(
        store,
        tmp_path,
        task_id="review-row",
        tenant_id="tenant-a",
        digest=digest,
        needs_review=True,
    )
    assert await store.find_replayable_document(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r1",
    ) is None

    await _persist(
        store,
        tmp_path,
        task_id="failed-row",
        tenant_id="tenant-a",
        digest="c" * 64,
        status=TaskStatus.FAILED,
    )
    assert await store.find_replayable_document(
        "c" * 64,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
        model_revision="model-r1",
    ) is None
    await store.close()


@pytest.mark.asyncio
async def test_workflow_engine_replay_uses_configured_model_revision(
    tmp_path: Path,
) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'engine.db').as_posix()}")
    await store.init()
    digest = "d" * 64
    await _persist(store, tmp_path, task_id="engine-row", tenant_id="tenant-a", digest=digest)
    deps = SimpleNamespace(
        mineru_shadow_runner=SimpleNamespace(
            client=SimpleNamespace(model_revision="model-r1")
        )
    )
    engine = WorkflowEngine(deps, store)
    hit = await engine.replay_source_sha(digest, tenant_id="tenant-a", parser_revision="parser-r1")
    assert hit is not None
    assert hit["task_id"] == "engine-row"

    # A changed configured model must fail closed without rerunning anything.
    deps.mineru_shadow_runner.client.model_revision = "model-r2"
    assert await engine.replay_source_sha(
        digest,
        tenant_id="tenant-a",
        parser_revision="parser-r1",
    ) is None
    await store.close()
