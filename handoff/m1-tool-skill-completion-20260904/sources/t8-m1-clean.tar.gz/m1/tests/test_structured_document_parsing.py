from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import os
import sys
import threading
import time
import weakref
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from typing import ClassVar

import pytest
from m1.documents.adapters.pdf_order import _extract_pdf_header
from m1.documents.models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
)
from m1.documents.parsing import (
    DocumentEvidence,
    DocumentParserService,
    EvidenceBBox,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.base import ParserBackendError
from m1.documents.parsing.comparison import compare_document_records
from m1.documents.parsing.service import (
    _blocking_evidence_pages,
    _has_blocking_evidence_issue,
    _has_deterministic_drawing_content,
    _merge_vlm_supplement,
    apply_evidence_to_pdf_document,
)
from m1.documents.parsing.structured import (
    PARSER_MODEL_REQUIREMENTS,
    PaddleOCRVLBackend,
    PPStructureV3Backend,
    _device_available,
    merge_evidence,
)
from PIL import Image


class FakeBackend:
    def __init__(self, evidence: DocumentEvidence, name: str = "fake-structured") -> None:
        self.name = name
        self.evidence = evidence
        self.calls = 0

    def readiness(self) -> dict[str, object]:
        return {"backend": self.name, "ready": True}

    def parse(self, path, *, pages=None) -> DocumentEvidence:
        self.calls += 1
        return self.evidence.model_copy(deep=True)


class FailingBackend(FakeBackend):
    def __init__(self, exc: BaseException, name: str = "fake-vlm") -> None:
        super().__init__(DocumentEvidence(backend=name), name=name)
        self.exc = exc

    def parse(self, path, *, pages=None) -> DocumentEvidence:
        self.calls += 1
        raise self.exc


def _evidence(*, confidence: float = 0.99) -> DocumentEvidence:
    cells = []
    rows = [["序号", "品名", "数量"], ["1", "测试线缆", "2"]]
    for row_index, row in enumerate(rows):
        for column_index, value in enumerate(row):
            cells.append(
                EvidenceCell(
                    row=row_index,
                    column=column_index,
                    text=value,
                    confidence=confidence,
                    bbox=EvidenceBBox(
                        x0=column_index * 100,
                        y0=100 + row_index * 40,
                        x1=(column_index + 1) * 100,
                        y1=140 + row_index * 40,
                    ),
                )
            )
    return DocumentEvidence(
        backend="fake-structured",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                blocks=[
                    EvidenceBlock(
                        block_id="title",
                        text="采购合同\n合同编号：MODEL-WRONG\n下单日期：2026-07-15",
                        confidence=confidence,
                        bbox=EvidenceBBox(x0=10, y0=10, x1=500, y1=80),
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="table-1",
                        rows=rows,
                        cells=cells,
                        bbox=EvidenceBBox(x0=0, y0=100, x1=300, y1=180),
                        source="fake-structured",
                    )
                ],
            )
        ],
    )


def _baseline(render_asset: str) -> DocumentRecord:
    return DocumentRecord(
        source=DocumentSource(
            original_filename="采购函.pdf",
            sha256="a" * 64,
            mime_type="application/pdf",
        ),
        document_type="order",
        document_subtype="purchase_contract",
        header=DocumentHeader(
            contract_number="HT-2026-001",
            date_raw="2026-07-15",
            buyer="广西桐曦电子科技有限公司",
        ),
        lines=[OrderLine(line_id="native:1", line_no=1, name_raw="原生行", quantity=1)],
        field_meta={
            "$.header.contract_number": FieldMetadata(
                confidence=1.0,
                source_refs=[SourceReference(page=1, part="native/text")],
            )
        },
        extraction={
            "raw_content": {
                "text_original": "采购合同",
                "text_normalized": "采购合同",
                "pages": [
                    {
                        "page_number": 1,
                        "page_index": 0,
                        "width": 300.0,
                        "height": 400.0,
                        "coordinate_width": 300.0,
                        "coordinate_height": 400.0,
                        "rotation": 0,
                        "text_original": "采购合同",
                        "text_normalized": "采购合同",
                        "tables": [],
                        "render_asset": render_asset,
                    }
                ],
            },
            "metadata": {
                "adapter": "test-native",
                "classification": {
                    "hinted_document_subtype": "purchase_contract",
                    "hinted_document_type": "order",
                },
            },
        },
    )


def test_ppstructure_result_normalizes_blocks_tables_and_coordinates(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)

    class Result:
        json: ClassVar[dict[str, object]] = {
            "res": {
                "parsing_res_list": [
                    {
                        "block_id": 7,
                        "block_label": "text",
                        "block_content": "采购合同",
                        "block_bbox": [10, 20, 300, 60],
                        "block_score": 0.98,
                    }
                ],
                "table_res_list": [
                    {
                        "pred_html": "<table><tr><th>序号</th><th>数量</th></tr><tr><td>1</td><td>2</td></tr></table>",
                        "cell_box_list": [
                            [0, 100, 100, 140],
                            [100, 100, 200, 140],
                            [0, 140, 100, 180],
                            [100, 140, 200, 180],
                        ],
                    }
                ],
            }
        }
        markdown: ClassVar[dict[str, str]] = {"markdown_texts": "# 采购合同"}

    class Model:
        def predict(self, path):
            return [Result()]

    backend = PPStructureV3Backend(model_factory=Model)
    evidence = backend.parse(image)
    assert evidence.pages[0].blocks[0].text == "采购合同"
    assert evidence.pages[0].tables[0].rows[1] == ["1", "2"]
    assert evidence.pages[0].tables[0].cells[3].bbox.as_list() == [100.0, 140.0, 200.0, 180.0]
    assert evidence.pages[0].markdown == "# 采购合同"


def test_paddle_backend_uses_the_verified_model_root_for_paddlex(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    artifacts = []
    for model_name in sorted(PARSER_MODEL_REQUIREMENTS["pp-structure-v3"]):
        artifact = (
            tmp_path / "official_models" / model_name / "inference.pdiparams"
        )
        artifact.parent.mkdir(parents=True)
        artifact.write_bytes(f"offline-model:{model_name}".encode())
        artifacts.append(
            {
                "name": artifact.relative_to(tmp_path).as_posix(),
                "path": artifact.relative_to(tmp_path).as_posix(),
                "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
            }
        )
    (tmp_path / "document-parser-models.json").write_text(
        json.dumps(
            {
                "complete": True,
                "pipelines": {
                    "pp-structure-v3": {
                        "complete": True,
                        "models": sorted(
                            PARSER_MODEL_REQUIREMENTS["pp-structure-v3"]
                        ),
                    }
                },
                "models": artifacts,
            }
        ),
        encoding="utf-8",
    )
    backend = PPStructureV3Backend(model_root=tmp_path, runtime_downloads=False)
    backend._instances.clear()
    monkeypatch.setattr(backend, "_create_model", lambda: object())
    monkeypatch.delenv("PADDLE_PDX_CACHE_HOME", raising=False)
    monkeypatch.delenv("PADDLEX_HOME", raising=False)

    backend._model()

    assert os.environ["PADDLE_PDX_CACHE_HOME"] == str(tmp_path)
    assert os.environ["PADDLEX_HOME"] == str(tmp_path)

    vl_status = PaddleOCRVLBackend(
        model_root=tmp_path, runtime_downloads=False
    ).readiness()
    assert vl_status["ready"] is False
    assert vl_status["error"] == "model_manifest_incomplete"


def test_paddle_vl_disables_internal_queues(monkeypatch: pytest.MonkeyPatch):
    captured: dict[str, object] = {}

    def paddle_ocr_vl(**kwargs):
        captured.update(kwargs)
        return object()

    monkeypatch.setitem(
        sys.modules,
        "paddleocr",
        SimpleNamespace(PaddleOCRVL=paddle_ocr_vl),
    )

    PaddleOCRVLBackend()._create_model()

    assert captured["vl_rec_backend"] == "native"
    assert captured["use_queues"] is False


def test_gpu_readiness_rejects_a_cpu_only_paddle_runtime(monkeypatch):
    paddle = pytest.importorskip("paddle")

    monkeypatch.setattr(paddle, "is_compiled_with_cuda", lambda: False)
    assert _device_available("gpu:0") == (
        False,
        "paddle_cuda_runtime_unavailable",
    )


def test_structured_evidence_keeps_high_confidence_native_header(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image)).model_dump(mode="json")
    candidate = apply_evidence_to_pdf_document(
        baseline,
        _evidence(),
        filename="采购函.pdf",
        doc_type_hint="order",
        document_subtype_hint="purchase_contract",
    )
    assert candidate["header"]["contract_number"] == "HT-2026-001"
    assert candidate["document_subtype"] == "purchase_contract"
    assert candidate["lines"][0]["name_raw"] == "测试线缆"
    assert candidate["field_meta"]["$.lines[0].quantity"]["source_refs"][0]["part"].startswith("ocr/")
    assert candidate["extraction"]["metadata"]["structured_parser"]["backend"] == "fake-structured"


def test_structured_inline_party_blocks_beat_ambiguous_native_reading_order() -> None:
    native_text = "采购合同\n乙方:\n广西桐曦电子科技有限公司\n甲方:\n东莞市亿穗电子科技有限公司"
    pages = [
        {
            "page_number": 1,
            "tables": [],
            "text_normalized": native_text,
            "native_text_normalized": native_text,
            "ocr_lines": [
                {
                    "text_normalized": "甲方：广西桐曦电子科技有限公司",
                    "bbox": [10.0, 20.0, 250.0, 40.0],
                    "coordinate_space": "pdf_points",
                    "source": "pp-structure-v3",
                    "kind": "text",
                },
                {
                    "text_normalized": "乙方：东莞市亿穗电子科技有限公司",
                    "bbox": [300.0, 20.0, 560.0, 40.0],
                    "coordinate_space": "pdf_points",
                    "source": "pp-structure-v3",
                    "kind": "text",
                },
            ],
        }
    ]
    metadata: dict[str, FieldMetadata] = {}
    issues = []

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", metadata, issues
    )

    assert header.buyer == "广西桐曦电子科技有限公司"
    assert header.seller == "东莞市亿穗电子科技有限公司"
    assert header.supplier == "东莞市亿穗电子科技有限公司"
    assert metadata["$.header.supplier"].model_extra["review_required"] is False
    buyer_ref = metadata["$.header.buyer"].source_refs[0]
    assert buyer_ref.part == "structured/pp-structure-v3/text"
    assert buyer_ref.model_extra["bbox"] == [10.0, 20.0, 250.0, 40.0]
    assert metadata["$.header.buyer"].confidence == 1.0


def test_native_label_next_line_party_association_is_low_confidence() -> None:
    native_text = "采购合同\n甲方:\n广西桐曦电子科技有限公司"
    pages = [
        {
            "page_number": 1,
            "tables": [],
            "text_normalized": native_text,
            "native_text_normalized": native_text,
        }
    ]
    metadata: dict[str, FieldMetadata] = {}

    header = _extract_pdf_header(
        "采购合同.pdf", pages, "purchase_contract", metadata, []
    )

    assert header.buyer == "广西桐曦电子科技有限公司"
    assert metadata["$.header.buyer"].confidence == 0.7
    assert metadata["$.header.buyer"].source_refs[0].part == (
        "native_text/reading_order"
    )


def test_blank_party_label_never_becomes_punctuation_party() -> None:
    pages = [
        {
            "page_number": 1,
            "tables": [],
            "text_normalized": "采购合同\n乙方:\n甲方:广西桐曦电子科技有限公司",
            "native_text_normalized": (
                "采购合同\n乙方:\n甲方:广西桐曦电子科技有限公司"
            ),
            "ocr_lines": [
                {
                    "text_normalized": "合同编号乙方：联系人：手机：",
                    "bbox": [100.0, 100.0, 300.0, 120.0],
                    "coordinate_space": "pdf_points",
                    "source": "pp-structure-v3",
                    "kind": "text",
                }
            ],
        }
    ]
    metadata: dict[str, FieldMetadata] = {}

    header = _extract_pdf_header(
        "采购函.pdf", pages, "purchase_contract", metadata, []
    )

    assert header.buyer == "广西桐曦电子科技有限公司"
    assert header.seller is None
    assert header.supplier is None
    assert "$.header.seller" not in metadata
    assert "$.header.supplier" not in metadata


@pytest.mark.asyncio
async def test_shadow_mode_returns_baseline_and_records_comparison(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))

    def native_parser(*args, **kwargs):
        return baseline.model_copy(deep=True)

    backend = FakeBackend(_evidence())
    service = DocumentParserService(
        mode="shadow",
        pp_structure=backend,
        native_pdf_parser=native_parser,
    )
    result = await service.parse_pdf(
        tmp_path / "document.pdf",
        "采购函.pdf",
        doc_type_hint="order",
        document_subtype_hint="purchase_contract",
    )
    assert result.lines[0].name_raw == "原生行"
    shadow = result.extraction["metadata"]["structured_parser_shadow"]
    assert shadow["candidate_line_count"] == 1
    assert backend.calls == 1


@pytest.mark.asyncio
async def test_structured_mode_falls_back_without_backend(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))

    service = DocumentParserService(
        mode="structured",
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )
    result = await service.parse_pdf(tmp_path / "document.pdf", "采购函.pdf")
    assert result.lines[0].name_raw == "原生行"
    assert any(issue.code == "STRUCTURED_PARSER_FALLBACK" for issue in result.validation_issues)


def test_shadow_comparison_does_not_require_raw_document_content():
    report = compare_document_records(
        {"document_type": "order", "document_subtype": "purchase_contract", "header": {"contract_number": "A"}, "lines": []},
        {"document_type": "order", "document_subtype": "purchase_contract", "header": {"contract_number": "B"}, "lines": [{}]},
    )
    assert report["classification_equal"] is True
    assert report["header_differences"] == [
        {"field": "contract_number", "baseline": "A", "candidate": "B"}
    ]
    assert "采购" not in str(report)


@pytest.mark.parametrize(
    ("page", "reason"),
    [
        (
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                raw={"nonempty": True},
            ),
            "empty_text",
        ),
        (
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[EvidenceBlock(block_id="low", text="x", confidence=0.5)],
            ),
            "low_text_confidence",
        ),
        (
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[EvidenceBlock(block_id="text", text="x", confidence=0.99)],
                tables=[EvidenceTable(table_id="empty")],
            ),
            "table_without_cells",
        ),
        (
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(block_id="text", text="x", confidence=0.99),
                    EvidenceBlock(
                        block_id="image",
                        kind="image",
                        bbox=EvidenceBBox(x0=0, y0=0, x1=50, y1=50),
                    ),
                ],
            ),
            "visual_region",
        ),
    ],
)
def test_page_vlm_escalation_rules(page: EvidencePage, reason: str):
    required, reasons = page.needs_vlm()
    assert required is True
    assert reason in reasons


def test_blank_page_does_not_escalate_to_vlm():
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=100,
        height=100,
        raw={"nonempty": False},
    )
    assert page.needs_vlm() == (False, [])


def test_normalized_visual_bbox_uses_page_ratio_without_pixel_rescaling():
    page = EvidencePage(
        page_number=1,
        page_index=0,
        width=2010,
        height=3015,
        coordinate_space="normalized",
        blocks=[
            EvidenceBlock(
                block_id="photo",
                kind="image",
                bbox=EvidenceBBox(
                    x0=0.0,
                    y0=0.0,
                    x1=0.998,
                    y1=0.998,
                    coordinate_space="normalized",
                ),
            )
        ],
    )

    assert page.visual_coverage_ratio == pytest.approx(0.996004)
    assert "visual_region" in page.needs_vlm()[1]


def _dominant_table_evidence() -> DocumentEvidence:
    rows = [[f"r{row}c{column}" for column in range(10)] for row in range(20)]
    cells = [
        EvidenceCell(row=row, column=column, text=rows[row][column])
        for row in range(20)
        for column in range(10)
    ]
    return DocumentEvidence(
        backend="fake-pp",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id="whole-page-table",
                        kind="table",
                        text="<table>complex engineering drawing</table>",
                        confidence=0.99,
                    )
                ],
                tables=[
                    EvidenceTable(
                        table_id="whole-page-table",
                        rows=rows,
                        cells=cells,
                        bbox=EvidenceBBox(x0=0, y0=0, x1=90, y1=90),
                    )
                ],
            )
        ],
    )


def test_page_dominated_by_complex_table_requires_vlm_review() -> None:
    page = _dominant_table_evidence().pages[0]

    required, reasons = page.needs_vlm()

    assert required is True
    assert "page_dominated_by_complex_table" in reasons
    small = page.model_copy(deep=True)
    small.tables[0].rows = [["a", "b"], ["1", "2"]]
    small.tables[0].cells = small.tables[0].cells[:4]
    assert "page_dominated_by_complex_table" not in small.needs_vlm()[1]


@pytest.mark.asyncio
async def test_vlm_escalation_never_receives_an_unrendered_pdf(tmp_path: Path):
    pp = FakeBackend(_evidence(confidence=0.5), name="pp-structure-v3")
    vl = FakeBackend(_evidence(), name="paddleocr-vl-1.6")
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
    )

    evidence = await service._pdf_evidence(tmp_path / "document.pdf", {})

    assert pp.calls == 1
    assert vl.calls == 0
    assert evidence.raw["vlm_escalation_skipped_pages"] == [1]
    assert evidence.raw["vlm_unavailable_pages"] == [1]
    assert evidence.raw["vlm_unavailable_reasons"] == {
        "1": "rendered_page_unavailable"
    }
    assert evidence.warnings == [
        "paddleocr-vl escalation unavailable: rendered_page_unavailable"
    ]


@pytest.mark.asyncio
async def test_required_vlm_backend_unavailable_marks_document_for_review(
    tmp_path: Path,
) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))
    service = DocumentParserService(
        mode="structured",
        pp_structure=FakeBackend(_evidence(confidence=0.5), name="fake-pp"),
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(
        tmp_path / "document.pdf",
        "document.pdf",
        doc_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert result.needs_review is True
    assert "PADDLEOCR_VL_ESCALATION_UNAVAILABLE" in {
        issue.code for issue in result.validation_issues
    }
    structured = result.extraction["metadata"]["structured_parser"]
    assert structured["vlm_unavailable_pages"] == [1]
    assert structured["vlm_unavailable_reasons"] == {"1": "backend_disabled"}


@pytest.mark.asyncio
async def test_drawing_field_blocker_with_vlm_disabled_preserves_pp_candidate(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))
    pp_candidate = baseline.model_dump(mode="json")
    pp_candidate.update(
        {
            "document_type": "technical_document",
            "document_subtype": "approval_drawing",
            "lines": [
                OrderLine(
                    line_id="drawing:1:2:B",
                    line_no=2,
                    product_code="B",
                    name_raw=None,
                    quantity=1,
                ).model_dump(mode="json")
            ],
            "field_meta": {
                "$.lines[0].product_code": {
                    "confidence": 0.75,
                    "source_refs": [
                        {
                            "page": 1,
                            "part": "table:0/row:2/column:1",
                            "bbox": [10, 20, 110, 40],
                            "coordinate_space": "pdf_points",
                        }
                    ],
                }
            },
            "validation_issues": [
                {
                    "code": "DRAWING_BOM_DESCRIPTION_MISSING",
                    "severity": "warning",
                    "message": "BOM description is missing",
                    "paths": ["$.lines[0].name_raw"],
                    "source_refs": [],
                    "actual": [2],
                }
            ],
            "needs_review": True,
        }
    )
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda *args, **kwargs: json.loads(json.dumps(pp_candidate)),
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=FakeBackend(_evidence(), name="fake-pp"),
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(tmp_path / "drawing.pdf", "drawing.pdf")

    assert result.lines[0].product_code == "B"
    assert result.lines[0].name_raw is None
    issue_codes = {issue.code for issue in result.validation_issues}
    assert "DRAWING_BOM_DESCRIPTION_MISSING" in issue_codes
    assert "PADDLEOCR_VL_ESCALATION_UNAVAILABLE" in issue_codes
    metadata = result.extraction["metadata"]
    assert metadata["structured_parser"]["vlm_unavailable_pages"] == [1]
    assert metadata["structured_parser"]["vlm_unavailable_reasons"] == {
        "1": "backend_disabled"
    }
    raw = metadata["structured_evidence"]["raw"]
    assert "business_evidence_blocker" in raw["vlm_escalation_reasons"]
    assert raw["vlm_escalation_reasons_by_page"]["1"] == [
        "business_evidence_blocker"
    ]


@pytest.mark.asyncio
async def test_pdf_reprojects_technical_fields_after_structured_evidence_is_attached(
    tmp_path: Path,
) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = DocumentRecord(
        source=DocumentSource(
            original_filename="connector-specification.pdf",
            sha256="a" * 64,
            mime_type="application/pdf",
        ),
        document_type="technical_document",
        document_subtype="product_specification",
        header=DocumentHeader(title="Connector specification"),
        extraction={
            "raw_content": {
                "text_original": "technical content",
                "text_normalized": "technical content",
                "pages": [
                    {
                        "page_number": 1,
                        "page_index": 0,
                        "width": 600.0,
                        "height": 800.0,
                        "coordinate_width": 600.0,
                        "coordinate_height": 800.0,
                        "rotation": 0,
                        "text_blocks": [],
                        "tables": [],
                        "render_asset": str(image),
                    }
                ],
            },
            "metadata": {"adapter": "test-native"},
        },
    )
    evidence = DocumentEvidence(
        backend="fake-pp",
        backend_version="1",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                blocks=[
                    EvidenceBlock(
                        block_id="page-content",
                        kind="text",
                        text="technical content",
                        confidence=0.99,
                        bbox=EvidenceBBox(x0=0, y0=0, x1=600, y1=800),
                    )
                ],
                raw={
                    "overall_ocr_res": {
                        "rec_texts": ["ICP-0018-A0", "DWG NO.", "6.10±0.07 mm"],
                        "rec_scores": [0.99, 0.99, 0.98],
                        "rec_polys": [
                            [[100, 60], [230, 60], [230, 90], [100, 90]],
                            [[100, 100], [200, 100], [200, 130], [100, 130]],
                            [[350, 200], [500, 200], [500, 230], [350, 230]],
                        ],
                    }
                },
            )
        ],
    )
    service = DocumentParserService(
        mode="structured",
        pp_structure=FakeBackend(evidence, name="fake-pp"),
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(
        tmp_path / "connector-specification.pdf",
        "connector-specification.pdf",
    )

    assert result.header.drawing_number == "ICP-0018-A0"
    assert [item["value"] for item in result.key_dimensions] == ["6.10±0.07 mm"]
    assert result.field_meta["$.header.drawing_number"].source_refs[0].part == (
        "ocr/token:0"
    )
    assert result.field_meta["$.key_dimensions[0].value"].source_refs[0].part == (
        "ocr/token:2"
    )
    assert result.extraction["metadata"]["technical_projection"] == {
        "strategy": "evidence-projection",
        "specification_count": 0,
        "dimension_count": 1,
        "process_step_count": 0,
        "line_count": 1,
        "headerless_material_row_count": 0,
        "headerless_material_table_ids": [],
        "replaced_model_line_count": 0,
        "replaced_validation_issue_codes": [],
    }


@pytest.mark.asyncio
async def test_image_vlm_unavailable_preserves_primary_evidence(tmp_path: Path) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    service = DocumentParserService(
        mode="structured",
        pp_structure=FakeBackend(_evidence(confidence=0.5), name="fake-pp"),
    )

    evidence = await service.parse_image(image)

    assert evidence.text
    assert evidence.raw["vlm_unavailable_pages"] == [1]
    assert evidence.raw["vlm_unavailable_reasons"] == {"1": "backend_disabled"}


@pytest.mark.asyncio
async def test_shadow_complete_native_drawing_suppresses_giant_table_vlm(
    tmp_path: Path,
):
    image = tmp_path / "page.png"
    Image.new("RGB", (100, 100), "white").save(image)
    baseline = DocumentRecord(
        source=DocumentSource(
            original_filename="cable.pdf",
            sha256="a" * 64,
            mime_type="application/pdf",
        ),
        document_type="technical_document",
        document_subtype="approval_drawing",
        header=DocumentHeader(title="USB cable", material_number="CBL-001"),
        lines=[
            OrderLine(
                line_id="drawing:1:1:RAW-001",
                line_no=1,
                product_code="RAW-001",
                quantity=1,
                name_raw="Cable bulk",
            ),
            OrderLine(
                line_id="drawing:1:2:CONN-002",
                line_no=2,
                product_code="CONN-002",
                quantity=2,
                name_raw="Type-C connector",
            ),
        ],
        field_meta={
            path: FieldMetadata(
                confidence=0.99,
                source_refs=[
                    SourceReference(
                        page=1,
                        part=f"native/{index}",
                        bbox=[1.0 + index, 2.0, 10.0 + index, 12.0],
                        coordinate_space="pdf_points",
                    )
                ],
            )
            for index, path in enumerate(
                (
                    "$.header.title",
                    "$.header.material_number",
                    "$.lines[0].product_code",
                    "$.lines[0].quantity",
                    "$.lines[1].product_code",
                    "$.lines[1].quantity",
                )
            )
        },
        extraction={
            "raw_content": {
                "text_original": "engineering drawing",
                "pages": [
                    {
                        "page_number": 1,
                        "page_index": 0,
                        "width": 100.0,
                        "height": 100.0,
                        "coordinate_width": 100.0,
                        "coordinate_height": 100.0,
                        "render_asset": str(image),
                    }
                ],
            }
        },
    )
    pp = FakeBackend(_dominant_table_evidence(), name="fake-pp")
    vl = FakeBackend(_evidence(), name="fake-vlm")
    service = DocumentParserService(
        mode="shadow",
        pp_structure=pp,
        paddle_vl=vl,
    )

    evidence = await service._pdf_evidence(
        tmp_path / "document.pdf", baseline.model_dump(mode="json")
    )

    assert pp.calls == 1
    assert vl.calls == 0
    assert evidence.raw["vlm_escalation_suppressed_pages"] == [1]
    assert evidence.raw["vlm_escalation_reasons_by_page"] == {
        "1": ["page_dominated_by_complex_table"]
    }

    structured_pp = FakeBackend(_dominant_table_evidence(), name="fake-pp")
    structured_vl = FakeBackend(_evidence(), name="fake-vlm")
    structured_service = DocumentParserService(
        mode="structured",
        pp_structure=structured_pp,
        paddle_vl=structured_vl,
    )
    structured_evidence = await structured_service._pdf_evidence(
        tmp_path / "document.pdf", baseline.model_dump(mode="json")
    )
    assert structured_vl.calls == 1
    assert structured_evidence.raw["vlm_escalated_pages"] == [1]

    hard_escalation_cases = [
        _evidence(confidence=0.5),
        DocumentEvidence(
            backend="fake-pp",
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=100,
                    height=100,
                    raw={"nonempty": True},
                )
            ],
        ),
        DocumentEvidence(
            backend="fake-pp",
            pages=[
                EvidencePage(
                    page_number=1,
                    page_index=0,
                    width=100,
                    height=100,
                    blocks=[
                        EvidenceBlock(
                            block_id="table-label",
                            text="BOM",
                            confidence=0.99,
                        )
                    ],
                    tables=[EvidenceTable(table_id="broken", rows=[])],
                )
            ],
        ),
    ]
    for hard_evidence in hard_escalation_cases:
        hard_vl = FakeBackend(_evidence(), name="fake-vlm")
        hard_service = DocumentParserService(
            mode="shadow",
            pp_structure=FakeBackend(hard_evidence, name="fake-pp"),
            paddle_vl=hard_vl,
        )
        result = await hard_service._pdf_evidence(
            tmp_path / "document.pdf", baseline.model_dump(mode="json")
        )
        assert hard_vl.calls == 1
        assert result.raw["vlm_escalated_pages"] == [1]

    unpositioned = baseline.model_dump(mode="json")
    for meta in unpositioned["field_meta"].values():
        for source_ref in meta["source_refs"]:
            source_ref.pop("bbox", None)
    assert _has_deterministic_drawing_content(unpositioned) is False

    incomplete = baseline.model_dump(mode="json")
    incomplete["lines"] = incomplete["lines"][:1]
    incomplete_pp = FakeBackend(_dominant_table_evidence(), name="fake-pp")
    incomplete_vl = FakeBackend(_evidence(), name="fake-vlm")
    incomplete_service = DocumentParserService(
        mode="shadow",
        pp_structure=incomplete_pp,
        paddle_vl=incomplete_vl,
    )
    incomplete_evidence = await incomplete_service._pdf_evidence(
        tmp_path / "document.pdf", incomplete
    )
    assert incomplete_vl.calls == 1
    assert incomplete_evidence.raw["vlm_escalated_pages"] == [1]


@pytest.mark.asyncio
async def test_shadow_native_drawing_blocker_does_not_repeat_whole_page_vlm(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (100, 100), "white").save(image)
    baseline = DocumentRecord(
        source=DocumentSource(
            original_filename="cable.pdf",
            sha256="a" * 64,
            mime_type="application/pdf",
        ),
        document_type="technical_document",
        document_subtype="approval_drawing",
        header=DocumentHeader(title="USB cable", material_number="CBL-001"),
        lines=[
            OrderLine(
                line_id=f"drawing:1:{index}:{code}",
                line_no=index,
                product_code=code,
                quantity=index,
                name_raw=name,
            )
            for index, (code, name) in enumerate(
                (("RAW-001", "Cable bulk"), ("CONN-002", "Type-C connector")),
                start=1,
            )
        ],
        field_meta={
            path: FieldMetadata(
                confidence=0.99,
                source_refs=[
                    SourceReference(
                        page=1,
                        part=f"native/{index}",
                        bbox=[1.0 + index, 2.0, 10.0 + index, 12.0],
                        coordinate_space="pdf_points",
                    )
                ],
            )
            for index, path in enumerate(
                (
                    "$.header.title",
                    "$.header.material_number",
                    "$.lines[0].product_code",
                    "$.lines[0].quantity",
                    "$.lines[1].product_code",
                    "$.lines[1].quantity",
                )
            )
        },
        extraction={
            "raw_content": {
                "text_original": "engineering drawing",
                "pages": [
                    {
                        "page_number": 1,
                        "page_index": 0,
                        "width": 100.0,
                        "height": 100.0,
                        "coordinate_width": 100.0,
                        "coordinate_height": 100.0,
                        "render_asset": str(image),
                    }
                ],
            }
        },
    )
    blocked_candidate = baseline.model_dump(mode="json")
    blocked_candidate["validation_issues"] = [
        {
            "code": "DRAWING_BOM_DESCRIPTION_MISSING",
            "severity": "warning",
            "message": "description needs review",
            "paths": ["$.lines[0].name_raw"],
            "source_refs": [{"page": 1}],
        }
    ]
    blocked_candidate["needs_review"] = True
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda *args, **kwargs: json.loads(json.dumps(blocked_candidate)),
    )
    pp = FakeBackend(_dominant_table_evidence(), name="fake-pp")
    vl = FakeBackend(_evidence(), name="fake-vlm")
    service = DocumentParserService(
        mode="shadow",
        pp_structure=pp,
        paddle_vl=vl,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(tmp_path / "document.pdf", "cable.pdf")

    assert pp.calls == 1
    assert vl.calls == 0
    summary = result.extraction["metadata"]["structured_parser"]
    assert summary["vlm_escalation_suppressed_pages"] == [1]
    assert summary["vlm_escalation_reasons_by_page"]["1"] == [
        "business_evidence_blocker",
        "page_dominated_by_complex_table",
    ]
    assert summary["timing"] == {
        "primary_backend": "fake-pp",
        "primary_elapsed_ms": 0.0,
        "supplement_backends": [],
        "supplement_elapsed_ms": 0.0,
        "total_elapsed_ms": 0.0,
    }


@pytest.mark.asyncio
async def test_shadow_text_only_drawing_blocker_escalates_for_missing_table(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    first_image = tmp_path / "page-1.png"
    second_image = tmp_path / "page-2.png"
    Image.new("RGB", (100, 100), "white").save(first_image)
    Image.new("RGB", (100, 100), "white").save(second_image)
    baseline = _baseline(str(first_image)).model_copy(deep=True)
    baseline.document_type = "technical_document"
    baseline.document_subtype = "approval_drawing"
    baseline.header.title = "USB cable"
    baseline.header.material_number = "CBL-001"
    baseline.lines = [
        OrderLine(
            line_id="drawing:1:1:RAW-001",
            line_no=1,
            product_code="RAW-001",
            quantity=1,
            name_raw="Cable bulk",
        ),
        OrderLine(
            line_id="drawing:1:2:CONN-002",
            line_no=2,
            product_code="CONN-002",
            quantity=2,
            name_raw="Type-C connector",
        ),
    ]
    baseline.field_meta = {
        path: FieldMetadata(
            confidence=0.99,
            source_refs=[
                SourceReference(
                    page=1,
                    part=f"native/{index}",
                    bbox=[1.0 + index, 2.0, 10.0 + index, 12.0],
                    coordinate_space="pdf_points",
                )
            ],
        )
        for index, path in enumerate(
            (
                "$.header.title",
                "$.header.material_number",
                "$.lines[0].product_code",
                "$.lines[0].quantity",
                "$.lines[1].product_code",
                "$.lines[1].quantity",
            )
        )
    }
    second_page = copy.deepcopy(baseline.extraction["raw_content"]["pages"][0])
    second_page.update(
        {
            "page_number": 2,
            "page_index": 1,
            "render_asset": str(second_image),
        }
    )
    baseline.extraction["raw_content"]["pages"].append(second_page)
    blocked_candidate = baseline.model_dump(mode="json")
    blocked_candidate["needs_review"] = True
    blocked_candidate["validation_issues"] = [
        {
            "code": "DRAWING_BOM_EMPTY",
            "severity": "warning",
            "message": "structured BOM evidence is missing",
            "paths": ["$.lines"],
            "source_refs": [{"page": 1}, {"page": 2}],
        }
    ]
    monkeypatch.setattr(
        "m1.documents.parsing.service.apply_evidence_to_pdf_document",
        lambda *args, **kwargs: json.loads(json.dumps(blocked_candidate)),
    )
    reliable_page = _dominant_table_evidence().pages[0]
    text_only_evidence = DocumentEvidence(
        backend="fake-pp",
        pages=[
            reliable_page,
            EvidencePage(
                page_number=2,
                page_index=1,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id="drawing-text",
                        text="BOM RAW-001 CONN-002",
                        confidence=0.99,
                        bbox=EvidenceBBox(x0=1, y0=1, x1=90, y1=20),
                    )
                ],
            )
        ],
    )
    vl = FakeBackend(_evidence(), name="fake-vlm")
    service = DocumentParserService(
        mode="shadow",
        pp_structure=FakeBackend(text_only_evidence, name="fake-pp"),
        paddle_vl=vl,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(tmp_path / "document.pdf", "cable.pdf")

    assert vl.calls == 1
    summary = result.extraction["metadata"]["structured_parser"]
    assert summary["vlm_escalated_pages"] == [2]
    assert "business_evidence_blocker" in summary[
        "vlm_escalation_reasons_by_page"
    ]["2"]
    assert summary["vlm_escalation_suppressed_pages"] == [1]


def test_merge_evidence_records_primary_supplement_and_total_elapsed_time() -> None:
    primary = _evidence()
    primary.backend = "pp-structure-v3"
    primary.elapsed_ms = 125.25
    first = _evidence()
    first.backend = "paddleocr-vl"
    first.elapsed_ms = 40.5
    second = _evidence()
    second.backend = "paddleocr-vl"
    second.elapsed_ms = 9.25

    merged = merge_evidence(merge_evidence(primary, first), second)

    assert merged.elapsed_ms == 175.0
    assert merged.raw["timing"] == {
        "primary_backend": "pp-structure-v3",
        "primary_elapsed_ms": 125.25,
        "supplement_backends": ["paddleocr-vl"],
        "supplement_elapsed_ms": 49.75,
        "total_elapsed_ms": 175.0,
    }


@pytest.mark.asyncio
async def test_shadow_metadata_exposes_primary_supplement_and_total_timing(
    tmp_path: Path,
) -> None:
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))
    primary_evidence = _evidence(confidence=0.5)
    primary_evidence.backend = "pp-structure-v3"
    primary_evidence.elapsed_ms = 12.5
    supplement_evidence = _evidence()
    supplement_evidence.backend = "paddleocr-vl"
    supplement_evidence.elapsed_ms = 7.5
    pp = FakeBackend(primary_evidence, name="pp-structure-v3")
    vl = FakeBackend(supplement_evidence, name="paddleocr-vl")
    service = DocumentParserService(
        mode="shadow",
        pp_structure=pp,
        paddle_vl=vl,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(tmp_path / "document.pdf", "document.pdf")

    summary = result.extraction["metadata"]["structured_parser"]
    assert pp.calls == 1
    assert vl.calls == 1
    assert summary["elapsed_ms"] == 20.0
    assert summary["timing"] == {
        "primary_backend": "pp-structure-v3",
        "primary_elapsed_ms": 12.5,
        "supplement_backends": ["paddleocr-vl"],
        "supplement_elapsed_ms": 7.5,
        "total_elapsed_ms": 20.0,
    }


@pytest.mark.asyncio
async def test_explicit_image_target_returns_v2_record_without_implicit_escalation(
    tmp_path: Path,
) -> None:
    image = tmp_path / "drawing.png"
    Image.new("RGB", (600, 800), "white").save(image)
    backend = FakeBackend(_evidence(), name="pp-structure-v3")
    service = DocumentParserService(mode="structured", pp_structure=backend)

    result = await service.parse_image_target(
        image,
        "drawing.png",
        backend="pp_structure_v3",
        document_subtype_hint="approval_drawing",
        timeout_seconds=1.0,
    )

    assert backend.calls == 1
    assert result.schema_version == "m1.document.v2"
    assert result.document_type == "technical_document"
    assert result.document_subtype == "approval_drawing"
    assert result.extraction["metadata"]["adapter"] == "pp_structure_v3"


def test_vlm_bom_supplement_aligns_rows_by_identity_not_array_position() -> None:
    primary = {
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {},
        "lines": [
            {
                "line_id": "drawing:1:A",
                "line_no": 1,
                "product_code": "A",
                "name_raw": "primary A",
            },
            {
                "line_id": "drawing:1:B",
                "line_no": 2,
                "product_code": "B",
                "name_raw": None,
            },
        ],
        "field_meta": {
            "$.lines[0].name_raw": {"confidence": 0.99, "source_refs": []},
        },
        "validation_issues": [
            {
                "code": "DRAWING_BOM_DESCRIPTION_MISSING",
                "severity": "warning",
                "paths": ["$.lines[1].name_raw"],
            }
        ],
    }
    supplemented = {
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {},
        "lines": [
            {"line_no": 0, "product_code": "X", "name_raw": "vlm X"},
            {"line_no": 1, "product_code": "A", "name_raw": "vlm A"},
            {"line_no": 2, "product_code": "B", "name_raw": "vlm B"},
        ],
        "field_meta": {
            "$.lines[2].name_raw": {
                "confidence": 0.8,
                "source_refs": [
                    {
                        "page": 1,
                        "part": "ocr/line:2",
                        "bbox": [10, 20, 110, 40],
                        "coordinate_space": "pdf_points",
                    }
                ],
            }
        },
    }

    merged = _merge_vlm_supplement(
        primary,
        supplemented,
        doc_type_hint=None,
        document_subtype_hint=None,
    )

    assert [line["product_code"] for line in merged["lines"]] == ["X", "A", "B"]
    assert [line["name_raw"] for line in merged["lines"]] == [
        "vlm X",
        "primary A",
        "vlm B",
    ]
    assert "$.lines[1].name_raw" in merged["field_meta"]
    assert merged["field_meta"]["$.lines[2].name_raw"]["source_refs"][0][
        "bbox"
    ] == [10, 20, 110, 40]
    assert "$.lines[0].name_raw" not in merged["field_meta"]
    assert merged.get("validation_issues", []) == []


def test_vlm_bom_supplement_rejects_unpositioned_description() -> None:
    primary = {
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {},
        "lines": [
            {
                "line_id": "drawing:1:B",
                "line_no": 2,
                "product_code": "B",
                "name_raw": None,
            }
        ],
        "field_meta": {},
        "validation_issues": [
            {
                "code": "DRAWING_BOM_DESCRIPTION_MISSING",
                "severity": "warning",
                "paths": ["$.lines[0].name_raw"],
            }
        ],
    }
    supplemented = {
        "document_type": "technical_document",
        "document_subtype": "approval_drawing",
        "header": {},
        "lines": [
            {
                "line_no": 2,
                "product_code": "B",
                "name_raw": "unpositioned VLM description",
            }
        ],
        "field_meta": {
            "$.lines[0].name_raw": {
                "confidence": 0.99,
                "source_refs": [{"page": 1, "part": "ocr/line:0"}],
            }
        },
        "validation_issues": [],
    }

    merged = _merge_vlm_supplement(
        primary,
        supplemented,
        doc_type_hint=None,
        document_subtype_hint=None,
    )

    assert merged["lines"][0]["name_raw"] is None
    assert merged["needs_review"] is True
    assert merged["validation_issues"] == primary["validation_issues"]


def test_nonempty_unknown_structured_result_never_succeeds_silently(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (100, 100), "white").save(image)
    baseline = DocumentRecord(
        source=DocumentSource(
            original_filename="unknown.pdf",
            sha256="a" * 64,
            mime_type="application/pdf",
        ),
        extraction={
            "raw_content": {
                "text_original": "generic native content",
                "text_normalized": "generic native content",
                "pages": [
                    {
                        "page_number": 1,
                        "page_index": 0,
                        "width": 100.0,
                        "height": 100.0,
                        "coordinate_width": 100.0,
                        "coordinate_height": 100.0,
                        "text_original": "generic native content",
                        "text_normalized": "generic native content",
                        "tables": [],
                        "render_asset": str(image),
                    }
                ],
            },
            "metadata": {},
        },
    ).model_dump(mode="json")
    evidence = DocumentEvidence(
        backend="fake-pp",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=100,
                height=100,
                blocks=[
                    EvidenceBlock(
                        block_id="generic",
                        text="generic structured content",
                        confidence=0.99,
                        bbox=EvidenceBBox(x0=0, y0=0, x1=50, y1=20),
                    )
                ],
            )
        ],
    )

    candidate = apply_evidence_to_pdf_document(
        baseline, evidence, filename="unknown.pdf"
    )

    assert candidate["needs_review"] is True
    assert "STRUCTURED_BUSINESS_OUTPUT_EMPTY" in {
        issue["code"] for issue in candidate["validation_issues"]
    }


def test_missing_drawing_name_or_bom_is_a_business_vlm_blocker() -> None:
    assert _has_blocking_evidence_issue(
        {
            "validation_issues": [
                {"code": "DRAWING_NAME_MISSING", "severity": "warning", "paths": ["$.header.title"]}
            ]
        }
    )
    assert _has_blocking_evidence_issue(
        {
            "validation_issues": [
                {"code": "DRAWING_BOM_EMPTY", "severity": "warning", "paths": ["$.lines"]}
            ]
        }
    )
    missing_description = {
        "validation_issues": [
            {
                "code": "DRAWING_BOM_DESCRIPTION_MISSING",
                "severity": "warning",
                "paths": ["$.lines[1].name_raw"],
            }
        ],
        "field_meta": {
            "$.lines[1].product_code": {
                "confidence": 0.75,
                "source_refs": [{"page": 2, "part": "table:0/row:1/column:1"}],
            }
        },
    }
    assert _has_blocking_evidence_issue(missing_description)
    assert _blocking_evidence_pages(missing_description) == {2}
    assert not _has_blocking_evidence_issue(
        {
            "validation_issues": [
                {"code": "DRAWING_NUMBER_MISSING", "severity": "warning", "paths": ["$.header.drawing_number"]}
            ]
        }
    )


@pytest.mark.asyncio
async def test_vlm_timeout_keeps_pp_candidate_and_marks_review(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image))
    pp = FakeBackend(_evidence(confidence=0.5), name="fake-pp")
    class SlowVLMBackend(FakeBackend):
        def parse(self, path, *, pages=None) -> DocumentEvidence:
            self.calls += 1
            time.sleep(0.15)
            return self.evidence.model_copy(deep=True)

    vl = SlowVLMBackend(_evidence(), name="fake-vlm")
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        vl_timeout_seconds=0.05,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(
        tmp_path / "document.pdf",
        "采购函.pdf",
        doc_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert pp.calls == 1
    assert vl.calls == 1
    assert result.document_type == "order"
    assert result.lines
    assert result.needs_review is True
    assert "PADDLEOCR_VL_ESCALATION_FAILED" in {
        issue.code for issue in result.validation_issues
    }
    structured = result.extraction["metadata"]["structured_parser"]
    assert structured["vlm_failed_pages"] == [1]
    assert structured["vlm_failure_types"] == {"1": "TimeoutError"}
    timing = structured["timing"]
    assert timing["supplement_backends"] == ["fake-vlm"]
    assert timing["supplement_elapsed_ms"] > 0
    assert timing["total_elapsed_ms"] >= (
        timing["primary_elapsed_ms"] + timing["supplement_elapsed_ms"]
    )
    assert structured.get("status") != "fallback"

    for _ in range(100):
        active = service._active_inference
        if active is None or active.done():
            break
        await asyncio.sleep(0.01)


@pytest.mark.asyncio
async def test_timed_out_predictor_blocks_overlapping_gpu_work(tmp_path: Path):
    started = threading.Event()
    release = threading.Event()

    class BlockingBackend(FakeBackend):
        def parse(self, path, *, pages=None) -> DocumentEvidence:
            self.calls += 1
            started.set()
            release.wait(timeout=2)
            return self.evidence.model_copy(deep=True)

    backend = BlockingBackend(_evidence(), name="blocking")
    service = DocumentParserService(mode="structured", pp_structure=backend)

    with pytest.raises(TimeoutError):
        await service._run_backend(
            backend, tmp_path / "document.pdf", pages=None, timeout=0.01
        )
    assert started.is_set()
    readiness = service.readiness()
    assert readiness["ready"] is False
    assert readiness["inference"] == {"busy": True, "timed_out": True}
    with pytest.raises(RuntimeError, match="still running"):
        await service._run_backend(
            backend, tmp_path / "document.pdf", pages=None, timeout=0.01
        )
    assert backend.calls == 1

    release.set()
    for _ in range(100):
        active = service._active_inference
        if active is None or active.done():
            break
        await asyncio.sleep(0.01)
    assert service.readiness()["inference"] == {"busy": False, "timed_out": False}
    result = await service._run_backend(
        FakeBackend(_evidence(), name="next"),
        tmp_path / "document.pdf",
        pages=None,
        timeout=1,
    )
    assert result.backend == "fake-structured"


def test_nonlegacy_readiness_requires_primary_and_enabled_backends():
    assert DocumentParserService(mode="structured").readiness() == {
        "mode": "structured",
        "ready": False,
        "required_backends": ["pp-structure-v3"],
        "missing_backends": ["pp-structure-v3"],
        "backends": {},
        "inference": {"busy": False, "timed_out": False},
    }
    pp = FakeBackend(_evidence(), name="pp-structure-v3")
    vl = FakeBackend(_evidence(), name="paddleocr-vl-1.6")
    status = DocumentParserService(
        mode="shadow", pp_structure=pp, paddle_vl=vl
    ).readiness()
    assert status["ready"] is True
    assert status["required_backends"] == [
        "paddleocr-vl-1.6",
        "pp-structure-v3",
    ]


def test_paddle_prediction_concurrency_is_process_global(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (20, 20), "white").save(image)
    guard = threading.Lock()
    active = 0
    maximum = 0

    class Result:
        json: ClassVar[dict[str, object]] = {"res": {"parsing_res_list": []}}

    class Model:
        def predict(self, path):
            nonlocal active, maximum
            with guard:
                active += 1
                maximum = max(maximum, active)
            time.sleep(0.05)
            with guard:
                active -= 1
            return [Result()]

    first = PPStructureV3Backend(model_factory=Model)
    second = PPStructureV3Backend(model_factory=Model)
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda backend: backend.parse(image), (first, second)))
    assert maximum == 1


def test_gpu_paddle_backends_keep_only_one_resident_pipeline(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    events: list[str] = []

    class Model:
        def __init__(self, name: str) -> None:
            self.name = name

        def close(self) -> None:
            events.append(f"close:{self.name}")

    def create(name: str):
        events.append(f"create:{name}")
        return Model(name)

    pp = PPStructureV3Backend(device="gpu:0", model_root=tmp_path)
    vl = PaddleOCRVLBackend(device="cuda:0", model_root=tmp_path)
    monkeypatch.setattr(pp, "_ensure_cache", lambda: None)
    monkeypatch.setattr(vl, "_ensure_cache", lambda: None)
    monkeypatch.setattr(pp, "_create_model", lambda: create("pp"))
    monkeypatch.setattr(vl, "_create_model", lambda: create("vl"))
    pp._instances.clear()

    try:
        first_pp = pp._model()
        first_vl = vl._model()
        second_pp = pp._model()

        assert first_pp is not second_pp
        assert first_vl.name == "vl"
        assert events == [
            "create:pp",
            "close:pp",
            "create:vl",
            "close:vl",
            "create:pp",
        ]
        assert list(pp._instances) == [pp._key()]
    finally:
        pp._instances.clear()


def test_cpu_paddle_backends_can_remain_resident_together(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    pp = PPStructureV3Backend(device="cpu", model_root=tmp_path)
    vl = PaddleOCRVLBackend(device="cpu", model_root=tmp_path)
    monkeypatch.setattr(pp, "_ensure_cache", lambda: None)
    monkeypatch.setattr(vl, "_ensure_cache", lambda: None)
    monkeypatch.setattr(pp, "_create_model", object)
    monkeypatch.setattr(vl, "_create_model", object)
    pp._instances.clear()

    try:
        pp_model = pp._model()
        vl_model = vl._model()

        assert pp._model() is pp_model
        assert vl._model() is vl_model
        assert set(pp._instances) == {pp._key(), vl._key()}
    finally:
        pp._instances.clear()


def test_overlapping_multi_gpu_backends_evict_the_previous_pipeline(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    pp = PPStructureV3Backend(device="gpu:0,01", model_root=tmp_path)
    vl = PaddleOCRVLBackend(device="cuda:1", model_root=tmp_path)
    monkeypatch.setattr(pp, "_ensure_cache", lambda: None)
    monkeypatch.setattr(vl, "_ensure_cache", lambda: None)
    monkeypatch.setattr(pp, "_create_model", object)
    monkeypatch.setattr(vl, "_create_model", object)
    pp._instances.clear()

    try:
        pp._model()
        vl._model()

        assert list(pp._instances) == [vl._key()]
    finally:
        pp._instances.clear()


def test_gpu_cleanup_collects_predictor_cycles_before_empty_cache(
    monkeypatch: pytest.MonkeyPatch,
):
    class CyclicModel:
        def __init__(self) -> None:
            self.predict = self.__call__

        def __call__(self):
            return None

        def close(self) -> None:
            return None

    model = CyclicModel()
    reference = weakref.ref(model)
    models = [model]
    del model

    def empty_cache() -> None:
        assert reference() is None

    fake_paddle = SimpleNamespace(
        is_compiled_with_cuda=lambda: True,
        device=SimpleNamespace(cuda=SimpleNamespace(empty_cache=empty_cache)),
    )
    monkeypatch.setitem(sys.modules, "paddle", fake_paddle)

    PPStructureV3Backend._release_cached_models(models)

    assert reference() is None


def test_gpu_cleanup_failure_blocks_replacement(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    class FailingClose:
        def close(self) -> None:
            raise OSError("synthetic cleanup failure")

    pp = PPStructureV3Backend(device="gpu:0", model_root=tmp_path)
    vl = PaddleOCRVLBackend(device="gpu:0", model_root=tmp_path)
    monkeypatch.setattr(pp, "_ensure_cache", lambda: None)
    monkeypatch.setattr(vl, "_ensure_cache", lambda: None)
    monkeypatch.setattr(pp, "_create_model", FailingClose)
    replacement_created = False

    def create_replacement():
        nonlocal replacement_created
        replacement_created = True
        return object()

    monkeypatch.setattr(vl, "_create_model", create_replacement)
    pp._instances.clear()
    pp._gpu_cleanup_failed_slots.clear()

    try:
        pp._model()
        with pytest.raises(ParserBackendError, match="cleanup failed"):
            vl._model()
        with pytest.raises(ParserBackendError, match="process restart required"):
            vl._model()
        assert replacement_created is False
    finally:
        pp._instances.clear()
        pp._gpu_cleanup_failed_slots.clear()


def test_gpu_backend_switch_waits_for_inflight_prediction(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    events: list[str] = []
    first_started = threading.Event()
    finish_first = threading.Event()

    class Model:
        def __init__(self, name: str) -> None:
            self.name = name

        def predict(self, _path: str):
            events.append(f"predict:{self.name}:start")
            if self.name == "pp":
                first_started.set()
                assert finish_first.wait(timeout=2)
            events.append(f"predict:{self.name}:end")
            return []

        def close(self) -> None:
            events.append(f"close:{self.name}")

    pp = PPStructureV3Backend(device="gpu:0", model_root=tmp_path)
    vl = PaddleOCRVLBackend(device="gpu:0", model_root=tmp_path)
    monkeypatch.setattr(pp, "_ensure_cache", lambda: None)
    monkeypatch.setattr(vl, "_ensure_cache", lambda: None)
    monkeypatch.setattr(pp, "_create_model", lambda: Model("pp"))
    monkeypatch.setattr(vl, "_create_model", lambda: Model("vl"))
    monkeypatch.setitem(
        sys.modules,
        "paddle",
        SimpleNamespace(is_compiled_with_cuda=lambda: False),
    )
    pp._instances.clear()
    pp._gpu_cleanup_failed_slots.clear()

    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(pp._predict, tmp_path / "first.png")
            assert first_started.wait(timeout=2)
            second = pool.submit(vl._predict, tmp_path / "second.png")
            time.sleep(0.05)
            assert "close:pp" not in events
            finish_first.set()
            first.result(timeout=2)
            second.result(timeout=2)

        assert events.index("predict:pp:end") < events.index("close:pp")
        assert events.index("close:pp") < events.index("predict:vl:start")
    finally:
        pp._instances.clear()
        pp._gpu_cleanup_failed_slots.clear()


@pytest.mark.asyncio
async def test_structured_image_and_docling_routes(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    pp = FakeBackend(_evidence(), name="pp-structure-v3")
    docling = FakeBackend(_evidence(), name="docling")
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        docling=docling,
        native_docx_parser=lambda *args, **kwargs: _baseline(str(image)).model_copy(
            deep=True
        ),
    )

    image_evidence = await service.parse_image(image)
    assert image_evidence.text
    docx = await service.parse_docx(tmp_path / "document.docx", "document.docx")
    assert docx.extraction["metadata"]["structured_parser"]["backend"] == "fake-structured"
    assert docx.extraction["raw_content"]["text_original"] == _evidence().text

    pptx_path = tmp_path / "slides.pptx"
    pptx_path.write_bytes(b"synthetic-pptx-for-fake-docling")
    presentation = await service.parse_docling_document(
        pptx_path, "slides.pptx", kind="pptx"
    )
    assert presentation.document_subtype == "presentation"
    assert presentation.extraction["metadata"]["adapter"] == "docling"


@pytest.mark.asyncio
async def test_business_evidence_blocker_escalates_remaining_page(tmp_path: Path):
    image = tmp_path / "page.png"
    Image.new("RGB", (600, 800), "white").save(image)
    baseline = _baseline(str(image)).model_copy(deep=True)
    baseline.lines = []
    baseline.bom = []
    baseline.field_meta = {
        path: meta
        for path, meta in baseline.field_meta.items()
        if not path.startswith("$.lines[")
    }
    pp_evidence = DocumentEvidence(
        backend="fake-pp",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=600,
                height=800,
                blocks=[
                    EvidenceBlock(
                        block_id="title",
                        text="采购合同\n合同编号：HT-2026-001",
                        confidence=0.99,
                        bbox=EvidenceBBox(x0=10, y0=10, x1=500, y1=80),
                    )
                ],
            )
        ],
    )
    pp = FakeBackend(pp_evidence, name="fake-pp")
    vl = FakeBackend(_evidence(), name="fake-vlm")
    service = DocumentParserService(
        mode="structured",
        pp_structure=pp,
        paddle_vl=vl,
        native_pdf_parser=lambda *args, **kwargs: baseline.model_copy(deep=True),
    )

    result = await service.parse_pdf(
        tmp_path / "document.pdf",
        "采购函.pdf",
        doc_type_hint="order",
        document_subtype_hint="purchase_contract",
    )

    assert pp.calls == 1
    assert vl.calls == 1
    assert result.document_subtype == "purchase_contract"
    assert result.header.contract_number == "HT-2026-001"
    assert result.lines[0].name_raw == "测试线缆"
    raw = result.extraction["metadata"]["structured_evidence"]["raw"]
    assert raw["vlm_escalated_pages"] == [1]
    assert "business_evidence_blocker" in raw["vlm_escalation_reasons"]
