from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutCandidateProposal,
    TabularLayoutExecutionObservation,
    TabularLayoutProbe,
    TabularLayoutRoutingRuntime,
    TabularLayoutSignature,
    TabularLayoutTableShape,
    build_tabular_layout_signature,
)
from m1.documents.tabular_schema import (
    ColumnMapping,
    HeaderFieldMapping,
    TableMapping,
    TabularSchemaPlan,
)
from m1.knowledge import (
    IdempotencyConflictError,
    KnowledgeStore,
    TabularLayoutObservationOutcome,
    TabularLayoutObservationRecord,
    TabularLayoutObservationSummary,
    TabularLayoutProfileRecord,
    TabularLayoutProfileStatus,
    TenantBoundaryError,
    TenantRecord,
)
from m1.knowledge.db_models import TabularLayoutObservationRow
from sqlalchemy.exc import IntegrityError


def _signature(*, label: str = "order_number") -> TabularLayoutSignature:
    return build_tabular_layout_signature(
        TabularLayoutProbe(
            source_kind="spreadsheet",
            layout_tokens=("header_band",),
            semantic_labels=(label, "quantity"),
            tables=(
                TabularLayoutTableShape(
                    table_index=0,
                    orientation="records_by_row",
                    row_bucket="many",
                    column_bucket="few",
                    header_band_rows=1,
                    semantic_labels=(label, "quantity"),
                    layout_tokens=("records",),
                ),
            ),
        )
    )


def _plan() -> TabularSchemaPlan:
    """A complete coordinate/target plan, deliberately without cell values."""

    return TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="contract_number",
                strategy="horizontal",
                sheet="Sheet1",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
        tables=[
            TableMapping(
                sheet="Sheet1",
                orientation="rows",
                header_rows=[3],
                data_start_row=4,
                data_end_row=20,
                columns=[
                    ColumnMapping(
                        column=1,
                        field="model",
                        label_cells=["A3"],
                    ),
                    ColumnMapping(
                        column=2,
                        field="quantity",
                        label_cells=["B3"],
                    ),
                ],
            )
        ],
    )


def _profile(
    tenant_id: str,
    *,
    profile_id: str,
    profile_key: str = "supplier-order-layout",
    version: int = 1,
    supersedes_profile_id: str | None = None,
    label: str = "order_number",
    embedding: list[float] | None = None,
    embedding_model: str = "test-embedding",
    embedding_dimensions: int | None = None,
) -> TabularLayoutProfileRecord:
    signature = _signature(label=label)
    return TabularLayoutProfileRecord(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=profile_key,
        version=version,
        supersedes_profile_id=supersedes_profile_id,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        plan=_plan(),
        embedding=embedding,
        embedding_model=embedding_model if embedding is not None else "",
        embedding_dimensions=(
            (1024 if embedding_dimensions is None else embedding_dimensions)
            if embedding is not None
            else 0
        ),
        created_by="tabular-layout-proposer",
    )


def _summary(
    *, task_reference_hash: str | None = None
) -> TabularLayoutObservationSummary:
    return TabularLayoutObservationSummary(
        parser_revision="m1.tabular-schema.v1",
        applied=True,
        validation_passed=True,
        mapped_field_count=3,
        mapped_record_count=17,
        issue_codes=(),
        task_reference_hash=task_reference_hash,
    )


async def _seed_success_observations(
    store, tenant_id: str, profile_id: str, fingerprint: str
) -> None:
    for index in range(3):
        task_hash = hashlib.sha256(f"task-{index}".encode()).hexdigest()
        await store.record_tabular_layout_observation(
            TabularLayoutObservationRecord(
                observation_id=f"activation-observation-{profile_id}-{index}",
                tenant_id=tenant_id,
                profile_id=profile_id,
                idempotency_key=f"activation:{profile_id}:{index}",
                exact_fingerprint=fingerprint,
                outcome=TabularLayoutObservationOutcome.SUCCESS,
                latency_ms=10 + index,
                summary=_summary(task_reference_hash=task_hash),
            )
        )


@pytest.fixture
async def layouts(tmp_path: Path):
    store = KnowledgeStore(f"sqlite+aiosqlite:///{tmp_path / 'layouts.db'}")
    await store.init()
    tenant = await store.create_tenant(
        TenantRecord(tenant_key="layout-a", display_name="Layout tenant A")
    )
    second = await store.create_tenant(
        TenantRecord(tenant_key="layout-b", display_name="Layout tenant B")
    )
    try:
        yield store, tenant, second
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_tabular_layout_profile_create_is_idempotent_and_returns_plan(
    layouts,
) -> None:
    store, tenant, second = layouts
    record = _profile(tenant.tenant_id, profile_id="tabular-layout-1")

    created = await store.create_tabular_layout_profile(record)
    replay = await store.create_tabular_layout_candidate(
        TabularLayoutCandidateProposal(
            tenant_id=tenant.tenant_id,
            profile_key=record.profile_key,
            signature=record.signature,
            plan=record.plan,
        )
    )

    assert replay.profile_id == created.profile_id == "tabular-layout-1"
    assert created.plan == _plan().model_dump(mode="json")
    assert (
        await store.get_tabular_layout_profile(second.tenant_id, created.profile_id)
        is None
    )
    assert [
        item.profile_id
        for item in await store.list_tabular_layout_profiles(tenant.tenant_id)
    ] == ["tabular-layout-1"]

    with pytest.raises(IdempotencyConflictError):
        await store.create_tabular_layout_profile(
            record.model_copy(update={"created_by": "different-proposer"})
        )


@pytest.mark.asyncio
async def test_tabular_layout_activation_requires_expected_observations(
    layouts,
) -> None:
    store, tenant, _second = layouts
    profile = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-active")
    )

    with pytest.raises(ValueError, match="three successful observations"):
        await store.activate_tabular_layout_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="reviewer",
            expected_observation_count=1,
        )

    await _seed_success_observations(
        store, tenant.tenant_id, profile.profile_id, profile.exact_fingerprint
    )
    active = await store.activate_tabular_layout_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="reviewer",
        expected_observation_count=3,
        review_reason_codes=("golden_corpus_passed",),
    )
    assert active.status is TabularLayoutProfileStatus.ACTIVE
    assert active.approved_by == "reviewer"
    assert active.plan["tables"][0]["columns"][0]["target_path"] is None
    assert (
        await store.get_active_tabular_layout_profile_by_fingerprint(
            tenant.tenant_id,
            active.exact_fingerprint,
            contract_revision="m1.document.v2",
            interpreter_revision="m1.tabular-layout.v1",
        )
    ).profile_id == active.profile_id


@pytest.mark.asyncio
async def test_knowledge_store_conforms_to_tabular_layout_routing_protocol(
    layouts,
) -> None:
    store, tenant, _second = layouts
    signature = _signature()
    candidate = await store.create_tabular_layout_candidate(
        TabularLayoutCandidateProposal(
            tenant_id=tenant.tenant_id,
            profile_key="tabular-layout-protocol",
            signature=signature,
            plan=_plan(),
        )
    )
    await _seed_success_observations(
        store, tenant.tenant_id, candidate.profile_id, candidate.exact_fingerprint
    )
    await store.activate_tabular_layout_profile(
        tenant.tenant_id,
        candidate.profile_id,
        approved_by="reviewer",
        expected_observation_count=3,
    )

    resolution = await TabularLayoutRoutingRuntime(store=store).resolve(
        tenant_id=tenant.tenant_id,
        probe=TabularLayoutProbe(
            source_kind="spreadsheet",
            layout_tokens=("header_band",),
            semantic_labels=("order_number", "quantity"),
            tables=(
                TabularLayoutTableShape(
                    table_index=0,
                    orientation="records_by_row",
                    row_bucket="many",
                    column_bucket="few",
                    header_band_rows=1,
                    semantic_labels=("order_number", "quantity"),
                    layout_tokens=("records",),
                ),
            ),
        ),
    )

    assert resolution.action == "reuse"
    assert resolution.profile_id == candidate.profile_id
    assert resolution.plan == _plan().model_dump(mode="json")


@pytest.mark.asyncio
async def test_tabular_layout_revision_is_immutable_and_tenant_scoped(layouts) -> None:
    store, tenant, second = layouts
    first = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-v1")
    )
    cross_tenant = _profile(
        second.tenant_id,
        profile_id="tabular-layout-cross-tenant",
        version=2,
        supersedes_profile_id=first.profile_id,
    )
    with pytest.raises(TenantBoundaryError):
        await store.create_tabular_layout_profile(cross_tenant)

    await _seed_success_observations(
        store, tenant.tenant_id, first.profile_id, first.exact_fingerprint
    )
    await store.activate_tabular_layout_profile(
        tenant.tenant_id,
        first.profile_id,
        approved_by="reviewer",
        expected_observation_count=3,
    )
    with pytest.raises(ValueError, match="must be deprecated"):
        await store.create_tabular_layout_profile(
            _profile(
                tenant.tenant_id,
                profile_id="tabular-layout-active-v2",
                version=2,
                supersedes_profile_id=first.profile_id,
            )
        )

    await store.deprecate_tabular_layout_profile(
        tenant.tenant_id,
        first.profile_id,
        reviewed_by="reviewer",
        review_reason_codes=("new_layout_revision",),
    )
    revision = await store.create_tabular_layout_profile(
        _profile(
            tenant.tenant_id,
            profile_id="tabular-layout-v2",
            version=2,
            supersedes_profile_id=first.profile_id,
        )
    )
    assert revision.version == 2
    assert revision.supersedes_profile_id == first.profile_id


@pytest.mark.asyncio
async def test_tabular_layout_observations_are_idempotent_and_tenant_safe(
    layouts,
) -> None:
    store, tenant, second = layouts
    profile = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-observed")
    )
    observation = TabularLayoutObservationRecord(
        observation_id="tabular-observation-1",
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        idempotency_key="layout-observation-0001",
        exact_fingerprint=profile.exact_fingerprint,
        outcome=TabularLayoutObservationOutcome.SUCCESS,
        latency_ms=17,
        summary=_summary(),
    )
    first = await store.record_tabular_layout_observation(observation)
    replay = await store.record_tabular_layout_observation(
        observation.model_copy(update={"observation_id": "tabular-observation-retry"})
    )
    assert replay.observation_id == first.observation_id
    updated = await store.get_tabular_layout_profile(
        tenant.tenant_id, profile.profile_id
    )
    assert (
        updated.observation_count,
        updated.success_count,
        updated.failure_count,
    ) == (
        1,
        1,
        0,
    )

    with pytest.raises(IdempotencyConflictError):
        await store.record_tabular_layout_observation(
            observation.model_copy(update={"latency_ms": 99})
        )
    with pytest.raises(TenantBoundaryError):
        await store.record_tabular_layout_observation(
            observation.model_copy(
                update={
                    "tenant_id": second.tenant_id,
                    "observation_id": "tabular-observation-cross",
                    "idempotency_key": "layout-observation-cross",
                }
            )
        )


@pytest.mark.asyncio
async def test_activation_rejects_any_failure_even_with_three_successful_tasks(
    layouts,
) -> None:
    store, tenant, _second = layouts
    profile = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-failure-gate")
    )
    await _seed_success_observations(
        store, tenant.tenant_id, profile.profile_id, profile.exact_fingerprint
    )
    await store.record_tabular_layout_observation(
        TabularLayoutObservationRecord(
            observation_id="activation-failure",
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            idempotency_key="activation:failure",
            exact_fingerprint=profile.exact_fingerprint,
            outcome=TabularLayoutObservationOutcome.FAILURE,
            latency_ms=20,
            error_code="apply_failed",
            summary=_summary(
                task_reference_hash=hashlib.sha256(b"failed-task").hexdigest()
            ).model_copy(update={"applied": False, "validation_passed": False}),
        )
    )

    with pytest.raises(IdempotencyConflictError, match="failures"):
        await store.activate_tabular_layout_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="reviewer",
            expected_observation_count=4,
        )


@pytest.mark.asyncio
async def test_parser_observation_adapter_uses_hashed_task_reference(layouts) -> None:
    store, tenant, _second = layouts
    profile = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-adapter")
    )
    task_hash = hashlib.sha256(b"task-adapter").hexdigest()
    persisted = await store.record_tabular_layout_execution_observation(
        TabularLayoutExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=task_hash,
            outcome="success",
            parser_revision="m1.tabular-schema.v1",
            applied=True,
            validation_passed=True,
            mapped_field_count=2,
            mapped_record_count=1,
        )
    )
    assert persisted.summary.task_reference_hash == task_hash
    assert persisted.idempotency_key.endswith(task_hash)


@pytest.mark.asyncio
async def test_tabular_layout_vector_search_isolates_embedding_space(layouts) -> None:
    store, tenant, _second = layouts
    first_vector = [1.0, *([0.0] * 1023)]
    second_vector = [0.0, 1.0, *([0.0] * 1022)]
    first = await store.create_tabular_layout_profile(
        _profile(
            tenant.tenant_id,
            profile_id="tabular-layout-vector-a",
            profile_key="tabular-layout-vector-a",
            embedding=first_vector,
        )
    )
    second = await store.create_tabular_layout_profile(
        _profile(
            tenant.tenant_id,
            profile_id="tabular-layout-vector-b",
            profile_key="tabular-layout-vector-b",
            label="product_id",
            embedding=second_vector,
            embedding_model="other-embedding",
        )
    )
    await _seed_success_observations(
        store, tenant.tenant_id, first.profile_id, first.exact_fingerprint
    )
    await store.activate_tabular_layout_profile(
        tenant.tenant_id,
        first.profile_id,
        approved_by="reviewer",
        expected_observation_count=3,
    )
    await _seed_success_observations(
        store, tenant.tenant_id, second.profile_id, second.exact_fingerprint
    )
    await store.activate_tabular_layout_profile(
        tenant.tenant_id,
        second.profile_id,
        approved_by="reviewer",
        expected_observation_count=3,
    )

    matches = await store.find_active_tabular_layout_profiles(
        tenant.tenant_id,
        first_vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        contract_revision="m1.document.v2",
        interpreter_revision="m1.tabular-layout.v1",
        limit=5,
    )
    assert [(item.profile.profile_id, item.vector_similarity) for item in matches] == [
        ("tabular-layout-vector-a", 1.0)
    ]


@pytest.mark.asyncio
async def test_direct_cross_tenant_observation_write_is_rejected_by_composite_fk(
    layouts,
) -> None:
    store, tenant, second = layouts
    profile = await store.create_tabular_layout_profile(
        _profile(tenant.tenant_id, profile_id="tabular-layout-fk")
    )
    with pytest.raises(IntegrityError):
        async with store.sessionmaker.begin() as session:
            session.add(
                TabularLayoutObservationRow(
                    observation_id="tabular-layout-invalid-fk",
                    tenant_id=second.tenant_id,
                    profile_id=profile.profile_id,
                    idempotency_key="direct-cross-tenant-layout-observation",
                    exact_fingerprint=profile.exact_fingerprint,
                    outcome="success",
                    latency_ms=0,
                    error_code="",
                    summary_json=_summary().model_dump(mode="json"),
                    observed_at=profile.created_at,
                )
            )


def test_tabular_layout_tables_have_tenant_safe_composite_foreign_keys() -> None:
    tables = {
        table.name: table
        for table in __import__(
            "m1.knowledge", fromlist=["KnowledgeBase"]
        ).KnowledgeBase.metadata.sorted_tables
    }
    observation = tables["knowledge_tabular_layout_observations"]
    targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in observation.foreign_key_constraints
    }
    assert (
        "knowledge_tabular_layout_profiles.tenant_id",
        "knowledge_tabular_layout_profiles.profile_id",
    ) in targets
    profile = tables["knowledge_tabular_layout_profiles"]
    profile_targets = {
        tuple(element.target_fullname for element in constraint.elements)
        for constraint in profile.foreign_key_constraints
    }
    assert (
        "knowledge_tabular_layout_profiles.tenant_id",
        "knowledge_tabular_layout_profiles.profile_id",
    ) in profile_targets
