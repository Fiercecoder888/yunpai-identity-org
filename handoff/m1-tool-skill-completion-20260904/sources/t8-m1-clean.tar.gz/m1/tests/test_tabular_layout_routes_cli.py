from __future__ import annotations

from types import SimpleNamespace

import pytest

from m1 import tabular_layout_routes as cli


def _profile(*, status: str = "candidate", observations: int = 3, failures: int = 0):
    return SimpleNamespace(
        profile_id="profile-1",
        tenant_id="tenant-a",
        profile_key="layout-1",
        version=1,
        status=status,
        exact_fingerprint="a" * 64,
        signature=SimpleNamespace(
            document_type_hint="order",
            document_subtype_hint="stocking_order",
            model_fingerprint="b" * 64,
        ),
        observation_count=observations,
        success_count=observations - failures,
        failure_count=failures,
        approved_by=None,
        approved_at=None,
    )


class _Store:
    profile = _profile()
    activated = None
    rejected = None

    def __init__(self, _url: str):
        pass

    async def init(self):
        return None

    async def close(self):
        return None

    async def list_tabular_layout_profiles(self, tenant_id, *, status=None, limit=100):
        assert tenant_id == "tenant-a"
        assert limit == 10
        return [self.profile]

    async def get_tabular_layout_profile(self, tenant_id, profile_id):
        assert (tenant_id, profile_id) == ("tenant-a", "profile-1")
        return self.profile

    async def activate_tabular_layout_profile(self, tenant_id, profile_id, **kwargs):
        self.activated = (tenant_id, profile_id, kwargs)
        return self.profile

    async def reject_tabular_layout_profile(self, tenant_id, profile_id, **kwargs):
        self.rejected = (tenant_id, profile_id, kwargs)
        return self.profile


@pytest.mark.asyncio
async def test_cli_list_delegates_to_repository(monkeypatch):
    monkeypatch.setattr(cli, "KnowledgeStore", _Store)
    result = await cli._run(
        cli._parser().parse_args(["list", "--tenant-id", "tenant-a", "--limit", "10"])
    )
    assert result["operation"] == "list"
    assert result["profiles"][0]["profile_id"] == "profile-1"


@pytest.mark.asyncio
async def test_cli_approve_uses_actual_observation_count(monkeypatch):
    monkeypatch.setattr(cli, "KnowledgeStore", _Store)
    store = _Store("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    result = await cli._run(
        cli._parser().parse_args(
            [
                "approve",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--approved-by",
                "reviewer",
            ]
        )
    )
    assert result["status"] == "active"
    assert store.activated[2]["expected_observation_count"] == 3


@pytest.mark.asyncio
async def test_cli_reject_delegates_without_direct_sql(monkeypatch):
    monkeypatch.setattr(cli, "KnowledgeStore", _Store)
    store = _Store("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    result = await cli._run(
        cli._parser().parse_args(
            [
                "reject",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--reviewed-by",
                "reviewer",
            ]
        )
    )
    assert result["status"] == "rejected"
    assert store.rejected[2]["reviewed_by"] == "reviewer"
