from __future__ import annotations

from collections.abc import Sequence

import pytest
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.tabular_layout_routing import (
    TabularLayoutCandidateProposal,
    TabularLayoutModelChoice,
    TabularLayoutProbe,
    TabularLayoutProfile,
    TabularLayoutProfileMatch,
    TabularLayoutRoutingRuntime,
    TabularLayoutTableShape,
    build_tabular_layout_signature,
)
from m1.documents.tabular_schema import TabularSchemaPlan

VECTOR = (0.1, 0.2, 0.3)


def _shape(
    *,
    labels: tuple[str, ...] = ("order_number", "quantity"),
    layout_tokens: tuple[str, ...] = ("header_band", "records"),
) -> TabularLayoutTableShape:
    return TabularLayoutTableShape(
        table_index=0,
        row_bucket="many",
        column_bucket="few",
        orientation="records_by_row",
        header_band_rows=1,
        layout_tokens=layout_tokens,
        semantic_labels=labels,
    )


def _probe(
    *,
    labels: tuple[str, ...] = ("order_number", "quantity"),
    layout_tokens: tuple[str, ...] = ("header_band", "records"),
) -> TabularLayoutProbe:
    return TabularLayoutProbe(
        source_kind="spreadsheet",
        tables=(_shape(labels=labels, layout_tokens=layout_tokens),),
        layout_tokens=layout_tokens,
        semantic_labels=labels,
    )


def _validated_plan(*, document_shape: str = "single_order") -> dict:
    return {
        "schema_version": "v1",
        "document_shape": document_shape,
        "header_fields": [
            {
                "field": "order_number",
                "target_path": "$.header.order_number",
                "strategy": "horizontal",
                "sheet": "Orders",
                "region_id": None,
                "label_cells": ["A1"],
                "value_cells": ["B1"],
            }
        ],
        "tables": [
            {
                "sheet": "Orders",
                "region_id": "table-1",
                "orientation": "rows",
                "header_rows": [3],
                "header_columns": [],
                "data_start_row": 4,
                "data_end_row": None,
                "data_rows": [],
                "data_start_column": None,
                "data_end_column": None,
                "data_columns": [],
                "data_ranges": [],
                "columns": [
                    {
                        "column": 1,
                        "field": "product_id",
                        "target_path": "$.lines[*].product_id",
                        "label_cells": ["A3"],
                    },
                    {
                        "column": 2,
                        "field": "quantity",
                        "target_path": "$.lines[*].quantity",
                        "label_cells": ["B3"],
                    },
                ],
                "row_fields": [],
            }
        ],
        "inspection_windows": [],
    }


def _profile(
    signature,
    *,
    profile_id: str = "profile-a",
    tenant_id: str = "tenant-a",
    status: str = "active",
    plan: dict | None = None,
    embedding: tuple[float, ...] | None = VECTOR,
) -> TabularLayoutProfile:
    return TabularLayoutProfile(
        profile_id=profile_id,
        tenant_id=tenant_id,
        profile_key=f"key-{profile_id}",
        status=status,
        exact_fingerprint=signature.exact_fingerprint(),
        signature=signature,
        plan=plan or _validated_plan(),
        embedding=embedding,
        embedding_model="test-layout-embedding" if embedding is not None else "",
        embedding_dimensions=len(embedding) if embedding is not None else 0,
        observation_count=10,
        success_count=10,
    )


class _Embedding:
    model = "test-layout-embedding"
    dimensions = len(VECTOR)

    def __init__(self, *, vector: tuple[float, ...] = VECTOR, failure: bool = False):
        self.vector = vector
        self.failure = failure
        self.inputs: list[str] = []

    async def embed_texts(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        self.inputs.extend(texts)
        if self.failure:
            raise TimeoutError("embedding unavailable")
        return (self.vector,)


class _Selector:
    def __init__(self, output: object, *, failure: bool = False) -> None:
        self.output = output
        self.failure = failure
        self.requests = []

    async def select(self, request):
        self.requests.append(request)
        if self.failure:
            raise TimeoutError("selector unavailable")
        return self.output


class _Store:
    def __init__(
        self,
        *,
        exact: TabularLayoutProfile | None = None,
        matches: Sequence[TabularLayoutProfileMatch] = (),
        exact_failure: bool = False,
        search_failure: bool = False,
        candidate_failure: bool = False,
    ) -> None:
        self.exact = exact
        self.matches = tuple(matches)
        self.exact_failure = exact_failure
        self.search_failure = search_failure
        self.candidate_failure = candidate_failure
        self.exact_calls: list[tuple[str, str, str, str]] = []
        self.search_calls: list[tuple[str, str, int, int]] = []
        self.created: list[TabularLayoutCandidateProposal] = []

    async def get_active_tabular_layout_profile_by_fingerprint(
        self,
        tenant_id: str,
        exact_fingerprint: str,
        *,
        contract_revision: str,
        interpreter_revision: str,
    ) -> TabularLayoutProfile | None:
        self.exact_calls.append(
            (tenant_id, exact_fingerprint, contract_revision, interpreter_revision)
        )
        if self.exact_failure:
            raise RuntimeError("store unavailable")
        return self.exact

    async def find_active_tabular_layout_profiles(
        self,
        tenant_id: str,
        embedding: Sequence[float],
        *,
        embedding_model: str,
        embedding_dimensions: int,
        limit: int,
    ) -> Sequence[TabularLayoutProfileMatch]:
        self.search_calls.append(
            (tenant_id, embedding_model, embedding_dimensions, limit)
        )
        if self.search_failure:
            raise RuntimeError("store unavailable")
        return self.matches[:limit]

    async def create_tabular_layout_candidate(
        self, candidate: TabularLayoutCandidateProposal
    ) -> TabularLayoutProfile:
        self.created.append(candidate)
        if self.candidate_failure:
            raise RuntimeError("candidate store unavailable")
        return TabularLayoutProfile(
            profile_id="candidate-1",
            tenant_id=candidate.tenant_id,
            profile_key=candidate.profile_key,
            status="candidate",
            exact_fingerprint=candidate.signature.exact_fingerprint(),
            signature=candidate.signature,
            plan=candidate.plan,
            embedding=candidate.embedding,
            embedding_model=candidate.embedding_model,
            embedding_dimensions=candidate.embedding_dimensions,
        )


@pytest.mark.asyncio
async def test_exact_profile_reuses_without_embedding_or_model() -> None:
    signature = build_tabular_layout_signature(_probe())
    store = _Store(exact=_profile(signature))
    embedding = _Embedding()
    selector = _Selector({"action": "generic", "confidence": 1.0})

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "reuse"
    assert result.reason == "exact_fingerprint"
    assert result.profile_id == "profile-a"
    assert result.plan == _validated_plan()
    assert not embedding.inputs
    assert not selector.requests


@pytest.mark.asyncio
async def test_vector_top_k_uses_candidate_index_not_profile_id() -> None:
    current = _probe(labels=("order_number", "quantity"))
    candidate_signature = build_tabular_layout_signature(
        _probe(labels=("order_number", "unit"))
    )
    profile = _profile(candidate_signature, profile_id="opaque-profile-9")
    store = _Store(
        matches=(TabularLayoutProfileMatch(profile=profile, vector_similarity=0.98),)
    )
    selector = _Selector(
        TabularLayoutModelChoice(
            action="reuse",
            candidate_index=0,
            confidence=0.95,
        )
    )

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=current)

    assert result.action == "reuse"
    assert result.reason == "model_reuse"
    assert result.profile_id == "opaque-profile-9"
    assert result.plan == _validated_plan()
    request_payload = selector.requests[0].model_dump(mode="json")
    assert "profile_id" not in request_payload
    assert "opaque-profile-9" not in str(request_payload)
    assert request_payload["candidates"][0]["candidate_index"] == 0


@pytest.mark.asyncio
async def test_vector_candidates_are_bounded_to_top_five_before_model_selection() -> (
    None
):
    signature = build_tabular_layout_signature(_probe())
    matches = tuple(
        TabularLayoutProfileMatch(
            profile=_profile(signature, profile_id=f"profile-{index}"),
            vector_similarity=0.99 - index / 100,
        )
        for index in range(6)
    )
    selector = _Selector(
        TabularLayoutModelChoice(
            action="reuse",
            candidate_index=4,
            confidence=0.99,
        )
    )

    result = await TabularLayoutRoutingRuntime(
        store=_Store(matches=matches),
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "reuse"
    assert result.profile_id == "profile-4"
    assert len(selector.requests[0].candidates) == 5
    assert [
        candidate.candidate_index for candidate in selector.requests[0].candidates
    ] == [0, 1, 2, 3, 4]


@pytest.mark.asyncio
async def test_vector_search_overfetches_before_runtime_compatibility_filtering() -> (
    None
):
    signature = build_tabular_layout_signature(_probe())
    incompatible = tuple(
        TabularLayoutProfileMatch(
            profile=_profile(
                signature,
                profile_id=f"foreign-{index}",
                tenant_id="tenant-b",
            ),
            vector_similarity=0.99 - index / 100,
        )
        for index in range(5)
    )
    compatible = TabularLayoutProfileMatch(
        profile=_profile(signature, profile_id="compatible-6"),
        vector_similarity=0.93,
    )
    store = _Store(matches=(*incompatible, compatible))
    selector = _Selector(
        TabularLayoutModelChoice(action="reuse", candidate_index=0, confidence=0.99)
    )

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert store.search_calls[0][3] == 20
    assert result.action == "reuse"
    assert result.profile_id == "compatible-6"
    assert len(selector.requests[0].candidates) == 1


@pytest.mark.asyncio
async def test_model_cannot_invent_a_profile_identifier() -> None:
    candidate_signature = build_tabular_layout_signature(
        _probe(labels=("order_number", "unit"))
    )
    profile = _profile(candidate_signature)
    store = _Store(
        matches=(TabularLayoutProfileMatch(profile=profile, vector_similarity=0.98),)
    )
    selector = _Selector(
        {
            "action": "reuse",
            "candidate_index": 0,
            "candidate_profile_id": "invented-profile",
            "confidence": 0.99,
        }
    )

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "generic"
    assert result.reason == "invalid_model_output"
    assert result.profile_id is None


@pytest.mark.asyncio
async def test_low_confidence_reuse_fails_closed_to_generic() -> None:
    candidate_signature = build_tabular_layout_signature(
        _probe(labels=("order_number", "unit"))
    )
    store = _Store(
        matches=(
            TabularLayoutProfileMatch(
                profile=_profile(candidate_signature), vector_similarity=0.98
            ),
        )
    )
    selector = _Selector({"action": "reuse", "candidate_index": 0, "confidence": 0.20})

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "generic"
    assert result.reason == "model_confidence_below_threshold"


@pytest.mark.asyncio
async def test_no_match_proposes_then_observe_persists_only_validated_plan() -> None:
    store = _Store()
    selector = _Selector({"action": "propose", "confidence": 0.95})
    runtime = TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    )

    result = await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "propose"
    assert result.reason == "no_compatible_candidates"
    assert result.candidate_observation_required is True
    assert not store.created
    assert selector.requests == []

    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        probe=_probe(),
        validated_plan=_validated_plan(),
    )

    assert candidate.profile_id == "candidate-1"
    assert candidate.status == "candidate"
    assert len(store.created) == 1
    proposal = store.created[0]
    assert proposal.plan == _validated_plan()
    assert proposal.signature.exact_fingerprint() == result.signature_fingerprint
    assert "order_number" in proposal.signature.embedding_text()


@pytest.mark.asyncio
async def test_review_never_creates_or_reuses_a_profile() -> None:
    signature = build_tabular_layout_signature(_probe())
    store = _Store(
        matches=(
            TabularLayoutProfileMatch(
                profile=_profile(signature), vector_similarity=0.99
            ),
        )
    )
    selector = _Selector({"action": "review", "confidence": 0.90})

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "review"
    assert result.reason == "model_review"
    assert result.review_required is True
    assert result.profile_id is None
    assert not store.created


@pytest.mark.asyncio
async def test_embedding_or_selector_failure_preserves_generic_path() -> None:
    embedding_failure = await TabularLayoutRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(failure=True),
        selector=_Selector({"action": "propose", "confidence": 0.95}),
    ).resolve(tenant_id="tenant-a", probe=_probe())
    assert embedding_failure.action == "generic"
    assert embedding_failure.reason == "embedding_failure"

    signature = build_tabular_layout_signature(_probe())
    selector_failure = await TabularLayoutRoutingRuntime(
        store=_Store(
            matches=(
                TabularLayoutProfileMatch(
                    profile=_profile(signature), vector_similarity=0.99
                ),
            )
        ),
        embedding_provider=_Embedding(),
        selector=_Selector({}, failure=True),
    ).resolve(tenant_id="tenant-a", probe=_probe())
    assert selector_failure.action == "generic"
    assert selector_failure.reason == "selector_failure"


@pytest.mark.asyncio
async def test_runtime_rechecks_tenant_and_profile_compatibility() -> None:
    foreign_signature = build_tabular_layout_signature(
        _probe(labels=("order_number", "unit"))
    )
    foreign = _profile(foreign_signature, tenant_id="tenant-b")
    store = _Store(
        matches=(TabularLayoutProfileMatch(profile=foreign, vector_similarity=0.99),)
    )
    selector = _Selector({"action": "reuse", "candidate_index": 0, "confidence": 0.99})

    result = await TabularLayoutRoutingRuntime(
        store=store,
        embedding_provider=_Embedding(),
        selector=selector,
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "propose"
    assert result.reason == "no_compatible_candidates"
    assert selector.requests == []


@pytest.mark.asyncio
async def test_exact_profile_with_incompatible_lifecycle_is_not_reused() -> None:
    signature = build_tabular_layout_signature(_probe())
    incompatible = _profile(signature, status="candidate")

    result = await TabularLayoutRoutingRuntime(
        store=_Store(exact=incompatible),
        embedding_provider=_Embedding(),
        selector=_Selector({"action": "generic", "confidence": 0.99}),
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "generic"
    assert result.reason == "exact_profile_incompatible"


@pytest.mark.asyncio
async def test_exact_store_result_is_rechecked_for_tenant_scope() -> None:
    signature = build_tabular_layout_signature(_probe())
    foreign = _profile(signature, tenant_id="tenant-b")

    result = await TabularLayoutRoutingRuntime(
        store=_Store(exact=foreign),
        embedding_provider=_Embedding(),
        selector=_Selector({"action": "generic", "confidence": 0.99}),
    ).resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "generic"
    assert result.reason == "exact_profile_incompatible"


def test_signature_accepts_only_closed_value_free_vocabulary() -> None:
    with pytest.raises(ValueError, match="closed value-free vocabulary"):
        TabularLayoutProbe(
            source_kind="spreadsheet",
            layout_tokens=("customer-secret-9001",),
        )
    with pytest.raises(ValueError, match="closed value-free vocabulary"):
        TabularLayoutTableShape(
            table_index=0,
            row_bucket="few",
            column_bucket="few",
            semantic_labels=("SO-SECRET-9001",),
        )

    signature = build_tabular_layout_signature(_probe())
    rendered = signature.embedding_text()
    assert "SO-SECRET-9001" not in rendered
    assert "customer-secret" not in rendered


@pytest.mark.asyncio
async def test_candidate_plan_keeps_mappings_but_rejects_values_and_filenames() -> None:
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(),
    )
    plan = _validated_plan()
    plan["inspection_windows"] = [
        {
            "sheet": "Orders",
            "start_row": 1,
            "end_row": 5,
            "start_column": 1,
            "end_column": 2,
            "reason": "cell B1 contains a source value and must not persist",
        }
    ]
    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        probe=_probe(),
        validated_plan=plan,
    )
    assert candidate.plan["header_fields"][0]["target_path"] == "$.header.order_number"
    assert candidate.plan["header_fields"][0]["value_cells"] == ["B1"]
    assert "reason" not in candidate.plan["inspection_windows"][0]

    unsafe = _validated_plan()
    unsafe["header_fields"][0]["value"] = "SO-SECRET-9001"
    with pytest.raises(ValueError, match="forbidden value-bearing key"):
        await runtime.observe_candidate(
            tenant_id="tenant-a",
            probe=_probe(),
            validated_plan=unsafe,
        )


@pytest.mark.asyncio
async def test_observe_candidate_accepts_a_validated_tabular_schema_plan_model() -> (
    None
):
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(), embedding_provider=_Embedding()
    )
    plan = TabularSchemaPlan.model_validate(_validated_plan())

    candidate = await runtime.observe_candidate(
        tenant_id="tenant-a",
        probe=_probe(),
        validated_plan=plan,
    )

    assert candidate.status == "candidate"
    assert candidate.plan["tables"][0]["columns"][0]["target_path"] == (
        "$.lines[*].product_id"
    )


@pytest.mark.asyncio
async def test_optional_dependency_failure_degrades_and_keeps_generic_route() -> None:
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(exact_failure=True),
        embedding_provider=_Embedding(),
        selector=_Selector({"action": "generic", "confidence": 1.0}),
    )

    result = await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert result.action == "generic"
    assert result.reason == "store_failure"
    status = runtime.status_snapshot()
    assert status["required"] is False
    assert status["degraded"] is True
    assert status["failures"] == 1
    assert status["dependencies"]["store"]["last_error_type"] == "RuntimeError"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("dependency", "runtime"),
    [
        (
            "store",
            TabularLayoutRoutingRuntime(
                store=_Store(exact_failure=True),
                embedding_provider=_Embedding(),
                required=True,
            ),
        ),
        (
            "embedding",
            TabularLayoutRoutingRuntime(
                store=_Store(),
                embedding_provider=_Embedding(failure=True),
                required=True,
            ),
        ),
    ],
)
async def test_required_dependencies_fail_closed_with_safe_error(
    dependency: str,
    runtime: TabularLayoutRoutingRuntime,
) -> None:
    with pytest.raises(DocumentRoutingDependencyError) as captured:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert captured.value.dependency == dependency
    assert "unavailable" not in str(captured.value).casefold()
    assert runtime.status_snapshot()["degraded"] is True


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "selector",
    [
        _Selector({}, failure=True),
        _Selector({"action": "reuse", "candidate_index": 4, "confidence": 0.99}),
        _Selector({"action": "untrusted", "confidence": 0.99}),
    ],
)
async def test_required_model_failure_or_invalid_response_fails_closed(
    selector: _Selector,
) -> None:
    signature = build_tabular_layout_signature(_probe())
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(
            matches=(
                TabularLayoutProfileMatch(
                    profile=_profile(signature),
                    vector_similarity=0.99,
                ),
            )
        ),
        embedding_provider=_Embedding(),
        selector=selector,
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as captured:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert captured.value.dependency == "model"
    assert "untrusted" not in str(captured.value)


@pytest.mark.asyncio
async def test_required_dependency_circuit_rejects_without_another_call() -> None:
    embedding = _Embedding(failure=True)
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(),
        embedding_provider=embedding,
        required=True,
        circuit_failures=1,
        circuit_seconds=300,
    )

    with pytest.raises(DocumentRoutingDependencyError) as first:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())
    with pytest.raises(DocumentRoutingDependencyError) as second:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert first.value.dependency == "embedding"
    assert first.value.error_type == "TimeoutError"
    assert second.value.dependency == "embedding"
    assert second.value.error_type == "CircuitOpen"
    assert len(embedding.inputs) == 1
    assert runtime.status_snapshot()["circuit_open"] is True


@pytest.mark.asyncio
async def test_normal_proposal_and_review_do_not_degrade_dependencies() -> None:
    proposal_runtime = TabularLayoutRoutingRuntime(
        store=_Store(),
        embedding_provider=_Embedding(),
        selector=_Selector({"action": "generic", "confidence": 1.0}),
        required=True,
    )
    proposal = await proposal_runtime.resolve(tenant_id="tenant-a", probe=_probe())
    assert proposal.action == "propose"
    assert proposal_runtime.status_snapshot()["degraded"] is False

    signature = build_tabular_layout_signature(_probe())
    review_runtime = TabularLayoutRoutingRuntime(
        store=_Store(
            matches=(
                TabularLayoutProfileMatch(
                    profile=_profile(signature),
                    vector_similarity=0.99,
                ),
            )
        ),
        embedding_provider=_Embedding(),
        selector=_Selector({"action": "review", "confidence": 0.99}),
        required=True,
    )
    review = await review_runtime.resolve(tenant_id="tenant-a", probe=_probe())
    assert review.action == "review"
    assert review_runtime.status_snapshot()["degraded"] is False


@pytest.mark.asyncio
async def test_required_router_never_executes_inactive_exact_candidate() -> None:
    signature = build_tabular_layout_signature(_probe())
    runtime = TabularLayoutRoutingRuntime(
        store=_Store(exact=_profile(signature, status="candidate")),
        embedding_provider=_Embedding(),
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as captured:
        await runtime.resolve(tenant_id="tenant-a", probe=_probe())

    assert captured.value.dependency == "store"
    assert runtime.status_snapshot()["dependencies"]["store"]["degraded"] is True
