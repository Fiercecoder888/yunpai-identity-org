from __future__ import annotations

import json
from datetime import date
from pathlib import Path

import pytest
from pydantic import ValidationError

from m1.documents.envelope import (
    CellValue,
    DocumentEnvelope,
    MergedRange,
    SheetEnvelope,
    coordinate_from_row_col,
)
from m1.documents.models import (
    DocumentHeader,
    DocumentRecord,
    DocumentSource,
    FieldMetadata,
    OrderLine,
    SourceReference,
    ValidationIssue,
)
from m1.documents.tabular_schema import (
    ColumnMapping,
    DataRange,
    HeaderFieldMapping,
    InspectionWindow,
    RowMapping,
    TableMapping,
    TabularSchemaPlan,
    TabularSchemaSafetyError,
    apply_plan,
    build_tabular_summary,
    template_fingerprint,
    validate_plan,
)


def _envelope(
    rows: list[list[object]],
    *,
    filename: str = "source.xlsx",
    sheet_name: str = "订单",
) -> DocumentEnvelope:
    sheet = SheetEnvelope(name=sheet_name)
    for row_index, row in enumerate(rows, 1):
        for column_index, value in enumerate(row, 1):
            if value is None:
                continue
            coordinate = coordinate_from_row_col(row_index, column_index)
            sheet.cells[(row_index, column_index)] = CellValue(
                sheet=sheet.name,
                coordinate=coordinate,
                row=row_index,
                column=column_index,
                value=value,
                normalized_value=str(value).strip(),
            )
    sheet.max_row = len(rows)
    sheet.max_column = max(map(len, rows), default=0)
    return DocumentEnvelope(
        path=Path(filename),
        original_filename=filename,
        display_filename=filename,
        sha256="sha",
        mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        file_kind="xlsx",
        sheets=[sheet],
    )


def _baseline(**kwargs) -> DocumentRecord:
    return DocumentRecord(
        source=DocumentSource(original_filename="source.xlsx"),
        document_type="order",
        **kwargs,
    )


def test_horizontal_kv_reads_real_value_and_never_returns_model_value() -> None:
    envelope = _envelope([["订单号", "PO-1001"], ["型号", "数量"], ["M1", 2]])
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.order_number == "PO-1001"
    metadata = result.field_meta["$.header.order_number"]
    assert metadata.confidence < 1.0
    assert metadata.source_refs == [SourceReference(sheet="订单", cell="B1")]
    assert "value" not in HeaderFieldMapping.model_json_schema()["properties"]


def test_vertical_kv_parses_delivery_date_deterministically() -> None:
    envelope = _envelope([["交货日期"], ["2026年8月3日"]])
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="delivery_date",
                strategy="vertical",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2"],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.delivery_date_raw == "2026年8月3日"
    assert result.header.delivery_date_standard == date(2026, 8, 3)
    assert result.field_meta["$.header.delivery_date_standard"].confidence == 0.82


def test_excel_serial_delivery_date_is_normalized_after_coordinate_mapping() -> None:
    envelope = _envelope([["Delivery date", 46147]])
    sheet_name = envelope.sheets[0].name
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="delivery_date",
                strategy="horizontal",
                sheet=sheet_name,
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.delivery_date_raw == "46147"
    assert result.header.delivery_date_standard == date(2026, 5, 5)
    assert result.field_meta["$.header.delivery_date_raw"].source_refs == [
        SourceReference(sheet=sheet_name, cell="B1")
    ]


def test_constant_order_column_promotes_only_single_unique_value() -> None:
    envelope = _envelope(
        [["订单编号", "奇怪货号", "采购个数"], ["PO-A", "X-1", 2], ["PO-A", "X-2", 3]]
    )
    table = TableMapping(
        sheet="订单",
        header_rows=[1],
        data_start_row=2,
        columns=[
            ColumnMapping(column=1, field="order_number"),
            ColumnMapping(column=2, field="product_code"),
            ColumnMapping(column=3, field="quantity"),
        ],
    )
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2", "A3"],
            )
        ],
        tables=[table],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.order_number == "PO-A"
    assert [line.product_code for line in result.lines] == ["X-1", "X-2"]
    assert [line.quantity for line in result.lines] == [2, 3]
    assert result.lines[0].raw_columns == {
        "订单编号": "PO-A",
        "奇怪货号": "X-1",
        "采购个数": 2,
    }
    assert [
        ref.cell for ref in result.field_meta["$.header.order_number"].source_refs
    ] == [
        "A2",
        "A3",
    ]


def test_constant_column_sample_evidence_expands_to_full_large_table() -> None:
    rows: list[list[object]] = [["订单编号", "产品", "数量"]]
    rows.extend([["PO-LARGE", f"SKU-{index:03d}", index] for index in range(1, 51)])
    envelope = _envelope(rows)
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                # The bounded model prompt can only expose sample rows. The
                # deterministic layer must expand these examples itself.
                value_cells=["A2", "A3"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="order_number"),
                    ColumnMapping(column=2, field="product_code"),
                    ColumnMapping(column=3, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.order_number == "PO-LARGE"
    assert len(result.lines) == 50
    assert [
        ref.cell for ref in result.field_meta["$.header.order_number"].source_refs
    ] == [f"A{row}" for row in range(2, 52)]


def test_constant_column_checks_unsampled_rows_before_promoting_header() -> None:
    rows: list[list[object]] = [["订单编号", "产品"]]
    rows.extend(
        [
            ["PO-A" if index < 40 else "PO-B", f"SKU-{index:03d}"]
            for index in range(1, 51)
        ]
    )
    envelope = _envelope(rows)
    plan = TabularSchemaPlan(
        document_shape="multi_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2", "A3"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="order_number"),
                    ColumnMapping(column=2, field="product_code"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.order_number is None
    assert {line.custom_fields["order_number"] for line in result.lines} == {
        "PO-A",
        "PO-B",
    }
    assert result.extraction["order_groups"] == [
        {
            "order_number": "PO-A",
            "line_ids": [f"schema:订单:{row}" for row in range(2, 41)],
        },
        {
            "order_number": "PO-B",
            "line_ids": [f"schema:订单:{row}" for row in range(41, 52)],
        },
    ]


def test_multi_order_column_is_grouped_per_line_and_not_promoted() -> None:
    envelope = _envelope(
        [["订单编号", "产品"], ["PO-A", "X-1"], ["PO-B", "X-2"], ["PO-A", "X-3"]]
    )
    plan = TabularSchemaPlan(
        document_shape="multi_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2", "A3", "A4"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="order_number"),
                    ColumnMapping(column=2, field="product_code"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.order_number is None
    assert [line.custom_fields["order_number"] for line in result.lines] == [
        "PO-A",
        "PO-B",
        "PO-A",
    ]
    assert {issue.code for issue in result.validation_issues} == {
        "LINE_CORE_FIELD_MISSING",
        "MULTI_ORDER_DOCUMENT",
        "TABULAR_SCHEMA_INTERPRETATION_REVIEW",
    }
    assert result.extraction["order_groups"] == [
        {"order_number": "PO-A", "line_ids": ["schema:订单:2", "schema:订单:4"]},
        {"order_number": "PO-B", "line_ids": ["schema:订单:3"]},
    ]


@pytest.mark.parametrize("confidence", [0.89, 0.9])
def test_multi_order_model_plan_preserves_existing_baseline_header(
    confidence: float,
) -> None:
    envelope = _envelope([["订单编号", "产品"], ["PO-A", "SKU-1"], ["PO-B", "SKU-2"]])
    baseline = _baseline(
        header=DocumentHeader(order_number="PO-BASELINE"),
        field_meta={
            "$.header.order_number": FieldMetadata(confidence=confidence),
        },
    )
    plan = TabularSchemaPlan(
        document_shape="multi_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2", "A3"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="order_number"),
                    ColumnMapping(column=2, field="product_code"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, baseline, plan)

    assert result.header.order_number == "PO-BASELINE"
    assert [line.custom_fields["order_number"] for line in result.lines] == [
        "PO-A",
        "PO-B",
    ]
    assert result.field_meta["$.header.order_number"].confidence == confidence


def test_multi_order_preserves_high_confidence_line_order_number() -> None:
    envelope = _envelope(
        [["订单编号", "产品"], ["PO-SOURCE", "SKU-1"], ["PO-B", "SKU-2"]]
    )
    baseline = _baseline(
        lines=[
            OrderLine(
                line_id="订单:2",
                product_code="SKU-1",
                custom_fields={"order_number": "PO-TRUSTED"},
            )
        ],
        field_meta={
            "$.lines[0].custom_fields.order_number": FieldMetadata(confidence=1.0)
        },
    )
    plan = TabularSchemaPlan(
        document_shape="multi_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="constant_column",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["A2", "A3"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="order_number"),
                    ColumnMapping(column=2, field="product_code"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, baseline, plan)

    assert result.lines[0].custom_fields["order_number"] == "PO-TRUSTED"
    metadata = result.field_meta["$.lines[0].custom_fields.order_number"]
    assert metadata.confidence == 1.0
    assert "TABULAR_SCHEMA_LINE_CONFLICT" in {
        issue.code for issue in result.validation_issues
    }


@pytest.mark.parametrize(
    "footer_marker",
    ["合计", "总计", "TOTAL", "备注", "签字", "审核", "条款"],
)
def test_table_stops_before_footer_markers(footer_marker: str) -> None:
    envelope = _envelope(
        [
            ["产品", "数量"],
            ["SKU-1", 2],
            [footer_marker, 999],
            ["SHOULD-NOT-BE-A-LINE", 7],
        ]
    )
    plan = TabularSchemaPlan(
        document_shape="single_order",
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [(line.product_code, line.quantity) for line in result.lines] == [
        ("SKU-1", 2)
    ]


def test_footer_prefix_inside_a_product_value_is_not_a_boundary() -> None:
    envelope = _envelope([["Product", "Quantity"], ["TOTAL HDMI Cable", 2]])
    plan = TabularSchemaPlan(
        document_shape="single_order",
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [(line.product_code, line.quantity) for line in result.lines] == [
        ("TOTAL HDMI Cable", 2)
    ]


def test_table_stops_at_blank_region_before_unrelated_content() -> None:
    envelope = _envelope(
        [
            ["产品", "数量"],
            ["SKU-1", 2],
            [None, None],
            [None, None],
            ["SHOULD-NOT-BE-A-LINE", 7],
        ]
    )
    plan = TabularSchemaPlan(
        document_shape="single_order",
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [(line.product_code, line.quantity) for line in result.lines] == [
        ("SKU-1", 2)
    ]


def test_recovered_order_lines_clear_stale_issues_and_recompute_review_state() -> None:
    envelope = _envelope(
        [
            ["订单号", "PO-RECOVERED"],
            [None, None],
            ["产品", "数量"],
            ["SKU-1", 2],
            ["SKU-2", 3],
        ]
    )
    baseline = _baseline(
        validation_issues=[
            ValidationIssue(code=code, message="stale deterministic issue")
            for code in (
                "ORDER_TABLE_NOT_FOUND",
                "ORDER_LINES_EMPTY",
                "ORDER_NUMBER_MISSING",
            )
        ],
    )
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[3],
                data_start_row=4,
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, baseline, plan)
    issue_codes = {issue.code for issue in result.validation_issues}

    assert result.header.order_number == "PO-RECOVERED"
    assert [line.quantity for line in result.lines] == [2, 3]
    assert result.totals.calculated_quantity == 5
    assert result.totals.system_calculated["quantity"] == 5
    assert issue_codes.isdisjoint(
        {"ORDER_TABLE_NOT_FOUND", "ORDER_LINES_EMPTY", "ORDER_NUMBER_MISSING"}
    )
    assert "TABULAR_SCHEMA_INTERPRETATION_REVIEW" in issue_codes
    assert result.needs_review is True


def test_unknown_synonym_column_mapping_can_create_lines() -> None:
    envelope = _envelope([["内部叫法", "盒内数"], ["CABLE-9", "1,200"]])
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[
                    ColumnMapping(column=1, field="model"),
                    ColumnMapping(column=2, field="piece_count"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert len(result.lines) == 1
    assert result.lines[0].model == "CABLE-9"
    assert result.lines[0].piece_count == 1200
    assert result.field_meta["$.lines[0].model"].source_refs[0].cell == "A2"


def test_existing_line_fact_without_matching_evidence_is_not_relabelled() -> None:
    envelope = _envelope([["内部叫法"], ["MODEL-FROM-PLAN"]])
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[ColumnMapping(column=1, field="model")],
            )
        ],
    )
    baseline = _baseline(lines=[OrderLine(line_id="legacy:1", model="MODEL-TRUSTED")])

    result = apply_plan(envelope, baseline, plan)

    assert result.lines[0].model == "MODEL-TRUSTED"
    assert "$.lines[0].model" not in result.field_meta


def test_summary_is_bounded_marks_cells_untrusted_and_fingerprint_ignores_values() -> (
    None
):
    first = _envelope(
        [["订单", "型号", "数量"], ["PO-SECRET-A", "MODEL-A", 10]],
        filename="customer-a-PO-SECRET-A.xlsx",
    )
    second = _envelope(
        [["订单", "型号", "数量"], ["PO-SECRET-B", "MODEL-B", 99]],
        filename="customer-b-PO-SECRET-B.xlsx",
    )

    summary = build_tabular_summary(first, max_rows=2, max_chars=700)
    payload = json.loads(summary)

    assert len(summary) <= 700
    assert "untrusted" in summary.casefold()
    assert payload["schema_version"] == "v1"
    assert template_fingerprint(first, model="local-model", subtype_hint="order") == (
        template_fingerprint(second, model="local-model", subtype_hint="order")
    )


def test_template_fingerprint_distinguishes_top_level_field_labels() -> None:
    order = _envelope([["Order Number", "PO-1"]])
    contract = _envelope([["Contract Number", "CT-9"]])

    assert template_fingerprint(order, model="local-model") != template_fingerprint(
        contract,
        model="local-model",
    )


def test_template_fingerprint_distinguishes_shifted_table_headers() -> None:
    first = _envelope([["Product", "Quantity"], ["SKU-1", 2]])
    shifted = _envelope([[None, None]] * 4 + [["Product", "Quantity"], ["SKU-1", 2]])

    assert template_fingerprint(first, model="local-model") != template_fingerprint(
        shifted,
        model="local-model",
    )


def test_summary_fairly_samples_later_sheets() -> None:
    cover = _envelope(
        [[f"Cover note {index}", f"Value {index}"] for index in range(40)],
        sheet_name="Cover",
    )
    order = _envelope(
        [["Order Number", "PO-1"], ["Product", "Quantity"], ["SKU-1", 2]],
        sheet_name="Orders",
    )
    cover.sheets.append(order.sheets[0])

    payload = json.loads(build_tabular_summary(cover, max_rows=4, max_chars=12_000))

    samples = {sheet["sheet"]: sheet["sampled_rows"] for sheet in payload["sheets"]}
    assert samples["Cover"]
    assert samples["Orders"]
    assert any(
        cell["untrusted_value"] == "Order Number"
        for row in samples["Orders"]
        for cell in row["cells"]
    )


def test_summary_uses_sparse_cells_for_remote_sheet_dimensions() -> None:
    envelope = _envelope([["Order Number"], ["PO-1"]])
    envelope.sheets[0].max_row = 1_048_576
    envelope.sheets[0].max_column = 16_384

    payload = json.loads(build_tabular_summary(envelope, max_rows=2, max_chars=4_000))

    assert payload["sheets"][0]["column_stats"][0]["nonempty"] == 2


def test_semantic_guard_rejects_known_wrong_header_mappings() -> None:
    order_date = _envelope([["下单日期", "2026-07-21"]])
    wrong_date_plan = TabularSchemaPlan(
        header_fields=[
            HeaderFieldMapping(
                field="delivery_date",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ]
    )
    buyer = _envelope([["甲方", "Buyer Company"]])
    wrong_role_plan = TabularSchemaPlan(
        header_fields=[
            HeaderFieldMapping(
                field="seller",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            ),
            HeaderFieldMapping(
                field="supplier",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            ),
        ]
    )

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(order_date, wrong_date_plan)
    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(buyer, wrong_role_plan)


def test_semantic_guard_allows_seller_and_supplier_from_party_b() -> None:
    envelope = _envelope([["乙方", "Supplier Company"]])
    plan = TabularSchemaPlan(
        header_fields=[
            HeaderFieldMapping(
                field="seller",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            ),
            HeaderFieldMapping(
                field="supplier",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            ),
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.header.seller == "Supplier Company"
    assert result.header.supplier == "Supplier Company"


def test_semantic_guard_rejects_sequence_column_as_delivery_date() -> None:
    envelope = _envelope([["序"], ["2026-07-21"]])
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_start_row=2,
                columns=[ColumnMapping(column=1, field="delivery_date")],
            )
        ]
    )

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(envelope, plan)


@pytest.mark.parametrize(
    "plan",
    [
        {
            "schema_version": "v1",
            "document_shape": "single_order",
            "header_fields": [
                {
                    "field": "order_number",
                    "strategy": "horizontal",
                    "sheet": "订单",
                    "label_cells": ["A1"],
                    "value_cells": ["Z99"],
                }
            ],
            "tables": [],
        },
        {
            "schema_version": "v1",
            "document_shape": "single_order",
            "header_fields": [
                {
                    "field": "order_number",
                    "strategy": "horizontal",
                    "sheet": "订单",
                    "label_cells": ["A1"],
                    "value_cells": [],
                }
            ],
            "tables": [],
        },
        {
            "schema_version": "v1",
            "document_shape": "ledger",
            "header_fields": [],
            "tables": [
                {
                    "sheet": "订单",
                    "header_rows": [1],
                    "data_start_row": 2,
                    "columns": [
                        {"column": 1, "field": "model"},
                        {"column": 2, "field": "model"},
                    ],
                }
            ],
        },
    ],
)
def test_validate_rejects_out_of_bounds_missing_evidence_and_conflicts(
    plan: dict,
) -> None:
    envelope = _envelope([["订单号", "型号"], ["PO-1", "M-1"]])

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(envelope, plan)  # type: ignore[arg-type]


def test_extra_value_is_forbidden_and_hint_and_high_confidence_are_protected() -> None:
    with pytest.raises(ValidationError):
        HeaderFieldMapping.model_validate(
            {
                "field": "order_number",
                "strategy": "horizontal",
                "sheet": "订单",
                "label_cells": ["A1"],
                "value_cells": ["B1"],
                "value": "MODEL-INVENTED",
            }
        )

    envelope = _envelope([["订单号", "PO-NEW"]])
    baseline = _baseline(
        document_subtype="explicit-old-value",
        header=DocumentHeader(order_number="PO-TRUSTED"),
        field_meta={
            "$.header.order_number": FieldMetadata(
                source_refs=[SourceReference(sheet="订单", cell="B1")], confidence=0.99
            )
        },
    )
    plan = TabularSchemaPlan(
        document_shape="single_order",
        header_fields=[
            HeaderFieldMapping(
                field="order_number",
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ],
    )

    result = apply_plan(
        envelope, baseline, plan, subtype_hint="supplier_purchase_order"
    )

    assert result.header.order_number == "PO-TRUSTED"
    assert result.document_subtype == "supplier_purchase_order"
    assert baseline.document_subtype == "explicit-old-value"
    assert baseline.header.order_number == "PO-TRUSTED"


def test_multiple_tables_on_one_sheet_are_independent_regions() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty", None, "Model", "Unit"],
            ["SKU-A", 2, None, "M-A", "pcs"],
            ["SKU-B", 3, None, "M-B", "sets"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="products",
                header_rows=[1],
                data_rows=[2, 3],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="models",
                header_rows=[1],
                data_rows=[2, 3],
                columns=[
                    ColumnMapping(column=4, field="model"),
                    ColumnMapping(column=5, field="unit"),
                ],
            ),
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [(line.product_code, line.quantity) for line in result.lines[:2]] == [
        ("SKU-A", 2),
        ("SKU-B", 3),
    ]
    assert [(line.model, line.unit) for line in result.lines[2:]] == [
        ("M-A", "pcs"),
        ("M-B", "sets"),
    ]
    assert set(result.lines[0].raw_columns) == {"Product", "Qty"}
    assert set(result.lines[2].raw_columns) == {"Model", "Unit"}
    assert len({line.line_id for line in result.lines}) == 4


def test_transposed_regions_keep_raw_columns_inside_their_row_spans() -> None:
    envelope = _envelope(
        [
            ["Header", None],
            ["Product", "SKU-A"],
            [None, None],
            ["Header", None],
            ["Model", "M-A"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="product",
                orientation="columns",
                header_columns=[1],
                data_columns=[2],
                row_fields=[RowMapping(row=2, field="product_code")],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="model",
                orientation="columns",
                header_columns=[1],
                data_columns=[2],
                row_fields=[RowMapping(row=5, field="model")],
            ),
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert len(result.lines) == 2
    assert result.lines[0].raw_columns == {"Product": "SKU-A"}
    assert result.lines[1].raw_columns == {"Model": "M-A"}


def test_region_partition_preserves_uniquely_nearest_unmapped_column() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty", "Color", None, "Model", "Unit"],
            ["SKU-A", 2, "red", None, "M-A", "pcs"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="left",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="right",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=5, field="model"),
                    ColumnMapping(column=6, field="unit"),
                ],
            ),
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.lines[0].raw_columns == {
        "Product": "SKU-A",
        "Qty": 2,
        "Color": "red",
    }
    assert result.lines[1].raw_columns == {"Model": "M-A", "Unit": "pcs"}


def test_interleaved_region_axes_do_not_cross_pollute_raw_columns() -> None:
    envelope = _envelope(
        [
            ["Product", "Model", "Qty", "Unit"],
            ["SKU-A", "M-A", 2, "pcs"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="order",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=3, field="quantity"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="technical",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=2, field="model"),
                    ColumnMapping(column=4, field="unit"),
                ],
            ),
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.lines[0].raw_columns == {"Product": "SKU-A", "Qty": 2}
    assert result.lines[1].raw_columns == {"Model": "M-A", "Unit": "pcs"}


def test_equidistant_unmapped_cell_between_regions_fails_closed() -> None:
    envelope = _envelope(
        [
            ["Product", "Unmapped", "Model"],
            ["SKU-A", "ambiguous", "M-A"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="left",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="right",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=3, field="model")],
            ),
        ]
    )

    with pytest.raises(TabularSchemaSafetyError, match="ambiguous between"):
        apply_plan(envelope, _baseline(), plan)


def test_mixed_orientation_regions_do_not_cross_pollute_raw_columns() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty", None, None, None],
            ["SKU-A", 2, None, "Model", "M-A"],
            [None, None, None, "Unit", "pcs"],
        ],
        sheet_name="Sheet1",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="order",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="technical",
                orientation="columns",
                header_columns=[4],
                data_columns=[5],
                row_fields=[
                    RowMapping(row=2, field="model"),
                    RowMapping(row=3, field="unit"),
                ],
            ),
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert len(result.lines) == 2
    assert result.lines[0].raw_columns == {"Product": "SKU-A", "Qty": 2}
    assert result.lines[1].raw_columns == {"Model": "M-A", "Unit": "pcs"}


def test_multiple_regions_reuse_matching_deterministic_line_without_double_count() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty", None, "Model", "Unit"],
            ["SKU-A", 2, None, "M-A", "pcs"],
        ],
        sheet_name="Sheet1",
    )
    baseline = _baseline(
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="Sheet1:2:1",
                product_code="SKU-A",
                quantity=2,
            )
        ],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[SourceReference(sheet="Sheet1", cell="A2")],
                confidence=0.99,
            ),
            "$.lines[0].quantity": FieldMetadata(
                source_refs=[SourceReference(sheet="Sheet1", cell="B2")],
                confidence=0.99,
            ),
        },
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="models",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=4, field="model"),
                    ColumnMapping(column=5, field="unit"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="products",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            ),
        ],
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 2
    assert result.lines[0].line_id == "Sheet1:2:1"
    assert result.lines[0].product_code == "SKU-A"
    assert result.lines[0].quantity == 2
    assert result.lines[1].model == "M-A"
    assert result.lines[1].unit == "pcs"
    assert result.totals.calculated_quantity == 2
    assert len(baseline.lines) == 1


def test_multiple_regions_do_not_reuse_same_identity_from_another_source_cell() -> None:
    envelope = _envelope(
        [
            ["Left product", "Left qty", None, "Right product", "Right model"],
            ["SKU-A", 2, None, "SKU-A", "RIGHT-MODEL"],
        ],
        sheet_name="Sheet1",
    )
    baseline = _baseline(
        document_subtype="supplier_purchase_order",
        lines=[
            OrderLine(
                line_id="Sheet1:2:1",
                product_code="SKU-A",
                quantity=2,
            )
        ],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[SourceReference(sheet="Sheet1", cell="A2")],
                confidence=0.99,
            ),
            "$.lines[0].quantity": FieldMetadata(
                source_refs=[SourceReference(sheet="Sheet1", cell="B2")],
                confidence=0.99,
            ),
        },
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="right",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=4, field="product_code"),
                    ColumnMapping(column=5, field="model"),
                ],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="left",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            ),
        ],
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 2
    assert result.lines[0].product_code == "SKU-A"
    assert result.lines[0].quantity == 2
    assert result.lines[0].model is None
    assert result.lines[1].product_code == "SKU-A"
    assert result.lines[1].model == "RIGHT-MODEL"


def test_row_region_reuses_identity_inherited_across_same_row_merge() -> None:
    envelope = _envelope(
        [["Source", "Product"], ["SKU-A", None]],
        sheet_name="Sheet1",
    )
    sheet = envelope.sheets[0]
    sheet.cells[(2, 1)].merged_range = "A2:B2"
    sheet.merged_ranges.append(MergedRange("A2:B2", 2, 1, 2, 2))
    baseline = _baseline(
        lines=[OrderLine(line_id="Sheet1:2:1", product_code="SKU-A")],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[
                    SourceReference(sheet="Sheet1", cell="A2", range="A2:B2")
                ],
                confidence=0.99,
            )
        },
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="merged-row",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=2, field="product_code")],
            )
        ]
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 1
    assert result.lines[0].product_code == "SKU-A"


def test_row_region_does_not_reuse_identity_inherited_from_another_row() -> None:
    envelope = _envelope(
        [["Product"], ["SKU-A"], [None]],
        sheet_name="Sheet1",
    )
    sheet = envelope.sheets[0]
    sheet.cells[(2, 1)].merged_range = "A2:A3"
    sheet.merged_ranges.append(MergedRange("A2:A3", 2, 1, 3, 1))
    baseline = _baseline(
        lines=[OrderLine(line_id="Sheet1:2:1", product_code="SKU-A")],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[
                    SourceReference(sheet="Sheet1", cell="A2", range="A2:A3")
                ],
                confidence=0.99,
            )
        },
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="merged-rows",
                header_rows=[1],
                data_rows=[3],
                columns=[ColumnMapping(column=1, field="product_code")],
            )
        ]
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 2
    assert [line.product_code for line in result.lines] == ["SKU-A", "SKU-A"]


def test_column_region_reuses_identity_inherited_across_same_column_merge() -> None:
    envelope = _envelope(
        [["Other"], ["Value", "SKU-A"], ["Product", None]],
        sheet_name="Sheet1",
    )
    sheet = envelope.sheets[0]
    sheet.cells[(2, 2)].merged_range = "B2:B3"
    sheet.merged_ranges.append(MergedRange("B2:B3", 2, 2, 3, 2))
    baseline = _baseline(
        lines=[OrderLine(line_id="Sheet1:column:2", product_code="SKU-A")],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[
                    SourceReference(sheet="Sheet1", cell="B2", range="B2:B3")
                ],
                confidence=0.99,
            )
        },
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="merged-column",
                orientation="columns",
                header_columns=[1],
                data_columns=[2],
                row_fields=[RowMapping(row=3, field="product_code")],
            )
        ]
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 1
    assert result.lines[0].product_code == "SKU-A"


def test_column_region_does_not_reuse_identity_inherited_from_another_column() -> None:
    envelope = _envelope(
        [[None, None, None], ["Product", "SKU-A", None]],
        sheet_name="Sheet1",
    )
    sheet = envelope.sheets[0]
    sheet.cells[(2, 2)].merged_range = "B2:C2"
    sheet.merged_ranges.append(MergedRange("B2:C2", 2, 2, 2, 3))
    baseline = _baseline(
        lines=[OrderLine(line_id="Sheet1:column:2", product_code="SKU-A")],
        field_meta={
            "$.lines[0].product_code": FieldMetadata(
                source_refs=[
                    SourceReference(sheet="Sheet1", cell="B2", range="B2:C2")
                ],
                confidence=0.99,
            )
        },
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Sheet1",
                region_id="merged-columns",
                orientation="columns",
                header_columns=[1],
                data_columns=[3],
                row_fields=[RowMapping(row=2, field="product_code")],
            )
        ]
    )

    result = apply_plan(envelope, baseline, plan)

    assert len(result.lines) == 2
    assert [line.product_code for line in result.lines] == ["SKU-A", "SKU-A"]


@pytest.mark.parametrize("orientation", ["rows", "columns"])
def test_explicit_region_id_cannot_collide_with_synthetic_region(
    orientation: str,
) -> None:
    if orientation == "rows":
        envelope = _envelope(
            [["Product", None, "Model"], ["SKU-A", None, "M-A"]],
            sheet_name="Sheet1",
        )
        tables = [
            TableMapping(
                sheet="Sheet1",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="table-1",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=3, field="model")],
            ),
        ]
    else:
        envelope = _envelope(
            [["Product", "SKU-A", "Model", "M-A"]],
            sheet_name="Sheet1",
        )
        tables = [
            TableMapping(
                sheet="Sheet1",
                orientation="columns",
                header_columns=[1],
                data_columns=[2],
                row_fields=[RowMapping(row=1, field="product_code")],
            ),
            TableMapping(
                sheet="Sheet1",
                region_id="table-1",
                orientation="columns",
                header_columns=[3],
                data_columns=[4],
                row_fields=[RowMapping(row=1, field="model")],
            ),
        ]

    with pytest.raises(TabularSchemaSafetyError, match="collides"):
        validate_plan(envelope, TabularSchemaPlan(tables=tables))


def test_transposed_records_and_dynamic_custom_target_are_coordinate_bound() -> None:
    envelope = _envelope(
        [
            ["Field", "Item A", "Item B"],
            ["Product", "SKU-A", "SKU-B"],
            ["Qty", 2, 3],
            ["Customer marker", "alpha", "beta"],
        ],
        sheet_name="Transpose",
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="Transpose",
                region_id="transposed-items",
                orientation="columns",
                header_columns=[1],
                data_columns=[2, 3],
                row_fields=[
                    RowMapping(row=2, field="product_code"),
                    RowMapping(row=3, field="quantity"),
                    RowMapping(
                        row=4,
                        field="customer_marker",
                        target_path="$.lines[*].custom_fields.customer_marker",
                    ),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [(line.product_code, line.quantity) for line in result.lines] == [
        ("SKU-A", 2),
        ("SKU-B", 3),
    ]
    assert [line.custom_fields["customer_marker"] for line in result.lines] == [
        "alpha",
        "beta",
    ]
    assert (
        result.field_meta["$.lines[1].custom_fields.customer_marker"]
        .source_refs[0]
        .cell
        == "C4"
    )


def test_discontinuous_repeated_blocks_use_explicit_ranges() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty"],
            ["SKU-A", 1],
            ["SKU-B", 2],
            ["Product", "Qty"],
            ["SKU-C", 3],
            ["SKU-D", 4],
        ],
        sheet_name="Blocks",
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        tables=[
            TableMapping(
                sheet="Blocks",
                header_rows=[1],
                data_ranges=[DataRange(start=2, end=3), DataRange(start=5, end=6)],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert [line.product_code for line in result.lines] == [
        "SKU-A",
        "SKU-B",
        "SKU-C",
        "SKU-D",
    ]
    assert [line.quantity for line in result.lines] == [1, 2, 3, 4]


def test_merged_multirow_header_and_unknown_document_content_are_preserved() -> None:
    envelope = _envelope(
        [
            ["Item", "Commercial", "Routing marker", "R-17"],
            [None, "Qty", None, None],
            ["SKU-M", 8, None, None],
        ],
        sheet_name="Merged",
    )
    envelope.sheets[0].merged_ranges.append(
        MergedRange(ref="A1:A2", min_row=1, min_col=1, max_row=2, max_col=1)
    )
    plan = TabularSchemaPlan(
        document_shape="ledger",
        header_fields=[
            HeaderFieldMapping(
                field="routing_marker",
                target_path="$.extraction.custom_fields.routing_marker",
                strategy="horizontal",
                sheet="Merged",
                label_cells=["C1"],
                value_cells=["D1"],
            )
        ],
        tables=[
            TableMapping(
                sheet="Merged",
                header_rows=[1, 2],
                data_rows=[3],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ],
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.lines[0].product_code == "SKU-M"
    assert result.lines[0].quantity == 8
    assert result.extraction["custom_fields"]["routing_marker"] == "R-17"
    summary = json.loads(
        build_tabular_summary(
            envelope,
            max_rows=4,
            max_chars=6_000,
            focus_windows=[
                InspectionWindow(
                    sheet="Merged",
                    start_row=2,
                    end_row=3,
                    start_column=1,
                    end_column=2,
                )
            ],
        )
    )
    assert summary["sheets"][0]["merged_ranges"][0]["range"] == "A1:A2"
    assert summary["sheets"][0]["focused"] is True


def test_summary_can_focus_a_remote_window_beyond_initial_rows() -> None:
    rows = [[f"note-{index}", index] for index in range(1, 101)]
    envelope = _envelope(rows, sheet_name="Long")

    payload = json.loads(
        build_tabular_summary(
            envelope,
            max_rows=5,
            max_chars=8_000,
            focus_windows=[
                InspectionWindow(
                    sheet="Long",
                    start_row=90,
                    end_row=92,
                    start_column=1,
                    end_column=2,
                )
            ],
        )
    )

    sampled = [row["row"] for row in payload["sheets"][0]["sampled_rows"]]
    assert sampled[:3] == [90, 91, 92]


def test_multiple_regions_never_reuse_unidentified_baseline_lines_by_position() -> None:
    envelope = _envelope(
        [["Left product", None, "Right product"], ["SKU-A", None, "SKU-B"]],
        sheet_name="Regions",
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="Regions",
                region_id="left",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            ),
            TableMapping(
                sheet="Regions",
                region_id="right",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=3, field="product_code")],
            ),
        ]
    )
    baseline = _baseline(
        lines=[OrderLine(line_id="legacy:1", product_code="SKU-B")],
        field_meta={"$.lines[0].product_code": FieldMetadata(confidence=0.99)},
    )

    result = apply_plan(envelope, baseline, plan)

    assert result.lines[0].product_code == "SKU-B"
    assert {line.product_code for line in result.lines[1:]} == {"SKU-A", "SKU-B"}
    assert len(result.lines) == 3


def test_known_label_cannot_map_to_an_incompatible_canonical_line_target() -> None:
    envelope = _envelope([["订单号"], ["PO-123"]])
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            )
        ]
    )

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(envelope, plan)


def test_known_role_word_inside_a_compound_product_label_is_not_a_contradiction() -> (
    None
):
    envelope = _envelope([["Customer Product Code"], ["SKU-123"]])
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            )
        ]
    )

    assert validate_plan(envelope, plan) == plan


def test_plan_runtime_preserves_every_source_column_in_raw_columns() -> None:
    envelope = _envelope(
        [
            ["Product", "Qty", "Color", "Customer marker"],
            ["SKU-A", 2, "red", "retain-me"],
        ]
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_rows=[2],
                columns=[
                    ColumnMapping(column=1, field="product_code"),
                    ColumnMapping(column=2, field="quantity"),
                ],
            )
        ]
    )

    result = apply_plan(envelope, _baseline(), plan)

    assert result.lines[0].raw_columns == {
        "Product": "SKU-A",
        "Qty": 2,
        "Color": "red",
        "Customer marker": "retain-me",
    }


@pytest.mark.parametrize(
    ("field", "target_path"),
    [
        ("date_inferred", "$.header.date_inferred"),
        ("calculated_amount", "$.totals.calculated_amount"),
    ],
)
def test_system_derived_document_targets_are_not_source_writable(
    field: str,
    target_path: str,
) -> None:
    envelope = _envelope([["Observed label", "100"]])
    plan = TabularSchemaPlan(
        header_fields=[
            HeaderFieldMapping(
                field=field,
                target_path=target_path,
                strategy="horizontal",
                sheet="订单",
                label_cells=["A1"],
                value_cells=["B1"],
            )
        ]
    )

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(envelope, plan)


def test_system_derived_line_targets_are_not_source_writable() -> None:
    envelope = _envelope([["Product name"], ["Observed name"]])
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="name_normalized")],
            )
        ]
    )

    with pytest.raises(TabularSchemaSafetyError):
        validate_plan(envelope, plan)


def test_finalization_removes_metadata_for_absent_facts() -> None:
    envelope = _envelope([["Product"], ["SKU-A"]])
    baseline = _baseline(
        field_meta={"$.totals.calculated_amount": FieldMetadata(confidence=0.82)}
    )
    plan = TabularSchemaPlan(
        tables=[
            TableMapping(
                sheet="订单",
                header_rows=[1],
                data_rows=[2],
                columns=[ColumnMapping(column=1, field="product_code")],
            )
        ]
    )

    result = apply_plan(envelope, baseline, plan)

    assert result.totals.calculated_amount is None
    assert "$.totals.calculated_amount" not in result.field_meta


def test_template_fingerprint_includes_remote_structural_labels() -> None:
    first_rows = [[None, None] for _ in range(30)]
    second_rows = [[None, None] for _ in range(30)]
    for rows in (first_rows, second_rows):
        rows[0] = ["Common", "Metric"]
        rows[1] = ["x", 1]
    first_rows[18:20] = [["Real product", "Real qty"], ["SKU-A", 2]]
    first_rows[28:30] = [["Archive", "Count"], ["old", 9]]
    second_rows[18:20] = [["Archive", "Count"], ["old", 9]]
    second_rows[28:30] = [["Real product", "Real qty"], ["SKU-B", 3]]

    first = _envelope(first_rows, sheet_name="Remote")
    second = _envelope(second_rows, sheet_name="Remote")

    assert template_fingerprint(first, model="model") != template_fingerprint(
        second, model="model"
    )
