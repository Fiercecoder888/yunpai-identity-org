from __future__ import annotations

import asyncio
import os
from pathlib import Path
from uuid import uuid4

import pytest
from m1.knowledge.db_models import (
    DocumentVersionRow,
    ProjectionOutboxRow,
    ReviewDecisionRow,
    ReviewTaskRow,
    TaskVersionBindingRow,
)
from m1.knowledge.persistence import (
    IdempotencyConflictError,
    KnowledgeStore,
    ReviewConflictError,
)
from m1.knowledge.runtime import KnowledgeRuntime
from m1.knowledge.schema import LifecycleStatus, TaskLifecycleStatus
from m1.knowledge.sinks import InMemoryGraphSink
from sqlalchemy import func, select, text


def _candidate_document(
    *,
    source_hash: str = "d" * 64,
    order_number: str = "TX-REVIEW-FENCE-1",
) -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "review-fence-order.xlsx",
            "display_filename": "review-fence-order.xlsx",
            "sha256": source_hash,
            "verified_external_identity": {
                "verified": True,
                "source_system": "test-review-source",
                "external_id": order_number,
            },
            "mime_type": (
                "application/vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            ),
            "size_bytes": 2048,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "Review fence order",
            "order_number": order_number,
            "buyer": "Review Buyer",
            "supplier": "Review Supplier",
        },
        "lines": [
            {
                "line_id": "line-1",
                "line_no": 1,
                "model": "RF-1",
                "product_code": "P-RF-1",
                "name_raw": "RF-1 cable",
                "name_normalized": "RF-1 cable",
                "quantity": 2,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 2},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            }
        },
        "validation_issues": [
            {
                "code": "REVIEW_FENCE_CHECK",
                "severity": "warning",
                "message": "review required for concurrency test",
                "paths": ["$.header.order_number"],
            }
        ],
        "needs_review": True,
    }


async def _runtime(tmp_path: Path) -> tuple[KnowledgeRuntime, KnowledgeStore]:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'task-fence-review.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(store, InMemoryGraphSink())
    await runtime.init()
    return runtime, store


@pytest.mark.asyncio
async def test_concurrent_final_review_allows_one_decision(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        candidate = await runtime.sync_document(
            tenant_id="default",
            task_id="concurrent-review-task",
            document=_candidate_document(),
        )
        review_task_id = str(candidate.document.review_task_id)
        results = await asyncio.gather(
            store.decide_review(
                tenant_id="default",
                review_task_id=review_task_id,
                decision="accept",
                reviewer_id="reviewer-a",
                idempotency_key="review-final-a",
            ),
            store.decide_review(
                tenant_id="default",
                review_task_id=review_task_id,
                decision="reject",
                reviewer_id="reviewer-b",
                idempotency_key="review-final-b",
            ),
            return_exceptions=True,
        )
        assert sum(not isinstance(result, Exception) for result in results) == 1
        assert sum(isinstance(result, ReviewConflictError) for result in results) == 1
        async with store.sessionmaker() as session:
            assert int(
                await session.scalar(
                    select(func.count())
                    .select_from(ReviewDecisionRow)
                    .where(ReviewDecisionRow.tenant_id == "default")
                )
                or 0
            ) == 1
            review_events = int(
                await session.scalar(
                    select(func.count())
                    .select_from(ProjectionOutboxRow)
                    .where(
                        ProjectionOutboxRow.tenant_id == "default",
                        ProjectionOutboxRow.event_type == "review.decided",
                    )
                )
                or 0
            )
            assert review_events == 1
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_review_idempotency_rejects_payload_reuse(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        candidate = await runtime.sync_document(
            tenant_id="default",
            task_id="review-idempotency-task",
            document=_candidate_document(),
        )
        kwargs = {
            "tenant_id": "default",
            "review_task_id": str(candidate.document.review_task_id),
            "decision": "accept",
            "reviewer_id": "same-reviewer",
            "reason": "evidence checked",
            "idempotency_key": "stable-review-key",
        }
        first = await store.decide_review(**kwargs)
        replay = await store.decide_review(**kwargs)
        assert replay.decision_id == first.decision_id
        with pytest.raises(IdempotencyConflictError):
            await store.decide_review(**{**kwargs, "reason": "different payload"})
        with pytest.raises(ValueError, match="atomic revision workflow"):
            await store.decide_review(
                **{
                    **kwargs,
                    "idempotency_key": "correction-key",
                    "corrections": {"$.header.order_number": "changed"},
                }
            )
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_review_idempotency_replays_after_task_tombstone(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        task_id = "review-replay-after-tombstone"
        candidate = await runtime.sync_document(
            tenant_id="default",
            task_id=task_id,
            document=_candidate_document(),
        )
        kwargs = {
            "tenant_id": "default",
            "review_task_id": str(candidate.document.review_task_id),
            "decision": "accept",
            "reviewer_id": "stable-reviewer",
            "reason": "evidence checked",
            "idempotency_key": "review-replay-after-tombstone-key",
        }
        first = await store.decide_review(**kwargs)
        await runtime.tombstone_task(tenant_id="default", task_id=task_id)

        replay = await store.decide_review(**kwargs)

        assert replay == first
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_review_idempotency_key_cannot_move_to_another_task(
    tmp_path: Path,
) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        first = await runtime.sync_document(
            tenant_id="default",
            task_id="review-key-task-a",
            document=_candidate_document(),
        )
        second = await runtime.sync_document(
            tenant_id="default",
            task_id="review-key-task-b",
            document=_candidate_document(
                source_hash="e" * 64,
                order_number="TX-REVIEW-FENCE-2",
            ),
        )
        key = "review-key-bound-to-one-task"
        await store.decide_review(
            tenant_id="default",
            review_task_id=str(first.document.review_task_id),
            decision="accept",
            reviewer_id="stable-reviewer",
            idempotency_key=key,
        )

        with pytest.raises(IdempotencyConflictError):
            await store.decide_review(
                tenant_id="default",
                review_task_id=str(second.document.review_task_id),
                decision="accept",
                reviewer_id="stable-reviewer",
                idempotency_key=key,
            )
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_tombstone_before_review_fails_closed(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        candidate = await runtime.sync_document(
            tenant_id="default",
            task_id="tombstone-before-review",
            document=_candidate_document(),
        )
        await runtime.tombstone_task(
            tenant_id="default",
            task_id="tombstone-before-review",
        )
        with pytest.raises(ReviewConflictError):
            await store.decide_review(
                tenant_id="default",
                review_task_id=str(candidate.document.review_task_id),
                decision="accept",
                reviewer_id="late-reviewer",
            )
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_review_lock_makes_tombstone_win_after_review_commits(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime, store = await _runtime(tmp_path)
    candidate = await runtime.sync_document(
        tenant_id="default",
        task_id="review-before-tombstone",
        document=_candidate_document(),
    )
    locked = asyncio.Event()
    release = asyncio.Event()
    original_lock = store._lock_review_source_lifecycles

    async def paused_lock(*args, **kwargs):
        result = await original_lock(*args, **kwargs)
        locked.set()
        await release.wait()
        return result

    monkeypatch.setattr(store, "_lock_review_source_lifecycles", paused_lock)
    reviewing = asyncio.create_task(
        store.decide_review(
            tenant_id="default",
            review_task_id=str(candidate.document.review_task_id),
            decision="accept",
            reviewer_id="first-reviewer",
        )
    )
    tombstoning: asyncio.Task | None = None
    try:
        await asyncio.wait_for(locked.wait(), timeout=5)
        tombstoning = asyncio.create_task(
            runtime.tombstone_task(
                tenant_id="default",
                task_id="review-before-tombstone",
            )
        )
        await asyncio.sleep(0.05)
        assert not tombstoning.done()
        release.set()
        await asyncio.wait_for(reviewing, timeout=5)
        await asyncio.wait_for(tombstoning, timeout=5)

        lifecycle = await store.get_task_lifecycle(
            "default", "review-before-tombstone"
        )
        assert lifecycle is not None
        assert lifecycle.status == TaskLifecycleStatus.TOMBSTONED
        version = await store.get_document_version(
            "default", candidate.document.version_id
        )
        assert version is not None
        assert version.lifecycle_status == LifecycleStatus.DEPRECATED
        assert await store.search_index("default", "TX-REVIEW-FENCE-1") == []
    finally:
        release.set()
        for task in (reviewing, tombstoning):
            if task is not None and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        await runtime.close()


@pytest.mark.asyncio
async def test_shared_version_remains_reviewable_for_live_task(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        first = await runtime.sync_document(
            tenant_id="default",
            task_id="shared-review-a",
            document=_candidate_document(),
        )
        second = await runtime.sync_document(
            tenant_id="default",
            task_id="shared-review-b",
            document=_candidate_document(),
        )
        assert second.document.version_id == first.document.version_id
        await runtime.tombstone_task(
            tenant_id="default",
            task_id="shared-review-a",
        )
        decision = await store.decide_review(
            tenant_id="default",
            review_task_id=str(first.document.review_task_id),
            decision="accept",
            reviewer_id="shared-reviewer",
        )
        assert str(decision.decision) == "accept"
        async with store.sessionmaker() as session:
            active = (
                await session.scalars(
                    select(TaskVersionBindingRow).where(
                        TaskVersionBindingRow.tenant_id == "default",
                        TaskVersionBindingRow.version_id == first.document.version_id,
                        TaskVersionBindingRow.status == "active",
                    )
                )
            ).all()
            assert [binding.task_id for binding in active] == ["shared-review-b"]

        await runtime.tombstone_task(
            tenant_id="default",
            task_id="shared-review-b",
        )
        async with store.sessionmaker() as session:
            version = await session.get(
                DocumentVersionRow, first.document.version_id
            )
            assert version is not None
            assert version.lifecycle_status == LifecycleStatus.DEPRECATED.value
    finally:
        await runtime.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_two_reviewers_commit_one_final_decision() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    tenant_id = f"review-pg-{uuid4().hex}"
    runtime = KnowledgeRuntime(store_a, InMemoryGraphSink())
    await runtime.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Review PostgreSQL tenant",
    )
    await store_b.init()
    try:
        candidate = await runtime.sync_document(
            tenant_id=tenant_id,
            task_id=f"review-task-{uuid4().hex}",
            document=_candidate_document(),
        )
        review_task_id = str(candidate.document.review_task_id)
        results = await asyncio.gather(
            store_a.decide_review(
                tenant_id=tenant_id,
                review_task_id=review_task_id,
                decision="accept",
                reviewer_id="postgres-reviewer-a",
                idempotency_key=f"pg-review-a-{uuid4().hex}",
            ),
            store_b.decide_review(
                tenant_id=tenant_id,
                review_task_id=review_task_id,
                decision="reject",
                reviewer_id="postgres-reviewer-b",
                idempotency_key=f"pg-review-b-{uuid4().hex}",
            ),
            return_exceptions=True,
        )
        assert sum(not isinstance(result, Exception) for result in results) == 1
        assert sum(isinstance(result, ReviewConflictError) for result in results) == 1
    finally:
        await runtime.close()
        await store_b.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_concurrent_tasks_cannot_share_review_idempotency_key() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    tenant_id = f"review-key-pg-{uuid4().hex}"
    runtime = KnowledgeRuntime(store_a, InMemoryGraphSink())
    await runtime.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Review key PostgreSQL tenant",
    )
    await store_b.init()
    try:
        first = await runtime.sync_document(
            tenant_id=tenant_id,
            task_id=f"review-key-task-a-{uuid4().hex}",
            document=_candidate_document(),
        )
        second = await runtime.sync_document(
            tenant_id=tenant_id,
            task_id=f"review-key-task-b-{uuid4().hex}",
            document=_candidate_document(
                source_hash="e" * 64,
                order_number=f"TX-REVIEW-{uuid4().hex}",
            ),
        )
        key = f"shared-review-key-{uuid4().hex}"
        results = await asyncio.gather(
            store_a.decide_review(
                tenant_id=tenant_id,
                review_task_id=str(first.document.review_task_id),
                decision="accept",
                reviewer_id="postgres-reviewer",
                idempotency_key=key,
            ),
            store_b.decide_review(
                tenant_id=tenant_id,
                review_task_id=str(second.document.review_task_id),
                decision="accept",
                reviewer_id="postgres-reviewer",
                idempotency_key=key,
            ),
            return_exceptions=True,
        )

        assert sum(not isinstance(result, Exception) for result in results) == 1
        assert sum(
            isinstance(result, IdempotencyConflictError) for result in results
        ) == 1
    finally:
        await runtime.close()
        await store_b.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_review_share_lock_precedes_tombstone() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    tenant_id = f"review-tombstone-pg-{uuid4().hex}"
    runtime_a = KnowledgeRuntime(store_a, InMemoryGraphSink())
    runtime_b = KnowledgeRuntime(store_b, InMemoryGraphSink())
    await runtime_a.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Review/tombstone PostgreSQL tenant",
    )
    await runtime_b.init(default_tenant_id=tenant_id)
    locked = asyncio.Event()
    release = asyncio.Event()
    reviewing: asyncio.Task | None = None
    tombstoning: asyncio.Task | None = None
    try:
        task_id = f"review-tombstone-task-{uuid4().hex}"
        candidate = await runtime_a.sync_document(
            tenant_id=tenant_id,
            task_id=task_id,
            document=_candidate_document(),
        )
        original_lock = store_a._lock_review_source_lifecycles

        async def paused_lock(*args, **kwargs):
            result = await original_lock(*args, **kwargs)
            locked.set()
            await release.wait()
            return result

        store_a._lock_review_source_lifecycles = paused_lock
        reviewing = asyncio.create_task(
            store_a.decide_review(
                tenant_id=tenant_id,
                review_task_id=str(candidate.document.review_task_id),
                decision="accept",
                reviewer_id="postgres-first-reviewer",
            )
        )
        await asyncio.wait_for(locked.wait(), timeout=5)
        tombstoning = asyncio.create_task(
            runtime_b.tombstone_task(tenant_id=tenant_id, task_id=task_id)
        )
        await asyncio.sleep(0.1)
        assert not tombstoning.done()
        release.set()
        await asyncio.wait_for(reviewing, timeout=5)
        await asyncio.wait_for(tombstoning, timeout=5)

        version = await store_a.get_document_version(
            tenant_id, candidate.document.version_id
        )
        assert version is not None
        assert version.lifecycle_status == LifecycleStatus.DEPRECATED
    finally:
        release.set()
        for task in (reviewing, tombstoning):
            if task is not None and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        await runtime_a.close()
        await runtime_b.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_shared_version_concurrent_tombstones_converge() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    runtime_a = KnowledgeRuntime(store_a, InMemoryGraphSink())
    runtime_b = KnowledgeRuntime(store_b, InMemoryGraphSink())
    tenant_id = f"shared-tombstone-pg-{uuid4().hex}"
    await runtime_a.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Shared tombstone PostgreSQL tenant",
    )
    await runtime_b.init(default_tenant_id=tenant_id)
    try:
        task_a = f"shared-tombstone-a-{uuid4().hex}"
        task_b = f"shared-tombstone-b-{uuid4().hex}"
        first = await runtime_a.sync_document(
            tenant_id=tenant_id,
            task_id=task_a,
            document=_candidate_document(),
        )
        second = await runtime_a.sync_document(
            tenant_id=tenant_id,
            task_id=task_b,
            document=_candidate_document(),
        )
        assert second.document.version_id == first.document.version_id

        outcomes = await asyncio.wait_for(
            asyncio.gather(
                runtime_a.tombstone_task(tenant_id=tenant_id, task_id=task_a),
                runtime_b.tombstone_task(tenant_id=tenant_id, task_id=task_b),
            ),
            timeout=15,
        )

        assert {outcome.status for outcome in outcomes} == {"tombstoned"}
        assert sum(outcome.version_count for outcome in outcomes) == 1
        for task_id in (task_a, task_b):
            lifecycle = await store_a.get_task_lifecycle(tenant_id, task_id)
            assert lifecycle is not None
            assert lifecycle.status == TaskLifecycleStatus.TOMBSTONED
        async with store_a.sessionmaker() as session:
            await session.execute(
                text("SELECT set_config('m1.tenant_id', :tenant_id, true)"),
                {"tenant_id": tenant_id},
            )
            version = await session.get(
                DocumentVersionRow, first.document.version_id
            )
            assert version is not None
            assert version.lifecycle_status == LifecycleStatus.DEPRECATED.value
            bindings = (
                await session.scalars(
                    select(TaskVersionBindingRow)
                    .where(
                        TaskVersionBindingRow.tenant_id == tenant_id,
                        TaskVersionBindingRow.version_id
                        == first.document.version_id,
                    )
                    .order_by(TaskVersionBindingRow.task_id)
                )
            ).all()
            assert [binding.task_id for binding in bindings] == sorted(
                [task_a, task_b]
            )
            assert {binding.status for binding in bindings} == {"tombstoned"}
    finally:
        await runtime_a.close()
        await runtime_b.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_same_document_versions_concurrent_approve_converges() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    runtime_a = KnowledgeRuntime(store_a, InMemoryGraphSink())
    runtime_b = KnowledgeRuntime(store_b, InMemoryGraphSink())
    tenant_id = f"version-approve-pg-{uuid4().hex}"
    await runtime_a.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Version approve PostgreSQL tenant",
    )
    await runtime_b.init(default_tenant_id=tenant_id)
    try:
        first = await runtime_a.sync_document(
            tenant_id=tenant_id,
            task_id=f"version-approve-a-{uuid4().hex}",
            document=_candidate_document(),
        )
        second = await runtime_a.sync_document(
            tenant_id=tenant_id,
            task_id=f"version-approve-b-{uuid4().hex}",
            document=_candidate_document(
                source_hash="e" * 64,
                order_number="TX-REVIEW-FENCE-1",
            ),
        )
        assert second.document.document_id == first.document.document_id
        assert second.document.version_id != first.document.version_id
        review_ids = {
            str(first.document.review_task_id),
            str(second.document.review_task_id),
        }

        results = await asyncio.wait_for(
            asyncio.gather(
                store_a.decide_review(
                    tenant_id=tenant_id,
                    review_task_id=str(first.document.review_task_id),
                    decision="accept",
                    reviewer_id="version-reviewer-a",
                ),
                store_b.decide_review(
                    tenant_id=tenant_id,
                    review_task_id=str(second.document.review_task_id),
                    decision="accept",
                    reviewer_id="version-reviewer-b",
                ),
                return_exceptions=True,
            ),
            timeout=15,
        )

        assert sum(not isinstance(result, Exception) for result in results) == 1
        assert sum(isinstance(result, ReviewConflictError) for result in results) == 1
        async with store_a.sessionmaker() as session:
            await session.execute(
                text("SELECT set_config('m1.tenant_id', :tenant_id, true)"),
                {"tenant_id": tenant_id},
            )
            versions = (
                await session.scalars(
                    select(DocumentVersionRow)
                    .where(
                        DocumentVersionRow.tenant_id == tenant_id,
                        DocumentVersionRow.document_id
                        == first.document.document_id,
                    )
                    .order_by(DocumentVersionRow.version_number)
                )
            ).all()
            assert len(versions) == 2
            assert [row.lifecycle_status for row in versions].count(
                LifecycleStatus.ACTIVE.value
            ) == 1
            assert [row.lifecycle_status for row in versions].count(
                LifecycleStatus.DEPRECATED.value
            ) == 1
            decisions = (
                await session.scalars(
                    select(ReviewDecisionRow).where(
                        ReviewDecisionRow.tenant_id == tenant_id,
                        ReviewDecisionRow.review_task_id.in_(review_ids),
                    )
                )
            ).all()
            assert len(decisions) == 1
            active_version = next(
                row
                for row in versions
                if row.lifecycle_status == LifecycleStatus.ACTIVE.value
            )
            assert decisions[0].target_id == active_version.version_id
            review_tasks = (
                await session.scalars(
                    select(ReviewTaskRow).where(
                        ReviewTaskRow.tenant_id == tenant_id,
                        ReviewTaskRow.review_task_id.in_(review_ids),
                    )
                )
            ).all()
            assert {row.status for row in review_tasks} == {
                "cancelled",
                "resolved",
            }
    finally:
        await runtime_a.close()
        await runtime_b.close()
