from __future__ import annotations

import asyncio
import os
from datetime import timedelta
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy import func, select

import m1.knowledge.outbox_repository as outbox_repository_module
from m1.knowledge.db_models import (
    AliasSourceBindingRow,
    CanonicalEntityRow,
    DocumentVersionRow,
    EntitySourceBindingRow,
    GraphProjectionSnapshotRow,
    IdentitySourceBindingRow,
    KnowledgeChunkRow,
    KnowledgeIndexRow,
    ProjectionOutboxRow,
    RelationshipClaimRow,
    TaskVersionBindingRow,
)
from m1.knowledge.persistence import KnowledgeStore
from m1.knowledge.runtime import KnowledgeRuntime
from m1.knowledge.schema import (
    ClaimStatus,
    LifecycleStatus,
    TaskFenceError,
    TaskLifecycleStatus,
    TaskTombstonedError,
)
from m1.knowledge.sinks import InMemoryGraphSink


class _BlockingEmbeddingProvider:
    model = "fence-embedding-1024"
    dimensions = 1024

    def __init__(self) -> None:
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def embed_texts(self, texts):  # noqa: ANN001
        self.started.set()
        await self.release.wait()
        return [[0.0] * self.dimensions for _text in texts]

    async def close(self) -> None:
        self.release.set()


class _UnusedLightRAG:
    workspace = "fence-crash-test"

    async def upsert_document(self, **_kwargs) -> None:  # noqa: ANN003
        return None

    async def delete_source(self, **_kwargs) -> None:  # noqa: ANN003
        return None

    async def health(self) -> dict[str, object]:
        return {"enabled": True, "ready": True, "workspace": self.workspace}

    async def close(self) -> None:
        return None


class _CrossProcessLightRAG(_UnusedLightRAG):
    workspace = "fence-cross-process-test"

    def __init__(self) -> None:
        self.current_version: str | None = None
        self.first_upsert_started = asyncio.Event()
        self.release_first_upsert = asyncio.Event()
        self.upsert_calls = 0
        self.delete_calls = 0

    async def upsert_document(self, **kwargs) -> None:  # noqa: ANN003
        self.upsert_calls += 1
        if self.upsert_calls == 1:
            self.first_upsert_started.set()
            await self.release_first_upsert.wait()
        self.current_version = str(kwargs["version"])

    async def delete_source(self, **_kwargs) -> None:  # noqa: ANN003
        self.delete_calls += 1
        self.current_version = None

    async def close(self) -> None:
        self.release_first_upsert.set()


class _CrashAfterExternalSuccessLightRAG(_UnusedLightRAG):
    workspace = "fence-crash-after-success-test"

    def __init__(self) -> None:
        self.current_version: str | None = None
        self.external_upsert_succeeded = asyncio.Event()
        self.hold_response = asyncio.Event()
        self.upsert_calls = 0
        self.delete_calls = 0

    async def upsert_document(self, **kwargs) -> None:  # noqa: ANN003
        self.upsert_calls += 1
        self.current_version = str(kwargs["version"])
        self.external_upsert_succeeded.set()
        # Cancellation here models a process dying after LightRAG committed
        # the external write but before M1 acknowledged its durable event.
        await self.hold_response.wait()

    async def delete_source(self, **_kwargs) -> None:  # noqa: ANN003
        self.delete_calls += 1
        self.current_version = None

    async def close(self) -> None:
        self.hold_response.set()


class _RetryingLightRAG(_UnusedLightRAG):
    workspace = "fence-pending-retry-test"

    def __init__(self) -> None:
        self.upsert_calls = 0
        self.delete_calls = 0

    async def upsert_document(self, **_kwargs) -> None:  # noqa: ANN003
        self.upsert_calls += 1
        raise RuntimeError("temporary LightRAG transport failure")

    async def delete_source(self, **_kwargs) -> None:  # noqa: ANN003
        self.delete_calls += 1


def _document() -> dict:
    return {
        "schema_version": "m1.document.v2",
        "source": {
            "original_filename": "fenced-stocking-order.xlsx",
            "display_filename": "fenced-stocking-order.xlsx",
            "sha256": "f" * 64,
            "mime_type": (
                "application/vnd.openxmlformats-officedocument."
                "spreadsheetml.sheet"
            ),
            "size_bytes": 4096,
        },
        "document_type": "order",
        "document_subtype": "stocking_order",
        "header": {
            "title": "Fenced stocking order",
            "order_number": "TX-FENCE-001",
            "buyer": "Fence Buyer",
            "supplier": "Fence Supplier",
        },
        "lines": [
            {
                "line_id": "line-1",
                "line_no": 1,
                "model": "DP-FENCE-1",
                "product_code": "P-DP-FENCE-1",
                "name_raw": "DP-FENCE-1 cable",
                "name_normalized": "DP-FENCE-1 DisplayPort cable",
                "full_product_name": "DP-FENCE-1 DisplayPort cable 1m",
                "product_category": "cable",
                "quantity": 12,
                "unit": "PCS",
            }
        ],
        "totals": {"calculated_quantity": 12},
        "field_meta": {
            "$.header.order_number": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B2"}],
            },
            "$.lines[0].model": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "B5"}],
            },
            "$.lines[0].quantity": {
                "confidence": 1.0,
                "source_refs": [{"sheet": "Order", "cell": "E5"}],
            },
        },
        "validation_issues": [],
        "needs_review": False,
    }


async def _runtime(tmp_path: Path) -> tuple[KnowledgeRuntime, KnowledgeStore]:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'task-fence-runtime.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(store, InMemoryGraphSink())
    await runtime.init()
    return runtime, store


@pytest.mark.asyncio
async def test_tombstone_before_first_sync_rejects_ordinary_replay(
    tmp_path: Path,
) -> None:
    runtime, store = await _runtime(tmp_path)
    try:
        outcome = await runtime.tombstone_task(
            tenant_id="default",
            task_id="never-ingested",
        )
        assert outcome.changed is False
        lifecycle = await store.get_task_lifecycle("default", "never-ingested")
        assert lifecycle is not None
        assert lifecycle.status == TaskLifecycleStatus.TOMBSTONED

        with pytest.raises(TaskTombstonedError):
            await runtime.sync_document(
                tenant_id="default",
                task_id="never-ingested",
                document=_document(),
            )
        with pytest.raises(ValueError, match="governed restoration workflow"):
            await runtime.sync_document(
                tenant_id="default",
                task_id="never-ingested",
                document=_document(),
                reactivate=True,
            )
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_retired_version_cannot_be_rebound_by_new_task(tmp_path: Path) -> None:
    runtime, store = await _runtime(tmp_path)
    first_task_id = "retired-version-owner"
    replay_task_id = "retired-version-replay"
    try:
        synced = await runtime.sync_document(
            tenant_id="default",
            task_id=first_task_id,
            document=_document(),
        )
        tombstone = await runtime.tombstone_task(
            tenant_id="default",
            task_id=first_task_id,
        )
        assert tombstone.changed is True

        with pytest.raises(TaskTombstonedError, match="retired"):
            await runtime.sync_document(
                tenant_id="default",
                task_id=replay_task_id,
                document=_document(),
            )

        async with store.sessionmaker() as session:
            version = await session.get(DocumentVersionRow, synced.document.version_id)
            assert version is not None
            assert version.lifecycle_status == LifecycleStatus.DEPRECATED.value

            replay_bindings = int(
                await session.scalar(
                    select(func.count())
                    .select_from(TaskVersionBindingRow)
                    .where(
                        TaskVersionBindingRow.tenant_id == "default",
                        TaskVersionBindingRow.task_id == replay_task_id,
                        TaskVersionBindingRow.status == "active",
                    )
                )
                or 0
            )
            assert replay_bindings == 0

            for row_type in (
                EntitySourceBindingRow,
                IdentitySourceBindingRow,
                AliasSourceBindingRow,
            ):
                active_sources = int(
                    await session.scalar(
                        select(func.count())
                        .select_from(row_type)
                        .where(
                            row_type.tenant_id == "default",
                            row_type.version_id == synced.document.version_id,
                            row_type.status == "active",
                        )
                    )
                    or 0
                )
                assert active_sources == 0
    finally:
        await runtime.close()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "retired_status",
    [LifecycleStatus.DEPRECATED, LifecycleStatus.REJECTED],
)
async def test_fenced_writes_reject_active_binding_to_retired_version(
    tmp_path: Path,
    retired_status: LifecycleStatus,
) -> None:
    runtime, store = await _runtime(tmp_path)
    task_id = f"retired-fenced-write-{retired_status.value}"
    try:
        synced = await runtime.sync_document(
            tenant_id="default",
            task_id=task_id,
            document=_document(),
        )
        fence = await store.begin_task_fence("default", task_id)
        async with store.sessionmaker.begin() as session:
            version = await session.get(DocumentVersionRow, synced.document.version_id)
            assert version is not None
            version.lifecycle_status = retired_status.value

        async def assert_binding(session):  # noqa: ANN001, ANN202
            return await store._assert_fenced_version_binding(
                session,
                fence,
                tenant_id="default",
                version_id=synced.document.version_id,
            )

        with pytest.raises(TaskTombstonedError, match="retired"):
            await store._write(assert_binding)
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_embedding_result_cannot_write_after_tombstone(tmp_path: Path) -> None:
    provider = _BlockingEmbeddingProvider()
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'embedding-fence.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
    )
    await runtime.init()
    syncing = asyncio.create_task(
        runtime.sync_document(
            tenant_id="default",
            task_id="embedding-fence-task",
            document=_document(),
        )
    )
    try:
        await asyncio.wait_for(provider.started.wait(), timeout=5)
        tombstone = await asyncio.wait_for(
            runtime.tombstone_task(
                tenant_id="default",
                task_id="embedding-fence-task",
            ),
            timeout=5,
        )
        assert tombstone.changed is True
        provider.release.set()
        result = (await asyncio.gather(syncing, return_exceptions=True))[0]
        assert isinstance(result, TaskFenceError)
        async with store.sessionmaker() as session:
            rows = (
                await session.scalars(
                    select(KnowledgeIndexRow).where(
                        KnowledgeIndexRow.tenant_id == "default"
                    )
                )
            ).all()
            assert rows
            assert all(row.status == "deprecated" for row in rows)
            assert all(row.embedding is None for row in rows)
    finally:
        provider.release.set()
        if not syncing.done():
            syncing.cancel()
            await asyncio.gather(syncing, return_exceptions=True)
        await runtime.close()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_replay_waits_for_retirement_and_fails_closed() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    tombstone_store = KnowledgeStore(database_url)
    replay_store = KnowledgeStore(database_url)
    tombstone_runtime = KnowledgeRuntime(tombstone_store, InMemoryGraphSink())
    replay_runtime = KnowledgeRuntime(replay_store, InMemoryGraphSink())
    suffix = uuid4().hex
    tenant_id = f"retired-replay-pg-{suffix}"
    first_task_id = f"retired-owner-{suffix}"
    replay_task_id = f"retired-replay-{suffix}"
    await tombstone_runtime.init(
        default_tenant_id=tenant_id,
        default_tenant_name="Retired replay PostgreSQL tenant",
    )
    await replay_runtime.init(default_tenant_id=tenant_id)
    locked = asyncio.Event()
    release = asyncio.Event()
    tombstoning: asyncio.Task | None = None
    replaying: asyncio.Task | None = None
    try:
        synced = await tombstone_runtime.sync_document(
            tenant_id=tenant_id,
            task_id=first_task_id,
            document=_document(),
        )
        original_lock = tombstone_store._lock_graph_generation_row

        async def paused_graph_lock(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
            result = await original_lock(*args, **kwargs)
            locked.set()
            await release.wait()
            return result

        tombstone_store._lock_graph_generation_row = paused_graph_lock
        tombstoning = asyncio.create_task(
            tombstone_runtime.tombstone_task(
                tenant_id=tenant_id,
                task_id=first_task_id,
            )
        )
        await asyncio.wait_for(locked.wait(), timeout=5)
        replaying = asyncio.create_task(
            replay_runtime.sync_document(
                tenant_id=tenant_id,
                task_id=replay_task_id,
                document=_document(),
            )
        )
        await asyncio.sleep(0.1)
        assert not replaying.done()

        release.set()
        tombstone = await asyncio.wait_for(tombstoning, timeout=5)
        assert tombstone.changed is True
        replay_result = (
            await asyncio.wait_for(
                asyncio.gather(replaying, return_exceptions=True),
                timeout=5,
            )
        )[0]
        assert isinstance(replay_result, TaskTombstonedError)

        version = await replay_store.get_document_version(
            tenant_id,
            synced.document.version_id,
        )
        assert version is not None
        assert version.lifecycle_status == LifecycleStatus.DEPRECATED
        inventory = await replay_store.inventory_stats(tenant_id)
        assert inventory["task_version_bindings"]["total"] == 1
        assert inventory["task_version_bindings"]["by_status"] == {
            "tombstoned": 1
        }
    finally:
        release.set()
        for task in (tombstoning, replaying):
            if task is not None and not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        await tombstone_runtime.close()
        await replay_runtime.close()


@pytest.mark.asyncio
async def test_projection_transaction_persists_external_intents_before_fast_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = _BlockingEmbeddingProvider()
    provider.release.set()
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'projection-intents.db').as_posix()}"
    )
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        embedding_provider=provider,
        lightrag_shadow=_UnusedLightRAG(),
    )
    await runtime.init()

    async def simulated_crash(**_kwargs):  # noqa: ANN003, ANN202
        raise RuntimeError("simulated process exit after projection commit")

    monkeypatch.setattr(runtime, "_enqueue_lightrag_projection", simulated_crash)
    try:
        with pytest.raises(RuntimeError, match="simulated process exit"):
            await runtime.sync_document(
                tenant_id="default",
                task_id="projection-intent-task",
                document=_document(),
            )
        async with store.sessionmaker() as session:
            events = (
                await session.scalars(
                    select(ProjectionOutboxRow).where(
                        ProjectionOutboxRow.tenant_id == "default",
                        ProjectionOutboxRow.projection_name.in_(
                            ["embedding", "lightrag_shadow"]
                        ),
                    )
                )
            ).all()
            assert {event.projection_name for event in events} == {
                "embedding",
                "lightrag_shadow",
            }
            assert all(event.status == "pending" for event in events)
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_lightrag_delete_intent_rolls_back_with_tombstone(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runtime, store = await _runtime(tmp_path)
    synced = await runtime.sync_document(
        tenant_id="default",
        task_id="tombstone-rollback-task",
        document=_document(),
    )
    original_enqueue = store._enqueue_in_session

    async def fail_shadow_delete(session, record):  # noqa: ANN001, ANN202
        if (
            record.projection_name == "lightrag_shadow"
            and record.event_type == "lightrag.shadow.delete"
        ):
            raise RuntimeError("inject tombstone rollback")
        return await original_enqueue(session, record)

    monkeypatch.setattr(store, "_enqueue_in_session", fail_shadow_delete)
    try:
        with pytest.raises(RuntimeError, match="inject tombstone rollback"):
            await store.tombstone_task(
                "default",
                "tombstone-rollback-task",
                include_lightrag=True,
            )
        lifecycle = await store.get_task_lifecycle(
            "default", "tombstone-rollback-task"
        )
        assert lifecycle is not None
        assert lifecycle.status == TaskLifecycleStatus.ACTIVE
        assert await store.get_graph_projection(
            "default",
            synced.document.document_id,
            str(synced.document.version_number),
            include_candidate=True,
            actor_roles={"admin"},
        ) is not None
    finally:
        await runtime.close()


@pytest.mark.asyncio
async def test_cross_process_lightrag_upsert_converges_after_tombstone(
    tmp_path: Path,
) -> None:
    database_url = (
        f"sqlite+aiosqlite:///{(tmp_path / 'lightrag-cross-process.db').as_posix()}"
    )
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    shadow = _CrossProcessLightRAG()
    runtime_a = KnowledgeRuntime(
        store_a,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    runtime_b = KnowledgeRuntime(
        store_b,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    await runtime_a.init()
    await runtime_b.init()
    syncing = asyncio.create_task(
        runtime_a.sync_document(
            tenant_id="default",
            task_id="lightrag-cross-process-task",
            document=_document(),
        )
    )
    try:
        await asyncio.wait_for(shadow.first_upsert_started.wait(), timeout=5)
        tombstone = await runtime_b.tombstone_task(
            tenant_id="default",
            task_id="lightrag-cross-process-task",
        )
        assert tombstone.shadow_queued == 1
        drained = await runtime_b.drain_outbox(tenant_id="default", limit=1_000)
        assert drained.terminal_failures == 0
        shadow.release_first_upsert.set()
        result = (await asyncio.gather(syncing, return_exceptions=True))[0]
        assert isinstance(result, TaskFenceError)
        final_drain = await runtime_b.drain_outbox(
            tenant_id="default",
            limit=1_000,
        )
        assert final_drain.terminal_failures == 0
        assert shadow.current_version is None
        assert shadow.upsert_calls == 1
        assert shadow.delete_calls >= 2
    finally:
        shadow.release_first_upsert.set()
        if not syncing.done():
            syncing.cancel()
            await asyncio.gather(syncing, return_exceptions=True)
        await runtime_a.close()
        await runtime_b.close()


@pytest.mark.asyncio
async def test_lightrag_delete_recovers_after_upsert_process_dies_post_success(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    database_url = (
        f"sqlite+aiosqlite:///{(tmp_path / 'lightrag-crash-recovery.db').as_posix()}"
    )
    store_a = KnowledgeStore(database_url)
    store_b = KnowledgeStore(database_url)
    shadow = _CrashAfterExternalSuccessLightRAG()
    runtime_a = KnowledgeRuntime(
        store_a,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    runtime_b = KnowledgeRuntime(
        store_b,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    # Keep lease time comfortably ahead of event creation while retaining a
    # deterministic, instant 120-second expiry jump later in the test.
    clock = [outbox_repository_module.utc_now() + timedelta(hours=1)]
    monkeypatch.setattr(outbox_repository_module, "utc_now", lambda: clock[0])
    await runtime_a.init()
    await runtime_b.init()
    syncing = asyncio.create_task(
        runtime_a.sync_document(
            tenant_id="default",
            task_id="lightrag-post-success-crash-task",
            document=_document(),
        )
    )
    try:
        await asyncio.wait_for(shadow.external_upsert_succeeded.wait(), timeout=5)
        assert shadow.current_version is not None
        syncing.cancel()
        cancelled = (await asyncio.gather(syncing, return_exceptions=True))[0]
        assert isinstance(cancelled, asyncio.CancelledError)

        tombstone = await runtime_b.tombstone_task(
            tenant_id="default",
            task_id="lightrag-post-success-crash-task",
        )
        assert tombstone.shadow_queued == 1

        # The delete cannot overtake the unacknowledged successful upsert.
        blocked = await runtime_b.drain_outbox(tenant_id="default", limit=1_000)
        assert blocked.terminal_failures == 0
        assert shadow.current_version is not None
        stats = await store_b.projection_stats("default")
        assert stats["outbox"]["lightrag_shadow:processing"] == 1
        assert stats["outbox"]["lightrag_shadow:pending"] == 1

        # After the bounded lease expires, the old event is reclaimed first.
        # Reconciliation observes the tombstone and deletes instead of
        # replaying the stale upsert; the queued delete then runs idempotently.
        clock[0] += timedelta(seconds=121)
        recovered = await runtime_b.drain_outbox(
            tenant_id="default",
            limit=1_000,
        )
        assert recovered.terminal_failures == 0
        assert recovered.delivered >= 2
        assert shadow.current_version is None
        assert shadow.delete_calls >= 2
        final_stats = await store_b.projection_stats("default")
        assert final_stats["outbox"].get("lightrag_shadow:processing", 0) == 0
        assert final_stats["outbox"].get("lightrag_shadow:pending", 0) == 0
        assert final_stats["outbox"]["lightrag_shadow:delivered"] == 2
    finally:
        shadow.hold_response.set()
        if not syncing.done():
            syncing.cancel()
            await asyncio.gather(syncing, return_exceptions=True)
        await runtime_a.close()
        await runtime_b.close()


@pytest.mark.asyncio
async def test_tombstone_expedites_backed_off_lightrag_event(tmp_path: Path) -> None:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'lightrag-pending-tombstone.db').as_posix()}"
    )
    shadow = _RetryingLightRAG()
    runtime = KnowledgeRuntime(
        store,
        InMemoryGraphSink(),
        lightrag_shadow=shadow,
    )
    await runtime.init()
    try:
        synced = await runtime.sync_document(
            tenant_id="default",
            task_id="lightrag-pending-tombstone-task",
            document=_document(),
        )
        assert synced.shadow_synced is False
        before = await store.projection_stats("default")
        assert before["outbox"]["lightrag_shadow:pending"] == 1

        tombstone = await runtime.tombstone_task(
            tenant_id="default",
            task_id="lightrag-pending-tombstone-task",
        )
        assert tombstone.shadow_queued == 1
        drained = await runtime.drain_outbox(tenant_id="default", limit=1_000)

        assert drained.terminal_failures == 0
        assert drained.delivered >= 2
        assert shadow.upsert_calls == 1
        assert shadow.delete_calls >= 2
        after = await store.projection_stats("default")
        assert after["outbox"].get("lightrag_shadow:pending", 0) == 0
        assert after["outbox"].get("lightrag_shadow:processing", 0) == 0
        assert after["outbox"]["lightrag_shadow:delivered"] == 2
    finally:
        await runtime.close()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "barrier_method",
    [
        "ingest_document",
        "put_entity_with_source",
        "add_external_identity_with_source",
        "add_entity_alias_with_source",
        "claim_relationship",
        "replace_document_projections",
    ],
)
async def test_tombstone_fences_every_committed_sync_stage(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    barrier_method: str,
) -> None:
    runtime, store = await _runtime(tmp_path)
    task_id = f"barrier-{barrier_method}"
    entered = asyncio.Event()
    release = asyncio.Event()
    original = getattr(store, barrier_method)

    async def paused(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        result = await original(*args, **kwargs)
        entered.set()
        await release.wait()
        return result

    monkeypatch.setattr(store, barrier_method, paused)
    sync = asyncio.create_task(
        runtime.sync_document(
            tenant_id="default",
            task_id=task_id,
            document=_document(),
        )
    )
    try:
        await asyncio.wait_for(entered.wait(), timeout=5)
        tombstone = await asyncio.wait_for(
            runtime.tombstone_task(tenant_id="default", task_id=task_id),
            timeout=5,
        )
        assert tombstone.changed is True
        release.set()
        result = (await asyncio.gather(sync, return_exceptions=True))[0]
        assert isinstance(result, TaskFenceError)

        lifecycle = await store.get_task_lifecycle("default", task_id)
        assert lifecycle is not None
        assert lifecycle.status == TaskLifecycleStatus.TOMBSTONED
        async with store.sessionmaker() as session:
            active_bindings = 0
            for row_type in (
                TaskVersionBindingRow,
                EntitySourceBindingRow,
                IdentitySourceBindingRow,
                AliasSourceBindingRow,
            ):
                active_bindings += int(
                    await session.scalar(
                        select(func.count())
                        .select_from(row_type)
                        .where(
                            row_type.tenant_id == "default",
                            row_type.status == "active",
                        )
                    )
                    or 0
                )
            assert active_bindings == 0

            active_relationships = int(
                await session.scalar(
                    select(func.count())
                    .select_from(RelationshipClaimRow)
                    .where(
                        RelationshipClaimRow.tenant_id == "default",
                        RelationshipClaimRow.status.in_(
                            [
                                ClaimStatus.CANDIDATE.value,
                                ClaimStatus.UNDER_REVIEW.value,
                                ClaimStatus.ACCEPTED.value,
                            ]
                        ),
                    )
                )
                or 0
            )
            assert active_relationships == 0

            for row_type in (
                KnowledgeChunkRow,
                KnowledgeIndexRow,
                GraphProjectionSnapshotRow,
            ):
                visible = int(
                    await session.scalar(
                        select(func.count())
                        .select_from(row_type)
                        .where(
                            row_type.tenant_id == "default",
                            row_type.status.in_(["active", "candidate"]),
                        )
                    )
                    or 0
                )
                assert visible == 0

            live_orphans = int(
                await session.scalar(
                    select(func.count())
                    .select_from(CanonicalEntityRow)
                    .where(
                        CanonicalEntityRow.tenant_id == "default",
                        CanonicalEntityRow.lifecycle_status.in_(
                            [
                                LifecycleStatus.ACTIVE.value,
                                LifecycleStatus.APPROVED.value,
                                LifecycleStatus.UNDER_REVIEW.value,
                            ]
                        ),
                    )
                )
                or 0
            )
            assert live_orphans == 0
    finally:
        release.set()
        if not sync.done():
            sync.cancel()
            await asyncio.gather(sync, return_exceptions=True)
        await runtime.close()
