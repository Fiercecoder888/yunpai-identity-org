from __future__ import annotations

import asyncio
import os
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy import select
from sqlalchemy.dialects import postgresql, sqlite

from m1.knowledge.db_models import TaskLifecycleRow
from m1.knowledge.persistence import KnowledgeStore
from m1.knowledge.schema import (
    StaleTaskFenceError,
    TaskFenceToken,
    TaskLifecycleStatus,
    TaskTombstonedError,
    TenantRecord,
)


async def _sqlite_store(tmp_path: Path) -> tuple[KnowledgeStore, str]:
    store = KnowledgeStore(
        f"sqlite+aiosqlite:///{(tmp_path / 'task-fence.db').as_posix()}"
    )
    await store.init()
    tenant_id = "fence-tenant"
    await store.create_tenant(
        TenantRecord(
            tenant_id=tenant_id,
            tenant_key=tenant_id,
            display_name="Fence tenant",
        )
    )
    return store, tenant_id


@pytest.mark.asyncio
async def test_task_fence_epoch_invalidates_older_sync(tmp_path: Path) -> None:
    store, tenant_id = await _sqlite_store(tmp_path)
    try:
        first = await store.begin_task_fence(tenant_id, "task-1")
        assert first.epoch == 1
        assert first.reactivated is False
        assert (
            await store.validate_task_fence(tenant_id, "task-1", first)
        ).status == TaskLifecycleStatus.ACTIVE

        second = await store.begin_task_fence(tenant_id, "task-1")
        assert second.epoch == 2
        with pytest.raises(StaleTaskFenceError, match="epoch is stale"):
            await store.validate_task_fence(tenant_id, "task-1", first)
        assert (
            await store.validate_task_fence(tenant_id, "task-1", second)
        ).epoch == 2
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_tombstone_before_ingest_is_durable_and_requires_reactivation(
    tmp_path: Path,
) -> None:
    store, tenant_id = await _sqlite_store(tmp_path)
    try:
        tombstone = await store.tombstone_task_fence(tenant_id, "never-ingested")
        assert tombstone.status == TaskLifecycleStatus.TOMBSTONED
        assert tombstone.epoch == 1
        repeated = await store.tombstone_task_fence(tenant_id, "never-ingested")
        assert repeated.epoch == tombstone.epoch
        assert repeated.tombstoned_at == tombstone.tombstoned_at

        with pytest.raises(TaskTombstonedError):
            await store.begin_task_fence(tenant_id, "never-ingested")

        active = await store.reactivate_task_fence(tenant_id, "never-ingested")
        assert active.epoch == 2
        assert active.reactivated is True
        lifecycle = await store.get_task_lifecycle(tenant_id, "never-ingested")
        assert lifecycle is not None
        assert lifecycle.status == TaskLifecycleStatus.ACTIVE
        assert lifecycle.tombstoned_at is None
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_tombstone_invalidates_existing_token_and_tenants_are_independent(
    tmp_path: Path,
) -> None:
    store, tenant_a = await _sqlite_store(tmp_path)
    tenant_b = "fence-tenant-b"
    await store.create_tenant(
        TenantRecord(
            tenant_id=tenant_b,
            tenant_key=tenant_b,
            display_name="Fence tenant B",
        )
    )
    try:
        token_a = await store.begin_task_fence(tenant_a, "shared-task-id")
        token_b = await store.begin_task_fence(tenant_b, "shared-task-id")
        await store.tombstone_task_fence(tenant_a, "shared-task-id")

        with pytest.raises(TaskTombstonedError):
            await store.validate_task_fence(
                tenant_a, "shared-task-id", token_a
            )
        assert (
            await store.validate_task_fence(
                tenant_b, "shared-task-id", token_b
            )
        ).status == TaskLifecycleStatus.ACTIVE
        with pytest.raises(StaleTaskFenceError, match="identity"):
            await store.validate_task_fence(
                tenant_b,
                "shared-task-id",
                TaskFenceToken(
                    tenant_id=tenant_a,
                    task_id="shared-task-id",
                    epoch=token_b.epoch,
                ),
            )
    finally:
        await store.close()


def test_task_fence_lock_statements_are_postgres_share_and_update() -> None:
    shared = KnowledgeStore._task_lifecycle_lock_statement(
        "tenant", "task", shared=True
    )
    exclusive = KnowledgeStore._task_lifecycle_lock_statement(
        "tenant", "task", shared=False
    )
    shared_sql = str(
        shared.compile(dialect=postgresql.dialect())
    ).upper()
    exclusive_sql = str(
        exclusive.compile(dialect=postgresql.dialect())
    ).upper()

    assert shared_sql.endswith("FOR SHARE")
    assert exclusive_sql.endswith("FOR UPDATE")
    assert "FOR SHARE" not in str(shared.compile(dialect=sqlite.dialect())).upper()


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.getenv("M1_POSTGRES_TEST_URL"),
    reason="M1_POSTGRES_TEST_URL is not configured",
)
async def test_postgres_tombstone_waits_for_cross_engine_shared_writer() -> None:
    database_url = str(os.environ["M1_POSTGRES_TEST_URL"])
    writer_store = KnowledgeStore(database_url)
    tombstone_store = KnowledgeStore(database_url)
    await writer_store.init()
    await tombstone_store.init()
    suffix = uuid4().hex
    tenant_id = f"fence-pg-{suffix}"
    task_id = f"fence-task-{suffix}"
    await writer_store.create_tenant(
        TenantRecord(
            tenant_id=tenant_id,
            tenant_key=tenant_id,
            display_name="PostgreSQL fence tenant",
        )
    )
    token = await writer_store.begin_task_fence(tenant_id, task_id)
    entered = asyncio.Event()
    release = asyncio.Event()
    original_assert = writer_store._assert_task_fence

    async def paused_assert(*args, **kwargs):  # noqa: ANN002, ANN003, ANN202
        row = await original_assert(*args, **kwargs)
        entered.set()
        await release.wait()
        return row

    writer_store._assert_task_fence = paused_assert
    writer = asyncio.create_task(
        writer_store.validate_task_fence(tenant_id, task_id, token)
    )
    try:
        await asyncio.wait_for(entered.wait(), timeout=5)
        tombstone = asyncio.create_task(
            tombstone_store.tombstone_task_fence(tenant_id, task_id)
        )
        await asyncio.sleep(0.1)
        assert not tombstone.done()
        release.set()
        await asyncio.wait_for(writer, timeout=5)
        result = await asyncio.wait_for(tombstone, timeout=5)
        assert result.status == TaskLifecycleStatus.TOMBSTONED

        with pytest.raises(TaskTombstonedError):
            await writer_store.validate_task_fence(tenant_id, task_id, token)
        async with writer_store.sessionmaker() as session:
            assert (
                await session.scalars(
                    select(TaskLifecycleRow).where(
                        TaskLifecycleRow.tenant_id == tenant_id
                    )
                )
            ).all() == []
    finally:
        release.set()
        if not writer.done():
            writer.cancel()
            await asyncio.gather(writer, return_exceptions=True)
        await writer_store.close()
        await tombstone_store.close()
