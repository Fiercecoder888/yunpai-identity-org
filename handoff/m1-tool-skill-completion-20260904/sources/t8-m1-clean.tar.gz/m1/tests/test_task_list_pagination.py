from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
from m1.api.ingest_routes import register_ingest_routes
from m1.api.review_routes import register_review_routes
from m1.api.task_routes import register_task_routes
from m1.core.config import settings
from m1.state import TaskState, TaskStatus, TaskSummary
from m1.workflow.persistence import TaskRow, TaskStore, TaskSummaryRow
from sqlalchemy import delete

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _tenant_app() -> FastAPI:
    app = FastAPI()

    @app.middleware("http")
    async def add_tenant(request: Request, call_next):
        request.state.tenant_id = "tenant-a"
        return await call_next(request)

    return app


class _SummaryStore:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def list_task_summaries(self, **kwargs):
        self.calls.append(kwargs)
        return (
            [
                TaskSummary(
                    task_id="task-1",
                    tenant_id="tenant-a",
                    filename="order.xlsx",
                    status="done",
                )
            ],
            123,
        )


def test_task_route_applies_bounded_pagination_and_headers() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_task_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/tasks?status=done&limit=25&offset=50")

    assert response.status_code == 200
    assert response.json()[0]["task_id"] == "task-1"
    assert response.headers["x-total-count"] == "123"
    assert response.headers["x-page-limit"] == "25"
    assert response.headers["x-page-offset"] == "50"
    assert response.headers["x-has-more"] == "true"
    assert store.calls == [
        {
            "tenant_id": "tenant-a",
            "status": "done",
            "root_only": False,
            "limit": 25,
            "offset": 50,
        }
    ]


def test_task_route_keeps_unpaginated_legacy_calls_compatible() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_task_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/tasks")

    assert response.status_code == 200
    assert response.headers["x-total-count"] == "123"
    assert response.headers["x-has-more"] == "false"
    assert store.calls[0]["limit"] is None
    assert store.calls[0]["root_only"] is True


def test_task_route_rejects_offset_without_limit() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_task_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/tasks?offset=10")

    assert response.status_code == 422
    assert store.calls == []


def test_review_route_caps_the_queue_before_frontend_fanout() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_review_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/review/queue?limit=40&offset=80")

    assert response.status_code == 200
    assert response.headers["x-total-count"] == "123"
    assert store.calls == [
        {
            "tenant_id": "tenant-a",
            "status": "needs_review",
            "exclude_batch_parents": True,
            "limit": 40,
            "offset": 80,
        }
    ]


def test_review_route_keeps_unpaginated_legacy_calls_compatible() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_review_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/review/queue")

    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert response.headers["x-has-more"] == "false"
    assert store.calls[0]["limit"] is None
    assert store.calls[0]["exclude_batch_parents"] is True


def test_review_route_rejects_offset_without_limit() -> None:
    store = _SummaryStore()
    app = _tenant_app()
    register_review_routes(app, SimpleNamespace(store=store))

    with TestClient(app) as client:
        response = client.get("/review/queue?offset=10")

    assert response.status_code == 422
    assert store.calls == []


@pytest.mark.asyncio
async def test_sqlite_summary_query_is_bounded_and_skips_full_state_validation(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'tasks.db').as_posix()}")
    await store.init()
    try:
        states = [
            TaskState(
                task_id="root-done",
                tenant_id="tenant-a",
                original_filename="done.pdf",
                status=TaskStatus.DONE,
                processing_stage="done",
                parsed_content="x" * 500_000,
            ),
            TaskState(
                task_id="root-review",
                tenant_id="tenant-a",
                original_filename="review.pdf",
                status=TaskStatus.NEEDS_REVIEW,
                processing_stage="needs_review",
                parsed_content="y" * 500_000,
            ),
            TaskState(
                task_id="child-review",
                tenant_id="tenant-a",
                original_filename="child.png",
                parent_id="batch-review",
                status=TaskStatus.NEEDS_REVIEW,
                processing_stage="needs_review",
            ),
            TaskState(
                task_id="batch-review",
                tenant_id="tenant-a",
                original_filename="batch_upload",
                file_type="batch",
                child_ids=["child-review"],
                status=TaskStatus.NEEDS_REVIEW,
                processing_stage="needs_review",
            ),
        ]
        for state in states:
            await store.save(state)

        def fail_full_validation(*_args, **_kwargs):
            raise AssertionError("summary listing rebuilt a full TaskState")

        monkeypatch.setattr(TaskState, "model_validate_json", fail_full_validation)

        roots, root_total = await store.list_task_summaries(
            tenant_id="tenant-a", root_only=True, limit=2, offset=0
        )
        queue, queue_total = await store.list_task_summaries(
            tenant_id="tenant-a",
            status=TaskStatus.NEEDS_REVIEW.value,
            exclude_batch_parents=True,
            limit=50,
            offset=0,
        )

        assert root_total == 3
        assert len(roots) == 2
        assert all(not summary.parent_id for summary in roots)
        assert queue_total == 2
        assert {summary.task_id for summary in queue} == {
            "root-review",
            "child-review",
        }
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_init_backfills_existing_tasks_and_projection_tracks_updates(
    tmp_path,
) -> None:
    database_url = f"sqlite+aiosqlite:///{(tmp_path / 'backfill.db').as_posix()}"
    store = TaskStore(database_url)
    await store.init()
    await store.save(
        TaskState(
            task_id="legacy-task",
            tenant_id="tenant-a",
            original_filename="legacy.pdf",
            status=TaskStatus.NEEDS_REVIEW,
            processing_stage="needs_review",
        )
    )
    async with store.sessionmaker() as session:
        await session.execute(
            delete(TaskSummaryRow).where(TaskSummaryRow.task_id == "legacy-task")
        )
        await session.commit()
    await store.close()

    reopened = TaskStore(database_url)
    await reopened.init()
    try:
        summaries, total = await reopened.list_task_summaries(tenant_id="tenant-a")
        assert total == 1
        assert summaries[0].filename == "legacy.pdf"

        await reopened.update_knowledge_status(
            "legacy-task", status="synced", document_id="doc-1"
        )
        summaries, total = await reopened.list_task_summaries(tenant_id="tenant-a")
        assert total == 1
        assert summaries[0].knowledge_sync_status == "synced"

        assert await reopened.delete("legacy-task") is True
        assert (await reopened.list_task_summaries(tenant_id="tenant-a"))[1] == 0
    finally:
        await reopened.close()


@pytest.mark.asyncio
async def test_legacy_backfill_preserves_taskstate_defaults(tmp_path) -> None:
    database_url = f"sqlite+aiosqlite:///{(tmp_path / 'legacy-defaults.db').as_posix()}"
    seed = TaskStore(database_url)
    await seed.init()
    async with seed.sessionmaker() as session:
        session.add(
            TaskRow(
                task_id="minimal-legacy-task",
                tenant_id="tenant-a",
                status="",
                parent_id="",
                state_json=json.dumps(
                    {
                        "task_id": "minimal-legacy-task",
                        "tenant_id": "tenant-a",
                        "original_filename": "legacy.pdf",
                    }
                ),
            )
        )
        await session.commit()
    await seed.close()

    reopened = TaskStore(database_url)
    await reopened.init()
    try:
        summaries, total = await reopened.list_task_summaries(tenant_id="tenant-a")
        assert total == 1
        assert summaries[0].status == TaskStatus.CREATED.value
        assert summaries[0].processing_stage == "created"
    finally:
        await reopened.close()


@pytest.mark.asyncio
async def test_init_refreshes_projection_after_an_old_release_updates_task(
    tmp_path,
) -> None:
    database_url = f"sqlite+aiosqlite:///{(tmp_path / 'rollback.db').as_posix()}"
    store = TaskStore(database_url)
    await store.init()
    await store.save(
        TaskState(
            task_id="rollback-task",
            tenant_id="tenant-a",
            original_filename="before.pdf",
            status=TaskStatus.NEEDS_REVIEW,
            processing_stage="needs_review",
        )
    )

    async with store.sessionmaker() as session:
        row = await session.get(TaskRow, "rollback-task")
        assert row is not None
        payload = json.loads(row.state_json)
        payload["original_filename"] = "after.pdf"
        payload["status"] = TaskStatus.DONE.value
        payload["updated_at"] = (datetime.now(UTC) + timedelta(seconds=1)).isoformat()
        row.status = TaskStatus.DONE.value
        row.state_json = json.dumps(payload)
        row.updated_at = datetime.now(UTC) + timedelta(seconds=1)
        await session.commit()
    await store.close()

    reopened = TaskStore(database_url)
    await reopened.init()
    try:
        summaries, total = await reopened.list_task_summaries(tenant_id="tenant-a")
        assert total == 1
        assert summaries[0].filename == "after.pdf"
        assert summaries[0].status == TaskStatus.DONE.value
    finally:
        await reopened.close()


@pytest.mark.asyncio
async def test_concurrent_init_backfill_is_idempotent(tmp_path) -> None:
    database_url = f"sqlite+aiosqlite:///{(tmp_path / 'concurrent.db').as_posix()}"
    seed = TaskStore(database_url)
    await seed.init()
    await seed.save(
        TaskState(
            task_id="legacy-task",
            tenant_id="tenant-a",
            original_filename="legacy.pdf",
            status=TaskStatus.NEEDS_REVIEW,
        )
    )
    async with seed.sessionmaker() as session:
        await session.execute(
            delete(TaskSummaryRow).where(TaskSummaryRow.task_id == "legacy-task")
        )
        await session.commit()
    await seed.close()

    first = TaskStore(database_url)
    second = TaskStore(database_url)
    try:
        await asyncio.gather(first.init(), second.init())
        summaries, total = await first.list_task_summaries(tenant_id="tenant-a")
        assert total == 1
        assert summaries[0].task_id == "legacy-task"
    finally:
        await asyncio.gather(first.close(), second.close())


@pytest.mark.asyncio
async def test_init_removes_projection_orphan_left_by_an_old_release(
    tmp_path,
) -> None:
    database_url = f"sqlite+aiosqlite:///{(tmp_path / 'orphan.db').as_posix()}"
    seed = TaskStore(database_url)
    await seed.init()
    await seed.save(
        TaskState(
            task_id="deleted-by-old-release",
            tenant_id="tenant-a",
            status=TaskStatus.DONE,
        )
    )
    async with seed.sessionmaker() as session:
        await session.execute(
            delete(TaskRow).where(TaskRow.task_id == "deleted-by-old-release")
        )
        await session.commit()
    await seed.close()

    reopened = TaskStore(database_url)
    await reopened.init()
    try:
        summaries, total = await reopened.list_task_summaries(tenant_id="tenant-a")
        assert summaries == []
        assert total == 0
    finally:
        await reopened.close()


@pytest.mark.asyncio
async def test_summary_pagination_preserves_legacy_oldest_first_order(
    tmp_path,
) -> None:
    store = TaskStore(f"sqlite+aiosqlite:///{(tmp_path / 'order.db').as_posix()}")
    await store.init()
    try:
        for task_id in ("oldest", "middle", "newest"):
            await store.save(
                TaskState(
                    task_id=task_id,
                    tenant_id="tenant-a",
                    status=TaskStatus.DONE,
                )
            )

        first_page, total = await store.list_task_summaries(
            tenant_id="tenant-a",
            limit=2,
        )
        second_page, _ = await store.list_task_summaries(
            tenant_id="tenant-a",
            limit=2,
            offset=2,
        )

        assert total == 3
        assert [item.task_id for item in first_page] == ["oldest", "middle"]
        assert [item.task_id for item in second_page] == ["newest"]
    finally:
        await store.close()


def test_batch_upload_returns_an_unambiguous_async_parent_contract(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    class FakeBatchOrchestrator:
        last_finalize_task = None

        def __init__(self, *_args, **_kwargs) -> None:
            pass

        async def ingest_paths(self, files, **_kwargs):
            assert len(files) == 1
            return TaskState(
                task_id="batch-parent",
                file_type="batch",
                status=TaskStatus.EXTRACTING,
                processing_stage="batch_queued",
            )

    monkeypatch.setattr("m1.ingest.batch.BatchOrchestrator", FakeBatchOrchestrator)
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path / "uploads"))
    runtime = SimpleNamespace(
        engine=object(),
        store=object(),
        _form_tenant=lambda request, tenant_id: request.state.tenant_id,
        _spawn=lambda *_args, **_kwargs: None,
        _processing_semaphore=None,
        _task_registry={},
        _register_background_task=lambda *_args, **_kwargs: None,
    )
    app = _tenant_app()
    register_ingest_routes(app, runtime)

    with TestClient(app) as client:
        response = client.post(
            "/ingest/batch",
            files=[("files", ("drawing.png", b"png-bytes", "image/png"))],
        )

    assert response.status_code == 202
    assert response.json() == {
        "task_id": "batch-parent",
        "parent_id": "batch-parent",
        "status": "extracting",
        "processing_stage": "batch_queued",
        "child_count": 0,
        "child_ids": [],
        "accepted_file_count": 1,
        "async": True,
        "poll_url": "/batch/batch-parent",
    }


def test_orchestrator_task_list_declarations_expose_optional_pagination() -> None:
    module_path = PROJECT_ROOT / "m1" / "src" / "m1" / ".well-known" / "tool.json"
    orchestrator_path = (
        PROJECT_ROOT
        / "yunpai-orchestrator"
        / "orchestrator"
        / "module_decls"
        / "m1.well-known"
        / "tool.json"
    )
    module_decl = json.loads(module_path.read_text(encoding="utf-8"))
    orchestrator_decl = json.loads(orchestrator_path.read_text(encoding="utf-8"))
    assert module_decl == orchestrator_decl

    tools = {tool["name"]: tool for tool in module_decl["tools"]}
    for name in ("list_m1_tasks", "list_m1_review_queue"):
        schema = tools[name]["input_schema"]
        properties = schema["properties"]
        assert properties["limit"]["maximum"] == 200
        assert properties["offset"]["minimum"] == 0
        assert schema["dependentRequired"] == {"offset": ["limit"]}
