"""Runtime contract tests for the M1 task-store one-shot migration."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest
import yaml
from m1.workflow.persistence import TaskStore, TaskStoreSchemaError
from m1.workflow.task_store_migrations import migrate_task_store
from sqlalchemy import text

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _database_url(path: Path) -> str:
    return f"sqlite+aiosqlite:///{path.as_posix()}"


@pytest.mark.asyncio
async def test_validate_only_startup_never_creates_schema(tmp_path: Path) -> None:
    database = tmp_path / "validate-only.db"
    store = TaskStore(_database_url(database))
    try:
        with pytest.raises(TaskStoreSchemaError, match="missing tables"):
            await store.init(migrate_schema=False)
    finally:
        await store.close()

    with sqlite3.connect(database) as connection:
        tables = connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        ).fetchall()
    assert tables == []


@pytest.mark.asyncio
async def test_one_shot_migration_is_idempotent_and_validates_indexes(
    tmp_path: Path,
) -> None:
    database = tmp_path / "fresh.db"
    database_url = _database_url(database)

    await migrate_task_store(database_url)
    await migrate_task_store(database_url)

    store = TaskStore(database_url)
    try:
        await store.init(migrate_schema=False)
        async with store.sessionmaker() as session:
            indexes = (
                (
                    await session.execute(
                        text(
                            "SELECT name FROM sqlite_master "
                            "WHERE type = 'index' AND tbl_name = 'task_summary_rows'"
                        )
                    )
                )
                .scalars()
                .all()
            )
        assert {
            "ix_task_summary_tenant_parent_updated",
            "ix_task_summary_tenant_status_updated",
        }.issubset(set(indexes))
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_one_shot_migrates_and_backfills_a_legacy_task_database(
    tmp_path: Path,
) -> None:
    database = tmp_path / "legacy.db"
    state = {
        "task_id": "legacy-task",
        "original_filename": "legacy.pdf",
        "status": "needs_review",
        "updated_at": "2026-08-08T10:00:00+00:00",
    }
    with sqlite3.connect(database) as connection:
        connection.execute(
            """
            CREATE TABLE tasks (
                task_id VARCHAR(64) PRIMARY KEY,
                status VARCHAR(32),
                state_json TEXT,
                created_at TIMESTAMP,
                updated_at TIMESTAMP
            )
            """
        )
        connection.execute(
            "INSERT INTO tasks VALUES (?, ?, ?, ?, ?)",
            (
                "legacy-task",
                "needs_review",
                json.dumps(state),
                "2026-08-08 10:00:00",
                "2026-08-08 10:00:00",
            ),
        )

    database_url = _database_url(database)
    await migrate_task_store(database_url)

    store = TaskStore(database_url)
    try:
        await store.init(migrate_schema=False)
        summaries, total = await store.list_task_summaries(tenant_id="default")
        assert total == 1
        assert summaries[0].task_id == "legacy-task"
        assert summaries[0].filename == "legacy.pdf"
        assert summaries[0].status == "needs_review"
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_validate_only_rejects_an_interrupted_missing_index(
    tmp_path: Path,
) -> None:
    database = tmp_path / "interrupted.db"
    database_url = _database_url(database)
    await migrate_task_store(database_url)

    with sqlite3.connect(database) as connection:
        connection.execute("DROP INDEX ix_task_summary_tenant_status_updated")

    store = TaskStore(database_url)
    try:
        with pytest.raises(TaskStoreSchemaError, match="missing indexes"):
            await store.init(migrate_schema=False)
    finally:
        await store.close()

    await migrate_task_store(database_url)
    recovered = TaskStore(database_url)
    try:
        await recovered.init(migrate_schema=False)
    finally:
        await recovered.close()


def test_compose_owns_task_store_migration_before_api_startup() -> None:
    runtime = yaml.safe_load(
        (PROJECT_ROOT / "m1/deploy/compose.runtime.yml").read_text(encoding="utf-8")
    )
    build = yaml.safe_load(
        (PROJECT_ROOT / "m1/deploy/compose.build.yml").read_text(encoding="utf-8")
    )
    dev = yaml.safe_load(
        (PROJECT_ROOT / "m1/deploy/compose.dev.yml").read_text(encoding="utf-8")
    )

    migration = runtime["services"]["m1-task-store-migrate"]
    migration_environment = {
        item.split("=", 1)[0]: item.split("=", 1)[1]
        for item in migration["environment"]
    }
    api = runtime["services"]["m1"]
    api_environment = {
        item.split("=", 1)[0]: item.split("=", 1)[1] for item in api["environment"]
    }

    assert migration["image"] == "${M1_IMAGE:?M1_IMAGE is required}"
    assert migration["command"][-2:] == ["-m", "m1.workflow.task_store_migrations"]
    assert migration["restart"] == "no"
    assert migration["labels"]["com.yunpai.role"] == "application"
    assert migration_environment["NVIDIA_VISIBLE_DEVICES"] == "void"
    assert migration_environment["DATABASE_URL"] == api_environment["DATABASE_URL"]
    assert api_environment["TASK_STORE_MIGRATE_ON_STARTUP"] == "false"
    assert api["depends_on"]["m1-task-store-migrate"] == {
        "condition": "service_completed_successfully",
        "required": True,
    }
    assert "m1-task-store-migrate" not in build["services"]
    assert (
        dev["services"]["m1-task-store-migrate"]["environment"]["DATABASE_URL"]
        == dev["services"]["m1"]["environment"]["DATABASE_URL"]
    )
