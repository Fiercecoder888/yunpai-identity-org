from __future__ import annotations

import copy
from pathlib import Path

import pytest
from m1.documents.adapters.docx import parse_docx_document
from m1.documents.models import DocumentRecord, DocumentSource
from m1.documents.technical_projection import (
    _dimension_matches,
    project_technical_document,
)


def test_dimension_matches_preserve_decimal_comma_tolerances() -> None:
    assert _dimension_matches("6,65±0,1\n27±0,3\n34±0,4") == [
        "6,65±0,1",
        "27±0,3",
        "34±0,4",
    ]


def test_dimension_matches_do_not_join_independent_tolerances_across_lines() -> None:
    matches = _dimension_matches("±0.2\n±0.05")

    assert "0.2 ±0.05" not in matches
    assert matches == ["±0.2", "±0.05"]


def test_projection_deduplicates_equivalent_dimension_text_layers() -> None:
    blocks = [
        {
            "block_id": f"p1:b{index}",
            "kind": "native_text",
            "text": text,
            "bbox": [0.1, index * 0.1, 0.2, index * 0.1 + 0.05],
            "confidence": 1.0,
            "source": "pdf-native",
        }
        for index, text in enumerate(
            [
                "12.27±0.2",
                "12,27±0,2",
                "6,65±0,1\n27±0,3\n34±0,4",
                "±0.2\n±0.05",
            ]
        )
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.pdf"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "coordinate_space": "normalized",
                        "blocks": blocks,
                        "tables": [],
                    }
                ]
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert [item["value"] for item in projected.key_dimensions] == [
        "12.27±0.2",
        "6,65±0,1",
        "27±0,3",
        "34±0,4",
    ]


def test_native_docx_image_dimension_preserves_parent_block_bbox() -> None:
    parent_id = f"asset:{'a' * 64}/p0/p1:b0"
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 2,
                        "coordinate_space": "normalized",
                        "blocks": [
                            {
                                "block_id": parent_id,
                                "kind": "image",
                                "text": "19.5±0.05",
                                "bbox": {
                                    "x0": 0.1,
                                    "y0": 0.2,
                                    "x1": 0.8,
                                    "y1": 0.9,
                                    "coordinate_space": "normalized",
                                },
                                "source": "mineru-content-list-v2",
                            }
                        ],
                        "tables": [],
                    }
                ]
            },
            "metadata": {
                "mineru_input": {
                    "source": {"file_type": "docx"},
                    "normalized": {"file_type": "docx", "conversion": "native"},
                }
            },
        },
    )

    projected = project_technical_document(record)

    assert [item["value"] for item in projected.key_dimensions] == ["19.5±0.05"]
    for suffix in ("name", "value"):
        reference = projected.field_meta[
            f"$.key_dimensions[0].{suffix}"
        ].source_refs[0]
        assert reference.page == 2
        assert reference.model_extra["bbox"] == [0.1, 0.2, 0.8, 0.9]
        assert reference.model_extra["coordinate_space"] == "normalized"


@pytest.mark.parametrize("subtype", ["service_policy", "product_photo"])
def test_open_domain_technical_subtypes_skip_drawing_projection(subtype: str) -> None:
    record = DocumentRecord(
        source=DocumentSource(
            original_filename="IMG_5289.PNG",
            sha256="a" * 64,
            mime_type="image/jpeg",
        ),
        document_type="technical_document",
        document_subtype=subtype,
        generic_facts=[
            {
                "name": "content_description",
                "value": "Two electronic devices",
                "source_refs": [{"page": 1, "part": "mineru/p1:b0"}],
            }
        ],
        extraction={
            "metadata": {"adapter": "mineru_llm_full_authority"},
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "blocks": [
                            {
                                "block_id": "p1:b0",
                                "kind": "image",
                                "text": "Two electronic devices",
                            }
                        ],
                    }
                ]
            },
        },
    )

    projected = project_technical_document(record)

    assert projected is record
    assert projected.lines == []
    assert projected.bom == []
    assert getattr(projected.header, "drawing_number", None) is None
    assert getattr(projected.header, "product_number", None) is None


def test_docx_projects_title_dimensions_process_and_cell_sources(
    tmp_path: Path,
) -> None:
    docx = pytest.importorskip("docx")
    source = tmp_path / "YA.F.02.146承认书.docx"
    document = docx.Document()
    document.add_paragraph("工艺流程")
    document.add_paragraph("素材\t\t切割      研磨      喷180砂   阳极氧化")
    document.add_paragraph("包装\t\t出货")
    document.add_paragraph("YA.F.02.146铝壳图纸")
    table = document.add_table(rows=2, cols=5)
    for column, value in enumerate(
        ("产品名称", "外径尺寸", "内径尺寸", "下料尺寸", "公差")
    ):
        table.cell(0, column).text = value
    for column, value in enumerate(
        ("HDMI铝壳", "20.2mm*10.7mm", "18.6mm*9.1mm", "22.5mm", "±0.05mm")
    ):
        table.cell(1, column).text = value
    document.save(source)

    record = parse_docx_document(source, assets_dir=tmp_path / "assets")

    assert record.header.title == "HDMI铝壳"
    assert record.header.drawing_number == "YA.F.02.146"
    assert [item["name"] for item in record.key_dimensions] == [
        "外径尺寸",
        "内径尺寸",
        "下料尺寸",
        "公差",
    ]
    assert [step["name"] for step in record.process_steps] == [
        "素材",
        "切割",
        "研磨",
        "喷180砂",
        "阳极氧化",
        "包装",
        "出货",
    ]
    assert len(record.lines) == 1
    number_ref = record.field_meta["$.header.drawing_number"].source_refs[0]
    dimension_ref = record.field_meta["$.key_dimensions[0].value"].source_refs[0]
    assert number_ref.part == "word/document.xml#paragraph:3"
    assert number_ref.model_extra["evidence_quote"] == "YA.F.02.146铝壳图纸"
    assert dimension_ref.part == "word/document.xml"
    assert dimension_ref.cell == "table:0/R2C2"
    assert dimension_ref.model_extra["evidence_quote"] == "20.2mm*10.7mm"
    assert all(item["source_refs"] for item in record.key_dimensions)
    assert all(step["source_refs"] for step in record.process_steps)


@pytest.mark.parametrize(
    "filename",
    [
        "fc9347dedd13b24f518df287914c74.jpg",
        "IMG_5289.PNG",
        "page-0001.png",
    ],
)
def test_machine_generated_filename_is_not_projected_as_product(filename: str) -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename=filename, mime_type="image/png"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={"raw_content": {"pages": []}, "metadata": {}},
    )

    projected = project_technical_document(record)

    assert projected.header.title is None
    assert getattr(projected.header, "product_numbers", []) == []
    assert projected.lines == []


def test_pdf_projects_product_fields_and_page_bboxes() -> None:
    rows = [
        [
            "产品编号",
            "494-05295 TX\n494-05296 RX",
            "产品名称",
            "HDMI2.0 光模组",
        ],
        ["规格参数", "接口类型", "HDMI Type A", None],
        ["规格参数", "支持协议", "HDMI 1.4 & HDMI 2.0 & HDMI 2.1", None],
        ["规格参数", "带宽", "48Gbps", None],
        ["规格参数", "分辨率", "8K@60Hz", None],
        ["规格参数", "工作电压", "5V", None],
        [None, "传输距离", "100米", None],
    ]
    boxes = [
        [
            [column * 100.0, row * 30.0, (column + 1) * 100.0, (row + 1) * 30.0]
            for column in range(4)
        ]
        for row in range(len(rows))
    ]
    record = DocumentRecord(
        source=DocumentSource(
            original_filename="HDMI2.0产品规格书.pdf",
            mime_type="application/pdf",
        ),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "coordinate_space": "pdf_points",
                        "text_blocks": [
                            {
                                "text_original": "结构尺寸 1.1131 cm",
                                "bbox": [50.0, 120.0, 200.0, 150.0],
                            }
                        ],
                        "tables": [
                            {
                                "table_index": 2,
                                "rows_normalized": rows,
                                "cell_bbox_matrix": boxes,
                            }
                        ],
                    }
                ]
            },
            "metadata": {
                "structured_evidence": {
                    "pages": [
                        {
                            "page_number": 1,
                            "coordinate_space": "pixels",
                            "raw": {
                                "overall_ocr_res": {
                                    "rec_texts": [
                                        "ZhanKian展联",
                                        "展联光电科技(深圳)有限公司",
                                        "产品编号",
                                        "产品名称",
                                    ],
                                    "rec_scores": [0.99, 0.99, 0.99, 0.99],
                                    "rec_polys": [
                                        [[0, 0], [100, 0], [100, 20], [0, 20]],
                                        [[200, 0], [400, 0], [400, 20], [200, 20]],
                                        [[0, 30], [100, 30], [100, 50], [0, 50]],
                                        [[200, 30], [400, 30], [400, 50], [200, 50]],
                                    ],
                                }
                            },
                        }
                    ]
                }
            },
        },
    )

    projected = project_technical_document(record)

    assert projected.header.title == "HDMI2.0 光模组"
    assert getattr(projected.header, "drawing_number", None) is None
    assert projected.header.product_numbers == ["494-05295 TX", "494-05296 RX"]
    assert projected.lines[0].product_code == "494-05295 TX"
    assert any(
        spec["name"] == "接口类型" and spec["value"] == "HDMI Type A"
        for spec in projected.specifications
    )
    assert {(spec["name"], spec["value"]) for spec in projected.specifications} >= {
        ("支持协议", "HDMI 1.4 & HDMI 2.0 & HDMI 2.1"),
        ("带宽", "48Gbps"),
        ("分辨率", "8K@60Hz"),
        ("工作电压", "5V"),
        ("传输距离", "100米"),
    }
    assert projected.key_dimensions[0]["value"] == "1.1131 cm"
    assert len(projected.lines) == 1
    title_ref = projected.field_meta["$.header.title"].source_refs[0]
    dimension_ref = projected.field_meta["$.key_dimensions[0].value"].source_refs[0]
    assert title_ref.page == dimension_ref.page == 1
    assert title_ref.model_extra["bbox"] == [300.0, 0.0, 400.0, 30.0]
    assert title_ref.model_extra["evidence_quote"] == "HDMI2.0 光模组"
    assert dimension_ref.model_extra["bbox"] == [50.0, 120.0, 200.0, 150.0]
    assert dimension_ref.model_extra["evidence_quote"] == "结构尺寸 1.1131 cm"


def test_mineru_unified_evidence_projects_product_specification() -> None:
    rows = [
        ["产品规格书", None, None, None],
        ["产品编号", "494-12732 TX 494-12733 RX", "产品名称", "HDMI2.1 光模组"],
        ["规格参数", "支持协议", "HDMI 1.4 & HDMI 2.0 & HDMI 2.1", None],
        ["规格参数", "带宽", "48Gbps", None],
        ["规格参数", "分辨率", "8K@60Hz", None],
        ["规格参数", "工作电压", "5V", None],
        ["规格参数", "传输距离", "100米", None],
    ]
    cells = [
        {
            "row": row,
            "column": column,
            "text": value,
            "bbox": {
                "x0": column * 0.2,
                "y0": row * 0.1,
                "x1": (column + 1) * 0.2,
                "y1": (row + 1) * 0.1,
                "coordinate_space": "normalized",
            },
            "confidence": 0.96,
        }
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
        if value is not None
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="HDMI2.1规格书第一页.png"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "width": 446,
                        "height": 631,
                        "coordinate_space": "normalized",
                        "blocks": [
                            {
                                "block_id": "p1:b0",
                                "kind": "table",
                                "text": "产品规格书",
                                "bbox": {
                                    "x0": 0.05,
                                    "y0": 0.04,
                                    "x1": 0.91,
                                    "y1": 0.87,
                                    "coordinate_space": "normalized",
                                },
                            }
                        ],
                        "tables": [{"table_id": "p1:t0", "rows": rows, "cells": cells}],
                    }
                ]
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.header.product_numbers == ["494-12732 TX", "494-12733 RX"]
    assert projected.header.title == "HDMI2.1 光模组"
    assert projected.lines[0].product_code == "494-12732 TX"
    assert {(item["name"], item["value"]) for item in projected.specifications} >= {
        ("支持协议", "HDMI 1.4 & HDMI 2.0 & HDMI 2.1"),
        ("带宽", "48Gbps"),
        ("分辨率", "8K@60Hz"),
        ("工作电压", "5V"),
        ("传输距离", "100米"),
    }
    assert not any(item["name"] == "规格参数" for item in projected.specifications)
    assert projected.field_meta["$.lines[0].product_code"].source_refs[0].part == (
        "mineru/p1:t0:r1:c1"
    )


def test_headerless_material_shape_replaces_column_oriented_title_rows() -> None:
    material_rows = [
        ["10", "50403-326", "50mm", "Double-sided conductive copper foil"],
        ["9", "30402-160", "2pcs", "Type C divider ABS+PC"],
        ["8", "82324-019", "1pcs", "Type C plug without E-Mark"],
        ["7", "82324-018", "1pcs", "Type C plug with E-Mark"],
        ["6", "50403-288", "0.002pcs", "UV adhesive 35ml"],
        ["5", "10726-014", "8g", "Black TPE compound"],
        ["4", "10707-003", "3g", "Transparent inner mold compound"],
        ["3", "30106-895△", "2pcs", "USB Type C bottom shell"],
        ["2", "30106-896△", "2pcs", "USB Type C top shell"],
        ["1", "10501-256", "160mm", "Black TPE cable OD=4.8mm"],
        ["1", "10501-256", "160mm", "APPROVED", "DATE", "DRAWING NO."],
        ["1", "10501-256", "160mm", "CHECKED", "DATE", "80826-041"],
        ["1", "10501-256", "160mm", "Type C-C 3.1 Gen2 Cable L=152mm"],
    ]
    cells = [
        {
            "row": row_index,
            "column": column,
            "text": value,
            "bbox": {
                "x0": float(column * 100),
                "y0": float(row_index * 20),
                "x1": float((column + 1) * 100),
                "y1": float((row_index + 1) * 20),
                "coordinate_space": "pdf_points",
            },
            "confidence": 0.97,
        }
        for row_index, row in enumerate(material_rows)
        for column, value in enumerate(row)
    ]
    stale_lines = [
        {
            "line_id": f"stale-{index}",
            "name_raw": value,
        }
        for index, value in enumerate(
            ("Customer material 54-57-00228", "Version C", "Customer CHYKH039")
        )
    ]
    stale_meta = {
        f"$.lines[{index}].name_raw": {
            "source_refs": [
                {
                    "page": 1,
                    "part": f"mineru/p1:t0:r{10 + index}:c{4 + index}",
                }
            ]
        }
        for index in range(3)
    }
    record = DocumentRecord(
        source=DocumentSource(original_filename="cable-drawing.pdf"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        lines=stale_lines,
        field_meta=stale_meta,
        validation_issues=[
            {
                "code": "STALE_COLUMN_RECORD",
                "severity": "warning",
                "message": "column-oriented title block was proposed as a line",
                "paths": ["$.lines[0].name_raw"],
            }
        ],
        extraction={
            "metadata": {"adapter": "mineru_instructor"},
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "coordinate_space": "pdf_points",
                        "tables": [
                            {
                                "table_id": "p1:t0",
                                "rows": material_rows,
                                "cells": cells,
                            }
                        ],
                    }
                ]
            },
        },
    )

    projected = project_technical_document(record)

    assert [line.line_no for line in projected.lines] == list(range(1, 11))
    expected_codes = [
        "10501-256",
        "30106-896",
        "30106-895",
        "10707-003",
        "10726-014",
        "50403-288",
        "82324-018",
        "82324-019",
        "30402-160",
        "50403-326",
    ]
    assert [line.product_code for line in projected.lines] == expected_codes
    assert str(projected.lines[0].quantity) == "160"
    assert projected.lines[0].unit == "mm"
    assert str(projected.lines[5].quantity) == "0.002"
    assert projected.lines[5].unit == "pcs"
    assert not any("Customer" in str(line.name_raw) for line in projected.lines)
    assert all(line.specification_raw is None for line in projected.lines)
    assert all("specifications" not in line.custom_fields for line in projected.lines)
    assert projected.header.title == "Type C-C 3.1 Gen2 Cable L=152mm"
    assert projected.field_meta["$.header.title"].source_refs[0].part == (
        "mineru/p1:t0:r12:c3"
    )
    assert projected.header.bom_line_count == len(expected_codes)
    assert projected.field_meta["$.header.bom_line_count"].source_refs
    code_meta = projected.field_meta["$.lines[0].product_code"]
    assert code_meta.inferred is True
    assert code_meta.model_extra["mapping_source"] == "headerless_material_shape"
    assert code_meta.source_refs[0].part == "mineru/p1:t0:r9:c1"
    assert code_meta.source_refs[0].model_extra["evidence_quote"] == "10501-256"
    projection = projected.extraction["metadata"]["technical_projection"]
    assert projection["headerless_material_table_ids"] == ["p1:t0"]
    assert projection["headerless_material_row_count"] == len(expected_codes)
    assert projection["replaced_model_line_count"] == len(stale_lines)
    assert projection["replaced_validation_issue_codes"] == [
        "STALE_COLUMN_RECORD"
    ]
    assert not any(issue.code == "STALE_COLUMN_RECORD" for issue in projected.validation_issues)


def test_reverse_label_title_block_does_not_become_product_table() -> None:
    revision_rows = [
        ["NO.", "DATE", "REVISION", "REVISER", "VERSION"],
        ["", "", "", "", ""],
    ]
    rows = [
        [
            "APPROVED",
            "J.G.QING",
            "PC",
            "8P8C六类四上四下",
            "m/m",
            "华思精密电子有限公司",
            "",
        ],
        [
            "APPROVED",
            "J.G.QING",
            "MATERIAL",
            "NAME",
            "UNIT",
            "华思精密电子有限公司",
            "华思精密电子有限公司",
        ],
        ["CHECKED", "", "ICP-0018-A0", "PJM38P801-0xxF-0", "", "Φ←", "±0.1"],
        [
            "DRAWN",
            "",
            "DWG NO.",
            "PART NO.",
            "WEIGHT",
            "THIRD ANGLE PROJECTION",
            "GENERAL TOLERANCE",
        ],
        ["DRAWN", "", "透明", "射出成型", "1:1", "S", "A/0"],
        [
            "DESIGNED",
            "Y.Cheng",
            "COLOR",
            "MANUFACTURE",
            "SCALE",
            "SURFACE ROUGHNESS",
            "VERSION",
        ],
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.pdf"),
        document_type="technical_document",
        document_subtype="product_specification",
        header={
            "title": "PJM38P801-0xxF-0",
            "drawing_number": "Pure",
            "drawn_by": "透明",
            "checked_by": "| | ICP-0018-A0 | PJM38P801-0xxF-0 | | Φ← | ±0.1",
        },
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "coordinate_space": "normalized",
                        "blocks": [
                            {
                                "block_id": "p1:image0",
                                "kind": "image",
                                "text": (
                                    "Pure technical line drawing of a mechanical "
                                    "component without any text or symbols"
                                ),
                                "bbox": [0.1, 0.1, 0.4, 0.4],
                            },
                            {
                                "block_id": "p1:image1",
                                "kind": "image",
                                "text": "0.35±0.02\n4.85±0.05",
                                "bbox": [0.1, 0.2, 0.4, 0.4],
                            },
                            {
                                "block_id": "p1:title0",
                                "kind": "title",
                                "text": "Electrical Test",
                                "bbox": [0.6, 0.2, 0.8, 0.25],
                            },
                            {
                                "block_id": "p1:list0",
                                "kind": "list",
                                "text": (
                                    "A. Dielectric withstanding 1000V DC/min\n"
                                    "B. Contact Resistance <20 MΩ"
                                ),
                                "bbox": [0.6, 0.25, 0.9, 0.35],
                            },
                            {
                                "block_id": "p1:title1",
                                "kind": "title",
                                "text": "Mechanical:",
                                "bbox": [0.6, 0.4, 0.8, 0.45],
                            },
                            {
                                "block_id": "p1:list1",
                                "kind": "list",
                                "text": "Durability: 2000 mating cycles",
                                "bbox": [0.6, 0.45, 0.9, 0.55],
                            },
                            {
                                "block_id": "p1:paragraph0",
                                "kind": "paragraph",
                                "text": "Operating Temperature: -40~+125°C",
                                "bbox": [0.6, 0.6, 0.9, 0.65],
                            },
                        ],
                        "tables": [
                            {
                                "table_id": "p1:revision",
                                "rows": revision_rows,
                                "cells": [
                                    {
                                        "row": row,
                                        "column": column,
                                        "text": value,
                                        "bbox": [
                                            column / 5,
                                            row / 2,
                                            (column + 1) / 5,
                                            (row + 1) / 2,
                                        ],
                                        "confidence": 0.98,
                                    }
                                    for row, values in enumerate(revision_rows)
                                    for column, value in enumerate(values)
                                ],
                            },
                            {
                                "table_id": "p1:title",
                                "rows": rows,
                                "cells": [
                                    {
                                        "row": row,
                                        "column": column,
                                        "text": value,
                                        "bbox": [
                                            column / 7,
                                            row / 6,
                                            (column + 1) / 7,
                                            (row + 1) / 6,
                                        ],
                                        "confidence": 0.98,
                                    }
                                    for row, values in enumerate(rows)
                                    for column, value in enumerate(values)
                                ],
                            },
                        ],
                    }
                ]
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.header.title == "8P8C六类四上四下"
    assert projected.header.drawing_number == "ICP-0018-A0"
    assert projected.header.material_number == "PJM38P801-0xxF-0"
    assert projected.header.unit == "m/m"
    assert projected.header.scale == "1:1"
    assert projected.header.version == "A/0"
    assert projected.header.drawn_by == "Y.Cheng"
    assert projected.header.checked_by is None
    assert projected.header.approved_by == "J.G.QING"
    assert {(item["name"], item["value"]) for item in projected.specifications} >= {
        (
            "Electrical Test",
            ("A. Dielectric withstanding 1000V DC/min\nB. Contact Resistance <20 MΩ"),
        ),
        ("Mechanical", "Durability: 2000 mating cycles"),
        ("Operating Temperature", "-40~+125°C"),
    }
    assert {item["value"] for item in projected.key_dimensions} >= {
        "0.35±0.02",
        "4.85±0.05",
    }
    assert len(projected.lines) == 1
    assert projected.lines[0].product_code == "PJM38P801-0xxF-0"
    assert projected.lines[0].name_raw == "8P8C六类四上四下"
    assert "REVISION=REVISER" not in (projected.lines[0].specification_raw or "")


def test_signal_name_and_section_label_are_not_people_or_version() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="specification.pdf"),
        document_type="technical_document",
        document_subtype="product_specification",
        header={
            "version": "光缆线材焊线规格",
            "approved_by": "HPD",
        },
        extraction={
            "raw_content": {"pages": [{"page_number": 1, "tables": []}]},
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.header.version is None
    assert projected.header.approved_by is None


def test_process_document_projects_title_date_and_numbered_steps() -> None:
    paragraphs = [
        "广西桐曦电子科技有限公司采购流程",
        "二、采购流程具体操作步骤",
        "1.提交系统采购申请",
        "由采购部门在采购管理系统中提交完整准确的采购申请。",
        "2.系统制作采购订单",
        "采购部门审核申请后制作采购订单并核对供应商信息。",
        "发布日期:2025年11月1日",
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="采购流程.docx"),
        document_type="technical_document",
        document_subtype="process_document",
        extraction={
            "raw_content": {
                "paragraphs": [
                    {"paragraph_index": index, "text_original": text}
                    for index, text in enumerate(paragraphs)
                ],
                "tables": [],
                "textboxes": [],
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.header.title == paragraphs[0]
    assert projected.header.date_standard.isoformat() == "2025-11-01"
    assert [(step["step_no"], step["name"]) for step in projected.process_steps] == [
        ("1", "提交系统采购申请"),
        ("2", "系统制作采购订单"),
    ]
    assert projected.process_steps[0]["description"].startswith("由采购部门")
    assert projected.field_meta["$.process_steps[0].description"].source_refs[
        0
    ].part == ("word/document.xml#paragraph:3")


def test_approval_drawing_flow_stops_before_later_title_and_dimension() -> None:
    paragraphs = [
        {"paragraph_index": 0, "text_original": "工艺流程"},
        {
            "paragraph_index": 1,
            "text_original": "素材\t\t切割  抛光  喷180砂  阳极氧化  前检  镭雕",
        },
        {"paragraph_index": 2, "text_original": "包装\t\t出货"},
        {"paragraph_index": 6, "text_original": "HDMI弧形铝壳图纸  长度27.6"},
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="3988-27.6长弧形太空灰.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        extraction={
            "raw_content": {
                "paragraphs": paragraphs,
                "tables": [],
                "textboxes": [],
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert [step["name"] for step in projected.process_steps] == [
        "素材",
        "切割",
        "抛光",
        "喷180砂",
        "阳极氧化",
        "前检",
        "镭雕",
        "包装",
        "出货",
    ]
    assert "HDMI弧形铝壳图纸" not in {step["name"] for step in projected.process_steps}
    assert "长度27.6" not in {step["name"] for step in projected.process_steps}


def test_numbered_dimensions_outside_process_context_are_not_process_steps() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        extraction={
            "raw_content": {
                "paragraphs": [
                    {"paragraph_index": 0, "text_original": "一、技术要求"},
                    {"paragraph_index": 1, "text_original": "1.长度 27.6mm"},
                    {"paragraph_index": 2, "text_original": "2.公差 ±0.05mm"},
                ],
                "tables": [],
                "textboxes": [],
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.process_steps == []


def _drawing_region_dimension_record(
    *,
    quote: str = "11.4 ±0.05",
    parent_matches: bool = True,
    audited: bool = True,
    include_bbox: bool = True,
) -> DocumentRecord:
    asset_sha256 = "a" * 64
    region_sha256 = "b" * 64
    parent_id = f"asset:{asset_sha256}/p0/p1:b0"
    fact_id = "semantic_fact:visual-dimension"
    source_ref: dict[str, object] = {
        "page": 3,
        "part": f"mineru/{parent_id}",
        "asset_id": f"asset:sha256:{asset_sha256}",
        "asset_sha256": asset_sha256,
        "asset_width_pixels": 417,
        "asset_height_pixels": 313,
        "parent_evidence_id": (
            parent_id if parent_matches else f"asset:{'c' * 64}/p0/p1:b0"
        ),
        "coordinate_space": "image_pixels",
        "region_bbox_pixels": [12, 44, 33, 123],
        "region_sha256": region_sha256,
        "authority": "advisory",
        "evidence_kind": "model_transcription",
        "model_transcription": True,
    }
    if include_bbox:
        source_ref["bbox"] = [12.0, 44.0, 33.0, 123.0]
    evidence_parent_id = str(source_ref["parent_evidence_id"])
    return DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 3,
                        "blocks": [
                            {
                                "block_id": parent_id,
                                "kind": "image",
                                "text": "11.4 ±0.05",
                                "source": "docx-native-ooxml",
                                "confidence": 0.99,
                            }
                        ],
                        "tables": [],
                    }
                ],
                "semantic_facts": [
                    {
                        "fact_id": fact_id,
                        "name": "drawing_linear_dimension",
                        "value": {
                            "nominal": "11.4",
                            "symmetric_deviation": "0.05",
                        },
                        "attributes": {
                            "dimension_type": "linear",
                            "localization": "region_bbox",
                            "evidence_kind": "model_transcription",
                            "model_transcription": True,
                        },
                        "evidence_refs": [
                            {
                                "evidence_id": (
                                    f"{evidence_parent_id}/region:{region_sha256}"
                                ),
                                "quote": quote,
                                "source_ref": source_ref,
                            }
                        ],
                        "extractor": "drawing_region_vlm.v1",
                        "confidence": 0.85,
                        "status": "advisory",
                    }
                ],
                "drawing_region_vlm": {
                    "schema_version": "m1.drawing-region-vlm-sidecar.v1",
                    "assets": [
                        {
                            "audit": [
                                {
                                    "disposition": "fact",
                                    "fact_ids": [fact_id] if audited else [],
                                }
                            ]
                        }
                    ],
                },
            },
            "metadata": {
                "mineru_input": {
                    "source": {"file_type": "docx"},
                    "normalized": {"file_type": "docx", "conversion": "native"},
                }
            },
        },
    )


def test_drawing_region_fact_adds_bbox_to_existing_dimension_metadata() -> None:
    projected = project_technical_document(_drawing_region_dimension_record())

    assert [item["value"] for item in projected.key_dimensions] == ["11.4 ±0.05"]
    for suffix in ("name", "value"):
        metadata = projected.field_meta[f"$.key_dimensions[0].{suffix}"]
        assert len(metadata.source_refs) == 2
        region_refs = [
            reference
            for reference in metadata.source_refs
            if (reference.model_extra or {}).get("coordinate_space")
            == "image_pixels"
        ]
        assert len(region_refs) == 1
        region_ref = region_refs[0]
        assert region_ref.model_extra["bbox"] == [12.0, 44.0, 33.0, 123.0]
        assert region_ref.model_extra["region_bbox_pixels"] == [12, 44, 33, 123]
        assert region_ref.model_extra["evidence_quote"] == "11.4 ±0.05"
        assert metadata.model_extra["visual_fact_ids"] == [
            "semantic_fact:visual-dimension"
        ]

    repeated = project_technical_document(projected)
    assert len(
        repeated.field_meta["$.key_dimensions[0].value"].source_refs
    ) == 2


@pytest.mark.parametrize(
    "record",
    [
        _drawing_region_dimension_record(parent_matches=False),
        _drawing_region_dimension_record(quote="10 ±0.05"),
        _drawing_region_dimension_record(audited=False),
        _drawing_region_dimension_record(include_bbox=False),
    ],
)
def test_unverified_or_unmatched_drawing_region_fact_is_not_linked(
    record: DocumentRecord,
) -> None:
    projected = project_technical_document(record)

    for suffix in ("name", "value"):
        metadata = projected.field_meta[f"$.key_dimensions[0].{suffix}"]
        assert len(metadata.source_refs) == 1
        assert not any(
            (reference.model_extra or {}).get("coordinate_space") == "image_pixels"
            for reference in metadata.source_refs
        )


def test_single_technical_line_links_internal_images_with_occurrence_evidence() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="single-item.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        lines=[
            {
                "line_id": "technical:docx:0:2",
                "name_raw": "HDMI铝壳",
            }
        ],
        extraction={
            "raw_content": {
                "paragraphs": [],
                "tables": [],
                "textboxes": [],
                "images": [
                    {
                        "asset_path": "assets/product-view.png",
                        "target_part": "word/media/image1.png",
                        "references": [{"xml_paragraph_index": 25}],
                    }
                ],
            },
            "title_block": {"approve_by": "Existing Approver", "version": "A"},
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.lines[0].image_refs == ["assets/product-view.png"]
    image_meta = projected.field_meta["$.lines[0].image_refs"]
    assert image_meta.inferred is True
    assert {ref.part for ref in image_meta.source_refs} == {
        "word/media/image1.png",
        "word/document.xml#paragraph:25",
    }
    assert projected.title_block["approve_by"] == "Existing Approver"
    assert projected.title_block["version"] == "A"


def _docx_asset_association_record(
    *,
    line_count: int = 1,
    method: str = "single_product_document",
    product_id: str | None = "line:0",
    status: str = "advisory",
    fact_asset_id: str | None = None,
    fact_attributes: dict[str, object] | None = None,
    visual_decision: dict[str, object] | None = None,
    existing_image_refs: list[list[str]] | None = None,
    existing_field_meta: dict[str, object] | None = None,
) -> tuple[DocumentRecord, str]:
    asset_id = f"asset:sha256:{'1' * 64}"
    association_asset_id = fact_asset_id or asset_id
    raw_content: dict[str, object] = {
        "paragraphs": [],
        "tables": [],
        "textboxes": [],
        "source_asset_inventory": {
            "schema_version": "m1.source-asset-inventory.v1",
            "assets": [
                {
                    "asset_id": asset_id,
                    "sha256": "1" * 64,
                    "mime_type": "image/png",
                    "byte_size": 123,
                    "parts": ["word/media/image1.png"],
                    "source_refs": [
                        {
                            "source_ref": {
                                "part": "word/document.xml#paragraph:25"
                            },
                            "relationship_id": "rId7",
                        }
                    ],
                    "coverage_status": "inventoried_referenced",
                }
            ],
            "coverage_status": "complete",
        },
        "semantic_facts": [
            {
                "fact_id": "semantic_fact:test-image-association",
                "name": "product_image_association",
                "value": {
                    "asset_id": association_asset_id,
                    "product_id": product_id,
                },
                "attributes": {
                    "association_method": method,
                    "source_boundary": "visual_asset_advisory",
                    **(fact_attributes or {}),
                },
                "evidence_refs": [
                    {
                        "evidence_id": "asset:image/chars:0:12",
                        "quote": "product view",
                        "source_ref": {
                            "part": "word/document.xml#paragraph:25",
                            "range": "chars:0:12",
                        },
                    }
                ],
                "extractor": "drawing_semantics.v1",
                "confidence": 0.82,
                "status": status,
            }
        ],
    }
    extraction: dict[str, object] = {
        "raw_content": raw_content,
        "metadata": {},
    }
    if visual_decision is not None:
        extraction["metadata"] = {
            "visual_region_routing": {
                "decisions": {asset_id: visual_decision}
            }
        }
    lines = [
        {
            "line_id": f"technical:docx:{index}",
            "product_code": f"PRODUCT-{index + 1}",
            "name_raw": f"Product {index + 1}",
            "image_refs": (
                existing_image_refs[index]
                if existing_image_refs is not None
                else []
            ),
        }
        for index in range(line_count)
    ]
    return (
        DocumentRecord(
            source=DocumentSource(original_filename="approval-drawing.docx"),
            document_type="technical_document",
            document_subtype="approval_drawing",
            lines=lines,
            field_meta=existing_field_meta or {},
            extraction=extraction,
        ),
        asset_id,
    )


def test_verified_docx_asset_association_projects_with_complete_metadata() -> None:
    record, asset_id = _docx_asset_association_record()
    raw_before = copy.deepcopy(record.extraction["raw_content"])

    projected = project_technical_document(record)

    assert projected.lines[0].image_refs == [asset_id]
    image_meta = projected.field_meta["$.lines[0].image_refs"]
    assert image_meta.confidence == pytest.approx(0.82)
    assert image_meta.inferred is True
    assert image_meta.model_extra["review_required"] is True
    assert image_meta.model_extra["association_method"] == (
        "single_product_document"
    )
    assert image_meta.model_extra["association_methods"] == [
        "single_product_document"
    ]
    assert image_meta.model_extra["asset_ids"] == [asset_id]
    assert {
        (reference.part, reference.range) for reference in image_meta.source_refs
    } == {
        ("word/media/image1.png", None),
        ("word/document.xml#paragraph:25", None),
        ("word/document.xml#paragraph:25", "chars:0:12"),
    }
    assert projected.extraction["raw_content"] == raw_before


def test_explicit_docx_asset_anchor_targets_only_one_line_and_deduplicates() -> None:
    asset_id = f"asset:sha256:{'1' * 64}"
    record, _ = _docx_asset_association_record(
        line_count=2,
        method="explicit_product_anchor",
        product_id="line:1",
        existing_image_refs=[["assets/existing.png"], [asset_id]],
        existing_field_meta={
            "$.lines[1].image_refs": {
                "source_refs": [{"part": "legacy/image-association"}],
                "confidence": 0.95,
                "association_method": "legacy_verified",
                "provider": "legacy",
            }
        },
    )

    projected = project_technical_document(record)

    assert projected.lines[0].image_refs == ["assets/existing.png"]
    assert projected.lines[1].image_refs == [asset_id]
    image_meta = projected.field_meta["$.lines[1].image_refs"]
    assert image_meta.confidence == pytest.approx(0.82)
    assert image_meta.model_extra["provider"] == "legacy"
    assert image_meta.model_extra["association_methods"] == [
        "legacy_verified",
        "explicit_product_anchor",
    ]
    assert image_meta.model_extra["asset_ids"] == [asset_id]
    assert len(projected.lines[1].image_refs) == 1


@pytest.mark.parametrize(
    ("record_kwargs", "line_count"),
    [
        ({"status": "ambiguous"}, 1),
        ({"method": "unresolved", "product_id": None}, 1),
        ({"fact_asset_id": f"asset:sha256:{'2' * 64}"}, 1),
        ({"fact_attributes": {"visual_role": "logo"}}, 1),
        ({"method": "single_product_document"}, 2),
        (
            {
                "visual_decision": {
                    "action": "route",
                    "role": "decorative",
                }
            },
            1,
        ),
        (
            {
                "visual_decision": {
                    "action": "review",
                    "role": None,
                    "suggested_role": "product",
                }
            },
            1,
        ),
    ],
)
def test_unresolved_or_unsafe_docx_asset_association_is_audit_only(
    record_kwargs: dict[str, object],
    line_count: int,
) -> None:
    record, _asset_id = _docx_asset_association_record(
        line_count=line_count,
        **record_kwargs,
    )
    raw_before = copy.deepcopy(record.extraction["raw_content"])

    projected = project_technical_document(record)

    assert all(line.image_refs == [] for line in projected.lines)
    assert not any(path.endswith(".image_refs") for path in projected.field_meta)
    assert projected.extraction["raw_content"] == raw_before


def test_verified_docx_inventory_disables_unscoped_legacy_image_linking() -> None:
    record, _asset_id = _docx_asset_association_record(status="ambiguous")
    record.extraction["raw_content"]["images"] = [
        {
            "asset_path": "assets/logo.png",
            "target_part": "word/media/logo.png",
            "references": [{"xml_paragraph_index": 0}],
        }
    ]

    projected = project_technical_document(record)

    assert projected.lines[0].image_refs == []
    assert "$.lines[0].image_refs" not in projected.field_meta
    assert projected.extraction["raw_content"]["images"][0]["asset_path"] == (
        "assets/logo.png"
    )


@pytest.mark.parametrize("filename", ["8P8C产品规格书.pdf", "HDMI2.0产品规格书.pdf"])
def test_interface_name_in_filename_is_not_promoted_to_document_number(
    filename: str,
) -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename=filename, mime_type="application/pdf"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "text_blocks": [
                            {
                                "text_original": "PRODUCT SPECIFICATION",
                                "bbox": [10.0, 10.0, 200.0, 40.0],
                            }
                        ],
                        "tables": [],
                    }
                ]
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert getattr(projected.header, "drawing_number", None) is None
    assert getattr(projected.header, "product_numbers", []) == []
    assert projected.lines == []


def test_pdf_spatial_labels_never_pair_with_a_different_page() -> None:
    record = DocumentRecord(
        source=DocumentSource(
            original_filename="drawing.pdf", mime_type="application/pdf"
        ),
        document_type="technical_document",
        document_subtype="approval_drawing",
        extraction={
            "raw_content": {
                "pages": [
                    {"page_number": 1, "text_blocks": [], "tables": []},
                    {"page_number": 2, "text_blocks": [], "tables": []},
                ]
            },
            "metadata": {
                "structured_evidence": {
                    "pages": [
                        {
                            "page_number": 1,
                            "coordinate_space": "pixels",
                            "raw": {
                                "overall_ocr_res": {
                                    "rec_texts": ["DWG NO."],
                                    "rec_scores": [0.99],
                                    "rec_polys": [
                                        [[100, 100], [180, 100], [180, 130], [100, 130]]
                                    ],
                                }
                            },
                        },
                        {
                            "page_number": 2,
                            "coordinate_space": "pixels",
                            "raw": {
                                "overall_ocr_res": {
                                    "rec_texts": ["ABC-123"],
                                    "rec_scores": [0.99],
                                    "rec_polys": [
                                        [[100, 60], [180, 60], [180, 90], [100, 90]]
                                    ],
                                }
                            },
                        },
                    ]
                }
            },
        },
    )

    projected = project_technical_document(record)

    assert getattr(projected.header, "drawing_number", None) is None
    assert "$.header.drawing_number" not in projected.field_meta


def _native_docx_page(
    *,
    product_number_text: str | None = None,
    product_name: str = "HDMI椭圆形铝壳",
    outer_dimension: str = "19.93*10.05mm",
) -> dict[str, object]:
    blocks: list[dict[str, object]] = [
        {
            "block_id": "docx:p:0",
            "kind": "paragraph",
            "text": "工艺流程",
            "source": "docx-native-ooxml",
            "source_id": "word/document.xml#paragraph:0",
            "order": 0,
            "confidence": 1.0,
        },
        {
            "block_id": "docx:p:1",
            "kind": "paragraph",
            "text": "素材\t\t切割\t\t抛光\t\t阳极氧化",
            "source": "docx-native-ooxml",
            "source_id": "word/document.xml#paragraph:1",
            "order": 1,
            "confidence": 1.0,
        },
        {
            "block_id": "docx:p:2",
            "kind": "paragraph",
            "text": f"{product_name}图纸 21长",
            "source": "docx-native-ooxml",
            "source_id": "word/document.xml#paragraph:2",
            "order": 2,
            "confidence": 1.0,
        },
    ]
    if product_number_text:
        blocks.append(
            {
                "block_id": "docx:p:3",
                "kind": "paragraph",
                "text": f"产品编号：{product_number_text}",
                "source": "docx-native-ooxml",
                "source_id": "word/document.xml#paragraph:3",
                "order": 3,
                "confidence": 1.0,
            }
        )
    rows = [
        ["产品名称", "外径尺寸", "内径尺寸", "下料尺寸", "公差"],
        [product_name, outer_dimension, "18.6*8.7mm", "21mm", "±0.05mm"],
    ]
    cells = [
        {
            "row": row,
            "column": column,
            "text": value,
            "source_id": (f"word/document.xml#table:0/row:{row}/cell:{column}"),
            "confidence": 1.0,
        }
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]
    return {
        "page_number": 1,
        "coordinate_space": "unknown",
        "blocks": blocks,
        "tables": [
            {
                "table_id": "docx:t:0",
                "source": "docx-native-ooxml",
                "source_id": "word/document.xml#table:0",
                "rows": rows,
                "cells": cells,
                "confidence": 1.0,
            }
        ],
    }


def _native_docx_metadata() -> dict[str, object]:
    return {
        "mineru_input": {
            "source": {"file_type": "docx"},
            "normalized": {"file_type": "docx", "conversion": "native"},
        },
        "classification_normalization": {
            "document_subtype_hint_applied": False,
        },
    }


def test_native_docx_engineering_drawing_merges_compatible_same_source_rows() -> None:
    ref = {
        "page": 1,
        "part": "mineru/docx:t:0:r1:c0",
        "evidence_id": "docx:t:0:r1:c0",
    }
    record = DocumentRecord(
        source=DocumentSource(
            original_filename="3933-21长蓝色.docx",
            mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ),
        document_type="technical_document",
        document_subtype="product_specification",
        document_kind_label="product_specification",
        lines=[
            {
                "line_id": "mineru-instructor-existing",
                "name_raw": "HDMI椭圆形铝壳",
                "custom_fields": {
                    "外径尺寸": "19.93*10.05mm",
                    "内径尺寸": "18.6*8.7mm",
                    "下料尺寸": "21mm",
                    "公差": "±0.05mm",
                },
                "raw_columns": {
                    "name_raw": "HDMI椭圆形铝壳",
                    "外径尺寸": "19.93*10.05mm",
                    "内径尺寸": "18.6*8.7mm",
                    "下料尺寸": "21mm",
                    "公差": "±0.05mm",
                },
            }
        ],
        field_meta={"$.lines[0].name_raw": {"source_refs": [ref]}},
        extraction={
            "raw_content": {"pages": [_native_docx_page()]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert projected.document_subtype == "engineering_drawing"
    assert projected.document_kind_label == "engineering_drawing"
    assert len(projected.lines) == 1
    line = projected.lines[0]
    assert line.line_id == "mineru-instructor-existing"
    assert line.product_code is None
    assert line.model is None
    assert line.name_normalized == "HDMI椭圆形铝壳"
    assert line.custom_fields["specifications"] == {
        "外径尺寸": "19.93*10.05mm",
        "内径尺寸": "18.6*8.7mm",
        "下料尺寸": "21mm",
        "公差": "±0.05mm",
    }
    assert "外径尺寸=19.93*10.05mm" in (line.specification_raw or "")
    assert len(projected.field_meta["$.lines[0].specification_raw"].source_refs) >= 4
    for column, (name, value) in enumerate(
        line.custom_fields["specifications"].items(), start=1
    ):
        path = f'$.lines[0].custom_fields["specifications"]["{name}"]'
        metadata = projected.field_meta[path]
        assert metadata.source_refs[0].part == f"mineru/docx:t:0:r1:c{column}"
        assert metadata.source_refs[0].model_extra["evidence_quote"] == value


def test_native_docx_explicit_product_number_populates_single_line_model() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {
                "pages": [_native_docx_page(product_number_text="3933-21")]
            },
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert len(projected.lines) == 1
    assert projected.lines[0].model == "3933-21"
    model_refs = projected.field_meta["$.lines[0].model"].source_refs
    assert {ref.part for ref in model_refs} == {"mineru/docx:p:3"}


def test_native_docx_explicit_model_column_populates_line_model() -> None:
    page = _native_docx_page()
    rows = [
        ["产品名称", "型号", "外径尺寸", "内径尺寸", "下料尺寸", "公差"],
        [
            "HDMI椭圆形铝壳",
            "3933-21",
            "19.93*10.05mm",
            "18.6*8.7mm",
            "21mm",
            "±0.05mm",
        ],
    ]
    page["tables"][0]["rows"] = rows
    page["tables"][0]["cells"] = [
        {
            "row": row,
            "column": column,
            "text": value,
            "source_id": f"word/document.xml#table:0/row:{row}/cell:{column}",
            "confidence": 1.0,
        }
        for row, values in enumerate(rows)
        for column, value in enumerate(values)
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {"pages": [page]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert len(projected.lines) == 1
    assert projected.lines[0].model == "3933-21"
    assert projected.lines[0].product_code is None
    assert {
        ref.part for ref in projected.field_meta["$.lines[0].model"].source_refs
    } == {"mineru/docx:t:0:r1:c1"}


@pytest.mark.parametrize("identifier", ["HDMI2.1", "DP1.4", "USB3.2", "Type-C"])
def test_interface_protocol_is_not_a_line_identifier(identifier: str) -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        lines=[
            {
                "line_id": "line-1",
                "model": identifier,
                "product_code": identifier,
                "name_raw": "铝壳",
            }
        ],
        field_meta={
            "$.lines[0].model": {
                "source_refs": [{"part": "word/document.xml#paragraph:1"}]
            },
            "$.lines[0].product_code": {
                "source_refs": [{"part": "word/document.xml#paragraph:1"}]
            },
        },
        extraction={
            "raw_content": {"paragraphs": [], "tables": [], "textboxes": []},
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.lines[0].model is None
    assert projected.lines[0].product_code is None
    assert "$.lines[0].model" not in projected.field_meta
    assert "$.lines[0].product_code" not in projected.field_meta


def test_filename_only_product_number_is_not_promoted_to_line_identifier() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="3933-21长蓝色.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {"pages": [_native_docx_page()]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert len(projected.lines) == 1
    assert projected.lines[0].model is None
    assert projected.lines[0].product_code is None
    assert "$.lines[0].model" not in projected.field_meta
    assert "$.lines[0].product_code" not in projected.field_meta


def test_incidental_drawing_mention_does_not_override_product_specification() -> None:
    page = _native_docx_page()
    page["blocks"] = [
        {
            "block_id": "docx:p:0",
            "kind": "paragraph",
            "text": "安装尺寸请参考客户图纸，产品参数以本规格书为准。",
            "source": "docx-native-ooxml",
            "source_id": "word/document.xml#paragraph:0",
            "order": 0,
            "confidence": 1.0,
        }
    ]
    record = DocumentRecord(
        source=DocumentSource(original_filename="product-specification.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {"pages": [page]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert projected.document_subtype == "product_specification"


def test_explicit_subtype_hint_is_not_overridden_by_drawing_evidence() -> None:
    metadata = _native_docx_metadata()
    metadata["classification_normalization"] = {"document_subtype_hint_applied": True}
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {"pages": [_native_docx_page()]},
            "metadata": metadata,
        },
    )

    projected = project_technical_document(record)

    assert projected.document_subtype == "product_specification"


def test_native_docx_classification_overrides_model_subtype_before_projection() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="renamed.docx"),
        document_type="technical_document",
        document_subtype="engineering_drawing",
        document_kind_label="engineering_drawing",
        extraction={
            "raw_content": {
                "pages": [_native_docx_page()],
                "native_classification": {
                    "source": "docx-native-classifier-v1",
                    "document_type": "technical_document",
                    "document_subtype": "approval_drawing",
                },
            },
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert projected.document_subtype == "approval_drawing"
    assert projected.document_kind_label == "approval_drawing"


def test_same_source_lines_with_conflicting_specifications_are_not_merged() -> None:
    shared_ref = {
        "part": "word/document.xml#table:0/row:1/cell:0",
        "evidence_id": "docx:t:0:r1:c0",
    }
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        lines=[
            {
                "line_id": "line-a",
                "name_raw": "椭圆形铝壳",
                "custom_fields": {"specifications": {"下料尺寸": "21mm"}},
            },
            {
                "line_id": "line-b",
                "name_raw": "椭圆形铝壳",
                "custom_fields": {"specifications": {"下料尺寸": "28mm"}},
            },
        ],
        field_meta={
            "$.lines[0].name_raw": {"source_refs": [shared_ref]},
            "$.lines[1].name_raw": {"source_refs": [shared_ref]},
        },
        extraction={
            "raw_content": {"paragraphs": [], "tables": [], "textboxes": []},
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert projected.document_subtype == "approval_drawing"
    assert [line.line_id for line in projected.lines] == ["line-a", "line-b"]


def test_same_facts_from_different_table_rows_are_not_merged() -> None:
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="approval_drawing",
        lines=[
            {
                "line_id": "row-1",
                "name_raw": "椭圆形铝壳",
                "custom_fields": {"specifications": {"下料尺寸": "21mm"}},
            },
            {
                "line_id": "row-2",
                "name_raw": "椭圆形铝壳",
                "custom_fields": {"specifications": {"下料尺寸": "21mm"}},
            },
        ],
        field_meta={
            "$.lines[0].name_raw": {
                "source_refs": [
                    {"part": "mineru/docx:t:0:r1:c0"},
                ]
            },
            "$.lines[1].name_raw": {
                "source_refs": [
                    {"part": "mineru/docx:t:0:r2:c0"},
                ]
            },
        },
        extraction={
            "raw_content": {"paragraphs": [], "tables": [], "textboxes": []},
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert [line.line_id for line in projected.lines] == ["row-1", "row-2"]


def test_product_table_projection_cites_specification_leaves_and_line_number() -> None:
    product_name = "Connector shell"
    page = _native_docx_page(
        product_name=product_name,
        outer_dimension="19.93*10.05mm",
    )
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {"pages": [page]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    assert len(projected.lines) == 1
    line = projected.lines[0]
    assert line.line_no == 2
    line_no_meta = projected.field_meta["$.lines[0].line_no"]
    assert line_no_meta.inferred is True
    assert len(line_no_meta.source_refs) == 1
    line_no_ref = line_no_meta.source_refs[0]
    assert line_no_ref.page == 1
    assert line_no_ref.part == "mineru/docx:t:0:r1:c0"
    assert line_no_ref.model_extra["evidence_quote"] == product_name

    specifications = line.custom_fields["specifications"]
    assert len(specifications) == 4
    for column, (name, value) in enumerate(specifications.items(), start=1):
        path = f'$.lines[0].custom_fields["specifications"]["{name}"]'
        metadata = projected.field_meta[path]
        assert metadata.source_refs
        assert metadata.source_refs[0].page == 1
        assert metadata.source_refs[0].part == f"mineru/docx:t:0:r1:c{column}"
        assert metadata.source_refs[0].model_extra["evidence_quote"] == value

    assert len(line.raw_columns) == 5
    for column, (name, value) in enumerate(line.raw_columns.items()):
        path = f'$.lines[0].raw_columns["{name}"]'
        metadata = projected.field_meta[path]
        assert metadata.source_refs[0].page == 1
        assert metadata.source_refs[0].part == f"mineru/docx:t:0:r1:c{column}"
        assert metadata.source_refs[0].model_extra["evidence_quote"] == value


def test_single_product_projection_cites_specification_leaves_and_line_number() -> None:
    text_blocks = [
        {
            "text_original": "Product Number: SKU-35B",
            "bbox": [10.0, 10.0, 180.0, 30.0],
        },
        {
            "text_original": "Bandwidth: 48Gbps",
            "bbox": [10.0, 40.0, 180.0, 60.0],
        },
        {
            "text_original": "Voltage: 5V",
            "bbox": [10.0, 70.0, 180.0, 90.0],
        },
    ]
    record = DocumentRecord(
        source=DocumentSource(
            original_filename="specification.pdf",
            mime_type="application/pdf",
        ),
        document_type="technical_document",
        document_subtype="product_specification",
        extraction={
            "raw_content": {
                "pages": [
                    {
                        "page_number": 1,
                        "coordinate_space": "pdf_points",
                        "text_blocks": text_blocks,
                        "tables": [],
                    }
                ]
            },
            "metadata": {},
        },
    )

    projected = project_technical_document(record)

    assert len(projected.lines) == 1
    line = projected.lines[0]
    assert line.line_no == 1
    assert line.product_code == "SKU-35B"
    assert line.custom_fields["specifications"] == {
        "Product Number": "SKU-35B",
        "Bandwidth": "48Gbps",
        "Voltage": "5V",
    }

    line_no_meta = projected.field_meta["$.lines[0].line_no"]
    assert line_no_meta.inferred is True
    assert len(line_no_meta.source_refs) == 1
    line_no_ref = line_no_meta.source_refs[0]
    assert line_no_ref.page == 1
    assert line_no_ref.model_extra["bbox"] == [10.0, 10.0, 180.0, 30.0]
    assert line_no_ref.model_extra["coordinate_space"] == "pdf_points"

    expected_bboxes = {
        "Product Number": [10.0, 10.0, 180.0, 30.0],
        "Bandwidth": [10.0, 40.0, 180.0, 60.0],
        "Voltage": [10.0, 70.0, 180.0, 90.0],
    }
    for name, value in line.custom_fields["specifications"].items():
        path = f'$.lines[0].custom_fields["specifications"]["{name}"]'
        metadata = projected.field_meta[path]
        assert len(metadata.source_refs) == 1
        source_ref = metadata.source_refs[0]
        assert source_ref.page == 1
        assert source_ref.model_extra["bbox"] == expected_bboxes[name]
        assert source_ref.model_extra["coordinate_space"] == "pdf_points"
        assert source_ref.model_extra["evidence_quote"] == f"{name}: {value}"


def test_projection_does_not_overwrite_explicit_specification_leaf_reference() -> None:
    page = _native_docx_page(product_name="Connector shell")
    path = '$.lines[0].custom_fields["specifications"]["外径尺寸"]'
    explicit_ref = {
        "page": 7,
        "part": "reviewed/specification-value",
        "bbox": [1.0, 2.0, 3.0, 4.0],
        "coordinate_space": "pdf_points",
        "evidence_quote": "19.93*10.05mm",
    }
    record = DocumentRecord(
        source=DocumentSource(original_filename="drawing.docx"),
        document_type="technical_document",
        document_subtype="product_specification",
        field_meta={
            path: {
                "source_refs": [explicit_ref],
                "confidence": 1.0,
            }
        },
        extraction={
            "raw_content": {"pages": [page]},
            "metadata": _native_docx_metadata(),
        },
    )

    projected = project_technical_document(record)

    metadata = projected.field_meta[path]
    assert metadata.confidence == 1.0
    assert metadata.source_refs[0].model_dump(mode="json", exclude_none=True) == (
        explicit_ref
    )
