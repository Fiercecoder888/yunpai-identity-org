from __future__ import annotations

from fastapi.testclient import TestClient
from starlette.routing import Mount

from m1.api import main as api_main


LEGACY_API_ROUTES = {
    ("DELETE", "/tasks/{task_id}"),
    ("GET", "/batch/{parent_id}"),
    ("GET", "/files/{task_id}"),
    ("GET", "/health"),
    ("GET", "/review/queue"),
    ("GET", "/tasks"),
    ("GET", "/tasks/{task_id}"),
    ("GET", "/tasks/{task_id}/download"),
    ("GET", "/tasks/{task_id}/replication-report/download"),
    ("GET", "/tasks/{task_id}/report/download"),
    ("POST", "/ingest"),
    ("POST", "/ingest/archive"),
    ("POST", "/ingest/batch"),
    ("POST", "/ingest/sync"),
    ("POST", "/review/{task_id}"),
    ("POST", "/tasks/{task_id}/replication-report"),
    ("POST", "/tasks/{task_id}/report"),
}


def test_all_legacy_api_routes_remain_registered(monkeypatch) -> None:
    """Knowledge routes are additive and cannot silently remove old M1 APIs."""

    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(api_main.settings, "tenant_api_key_hashes", "")
    app = api_main.create_app()
    registered = {
        (method, route.path)
        for route in app.routes
        for method in (getattr(route, "methods", None) or ())
    }

    assert LEGACY_API_ROUTES <= registered


def test_original_react_console_is_mounted_after_all_api_routes(
    monkeypatch,
) -> None:
    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(api_main.settings, "tenant_api_key_hashes", "")
    monkeypatch.setattr(api_main, "knowledge_runtime", None)

    app = api_main.create_app()
    assert isinstance(app.routes[-1], Mount)
    assert app.routes[-1].name == "static"

    # No lifespan is needed for static dispatch or for proving that the
    # knowledge route reaches its JSON API handler.
    client = TestClient(app)
    root = client.get("/")
    assert root.status_code == 200
    assert root.headers["content-type"].startswith("text/html")
    assert '<div id="root"></div>' in root.text

    knowledge = client.get("/knowledge/health")
    assert knowledge.status_code == 503
    assert knowledge.headers["content-type"].startswith("application/json")
    assert isinstance(knowledge.json().get("detail"), str)


def test_original_static_assets_remain_served(monkeypatch) -> None:
    monkeypatch.setattr(api_main.settings, "api_auth_key", "")
    monkeypatch.setattr(api_main.settings, "tenant_api_key_hashes", "")

    client = TestClient(api_main.create_app())
    javascript = client.get("/assets/index-B1vCSeRy.js")
    stylesheet = client.get("/assets/index-BfHb-0WB.css")

    assert javascript.status_code == 200
    assert "javascript" in javascript.headers["content-type"]
    assert javascript.content
    assert stylesheet.status_code == 200
    assert "text/css" in stylesheet.headers["content-type"]
    assert stylesheet.content
