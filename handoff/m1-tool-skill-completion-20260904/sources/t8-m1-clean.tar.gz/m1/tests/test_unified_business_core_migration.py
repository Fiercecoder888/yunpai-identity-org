from __future__ import annotations

from importlib import import_module
from pathlib import Path

from alembic import command
from sqlalchemy import create_engine, inspect

from m1.knowledge.migrations.runner import _config


def test_unified_core_revision_is_sqlite_safe(tmp_path: Path) -> None:
    """The PostgreSQL-only core must not break M1's SQLite compatibility tests."""

    engine = create_engine(f"sqlite:///{tmp_path / 'knowledge.db'}")
    try:
        with engine.begin() as connection:
            command.upgrade(_config(connection), "0016_unified_business_core")
            assert not inspect(connection).has_table("orders")
            command.downgrade(_config(connection), "0015_content_region_routes")
    finally:
        engine.dispose()


def test_unified_core_declares_governed_postgres_contract() -> None:
    migration = import_module(
        "m1.knowledge.migrations.versions.0016_unified_business_core"
    )

    assert migration.down_revision == "0015_content_region_routes"
    assert migration.SCHEMA == "yunpai_core"
    assert set(migration.TABLES) == {
        "orders",
        "materials",
        "order_materials",
        "inventory_balances",
        "inventory_movements",
        "procurement_plans",
        "procurement_plan_lines",
        "purchase_orders",
        "schedule_versions",
        "business_flow_runs",
        "business_flow_steps",
        "integration_outbox",
    }
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())

    source = Path(migration.__file__).read_text(encoding="utf-8")
    assert "FORCE ROW LEVEL SECURITY" in source
    assert "current_setting('yunpai.tenant_id', true)" in source
    assert "integration_outbox" in source
