from __future__ import annotations

import os
from urllib.parse import quote, urlsplit, urlunsplit

import asyncpg
import pytest
from alembic import command
from sqlalchemy.ext.asyncio import create_async_engine

from m1.knowledge.migrations.runner import _config, upgrade_database


POSTGRES_URL = os.getenv("M1_TEST_POSTGRES_URL", "").strip()


def _asyncpg_url(url: str) -> str:
    return url.replace("postgresql+asyncpg://", "postgresql://", 1)


def _with_credentials(url: str, username: str, password: str) -> str:
    parsed = urlsplit(_asyncpg_url(url))
    host = parsed.hostname or "localhost"
    port = f":{parsed.port}" if parsed.port else ""
    netloc = f"{quote(username)}:{quote(password)}@{host}{port}"
    return urlunsplit((parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment))


@pytest.mark.skipif(not POSTGRES_URL, reason="M1_TEST_POSTGRES_URL is not configured")
@pytest.mark.asyncio
async def test_unified_core_postgres_upgrade_rls_and_downgrade() -> None:
    assert await upgrade_database(POSTGRES_URL) == "0022_flow_request_persistence"

    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    role_name = "vnext_core_contract_app"
    role_password = "temporary-contract-password"
    try:
        tables = {
            row["tablename"]
            for row in await admin.fetch(
                "SELECT tablename FROM pg_tables WHERE schemaname='yunpai_core'"
            )
        }
        assert tables == {
            "orders",
            "materials",
            "order_materials",
            "inventory_balances",
            "inventory_movements",
            "procurement_plans",
            "procurement_plan_lines",
            "purchase_orders",
            "schedule_versions",
            "business_flow_runs",
            "business_flow_steps",
            "integration_outbox",
            "fact_versions",
            "algorithm_versions",
            "calculation_runs",
            "calculation_inputs",
            "validation_results",
            "supply_allocations",
            "recalculation_jobs",
            "recalculation_job_orders",
        }
        rls = await admin.fetch(
            """
            SELECT relname, relrowsecurity, relforcerowsecurity
            FROM pg_class c
            JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE n.nspname='yunpai_core' AND c.relkind='r'
            """
        )
        assert len(rls) == 20
        assert all(row["relrowsecurity"] and row["relforcerowsecurity"] for row in rls)
        assert await admin.fetchval(
            "SELECT count(*) FROM pg_policies WHERE schemaname='yunpai_core'"
        ) == 20

        await admin.execute(f'DROP ROLE IF EXISTS "{role_name}"')
        await admin.execute(
            f'CREATE ROLE "{role_name}" LOGIN PASSWORD \'{role_password}\''
        )
        await admin.execute(f'GRANT USAGE ON SCHEMA yunpai_core TO "{role_name}"')
        await admin.execute(
            f'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA yunpai_core TO "{role_name}"'
        )
    finally:
        await admin.close()

    app = await asyncpg.connect(_with_credentials(POSTGRES_URL, role_name, role_password))
    try:
        await app.execute("SELECT set_config('yunpai.tenant_id', 'tenant-a', false)")
        await app.execute(
            """
            INSERT INTO yunpai_core.orders
                (order_id, tenant_id, order_number, lifecycle_status, attributes,
                 version, created_at, updated_at)
            VALUES ('ORDER-A', 'tenant-a', 'ORDER-A', 'active', '{}'::jsonb,
                    1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            """
        )
        assert await app.fetchval(
            "SELECT count(*) FROM yunpai_core.orders WHERE order_id='ORDER-A'"
        ) == 1
        await app.execute(
            """
            INSERT INTO yunpai_core.fact_versions
                (fact_version_id, tenant_id, fact_type, aggregate_type,
                 aggregate_id, version, source_module, source_event_id,
                 occurred_at, effective_at, payload_digest, payload, validation,
                 created_at)
            VALUES ('FACT-A', 'tenant-a', 'inventory', 'material', 'MAT-A', 1,
                    'm3', 'EVENT-A', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
                    repeat('a', 64), '{}'::jsonb, '[]'::jsonb, CURRENT_TIMESTAMP)
            """
        )
        with pytest.raises(asyncpg.PostgresError, match="immutable ledger table"):
            await app.execute(
                "UPDATE yunpai_core.fact_versions SET version=2 WHERE fact_version_id='FACT-A'"
            )

        await app.execute("SELECT set_config('yunpai.tenant_id', 'tenant-b', false)")
        assert await app.fetchval(
            "SELECT count(*) FROM yunpai_core.orders WHERE order_id='ORDER-A'"
        ) == 0
        with pytest.raises(asyncpg.InsufficientPrivilegeError):
            await app.execute(
                """
                INSERT INTO yunpai_core.orders
                    (order_id, tenant_id, order_number, lifecycle_status, attributes,
                     version, created_at, updated_at)
                VALUES ('ORDER-CROSS', 'tenant-a', 'ORDER-CROSS', 'active', '{}'::jsonb,
                        1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                """
            )
    finally:
        await app.close()

    admin = await asyncpg.connect(_asyncpg_url(POSTGRES_URL))
    try:
        await admin.execute(f'DROP OWNED BY "{role_name}"')
        await admin.execute(f'DROP ROLE "{role_name}"')
    finally:
        await admin.close()

    engine = create_async_engine(POSTGRES_URL)
    try:
        async with engine.begin() as connection:
            await connection.run_sync(
                lambda sync_connection: command.downgrade(
                    _config(sync_connection), "0015_content_region_routes"
                )
            )
        async with engine.connect() as connection:
            schema_exists = await connection.exec_driver_sql(
                "SELECT to_regnamespace('yunpai_core') IS NOT NULL"
            )
            assert schema_exists.scalar_one() is False
    finally:
        await engine.dispose()

    assert await upgrade_database(POSTGRES_URL) == "0022_flow_request_persistence"
