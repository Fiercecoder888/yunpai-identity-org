from __future__ import annotations

import importlib.util
from datetime import datetime, timezone
from pathlib import Path
import sys
from typing import Any

import httpx
import pytest

from m1.documents import parse_spreadsheet_document


SCRIPT_PATH = (
    Path(__file__).resolve().parents[1] / "scripts" / "verify_knowledge_lifecycle.py"
)
SPEC = importlib.util.spec_from_file_location("verify_knowledge_lifecycle_script", SCRIPT_PATH)
assert SPEC is not None and SPEC.loader is not None
lifecycle = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = lifecycle
SPEC.loader.exec_module(lifecycle)


class _FakeClock:
    def __init__(self) -> None:
        self.value = 0.0

    def monotonic(self) -> float:
        return self.value

    async def sleep(self, seconds: float) -> None:
        self.value += seconds


class _LifecycleApi:
    def __init__(
        self,
        marker: str,
        *,
        search_visible: bool = True,
        expected_api_key: str = "",
        outbox_pending: int = 0,
        lightrag_enabled: bool = False,
        graph_contains_marker: bool = True,
        health_complete: bool = True,
        delete_results: list[bool] | None = None,
    ) -> None:
        self.marker = marker
        self.search_visible = search_visible
        self.expected_api_key = expected_api_key
        self.outbox_pending = outbox_pending
        self.lightrag_enabled = lightrag_enabled
        self.graph_contains_marker = graph_contains_marker
        self.health_complete = health_complete
        self.delete_results = list(delete_results or [True])
        self.deleted = False
        self.requests: list[tuple[str, str]] = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path
        self.requests.append((request.method, path))
        if request.method == "POST" and path == "/ingest":
            assert request.headers.get("X-API-Key", "") == self.expected_api_key
            return httpx.Response(200, json={"task_id": "task-probe"})
        if request.method == "GET" and path == "/tasks/task-probe":
            return httpx.Response(
                200,
                json={
                    "task_id": "task-probe",
                    "status": "done",
                    "knowledge_sync_status": "synced",
                    "knowledge_document_id": "document-probe",
                },
            )
        if request.method == "GET" and path == "/knowledge/search":
            visible = self.search_visible and not self.deleted
            hits: list[dict[str, Any]] = []
            if visible:
                hits.append(
                    {
                        "match_reason": "exact_identifier",
                        "document": {
                            "source_record_id": "document-probe",
                            "text": self.marker,
                        },
                    }
                )
            return httpx.Response(200, json={"hits": hits})
        if request.method == "GET" and path == "/knowledge/graph/document-probe":
            if self.deleted:
                return httpx.Response(404, json={"detail": "not found"})
            return httpx.Response(
                200,
                json={
                    "source_record_id": "document-probe",
                    "nodes": [
                        {
                            "status": "active",
                            "source_record_id": "document-probe",
                            "properties": {
                                "product_code": (
                                    self.marker
                                    if self.graph_contains_marker
                                    else "OTHER"
                                )
                            },
                        }
                    ],
                    "edges": [],
                },
            )
        if request.method == "DELETE" and path == "/tasks/task-probe":
            confirmed = self.delete_results.pop(0) if self.delete_results else True
            if confirmed:
                self.deleted = True
            return httpx.Response(200, json={"deleted": confirmed})
        if request.method == "GET" and path == "/health":
            return httpx.Response(
                200,
                json={
                    "knowledge": {
                        "outbox": {
                            "pending": self.outbox_pending,
                            "oldest_pending_age_seconds": (
                                10.0 if self.outbox_pending else 0.0
                            ),
                            "terminal_failures": 0,
                            "status_error_count": 0,
                            "health_complete": self.health_complete,
                            "enabled": True,
                            "running": True,
                            "refreshed_at": datetime.now(timezone.utc).isoformat(),
                        }
                    }
                },
            )
        if request.method == "GET" and path == "/ready":
            return httpx.Response(
                200,
                json={
                    "status": "ready",
                    "knowledge": {
                        "ready": True,
                        "backend": {
                            "status": "ok",
                            "wiki": {"status": "ok", "backend": "postgresql"},
                            "graph": {
                                "status": "ok",
                                "backend": "neo4j",
                                "schema_initialized": True,
                            },
                            "lightrag_shadow": {
                                "enabled": self.lightrag_enabled,
                                "ready": True,
                            },
                        },
                        "outbox": {
                            "enabled": True,
                            "running": True,
                            "health_complete": self.health_complete,
                        },
                    },
                },
            )
        raise AssertionError(f"unexpected request: {request.method} {path}")


class _LightRAGApi:
    def __init__(self, marker: str, m1: _LifecycleApi) -> None:
        self.marker = marker
        self.m1 = m1

    def __call__(self, request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/query"
        assert request.headers.get("X-API-Key") == "lightrag-test-secret"
        context = "" if self.m1.deleted else self.marker
        return httpx.Response(
            200,
            json={"response": context, "data": {"references": []}},
        )


class _Neo4jProbe:
    def __init__(self, marker: str, m1: _LifecycleApi) -> None:
        self.marker = marker
        self.m1 = m1
        self.closed = False

    async def inspect(
        self, *, tenant_id: str, source_record_id: str, marker: str
    ) -> dict[str, int]:
        assert tenant_id == "default"
        assert source_record_id == "document-probe"
        assert marker == self.marker
        if self.m1.deleted:
            return {"node_count": 0, "marker_count": 0}
        return {"node_count": 2, "marker_count": 1}

    async def close(self) -> None:
        self.closed = True


def test_synthetic_csv_is_a_review_free_inventory_document(tmp_path: Path) -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_TEST_FIXTURE"
    source = tmp_path / "knowledge-lifecycle.csv"
    source.write_bytes(lifecycle._synthetic_csv(marker))

    document = parse_spreadsheet_document(source)

    assert document.document_type == "inventory"
    assert document.document_subtype == "inventory_snapshot"
    assert document.needs_review is False
    assert len(document.lines) == 1
    assert document.lines[0].product_code == marker


@pytest.mark.asyncio
async def test_lifecycle_success_with_optional_lightrag_and_no_secret_report() -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_TEST_SUCCESS"
    clock = _FakeClock()
    api = _LifecycleApi(
        marker,
        expected_api_key="m1-test-secret",
        lightrag_enabled=True,
    )
    lightrag_api = _LightRAGApi(marker, api)
    neo4j = _Neo4jProbe(marker, api)
    config = lifecycle.VerificationConfig(
        base_url="http://127.0.0.1:8080",
        api_key="m1-test-secret",
        lightrag_base_url="http://localhost:9621",
        lightrag_api_key="lightrag-test-secret",
        poll_interval_seconds=2.0,
        visibility_timeout_seconds=10.0,
        deletion_timeout_seconds=10.0,
    )

    report = await lifecycle.verify_knowledge_lifecycle(
        config,
        marker=marker,
        m1_transport=httpx.MockTransport(api),
        lightrag_transport=httpx.MockTransport(lightrag_api),
        neo4j_probe=neo4j,
        monotonic=clock.monotonic,
        sleep=clock.sleep,
    )

    assert report["status"] == "passed"
    assert report["visibility"]["lightrag_visible"] is True
    assert report["preflight"] == {
        "postgresql": "ready",
        "neo4j": "ready",
        "neo4j_schema_initialized": True,
        "outbox_worker": "ready",
        "lightrag_shadow_enabled": True,
    }
    assert report["visibility"]["neo4j_visible"] is True
    assert report["deletion"]["task_deleted"] is True
    assert report["deletion"]["authoritative_search_absent"] is True
    assert report["deletion"]["graph_active_projection_absent"] is True
    assert report["deletion"]["neo4j_projection_absent"] is True
    assert report["deletion"]["lightrag_absent"] is True
    assert report["deletion"]["outbox"]["health_complete"] is True
    assert report["deletion"]["outbox"]["refreshed_after_delete"] is True
    assert neo4j.closed is True
    rendered = lifecycle.json.dumps(report)
    assert "m1-test-secret" not in rendered
    assert "lightrag-test-secret" not in rendered
    assert ("DELETE", "/tasks/task-probe") in api.requests


@pytest.mark.asyncio
async def test_deletion_timeout_is_bounded() -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_TEST_TIMEOUT"
    clock = _FakeClock()
    api = _LifecycleApi(marker, outbox_pending=1)
    neo4j = _Neo4jProbe(marker, api)
    config = lifecycle.VerificationConfig(
        base_url="http://127.0.0.1:8080",
        poll_interval_seconds=2.0,
        visibility_timeout_seconds=4.0,
        deletion_timeout_seconds=4.0,
    )

    with pytest.raises(lifecycle.LifecycleVerificationError) as captured:
        await lifecycle.verify_knowledge_lifecycle(
            config,
            marker=marker,
            m1_transport=httpx.MockTransport(api),
            neo4j_probe=neo4j,
            monotonic=clock.monotonic,
            sleep=clock.sleep,
        )

    assert captured.value.code == "DELETION_CONVERGENCE_TIMEOUT"
    assert captured.value.phase == "deletion"
    assert captured.value.report()["observed"]["outbox"]["pending"] == 1
    assert clock.value == 4.0
    assert api.deleted is True


@pytest.mark.asyncio
async def test_remote_target_is_refused_before_transport_request() -> None:
    calls = 0

    def handler(_request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(500)

    config = lifecycle.VerificationConfig(
        base_url="http://m1.example.invalid:39081"
    )

    with pytest.raises(lifecycle.UnsafeTargetError):
        await lifecycle.verify_knowledge_lifecycle(
            config,
            m1_transport=httpx.MockTransport(handler),
        )

    assert calls == 0


@pytest.mark.asyncio
async def test_remote_target_requires_exact_destructive_confirmation() -> None:
    config = lifecycle.VerificationConfig(
        base_url="http://m1.example.invalid:8080",
        allow_remote=True,
        confirm_destructive_target="http://different.example.invalid:8080",
    )

    with pytest.raises(lifecycle.UnsafeTargetError):
        await lifecycle.verify_knowledge_lifecycle(config)


@pytest.mark.asyncio
async def test_preflight_rejects_incomplete_outbox_before_upload() -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_PREFLIGHT"
    api = _LifecycleApi(marker, health_complete=False)
    neo4j = _Neo4jProbe(marker, api)

    with pytest.raises(lifecycle.LifecycleVerificationError) as captured:
        await lifecycle.verify_knowledge_lifecycle(
            lifecycle.VerificationConfig(),
            marker=marker,
            m1_transport=httpx.MockTransport(api),
            neo4j_probe=neo4j,
        )

    assert captured.value.code == "OUTBOX_WORKER_NOT_READY"
    assert not any(path == "/ingest" for _method, path in api.requests)
    assert neo4j.closed is True


@pytest.mark.asyncio
async def test_graph_without_marker_cannot_pass_visibility() -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_GRAPH_MARKER"
    clock = _FakeClock()
    api = _LifecycleApi(marker, graph_contains_marker=False)
    neo4j = _Neo4jProbe(marker, api)

    with pytest.raises(lifecycle.LifecycleVerificationError) as captured:
        await lifecycle.verify_knowledge_lifecycle(
            lifecycle.VerificationConfig(
                visibility_timeout_seconds=4,
                deletion_timeout_seconds=4,
                poll_interval_seconds=2,
            ),
            marker=marker,
            m1_transport=httpx.MockTransport(api),
            neo4j_probe=neo4j,
            monotonic=clock.monotonic,
            sleep=clock.sleep,
        )

    assert captured.value.code == "PROJECTION_VISIBILITY_TIMEOUT"
    assert api.deleted is True


@pytest.mark.asyncio
async def test_unconfirmed_delete_is_retried_during_cleanup() -> None:
    marker = "M1_KNOWLEDGE_LIFECYCLE_DELETE_RETRY"
    api = _LifecycleApi(marker, delete_results=[False, True])
    neo4j = _Neo4jProbe(marker, api)

    with pytest.raises(lifecycle.LifecycleVerificationError) as captured:
        await lifecycle.verify_knowledge_lifecycle(
            lifecycle.VerificationConfig(),
            marker=marker,
            m1_transport=httpx.MockTransport(api),
            neo4j_probe=neo4j,
        )

    assert captured.value.code == "TASK_DELETE_NOT_CONFIRMED"
    assert api.requests.count(("DELETE", "/tasks/task-probe")) == 2
    assert api.deleted is True
