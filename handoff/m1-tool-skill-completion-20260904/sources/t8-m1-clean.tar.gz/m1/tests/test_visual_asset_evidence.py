from __future__ import annotations

import asyncio
import base64
import hashlib
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZIP_DEFLATED, ZipFile

import fitz
import pytest

from m1.documents.models import SourceReference
from m1.documents.parsing.evidence import (
    DocumentEvidence,
    EvidenceBlock,
    EvidenceCell,
    EvidencePage,
    EvidenceTable,
)
from m1.documents.parsing.source_asset_inventory import (
    SourceAsset,
    SourceAssetInventory,
    SourceAssetReference,
    inventory_source_assets,
)
from m1.documents.parsing.visual_asset_evidence import (
    VisualAssetEvidenceError,
    enrich_visual_asset_evidence,
)

PIXEL = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+"
    "A8AAQUBAScY42YAAAAASUVORK5CYII="
)


def _base_evidence() -> DocumentEvidence:
    return DocumentEvidence(
        backend="base",
        pages=[
            EvidencePage(
                page_number=1,
                page_index=0,
                width=200,
                height=100,
                blocks=[EvidenceBlock(block_id="base-block", text="base")],
            )
        ],
        raw={"base": True},
    )


def _asset(
    payload: bytes,
    *,
    parts: list[str],
    source_refs: list[SourceAssetReference] | None = None,
) -> SourceAsset:
    digest = hashlib.sha256(payload).hexdigest()
    return SourceAsset(
        asset_id=f"asset:sha256:{digest}",
        sha256=digest,
        mime_type="image/png",
        byte_size=len(payload),
        parts=sorted(parts),
        source_refs=source_refs or [],
        coverage_status=(
            "inventoried_referenced"
            if source_refs
            else "inventoried_unreferenced"
        ),
    )


def _inventory(
    source: Path,
    *,
    source_kind: str,
    assets: list[SourceAsset],
) -> SourceAssetInventory:
    payload = source.read_bytes()
    return SourceAssetInventory(
        source_kind=source_kind,
        source_name=source.name,
        source_sha256=hashlib.sha256(payload).hexdigest(),
        source_byte_size=len(payload),
        assets=assets,
        coverage_status="complete",
    )


def _package(path: Path, parts: dict[str, bytes]) -> None:
    with ZipFile(path, "w", ZIP_DEFLATED) as package:
        for name, payload in parts.items():
            package.writestr(name, payload)


class FakeAssetParser:
    def __init__(
        self,
        *,
        failures: set[bytes] | None = None,
        delays: dict[bytes, float] | None = None,
        wrapped: bool = False,
    ) -> None:
        self.failures = failures or set()
        self.delays = delays or {}
        self.wrapped = wrapped
        self.calls: list[bytes] = []
        self.paths: list[Path] = []
        self.original_filenames: list[str | None] = []
        self.active = 0
        self.max_active = 0

    async def parse(
        self,
        path: str | Path,
        *,
        original_filename: str | None = None,
    ):
        temporary_path = Path(path)
        payload = temporary_path.read_bytes()
        self.calls.append(payload)
        self.paths.append(temporary_path)
        self.original_filenames.append(original_filename)
        self.active += 1
        self.max_active = max(self.max_active, self.active)
        try:
            await asyncio.sleep(self.delays.get(payload, 0))
            if payload in self.failures:
                raise RuntimeError("sensitive provider detail")
            marker = hashlib.sha256(payload).hexdigest()[:8]
            evidence = DocumentEvidence(
                backend="fake-asset-parser",
                backend_version="1",
                pages=[
                    EvidencePage(
                        page_number=1,
                        page_index=0,
                        width=10,
                        height=20,
                        blocks=[
                            EvidenceBlock(
                                block_id="block-0",
                                text=marker,
                                source="fake",
                            )
                        ],
                        tables=[
                            EvidenceTable(
                                table_id="table-0",
                                rows=[[marker]],
                                cells=[
                                    EvidenceCell(row=0, column=0, text=marker)
                                ],
                                source="fake",
                            )
                        ],
                        raw={"provider": "fake"},
                    )
                ],
            )
            return SimpleNamespace(evidence=evidence) if self.wrapped else evidence
        finally:
            self.active -= 1


class FakeBatchAssetParser:
    def __init__(self, *, mode: str = "complete") -> None:
        self.mode = mode
        self.parse_calls = 0
        self.batch_calls: list[list[bytes]] = []
        self.paths: list[Path] = []
        self.original_filenames: list[str | None] = []

    async def parse(self, path, *, original_filename=None):
        del path, original_filename
        self.parse_calls += 1
        raise AssertionError("batch-capable parser must not use parse")

    async def parse_many(self, paths, *, original_filenames=None):
        materialized = [Path(path) for path in paths]
        payloads = [path.read_bytes() for path in materialized]
        self.batch_calls.append(payloads)
        self.paths.extend(materialized)
        self.original_filenames.extend(original_filenames or [])
        results = {}
        for index, (path, payload) in enumerate(
            zip(materialized, payloads, strict=True)
        ):
            if self.mode == "partial" and index == 1:
                results[path] = RuntimeError("private provider detail")
                continue
            if self.mode == "partial" and index == 2:
                continue
            marker = hashlib.sha256(payload).hexdigest()[:8]
            results[path] = DocumentEvidence(
                backend="fake-batch-parser",
                pages=[
                    EvidencePage(
                        page_number=1,
                        page_index=0,
                        width=10,
                        height=10,
                        blocks=[EvidenceBlock(block_id="b0", text=marker)],
                    )
                ],
            )
        return results


class ConfiguredBatchAssetParser(FakeBatchAssetParser):
    def __init__(self) -> None:
        super().__init__()
        self.concurrency = None
        self.timeout_seconds = None

    async def parse_many(
        self,
        paths,
        *,
        original_filenames=None,
        concurrency=1,
        timeout_seconds=None,
    ):
        self.concurrency = concurrency
        self.timeout_seconds = timeout_seconds
        return await super().parse_many(
            paths,
            original_filenames=original_filenames,
        )


class FakeParseBatchParser:
    def __init__(self) -> None:
        self.calls = 0

    async def parse(self, path, *, original_filename=None):
        del path, original_filename
        raise AssertionError("parse_batch must be preferred")

    async def parse_batch(self, paths, *, original_filenames=None):
        del original_filenames
        self.calls += 1
        return [
            DocumentEvidence(
                backend="fake-parse-batch",
                pages=[EvidencePage(page_number=1, page_index=0, width=1, height=1)],
            )
            for _path in paths
        ]


@pytest.mark.asyncio
async def test_docx_asset_is_parsed_once_and_all_occurrences_reach_every_level(
    tmp_path: Path,
) -> None:
    source = tmp_path / "assets.docx"
    _package(
        source,
        {
            "word/media/image1.png": PIXEL,
            "word/media/image2.png": PIXEL,
        },
    )
    references = [
        SourceAssetReference(
            source_ref=SourceReference(part="word/document.xml#paragraph:0"),
            relationship_id="rId1",
        ),
        SourceAssetReference(
            source_ref=SourceReference(part="word/document.xml#paragraph:2"),
            relationship_id="rId2",
        ),
    ]
    asset = _asset(
        PIXEL,
        parts=["word/media/image1.png", "word/media/image2.png"],
        source_refs=references,
    )
    inventory = _inventory(source, source_kind="docx", assets=[asset])
    parser = FakeAssetParser(wrapped=True)
    base = _base_evidence()

    result = await enrich_visual_asset_evidence(
        source,
        base,
        inventory,
        parser,
        max_assets=10,
        max_asset_bytes=1024,
        timeout_seconds=1,
    )

    assert len(parser.calls) == 1
    assert hashlib.sha256(parser.calls[0]).hexdigest() == inventory.assets[0].sha256
    assert len(parser.calls[0]) == inventory.assets[0].byte_size
    assert len(result.pages) == 2
    assert len(base.pages) == 1
    page = result.pages[1]
    assert (page.page_number, page.page_index) == (2, 1)
    assert page.asset_parser_page_number == 1
    assert page.asset_parser_page_index == 0
    assert page.asset_sha256 == asset.sha256
    assert page.asset_parts == asset.parts
    assert len(page.asset_source_refs) == 2
    assert page.blocks[0].block_id == f"asset:{asset.sha256}/p0/block-0"
    assert page.tables[0].table_id == f"asset:{asset.sha256}/p0/table-0"
    assert page.tables[0].cells[0].asset_cell_id.endswith("/cell:0:0:0")
    for item in (page.blocks[0], page.tables[0], page.tables[0].cells[0]):
        assert item.asset_id == asset.asset_id
        assert item.asset_parts == asset.parts
        assert len(item.asset_source_refs) == 2
    assert result.raw["source_asset_inventory"]["assets"][0]["sha256"] == asset.sha256
    assert result.raw["visual_asset_enrichment"]["success_count"] == 1
    assert all(not path.exists() for path in parser.paths)
    assert parser.original_filenames == [f"{asset.sha256}.png"]


@pytest.mark.asyncio
async def test_xlsx_assets_merge_in_inventory_order_not_completion_order(
    tmp_path: Path,
) -> None:
    source = tmp_path / "assets.xlsx"
    first, second = b"first-image", b"second-image"
    _package(
        source,
        {
            "xl/media/image1.png": first,
            "xl/media/image2.png": second,
        },
    )
    assets = [
        _asset(first, parts=["xl/media/image1.png"]),
        _asset(second, parts=["xl/media/image2.png"]),
    ]
    inventory = _inventory(source, source_kind="xlsx", assets=assets)
    parser = FakeAssetParser(delays={first: 0.03, second: 0})

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        inventory,
        parser,
        max_assets=10,
        max_asset_bytes=1024,
        timeout_seconds=1,
        concurrency=2,
    )

    assert parser.max_active == 2
    assert len(parser.calls) == 2
    assert [page.asset_sha256 for page in result.pages[1:]] == [
        asset.sha256 for asset in assets
    ]
    assert len({page.blocks[0].block_id for page in result.pages[1:]}) == 2
    assert len({page.tables[0].table_id for page in result.pages[1:]}) == 2


@pytest.mark.asyncio
async def test_batch_parser_runs_once_and_isolates_partial_results(
    tmp_path: Path,
) -> None:
    source = tmp_path / "batch.xlsx"
    payloads = [b"first", b"second", b"third"]
    parts = {
        f"xl/media/image{index}.png": payload
        for index, payload in enumerate(payloads, start=1)
    }
    _package(source, parts)
    assets = [
        _asset(
            payload,
            parts=[f"xl/media/image{index}.png"],
            source_refs=[
                SourceAssetReference(
                    source_ref=SourceReference(
                        part=f"xl/worksheets/sheet1.xml#cell:A{index}"
                    )
                )
            ],
        )
        for index, payload in enumerate(payloads, start=1)
    ]
    parser = FakeBatchAssetParser(mode="partial")

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        _inventory(source, source_kind="xlsx", assets=assets),
        parser,
        max_assets=3,
        max_asset_bytes=1024,
        timeout_seconds=1,
    )

    assert parser.parse_calls == 0
    assert parser.batch_calls == [payloads]
    assert all(not path.exists() for path in parser.paths)
    statuses = result.raw["visual_asset_enrichment"]["assets"]
    assert [item["status"] for item in statuses] == ["success", "failed", "failed"]
    assert statuses[1]["failure_type"] == "RuntimeError"
    assert statuses[2]["reason"] == "batch_result_missing"
    assert statuses[2]["failure_type"] == "BatchResultMissingError"
    assert statuses[0]["asset_source_refs"][0]["source_ref"]["part"].endswith(
        "#cell:A1"
    )
    assert len(result.pages) == 2
    assert all("private provider detail" not in warning for warning in result.warnings)


@pytest.mark.asyncio
async def test_parse_batch_alias_is_detected(tmp_path: Path) -> None:
    source = tmp_path / "alias.docx"
    _package(source, {"word/media/image.png": PIXEL})
    asset = _asset(PIXEL, parts=["word/media/image.png"])
    parser = FakeParseBatchParser()

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        _inventory(source, source_kind="docx", assets=[asset]),
        parser,
        max_assets=1,
        max_asset_bytes=1024,
        timeout_seconds=1,
    )

    assert parser.calls == 1
    assert result.raw["visual_asset_enrichment"]["success_count"] == 1


@pytest.mark.asyncio
async def test_batch_parser_receives_concurrency_and_internal_deadline(
    tmp_path: Path,
) -> None:
    source = tmp_path / "configured.docx"
    _package(source, {"word/media/image.png": PIXEL})
    asset = _asset(PIXEL, parts=["word/media/image.png"])
    parser = ConfiguredBatchAssetParser()

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        _inventory(source, source_kind="docx", assets=[asset]),
        parser,
        max_assets=1,
        max_asset_bytes=1024,
        timeout_seconds=1,
        concurrency=2,
    )

    assert parser.concurrency == 2
    assert 0 < parser.timeout_seconds < 1
    assert result.raw["visual_asset_enrichment"]["success_count"] == 1


@pytest.mark.asyncio
async def test_pdf_xref_asset_is_materialized_with_verified_bytes(
    tmp_path: Path,
) -> None:
    source = tmp_path / "asset.pdf"
    document = fitz.open()
    page = document.new_page(width=100, height=100)
    page.insert_image(fitz.Rect(10, 10, 30, 30), stream=PIXEL)
    document.save(source)
    document.close()
    inventory = inventory_source_assets(source)
    parser = FakeAssetParser()

    result = await enrich_visual_asset_evidence(
        source,
        DocumentEvidence(backend="pdf-base"),
        inventory,
        parser,
        max_assets=10,
        max_asset_bytes=1024 * 1024,
        timeout_seconds=1,
    )

    assert len(parser.calls) == 1
    assert hashlib.sha256(parser.calls[0]).hexdigest() == inventory.assets[0].sha256
    assert len(parser.calls[0]) == inventory.assets[0].byte_size
    assert result.pages[0].asset_source_refs[0]["source_ref"]["page"] == 1
    assert result.raw["visual_asset_enrichment"]["failed_count"] == 0


@pytest.mark.asyncio
async def test_parser_failure_keeps_manifest_base_and_other_asset_results(
    tmp_path: Path,
) -> None:
    source = tmp_path / "failure.xlsx"
    good, bad = b"good", b"bad"
    _package(
        source,
        {
            "xl/media/good.png": good,
            "xl/media/bad.png": bad,
        },
    )
    assets = [
        _asset(good, parts=["xl/media/good.png"]),
        _asset(bad, parts=["xl/media/bad.png"]),
    ]
    inventory = _inventory(source, source_kind="xlsx", assets=assets)
    parser = FakeAssetParser(failures={bad})

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        inventory,
        parser,
        max_assets=10,
        max_asset_bytes=1024,
        timeout_seconds=1,
    )

    enrichment = result.raw["visual_asset_enrichment"]
    assert enrichment["success_count"] == 1
    assert enrichment["failed_count"] == 1
    assert enrichment["asset_count"] == 2
    assert result.pages[0].blocks[0].text == "base"
    assert len(result.raw["source_asset_inventory"]["assets"]) == 2
    assert any("RuntimeError" in warning for warning in result.warnings)
    assert all(
        "sensitive provider detail" not in warning for warning in result.warnings
    )


@pytest.mark.asyncio
async def test_timeout_isolated_and_default_concurrency_is_one(tmp_path: Path) -> None:
    source = tmp_path / "timeout.xlsx"
    first, second = b"slow", b"fast"
    _package(
        source,
        {
            "xl/media/slow.png": first,
            "xl/media/fast.png": second,
        },
    )
    assets = [
        _asset(first, parts=["xl/media/slow.png"]),
        _asset(second, parts=["xl/media/fast.png"]),
    ]
    inventory = _inventory(source, source_kind="xlsx", assets=assets)
    parser = FakeAssetParser(delays={first: 0.2, second: 0})

    result = await enrich_visual_asset_evidence(
        source,
        DocumentEvidence(backend="base"),
        inventory,
        parser,
        max_assets=10,
        max_asset_bytes=1024,
        timeout_seconds=0.05,
    )

    statuses = result.raw["visual_asset_enrichment"]["assets"]
    assert parser.max_active == 1
    assert [item["status"] for item in statuses] == ["failed", "success"]
    assert statuses[0]["reason"] == "timeout"
    assert all(not path.exists() for path in parser.paths)


@pytest.mark.asyncio
async def test_non_batch_assets_share_one_absolute_timeout_budget(tmp_path: Path) -> None:
    source = tmp_path / "absolute-timeout.xlsx"
    payloads = [b"slow-1", b"slow-2", b"slow-3"]
    _package(
        source,
        {
            f"xl/media/image{index}.png": payload
            for index, payload in enumerate(payloads, start=1)
        },
    )
    assets = [
        _asset(payload, parts=[f"xl/media/image{index}.png"])
        for index, payload in enumerate(payloads, start=1)
    ]
    parser = FakeAssetParser(delays={payload: 0.2 for payload in payloads})

    started = asyncio.get_running_loop().time()
    result = await enrich_visual_asset_evidence(
        source,
        DocumentEvidence(backend="base"),
        _inventory(source, source_kind="xlsx", assets=assets),
        parser,
        max_assets=3,
        max_asset_bytes=1024,
        timeout_seconds=0.09,
        concurrency=1,
    )
    elapsed = asyncio.get_running_loop().time() - started

    assert elapsed < 0.18
    statuses = result.raw["visual_asset_enrichment"]["assets"]
    assert [item["reason"] for item in statuses] == ["timeout"] * 3


@pytest.mark.asyncio
async def test_asset_count_and_byte_limits_are_reported_without_parser_calls(
    tmp_path: Path,
) -> None:
    source = tmp_path / "limits.xlsx"
    oversized, accepted, beyond = b"0123456789", b"ok", b"later"
    _package(
        source,
        {
            "xl/media/oversized.png": oversized,
            "xl/media/accepted.png": accepted,
            "xl/media/beyond.png": beyond,
        },
    )
    assets = [
        _asset(oversized, parts=["xl/media/oversized.png"]),
        _asset(accepted, parts=["xl/media/accepted.png"]),
        _asset(beyond, parts=["xl/media/beyond.png"]),
    ]
    inventory = _inventory(source, source_kind="xlsx", assets=assets)
    parser = FakeAssetParser()

    result = await enrich_visual_asset_evidence(
        source,
        DocumentEvidence(backend="base"),
        inventory,
        parser,
        max_assets=2,
        max_asset_bytes=5,
        timeout_seconds=1,
    )

    assert parser.calls == [accepted]
    statuses = result.raw["visual_asset_enrichment"]["assets"]
    reasons = [
        item["reason"] if item["status"] == "skipped" else None
        for item in statuses
    ]
    assert reasons == [
        "max_asset_bytes",
        None,
        "max_assets",
    ]


@pytest.mark.asyncio
async def test_locator_failure_is_per_asset_and_does_not_escape(tmp_path: Path) -> None:
    source = tmp_path / "unsafe.docx"
    _package(source, {"word/media/real.png": PIXEL})
    asset = _asset(PIXEL, parts=["word/media/../real.png"])
    inventory = _inventory(source, source_kind="docx", assets=[asset])

    result = await enrich_visual_asset_evidence(
        source,
        _base_evidence(),
        inventory,
        FakeAssetParser(),
        max_assets=1,
        max_asset_bytes=1024,
        timeout_seconds=1,
    )

    status = result.raw["visual_asset_enrichment"]["assets"][0]
    assert status["status"] == "failed"
    assert status["failure_type"] == "VisualAssetEvidenceError"
    assert len(result.pages) == 1


@pytest.mark.asyncio
async def test_source_hash_mismatch_fails_before_parsing(tmp_path: Path) -> None:
    source = tmp_path / "changed.docx"
    _package(source, {"word/media/image.png": PIXEL})
    asset = _asset(PIXEL, parts=["word/media/image.png"])
    inventory = _inventory(source, source_kind="docx", assets=[asset])
    source.write_bytes(source.read_bytes() + b"changed")
    parser = FakeAssetParser()

    with pytest.raises(VisualAssetEvidenceError, match="byte size"):
        await enrich_visual_asset_evidence(
            source,
            DocumentEvidence(backend="base"),
            inventory,
            parser,
            max_assets=1,
            max_asset_bytes=1024,
            timeout_seconds=1,
        )

    assert parser.calls == []
