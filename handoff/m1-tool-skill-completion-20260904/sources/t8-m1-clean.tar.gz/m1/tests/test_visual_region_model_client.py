from __future__ import annotations

from types import SimpleNamespace

import pytest
from m1.documents.parsing.visual_region_model_client import (
    PydanticVisualRegionSelectorFactory,
    TextVisualRegionEmbeddingAdapter,
)
from m1.documents.parsing.visual_region_routing import (
    VisualGeometryAssessment,
    VisualGeometryReason,
    VisualRegionRole,
    VisualRegionRouter,
    VisualRegionSourceKind,
    VisualRegionTopology,
)
from pydantic import ValidationError


class _StructuredClient:
    def __init__(self, output) -> None:
        self.output = output
        self.calls = []

    async def run(self, output_type, **kwargs):
        self.calls.append((output_type, kwargs))
        return SimpleNamespace(output=self.output)


class _EmbeddingClient:
    model = "fixture-embedding"
    dimensions = 3

    def __init__(self) -> None:
        self.inputs = []

    async def embed_texts(self, texts):
        self.inputs.extend(texts)
        return [[1.0, 0.0, 0.0] for _text in texts]


def _request():
    topology = VisualRegionTopology(
        source_kind=VisualRegionSourceKind.SPREADSHEET_ANCHOR,
        overlaps_table_body=True,
    )
    request, _ranked = VisualRegionRouter().selection_request(
        geometry=VisualGeometryAssessment(
            reason=VisualGeometryReason.AMBIGUOUS_OVERLAP
        ),
        topology=topology,
        allowed_roles=(VisualRegionRole.PRODUCT, VisualRegionRole.CHART),
    )
    return request


@pytest.mark.asyncio
async def test_selector_binds_verified_pixels_but_returns_only_closed_index() -> None:
    client = _StructuredClient(
        {"action": "select_role", "role_index": 0, "confidence": 0.99}
    )
    selector = PydanticVisualRegionSelectorFactory(client).bind(
        image_bytes=b"verified-pixels",
        media_type="image/png",
    )

    choice = await selector.select(_request())

    assert choice.action == "select_role"
    assert choice.role_index == 0
    output_type, kwargs = client.calls[0]
    assert output_type.__name__ == "VisualRegionModelChoice"
    assert kwargs["request_limit"] == 1
    assert len(kwargs["images"]) == 1
    assert kwargs["images"][0].data == b"verified-pixels"
    assert "verified-pixels" not in kwargs["prompt"]
    assert "filename" not in kwargs["prompt"]


@pytest.mark.asyncio
async def test_selector_rejects_free_form_fact_even_with_valid_role_index() -> None:
    client = _StructuredClient(
        {
            "action": "select_role",
            "role_index": 0,
            "confidence": 0.99,
            "facts": {"product_code": "SECRET"},
        }
    )
    selector = PydanticVisualRegionSelectorFactory(client).bind(
        image_bytes=b"verified-pixels",
        media_type="image/png",
    )

    with pytest.raises(ValidationError):
        await selector.select(_request())


@pytest.mark.asyncio
async def test_topology_embedding_adapter_never_sends_pixels_or_filename() -> None:
    client = _EmbeddingClient()
    adapter = TextVisualRegionEmbeddingAdapter(client)
    topology = VisualRegionTopology(
        source_kind=VisualRegionSourceKind.SPREADSHEET_ANCHOR,
        overlaps_table_body=True,
    )

    vector = await adapter.embed_region(
        topology,
        image_bytes=b"private-image",
        media_type="image/png",
    )

    assert vector == [1.0, 0.0, 0.0]
    assert len(client.inputs) == 1
    assert "private-image" not in client.inputs[0]
    assert "filename" not in client.inputs[0]
