from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from alembic import command
from m1.documents.parsing.visual_region_routing import (
    VisualRegionCandidateProposal,
    VisualRegionExecutionObservation,
    VisualRegionRole,
    VisualRegionSourceKind,
    VisualRegionTopology,
)
from m1.knowledge.db_models_base import (
    IdempotencyConflictError,
    TenantBoundaryError,
)
from m1.knowledge.migrations.runner import _config
from m1.knowledge.schema import TenantRecord
from m1.knowledge.visual_region_db_models import (
    VisualRegionObservationRow,
    VisualRegionProfileRow,
)
from m1.knowledge.visual_region_repository import VisualRegionRepository
from m1.knowledge.visual_region_schema import (
    VisualRegionObservationOutcome,
    VisualRegionObservationRecord,
    VisualRegionProfileStatus,
)
from sqlalchemy import create_engine, inspect, update
from sqlalchemy.exc import IntegrityError


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _topology(
    source_kind: VisualRegionSourceKind = VisualRegionSourceKind.SPREADSHEET_ANCHOR,
) -> VisualRegionTopology:
    return VisualRegionTopology(
        source_kind=source_kind,
        overlaps_table_body=True,
        has_nearby_identifier_slot=True,
    )


def _proposal(
    tenant_id: str,
    *,
    role: VisualRegionRole = VisualRegionRole.PRODUCT,
    topology: VisualRegionTopology | None = None,
    vector: list[float] | None = None,
    asset_sha256: str | None = None,
) -> VisualRegionCandidateProposal:
    return VisualRegionCandidateProposal.build(
        tenant_id=tenant_id,
        asset_sha256=asset_sha256 or _hash("fixture-asset"),
        topology=topology or _topology(),
        role=role,
        embedding=vector or [1.0, *([0.0] * 1023)],
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        created_by="test-suite",
    )


async def _seed_successes(
    store: VisualRegionRepository,
    profile,
    *,
    task_names: tuple[str, ...] = ("task-1", "task-2", "task-3"),
) -> None:
    for index, task_name in enumerate(task_names):
        await store.record_visual_region_execution_observation(
            VisualRegionExecutionObservation(
                tenant_id=profile.tenant_id,
                profile_id=profile.profile_id,
                exact_fingerprint=profile.exact_fingerprint,
                task_reference_hash=_hash(task_name),
                outcome="success",
                validation_passed=True,
                reviewed_by=f"reviewer-{index}",
                review_note_sha256=_hash(f"note-{index}"),
            )
        )


@pytest.fixture
async def visual_store(tmp_path: Path):
    store = VisualRegionRepository(
        f"sqlite+aiosqlite:///{(tmp_path / 'visual-routes.db').as_posix()}"
    )
    await store.init()
    first = TenantRecord(tenant_key="tenant-a", display_name="Tenant A")
    second = TenantRecord(tenant_key="tenant-b", display_name="Tenant B")
    await store.create_tenant(first)
    await store.create_tenant(second)
    try:
        yield store, first, second
    finally:
        await store.close()


@pytest.mark.asyncio
async def test_new_candidate_is_idempotent_and_never_active(visual_store) -> None:
    store, tenant, _other = visual_store
    proposal = _proposal(tenant.tenant_id)

    created = await store.create_visual_region_candidate(proposal)
    replay = await store.create_visual_region_candidate(proposal)
    matches = await store.find_active_visual_region_cases(
        tenant.tenant_id,
        proposal.embedding,
        embedding_model=proposal.embedding_model,
        embedding_dimensions=proposal.embedding_dimensions,
        topology=proposal.topology,
        asset_sha256=proposal.asset_sha256,
        limit=5,
    )

    assert created.status is VisualRegionProfileStatus.CANDIDATE
    assert replay.profile_id == created.profile_id
    assert matches == []


@pytest.mark.asyncio
async def test_activation_requires_three_distinct_clean_reviewed_tasks(
    visual_store,
) -> None:
    store, tenant, _other = visual_store
    profile = await store.create_visual_region_candidate(_proposal(tenant.tenant_id))
    await _seed_successes(store, profile, task_names=("task-1", "task-2"))
    with pytest.raises(ValueError, match="at least three"):
        await store.activate_visual_region_profile(
            tenant.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="insufficient evidence",
            expected_observation_count=2,
            allowed_roles={VisualRegionRole.PRODUCT},
        )

    await store.record_visual_region_execution_observation(
        VisualRegionExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=profile.profile_id,
            exact_fingerprint=profile.exact_fingerprint,
            task_reference_hash=_hash("task-3"),
            outcome="success",
            validation_passed=True,
            reviewed_by="reviewer-3",
            review_note_sha256=_hash("note-3"),
        )
    )
    active = await store.activate_visual_region_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="three clean validations",
        expected_observation_count=3,
        allowed_roles={VisualRegionRole.PRODUCT},
    )

    assert active.status is VisualRegionProfileStatus.ACTIVE
    assert active.failure_count == 0


@pytest.mark.asyncio
async def test_duplicate_task_hashes_and_any_failure_block_activation(
    visual_store,
) -> None:
    store, tenant, _other = visual_store
    duplicate = await store.create_visual_region_candidate(
        _proposal(tenant.tenant_id, role=VisualRegionRole.CHART)
    )
    for index in range(3):
        await store.record_visual_region_observation(
            VisualRegionObservationRecord(
                observation_id=f"duplicate-{index}",
                tenant_id=tenant.tenant_id,
                profile_id=duplicate.profile_id,
                idempotency_key=f"duplicate-key-{index}",
                exact_fingerprint=duplicate.exact_fingerprint,
                task_reference_hash=_hash("same-task"),
                outcome=VisualRegionObservationOutcome.SUCCESS,
                validation_passed=True,
                reviewed_by="reviewer",
                review_note_sha256=_hash(f"note-{index}"),
            )
        )
    with pytest.raises(IdempotencyConflictError, match="distinct-tasks"):
        await store.activate_visual_region_profile(
            tenant.tenant_id,
            duplicate.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="duplicates must fail",
            expected_observation_count=3,
            allowed_roles={VisualRegionRole.CHART},
        )

    failed = await store.create_visual_region_candidate(
        _proposal(tenant.tenant_id, role=VisualRegionRole.STAMP)
    )
    await _seed_successes(store, failed)
    await store.record_visual_region_execution_observation(
        VisualRegionExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=failed.profile_id,
            exact_fingerprint=failed.exact_fingerprint,
            task_reference_hash=_hash("failed-task"),
            outcome="failure",
            validation_passed=False,
            error_code="wrong_role",
        )
    )
    with pytest.raises(IdempotencyConflictError, match="failures"):
        await store.activate_visual_region_profile(
            tenant.tenant_id,
            failed.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="failure must block",
            expected_observation_count=4,
            allowed_roles={VisualRegionRole.STAMP},
        )


@pytest.mark.asyncio
async def test_active_top_k_is_tenant_source_and_embedding_space_scoped(
    visual_store,
) -> None:
    store, tenant, other = visual_store
    vector = [1.0, *([0.0] * 1023)]
    first = await store.create_visual_region_candidate(
        _proposal(tenant.tenant_id, vector=vector)
    )
    foreign = await store.create_visual_region_candidate(
        _proposal(other.tenant_id, vector=vector)
    )
    office = await store.create_visual_region_candidate(
        _proposal(
            tenant.tenant_id,
            role=VisualRegionRole.ENGINEERING_DRAWING,
            topology=_topology(VisualRegionSourceKind.OFFICE_SHAPE),
            vector=vector,
        )
    )
    other_asset = await store.create_visual_region_candidate(
        _proposal(
            tenant.tenant_id,
            role=VisualRegionRole.CHART,
            vector=vector,
            asset_sha256=_hash("different-asset"),
        )
    )
    for profile in (first, foreign, office, other_asset):
        await _seed_successes(store, profile)
        await store.activate_visual_region_profile(
            profile.tenant_id,
            profile.profile_id,
            approved_by="approver",
            reviewed_by="reviewer",
            review_note="validated route",
            expected_observation_count=3,
            allowed_roles=set(VisualRegionRole),
        )

    matches = await store.find_active_visual_region_cases(
        tenant.tenant_id,
        vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        topology=_topology(),
        asset_sha256=first.asset_sha256,
        limit=5,
    )

    assert [(match.case_id, match.role) for match in matches] == [
        (first.profile_id, VisualRegionRole.PRODUCT)
    ]
    assert matches[0].active is True
    assert matches[0].vector_similarity == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_active_top_k_is_contract_revision_scoped(visual_store) -> None:
    store, tenant, _other = visual_store
    vector = [1.0, *([0.0] * 1023)]
    profile = await store.create_visual_region_candidate(
        _proposal(tenant.tenant_id, vector=vector)
    )
    await _seed_successes(store, profile)
    await store.activate_visual_region_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="validated route",
        expected_observation_count=3,
        allowed_roles=set(VisualRegionRole),
    )
    async with store.sessionmaker.begin() as session:
        await session.execute(
            update(VisualRegionProfileRow)
            .where(VisualRegionProfileRow.profile_id == profile.profile_id)
            .values(contract_revision="m1.visual-region.v0")
        )

    matches = await store.find_active_visual_region_cases(
        tenant.tenant_id,
        vector,
        embedding_model="test-embedding",
        embedding_dimensions=1024,
        topology=_topology(),
        asset_sha256=profile.asset_sha256,
        limit=5,
    )

    assert matches == []


@pytest.mark.asyncio
async def test_active_exact_lookup_is_fully_scoped_and_embedding_independent(
    visual_store,
) -> None:
    store, tenant, other = visual_store
    topology = _topology()
    profile = await store.create_visual_region_candidate(
        _proposal(tenant.tenant_id, topology=topology)
    )
    await _seed_successes(store, profile)
    active = await store.activate_visual_region_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="validated exact route",
        expected_observation_count=3,
        allowed_roles=set(VisualRegionRole),
    )
    async with store.sessionmaker.begin() as session:
        await session.execute(
            update(VisualRegionProfileRow)
            .where(VisualRegionProfileRow.profile_id == active.profile_id)
            .values(embedding=None, embedding_model="", embedding_dimensions=0)
        )

    found = await store.get_active_visual_region_case_by_fingerprint(
        tenant.tenant_id,
        topology.exact_fingerprint(),
        contract_revision=topology.contract_revision,
        source_kind=topology.source_kind,
        asset_sha256=active.asset_sha256,
    )

    assert found is not None
    assert found.case_id == active.profile_id
    assert found.tenant_id == tenant.tenant_id
    assert found.topology == topology
    assert found.role is VisualRegionRole.PRODUCT
    assert found.review_success_rate == 1.0

    incompatible_queries = (
        {"tenant_id": other.tenant_id},
        {"exact_fingerprint": _hash("different-topology")},
        {"contract_revision": "m1.visual-region.v0"},
        {"source_kind": VisualRegionSourceKind.OFFICE_SHAPE},
        {"asset_sha256": _hash("different-asset")},
    )
    defaults = {
        "tenant_id": tenant.tenant_id,
        "exact_fingerprint": topology.exact_fingerprint(),
        "contract_revision": topology.contract_revision,
        "source_kind": topology.source_kind,
        "asset_sha256": active.asset_sha256,
    }
    for override in incompatible_queries:
        query = {**defaults, **override}
        assert (
            await store.get_active_visual_region_case_by_fingerprint(
                query.pop("tenant_id"),
                query.pop("exact_fingerprint"),
                **query,
            )
            is None
        )


@pytest.mark.asyncio
async def test_failed_observation_atomically_deprecates_an_active_profile(
    visual_store,
) -> None:
    store, tenant, _other = visual_store
    proposal = _proposal(tenant.tenant_id)
    profile = await store.create_visual_region_candidate(proposal)
    await _seed_successes(store, profile)
    active = await store.activate_visual_region_profile(
        tenant.tenant_id,
        profile.profile_id,
        approved_by="approver",
        reviewed_by="reviewer",
        review_note="validated route",
        expected_observation_count=3,
        allowed_roles=set(VisualRegionRole),
    )

    await store.record_visual_region_execution_observation(
        VisualRegionExecutionObservation(
            tenant_id=tenant.tenant_id,
            profile_id=active.profile_id,
            exact_fingerprint=active.exact_fingerprint,
            task_reference_hash=_hash("failed-active-task"),
            outcome="failure",
            validation_passed=False,
            error_code="wrong_role",
        )
    )
    refreshed = await store.get_visual_region_profile(
        tenant.tenant_id,
        active.profile_id,
    )
    matches = await store.find_active_visual_region_cases(
        tenant.tenant_id,
        proposal.embedding,
        embedding_model=proposal.embedding_model,
        embedding_dimensions=proposal.embedding_dimensions,
        topology=proposal.topology,
        asset_sha256=proposal.asset_sha256,
        limit=5,
    )

    assert refreshed is not None
    assert refreshed.status is VisualRegionProfileStatus.DEPRECATED
    assert refreshed.failure_count == 1
    assert matches == []


@pytest.mark.asyncio
async def test_observation_is_idempotent_and_tenant_safe(visual_store) -> None:
    store, tenant, other = visual_store
    profile = await store.create_visual_region_candidate(_proposal(tenant.tenant_id))
    observation = VisualRegionObservationRecord(
        observation_id="visual-observation",
        tenant_id=tenant.tenant_id,
        profile_id=profile.profile_id,
        idempotency_key="visual-observation-key",
        exact_fingerprint=profile.exact_fingerprint,
        task_reference_hash=_hash("task-idempotent"),
        outcome=VisualRegionObservationOutcome.SUCCESS,
        validation_passed=True,
        reviewed_by="reviewer",
        review_note_sha256=_hash("reviewed"),
    )
    first = await store.record_visual_region_observation(observation)
    replay = await store.record_visual_region_observation(
        observation.model_copy(update={"observation_id": "replay-id"})
    )
    assert replay.observation_id == first.observation_id
    with pytest.raises(IdempotencyConflictError):
        await store.record_visual_region_observation(
            observation.model_copy(update={"latency_ms": 99})
        )
    with pytest.raises(TenantBoundaryError):
        await store.record_visual_region_observation(
            observation.model_copy(
                update={
                    "tenant_id": other.tenant_id,
                    "observation_id": "cross-tenant",
                    "idempotency_key": "cross-tenant",
                }
            )
        )


@pytest.mark.asyncio
async def test_composite_foreign_key_blocks_cross_tenant_direct_write(
    visual_store,
) -> None:
    store, tenant, other = visual_store
    profile = await store.create_visual_region_candidate(_proposal(tenant.tenant_id))
    with pytest.raises(IntegrityError):
        async with store.sessionmaker.begin() as session:
            session.add(
                VisualRegionObservationRow(
                    observation_id="invalid-fk",
                    tenant_id=other.tenant_id,
                    profile_id=profile.profile_id,
                    idempotency_key="invalid-fk",
                    exact_fingerprint=profile.exact_fingerprint,
                    task_reference_hash=_hash("cross-tenant"),
                    outcome="success",
                    validation_passed=True,
                    reviewed_by="reviewer",
                    review_note_sha256=_hash("reviewed"),
                    latency_ms=0,
                    error_code="",
                    observed_at=profile.created_at,
                )
            )


def test_visual_region_migration_round_trip_and_identifiers(tmp_path: Path) -> None:
    migration = __import__(
        "m1.knowledge.migrations.versions.0013_visual_region_routes",
        fromlist=["revision"],
    )
    assert migration.down_revision == "0012_field_semantic_routes"
    assert len(migration.revision) <= 32
    assert all(len(name) <= 63 for name in migration.POLICY_NAMES.values())
    assert len(migration.HNSW_INDEX) <= 63

    database = tmp_path / "visual-region-round-trip.db"
    engine = create_engine(f"sqlite:///{database.as_posix()}")
    try:
        with engine.begin() as connection:
            config = _config(connection)
            command.upgrade(config, migration.revision)
            schema = inspect(connection)
            assert {
                migration.PROFILE_TABLE,
                migration.OBSERVATION_TABLE,
            }.issubset(schema.get_table_names())
            assert {"contract_revision", "asset_sha256"} <= {
                column["name"] for column in schema.get_columns(migration.PROFILE_TABLE)
            }
            indexes = {
                index["name"]: index["column_names"]
                for index in schema.get_indexes(migration.PROFILE_TABLE)
            }
            assert indexes["ux_visual_region_profiles_active_fingerprint"] == [
                "tenant_id",
                "exact_fingerprint",
                "asset_sha256",
            ]
            command.downgrade(config, migration.down_revision)
            assert migration.PROFILE_TABLE not in inspect(connection).get_table_names()
            command.upgrade(config, migration.revision)
            assert migration.PROFILE_TABLE in inspect(connection).get_table_names()
    finally:
        engine.dispose()
