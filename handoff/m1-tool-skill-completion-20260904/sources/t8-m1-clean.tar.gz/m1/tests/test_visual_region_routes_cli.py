from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from types import SimpleNamespace

import pytest
from m1.documents.parsing.visual_region_routing import (
    VisualRegionRole,
    VisualRegionSourceKind,
)
from m1.state import TaskStatus

from m1 import visual_region_routes as cli


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _task_digest(tenant_id: str, task_id: str) -> str:
    return _digest(f"{tenant_id}\0{task_id}")


def _profile(*, status: str = "candidate", observations: int = 3):
    now = datetime(2026, 7, 28, 8, 0, tzinfo=UTC)
    return SimpleNamespace(
        profile_id="profile-1",
        tenant_id="tenant-a",
        profile_key="visual:spreadsheet_anchor:product:abcd",
        version=1,
        supersedes_profile_id=None,
        status=status,
        exact_fingerprint="a" * 64,
        asset_sha256="b" * 64,
        topology=SimpleNamespace(
            source_kind=VisualRegionSourceKind.SPREADSHEET_ANCHOR,
            contract_revision="m1.visual-region-routing.v1",
        ),
        role=VisualRegionRole.PRODUCT,
        embedding=[0.25] * 1024,
        embedding_model="visual-embedding-v1",
        embedding_dimensions=1024,
        observation_count=observations,
        success_count=observations,
        failure_count=0,
        created_by="visual-router",
        reviewed_by=None,
        reviewed_at=None,
        review_note="sensitive operator note",
        approved_by=None,
        approved_at=None,
        last_observed_at=now,
    )


class _Store:
    def __init__(self, _url: str):
        self.profile = _profile()
        self.events: list[tuple[str, object]] = []

    async def init(self):
        self.events.append(("init", True))

    async def close(self):
        self.events.append(("close", True))

    async def list_visual_region_profiles(self, tenant_id, *, status=None, limit=100):
        self.events.append(("list", (tenant_id, status, limit)))
        return [self.profile]

    async def get_visual_region_profile(self, tenant_id, profile_id):
        self.events.append(("get", (tenant_id, profile_id)))
        return self.profile

    async def record_visual_region_execution_observation(self, observation):
        self.events.append(("observe", observation))
        return SimpleNamespace(
            tenant_id=observation.tenant_id,
            profile_id=observation.profile_id,
            task_reference_hash=observation.task_reference_hash,
            outcome=observation.outcome,
            validation_passed=observation.validation_passed,
            reviewed_by=observation.reviewed_by,
            latency_ms=observation.latency_ms,
            error_code=observation.error_code,
        )

    async def activate_visual_region_profile(self, tenant_id, profile_id, **kwargs):
        self.events.append(("activate", (tenant_id, profile_id, kwargs)))
        return _profile(status="active")

    async def reject_visual_region_profile(self, tenant_id, profile_id, **kwargs):
        self.events.append(("reject", (tenant_id, profile_id, kwargs)))
        return _profile(status="rejected")

    async def deprecate_visual_region_profile(self, tenant_id, profile_id, **kwargs):
        self.events.append(("deprecate", (tenant_id, profile_id, kwargs)))
        return _profile(status="deprecated")


class _TaskStore:
    def __init__(self, _url: str, *, task=None):
        self.loaded: list[str] = []
        self.closed = False
        self.task = task or SimpleNamespace(
            tenant_id="tenant-a",
            status=TaskStatus.DONE,
            document={
                "schema_version": "m1.document.v2",
                "extraction": {
                    "metadata": {
                        "visual_region_routing": {
                            "decisions": {
                                "asset:1": {
                                    "action": "new_candidate",
                                    "candidate_profile_id": "profile-1",
                                }
                            }
                        }
                    }
                },
            },
        )

    async def load(self, task_id: str):
        self.loaded.append(task_id)
        return self.task

    async def close(self):
        self.closed = True


def _settings():
    return SimpleNamespace(
        resolved_knowledge_database_url="postgresql+asyncpg://knowledge",
        database_url="sqlite+aiosqlite:///tasks.db",
    )


def test_cli_requires_approval_and_review_metadata() -> None:
    parser = cli._parser()
    with pytest.raises(SystemExit):
        parser.parse_args(
            [
                "activate",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--approved-by",
                "approver-a",
            ]
        )


@pytest.mark.parametrize(
    "task_reference",
    [
        "a" * 32,
        "a" * 64,
        f"sha256:{'a' * 64}",
        f"SHA-256:{'a' * 64}",
        f"sha512={'a' * 128}",
        f"blake2b:{'a' * 128}",
    ],
)
def test_cli_rejects_prehashed_task_references(task_reference: str) -> None:
    parser = cli._parser()
    with pytest.raises(SystemExit):
        parser.parse_args(
            [
                "record-observation",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--task-id",
                task_reference,
                "--outcome",
                "success",
                "--reviewed-by",
                "reviewer-a",
                "--review-note",
                "checked",
            ]
        )


@pytest.mark.asyncio
async def test_list_and_get_return_bounded_profile_metadata(monkeypatch) -> None:
    store = _Store("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    monkeypatch.setattr(cli, "settings", _settings())

    listed = await cli._run(
        cli._parser().parse_args(["list", "--tenant-id", "tenant-a", "--limit", "10"])
    )
    fetched = await cli._run(
        cli._parser().parse_args(
            ["get", "--tenant-id", "tenant-a", "--profile-id", "profile-1"]
        )
    )

    assert listed["profiles"][0]["role"] == "product"
    assert fetched["profile"]["source_kind"] == "spreadsheet_anchor"
    assert fetched["profile"]["asset_sha256"] == "b" * 64
    assert "embedding" not in fetched["profile"]
    assert "review_note" not in fetched["profile"]
    assert ("list", ("tenant-a", None, 10)) in store.events


@pytest.mark.asyncio
async def test_observation_hashes_verified_raw_task_and_review_note(
    monkeypatch,
) -> None:
    route_store = _Store("unused")
    task_store = _TaskStore("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: route_store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    monkeypatch.setattr(cli, "settings", _settings())
    task_id = "M1-TASK-1001"
    review_note = "matched the product image against the final document"

    result = await cli._run(
        cli._parser().parse_args(
            [
                "record-observation",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--task-id",
                task_id,
                "--outcome",
                "success",
                "--reviewed-by",
                "reviewer-a",
                "--review-note",
                review_note,
                "--latency-ms",
                "42",
            ]
        )
    )

    observation = dict(route_store.events)["observe"]
    assert task_store.loaded == [task_id]
    assert observation.task_reference_hash == _task_digest("tenant-a", task_id)
    assert observation.review_note_sha256 == _digest(review_note)
    assert observation.validation_passed is True
    assert task_id not in str(result)
    assert review_note not in str(result)
    assert result["task_reference_hash"] == _task_digest("tenant-a", task_id)
    assert task_store.closed is True


def test_task_reference_hash_is_tenant_bound() -> None:
    task_id = "M1-TASK-SHARED"

    tenant_a = cli._task_hash("tenant-a", task_id)
    tenant_b = cli._task_hash("tenant-b", task_id)

    assert tenant_a == _task_digest("tenant-a", task_id)
    assert tenant_b == _task_digest("tenant-b", task_id)
    assert tenant_a != tenant_b
    assert task_id not in tenant_a


@pytest.mark.asyncio
async def test_success_observation_rejects_unrelated_final_task(monkeypatch) -> None:
    route_store = _Store("unused")
    task_store = _TaskStore(
        "unused",
        task=SimpleNamespace(
            tenant_id="tenant-a",
            status=TaskStatus.DONE,
            document={"schema_version": "m1.document.v2", "extraction": {}},
        ),
    )
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: route_store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    monkeypatch.setattr(cli, "settings", _settings())
    args = cli._parser().parse_args(
        [
            "record-observation",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "profile-1",
            "--task-id",
            "M1-TASK-UNRELATED",
            "--outcome",
            "success",
            "--reviewed-by",
            "reviewer-a",
            "--review-note",
            "checked",
        ]
    )

    with pytest.raises(ValueError, match="references the candidate profile"):
        await cli._record_observation(args)
    assert not any(event == "observe" for event, _payload in route_store.events)


@pytest.mark.asyncio
async def test_failed_observation_requires_error_code(monkeypatch) -> None:
    store = _Store("unused")
    task_store = _TaskStore("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    monkeypatch.setattr(cli, "settings", _settings())

    args = cli._parser().parse_args(
        [
            "record-observation",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "profile-1",
            "--task-id",
            "M1-TASK-1002",
            "--outcome",
            "failure",
            "--reviewed-by",
            "reviewer-a",
            "--review-note",
            "role mismatch",
        ]
    )
    with pytest.raises(ValueError, match="error code"):
        await cli._record_observation(args)


@pytest.mark.asyncio
async def test_observation_rejects_nonfinal_task(monkeypatch) -> None:
    store = _Store("unused")
    task_store = _TaskStore(
        "unused",
        task=SimpleNamespace(
            tenant_id="tenant-a",
            status=TaskStatus.NEEDS_REVIEW,
            document={"schema_version": "m1.document.v2"},
        ),
    )
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    monkeypatch.setattr(cli, "TaskStore", lambda _url: task_store)
    monkeypatch.setattr(cli, "settings", _settings())

    args = cli._parser().parse_args(
        [
            "record-observation",
            "--tenant-id",
            "tenant-a",
            "--profile-id",
            "profile-1",
            "--task-id",
            "M1-TASK-NEEDS-REVIEW",
            "--outcome",
            "success",
            "--reviewed-by",
            "reviewer-a",
            "--review-note",
            "not final yet",
        ]
    )
    with pytest.raises(ValueError, match="completed task"):
        await cli._record_observation(args)


@pytest.mark.asyncio
async def test_activation_uses_repository_counts_and_code_owned_roles(
    monkeypatch,
) -> None:
    store = _Store("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    monkeypatch.setattr(cli, "settings", _settings())

    result = await cli._run(
        cli._parser().parse_args(
            [
                "activate",
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--approved-by",
                "approver-a",
                "--reviewed-by",
                "reviewer-a",
                "--review-note",
                "three clean reviewed tasks",
            ]
        )
    )

    _event, (_tenant, _profile, kwargs) = next(
        item for item in store.events if item[0] == "activate"
    )
    assert result["status"] == "active"
    assert kwargs["expected_observation_count"] == 3
    assert set(kwargs["allowed_roles"]) == set(VisualRegionRole)
    assert kwargs["approved_by"] == "approver-a"
    assert kwargs["reviewed_by"] == "reviewer-a"
    assert kwargs["review_note"] == "three clean reviewed tasks"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("command", "event", "status"),
    [("reject", "reject", "rejected"), ("deprecate", "deprecate", "deprecated")],
)
async def test_terminal_mutations_require_and_forward_review_metadata(
    monkeypatch,
    command: str,
    event: str,
    status: str,
) -> None:
    store = _Store("unused")
    monkeypatch.setattr(cli, "KnowledgeStore", lambda _url: store)
    monkeypatch.setattr(cli, "settings", _settings())

    result = await cli._run(
        cli._parser().parse_args(
            [
                command,
                "--tenant-id",
                "tenant-a",
                "--profile-id",
                "profile-1",
                "--reviewed-by",
                "reviewer-a",
                "--review-note",
                "governance decision",
            ]
        )
    )

    _event, (_tenant, _profile, kwargs) = next(
        item for item in store.events if item[0] == event
    )
    assert result["status"] == status
    assert kwargs == {
        "reviewed_by": "reviewer-a",
        "review_note": "governance decision",
    }
