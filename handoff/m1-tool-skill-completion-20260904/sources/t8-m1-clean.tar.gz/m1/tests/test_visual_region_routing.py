from __future__ import annotations

import hashlib
from types import SimpleNamespace

import pytest
from m1.documents.parsing.document_routing_status import (
    DocumentRoutingDependencyError,
)
from m1.documents.parsing.visual_region_routing import (
    GovernedVisualRegionRoutingRuntime,
    VisualAreaBucket,
    VisualAspectBucket,
    VisualGeometryAssessment,
    VisualGeometryReason,
    VisualPositionBucket,
    VisualRegionExactCase,
    VisualRegionModelChoice,
    VisualRegionRole,
    VisualRegionRouter,
    VisualRegionRoutingDecision,
    VisualRegionRoutingPolicy,
    VisualRegionSimilarCase,
    VisualRegionSourceKind,
    VisualRegionTopology,
    visual_topology_similarity,
)
from pydantic import ValidationError

_ASSET_BYTES = b"verified-image"
_ASSET_SHA256 = hashlib.sha256(_ASSET_BYTES).hexdigest()
_OTHER_ASSET_SHA256 = hashlib.sha256(b"different-image").hexdigest()


def _topology(
    *, source_kind: VisualRegionSourceKind = VisualRegionSourceKind.PDF_FIGURE
) -> VisualRegionTopology:
    return VisualRegionTopology(
        source_kind=source_kind,
        horizontal_position=VisualPositionBucket.CENTER,
        vertical_position=VisualPositionBucket.CENTER,
        area_bucket=VisualAreaBucket.MEDIUM,
        aspect_bucket=VisualAspectBucket.LANDSCAPE,
        overlaps_text_block=True,
        has_nearby_identifier_slot=True,
    )


def _unresolved() -> VisualGeometryAssessment:
    return VisualGeometryAssessment(reason=VisualGeometryReason.AMBIGUOUS_OVERLAP)


def _case(
    case_id: str,
    *,
    role: VisualRegionRole = VisualRegionRole.ENGINEERING_DRAWING,
    vector: float | None = 0.98,
    geometry: float = 0.95,
    success: float = 1.0,
    source_kind: VisualRegionSourceKind = VisualRegionSourceKind.PDF_FIGURE,
    active: bool = True,
    asset_sha256: str = _ASSET_SHA256,
) -> VisualRegionSimilarCase:
    return VisualRegionSimilarCase(
        case_id=case_id,
        asset_sha256=asset_sha256,
        role=role,
        source_kind=source_kind,
        active=active,
        vector_similarity=vector,
        geometry_similarity=geometry,
        review_success_rate=success,
    )


def _exact_case(
    case_id: str = "exact-active-case",
    *,
    tenant_id: str = "tenant-a",
    topology: VisualRegionTopology | None = None,
    role: VisualRegionRole = VisualRegionRole.ENGINEERING_DRAWING,
    asset_sha256: str = _ASSET_SHA256,
) -> VisualRegionExactCase:
    exact_topology = topology or _topology()
    return VisualRegionExactCase(
        case_id=case_id,
        tenant_id=tenant_id,
        exact_fingerprint=exact_topology.exact_fingerprint(),
        asset_sha256=asset_sha256,
        topology=exact_topology,
        role=role,
        observation_count=3,
        success_count=3,
        failure_count=0,
        review_success_rate=1.0,
    )


class _Selector:
    def __init__(self, output) -> None:
        self.output = output
        self.requests = []

    async def select(self, request):
        self.requests.append(request)
        if isinstance(self.output, BaseException):
            raise self.output
        return self.output


@pytest.mark.asyncio
async def test_deterministic_geometry_has_absolute_priority_and_skips_model() -> None:
    selector = _Selector(AssertionError("resolved geometry must skip the model"))
    geometry = VisualGeometryAssessment(
        role=VisualRegionRole.DOCUMENT_HEADER,
        reason=VisualGeometryReason.BEFORE_TABLE_HEADER,
    )

    decision = await VisualRegionRouter().resolve_with_selector(
        geometry=geometry,
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        similar_cases=(_case("case-product", role=VisualRegionRole.PRODUCT),),
        selector=selector,
    )

    assert decision.action == "route"
    assert decision.role is VisualRegionRole.DOCUMENT_HEADER
    assert decision.reason == "deterministic_geometry"
    assert decision.model_used is False
    assert not selector.requests


def test_model_request_is_bounded_value_free_and_hides_case_identity() -> None:
    request, ranked = VisualRegionRouter().selection_request(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.CHART, VisualRegionRole.STAMP),
        similar_cases=(_case("opaque-case-secret"),),
        asset_sha256=_ASSET_SHA256,
    )

    payload = request.model_dump_json()
    assert [option.role_index for option in request.roles] == [0, 1]
    assert [option.candidate_index for option in request.candidates] == [0]
    assert ranked[0].case_id == "opaque-case-secret"
    assert "opaque-case-secret" not in payload
    assert "filename" not in payload
    assert "pixels" not in payload
    assert "source_text" not in payload


def test_topology_rejects_filename_pixels_and_free_form_source_content() -> None:
    base = _topology().model_dump()
    for forbidden in ("filename", "pixels", "source_text"):
        with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
            VisualRegionTopology.model_validate(
                {**base, forbidden: "confidential-value"},
                strict=True,
            )


def test_model_may_select_only_one_server_authorized_role() -> None:
    router = VisualRegionRouter()
    allowed = (VisualRegionRole.CHART, VisualRegionRole.STAMP)

    accepted = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=allowed,
        model_choice=VisualRegionModelChoice(
            action="select_role",
            role_index=1,
            confidence=0.96,
        ),
    )
    out_of_bounds = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=allowed,
        model_choice=VisualRegionModelChoice(
            action="select_role",
            role_index=8,
            confidence=0.99,
        ),
    )

    assert accepted.action == "new_candidate"
    assert accepted.role is None
    assert accepted.suggested_role is VisualRegionRole.STAMP
    assert accepted.reason == "model_role_proposed_candidate"
    assert out_of_bounds.action == "review"
    assert out_of_bounds.reason == "model_role_not_authorized"


def test_model_cannot_invent_a_role_candidate_identifier_or_fact() -> None:
    decision = VisualRegionRouter().resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        similar_cases=(_case("case-a"),),
        asset_sha256=_ASSET_SHA256,
        model_choice={
            "action": "select_role",
            "role_index": 0,
            "candidate_id": "invented-case",
            "role": "product",
            "facts": {"part_number": "SECRET-1"},
            "confidence": 0.99,
        },
    )

    assert decision.action == "review"
    assert decision.role is None
    assert decision.case_id is None
    assert decision.reason == "invalid_model_output"


def test_top_reviewed_case_can_be_reused_only_after_all_hard_gates() -> None:
    decision = VisualRegionRouter().resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.CHART,),
        similar_cases=(
            _case("case-drawing"),
            _case(
                "case-chart",
                role=VisualRegionRole.CHART,
                vector=0.72,
                geometry=0.70,
            ),
        ),
        asset_sha256=_ASSET_SHA256,
        model_choice=VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=0.94,
        ),
    )

    assert decision.action == "route"
    assert decision.role is VisualRegionRole.ENGINEERING_DRAWING
    assert decision.case_id == "case-drawing"
    assert decision.reason == "model_candidate_selected"
    assert decision.top_score >= 0.82
    assert decision.top1_top2_margin >= 0.08


@pytest.mark.parametrize(
    ("cases", "expected_reason"),
    [
        (
            (_case("weak", vector=0.70, geometry=0.70),),
            "candidate_score_below_threshold",
        ),
        (
            (
                _case("near-a", vector=0.96, geometry=0.96),
                _case("near-b", vector=0.95, geometry=0.95),
            ),
            "candidate_margin_below_threshold",
        ),
    ],
)
def test_candidate_score_and_margin_are_non_model_hard_gates(
    cases, expected_reason: str
) -> None:
    decision = VisualRegionRouter().resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
        similar_cases=cases,
        asset_sha256=_ASSET_SHA256,
        model_choice=VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=1.0,
        ),
    )

    assert decision.action == "review"
    assert decision.reason == expected_reason
    assert decision.role is None


def test_model_cannot_route_to_a_non_top_similar_case() -> None:
    decision = VisualRegionRouter().resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(),
        similar_cases=(
            _case("top", vector=0.99, geometry=0.99),
            _case("second", vector=0.90, geometry=0.90),
        ),
        asset_sha256=_ASSET_SHA256,
        model_choice=VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=1,
            confidence=0.99,
        ),
    )

    assert decision.action == "review"
    assert decision.reason == "model_candidate_not_top"


def test_only_active_source_compatible_cases_reach_the_model() -> None:
    request, ranked = VisualRegionRouter().selection_request(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(),
        similar_cases=(
            _case("active-compatible"),
            _case("inactive", active=False),
            _case("wrong-asset", asset_sha256=_OTHER_ASSET_SHA256),
            _case(
                "wrong-source",
                source_kind=VisualRegionSourceKind.SPREADSHEET_ANCHOR,
            ),
        ),
        asset_sha256=_ASSET_SHA256,
    )

    assert [item.case_id for item in ranked] == ["active-compatible"]
    assert len(request.candidates) == 1


@pytest.mark.asyncio
async def test_selector_failure_falls_back_to_review_without_a_role() -> None:
    selector = _Selector(TimeoutError("model unavailable"))

    decision = await VisualRegionRouter().resolve_with_selector(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        selector=selector,
    )

    assert decision.action == "review"
    assert decision.role is None
    assert decision.reason == "model_failure"
    assert decision.model_used is True
    assert len(selector.requests) == 1


@pytest.mark.asyncio
async def test_selector_is_not_called_without_any_closed_option() -> None:
    selector = _Selector(AssertionError("model must not run without options"))

    decision = await VisualRegionRouter().resolve_with_selector(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(),
        similar_cases=(),
        selector=selector,
    )

    assert decision.action == "review"
    assert decision.reason == "no_closed_options"
    assert decision.model_used is False
    assert not selector.requests


def test_review_and_new_candidate_never_create_a_fact_or_active_route() -> None:
    router = VisualRegionRouter()
    review = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.LOGO,),
        model_choice=VisualRegionModelChoice(action="review", confidence=0.10),
    )
    new_candidate = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.LOGO,),
        model_choice=VisualRegionModelChoice(
            action="new_candidate",
            confidence=0.95,
        ),
    )

    assert review.review_required is True
    assert review.role is None
    assert new_candidate.action == "new_candidate"
    assert new_candidate.candidate_observation_required is True
    assert new_candidate.role is None
    assert new_candidate.case_id is None


def test_decision_contract_rejects_a_direct_model_role_route() -> None:
    with pytest.raises(ValidationError, match="active reviewed case"):
        VisualRegionRoutingDecision(
            action="route",
            reason="model_role_proposed_candidate",
            role=VisualRegionRole.PRODUCT,
            geometry_reason=VisualGeometryReason.AMBIGUOUS_OVERLAP,
            model_used=True,
            model_confidence=0.99,
        )


def test_low_model_confidence_cannot_route_or_open_a_candidate() -> None:
    router = VisualRegionRouter()
    role = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        model_choice=VisualRegionModelChoice(
            action="select_role",
            role_index=0,
            confidence=0.89,
        ),
    )
    new_candidate = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        model_choice=VisualRegionModelChoice(
            action="new_candidate",
            confidence=0.84,
        ),
    )
    reused = router.resolve(
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(),
        similar_cases=(_case("high-score-case"),),
        asset_sha256=_ASSET_SHA256,
        model_choice=VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=0.84,
        ),
    )

    assert role.action == "review"
    assert role.reason == "model_role_confidence_below_threshold"
    assert new_candidate.action == "review"
    assert new_candidate.reason == "model_new_candidate_confidence_below_threshold"
    assert reused.action == "review"
    assert reused.reason == "model_candidate_confidence_below_threshold"


def test_policy_rejects_non_finite_or_inverted_hard_gates() -> None:
    with pytest.raises(ValidationError):
        VisualRegionRoutingPolicy(vector_weight=float("nan"))
    with pytest.raises(ValidationError, match="reuse threshold"):
        VisualRegionRoutingPolicy(
            candidate_request_min_score=0.80,
            candidate_reuse_min_score=0.70,
        )


class _RuntimeEmbedding:
    model = "fixture-embedding"
    dimensions = 3

    def __init__(self, failure: BaseException | None = None) -> None:
        self.failure = failure
        self.calls = []

    async def embed_region(self, topology, *, image_bytes, media_type):
        self.calls.append((topology, image_bytes, media_type))
        if self.failure is not None:
            raise self.failure
        return [1.0, 0.0, 0.0]


class _RuntimeStore:
    def __init__(
        self,
        *,
        cases=(),
        failure: BaseException | None = None,
        exact_case: VisualRegionExactCase | None = None,
        exact_failure: BaseException | None = None,
    ) -> None:
        self.cases = cases
        self.failure = failure
        self.exact_case = exact_case
        self.exact_failure = exact_failure
        self.exact_searches = []
        self.searches = []
        self.proposals = []
        self.observations = []

    async def get_active_visual_region_case_by_fingerprint(
        self, tenant_id, exact_fingerprint, **kwargs
    ):
        self.exact_searches.append((tenant_id, exact_fingerprint, kwargs))
        if self.exact_failure is not None:
            raise self.exact_failure
        return self.exact_case

    async def find_active_visual_region_cases(self, tenant_id, embedding, **kwargs):
        self.searches.append((tenant_id, embedding, kwargs))
        if self.failure is not None:
            raise self.failure
        return self.cases

    async def create_visual_region_candidate(self, record):
        self.proposals.append(record)
        return SimpleNamespace(
            profile_id="candidate-profile",
            exact_fingerprint=record.topology.exact_fingerprint(),
            asset_sha256=record.asset_sha256,
            status="candidate",
        )

    async def record_visual_region_execution_observation(self, record):
        self.observations.append(record)


class _RuntimeSelectorFactory:
    def __init__(self, output) -> None:
        self.output = output
        self.bindings = []
        self.requests = []

    def bind(self, *, image_bytes, media_type):
        self.bindings.append((image_bytes, media_type))
        owner = self

        class Bound:
            async def select(self, request):
                owner.requests.append(request)
                if isinstance(owner.output, BaseException):
                    raise owner.output
                return owner.output

        return Bound()


@pytest.mark.asyncio
async def test_governed_runtime_queries_active_top_k_only_after_unresolved() -> None:
    embedding = _RuntimeEmbedding()
    store = _RuntimeStore(cases=(_case("active-case"),))
    selector = _RuntimeSelectorFactory(
        VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=0.99,
        )
    )
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert decision.action == "route"
    assert decision.case_id == "active-case"
    assert decision.profile_id == "active-case"
    assert len(embedding.calls) == len(store.searches) == len(selector.requests) == 1
    assert store.searches[0][0] == "tenant-a"
    assert store.searches[0][2]["limit"] == 5
    assert store.searches[0][2]["asset_sha256"] == _ASSET_SHA256
    assert selector.bindings == [(_ASSET_BYTES, "image/png")]


@pytest.mark.asyncio
async def test_governed_runtime_reuses_exact_active_case_before_embedding() -> None:
    embedding = _RuntimeEmbedding(failure=AssertionError("embedding must not run"))
    store = _RuntimeStore(exact_case=_exact_case())
    selector = _RuntimeSelectorFactory(AssertionError("selector must not run"))
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert decision.action == "route"
    assert decision.reason == "exact_active_profile"
    assert decision.role is VisualRegionRole.ENGINEERING_DRAWING
    assert decision.profile_id == "exact-active-case"
    assert decision.asset_identity == "sha256_exact"
    assert decision.model_used is False
    assert len(store.exact_searches) == 1
    assert store.searches == []
    assert embedding.calls == []
    assert selector.bindings == []


@pytest.mark.asyncio
@pytest.mark.parametrize("dependency", ["embedding", "store", "model"])
async def test_exact_active_case_remains_reusable_while_advisory_circuit_is_open(
    dependency: str,
) -> None:
    store = _RuntimeStore(
        cases=(_case("approximate-case"),),
        failure=TimeoutError("vector lookup unavailable")
        if dependency == "store"
        else None,
    )
    embedding = _RuntimeEmbedding(
        failure=TimeoutError("embedding unavailable")
        if dependency == "embedding"
        else None
    )
    selector = _RuntimeSelectorFactory(
        TimeoutError("selector unavailable")
        if dependency == "model"
        else VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=0.99,
        )
    )
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
        circuit_failures=1,
        circuit_seconds=300,
    )
    arguments = {
        "tenant_id": "tenant-a",
        "geometry": _unresolved(),
        "topology": _topology(),
        "allowed_roles": (VisualRegionRole.ENGINEERING_DRAWING,),
        "image_bytes": _ASSET_BYTES,
        "media_type": "image/png",
        "asset_sha256": _ASSET_SHA256,
    }

    failed = await runtime.resolve(**arguments)
    store.exact_case = _exact_case()
    reused = await runtime.resolve(**arguments)

    assert failed.reason in {
        "embedding_failure",
        "candidate_store_failure",
        "model_failure",
    }
    assert reused.reason == "exact_active_profile"
    assert len(store.exact_searches) == 2


@pytest.mark.asyncio
async def test_governed_runtime_skips_all_external_calls_for_resolved_geometry() -> (
    None
):
    embedding = _RuntimeEmbedding()
    store = _RuntimeStore(failure=AssertionError("store must not run"))
    selector = _RuntimeSelectorFactory(AssertionError("selector must not run"))
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
    )
    geometry = VisualGeometryAssessment(
        role=VisualRegionRole.DOCUMENT_HEADER,
        reason=VisualGeometryReason.BEFORE_TABLE_HEADER,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=geometry,
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert decision.role is VisualRegionRole.DOCUMENT_HEADER
    assert embedding.calls == []
    assert store.searches == []
    assert selector.bindings == []


@pytest.mark.asyncio
@pytest.mark.parametrize("asset_sha256", [None, _OTHER_ASSET_SHA256])
async def test_unverified_asset_identity_skips_all_advisory_dependencies(
    asset_sha256: str | None,
) -> None:
    embedding = _RuntimeEmbedding(failure=AssertionError("embedding must not run"))
    store = _RuntimeStore(failure=AssertionError("store must not run"))
    selector = _RuntimeSelectorFactory(AssertionError("selector must not run"))
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=asset_sha256,
    )

    assert decision.action == "review"
    assert decision.reason == "asset_identity_unavailable"
    assert decision.role is None
    assert embedding.calls == []
    assert store.searches == []
    assert selector.bindings == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("embedding_failure", "store_failure", "reason"),
    [
        (TimeoutError("embedding"), None, "embedding_failure"),
        (None, TimeoutError("store"), "candidate_store_failure"),
    ],
)
async def test_governed_runtime_retrieval_failures_are_review_only(
    embedding_failure,
    store_failure,
    reason: str,
) -> None:
    runtime = GovernedVisualRegionRoutingRuntime(
        store=_RuntimeStore(failure=store_failure),
        embedding_provider=_RuntimeEmbedding(failure=embedding_failure),
        selector_factory=_RuntimeSelectorFactory(
            VisualRegionModelChoice(action="review", confidence=1.0)
        ),
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert decision.action == "review"
    assert decision.reason == reason
    assert decision.role is None


@pytest.mark.asyncio
@pytest.mark.parametrize("dependency", ["embedding", "store", "model"])
async def test_governed_runtime_opens_a_bounded_dependency_circuit(
    dependency: str,
) -> None:
    embedding = _RuntimeEmbedding(
        failure=TimeoutError("embedding") if dependency == "embedding" else None
    )
    store = _RuntimeStore(
        cases=(_case("active-case"),),
        failure=TimeoutError("store") if dependency == "store" else None,
    )
    selector = _RuntimeSelectorFactory(
        TimeoutError("model")
        if dependency == "model"
        else VisualRegionModelChoice(
            action="reuse_candidate",
            candidate_index=0,
            confidence=0.99,
        )
    )
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=embedding,
        selector_factory=selector,
        circuit_failures=3,
        circuit_seconds=300,
    )

    decisions = [
        await runtime.resolve(
            tenant_id="tenant-a",
            geometry=_unresolved(),
            topology=_topology(),
            allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
            image_bytes=_ASSET_BYTES,
            media_type="image/png",
            asset_sha256=_ASSET_SHA256,
        )
        for _ in range(3)
    ]
    calls_before_circuit = (
        len(embedding.calls),
        len(store.searches),
        len(selector.requests),
    )
    circuit_decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )
    snapshot = runtime.status_snapshot()

    assert all(decision.action == "review" for decision in decisions)
    assert circuit_decision.action == "review"
    assert circuit_decision.reason == "routing_circuit_open"
    assert circuit_decision.role is None
    assert (
        len(embedding.calls),
        len(store.searches),
        len(selector.requests),
    ) == calls_before_circuit
    assert snapshot["calls"] == 4
    assert snapshot["failures"] == 4
    assert snapshot["circuit_open"] is True
    assert snapshot["degraded"] is True
    assert snapshot["last_failure_at"] is not None
    assert snapshot["dependencies"][dependency]["circuit_open"] is True
    assert "filename" not in str(snapshot).casefold()
    assert "model output" not in str(snapshot).casefold()


@pytest.mark.asyncio
@pytest.mark.parametrize("dependency", ["embedding", "store", "model"])
async def test_required_runtime_fails_closed_on_dependency_failure(
    dependency: str,
) -> None:
    runtime = GovernedVisualRegionRoutingRuntime(
        store=_RuntimeStore(
            cases=(_case("active-case"),),
            failure=TimeoutError("private store detail")
            if dependency == "store"
            else None,
        ),
        embedding_provider=_RuntimeEmbedding(
            failure=TimeoutError("private embedding detail")
            if dependency == "embedding"
            else None
        ),
        selector_factory=_RuntimeSelectorFactory(
            TimeoutError("private model detail")
            if dependency == "model"
            else VisualRegionModelChoice(
                action="reuse_candidate", candidate_index=0, confidence=0.99
            )
        ),
        required=True,
    )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            tenant_id="tenant-a",
            geometry=_unresolved(),
            topology=_topology(),
            allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
            image_bytes=_ASSET_BYTES,
            media_type="image/png",
            asset_sha256=_ASSET_SHA256,
        )

    assert caught.value.dependency == dependency
    assert "private" not in str(caught.value)


@pytest.mark.asyncio
async def test_required_runtime_allows_normal_new_candidate() -> None:
    store = _RuntimeStore()
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=_RuntimeEmbedding(),
        selector_factory=_RuntimeSelectorFactory(
            VisualRegionModelChoice(action="select_role", role_index=0, confidence=0.99)
        ),
        required=True,
    )

    decision = await runtime.resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert decision.action == "new_candidate"
    assert decision.reason == "model_role_proposed_candidate"
    assert decision.role is None
    assert decision.candidate_profile_id == "candidate-profile"
    assert len(store.proposals) == 1
    assert store.proposals[0].role is VisualRegionRole.PRODUCT
    assert store.observations == []


@pytest.mark.asyncio
async def test_candidate_persistence_failure_reviews_or_fails_closed() -> None:
    class CandidateFailureStore(_RuntimeStore):
        async def create_visual_region_candidate(self, record):
            del record
            raise TimeoutError("private candidate detail")

    def runtime(*, required: bool):
        return GovernedVisualRegionRoutingRuntime(
            store=CandidateFailureStore(),
            embedding_provider=_RuntimeEmbedding(),
            selector_factory=_RuntimeSelectorFactory(
                VisualRegionModelChoice(
                    action="select_role", role_index=0, confidence=0.99
                )
            ),
            required=required,
        )

    optional = await runtime(required=False).resolve(
        tenant_id="tenant-a",
        geometry=_unresolved(),
        topology=_topology(),
        allowed_roles=(VisualRegionRole.PRODUCT,),
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )
    assert optional.action == "review"
    assert optional.reason == "candidate_store_failure"
    assert optional.candidate_profile_id is None

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime(required=True).resolve(
            tenant_id="tenant-a",
            geometry=_unresolved(),
            topology=_topology(),
            allowed_roles=(VisualRegionRole.PRODUCT,),
            image_bytes=_ASSET_BYTES,
            media_type="image/png",
            asset_sha256=_ASSET_SHA256,
        )
    assert caught.value.dependency == "store"
    assert "private" not in str(caught.value)


@pytest.mark.asyncio
async def test_required_runtime_fails_closed_after_model_circuit_opens() -> None:
    selector = _RuntimeSelectorFactory(TimeoutError("private model detail"))
    runtime = GovernedVisualRegionRoutingRuntime(
        store=_RuntimeStore(cases=(_case("active-case"),)),
        embedding_provider=_RuntimeEmbedding(),
        selector_factory=selector,
        required=True,
        circuit_failures=3,
    )
    for _index in range(3):
        with pytest.raises(DocumentRoutingDependencyError):
            await runtime.resolve(
                tenant_id="tenant-a",
                geometry=_unresolved(),
                topology=_topology(),
                allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
                image_bytes=_ASSET_BYTES,
                media_type="image/png",
                asset_sha256=_ASSET_SHA256,
            )

    with pytest.raises(DocumentRoutingDependencyError) as caught:
        await runtime.resolve(
            tenant_id="tenant-a",
            geometry=_unresolved(),
            topology=_topology(),
            allowed_roles=(VisualRegionRole.ENGINEERING_DRAWING,),
            image_bytes=_ASSET_BYTES,
            media_type="image/png",
            asset_sha256=_ASSET_SHA256,
        )

    assert caught.value.dependency == "model"
    assert caught.value.error_type == "CircuitOpen"
    assert len(selector.requests) == 3


@pytest.mark.asyncio
async def test_candidate_observation_is_explicit_and_remains_inactive() -> None:
    store = _RuntimeStore()
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=_RuntimeEmbedding(),
        selector_factory=None,
    )
    decision = VisualRegionRoutingDecision(
        action="new_candidate",
        reason="model_requested_new_candidate",
        geometry_reason=VisualGeometryReason.AMBIGUOUS_OVERLAP,
        model_used=True,
        model_confidence=0.99,
        candidate_observation_required=True,
    )

    profile = await runtime.observe_candidate(
        decision=decision,
        tenant_id="tenant-a",
        topology=_topology(),
        validated_role=VisualRegionRole.PRODUCT,
        task_reference_hash="a" * 64,
        reviewed_by="reviewer",
        review_note_sha256="b" * 64,
        image_bytes=_ASSET_BYTES,
        media_type="image/png",
        asset_sha256=_ASSET_SHA256,
    )

    assert profile.status == "candidate"
    assert len(store.proposals) == len(store.observations) == 1
    assert store.proposals[0].role is VisualRegionRole.PRODUCT
    assert store.observations[0].profile_id == "candidate-profile"


@pytest.mark.asyncio
async def test_candidate_observation_rejects_a_store_that_returns_active() -> None:
    class ActiveStore(_RuntimeStore):
        async def create_visual_region_candidate(self, record):
            self.proposals.append(record)
            return SimpleNamespace(
                profile_id="unsafe-active-profile",
                exact_fingerprint=record.topology.exact_fingerprint(),
                asset_sha256=record.asset_sha256,
                status="active",
                tenant_id=record.tenant_id,
                role=record.role,
            )

    store = ActiveStore()
    runtime = GovernedVisualRegionRoutingRuntime(
        store=store,
        embedding_provider=_RuntimeEmbedding(),
        selector_factory=None,
    )
    decision = VisualRegionRoutingDecision(
        action="new_candidate",
        reason="model_role_proposed_candidate",
        suggested_role=VisualRegionRole.PRODUCT,
        geometry_reason=VisualGeometryReason.AMBIGUOUS_OVERLAP,
        model_used=True,
        model_confidence=0.99,
        candidate_observation_required=True,
    )

    with pytest.raises(ValueError, match="non-candidate"):
        await runtime.observe_candidate(
            decision=decision,
            tenant_id="tenant-a",
            topology=_topology(),
            validated_role=VisualRegionRole.PRODUCT,
            task_reference_hash="a" * 64,
            reviewed_by="reviewer",
            review_note_sha256="b" * 64,
            image_bytes=_ASSET_BYTES,
            media_type="image/png",
            asset_sha256=_ASSET_SHA256,
        )

    assert len(store.proposals) == 1
    assert store.observations == []


def test_visual_topology_fingerprint_and_similarity_are_value_free() -> None:
    topology = _topology()
    changed = topology.model_copy(update={"overlaps_text_block": False})
    foreign = topology.model_copy(
        update={"source_kind": VisualRegionSourceKind.OFFICE_SHAPE}
    )

    assert len(topology.exact_fingerprint()) == 64
    assert "filename" not in topology.embedding_text()
    assert visual_topology_similarity(topology, topology) == pytest.approx(1.0)
    assert visual_topology_similarity(topology, changed) < 1.0
    assert visual_topology_similarity(topology, foreign) == 0.0
