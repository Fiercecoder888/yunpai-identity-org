from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from types import SimpleNamespace
from zipfile import ZIP_DEFLATED, ZipFile

import pytest
from m1.documents import (
    build_spreadsheet_document,
    build_spreadsheet_document_with_image_roles,
    find_table_regions,
    parse_spreadsheet_envelope,
)
from m1.documents.envelope import DocumentEnvelope, ImageAnchor, SheetEnvelope
from m1.documents.image_roles import route_unresolved_image_roles
from m1.documents.parsing.visual_region_routing import (
    GovernedVisualRegionRoutingRuntime,
    VisualGeometryReason,
    VisualRegionModelChoice,
    VisualRegionRole,
    VisualRegionRoutingDecision,
)


def _write_pixel(path: Path) -> None:
    path.write_bytes(_pixel_payload())


def _pixel_payload(*, variant: int = 0) -> bytes:
    return base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
    ) + (bytes([variant % 256]) if variant else b"")


def _visual_envelope(
    tmp_path: Path,
    *,
    entries: dict[str, bytes],
    anchors: list[tuple[str, str]],
) -> DocumentEnvelope:
    source = tmp_path / f"visual-assets-{len(list(tmp_path.iterdir()))}.xlsx"
    with ZipFile(source, "w", compression=ZIP_DEFLATED) as package:
        for part_name, payload in entries.items():
            package.writestr(part_name, payload)
    sheet = SheetEnvelope(name="Sheet1", max_row=12, max_column=12)
    for index, (part_name, media_type) in enumerate(anchors, start=1):
        payload = entries[part_name]
        sheet.images.append(
            ImageAnchor(
                image_id=f"Sheet1:image:{index}",
                sheet=sheet.name,
                part_name=part_name,
                media_type=media_type,
                sha256=hashlib.sha256(payload).hexdigest(),
                from_row=2,
                from_col=3,
                to_row=2,
                to_col=3,
            )
        )
    return DocumentEnvelope(
        path=source,
        original_filename=source.name,
        display_filename=source.name,
        sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        mime_type=("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        file_kind="xlsx",
        sheets=[sheet],
    )


def _add_image(sheet, path: Path, anchor: str) -> None:
    image_module = pytest.importorskip("openpyxl.drawing.image")
    image = image_module.Image(path)
    image.width = 40
    image.height = 24
    sheet.add_image(image, anchor)


def _workbook(tmp_path: Path, *, side_by_side: bool = False) -> Path:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "订单"
    headers = ["序号", "产品图片", "型号", "数量", "单位"]
    for column, value in enumerate(headers, start=1):
        sheet.cell(1, column, value)
    for column, value in enumerate([1, None, "LEFT-1", 2, "PCS"], start=1):
        sheet.cell(2, column, value)
    if side_by_side:
        for column, value in enumerate(headers, start=7):
            sheet.cell(1, column, value)
        for column, value in enumerate(
            [1, None, "RIGHT-1", 3, "PCS"],
            start=7,
        ):
            sheet.cell(2, column, value)
    pixel = tmp_path / "pixel.png"
    _write_pixel(pixel)
    # C2 is inside the left table body but outside its explicit image column B.
    # Existing geometry therefore keeps it unresolved.
    _add_image(sheet, pixel, "C2")
    source = tmp_path / ("并排表.xlsx" if side_by_side else "未知图片角色.xlsx")
    workbook.save(source)
    return source


class _ProductRuntime:
    def __init__(self, *, mode: str = "guarded") -> None:
        self.calls = []
        self.mode = mode

    async def resolve(self, **kwargs):
        self.calls.append(kwargs)
        assert kwargs["geometry"].resolved is False
        assert kwargs["tenant_id"] == "tenant-a"
        assert kwargs["image_bytes"].startswith(b"\x89PNG")
        assert kwargs["media_type"] == "image/png"
        assert (
            hashlib.sha256(kwargs["image_bytes"]).hexdigest() == kwargs["asset_sha256"]
        )
        return VisualRegionRoutingDecision(
            action="route",
            reason="model_candidate_selected",
            role=VisualRegionRole.PRODUCT,
            case_id="active-product-image-case",
            profile_id="active-product-image-case",
            geometry_reason=VisualGeometryReason.AMBIGUOUS_OVERLAP,
            model_used=True,
            model_confidence=0.99,
            asset_identity="sha256_exact",
        )


class _FailingRuntime:
    mode = "guarded"

    def __init__(self, *, required: bool) -> None:
        self.required = required

    async def resolve(self, **kwargs):
        del kwargs
        raise TimeoutError("private visual dependency detail")


class _TopologyEmbedding:
    model = "fixture-embedding"
    dimensions = 3

    async def embed_region(self, topology, *, image_bytes, media_type):
        del topology, image_bytes, media_type
        return [1.0, 0.0, 0.0]


class _NoActiveCaseStore:
    async def get_active_visual_region_case_by_fingerprint(self, *args, **kwargs):
        del args, kwargs

    async def find_active_visual_region_cases(self, *args, **kwargs):
        del args, kwargs
        return []

    async def create_visual_region_candidate(self, proposal):
        return SimpleNamespace(
            profile_id="candidate-product-image",
            exact_fingerprint=proposal.topology.exact_fingerprint(),
            asset_sha256=proposal.asset_sha256,
            status="candidate",
            tenant_id=proposal.tenant_id,
            role=proposal.role,
        )


class _SelectProductFactory:
    def bind(self, *, image_bytes, media_type):
        del image_bytes, media_type

        class _Selector:
            async def select(self, request):
                assert request.candidates == ()
                return VisualRegionModelChoice(
                    action="select_role",
                    role_index=next(
                        option.role_index
                        for option in request.roles
                        if option.role is VisualRegionRole.PRODUCT
                    ),
                    confidence=0.99,
                )

        return _Selector()


class _Store:
    def __init__(self) -> None:
        self.saved = []

    async def save(self, state) -> None:
        self.saved.append(state)


@pytest.mark.asyncio
async def test_unresolved_role_override_rebuilds_real_line_association(
    tmp_path: Path,
) -> None:
    source = _workbook(tmp_path)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]
    baseline = build_spreadsheet_document(envelope)
    image_id = envelope.sheets[0].images[0].image_id
    assert baseline.lines[0].image_refs == []
    assert "IMAGE_UNASSOCIATED" in {issue.code for issue in baseline.validation_issues}
    assert baseline.extraction["images"][0]["visual_role"] == "unresolved"

    runtime = _ProductRuntime()
    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=runtime,
    )
    rebuilt = build_spreadsheet_document_with_image_roles(
        envelope,
        image_role_overrides=routed.overrides,
    )

    assert len(runtime.calls) == 1
    assert rebuilt.lines[0].image_refs == [image_id]
    assert "IMAGE_UNASSOCIATED" not in {
        issue.code for issue in rebuilt.validation_issues
    }
    assert rebuilt.extraction["images"][0]["visual_role"] == "product"
    assert routed.audit_payload()["decisions"][image_id]["role"] == "product"


@pytest.mark.asyncio
async def test_role_override_never_selects_or_crosses_a_line_id(tmp_path: Path) -> None:
    source = _workbook(tmp_path, side_by_side=True)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]
    runtime = _ProductRuntime()
    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=runtime,
    )
    rebuilt = build_spreadsheet_document_with_image_roles(
        envelope,
        image_role_overrides=routed.overrides,
    )

    assert [line.model for line in rebuilt.lines] == ["LEFT-1", "RIGHT-1"]
    assert len(rebuilt.lines[0].image_refs) == 1
    assert rebuilt.lines[1].image_refs == []
    serialized_decision = next(iter(routed.decisions.values())).model_dump_json()
    assert "line_id" not in serialized_decision


@pytest.mark.asyncio
async def test_deterministic_product_image_never_calls_router(tmp_path: Path) -> None:
    openpyxl = pytest.importorskip("openpyxl")
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["序号", "产品图片", "型号", "数量", "单位"])
    sheet.append([1, None, "M-1", 2, "PCS"])
    pixel = tmp_path / "pixel.png"
    _write_pixel(pixel)
    _add_image(sheet, pixel, "B2")
    source = tmp_path / "确定性产品图.xlsx"
    workbook.save(source)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for current in envelope.sheets for region in find_table_regions(current)
    ]
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=runtime,
    )

    assert runtime.calls == []
    assert routed.overrides == {}
    assert routed.decisions == {}


@pytest.mark.asyncio
async def test_shadow_mode_records_decision_without_rebuilding_role(
    tmp_path: Path,
) -> None:
    source = _workbook(tmp_path)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]
    runtime = _ProductRuntime(mode="shadow")

    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=runtime,
    )
    unchanged = build_spreadsheet_document_with_image_roles(
        envelope,
        image_role_overrides=routed.overrides,
    )

    assert len(routed.decisions) == 1
    assert routed.overrides == {}
    assert routed.audit_payload()["mode"] == "shadow"
    assert unchanged.lines[0].image_refs == []
    assert "IMAGE_UNASSOCIATED" in {issue.code for issue in unchanged.validation_issues}


@pytest.mark.asyncio
async def test_optional_image_adapter_preserves_facts_and_records_failure(
    tmp_path: Path,
) -> None:
    source = _workbook(tmp_path)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]

    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=_FailingRuntime(required=False),
    )

    assert routed.overrides == {}
    assert routed.decisions == {}
    assert routed.audit_payload()["status"] == "degraded"
    assert set(routed.audit_payload()["failures"].values()) == {"TimeoutError"}


@pytest.mark.asyncio
async def test_required_image_adapter_propagates_runtime_failure(
    tmp_path: Path,
) -> None:
    source = _workbook(tmp_path)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]

    with pytest.raises(TimeoutError, match="private visual dependency detail"):
        await route_unresolved_image_roles(
            envelope,
            regions,
            tenant_id="tenant-a",
            runtime=_FailingRuntime(required=True),
        )


@pytest.mark.asyncio
async def test_model_role_without_active_case_cannot_override_document(
    tmp_path: Path,
) -> None:
    source = _workbook(tmp_path)
    envelope = parse_spreadsheet_envelope(source)
    regions = [
        region for sheet in envelope.sheets for region in find_table_regions(sheet)
    ]
    baseline = build_spreadsheet_document(envelope)
    runtime = GovernedVisualRegionRoutingRuntime(
        store=_NoActiveCaseStore(),
        embedding_provider=_TopologyEmbedding(),
        selector_factory=_SelectProductFactory(),
        mode="guarded",
    )

    routed = await route_unresolved_image_roles(
        envelope,
        regions,
        tenant_id="tenant-a",
        runtime=runtime,
    )
    rebuilt = build_spreadsheet_document_with_image_roles(
        envelope,
        image_role_overrides=routed.overrides,
    )
    decision = next(iter(routed.decisions.values()))

    assert decision.action == "new_candidate"
    assert decision.role is None
    assert decision.suggested_role is VisualRegionRole.PRODUCT
    assert decision.reason == "model_role_proposed_candidate"
    assert routed.overrides == {}
    assert rebuilt.model_dump(mode="json") == baseline.model_dump(mode="json")


@pytest.mark.asyncio
async def test_spreadsheet_visual_rejects_zip_bomb_before_reading(
    tmp_path: Path,
) -> None:
    payload = b"\x89PNG\r\n\x1a\n" + (b"0" * 256_000)
    part_name = "xl/media/bomb.png"
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: payload},
        anchors=[(part_name, "image/png")],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
    )

    assert runtime.calls == []
    assert routed.failures == {"Sheet1:image:1": "image_compression_ratio_exceeded"}
    assert routed.asset_bytes_read == 0


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("limit_name", "limit_value", "expected_code"),
    [
        ("max_image_bytes", 32, "image_uncompressed_size_exceeded"),
        ("max_compressed_image_bytes", 1, "image_compressed_size_exceeded"),
    ],
)
async def test_spreadsheet_visual_rejects_oversized_zip_metadata_before_reading(
    tmp_path: Path,
    limit_name: str,
    limit_value: int,
    expected_code: str,
) -> None:
    part_name = "xl/media/oversized.png"
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: _pixel_payload()},
        anchors=[(part_name, "image/png")],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
        **{limit_name: limit_value},
    )

    assert runtime.calls == []
    assert routed.failures == {"Sheet1:image:1": expected_code}
    assert routed.asset_bytes_read == 0


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("part_name", "media_type"),
    [
        ("xl/media/unsafe.svg", "image/svg+xml"),
        ("xl/media/unsafe.png", "application/octet-stream"),
        ("xl/media/unsafe.bin", "image/png"),
    ],
)
async def test_spreadsheet_visual_rejects_unsafe_mime_or_extension_before_reading(
    tmp_path: Path,
    part_name: str,
    media_type: str,
) -> None:
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: _pixel_payload()},
        anchors=[(part_name, media_type)],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
    )

    assert runtime.calls == []
    assert routed.failures == {"Sheet1:image:1": "unsafe_image_media_type"}
    assert routed.asset_bytes_read == 0


@pytest.mark.asyncio
async def test_spreadsheet_visual_rejects_image_magic_mismatch(
    tmp_path: Path,
) -> None:
    part_name = "xl/media/not-really-an-image.png"
    payload = b"<html>not an image</html>"
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: payload},
        anchors=[(part_name, "image/png")],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
    )

    assert runtime.calls == []
    assert routed.failures == {"Sheet1:image:1": "image_magic_mismatch"}
    assert routed.asset_bytes_read == len(payload)


@pytest.mark.asyncio
async def test_spreadsheet_visual_never_routes_an_unverified_asset_digest(
    tmp_path: Path,
) -> None:
    part_name = "xl/media/digest.png"
    payload = _pixel_payload()
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: payload},
        anchors=[(part_name, "image/png")],
    )
    envelope.sheets[0].images[0].sha256 = "0" * 64
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
    )

    assert runtime.calls == []
    assert routed.failures == {"Sheet1:image:1": "image_sha256_mismatch"}
    assert routed.asset_bytes_read == len(payload)


@pytest.mark.asyncio
async def test_spreadsheet_visual_reuses_only_digest_and_topology_matches(
    tmp_path: Path,
) -> None:
    first_part = "xl/media/first.png"
    second_part = "xl/media/second.png"
    first_payload = _pixel_payload()
    second_payload = _pixel_payload(variant=1)
    envelope = _visual_envelope(
        tmp_path,
        entries={first_part: first_payload, second_part: second_payload},
        anchors=[
            (first_part, "image/png"),
            (first_part, "image/png"),
            (second_part, "image/png"),
            (second_part, "image/png"),
        ],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
        max_total_image_bytes=len(first_payload) + len(second_payload),
    )

    assert len(runtime.calls) == 2
    assert len(routed.decisions) == 4
    assert routed.unique_signature_count == 2
    assert routed.reused_decision_count == 2
    assert routed.asset_bytes_read == len(first_payload) + len(second_payload)
    assert runtime.calls[0]["topology"] == runtime.calls[1]["topology"]
    assert runtime.calls[0]["asset_sha256"] != runtime.calls[1]["asset_sha256"]


@pytest.mark.asyncio
async def test_spreadsheet_visual_does_not_reuse_same_asset_across_topologies(
    tmp_path: Path,
) -> None:
    part_name = "xl/media/shared.png"
    payload = _pixel_payload()
    envelope = _visual_envelope(
        tmp_path,
        entries={part_name: payload},
        anchors=[(part_name, "image/png"), (part_name, "image/png")],
    )
    second = envelope.sheets[0].images[1]
    second.from_row = second.to_row = 11
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
        max_total_image_bytes=len(payload),
    )

    assert len(runtime.calls) == 2
    assert routed.unique_signature_count == 2
    assert routed.reused_decision_count == 0
    assert routed.asset_bytes_read == len(payload)
    assert runtime.calls[0]["asset_sha256"] == runtime.calls[1]["asset_sha256"]
    assert runtime.calls[0]["topology"] != runtime.calls[1]["topology"]


@pytest.mark.asyncio
async def test_spreadsheet_visual_enforces_total_read_budget(
    tmp_path: Path,
) -> None:
    first_part = "xl/media/first.png"
    second_part = "xl/media/second.png"
    first_payload = _pixel_payload()
    second_payload = _pixel_payload(variant=1)
    envelope = _visual_envelope(
        tmp_path,
        entries={first_part: first_payload, second_part: second_payload},
        anchors=[(first_part, "image/png"), (second_part, "image/png")],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
        max_total_image_bytes=len(first_payload),
    )

    assert len(runtime.calls) == 1
    assert routed.asset_bytes_read == len(first_payload)
    assert routed.failures == {"Sheet1:image:2": "image_total_read_budget_exceeded"}


@pytest.mark.asyncio
async def test_spreadsheet_visual_hard_caps_unique_signatures_at_sixteen(
    tmp_path: Path,
) -> None:
    entries = {
        f"xl/media/image-{index}.png": _pixel_payload(variant=index)
        for index in range(1, 18)
    }
    envelope = _visual_envelope(
        tmp_path,
        entries=entries,
        anchors=[(part_name, "image/png") for part_name in entries],
    )
    runtime = _ProductRuntime()

    routed = await route_unresolved_image_roles(
        envelope,
        [],
        tenant_id="tenant-a",
        runtime=runtime,
        max_images=64,
    )

    assert len(runtime.calls) == 16
    assert len(routed.decisions) == 16
    assert routed.unique_signature_count == 16
    assert routed.skipped_limit_count == 1
