from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import pytest

from m1.documents.models import DocumentRecord
from m1.documents.parsing.document_route_policy import DocumentRoutingResolution
from m1.documents.parsing.mineru_authority import MinerUAuthorityDecision
from m1.extractors.vlm_agent import VLMExtractor
from m1.knowledge import HybridSearchEngine, build_field_index_documents
from m1.knowledge.eligibility import knowledge_sync_eligibility
from m1.state import TaskState, TaskStatus
from m1.workflow.engine import WorkflowEngine


@pytest.mark.asyncio
async def test_full_mineru_runtime_failure_blocks_knowledge_projection(
    tmp_path,
) -> None:
    source = tmp_path / "failed-mineru.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class FailingRunner:
        authority_mode = "full"

        async def run_candidate(self, **_kwargs):
            raise RuntimeError("mineru sidecar unavailable")

    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=FailingRunner())
    engine._save = AsyncMock()
    engine._validation_stage = Mock(side_effect=lambda document, _native: document)
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="mineru-runtime-failure",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )

    await engine._run_mineru_full_pipeline(state)

    persisted = engine._knowledge_sync_stage.await_args.args[1]
    eligible, reason = knowledge_sync_eligibility(persisted)
    assert eligible is False
    assert reason == "MINERU_FULL_AUTHORITY_FAILED"
    assert persisted["header"] == {}
    assert persisted["lines"] == []


@pytest.mark.asyncio
async def test_full_mineru_candidate_bypasses_legacy_model_stages(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "accepted-mineru.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class Candidate:
        def model_dump(self, *, mode: str) -> dict:
            assert mode == "json"
            return {
                "schema_version": "m1.document.v2",
                "source": {"original_filename": source.name},
                "document_type": "technical_document",
                "document_subtype": "approval_drawing",
                "header": {},
                "lines": [],
                "totals": {},
                "field_meta": {},
                "validation_issues": [],
                "needs_review": False,
                "extraction": {"metadata": {}},
            }

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **_kwargs):
            return SimpleNamespace(document=Candidate(), summary={}, plan=None)

    class PostbuildRuntime:
        required = False
        max_regions_per_document = 16

        def __init__(self) -> None:
            self.calls = 0

        async def resolve(self, **_kwargs):
            self.calls += 1
            return SimpleNamespace(
                model_dump=lambda *, mode: {
                    "schema_version": "m1.content-region-routing-decision.v1",
                    "action": "new_candidate",
                    "reason": "selector_unavailable",
                    "role": None,
                    "strategy_id": None,
                    "profile_id": None,
                    "candidate_profile_id": "candidate-full-mineru",
                    "suggested_role": None,
                    "suggested_strategy_id": None,
                    "top_score": 0.0,
                    "selected_score": 0.0,
                    "model_used": False,
                    "model_confidence": None,
                    "review_required": False,
                }
            )

    decision = SimpleNamespace(accepted=True, summary=lambda: {"passed": True})
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: decision,
    )
    engine = object.__new__(WorkflowEngine)
    postbuild = PostbuildRuntime()
    engine.deps = SimpleNamespace(
        mineru_shadow_runner=FullRunner(),
        content_region_routing_runtime=postbuild,
    )
    engine._save = AsyncMock()
    engine._validation_stage = Mock(side_effect=lambda document, _native: document)
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="mineru-accepted",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )

    await engine._run_mineru_full_pipeline(state)

    engine._validation_stage.assert_called_once()
    persisted = engine._knowledge_sync_stage.await_args.args[1]
    assert persisted["extraction"]["metadata"]["adapter"] == "mineru_llm_full_authority"
    assert postbuild.calls == 1
    assert (
        persisted["extraction"]["metadata"]["adaptive_postbuild"]["invocation_count"]
        == 1
    )


@pytest.mark.asyncio
async def test_reviewable_full_mineru_candidate_keeps_facts_but_blocks_knowledge(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "reviewable-mineru.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")

    class Candidate:
        def model_dump(self, *, mode: str) -> dict:
            assert mode == "json"
            return {
                "schema_version": "m1.document.v2",
                "source": {"original_filename": source.name},
                "document_type": "technical_document",
                "document_subtype": "approval_drawing",
                "generic_facts": [
                    {
                        "name": "visual_identifier",
                        "value": "ZXQ-86420-VISUAL-ONLY",
                        "source_refs": [{"page": 1, "part": "word/media/image1.png"}],
                    }
                ],
                "header": {"title": "Cable assembly"},
                "lines": [
                    {
                        "line_id": "line-1",
                        "product_code": "CABLE-01",
                        "name_raw": "Cable assembly",
                    }
                ],
                "totals": {},
                "field_meta": {},
                "validation_issues": [],
                "needs_review": False,
                "extraction": {
                    "metadata": {"evidence_complete": False},
                    "raw_content": {"text_original": "Cable assembly"},
                },
            }

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **_kwargs):
            return SimpleNamespace(document=Candidate(), summary={})

    decision = MinerUAuthorityDecision(
        accepted=False,
        reasons=(
            "instructor_incomplete",
            "inconclusive_record_region_assessment",
            "missing_source_refs",
        ),
        missing_source_paths=("$.header.title",),
    )
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: decision,
    )

    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=FullRunner())
    engine._save = AsyncMock()
    engine._validation_stage = Mock(side_effect=lambda document, _native: document)
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="mineru-reviewable",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )

    await engine._run_mineru_full_pipeline(state)

    persisted = engine._knowledge_sync_stage.await_args.args[1]
    eligible, reason = knowledge_sync_eligibility(persisted)
    assert eligible is False
    assert reason == "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW"
    assert persisted["header"]["title"] == "Cable assembly"
    assert persisted["generic_facts"][0]["value"] == "ZXQ-86420-VISUAL-ONLY"
    assert persisted["lines"][0]["product_code"] == "CABLE-01"
    assert persisted["extraction"]["raw_content"]["text_original"] == "Cable assembly"
    assert persisted["needs_review"] is True
    assert persisted["validation_issues"][-1]["code"] == (
        "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW"
    )
    assert persisted["validation_issues"][-1]["severity"] == "warning"
    metadata = persisted["extraction"]["metadata"]
    assert metadata["authority_mode"] == "full"
    assert metadata["authority_selected"] is False
    assert metadata["authority_review_preserved"] is True
    assert metadata["knowledge_sync_eligible"] is False
    assert state.mineru_shadow["authority_review_preserved"] is True

    engine._apply_document_review(
        persisted,
        corrected_fields=None,
        header_corrections=None,
        line_corrections=None,
        issue_resolutions=None,
        reviewer="reviewer-1",
        comment="visual source checked",
        approve=True,
    )

    reviewed_metadata = persisted["extraction"]["metadata"]
    assert reviewed_metadata["authority_selected"] == "manual_review"
    assert reviewed_metadata["knowledge_sync_eligible"] is True
    assert "knowledge_sync_block_reason" not in reviewed_metadata
    assert persisted["generic_facts"][0]["value"] == "ZXQ-86420-VISUAL-ONLY"
    assert knowledge_sync_eligibility(persisted) == (True, "")

    indexed = build_field_index_documents(persisted, tenant_id="tenant-visual")
    hits = HybridSearchEngine(indexed).search(
        "ZXQ-86420-VISUAL-ONLY",
        tenant_id="tenant-visual",
    )
    assert hits
    assert hits[0].document.metadata["chunk_kind"] == "generic_fact"


@pytest.mark.asyncio
async def test_local_row_acceptance_rechecks_full_authority_gate(
    tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "order-with-summary-row.xlsx"
    source.write_bytes(b"placeholder")
    candidate = DocumentRecord.model_validate(
        {
            "source": {"original_filename": source.name},
            "document_type": "order",
            "document_subtype": "purchase_contract",
            "header": {"order_number": "PO-1"},
            "lines": [
                {
                    "line_id": "line-1",
                    "product_code": "SKU-1",
                    "quantity": 1,
                    "unit": "PCS",
                },
                {
                    "line_id": "summary",
                    "remark": "total",
                },
            ],
            "extraction": {
                "metadata": {
                    "adapter": "mineru_instructor",
                    "evidence_complete": True,
                }
            },
        }
    )

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **_kwargs):
            return SimpleNamespace(document=candidate, summary={})

    initial = MinerUAuthorityDecision(
        accepted=False,
        reasons=("invalid_domain_records", "invalid_business_lines"),
        invalid_line_paths=("$.lines[1]",),
    )
    accepted = MinerUAuthorityDecision(accepted=True, reasons=())
    evaluate = Mock(side_effect=[initial, accepted])
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        evaluate,
    )

    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(mineru_shadow_runner=FullRunner())
    engine._save = AsyncMock()
    engine._validation_stage = Mock(side_effect=lambda document, _native: document)
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="mineru-locally-accepted",
        file_path=str(source),
        original_filename=source.name,
        file_type="xlsx",
        status=TaskStatus.CREATED,
    )

    await engine._run_mineru_full_pipeline(state)

    persisted = engine._knowledge_sync_stage.await_args.args[1]
    assert [line["product_code"] for line in persisted["lines"]] == ["SKU-1"]
    assert persisted["extraction"]["metadata"]["authority_selected"] is True
    assert persisted["extraction"]["metadata"]["knowledge_sync_eligible"] is True
    assert state.mineru_shadow["authority_selected"] is True
    assert evaluate.call_count == 2
    rechecked = evaluate.call_args_list[1].args[0]
    assert rechecked.extraction["metadata"]["adapter"] == "mineru_instructor"


@pytest.mark.asyncio
async def test_full_mineru_observes_postparse_route_without_applying_it(
    tmp_path,
) -> None:
    source = tmp_path / "new-layout.pdf"
    source.write_bytes(b"%PDF-1.4\n%%EOF\n")
    route_calls: list[tuple[tuple, dict]] = []

    class Candidate:
        def model_dump(self, *, mode: str) -> dict:
            assert mode == "json"
            return {
                "schema_version": "m1.document.v2",
                "source": {"original_filename": source.name},
                "document_type": "technical_document",
                "document_subtype": "approval_drawing",
                "header": {"title": "Observed drawing"},
                "lines": [],
                "totals": {},
                "field_meta": {},
                "validation_issues": [],
                "needs_review": False,
                "extraction": {
                    "metadata": {
                        "structured_evidence": {
                            "pages": [{"page_number": 1, "blocks": []}]
                        }
                    }
                },
            }

    class FullRunner:
        authority_mode = "full"

        async def run_candidate(self, **_kwargs):
            return SimpleNamespace(document=Candidate(), summary={})

    class Runtime:
        required = False

        async def resolve(self, *args, **kwargs):
            route_calls.append((args, kwargs))
            return DocumentRoutingResolution(
                mode="shadow",
                recommendation="propose",
                reason="model_propose",
                signature_fingerprint="b" * 64,
                candidate_profile_id="candidate-new-layout",
                top_score=0.2,
                top1_top2_margin=0.2,
            )

    decision = SimpleNamespace(accepted=True, summary=lambda: {"passed": True})
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(
        "m1.documents.parsing.mineru_authority.evaluate_mineru_authority",
        lambda *_args, **_kwargs: decision,
    )
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(
        mineru_shadow_runner=FullRunner(),
        document_routing_runtime=Runtime(),
    )
    engine._save = AsyncMock()
    engine._validation_stage = Mock(side_effect=lambda document, _native: document)
    engine._knowledge_sync_stage = AsyncMock()
    state = TaskState(
        task_id="mineru-postparse-route",
        file_path=str(source),
        original_filename=source.name,
        file_type="pdf",
        status=TaskStatus.CREATED,
    )

    try:
        await engine._run_mineru_full_pipeline(state)
    finally:
        monkeypatch.undo()

    assert route_calls
    persisted = engine._knowledge_sync_stage.await_args.args[1]
    routing = persisted["extraction"]["metadata"]["adaptive_routing"]
    assert routing["candidate_profile_id"] == "candidate-new-layout"
    assert routing["advisory_only"] is True
    assert routing["policy_applied"] is False
    assert persisted["extraction"]["metadata"]["route_plan"]["policy_applied"] is False
    assert persisted["document_subtype"] == "approval_drawing"


def _review_status_document(
    *,
    issue_code: str = "MAPPER_AUDIT",
    issue_severity: str = "info",
    field_confidence: float | None = None,
    evidence_needs_review: int = 0,
) -> dict:
    field_metadata: dict[str, object] = {
        "source_refs": [{"page": 1, "part": "mineru/p1:b0"}],
    }
    if field_confidence is not None:
        field_metadata["confidence"] = field_confidence
    return DocumentRecord.model_validate(
        {
            "source": {"original_filename": "review-status.pdf"},
            "document_type": "technical_document",
            "document_subtype": "engineering_drawing",
            "header": {"title": "Cable drawing"},
            "lines": [
                {
                    "line_id": "line-1",
                    "product_code": "CABLE-01",
                    "name_raw": "Cable drawing",
                    "name_normalized": "Cable drawing",
                }
            ],
            # The full-authority gate owns citation completeness.  The legacy
            # projection has no separate confidence entry for name_normalized
            # and therefore assigns its synthetic 0.85 compatibility score.
            "field_meta": {"$.header.title": field_metadata},
            "validation_issues": [
                {
                    "code": issue_code,
                    "severity": issue_severity,
                    "message": "evidence mapping audited",
                }
            ],
            "extraction": {
                "metadata": {
                    "authority_mode": "full",
                    "authority_selected": True,
                    "evidence_complete": True,
                    "accounted_complete": True,
                    "retained_complete": True,
                    "evidence_unresolved_count": 0,
                },
                "raw_content": {
                    "text_original": "Cable drawing",
                    "semantic_completeness_audit": {
                        "schema_version": "m1.semantic-completion.v1",
                        "counts": {
                            "evidence_total": 2,
                            "evidence_accounted": 2,
                            "source_evidence_ambiguous": 0,
                            "source_evidence_needs_review": evidence_needs_review,
                            "evidence_needs_review": evidence_needs_review,
                            "evidence_ambiguous": 0,
                        },
                        "review_required": False,
                    },
                }
            },
        }
    ).model_dump(mode="json")


def _review_status_engine() -> WorkflowEngine:
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(confidence_threshold=0.9)
    engine.store = SimpleNamespace(save_document=AsyncMock())
    engine._save = AsyncMock()
    return engine


def _review_status_state(*, located: int = 2, total: int = 2) -> TaskState:
    return TaskState(
        task_id="review-status",
        file_path="review-status.pdf",
        original_filename="review-status.pdf",
        file_type="pdf",
        status=TaskStatus.CREATED,
        mineru_shadow={
            "authority_selected": True,
            "authority_gate": {
                "passed": True,
                "missing_source_paths": [],
                "invalid_line_paths": [],
                "lost_baseline_paths": [],
                "mismatched_baseline_paths": [],
            },
            "source_reference_coverage": {
                "located": located,
                "total": total,
                "ratio": located / total,
            },
        },
    )


@pytest.mark.asyncio
async def test_info_only_full_authority_result_is_not_reopened_by_legacy_score(
) -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    document = engine._validation_stage(_review_status_document(), {})

    assert document["review_assessment"]["requires_review"] is False
    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.DONE
    assert state.processing_stage == "completed"
    assert state.document["needs_review"] is False
    assert state.scored_result.needs_review is False
    assert state.scored_result.review_status == "auto_approved"
    semantic = next(
        field
        for field in state.scored_result.fields
        if field.name.endswith(".name_normalized")
    )
    assert semantic.confidence == pytest.approx(0.85)
    assert semantic.needs_review is False
    assert not any(
        field.name.startswith("validation.issue.")
        for field in state.scored_result.fields
    )


@pytest.mark.asyncio
async def test_repaired_35b_classification_can_finish_full_authority_workflow() -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    document = engine._validation_stage(
        _review_status_document(
            issue_code=(
                "MINERU_INSTRUCTOR_DOCUMENT_CLASSIFICATION_CONSISTENCY_REPAIR"
            )
        ),
        {},
    )

    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.DONE
    assert state.processing_stage == "completed"
    assert state.scored_result.review_status == "auto_approved"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "audit_defect",
    ["missing", "wrong_schema", "missing_review_flag", "incomplete_counts", "mismatch"],
)
async def test_incomplete_semantic_audit_keeps_legacy_review_gate(
    audit_defect: str,
) -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    payload = _review_status_document()
    raw_content = payload["extraction"]["raw_content"]
    audit = raw_content["semantic_completeness_audit"]
    if audit_defect == "missing":
        raw_content.pop("semantic_completeness_audit")
    elif audit_defect == "wrong_schema":
        audit["schema_version"] = "m1.semantic-completion.invalid"
    elif audit_defect == "missing_review_flag":
        audit.pop("review_required")
    elif audit_defect == "incomplete_counts":
        audit["counts"].pop("source_evidence_needs_review")
    else:
        audit["counts"]["evidence_accounted"] = 1
    document = engine._validation_stage(payload, {})

    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.review_status == "needs_review"


@pytest.mark.asyncio
async def test_warning_full_authority_result_still_requires_review() -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    document = engine._validation_stage(
        _review_status_document(issue_severity="warning"),
        {},
    )

    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.needs_review is True
    assert state.scored_result.review_status == "needs_review"
    assert any(
        field.name == "validation.issue.0.MAPPER_AUDIT" and field.needs_review
        for field in state.scored_result.fields
    )


@pytest.mark.asyncio
async def test_missing_identifier_authority_gate_still_requires_review() -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    state.mineru_shadow["authority_selected"] = False
    state.mineru_shadow["authority_gate"] = {
        "passed": False,
        "reasons": ["missing_order_identifier"],
        "missing_source_paths": [],
        "invalid_line_paths": [],
        "lost_baseline_paths": [],
        "mismatched_baseline_paths": [],
    }
    document = _review_status_document(issue_severity="warning")
    document["validation_issues"][0].update(
        {
            "code": "MINERU_FULL_AUTHORITY_REQUIRES_REVIEW",
            "message": "missing_order_identifier",
        }
    )
    document = engine._validation_stage(document, {})

    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.needs_review is True


@pytest.mark.asyncio
async def test_incomplete_authority_evidence_keeps_legacy_review_gate() -> None:
    engine = _review_status_engine()
    state = _review_status_state(located=1, total=2)
    document = engine._validation_stage(_review_status_document(), {})

    assert document["review_assessment"]["requires_review"] is False
    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.needs_review is True


@pytest.mark.asyncio
async def test_unresolved_semantic_evidence_keeps_legacy_review_gate() -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    document = engine._validation_stage(
        _review_status_document(evidence_needs_review=1),
        {},
    )

    assert document["review_assessment"]["requires_review"] is False
    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.needs_review is True


@pytest.mark.asyncio
async def test_low_confidence_full_authority_field_still_requires_review() -> None:
    engine = _review_status_engine()
    state = _review_status_state()
    document = engine._validation_stage(
        _review_status_document(field_confidence=0.7),
        {},
    )

    assert "LOW_CONFIDENCE_FIELD" in {
        blocker["code"] for blocker in document["review_assessment"]["blockers"]
    }
    await engine._knowledge_sync_stage(state, document)

    assert state.status == TaskStatus.NEEDS_REVIEW
    assert state.document["needs_review"] is True
    assert state.scored_result.needs_review is True


@pytest.mark.asyncio
async def test_replication_uses_endpoint_config_with_pydantic_ai(monkeypatch) -> None:
    captured: dict[str, str] = {}

    class FakeReplicationExtractor:
        def __init__(self, api_key: str, base_url: str, model: str) -> None:
            captured.update(api_key=api_key, base_url=base_url, model=model)

        async def extract(self, file_path, *, doc_type: str) -> str:
            captured.update(file_path=str(file_path), doc_type=doc_type)
            return "report"

        async def close(self) -> None:
            captured["closed"] = "true"

    monkeypatch.setattr(
        "m1.extractors.replication.ReplicationExtractor", FakeReplicationExtractor
    )
    vlm = VLMExtractor(
        api_key="test-key",
        base_url="http://vllm.invalid/v1/",
        model="local-vlm",
        structured_backend="pydantic_ai",
    )
    engine = object.__new__(WorkflowEngine)
    engine.deps = SimpleNamespace(vlm_agent=vlm)
    engine.store = SimpleNamespace(
        load=AsyncMock(
            return_value=SimpleNamespace(file_path="document.pdf", doc_type="order")
        )
    )

    try:
        assert await engine.generate_replication("task-1") == "report"
    finally:
        await vlm.close()

    assert captured == {
        "api_key": "test-key",
        "base_url": "http://vllm.invalid/v1",
        "model": "local-vlm",
        "file_path": "document.pdf",
        "doc_type": "order",
        "closed": "true",
    }
