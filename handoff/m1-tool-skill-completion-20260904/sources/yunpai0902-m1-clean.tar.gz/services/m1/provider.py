"""M1 provider: parse known-format order document -> candidate -> order-fact."""
import csv, io, json, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import db

def parse_order_document(content, source_ref="r0-order-doc", product_code=None):
    """Parse the fixed R0 order CSV format. Returns order-candidate payload."""
    rows = list(csv.DictReader(io.StringIO(content)))
    if not rows:
        raise ValueError("empty order document")
    r = rows[0]
    for field in ("订单号", "产品名称", "数量", "单位", "交期"):
        if field not in r or not str(r.get(field, "")).strip():
            raise ValueError(f"order document missing field: {field}")
    code = product_code or str(r.get("产品编码", "")).strip() or "80806-129"
    lines = [{"line_no": i + 1,
              "product_code": code,
              "product_name": str(r["产品名称"]).strip(),
              "qty": str(r["数量"]).strip(),
              "uom": str(r["单位"]).strip(),
              "due_date": str(r["交期"]).strip(),
              "provenance": {"level": "SCANNED_REAL",
                             "source_refs": [source_ref],
                             "generator_version": "yunpai-r0-provider-v1"}}
             for i, r in enumerate(rows)]
    return {"order_no": str(rows[0]["订单号"]).strip(),
            "customer": "订单 CSV",
            "lines": lines,
            "provenance": {"level": "SCANNED_REAL", "source_refs": [source_ref],
                           "generator_version": "yunpai-r0-provider-v1"}}

def confirm_order_fact(task_id, candidate, actor="frontend-user"):
    payload = {"order_id": db.new_id("ord"),
               "order_no": candidate["order_no"],
               "customer": candidate["customer"],
               "lines": candidate["lines"],
               "revision": 1}
    _apply = db.apply_fact_tx("m1", task_id, payload["order_id"], "m1.order-fact",
                            "m1.confirm-order", f"m1:{payload['order_id']}",
                            db.checksum_of(payload), payload, actor_ref=actor)
    return {"payload": payload, "apply": _apply}


# ---------------------------------------------------------------------------
# T-099-M1: hardened 0826 CSV order parse -> candidate (no implicit defaults)
# ---------------------------------------------------------------------------
import datetime as _dt
from decimal import Decimal as _Decimal

UOMS = ("PCS", "SET", "KG", "G", "M", "MM", "ROLL", "BOX")


class OrderInputError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def parse_order_csv(content, source_ref, *, customer=None, product_code=None,
                    parser_version="yunpai-r0-csv-v1"):
    """0826 CSV -> (order-candidate, parse_report).

    No implicit defaults: missing required fields -> BLOCKED_INPUT; wrong
    units / illegal qty / duplicate or multi product / bad date -> INPUT_INVALID.
    The candidate is schema-conformant (m1.order-candidate.v1); the report
    records per-field source row / parser version / confidence.
    """
    from common import contracts as ctr
    from common import schema as c_schema
    if not customer:
        raise OrderInputError("BLOCKED_INPUT", "customer missing (no implicit default)")
    if isinstance(content, (bytes, bytearray)):
        try:
            content = bytes(content).decode("utf-8")
        except UnicodeDecodeError:
            raise OrderInputError("INPUT_INVALID", "file is not valid UTF-8 text")
    rows = list(csv.DictReader(io.StringIO(content)))
    if not rows:
        raise OrderInputError("INPUT_INVALID", "empty order document")
    required = ("订单号", "产品名称", "数量", "单位", "交期")
    order_no = None
    seen_products = set()
    lines = []
    fields = []
    for i, r in enumerate(rows, start=2):
        missing = [f for f in required if not str(r.get(f, "")).strip()]
        if missing:
            raise OrderInputError("BLOCKED_INPUT", "row %d missing fields %s" % (i, missing))
        row_no = str(r["订单号"]).strip()
        if order_no is None:
            order_no = row_no
        elif row_no != order_no:
            raise OrderInputError("INPUT_INVALID", "multi-order file not supported (%s vs %s)" % (order_no, row_no))
        qty_s = str(r["数量"]).strip()
        try:
            qty = _Decimal(qty_s)
        except Exception:
            raise OrderInputError("INPUT_INVALID", "row %d qty invalid: %s" % (i, qty_s))
        if qty <= 0:
            raise OrderInputError("INPUT_INVALID", "row %d qty not positive: %s" % (i, qty_s))
        uom = str(r["单位"]).strip()
        if uom not in UOMS:
            raise OrderInputError("INPUT_INVALID", "row %d uom invalid: %s" % (i, uom))
        due = str(r["交期"]).strip()
        try:
            _dt.date.fromisoformat(due)
        except Exception:
            raise OrderInputError("INPUT_INVALID", "row %d due_date invalid: %s" % (i, due))
        pc = str(r.get("产品编码", "")).strip() or (product_code or "")
        if not pc:
            raise OrderInputError("BLOCKED_INPUT", "row %d product_code missing (no implicit default)" % i)
        if pc in seen_products:
            raise OrderInputError("INPUT_INVALID", "row %d duplicate product %s" % (i, pc))
        seen_products.add(pc)
        if len(seen_products) > 1:
            raise OrderInputError("INPUT_INVALID", "multi-product order not supported")
        lines.append({
            "line_no": i,
            "product_code": pc,
            "qty": str(qty),
            "uom": uom,
            "due_date": due,
            "provenance": {"level": "SCANNED_REAL", "source_refs": [source_ref],
                           "generator_version": parser_version},
        })
        fields.append({
            "line_no": i,
            "fields": {f: {"row": i, "source_ref": source_ref, "confidence": 1.0}
                       for f in ("订单号", "产品名称", "产品编码", "数量", "单位", "交期")},
        })
    candidate = {
        "order_no": order_no,
        "customer": customer,
        "lines": lines,
        "source_refs": [source_ref],
        "extraction_evidence": {"parser_version": parser_version, "model_version": "none"},
        "provenance": {"level": "SCANNED_REAL", "source_refs": [source_ref],
                       "generator_version": parser_version},
    }
    c_schema.validate(candidate, ctr.schema_of("m1.order-candidate.v1"), ctr.schema_of)
    checksum = db.checksum_of(candidate)
    report = {"parser_version": parser_version, "checksum": checksum,
              "source_ref": source_ref, "row_count": len(rows), "fields": fields}
    return candidate, report


# ---------------------------------------------------------------------------
# T-099: real order PDF -> order-candidate (multi-line; no implicit defaults)
# ---------------------------------------------------------------------------
import re as _re

_UOM_MAP = {"条": "PCS", "根": "PCS", "个": "PCS", "米": "M", "卷": "ROLL", "盒": "BOX"}


def parse_order_pdf(content, source_ref, *, customer=None,
                    parser_version="yunpai-r0-order-pdf-v1"):
    """Real order PDF (pypdf text) -> (order-candidate, parse_report).

    Mirrors parse_order_csv hardening: customer is explicit (BLOCKED_INPUT if
    missing); missing 订单号码/交货日期/型号/数量 -> BLOCKED_INPUT; illegal
    qty/date -> INPUT_INVALID.  Multi-line orders ARE supported (unlike CSV);
    each line carries product_code/qty/uom/due_date.  The parse report records
    per-line source span + length + document customer for cross-check.
    """
    from common import contracts as ctr
    from common import schema as c_schema
    if not customer:
        raise OrderInputError("BLOCKED_INPUT", "customer missing (no implicit default)")
    if isinstance(content, str):
        content = content.encode("utf-8")
    import io as _io
    from pypdf import PdfReader
    try:
        reader = PdfReader(_io.BytesIO(bytes(content)))
        pages = [(p.extract_text() or "") for p in reader.pages]
    except Exception as e:
        raise OrderInputError("INPUT_INVALID", "not a readable PDF: %s" % e)
    text = "\n".join(pages)
    if not text.strip():
        raise OrderInputError("INPUT_INVALID", "PDF has no extractable text")

    # --- order-level fields (no implicit defaults) ---
    m = _re.search(r"订单号码[:：]\s*([A-Za-z0-9][A-Za-z0-9\-_/]*[A-Za-z0-9])", text)
    if not m:
        raise OrderInputError("BLOCKED_INPUT", "订单号码 not found in PDF")
    order_no = m.group(1).strip()
    m = _re.search(r"交货日期[:：]\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日", text)
    if not m:
        raise OrderInputError("BLOCKED_INPUT", "交货日期 not found in PDF")
    due = "%04d-%02d-%02d" % (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    doc_customer = None
    m = _re.search(r"^[ \t]*([^\n]{2,60}?)\s*\n?\s*采购合同", text, _re.M)
    if m:
        doc_customer = m.group(1).strip()

    # --- line items: 型号 + "N M足米 <qty> 条" ---
    lines = []
    fields = []
    model_re = _re.compile(r"(DZW-[A-Za-z0-9\-]+)")
    for mm in model_re.finditer(text):
        pc = mm.group(1)
        seg = text[mm.end():]
        lm = _re.search(r"(\d+(?:\.\d+)?)M足米\s*(\d+)\s*条", seg)
        if not lm:
            raise OrderInputError("BLOCKED_INPUT",
                                  "model %s missing length/qty (expect 'N M足米 <qty> 条')" % pc)
        length = lm.group(1) + "M"
        qty_s = lm.group(2)
        qty = int(qty_s)
        if qty <= 0:
            raise OrderInputError("INPUT_INVALID", "model %s qty not positive: %s" % (pc, qty_s))
        line_no = len(lines) + 1
        lines.append({
            "line_no": line_no,
            "product_code": pc,
            "qty": str(qty),
            "uom": "PCS",  # 条 -> PCS (mapped; recorded in report)
            "due_date": due,
            "provenance": {"level": "SCANNED_REAL", "source_refs": [source_ref],
                           "generator_version": parser_version},
        })
        fields.append({
            "line_no": line_no,
            "product_code": pc,
            "length": length,
            "uom_source": "条",
            "uom_mapped": "PCS",
            "qty_source": qty_s,
            "span": [mm.start(), mm.start() + len(seg[:lm.end()])],
            "confidence": 0.9,
        })
    if not lines:
        raise OrderInputError("BLOCKED_INPUT", "no order lines (DZW- 型号) found in PDF")
    candidate = {
        "order_no": order_no,
        "customer": customer,
        "lines": lines,
        "source_refs": [source_ref],
        "extraction_evidence": {"parser_version": parser_version, "model_version": "none"},
        "provenance": {"level": "SCANNED_REAL", "source_refs": [source_ref],
                       "generator_version": parser_version},
    }
    c_schema.validate(candidate, ctr.schema_of("m1.order-candidate.v1"), ctr.schema_of)
    checksum = db.checksum_of(candidate)
    report = {"parser_version": parser_version, "checksum": checksum,
              "source_ref": source_ref, "order_no": order_no,
              "document_customer": doc_customer, "due_date": due,
              "page_count": len(pages), "fields": fields}
    return candidate, report

