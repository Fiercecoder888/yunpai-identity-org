#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""M1 SOP extraction (Goal T-097): real PDF work-instruction -> sop-candidate.

Contract-bound PDF/parser path (pypdf, lightweight; MinerU is PENDING_G1_PROOF
and therefore not used).  Output is a *candidate* (non-authoritative): it is
stored with fact_type ``m1.sop-candidate`` and is never promoted to a business
fact.  Every extracted field carries page_ref + region (page MediaBox for this
document: glyph-level positions are not exposed by the text engine).  Missing
工时 (std_minutes) is preserved as absent -> M2 BLOCKED_INPUT (no defaults).
"""

import base64
import hashlib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import contracts as ctr
from common import db

try:
    from pypdf import PdfReader
except Exception as exc:  # pragma: no cover - environment probe
    PdfReader = None

SOURCE_ID = "SRC-REAL-HDTV-SOP-001"
PARSER_VERSION = "yunpai-r0-pdf-v1"
PDF_PATH = "/Users/murkydoubloon45/Desktop/yunpai.nosync/output/pdf/HDTV 作业指导书.pdf"
EXPECTED_PDF_SHA256 = "b279ce6a1045b8849d593f4657ac53b0e86b3ad7d9c33eec1f54efa277aa4f1c"

CANDIDATE_SCHEMA = "m1.sop-candidate.v1"
CANDIDATE_FACT_TYPE = "m1.sop-candidate"
COMMAND_ID = "m1.submit-sop-candidate"


class ParseError(Exception):
    pass


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_source(pdf_path):
    """Fail-closed admission: the real file must match the registered hash."""
    return _sha256_file(pdf_path) == EXPECTED_PDF_SHA256


def _schema(name):
    schema = ctr.schema_of(name)
    if schema is None:
        raise ParseError("SCHEMA_MISSING", "locked schema unavailable: %s" % name)
    return schema


def validate_schema(instance, schema, path="$", seen=None):
    """Recursive Draft-7 validation with $ref resolution (write boundary)."""
    if seen is None:
        seen = set()
    if "$ref" in schema:
        ref = schema["$ref"]
        if ref in seen:
            return
        validate_schema(instance, _schema(ref), path, seen | {ref})
        return
    if "const" in schema and instance != schema["const"]:
        raise ParseError("CONTRACT_INVALID", "%s: const mismatch" % path)
    if "enum" in schema and instance not in schema["enum"]:
        raise ParseError("CONTRACT_INVALID", "%s: outside enum" % path)
    typ = schema.get("type")
    if typ == "object":
        if not isinstance(instance, dict):
            raise ParseError("CONTRACT_INVALID", "%s: expected object" % path)
        props = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in instance:
                raise ParseError("CONTRACT_INVALID", "%s.%s: required missing" % (path, key))
        if schema.get("additionalProperties") is False:
            extra = sorted(set(instance) - set(props))
            if extra:
                raise ParseError("CONTRACT_INVALID", "%s: additional %s" % (path, extra))
        for key, child in props.items():
            if key in instance:
                validate_schema(instance[key], child, "%s.%s" % (path, key), seen)
        return
    if typ == "array":
        if not isinstance(instance, list):
            raise ParseError("CONTRACT_INVALID", "%s: expected array" % path)
        for i, child in enumerate(instance):
            validate_schema(child, schema.get("items", {}), "%s[%d]" % (path, i), seen)
        return
    if typ == "integer":
        if not isinstance(instance, int) or isinstance(instance, bool):
            raise ParseError("CONTRACT_INVALID", "%s: expected integer" % path)
        return
    if typ == "number":
        if not isinstance(instance, (int, float)) or isinstance(instance, bool):
            raise ParseError("CONTRACT_INVALID", "%s: expected number" % path)
        return
    if typ == "string":
        if not isinstance(instance, str):
            raise ParseError("CONTRACT_INVALID", "%s: expected string" % path)
        if len(instance) < schema.get("minLength", 0):
            raise ParseError("CONTRACT_INVALID", "%s: string too short" % path)
        pattern = schema.get("pattern")
        if pattern and re.fullmatch(pattern, instance) is None:
            raise ParseError("CONTRACT_INVALID", "%s: pattern mismatch" % path)
        if "enum" in schema and instance not in schema["enum"]:
            raise ParseError("CONTRACT_INVALID", "%s: outside enum" % path)
        return


def _numbered_items(lines, start):
    """Collect 'N.' / 'N：' items in reading order, stopping at IE工时.

    Handles multiple numbered heads on one line ('3.xxx4.yyy' -> 3 and 4).
    """
    items = []
    for line in lines[start:]:
        if "IE工时" in line:
            break
        segments = re.split(r"(?=\d+[\.：:](?!\d))", line)
        for seg in segments:
            m = re.match(r"(\d+)[\.：:](?!\d)\s*(.*)$", seg)
            if m and m.group(2).strip():
                items.append((int(m.group(1)), m.group(2).strip()))
    return items


def _split_sequences(items):
    """Split numbered items into step sequence(s); returns (steps, quality)."""
    if not items:
        return [], []
    steps, quality = [], []
    current = None
    for num, text in items:
        if num == 1 and (current is not None):
            # a new sequence starts -> previous was steps, this one is quality
            quality.append((num, text))
            current = "quality"
        elif current == "quality":
            quality.append((num, text))
        else:
            steps.append((num, text))
            current = "steps"
    return steps, quality


def _table_columns(header):
    cols = []
    if "使用材料" in header:
        cols.append("materials")
    if "设备及模治具" in header:
        cols.append("equipment")
    if "检测仪器" in header:
        cols.append("inspection")
    if "设备参数" in header:
        cols.append("parameters")
    if "品质要求" in header:
        cols.append("quality")
    return cols


def _table_values(line):
    """Split a table values line into cells (2+ spaces, then 1+ space fallback)."""
    parts = [p for p in re.split(r"\s{2,}", line) if p]
    if len(parts) < 2:
        parts = [p for p in line.split() if p]
    return parts


def parse_page(page, page_no):
    """Parse one work-instruction page into an operation candidate fragment."""
    text = page.extract_text() or ""
    if not text.strip():
        raise ParseError("EMPTY_PAGE", "page %d has no extractable text" % page_no)
    lines = [l.strip() for l in text.splitlines()]
    lines = [l for l in lines if l]

    # --- operation identity ---
    seq_m = re.search(r"序号\s*(\d+)", text)
    seq = int(seq_m.group(1)) if seq_m else None
    name_m = re.search(r"制作工站[：:]\s*([^\s，,；;、]+)", text)
    name = name_m.group(1) if name_m else None
    if seq is None or not name:
        # page 1 is the flow chart (no single operation); treat as unparseable op
        return None

    # --- region (page MediaBox; glyph-level positions unavailable for this doc) ---
    box = page.mediabox
    region = {
        "page": page_no,
        "left": str(float(box.left)),
        "top": str(float(box.top)),
        "width": str(float(box.width)),
        "height": str(float(box.height)),
    }

    # --- table header + values ---
    materials, equipment, inspection, parameters, quality = [], [], [], [], []
    header_idx = None
    header = ""
    for i, l in enumerate(lines):
        if "使用材料" in l:
            header_idx = i
            header = l
            break
    cols = _table_columns(header) if header_idx is not None else []
    has_inspection = "inspection" in cols
    has_params = "parameters" in cols
    parts = []
    if header_idx is not None and header_idx + 1 < len(lines):
        parts = _table_values(lines[header_idx + 1])
    MATERIAL_HINT = re.compile(r"半成品|线材|胶料|魔术贴|PE膜|防尘|清洁檫布|连接器")
    if "materials" in cols and parts and MATERIAL_HINT.search(parts[0]):
        materials.append(parts[0])
    EQUIP_HINT = re.compile(r"机|治具|刀|镊|钳|剪|尺")
    if "equipment" in cols:
        if len(parts) >= 2 and "materials" in cols:
            equipment.append(parts[1])
        elif len(parts) >= 1 and EQUIP_HINT.search(parts[0]):
            equipment.append(parts[0])  # 设备参数/单值变体：首值即设备
    if has_inspection and len(parts) >= 3:
        inspection.append(parts[2])
    # scattered fallbacks (pages 8-15 layouts; do not pull step text)
    if not equipment:
        best = (0, None)
        for l in lines:
            if EQUIP_HINT.search(l) and not re.search(
                    r"使用材料|作业步骤|图示|品质要求|IE工时|序号|^\d+[\.：:]", l):
                tokens = [tok for tok in l.split() if EQUIP_HINT.search(tok)]
                if len(tokens) > best[0]:
                    best = (len(tokens), tokens)
        if best[1]:
            equipment.append(" ".join(best[1]))
    if not materials:
        for l in lines:
            if re.search(r"半成品线材[，,]\s*(PE|Pvc|PVC)|胶料|魔术贴|清洁檫布|防尘", l) \
                    and not re.search(r"使用材料|作业步骤|品质要求|^\d+[\.：:]", l):
                head = re.split(r"\s+\d+[\.：:]", l)[0].strip()
                if head:
                    materials.append(head)
                break
    for l in lines:
        if re.search(r"^\s*[\d\-~.]+°|速度[：:]|压力[：:]|保压|料桶|温度[：:]|4K|\*HZ|分辨率", l):
            if l not in parameters:
                parameters.append(l)
    # HDMI version parameters (page 11): "a:1.4 4K1920*1080*60HZ ..."
    ver_m = re.search(r"[abc]:\s*([\d.]+)\s*(4K[\d*]*HZ)", text)
    if ver_m:
        parameters.append("%s %s" % (ver_m.group(1), ver_m.group(2)))

    # --- steps vs quality items ---
    body_start = 0
    for i, l in enumerate(lines):
        if re.match(r"^\d+[\.：:]", l):
            body_start = i
            break
    items = _numbered_items(lines, body_start)
    steps, quality_items = _split_sequences(items)
    for _, txt in quality_items:
        if txt and txt not in quality:
            quality.append(txt)

    # --- confidence heuristic ---
    missing = 0
    if not materials:
        missing += 1
    if not equipment:
        missing += 1
    if not quality:
        missing += 1
    if has_inspection and not inspection:
        missing += 0.6
    confidence = round(max(0.5, 0.96 - 0.06 * missing), 2)

    op = {
        "seq": seq,
        "name": name,
        "page_ref": page_no,
        "region": region,
        "confidence": confidence,
        "provenance": {"level": "SCANNED_REAL", "source_refs": [SOURCE_ID]},
    }
    if materials:
        op["materials"] = [{"name": m, "page_ref": page_no, "region": region}
                           for m in materials[:4]]
    if equipment:
        op["equipment"] = [{"name": e, "page_ref": page_no, "region": region}
                           for e in equipment[:4]]
    if inspection:
        op["inspection"] = [{"item": i, "page_ref": page_no, "region": region}
                            for i in inspection[:4]]
    if quality:
        op["quality_standard"] = [{"item": q, "page_ref": page_no, "region": region}
                                  for q in quality[:4]]
    if parameters:
        op["parameters"] = [{"name": "设备参数", "value": p, "page_ref": page_no, "region": region}
                            for p in parameters[:6]]
    # NOTE: std_minutes intentionally ABSENT (PDF gives no per-operation工时)
    return op


def extract_length_time_mapping(pdf_path=PDF_PATH):
    """Document-level IE工时 length->time mapping (real PDF data)."""
    reader = PdfReader(pdf_path)
    mapping = {}
    for page in reader.pages:
        text = page.extract_text() or ""
        m = re.search(r"IE工时\s*\n([\s\S]*?)(?:\n\s*图|\Z)", text)
        if not m:
            continue
        block = m.group(1)
        pairs = re.findall(r"([\d.]+)米\s*([\d.]+)米", block)
        for length, minutes in pairs:
            key = "%s米" % length
            mapping[key] = "%s米" % minutes
    return mapping


def extract_sop_candidate(pdf_path=PDF_PATH, source_id=SOURCE_ID):
    """Parse the real PDF into an m1.sop-candidate payload (non-authoritative)."""
    if PdfReader is None:
        raise ParseError("PDF_ENGINE_MISSING", "pypdf is not available")
    if not verify_source(pdf_path):
        raise ParseError("SOURCE_HASH_MISMATCH", "PDF hash != registered b279ce6a...")
    reader = PdfReader(pdf_path)
    operations = []
    for i in range(1, len(reader.pages)):  # page 1 is the flow chart
        op = parse_page(reader.pages[i], i + 1)
        if op is not None:
            operations.append(op)
    candidate = {
        "document_kind": "pdf-work-instruction",
        "document_pages": len(reader.pages),
        "source_refs": [source_id],
        "extraction_evidence": {"parser_version": PARSER_VERSION},
        "operations": operations,
        "provenance": {"level": "SCANNED_REAL", "source_refs": [source_id]},
    }
    validate_schema(candidate, _schema(CANDIDATE_SCHEMA))
    return candidate


def scoped_aggregate(base, tenant_id, site_id):
    def part(v):
        return base64.urlsafe_b64encode(v.encode("utf-8")).decode("ascii").rstrip("=")
    return "%s::%s::%s" % (base, part(tenant_id), part(site_id))


def _idempotency_scope(tenant_id, site_id, aggregate, key):
    return "%s|%s|%s|%s|%s" % (tenant_id, site_id, COMMAND_ID, aggregate, key)


def _lock_key(value):
    raw = hashlib.sha256(value.encode("utf-8")).digest()[:8]
    return int.from_bytes(raw, byteorder="big", signed=True)


def submit_sop_candidate(*, task_id, idempotency_key, tenant_id="tenant-r0",
                         site_id="site-r0", pdf_path=PDF_PATH, source_id=SOURCE_ID,
                         actor_ref="m1-sop-parser"):
    """Parse -> validate -> persist candidate record (fact_type m1.sop-candidate).

    Never promotes to a business fact.  Same-key resubmission returns REPLAY;
    the scope check + insert share one transaction under an advisory lock so
    concurrent same-key submits cannot double-apply (T-098 hardening).
    """
    if not task_id or not idempotency_key:
        raise ParseError("SCOPE_MISSING", "task_id/idempotency_key are required")
    candidate = extract_sop_candidate(pdf_path, source_id)
    candidate_id = db.new_id("cand")
    payload = {"candidate_id": candidate_id, "candidate": candidate,
               "task_id": task_id, "source_id": source_id}
    checksum = db.checksum_of(payload)
    aggregate = scoped_aggregate("r0-sop-candidate", tenant_id, site_id)
    scope = _idempotency_scope(tenant_id, site_id, aggregate, idempotency_key)
    command_id = db.new_id("cmd")
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT pg_advisory_xact_lock(%s)", (_lock_key(scope),))
            cur.execute("SELECT receipt_id FROM command_receipts WHERE idempotency_scope=%s LIMIT 1",
                        (scope,))
            row = cur.fetchone()
            if row:
                return {"status": "REPLAY", "candidate_id": candidate_id,
                        "receipt_id": row[0], "candidate": candidate}
            fid = db.new_id("fact")
            rid = db.new_id("rcpt")
            eid = db.new_id("evt")
            cur.execute("INSERT INTO facts(id, aggregate_id, fact_type, revision, payload, checksum) "
                        "VALUES(%s,%s,%s,1,%s,%s)",
                        (fid, aggregate, CANDIDATE_FACT_TYPE, json.dumps(payload, ensure_ascii=False), checksum))
            cur.execute("INSERT INTO outbox(id, event_id, payload) VALUES(%s,%s,%s)",
                        (db.new_id("out"), eid, json.dumps(
                            {"fact_id": fid, "fact_type": CANDIDATE_FACT_TYPE, "revision": 1,
                             "task_id": task_id}, ensure_ascii=False)))
            cur.execute(
                "INSERT INTO command_receipts(receipt_id, command_id, task_id, aggregate_id, "
                "idempotency_scope, request_checksum, status, terminal, previous_revision, "
                "applied_revision, applied_checksum, actor_ref) "
                "VALUES(%s,%s,%s,%s,%s,%s,'APPLIED',TRUE,0,1,%s,%s)",
                (rid, command_id, task_id, aggregate, scope, checksum, checksum, actor_ref))
            apply = {"fact_id": fid, "revision": 1, "checksum": checksum,
                     "receipt_id": rid, "event_id": eid}
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"status": "APPLIED", "apply": apply, "candidate": candidate,
            "candidate_id": candidate_id}


def get_latest_sop_candidate(tenant_id="tenant-r0", site_id="site-r0", task_id=None):
    """Task-scoped latest candidate (never global; missing task_id refused)."""
    if not task_id:
        raise ParseError("SCOPE_MISSING", "task_id is required for candidate queries")
    aggregate = scoped_aggregate("r0-sop-candidate", tenant_id, site_id)
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT f.payload FROM facts f "
                "JOIN command_receipts r ON r.aggregate_id=f.aggregate_id AND r.task_id=%s "
                "WHERE f.aggregate_id=%s AND f.fact_type=%s "
                "ORDER BY f.revision DESC LIMIT 1", (task_id, aggregate, CANDIDATE_FACT_TYPE))
            row = cur.fetchone()
            if not row:
                return None
            payload = row[0]
            if isinstance(payload, str):
                payload = json.loads(payload)
            return payload.get("candidate")
    finally:
        conn.close()
