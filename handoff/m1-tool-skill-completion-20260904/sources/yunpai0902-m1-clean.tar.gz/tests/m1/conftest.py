import os
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "services"))
sys.path.insert(0, os.path.join(ROOT, ".pylibs"))


def _psql(user, db, sql):
    return subprocess.run(["docker", "exec", "-i", "yunpai-pg", "psql", "-U", user,
                           "-d", db, "-v", "ON_ERROR_STOP=1", "-c", sql],
                          capture_output=True, text=True)


@pytest.fixture(autouse=True)
def clean_m1():
    _psql("yunpai_m1_migrator", "yunpai_m1",
          "TRUNCATE facts, outbox, command_receipts, attempt_records RESTART IDENTITY")
    yield
    _psql("yunpai_m1_migrator", "yunpai_m1",
          "TRUNCATE facts, outbox, command_receipts, attempt_records RESTART IDENTITY")
