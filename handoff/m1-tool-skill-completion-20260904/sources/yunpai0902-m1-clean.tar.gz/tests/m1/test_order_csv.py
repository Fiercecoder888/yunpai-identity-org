"""T-099-M1: hardened 0826 CSV order parse -> candidate (no implicit defaults).

Evidence level: L1/L2 — schema-conformant candidate, per-field row/confidence
report, BLOCKED_INPUT/INPUT_INVALID on missing fields / wrong units / illegal
qty / duplicate or multi product; parse never writes an order-fact.
"""
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "services"))

from m1 import provider as m1p
from common import contracts as ctr

SRC = "SRC-UPLOAD-001"
CSV_OK = "订单号,项目号,产品名称,数量,单位,交期,产品编码\nORD-U-1,PRJ-U-1,HDMI 线材,100,PCS,2026-09-30,HDMI-2.0-1.5M\n"
CSV_NO_CODE = "订单号,项目号,产品名称,数量,单位,交期\nORD-U-1,PRJ-U-1,HDMI 线材,100,PCS,2026-09-30\n"


def test_parse_valid_0826_csv():
    cand, report = m1p.parse_order_csv(CSV_OK, SRC, customer="客户A")
    assert cand["order_no"] == "ORD-U-1" and cand["customer"] == "客户A"
    assert len(cand["lines"]) == 1
    line = cand["lines"][0]
    assert line["line_no"] == 2 and line["product_code"] == "HDMI-2.0-1.5M"
    assert line["qty"] == "100" and line["uom"] == "PCS" and line["due_date"] == "2026-09-30"
    assert line["provenance"]["source_refs"] == [SRC]
    # schema-conformant
    err = ctr.validate(cand, ctr.schema_of("m1.order-candidate.v1"))
    assert err is None, err
    # report: per-field row + confidence
    assert report["checksum"] and report["row_count"] == 1
    assert report["fields"][0]["line_no"] == 2
    assert report["fields"][0]["fields"]["数量"]["confidence"] == 1.0


def test_missing_field_blocked():
    csv = "订单号,产品名称,数量,单位,交期\nORD-U-1,HDMI 线材,,PCS,2026-09-30\n"
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "BLOCKED_INPUT"
    assert "数量" in e.value.message


def test_missing_product_code_blocked_no_default():
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(CSV_NO_CODE, SRC, customer="客户A")
    assert e.value.code == "BLOCKED_INPUT"
    assert "product_code" in e.value.message and "default" in e.value.message


def test_missing_customer_blocked():
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(CSV_OK, SRC)
    assert e.value.code == "BLOCKED_INPUT"
    assert "customer" in e.value.message


def test_wrong_unit_invalid():
    csv = CSV_OK.replace("PCS", "EACH")
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "INPUT_INVALID"
    assert "uom" in e.value.message


def test_illegal_qty_invalid():
    for q in ("0", "-5", "abc"):
        csv = CSV_OK.replace("100,", q + ",")
        with pytest.raises(m1p.OrderInputError) as e:
            m1p.parse_order_csv(csv, SRC, customer="客户A")
        assert e.value.code == "INPUT_INVALID", q
        assert "qty" in e.value.message, q


def test_bad_date_invalid():
    csv = CSV_OK.replace("2026-09-30", "not-a-date")
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "INPUT_INVALID"
    assert "due_date" in e.value.message


def test_duplicate_product_invalid():
    csv = CSV_OK + "ORD-U-1,PRJ-U-1,HDMI 线材,50,PCS,2026-09-30,HDMI-2.0-1.5M\n"
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "INPUT_INVALID"
    assert "duplicate product" in e.value.message


def test_multi_product_invalid():
    csv = CSV_OK + "ORD-U-1,PRJ-U-1,另一产品,50,PCS,2026-09-30,OTHER-001\n"
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "INPUT_INVALID"
    assert "multi-product" in e.value.message


def test_multi_order_invalid():
    csv = CSV_OK + "ORD-U-2,PRJ-U-2,HDMI 线材,50,PCS,2026-09-30,HDMI-2.0-1.5M\n"
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_csv(csv, SRC, customer="客户A")
    assert e.value.code == "INPUT_INVALID"


def test_parse_never_writes_order_fact():
    """解析只输出候选；不写 order-fact（无权威写入）。"""
    from common import db
    m1p.parse_order_csv(CSV_OK, SRC, customer="客户A")
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM facts WHERE fact_type='m1.order-fact'")
            assert cur.fetchone()[0] == 0
    finally:
        conn.close()
