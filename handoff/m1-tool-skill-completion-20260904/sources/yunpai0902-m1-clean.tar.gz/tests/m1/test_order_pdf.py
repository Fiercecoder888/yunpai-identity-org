"""T-099-M1: real order PDF parse -> order-candidate (multi-line, no implicit defaults).

Evidence level: L1/L2 — schema-conformant candidate (m1.order-candidate.v1),
per-line length/uom-mapping report, BLOCKED_INPUT/INPUT_INVALID on missing
customer/order fields / unreadable PDF; parse never writes an order-fact.
Fixture PDF is generated in-memory with reportlab (STSong-Light CID), mirroring
the real 桐曦 PO-20260819-007 layout (3 models, 5M/10M/15M, 2000 条 each).
"""
import io
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "services"))

from m1 import provider as m1p
from common import contracts as ctr

SRC = "SRC-REAL-HDTV-PO-20260819-007"


def _pdf(lines_text, order_no="PO-20260819-007", due="2026 年 09 月 15 日",
         customer="东莞市唯格电子科技有限公司"):
    from reportlab.pdfgen import canvas
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.setFont('STSong-Light', 10)
    c.drawString(50, 800, customer)
    c.drawString(50, 780, "采购合同")
    c.drawString(50, 760, "订单号码：" + order_no)
    c.drawString(50, 740, "交货日期：" + due)
    y = 700
    for ln in lines_text:
        c.drawString(50, y, ln)
        y -= 20
    c.showPage()
    c.save()
    return buf.getvalue()


REAL_LINES = [
    "1 DZW-H39-R 5M足米 2000 条 6.5 13000",
    "2 DZW-H41-R 10M足米 2000 条 10.8 21600",
    "3 DZW-H42-R 15M足米 2000 条 15.3 30600",
]


def test_parse_real_style_pdf_multi_line():
    cand, report = m1p.parse_order_pdf(_pdf(REAL_LINES), SRC, customer="东莞市唯格电子科技有限公司")
    assert cand["order_no"] == "PO-20260819-007"
    assert cand["customer"] == "东莞市唯格电子科技有限公司"
    assert len(cand["lines"]) == 3
    codes = [l["product_code"] for l in cand["lines"]]
    assert codes == ["DZW-H39-R", "DZW-H41-R", "DZW-H42-R"]
    for l in cand["lines"]:
        assert l["qty"] == "2000" and l["uom"] == "PCS" and l["due_date"] == "2026-09-15"
        assert l["provenance"]["source_refs"] == [SRC]
    # schema-conformant
    err = ctr.validate(cand, ctr.schema_of("m1.order-candidate.v1"))
    assert err is None, err
    # report: per-line length + uom mapping + document customer cross-check
    assert report["document_customer"] == "东莞市唯格电子科技有限公司"
    lengths = [f["length"] for f in report["fields"]]
    assert lengths == ["5M", "10M", "15M"]
    assert all(f["uom_source"] == "条" and f["uom_mapped"] == "PCS" for f in report["fields"])


def test_missing_customer_blocked():
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_pdf(_pdf(REAL_LINES), SRC)
    assert e.value.code == "BLOCKED_INPUT"
    assert "customer" in e.value.message


def test_missing_order_no_blocked():
    pdf = _pdf(REAL_LINES, order_no="")
    # blank order number -> PDF still renders; 订单号码： present but empty -> no match
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_pdf(pdf, SRC, customer="C")
    assert e.value.code in ("BLOCKED_INPUT", "INPUT_INVALID")


def test_missing_due_date_blocked():
    pdf = _pdf(REAL_LINES, due="待定")
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_pdf(pdf, SRC, customer="C")
    assert e.value.code == "BLOCKED_INPUT"
    assert "交货日期" in e.value.message


def test_line_missing_length_qty_blocked():
    pdf = _pdf(["1 DZW-H39-R 无长度信息"], SRC)
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_pdf(pdf, SRC, customer="C")
    assert e.value.code == "BLOCKED_INPUT"
    assert "length/qty" in e.value.message


def test_non_pdf_invalid():
    with pytest.raises(m1p.OrderInputError) as e:
        m1p.parse_order_pdf(b"this is not a pdf", SRC, customer="C")
    assert e.value.code == "INPUT_INVALID"


def test_parse_never_writes_order_fact():
    """解析只输出候选；不写 order-fact（无权威写入）。"""
    from common import db
    m1p.parse_order_pdf(_pdf(REAL_LINES), SRC, customer="C")
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM facts WHERE fact_type='m1.order-fact'")
            assert cur.fetchone()[0] == 0
    finally:
        conn.close()
