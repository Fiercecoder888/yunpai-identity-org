"""T-097-M1: real PDF SOP extraction -> m1.sop-candidate (non-authoritative).

Evidence level: L2/L3 — real input (SHA b279ce6a authoritative), schema
conformance, page/region locatability, confidence range, BLOCKED_INPUT
(no per-operation std_minutes), candidate persistence with NO auto-fact.
"""
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "services"))

from m1 import sop_parser as sp
from common import db

PDF_PATH = "/Users/murkydoubloon45/Desktop/yunpai.nosync/output/pdf/HDTV 作业指导书.pdf"


def test_real_pdf_parses_14_operations():
    cand = sp.extract_sop_candidate()
    ops = cand["operations"]
    assert len(ops) == 14
    seqs = [o["seq"] for o in ops]
    assert min(seqs) == 1 and max(seqs) == 12
    names = [o["name"] for o in ops]
    for expected in ("脱皮", "分线.激光", "理线", "排卡", "焊接", "测试",
                     "成型内模", "成型外模", "成品测试", "清洁", "扎线", "贴标签", "覆膜"):
        assert any(expected in n for n in names), expected
    assert cand["document_kind"] == "pdf-work-instruction"
    assert sp.SOURCE_ID in cand["source_refs"]


def test_every_field_locatable_to_page_and_region():
    cand = sp.extract_sop_candidate()
    for op in cand["operations"]:
        assert op["page_ref"] >= 2
        reg = op["region"]
        for key in ("page", "left", "top", "width", "height"):
            assert reg.get(key) not in (None, ""), key
        assert reg["page"] == op["page_ref"]
        # field-level locatability
        for field in ("materials", "equipment", "inspection", "quality_standard", "parameters"):
            for item in op.get(field, []):
                assert item.get("page_ref") == op["page_ref"]
                assert item.get("region") == reg


def test_confidence_in_range():
    cand = sp.extract_sop_candidate()
    for op in cand["operations"]:
        assert 0.0 <= op["confidence"] <= 1.0


def test_candidate_schema_conformance_and_rejection():
    cand = sp.extract_sop_candidate()  # raises ParseError if schema-invalid
    assert cand["operations"]
    bad = {"document_kind": "pdf-work-instruction", "operations": []}  # missing required
    with pytest.raises(sp.ParseError) as e:
        sp.validate_schema(bad, sp._schema(sp.CANDIDATE_SCHEMA))
    assert e.value.args[0] == "CONTRACT_INVALID"


def test_std_minutes_absent_means_blocked_input():
    """完成标准：未确认工时不得默认或伪造——PDF 无每工序工时，候选必须缺失。"""
    cand = sp.extract_sop_candidate()
    for op in cand["operations"]:
        assert "std_minutes" not in op


def test_anomalies_preserved_for_human_review():
    """重复序号/内模外模/PE-PVC 原样保留，交由 M2 人工审核。"""
    cand = sp.extract_sop_candidate()
    seqs = [o["seq"] for o in cand["operations"]]
    dup = {s for s in seqs if seqs.count(s) > 1}
    assert dup == {8, 12}
    names = [o["name"] for o in cand["operations"]]
    assert names.count("成型内模") == 2 and "成型外模" in names
    all_mats = " ".join(m["name"] for o in cand["operations"] for m in o.get("materials", []))
    assert "PE胶料" in all_mats and ("PVC" in all_mats or "Pvc" in all_mats)


def test_length_time_mapping_from_pdf():
    """IE工时 长度->工时 表（真实 PDF 数据，供 M2/M5 长度映射）。"""
    mapping = sp.extract_length_time_mapping()
    assert mapping == {"1米": "5米", "1.5米": "10米", "2米": "15米", "3米": "20米"}


def test_submit_persists_candidate_only_no_auto_fact():
    r = sp.submit_sop_candidate(task_id="TASK-SOP-1", idempotency_key="k-sop-1")
    assert r["status"] == "APPLIED"
    assert r["candidate"]["operations"]
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT fact_type, count(*) FROM facts GROUP BY fact_type")
            rows = dict(cur.fetchall())
            assert rows.get("m1.sop-candidate") == 1
            # 禁止自动成为 Fact：不得有路线/事实类记录
            for bad in ("m1.sop-route-fact", "m1.sop-fact", "m2.sop-route-fact"):
                assert bad not in rows, bad
    finally:
        conn.close()


def test_submit_idempotent_replay():
    r1 = sp.submit_sop_candidate(task_id="TASK-SOP-1", idempotency_key="k-sop-1")
    r2 = sp.submit_sop_candidate(task_id="TASK-SOP-1", idempotency_key="k-sop-1")
    assert r1["status"] == "APPLIED" and r2["status"] == "REPLAY"
    assert r2["receipt_id"] == r1["apply"]["receipt_id"]
    conn = db.connect("m1")
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT count(*) FROM facts WHERE fact_type='m1.sop-candidate'")
            assert cur.fetchone()[0] == 1
    finally:
        conn.close()


def test_get_latest_candidate_returns_parsed_route():
    sp.submit_sop_candidate(task_id="TASK-SOP-1", idempotency_key="k-sop-1")
    latest = sp.get_latest_sop_candidate(task_id="TASK-SOP-1")
    assert latest is not None
    assert len(latest["operations"]) == 14
    assert latest["provenance"]["level"] == "SCANNED_REAL"


def test_no_pdf_bytes_in_repo():
    assert not os.path.isfile(os.path.join(ROOT, "HDTV 作业指导书.pdf"))
    assert not os.path.isfile(os.path.join(ROOT, "platform", "source-assets", "HDTV 作业指导书.pdf"))
